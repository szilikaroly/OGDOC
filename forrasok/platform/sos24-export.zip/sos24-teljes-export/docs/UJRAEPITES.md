# Újraépítési kézikönyv (Rebuild Guide)

Ez a dokumentum mindent tartalmaz ahhoz, hogy a portál **nulláról**, más környezetben (saját Supabase + tetszőleges hosting) is felépíthető legyen.

---

## 1. Előfeltételek

| Eszköz | Verzió |
|---|---|
| Node.js | ≥ 20 (vagy Bun ≥ 1.1) |
| Deno | ≥ 1.45 (Edge Functionök teszteléséhez) |
| Supabase CLI | ≥ 1.190 |
| PostgreSQL kliens | `psql`, `pg_dump` (séma import/export) |

---

## 2. Környezeti változók

### Frontend (`.env`, Vite – csak publikus értékek!)

```
VITE_SUPABASE_PROJECT_ID="<project-ref>"
VITE_SUPABASE_URL="https://<project-ref>.supabase.co"
VITE_SUPABASE_PUBLISHABLE_KEY="<anon/publishable key>"
```

### Backend (Edge Function secretek – soha ne kerüljenek a repóba)

| Secret | Szerep |
|---|---|
| `SUPABASE_URL` | Projekt URL |
| `SUPABASE_ANON_KEY` / `SUPABASE_PUBLISHABLE_KEY` | Kliens hitelesítés |
| `SUPABASE_SERVICE_ROLE_KEY` | Admin műveletek (user kezelés, bulk import) |
| `SUPABASE_DB_URL` | Közvetlen DB kapcsolat |
| `SUPABASE_JWKS` | JWT verifikáció Edge Functionben |
| `LOVABLE_API_KEY` | AI Gateway (összes `ai-*` függvény) |
| `CRON_SECRET` | `check-reminders`, `security-alert-monitor` védelme |
| `email_queue_service_role_key` (vault) | `email_queue_dispatch()` pg_cron hívásokhoz |

Beállítás: `supabase secrets set NEV=ertek`.

---

## 3. Adatbázis felépítése

```bash
# 1) Séma (táblák, enumok, függvények, RLS policyk, indexek)
psql "$SUPABASE_DB_URL" -f supabase/schema.sql

# 2) Storage policyk
psql "$SUPABASE_DB_URL" -f supabase/storage-policies.sql
```

Alternatíva (inkrementálisan, verziózottan):

```bash
supabase link --project-ref <ref>
supabase db push          # a supabase/migrations/*.sql 75 migrációját sorrendben futtatja
```

### Kötelező szabályok minden új táblánál

1. `CREATE TABLE public.x (...)`
2. `GRANT SELECT, INSERT, UPDATE, DELETE ON public.x TO authenticated;` + `GRANT ALL ... TO service_role;` (anon **csak** ha van anon policy)
3. `ALTER TABLE public.x ENABLE ROW LEVEL SECURITY;`
4. `CREATE POLICY ...` – szerepellenőrzés mindig `public.has_role(auth.uid(), 'role')`-lal

Időfüggő szabályt (`expire_at > now()`) **trigger**tel validálj, ne CHECK constraint-tel.

### Kulcsfontosságú DB függvények

| Függvény | Szerep |
|---|---|
| `has_role(uuid, app_role)` | Jogosultság-ellenőrzés RLS-ben (SECURITY DEFINER, nem rekurzív) |
| `get_user_roles(uuid)` | Szerepkörök tömbben |
| `handle_new_user()` | Profil automatikus létrehozása regisztrációkor |
| `is_company_member`, `is_employer_of_patient` | Cég-hierarchia jogosultságok |
| `audit_trigger_func()` | Általános audit log trigger |
| `log_security_event(...)` | RLS-megtagadás / biztonsági esemény naplózás |
| `generate_lab_request_number`, `generate_lab_order_number` | Sorszámozás (`LKR-ÉÉÉÉ-NNNN`, `LO-ÉÉÉÉ-NNNN`) |
| `create_public_lab_order(...)` | Anonim laborrendelés biztonságos beszúrása |
| `get_public_locations()` | Publikus helyszínlista (a `locations` táblán nincs anon SELECT) |
| `enqueue_email`, `read_email_batch`, `move_to_dlq`, `email_queue_dispatch`, `email_queue_wake` | pgmq alapú e-mail sor + DLQ + pg_cron ébresztés |
| `admin_get_recovery_status`, `admin_get_recovery_history`, `admin_recovery_failures_summary`, `admin_get_user_providers` | Admin auth-diagnosztika (csak `super_admin`) |
| `search_icd_codes(query, version, limit)` | BNO/ICD kódok trigrám alapú keresése (`pg_trgm`) |
| `ai-icd-suggest` Edge Function | AI javaslat BNO kódokra leírás alapján |

### Kötelező seed adatok

- `app_role` enum már a sémában definiált.
- BNO/ICD: legalább a gyakori ICD-10 kódokat (`supabase/seed/icd-codes.sql`) töltsd be, különben a kereső üres marad.

---

## 4. Storage bucketek

| Bucket | Publikus | Tartalom |
|---|---|---|
| `medical-documents` | nem | Orvosi dokumentumok, leletek |
| `signatures` | nem | Orvosi aláírásképek |
| `risk-assessment-photos` | nem | Kockázatértékelés fotói |
| `sds-documents` | nem | Biztonsági adatlapok (SDS) |
| `accident-photos` | nem | Baleseti fotók |
| `og-images` | igen | Generált OG képek |

Fájlnév-szabály: magyar ékezeteket ASCII-re kell cserélni feltöltés előtt (`src/lib/storage-utils.ts`), különben 500-as hiba.

---

## 5. Auth beállítás

- E-mail + jelszó, **anonim regisztráció tiltva**, auto-confirm kikapcsolva.
- Google OAuth engedélyezve (`@lovable.dev/cloud-auth-js`); redirect URI mindig `window.location.origin` alapú, soha nem védett route.
- Fiók-összekapcsolás: `src/components/ConnectedAccounts.tsx` (`linkIdentity` / `unlinkIdentity`).
- Jelszó-visszaállítás: `/reset-password`, központosított hibaüzenetek `src/lib/auth-errors.ts`, 60 mp cooldown.
- Admin jelszókezelés: `admin-set-user-password` (HIBP „weak password” hibát magyarul jelzi).

---

## 6. Edge Functionök telepítése

```bash
supabase functions deploy --project-ref <ref>          # mind
supabase functions deploy ai-analysis --project-ref <ref>   # egy
```

`supabase/config.toml`-ban a cron-hívott függvényeknél `verify_jwt = false`, ezeket a `CRON_SECRET` védi.

---

## 7. Frontend build és hosting

```bash
bun install
bun run build      # dist/
```

Bármely statikus hosting (Lovable, Netlify, Vercel, S3+CDN). SPA fallback (`/* -> /index.html`) kötelező. A build-időben beégetett `VITE_*` változókat a hostingban is állítsd be.

---

## 8. Ütemezett feladatok (pg_cron)

| Job | Ütem | Cél |
|---|---|---|
| `process-email-queue` | 5 másodperc (önmagát ki/be kapcsolja, ha üres a sor) | e-mail sor kiürítése |
| emlékeztetők | napi | `check-reminders` (CRON_SECRET-tel) |
| biztonsági riasztás | óránként | `security-alert-monitor` |

---

## 9. Ismert buktatók (a projekt tapasztalataiból)

- `vite.config.ts` `optimizeDeps.include`-ban explicit kell: `react`, `react-dom`, `i18next` – különben „useState of null” hiba.
- Supabase Realtime `postgres_changes` **tilos** CMS hookokhoz → React Query cache invalidálás.
- 1000 soros lekérdezési limit: `range(from, to)` 1000-es kötegekben.
- Szerver oldali PDF: Helvetica, `ő→ö`, `ű→ü`, `\n`/`\r` → szóköz (WinAnsi crash ellen).
- Nyomtatás: `window.print()` inline iframe viewerrel (popup blokkoló miatt).
- Rich text: TipTap HTML → `dangerouslySetInnerHTML` + Tailwind `prose`, **mindig** DOMPurify sanitizálással.
- Edge Function auth: `getUser()`, ne `getClaims()`.
