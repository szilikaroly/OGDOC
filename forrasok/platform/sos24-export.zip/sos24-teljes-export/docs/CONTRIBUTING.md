# Közreműködési útmutató

## Fejlesztői környezet

```bash
bun install
cp .env.example .env
bun run dev
```

## Kötelező szabályok

1. **Design tokenek**: színt, árnyékot, gradienst kizárólag `src/index.css` + `tailwind.config.ts` tokeneken keresztül. Tilos `text-white`, `bg-[#...]` a komponensekben.
2. **RLS**: minden új `public` tábla → `GRANT` + `ENABLE ROW LEVEL SECURITY` + policy, ugyanabban a migrációban.
3. **Szerepkörök**: kizárólag `public.user_roles` + `has_role()`. Soha ne a profilon.
4. **Sanitizálás**: minden felhasználói vagy AI eredetű HTML → DOMPurify (`src/lib/sanitize-html.ts`), nyomtatásnál `esc()`.
5. **Edge Function**: mindig `requireUser()` / `hasAnyRole()` (`supabase/functions/_shared/auth.ts`); cron végpontnál `requireCronSecret()`.
6. **Nyelv**: hivatalos orvosi dokumentumok (beutaló, üzemorvosi vélemény) magyarul maradnak, fordítás nélkül.
7. **Auto-generált fájlok tilos szerkeszteni**: `src/integrations/supabase/client.ts`, `types.ts`, `supabase/config.toml`.

## Commit előtt

```bash
bun run lint && bun run test && bun run build
```

## Migrációk

Új migráció: `supabase/migrations/<timestamp>_<leiras>.sql`. Sose módosíts már kiadott migrációt — mindig újat írj.
