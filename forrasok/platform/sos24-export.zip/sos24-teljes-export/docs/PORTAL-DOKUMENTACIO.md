# SOS24 Foglalkozás-egészségügyi Portál — Teljes műszaki dokumentáció

> Verzió: 1.0 · Generálva: 2026-07-27
> Kapcsolódó exportok: [`supabase/schema.sql`](../supabase/schema.sql) (teljes adatbázis-séma),
> [`supabase/storage-policies.sql`](../supabase/storage-policies.sql) (tárhely hozzáférési szabályok),
> [`supabase/migrations/`](../supabase/migrations) (75 db időrendi migráció).

---

## 1. Áttekintés

A portál egy komplex, több szerepkörös **foglalkozás-egészségügyi és háziorvosi rendszer**,
amely egyszerre szolgál ki nyilvános marketing/CMS felületet és zárt, szerepkör-alapú
munkafolyamat-portálokat (admin, háziorvos, üzemorvos, munkáltató, munkavállaló, praxistag).

Fő funkciócsoportok:

| Terület | Rövid leírás |
|---|---|
| Nyilvános portál | CMS-vezérelt landing oldal, tevékenységek, laborwebshop, SEO |
| Időpontfoglalás | Slot-alapú kapacitáskezelés, naptár, emlékeztetők |
| Foglalkozás-egészségügy | Beutalók, vizsgálatok, orvosi vélemények, alkalmassági iratok |
| Háziorvosi praxis | Betegkarton, receptigénylés, beutalókérés, oltások, igazolások |
| Kockázatértékelés | ISO 45001 workflow, veszélyleltár, kockázati mátrix, SDS/REACH |
| Munkabalesetek | Hivatalos magyar baleseti jegyzőkönyv, fotódokumentáció, GPS |
| Labor | SYNLAB katalógus, árazás/markup, laborkérők, webshop rendelések |
| AI szolgáltatások | 20+ edge function (triázs, OCR, fordítás, SEO, kockázat-fotóelemzés) |
| Adminisztráció | Felhasználó- és jogosultságkezelés, CMS, e-mail sablonok, audit, GDPR |
| Biztonság | RLS mindenhol, security_events napló, riasztások, audit log |

---

## 2. Technológiai stack

**Frontend**
- React 18 + TypeScript 5 + Vite 5 (SWC plugin)
- Tailwind CSS 3 + shadcn/ui (Radix primitívek) + `tailwindcss-animate`, `@tailwindcss/typography`
- React Router v6 (`BrowserRouter`), TanStack Query v5 (szerver-állapot, cache-invalidáció)
- react-hook-form + zod (űrlapvalidáció), recharts (diagram), TipTap (rich text CMS)
- i18next + react-i18next + böngésző nyelvfelismerés
- dompurify (XSS), xlsx (import/export), date-fns, lucide-react

**Backend (Lovable Cloud / Supabase)**
- PostgreSQL 17 (RLS mindenhol), `pgmq` e-mail sor, `pg_cron` + `pg_net` ütemezés, `vault` titkok
- Supabase Auth (e-mail/jelszó + Google OAuth), `@lovable.dev/cloud-auth-js`
- 37 Deno edge function
- Storage: 6 bucket (5 privát, 1 publikus)

**Teszt / minőség**
- Vitest + Testing Library (unit), Playwright (E2E), ESLint + typescript-eslint

---

## 3. Szerepkörök és jogosultsági modell

Az `app_role` enum értékei (a szerepek **külön `user_roles` táblában** tárolódnak, soha nem a profilon):

| Szerep | Belépési útvonal | Leírás |
|---|---|---|
| `super_admin` | `/admin` | Teljes rendszeradminisztráció |
| `haziorvos` | `/haziorvos` | Háziorvosi praxis vezetése |
| `uzemorvos` | `/uzemorvos` | Üzemorvosi vizsgálatok, vélemények |
| `munkaltato` | `/munkaltato` | Cég, munkavállalók, beutalók, kockázatértékelés |
| `munkavallalo` | `/munkavallalo` | Saját egészségügyi adatok, időpontok |
| `praxistag` | `/praxistag` | Háziorvosi praxis páciense |

Egy felhasználónak több szerepe is lehet; a fejlécben lévő profilmenüből válthat
(`DashboardLayout` → `ROLE_REDIRECTS`).

**Jogosultsági rétegek**
1. `ProtectedRoute` (`allowedRoles`) — kliensoldali útvonalvédelem (UX).
2. RLS policy minden `public` táblán — a valódi védelem (230 policy).
3. `SECURITY DEFINER` segédfüggvények a rekurzió elkerülésére:
   `has_role`, `get_user_roles`, `is_company_member`, `is_employer_of_patient`.
4. Edge function szintű `requireUser` / `hasAnyRole` / `requireCronSecret`
   (`supabase/functions/_shared/auth.ts`).

---

## 4. Útvonaltérkép (route map)

### 4.1 Nyilvános
| Útvonal | Oldal | Funkció |
|---|---|---|
| `/` | `Index` | Landing: hero, tevékenységek, szolgáltatások, labor, rólunk, CTA, helyszínek |
| `/login` | `Login` | E-mail/jelszó + Google bejelentkezés |
| `/register` | `Register` | Regisztráció + Google |
| `/reset-password` | `ResetPassword` | Jelszó-visszaállítás, új link küldése 60 mp cooldownnal |
| `/tevekenysegeink` | `ActivitiesListPage` | CMS tevékenységlista |
| `/tevekenyseg/:slug` | `ActivityPage` | Tevékenység aloldal, saját SEO mezőkkel |
| `/labor` | `LabShop` | Nyilvános laborwebshop (kosár, helyszín/otthoni mintavétel) |
| `/unsubscribe`, `/email-unsubscribe` | leiratkozás | E-mail leiratkozás tokennel |
| `*` | `NotFound` | 404 |

### 4.2 `/admin` (super_admin)
`users`, `companies`, `examinations`, `services`, `activities`, `locations`, `slots`,
`cms`, `navigation`, `seo`, `translate`, `messages`, `document-tags`, `email-templates`,
`document-templates`, `risk-assessments`, `substances`, `marketing`, `lab-shop`,
`audit-log`, `security-events`, `gdpr`, `settings`.

### 4.3 `/haziorvos`
`patients`, `appointments`, `med-requests`, `requests`, `certificates`,
`questionnaires`, `documents`, `vaccinations`, `health-plans`, `lab-requests`, `messages`.

### 4.4 `/uzemorvos`
`examinations`, `appointments`, `employees`, `companies`, `referrals`, `opinions`,
`certificates`, `questionnaires`, `documents`, `vaccinations`, `statistics`,
`health-plans`, `risk-assessments`, `lab-requests`, `messages`.

### 4.5 `/munkaltato`
`employees`, `company`, `referrals`, `opinions`, `documents`, `reports`,
`risk-assessments`, `accidents`, `messages`.

### 4.6 `/munkavallalo`
`profile`, `appointments`, `health`, `journal`, `vaccinations`, `opinions`,
`questionnaires`, `health-plan`, `documents`, `accidents`, `labor`, `data-access`,
`gdpr`, `settings`, `messages`.

### 4.7 `/praxistag`
`profile`, `appointments`, `health`, `journal`, `medications`, `referral-request`,
`documents`, `labor`, `questionnaires`, `health-plan`, `messages`.

---

## 5. Funkcionális modulok részletesen

### 5.1 Tartalomkezelés (CMS)
- `site_settings` (kulcs–érték, téma és márkaadatok), `pages_content` (szekciók, TipTap HTML),
  `navigation_links` (fa struktúra), `activities` (aloldalak saját SEO-val), `services`,
  `service_categories`, `locations`.
- A frontend `src/hooks/use-cms.ts` hookjai olvassák, 5 perc `staleTime`-mal.
- Rich text mindig `dangerouslySetInnerHTML` + `prose` osztályokkal, előtte `sanitize-html.ts`.
- Téma (színek, betűtípus) CMS-ből: `use-theme-from-cms.ts`.

### 5.2 Többnyelvűség
- Statikus szótárak: `src/i18n/{hu,en,de,ro,sr,zh,fil}.json`.
- Adatbázis-oldali fordítások: `content_translations` (polimorf `table_name`/`record_id`/`field_name`/`language`).
- Admin felülírások: `i18n_overrides` (`use-i18n-overrides.ts`).
- AI fordító: `/admin/translate` + `ai-translate` edge function, tömeges CMS fordítás
  (`src/lib/auto-translate-cms.ts`).
- **Szabály:** hivatalos orvosi dokumentumok (beutaló, vélemény) mindig magyarul maradnak.

### 5.3 Időpontfoglalás
- `appointment_slots` (szolgáltatás, helyszín, orvos, asszisztens, kapacitás),
  `appointments` (`appointment_status`: pending/confirmed/cancelled/completed/no_show).
- Magyar munkaszüneti napok: `src/lib/hungarian-holidays.ts`.
- Naptárexport: `src/lib/ics-generator.ts` + `AddToCalendarButton`.
- Emlékeztetők: `check-reminders` edge function (cron, `CRON_SECRET`).

### 5.4 Foglalkozás-egészségügyi workflow
1. Munkáltató beutalót készít (`referrals`: FEOR, munkakör, kockázati tényezők, telephely).
2. Munkavállaló időpontot foglal → státusz `appointment_booked`.
3. Kérdőív kitöltése → trigger (`auto_update_referral_on_questionnaire`) átállítja
   `questionnaire_filled` státuszra.
4. Üzemorvos vizsgálatot rögzít (`examinations`: `patient_data`, `clinical_findings`,
   `opinion_status`, korlátozások, érvényesség).
5. Orvosi vélemény (`medical_opinions`) aláírással (`signature_data`) és PDF-fel.
6. A munkáltató **csak az alkalmassági eredményt** látja, a klinikai részleteket nem.

### 5.5 Háziorvosi / praxistag modul
- Törzskarton (`patient_cards`): allergiák, krónikus betegségek, gyógyszerek, család-
  és foglalkozási anamnézis, expozíciók, dohányzás/alkohol, szűrések.
- Receptigénylés (`medication_requests`) + gyógyszertörzs (`medications`, `MedicationSearch`).
- Beutalókérés (`requests`), igazolások (`certificates`), oltások (`vaccinations`).
- Egészségnapló: `health_journal` (vérnyomás, pulzus, súly, vércukor),
  `food_journal` és `stool_journal` AI-képelemzéssel.
- Egészségterv: `health_plans` + `ai-health-plan`, orvosi ajánlások: `doctor_recommendations`.

### 5.6 Kockázatértékelés (ISO 45001)
- Hierarchia: `companies` → `company_sites` → `work_areas` → `workplaces`.
- `risk_assessments` (státusz: draft/in_review/approved/archived, felülvizsgálati ciklus,
  előzmény-hivatkozás), `risk_assessment_hazards` (kategória, valószínűség × súlyosság =
  kockázati szint, intézkedési hierarchia, maradék kockázat).
- Fotódokumentáció: `risk_assessment_photos` + `ai-risk-photo-analysis`.
- Zaj- és rezgésmérés böngészőből: `NoiseMeter`, `VibrationMeter` → `noise_vibration_measurements`.
- Veszélyes anyagok: `hazardous_substances` (REACH SVHC import), `company_hazardous_substances`,
  biztonsági adatlap feldolgozás `work_area_sds_documents` + `ai-sds-analysis`.
- Nyomtatható változat: `PrintableRiskAssessment`.

### 5.7 Munkabaleseti jegyzőkönyv
- `accident_reports` — a hivatalos magyar nyomtatvány teljes mezőkészlete
  (munkáltatói adatok, sérült adatai, FEOR, baleseti kódok, súlyosság, kivizsgálás,
  aláírók), GPS-koordináta és fotók.
- Kódtárak: `src/lib/accident-codes.ts`, `feor-codes.ts`, `teaor-codes.ts`.
- Nyomtatás: `PrintableAccidentReport`.

### 5.8 Labor modul
- Katalógus a kódban: `src/lib/labTestCatalog*.ts` (Klinikai Kémia és bővítmények).
- Árazás: `lab_pricing_config` (pontszám + Ft), `lab_markup_config`
  (globális felár + otthoni mintavételi díj).
- **Árszabály:** a felár nem vonatkozik az „Elemi” tesztekre; a számítás egyetlen
  központi függvényben történik: `calculateDisplayPrice()` (`src/hooks/use-lab-pricing.ts`),
  unit tesztekkel. Az admin `LabPricingEditor` validációt és anomália-detektálást futtat.
- Csomagok: `lab_packages`, orvosi laborkérő: `lab_requests` (`LKR-ÉV-NNNN` sorszám),
  webshop rendelés: `lab_orders` (`LO-ÉV-NNNN`), anonim rendelés a
  `create_public_lab_order()` SECURITY DEFINER RPC-n keresztül.
- Nyomtatás: `src/lib/printLabRequest.ts` (HTML-escape XSS ellen).

### 5.9 Dokumentumkezelés
- `documents` (típus, kapcsolt rekord, címkék, AI-elemzés), `document_tags`,
  `document_templates` (dinamikus mezők), `DocumentBrowser`.
- Fájlnév-sanitizálás (magyar ékezetek → ASCII) a Storage 500-as hibák elkerülésére
  (`src/lib/storage-utils.ts`).
- PDF: szerveroldali `generate-pdf` (Helvetica, `ő→ö`, `ű→ü` csere a WinAnsi hibák miatt),
  kliensoldali nyomtatás inline iframe + `window.print()` (popup-blokkoló kerülése).

### 5.10 Kommunikáció és értesítések
- Belső üzenetek: `messages` (címzett vagy szerepkör-csoport), `useUnreadMessages` badge.
- Értesítések: `notifications` + `notification_preferences`, `NotificationBell`,
  natív Notification API (nem Service Worker push, hogy iframe előnézetben is működjön).
- E-mail: `pgmq` sor (`enqueue_email`, `read_email_batch`, `move_to_dlq`),
  `email_queue_wake` trigger + `email_queue_dispatch` cron,
  `process-email-queue` / `send-transactional-email` edge functionök,
  `email_send_log`, `suppressed_emails`, `email_unsubscribe_tokens`,
  sikertelen recovery e-mailnél admin értesítés (`notify_admins_on_recovery_failure`).

### 5.11 Felhasználókezelés (admin)
- `AdminUsers`: szerepkiosztás, telefon/e-mail szerkesztés élő ütközésvizsgálattal
  (`admin-check-email-available`, debounce), jelszóbeállítás (`admin-set-user-password`,
  HIBP „gyenge jelszó” hibák magyar üzenettel), visszaállító link és megerősítő link újraküldése.
- Diagnosztika: `admin_get_recovery_status`, `admin_get_recovery_history`,
  `admin_recovery_failures_summary`, `admin_get_user_providers`,
  UI: `AuthHealthDialog`, `RecoveryHistoryPanel`, `RecoveryFailuresSummary`.
- Tömeges praxistag import: `BulkPatientImport` (MedMax Excel), duplumszűrés TAJ és
  Név+születési dátum alapján, előnézet és élő folyamatjelzés, napló: `bulk_import_logs`,
  előzmények: `BulkImportHistory` (poll-intervallum, exponenciális backoff 2→60 mp,
  visszaszámláló, 6 sikertelen próbálkozás után végleges hiba + manuális frissítés).
- Fiók-összekapcsolás: `ConnectedAccounts` (`linkIdentity` / `unlinkIdentity`) — így nem
  jön létre duplikált fiók, ha ugyanazzal az e-mail-címmel jelentkeznek be Google-lel.

### 5.12 Marketing és SEO
- `seo_pages` (oldalankénti meta/OG/canonical/noindex), `seo_audit_scores`,
  `page_views`, `web_vitals`, versenytárs-elemzés (`competitor_urls`, `competitor_analyses`).
- `ai-seo` (SSRF-védelemmel), `ai-og-image` + `og-images` publikus bucket,
  `serve-sitemap` és `serve-llms-txt` edge functionök, `public/robots.txt`, `sitemap.xml`.
- `useSeo` hook a fejléc metaadatokhoz.

### 5.13 GDPR és audit
- `gdpr_requests` (adatkiadás/törlés), `MunkavallaloGdpr`, `AdminGdpr`.
- `audit_logs` + `audit_trigger_func()` (régi/új érték, változott mezők, felhasználó).
- Adathozzáférési átláthatóság a munkavállalónak: `/munkavallalo/data-access`.

---

## 6. AI szolgáltatások (Lovable AI Gateway)

| Edge function | Feladat |
|---|---|
| `ai-triage` | Panasz alapú triázs javaslat |
| `ai-chatbot` | Nyilvános chatbot a portálon |
| `ai-analysis` | Általános orvosi adatelemzés, anomália-jelzés |
| `ai-document-analysis` | Feltöltött leletek OCR + strukturálás |
| `ai-health-image-analysis` | Étkezési/széklet napló képelemzés |
| `ai-medical-note` | Orvosi jegyzet generálás/összegzés |
| `ai-opinion-draft` | Orvosi vélemény piszkozat |
| `ai-questionnaire-scoring` | Kérdőív pontozás (IDOR-védelemmel) |
| `ai-doctor-recommendation` | Személyre szabott orvosi ajánlás (kapcsolat-ellenőrzéssel) |
| `ai-health-plan` | Egészségterv generálás |
| `ai-risk-photo-analysis` | Munkahelyi fotó → veszélyforrás javaslat |
| `ai-sds-analysis` | Biztonsági adatlap kiolvasás |
| `ai-lab-recommend` | Laborcsomag ajánlás |
| `ai-travel-vaccines` | Utazási oltási tanácsadó |
| `ai-speech-to-text` | Diktálás (`SpeechToTextButton`) |
| `ai-translate` | CMS és i18n fordítás |
| `ai-seo` / `ai-og-image` | SEO szövegek és OG kép |
| `ai-marketing` / `ai-activity-content` | Marketing- és aloldal-tartalom |

Minden AI függvény JWT-hitelesítést vár, és a `LOVABLE_API_KEY`-t szerveroldalon használja.

---

## 7. Edge function katalógus (37 db)

**Adminisztráció:** `admin-update-user`, `admin-set-user-password`,
`admin-check-email-available`, `admin-preview-email`, `bulk-create-patients`, `invite-employer`.

**E-mail:** `process-email-queue`, `send-transactional-email`, `preview-transactional-email`,
`handle-email-unsubscribe`, `handle-email-suppression`, `send-notification`.

**Háttérfeladatok (cron, `CRON_SECRET`, `verify_jwt = false`):** `check-reminders`,
`security-alert-monitor`.

**Publikus kiszolgálás:** `serve-sitemap`, `serve-llms-txt`.

**Dokumentum:** `generate-pdf`.

**AI:** lásd 6. fejezet.

**Megosztott modulok:** `_shared/auth.ts` (hitelesítés, szerepellenőrzés, cron secret),
`_shared/audit.ts` (biztonsági naplózás), `_shared/sanitize.ts` (HTML/PDF input tisztítás,
payload limitek), `_shared/transactional-email-templates/`.

---

## 8. Adatbázis

### 8.1 Séma export
A teljes DDL (táblák, indexek, kulcsok, 230 RLS policy, 380 GRANT, függvények, triggerek,
enumok) a **[`supabase/schema.sql`](../supabase/schema.sql)** fájlban található,
`pg_dump --schema-only --schema=public` formátumban. Új környezetbe telepítés:

```bash
psql "$DATABASE_URL" -f supabase/schema.sql
psql "$DATABASE_URL" -f supabase/storage-policies.sql
```

Az időrendi változástörténet a `supabase/migrations/` mappában (75 fájl) van.

### 8.2 Táblacsoportok

| Csoport | Táblák |
|---|---|
| Identitás | `profiles`, `user_roles`, `user_company_relations` |
| Cégstruktúra | `companies`, `company_sites`, `work_areas`, `workplaces`, `company_teaor_codes`, `company_hazardous_substances` |
| Ellátás | `appointments`, `appointment_slots`, `services`, `service_categories`, `locations` |
| Foglalkozás-eü. | `referrals`, `examinations`, `medical_opinions`, `certificates` |
| Páciens | `patient_cards`, `health_reports`, `health_journal`, `food_journal`, `stool_journal`, `vaccinations`, `health_plans`, `doctor_recommendations`, `medication_requests`, `medications` |
| Kérdőívek | `questionnaires`, `questionnaire_assignments`, `questionnaire_submissions` |
| Kockázat | `risk_assessments`, `risk_assessment_hazards`, `risk_assessment_photos`, `noise_vibration_measurements`, `hazardous_substances`, `work_area_sds_documents` |
| Baleset | `accident_reports` |
| Labor | `lab_pricing_config`, `lab_markup_config`, `lab_packages`, `lab_requests`, `lab_orders` |
| Dokumentum | `documents`, `document_tags`, `document_templates` |
| CMS/SEO | `site_settings`, `pages_content`, `navigation_links`, `activities`, `content_translations`, `i18n_overrides`, `seo_pages`, `seo_audit_scores`, `page_views`, `web_vitals`, `competitor_urls`, `competitor_analyses` |
| Kommunikáció | `messages`, `notifications`, `notification_preferences`, `email_send_log`, `email_send_state`, `email_unsubscribe_tokens`, `suppressed_emails` |
| Üzemeltetés | `audit_logs`, `security_events`, `gdpr_requests`, `bulk_import_logs`, `requests` |

### 8.3 Enumok
`app_role`, `appointment_status`, `opinion_status`, `referral_status`, `request_status`,
`risk_assessment_status`, `hazard_category`, `action_hierarchy`, `action_status`,
`gender_type`, `blood_type`.

### 8.4 Fontosabb adatbázis-függvények
`has_role`, `get_user_roles`, `is_company_member`, `is_employer_of_patient`,
`handle_new_user`, `audit_trigger_func`, `log_security_event`, `security_denials_summary`,
`get_public_locations`, `create_public_lab_order`, `generate_lab_request_number`,
`generate_lab_order_number`, `auto_update_referral_on_questionnaire`,
`enqueue_email`, `read_email_batch`, `delete_email`, `move_to_dlq`,
`email_queue_wake`, `email_queue_dispatch`, `notify_admins_on_recovery_failure`,
`admin_get_recovery_status`, `admin_get_recovery_history`,
`admin_recovery_failures_summary`, `admin_get_user_providers`, `update_updated_at_column`.

### 8.5 Storage bucketek

| Bucket | Publikus | Tartalom |
|---|---|---|
| `medical-documents` | nem | Leletek, vélemények, igazolások |
| `signatures` | nem | Orvosi aláírásképek |
| `risk-assessment-photos` | nem | Kockázatértékelési fotók (tulajdonos-ellenőrzéssel) |
| `sds-documents` | nem | Biztonsági adatlapok |
| `accident-photos` | nem | Baleseti fotódokumentáció |
| `og-images` | igen | Generált közösségi megosztási képek |

---

## 9. Biztonsági architektúra

- **RLS mindenhol.** Minden `public` tábla RLS-védett; a policy-k `auth.uid()`-ra vagy
  `has_role()` / `is_company_member()` / `is_employer_of_patient()` SECURITY DEFINER
  függvényekre épülnek. Minden táblához explicit `GRANT` tartozik.
- **Szerepek külön táblában** (`user_roles`) — privilégium-eszkaláció elkerülése.
- **Edge function védelem:** JWT-ellenőrzés (`verify_jwt`), `requireUser`, szerepellenőrzés,
  IDOR-ellenőrzések, `CRON_SECRET` a háttérfeladatokhoz, SSRF-szűrés az URL-t fogadó
  függvényekben, payload-limitek.
- **XSS:** minden felhasználói/AI eredetű HTML `dompurify`-jal tisztítva; nyomtatási
  sablonokban manuális `esc()` escape.
- **Biztonsági napló:** `security_events` tábla + `log_security_event()` RPC,
  kliensoldali jelentő (`src/lib/security-monitor.ts`) RLS/storage megtagadásokra,
  `/admin/security-events` felület, `security-alert-monitor` e-mail riasztás.
- **Audit:** `audit_logs` triggerek a kritikus táblákon, `/admin/audit-log`.
- **Titkok:** kizárólag szerveroldalon (`Deno.env.get`), soha nem a kliensben.

---

## 10. Fejlesztői útmutató

```bash
bun install          # függőségek
bun run dev          # fejlesztői szerver (http://localhost:8080)
bun run build        # produkciós build
bunx vitest run      # unit tesztek
bunx playwright test # E2E tesztek
```

**Környezeti változók (`.env`, automatikusan generált):**
`VITE_SUPABASE_URL`, `VITE_SUPABASE_PUBLISHABLE_KEY`, `VITE_SUPABASE_PROJECT_ID`.
A szerveroldali titkok (`LOVABLE_API_KEY`, `CRON_SECRET`, `SUPABASE_SERVICE_ROLE_KEY` stb.)
a backend secret-tárban élnek.

**Kódkonvenciók**
- Színek, árnyékok, gradiensek kizárólag szemantikus tokenekként (`src/index.css`,
  `tailwind.config.ts`) — soha `text-white` / `bg-[#...]` a komponensekben.
- Supabase kliens importja: `import { supabase } from "@/integrations/supabase/client"`.
  A `client.ts` és `types.ts` generált fájlok, kézzel nem szerkesztendők.
- 1000 sor feletti lekérdezéseknél `range(from, to)` lapozás.
- CMS frissítés React Query cache-invalidációval, nem `postgres_changes` realtime-mal.
- `vite.config.ts` `optimizeDeps.include`: `react`, `react-dom`, `i18next` (kötelező).

---

## 11. Telepítés új környezetbe

1. Supabase projekt létrehozása, `supabase/schema.sql` és `storage-policies.sql` futtatása.
2. Storage bucketek létrehozása a 8.5 táblázat szerint (5 privát, `og-images` publikus).
3. Auth: e-mail/jelszó + Google provider engedélyezése, HIBP jelszóellenőrzés bekapcsolása,
   redirect URL-ek beállítása (`/`, `/reset-password`).
4. Secretek feltöltése: `LOVABLE_API_KEY`, `CRON_SECRET`, e-mail szolgáltató kulcsok.
5. Edge functionök deploya, `supabase/config.toml` `verify_jwt` beállításainak átvétele.
6. Cron: `email_queue_dispatch`, `check-reminders`, `security-alert-monitor` ütemezése.
7. Alapadatok feltöltése: `site_settings`, `navigation_links`, `services`, `locations`,
   `lab_pricing_config`, `hazardous_substances` (REACH import).

---

## 12. Fájlstruktúra

```
src/
  components/        közös és domain komponensek (nyomtatható sablonok, űrlapok, mérők)
    landing/         nyilvános landing szekciók
    admin/           admin segédpanelek
    ui/              shadcn/ui primitívek
  contexts/          AuthContext (session, szerepek, aktív szerep)
  hooks/             use-cms, use-lab-pricing, use-notifications, use-seo, ...
  i18n/              7 nyelv szótárai + i18n.ts
  integrations/      supabase kliens és generált típusok
  lib/               kódtárak (FEOR, TEÁOR, baleseti kódok), labor katalógus,
                     sanitizálás, nyomtatás, security-monitor, storage-utils
  pages/             útvonalankénti oldalak szerepkör szerinti mappákban
supabase/
  functions/         37 Deno edge function + _shared modulok
  migrations/        75 időrendi migráció
  schema.sql         teljes séma export
  storage-policies.sql
docs/                dokumentáció (ez a fájl, lab-pricing-audit, security-monitoring)
```
