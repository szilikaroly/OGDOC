# SOS24 Portál — Teljes export kalauz (tételes magyarázat)

Készült: 2026-09-01 · Csomag: `sos24-teljes-export-2026-09-01.zip`

Ez a dokumentum a csomag **minden részét tételesen** végigveszi: mi van benne, mire jó,
és hogyan lehet belőle a portált a nulláról újraépíteni.

---

## 1. A csomag felépítése

```text
sos24-teljes-export/
├── README-ELSO-LEPESEK.md      Gyorsindítás 6 lépésben
├── docs/                       Teljes dokumentáció (lásd 6. fejezet)
├── database/
│   ├── schema-public.sql       Séma DDL (táblák, indexek, függvények, triggerek, RLS)
│   ├── schema-public-with-grants.sql  Ugyanaz + GRANT-ok (EZT állítsd vissza!)
│   ├── reference-data.sql      Törzs- és tartalmi adatok (INSERT-ek)
│   ├── storage-policies.sql    Storage bucket szabályok
│   └── migrations/             A 78 időrendi migráció (fejlődéstörténet)
├── src/                        Teljes React/TypeScript frontend
├── supabase/functions/         40 Deno Edge Function
├── public/                     Statikus fájlok, PWA ikonok, robots.txt, sitemap
├── package.json, vite.config.ts, tailwind.config.ts, tsconfig*.json
├── playwright.config.ts, vitest.config.ts, .github/workflows/ci.yml
└── .env.example                Kitöltendő környezeti változók
```

---

## 2. Adatbázis — mit tartalmaz és hogyan áll vissza

### 2.1 Visszaállítás sorrendje

```bash
# 1) Séma (jogosultságokkal együtt!)
psql "$DB_URL" -f database/schema-public-with-grants.sql
# 2) Törzsadatok
psql "$DB_URL" -f database/reference-data.sql
# 3) Storage szabályok (a bucket-ek létrehozása után)
psql "$DB_URL" -f database/storage-policies.sql
```

> **Fontos:** a `schema-public.sql` a GRANT-ok nélküli változat (olvasáshoz, diff-hez).
> Éles visszaállításnál mindig a `...-with-grants.sql` fájlt használd, különben a
> Data API „permission denied" hibát ad, még akkor is, ha az RLS szabályok rendben vannak.

### 2.2 Mit NEM tartalmaz a `reference-data.sql` (szándékosan)

Személyes és egészségügyi adatokat **nem** exportáltunk (GDPR / különös kategória):
`profiles`, `patient_cards`, `medical_opinions`, `referrals`, `examinations`,
`accident_reports`, `health_journal`, `food_journal`, `stool_journal`,
`lab_orders`, `lab_requests`, `messages`, `notifications`, `documents`,
`audit_logs`, `security_events`, `companies`, `user_roles`, `user_company_relations`.
Ezek sémája megvan, tartalmuk nincs — új környezetben üresen indulnak.

### 2.3 Exportált törzs- és tartalmi táblák (soronkénti darabszámmal)

| Tábla | Sor | Mire jó |
|---|---|---|
| `medications` | 40 932 | Gyógyszertörzs a receptíráshoz / kereséshez |
| `hazardous_substances` | 3 013 | REACH/veszélyes anyag katalógus a kockázatértékeléshez |
| `content_translations` | 2 057 | Polimorf CMS fordítások (7 nyelv) |
| `lab_pricing_config` | 1 054 | Labor tételek listaárai (SYNLAB árlista alapján) |
| `services` | 70 | Szolgáltatás katalógus |
| `icd_codes` | 50 | BNO/ICD törzs (ICD-10 + ICD-11, trigram kereséssel) |
| `lab_packages` | 35 | Labor csomagok (LabShop) |
| `seo_pages` | 25 | Oldalankénti SEO metaadatok |
| `activities` | 15 | Tevékenység aloldalak (CMS) |
| `document_tags` / `document_templates` | 9 / 5 | Dokumentum címkék és sablonok |
| `site_settings` | 44 | Globális beállítások (téma, logók, elérhetőség) |
| `locations`, `service_categories`, `navigation_links`, `pages_content`, `questionnaires`, `i18n_overrides`, `lab_markup_config` | 6 / 6 / 5 / 4 / 6 / 6 / 1 | Helyszínek, kategóriák, menü, CMS blokkok, kérdőívek, felülírt fordítások, labor felárkonfig |

### 2.4 A 71 tábla funkció szerinti csoportosítása

- **Azonosítás és jogosultság:** `profiles`, `user_roles` (külön tábla — soha nem a profilon!),
  `user_company_relations`. A `has_role()` SECURITY DEFINER függvény oldja fel a
  rekurzív RLS problémát.
- **Cégek és munkahelyek:** `companies`, `company_sites`, `company_teaor_codes`,
  `workplaces`, `work_areas`, `company_hazardous_substances`.
- **Munkaegészségügy:** `examinations`, `medical_opinions`, `referrals`, `certificates`,
  `vaccinations`, `patient_cards`, `health_reports`, `health_plans`,
  `doctor_recommendations`, `medication_requests`, `requests`.
- **Kockázatértékelés / munkavédelem:** `risk_assessments`, `risk_assessment_hazards`,
  `risk_assessment_photos`, `hazardous_substances`, `work_area_sds_documents`,
  `noise_vibration_measurements`, `accident_reports`.
- **Labor:** `lab_orders`, `lab_requests`, `lab_packages`, `lab_pricing_config`,
  `lab_markup_config`.
- **Időpont:** `appointment_slots`, `appointments`.
- **Kérdőívek:** `questionnaires`, `questionnaire_assignments`, `questionnaire_submissions`.
- **Napló / önmonitorozás:** `health_journal`, `food_journal`, `stool_journal`.
- **CMS / marketing / SEO:** `pages_content`, `activities`, `services`,
  `service_categories`, `navigation_links`, `site_settings`, `seo_pages`,
  `seo_audit_scores`, `competitor_urls`, `competitor_analyses`, `page_views`,
  `web_vitals`, `content_translations`, `i18n_overrides`.
- **Kommunikáció:** `messages`, `notifications`, `notification_preferences`,
  `email_send_log`, `email_send_state`, `suppressed_emails`,
  `email_unsubscribe_tokens`.
- **Üzemeltetés / megfelelés:** `audit_logs`, `security_events`, `gdpr_requests`,
  `bulk_import_logs`, `documents`, `document_tags`, `document_templates`,
  `icd_codes`, `medications`.

### 2.5 Biztonsági alapelvek, amiket a séma kódol

1. Minden `public` tábla RLS-sel védett, és **minden** táblához tartozik explicit `GRANT`.
2. A jogosultság-ellenőrzés `SECURITY DEFINER` függvényeken keresztül fut
   (`has_role`, `get_public_locations`, `create_public_lab_order`,
   `log_security_event`), az `EXECUTE` jog csak a szükséges szerepekre van kiadva.
3. Publikus olvasás csak ott van, ahol tényleg kell (CMS, katalógusok) — a
   `locations` e-mail/telefon például kizárólag RPC-n keresztül érhető el.
4. Storage: minden bucket privát, hozzáférés a feltöltő/ügyintéző szerepéhez kötve.
5. Minden érzékeny művelet a `security_events` és `audit_logs` táblákba naplózódik.

---

## 3. Frontend (`src/`) — tételes magyarázat

| Útvonal | Tartalom |
|---|---|
| `src/main.tsx`, `src/App.tsx` | Belépési pont, provider-ek, teljes route-fa (6 portál) |
| `src/contexts/AuthContext.tsx` | Session, szerepkör-feloldás, Google OAuth kezelés |
| `src/components/ProtectedRoute.tsx` | Szerepalapú route-védelem |
| `src/components/DashboardLayout.tsx` | Közös vezérlőpult váz (sidebar, fejléc, értesítések) |
| `src/components/landing/*` | Nyilvános landing szekciók (Hero, Services, Lab, Locations, Footer…) |
| `src/components/Printable*.tsx` | Nyomtatható dokumentumok (beutaló, szakvélemény, baleset, kockázatértékelés, betegkarton) — `window.print()` + inline iframe |
| `src/components/Bno*.tsx` | BNO/ICD kereső, kiválasztó és AI javaslat dialógus |
| `src/components/Lab*.tsx` | LabShop kérőépítő, csomag- és árszerkesztő, AI asszisztens |
| `src/components/RiskAssessmentForm.tsx`, `RiskMatrix.tsx`, `SdsReader.tsx`, `HazardousSubstanceSelector.tsx` | ISO 45001 kockázatértékelési munkafolyamat |
| `src/components/AccidentReportForm.tsx` | Hivatalos munkabaleseti jegyzőkönyv (több lépcsős) |
| `src/components/BulkPatientImport.tsx`, `BulkImportHistory.tsx` | Csoportos praxistag-import előnézettel, duplumszűréssel, élő folyamatjelzéssel, exponenciális backoff-os pollozással |
| `src/components/ConnectedAccounts.tsx` | Fiókösszekapcsolás (Google identity link/unlink) |
| `src/hooks/*` | Adatelérés TanStack Query-vel: `use-cms`, `use-icd-codes`, `use-lab-pricing`, `use-notifications`, `use-seo`, `use-document-templates` stb. |
| `src/lib/*` | Segédek: kódtörzsek (FEOR, TEAOR, BNO, baleseti kódok), `sanitize-html` (DOMPurify), `security-monitor`, `storage-utils` (magyar ékezet-normalizálás), `auth-errors`, `ics-generator` |
| `src/i18n/*` | 7 nyelv (hu, en, de, ro, sr, zh, fil) + DB-alapú felülírás |
| `src/pages/admin/*` | 20+ admin oldal (felhasználók, cégek, CMS, SEO, labor, BNO, GDPR, audit, biztonsági események) |
| `src/pages/uzemorvos/*` | Üzemorvosi portál (vizsgálatok, szakvélemények, beutalók, statisztika) |
| `src/pages/haziorvos/*` | Háziorvosi portál (páciensek, receptkérések, kérdőívek) |
| `src/pages/munkaltato/*` | Munkáltatói portál (munkavállalók, riportok, balesetek, kockázatértékelés) |
| `src/pages/munkavallalo/*` | Munkavállalói portál (profil, egészség, naplók, GDPR, adathozzáférés) |
| `src/pages/praxistag/*` | Praxistag portál (időpont, gyógyszerek, üzenetek, beutalókérés) |

**Design rendszer:** minden szín/árnyék/gradiens szemantikus token az `src/index.css`-ben és
a `tailwind.config.ts`-ben; a komponensekben nincs beégetett színosztály.

---

## 4. Edge Function-ök (40 db) — mit csinálnak

- **Admin művelet (JWT + szerepellenőrzés):** `admin-update-user`,
  `admin-set-user-password`, `admin-check-email-available`, `admin-preview-email`,
  `bulk-create-patients`, `invite-employer`.
- **AI szolgáltatások (Lovable AI Gateway, kulcs nélkül):** `ai-analysis`,
  `ai-chatbot`, `ai-triage`, `ai-icd-suggest`, `ai-opinion-draft`, `ai-medical-note`,
  `ai-document-analysis`, `ai-health-image-analysis`, `ai-health-plan`,
  `ai-questionnaire-scoring`, `ai-doctor-recommendation`, `ai-lab-recommend`,
  `ai-risk-photo-analysis`, `ai-sds-analysis`, `ai-travel-vaccines`,
  `ai-speech-to-text`, `ai-translate`, `ai-marketing`, `ai-seo`, `ai-og-image`,
  `ai-activity-content`.
- **Dokumentum és e-mail:** `generate-pdf` (Helvetica, `ő→ö`, `ű→ü` csere a WinAnsi
  hiba elkerülésére), `send-transactional-email`, `process-email-queue`,
  `handle-email-suppression`, `handle-email-unsubscribe`,
  `preview-transactional-email`, `send-notification`.
- **Ütemezett / rendszer:** `check-reminders`, `security-alert-monitor`
  (mindkettő `CRON_SECRET`-tel védve), `serve-sitemap`, `serve-llms-txt`.
- **Közös helperek:** `_shared/auth.ts` (JWT + `getUser()` alapú ellenőrzés),
  `_shared/ai-gateway.ts`, `_shared/cors.ts`; `_tests/integration.test.ts` a
  szerepalapú jogosultsági tesztekkel.

---

## 5. Újraépítés lépésről lépésre

1. Új Vite + React 18 + TS projekt, `npm install` a csomagolt `package.json` alapján.
2. Backend létrehozása, `.env` kitöltése a `.env.example` szerint.
3. `database/schema-public-with-grants.sql` futtatása.
4. Storage bucket-ek létrehozása (`documents`, `signatures`, `accident-photos`,
   `risk-assessment-photos`, `work-area-sds`, `medical-documents`) → majd
   `storage-policies.sql`.
5. `reference-data.sql` betöltése.
6. `supabase/functions/*` deploy, titkok beállítása (`CRON_SECRET`, e-mail szolgáltató).
7. Auth: e-mail + jelszó, Google provider, redirect URL = `window.location.origin`.
8. `npm run dev`, majd `npm run test` és a Playwright tesztek.

Egyetlen prompttal történő újraépítéshez: `docs/MASTER-PROMPT.md`.

---

## 6. A csomagolt dokumentáció

| Fájl | Tartalom |
|---|---|
| `docs/EXPORT-KALAUZ.md` | Ez a dokumentum — tételes csomagmagyarázat |
| `docs/PORTAL-DOKUMENTACIO.md` | Funkcionális modul-leírások, AI szolgáltatások |
| `docs/PROGRAMFA.md` | Teljes program-/fájlfa magyarázatokkal |
| `docs/UJRAEPITES.md` | Részletes újraépítési recept |
| `docs/DEBUG-TESZT-MATRIX.md` | Funkció ↔ teszt ↔ debug lépés mátrix |
| `docs/MASTER-PROMPT.md` | Egyprompt-os teljes újragenerálás |
| `docs/security-monitoring.md` | RLS/storage megtagadás naplózás és riasztás |
| `docs/lab-pricing-audit.md` | Labor árazás és felár szabályok audit |
| `docs/CONTRIBUTING.md`, `docs/README.md` | Fejlesztői konvenciók |

---

## 7. Amit a csomag szándékosan nem tartalmaz

- Titkok és kulcsok (`.env` valós értékek, service role kulcs, DB jelszó) — csak `.env.example`.
- Személyes és egészségügyi adatok (lásd 2.2).
- `node_modules`, build kimenet, cache.
