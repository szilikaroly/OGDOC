# SOS24 Portál – Master Prompt (teljes újraépítéshez)

> Másold be az alábbi, `PROMPT` blokkban lévő szöveget **egyetlen üzenetként** egy üres Lovable projektbe (Lovable Cloud bekapcsolva). A prompt önmagában tartalmazza a teljes specifikációt: design rendszer, adatmodell, RLS, szerepkörök, route-fa, modulok, Edge Functionök, AI-funkciók, i18n, biztonság, tesztelés és ismert buktatók.

---

## PROMPT

Építs fel egy teljes, produkciókész **magyar nyelvű foglalkozás-egészségügyi és háziorvosi portált** („SOS24”) az alábbi teljes specifikáció szerint. Stack: React 18 + Vite + TypeScript + Tailwind + shadcn/ui, backend Lovable Cloud (Postgres + Auth + Storage + Edge Functions). A felület nyelve magyar, i18n-nel többnyelvűsítve.

### 0. Munkamódszer
Építsd fel iteratívan, modulonként, de a teljes adatmodellt és jogosultsági réteget hozd létre az elején. Minden `public` táblához ugyanabban a migrációban: `CREATE TABLE` → `GRANT` (authenticated/service_role, anon csak ha van anon policy) → `ENABLE ROW LEVEL SECURITY` → policyk. Ne használj CHECK constraintet időfüggő szabályhoz, arra triggert írj.

### 1. Design rendszer (kötelező, semantic tokenek)
Luxus orvosi arculat: **mélykék (navy) + arany**. Minden szín HSL tokenként az `index.css`-ben és a `tailwind.config.ts`-ben; komponensben tilos hardkódolt szín (`text-white`, `bg-[#...]`).
- Navy skála: `--navy-950: 220 60% 6%` … `--navy-50: 220 15% 97%`
- Arany skála: `--gold-900: 43 80% 25%` … `--gold-50: 43 50% 97%`, főarany `--gold-500: 43 70% 55%`
- Szemantikus: `--background: navy-50`, `--foreground: navy-900`, `--primary: navy-900`, `--secondary: gold-500`, `--ring: gold-500`, `--radius: 0.5rem`
- Gradientek: `--gradient-navy`, `--gradient-gold`, `--gradient-luxury`, `--gradient-hero`, `--gradient-card`
- Árnyékok: `--shadow-sm/md/lg/xl` navy alapon + `--shadow-gold`
- Tipográfia: `Playfair Display` (display/címsorok) + `Inter` (szöveg). Segédosztály: `text-gradient-gold`, `font-display`.
- Sötét mód támogatása, mobilbarát, `safe-bottom` a mobil navigációhoz.

### 2. Szerepkörök és jogosultság
`app_role` enum: `super_admin`, `haziorvos`, `uzemorvos`, `munkaltato`, `munkavallalo`, `praxistag`.
- Szerepek **külön** `public.user_roles(user_id, role)` táblában (soha nem a profilon).
- `public.has_role(_user_id uuid, _role app_role)` SECURITY DEFINER STABLE függvény, `search_path=public` – minden RLS policy ezt használja.
- `get_user_roles(uuid) returns app_role[]`.
- Cég-hierarchia: `is_company_member(user_id, company_id, role)`, `is_employer_of_patient(employer_id, patient_id)` – a munkáltató csak a saját cégéhez tartozó munkavállalók **nem-egészségügyi** adatait láthatja (csak alkalmassági eredmény: alkalmas / nem alkalmas / korlátozással, diagnózis SOHA).
- Frontend: `AuthContext` (user, session, profile, roles, activeRole, szerepváltás localStorage-ban), `ProtectedRoute allowedRoles={[...]}`.
- Regisztrációkor `handle_new_user()` trigger hozza létre a `profiles` rekordot.

### 3. Adatmodell (public séma, ~70 tábla)
Hozd létre az alábbi táblákat értelmes oszlopokkal, `created_at/updated_at` (utóbbi `update_updated_at_column()` triggerrel), és teljes RLS-sel:

`profiles, user_roles, companies, company_sites, company_teaor_codes, company_hazardous_substances, user_company_relations, workplaces, work_areas, work_area_sds_documents, hazardous_substances, examinations, appointments, appointment_slots, referrals, medical_opinions, certificates, vaccinations, medications, medication_requests, patient_cards, health_plans, health_reports, health_journal, food_journal, stool_journal, questionnaires, questionnaire_assignments, questionnaire_submissions, doctor_recommendations, requests, documents, document_tags, document_templates, risk_assessments, risk_assessment_hazards, risk_assessment_photos, accident_reports, noise_vibration_measurements, lab_requests, lab_orders, lab_packages, lab_pricing_config, lab_markup_config, locations, services, service_categories, activities, pages_content, navigation_links, site_settings, content_translations, seo_pages, seo_audit_scores, competitor_urls, competitor_analyses, page_views, web_vitals, messages, notifications, notification_preferences, email_send_log, email_send_state, email_unsubscribe_tokens, suppressed_emails, gdpr_requests, audit_logs, security_events, bulk_import_logs`

Fontos DB függvények: `audit_trigger_func()` (általános audit trigger `changed_fields` számítással), `log_security_event(...)`, `security_denials_summary(since)`, `generate_lab_request_number()` (`LKR-ÉÉÉÉ-NNNN`), `generate_lab_order_number()` (`LO-ÉÉÉÉ-NNNN`), `create_public_lab_order(...)` (anonim rendelés SECURITY DEFINER-rel), `get_public_locations()` (a `locations` táblán nincs anon SELECT), pgmq e-mail sor: `enqueue_email`, `read_email_batch`, `delete_email`, `move_to_dlq`, `email_queue_dispatch`, `email_queue_wake`, admin auth-diagnosztika: `admin_get_recovery_status`, `admin_get_recovery_history`, `admin_recovery_failures_summary`, `admin_get_user_providers` (mind `super_admin`-ellenőrzéssel). A belső SECURITY DEFINER függvényektől vond meg az `EXECUTE`-ot `public`/`anon` szerepektől ott, ahol nem kell.

Storage bucketek: `medical-documents` (privát), `signatures` (privát), `risk-assessment-photos` (privát, tulajdonos-ellenőrzéssel), `sds-documents` (privát), `accident-photos` (privát), `og-images` (publikus, listázás tiltva). Fájlnevekben magyar ékezeteket ASCII-re kell normalizálni feltöltés előtt.

### 4. Route-fa
**Publikus**: `/` (landing: Hero, About, Services, Activities, Lab, Locations, CTA, Footer, Navbar, cookie banner), `/login`, `/register`, `/reset-password`, `/tevekenysegeink`, `/tevekenyseg/:slug`, `/labor` (labor webshop), `/unsubscribe`, `/email-unsubscribe`, `*` → 404.

**/admin** (`super_admin`): dashboard, users, companies, examinations, services, locations, slots, cms, navigation, seo, translate, activities, messages, document-tags, email-templates, audit-log, security-events, settings, document-templates, risk-assessments, substances, marketing, lab-shop, gdpr.

**/haziorvos**: dashboard, patients, appointments, med-requests, requests, questionnaires, documents, vaccinations, certificates, health-plans, lab-requests, messages.

**/uzemorvos**: dashboard, examinations, appointments, employees, companies, referrals, opinions, certificates, questionnaires, documents, vaccinations, statistics, health-plans, risk-assessments, lab-requests, messages.

**/munkaltato**: dashboard, employees, company, referrals, opinions, documents, reports, risk-assessments, accidents, messages.

**/munkavallalo**: dashboard, profile, appointments, health, journal, vaccinations, opinions, questionnaires, health-plan, documents, data-access, accidents, labor, settings, gdpr, messages.

**/praxistag**: dashboard, profile, appointments, health, journal, medications, referral-request, documents, questionnaires, labor, health-plan, messages.

Közös `DashboardLayout` collapsible sidebarral, szerepváltó dropdownnal, értesítés-haranggal, nyelvváltóval.

### 5. Modulok
1. **Auth**: e-mail+jelszó, Google OAuth (redirect mindig `window.location.origin`), fiók-összekapcsolás (`linkIdentity`/`unlinkIdentity`), jelszó-visszaállítás cooldownnal és központosított magyar hibaüzenetekkel, OAuth-szerepkör hiány jelzése + security event.
2. **Admin felhasználókezelés**: lista, szerepkiosztás, e-mail/telefon szerkesztés élő ütközésvizsgálattal (debounce), közvetlen jelszóbeállítás (HIBP „weak password” hibát magyarul jelzi), recovery link küldés, megerősítő e-mail újraküldés, „Auth health” diagnosztikai dialógus findings-listával.
3. **Csoportos import** (praxistag/munkavállaló, Excel/CSV): előnézet, élő folyamatjelzés, teljes duplumvizsgálat (TAJ, valamint Név+születési dátum), `bulk_import_logs` napló, importtörténet auto-refresh-sel, exponenciális backoffal (2s→60s, max 6 próbálkozás), visszaszámlálóval és villogásmentes loadinggal.
4. **Üzemorvosi modul**: vizsgálatok, beutalók, alkalmassági vélemények, munkakörök (FEOR), cégek/telephelyek (TEAOR), statisztika, nyomtatható dokumentumok.
5. **Kockázatértékelés (ISO 45001)**: veszélykatalógus, kockázati mátrix, fotóelemzés AI-jal, SDS (biztonsági adatlap) feltöltés és AI kiolvasás, zaj-/rezgésmérés rögzítés, nyomtatható riport.
6. **Balesetkezelés**: baleseti jegyzőkönyv űrlap kódlistákkal, fotókkal, nyomtatható jegyzőkönyv.
7. **Labor**: teljes SYNLAB-alapú tesztkatalógus kódban + `lab_pricing_config` DB-ben, csomagok, árazás **központi** `calculateDisplayPrice()` függvénnyel (globális markup, de az „Elemi” típusú teszteknél markup NEM alkalmazható), 100 Ft-ra kerekítés, admin árazó szerkesztő anomália-validációval, publikus webshop (anonim rendelés RPC-vel, helyszínválasztás vagy otthoni mintavétel), orvosi labor-kérő builder és nyomtatás.
8. **Dokumentumkezelés**: feltöltés, címkék, sablonok, szerepfüggő láthatóság, szerver oldali PDF generálás.
9. **Kérdőívek**: kiosztás, kitöltés, AI pontozás, orvosi visszajelzés.
10. **Egészség-napló**: étkezés, széklet, panaszok, AI egészségterv.
11. **Üzenetek**: szerepek közti belső üzenetküldés, olvasatlan badge.
12. **CMS + SEO**: oldalszerkesztő TipTap WYSIWYG-gel, navigáció, site settings, téma CMS-ből, SEO oldalak, versenytárs-elemzés, OG kép generálás, sitemap és `llms.txt` kiszolgálás.
13. **Értesítés + e-mail**: natív Notification API (nem Service Worker push), pgmq alapú e-mail sor DLQ-val, tranzakciós sablonok, leiratkozás és suppression kezelés.
14. **GDPR**: adathozzáférési napló, adatkérelmek, export/törlés.
15. **Biztonsági monitorozás**: RLS-megtagadások és storage hibák naplózása kliensről, admin nézet, e-mail riasztás.

### 6. Edge Functionök (Deno)
Hozz létre egy `_shared/auth.ts`-t `requireUser()`, `hasAnyRole()`, `requireCronSecret()` segédekkel (`getUser()`-rel, nem `getClaims()`-szel) és `_shared/sanitize.ts`-t szerveroldali HTML tisztításhoz, `_shared/audit.ts`-t naplózáshoz.

Függvények: `admin-update-user`, `admin-set-user-password`, `admin-check-email-available`, `admin-preview-email`, `bulk-create-patients`, `generate-pdf`, `invite-employer`, `send-notification`, `send-transactional-email`, `preview-transactional-email`, `process-email-queue`, `handle-email-suppression`, `handle-email-unsubscribe`, `check-reminders` (cron), `security-alert-monitor` (cron), `serve-sitemap`, `serve-llms-txt`, valamint AI: `ai-analysis`, `ai-chatbot`, `ai-triage`, `ai-medical-note`, `ai-opinion-draft`, `ai-doctor-recommendation`, `ai-document-analysis`, `ai-health-image-analysis`, `ai-health-plan`, `ai-lab-recommend`, `ai-questionnaire-scoring`, `ai-risk-photo-analysis`, `ai-sds-analysis`, `ai-speech-to-text`, `ai-translate`, `ai-travel-vaccines`, `ai-marketing`, `ai-seo`, `ai-og-image`, `ai-activity-content`.

Szabályok: minden függvény JWT-védett (kivéve a cron-hívottak, azok `CRON_SECRET`-tel és `verify_jwt = false`-szal), IDOR-ellenőrzés minden erőforrás-azonosítót fogadó függvényben (pl. csak a saját kérdőívét vagy a hozzá tartozó pácienst érheti el), SSRF-védelem az URL-t fogadó függvényekben, payload méretkorlát a PDF-nél, CORS fejlécek, hibáknál a provider státusz és body visszaadása.

AI-hoz a Lovable AI Gateway-t használd (`LOVABLE_API_KEY`), alapmodell `google/gemini-3-flash-preview`, összetett orvosi feladatra `google/gemini-3-pro-preview`.

### 7. i18n
i18next + böngésző nyelvfelismerés, nyelvek: **hu** (alap), en, de, ro, sr, zh, fil. Statikus kulcsok JSON-ban, dinamikus CMS-tartalom `content_translations` polimorf táblában, admin AI-fordító felülettel, fallback mindig magyarra.
**Jogi megkötés**: hivatalos orvosi dokumentumok (beutaló, üzemorvosi vélemény, alkalmassági igazolás) **kizárólag magyar nyelvűek maradnak**, ezeket nem szabad fordítani.

### 8. Biztonsági követelmények
- Minden táblán RLS, GRANT-ekkel; a `has_role()`-on kívül semmi kliensoldali jogosultság-ellenőrzés.
- Minden felhasználói vagy AI eredetű HTML DOMPurify-jal tisztítva (`lib/sanitize-html.ts`); nyomtatásnál HTML-escape (`esc()`).
- Storage: privát bucketek, tulajdonos- és szerepalapú policyk, publikus bucketen listázás tiltva.
- Audit log minden érzékeny táblán triggerrel; `security_events` naplózás RLS-megtagadásokra.
- Titkokat soha ne írj kliensoldali kódba.

### 9. Tesztelés és debug
- Vitest (jsdom) unit tesztek: labor árazás (`calculateDisplayPrice`, elemi tesztek markup-mentessége, kerekítés), auth-diagnosztika, sanitizálás, storage fájlnév-normalizálás.
- Deno integrációs tesztek az Edge Functionök szerepalapú jogosultságaira.
- Playwright E2E: bejelentkezés → szerepváltás → laborrendelés.
- Készíts `docs/DEBUG-TESZT-MATRIX.md`-t: funkció ↔ fájl ↔ backend ↔ teszt ↔ debug belépési pont.
- Készíts `docs/UJRAEPITES.md` (env, DB, storage, deploy) és `docs/PROGRAMFA.md` (fájlfa) dokumentumokat, valamint README-t és CI workflow-t (lint + test + build).

### 10. Ismert buktatók, amiket előre kezelj
- `vite.config.ts` → `optimizeDeps.include: ['react','react-dom','i18next']`, különben „useState of null”.
- Supabase Realtime `postgres_changes` **tilos** CMS hookokhoz → React Query cache invalidálás.
- 1000 soros lekérdezési limit → `range(from, to)` 1000-es kötegekben.
- Szerver oldali PDF: Helvetica font, `ő→ö`, `ű→ü`, sortörések szóközzé (WinAnsi crash).
- Nyomtatás: `window.print()` inline iframe viewerrel (popup blokkoló miatt).
- TipTap HTML megjelenítés: `dangerouslySetInnerHTML` + Tailwind `prose` + DOMPurify.
- Storage feltöltés: ékezetes fájlnév → 500-as hiba, előtte normalizálj.
- Új tábla RLS-sel → azonnal implementáld hozzá az auth-ot, különben a CRUD megáll.

### 11. Elvárt végeredmény
Működő, reszponzív, magyar nyelvű portál mind a 6 szerepkörre külön dashboarddal, teljes RLS-védett adatmodellel, működő laborrendeléssel, AI-funkciókkal, CMS-sel, e-mail sorral és admin biztonsági felülettel. SEO: egyedi `<title>` (<60 karakter) és meta description (<160), egy H1, szemantikus HTML, JSON-LD, sitemap.

---

## Használati tippek

- **Egy promptból** a modell nagy valószínűséggel a vázat építi fel először — utána modulonként kérd a mélyítést („most a kockázatértékelés modult részletesen”).
- Ha kész séma is rendelkezésre áll, a prompt elé told be: „A `supabase/schema.sql` fájl tartalmazza a kész adatmodellt, azt alkalmazd migrációként.” — ez lerövidíti a 3. pontot.
- A `sos24-portal-github.zip` csomagból importált repo esetén elég a prompt 8–10. pontja mint fejlesztési szabályzat.
