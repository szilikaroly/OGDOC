# Security event monitoring

This project logs denied database access attempts (RLS / `permission denied`)
into the `security_events` table and surfaces them in the admin UI at
**Admin → Biztonsági események** (`/admin/security-events`).

## Components

| Layer                | Where                                                          |
| -------------------- | -------------------------------------------------------------- |
| Storage              | `public.security_events` (super_admin read only)               |
| Logging RPC          | `public.log_security_event(...)` — SECURITY DEFINER            |
| Aggregation RPC      | `public.security_denials_summary(_since)`                      |
| Client helper        | `src/lib/security-monitor.ts`                                  |
| Admin dashboard      | `src/pages/admin/AdminSecurityEvents.tsx`                      |
| Alert cron           | edge function `security-alert-monitor`, scheduled every 5 min  |
| Notification email   | `general-notification` template via `send-transactional-email` |

## How to capture an RLS denial from the client

Wrap any Supabase call where a permission denial is meaningful:

```ts
import { reportSupabaseError } from "@/lib/security-monitor";

const { data, error } = await supabase
  .from("lab_pricing_config")
  .update({ markup_percent: 12 })
  .eq("id", id);

if (error) {
  // Only reports if the error is an RLS / permission-denied error.
  // No-op otherwise; never throws.
  reportSupabaseError(error, { table: "lab_pricing_config", operation: "update" });
  toast.error(error.message);
}
```

You can also log a custom event explicitly:

```ts
import { reportSecurityEvent } from "@/lib/security-monitor";

await reportSecurityEvent({
  eventType: "admin_action_blocked",
  severity: "error",
  metadata: { reason: "missing_role" },
});
```

## Alert thresholds

The cron edge function `security-alert-monitor` runs every 5 minutes and
inserts a `critical` row + emails super_admins when **a single user produces
≥ 10 denials in 5 minutes**. A 30-minute cooldown prevents email spam.

Edit `WINDOW_MINUTES`, `ALERT_THRESHOLD`, `ALERT_COOLDOWN_MINUTES` at the top
of `supabase/functions/security-alert-monitor/index.ts` to tune.

## Schedule

The pg_cron job `security-alert-monitor-5min` is created via SQL. Inspect:

```sql
SELECT jobname, schedule, active FROM cron.job;
```
