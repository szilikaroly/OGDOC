# SOS24 Portál – Programfa (teljes fájlstruktúra)

> Generálva automatikusan. Kihagyva: `node_modules/`, `.git/`, `dist/`.

## Rétegek gyorsan

| Könyvtár | Tartalom |
|---|---|
| `src/pages/` | Route-szintű oldalak, szerepkörönként almappákban (`admin`, `haziorvos`, `uzemorvos`, `munkaltato`, `munkavallalo`, `praxistag`) |
| `src/components/` | Újrafelhasználható UI + domain komponensek; `components/ui` = shadcn primitívek |
| `src/hooks/` | React Query alapú adat-hookok (CMS, labor árazás, értesítések, i18n) |
| `src/lib/` | Tiszta üzleti logika és segédfüggvények (katalógusok, sanitizálás, nyomtatás, security monitor) |
| `src/i18n/` | 7 nyelv fordítási JSON-jai + i18next konfiguráció |
| `src/integrations/supabase/` | Auto-generált backend kliens és típusok (NEM szerkesztendő) |
| `supabase/functions/` | 37+ Edge Function (Deno) |
| `supabase/migrations/` | 75 adatbázis migráció (időrendben) |
| `docs/` | Műszaki dokumentáció |

## Teljes fa

```text
├── docs/
│   ├── PORTAL-DOKUMENTACIO.md
│   ├── lab-pricing-audit.md
│   └── security-monitoring.md
├── public/
│   ├── .well-known/
│   │   └── ai-plugin.json
│   ├── favicon.png
│   ├── logo.png
│   ├── manifest.json
│   ├── placeholder.svg
│   ├── pwa-icon-192.png
│   ├── pwa-icon-512.png
│   ├── robots.txt
│   └── sitemap.xml
├── src/
│   ├── components/
│   │   ├── admin/
│   │   │   ├── AuthHealthDialog.tsx
│   │   │   ├── RecoveryFailuresSummary.tsx
│   │   │   └── RecoveryHistoryPanel.tsx
│   │   ├── landing/
│   │   │   ├── AboutSection.tsx
│   │   │   ├── ActivitiesSection.tsx
│   │   │   ├── CTASection.tsx
│   │   │   ├── Footer.tsx
│   │   │   ├── HeroSection.tsx
│   │   │   ├── LabSection.tsx
│   │   │   ├── LocationsSection.tsx
│   │   │   ├── Navbar.tsx
│   │   │   └── ServicesSection.tsx
│   │   ├── ui/
│   │   │   ├── accordion.tsx
│   │   │   ├── alert-dialog.tsx
│   │   │   ├── alert.tsx
│   │   │   ├── aspect-ratio.tsx
│   │   │   ├── avatar.tsx
│   │   │   ├── badge.tsx
│   │   │   ├── breadcrumb.tsx
│   │   │   ├── button.tsx
│   │   │   ├── calendar.tsx
│   │   │   ├── card.tsx
│   │   │   ├── carousel.tsx
│   │   │   ├── chart.tsx
│   │   │   ├── checkbox.tsx
│   │   │   ├── collapsible.tsx
│   │   │   ├── command.tsx
│   │   │   ├── context-menu.tsx
│   │   │   ├── dialog.tsx
│   │   │   ├── drawer.tsx
│   │   │   ├── dropdown-menu.tsx
│   │   │   ├── form.tsx
│   │   │   ├── hover-card.tsx
│   │   │   ├── input-otp.tsx
│   │   │   ├── input.tsx
│   │   │   ├── label.tsx
│   │   │   ├── menubar.tsx
│   │   │   ├── navigation-menu.tsx
│   │   │   ├── pagination.tsx
│   │   │   ├── popover.tsx
│   │   │   ├── progress.tsx
│   │   │   ├── radio-group.tsx
│   │   │   ├── resizable.tsx
│   │   │   ├── scroll-area.tsx
│   │   │   ├── select.tsx
│   │   │   ├── separator.tsx
│   │   │   ├── sheet.tsx
│   │   │   ├── sidebar.tsx
│   │   │   ├── skeleton.tsx
│   │   │   ├── slider.tsx
│   │   │   ├── sonner.tsx
│   │   │   ├── switch.tsx
│   │   │   ├── table.tsx
│   │   │   ├── tabs.tsx
│   │   │   ├── textarea.tsx
│   │   │   ├── toast.tsx
│   │   │   ├── toaster.tsx
│   │   │   ├── toggle-group.tsx
│   │   │   ├── toggle.tsx
│   │   │   ├── tooltip.tsx
│   │   │   └── use-toast.ts
│   │   ├── AccidentReportForm.tsx
│   │   ├── AccidentReportList.tsx
│   │   ├── AddToCalendarButton.tsx
│   │   ├── AiAnalysisPanel.tsx
│   │   ├── AiTranslateButton.tsx
│   │   ├── BulkImportHistory.tsx
│   │   ├── BulkPatientImport.tsx
│   │   ├── ChatBot.tsx
│   │   ├── ConnectedAccounts.tsx
│   │   ├── CookieBanner.tsx
│   │   ├── DashboardLayout.tsx
│   │   ├── DoctorCertificates.tsx
│   │   ├── DoctorPatientHealthPlans.tsx
│   │   ├── DoctorRecommendationsSection.tsx
│   │   ├── DoctorSignatureUpload.tsx
│   │   ├── DoctorVaccinations.tsx
│   │   ├── DocumentBrowser.tsx
│   │   ├── ExportButton.tsx
│   │   ├── FeorSearch.tsx
│   │   ├── FoodJournal.tsx
│   │   ├── GeneratePdfButton.tsx
│   │   ├── HazardousSubstanceSelector.tsx
│   │   ├── IconPicker.tsx
│   │   ├── LabAiAssistant.tsx
│   │   ├── LabPackageEditor.tsx
│   │   ├── LabPricingEditor.tsx
│   │   ├── LabRequestBuilder.tsx
│   │   ├── LanguageSwitcher.tsx
│   │   ├── MedicationSearch.tsx
│   │   ├── MessagesPage.tsx
│   │   ├── NavLink.tsx
│   │   ├── NoiseMeter.tsx
│   │   ├── NotificationBell.tsx
│   │   ├── OgImageGenerator.tsx
│   │   ├── PatientCardForm.tsx
│   │   ├── PatientProfile.tsx
│   │   ├── PrintableAccidentReport.tsx
│   │   ├── PrintableOpinion.tsx
│   │   ├── PrintablePatientCard.tsx
│   │   ├── PrintableReferral.tsx
│   │   ├── PrintableRiskAssessment.tsx
│   │   ├── ProtectedRoute.tsx
│   │   ├── RiskAssessmentForm.tsx
│   │   ├── RiskMatrix.tsx
│   │   ├── RiskPhotoAnalysis.tsx
│   │   ├── SdsReader.tsx
│   │   ├── ServiceCategoryManager.tsx
│   │   ├── SignaturePad.tsx
│   │   ├── SpeechToTextButton.tsx
│   │   ├── StickyLogos.tsx
│   │   ├── StoolJournal.tsx
│   │   ├── TeaorSearch.tsx
│   │   ├── TravelVaccinationAdvisor.tsx
│   │   ├── VibrationMeter.tsx
│   │   ├── WorkAreaManager.tsx
│   │   ├── WorkAreaSdsUpload.tsx
│   │   └── WysiwygEditor.tsx
│   ├── contexts/
│   │   └── AuthContext.tsx
│   ├── hooks/
│   │   ├── use-cms.ts
│   │   ├── use-content-translations.ts
│   │   ├── use-csv-export.ts
│   │   ├── use-document-templates.ts
│   │   ├── use-i18n-overrides.ts
│   │   ├── use-lab-packages.ts
│   │   ├── use-lab-pricing.test.ts
│   │   ├── use-lab-pricing.ts
│   │   ├── use-mobile.tsx
│   │   ├── use-notifications.ts
│   │   ├── use-seo.ts
│   │   ├── use-theme-from-cms.ts
│   │   ├── use-toast.ts
│   │   └── use-unread-messages.ts
│   ├── i18n/
│   │   ├── de.json
│   │   ├── en.json
│   │   ├── fil.json
│   │   ├── hu.json
│   │   ├── i18n.ts
│   │   ├── ro.json
│   │   ├── sr.json
│   │   └── zh.json
│   ├── integrations/
│   │   ├── lovable/
│   │   │   └── index.ts
│   │   └── supabase/
│   │       ├── client.ts
│   │       └── types.ts
│   ├── lib/
│   │   ├── accident-codes.ts
│   │   ├── auth-diagnostics.ts
│   │   ├── auth-errors.ts
│   │   ├── auto-translate-cms.ts
│   │   ├── feor-codes.ts
│   │   ├── hazard-catalog.ts
│   │   ├── hungarian-holidays.ts
│   │   ├── icon-map.ts
│   │   ├── ics-generator.ts
│   │   ├── import-export.ts
│   │   ├── labTestCatalog.ts
│   │   ├── labTestCatalogExtension.ts
│   │   ├── labTestCatalogKlinikaiKemia.ts
│   │   ├── oauth-errors.ts
│   │   ├── printLabRequest.ts
│   │   ├── sanitize-html.ts
│   │   ├── security-monitor.ts
│   │   ├── storage-utils.ts
│   │   ├── teaor-codes.ts
│   │   └── utils.ts
│   ├── pages/
│   │   ├── admin/
│   │   │   ├── AdminActivities.tsx
│   │   │   ├── AdminAuditLog.tsx
│   │   │   ├── AdminCMS.tsx
│   │   │   ├── AdminCompanies.tsx
│   │   │   ├── AdminDashboard.tsx
│   │   │   ├── AdminDocumentTags.tsx
│   │   │   ├── AdminDocumentTemplates.tsx
│   │   │   ├── AdminEmailTemplates.tsx
│   │   │   ├── AdminExaminations.tsx
│   │   │   ├── AdminGdpr.tsx
│   │   │   ├── AdminLabOrders.tsx
│   │   │   ├── AdminLabShop.tsx
│   │   │   ├── AdminLayout.tsx
│   │   │   ├── AdminLocations.tsx
│   │   │   ├── AdminMarketing.tsx
│   │   │   ├── AdminNavigation.tsx
│   │   │   ├── AdminPlaceholder.tsx
│   │   │   ├── AdminRiskAssessments.tsx
│   │   │   ├── AdminSEO.tsx
│   │   │   ├── AdminSecurityEvents.tsx
│   │   │   ├── AdminServices.tsx
│   │   │   ├── AdminSettings.tsx
│   │   │   ├── AdminSlots.tsx
│   │   │   ├── AdminSubstances.tsx
│   │   │   ├── AdminTranslate.tsx
│   │   │   └── AdminUsers.tsx
│   │   ├── haziorvos/
│   │   │   ├── HaziorvosAppointments.tsx
│   │   │   ├── HaziorvosDashboard.tsx
│   │   │   ├── HaziorvosDocuments.tsx
│   │   │   ├── HaziorvosLayout.tsx
│   │   │   ├── HaziorvosMedRequests.tsx
│   │   │   ├── HaziorvosPatients.tsx
│   │   │   ├── HaziorvosQuestionnaires.tsx
│   │   │   └── HaziorvosRequests.tsx
│   │   ├── munkaltato/
│   │   │   ├── MunkaltatoAccidents.tsx
│   │   │   ├── MunkaltatoCompany.tsx
│   │   │   ├── MunkaltatoDashboard.tsx
│   │   │   ├── MunkaltatoDocuments.tsx
│   │   │   ├── MunkaltatoEmployees.tsx
│   │   │   ├── MunkaltatoLayout.tsx
│   │   │   ├── MunkaltatoOpinions.tsx
│   │   │   ├── MunkaltatoReferrals.tsx
│   │   │   ├── MunkaltatoReports.tsx
│   │   │   └── MunkaltatoRiskAssessments.tsx
│   │   ├── munkavallalo/
│   │   │   ├── MunkavallaloAccidents.tsx
│   │   │   ├── MunkavallaloAppointments.tsx
│   │   │   ├── MunkavallaloDataAccess.tsx
│   │   │   ├── MunkavallaloDocuments.tsx
│   │   │   ├── MunkavallaloGdpr.tsx
│   │   │   ├── MunkavallaloHealth.tsx
│   │   │   ├── MunkavallaloJournal.tsx
│   │   │   ├── MunkavallaloLayout.tsx
│   │   │   ├── MunkavallaloOpinions.tsx
│   │   │   ├── MunkavallaloProfile.tsx
│   │   │   ├── MunkavallaloQuestionnaires.tsx
│   │   │   ├── MunkavallaloSettings.tsx
│   │   │   ├── MunkavallaloVaccinations.tsx
│   │   │   └── MunkavallatoDashboard.tsx
│   │   ├── praxistag/
│   │   │   ├── PraxistagAppointments.tsx
│   │   │   ├── PraxistagDashboard.tsx
│   │   │   ├── PraxistagDocuments.tsx
│   │   │   ├── PraxistagHealth.tsx
│   │   │   ├── PraxistagLayout.tsx
│   │   │   ├── PraxistagMedications.tsx
│   │   │   ├── PraxistagMessages.tsx
│   │   │   ├── PraxistagProfile.tsx
│   │   │   └── PraxistagReferralRequest.tsx
│   │   ├── shared/
│   │   │   └── HealthPlanPage.tsx
│   │   ├── uzemorvos/
│   │   │   ├── UzemorvosAppointments.tsx
│   │   │   ├── UzemorvosCompanies.tsx
│   │   │   ├── UzemorvosDashboard.tsx
│   │   │   ├── UzemorvosDocuments.tsx
│   │   │   ├── UzemorvosEmployees.tsx
│   │   │   ├── UzemorvosExaminations.tsx
│   │   │   ├── UzemorvosLayout.tsx
│   │   │   ├── UzemorvosOpinions.tsx
│   │   │   ├── UzemorvosQuestionnaires.tsx
│   │   │   ├── UzemorvosReferrals.tsx
│   │   │   ├── UzemorvosRiskAssessments.tsx
│   │   │   └── UzemorvosStatistics.tsx
│   │   ├── ActivitiesListPage.tsx
│   │   ├── ActivityPage.tsx
│   │   ├── EmailUnsubscribe.tsx
│   │   ├── Index.tsx
│   │   ├── LabShop.tsx
│   │   ├── Login.tsx
│   │   ├── NotFound.tsx
│   │   ├── PlaceholderPage.tsx
│   │   ├── Register.tsx
│   │   ├── ResetPassword.tsx
│   │   └── Unsubscribe.tsx
│   ├── test/
│   │   ├── example.test.ts
│   │   └── setup.ts
│   ├── App.css
│   ├── App.tsx
│   ├── index.css
│   ├── main.tsx
│   └── vite-env.d.ts
├── supabase/
│   ├── functions/
│   │   ├── _shared/
│   │   │   ├── transactional-email-templates/
│   │   │   │   ├── appointment-confirmed.tsx
│   │   │   │   ├── general-notification.tsx
│   │   │   │   ├── health-day-invitation.tsx
│   │   │   │   ├── lab-control-reminder.tsx
│   │   │   │   ├── medication-response.tsx
│   │   │   │   ├── opinion-ready.tsx
│   │   │   │   ├── prescription-ready.tsx
│   │   │   │   ├── referral-received.tsx
│   │   │   │   └── registry.ts
│   │   │   ├── audit.ts
│   │   │   ├── auth.ts
│   │   │   └── sanitize.ts
│   │   ├── _tests/
│   │   │   └── integration.test.ts
│   │   ├── admin-check-email-available/
│   │   │   └── index.ts
│   │   ├── admin-preview-email/
│   │   │   └── index.ts
│   │   ├── admin-set-user-password/
│   │   │   └── index.ts
│   │   ├── admin-update-user/
│   │   │   └── index.ts
│   │   ├── ai-activity-content/
│   │   │   └── index.ts
│   │   ├── ai-analysis/
│   │   │   └── index.ts
│   │   ├── ai-chatbot/
│   │   │   └── index.ts
│   │   ├── ai-doctor-recommendation/
│   │   │   └── index.ts
│   │   ├── ai-document-analysis/
│   │   │   └── index.ts
│   │   ├── ai-health-image-analysis/
│   │   │   └── index.ts
│   │   ├── ai-health-plan/
│   │   │   └── index.ts
│   │   ├── ai-lab-recommend/
│   │   │   └── index.ts
│   │   ├── ai-marketing/
│   │   │   └── index.ts
│   │   ├── ai-medical-note/
│   │   │   └── index.ts
│   │   ├── ai-og-image/
│   │   │   └── index.ts
│   │   ├── ai-opinion-draft/
│   │   │   └── index.ts
│   │   ├── ai-questionnaire-scoring/
│   │   │   └── index.ts
│   │   ├── ai-risk-photo-analysis/
│   │   │   └── index.ts
│   │   ├── ai-sds-analysis/
│   │   │   └── index.ts
│   │   ├── ai-seo/
│   │   │   └── index.ts
│   │   ├── ai-speech-to-text/
│   │   │   └── index.ts
│   │   ├── ai-translate/
│   │   │   └── index.ts
│   │   ├── ai-travel-vaccines/
│   │   │   └── index.ts
│   │   ├── ai-triage/
│   │   │   └── index.ts
│   │   ├── bulk-create-patients/
│   │   │   └── index.ts
│   │   ├── check-reminders/
│   │   │   └── index.ts
│   │   ├── generate-pdf/
│   │   │   └── index.ts
│   │   ├── handle-email-suppression/
│   │   │   ├── deno.json
│   │   │   └── index.ts
│   │   ├── handle-email-unsubscribe/
│   │   │   ├── deno.json
│   │   │   └── index.ts
│   │   ├── invite-employer/
│   │   │   └── index.ts
│   │   ├── preview-transactional-email/
│   │   │   ├── deno.json
│   │   │   └── index.ts
│   │   ├── process-email-queue/
│   │   │   ├── deno.json
│   │   │   └── index.ts
│   │   ├── security-alert-monitor/
│   │   │   └── index.ts
│   │   ├── send-notification/
│   │   │   └── index.ts
│   │   ├── send-transactional-email/
│   │   │   ├── deno.json
│   │   │   └── index.ts
│   │   ├── serve-llms-txt/
│   │   │   └── index.ts
│   │   └── serve-sitemap/
│   │       └── index.ts
│   ├── migrations/
│   │   ├── 20260326083955_baddf97a-5e6d-4b0d-bfae-93fe2dff4c4d.sql
│   │   ├── 20260326224237_8660d92c-01d1-418a-9c8c-9f5f598b4392.sql
│   │   ├── 20260326224706_2edbf9da-f3a1-4148-bdd8-9e5b15a408c1.sql
│   │   ├── 20260326230417_ec39c8e0-7ea4-4332-9c1f-ccb6a3452baf.sql
│   │   ├── 20260326233738_b4d1f991-bac2-4104-9c7d-05ad62a605f0.sql
│   │   ├── 20260326235110_cccb3096-91a5-41d7-834e-aa9436b7e8ee.sql
│   │   ├── 20260327102907_424abd41-352c-4777-921b-5bc7750c681c.sql
│   │   ├── 20260327133146_c2b04ec5-2ae8-43a8-beae-c30a320412d7.sql
│   │   ├── 20260327133659_7c3ce449-4288-49f1-8cc6-a57962083425.sql
│   │   ├── 20260327175915_b028fba1-6050-45e4-adb1-35a56fbada19.sql
│   │   ├── 20260327182426_dd3041f2-cdbc-430e-8cc9-28bacba5701f.sql
│   │   ├── 20260327220715_eb534409-b411-4d11-b3d9-f80d8df3c4be.sql
│   │   ├── 20260327221207_7446cec3-118b-4524-935a-7e9403f24e0b.sql
│   │   ├── 20260327231246_d7237a00-12c7-458c-a030-066833aaaa0e.sql
│   │   ├── 20260327235802_1454f5e1-0a52-480b-a28c-b3c2802fc4de.sql
│   │   ├── 20260328000314_0779d468-94b0-49a1-a684-416e1911f3f6.sql
│   │   ├── 20260328000908_05a4f5d0-a1cf-468b-9703-0927098b9c5d.sql
│   │   ├── 20260328001903_487404a6-d7a5-431b-b6e2-4f31a4dbaefd.sql
│   │   ├── 20260328002446_200d75c5-d928-464d-8c27-efd6e286afef.sql
│   │   ├── 20260328002539_b57fdcdd-93b8-4588-8f39-5638edabf71a.sql
│   │   ├── 20260328002938_6214c9bb-029a-427e-9bff-814d24f97ccd.sql
│   │   ├── 20260328003230_1c6e82fe-cf41-4efd-9117-6555b167c8d6.sql
│   │   ├── 20260328004220_f77732c4-84c4-4625-b978-9c12acab0cb5.sql
│   │   ├── 20260328102305_c769ce69-3a61-40f3-a328-1a9143238b5c.sql
│   │   ├── 20260328110542_email_infra.sql
│   │   ├── 20260328112822_8750f413-4f01-4a09-83ac-5405a9b06bfb.sql
│   │   ├── 20260328131612_72a1d10d-6421-4e79-879f-77e74536ae5b.sql
│   │   ├── 20260328141855_e9d9ca00-6483-4834-82d2-60ad9147fa63.sql
│   │   ├── 20260328143323_4869009c-8c5a-4d66-a3c6-943844548603.sql
│   │   ├── 20260328150129_e00dc686-e045-4fa8-be73-77b8585a23a1.sql
│   │   ├── 20260328151651_3381e168-4eb1-44b8-9638-b2c0e67753e3.sql
│   │   ├── 20260328164757_436653d3-9a06-446b-806a-cb486e27a1ab.sql
│   │   ├── 20260328164920_d0ad4aa5-04a5-4d01-b286-571a1e012ecb.sql
│   │   ├── 20260328165028_2acd4a8e-a292-4150-862e-0d57928e51d9.sql
│   │   ├── 20260328170750_8e530e5d-2125-4696-ab23-3ac38a43332e.sql
│   │   ├── 20260328171555_9f9a461b-fe07-4853-b5e1-495ea6e12534.sql
│   │   ├── 20260328171912_09545ae9-3419-4ded-a617-56cc02586050.sql
│   │   ├── 20260328172613_416473f7-0473-4aeb-b5a9-902162eda916.sql
│   │   ├── 20260329142435_6f5dba5f-6218-45de-9a9a-0d616bbb766b.sql
│   │   ├── 20260329144948_39345678-a283-4234-9223-43c74345177e.sql
│   │   ├── 20260329211720_3530a0e8-b303-484b-b60f-fd903a8c8df5.sql
│   │   ├── 20260330070408_e893b53d-7d8a-4e1c-b602-1d9f162903c9.sql
│   │   ├── 20260330072052_90a56906-6480-4e27-b1b9-c0ba3cd2fdb9.sql
│   │   ├── 20260409073355_778f76b3-9653-4b43-8f17-5d9462c16406.sql
│   │   ├── 20260409074058_ba0e0368-658e-4799-8ee6-62ff541984f0.sql
│   │   ├── 20260409094119_208dec9b-49d3-48d3-86f0-63f2b783ab68.sql
│   │   ├── 20260409101358_e92af6a6-6e8e-4c82-b9bc-4d0ab9a39ca2.sql
│   │   ├── 20260409103748_fd3896a7-3d67-43e5-9d61-8a7806b083e5.sql
│   │   ├── 20260409105208_784f0b26-3141-4af7-8d47-4ffff1842be7.sql
│   │   ├── 20260409112902_a46fd6c0-5e47-4b69-bcad-bd6f8705aa87.sql
│   │   ├── 20260409114431_28210805-9a96-45f1-9ff9-de53c84205ff.sql
│   │   ├── 20260409120736_d9d7c837-edb6-4939-986f-cba02585b59a.sql
│   │   ├── 20260409122640_708ff4f5-e48e-4ddf-beb8-3055fd40f386.sql
│   │   ├── 20260409135743_5cf8ad2b-dedb-4e49-8fe2-dd3e543a3412.sql
│   │   ├── 20260409142532_aeb48757-4449-470c-a760-7f78b7c8adbc.sql
│   │   ├── 20260410084941_b1e30899-4b97-4c08-bd47-2f7fa604d55a.sql
│   │   ├── 20260410092617_74c47062-5373-4152-83a0-e9c7bf5cc0a3.sql
│   │   ├── 20260410094101_e307d67a-3bd8-4eef-aa64-c6ae44af11a9.sql
│   │   ├── 20260410102000_6367127a-f4eb-41af-a3a4-2d84c73fede4.sql
│   │   ├── 20260419094110_047e00d9-6670-4e37-9d55-5d6ebf522fdb.sql
│   │   ├── 20260623100329_1498c90a-513e-4482-af71-7dcce9179874.sql
│   │   ├── 20260623101128_c60eb55d-3ea3-4adb-a8cb-0c97f2e5565c.sql
│   │   ├── 20260629073709_2c18d12e-042d-4248-818a-9878d9642cfe.sql
│   │   ├── 20260629080626_2c67580e-4ea4-4597-afa5-d522fdaf4e02.sql
│   │   ├── 20260629091321_71664827-e97f-4cf8-850d-8c10ed0fad18.sql
│   │   ├── 20260629091711_8c9be73a-7a9f-4c3d-b272-29a4e14b3ea4.sql
│   │   ├── 20260629091728_283d16ba-7095-452e-a278-226caaf9d9f4.sql
│   │   ├── 20260629094042_587b7d9e-562c-4774-9472-9ed0a464aa3b.sql
│   │   ├── 20260629101033_62033e05-a0b6-49d0-8cc1-7c65d36cf362.sql
│   │   ├── 20260630070924_58436231-0d11-4daf-84fc-ead99f15f4bf.sql
│   │   ├── 20260630071050_992d5905-ce2e-48d6-bda5-d6d47f2906e1.sql
│   │   ├── 20260630071313_1d02ed7e-42da-4163-a267-a9abf176a6d1.sql
│   │   ├── 20260630072005_d4f22fb2-2125-4140-95c5-41aedc131d3a.sql
│   │   ├── 20260630105831_b0c44398-9dca-4941-a1a2-b4d808c0a753.sql
│   │   └── 20260630105902_ccdd3c6b-0c23-41a5-9add-19f299e63d4e.sql
│   ├── config.toml
│   ├── schema.sql
│   └── storage-policies.sql
├── .env
├── .gitignore
├── README.md
├── bun.lock
├── components.json
├── eslint.config.js
├── index.html
├── package-lock.json
├── package.json
├── playwright-fixture.ts
├── playwright.config.ts
├── postcss.config.js
├── tailwind.config.ts
├── tsconfig.app.json
├── tsconfig.json
├── tsconfig.node.json
├── vite.config.ts
└── vitest.config.ts
```
