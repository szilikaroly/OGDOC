# Labor árazási audit — `calculateDisplayPrice` használat ellenőrző lista

**Cél:** Biztosítani, hogy a teljes alkalmazásban MINDEN olyan helyen, ahol a felhasználónak ár jelenik meg (vásárló oldal, kérőlap-építő, csomagajánlatok), a centralizált `calculateDisplayPrice` függvényt használjuk az `src/hooks/use-lab-pricing.ts`-ből — duplikált markup-logika nélkül.

**Forrás-igazság:** `src/hooks/use-lab-pricing.ts` → `calculateDisplayPrice(test, overrides, markup, testId?)`

**Szabály:**
- `test.type === 'Elemi'` → markup KIHAGYVA (csak override vagy katalógus alapár).
- bármi más típus (`Panel`, `Csomag`, `Speciális`, `Variabilis módszertan`, `Számolt érték`, …) → markup HOZZÁADVA.

---

## ✅ Ellenőrző lista — minden ár-megjelenítési pont

### 1. **Vásárló oldal — `src/pages/LabShop.tsx`** (`/labor`)

| # | Hely (sor) | Mit mutat | Hogyan számol | Státusz |
|---|---|---|---|---|
| 1 | `53` | `getPrice` definíció | `calculateDisplayPrice(t, overrides, markup, t.id)` | ✅ |
| 2 | `72` | Kosár subtotal | `cartItems.reduce(... + getPrice(t))` | ✅ |
| 3 | `106` | Megrendelés mentése — `orderedTests[].priceHuf` | `getPrice(t)` (snapshot) | ✅ |
| 4 | `137` | Kosárba adáskor letárolt ár | `getPrice(t)` | ✅ |
| 5 | `197` | LabAiAssistant prop | `getPrice={getPrice}` | ✅ |
| 6 | `209` | Csomag össz-ár (`pkgPrice`) | `pkgTests.reduce(... + getPrice(t))` | ✅ |
| 7 | `216`, `258` | Csomagajánlat ár megjelenítése | `pkgPrice` (lásd 6.) | ✅ |
| 8 | `249` | Csomag tételei tooltipben | `getPrice(t)` | ✅ |
| 9 | `300`, `311` | Egyedi vizsgálat kártya ára | `const price = getPrice(test)` | ✅ |
| 10 | `349`, `446` | Kosár-pop, sidebar tételsor | `getPrice(t)` | ✅ |
| 11 | `358–360` | Subtotal / otthoni díj / összesen | `subtotal` (lásd 2.) + `homeFee` (külön DB-mező) | ✅ |
| 12 | `417`, `452` | Otthoni mintavétel díja | `markup.home_sampling_fee_huf` (külön mező, NEM markup) | ✅ |

### 2. **Kérőlap-építő — `src/components/LabRequestBuilder.tsx`** (orvosi felület)

| # | Hely (sor) | Mit mutat | Hogyan számol | Státusz |
|---|---|---|---|---|
| 1 | `164` | `getTestPrice` definíció | `calculateDisplayPrice(test, pricingOverrides, pricingMarkup, test.id)` | ✅ |
| 2 | `166` | `selectedTotalPrice` | `selectedList.reduce(... + getTestPrice(t))` | ✅ |
| 3 | `477` | Vizsgálat sor ára | `getTestPrice(test)` | ✅ |
| 4 | `515` | Összesen sor | `selectedTotalPrice` (lásd 2.) | ✅ |

### 3. **AI asszisztens — `src/components/LabAiAssistant.tsx`**

| # | Hely (sor) | Mit mutat | Hogyan számol | Státusz |
|---|---|---|---|---|
| 1 | `28`, `37` | `getPrice` PROP (nem saját számítás) | A LabShop-ból kapja: `getPrice={getPrice}` (lásd LabShop #5) | ✅ |
| 2 | `202` | AI-ajánlott teszt ára | `getPrice(test)` (a propon át) | ✅ |

### 4. **Admin árazás-szerkesztő — `src/components/LabPricingEditor.tsx`**

> **Szándékosan NEM** használja `calculateDisplayPrice`-t — itt a NYERS, szerkeszthető ár (override / katalógus) jelenik meg az input mezőkben. A markup vizuálisan jelzett (banner + ELEMI badge + `explainDisplayPrice` popover), de nem épül rá.

| # | Hely (sor) | Mit mutat | Hogyan számol | Státusz |
|---|---|---|---|---|
| 1 | `126` | Lokális `getPrice` (szerkeszthető nyers ár) | `overrides[t.id]?.priceHuf ?? t.priceHuf` (markup nélkül) | ✅ szándékos |
| 2 | `213` | Globális markup banner | `currentMarkup` direkt | ✅ szándékos |
| 3 | `335` | ELEMI tooltip | `currentMarkup` szöveges magyarázat | ✅ szándékos |
| 4 | `347` | Suspicious (markup baked-in) banner | `detectMarkupBakedIn` | ✅ szándékos |
| 5 | `377` | Trace-popover | `explainDisplayPrice` (ugyanaz a forrás-igazság) | ✅ |

### 5. **Admin megrendeléskezelő — `src/pages/admin/AdminLabOrders.tsx`**

> Már LEMENTETT rendelés snapshotját mutatja — a `priceHuf` érték a vásárláskor `getPrice(t)`-vel rögzítve lett (LabShop #3). Itt utólag NEM szabad újra markupot számolni.

| # | Hely (sor) | Mit mutat | Hogyan számol | Státusz |
|---|---|---|---|---|
| 1 | `144` | `total_price_huf` (DB-ből) | Snapshot, már tartalmazza a vásárláskori markupot | ✅ szándékos |
| 2 | `203` | `ordered_tests[].priceHuf` (DB-ből) | Snapshot (lásd LabShop #3) | ✅ szándékos |
| 3 | `210` | `total_price_huf` ismétlés | Snapshot | ✅ szándékos |
| 4 | `220` | Print: `priceHuf: t.priceHuf \|\| 0` | A snapshot priceHuf-ot adja át a printerelésnek (de a `printLabRequest` nem nyomtat árat) | ✅ |

### 6. **Print kérőlap — `src/lib/printLabRequest.ts`**

> NEM jelenít meg árat — csak vizsgálati lista mintatípusokkal. Nincs ár-érintettség.

| # | Hely | Státusz |
|---|---|---|
| — | nincs ár-megjelenítés | ✅ N/A |

---

## 🛡️ Védelmi rétegek (mit szűr ki, ha valaki később duplikálja a logikát)

1. **Unit tesztek** (`src/hooks/use-lab-pricing.test.ts`, 21 db):
   - REGRESSION teszt: `Nátrium soha nem lehet 4300 Ft`.
   - Minden test type esetén ellenőrzött markup-viselkedés.
   - `explainDisplayPrice` és `detectMarkupBakedIn` lefedettsége.
2. **`detectMarkupBakedIn` admin figyelmeztető** — az árszerkesztőben sárga banner + sor-jelzés, ha valaki kézzel beleszámolja a markupot egy elemi teszt árába.
3. **Dev trace** — `window.__LAB_PRICE_TRACE__ = true` minden ár-számítás lépésről részletes konzol-logot ad, így gyorsan kiderül, ha valahol nyers `priceHuf` jelenik meg (a trace nem hívódik meg).
4. **Admin árszerkesztő trace popover** (🐞 ikon) — soronként megnyitható számítási magyarázat, mindig ugyanazt az `explainDisplayPrice` függvényt hívja.

---

## 🚫 Anti-pattern — NE csináld

```tsx
// ❌ ROSSZ — duplikált logika
const price = test.priceHuf + (test.type === 'Elemi' ? 0 : markup.markup_huf);

// ❌ ROSSZ — nyers ár megjelenítése
<span>{test.priceHuf} Ft</span>

// ❌ ROSSZ — saját mini-getPrice
const myGetPrice = (t) => overrides[t.id]?.priceHuf ?? t.priceHuf;
```

```tsx
// ✅ HELYES
import { calculateDisplayPrice } from '@/hooks/use-lab-pricing';
const price = calculateDisplayPrice(test, overrides, markup, test.id);
```

---

## 📋 Karbantartási checklist új ár-megjelenítés hozzáadásakor

- [ ] Hívja meg a `calculateDisplayPrice`-t (vagy egy olyan wrappert, ami azt hívja)?
- [ ] A `useLabPricing()` hookból veszi az `overrides` és `markup` értékeket?
- [ ] Ha snapshot (mentett rendelés), explicit kommentelve van a komponensben, hogy szándékosan nyers a `priceHuf`?
- [ ] Hozzá lett adva ehhez az audit-listához új sor?
- [ ] Ha új edge case, került új unit teszt a `use-lab-pricing.test.ts`-be?

---

**Utolsó audit:** automatikus, agent által generálva. Frissítendő minden új ár-megjelenítési pont hozzáadásakor.
