# SOS24 Egészségügyi Portál

Teljes körű foglalkozás-egészségügyi és háziorvosi portál: betegkezelés, üzemorvosi vizsgálatok, kockázatértékelés (ISO 45001), balesetkezelés, laborrendelés, CMS, AI-asszisztensek és GDPR-eszközök.

- **Éles**: https://sos24.lovable.app
- **Stack**: React 18 + Vite 5 + TypeScript 5 + Tailwind 3 + shadcn/ui, backend: Supabase (Postgres + Auth + Storage + Edge Functions, Deno)
- **Nyelvek**: hu (alap), en, de, ro, sr, zh, fil

## Dokumentáció

| Dokumentum | Tartalom |
|---|---|
| [docs/PORTAL-DOKUMENTACIO.md](docs/PORTAL-DOKUMENTACIO.md) | Funkcionális és műszaki leírás, modulok, szerepkörök |
| [docs/UJRAEPITES.md](docs/UJRAEPITES.md) | Nulláról újraépítés: env, DB, storage, függvények, deploy |
| [docs/PROGRAMFA.md](docs/PROGRAMFA.md) | Teljes fájlstruktúra (programfa) |
| [docs/DEBUG-TESZT-MATRIX.md](docs/DEBUG-TESZT-MATRIX.md) | Funkció ↔ fájl ↔ teszt ↔ debug hozzárendelés |
| [docs/security-monitoring.md](docs/security-monitoring.md) | Biztonsági események, RLS-megtagadás naplózás |
| [docs/lab-pricing-audit.md](docs/lab-pricing-audit.md) | Labor árazási szabályok és audit |
| `supabase/schema.sql` | Teljes adatbázis séma (táblák, enumok, függvények, 230 RLS policy) |
| `supabase/storage-policies.sql` | Storage bucket szabályok |

## Gyors indítás

```bash
bun install          # vagy: npm install
cp .env.example .env # töltsd ki a backend adatokkal
bun run dev          # http://localhost:8080
```

## Scriptek

| Parancs | Leírás |
|---|---|
| `bun run dev` | Fejlesztői szerver (port 8080) |
| `bun run build` | Production build (`dist/`) |
| `bun run build:dev` | Development módú build |
| `bun run preview` | Build előnézete |
| `bun run lint` | ESLint |
| `bun run test` | Vitest futtatás egyszer |
| `bun run test:watch` | Vitest figyelő módban |
| `npx playwright test` | E2E tesztek |
| `deno test --allow-net --allow-env supabase/functions/_tests/` | Edge Function integrációs tesztek |

## Szerepkörök

`super_admin`, `haziorvos`, `uzemorvos`, `munkaltato`, `munkavallalo`, `praxistag` — a szerepek külön `public.user_roles` táblában élnek, jogosultság-ellenőrzés a `public.has_role()` SECURITY DEFINER függvénnyel (RLS-ben és Edge Functionben egyaránt).

## Licenc / jogi

Az orvosi dokumentumok (beutaló, üzemorvosi vélemény) jogszabályi okból **kizárólag magyar nyelvűek**. Egészségügyi adatokat kezel: GDPR és adatminimalizálás kötelező.
