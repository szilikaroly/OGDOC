# Debug- és tesztmátrix

Funkció ↔ forrásfájl ↔ backend ↔ teszt ↔ debug-lépések hozzárendelése.

---

## 1. Tesztrétegek

| Réteg | Eszköz | Hely | Futtatás |
|---|---|---|---|
| Unit / logika | Vitest + jsdom | `src/**/*.test.ts(x)` | `bun run test` |
| Edge Function integráció | Deno test | `supabase/functions/_tests/integration.test.ts` | `deno test --allow-net --allow-env supabase/functions/_tests/` |
| E2E / UI | Playwright | `playwright.config.ts`, `playwright-fixture.ts` | `npx playwright test` |
| Adatbázis-biztonság | Supabase linter + security scan | – | `supabase db lint`, Lovable security scan |
| Futásidejű biztonság | `security_events` tábla + `/admin/security-events` | `src/lib/security-monitor.ts` | admin felület |

Jelenlegi teszt fájlok:

- `src/test/example.test.ts` – setup smoke test
- `src/hooks/use-lab-pricing.test.ts` – árazási logika (`calculateDisplayPrice`, elemi tesztek markup-mentessége, 100 Ft-os kerekítés)
- `supabase/functions/_tests/integration.test.ts` – szerepalapú jogosultság-ellenőrzés Edge Functionökre

---

## 2. Modulmátrix

| Funkció | Frontend | Hook / logika | Backend (Edge / RPC) | Teszt | Debug belépési pont |
|---|---|---|---|---|---|
| Auth, szerepváltás | `src/pages/Login.tsx`, `Register.tsx`, `contexts/AuthContext.tsx`, `components/ProtectedRoute.tsx` | `lib/auth-errors.ts`, `lib/oauth-errors.ts` | Supabase Auth, `get_user_roles` | integration.test.ts (role guard) | Console: `onAuthStateChange` események; `localStorage` `sb-*` kulcsok, `activeRole` |
| Google OAuth / fiók-összekapcsolás | `components/ConnectedAccounts.tsx` | – | Supabase identities | manuális | Network: `/auth/v1/authorize`, `oauth_login_no_role` security event |
| Jelszó-visszaállítás | `pages/ResetPassword.tsx` | `lib/auth-errors.ts` | `admin-set-user-password` | manuális | `admin_get_recovery_status`, `admin_get_recovery_history` RPC, `email_send_log` |
| Admin felhasználókezelés | `pages/admin/AdminUsers.tsx`, `components/admin/AuthHealthDialog.tsx` | `lib/auth-diagnostics.ts` | `admin-update-user`, `admin-check-email-available`, `admin-resend-confirmation` | `lib/auth-diagnostics.ts` (tiszta függvény – unit tesztelhető) | `AuthHealthDialog` findings lista |
| Csoportos praxistag import | `components/BulkPatientImport.tsx`, `BulkImportHistory.tsx` | duplumvizsgálat (TAJ, Név+szül.dátum) | `bulk-create-patients` | manuális + import napló | `public.bulk_import_logs` tábla, élő progress, backoff/countdown UI |
| Labor webshop | `pages/LabShop.tsx` | `hooks/use-lab-pricing.ts`, `use-lab-packages.ts`, `lib/labTestCatalog*.ts` | `create_public_lab_order`, `get_public_locations`, `ai-lab-recommend` | `use-lab-pricing.test.ts` | Ár-anomália: `LabPricingEditor` validáció; markup vs. „Elemi” teszt flag |
| Labor kérő (orvosi) | `components/LabRequestBuilder.tsx` | `lib/printLabRequest.ts` (HTML escape!) | `generate_lab_request_number` | manuális | Nyomtatás iframe; XSS: `esc()` |
| Kockázatértékelés | `components/RiskAssessmentForm.tsx`, `RiskMatrix.tsx`, `RiskPhotoAnalysis.tsx` | `lib/hazard-catalog.ts` | `ai-risk-photo-analysis`, `ai-sds-analysis` | manuális | Storage `risk-assessment-photos` ownership policy |
| Balesetkezelés | `components/AccidentReportForm.tsx`, `AccidentReportList.tsx` | `lib/accident-codes.ts` | – | manuális | Storage `accident-photos` RLS |
| Dokumentumok / PDF | `components/GeneratePdfButton.tsx`, `Printable*.tsx` | `hooks/use-document-templates.ts` | `generate-pdf` (payload limit, JWT) | integration.test.ts | 500-as hiba → karakterkonverzió (ő/ű), payload méret |
| CMS + SEO | `pages/admin/AdminCMS.tsx`, `AdminSEO.tsx`, `components/WysiwygEditor.tsx` | `hooks/use-cms.ts`, `use-seo.ts`, `lib/sanitize-html.ts` | `ai-seo`, `ai-og-image`, `serve-sitemap`, `serve-llms-txt` | manuális | React Query cache invalidálás (NEM realtime) |
| i18n | `components/LanguageSwitcher.tsx` | `i18n/i18n.ts`, `hooks/use-i18n-overrides.ts`, `use-content-translations.ts` | `ai-translate` | manuális | Hiányzó kulcs → i18next console warn |
| Értesítések / e-mail | `components/NotificationBell.tsx` | `hooks/use-notifications.ts` | `send-notification`, `send-transactional-email`, `process-email-queue`, `handle-email-suppression/unsubscribe` | manuális | `email_send_log`, pgmq `q_auth_emails`/`q_transactional_emails`, DLQ |
| AI asszisztensek | `components/ChatBot.tsx`, `AiAnalysisPanel.tsx`, `SpeechToTextButton.tsx`, `LabAiAssistant.tsx` | – | `ai-*` (20+ függvény, mind JWT-védett) | integration.test.ts (auth guard) | AI Gateway logok; 401 → `LOVABLE_API_KEY` |
| Biztonsági monitorozás | `pages/admin/AdminSecurityEvents.tsx` | `lib/security-monitor.ts` | `log_security_event`, `security-alert-monitor` | – | `security_denials_summary(since)` RPC |
| Audit log | `pages/admin/AdminAuditLog.tsx` | – | `audit_trigger_func`, `_shared/audit.ts` | – | `public.audit_logs` (`changed_fields`) |

---

## 3. Debug-recept gyakori hibákra

| Tünet | Első lépés | Valószínű ok |
|---|---|---|
| `Edge Function returned a non-2xx status code` | `error.context.text()` kiolvasása (`FunctionsHttpError`) | Hiányzó JWT / szerepkör / secret |
| Üres lista, hibaüzenet nélkül | Network: 200 de `[]` | RLS policy vagy hiányzó `GRANT` |
| `permission denied for table` | Migráció ellenőrzése | Hiányzó `GRANT` a public sémában |
| Feltöltés 500 | Fájlnév | Ékezetes karakter → `storage-utils` sanitizálás |
| Csak 1000 sor jön vissza | Lekérdezés | Supabase limit → `range()` kötegelés |
| „useState of null” | `vite.config.ts` | `optimizeDeps.include` hiányzik |
| PDF crash | Szöveg | WinAnsi: `ő`, `ű`, sortörés |
| Villogó töltés / végtelen retry | `BulkImportHistory` | Backoff állapot (max 6 próbálkozás → manuális frissítés) |

---

## 4. Ajánlott bővítendő tesztlefedettség

1. `lib/auth-diagnostics.ts` – `evaluateUser` esetek (unit, gyors nyereség).
2. `lib/sanitize-html.ts` – XSS payload mátrix.
3. `lib/storage-utils.ts` – ékezet-normalizálás.
4. RLS smoke tesztek szerepkörönként (Deno + service_role vs. user token).
5. Playwright E2E: bejelentkezés → szerepváltás → laborrendelés leadása.
