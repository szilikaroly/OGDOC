--
-- PostgreSQL database dump
--

\restrict Y3lqI6tousGnitXhvUUWHmCdJryMe6rR2at5mSdeGUKiBpREfKOMTvnrzCZgEim

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: action_hierarchy; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.action_hierarchy AS ENUM (
    'elimination',
    'substitution',
    'engineering',
    'admin',
    'ppe'
);


--
-- Name: action_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.action_status AS ENUM (
    'planned',
    'in_progress',
    'completed'
);


--
-- Name: app_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.app_role AS ENUM (
    'super_admin',
    'haziorvos',
    'uzemorvos',
    'munkaltato',
    'munkavallalo',
    'praxistag'
);


--
-- Name: appointment_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.appointment_status AS ENUM (
    'pending',
    'confirmed',
    'cancelled',
    'completed',
    'no_show'
);


--
-- Name: blood_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.blood_type AS ENUM (
    'A+',
    'A-',
    'B+',
    'B-',
    'AB+',
    'AB-',
    '0+',
    '0-'
);


--
-- Name: gender_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.gender_type AS ENUM (
    'ferfi',
    'no',
    'egyeb'
);


--
-- Name: hazard_category; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.hazard_category AS ENUM (
    'physical',
    'chemical',
    'biological',
    'ergonomic',
    'psychosocial',
    'equipment',
    'environment',
    'fire',
    'other'
);


--
-- Name: icd_version; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.icd_version AS ENUM (
    'icd10',
    'icd11'
);


--
-- Name: opinion_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.opinion_status AS ENUM (
    'alkalmas',
    'nem_alkalmas',
    'feltetelesen_alkalmas',
    'ideiglenes'
);


--
-- Name: referral_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.referral_status AS ENUM (
    'draft',
    'sent',
    'completed',
    'appointment_booked',
    'questionnaire_filled',
    'exam_started'
);


--
-- Name: request_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.request_status AS ENUM (
    'pending',
    'approved',
    'rejected',
    'completed'
);


--
-- Name: risk_assessment_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.risk_assessment_status AS ENUM (
    'draft',
    'in_review',
    'approved',
    'archived'
);


--
-- Name: admin_get_recovery_history(uuid, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.admin_get_recovery_history(_user_id uuid, _limit integer DEFAULT 10) RETURNS TABLE(id uuid, created_at timestamp with time zone, status text, error_message text, message_id text, recipient_email text, metadata jsonb)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
DECLARE
  _email text;
  _lim int := LEAST(GREATEST(COALESCE(_limit, 10), 1), 50);
BEGIN
  IF NOT public.has_role(auth.uid(), 'super_admin'::app_role) THEN
    RAISE EXCEPTION 'forbidden: super_admin role required';
  END IF;

  SELECT u.email::text INTO _email FROM auth.users u WHERE u.id = _user_id;
  IF _email IS NULL THEN
    RETURN;
  END IF;

  RETURN QUERY
  SELECT l.id, l.created_at, l.status, l.error_message, l.message_id, l.recipient_email, l.metadata
  FROM public.email_send_log l
  WHERE l.template_name = 'recovery'
    AND lower(l.recipient_email) = lower(_email)
  ORDER BY l.created_at DESC
  LIMIT _lim;
END;
$$;


--
-- Name: admin_get_recovery_status(uuid[]); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.admin_get_recovery_status(_user_ids uuid[]) RETURNS TABLE(user_id uuid, email text, recovery_sent_at timestamp with time zone, last_sign_in_at timestamp with time zone, email_confirmed_at timestamp with time zone, last_recovery_status text, last_recovery_error text, last_recovery_log_at timestamp with time zone, user_created_at timestamp with time zone, has_password boolean, last_admin_direct_at timestamp with time zone, last_admin_direct_by uuid, last_action_kind text, last_action_at timestamp with time zone)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
BEGIN
  IF NOT public.has_role(auth.uid(), 'super_admin'::app_role) THEN
    RAISE EXCEPTION 'forbidden: super_admin role required';
  END IF;

  RETURN QUERY
  WITH latest_email AS (
    SELECT DISTINCT ON (l.message_id)
      l.recipient_email, l.status, l.error_message, l.created_at
    FROM public.email_send_log l
    WHERE l.template_name = 'recovery'
      AND l.message_id IS NOT NULL
      AND l.recipient_email IS NOT NULL
    ORDER BY l.message_id, l.created_at DESC
  ), per_user_email AS (
    SELECT
      recipient_email,
      (ARRAY_AGG(status ORDER BY created_at DESC))[1] AS status,
      (ARRAY_AGG(error_message ORDER BY created_at DESC))[1] AS err,
      MAX(created_at) AS at
    FROM latest_email
    GROUP BY recipient_email
  ), latest_direct AS (
    SELECT DISTINCT ON ((se.metadata->>'target_user_id')::uuid)
      (se.metadata->>'target_user_id')::uuid AS target_user_id,
      se.user_id AS actor_user_id,
      se.created_at
    FROM public.security_events se
    WHERE se.event_type = 'admin_password_set'
      AND se.metadata ? 'target_user_id'
    ORDER BY (se.metadata->>'target_user_id')::uuid, se.created_at DESC
  )
  SELECT
    u.id,
    u.email::text,
    u.recovery_sent_at,
    u.last_sign_in_at,
    u.email_confirmed_at,
    p.status,
    p.err,
    p.at,
    u.created_at,
    (u.encrypted_password IS NOT NULL AND length(u.encrypted_password) > 0) AS has_password,
    d.created_at AS last_admin_direct_at,
    d.actor_user_id AS last_admin_direct_by,
    CASE
      WHEN d.created_at IS NULL AND p.at IS NULL AND u.recovery_sent_at IS NULL THEN NULL
      WHEN d.created_at IS NOT NULL
           AND d.created_at >= COALESCE(p.at, '-infinity'::timestamptz)
           AND d.created_at >= COALESCE(u.recovery_sent_at, '-infinity'::timestamptz)
        THEN 'admin_direct'
      ELSE 'email_recovery'
    END AS last_action_kind,
    GREATEST(
      COALESCE(d.created_at, '-infinity'::timestamptz),
      COALESCE(p.at, '-infinity'::timestamptz),
      COALESCE(u.recovery_sent_at, '-infinity'::timestamptz)
    ) AS last_action_at
  FROM auth.users u
  LEFT JOIN per_user_email p ON lower(p.recipient_email) = lower(u.email)
  LEFT JOIN latest_direct d ON d.target_user_id = u.id
  WHERE u.id = ANY(_user_ids);
END;
$$;


--
-- Name: admin_get_user_providers(uuid[]); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.admin_get_user_providers(_user_ids uuid[]) RETURNS TABLE(user_id uuid, providers text[], last_google_sign_in_at timestamp with time zone, last_apple_sign_in_at timestamp with time zone, last_email_sign_in_at timestamp with time zone, google_email text)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
BEGIN
  IF NOT public.has_role(auth.uid(), 'super_admin'::app_role) THEN
    RAISE EXCEPTION 'forbidden: super_admin role required';
  END IF;

  RETURN QUERY
  SELECT
    i.user_id,
    ARRAY_AGG(DISTINCT i.provider ORDER BY i.provider) AS providers,
    MAX(CASE WHEN i.provider = 'google' THEN i.last_sign_in_at END) AS last_google_sign_in_at,
    MAX(CASE WHEN i.provider = 'apple'  THEN i.last_sign_in_at END) AS last_apple_sign_in_at,
    MAX(CASE WHEN i.provider = 'email'  THEN i.last_sign_in_at END) AS last_email_sign_in_at,
    (ARRAY_AGG(i.identity_data->>'email' ORDER BY i.last_sign_in_at DESC NULLS LAST)
       FILTER (WHERE i.provider = 'google'))[1] AS google_email
  FROM auth.identities i
  WHERE i.user_id = ANY(_user_ids)
  GROUP BY i.user_id;
END;
$$;


--
-- Name: admin_recovery_failures_summary(timestamp with time zone); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.admin_recovery_failures_summary(_since timestamp with time zone DEFAULT (now() - '7 days'::interval)) RETURNS TABLE(total_failures bigint, failed_count bigint, suppressed_count bigint, bounced_count bigint, complained_count bigint, dlq_count bigint, affected_recipients bigint, last_event_at timestamp with time zone, recent jsonb)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
BEGIN
  IF NOT public.has_role(auth.uid(), 'super_admin'::app_role) THEN
    RAISE EXCEPTION 'forbidden: super_admin role required';
  END IF;

  RETURN QUERY
  WITH latest AS (
    SELECT DISTINCT ON (l.message_id)
      l.message_id, l.recipient_email, l.status, l.error_message, l.created_at
    FROM public.email_send_log l
    WHERE l.template_name = 'recovery'
      AND l.message_id IS NOT NULL
      AND l.created_at >= _since
    ORDER BY l.message_id, l.created_at DESC
  ), bad AS (
    SELECT * FROM latest
    WHERE status IN ('failed','dlq','bounced','complained','suppressed')
  )
  SELECT
    (SELECT count(*) FROM bad),
    (SELECT count(*) FROM bad WHERE status = 'failed'),
    (SELECT count(*) FROM bad WHERE status = 'suppressed'),
    (SELECT count(*) FROM bad WHERE status = 'bounced'),
    (SELECT count(*) FROM bad WHERE status = 'complained'),
    (SELECT count(*) FROM bad WHERE status = 'dlq'),
    (SELECT count(DISTINCT lower(recipient_email)) FROM bad),
    (SELECT max(created_at) FROM bad),
    COALESCE((
      SELECT jsonb_agg(row_to_json(t) ORDER BY t.created_at DESC)
      FROM (
        SELECT recipient_email, status, error_message, created_at
        FROM bad
        ORDER BY created_at DESC
        LIMIT 10
      ) t
    ), '[]'::jsonb);
END;
$$;


--
-- Name: audit_trigger_func(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.audit_trigger_func() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
DECLARE
  _old_data jsonb;
  _new_data jsonb;
  _changed text[];
  _user_id uuid;
  _record_id uuid;
  _key text;
BEGIN
  -- Try to get the current user
  BEGIN
    _user_id := auth.uid();
  EXCEPTION WHEN OTHERS THEN
    _user_id := NULL;
  END;

  IF TG_OP = 'DELETE' THEN
    _old_data := to_jsonb(OLD);
    _new_data := NULL;
    _record_id := OLD.id;
    _changed := NULL;
  ELSIF TG_OP = 'INSERT' THEN
    _old_data := NULL;
    _new_data := to_jsonb(NEW);
    _record_id := NEW.id;
    _changed := NULL;
  ELSIF TG_OP = 'UPDATE' THEN
    _old_data := to_jsonb(OLD);
    _new_data := to_jsonb(NEW);
    _record_id := NEW.id;
    -- Calculate changed fields
    SELECT array_agg(key) INTO _changed
    FROM jsonb_each(_new_data) AS n(key, value)
    WHERE _old_data->key IS DISTINCT FROM n.value
      AND key NOT IN ('updated_at', 'created_at');
  END IF;

  INSERT INTO public.audit_logs (table_name, record_id, action, old_data, new_data, changed_fields, user_id)
  VALUES (TG_TABLE_NAME, _record_id, TG_OP, _old_data, _new_data, _changed, _user_id);

  IF TG_OP = 'DELETE' THEN
    RETURN OLD;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: auto_update_referral_on_questionnaire(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.auto_update_referral_on_questionnaire() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
BEGIN
  UPDATE public.referrals
  SET status = 'questionnaire_filled', updated_at = now()
  WHERE employee_id = NEW.user_id
    AND status IN ('sent', 'appointment_booked')
    AND updated_at = (
      SELECT MAX(updated_at) FROM public.referrals
      WHERE employee_id = NEW.user_id AND status IN ('sent', 'appointment_booked')
    );
  RETURN NEW;
END;
$$;


--
-- Name: create_public_lab_order(text, text, text, jsonb, text, uuid, text, date, text, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_public_lab_order(_customer_name text, _customer_email text, _customer_phone text, _ordered_tests jsonb, _sampling_type text, _location_id uuid, _home_address text, _preferred_date date, _notes text, _total_price_huf integer) RETURNS TABLE(id uuid, order_number text)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
DECLARE
  _id uuid;
  _num text;
BEGIN
  IF _customer_name IS NULL OR _customer_email IS NULL OR _customer_phone IS NULL THEN
    RAISE EXCEPTION 'Missing required fields';
  END IF;
  IF _ordered_tests IS NULL OR jsonb_array_length(_ordered_tests) = 0 THEN
    RAISE EXCEPTION 'No tests selected';
  END IF;

  INSERT INTO public.lab_orders (
    customer_name, customer_email, customer_phone,
    ordered_tests, sampling_type, location_id, home_address,
    preferred_date, notes, total_price_huf, status
  ) VALUES (
    _customer_name, _customer_email, _customer_phone,
    _ordered_tests, _sampling_type, _location_id, _home_address,
    _preferred_date, _notes, _total_price_huf, 'pending'
  )
  RETURNING lab_orders.id, lab_orders.order_number INTO _id, _num;

  RETURN QUERY SELECT _id, _num;
END;
$$;


--
-- Name: delete_email(text, bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.delete_email(queue_name text, message_id bigint) RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
BEGIN
  RETURN pgmq.delete(queue_name, message_id);
EXCEPTION WHEN undefined_table THEN
  RETURN FALSE;
END;
$$;


--
-- Name: email_queue_dispatch(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.email_queue_dispatch() RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pgmq.q_auth_emails)
     AND NOT EXISTS (SELECT 1 FROM pgmq.q_transactional_emails) THEN
    BEGIN
      -- Serialize disarm against email_queue_wake on a shared advisory lock, then
      -- re-read under it: an enqueue racing the unschedule either committed (we
      -- see its row and leave the cron) or waits and re-arms after we commit.
      PERFORM pg_catalog.pg_advisory_xact_lock(7700000000000001);
      IF EXISTS (SELECT 1 FROM pgmq.q_auth_emails)
         OR EXISTS (SELECT 1 FROM pgmq.q_transactional_emails) THEN
        RETURN;
      END IF;
      PERFORM cron.unschedule('process-email-queue');
    EXCEPTION WHEN OTHERS THEN
      RAISE WARNING 'email_queue_dispatch: cron unschedule failed: %', SQLERRM;
    END;
    RETURN;
  END IF;

  IF (SELECT retry_after_until FROM public.email_send_state WHERE id = 1) > now() THEN
    RETURN;
  END IF;

  PERFORM net.http_post(
    url := 'https://ysbmahmodlflbotekezg.supabase.co/functions/v1/process-email-queue',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Lovable-Context', 'cron',
      'Authorization', 'Bearer ' || (
        SELECT decrypted_secret FROM vault.decrypted_secrets WHERE name = 'email_queue_service_role_key'
      )
    ),
    body := '{}'::jsonb
  );
END;
$$;


--
-- Name: email_queue_wake(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.email_queue_wake() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $_$
BEGIN
  -- Runs inside the enqueue transaction; the outer handler guarantees nothing
  -- below can roll back the customer's email. Shared advisory lock serializes
  -- arming against email_queue_dispatch's disarm.
  PERFORM pg_catalog.pg_advisory_xact_lock(7700000000000001);
  IF NOT EXISTS (SELECT 1 FROM cron.job WHERE jobname = 'process-email-queue') THEN
    BEGIN
      PERFORM cron.schedule('process-email-queue', '5 seconds', $cron$ SELECT public.email_queue_dispatch(); $cron$);
    EXCEPTION WHEN OTHERS THEN
      RAISE WARNING 'email_queue_wake: cron schedule failed: %', SQLERRM;
    END;
  END IF;

  BEGIN
    PERFORM net.http_post(
      url := 'https://ysbmahmodlflbotekezg.supabase.co/functions/v1/process-email-queue',
      headers := jsonb_build_object(
        'Content-Type', 'application/json',
        'Lovable-Context', 'cron',
        'Authorization', 'Bearer ' || (
          SELECT decrypted_secret FROM vault.decrypted_secrets WHERE name = 'email_queue_service_role_key'
        )
      ),
      body := '{}'::jsonb
    );
  EXCEPTION WHEN OTHERS THEN NULL;
  END;

  RETURN NULL;
EXCEPTION WHEN OTHERS THEN
  RAISE WARNING 'email_queue_wake failed (enqueue preserved): %', SQLERRM;
  RETURN NULL;
END;
$_$;


--
-- Name: enqueue_email(text, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.enqueue_email(queue_name text, payload jsonb) RETURNS bigint
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
BEGIN
  RETURN pgmq.send(queue_name, payload);
EXCEPTION WHEN undefined_table THEN
  PERFORM pgmq.create(queue_name);
  RETURN pgmq.send(queue_name, payload);
END;
$$;


--
-- Name: generate_lab_order_number(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.generate_lab_order_number() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $_$
DECLARE seq_num INTEGER;
BEGIN
  SELECT COALESCE(MAX(
    CASE WHEN order_number ~ '^LO-\d{4}-\d+$'
    THEN CAST(SPLIT_PART(order_number, '-', 3) AS INTEGER)
    ELSE 0 END
  ), 0) + 1
  INTO seq_num
  FROM public.lab_orders
  WHERE order_number LIKE 'LO-' || EXTRACT(YEAR FROM now())::text || '-%';

  NEW.order_number := 'LO-' || EXTRACT(YEAR FROM now())::text || '-' || LPAD(seq_num::text, 4, '0');
  RETURN NEW;
END;
$_$;


--
-- Name: generate_lab_request_number(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.generate_lab_request_number() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $_$
DECLARE
  seq_num INTEGER;
BEGIN
  SELECT COALESCE(MAX(
    CASE WHEN request_number ~ '^LKR-\d{4}-\d+$'
    THEN CAST(SPLIT_PART(request_number, '-', 3) AS INTEGER)
    ELSE 0 END
  ), 0) + 1
  INTO seq_num
  FROM public.lab_requests
  WHERE request_number LIKE 'LKR-' || EXTRACT(YEAR FROM now())::text || '-%';

  NEW.request_number := 'LKR-' || EXTRACT(YEAR FROM now())::text || '-' || LPAD(seq_num::text, 4, '0');
  RETURN NEW;
END;
$_$;


--
-- Name: get_public_locations(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_public_locations() RETURNS TABLE(id uuid, name text, address text, city text, email text, phone text, whatsapp text, google_maps_url text, description text)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT id, name, address, city, email, phone, whatsapp, google_maps_url, description
  FROM public.locations
  WHERE is_active = true
  ORDER BY name;
$$;


--
-- Name: get_user_roles(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_user_roles(_user_id uuid) RETURNS public.app_role[]
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT ARRAY_AGG(role) FROM public.user_roles WHERE user_id = _user_id;
$$;


--
-- Name: handle_new_user(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.handle_new_user() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
BEGIN
  INSERT INTO public.profiles (user_id, full_name)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email, '')
  )
  ON CONFLICT (user_id) DO NOTHING;
  RETURN NEW;
END;
$$;


--
-- Name: has_role(uuid, public.app_role); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.has_role(_user_id uuid, _role public.app_role) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  );
$$;


--
-- Name: is_company_member(uuid, uuid, public.app_role); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.is_company_member(_user_id uuid, _company_id uuid, _role public.app_role) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_company_relations
    WHERE user_id = _user_id
      AND company_id = _company_id
      AND role = _role
      AND is_active = true
  )
$$;


--
-- Name: is_employer_of_patient(uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.is_employer_of_patient(_employer_id uuid, _patient_id uuid) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_company_relations emp
    JOIN public.user_company_relations pat ON pat.company_id = emp.company_id
    WHERE emp.user_id = _employer_id
      AND emp.role = 'munkaltato'
      AND emp.is_active = true
      AND pat.user_id = _patient_id
      AND pat.is_active = true
  )
$$;


--
-- Name: log_security_event(text, text, text, text, text, text, text, text, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.log_security_event(_event_type text, _severity text DEFAULT 'warn'::text, _table_name text DEFAULT NULL::text, _operation text DEFAULT NULL::text, _error_code text DEFAULT NULL::text, _error_message text DEFAULT NULL::text, _route text DEFAULT NULL::text, _user_agent text DEFAULT NULL::text, _metadata jsonb DEFAULT '{}'::jsonb) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
DECLARE
  _id uuid;
  _uid uuid;
  _email text;
BEGIN
  BEGIN
    _uid := auth.uid();
  EXCEPTION WHEN OTHERS THEN
    _uid := NULL;
  END;

  IF _uid IS NOT NULL THEN
    SELECT email INTO _email FROM auth.users WHERE id = _uid;
  END IF;

  -- Truncate large messages to keep table small
  INSERT INTO public.security_events (
    event_type, severity, user_id, user_email, table_name, operation,
    error_code, error_message, route, user_agent, metadata
  ) VALUES (
    _event_type,
    COALESCE(_severity, 'warn'),
    _uid,
    _email,
    _table_name,
    _operation,
    _error_code,
    LEFT(COALESCE(_error_message, ''), 2000),
    _route,
    LEFT(COALESCE(_user_agent, ''), 500),
    COALESCE(_metadata, '{}'::jsonb)
  ) RETURNING id INTO _id;

  RETURN _id;
END;
$$;


--
-- Name: move_to_dlq(text, text, bigint, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.move_to_dlq(source_queue text, dlq_name text, message_id bigint, payload jsonb) RETURNS bigint
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
DECLARE new_id BIGINT;
BEGIN
  SELECT pgmq.send(dlq_name, payload) INTO new_id;
  PERFORM pgmq.delete(source_queue, message_id);
  RETURN new_id;
EXCEPTION WHEN undefined_table THEN
  BEGIN
    PERFORM pgmq.create(dlq_name);
  EXCEPTION WHEN OTHERS THEN
    NULL;
  END;
  SELECT pgmq.send(dlq_name, payload) INTO new_id;
  BEGIN
    PERFORM pgmq.delete(source_queue, message_id);
  EXCEPTION WHEN undefined_table THEN
    NULL;
  END;
  RETURN new_id;
END;
$$;


--
-- Name: notify_admins_on_recovery_failure(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.notify_admins_on_recovery_failure() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
DECLARE
  _bad_statuses text[] := ARRAY['failed','dlq','bounced','complained','suppressed'];
  _title text;
  _body text;
BEGIN
  IF NEW.template_name <> 'recovery' THEN
    RETURN NEW;
  END IF;
  IF NOT (NEW.status = ANY(_bad_statuses)) THEN
    RETURN NEW;
  END IF;
  -- Only fire when status transitions into a bad state (or first insert)
  IF TG_OP = 'UPDATE' AND OLD.status = NEW.status THEN
    RETURN NEW;
  END IF;

  _title := CASE
    WHEN NEW.status = 'suppressed' THEN 'Letiltott jelszó-visszaállító e-mail'
    ELSE 'Sikertelen jelszó-visszaállító e-mail'
  END;
  _body := COALESCE(NEW.recipient_email, '?') || ' — státusz: ' || NEW.status
    || CASE WHEN NEW.error_message IS NOT NULL AND length(NEW.error_message) > 0
            THEN ' — ' || LEFT(NEW.error_message, 240)
            ELSE '' END;

  INSERT INTO public.notifications (user_id, type, title, body, link)
  SELECT ur.user_id, 'recovery_alert', _title, _body, '/admin/users'
  FROM public.user_roles ur
  WHERE ur.role = 'super_admin'::app_role;

  RETURN NEW;
END;
$$;


--
-- Name: read_email_batch(text, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.read_email_batch(queue_name text, batch_size integer, vt integer) RETURNS TABLE(msg_id bigint, read_ct integer, message jsonb)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
BEGIN
  RETURN QUERY SELECT r.msg_id, r.read_ct, r.message FROM pgmq.read(queue_name, vt, batch_size) r;
EXCEPTION WHEN undefined_table THEN
  PERFORM pgmq.create(queue_name);
  RETURN;
END;
$$;


--
-- Name: search_icd_codes(text, text, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_icd_codes(_query text, _version text DEFAULT 'icd10'::text, _limit integer DEFAULT 20) RETURNS TABLE(id uuid, code text, version public.icd_version, label_hu text, label_en text, parent_code text, level integer, synonyms text[], category text, is_active boolean)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT id, code, version, label_hu, label_en, parent_code, level, synonyms, category, is_active
  FROM public.icd_codes
  WHERE is_active = true
    AND version = _version::public.icd_version
    AND (
      code ILIKE '%' || _query || '%'
      OR label_hu ILIKE '%' || _query || '%'
      OR label_en ILIKE '%' || _query || '%'
      OR category ILIKE '%' || _query || '%'
      OR EXISTS (
        SELECT 1 FROM unnest(synonyms) s
        WHERE s ILIKE '%' || _query || '%'
      )
    )
  ORDER BY code
  LIMIT LEAST(GREATEST(COALESCE(_limit, 20), 1), 100);
$$;


--
-- Name: security_denials_summary(timestamp with time zone); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.security_denials_summary(_since timestamp with time zone) RETURNS TABLE(user_id uuid, user_email text, denial_count bigint, last_seen timestamp with time zone, sample_messages text[])
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT
    user_id,
    MAX(user_email) AS user_email,
    COUNT(*) AS denial_count,
    MAX(created_at) AS last_seen,
    (ARRAY_AGG(DISTINCT LEFT(error_message, 200)))[1:5] AS sample_messages
  FROM public.security_events
  WHERE event_type = 'rls_denied'
    AND created_at >= _since
  GROUP BY user_id;
$$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;


--
-- Name: validate_icd_code(text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_icd_code(_code text, _version text DEFAULT 'icd10'::text) RETURNS boolean
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
DECLARE
  _exists boolean;
BEGIN
  SELECT EXISTS (
    SELECT 1 FROM public.icd_codes
    WHERE code = _code
      AND version = _version::public.icd_version
      AND is_active = true
  ) INTO _exists;

  IF NOT _exists THEN
    PERFORM public.log_security_event(
      'invalid_icd_code',
      'warn',
      'icd_codes',
      'validate',
      NULL,
      'Invalid ICD code attempted: ' || _code || ' (' || _version || ')',
      NULL,
      NULL,
      jsonb_build_object('code', _code, 'version', _version)
    );
  END IF;

  RETURN _exists;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accident_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accident_reports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    employee_id uuid NOT NULL,
    created_by uuid NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    registration_number text,
    territorial_code text,
    report_type text DEFAULT '1'::text,
    employer_name text,
    employer_address text,
    employer_phone text,
    employer_fax text,
    employer_mobile text,
    employer_email text,
    employer_tax_number text,
    employer_tax_id text,
    employer_org_form text,
    employer_teaor_main text,
    employer_teaor_local text,
    employer_total_staff_category text,
    employer_local_staff_category text,
    injured_name text,
    injured_taj text,
    injured_birth_name text,
    injured_mother_name text,
    injured_birth_place text,
    injured_birth_date date,
    injured_gender text,
    injured_citizenship text,
    injured_address text,
    injured_phone text,
    injured_feor_code text,
    injured_feor_name text,
    injured_employment_type text,
    injured_employment_nature text,
    accident_date date,
    accident_time_hour text,
    injury_work_hour text,
    injury_type_code text,
    injured_body_part_code text,
    work_location_code text,
    accident_geo_location text,
    accident_geo_code text,
    injury_severity_code text,
    disability_days integer,
    detailed_description text,
    workplace_environment text,
    work_process text,
    physical_activity text,
    physical_activity_material text,
    triggering_event text,
    triggering_event_material text,
    injury_contact_mode text,
    injury_contact_material text,
    personal_factor_injured text,
    personal_factor_employer text,
    safety_device_guard text,
    safety_device_protection text,
    safety_device_signal text,
    safety_device_ppe text,
    safety_device_other text,
    accident_causes text,
    prevention_measures text,
    attachments_notes text,
    safety_rep_name text,
    safety_rep_date date,
    safety_rep_agreement text,
    investigator_name text,
    investigator_date date,
    investigator_cert_no text,
    doctor_name text,
    doctor_date date,
    doctor_stamp_no text,
    employer_rep_name text,
    employer_rep_position text,
    employer_rep_date date,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    gps_lat numeric,
    gps_lng numeric,
    photos text[] DEFAULT '{}'::text[],
    icd_codes text[] DEFAULT '{}'::text[]
);


--
-- Name: COLUMN accident_reports.icd_codes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.accident_reports.icd_codes IS 'Kiválasztott BNO/ICD kódok a balesethez';


--
-- Name: activities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.activities (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    short_description text,
    long_description text,
    icon_name text DEFAULT 'Stethoscope'::text,
    image_url text,
    seo_title text,
    seo_description text,
    seo_keywords text,
    og_title text,
    og_description text,
    og_image text,
    page_content text,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: appointment_slots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.appointment_slots (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    service_id uuid,
    location_id uuid,
    doctor_id uuid,
    assistant_id uuid,
    slot_start timestamp with time zone NOT NULL,
    slot_end timestamp with time zone NOT NULL,
    capacity integer DEFAULT 1 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: appointments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.appointments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    slot_id uuid,
    patient_id uuid NOT NULL,
    service_id uuid,
    doctor_id uuid,
    status public.appointment_status DEFAULT 'pending'::public.appointment_status NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    table_name text NOT NULL,
    record_id uuid NOT NULL,
    action text NOT NULL,
    old_data jsonb,
    new_data jsonb,
    changed_fields text[],
    user_id uuid,
    ip_address text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: bulk_import_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bulk_import_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    import_type text DEFAULT 'patients'::text NOT NULL,
    file_name text,
    total_rows integer DEFAULT 0 NOT NULL,
    new_count integer DEFAULT 0 NOT NULL,
    duplicate_count integer DEFAULT 0 NOT NULL,
    error_count integer DEFAULT 0 NOT NULL,
    success_count integer DEFAULT 0 NOT NULL,
    details jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: certificates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.certificates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    doctor_id uuid NOT NULL,
    patient_id uuid NOT NULL,
    certificate_type text NOT NULL,
    certificate_date date DEFAULT CURRENT_DATE NOT NULL,
    valid_from date,
    valid_until date,
    purpose text,
    notes text,
    pdf_url text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT certificates_certificate_type_check CHECK ((certificate_type = ANY (ARRAY['megjelenes'::text, 'special'::text, 'keresokeptelen'::text])))
);


--
-- Name: companies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.companies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    tax_number text,
    registration_no text,
    address text,
    contact_email text,
    contact_phone text,
    industry text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    contract_category text,
    pricing_type text,
    contract_price numeric,
    CONSTRAINT companies_contract_category_check CHECK ((contract_category = ANY (ARRAY['A'::text, 'B'::text, 'C'::text, 'D'::text]))),
    CONSTRAINT companies_pricing_type_check CHECK ((pricing_type = ANY (ARRAY['fix'::text, 'per_capita'::text, 'monthly'::text])))
);


--
-- Name: company_hazardous_substances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_hazardous_substances (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    substance_id uuid NOT NULL,
    usage_description text DEFAULT ''::text,
    annual_quantity text DEFAULT ''::text,
    exposure_type text DEFAULT ''::text,
    ppe_required text DEFAULT ''::text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: company_sites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_sites (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    name text NOT NULL,
    address text,
    city text,
    postal_code text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: company_teaor_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_teaor_codes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    teaor_code text NOT NULL,
    teaor_name text,
    is_primary boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid
);


--
-- Name: competitor_analyses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.competitor_analyses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    competitor_url_id uuid,
    analysis_type text DEFAULT 'seo_compare'::text NOT NULL,
    results jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: competitor_urls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.competitor_urls (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    url text NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: content_translations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.content_translations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    table_name text NOT NULL,
    record_id uuid NOT NULL,
    field_name text NOT NULL,
    language text NOT NULL,
    value text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: doctor_recommendations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.doctor_recommendations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    doctor_id uuid NOT NULL,
    patient_id uuid NOT NULL,
    type text NOT NULL,
    title text DEFAULT ''::text NOT NULL,
    plan_markdown text DEFAULT ''::text NOT NULL,
    duration_days integer,
    preferences jsonb DEFAULT '{}'::jsonb,
    is_read boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT doctor_recommendations_type_check CHECK ((type = ANY (ARRAY['screening_plan'::text, 'diet_plan'::text])))
);


--
-- Name: document_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_tags (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    label text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: document_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    document_type text NOT NULL,
    name text NOT NULL,
    fields jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.documents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    document_type text NOT NULL,
    related_id uuid,
    file_name text NOT NULL,
    file_path text NOT NULL,
    file_size integer,
    mime_type text DEFAULT 'application/pdf'::text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    ai_analysis jsonb,
    tags text[] DEFAULT '{}'::text[]
);


--
-- Name: email_send_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_send_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    message_id text,
    template_name text NOT NULL,
    recipient_email text NOT NULL,
    status text NOT NULL,
    error_message text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT email_send_log_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'sent'::text, 'suppressed'::text, 'failed'::text, 'bounced'::text, 'complained'::text, 'dlq'::text])))
);


--
-- Name: email_send_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_send_state (
    id integer DEFAULT 1 NOT NULL,
    retry_after_until timestamp with time zone,
    batch_size integer DEFAULT 10 NOT NULL,
    send_delay_ms integer DEFAULT 200 NOT NULL,
    auth_email_ttl_minutes integer DEFAULT 15 NOT NULL,
    transactional_email_ttl_minutes integer DEFAULT 60 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT email_send_state_id_check CHECK ((id = 1))
);


--
-- Name: email_unsubscribe_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_unsubscribe_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    token text NOT NULL,
    email text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    used_at timestamp with time zone
);


--
-- Name: examinations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.examinations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    patient_id uuid NOT NULL,
    doctor_id uuid NOT NULL,
    referral_id uuid,
    appointment_id uuid,
    exam_type text NOT NULL,
    patient_data jsonb DEFAULT '{}'::jsonb,
    clinical_findings jsonb DEFAULT '{}'::jsonb,
    result public.opinion_status DEFAULT 'alkalmas'::public.opinion_status NOT NULL,
    restrictions text,
    valid_until date,
    ai_notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    workflow_status text DEFAULT 'started'::text,
    next_lab_control date
);


--
-- Name: food_journal; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.food_journal (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    entry_date date DEFAULT CURRENT_DATE NOT NULL,
    meal_type text DEFAULT 'snack'::text NOT NULL,
    food_description text,
    calories_estimated integer,
    protein_g numeric,
    carbs_g numeric,
    fat_g numeric,
    fiber_g numeric,
    image_url text,
    ai_analyzed boolean DEFAULT false NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: gdpr_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gdpr_requests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    type text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    notes text,
    processed_by uuid,
    processed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT gdpr_requests_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'processing'::text, 'completed'::text, 'rejected'::text]))),
    CONSTRAINT gdpr_requests_type_check CHECK ((type = ANY (ARRAY['export'::text, 'delete'::text])))
);


--
-- Name: hazardous_substances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hazardous_substances (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    ec_number text DEFAULT ''::text,
    cas_number text DEFAULT ''::text,
    reason_for_inclusion text DEFAULT ''::text,
    source text DEFAULT 'echa_candidate'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    description text,
    date_of_inclusion date,
    decision_url text,
    iuclid_dataset_url text,
    support_document_url text,
    remarks text
);


--
-- Name: health_journal; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.health_journal (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    entry_date date DEFAULT CURRENT_DATE NOT NULL,
    blood_pressure_systolic integer,
    blood_pressure_diastolic integer,
    heart_rate integer,
    weight_kg numeric,
    blood_sugar numeric,
    temperature numeric,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: health_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.health_plans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    preferences jsonb DEFAULT '{}'::jsonb,
    plan_markdown text NOT NULL,
    generated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: health_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.health_reports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    report_date date DEFAULT CURRENT_DATE NOT NULL,
    weight_kg numeric(5,2),
    height_cm numeric(5,1),
    blood_pressure_systolic integer,
    blood_pressure_diastolic integer,
    heart_rate integer,
    blood_sugar numeric(5,2),
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: i18n_overrides; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.i18n_overrides (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    language text NOT NULL,
    translations jsonb DEFAULT '{}'::jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid
);


--
-- Name: icd_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.icd_codes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code text NOT NULL,
    version public.icd_version DEFAULT 'icd10'::public.icd_version NOT NULL,
    label_hu text NOT NULL,
    label_en text,
    parent_code text,
    level integer DEFAULT 0 NOT NULL,
    synonyms text[] DEFAULT '{}'::text[],
    category text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: lab_markup_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lab_markup_config (
    id integer DEFAULT 1 NOT NULL,
    markup_huf integer DEFAULT 4000 NOT NULL,
    home_sampling_fee_huf integer DEFAULT 8000 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: lab_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lab_orders (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    order_number text DEFAULT ''::text NOT NULL,
    customer_name text NOT NULL,
    customer_email text NOT NULL,
    customer_phone text NOT NULL,
    ordered_tests jsonb DEFAULT '[]'::jsonb NOT NULL,
    sampling_type text DEFAULT 'location'::text NOT NULL,
    location_id uuid,
    home_address text,
    preferred_date date,
    notes text,
    total_price_huf integer DEFAULT 0 NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    user_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: lab_packages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lab_packages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    description text,
    icon text DEFAULT '📦'::text,
    test_ids text[] DEFAULT '{}'::text[] NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    target_audience text
);


--
-- Name: lab_pricing_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lab_pricing_config (
    test_id text NOT NULL,
    points integer DEFAULT 10 NOT NULL,
    price_huf integer DEFAULT 0 NOT NULL,
    updated_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: lab_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lab_requests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    request_number text DEFAULT ''::text NOT NULL,
    patient_id uuid NOT NULL,
    physician_id uuid NOT NULL,
    requested_tests jsonb DEFAULT '[]'::jsonb NOT NULL,
    priority text DEFAULT 'routine'::text NOT NULL,
    scheduled_date date,
    notes text,
    cost_bearer text DEFAULT 'taj'::text,
    status text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.locations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    address text,
    city text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    email text,
    phone text,
    whatsapp text,
    google_maps_url text,
    responsible_user_id uuid,
    description text
);


--
-- Name: medical_opinions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.medical_opinions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    patient_id uuid NOT NULL,
    doctor_id uuid NOT NULL,
    company_id uuid,
    appointment_id uuid,
    opinion_date date DEFAULT CURRENT_DATE NOT NULL,
    valid_until date,
    status public.opinion_status DEFAULT 'alkalmas'::public.opinion_status NOT NULL,
    notes text,
    pdf_url text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    signature_data text,
    icd_codes text[] DEFAULT '{}'::text[]
);


--
-- Name: COLUMN medical_opinions.icd_codes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.medical_opinions.icd_codes IS 'Kiválasztott BNO/ICD kódok a szakvéleményhez';


--
-- Name: medication_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.medication_requests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    patient_id uuid NOT NULL,
    medication_name text NOT NULL,
    request_type text DEFAULT 'allando'::text NOT NULL,
    notes text,
    status text DEFAULT 'pending'::text NOT NULL,
    doctor_response text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: medications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.medications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL
);


--
-- Name: messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    sender_id uuid NOT NULL,
    recipient_id uuid,
    group_role public.app_role,
    subject text,
    body text NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: navigation_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.navigation_links (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    label text NOT NULL,
    href text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    parent_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: noise_vibration_measurements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.noise_vibration_measurements (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    risk_assessment_id uuid NOT NULL,
    workplace_id uuid,
    measurement_type text NOT NULL,
    value_db numeric,
    value_ms2 numeric,
    peak_value numeric,
    duration_seconds integer DEFAULT 10 NOT NULL,
    frequency_data jsonb DEFAULT '[]'::jsonb,
    location_description text,
    notes text,
    measured_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT noise_vibration_measurements_measurement_type_check CHECK ((measurement_type = ANY (ARRAY['noise_room'::text, 'noise_1m'::text, 'vibration_wbv'::text, 'vibration_hav'::text])))
);


--
-- Name: notification_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_preferences (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    email_appointments boolean DEFAULT true NOT NULL,
    email_reminders boolean DEFAULT true NOT NULL,
    email_opinions boolean DEFAULT true NOT NULL,
    email_vaccinations boolean DEFAULT true NOT NULL,
    inapp_appointments boolean DEFAULT true NOT NULL,
    inapp_reminders boolean DEFAULT true NOT NULL,
    inapp_opinions boolean DEFAULT true NOT NULL,
    inapp_vaccinations boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    type text NOT NULL,
    title text NOT NULL,
    body text,
    link text,
    is_read boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: page_views; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.page_views (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    page_path text NOT NULL,
    referrer text,
    user_agent text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: pages_content; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pages_content (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    page_key text NOT NULL,
    section text NOT NULL,
    content text,
    content_json jsonb,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: patient_cards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.patient_cards (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    drug_allergies text,
    chronic_diseases text,
    regular_medications text,
    family_history jsonb DEFAULT '{}'::jsonb,
    surgeries text,
    smoking jsonb DEFAULT '{}'::jsonb,
    alcohol text,
    last_chest_xray date,
    last_gynecology date,
    pregnancies text,
    other_notes text,
    occupation text,
    employer_name text,
    marital_status text,
    drivers_license boolean DEFAULT false,
    previous_doctor text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    education text,
    professional_qual text,
    notification_address text,
    sports_habit text,
    eating_habit text,
    occupation_history jsonb DEFAULT '[]'::jsonb,
    reported_occupational_diseases text,
    military_service boolean DEFAULT false,
    exposures jsonb DEFAULT '{}'::jsonb
);


--
-- Name: profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.profiles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    full_name text DEFAULT ''::text NOT NULL,
    taj_number text,
    birth_date date,
    gender public.gender_type,
    blood_type public.blood_type,
    mother_name text,
    birth_place text,
    phone text,
    address text,
    avatar_url text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    signature_url text
);


--
-- Name: questionnaire_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.questionnaire_assignments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    questionnaire_id uuid NOT NULL,
    patient_id uuid NOT NULL,
    assigned_by uuid NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone
);


--
-- Name: questionnaire_submissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.questionnaire_submissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    questionnaire_id uuid NOT NULL,
    user_id uuid NOT NULL,
    answers jsonb DEFAULT '{}'::jsonb NOT NULL,
    submitted_at timestamp with time zone DEFAULT now() NOT NULL,
    score integer,
    risk_category text,
    ai_evaluation text
);


--
-- Name: questionnaires; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.questionnaires (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title text NOT NULL,
    description text,
    fields jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: referrals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.referrals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    employee_id uuid NOT NULL,
    created_by uuid NOT NULL,
    "position" text,
    feor text,
    unit_name text,
    exam_reason text NOT NULL,
    risk_factors jsonb DEFAULT '{}'::jsonb,
    status public.referral_status DEFAULT 'draft'::public.referral_status NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    work_area_id uuid,
    workplace_id uuid,
    risk_assessment_id uuid,
    icd_codes text[] DEFAULT '{}'::text[]
);


--
-- Name: COLUMN referrals.icd_codes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.referrals.icd_codes IS 'Kiválasztott BNO/ICD kódok a beutalóhoz';


--
-- Name: requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.requests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    requester_id uuid NOT NULL,
    assignee_id uuid,
    type text NOT NULL,
    subject text,
    description text,
    status public.request_status DEFAULT 'pending'::public.request_status NOT NULL,
    response text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: risk_assessment_hazards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.risk_assessment_hazards (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    risk_assessment_id uuid NOT NULL,
    workplace_id uuid,
    hazard_category public.hazard_category DEFAULT 'other'::public.hazard_category NOT NULL,
    hazard_subcategory text,
    hazard_name text NOT NULL,
    hazard_description text,
    exposed_count integer DEFAULT 0,
    exposure_duration text,
    exposure_frequency text,
    probability integer DEFAULT 1,
    severity integer DEFAULT 1,
    risk_level integer GENERATED ALWAYS AS ((probability * severity)) STORED,
    risk_category text GENERATED ALWAYS AS (
CASE
    WHEN ((probability * severity) <= 2) THEN 'trivial'::text
    WHEN ((probability * severity) <= 4) THEN 'tolerable'::text
    WHEN ((probability * severity) <= 6) THEN 'moderate'::text
    WHEN ((probability * severity) <= 9) THEN 'substantial'::text
    ELSE 'intolerable'::text
END) STORED,
    current_controls text,
    required_actions text,
    action_responsible text,
    action_deadline date,
    action_status public.action_status DEFAULT 'planned'::public.action_status,
    action_hierarchy public.action_hierarchy,
    residual_probability integer,
    residual_severity integer,
    residual_risk_level integer GENERATED ALWAYS AS (
CASE
    WHEN ((residual_probability IS NOT NULL) AND (residual_severity IS NOT NULL)) THEN (residual_probability * residual_severity)
    ELSE NULL::integer
END) STORED,
    substance_ids uuid[] DEFAULT '{}'::uuid[],
    ai_suggested boolean DEFAULT false,
    sort_order integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT risk_assessment_hazards_probability_check CHECK (((probability >= 1) AND (probability <= 4))),
    CONSTRAINT risk_assessment_hazards_residual_probability_check CHECK (((residual_probability IS NULL) OR ((residual_probability >= 1) AND (residual_probability <= 4)))),
    CONSTRAINT risk_assessment_hazards_residual_severity_check CHECK (((residual_severity IS NULL) OR ((residual_severity >= 1) AND (residual_severity <= 4)))),
    CONSTRAINT risk_assessment_hazards_severity_check CHECK (((severity >= 1) AND (severity <= 4)))
);


--
-- Name: risk_assessment_photos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.risk_assessment_photos (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    risk_assessment_id uuid NOT NULL,
    work_area_id uuid,
    workplace_id uuid,
    file_path text NOT NULL,
    file_name text NOT NULL,
    caption text,
    ai_analysis jsonb,
    uploaded_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: risk_assessments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.risk_assessments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    work_area_id uuid NOT NULL,
    title text DEFAULT ''::text NOT NULL,
    assessment_date date DEFAULT CURRENT_DATE NOT NULL,
    assessor_name text,
    assessor_qualification text,
    status public.risk_assessment_status DEFAULT 'draft'::public.risk_assessment_status NOT NULL,
    approved_by uuid,
    approved_at timestamp with time zone,
    next_review_date date,
    review_frequency_months integer DEFAULT 12,
    previous_assessment_id uuid,
    context_analysis jsonb DEFAULT '{}'::jsonb,
    summary_notes text,
    document_url text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: security_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.security_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    event_type text NOT NULL,
    severity text DEFAULT 'info'::text NOT NULL,
    user_id uuid,
    user_email text,
    table_name text,
    operation text,
    error_code text,
    error_message text,
    route text,
    user_agent text,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    function_name text,
    resource_type text,
    resource_id text,
    action text,
    duration_ms integer,
    status_code integer
);


--
-- Name: seo_audit_scores; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seo_audit_scores (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    page_path text NOT NULL,
    score integer DEFAULT 0 NOT NULL,
    grade text DEFAULT 'F'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: seo_pages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seo_pages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    page_path text NOT NULL,
    title text,
    description text,
    og_title text,
    og_description text,
    og_image text,
    keywords text,
    canonical_url text,
    noindex boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: service_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_categories (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.services (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    description text,
    duration_min integer DEFAULT 30 NOT NULL,
    category text,
    is_active boolean DEFAULT true NOT NULL,
    price numeric(10,2),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    icon_name text
);


--
-- Name: site_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.site_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    key text NOT NULL,
    value text,
    value_json jsonb,
    label text,
    section text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stool_journal; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stool_journal (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    entry_date date DEFAULT CURRENT_DATE NOT NULL,
    bristol_type integer,
    color text,
    blood_present boolean DEFAULT false NOT NULL,
    mucus_present boolean DEFAULT false NOT NULL,
    pain_level integer,
    image_url text,
    ai_analyzed boolean DEFAULT false NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT stool_journal_bristol_type_check CHECK (((bristol_type >= 1) AND (bristol_type <= 7))),
    CONSTRAINT stool_journal_pain_level_check CHECK (((pain_level >= 0) AND (pain_level <= 10)))
);


--
-- Name: suppressed_emails; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suppressed_emails (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email text NOT NULL,
    reason text NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT suppressed_emails_reason_check CHECK ((reason = ANY (ARRAY['unsubscribe'::text, 'bounce'::text, 'complaint'::text])))
);


--
-- Name: user_company_relations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_company_relations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    company_id uuid NOT NULL,
    role public.app_role DEFAULT 'munkavallalo'::public.app_role NOT NULL,
    "position" text,
    is_active boolean DEFAULT true NOT NULL,
    start_date date,
    end_date date,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    risk_factors jsonb DEFAULT '{}'::jsonb,
    hazard_substances uuid[] DEFAULT '{}'::uuid[],
    site_id uuid,
    work_area_id uuid,
    workplace_id uuid,
    feor_code text,
    feor_name text
);


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    role public.app_role NOT NULL,
    granted_by uuid,
    granted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vaccinations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vaccinations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    vaccine_name text NOT NULL,
    administered_date date NOT NULL,
    expiry_date date,
    lot_number text,
    administered_by text,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: web_vitals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.web_vitals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    metric_name text NOT NULL,
    value numeric NOT NULL,
    page_path text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: work_area_sds_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_area_sds_documents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    work_area_id uuid NOT NULL,
    file_name text NOT NULL,
    file_path text NOT NULL,
    substance_name text,
    cas_number text,
    ec_number text,
    is_mixture boolean DEFAULT false,
    mixture_components jsonb DEFAULT '[]'::jsonb,
    analysis_data jsonb,
    risk_level text,
    uploaded_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: work_areas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_areas (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    site_id uuid NOT NULL,
    name text NOT NULL,
    description text,
    area_size_m2 numeric,
    floor_plan_url text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: workplaces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workplaces (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    work_area_id uuid NOT NULL,
    name text NOT NULL,
    code text,
    description text,
    equipment_list jsonb DEFAULT '[]'::jsonb,
    employee_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: accident_reports accident_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accident_reports
    ADD CONSTRAINT accident_reports_pkey PRIMARY KEY (id);


--
-- Name: activities activities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT activities_pkey PRIMARY KEY (id);


--
-- Name: activities activities_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT activities_slug_key UNIQUE (slug);


--
-- Name: appointment_slots appointment_slots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointment_slots
    ADD CONSTRAINT appointment_slots_pkey PRIMARY KEY (id);


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: bulk_import_logs bulk_import_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bulk_import_logs
    ADD CONSTRAINT bulk_import_logs_pkey PRIMARY KEY (id);


--
-- Name: certificates certificates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_pkey PRIMARY KEY (id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: companies companies_tax_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_tax_number_key UNIQUE (tax_number);


--
-- Name: company_hazardous_substances company_hazardous_substances_company_id_substance_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_hazardous_substances
    ADD CONSTRAINT company_hazardous_substances_company_id_substance_id_key UNIQUE (company_id, substance_id);


--
-- Name: company_hazardous_substances company_hazardous_substances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_hazardous_substances
    ADD CONSTRAINT company_hazardous_substances_pkey PRIMARY KEY (id);


--
-- Name: company_sites company_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_sites
    ADD CONSTRAINT company_sites_pkey PRIMARY KEY (id);


--
-- Name: company_teaor_codes company_teaor_codes_company_id_teaor_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_teaor_codes
    ADD CONSTRAINT company_teaor_codes_company_id_teaor_code_key UNIQUE (company_id, teaor_code);


--
-- Name: company_teaor_codes company_teaor_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_teaor_codes
    ADD CONSTRAINT company_teaor_codes_pkey PRIMARY KEY (id);


--
-- Name: competitor_analyses competitor_analyses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.competitor_analyses
    ADD CONSTRAINT competitor_analyses_pkey PRIMARY KEY (id);


--
-- Name: competitor_urls competitor_urls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.competitor_urls
    ADD CONSTRAINT competitor_urls_pkey PRIMARY KEY (id);


--
-- Name: content_translations content_translations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content_translations
    ADD CONSTRAINT content_translations_pkey PRIMARY KEY (id);


--
-- Name: content_translations content_translations_table_name_record_id_field_name_langua_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content_translations
    ADD CONSTRAINT content_translations_table_name_record_id_field_name_langua_key UNIQUE (table_name, record_id, field_name, language);


--
-- Name: doctor_recommendations doctor_recommendations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doctor_recommendations
    ADD CONSTRAINT doctor_recommendations_pkey PRIMARY KEY (id);


--
-- Name: document_tags document_tags_label_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_tags
    ADD CONSTRAINT document_tags_label_key UNIQUE (label);


--
-- Name: document_tags document_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_tags
    ADD CONSTRAINT document_tags_pkey PRIMARY KEY (id);


--
-- Name: document_templates document_templates_document_type_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_templates
    ADD CONSTRAINT document_templates_document_type_key UNIQUE (document_type);


--
-- Name: document_templates document_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_templates
    ADD CONSTRAINT document_templates_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: email_send_log email_send_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_send_log
    ADD CONSTRAINT email_send_log_pkey PRIMARY KEY (id);


--
-- Name: email_send_state email_send_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_send_state
    ADD CONSTRAINT email_send_state_pkey PRIMARY KEY (id);


--
-- Name: email_unsubscribe_tokens email_unsubscribe_tokens_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_unsubscribe_tokens
    ADD CONSTRAINT email_unsubscribe_tokens_email_key UNIQUE (email);


--
-- Name: email_unsubscribe_tokens email_unsubscribe_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_unsubscribe_tokens
    ADD CONSTRAINT email_unsubscribe_tokens_pkey PRIMARY KEY (id);


--
-- Name: email_unsubscribe_tokens email_unsubscribe_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_unsubscribe_tokens
    ADD CONSTRAINT email_unsubscribe_tokens_token_key UNIQUE (token);


--
-- Name: examinations examinations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.examinations
    ADD CONSTRAINT examinations_pkey PRIMARY KEY (id);


--
-- Name: food_journal food_journal_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.food_journal
    ADD CONSTRAINT food_journal_pkey PRIMARY KEY (id);


--
-- Name: gdpr_requests gdpr_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gdpr_requests
    ADD CONSTRAINT gdpr_requests_pkey PRIMARY KEY (id);


--
-- Name: hazardous_substances hazardous_substances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hazardous_substances
    ADD CONSTRAINT hazardous_substances_pkey PRIMARY KEY (id);


--
-- Name: health_journal health_journal_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_journal
    ADD CONSTRAINT health_journal_pkey PRIMARY KEY (id);


--
-- Name: health_plans health_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_plans
    ADD CONSTRAINT health_plans_pkey PRIMARY KEY (id);


--
-- Name: health_reports health_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_reports
    ADD CONSTRAINT health_reports_pkey PRIMARY KEY (id);


--
-- Name: i18n_overrides i18n_overrides_language_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.i18n_overrides
    ADD CONSTRAINT i18n_overrides_language_key UNIQUE (language);


--
-- Name: i18n_overrides i18n_overrides_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.i18n_overrides
    ADD CONSTRAINT i18n_overrides_pkey PRIMARY KEY (id);


--
-- Name: icd_codes icd_codes_code_version_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.icd_codes
    ADD CONSTRAINT icd_codes_code_version_key UNIQUE (code, version);


--
-- Name: icd_codes icd_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.icd_codes
    ADD CONSTRAINT icd_codes_pkey PRIMARY KEY (id);


--
-- Name: lab_markup_config lab_markup_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lab_markup_config
    ADD CONSTRAINT lab_markup_config_pkey PRIMARY KEY (id);


--
-- Name: lab_orders lab_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lab_orders
    ADD CONSTRAINT lab_orders_pkey PRIMARY KEY (id);


--
-- Name: lab_packages lab_packages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lab_packages
    ADD CONSTRAINT lab_packages_pkey PRIMARY KEY (id);


--
-- Name: lab_pricing_config lab_pricing_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lab_pricing_config
    ADD CONSTRAINT lab_pricing_config_pkey PRIMARY KEY (test_id);


--
-- Name: lab_requests lab_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lab_requests
    ADD CONSTRAINT lab_requests_pkey PRIMARY KEY (id);


--
-- Name: locations locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_pkey PRIMARY KEY (id);


--
-- Name: medical_opinions medical_opinions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medical_opinions
    ADD CONSTRAINT medical_opinions_pkey PRIMARY KEY (id);


--
-- Name: medication_requests medication_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_requests
    ADD CONSTRAINT medication_requests_pkey PRIMARY KEY (id);


--
-- Name: medications medications_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medications
    ADD CONSTRAINT medications_name_key UNIQUE (name);


--
-- Name: medications medications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medications
    ADD CONSTRAINT medications_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: navigation_links navigation_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.navigation_links
    ADD CONSTRAINT navigation_links_pkey PRIMARY KEY (id);


--
-- Name: noise_vibration_measurements noise_vibration_measurements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.noise_vibration_measurements
    ADD CONSTRAINT noise_vibration_measurements_pkey PRIMARY KEY (id);


--
-- Name: notification_preferences notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_pkey PRIMARY KEY (id);


--
-- Name: notification_preferences notification_preferences_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_user_id_key UNIQUE (user_id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: page_views page_views_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.page_views
    ADD CONSTRAINT page_views_pkey PRIMARY KEY (id);


--
-- Name: pages_content pages_content_page_key_section_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pages_content
    ADD CONSTRAINT pages_content_page_key_section_key UNIQUE (page_key, section);


--
-- Name: pages_content pages_content_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pages_content
    ADD CONSTRAINT pages_content_pkey PRIMARY KEY (id);


--
-- Name: patient_cards patient_cards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_cards
    ADD CONSTRAINT patient_cards_pkey PRIMARY KEY (id);


--
-- Name: patient_cards patient_cards_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_cards
    ADD CONSTRAINT patient_cards_user_id_key UNIQUE (user_id);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- Name: profiles profiles_taj_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_taj_number_key UNIQUE (taj_number);


--
-- Name: profiles profiles_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_user_id_key UNIQUE (user_id);


--
-- Name: questionnaire_assignments questionnaire_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.questionnaire_assignments
    ADD CONSTRAINT questionnaire_assignments_pkey PRIMARY KEY (id);


--
-- Name: questionnaire_submissions questionnaire_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.questionnaire_submissions
    ADD CONSTRAINT questionnaire_submissions_pkey PRIMARY KEY (id);


--
-- Name: questionnaires questionnaires_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.questionnaires
    ADD CONSTRAINT questionnaires_pkey PRIMARY KEY (id);


--
-- Name: referrals referrals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_pkey PRIMARY KEY (id);


--
-- Name: requests requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.requests
    ADD CONSTRAINT requests_pkey PRIMARY KEY (id);


--
-- Name: risk_assessment_hazards risk_assessment_hazards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.risk_assessment_hazards
    ADD CONSTRAINT risk_assessment_hazards_pkey PRIMARY KEY (id);


--
-- Name: risk_assessment_photos risk_assessment_photos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.risk_assessment_photos
    ADD CONSTRAINT risk_assessment_photos_pkey PRIMARY KEY (id);


--
-- Name: risk_assessments risk_assessments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.risk_assessments
    ADD CONSTRAINT risk_assessments_pkey PRIMARY KEY (id);


--
-- Name: security_events security_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_events
    ADD CONSTRAINT security_events_pkey PRIMARY KEY (id);


--
-- Name: seo_audit_scores seo_audit_scores_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seo_audit_scores
    ADD CONSTRAINT seo_audit_scores_pkey PRIMARY KEY (id);


--
-- Name: seo_pages seo_pages_page_path_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seo_pages
    ADD CONSTRAINT seo_pages_page_path_key UNIQUE (page_path);


--
-- Name: seo_pages seo_pages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seo_pages
    ADD CONSTRAINT seo_pages_pkey PRIMARY KEY (id);


--
-- Name: service_categories service_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_categories
    ADD CONSTRAINT service_categories_pkey PRIMARY KEY (id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: site_settings site_settings_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_settings
    ADD CONSTRAINT site_settings_key_key UNIQUE (key);


--
-- Name: site_settings site_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_settings
    ADD CONSTRAINT site_settings_pkey PRIMARY KEY (id);


--
-- Name: stool_journal stool_journal_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stool_journal
    ADD CONSTRAINT stool_journal_pkey PRIMARY KEY (id);


--
-- Name: suppressed_emails suppressed_emails_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppressed_emails
    ADD CONSTRAINT suppressed_emails_email_key UNIQUE (email);


--
-- Name: suppressed_emails suppressed_emails_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppressed_emails
    ADD CONSTRAINT suppressed_emails_pkey PRIMARY KEY (id);


--
-- Name: user_company_relations user_company_relations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_company_relations
    ADD CONSTRAINT user_company_relations_pkey PRIMARY KEY (id);


--
-- Name: user_company_relations user_company_relations_user_id_company_id_role_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_company_relations
    ADD CONSTRAINT user_company_relations_user_id_company_id_role_key UNIQUE (user_id, company_id, role);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_user_id_role_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_role_key UNIQUE (user_id, role);


--
-- Name: vaccinations vaccinations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vaccinations
    ADD CONSTRAINT vaccinations_pkey PRIMARY KEY (id);


--
-- Name: web_vitals web_vitals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.web_vitals
    ADD CONSTRAINT web_vitals_pkey PRIMARY KEY (id);


--
-- Name: work_area_sds_documents work_area_sds_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_area_sds_documents
    ADD CONSTRAINT work_area_sds_documents_pkey PRIMARY KEY (id);


--
-- Name: work_areas work_areas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_areas
    ADD CONSTRAINT work_areas_pkey PRIMARY KEY (id);


--
-- Name: workplaces workplaces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workplaces
    ADD CONSTRAINT workplaces_pkey PRIMARY KEY (id);


--
-- Name: idx_bulk_import_logs_user_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bulk_import_logs_user_created ON public.bulk_import_logs USING btree (user_id, created_at DESC);


--
-- Name: idx_company_sites_company; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_company_sites_company ON public.company_sites USING btree (company_id);


--
-- Name: idx_competitor_analyses_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_competitor_analyses_type ON public.competitor_analyses USING btree (analysis_type);


--
-- Name: idx_competitor_analyses_url_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_competitor_analyses_url_id ON public.competitor_analyses USING btree (competitor_url_id);


--
-- Name: idx_content_translations_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_content_translations_lookup ON public.content_translations USING btree (table_name, language);


--
-- Name: idx_content_translations_record; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_content_translations_record ON public.content_translations USING btree (table_name, record_id, language);


--
-- Name: idx_email_send_log_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_email_send_log_created ON public.email_send_log USING btree (created_at DESC);


--
-- Name: idx_email_send_log_message; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_email_send_log_message ON public.email_send_log USING btree (message_id);


--
-- Name: idx_email_send_log_message_sent_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_email_send_log_message_sent_unique ON public.email_send_log USING btree (message_id) WHERE (status = 'sent'::text);


--
-- Name: idx_email_send_log_recipient; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_email_send_log_recipient ON public.email_send_log USING btree (recipient_email);


--
-- Name: idx_hazardous_substances_cas; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hazardous_substances_cas ON public.hazardous_substances USING btree (cas_number);


--
-- Name: idx_hazardous_substances_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hazardous_substances_name ON public.hazardous_substances USING gin (to_tsvector('simple'::regconfig, name));


--
-- Name: idx_icd_codes_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_icd_codes_code ON public.icd_codes USING btree (code);


--
-- Name: idx_icd_codes_search_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_icd_codes_search_trgm ON public.icd_codes USING gin (code public.gin_trgm_ops, label_hu public.gin_trgm_ops, label_en public.gin_trgm_ops, category public.gin_trgm_ops);


--
-- Name: idx_icd_codes_version_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_icd_codes_version_active ON public.icd_codes USING btree (version, is_active);


--
-- Name: idx_nvm_risk_assessment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_nvm_risk_assessment ON public.noise_vibration_measurements USING btree (risk_assessment_id);


--
-- Name: idx_nvm_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_nvm_type ON public.noise_vibration_measurements USING btree (measurement_type);


--
-- Name: idx_page_views_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_page_views_created ON public.page_views USING btree (created_at);


--
-- Name: idx_page_views_path; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_page_views_path ON public.page_views USING btree (page_path);


--
-- Name: idx_referrals_work_area; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_referrals_work_area ON public.referrals USING btree (work_area_id);


--
-- Name: idx_risk_assessment_hazards_assessment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_risk_assessment_hazards_assessment ON public.risk_assessment_hazards USING btree (risk_assessment_id);


--
-- Name: idx_risk_assessment_photos_assessment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_risk_assessment_photos_assessment ON public.risk_assessment_photos USING btree (risk_assessment_id);


--
-- Name: idx_risk_assessments_company; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_risk_assessments_company ON public.risk_assessments USING btree (company_id);


--
-- Name: idx_risk_assessments_work_area; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_risk_assessments_work_area ON public.risk_assessments USING btree (work_area_id);


--
-- Name: idx_security_events_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_security_events_created_at ON public.security_events USING btree (created_at DESC);


--
-- Name: idx_security_events_event_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_security_events_event_type ON public.security_events USING btree (event_type);


--
-- Name: idx_security_events_function_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_security_events_function_name ON public.security_events USING btree (function_name) WHERE (function_name IS NOT NULL);


--
-- Name: idx_security_events_severity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_security_events_severity ON public.security_events USING btree (severity);


--
-- Name: idx_security_events_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_security_events_user_id ON public.security_events USING btree (user_id);


--
-- Name: idx_seo_audit_scores_path; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_seo_audit_scores_path ON public.seo_audit_scores USING btree (page_path);


--
-- Name: idx_suppressed_emails_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_suppressed_emails_email ON public.suppressed_emails USING btree (email);


--
-- Name: idx_ucr_site; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ucr_site ON public.user_company_relations USING btree (site_id);


--
-- Name: idx_ucr_work_area; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ucr_work_area ON public.user_company_relations USING btree (work_area_id);


--
-- Name: idx_unsubscribe_tokens_token; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_unsubscribe_tokens_token ON public.email_unsubscribe_tokens USING btree (token);


--
-- Name: idx_web_vitals_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_web_vitals_created ON public.web_vitals USING btree (created_at);


--
-- Name: idx_web_vitals_metric; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_web_vitals_metric ON public.web_vitals USING btree (metric_name);


--
-- Name: idx_work_areas_site; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_work_areas_site ON public.work_areas USING btree (site_id);


--
-- Name: idx_workplaces_work_area; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_workplaces_work_area ON public.workplaces USING btree (work_area_id);


--
-- Name: user_company_relations_user_company_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX user_company_relations_user_company_unique ON public.user_company_relations USING btree (user_id, company_id);


--
-- Name: appointments audit_appointments; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_appointments AFTER INSERT OR DELETE OR UPDATE ON public.appointments FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();


--
-- Name: companies audit_companies; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_companies AFTER INSERT OR DELETE OR UPDATE ON public.companies FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();


--
-- Name: documents audit_documents; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_documents AFTER INSERT OR DELETE OR UPDATE ON public.documents FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();


--
-- Name: examinations audit_examinations; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_examinations AFTER INSERT OR DELETE OR UPDATE ON public.examinations FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();


--
-- Name: icd_codes audit_icd_codes; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_icd_codes AFTER INSERT OR DELETE OR UPDATE ON public.icd_codes FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();


--
-- Name: medical_opinions audit_medical_opinions; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_medical_opinions AFTER INSERT OR DELETE OR UPDATE ON public.medical_opinions FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();


--
-- Name: medication_requests audit_medication_requests; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_medication_requests AFTER INSERT OR DELETE OR UPDATE ON public.medication_requests FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();


--
-- Name: patient_cards audit_patient_cards; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_patient_cards AFTER INSERT OR DELETE OR UPDATE ON public.patient_cards FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();


--
-- Name: profiles audit_profiles; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_profiles AFTER INSERT OR DELETE OR UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();


--
-- Name: referrals audit_referrals; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_referrals AFTER INSERT OR DELETE OR UPDATE ON public.referrals FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();


--
-- Name: user_company_relations audit_user_company_relations; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_user_company_relations AFTER INSERT OR DELETE OR UPDATE ON public.user_company_relations FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();


--
-- Name: vaccinations audit_vaccinations; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_vaccinations AFTER INSERT OR DELETE OR UPDATE ON public.vaccinations FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();


--
-- Name: questionnaire_submissions auto_referral_questionnaire_status; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER auto_referral_questionnaire_status AFTER INSERT ON public.questionnaire_submissions FOR EACH ROW EXECUTE FUNCTION public.auto_update_referral_on_questionnaire();


--
-- Name: lab_orders set_lab_order_number; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER set_lab_order_number BEFORE INSERT ON public.lab_orders FOR EACH ROW EXECUTE FUNCTION public.generate_lab_order_number();


--
-- Name: lab_requests set_lab_request_number; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER set_lab_request_number BEFORE INSERT ON public.lab_requests FOR EACH ROW EXECUTE FUNCTION public.generate_lab_request_number();


--
-- Name: email_send_log trg_notify_admins_recovery_failure; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_notify_admins_recovery_failure AFTER INSERT OR UPDATE OF status ON public.email_send_log FOR EACH ROW EXECUTE FUNCTION public.notify_admins_on_recovery_failure();


--
-- Name: accident_reports update_accident_reports_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_accident_reports_updated_at BEFORE UPDATE ON public.accident_reports FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: activities update_activities_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_activities_updated_at BEFORE UPDATE ON public.activities FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: appointments update_appointments_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_appointments_updated_at BEFORE UPDATE ON public.appointments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: companies update_companies_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_companies_updated_at BEFORE UPDATE ON public.companies FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: company_sites update_company_sites_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_company_sites_updated_at BEFORE UPDATE ON public.company_sites FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: content_translations update_content_translations_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_content_translations_updated_at BEFORE UPDATE ON public.content_translations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: document_templates update_document_templates_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_document_templates_updated_at BEFORE UPDATE ON public.document_templates FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: gdpr_requests update_gdpr_requests_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_gdpr_requests_updated_at BEFORE UPDATE ON public.gdpr_requests FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: i18n_overrides update_i18n_overrides_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_i18n_overrides_updated_at BEFORE UPDATE ON public.i18n_overrides FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: icd_codes update_icd_codes_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_icd_codes_updated_at BEFORE UPDATE ON public.icd_codes FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: lab_orders update_lab_orders_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_lab_orders_updated_at BEFORE UPDATE ON public.lab_orders FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: lab_packages update_lab_packages_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_lab_packages_updated_at BEFORE UPDATE ON public.lab_packages FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: lab_requests update_lab_requests_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_lab_requests_updated_at BEFORE UPDATE ON public.lab_requests FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: locations update_locations_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_locations_updated_at BEFORE UPDATE ON public.locations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: medication_requests update_medication_requests_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_medication_requests_updated_at BEFORE UPDATE ON public.medication_requests FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: navigation_links update_nav_links_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_nav_links_updated_at BEFORE UPDATE ON public.navigation_links FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: notification_preferences update_notification_preferences_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_notification_preferences_updated_at BEFORE UPDATE ON public.notification_preferences FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: medical_opinions update_opinions_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_opinions_updated_at BEFORE UPDATE ON public.medical_opinions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: pages_content update_pages_content_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_pages_content_updated_at BEFORE UPDATE ON public.pages_content FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: patient_cards update_patient_cards_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_patient_cards_updated_at BEFORE UPDATE ON public.patient_cards FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: profiles update_profiles_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: questionnaires update_questionnaires_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_questionnaires_updated_at BEFORE UPDATE ON public.questionnaires FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: referrals update_referrals_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_referrals_updated_at BEFORE UPDATE ON public.referrals FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: requests update_requests_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_requests_updated_at BEFORE UPDATE ON public.requests FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: risk_assessments update_risk_assessments_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_risk_assessments_updated_at BEFORE UPDATE ON public.risk_assessments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: services update_services_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_services_updated_at BEFORE UPDATE ON public.services FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: site_settings update_site_settings_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_site_settings_updated_at BEFORE UPDATE ON public.site_settings FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: appointment_slots update_slots_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_slots_updated_at BEFORE UPDATE ON public.appointment_slots FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: vaccinations update_vaccinations_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_vaccinations_updated_at BEFORE UPDATE ON public.vaccinations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: work_area_sds_documents update_work_area_sds_documents_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_work_area_sds_documents_updated_at BEFORE UPDATE ON public.work_area_sds_documents FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: work_areas update_work_areas_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_work_areas_updated_at BEFORE UPDATE ON public.work_areas FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: workplaces update_workplaces_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_workplaces_updated_at BEFORE UPDATE ON public.workplaces FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: accident_reports accident_reports_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accident_reports
    ADD CONSTRAINT accident_reports_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: appointment_slots appointment_slots_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointment_slots
    ADD CONSTRAINT appointment_slots_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.locations(id) ON DELETE SET NULL;


--
-- Name: appointment_slots appointment_slots_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointment_slots
    ADD CONSTRAINT appointment_slots_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id) ON DELETE SET NULL;


--
-- Name: appointments appointments_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id) ON DELETE SET NULL;


--
-- Name: appointments appointments_slot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_slot_id_fkey FOREIGN KEY (slot_id) REFERENCES public.appointment_slots(id) ON DELETE SET NULL;


--
-- Name: company_hazardous_substances company_hazardous_substances_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_hazardous_substances
    ADD CONSTRAINT company_hazardous_substances_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: company_hazardous_substances company_hazardous_substances_substance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_hazardous_substances
    ADD CONSTRAINT company_hazardous_substances_substance_id_fkey FOREIGN KEY (substance_id) REFERENCES public.hazardous_substances(id) ON DELETE CASCADE;


--
-- Name: company_sites company_sites_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_sites
    ADD CONSTRAINT company_sites_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: company_teaor_codes company_teaor_codes_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_teaor_codes
    ADD CONSTRAINT company_teaor_codes_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: competitor_analyses competitor_analyses_competitor_url_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.competitor_analyses
    ADD CONSTRAINT competitor_analyses_competitor_url_id_fkey FOREIGN KEY (competitor_url_id) REFERENCES public.competitor_urls(id) ON DELETE CASCADE;


--
-- Name: examinations examinations_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.examinations
    ADD CONSTRAINT examinations_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id) ON DELETE SET NULL;


--
-- Name: examinations examinations_referral_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.examinations
    ADD CONSTRAINT examinations_referral_id_fkey FOREIGN KEY (referral_id) REFERENCES public.referrals(id) ON DELETE SET NULL;


--
-- Name: i18n_overrides i18n_overrides_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.i18n_overrides
    ADD CONSTRAINT i18n_overrides_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES auth.users(id);


--
-- Name: lab_orders lab_orders_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lab_orders
    ADD CONSTRAINT lab_orders_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.locations(id);


--
-- Name: medical_opinions medical_opinions_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medical_opinions
    ADD CONSTRAINT medical_opinions_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id) ON DELETE SET NULL;


--
-- Name: medical_opinions medical_opinions_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medical_opinions
    ADD CONSTRAINT medical_opinions_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE SET NULL;


--
-- Name: navigation_links navigation_links_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.navigation_links
    ADD CONSTRAINT navigation_links_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.navigation_links(id) ON DELETE SET NULL;


--
-- Name: noise_vibration_measurements noise_vibration_measurements_risk_assessment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.noise_vibration_measurements
    ADD CONSTRAINT noise_vibration_measurements_risk_assessment_id_fkey FOREIGN KEY (risk_assessment_id) REFERENCES public.risk_assessments(id) ON DELETE CASCADE;


--
-- Name: noise_vibration_measurements noise_vibration_measurements_workplace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.noise_vibration_measurements
    ADD CONSTRAINT noise_vibration_measurements_workplace_id_fkey FOREIGN KEY (workplace_id) REFERENCES public.workplaces(id) ON DELETE SET NULL;


--
-- Name: questionnaire_assignments questionnaire_assignments_questionnaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.questionnaire_assignments
    ADD CONSTRAINT questionnaire_assignments_questionnaire_id_fkey FOREIGN KEY (questionnaire_id) REFERENCES public.questionnaires(id) ON DELETE CASCADE;


--
-- Name: questionnaire_submissions questionnaire_submissions_questionnaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.questionnaire_submissions
    ADD CONSTRAINT questionnaire_submissions_questionnaire_id_fkey FOREIGN KEY (questionnaire_id) REFERENCES public.questionnaires(id) ON DELETE CASCADE;


--
-- Name: referrals referrals_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: referrals referrals_risk_assessment_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_risk_assessment_id_fk FOREIGN KEY (risk_assessment_id) REFERENCES public.risk_assessments(id) ON DELETE SET NULL;


--
-- Name: referrals referrals_work_area_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_work_area_id_fk FOREIGN KEY (work_area_id) REFERENCES public.work_areas(id) ON DELETE SET NULL;


--
-- Name: referrals referrals_workplace_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_workplace_id_fk FOREIGN KEY (workplace_id) REFERENCES public.workplaces(id) ON DELETE SET NULL;


--
-- Name: risk_assessment_hazards risk_assessment_hazards_risk_assessment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.risk_assessment_hazards
    ADD CONSTRAINT risk_assessment_hazards_risk_assessment_id_fkey FOREIGN KEY (risk_assessment_id) REFERENCES public.risk_assessments(id) ON DELETE CASCADE;


--
-- Name: risk_assessment_hazards risk_assessment_hazards_workplace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.risk_assessment_hazards
    ADD CONSTRAINT risk_assessment_hazards_workplace_id_fkey FOREIGN KEY (workplace_id) REFERENCES public.workplaces(id) ON DELETE SET NULL;


--
-- Name: risk_assessment_photos risk_assessment_photos_risk_assessment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.risk_assessment_photos
    ADD CONSTRAINT risk_assessment_photos_risk_assessment_id_fkey FOREIGN KEY (risk_assessment_id) REFERENCES public.risk_assessments(id) ON DELETE CASCADE;


--
-- Name: risk_assessment_photos risk_assessment_photos_work_area_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.risk_assessment_photos
    ADD CONSTRAINT risk_assessment_photos_work_area_id_fkey FOREIGN KEY (work_area_id) REFERENCES public.work_areas(id) ON DELETE SET NULL;


--
-- Name: risk_assessment_photos risk_assessment_photos_workplace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.risk_assessment_photos
    ADD CONSTRAINT risk_assessment_photos_workplace_id_fkey FOREIGN KEY (workplace_id) REFERENCES public.workplaces(id) ON DELETE SET NULL;


--
-- Name: risk_assessments risk_assessments_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.risk_assessments
    ADD CONSTRAINT risk_assessments_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: risk_assessments risk_assessments_previous_assessment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.risk_assessments
    ADD CONSTRAINT risk_assessments_previous_assessment_id_fkey FOREIGN KEY (previous_assessment_id) REFERENCES public.risk_assessments(id);


--
-- Name: risk_assessments risk_assessments_work_area_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.risk_assessments
    ADD CONSTRAINT risk_assessments_work_area_id_fkey FOREIGN KEY (work_area_id) REFERENCES public.work_areas(id) ON DELETE CASCADE;


--
-- Name: user_company_relations ucr_site_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_company_relations
    ADD CONSTRAINT ucr_site_id_fk FOREIGN KEY (site_id) REFERENCES public.company_sites(id) ON DELETE SET NULL;


--
-- Name: user_company_relations ucr_work_area_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_company_relations
    ADD CONSTRAINT ucr_work_area_id_fk FOREIGN KEY (work_area_id) REFERENCES public.work_areas(id) ON DELETE SET NULL;


--
-- Name: user_company_relations ucr_workplace_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_company_relations
    ADD CONSTRAINT ucr_workplace_id_fk FOREIGN KEY (workplace_id) REFERENCES public.workplaces(id) ON DELETE SET NULL;


--
-- Name: user_company_relations user_company_relations_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_company_relations
    ADD CONSTRAINT user_company_relations_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: work_area_sds_documents work_area_sds_documents_work_area_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_area_sds_documents
    ADD CONSTRAINT work_area_sds_documents_work_area_id_fkey FOREIGN KEY (work_area_id) REFERENCES public.work_areas(id) ON DELETE CASCADE;


--
-- Name: work_areas work_areas_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_areas
    ADD CONSTRAINT work_areas_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.company_sites(id) ON DELETE CASCADE;


--
-- Name: workplaces workplaces_work_area_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workplaces
    ADD CONSTRAINT workplaces_work_area_id_fkey FOREIGN KEY (work_area_id) REFERENCES public.work_areas(id) ON DELETE CASCADE;


--
-- Name: activities Activities readable by everyone; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Activities readable by everyone" ON public.activities FOR SELECT USING (true);


--
-- Name: competitor_analyses Admins can manage competitor_analyses; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage competitor_analyses" ON public.competitor_analyses TO authenticated USING (public.has_role(auth.uid(), 'super_admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: competitor_urls Admins can manage competitor_urls; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage competitor_urls" ON public.competitor_urls TO authenticated USING (public.has_role(auth.uid(), 'super_admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: content_translations Admins can manage content translations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage content translations" ON public.content_translations TO authenticated USING (public.has_role(auth.uid(), 'super_admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: i18n_overrides Admins can manage translations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage translations" ON public.i18n_overrides TO authenticated USING (public.has_role(auth.uid(), 'super_admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: page_views Admins can read page views; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can read page views" ON public.page_views FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: web_vitals Admins can read web vitals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can read web vitals" ON public.web_vitals FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: gdpr_requests Admins can update gdpr_requests; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can update gdpr_requests" ON public.gdpr_requests FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: seo_audit_scores Admins manage audit scores; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins manage audit scores" ON public.seo_audit_scores TO authenticated USING (public.has_role(auth.uid(), 'super_admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: lab_markup_config Admins manage lab markup; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins manage lab markup" ON public.lab_markup_config TO authenticated USING (public.has_role(auth.uid(), 'super_admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: lab_orders Admins manage lab orders; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins manage lab orders" ON public.lab_orders TO authenticated USING (public.has_role(auth.uid(), 'super_admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: lab_pricing_config Admins manage lab pricing; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins manage lab pricing" ON public.lab_pricing_config TO authenticated USING (public.has_role(auth.uid(), 'super_admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: lab_orders Anonymous create guest lab orders; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Anonymous create guest lab orders" ON public.lab_orders FOR INSERT TO anon WITH CHECK ((user_id IS NULL));


--
-- Name: page_views Anyone can insert page views; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Anyone can insert page views" ON public.page_views FOR INSERT TO authenticated, anon WITH CHECK (((page_path IS NOT NULL) AND ((char_length(page_path) >= 1) AND (char_length(page_path) <= 2048)) AND ((user_agent IS NULL) OR (char_length(user_agent) <= 1024))));


--
-- Name: web_vitals Anyone can insert web vitals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Anyone can insert web vitals" ON public.web_vitals FOR INSERT TO authenticated, anon WITH CHECK (((metric_name IS NOT NULL) AND ((char_length(metric_name) >= 1) AND (char_length(metric_name) <= 64)) AND (value IS NOT NULL) AND (page_path IS NOT NULL) AND ((char_length(page_path) >= 1) AND (char_length(page_path) <= 2048))));


--
-- Name: lab_packages Anyone can read active packages; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Anyone can read active packages" ON public.lab_packages FOR SELECT USING ((is_active = true));


--
-- Name: content_translations Anyone can read content translations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Anyone can read content translations" ON public.content_translations FOR SELECT TO authenticated, anon USING (true);


--
-- Name: document_templates Anyone can read document templates; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Anyone can read document templates" ON public.document_templates FOR SELECT TO authenticated USING (true);


--
-- Name: lab_markup_config Anyone can read lab markup; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Anyone can read lab markup" ON public.lab_markup_config FOR SELECT TO authenticated, anon USING (true);


--
-- Name: lab_pricing_config Anyone can read lab pricing; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Anyone can read lab pricing" ON public.lab_pricing_config FOR SELECT TO authenticated, anon USING (true);


--
-- Name: i18n_overrides Anyone can read translations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Anyone can read translations" ON public.i18n_overrides FOR SELECT TO authenticated, anon USING (true);


--
-- Name: requests Assignee updates requests; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Assignee updates requests" ON public.requests FOR UPDATE USING (((auth.uid() = assignee_id) OR (auth.uid() = requester_id)));


--
-- Name: lab_orders Authenticated create own lab orders; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Authenticated create own lab orders" ON public.lab_orders FOR INSERT TO authenticated WITH CHECK ((auth.uid() = user_id));


--
-- Name: noise_vibration_measurements Authenticated users can create measurements; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Authenticated users can create measurements" ON public.noise_vibration_measurements FOR INSERT TO authenticated WITH CHECK ((auth.uid() = measured_by));


--
-- Name: work_area_sds_documents Authenticated users can insert SDS documents; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Authenticated users can insert SDS documents" ON public.work_area_sds_documents FOR INSERT TO authenticated WITH CHECK ((auth.uid() = uploaded_by));


--
-- Name: icd_codes Authenticated users can read active ICD codes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Authenticated users can read active ICD codes" ON public.icd_codes FOR SELECT TO authenticated USING ((is_active = true));


--
-- Name: hazardous_substances Authenticated users can read substances; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Authenticated users can read substances" ON public.hazardous_substances FOR SELECT TO authenticated USING (true);


--
-- Name: companies Company members and admins see companies; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Company members and admins see companies" ON public.companies FOR SELECT TO authenticated USING ((public.has_role(auth.uid(), 'super_admin'::public.app_role) OR public.has_role(auth.uid(), 'uzemorvos'::public.app_role) OR (EXISTS ( SELECT 1
   FROM public.user_company_relations
  WHERE ((user_company_relations.company_id = companies.id) AND (user_company_relations.user_id = auth.uid()) AND (user_company_relations.is_active = true))))));


--
-- Name: company_hazardous_substances Company members can view company substances; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Company members can view company substances" ON public.company_hazardous_substances FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.user_company_relations
  WHERE ((user_company_relations.user_id = auth.uid()) AND (user_company_relations.company_id = company_hazardous_substances.company_id) AND (user_company_relations.is_active = true)))));


--
-- Name: company_teaor_codes Company members can view teaor codes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Company members can view teaor codes" ON public.company_teaor_codes FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.user_company_relations
  WHERE ((user_company_relations.user_id = auth.uid()) AND (user_company_relations.company_id = company_teaor_codes.company_id) AND (user_company_relations.is_active = true)))));


--
-- Name: risk_assessment_hazards Company members see hazards; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Company members see hazards" ON public.risk_assessment_hazards FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM (public.risk_assessments ra
     JOIN public.user_company_relations ucr ON ((ucr.company_id = ra.company_id)))
  WHERE ((ra.id = risk_assessment_hazards.risk_assessment_id) AND (ucr.user_id = auth.uid()) AND (ucr.is_active = true)))));


--
-- Name: risk_assessment_photos Company members see photos; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Company members see photos" ON public.risk_assessment_photos FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM (public.risk_assessments ra
     JOIN public.user_company_relations ucr ON ((ucr.company_id = ra.company_id)))
  WHERE ((ra.id = risk_assessment_photos.risk_assessment_id) AND (ucr.user_id = auth.uid()) AND (ucr.is_active = true)))));


--
-- Name: work_areas Company members see work_areas; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Company members see work_areas" ON public.work_areas FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM (public.company_sites cs
     JOIN public.user_company_relations ucr ON ((ucr.company_id = cs.company_id)))
  WHERE ((cs.id = work_areas.site_id) AND (ucr.user_id = auth.uid()) AND (ucr.is_active = true)))));


--
-- Name: workplaces Company members see workplaces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Company members see workplaces" ON public.workplaces FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM ((public.work_areas wa
     JOIN public.company_sites cs ON ((cs.id = wa.site_id)))
     JOIN public.user_company_relations ucr ON ((ucr.company_id = cs.company_id)))
  WHERE ((wa.id = workplaces.work_area_id) AND (ucr.user_id = auth.uid()) AND (ucr.is_active = true)))));


--
-- Name: examinations Doctor manages own examinations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Doctor manages own examinations" ON public.examinations USING ((auth.uid() = doctor_id));


--
-- Name: work_area_sds_documents Doctors can manage SDS documents; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Doctors can manage SDS documents" ON public.work_area_sds_documents TO authenticated USING (public.has_role(auth.uid(), 'uzemorvos'::public.app_role));


--
-- Name: health_plans Doctors can view patient health plans; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Doctors can view patient health plans" ON public.health_plans FOR SELECT TO authenticated USING ((public.has_role(auth.uid(), 'haziorvos'::public.app_role) OR public.has_role(auth.uid(), 'uzemorvos'::public.app_role) OR public.has_role(auth.uid(), 'praxistag'::public.app_role)));


--
-- Name: certificates Doctors manage own certificates; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Doctors manage own certificates" ON public.certificates TO authenticated USING ((auth.uid() = doctor_id)) WITH CHECK ((auth.uid() = doctor_id));


--
-- Name: doctor_recommendations Doctors manage own recommendations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Doctors manage own recommendations" ON public.doctor_recommendations TO authenticated USING ((auth.uid() = doctor_id)) WITH CHECK ((auth.uid() = doctor_id));


--
-- Name: medical_opinions Doctors manage their opinions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Doctors manage their opinions" ON public.medical_opinions USING ((auth.uid() = doctor_id));


--
-- Name: referrals Doctors see all referrals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Doctors see all referrals" ON public.referrals FOR SELECT USING ((public.has_role(auth.uid(), 'uzemorvos'::public.app_role) OR public.has_role(auth.uid(), 'haziorvos'::public.app_role)));


--
-- Name: documents Doctors see documents; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Doctors see documents" ON public.documents FOR SELECT TO authenticated USING ((public.has_role(auth.uid(), 'uzemorvos'::public.app_role) OR public.has_role(auth.uid(), 'haziorvos'::public.app_role)));


--
-- Name: patient_cards Doctors see patient cards; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Doctors see patient cards" ON public.patient_cards FOR SELECT USING ((public.has_role(auth.uid(), 'haziorvos'::public.app_role) OR public.has_role(auth.uid(), 'uzemorvos'::public.app_role)));


--
-- Name: appointments Doctors see their appointments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Doctors see their appointments" ON public.appointments FOR SELECT USING ((auth.uid() = doctor_id));


--
-- Name: appointments Doctors update their appointments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Doctors update their appointments" ON public.appointments FOR UPDATE USING ((auth.uid() = doctor_id));


--
-- Name: accident_reports Employee sees own accidents; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Employee sees own accidents" ON public.accident_reports FOR SELECT TO authenticated USING ((auth.uid() = employee_id));


--
-- Name: referrals Employee sees own referrals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Employee sees own referrals" ON public.referrals FOR SELECT USING ((auth.uid() = employee_id));


--
-- Name: questionnaire_assignments Haziorvos manages assignments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Haziorvos manages assignments" ON public.questionnaire_assignments TO authenticated USING (public.has_role(auth.uid(), 'haziorvos'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'haziorvos'::public.app_role));


--
-- Name: lab_requests Haziorvos manages lab requests; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Haziorvos manages lab requests" ON public.lab_requests TO authenticated USING (public.has_role(auth.uid(), 'haziorvos'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'haziorvos'::public.app_role));


--
-- Name: medication_requests Haziorvos manages med requests; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Haziorvos manages med requests" ON public.medication_requests TO authenticated USING (public.has_role(auth.uid(), 'haziorvos'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'haziorvos'::public.app_role));


--
-- Name: vaccinations Haziorvos manages vaccinations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Haziorvos manages vaccinations" ON public.vaccinations USING (public.has_role(auth.uid(), 'haziorvos'::public.app_role));


--
-- Name: appointments Haziorvos sees all appointments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Haziorvos sees all appointments" ON public.appointments FOR SELECT USING (public.has_role(auth.uid(), 'haziorvos'::public.app_role));


--
-- Name: requests Haziorvos sees all requests; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Haziorvos sees all requests" ON public.requests FOR SELECT USING (public.has_role(auth.uid(), 'haziorvos'::public.app_role));


--
-- Name: food_journal Haziorvos sees food journal; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Haziorvos sees food journal" ON public.food_journal FOR SELECT USING (public.has_role(auth.uid(), 'haziorvos'::public.app_role));


--
-- Name: health_reports Haziorvos sees health reports; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Haziorvos sees health reports" ON public.health_reports FOR SELECT USING (public.has_role(auth.uid(), 'haziorvos'::public.app_role));


--
-- Name: health_journal Haziorvos sees journal; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Haziorvos sees journal" ON public.health_journal FOR SELECT USING (public.has_role(auth.uid(), 'haziorvos'::public.app_role));


--
-- Name: profiles Haziorvos sees member profiles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Haziorvos sees member profiles" ON public.profiles FOR SELECT USING (public.has_role(auth.uid(), 'haziorvos'::public.app_role));


--
-- Name: stool_journal Haziorvos sees stool journal; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Haziorvos sees stool journal" ON public.stool_journal FOR SELECT USING (public.has_role(auth.uid(), 'haziorvos'::public.app_role));


--
-- Name: questionnaire_submissions Haziorvos sees submissions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Haziorvos sees submissions" ON public.questionnaire_submissions FOR SELECT USING (public.has_role(auth.uid(), 'haziorvos'::public.app_role));


--
-- Name: requests Haziorvos updates requests; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Haziorvos updates requests" ON public.requests FOR UPDATE USING (public.has_role(auth.uid(), 'haziorvos'::public.app_role));


--
-- Name: locations Locations readable by authenticated; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Locations readable by authenticated" ON public.locations FOR SELECT TO authenticated USING (true);


--
-- Name: medications Medications readable by authenticated; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Medications readable by authenticated" ON public.medications FOR SELECT TO authenticated USING (true);


--
-- Name: work_area_sds_documents Members view SDS documents; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Members view SDS documents" ON public.work_area_sds_documents FOR SELECT TO authenticated USING (((uploaded_by = auth.uid()) OR public.has_role(auth.uid(), 'super_admin'::public.app_role) OR public.has_role(auth.uid(), 'uzemorvos'::public.app_role) OR (EXISTS ( SELECT 1
   FROM ((public.work_areas wa
     JOIN public.company_sites cs ON ((cs.id = wa.site_id)))
     JOIN public.user_company_relations ucr ON ((ucr.company_id = cs.company_id)))
  WHERE ((wa.id = work_area_sds_documents.work_area_id) AND (ucr.user_id = auth.uid()) AND (ucr.is_active = true))))));


--
-- Name: user_company_relations Munkaltato inserts employees; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Munkaltato inserts employees" ON public.user_company_relations FOR INSERT WITH CHECK ((public.has_role(auth.uid(), 'munkaltato'::public.app_role) OR public.has_role(auth.uid(), 'super_admin'::public.app_role)));


--
-- Name: risk_assessment_photos Munkaltato inserts photos; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Munkaltato inserts photos" ON public.risk_assessment_photos FOR INSERT TO authenticated WITH CHECK ((EXISTS ( SELECT 1
   FROM (public.risk_assessments ra
     JOIN public.user_company_relations ucr ON ((ucr.company_id = ra.company_id)))
  WHERE ((ra.id = risk_assessment_photos.risk_assessment_id) AND (ucr.user_id = auth.uid()) AND (ucr.role = 'munkaltato'::public.app_role) AND (ucr.is_active = true)))));


--
-- Name: referrals Munkaltato inserts referrals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Munkaltato inserts referrals" ON public.referrals FOR INSERT WITH CHECK (((auth.uid() = created_by) AND public.has_role(auth.uid(), 'munkaltato'::public.app_role)));


--
-- Name: accident_reports Munkaltato manages own company accidents; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Munkaltato manages own company accidents" ON public.accident_reports TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.user_company_relations
  WHERE ((user_company_relations.user_id = auth.uid()) AND (user_company_relations.company_id = accident_reports.company_id) AND (user_company_relations.role = 'munkaltato'::public.app_role) AND (user_company_relations.is_active = true))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM public.user_company_relations
  WHERE ((user_company_relations.user_id = auth.uid()) AND (user_company_relations.company_id = accident_reports.company_id) AND (user_company_relations.role = 'munkaltato'::public.app_role) AND (user_company_relations.is_active = true)))));


--
-- Name: company_sites Munkaltato manages own company sites; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Munkaltato manages own company sites" ON public.company_sites TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.user_company_relations
  WHERE ((user_company_relations.user_id = auth.uid()) AND (user_company_relations.company_id = company_sites.company_id) AND (user_company_relations.role = 'munkaltato'::public.app_role) AND (user_company_relations.is_active = true))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM public.user_company_relations
  WHERE ((user_company_relations.user_id = auth.uid()) AND (user_company_relations.company_id = company_sites.company_id) AND (user_company_relations.role = 'munkaltato'::public.app_role) AND (user_company_relations.is_active = true)))));


--
-- Name: company_hazardous_substances Munkaltato manages own company substances; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Munkaltato manages own company substances" ON public.company_hazardous_substances TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.user_company_relations
  WHERE ((user_company_relations.user_id = auth.uid()) AND (user_company_relations.company_id = company_hazardous_substances.company_id) AND (user_company_relations.role = 'munkaltato'::public.app_role) AND (user_company_relations.is_active = true))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM public.user_company_relations
  WHERE ((user_company_relations.user_id = auth.uid()) AND (user_company_relations.company_id = company_hazardous_substances.company_id) AND (user_company_relations.role = 'munkaltato'::public.app_role) AND (user_company_relations.is_active = true)))));


--
-- Name: company_teaor_codes Munkaltato manages own company teaor codes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Munkaltato manages own company teaor codes" ON public.company_teaor_codes TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.user_company_relations
  WHERE ((user_company_relations.user_id = auth.uid()) AND (user_company_relations.company_id = company_teaor_codes.company_id) AND (user_company_relations.role = 'munkaltato'::public.app_role) AND (user_company_relations.is_active = true))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM public.user_company_relations
  WHERE ((user_company_relations.user_id = auth.uid()) AND (user_company_relations.company_id = company_teaor_codes.company_id) AND (user_company_relations.role = 'munkaltato'::public.app_role) AND (user_company_relations.is_active = true)))));


--
-- Name: work_areas Munkaltato manages work_areas; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Munkaltato manages work_areas" ON public.work_areas TO authenticated USING ((EXISTS ( SELECT 1
   FROM (public.company_sites cs
     JOIN public.user_company_relations ucr ON ((ucr.company_id = cs.company_id)))
  WHERE ((cs.id = work_areas.site_id) AND (ucr.user_id = auth.uid()) AND (ucr.role = 'munkaltato'::public.app_role) AND (ucr.is_active = true))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM (public.company_sites cs
     JOIN public.user_company_relations ucr ON ((ucr.company_id = cs.company_id)))
  WHERE ((cs.id = work_areas.site_id) AND (ucr.user_id = auth.uid()) AND (ucr.role = 'munkaltato'::public.app_role) AND (ucr.is_active = true)))));


--
-- Name: workplaces Munkaltato manages workplaces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Munkaltato manages workplaces" ON public.workplaces TO authenticated USING ((EXISTS ( SELECT 1
   FROM ((public.work_areas wa
     JOIN public.company_sites cs ON ((cs.id = wa.site_id)))
     JOIN public.user_company_relations ucr ON ((ucr.company_id = cs.company_id)))
  WHERE ((wa.id = workplaces.work_area_id) AND (ucr.user_id = auth.uid()) AND (ucr.role = 'munkaltato'::public.app_role) AND (ucr.is_active = true))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM ((public.work_areas wa
     JOIN public.company_sites cs ON ((cs.id = wa.site_id)))
     JOIN public.user_company_relations ucr ON ((ucr.company_id = cs.company_id)))
  WHERE ((wa.id = workplaces.work_area_id) AND (ucr.user_id = auth.uid()) AND (ucr.role = 'munkaltato'::public.app_role) AND (ucr.is_active = true)))));


--
-- Name: noise_vibration_measurements Munkaltato reads company measurements; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Munkaltato reads company measurements" ON public.noise_vibration_measurements FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM (public.risk_assessments ra
     JOIN public.user_company_relations ucr ON ((ucr.company_id = ra.company_id)))
  WHERE ((ra.id = noise_vibration_measurements.risk_assessment_id) AND (ucr.user_id = auth.uid()) AND (ucr.role = 'munkaltato'::public.app_role) AND (ucr.is_active = true)))));


--
-- Name: examinations Munkaltato sees company employee exams; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Munkaltato sees company employee exams" ON public.examinations FOR SELECT USING (public.is_employer_of_patient(auth.uid(), patient_id));


--
-- Name: medical_opinions Munkaltato sees company opinions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Munkaltato sees company opinions" ON public.medical_opinions FOR SELECT USING (public.is_company_member(auth.uid(), company_id, 'munkaltato'::public.app_role));


--
-- Name: certificates Munkaltato sees employee certificates; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Munkaltato sees employee certificates" ON public.certificates FOR SELECT TO authenticated USING (public.is_employer_of_patient(auth.uid(), patient_id));


--
-- Name: documents Munkaltato sees employee docs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Munkaltato sees employee docs" ON public.documents FOR SELECT TO authenticated USING (public.is_employer_of_patient(auth.uid(), user_id));


--
-- Name: lab_requests Munkaltato sees employee lab requests; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Munkaltato sees employee lab requests" ON public.lab_requests FOR SELECT TO authenticated USING (public.is_employer_of_patient(auth.uid(), patient_id));


--
-- Name: profiles Munkaltato sees employee profiles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Munkaltato sees employee profiles" ON public.profiles FOR SELECT TO authenticated USING (public.is_employer_of_patient(auth.uid(), user_id));


--
-- Name: risk_assessments Munkaltato sees own company assessments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Munkaltato sees own company assessments" ON public.risk_assessments FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.user_company_relations
  WHERE ((user_company_relations.user_id = auth.uid()) AND (user_company_relations.company_id = risk_assessments.company_id) AND (user_company_relations.role = 'munkaltato'::public.app_role) AND (user_company_relations.is_active = true)))));


--
-- Name: referrals Munkaltato sees own company referrals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Munkaltato sees own company referrals" ON public.referrals FOR SELECT USING (public.is_company_member(auth.uid(), company_id, 'munkaltato'::public.app_role));


--
-- Name: company_sites Munkaltato sees own company sites; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Munkaltato sees own company sites" ON public.company_sites FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.user_company_relations
  WHERE ((user_company_relations.user_id = auth.uid()) AND (user_company_relations.company_id = company_sites.company_id) AND (user_company_relations.is_active = true)))));


--
-- Name: user_company_relations Munkaltato sees their company members; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Munkaltato sees their company members" ON public.user_company_relations FOR SELECT USING (public.is_company_member(auth.uid(), company_id, 'munkaltato'::public.app_role));


--
-- Name: user_company_relations Munkaltato updates employee position and risks; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Munkaltato updates employee position and risks" ON public.user_company_relations FOR UPDATE TO authenticated USING (public.is_company_member(auth.uid(), company_id, 'munkaltato'::public.app_role)) WITH CHECK (public.is_company_member(auth.uid(), company_id, 'munkaltato'::public.app_role));


--
-- Name: profiles Munkaltato updates employee profiles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Munkaltato updates employee profiles" ON public.profiles FOR UPDATE TO authenticated USING ((EXISTS ( SELECT 1
   FROM (public.user_company_relations emp
     JOIN public.user_company_relations pat ON ((pat.company_id = emp.company_id)))
  WHERE ((emp.user_id = auth.uid()) AND (emp.role = 'munkaltato'::public.app_role) AND (emp.is_active = true) AND (pat.user_id = profiles.user_id) AND (pat.is_active = true))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM (public.user_company_relations emp
     JOIN public.user_company_relations pat ON ((pat.company_id = emp.company_id)))
  WHERE ((emp.user_id = auth.uid()) AND (emp.role = 'munkaltato'::public.app_role) AND (emp.is_active = true) AND (pat.user_id = profiles.user_id) AND (pat.is_active = true)))));


--
-- Name: companies Munkaltato updates own companies; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Munkaltato updates own companies" ON public.companies FOR UPDATE TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.user_company_relations
  WHERE ((user_company_relations.user_id = auth.uid()) AND (user_company_relations.company_id = companies.id) AND (user_company_relations.role = 'munkaltato'::public.app_role) AND (user_company_relations.is_active = true))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM public.user_company_relations
  WHERE ((user_company_relations.user_id = auth.uid()) AND (user_company_relations.company_id = companies.id) AND (user_company_relations.role = 'munkaltato'::public.app_role) AND (user_company_relations.is_active = true)))));


--
-- Name: referrals Munkaltato updates own company referrals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Munkaltato updates own company referrals" ON public.referrals FOR UPDATE USING (public.is_company_member(auth.uid(), company_id, 'munkaltato'::public.app_role));


--
-- Name: risk_assessments Munkavallalo sees own work area assessments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Munkavallalo sees own work area assessments" ON public.risk_assessments FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.user_company_relations
  WHERE ((user_company_relations.user_id = auth.uid()) AND (user_company_relations.company_id = risk_assessments.company_id) AND (user_company_relations.work_area_id = risk_assessments.work_area_id) AND (user_company_relations.is_active = true)))));


--
-- Name: navigation_links Nav links readable by everyone; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Nav links readable by everyone" ON public.navigation_links FOR SELECT USING (true);


--
-- Name: pages_content Pages content readable by everyone; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Pages content readable by everyone" ON public.pages_content FOR SELECT USING (true);


--
-- Name: medication_requests Patient manages own med requests; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patient manages own med requests" ON public.medication_requests TO authenticated USING ((auth.uid() = patient_id)) WITH CHECK ((auth.uid() = patient_id));


--
-- Name: examinations Patient sees own examinations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patient sees own examinations" ON public.examinations FOR SELECT USING ((auth.uid() = patient_id));


--
-- Name: appointments Patients insert own appointments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients insert own appointments" ON public.appointments FOR INSERT WITH CHECK ((auth.uid() = patient_id));


--
-- Name: appointments Patients see own appointments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients see own appointments" ON public.appointments FOR SELECT USING ((auth.uid() = patient_id));


--
-- Name: questionnaire_assignments Patients see own assignments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients see own assignments" ON public.questionnaire_assignments FOR SELECT TO authenticated USING ((auth.uid() = patient_id));


--
-- Name: certificates Patients see own certificates; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients see own certificates" ON public.certificates FOR SELECT TO authenticated USING ((auth.uid() = patient_id));


--
-- Name: lab_requests Patients see own lab requests; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients see own lab requests" ON public.lab_requests FOR SELECT TO authenticated USING ((auth.uid() = patient_id));


--
-- Name: medical_opinions Patients see own opinions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients see own opinions" ON public.medical_opinions FOR SELECT USING ((auth.uid() = patient_id));


--
-- Name: doctor_recommendations Patients see own recommendations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients see own recommendations" ON public.doctor_recommendations FOR SELECT TO authenticated USING ((auth.uid() = patient_id));


--
-- Name: appointments Patients update own appointments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients update own appointments" ON public.appointments FOR UPDATE USING ((auth.uid() = patient_id));


--
-- Name: questionnaire_assignments Patients update own assignments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients update own assignments" ON public.questionnaire_assignments FOR UPDATE TO authenticated USING ((auth.uid() = patient_id)) WITH CHECK ((auth.uid() = patient_id));


--
-- Name: doctor_recommendations Patients update own recommendations read status; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients update own recommendations read status" ON public.doctor_recommendations FOR UPDATE TO authenticated USING ((auth.uid() = patient_id)) WITH CHECK ((auth.uid() = patient_id));


--
-- Name: profiles Praxistag sees profiles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Praxistag sees profiles" ON public.profiles FOR SELECT USING (public.has_role(auth.uid(), 'praxistag'::public.app_role));


--
-- Name: questionnaires Questionnaires readable by authenticated; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Questionnaires readable by authenticated" ON public.questionnaires FOR SELECT TO authenticated USING (true);


--
-- Name: messages Recipients update messages; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Recipients update messages" ON public.messages FOR UPDATE TO authenticated USING ((auth.uid() = recipient_id)) WITH CHECK ((auth.uid() = recipient_id));


--
-- Name: seo_pages SEO pages readable by everyone; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "SEO pages readable by everyone" ON public.seo_pages FOR SELECT USING (true);


--
-- Name: service_categories Service categories readable by everyone; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service categories readable by everyone" ON public.service_categories FOR SELECT USING (true);


--
-- Name: email_send_log Service role can insert send log; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can insert send log" ON public.email_send_log FOR INSERT WITH CHECK ((auth.role() = 'service_role'::text));


--
-- Name: suppressed_emails Service role can insert suppressed emails; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can insert suppressed emails" ON public.suppressed_emails FOR INSERT WITH CHECK ((auth.role() = 'service_role'::text));


--
-- Name: email_unsubscribe_tokens Service role can insert tokens; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can insert tokens" ON public.email_unsubscribe_tokens FOR INSERT WITH CHECK ((auth.role() = 'service_role'::text));


--
-- Name: email_send_state Service role can manage send state; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage send state" ON public.email_send_state USING ((auth.role() = 'service_role'::text)) WITH CHECK ((auth.role() = 'service_role'::text));


--
-- Name: email_unsubscribe_tokens Service role can mark tokens as used; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can mark tokens as used" ON public.email_unsubscribe_tokens FOR UPDATE USING ((auth.role() = 'service_role'::text)) WITH CHECK ((auth.role() = 'service_role'::text));


--
-- Name: email_send_log Service role can read send log; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can read send log" ON public.email_send_log FOR SELECT USING ((auth.role() = 'service_role'::text));


--
-- Name: suppressed_emails Service role can read suppressed emails; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can read suppressed emails" ON public.suppressed_emails FOR SELECT USING ((auth.role() = 'service_role'::text));


--
-- Name: email_unsubscribe_tokens Service role can read tokens; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can read tokens" ON public.email_unsubscribe_tokens FOR SELECT USING ((auth.role() = 'service_role'::text));


--
-- Name: email_send_log Service role can update send log; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can update send log" ON public.email_send_log FOR UPDATE USING ((auth.role() = 'service_role'::text)) WITH CHECK ((auth.role() = 'service_role'::text));


--
-- Name: services Services readable by everyone; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Services readable by everyone" ON public.services FOR SELECT USING (true);


--
-- Name: site_settings Site settings readable by everyone; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Site settings readable by everyone" ON public.site_settings FOR SELECT USING (true);


--
-- Name: appointment_slots Slots readable by authenticated; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Slots readable by authenticated" ON public.appointment_slots FOR SELECT TO authenticated USING (true);


--
-- Name: medication_requests Super admin manages med requests; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admin manages med requests" ON public.medication_requests TO authenticated USING (public.has_role(auth.uid(), 'super_admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: icd_codes Super admins can manage ICD codes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins can manage ICD codes" ON public.icd_codes TO authenticated USING (public.has_role(auth.uid(), 'super_admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: work_area_sds_documents Super admins can manage SDS documents; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins can manage SDS documents" ON public.work_area_sds_documents TO authenticated USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: lab_packages Super admins can manage packages; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins can manage packages" ON public.lab_packages TO authenticated USING (public.has_role(auth.uid(), 'super_admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: security_events Super admins can view security events; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins can view security events" ON public.security_events FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: accident_reports Super admins manage accidents; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage accidents" ON public.accident_reports TO authenticated USING (public.has_role(auth.uid(), 'super_admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: activities Super admins manage activities; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage activities" ON public.activities USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: medical_opinions Super admins manage all opinions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage all opinions" ON public.medical_opinions USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: requests Super admins manage all requests; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage all requests" ON public.requests USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: user_roles Super admins manage all roles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage all roles" ON public.user_roles USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: appointments Super admins manage appointments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage appointments" ON public.appointments USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: questionnaire_assignments Super admins manage assignments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage assignments" ON public.questionnaire_assignments TO authenticated USING (public.has_role(auth.uid(), 'super_admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: certificates Super admins manage certificates; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage certificates" ON public.certificates TO authenticated USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: companies Super admins manage companies; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage companies" ON public.companies USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: user_company_relations Super admins manage company relations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage company relations" ON public.user_company_relations USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: company_hazardous_substances Super admins manage company substances; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage company substances" ON public.company_hazardous_substances TO authenticated USING (public.has_role(auth.uid(), 'super_admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: company_sites Super admins manage company_sites; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage company_sites" ON public.company_sites TO authenticated USING (public.has_role(auth.uid(), 'super_admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: document_templates Super admins manage document templates; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage document templates" ON public.document_templates TO authenticated USING (public.has_role(auth.uid(), 'super_admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: documents Super admins manage documents; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage documents" ON public.documents USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: examinations Super admins manage examinations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage examinations" ON public.examinations USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: food_journal Super admins manage food journal; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage food journal" ON public.food_journal USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: risk_assessment_hazards Super admins manage hazards; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage hazards" ON public.risk_assessment_hazards TO authenticated USING (public.has_role(auth.uid(), 'super_admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: health_journal Super admins manage journal; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage journal" ON public.health_journal USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: lab_requests Super admins manage lab requests; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage lab requests" ON public.lab_requests TO authenticated USING (public.has_role(auth.uid(), 'super_admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: locations Super admins manage locations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage locations" ON public.locations USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: noise_vibration_measurements Super admins manage measurements; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage measurements" ON public.noise_vibration_measurements TO authenticated USING (public.has_role(auth.uid(), 'super_admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: messages Super admins manage messages; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage messages" ON public.messages USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: navigation_links Super admins manage nav links; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage nav links" ON public.navigation_links USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: pages_content Super admins manage pages content; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage pages content" ON public.pages_content USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: patient_cards Super admins manage patient_cards; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage patient_cards" ON public.patient_cards USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: risk_assessment_photos Super admins manage photos; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage photos" ON public.risk_assessment_photos TO authenticated USING (public.has_role(auth.uid(), 'super_admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: questionnaires Super admins manage questionnaires; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage questionnaires" ON public.questionnaires USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: doctor_recommendations Super admins manage recommendations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage recommendations" ON public.doctor_recommendations TO authenticated USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: referrals Super admins manage referrals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage referrals" ON public.referrals USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: risk_assessments Super admins manage risk_assessments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage risk_assessments" ON public.risk_assessments TO authenticated USING (public.has_role(auth.uid(), 'super_admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: seo_pages Super admins manage seo pages; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage seo pages" ON public.seo_pages USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: service_categories Super admins manage service categories; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage service categories" ON public.service_categories USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: services Super admins manage services; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage services" ON public.services USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: site_settings Super admins manage site settings; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage site settings" ON public.site_settings USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: appointment_slots Super admins manage slots; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage slots" ON public.appointment_slots USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: stool_journal Super admins manage stool journal; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage stool journal" ON public.stool_journal USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: questionnaire_submissions Super admins manage submissions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage submissions" ON public.questionnaire_submissions USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: hazardous_substances Super admins manage substances; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage substances" ON public.hazardous_substances TO authenticated USING (public.has_role(auth.uid(), 'super_admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: document_tags Super admins manage tags; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage tags" ON public.document_tags USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: company_teaor_codes Super admins manage teaor codes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage teaor codes" ON public.company_teaor_codes TO authenticated USING (public.has_role(auth.uid(), 'super_admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: vaccinations Super admins manage vaccinations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage vaccinations" ON public.vaccinations USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: work_areas Super admins manage work_areas; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage work_areas" ON public.work_areas TO authenticated USING (public.has_role(auth.uid(), 'super_admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: workplaces Super admins manage workplaces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins manage workplaces" ON public.workplaces TO authenticated USING (public.has_role(auth.uid(), 'super_admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: health_reports Super admins see all health reports; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins see all health reports" ON public.health_reports FOR SELECT USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: profiles Super admins see all profiles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins see all profiles" ON public.profiles FOR SELECT USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: audit_logs Super admins see audit logs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins see audit logs" ON public.audit_logs FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: notification_preferences Super admins see preferences; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Super admins see preferences" ON public.notification_preferences FOR SELECT USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));


--
-- Name: document_tags Tags readable by authenticated; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Tags readable by authenticated" ON public.document_tags FOR SELECT TO authenticated USING (true);


--
-- Name: patient_cards User manages own patient card; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "User manages own patient card" ON public.patient_cards USING ((auth.uid() = user_id));


--
-- Name: gdpr_requests Users can create own gdpr_requests; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can create own gdpr_requests" ON public.gdpr_requests FOR INSERT TO authenticated WITH CHECK ((user_id = auth.uid()));


--
-- Name: work_area_sds_documents Users can delete their own SDS documents; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can delete their own SDS documents" ON public.work_area_sds_documents FOR DELETE TO authenticated USING ((auth.uid() = uploaded_by));


--
-- Name: health_plans Users can insert own health plans; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can insert own health plans" ON public.health_plans FOR INSERT TO authenticated WITH CHECK ((user_id = auth.uid()));


--
-- Name: noise_vibration_measurements Users can read own measurements; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can read own measurements" ON public.noise_vibration_measurements FOR SELECT TO authenticated USING ((auth.uid() = measured_by));


--
-- Name: work_area_sds_documents Users can update their own SDS documents; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can update their own SDS documents" ON public.work_area_sds_documents FOR UPDATE TO authenticated USING ((auth.uid() = uploaded_by));


--
-- Name: gdpr_requests Users can view own gdpr_requests; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view own gdpr_requests" ON public.gdpr_requests FOR SELECT TO authenticated USING (((user_id = auth.uid()) OR public.has_role(auth.uid(), 'super_admin'::public.app_role)));


--
-- Name: health_plans Users can view own health plans; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view own health plans" ON public.health_plans FOR SELECT TO authenticated USING ((user_id = auth.uid()));


--
-- Name: bulk_import_logs Users insert own import logs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users insert own import logs" ON public.bulk_import_logs FOR INSERT TO authenticated WITH CHECK ((auth.uid() = user_id));


--
-- Name: notifications Users insert own notifications; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users insert own notifications" ON public.notifications FOR INSERT TO authenticated WITH CHECK ((auth.uid() = user_id));


--
-- Name: profiles Users insert own profile; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users insert own profile" ON public.profiles FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: requests Users insert own requests; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users insert own requests" ON public.requests FOR INSERT WITH CHECK ((auth.uid() = requester_id));


--
-- Name: questionnaire_submissions Users insert own submissions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users insert own submissions" ON public.questionnaire_submissions FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: food_journal Users manage own food journal; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users manage own food journal" ON public.food_journal USING ((auth.uid() = user_id)) WITH CHECK ((auth.uid() = user_id));


--
-- Name: health_reports Users manage own health reports; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users manage own health reports" ON public.health_reports USING ((auth.uid() = user_id));


--
-- Name: health_journal Users manage own journal; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users manage own journal" ON public.health_journal USING ((auth.uid() = user_id)) WITH CHECK ((auth.uid() = user_id));


--
-- Name: notification_preferences Users manage own preferences; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users manage own preferences" ON public.notification_preferences USING ((auth.uid() = user_id)) WITH CHECK ((auth.uid() = user_id));


--
-- Name: stool_journal Users manage own stool journal; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users manage own stool journal" ON public.stool_journal USING ((auth.uid() = user_id)) WITH CHECK ((auth.uid() = user_id));


--
-- Name: vaccinations Users manage own vaccinations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users manage own vaccinations" ON public.vaccinations USING ((auth.uid() = user_id)) WITH CHECK ((auth.uid() = user_id));


--
-- Name: bulk_import_logs Users read own import logs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users read own import logs" ON public.bulk_import_logs FOR SELECT TO authenticated USING (((auth.uid() = user_id) OR public.has_role(auth.uid(), 'super_admin'::public.app_role)));


--
-- Name: audit_logs Users see own audit logs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users see own audit logs" ON public.audit_logs FOR SELECT TO authenticated USING ((((new_data ->> 'patient_id'::text) = (auth.uid())::text) OR ((new_data ->> 'user_id'::text) = (auth.uid())::text) OR ((old_data ->> 'patient_id'::text) = (auth.uid())::text) OR ((old_data ->> 'user_id'::text) = (auth.uid())::text)));


--
-- Name: user_company_relations Users see own company relations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users see own company relations" ON public.user_company_relations FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: documents Users see own documents; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users see own documents" ON public.documents FOR SELECT TO authenticated USING ((auth.uid() = user_id));


--
-- Name: lab_orders Users see own lab orders; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users see own lab orders" ON public.lab_orders FOR SELECT TO authenticated USING ((auth.uid() = user_id));


--
-- Name: messages Users see own messages; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users see own messages" ON public.messages FOR SELECT USING (((auth.uid() = sender_id) OR (auth.uid() = recipient_id) OR ((group_role IS NOT NULL) AND public.has_role(auth.uid(), group_role))));


--
-- Name: notifications Users see own notifications; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users see own notifications" ON public.notifications FOR SELECT TO authenticated USING ((auth.uid() = user_id));


--
-- Name: profiles Users see own profile; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users see own profile" ON public.profiles FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: requests Users see own requests; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users see own requests" ON public.requests FOR SELECT USING (((auth.uid() = requester_id) OR (auth.uid() = assignee_id)));


--
-- Name: user_roles Users see own roles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users see own roles" ON public.user_roles FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: questionnaire_submissions Users see own submissions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users see own submissions" ON public.questionnaire_submissions FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: messages Users send messages; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users send messages" ON public.messages FOR INSERT WITH CHECK ((auth.uid() = sender_id));


--
-- Name: notifications Users update own notifications; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users update own notifications" ON public.notifications FOR UPDATE TO authenticated USING ((auth.uid() = user_id));


--
-- Name: profiles Users update own profile; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users update own profile" ON public.profiles FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: documents Users upload own documents; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users upload own documents" ON public.documents FOR INSERT TO authenticated WITH CHECK ((auth.uid() = user_id));


--
-- Name: accident_reports Uzemorvos manages accidents; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Uzemorvos manages accidents" ON public.accident_reports TO authenticated USING (public.has_role(auth.uid(), 'uzemorvos'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'uzemorvos'::public.app_role));


--
-- Name: questionnaire_assignments Uzemorvos manages assignments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Uzemorvos manages assignments" ON public.questionnaire_assignments TO authenticated USING (public.has_role(auth.uid(), 'uzemorvos'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'uzemorvos'::public.app_role));


--
-- Name: companies Uzemorvos manages companies; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Uzemorvos manages companies" ON public.companies TO authenticated USING (public.has_role(auth.uid(), 'uzemorvos'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'uzemorvos'::public.app_role));


--
-- Name: company_hazardous_substances Uzemorvos manages company substances; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Uzemorvos manages company substances" ON public.company_hazardous_substances TO authenticated USING (public.has_role(auth.uid(), 'uzemorvos'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'uzemorvos'::public.app_role));


--
-- Name: company_sites Uzemorvos manages company_sites; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Uzemorvos manages company_sites" ON public.company_sites TO authenticated USING (public.has_role(auth.uid(), 'uzemorvos'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'uzemorvos'::public.app_role));


--
-- Name: risk_assessment_hazards Uzemorvos manages hazards; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Uzemorvos manages hazards" ON public.risk_assessment_hazards TO authenticated USING (public.has_role(auth.uid(), 'uzemorvos'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'uzemorvos'::public.app_role));


--
-- Name: lab_orders Uzemorvos manages lab orders; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Uzemorvos manages lab orders" ON public.lab_orders TO authenticated USING (public.has_role(auth.uid(), 'uzemorvos'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'uzemorvos'::public.app_role));


--
-- Name: lab_pricing_config Uzemorvos manages lab pricing; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Uzemorvos manages lab pricing" ON public.lab_pricing_config TO authenticated USING (public.has_role(auth.uid(), 'uzemorvos'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'uzemorvos'::public.app_role));


--
-- Name: lab_requests Uzemorvos manages lab requests; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Uzemorvos manages lab requests" ON public.lab_requests TO authenticated USING (public.has_role(auth.uid(), 'uzemorvos'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'uzemorvos'::public.app_role));


--
-- Name: noise_vibration_measurements Uzemorvos manages measurements; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Uzemorvos manages measurements" ON public.noise_vibration_measurements TO authenticated USING (public.has_role(auth.uid(), 'uzemorvos'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'uzemorvos'::public.app_role));


--
-- Name: risk_assessment_photos Uzemorvos manages photos; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Uzemorvos manages photos" ON public.risk_assessment_photos TO authenticated USING (public.has_role(auth.uid(), 'uzemorvos'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'uzemorvos'::public.app_role));


--
-- Name: risk_assessments Uzemorvos manages risk_assessments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Uzemorvos manages risk_assessments" ON public.risk_assessments TO authenticated USING (public.has_role(auth.uid(), 'uzemorvos'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'uzemorvos'::public.app_role));


--
-- Name: appointment_slots Uzemorvos manages slots; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Uzemorvos manages slots" ON public.appointment_slots USING (public.has_role(auth.uid(), 'uzemorvos'::public.app_role));


--
-- Name: hazardous_substances Uzemorvos manages substances; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Uzemorvos manages substances" ON public.hazardous_substances TO authenticated USING (public.has_role(auth.uid(), 'uzemorvos'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'uzemorvos'::public.app_role));


--
-- Name: company_teaor_codes Uzemorvos manages teaor codes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Uzemorvos manages teaor codes" ON public.company_teaor_codes TO authenticated USING (public.has_role(auth.uid(), 'uzemorvos'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'uzemorvos'::public.app_role));


--
-- Name: vaccinations Uzemorvos manages vaccinations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Uzemorvos manages vaccinations" ON public.vaccinations USING (public.has_role(auth.uid(), 'uzemorvos'::public.app_role));


--
-- Name: work_areas Uzemorvos manages work_areas; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Uzemorvos manages work_areas" ON public.work_areas TO authenticated USING (public.has_role(auth.uid(), 'uzemorvos'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'uzemorvos'::public.app_role));


--
-- Name: workplaces Uzemorvos manages workplaces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Uzemorvos manages workplaces" ON public.workplaces TO authenticated USING (public.has_role(auth.uid(), 'uzemorvos'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'uzemorvos'::public.app_role));


--
-- Name: appointments Uzemorvos sees all appointments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Uzemorvos sees all appointments" ON public.appointments FOR SELECT USING (public.has_role(auth.uid(), 'uzemorvos'::public.app_role));


--
-- Name: questionnaire_submissions Uzemorvos sees all submissions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Uzemorvos sees all submissions" ON public.questionnaire_submissions FOR SELECT USING (public.has_role(auth.uid(), 'uzemorvos'::public.app_role));


--
-- Name: user_company_relations Uzemorvos sees company relations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Uzemorvos sees company relations" ON public.user_company_relations FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'uzemorvos'::public.app_role));


--
-- Name: profiles Uzemorvos sees employee profiles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Uzemorvos sees employee profiles" ON public.profiles FOR SELECT USING (public.has_role(auth.uid(), 'uzemorvos'::public.app_role));


--
-- Name: food_journal Uzemorvos sees food journal; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Uzemorvos sees food journal" ON public.food_journal FOR SELECT USING (public.has_role(auth.uid(), 'uzemorvos'::public.app_role));


--
-- Name: health_journal Uzemorvos sees journal; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Uzemorvos sees journal" ON public.health_journal FOR SELECT USING (public.has_role(auth.uid(), 'uzemorvos'::public.app_role));


--
-- Name: stool_journal Uzemorvos sees stool journal; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Uzemorvos sees stool journal" ON public.stool_journal FOR SELECT USING (public.has_role(auth.uid(), 'uzemorvos'::public.app_role));


--
-- Name: user_company_relations Uzemorvos updates company relations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Uzemorvos updates company relations" ON public.user_company_relations FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'uzemorvos'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'uzemorvos'::public.app_role));


--
-- Name: accident_reports; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.accident_reports ENABLE ROW LEVEL SECURITY;

--
-- Name: activities; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.activities ENABLE ROW LEVEL SECURITY;

--
-- Name: appointment_slots; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.appointment_slots ENABLE ROW LEVEL SECURITY;

--
-- Name: appointments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_logs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: bulk_import_logs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.bulk_import_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: certificates; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.certificates ENABLE ROW LEVEL SECURITY;

--
-- Name: companies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.companies ENABLE ROW LEVEL SECURITY;

--
-- Name: company_hazardous_substances; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.company_hazardous_substances ENABLE ROW LEVEL SECURITY;

--
-- Name: company_sites; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.company_sites ENABLE ROW LEVEL SECURITY;

--
-- Name: company_teaor_codes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.company_teaor_codes ENABLE ROW LEVEL SECURITY;

--
-- Name: competitor_analyses; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.competitor_analyses ENABLE ROW LEVEL SECURITY;

--
-- Name: competitor_urls; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.competitor_urls ENABLE ROW LEVEL SECURITY;

--
-- Name: content_translations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.content_translations ENABLE ROW LEVEL SECURITY;

--
-- Name: doctor_recommendations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.doctor_recommendations ENABLE ROW LEVEL SECURITY;

--
-- Name: document_tags; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.document_tags ENABLE ROW LEVEL SECURITY;

--
-- Name: document_templates; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.document_templates ENABLE ROW LEVEL SECURITY;

--
-- Name: documents; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.documents ENABLE ROW LEVEL SECURITY;

--
-- Name: email_send_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.email_send_log ENABLE ROW LEVEL SECURITY;

--
-- Name: email_send_state; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.email_send_state ENABLE ROW LEVEL SECURITY;

--
-- Name: email_unsubscribe_tokens; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.email_unsubscribe_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: examinations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.examinations ENABLE ROW LEVEL SECURITY;

--
-- Name: food_journal; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.food_journal ENABLE ROW LEVEL SECURITY;

--
-- Name: gdpr_requests; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.gdpr_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: hazardous_substances; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.hazardous_substances ENABLE ROW LEVEL SECURITY;

--
-- Name: health_journal; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.health_journal ENABLE ROW LEVEL SECURITY;

--
-- Name: health_plans; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.health_plans ENABLE ROW LEVEL SECURITY;

--
-- Name: health_reports; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.health_reports ENABLE ROW LEVEL SECURITY;

--
-- Name: i18n_overrides; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.i18n_overrides ENABLE ROW LEVEL SECURITY;

--
-- Name: icd_codes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.icd_codes ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_markup_config; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.lab_markup_config ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_orders; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.lab_orders ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_packages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.lab_packages ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_pricing_config; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.lab_pricing_config ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_requests; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.lab_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: locations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.locations ENABLE ROW LEVEL SECURITY;

--
-- Name: medical_opinions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.medical_opinions ENABLE ROW LEVEL SECURITY;

--
-- Name: medication_requests; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.medication_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: medications; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.medications ENABLE ROW LEVEL SECURITY;

--
-- Name: messages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;

--
-- Name: navigation_links; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.navigation_links ENABLE ROW LEVEL SECURITY;

--
-- Name: noise_vibration_measurements; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.noise_vibration_measurements ENABLE ROW LEVEL SECURITY;

--
-- Name: notification_preferences; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.notification_preferences ENABLE ROW LEVEL SECURITY;

--
-- Name: notifications; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

--
-- Name: page_views; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.page_views ENABLE ROW LEVEL SECURITY;

--
-- Name: pages_content; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.pages_content ENABLE ROW LEVEL SECURITY;

--
-- Name: patient_cards; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.patient_cards ENABLE ROW LEVEL SECURITY;

--
-- Name: profiles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

--
-- Name: questionnaire_assignments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.questionnaire_assignments ENABLE ROW LEVEL SECURITY;

--
-- Name: questionnaire_submissions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.questionnaire_submissions ENABLE ROW LEVEL SECURITY;

--
-- Name: questionnaires; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.questionnaires ENABLE ROW LEVEL SECURITY;

--
-- Name: referrals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.referrals ENABLE ROW LEVEL SECURITY;

--
-- Name: requests; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.requests ENABLE ROW LEVEL SECURITY;

--
-- Name: risk_assessment_hazards; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.risk_assessment_hazards ENABLE ROW LEVEL SECURITY;

--
-- Name: risk_assessment_photos; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.risk_assessment_photos ENABLE ROW LEVEL SECURITY;

--
-- Name: risk_assessments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.risk_assessments ENABLE ROW LEVEL SECURITY;

--
-- Name: security_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.security_events ENABLE ROW LEVEL SECURITY;

--
-- Name: seo_audit_scores; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.seo_audit_scores ENABLE ROW LEVEL SECURITY;

--
-- Name: seo_pages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.seo_pages ENABLE ROW LEVEL SECURITY;

--
-- Name: service_categories; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.service_categories ENABLE ROW LEVEL SECURITY;

--
-- Name: services; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;

--
-- Name: site_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: stool_journal; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.stool_journal ENABLE ROW LEVEL SECURITY;

--
-- Name: suppressed_emails; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.suppressed_emails ENABLE ROW LEVEL SECURITY;

--
-- Name: user_company_relations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.user_company_relations ENABLE ROW LEVEL SECURITY;

--
-- Name: user_roles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

--
-- Name: vaccinations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.vaccinations ENABLE ROW LEVEL SECURITY;

--
-- Name: web_vitals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.web_vitals ENABLE ROW LEVEL SECURITY;

--
-- Name: work_area_sds_documents; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.work_area_sds_documents ENABLE ROW LEVEL SECURITY;

--
-- Name: work_areas; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.work_areas ENABLE ROW LEVEL SECURITY;

--
-- Name: workplaces; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.workplaces ENABLE ROW LEVEL SECURITY;

--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA public TO postgres;
GRANT USAGE ON SCHEMA public TO anon;
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT USAGE ON SCHEMA public TO service_role;
GRANT USAGE ON SCHEMA public TO sandbox_exec;


--
-- Name: FUNCTION admin_get_recovery_history(_user_id uuid, _limit integer); Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON FUNCTION public.admin_get_recovery_history(_user_id uuid, _limit integer) FROM PUBLIC;
GRANT ALL ON FUNCTION public.admin_get_recovery_history(_user_id uuid, _limit integer) TO authenticated;
GRANT ALL ON FUNCTION public.admin_get_recovery_history(_user_id uuid, _limit integer) TO service_role;


--
-- Name: FUNCTION admin_get_recovery_status(_user_ids uuid[]); Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON FUNCTION public.admin_get_recovery_status(_user_ids uuid[]) FROM PUBLIC;
GRANT ALL ON FUNCTION public.admin_get_recovery_status(_user_ids uuid[]) TO authenticated;
GRANT ALL ON FUNCTION public.admin_get_recovery_status(_user_ids uuid[]) TO service_role;


--
-- Name: FUNCTION admin_get_user_providers(_user_ids uuid[]); Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON FUNCTION public.admin_get_user_providers(_user_ids uuid[]) FROM PUBLIC;
GRANT ALL ON FUNCTION public.admin_get_user_providers(_user_ids uuid[]) TO authenticated;
GRANT ALL ON FUNCTION public.admin_get_user_providers(_user_ids uuid[]) TO service_role;


--
-- Name: FUNCTION admin_recovery_failures_summary(_since timestamp with time zone); Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON FUNCTION public.admin_recovery_failures_summary(_since timestamp with time zone) FROM PUBLIC;
GRANT ALL ON FUNCTION public.admin_recovery_failures_summary(_since timestamp with time zone) TO authenticated;
GRANT ALL ON FUNCTION public.admin_recovery_failures_summary(_since timestamp with time zone) TO service_role;


--
-- Name: FUNCTION audit_trigger_func(); Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON FUNCTION public.audit_trigger_func() FROM PUBLIC;
GRANT ALL ON FUNCTION public.audit_trigger_func() TO service_role;


--
-- Name: FUNCTION auto_update_referral_on_questionnaire(); Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON FUNCTION public.auto_update_referral_on_questionnaire() FROM PUBLIC;
GRANT ALL ON FUNCTION public.auto_update_referral_on_questionnaire() TO service_role;


--
-- Name: FUNCTION create_public_lab_order(_customer_name text, _customer_email text, _customer_phone text, _ordered_tests jsonb, _sampling_type text, _location_id uuid, _home_address text, _preferred_date date, _notes text, _total_price_huf integer); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.create_public_lab_order(_customer_name text, _customer_email text, _customer_phone text, _ordered_tests jsonb, _sampling_type text, _location_id uuid, _home_address text, _preferred_date date, _notes text, _total_price_huf integer) TO anon;
GRANT ALL ON FUNCTION public.create_public_lab_order(_customer_name text, _customer_email text, _customer_phone text, _ordered_tests jsonb, _sampling_type text, _location_id uuid, _home_address text, _preferred_date date, _notes text, _total_price_huf integer) TO authenticated;
GRANT ALL ON FUNCTION public.create_public_lab_order(_customer_name text, _customer_email text, _customer_phone text, _ordered_tests jsonb, _sampling_type text, _location_id uuid, _home_address text, _preferred_date date, _notes text, _total_price_huf integer) TO service_role;


--
-- Name: FUNCTION delete_email(queue_name text, message_id bigint); Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON FUNCTION public.delete_email(queue_name text, message_id bigint) FROM PUBLIC;
GRANT ALL ON FUNCTION public.delete_email(queue_name text, message_id bigint) TO service_role;


--
-- Name: FUNCTION email_queue_dispatch(); Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON FUNCTION public.email_queue_dispatch() FROM PUBLIC;
GRANT ALL ON FUNCTION public.email_queue_dispatch() TO anon;
GRANT ALL ON FUNCTION public.email_queue_dispatch() TO authenticated;
GRANT ALL ON FUNCTION public.email_queue_dispatch() TO service_role;


--
-- Name: FUNCTION email_queue_wake(); Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON FUNCTION public.email_queue_wake() FROM PUBLIC;
GRANT ALL ON FUNCTION public.email_queue_wake() TO anon;
GRANT ALL ON FUNCTION public.email_queue_wake() TO authenticated;
GRANT ALL ON FUNCTION public.email_queue_wake() TO service_role;


--
-- Name: FUNCTION enqueue_email(queue_name text, payload jsonb); Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON FUNCTION public.enqueue_email(queue_name text, payload jsonb) FROM PUBLIC;
GRANT ALL ON FUNCTION public.enqueue_email(queue_name text, payload jsonb) TO service_role;


--
-- Name: FUNCTION generate_lab_order_number(); Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON FUNCTION public.generate_lab_order_number() FROM PUBLIC;
GRANT ALL ON FUNCTION public.generate_lab_order_number() TO service_role;


--
-- Name: FUNCTION generate_lab_request_number(); Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON FUNCTION public.generate_lab_request_number() FROM PUBLIC;
GRANT ALL ON FUNCTION public.generate_lab_request_number() TO service_role;


--
-- Name: FUNCTION get_public_locations(); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.get_public_locations() TO anon;
GRANT ALL ON FUNCTION public.get_public_locations() TO authenticated;
GRANT ALL ON FUNCTION public.get_public_locations() TO service_role;


--
-- Name: FUNCTION get_user_roles(_user_id uuid); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.get_user_roles(_user_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_user_roles(_user_id uuid) TO service_role;


--
-- Name: FUNCTION handle_new_user(); Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON FUNCTION public.handle_new_user() FROM PUBLIC;
GRANT ALL ON FUNCTION public.handle_new_user() TO service_role;


--
-- Name: FUNCTION has_role(_user_id uuid, _role public.app_role); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.has_role(_user_id uuid, _role public.app_role) TO authenticated;
GRANT ALL ON FUNCTION public.has_role(_user_id uuid, _role public.app_role) TO service_role;


--
-- Name: FUNCTION is_company_member(_user_id uuid, _company_id uuid, _role public.app_role); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.is_company_member(_user_id uuid, _company_id uuid, _role public.app_role) TO authenticated;
GRANT ALL ON FUNCTION public.is_company_member(_user_id uuid, _company_id uuid, _role public.app_role) TO service_role;


--
-- Name: FUNCTION is_employer_of_patient(_employer_id uuid, _patient_id uuid); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.is_employer_of_patient(_employer_id uuid, _patient_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.is_employer_of_patient(_employer_id uuid, _patient_id uuid) TO service_role;


--
-- Name: FUNCTION log_security_event(_event_type text, _severity text, _table_name text, _operation text, _error_code text, _error_message text, _route text, _user_agent text, _metadata jsonb); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.log_security_event(_event_type text, _severity text, _table_name text, _operation text, _error_code text, _error_message text, _route text, _user_agent text, _metadata jsonb) TO anon;
GRANT ALL ON FUNCTION public.log_security_event(_event_type text, _severity text, _table_name text, _operation text, _error_code text, _error_message text, _route text, _user_agent text, _metadata jsonb) TO authenticated;
GRANT ALL ON FUNCTION public.log_security_event(_event_type text, _severity text, _table_name text, _operation text, _error_code text, _error_message text, _route text, _user_agent text, _metadata jsonb) TO service_role;


--
-- Name: FUNCTION move_to_dlq(source_queue text, dlq_name text, message_id bigint, payload jsonb); Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON FUNCTION public.move_to_dlq(source_queue text, dlq_name text, message_id bigint, payload jsonb) FROM PUBLIC;
GRANT ALL ON FUNCTION public.move_to_dlq(source_queue text, dlq_name text, message_id bigint, payload jsonb) TO service_role;


--
-- Name: FUNCTION notify_admins_on_recovery_failure(); Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON FUNCTION public.notify_admins_on_recovery_failure() FROM PUBLIC;
GRANT ALL ON FUNCTION public.notify_admins_on_recovery_failure() TO service_role;


--
-- Name: FUNCTION read_email_batch(queue_name text, batch_size integer, vt integer); Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON FUNCTION public.read_email_batch(queue_name text, batch_size integer, vt integer) FROM PUBLIC;
GRANT ALL ON FUNCTION public.read_email_batch(queue_name text, batch_size integer, vt integer) TO service_role;


--
-- Name: FUNCTION search_icd_codes(_query text, _version text, _limit integer); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.search_icd_codes(_query text, _version text, _limit integer) TO anon;
GRANT ALL ON FUNCTION public.search_icd_codes(_query text, _version text, _limit integer) TO authenticated;
GRANT ALL ON FUNCTION public.search_icd_codes(_query text, _version text, _limit integer) TO service_role;


--
-- Name: FUNCTION security_denials_summary(_since timestamp with time zone); Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON FUNCTION public.security_denials_summary(_since timestamp with time zone) FROM PUBLIC;
GRANT ALL ON FUNCTION public.security_denials_summary(_since timestamp with time zone) TO service_role;


--
-- Name: FUNCTION update_updated_at_column(); Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON FUNCTION public.update_updated_at_column() FROM PUBLIC;
GRANT ALL ON FUNCTION public.update_updated_at_column() TO service_role;


--
-- Name: FUNCTION validate_icd_code(_code text, _version text); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.validate_icd_code(_code text, _version text) TO anon;
GRANT ALL ON FUNCTION public.validate_icd_code(_code text, _version text) TO authenticated;
GRANT ALL ON FUNCTION public.validate_icd_code(_code text, _version text) TO service_role;


--
-- Name: TABLE accident_reports; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.accident_reports TO anon;
GRANT ALL ON TABLE public.accident_reports TO authenticated;
GRANT ALL ON TABLE public.accident_reports TO service_role;
GRANT SELECT,INSERT ON TABLE public.accident_reports TO sandbox_exec;


--
-- Name: TABLE activities; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.activities TO anon;
GRANT ALL ON TABLE public.activities TO authenticated;
GRANT ALL ON TABLE public.activities TO service_role;
GRANT SELECT,INSERT ON TABLE public.activities TO sandbox_exec;


--
-- Name: TABLE appointment_slots; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.appointment_slots TO anon;
GRANT ALL ON TABLE public.appointment_slots TO authenticated;
GRANT ALL ON TABLE public.appointment_slots TO service_role;
GRANT SELECT,INSERT ON TABLE public.appointment_slots TO sandbox_exec;


--
-- Name: TABLE appointments; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.appointments TO anon;
GRANT ALL ON TABLE public.appointments TO authenticated;
GRANT ALL ON TABLE public.appointments TO service_role;
GRANT SELECT,INSERT ON TABLE public.appointments TO sandbox_exec;


--
-- Name: TABLE audit_logs; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.audit_logs TO anon;
GRANT ALL ON TABLE public.audit_logs TO authenticated;
GRANT ALL ON TABLE public.audit_logs TO service_role;
GRANT SELECT,INSERT ON TABLE public.audit_logs TO sandbox_exec;


--
-- Name: TABLE bulk_import_logs; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.bulk_import_logs TO anon;
GRANT ALL ON TABLE public.bulk_import_logs TO authenticated;
GRANT ALL ON TABLE public.bulk_import_logs TO service_role;
GRANT SELECT,INSERT ON TABLE public.bulk_import_logs TO sandbox_exec;


--
-- Name: TABLE certificates; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.certificates TO anon;
GRANT ALL ON TABLE public.certificates TO authenticated;
GRANT ALL ON TABLE public.certificates TO service_role;
GRANT SELECT,INSERT ON TABLE public.certificates TO sandbox_exec;


--
-- Name: TABLE companies; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.companies TO anon;
GRANT ALL ON TABLE public.companies TO authenticated;
GRANT ALL ON TABLE public.companies TO service_role;
GRANT SELECT,INSERT ON TABLE public.companies TO sandbox_exec;


--
-- Name: TABLE company_hazardous_substances; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.company_hazardous_substances TO anon;
GRANT ALL ON TABLE public.company_hazardous_substances TO authenticated;
GRANT ALL ON TABLE public.company_hazardous_substances TO service_role;
GRANT SELECT,INSERT ON TABLE public.company_hazardous_substances TO sandbox_exec;


--
-- Name: TABLE company_sites; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.company_sites TO anon;
GRANT ALL ON TABLE public.company_sites TO authenticated;
GRANT ALL ON TABLE public.company_sites TO service_role;
GRANT SELECT,INSERT ON TABLE public.company_sites TO sandbox_exec;


--
-- Name: TABLE company_teaor_codes; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.company_teaor_codes TO anon;
GRANT ALL ON TABLE public.company_teaor_codes TO authenticated;
GRANT ALL ON TABLE public.company_teaor_codes TO service_role;
GRANT SELECT,INSERT ON TABLE public.company_teaor_codes TO sandbox_exec;


--
-- Name: TABLE competitor_analyses; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.competitor_analyses TO anon;
GRANT ALL ON TABLE public.competitor_analyses TO authenticated;
GRANT ALL ON TABLE public.competitor_analyses TO service_role;
GRANT SELECT,INSERT ON TABLE public.competitor_analyses TO sandbox_exec;


--
-- Name: TABLE competitor_urls; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.competitor_urls TO anon;
GRANT ALL ON TABLE public.competitor_urls TO authenticated;
GRANT ALL ON TABLE public.competitor_urls TO service_role;
GRANT SELECT,INSERT ON TABLE public.competitor_urls TO sandbox_exec;


--
-- Name: TABLE content_translations; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.content_translations TO anon;
GRANT ALL ON TABLE public.content_translations TO authenticated;
GRANT ALL ON TABLE public.content_translations TO service_role;
GRANT SELECT,INSERT ON TABLE public.content_translations TO sandbox_exec;


--
-- Name: TABLE doctor_recommendations; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.doctor_recommendations TO anon;
GRANT ALL ON TABLE public.doctor_recommendations TO authenticated;
GRANT ALL ON TABLE public.doctor_recommendations TO service_role;
GRANT SELECT,INSERT ON TABLE public.doctor_recommendations TO sandbox_exec;


--
-- Name: TABLE document_tags; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.document_tags TO anon;
GRANT ALL ON TABLE public.document_tags TO authenticated;
GRANT ALL ON TABLE public.document_tags TO service_role;
GRANT SELECT,INSERT ON TABLE public.document_tags TO sandbox_exec;


--
-- Name: TABLE document_templates; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.document_templates TO anon;
GRANT ALL ON TABLE public.document_templates TO authenticated;
GRANT ALL ON TABLE public.document_templates TO service_role;
GRANT SELECT,INSERT ON TABLE public.document_templates TO sandbox_exec;


--
-- Name: TABLE documents; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.documents TO anon;
GRANT ALL ON TABLE public.documents TO authenticated;
GRANT ALL ON TABLE public.documents TO service_role;
GRANT SELECT,INSERT ON TABLE public.documents TO sandbox_exec;


--
-- Name: TABLE email_send_log; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.email_send_log TO anon;
GRANT ALL ON TABLE public.email_send_log TO authenticated;
GRANT ALL ON TABLE public.email_send_log TO service_role;
GRANT SELECT,INSERT ON TABLE public.email_send_log TO sandbox_exec;


--
-- Name: TABLE email_send_state; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.email_send_state TO anon;
GRANT ALL ON TABLE public.email_send_state TO authenticated;
GRANT ALL ON TABLE public.email_send_state TO service_role;
GRANT SELECT,INSERT ON TABLE public.email_send_state TO sandbox_exec;


--
-- Name: TABLE email_unsubscribe_tokens; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.email_unsubscribe_tokens TO anon;
GRANT ALL ON TABLE public.email_unsubscribe_tokens TO authenticated;
GRANT ALL ON TABLE public.email_unsubscribe_tokens TO service_role;
GRANT SELECT,INSERT ON TABLE public.email_unsubscribe_tokens TO sandbox_exec;


--
-- Name: TABLE examinations; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.examinations TO anon;
GRANT ALL ON TABLE public.examinations TO authenticated;
GRANT ALL ON TABLE public.examinations TO service_role;
GRANT SELECT,INSERT ON TABLE public.examinations TO sandbox_exec;


--
-- Name: TABLE food_journal; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.food_journal TO anon;
GRANT ALL ON TABLE public.food_journal TO authenticated;
GRANT ALL ON TABLE public.food_journal TO service_role;
GRANT SELECT,INSERT ON TABLE public.food_journal TO sandbox_exec;


--
-- Name: TABLE gdpr_requests; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.gdpr_requests TO anon;
GRANT ALL ON TABLE public.gdpr_requests TO authenticated;
GRANT ALL ON TABLE public.gdpr_requests TO service_role;
GRANT SELECT,INSERT ON TABLE public.gdpr_requests TO sandbox_exec;


--
-- Name: TABLE hazardous_substances; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.hazardous_substances TO anon;
GRANT ALL ON TABLE public.hazardous_substances TO authenticated;
GRANT ALL ON TABLE public.hazardous_substances TO service_role;
GRANT SELECT,INSERT ON TABLE public.hazardous_substances TO sandbox_exec;


--
-- Name: TABLE health_journal; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.health_journal TO anon;
GRANT ALL ON TABLE public.health_journal TO authenticated;
GRANT ALL ON TABLE public.health_journal TO service_role;
GRANT SELECT,INSERT ON TABLE public.health_journal TO sandbox_exec;


--
-- Name: TABLE health_plans; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.health_plans TO anon;
GRANT ALL ON TABLE public.health_plans TO authenticated;
GRANT ALL ON TABLE public.health_plans TO service_role;
GRANT SELECT,INSERT ON TABLE public.health_plans TO sandbox_exec;


--
-- Name: TABLE health_reports; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.health_reports TO anon;
GRANT ALL ON TABLE public.health_reports TO authenticated;
GRANT ALL ON TABLE public.health_reports TO service_role;
GRANT SELECT,INSERT ON TABLE public.health_reports TO sandbox_exec;


--
-- Name: TABLE i18n_overrides; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.i18n_overrides TO anon;
GRANT ALL ON TABLE public.i18n_overrides TO authenticated;
GRANT ALL ON TABLE public.i18n_overrides TO service_role;
GRANT SELECT,INSERT ON TABLE public.i18n_overrides TO sandbox_exec;


--
-- Name: TABLE icd_codes; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.icd_codes TO anon;
GRANT ALL ON TABLE public.icd_codes TO authenticated;
GRANT ALL ON TABLE public.icd_codes TO service_role;
GRANT SELECT,INSERT ON TABLE public.icd_codes TO sandbox_exec;


--
-- Name: TABLE lab_markup_config; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.lab_markup_config TO anon;
GRANT ALL ON TABLE public.lab_markup_config TO authenticated;
GRANT ALL ON TABLE public.lab_markup_config TO service_role;
GRANT SELECT,INSERT ON TABLE public.lab_markup_config TO sandbox_exec;


--
-- Name: TABLE lab_orders; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.lab_orders TO anon;
GRANT ALL ON TABLE public.lab_orders TO authenticated;
GRANT ALL ON TABLE public.lab_orders TO service_role;
GRANT SELECT,INSERT ON TABLE public.lab_orders TO sandbox_exec;


--
-- Name: TABLE lab_packages; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.lab_packages TO anon;
GRANT ALL ON TABLE public.lab_packages TO authenticated;
GRANT ALL ON TABLE public.lab_packages TO service_role;
GRANT SELECT,INSERT ON TABLE public.lab_packages TO sandbox_exec;


--
-- Name: TABLE lab_pricing_config; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.lab_pricing_config TO anon;
GRANT ALL ON TABLE public.lab_pricing_config TO authenticated;
GRANT ALL ON TABLE public.lab_pricing_config TO service_role;
GRANT SELECT,INSERT ON TABLE public.lab_pricing_config TO sandbox_exec;


--
-- Name: TABLE lab_requests; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.lab_requests TO anon;
GRANT ALL ON TABLE public.lab_requests TO authenticated;
GRANT ALL ON TABLE public.lab_requests TO service_role;
GRANT SELECT,INSERT ON TABLE public.lab_requests TO sandbox_exec;


--
-- Name: TABLE locations; Type: ACL; Schema: public; Owner: -
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE public.locations TO anon;
GRANT ALL ON TABLE public.locations TO authenticated;
GRANT ALL ON TABLE public.locations TO service_role;
GRANT SELECT,INSERT ON TABLE public.locations TO sandbox_exec;


--
-- Name: TABLE medical_opinions; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.medical_opinions TO anon;
GRANT ALL ON TABLE public.medical_opinions TO authenticated;
GRANT ALL ON TABLE public.medical_opinions TO service_role;
GRANT SELECT,INSERT ON TABLE public.medical_opinions TO sandbox_exec;


--
-- Name: TABLE medication_requests; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.medication_requests TO anon;
GRANT ALL ON TABLE public.medication_requests TO authenticated;
GRANT ALL ON TABLE public.medication_requests TO service_role;
GRANT SELECT,INSERT ON TABLE public.medication_requests TO sandbox_exec;


--
-- Name: TABLE medications; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.medications TO anon;
GRANT ALL ON TABLE public.medications TO authenticated;
GRANT ALL ON TABLE public.medications TO service_role;
GRANT SELECT,INSERT ON TABLE public.medications TO sandbox_exec;


--
-- Name: TABLE messages; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.messages TO anon;
GRANT ALL ON TABLE public.messages TO authenticated;
GRANT ALL ON TABLE public.messages TO service_role;
GRANT SELECT,INSERT ON TABLE public.messages TO sandbox_exec;


--
-- Name: TABLE navigation_links; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.navigation_links TO anon;
GRANT ALL ON TABLE public.navigation_links TO authenticated;
GRANT ALL ON TABLE public.navigation_links TO service_role;
GRANT SELECT,INSERT ON TABLE public.navigation_links TO sandbox_exec;


--
-- Name: TABLE noise_vibration_measurements; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.noise_vibration_measurements TO anon;
GRANT ALL ON TABLE public.noise_vibration_measurements TO authenticated;
GRANT ALL ON TABLE public.noise_vibration_measurements TO service_role;
GRANT SELECT,INSERT ON TABLE public.noise_vibration_measurements TO sandbox_exec;


--
-- Name: TABLE notification_preferences; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.notification_preferences TO anon;
GRANT ALL ON TABLE public.notification_preferences TO authenticated;
GRANT ALL ON TABLE public.notification_preferences TO service_role;
GRANT SELECT,INSERT ON TABLE public.notification_preferences TO sandbox_exec;


--
-- Name: TABLE notifications; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.notifications TO anon;
GRANT ALL ON TABLE public.notifications TO authenticated;
GRANT ALL ON TABLE public.notifications TO service_role;
GRANT SELECT,INSERT ON TABLE public.notifications TO sandbox_exec;


--
-- Name: TABLE page_views; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.page_views TO anon;
GRANT ALL ON TABLE public.page_views TO authenticated;
GRANT ALL ON TABLE public.page_views TO service_role;
GRANT SELECT,INSERT ON TABLE public.page_views TO sandbox_exec;


--
-- Name: TABLE pages_content; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.pages_content TO anon;
GRANT ALL ON TABLE public.pages_content TO authenticated;
GRANT ALL ON TABLE public.pages_content TO service_role;
GRANT SELECT,INSERT ON TABLE public.pages_content TO sandbox_exec;


--
-- Name: TABLE patient_cards; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.patient_cards TO anon;
GRANT ALL ON TABLE public.patient_cards TO authenticated;
GRANT ALL ON TABLE public.patient_cards TO service_role;
GRANT SELECT,INSERT ON TABLE public.patient_cards TO sandbox_exec;


--
-- Name: TABLE profiles; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.profiles TO anon;
GRANT ALL ON TABLE public.profiles TO authenticated;
GRANT ALL ON TABLE public.profiles TO service_role;
GRANT SELECT,INSERT ON TABLE public.profiles TO sandbox_exec;


--
-- Name: TABLE questionnaire_assignments; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.questionnaire_assignments TO anon;
GRANT ALL ON TABLE public.questionnaire_assignments TO authenticated;
GRANT ALL ON TABLE public.questionnaire_assignments TO service_role;
GRANT SELECT,INSERT ON TABLE public.questionnaire_assignments TO sandbox_exec;


--
-- Name: TABLE questionnaire_submissions; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.questionnaire_submissions TO anon;
GRANT ALL ON TABLE public.questionnaire_submissions TO authenticated;
GRANT ALL ON TABLE public.questionnaire_submissions TO service_role;
GRANT SELECT,INSERT ON TABLE public.questionnaire_submissions TO sandbox_exec;


--
-- Name: TABLE questionnaires; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.questionnaires TO anon;
GRANT ALL ON TABLE public.questionnaires TO authenticated;
GRANT ALL ON TABLE public.questionnaires TO service_role;
GRANT SELECT,INSERT ON TABLE public.questionnaires TO sandbox_exec;


--
-- Name: TABLE referrals; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.referrals TO anon;
GRANT ALL ON TABLE public.referrals TO authenticated;
GRANT ALL ON TABLE public.referrals TO service_role;
GRANT SELECT,INSERT ON TABLE public.referrals TO sandbox_exec;


--
-- Name: TABLE requests; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.requests TO anon;
GRANT ALL ON TABLE public.requests TO authenticated;
GRANT ALL ON TABLE public.requests TO service_role;
GRANT SELECT,INSERT ON TABLE public.requests TO sandbox_exec;


--
-- Name: TABLE risk_assessment_hazards; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.risk_assessment_hazards TO anon;
GRANT ALL ON TABLE public.risk_assessment_hazards TO authenticated;
GRANT ALL ON TABLE public.risk_assessment_hazards TO service_role;
GRANT SELECT,INSERT ON TABLE public.risk_assessment_hazards TO sandbox_exec;


--
-- Name: TABLE risk_assessment_photos; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.risk_assessment_photos TO anon;
GRANT ALL ON TABLE public.risk_assessment_photos TO authenticated;
GRANT ALL ON TABLE public.risk_assessment_photos TO service_role;
GRANT SELECT,INSERT ON TABLE public.risk_assessment_photos TO sandbox_exec;


--
-- Name: TABLE risk_assessments; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.risk_assessments TO anon;
GRANT ALL ON TABLE public.risk_assessments TO authenticated;
GRANT ALL ON TABLE public.risk_assessments TO service_role;
GRANT SELECT,INSERT ON TABLE public.risk_assessments TO sandbox_exec;


--
-- Name: TABLE security_events; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.security_events TO anon;
GRANT ALL ON TABLE public.security_events TO authenticated;
GRANT ALL ON TABLE public.security_events TO service_role;
GRANT SELECT,INSERT ON TABLE public.security_events TO sandbox_exec;


--
-- Name: TABLE seo_audit_scores; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.seo_audit_scores TO anon;
GRANT ALL ON TABLE public.seo_audit_scores TO authenticated;
GRANT ALL ON TABLE public.seo_audit_scores TO service_role;
GRANT SELECT,INSERT ON TABLE public.seo_audit_scores TO sandbox_exec;


--
-- Name: TABLE seo_pages; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.seo_pages TO anon;
GRANT ALL ON TABLE public.seo_pages TO authenticated;
GRANT ALL ON TABLE public.seo_pages TO service_role;
GRANT SELECT,INSERT ON TABLE public.seo_pages TO sandbox_exec;


--
-- Name: TABLE service_categories; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.service_categories TO anon;
GRANT ALL ON TABLE public.service_categories TO authenticated;
GRANT ALL ON TABLE public.service_categories TO service_role;
GRANT SELECT,INSERT ON TABLE public.service_categories TO sandbox_exec;


--
-- Name: TABLE services; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.services TO anon;
GRANT ALL ON TABLE public.services TO authenticated;
GRANT ALL ON TABLE public.services TO service_role;
GRANT SELECT,INSERT ON TABLE public.services TO sandbox_exec;


--
-- Name: TABLE site_settings; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.site_settings TO anon;
GRANT ALL ON TABLE public.site_settings TO authenticated;
GRANT ALL ON TABLE public.site_settings TO service_role;
GRANT SELECT,INSERT ON TABLE public.site_settings TO sandbox_exec;


--
-- Name: TABLE stool_journal; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.stool_journal TO anon;
GRANT ALL ON TABLE public.stool_journal TO authenticated;
GRANT ALL ON TABLE public.stool_journal TO service_role;
GRANT SELECT,INSERT ON TABLE public.stool_journal TO sandbox_exec;


--
-- Name: TABLE suppressed_emails; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.suppressed_emails TO anon;
GRANT ALL ON TABLE public.suppressed_emails TO authenticated;
GRANT ALL ON TABLE public.suppressed_emails TO service_role;
GRANT SELECT,INSERT ON TABLE public.suppressed_emails TO sandbox_exec;


--
-- Name: TABLE user_company_relations; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.user_company_relations TO anon;
GRANT ALL ON TABLE public.user_company_relations TO authenticated;
GRANT ALL ON TABLE public.user_company_relations TO service_role;
GRANT SELECT,INSERT ON TABLE public.user_company_relations TO sandbox_exec;


--
-- Name: TABLE user_roles; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.user_roles TO anon;
GRANT ALL ON TABLE public.user_roles TO authenticated;
GRANT ALL ON TABLE public.user_roles TO service_role;
GRANT SELECT,INSERT ON TABLE public.user_roles TO sandbox_exec;


--
-- Name: TABLE vaccinations; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.vaccinations TO anon;
GRANT ALL ON TABLE public.vaccinations TO authenticated;
GRANT ALL ON TABLE public.vaccinations TO service_role;
GRANT SELECT,INSERT ON TABLE public.vaccinations TO sandbox_exec;


--
-- Name: TABLE web_vitals; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.web_vitals TO anon;
GRANT ALL ON TABLE public.web_vitals TO authenticated;
GRANT ALL ON TABLE public.web_vitals TO service_role;
GRANT SELECT,INSERT ON TABLE public.web_vitals TO sandbox_exec;


--
-- Name: TABLE work_area_sds_documents; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.work_area_sds_documents TO anon;
GRANT ALL ON TABLE public.work_area_sds_documents TO authenticated;
GRANT ALL ON TABLE public.work_area_sds_documents TO service_role;
GRANT SELECT,INSERT ON TABLE public.work_area_sds_documents TO sandbox_exec;


--
-- Name: TABLE work_areas; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.work_areas TO anon;
GRANT ALL ON TABLE public.work_areas TO authenticated;
GRANT ALL ON TABLE public.work_areas TO service_role;
GRANT SELECT,INSERT ON TABLE public.work_areas TO sandbox_exec;


--
-- Name: TABLE workplaces; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.workplaces TO anon;
GRANT ALL ON TABLE public.workplaces TO authenticated;
GRANT ALL ON TABLE public.workplaces TO service_role;
GRANT SELECT,INSERT ON TABLE public.workplaces TO sandbox_exec;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: -
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO service_role;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT SELECT,USAGE ON SEQUENCES TO sandbox_exec;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: -
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: -
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: -
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: -
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO service_role;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT SELECT,INSERT ON TABLES TO sandbox_exec;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: -
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO service_role;


--
-- PostgreSQL database dump complete
--

\unrestrict Y3lqI6tousGnitXhvUUWHmCdJryMe6rR2at5mSdeGUKiBpREfKOMTvnrzCZgEim

