-- Admin manage medical docs
CREATE POLICY "Admin manage medical docs" ON storage.objects AS PERMISSIVE FOR ALL TO authenticated
  USING (((bucket_id = 'medical-documents'::text) AND has_role(auth.uid(), 'super_admin'::app_role)));
-- Admins delete risk photos
CREATE POLICY "Admins delete risk photos" ON storage.objects AS PERMISSIVE FOR DELETE TO authenticated
  USING (((bucket_id = 'risk-assessment-photos'::text) AND (has_role(auth.uid(), 'super_admin'::app_role) OR has_role(auth.uid(), 'uzemorvos'::app_role))));
-- Authenticated users can upload SDS
CREATE POLICY "Authenticated users can upload SDS" ON storage.objects AS PERMISSIVE FOR INSERT TO authenticated
  WITH CHECK ((bucket_id = 'sds-documents'::text));
-- Doctors and admins read accident photos
CREATE POLICY "Doctors and admins read accident photos" ON storage.objects AS PERMISSIVE FOR SELECT TO authenticated
  USING (((bucket_id = 'accident-photos'::text) AND (has_role(auth.uid(), 'super_admin'::app_role) OR has_role(auth.uid(), 'uzemorvos'::app_role) OR has_role(auth.uid(), 'haziorvos'::app_role))));
-- Doctors read medical docs
CREATE POLICY "Doctors read medical docs" ON storage.objects AS PERMISSIVE FOR SELECT TO authenticated
  USING (((bucket_id = 'medical-documents'::text) AND (has_role(auth.uid(), 'uzemorvos'::app_role) OR has_role(auth.uid(), 'haziorvos'::app_role))));
-- Members view SDS files
CREATE POLICY "Members view SDS files" ON storage.objects AS PERMISSIVE FOR SELECT TO authenticated
  USING (((bucket_id = 'sds-documents'::text) AND (((storage.foldername(name))[1] = (auth.uid())::text) OR has_role(auth.uid(), 'super_admin'::app_role) OR has_role(auth.uid(), 'uzemorvos'::app_role) OR (EXISTS ( SELECT 1
   FROM (((work_area_sds_documents d
     JOIN work_areas wa ON ((wa.id = d.work_area_id)))
     JOIN company_sites cs ON ((cs.id = wa.site_id)))
     JOIN user_company_relations ucr ON ((ucr.company_id = cs.company_id)))
  WHERE ((d.file_path = objects.name) AND (ucr.user_id = auth.uid()) AND (ucr.is_active = true)))))));
-- Munkaltato read medical docs
CREATE POLICY "Munkaltato read medical docs" ON storage.objects AS PERMISSIVE FOR SELECT TO authenticated
  USING (((bucket_id = 'medical-documents'::text) AND has_role(auth.uid(), 'munkaltato'::app_role) AND is_employer_of_patient(auth.uid(), ((storage.foldername(name))[1])::uuid)));
-- Risk photos read: company members and staff
CREATE POLICY "Risk photos read: company members and staff" ON storage.objects AS PERMISSIVE FOR SELECT TO authenticated
  USING (((bucket_id = 'risk-assessment-photos'::text) AND (has_role(auth.uid(), 'super_admin'::app_role) OR has_role(auth.uid(), 'uzemorvos'::app_role) OR (EXISTS ( SELECT 1
   FROM (risk_assessments ra
     JOIN user_company_relations ucr ON ((ucr.company_id = ra.company_id)))
  WHERE (((ra.id)::text = split_part(objects.name, '/'::text, 1)) AND (ucr.user_id = auth.uid()) AND (ucr.is_active = true)))))));
-- Risk photos upload: company members and staff
CREATE POLICY "Risk photos upload: company members and staff" ON storage.objects AS PERMISSIVE FOR INSERT TO authenticated
  WITH CHECK (((bucket_id = 'risk-assessment-photos'::text) AND (has_role(auth.uid(), 'super_admin'::app_role) OR has_role(auth.uid(), 'uzemorvos'::app_role) OR (EXISTS ( SELECT 1
   FROM (risk_assessments ra
     JOIN user_company_relations ucr ON ((ucr.company_id = ra.company_id)))
  WHERE (((ra.id)::text = split_part(objects.name, '/'::text, 1)) AND (ucr.user_id = auth.uid()) AND (ucr.is_active = true) AND (ucr.role = ANY (ARRAY['munkaltato'::app_role, 'uzemorvos'::app_role, 'super_admin'::app_role]))))))));
-- Super admins can delete OG images
CREATE POLICY "Super admins can delete OG images" ON storage.objects AS PERMISSIVE FOR DELETE TO 
  USING (((bucket_id = 'og-images'::text) AND has_role(auth.uid(), 'super_admin'::app_role)));
-- Super admins can update OG images
CREATE POLICY "Super admins can update OG images" ON storage.objects AS PERMISSIVE FOR UPDATE TO 
  USING (((bucket_id = 'og-images'::text) AND has_role(auth.uid(), 'super_admin'::app_role)));
-- Super admins can upload OG images
CREATE POLICY "Super admins can upload OG images" ON storage.objects AS PERMISSIVE FOR INSERT TO 
  WITH CHECK (((bucket_id = 'og-images'::text) AND has_role(auth.uid(), 'super_admin'::app_role)));
-- Users can delete own SDS files
CREATE POLICY "Users can delete own SDS files" ON storage.objects AS PERMISSIVE FOR DELETE TO authenticated
  USING (((bucket_id = 'sds-documents'::text) AND ((auth.uid())::text = (storage.foldername(name))[1])));
-- Users delete own accident photos
CREATE POLICY "Users delete own accident photos" ON storage.objects AS PERMISSIVE FOR DELETE TO authenticated
  USING (((bucket_id = 'accident-photos'::text) AND ((storage.foldername(name))[1] = (auth.uid())::text)));
-- Users delete own signature
CREATE POLICY "Users delete own signature" ON storage.objects AS PERMISSIVE FOR DELETE TO authenticated
  USING (((bucket_id = 'signatures'::text) AND ((storage.foldername(name))[1] = (auth.uid())::text)));
-- Users read own accident photos
CREATE POLICY "Users read own accident photos" ON storage.objects AS PERMISSIVE FOR SELECT TO authenticated
  USING (((bucket_id = 'accident-photos'::text) AND ((storage.foldername(name))[1] = (auth.uid())::text)));
-- Users read own medical docs
CREATE POLICY "Users read own medical docs" ON storage.objects AS PERMISSIVE FOR SELECT TO authenticated
  USING (((bucket_id = 'medical-documents'::text) AND ((storage.foldername(name))[1] = (auth.uid())::text)));
-- Users read own signature
CREATE POLICY "Users read own signature" ON storage.objects AS PERMISSIVE FOR SELECT TO authenticated
  USING (((bucket_id = 'signatures'::text) AND ((storage.foldername(name))[1] = (auth.uid())::text)));
-- Users update own signature
CREATE POLICY "Users update own signature" ON storage.objects AS PERMISSIVE FOR UPDATE TO authenticated
  USING (((bucket_id = 'signatures'::text) AND ((storage.foldername(name))[1] = (auth.uid())::text)));
-- Users upload own accident photos
CREATE POLICY "Users upload own accident photos" ON storage.objects AS PERMISSIVE FOR INSERT TO authenticated
  WITH CHECK (((bucket_id = 'accident-photos'::text) AND ((storage.foldername(name))[1] = (auth.uid())::text)));
-- Users upload own medical docs
CREATE POLICY "Users upload own medical docs" ON storage.objects AS PERMISSIVE FOR INSERT TO authenticated
  WITH CHECK (((bucket_id = 'medical-documents'::text) AND ((storage.foldername(name))[1] = (auth.uid())::text)));
-- Users upload own signature
CREATE POLICY "Users upload own signature" ON storage.objects AS PERMISSIVE FOR INSERT TO authenticated
  WITH CHECK (((bucket_id = 'signatures'::text) AND ((storage.foldername(name))[1] = (auth.uid())::text)));
