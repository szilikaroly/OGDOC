-- CMS Seed Data: site_settings
INSERT INTO public.site_settings (key, value, label, section) VALUES
  ('site_name', 'MediCenter', 'Weboldal neve', 'general'),
  ('hero_title', 'Professzionális Egészségügyi Szolgáltatások', 'Hero cím', 'hero'),
  ('hero_subtitle', 'Megbízható orvosi ellátás, modern technológiával és személyre szabott megoldásokkal az Ön egészségéért.', 'Hero alcím', 'hero'),
  ('hero_cta_text', 'Időpont foglalás', 'Hero CTA gomb szöveg', 'hero'),
  ('hero_cta_link', '/register', 'Hero CTA link', 'hero'),
  ('footer_text', '© 2026 MediCenter. Minden jog fenntartva.', 'Footer szöveg', 'footer'),
  ('contact_email', 'info@medicenter.hu', 'Kapcsolat email', 'contact'),
  ('contact_phone', '+36 1 234 5678', 'Kapcsolat telefon', 'contact'),
  ('contact_address', '1052 Budapest, Váci utca 10.', 'Kapcsolat cím', 'contact'),
  ('logo_url', '', 'Logó URL', 'general');

-- CMS Seed Data: navigation_links
INSERT INTO public.navigation_links (label, href, sort_order, is_active) VALUES
  ('Főoldal', '/', 1, true),
  ('Szolgáltatások', '/#szolgaltatasok', 2, true),
  ('Rólunk', '/#rolunk', 3, true),
  ('Kapcsolat', '/#kapcsolat', 4, true),
  ('Bejelentkezés', '/login', 5, true);

-- CMS Seed Data: pages_content
INSERT INTO public.pages_content (page_key, section, sort_order, is_active, content_json) VALUES
  ('home', 'hero', 1, true, '{"title": "Professzionális Egészségügyi Szolgáltatások", "subtitle": "Megbízható orvosi ellátás, modern technológiával és személyre szabott megoldásokkal az Ön egészségéért.", "image_url": ""}'),
  ('home', 'about', 2, true, '{"title": "Rólunk", "description": "Csapatunk elkötelezett az Ön egészségének megőrzése mellett. Több évtizedes tapasztalattal és a legmodernebb diagnosztikai eszközökkel állunk rendelkezésére. Célunk, hogy minden páciensünk a legmagasabb szintű ellátásban részesüljön.", "image_url": ""}'),
  ('home', 'services_intro', 3, true, '{"title": "Szolgáltatásaink", "description": "Széles körű egészségügyi szolgáltatásokat kínálunk, a megelőzéstől a komplex vizsgálatokig."}'),
  ('home', 'cta', 4, true, '{"title": "Foglaljon időpontot még ma!", "description": "Regisztráljon rendszerünkbe és válasszon a számára legmegfelelőbb időpontot. Gyors, egyszerű és biztonságos.", "button_text": "Regisztráció", "button_link": "/register"}');

-- CMS Seed Data: services
INSERT INTO public.services (name, description, category, duration_min, is_active, price) VALUES
  ('Üzemorvosi vizsgálat', 'Munkavállalók kötelező és időszakos üzemorvosi alkalmassági vizsgálata a hatályos jogszabályok szerint.', 'uzemorvos', 30, true, 15000),
  ('Háziorvosi ellátás', 'Általános háziorvosi konzultáció, betegvizsgálat, receptírás és beutaló kiállítása.', 'haziorvos', 20, true, null),
  ('Alkalmassági vélemény', 'Munkáltatói igényre készített orvosi alkalmassági vélemény, nyomtatható formátumban.', 'uzemorvos', 45, true, 20000),
  ('Előjegyzés szakrendelésre', 'Online időpont foglalás különböző szakrendelésekre és vizsgálatokra.', 'altalanos', 15, true, null),
  ('Egészségügyi kérdőív', 'Digitális egészségügyi kérdőív kitöltése, amely az orvosi konzultációt segíti elő.', 'altalanos', 10, true, null);