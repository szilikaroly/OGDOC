-- Add ECHA candidate list fields to hazardous_substances
ALTER TABLE public.hazardous_substances
  ADD COLUMN IF NOT EXISTS description text,
  ADD COLUMN IF NOT EXISTS date_of_inclusion date,
  ADD COLUMN IF NOT EXISTS decision_url text,
  ADD COLUMN IF NOT EXISTS iuclid_dataset_url text,
  ADD COLUMN IF NOT EXISTS support_document_url text,
  ADD COLUMN IF NOT EXISTS remarks text;