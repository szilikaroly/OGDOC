-- Restore missing GRANTs on locations and lab_orders, add public RPC for lab order creation

GRANT SELECT, INSERT, UPDATE, DELETE ON public.locations TO authenticated;
GRANT ALL ON public.locations TO service_role;

GRANT INSERT ON public.lab_orders TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.lab_orders TO authenticated;
GRANT ALL ON public.lab_orders TO service_role;

-- RPC that lets anonymous webshop users create an order and receive the order_number back
CREATE OR REPLACE FUNCTION public.create_public_lab_order(
  _customer_name text,
  _customer_email text,
  _customer_phone text,
  _ordered_tests jsonb,
  _sampling_type text,
  _location_id uuid,
  _home_address text,
  _preferred_date date,
  _notes text,
  _total_price_huf integer
)
RETURNS TABLE(id uuid, order_number text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _id uuid;
  _num text;
BEGIN
  IF _customer_name IS NULL OR _customer_email IS NULL OR _customer_phone IS NULL THEN
    RAISE EXCEPTION 'Missing required fields';
  END IF;
  IF _ordered_tests IS NULL OR jsonb_array_length(_ordered_tests) = 0 THEN
    RAISE EXCEPTION 'No tests selected';
  END IF;

  INSERT INTO public.lab_orders (
    customer_name, customer_email, customer_phone,
    ordered_tests, sampling_type, location_id, home_address,
    preferred_date, notes, total_price_huf, status
  ) VALUES (
    _customer_name, _customer_email, _customer_phone,
    _ordered_tests, _sampling_type, _location_id, _home_address,
    _preferred_date, _notes, _total_price_huf, 'pending'
  )
  RETURNING lab_orders.id, lab_orders.order_number INTO _id, _num;

  RETURN QUERY SELECT _id, _num;
END;
$$;

GRANT EXECUTE ON FUNCTION public.create_public_lab_order(text,text,text,jsonb,text,uuid,text,date,text,integer) TO anon, authenticated;