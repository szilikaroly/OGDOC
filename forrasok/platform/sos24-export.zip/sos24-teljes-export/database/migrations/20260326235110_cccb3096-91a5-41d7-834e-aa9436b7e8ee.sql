
-- Allow recipients to mark messages as read
CREATE POLICY "Recipients update messages"
ON public.messages
FOR UPDATE
TO authenticated
USING (auth.uid() = recipient_id)
WITH CHECK (auth.uid() = recipient_id);
