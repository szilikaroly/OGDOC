
-- 1. Service categories table
CREATE TABLE public.service_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  sort_order integer NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.service_categories ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Service categories readable by everyone" ON public.service_categories FOR SELECT TO public USING (true);
CREATE POLICY "Super admins manage service categories" ON public.service_categories FOR ALL TO public USING (has_role(auth.uid(), 'super_admin'::app_role));

-- 2. Extend locations table
ALTER TABLE public.locations
  ADD COLUMN IF NOT EXISTS email text,
  ADD COLUMN IF NOT EXISTS phone text,
  ADD COLUMN IF NOT EXISTS whatsapp text,
  ADD COLUMN IF NOT EXISTS google_maps_url text,
  ADD COLUMN IF NOT EXISTS responsible_user_id uuid,
  ADD COLUMN IF NOT EXISTS description text;

-- 3. SEO pages table
CREATE TABLE public.seo_pages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  page_path text NOT NULL UNIQUE,
  title text,
  description text,
  og_title text,
  og_description text,
  og_image text,
  keywords text,
  canonical_url text,
  noindex boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.seo_pages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "SEO pages readable by everyone" ON public.seo_pages FOR SELECT TO public USING (true);
CREATE POLICY "Super admins manage seo pages" ON public.seo_pages FOR ALL TO public USING (has_role(auth.uid(), 'super_admin'::app_role));
