
DROP FUNCTION IF EXISTS public.admin_get_recovery_status(uuid[]);

CREATE OR REPLACE FUNCTION public.admin_get_recovery_status(_user_ids uuid[])
 RETURNS TABLE(
   user_id uuid, email text,
   recovery_sent_at timestamptz, last_sign_in_at timestamptz, email_confirmed_at timestamptz,
   last_recovery_status text, last_recovery_error text, last_recovery_log_at timestamptz,
   user_created_at timestamptz, has_password boolean,
   last_admin_direct_at timestamptz, last_admin_direct_by uuid,
   last_action_kind text, last_action_at timestamptz
 )
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  IF NOT public.has_role(auth.uid(), 'super_admin'::app_role) THEN
    RAISE EXCEPTION 'forbidden: super_admin role required';
  END IF;

  RETURN QUERY
  WITH latest_email AS (
    SELECT DISTINCT ON (l.message_id)
      l.recipient_email, l.status, l.error_message, l.created_at
    FROM public.email_send_log l
    WHERE l.template_name = 'recovery'
      AND l.message_id IS NOT NULL
      AND l.recipient_email IS NOT NULL
    ORDER BY l.message_id, l.created_at DESC
  ), per_user_email AS (
    SELECT
      recipient_email,
      (ARRAY_AGG(status ORDER BY created_at DESC))[1] AS status,
      (ARRAY_AGG(error_message ORDER BY created_at DESC))[1] AS err,
      MAX(created_at) AS at
    FROM latest_email
    GROUP BY recipient_email
  ), latest_direct AS (
    SELECT DISTINCT ON ((se.metadata->>'target_user_id')::uuid)
      (se.metadata->>'target_user_id')::uuid AS target_user_id,
      se.user_id AS actor_user_id,
      se.created_at
    FROM public.security_events se
    WHERE se.event_type = 'admin_password_set'
      AND se.metadata ? 'target_user_id'
    ORDER BY (se.metadata->>'target_user_id')::uuid, se.created_at DESC
  )
  SELECT
    u.id,
    u.email::text,
    u.recovery_sent_at,
    u.last_sign_in_at,
    u.email_confirmed_at,
    p.status,
    p.err,
    p.at,
    u.created_at,
    (u.encrypted_password IS NOT NULL AND length(u.encrypted_password) > 0) AS has_password,
    d.created_at AS last_admin_direct_at,
    d.actor_user_id AS last_admin_direct_by,
    CASE
      WHEN d.created_at IS NULL AND p.at IS NULL AND u.recovery_sent_at IS NULL THEN NULL
      WHEN d.created_at IS NOT NULL
           AND d.created_at >= COALESCE(p.at, '-infinity'::timestamptz)
           AND d.created_at >= COALESCE(u.recovery_sent_at, '-infinity'::timestamptz)
        THEN 'admin_direct'
      ELSE 'email_recovery'
    END AS last_action_kind,
    GREATEST(
      COALESCE(d.created_at, '-infinity'::timestamptz),
      COALESCE(p.at, '-infinity'::timestamptz),
      COALESCE(u.recovery_sent_at, '-infinity'::timestamptz)
    ) AS last_action_at
  FROM auth.users u
  LEFT JOIN per_user_email p ON lower(p.recipient_email) = lower(u.email)
  LEFT JOIN latest_direct d ON d.target_user_id = u.id
  WHERE u.id = ANY(_user_ids);
END;
$function$;
