
ALTER TYPE public.referral_status ADD VALUE IF NOT EXISTS 'appointment_booked';
ALTER TYPE public.referral_status ADD VALUE IF NOT EXISTS 'questionnaire_filled';
ALTER TYPE public.referral_status ADD VALUE IF NOT EXISTS 'exam_started';

ALTER TABLE public.examinations ADD COLUMN IF NOT EXISTS workflow_status text DEFAULT 'started';
ALTER TABLE public.medical_opinions ADD COLUMN IF NOT EXISTS signature_data text;
