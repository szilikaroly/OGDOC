
-- 1) Security events table
CREATE TABLE public.security_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_type text NOT NULL,
  severity text NOT NULL DEFAULT 'info',
  user_id uuid,
  user_email text,
  table_name text,
  operation text,
  error_code text,
  error_message text,
  route text,
  user_agent text,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_security_events_created_at ON public.security_events(created_at DESC);
CREATE INDEX idx_security_events_user_id ON public.security_events(user_id);
CREATE INDEX idx_security_events_event_type ON public.security_events(event_type);
CREATE INDEX idx_security_events_severity ON public.security_events(severity);

GRANT SELECT ON public.security_events TO authenticated;
GRANT ALL ON public.security_events TO service_role;

ALTER TABLE public.security_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Super admins can view security events"
  ON public.security_events FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'super_admin'));

-- 2) Logging RPC (SECURITY DEFINER so any authenticated/anon client can log without table INSERT grant)
CREATE OR REPLACE FUNCTION public.log_security_event(
  _event_type text,
  _severity text DEFAULT 'warn',
  _table_name text DEFAULT NULL,
  _operation text DEFAULT NULL,
  _error_code text DEFAULT NULL,
  _error_message text DEFAULT NULL,
  _route text DEFAULT NULL,
  _user_agent text DEFAULT NULL,
  _metadata jsonb DEFAULT '{}'::jsonb
) RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _id uuid;
  _uid uuid;
  _email text;
BEGIN
  BEGIN
    _uid := auth.uid();
  EXCEPTION WHEN OTHERS THEN
    _uid := NULL;
  END;

  IF _uid IS NOT NULL THEN
    SELECT email INTO _email FROM auth.users WHERE id = _uid;
  END IF;

  -- Truncate large messages to keep table small
  INSERT INTO public.security_events (
    event_type, severity, user_id, user_email, table_name, operation,
    error_code, error_message, route, user_agent, metadata
  ) VALUES (
    _event_type,
    COALESCE(_severity, 'warn'),
    _uid,
    _email,
    _table_name,
    _operation,
    _error_code,
    LEFT(COALESCE(_error_message, ''), 2000),
    _route,
    LEFT(COALESCE(_user_agent, ''), 500),
    COALESCE(_metadata, '{}'::jsonb)
  ) RETURNING id INTO _id;

  RETURN _id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.log_security_event(text,text,text,text,text,text,text,text,jsonb)
  TO anon, authenticated, service_role;

-- 3) Aggregation helper for the alert cron
CREATE OR REPLACE FUNCTION public.security_denials_summary(_since timestamptz)
RETURNS TABLE(user_id uuid, user_email text, denial_count bigint, last_seen timestamptz, sample_messages text[])
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    user_id,
    MAX(user_email) AS user_email,
    COUNT(*) AS denial_count,
    MAX(created_at) AS last_seen,
    (ARRAY_AGG(DISTINCT LEFT(error_message, 200)))[1:5] AS sample_messages
  FROM public.security_events
  WHERE event_type = 'rls_denied'
    AND created_at >= _since
  GROUP BY user_id;
$$;

GRANT EXECUTE ON FUNCTION public.security_denials_summary(timestamptz) TO service_role;
