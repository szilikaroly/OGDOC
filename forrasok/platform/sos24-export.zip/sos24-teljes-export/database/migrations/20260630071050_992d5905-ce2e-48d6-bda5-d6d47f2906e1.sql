
-- 1) Trigger function: notify all super_admins on bad recovery email status
CREATE OR REPLACE FUNCTION public.notify_admins_on_recovery_failure()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  _bad_statuses text[] := ARRAY['failed','dlq','bounced','complained','suppressed'];
  _title text;
  _body text;
BEGIN
  IF NEW.template_name <> 'recovery' THEN
    RETURN NEW;
  END IF;
  IF NOT (NEW.status = ANY(_bad_statuses)) THEN
    RETURN NEW;
  END IF;
  -- Only fire when status transitions into a bad state (or first insert)
  IF TG_OP = 'UPDATE' AND OLD.status = NEW.status THEN
    RETURN NEW;
  END IF;

  _title := CASE
    WHEN NEW.status = 'suppressed' THEN 'Letiltott jelszó-visszaállító e-mail'
    ELSE 'Sikertelen jelszó-visszaállító e-mail'
  END;
  _body := COALESCE(NEW.recipient_email, '?') || ' — státusz: ' || NEW.status
    || CASE WHEN NEW.error_message IS NOT NULL AND length(NEW.error_message) > 0
            THEN ' — ' || LEFT(NEW.error_message, 240)
            ELSE '' END;

  INSERT INTO public.notifications (user_id, type, title, body, link)
  SELECT ur.user_id, 'recovery_alert', _title, _body, '/admin/users'
  FROM public.user_roles ur
  WHERE ur.role = 'super_admin'::app_role;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_notify_admins_recovery_failure ON public.email_send_log;
CREATE TRIGGER trg_notify_admins_recovery_failure
AFTER INSERT OR UPDATE OF status ON public.email_send_log
FOR EACH ROW
EXECUTE FUNCTION public.notify_admins_on_recovery_failure();

-- 2) Summary RPC for AdminUsers page
CREATE OR REPLACE FUNCTION public.admin_recovery_failures_summary(_since timestamptz DEFAULT (now() - interval '7 days'))
RETURNS TABLE(
  total_failures bigint,
  failed_count bigint,
  suppressed_count bigint,
  bounced_count bigint,
  complained_count bigint,
  dlq_count bigint,
  affected_recipients bigint,
  last_event_at timestamptz,
  recent jsonb
)
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  IF NOT public.has_role(auth.uid(), 'super_admin'::app_role) THEN
    RAISE EXCEPTION 'forbidden: super_admin role required';
  END IF;

  RETURN QUERY
  WITH latest AS (
    SELECT DISTINCT ON (l.message_id)
      l.message_id, l.recipient_email, l.status, l.error_message, l.created_at
    FROM public.email_send_log l
    WHERE l.template_name = 'recovery'
      AND l.message_id IS NOT NULL
      AND l.created_at >= _since
    ORDER BY l.message_id, l.created_at DESC
  ), bad AS (
    SELECT * FROM latest
    WHERE status IN ('failed','dlq','bounced','complained','suppressed')
  )
  SELECT
    (SELECT count(*) FROM bad),
    (SELECT count(*) FROM bad WHERE status = 'failed'),
    (SELECT count(*) FROM bad WHERE status = 'suppressed'),
    (SELECT count(*) FROM bad WHERE status = 'bounced'),
    (SELECT count(*) FROM bad WHERE status = 'complained'),
    (SELECT count(*) FROM bad WHERE status = 'dlq'),
    (SELECT count(DISTINCT lower(recipient_email)) FROM bad),
    (SELECT max(created_at) FROM bad),
    COALESCE((
      SELECT jsonb_agg(row_to_json(t) ORDER BY t.created_at DESC)
      FROM (
        SELECT recipient_email, status, error_message, created_at
        FROM bad
        ORDER BY created_at DESC
        LIMIT 10
      ) t
    ), '[]'::jsonb);
END;
$$;

REVOKE ALL ON FUNCTION public.admin_recovery_failures_summary(timestamptz) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.admin_recovery_failures_summary(timestamptz) TO authenticated;
