-- Medications reference table
CREATE TABLE public.medications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE
);
ALTER TABLE public.medications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Medications readable by authenticated"
  ON public.medications FOR SELECT TO authenticated USING (true);

-- Medication requests table
CREATE TABLE public.medication_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id uuid NOT NULL,
  medication_name text NOT NULL,
  request_type text NOT NULL DEFAULT 'allando',
  notes text,
  status text NOT NULL DEFAULT 'pending',
  doctor_response text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.medication_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Patient manages own med requests"
  ON public.medication_requests FOR ALL TO authenticated
  USING (auth.uid() = patient_id)
  WITH CHECK (auth.uid() = patient_id);

CREATE POLICY "Haziorvos manages med requests"
  ON public.medication_requests FOR ALL TO authenticated
  USING (has_role(auth.uid(), 'haziorvos'))
  WITH CHECK (has_role(auth.uid(), 'haziorvos'));

CREATE POLICY "Super admin manages med requests"
  ON public.medication_requests FOR ALL TO authenticated
  USING (has_role(auth.uid(), 'super_admin'))
  WITH CHECK (has_role(auth.uid(), 'super_admin'));

-- updated_at trigger
CREATE TRIGGER update_medication_requests_updated_at
  BEFORE UPDATE ON public.medication_requests
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();