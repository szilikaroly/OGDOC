
-- Page views tracking table
CREATE TABLE public.page_views (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  page_path text NOT NULL,
  referrer text,
  user_agent text,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.page_views ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert page views"
ON public.page_views FOR INSERT
TO anon, authenticated
WITH CHECK (true);

CREATE POLICY "Admins can read page views"
ON public.page_views FOR SELECT
TO authenticated
USING (has_role(auth.uid(), 'super_admin'::app_role));

CREATE INDEX idx_page_views_path ON public.page_views (page_path);
CREATE INDEX idx_page_views_created ON public.page_views (created_at);

-- SEO audit scores table
CREATE TABLE public.seo_audit_scores (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  page_path text NOT NULL,
  score integer NOT NULL DEFAULT 0,
  grade text NOT NULL DEFAULT 'F',
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.seo_audit_scores ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins manage audit scores"
ON public.seo_audit_scores FOR ALL
TO authenticated
USING (has_role(auth.uid(), 'super_admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'super_admin'::app_role));

CREATE INDEX idx_seo_audit_scores_path ON public.seo_audit_scores (page_path);

-- Web vitals table
CREATE TABLE public.web_vitals (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  metric_name text NOT NULL,
  value numeric NOT NULL,
  page_path text NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.web_vitals ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert web vitals"
ON public.web_vitals FOR INSERT
TO anon, authenticated
WITH CHECK (true);

CREATE POLICY "Admins can read web vitals"
ON public.web_vitals FOR SELECT
TO authenticated
USING (has_role(auth.uid(), 'super_admin'::app_role));

CREATE INDEX idx_web_vitals_metric ON public.web_vitals (metric_name);
CREATE INDEX idx_web_vitals_created ON public.web_vitals (created_at);
