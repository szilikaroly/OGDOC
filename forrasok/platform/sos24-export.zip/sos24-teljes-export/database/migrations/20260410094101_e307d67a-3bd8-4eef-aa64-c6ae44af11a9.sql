-- Lab pricing config: per-test price overrides (admin editable)
CREATE TABLE public.lab_pricing_config (
  test_id TEXT PRIMARY KEY,
  points INTEGER NOT NULL DEFAULT 10,
  price_huf INTEGER NOT NULL DEFAULT 0,
  updated_by UUID,
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.lab_pricing_config ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read lab pricing" ON public.lab_pricing_config
  FOR SELECT TO anon, authenticated USING (true);

CREATE POLICY "Admins manage lab pricing" ON public.lab_pricing_config
  FOR ALL TO authenticated
  USING (has_role(auth.uid(), 'super_admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'super_admin'::app_role));

CREATE POLICY "Uzemorvos manages lab pricing" ON public.lab_pricing_config
  FOR ALL TO authenticated
  USING (has_role(auth.uid(), 'uzemorvos'::app_role))
  WITH CHECK (has_role(auth.uid(), 'uzemorvos'::app_role));

-- Lab markup config: global markup + home sampling fee
CREATE TABLE public.lab_markup_config (
  id INTEGER PRIMARY KEY DEFAULT 1,
  markup_huf INTEGER NOT NULL DEFAULT 4000,
  home_sampling_fee_huf INTEGER NOT NULL DEFAULT 8000,
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.lab_markup_config ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read lab markup" ON public.lab_markup_config
  FOR SELECT TO anon, authenticated USING (true);

CREATE POLICY "Admins manage lab markup" ON public.lab_markup_config
  FOR ALL TO authenticated
  USING (has_role(auth.uid(), 'super_admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'super_admin'::app_role));

-- Insert default config row
INSERT INTO public.lab_markup_config (id, markup_huf, home_sampling_fee_huf) VALUES (1, 4000, 8000);

-- Lab orders: public orders (no auth required)
CREATE TABLE public.lab_orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number TEXT NOT NULL DEFAULT '',
  customer_name TEXT NOT NULL,
  customer_email TEXT NOT NULL,
  customer_phone TEXT NOT NULL,
  ordered_tests JSONB NOT NULL DEFAULT '[]'::jsonb,
  sampling_type TEXT NOT NULL DEFAULT 'location',
  location_id UUID REFERENCES public.locations(id),
  home_address TEXT,
  preferred_date DATE,
  notes TEXT,
  total_price_huf INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'pending',
  user_id UUID,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.lab_orders ENABLE ROW LEVEL SECURITY;

-- Anyone can create orders (public webshop)
CREATE POLICY "Anyone can create lab orders" ON public.lab_orders
  FOR INSERT TO anon, authenticated
  WITH CHECK (true);

-- Admins and uzemorvos can manage all orders
CREATE POLICY "Admins manage lab orders" ON public.lab_orders
  FOR ALL TO authenticated
  USING (has_role(auth.uid(), 'super_admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'super_admin'::app_role));

CREATE POLICY "Uzemorvos manages lab orders" ON public.lab_orders
  FOR ALL TO authenticated
  USING (has_role(auth.uid(), 'uzemorvos'::app_role))
  WITH CHECK (has_role(auth.uid(), 'uzemorvos'::app_role));

-- Logged-in users can see their own orders
CREATE POLICY "Users see own lab orders" ON public.lab_orders
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

-- Auto-generate order number
CREATE OR REPLACE FUNCTION public.generate_lab_order_number()
  RETURNS TRIGGER
  LANGUAGE plpgsql
  SECURITY DEFINER
  SET search_path = public
AS $$
DECLARE seq_num INTEGER;
BEGIN
  SELECT COALESCE(MAX(
    CASE WHEN order_number ~ '^LO-\d{4}-\d+$'
    THEN CAST(SPLIT_PART(order_number, '-', 3) AS INTEGER)
    ELSE 0 END
  ), 0) + 1
  INTO seq_num
  FROM public.lab_orders
  WHERE order_number LIKE 'LO-' || EXTRACT(YEAR FROM now())::text || '-%';

  NEW.order_number := 'LO-' || EXTRACT(YEAR FROM now())::text || '-' || LPAD(seq_num::text, 4, '0');
  RETURN NEW;
END;
$$;

CREATE TRIGGER set_lab_order_number
  BEFORE INSERT ON public.lab_orders
  FOR EACH ROW
  EXECUTE FUNCTION public.generate_lab_order_number();

-- Updated_at trigger
CREATE TRIGGER update_lab_orders_updated_at
  BEFORE UPDATE ON public.lab_orders
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();