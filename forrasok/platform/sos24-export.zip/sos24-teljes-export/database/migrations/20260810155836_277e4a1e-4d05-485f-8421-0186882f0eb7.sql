ALTER TABLE public.accident_reports ADD COLUMN IF NOT EXISTS icd_codes text[] DEFAULT '{}';
ALTER TABLE public.referrals ADD COLUMN IF NOT EXISTS icd_codes text[] DEFAULT '{}';
ALTER TABLE public.medical_opinions ADD COLUMN IF NOT EXISTS icd_codes text[] DEFAULT '{}';

COMMENT ON COLUMN public.accident_reports.icd_codes IS 'Kiválasztott BNO/ICD kódok a balesethez';
COMMENT ON COLUMN public.referrals.icd_codes IS 'Kiválasztott BNO/ICD kódok a beutalóhoz';
COMMENT ON COLUMN public.medical_opinions.icd_codes IS 'Kiválasztott BNO/ICD kódok a szakvéleményhez';