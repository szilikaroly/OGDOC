CREATE POLICY "Authenticated see user_roles for messaging"
ON public.user_roles
FOR SELECT
TO authenticated
USING (true);