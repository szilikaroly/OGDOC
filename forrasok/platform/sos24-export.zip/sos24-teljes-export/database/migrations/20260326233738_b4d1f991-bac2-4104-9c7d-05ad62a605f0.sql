
-- 1. Create referral_status enum
CREATE TYPE public.referral_status AS ENUM ('draft', 'sent', 'completed');

-- 2. Create referrals table
CREATE TABLE public.referrals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid REFERENCES public.companies(id) ON DELETE CASCADE NOT NULL,
  employee_id uuid NOT NULL,
  created_by uuid NOT NULL,
  position text,
  feor text,
  unit_name text,
  exam_reason text NOT NULL,
  risk_factors jsonb DEFAULT '{}'::jsonb,
  status referral_status NOT NULL DEFAULT 'draft',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 3. Create examinations table
CREATE TABLE public.examinations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id uuid NOT NULL,
  doctor_id uuid NOT NULL,
  referral_id uuid REFERENCES public.referrals(id) ON DELETE SET NULL,
  appointment_id uuid REFERENCES public.appointments(id) ON DELETE SET NULL,
  exam_type text NOT NULL,
  patient_data jsonb DEFAULT '{}'::jsonb,
  clinical_findings jsonb DEFAULT '{}'::jsonb,
  result public.opinion_status NOT NULL DEFAULT 'alkalmas',
  restrictions text,
  valid_until date,
  ai_notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- 4. Create patient_cards table
CREATE TABLE public.patient_cards (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL UNIQUE,
  drug_allergies text,
  chronic_diseases text,
  regular_medications text,
  family_history jsonb DEFAULT '{}'::jsonb,
  surgeries text,
  smoking jsonb DEFAULT '{}'::jsonb,
  alcohol text,
  last_chest_xray date,
  last_gynecology date,
  pregnancies text,
  other_notes text,
  occupation text,
  employer_name text,
  marital_status text,
  drivers_license boolean DEFAULT false,
  previous_doctor text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 5. Enable RLS
ALTER TABLE public.referrals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.examinations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.patient_cards ENABLE ROW LEVEL SECURITY;

-- 6. RLS for referrals
CREATE POLICY "Super admins manage referrals" ON public.referrals FOR ALL TO public
  USING (public.has_role(auth.uid(), 'super_admin'));

CREATE POLICY "Munkaltato inserts referrals" ON public.referrals FOR INSERT TO public
  WITH CHECK (auth.uid() = created_by AND public.has_role(auth.uid(), 'munkaltato'));

CREATE POLICY "Munkaltato sees own company referrals" ON public.referrals FOR SELECT TO public
  USING (EXISTS (
    SELECT 1 FROM public.user_company_relations ucr
    WHERE ucr.user_id = auth.uid() AND ucr.company_id = referrals.company_id AND ucr.role = 'munkaltato'
  ));

CREATE POLICY "Munkaltato updates own company referrals" ON public.referrals FOR UPDATE TO public
  USING (EXISTS (
    SELECT 1 FROM public.user_company_relations ucr
    WHERE ucr.user_id = auth.uid() AND ucr.company_id = referrals.company_id AND ucr.role = 'munkaltato'
  ));

CREATE POLICY "Doctors see all referrals" ON public.referrals FOR SELECT TO public
  USING (public.has_role(auth.uid(), 'uzemorvos') OR public.has_role(auth.uid(), 'haziorvos'));

CREATE POLICY "Employee sees own referrals" ON public.referrals FOR SELECT TO public
  USING (auth.uid() = employee_id);

-- 7. RLS for examinations
CREATE POLICY "Super admins manage examinations" ON public.examinations FOR ALL TO public
  USING (public.has_role(auth.uid(), 'super_admin'));

CREATE POLICY "Doctor manages own examinations" ON public.examinations FOR ALL TO public
  USING (auth.uid() = doctor_id);

CREATE POLICY "Patient sees own examinations" ON public.examinations FOR SELECT TO public
  USING (auth.uid() = patient_id);

CREATE POLICY "Munkaltato sees company employee exams" ON public.examinations FOR SELECT TO public
  USING (EXISTS (
    SELECT 1 FROM public.user_company_relations ucr
    JOIN public.user_company_relations ucr2 ON ucr2.company_id = ucr.company_id
    WHERE ucr.user_id = auth.uid() AND ucr.role = 'munkaltato'
      AND ucr2.user_id = examinations.patient_id
  ));

-- 8. RLS for patient_cards
CREATE POLICY "Super admins manage patient_cards" ON public.patient_cards FOR ALL TO public
  USING (public.has_role(auth.uid(), 'super_admin'));

CREATE POLICY "User manages own patient card" ON public.patient_cards FOR ALL TO public
  USING (auth.uid() = user_id);

CREATE POLICY "Doctors see patient cards" ON public.patient_cards FOR SELECT TO public
  USING (public.has_role(auth.uid(), 'haziorvos') OR public.has_role(auth.uid(), 'uzemorvos'));

-- 9. Updated_at triggers
CREATE TRIGGER update_referrals_updated_at BEFORE UPDATE ON public.referrals
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_patient_cards_updated_at BEFORE UPDATE ON public.patient_cards
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 10. Enable realtime for messages
ALTER PUBLICATION supabase_realtime ADD TABLE public.messages;
