CREATE TABLE public.bulk_import_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  import_type text NOT NULL DEFAULT 'patients',
  file_name text,
  total_rows integer NOT NULL DEFAULT 0,
  new_count integer NOT NULL DEFAULT 0,
  duplicate_count integer NOT NULL DEFAULT 0,
  error_count integer NOT NULL DEFAULT 0,
  success_count integer NOT NULL DEFAULT 0,
  details jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT ON public.bulk_import_logs TO authenticated;
GRANT ALL ON public.bulk_import_logs TO service_role;

ALTER TABLE public.bulk_import_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users read own import logs"
  ON public.bulk_import_logs FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'super_admin'::app_role));

CREATE POLICY "Users insert own import logs"
  ON public.bulk_import_logs FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE INDEX idx_bulk_import_logs_user_created ON public.bulk_import_logs (user_id, created_at DESC);