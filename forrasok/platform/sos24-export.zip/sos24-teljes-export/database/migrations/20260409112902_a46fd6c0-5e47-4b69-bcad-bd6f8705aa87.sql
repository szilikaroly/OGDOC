CREATE TABLE public.work_area_sds_documents (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  work_area_id UUID NOT NULL REFERENCES public.work_areas(id) ON DELETE CASCADE,
  file_name TEXT NOT NULL,
  file_path TEXT NOT NULL,
  substance_name TEXT,
  cas_number TEXT,
  ec_number TEXT,
  is_mixture BOOLEAN DEFAULT false,
  mixture_components JSONB DEFAULT '[]'::jsonb,
  analysis_data JSONB,
  risk_level TEXT,
  uploaded_by UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.work_area_sds_documents ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view SDS documents"
  ON public.work_area_sds_documents FOR SELECT
  TO authenticated USING (true);

CREATE POLICY "Authenticated users can insert SDS documents"
  ON public.work_area_sds_documents FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = uploaded_by);

CREATE POLICY "Users can update their own SDS documents"
  ON public.work_area_sds_documents FOR UPDATE
  TO authenticated USING (auth.uid() = uploaded_by);

CREATE POLICY "Users can delete their own SDS documents"
  ON public.work_area_sds_documents FOR DELETE
  TO authenticated USING (auth.uid() = uploaded_by);

CREATE POLICY "Super admins can manage SDS documents"
  ON public.work_area_sds_documents FOR ALL
  TO authenticated USING (public.has_role(auth.uid(), 'super_admin'));

CREATE POLICY "Doctors can manage SDS documents"
  ON public.work_area_sds_documents FOR ALL
  TO authenticated USING (public.has_role(auth.uid(), 'uzemorvos'));

CREATE TRIGGER update_work_area_sds_documents_updated_at
  BEFORE UPDATE ON public.work_area_sds_documents
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

INSERT INTO storage.buckets (id, name, public) VALUES ('sds-documents', 'sds-documents', false)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Authenticated users can upload SDS"
  ON storage.objects FOR INSERT
  TO authenticated WITH CHECK (bucket_id = 'sds-documents');

CREATE POLICY "Authenticated users can view SDS"
  ON storage.objects FOR SELECT
  TO authenticated USING (bucket_id = 'sds-documents');

CREATE POLICY "Users can delete own SDS files"
  ON storage.objects FOR DELETE
  TO authenticated USING (bucket_id = 'sds-documents' AND auth.uid()::text = (storage.foldername(name))[1]);