
-- 1) accident-photos: replace permissive policies with owner-folder + role-based access
drop policy if exists "Authenticated users can upload accident photos" on storage.objects;
drop policy if exists "Authenticated users can view accident photos" on storage.objects;

create policy "Users upload own accident photos"
on storage.objects for insert to authenticated
with check (
  bucket_id = 'accident-photos'
  and (storage.foldername(name))[1] = auth.uid()::text
);

create policy "Users read own accident photos"
on storage.objects for select to authenticated
using (
  bucket_id = 'accident-photos'
  and (storage.foldername(name))[1] = auth.uid()::text
);

create policy "Doctors and admins read accident photos"
on storage.objects for select to authenticated
using (
  bucket_id = 'accident-photos'
  and (
    has_role(auth.uid(), 'super_admin'::app_role)
    or has_role(auth.uid(), 'uzemorvos'::app_role)
    or has_role(auth.uid(), 'haziorvos'::app_role)
  )
);

-- 2) medical-documents: drop overly broad "Service upload" that lets any authenticated upload anywhere
drop policy if exists "Service upload medical docs" on storage.objects;
-- "Users upload own medical docs" already restricts to own folder; keep it.

-- 3) lab_orders: explicit anon insert (only when user_id IS NULL)
drop policy if exists "Anonymous create guest lab orders" on public.lab_orders;
create policy "Anonymous create guest lab orders"
on public.lab_orders for insert to anon
with check (user_id is null);

-- 4) notifications: explicit insert policy (own only); service role bypasses RLS
drop policy if exists "Users insert own notifications" on public.notifications;
create policy "Users insert own notifications"
on public.notifications for insert to authenticated
with check (auth.uid() = user_id);

-- 5) Revoke execute on internal SECURITY DEFINER helpers from anon/authenticated
revoke execute on function public.audit_trigger_func() from public, anon, authenticated;
revoke execute on function public.auto_update_referral_on_questionnaire() from public, anon, authenticated;
revoke execute on function public.handle_new_user() from public, anon, authenticated;
revoke execute on function public.update_updated_at_column() from public, anon, authenticated;
revoke execute on function public.delete_email(text, bigint) from public, anon, authenticated;
revoke execute on function public.enqueue_email(text, jsonb) from public, anon, authenticated;
revoke execute on function public.read_email_batch(text, integer, integer) from public, anon, authenticated;
revoke execute on function public.move_to_dlq(text, text, bigint, jsonb) from public, anon, authenticated;
revoke execute on function public.notify_admins_on_recovery_failure() from public, anon, authenticated;
revoke execute on function public.generate_lab_order_number() from public, anon, authenticated;
revoke execute on function public.generate_lab_request_number() from public, anon, authenticated;
revoke execute on function public.security_denials_summary(timestamp with time zone) from public, anon, authenticated;
