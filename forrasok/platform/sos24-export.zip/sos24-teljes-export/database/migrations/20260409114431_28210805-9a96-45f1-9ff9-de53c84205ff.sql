
-- Company TEÁOR codes junction table
CREATE TABLE public.company_teaor_codes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  company_id UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  teaor_code TEXT NOT NULL,
  teaor_name TEXT,
  is_primary BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by UUID,
  UNIQUE(company_id, teaor_code)
);

ALTER TABLE public.company_teaor_codes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Company members can view teaor codes"
  ON public.company_teaor_codes FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM user_company_relations
    WHERE user_company_relations.user_id = auth.uid()
      AND user_company_relations.company_id = company_teaor_codes.company_id
      AND user_company_relations.is_active = true
  ));

CREATE POLICY "Munkaltato manages own company teaor codes"
  ON public.company_teaor_codes FOR ALL TO authenticated
  USING (EXISTS (
    SELECT 1 FROM user_company_relations
    WHERE user_company_relations.user_id = auth.uid()
      AND user_company_relations.company_id = company_teaor_codes.company_id
      AND user_company_relations.role = 'munkaltato'
      AND user_company_relations.is_active = true
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM user_company_relations
    WHERE user_company_relations.user_id = auth.uid()
      AND user_company_relations.company_id = company_teaor_codes.company_id
      AND user_company_relations.role = 'munkaltato'
      AND user_company_relations.is_active = true
  ));

CREATE POLICY "Super admins manage teaor codes"
  ON public.company_teaor_codes FOR ALL TO authenticated
  USING (has_role(auth.uid(), 'super_admin'))
  WITH CHECK (has_role(auth.uid(), 'super_admin'));

CREATE POLICY "Uzemorvos manages teaor codes"
  ON public.company_teaor_codes FOR ALL TO authenticated
  USING (has_role(auth.uid(), 'uzemorvos'))
  WITH CHECK (has_role(auth.uid(), 'uzemorvos'));

-- Accident reports table (MBJKV 2025)
CREATE TABLE public.accident_reports (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  company_id UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  employee_id UUID NOT NULL,
  created_by UUID NOT NULL,
  status TEXT NOT NULL DEFAULT 'draft',

  registration_number TEXT,
  territorial_code TEXT,
  report_type TEXT DEFAULT '1',

  -- (A) Employer data
  employer_name TEXT,
  employer_address TEXT,
  employer_phone TEXT,
  employer_fax TEXT,
  employer_mobile TEXT,
  employer_email TEXT,
  employer_tax_number TEXT,
  employer_tax_id TEXT,
  employer_org_form TEXT,
  employer_teaor_main TEXT,
  employer_teaor_local TEXT,
  employer_total_staff_category TEXT,
  employer_local_staff_category TEXT,

  -- (B) Injured person data
  injured_name TEXT,
  injured_taj TEXT,
  injured_birth_name TEXT,
  injured_mother_name TEXT,
  injured_birth_place TEXT,
  injured_birth_date DATE,
  injured_gender TEXT,
  injured_citizenship TEXT,
  injured_address TEXT,
  injured_phone TEXT,
  injured_feor_code TEXT,
  injured_feor_name TEXT,
  injured_employment_type TEXT,
  injured_employment_nature TEXT,

  -- (C) Accident data
  accident_date DATE,
  accident_time_hour TEXT,
  injury_work_hour TEXT,
  injury_type_code TEXT,
  injured_body_part_code TEXT,
  work_location_code TEXT,
  accident_geo_location TEXT,
  accident_geo_code TEXT,
  injury_severity_code TEXT,
  disability_days INTEGER,

  -- (D) Detailed description
  detailed_description TEXT,

  -- (E) Additional info
  workplace_environment TEXT,
  work_process TEXT,
  physical_activity TEXT,
  physical_activity_material TEXT,
  triggering_event TEXT,
  triggering_event_material TEXT,
  injury_contact_mode TEXT,
  injury_contact_material TEXT,
  personal_factor_injured TEXT,
  personal_factor_employer TEXT,
  safety_device_guard TEXT,
  safety_device_protection TEXT,
  safety_device_signal TEXT,
  safety_device_ppe TEXT,
  safety_device_other TEXT,

  -- (F) Causes
  accident_causes TEXT,

  -- (G) Prevention
  prevention_measures TEXT,

  -- (H) Attachments
  attachments_notes TEXT,

  -- (I) Investigators
  safety_rep_name TEXT,
  safety_rep_date DATE,
  safety_rep_agreement TEXT,
  investigator_name TEXT,
  investigator_date DATE,
  investigator_cert_no TEXT,
  doctor_name TEXT,
  doctor_date DATE,
  doctor_stamp_no TEXT,
  employer_rep_name TEXT,
  employer_rep_position TEXT,
  employer_rep_date DATE,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.accident_reports ENABLE ROW LEVEL SECURITY;

CREATE TRIGGER update_accident_reports_updated_at
  BEFORE UPDATE ON public.accident_reports
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- RLS policies
CREATE POLICY "Munkaltato manages own company accidents"
  ON public.accident_reports FOR ALL TO authenticated
  USING (EXISTS (
    SELECT 1 FROM user_company_relations
    WHERE user_company_relations.user_id = auth.uid()
      AND user_company_relations.company_id = accident_reports.company_id
      AND user_company_relations.role = 'munkaltato'
      AND user_company_relations.is_active = true
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM user_company_relations
    WHERE user_company_relations.user_id = auth.uid()
      AND user_company_relations.company_id = accident_reports.company_id
      AND user_company_relations.role = 'munkaltato'
      AND user_company_relations.is_active = true
  ));

CREATE POLICY "Employee sees own accidents"
  ON public.accident_reports FOR SELECT TO authenticated
  USING (auth.uid() = employee_id);

CREATE POLICY "Super admins manage accidents"
  ON public.accident_reports FOR ALL TO authenticated
  USING (has_role(auth.uid(), 'super_admin'))
  WITH CHECK (has_role(auth.uid(), 'super_admin'));

CREATE POLICY "Uzemorvos manages accidents"
  ON public.accident_reports FOR ALL TO authenticated
  USING (has_role(auth.uid(), 'uzemorvos'))
  WITH CHECK (has_role(auth.uid(), 'uzemorvos'));
