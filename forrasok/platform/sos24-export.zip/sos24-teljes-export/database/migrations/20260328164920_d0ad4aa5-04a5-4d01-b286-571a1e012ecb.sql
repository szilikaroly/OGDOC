CREATE POLICY "Munkaltato updates employee position and risks"
ON public.user_company_relations
FOR UPDATE
TO authenticated
USING (is_company_member(auth.uid(), company_id, 'munkaltato'::app_role))
WITH CHECK (is_company_member(auth.uid(), company_id, 'munkaltato'::app_role));