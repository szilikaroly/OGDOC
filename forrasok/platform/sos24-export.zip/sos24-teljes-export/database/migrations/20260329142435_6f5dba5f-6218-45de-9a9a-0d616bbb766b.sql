
-- Food journal table
CREATE TABLE public.food_journal (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  entry_date date NOT NULL DEFAULT CURRENT_DATE,
  meal_type text NOT NULL DEFAULT 'snack',
  food_description text,
  calories_estimated integer,
  protein_g numeric,
  carbs_g numeric,
  fat_g numeric,
  fiber_g numeric,
  image_url text,
  ai_analyzed boolean NOT NULL DEFAULT false,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.food_journal ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage own food journal" ON public.food_journal FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Haziorvos sees food journal" ON public.food_journal FOR SELECT USING (has_role(auth.uid(), 'haziorvos'));
CREATE POLICY "Uzemorvos sees food journal" ON public.food_journal FOR SELECT USING (has_role(auth.uid(), 'uzemorvos'));
CREATE POLICY "Super admins manage food journal" ON public.food_journal FOR ALL USING (has_role(auth.uid(), 'super_admin'));

-- Stool journal table
CREATE TABLE public.stool_journal (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  entry_date date NOT NULL DEFAULT CURRENT_DATE,
  bristol_type integer CHECK (bristol_type >= 1 AND bristol_type <= 7),
  color text,
  blood_present boolean NOT NULL DEFAULT false,
  mucus_present boolean NOT NULL DEFAULT false,
  pain_level integer CHECK (pain_level >= 0 AND pain_level <= 10),
  image_url text,
  ai_analyzed boolean NOT NULL DEFAULT false,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.stool_journal ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage own stool journal" ON public.stool_journal FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Haziorvos sees stool journal" ON public.stool_journal FOR SELECT USING (has_role(auth.uid(), 'haziorvos'));
CREATE POLICY "Uzemorvos sees stool journal" ON public.stool_journal FOR SELECT USING (has_role(auth.uid(), 'uzemorvos'));
CREATE POLICY "Super admins manage stool journal" ON public.stool_journal FOR ALL USING (has_role(auth.uid(), 'super_admin'));
