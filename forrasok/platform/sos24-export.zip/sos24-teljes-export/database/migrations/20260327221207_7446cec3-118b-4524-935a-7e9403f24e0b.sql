
-- Audit logs table
CREATE TABLE public.audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  table_name text NOT NULL,
  record_id uuid NOT NULL,
  action text NOT NULL, -- INSERT, UPDATE, DELETE
  old_data jsonb,
  new_data jsonb,
  changed_fields text[],
  user_id uuid,
  ip_address text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

-- Super admins see all audit logs
CREATE POLICY "Super admins see audit logs" ON public.audit_logs
  FOR SELECT TO authenticated
  USING (has_role(auth.uid(), 'super_admin'));

-- Users see audit logs related to their own data
CREATE POLICY "Users see own audit logs" ON public.audit_logs
  FOR SELECT TO authenticated
  USING (
    (new_data->>'patient_id' = auth.uid()::text) OR
    (new_data->>'user_id' = auth.uid()::text) OR
    (old_data->>'patient_id' = auth.uid()::text) OR
    (old_data->>'user_id' = auth.uid()::text)
  );

-- Service/triggers can insert
CREATE POLICY "Service inserts audit logs" ON public.audit_logs
  FOR INSERT WITH CHECK (true);

-- Create the audit trigger function
CREATE OR REPLACE FUNCTION public.audit_trigger_func()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _old_data jsonb;
  _new_data jsonb;
  _changed text[];
  _user_id uuid;
  _record_id uuid;
  _key text;
BEGIN
  -- Try to get the current user
  BEGIN
    _user_id := auth.uid();
  EXCEPTION WHEN OTHERS THEN
    _user_id := NULL;
  END;

  IF TG_OP = 'DELETE' THEN
    _old_data := to_jsonb(OLD);
    _new_data := NULL;
    _record_id := OLD.id;
    _changed := NULL;
  ELSIF TG_OP = 'INSERT' THEN
    _old_data := NULL;
    _new_data := to_jsonb(NEW);
    _record_id := NEW.id;
    _changed := NULL;
  ELSIF TG_OP = 'UPDATE' THEN
    _old_data := to_jsonb(OLD);
    _new_data := to_jsonb(NEW);
    _record_id := NEW.id;
    -- Calculate changed fields
    SELECT array_agg(key) INTO _changed
    FROM jsonb_each(_new_data) AS n(key, value)
    WHERE _old_data->key IS DISTINCT FROM n.value
      AND key NOT IN ('updated_at', 'created_at');
  END IF;

  INSERT INTO public.audit_logs (table_name, record_id, action, old_data, new_data, changed_fields, user_id)
  VALUES (TG_TABLE_NAME, _record_id, TG_OP, _old_data, _new_data, _changed, _user_id);

  IF TG_OP = 'DELETE' THEN
    RETURN OLD;
  END IF;
  RETURN NEW;
END;
$$;

-- Attach triggers to examinations
CREATE TRIGGER audit_examinations
  AFTER INSERT OR UPDATE OR DELETE ON public.examinations
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();

-- Attach triggers to medical_opinions
CREATE TRIGGER audit_medical_opinions
  AFTER INSERT OR UPDATE OR DELETE ON public.medical_opinions
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();

-- Attach triggers to patient_cards
CREATE TRIGGER audit_patient_cards
  AFTER INSERT OR UPDATE OR DELETE ON public.patient_cards
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();

-- Also audit documents and referrals
CREATE TRIGGER audit_documents
  AFTER INSERT OR UPDATE OR DELETE ON public.documents
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();

CREATE TRIGGER audit_referrals
  AFTER INSERT OR UPDATE OR DELETE ON public.referrals
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();
