
-- 1. medical-documents: munkaltato can only see their employees' docs (path = {patient_user_id}/...)
DROP POLICY IF EXISTS "Munkaltato read medical docs" ON storage.objects;
CREATE POLICY "Munkaltato read medical docs" ON storage.objects
FOR SELECT TO authenticated
USING (
  bucket_id = 'medical-documents'
  AND has_role(auth.uid(), 'munkaltato'::app_role)
  AND public.is_employer_of_patient(auth.uid(), ((storage.foldername(name))[1])::uuid)
);

-- 2. signatures bucket: restrict SELECT to owner of the file folder
DROP POLICY IF EXISTS "Authenticated users read signatures" ON storage.objects;
CREATE POLICY "Users read own signature" ON storage.objects
FOR SELECT TO authenticated
USING (
  bucket_id = 'signatures'
  AND (storage.foldername(name))[1] = auth.uid()::text
);

-- 3. accident-photos: DELETE only by owner of folder; SELECT scoped to owner too for safety
DROP POLICY IF EXISTS "Authenticated users can delete own accident photos" ON storage.objects;
CREATE POLICY "Users delete own accident photos" ON storage.objects
FOR DELETE TO authenticated
USING (
  bucket_id = 'accident-photos'
  AND (storage.foldername(name))[1] = auth.uid()::text
);

-- 4. work_area_sds_documents table: scope SELECT to company members / doctors / uploader / admin
DROP POLICY IF EXISTS "Authenticated users can view SDS documents" ON public.work_area_sds_documents;
CREATE POLICY "Members view SDS documents" ON public.work_area_sds_documents
FOR SELECT TO authenticated
USING (
  uploaded_by = auth.uid()
  OR has_role(auth.uid(), 'super_admin'::app_role)
  OR has_role(auth.uid(), 'uzemorvos'::app_role)
  OR EXISTS (
    SELECT 1
    FROM public.work_areas wa
    JOIN public.company_sites cs ON cs.id = wa.site_id
    JOIN public.user_company_relations ucr ON ucr.company_id = cs.company_id
    WHERE wa.id = work_area_sds_documents.work_area_id
      AND ucr.user_id = auth.uid()
      AND ucr.is_active = true
  )
);

-- 4b. sds-documents storage bucket: scope SELECT similarly via file_path join
DROP POLICY IF EXISTS "Authenticated users can view SDS" ON storage.objects;
CREATE POLICY "Members view SDS files" ON storage.objects
FOR SELECT TO authenticated
USING (
  bucket_id = 'sds-documents'
  AND (
    (storage.foldername(name))[1] = auth.uid()::text
    OR has_role(auth.uid(), 'super_admin'::app_role)
    OR has_role(auth.uid(), 'uzemorvos'::app_role)
    OR EXISTS (
      SELECT 1
      FROM public.work_area_sds_documents d
      JOIN public.work_areas wa ON wa.id = d.work_area_id
      JOIN public.company_sites cs ON cs.id = wa.site_id
      JOIN public.user_company_relations ucr ON ucr.company_id = cs.company_id
      WHERE d.file_path = storage.objects.name
        AND ucr.user_id = auth.uid()
        AND ucr.is_active = true
    )
  )
);

-- 5. Revoke EXECUTE on SECURITY DEFINER functions that should NOT be callable from the API.
-- Keep public-callable: get_public_locations, create_public_lab_order, log_security_event,
-- and RLS-helper functions invoked from policies (has_role, is_company_member,
-- is_employer_of_patient, get_user_roles) for authenticated.
REVOKE EXECUTE ON FUNCTION public.audit_trigger_func() FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.auto_update_referral_on_questionnaire() FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.generate_lab_order_number() FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.generate_lab_request_number() FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.update_updated_at_column() FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.delete_email(text, bigint) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.enqueue_email(text, jsonb) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.read_email_batch(text, integer, integer) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.move_to_dlq(text, text, bigint, jsonb) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.security_denials_summary(timestamp with time zone) FROM anon, authenticated;
-- Revoke from anon for helpers / RLS / admin RPCs not used by anon
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, app_role) FROM anon;
REVOKE EXECUTE ON FUNCTION public.is_company_member(uuid, uuid, app_role) FROM anon;
REVOKE EXECUTE ON FUNCTION public.is_employer_of_patient(uuid, uuid) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_user_roles(uuid) FROM anon;

-- 6. og-images: remove broad listing policy. The bucket is public so direct object URLs still work;
-- only API listing is blocked.
DROP POLICY IF EXISTS "OG images are publicly accessible" ON storage.objects;

-- 7. Tighten always-true INSERT policies.
-- 7a. lab_orders: drop open anon insert; anon path uses create_public_lab_order RPC (SECURITY DEFINER).
DROP POLICY IF EXISTS "Anyone can create lab orders" ON public.lab_orders;
CREATE POLICY "Authenticated create own lab orders" ON public.lab_orders
FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id);

-- 7b. page_views: require a non-empty, length-bounded page_path.
DROP POLICY IF EXISTS "Anyone can insert page views" ON public.page_views;
CREATE POLICY "Anyone can insert page views" ON public.page_views
FOR INSERT TO anon, authenticated
WITH CHECK (
  page_path IS NOT NULL
  AND char_length(page_path) BETWEEN 1 AND 2048
  AND (user_agent IS NULL OR char_length(user_agent) <= 1024)
);

-- 7c. web_vitals: require known metric and bounded values.
DROP POLICY IF EXISTS "Anyone can insert web vitals" ON public.web_vitals;
CREATE POLICY "Anyone can insert web vitals" ON public.web_vitals
FOR INSERT TO anon, authenticated
WITH CHECK (
  metric_name IS NOT NULL
  AND char_length(metric_name) BETWEEN 1 AND 64
  AND value IS NOT NULL
  AND page_path IS NOT NULL
  AND char_length(page_path) BETWEEN 1 AND 2048
);
