
-- Create competitor_urls table
CREATE TABLE public.competitor_urls (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  url TEXT NOT NULL,
  name TEXT NOT NULL DEFAULT '',
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_by UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.competitor_urls ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage competitor_urls"
  ON public.competitor_urls
  FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'super_admin'))
  WITH CHECK (public.has_role(auth.uid(), 'super_admin'));

-- Create competitor_analyses table
CREATE TABLE public.competitor_analyses (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  competitor_url_id UUID REFERENCES public.competitor_urls(id) ON DELETE CASCADE,
  analysis_type TEXT NOT NULL DEFAULT 'seo_compare',
  results JSONB NOT NULL DEFAULT '{}',
  created_by UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.competitor_analyses ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage competitor_analyses"
  ON public.competitor_analyses
  FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'super_admin'))
  WITH CHECK (public.has_role(auth.uid(), 'super_admin'));

-- Index for faster lookups
CREATE INDEX idx_competitor_analyses_url_id ON public.competitor_analyses(competitor_url_id);
CREATE INDEX idx_competitor_analyses_type ON public.competitor_analyses(analysis_type);
