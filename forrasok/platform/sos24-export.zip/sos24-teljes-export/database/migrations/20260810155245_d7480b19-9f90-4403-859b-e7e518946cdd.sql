CREATE TYPE public.icd_version AS ENUM ('icd10', 'icd11');

CREATE EXTENSION IF NOT EXISTS pg_trgm;

CREATE TABLE public.icd_codes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code TEXT NOT NULL,
  version public.icd_version NOT NULL DEFAULT 'icd10',
  label_hu TEXT NOT NULL,
  label_en TEXT,
  parent_code TEXT,
  level INTEGER NOT NULL DEFAULT 0,
  synonyms TEXT[] DEFAULT '{}',
  category TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE (code, version)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.icd_codes TO authenticated;
GRANT ALL ON public.icd_codes TO service_role;

ALTER TABLE public.icd_codes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read active ICD codes"
  ON public.icd_codes
  FOR SELECT
  TO authenticated
  USING (is_active = true);

CREATE POLICY "Super admins can manage ICD codes"
  ON public.icd_codes
  FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'super_admin'))
  WITH CHECK (public.has_role(auth.uid(), 'super_admin'));

CREATE INDEX idx_icd_codes_code ON public.icd_codes (code);

CREATE INDEX idx_icd_codes_search_trgm
  ON public.icd_codes
  USING gin (code gin_trgm_ops, label_hu gin_trgm_ops, label_en gin_trgm_ops, category gin_trgm_ops);

CREATE INDEX idx_icd_codes_version_active
  ON public.icd_codes (version, is_active);

CREATE TRIGGER update_icd_codes_updated_at
  BEFORE UPDATE ON public.icd_codes
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER audit_icd_codes
  AFTER INSERT OR UPDATE OR DELETE ON public.icd_codes
  FOR EACH ROW
  EXECUTE FUNCTION public.audit_trigger_func();