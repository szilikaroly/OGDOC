INSERT INTO public.questionnaires (title, description, is_active, fields)
VALUES (
  'Életmód kérdőív (Delphi)',
  'Átfogó életmód felmérés: fizikai aktivitás, táplálkozás, társas kapcsolatok és társadalmi részvétel.',
  true,
  '[
    {
      "section": "Fizikai aktivitás — Aktív",
      "fields": [
        {"key": "pa_active_1", "label": "Rendszeresen végzek erő-/aerob edzést legalább heti 3 alkalommal.", "type": "yesno"},
        {"key": "pa_active_2", "label": "Legalább heti egyszer végzek nagy intenzitású edzést, amitől kifullladok.", "type": "yesno"},
        {"key": "pa_active_3", "label": "Naponta legalább 20 percet sétálok.", "type": "yesno"},
        {"key": "pa_active_4", "label": "Sokat mozgok a mindennapokban.", "type": "yesno"},
        {"key": "pa_active_5", "label": "Inkább tömegközlekedést vagy sétát választom.", "type": "yesno"},
        {"key": "pa_active_6", "label": "Rendszeresen végzek könnyű gyakorlatokat (nyújtás, torna).", "type": "yesno"},
        {"key": "pa_active_7", "label": "Nem rendszeresen, de sportolok.", "type": "yesno"},
        {"key": "pa_active_8", "label": "Tanfolyamon tanulok sportolni.", "type": "yesno"},
        {"key": "pa_active_9", "label": "Rendszeres edzésterv szerint sportolok.", "type": "yesno"}
      ]
    },
    {
      "section": "Fizikai aktivitás — Ülő életmód",
      "fields": [
        {"key": "pa_sed_1", "label": "Nincs külön edzésidőm, amit rendszeresen vagy tervezetten végzek.", "type": "yesno"},
        {"key": "pa_sed_2", "label": "A napi sétán kívül nem végzek fizikai aktivitást.", "type": "yesno"},
        {"key": "pa_sed_3", "label": "Inkább autót használok, mint tömegközlekedést.", "type": "yesno"},
        {"key": "pa_sed_4", "label": "Amikor csak lehet, közlekedési eszközt használok séta helyett.", "type": "yesno"},
        {"key": "pa_sed_5", "label": "Szabadidőmet ülve töltöm, nem mozgással.", "type": "yesno"},
        {"key": "pa_sed_6", "label": "A nap nagy részét ülve vagy fekve töltöm.", "type": "yesno"},
        {"key": "pa_sed_7", "label": "Nem mozdulok, ha nem muszáj.", "type": "yesno"},
        {"key": "pa_sed_8", "label": "Nem szánok időt külön edzésre.", "type": "yesno"},
        {"key": "pa_sed_9", "label": "Úgy gondolom, nem mozgok eleget.", "type": "yesno"}
      ]
    },
    {
      "section": "Táplálkozás — Kiegyensúlyozott",
      "fields": [
        {"key": "nut_bal_1", "label": "Legalább heti kétszer eszem vörös húst.", "type": "yesno"},
        {"key": "nut_bal_2", "label": "Hetente fogyasztok kalciumot tartalmazó ételeket (tej, sajt, joghurt, káposzta).", "type": "yesno"},
        {"key": "nut_bal_3", "label": "Minden második nap eszem nyers vagy főtt zöldséget.", "type": "yesno"},
        {"key": "nut_bal_4", "label": "Naponta legalább kétszer fogyasztok fehérjét (hal, hús, tojás, hüvelyesek).", "type": "yesno"},
        {"key": "nut_bal_5", "label": "Naponta több mint 8 pohár vizet iszom.", "type": "yesno"},
        {"key": "nut_bal_6", "label": "Minden nap eszem diófélét.", "type": "yesno"},
        {"key": "nut_bal_7", "label": "Rendszeresen étkezem.", "type": "yesno"},
        {"key": "nut_bal_8", "label": "Igyekszem egyenletesen elosztani az étkezéseimet.", "type": "yesno"},
        {"key": "nut_bal_9", "label": "Kerülöm a túlzott sófogyasztást.", "type": "yesno"}
      ]
    },
    {
      "section": "Táplálkozás — Kiegyensúlyozatlan",
      "fields": [
        {"key": "nut_unb_1", "label": "Sok napon eszem feldolgozott ételeket (feldolgozott hús, snackek, üdítők).", "type": "yesno"},
        {"key": "nut_unb_2", "label": "Nem fogyasztok kalciumot tartalmazó ételeket.", "type": "yesno"},
        {"key": "nut_unb_3", "label": "Hetente legfeljebb 3-szor eszem zöldséget.", "type": "yesno"},
        {"key": "nut_unb_4", "label": "Gyakran nem eszem naponta egyszer sem fehérjét.", "type": "yesno"},
        {"key": "nut_unb_5", "label": "Gyorsabban eszem, mint mások.", "type": "yesno"},
        {"key": "nut_unb_6", "label": "Legalább heti 3-szor eszem éjszakai nassolnivalót.", "type": "yesno"},
        {"key": "nut_unb_7", "label": "Rendszertelenül étkezem.", "type": "yesno"},
        {"key": "nut_unb_8", "label": "Jelenleg dohányzom (beleértve minden dohányterméket).", "type": "yesno"},
        {"key": "nut_unb_9", "label": "Sok napon nem eszem napi két étkezést sem.", "type": "yesno"}
      ]
    },
    {
      "section": "Társas kapcsolatok — Kapcsolódó",
      "fields": [
        {"key": "soc_con_1", "label": "Családommal vagy másokkal élek együtt.", "type": "yesno"},
        {"key": "soc_con_2", "label": "Elegendő társas interakcióm van másokkal.", "type": "yesno"},
        {"key": "soc_con_3", "label": "Vannak közeli barátaim/rokonaim, akik közel laknak.", "type": "yesno"},
        {"key": "soc_con_4", "label": "Vannak közeli barátaim, akikkel legalább kéthetente találkozom.", "type": "yesno"},
        {"key": "soc_con_5", "label": "Elegendő kommunikációm van másokkal.", "type": "yesno"},
        {"key": "soc_con_6", "label": "Van online találkozó, amiben aktívan részt veszek.", "type": "yesno"},
        {"key": "soc_con_7", "label": "Mindig igyekszem új embereket megismerni.", "type": "yesno"},
        {"key": "soc_con_8", "label": "Legalább 3 rendszeres találkozóm van (osztálytalálkozó, társasági összejövetel).", "type": "yesno"},
        {"key": "soc_con_9", "label": "Van csoportom vagy szervezetem, ahová rendszeresen járok.", "type": "yesno"}
      ]
    },
    {
      "section": "Társas kapcsolatok — Elszigetelt",
      "fields": [
        {"key": "soc_iso_1", "label": "Jelenleg egyedül élek.", "type": "yesno"},
        {"key": "soc_iso_2", "label": "Magányosnak vagy elszigeteltnek érzem magam.", "type": "yesno"},
        {"key": "soc_iso_3", "label": "Az időm nagy részét egyedül töltöm.", "type": "yesno"},
        {"key": "soc_iso_4", "label": "Nincs senkim, aki segítene, ha bajban vagyok.", "type": "yesno"},
        {"key": "soc_iso_5", "label": "Nem szeretek másokkal lógni vagy együtt lenni.", "type": "yesno"},
        {"key": "soc_iso_6", "label": "Nincs találkozóm vagy szervezetem, ahová rendszeresen járnék.", "type": "yesno"},
        {"key": "soc_iso_7", "label": "Nem érzem szükségét új kapcsolatok kialakításának.", "type": "yesno"},
        {"key": "soc_iso_8", "label": "Nem érzem szükségét a társas hovatartozásnak.", "type": "yesno"},
        {"key": "soc_iso_9", "label": "Nehezen kommunikálok online, nem vagyok aktív.", "type": "yesno"}
      ]
    },
    {
      "section": "Társadalmi részvétel — Változatos",
      "fields": [
        {"key": "sp_div_1", "label": "Gazdasági tevékenység céljából dolgozom.", "type": "yesno"},
        {"key": "sp_div_2", "label": "Előadásokat, művészeti tevékenységeket nézek, vagy kreatív tevékenységben veszek részt.", "type": "yesno"},
        {"key": "sp_div_3", "label": "Aktívan részt veszek közösségi rendezvényeken, fesztiválokon.", "type": "yesno"},
        {"key": "sp_div_4", "label": "Online és offline előadásokra járok.", "type": "yesno"},
        {"key": "sp_div_5", "label": "Aktívan használom a közösségi létesítményeket (könyvtár, művelődési ház).", "type": "yesno"},
        {"key": "sp_div_6", "label": "Érdeklődöm a politikai tevékenységek és szavazás iránt, részt is veszek benne.", "type": "yesno"},
        {"key": "sp_div_7", "label": "Érdeklődöm a közösségi problémák megoldása iránt.", "type": "yesno"},
        {"key": "sp_div_8", "label": "Részt veszek lakossági önkormányzati tevékenységekben.", "type": "yesno"},
        {"key": "sp_div_9", "label": "Rendszeresen részt veszek vallási tevékenységekben.", "type": "yesno"}
      ]
    },
    {
      "section": "Társadalmi részvétel — Monoton",
      "fields": [
        {"key": "sp_mono_1", "label": "Nem dolgozom gazdasági tevékenység céljából.", "type": "yesno"},
        {"key": "sp_mono_2", "label": "Nem veszek részt önkéntesen másokkal közös tevékenységekben.", "type": "yesno"},
        {"key": "sp_mono_3", "label": "Nem ismerem a közösségi rendezvényeket, fesztiválokat.", "type": "yesno"},
        {"key": "sp_mono_4", "label": "Nincs különleges esemény vagy rendezvény a mindennapi életemben.", "type": "yesno"},
        {"key": "sp_mono_5", "label": "Nem érdekelnek a politikai ügyek és közösségi hírek.", "type": "yesno"},
        {"key": "sp_mono_6", "label": "A mindennapjaim monotonok és ismétlődők.", "type": "yesno"},
        {"key": "sp_mono_7", "label": "Inkább megtartom a mindennapi rutint, mint hogy változtassak.", "type": "yesno"},
        {"key": "sp_mono_8", "label": "Korlátozott lehetőségeim vannak a közösségi részvételre.", "type": "yesno"},
        {"key": "sp_mono_9", "label": "Szívesebben hallgatok zenét vagy nézek TV-t egyedül.", "type": "yesno"}
      ]
    }
  ]'::jsonb
);