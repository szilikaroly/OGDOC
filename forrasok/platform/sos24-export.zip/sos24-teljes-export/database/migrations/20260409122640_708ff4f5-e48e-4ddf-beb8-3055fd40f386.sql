
-- Add GPS and photo columns to accident_reports
ALTER TABLE public.accident_reports
  ADD COLUMN IF NOT EXISTS gps_lat numeric,
  ADD COLUMN IF NOT EXISTS gps_lng numeric,
  ADD COLUMN IF NOT EXISTS photos text[] DEFAULT '{}'::text[];

-- Create storage bucket for accident photos
INSERT INTO storage.buckets (id, name, public) VALUES ('accident-photos', 'accident-photos', false)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for accident photos
CREATE POLICY "Authenticated users can upload accident photos"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'accident-photos');

CREATE POLICY "Authenticated users can view accident photos"
ON storage.objects FOR SELECT TO authenticated
USING (bucket_id = 'accident-photos');

CREATE POLICY "Authenticated users can delete own accident photos"
ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'accident-photos');
