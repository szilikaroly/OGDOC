
INSERT INTO storage.buckets (id, name, public)
VALUES ('og-images', 'og-images', true)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "OG images are publicly accessible"
ON storage.objects FOR SELECT
USING (bucket_id = 'og-images');

CREATE POLICY "Super admins can upload OG images"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'og-images'
  AND public.has_role(auth.uid(), 'super_admin')
);

CREATE POLICY "Super admins can update OG images"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'og-images'
  AND public.has_role(auth.uid(), 'super_admin')
);

CREATE POLICY "Super admins can delete OG images"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'og-images'
  AND public.has_role(auth.uid(), 'super_admin')
);
