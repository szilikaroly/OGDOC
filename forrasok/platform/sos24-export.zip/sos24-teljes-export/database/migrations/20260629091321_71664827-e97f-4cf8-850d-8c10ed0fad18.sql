
CREATE OR REPLACE FUNCTION public.admin_get_recovery_status(_user_ids uuid[])
RETURNS TABLE (
  user_id uuid,
  email text,
  recovery_sent_at timestamptz,
  last_sign_in_at timestamptz,
  email_confirmed_at timestamptz,
  last_recovery_status text,
  last_recovery_error text,
  last_recovery_log_at timestamptz
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.has_role(auth.uid(), 'super_admin'::app_role) THEN
    RAISE EXCEPTION 'forbidden: super_admin role required';
  END IF;

  RETURN QUERY
  WITH latest AS (
    SELECT DISTINCT ON (l.message_id)
      l.recipient_email, l.status, l.error_message, l.created_at
    FROM public.email_send_log l
    WHERE l.template_name = 'recovery'
      AND l.message_id IS NOT NULL
      AND l.recipient_email IS NOT NULL
    ORDER BY l.message_id, l.created_at DESC
  ), per_user AS (
    SELECT
      recipient_email,
      (ARRAY_AGG(status ORDER BY created_at DESC))[1] AS status,
      (ARRAY_AGG(error_message ORDER BY created_at DESC))[1] AS err,
      MAX(created_at) AS at
    FROM latest
    GROUP BY recipient_email
  )
  SELECT
    u.id,
    u.email::text,
    u.recovery_sent_at,
    u.last_sign_in_at,
    u.email_confirmed_at,
    p.status,
    p.err,
    p.at
  FROM auth.users u
  LEFT JOIN per_user p ON lower(p.recipient_email) = lower(u.email)
  WHERE u.id = ANY(_user_ids);
END;
$$;

REVOKE ALL ON FUNCTION public.admin_get_recovery_status(uuid[]) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.admin_get_recovery_status(uuid[]) TO authenticated;
