
-- Add unique constraint for upsert support on user_company_relations
CREATE UNIQUE INDEX IF NOT EXISTS user_company_relations_user_company_unique 
ON public.user_company_relations (user_id, company_id);
