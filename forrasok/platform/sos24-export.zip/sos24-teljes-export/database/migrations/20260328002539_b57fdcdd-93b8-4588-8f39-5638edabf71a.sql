
-- Document tags table (extensible list)
CREATE TABLE public.document_tags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  label text NOT NULL UNIQUE,
  sort_order integer NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.document_tags ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Tags readable by authenticated" ON public.document_tags FOR SELECT TO authenticated USING (true);
CREATE POLICY "Super admins manage tags" ON public.document_tags FOR ALL USING (has_role(auth.uid(), 'super_admin'::app_role));

-- Seed default tags
INSERT INTO public.document_tags (label, sort_order) VALUES
  ('Zárójelentés', 1),
  ('Ambulánslap', 2),
  ('Recept', 3),
  ('Szakorvosi javaslat', 4),
  ('Laboreredmény', 5),
  ('Vércsoport', 6),
  ('Leletegyéb', 7),
  ('Képalkotó', 8);

-- Allow praxistag users to insert documents (own user_id folder)
CREATE POLICY "Users upload own documents" ON public.documents
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Storage: allow authenticated users to upload to their own folder
CREATE POLICY "Users upload own medical docs" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'medical-documents' AND (storage.foldername(name))[1] = (auth.uid())::text);

-- Add ai_analysis column to documents for storing AI findings
ALTER TABLE public.documents ADD COLUMN IF NOT EXISTS ai_analysis jsonb;
ALTER TABLE public.documents ADD COLUMN IF NOT EXISTS tags text[] DEFAULT '{}';
