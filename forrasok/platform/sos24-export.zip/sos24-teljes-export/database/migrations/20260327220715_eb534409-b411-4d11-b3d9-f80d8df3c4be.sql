-- Create documents table to track generated/uploaded documents
CREATE TABLE public.documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  document_type text NOT NULL, -- 'opinion', 'examination', 'referral', 'upload'
  related_id uuid, -- references the source record (medical_opinions.id, examinations.id, referrals.id)
  file_name text NOT NULL,
  file_path text NOT NULL, -- storage path
  file_size integer,
  mime_type text DEFAULT 'application/pdf',
  created_at timestamptz NOT NULL DEFAULT now(),
  created_by uuid
);

ALTER TABLE public.documents ENABLE ROW LEVEL SECURITY;

-- User sees own documents
CREATE POLICY "Users see own documents" ON public.documents
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

-- Doctors see all documents
CREATE POLICY "Doctors see documents" ON public.documents
  FOR SELECT TO authenticated
  USING (has_role(auth.uid(), 'uzemorvos') OR has_role(auth.uid(), 'haziorvos'));

-- Munkaltato sees employee documents
CREATE POLICY "Munkaltato sees employee docs" ON public.documents
  FOR SELECT TO authenticated
  USING (is_employer_of_patient(auth.uid(), user_id));

-- Super admin full access
CREATE POLICY "Super admins manage documents" ON public.documents
  FOR ALL USING (has_role(auth.uid(), 'super_admin'));

-- Service/edge functions can insert
CREATE POLICY "Service inserts documents" ON public.documents
  FOR INSERT WITH CHECK (true);

-- Storage bucket
INSERT INTO storage.buckets (id, name, public) VALUES ('medical-documents', 'medical-documents', false);

-- Storage RLS: users can read own files
CREATE POLICY "Users read own medical docs" ON storage.objects
  FOR SELECT TO authenticated
  USING (bucket_id = 'medical-documents' AND (storage.foldername(name))[1] = auth.uid()::text);

-- Doctors read all medical docs
CREATE POLICY "Doctors read medical docs" ON storage.objects
  FOR SELECT TO authenticated
  USING (bucket_id = 'medical-documents' AND (has_role(auth.uid(), 'uzemorvos') OR has_role(auth.uid(), 'haziorvos')));

-- Munkaltato reads employee docs (via documents table check)
CREATE POLICY "Munkaltato read medical docs" ON storage.objects
  FOR SELECT TO authenticated
  USING (bucket_id = 'medical-documents' AND has_role(auth.uid(), 'munkaltato'));

-- Super admin full access to storage
CREATE POLICY "Admin manage medical docs" ON storage.objects
  FOR ALL TO authenticated
  USING (bucket_id = 'medical-documents' AND has_role(auth.uid(), 'super_admin'));

-- Service can upload
CREATE POLICY "Service upload medical docs" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'medical-documents');