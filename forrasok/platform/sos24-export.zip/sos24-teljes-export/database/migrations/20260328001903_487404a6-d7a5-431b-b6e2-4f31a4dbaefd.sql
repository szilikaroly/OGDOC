
-- Health journal table
CREATE TABLE public.health_journal (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  entry_date date NOT NULL DEFAULT CURRENT_DATE,
  blood_pressure_systolic integer,
  blood_pressure_diastolic integer,
  heart_rate integer,
  weight_kg numeric,
  blood_sugar numeric,
  temperature numeric,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.health_journal ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage own journal" ON public.health_journal FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Haziorvos sees journal" ON public.health_journal FOR SELECT USING (has_role(auth.uid(), 'haziorvos'::app_role));
CREATE POLICY "Uzemorvos sees journal" ON public.health_journal FOR SELECT USING (has_role(auth.uid(), 'uzemorvos'::app_role));
CREATE POLICY "Super admins manage journal" ON public.health_journal FOR ALL USING (has_role(auth.uid(), 'super_admin'::app_role));

-- Vaccinations table
CREATE TABLE public.vaccinations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  vaccine_name text NOT NULL,
  administered_date date NOT NULL,
  expiry_date date,
  lot_number text,
  administered_by text,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.vaccinations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage own vaccinations" ON public.vaccinations FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Haziorvos manages vaccinations" ON public.vaccinations FOR ALL USING (has_role(auth.uid(), 'haziorvos'::app_role));
CREATE POLICY "Uzemorvos manages vaccinations" ON public.vaccinations FOR ALL USING (has_role(auth.uid(), 'uzemorvos'::app_role));
CREATE POLICY "Super admins manage vaccinations" ON public.vaccinations FOR ALL USING (has_role(auth.uid(), 'super_admin'::app_role));

CREATE TRIGGER update_vaccinations_updated_at BEFORE UPDATE ON public.vaccinations FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Notification preferences table
CREATE TABLE public.notification_preferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL UNIQUE,
  email_appointments boolean NOT NULL DEFAULT true,
  email_reminders boolean NOT NULL DEFAULT true,
  email_opinions boolean NOT NULL DEFAULT true,
  email_vaccinations boolean NOT NULL DEFAULT true,
  inapp_appointments boolean NOT NULL DEFAULT true,
  inapp_reminders boolean NOT NULL DEFAULT true,
  inapp_opinions boolean NOT NULL DEFAULT true,
  inapp_vaccinations boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.notification_preferences ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage own preferences" ON public.notification_preferences FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Super admins see preferences" ON public.notification_preferences FOR SELECT USING (has_role(auth.uid(), 'super_admin'::app_role));

CREATE TRIGGER update_notification_preferences_updated_at BEFORE UPDATE ON public.notification_preferences FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
