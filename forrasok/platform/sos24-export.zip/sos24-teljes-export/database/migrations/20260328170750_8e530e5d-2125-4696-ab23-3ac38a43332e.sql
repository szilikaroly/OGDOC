
-- Uzemorvos can read user_company_relations
CREATE POLICY "Uzemorvos sees company relations"
ON public.user_company_relations
FOR SELECT
TO authenticated
USING (has_role(auth.uid(), 'uzemorvos'::app_role));

-- Uzemorvos can update companies
CREATE POLICY "Uzemorvos manages companies"
ON public.companies
FOR ALL
TO authenticated
USING (has_role(auth.uid(), 'uzemorvos'::app_role))
WITH CHECK (has_role(auth.uid(), 'uzemorvos'::app_role));

-- Uzemorvos can update user_company_relations (position, risk_factors)
CREATE POLICY "Uzemorvos updates company relations"
ON public.user_company_relations
FOR UPDATE
TO authenticated
USING (has_role(auth.uid(), 'uzemorvos'::app_role))
WITH CHECK (has_role(auth.uid(), 'uzemorvos'::app_role));
