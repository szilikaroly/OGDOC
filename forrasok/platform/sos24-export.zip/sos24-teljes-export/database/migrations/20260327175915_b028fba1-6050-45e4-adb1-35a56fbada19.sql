
-- 1. Create SECURITY DEFINER helper to check company membership without RLS
CREATE OR REPLACE FUNCTION public.is_company_member(
  _user_id uuid, _company_id uuid, _role app_role
) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_company_relations
    WHERE user_id = _user_id
      AND company_id = _company_id
      AND role = _role
  )
$$;

-- Also a variant: check if user is employer of ANY company that a patient belongs to
CREATE OR REPLACE FUNCTION public.is_employer_of_patient(
  _employer_id uuid, _patient_id uuid
) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_company_relations emp
    JOIN public.user_company_relations pat ON pat.company_id = emp.company_id
    WHERE emp.user_id = _employer_id
      AND emp.role = 'munkaltato'
      AND pat.user_id = _patient_id
  )
$$;

-- 2. Fix user_company_relations
DROP POLICY IF EXISTS "Munkaltato sees their company members" ON public.user_company_relations;
CREATE POLICY "Munkaltato sees their company members"
ON public.user_company_relations FOR SELECT TO public
USING (is_company_member(auth.uid(), company_id, 'munkaltato'));

-- 3. Fix referrals
DROP POLICY IF EXISTS "Munkaltato sees own company referrals" ON public.referrals;
CREATE POLICY "Munkaltato sees own company referrals"
ON public.referrals FOR SELECT TO public
USING (is_company_member(auth.uid(), company_id, 'munkaltato'));

DROP POLICY IF EXISTS "Munkaltato updates own company referrals" ON public.referrals;
CREATE POLICY "Munkaltato updates own company referrals"
ON public.referrals FOR UPDATE TO public
USING (is_company_member(auth.uid(), company_id, 'munkaltato'));

-- 4. Fix medical_opinions
DROP POLICY IF EXISTS "Munkaltato sees company opinions" ON public.medical_opinions;
CREATE POLICY "Munkaltato sees company opinions"
ON public.medical_opinions FOR SELECT TO public
USING (is_company_member(auth.uid(), company_id, 'munkaltato'));

-- 5. Fix examinations
DROP POLICY IF EXISTS "Munkaltato sees company employee exams" ON public.examinations;
CREATE POLICY "Munkaltato sees company employee exams"
ON public.examinations FOR SELECT TO public
USING (is_employer_of_patient(auth.uid(), patient_id));
