
-- Audit triggers for all sensitive tables
-- Drop existing triggers if any, then recreate

DROP TRIGGER IF EXISTS audit_examinations ON public.examinations;
CREATE TRIGGER audit_examinations
  AFTER INSERT OR UPDATE OR DELETE ON public.examinations
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();

DROP TRIGGER IF EXISTS audit_medical_opinions ON public.medical_opinions;
CREATE TRIGGER audit_medical_opinions
  AFTER INSERT OR UPDATE OR DELETE ON public.medical_opinions
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();

DROP TRIGGER IF EXISTS audit_patient_cards ON public.patient_cards;
CREATE TRIGGER audit_patient_cards
  AFTER INSERT OR UPDATE OR DELETE ON public.patient_cards
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();

DROP TRIGGER IF EXISTS audit_documents ON public.documents;
CREATE TRIGGER audit_documents
  AFTER INSERT OR UPDATE OR DELETE ON public.documents
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();

DROP TRIGGER IF EXISTS audit_referrals ON public.referrals;
CREATE TRIGGER audit_referrals
  AFTER INSERT OR UPDATE OR DELETE ON public.referrals
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();

DROP TRIGGER IF EXISTS audit_medication_requests ON public.medication_requests;
CREATE TRIGGER audit_medication_requests
  AFTER INSERT OR UPDATE OR DELETE ON public.medication_requests
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();
