
-- Allow praxistag to see doctor profiles (needed to display doctor names on examinations)
CREATE POLICY "Praxistag sees profiles" ON public.profiles
  FOR SELECT USING (has_role(auth.uid(), 'praxistag'::app_role));
