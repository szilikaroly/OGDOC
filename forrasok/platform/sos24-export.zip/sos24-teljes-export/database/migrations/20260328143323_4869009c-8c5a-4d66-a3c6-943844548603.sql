
-- Table for doctor-to-patient questionnaire assignments
CREATE TABLE public.questionnaire_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  questionnaire_id uuid NOT NULL REFERENCES public.questionnaires(id) ON DELETE CASCADE,
  patient_id uuid NOT NULL,
  assigned_by uuid NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  message text,
  created_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz
);

ALTER TABLE public.questionnaire_assignments ENABLE ROW LEVEL SECURITY;

-- Doctors can assign questionnaires
CREATE POLICY "Haziorvos manages assignments" ON public.questionnaire_assignments
  FOR ALL TO authenticated
  USING (has_role(auth.uid(), 'haziorvos'::app_role))
  WITH CHECK (has_role(auth.uid(), 'haziorvos'::app_role));

-- Uzemorvos can manage assignments
CREATE POLICY "Uzemorvos manages assignments" ON public.questionnaire_assignments
  FOR ALL TO authenticated
  USING (has_role(auth.uid(), 'uzemorvos'::app_role))
  WITH CHECK (has_role(auth.uid(), 'uzemorvos'::app_role));

-- Patients see their own assignments
CREATE POLICY "Patients see own assignments" ON public.questionnaire_assignments
  FOR SELECT TO authenticated
  USING (auth.uid() = patient_id);

-- Patients can update their own assignments (mark as completed)
CREATE POLICY "Patients update own assignments" ON public.questionnaire_assignments
  FOR UPDATE TO authenticated
  USING (auth.uid() = patient_id)
  WITH CHECK (auth.uid() = patient_id);

-- Super admins manage all
CREATE POLICY "Super admins manage assignments" ON public.questionnaire_assignments
  FOR ALL TO authenticated
  USING (has_role(auth.uid(), 'super_admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'super_admin'::app_role));

-- Add score columns to questionnaire_submissions for FINDRISK/BECK scoring
ALTER TABLE public.questionnaire_submissions 
  ADD COLUMN IF NOT EXISTS score integer,
  ADD COLUMN IF NOT EXISTS risk_category text,
  ADD COLUMN IF NOT EXISTS ai_evaluation text;
