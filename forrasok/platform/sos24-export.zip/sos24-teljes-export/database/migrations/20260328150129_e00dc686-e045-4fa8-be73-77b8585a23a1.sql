
CREATE TABLE public.i18n_overrides (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  language text NOT NULL UNIQUE,
  translations jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now(),
  updated_by uuid REFERENCES auth.users(id)
);

ALTER TABLE public.i18n_overrides ENABLE ROW LEVEL SECURITY;

-- Everyone can read translations (needed for app to load them)
CREATE POLICY "Anyone can read translations"
  ON public.i18n_overrides FOR SELECT
  TO anon, authenticated
  USING (true);

-- Only super_admin can modify
CREATE POLICY "Admins can manage translations"
  ON public.i18n_overrides FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'super_admin'))
  WITH CHECK (public.has_role(auth.uid(), 'super_admin'));

CREATE TRIGGER update_i18n_overrides_updated_at
  BEFORE UPDATE ON public.i18n_overrides
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Enable realtime for instant updates
ALTER PUBLICATION supabase_realtime ADD TABLE public.i18n_overrides;
