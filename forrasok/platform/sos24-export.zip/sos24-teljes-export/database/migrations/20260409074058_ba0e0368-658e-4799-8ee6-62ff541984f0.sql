
DROP TRIGGER IF EXISTS audit_examinations ON public.examinations;
DROP TRIGGER IF EXISTS audit_profiles ON public.profiles;
DROP TRIGGER IF EXISTS audit_referrals ON public.referrals;
DROP TRIGGER IF EXISTS audit_medical_opinions ON public.medical_opinions;
DROP TRIGGER IF EXISTS audit_documents ON public.documents;
DROP TRIGGER IF EXISTS audit_patient_cards ON public.patient_cards;
DROP TRIGGER IF EXISTS audit_companies ON public.companies;
DROP TRIGGER IF EXISTS audit_user_company_relations ON public.user_company_relations;

CREATE TRIGGER audit_examinations
  AFTER INSERT OR UPDATE OR DELETE ON public.examinations
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();

CREATE TRIGGER audit_profiles
  AFTER INSERT OR UPDATE OR DELETE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();

CREATE TRIGGER audit_referrals
  AFTER INSERT OR UPDATE OR DELETE ON public.referrals
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();

CREATE TRIGGER audit_medical_opinions
  AFTER INSERT OR UPDATE OR DELETE ON public.medical_opinions
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();

CREATE TRIGGER audit_documents
  AFTER INSERT OR UPDATE OR DELETE ON public.documents
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();

CREATE TRIGGER audit_patient_cards
  AFTER INSERT OR UPDATE OR DELETE ON public.patient_cards
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();

CREATE TRIGGER audit_companies
  AFTER INSERT OR UPDATE OR DELETE ON public.companies
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();

CREATE TRIGGER audit_user_company_relations
  AFTER INSERT OR UPDATE OR DELETE ON public.user_company_relations
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();
