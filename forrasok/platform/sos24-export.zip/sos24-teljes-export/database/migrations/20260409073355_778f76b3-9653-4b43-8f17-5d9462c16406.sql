-- 1. Fix: Munkaltato manages own companies (scope to own companies only)
DROP POLICY IF EXISTS "Munkaltato manages own companies" ON public.companies;

-- Separate SELECT (already handled by "Company members and admins see companies")
-- Add scoped INSERT, UPDATE, DELETE for munkaltato
CREATE POLICY "Munkaltato updates own companies"
  ON public.companies FOR UPDATE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.user_company_relations
      WHERE user_id = auth.uid()
        AND company_id = companies.id
        AND role = 'munkaltato'
        AND is_active = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.user_company_relations
      WHERE user_id = auth.uid()
        AND company_id = companies.id
        AND role = 'munkaltato'
        AND is_active = true
    )
  );

-- 2. Fix: Munkaltato sees employee profiles (scope to own employees only)
DROP POLICY IF EXISTS "Munkaltato sees employee profiles" ON public.profiles;

CREATE POLICY "Munkaltato sees employee profiles"
  ON public.profiles FOR SELECT TO authenticated
  USING (
    is_employer_of_patient(auth.uid(), profiles.user_id)
  );

-- 3. Fix: Make signatures bucket private
UPDATE storage.buckets SET public = false WHERE id = 'signatures';

-- Update storage policy: remove public read, add authenticated read
DROP POLICY IF EXISTS "Signatures publicly readable" ON storage.objects;

CREATE POLICY "Authenticated users read signatures"
  ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'signatures');