
ALTER TABLE public.patient_cards 
ADD COLUMN IF NOT EXISTS education text,
ADD COLUMN IF NOT EXISTS professional_qual text,
ADD COLUMN IF NOT EXISTS notification_address text,
ADD COLUMN IF NOT EXISTS sports_habit text,
ADD COLUMN IF NOT EXISTS eating_habit text,
ADD COLUMN IF NOT EXISTS occupation_history jsonb DEFAULT '[]'::jsonb,
ADD COLUMN IF NOT EXISTS reported_occupational_diseases text,
ADD COLUMN IF NOT EXISTS military_service boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS exposures jsonb DEFAULT '{}'::jsonb;
