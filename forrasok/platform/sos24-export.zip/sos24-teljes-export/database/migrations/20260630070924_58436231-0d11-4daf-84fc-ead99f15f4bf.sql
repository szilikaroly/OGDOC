
CREATE OR REPLACE FUNCTION public.admin_get_recovery_history(_user_id uuid, _limit int DEFAULT 10)
RETURNS TABLE(
  id uuid,
  created_at timestamptz,
  status text,
  error_message text,
  message_id text,
  recipient_email text,
  metadata jsonb
)
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  _email text;
  _lim int := LEAST(GREATEST(COALESCE(_limit, 10), 1), 50);
BEGIN
  IF NOT public.has_role(auth.uid(), 'super_admin'::app_role) THEN
    RAISE EXCEPTION 'forbidden: super_admin role required';
  END IF;

  SELECT u.email::text INTO _email FROM auth.users u WHERE u.id = _user_id;
  IF _email IS NULL THEN
    RETURN;
  END IF;

  RETURN QUERY
  SELECT l.id, l.created_at, l.status, l.error_message, l.message_id, l.recipient_email, l.metadata
  FROM public.email_send_log l
  WHERE l.template_name = 'recovery'
    AND lower(l.recipient_email) = lower(_email)
  ORDER BY l.created_at DESC
  LIMIT _lim;
END;
$$;

REVOKE ALL ON FUNCTION public.admin_get_recovery_history(uuid, int) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.admin_get_recovery_history(uuid, int) TO authenticated;
