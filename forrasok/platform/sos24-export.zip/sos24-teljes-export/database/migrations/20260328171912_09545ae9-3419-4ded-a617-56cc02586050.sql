
-- Allow munkaltato to update profiles of their employees
CREATE POLICY "Munkaltato updates employee profiles"
ON public.profiles
FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.user_company_relations emp
    JOIN public.user_company_relations pat ON pat.company_id = emp.company_id
    WHERE emp.user_id = auth.uid()
      AND emp.role = 'munkaltato'
      AND emp.is_active = true
      AND pat.user_id = profiles.user_id
      AND pat.is_active = true
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.user_company_relations emp
    JOIN public.user_company_relations pat ON pat.company_id = emp.company_id
    WHERE emp.user_id = auth.uid()
      AND emp.role = 'munkaltato'
      AND emp.is_active = true
      AND pat.user_id = profiles.user_id
      AND pat.is_active = true
  )
);
