
-- ============================================================
-- 1. ENUMS
-- ============================================================
CREATE TYPE public.app_role AS ENUM (
  'super_admin',
  'haziorvos',
  'uzemorvos',
  'munkaltato',
  'munkavallalo',
  'praxistag'
);

CREATE TYPE public.gender_type AS ENUM ('ferfi', 'no', 'egyeb');
CREATE TYPE public.blood_type AS ENUM ('A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', '0+', '0-');
CREATE TYPE public.appointment_status AS ENUM ('pending', 'confirmed', 'cancelled', 'completed', 'no_show');
CREATE TYPE public.request_status AS ENUM ('pending', 'approved', 'rejected', 'completed');
CREATE TYPE public.opinion_status AS ENUM ('alkalmas', 'nem_alkalmas', 'feltetelesen_alkalmas', 'ideiglenes');

-- ============================================================
-- 2. UPDATED_AT TRIGGER FUNCTION
-- ============================================================
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- ============================================================
-- 3. PROFILES (közös biometriai adatok – minden szerepkörhöz egységes)
-- ============================================================
CREATE TABLE public.profiles (
  id            UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id       UUID NOT NULL UNIQUE,
  full_name     TEXT NOT NULL DEFAULT '',
  taj_number    TEXT UNIQUE,
  birth_date    DATE,
  gender        public.gender_type,
  blood_type    public.blood_type,
  mother_name   TEXT,
  birth_place   TEXT,
  phone         TEXT,
  address       TEXT,
  avatar_url    TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (user_id, full_name)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email, '')
  )
  ON CONFLICT (user_id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ============================================================
-- 4. USER_ROLES
-- ============================================================
CREATE TABLE public.user_roles (
  id         UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id    UUID NOT NULL,
  role       public.app_role NOT NULL,
  granted_by UUID,
  granted_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  );
$$;

CREATE OR REPLACE FUNCTION public.get_user_roles(_user_id UUID)
RETURNS public.app_role[]
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT ARRAY_AGG(role) FROM public.user_roles WHERE user_id = _user_id;
$$;

CREATE POLICY "Users see own roles"
  ON public.user_roles FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Super admins manage all roles"
  ON public.user_roles FOR ALL
  USING (public.has_role(auth.uid(), 'super_admin'));

-- Profiles RLS
CREATE POLICY "Users see own profile"
  ON public.profiles FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users update own profile"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users insert own profile"
  ON public.profiles FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Super admins see all profiles"
  ON public.profiles FOR SELECT
  USING (public.has_role(auth.uid(), 'super_admin'));

CREATE POLICY "Haziorvos sees member profiles"
  ON public.profiles FOR SELECT
  USING (public.has_role(auth.uid(), 'haziorvos'));

CREATE POLICY "Uzemorvos sees employee profiles"
  ON public.profiles FOR SELECT
  USING (public.has_role(auth.uid(), 'uzemorvos'));

CREATE POLICY "Munkaltato sees employee profiles"
  ON public.profiles FOR SELECT
  USING (public.has_role(auth.uid(), 'munkaltato'));

-- ============================================================
-- 5. COMPANIES
-- ============================================================
CREATE TABLE public.companies (
  id              UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name            TEXT NOT NULL,
  tax_number      TEXT UNIQUE,
  registration_no TEXT,
  address         TEXT,
  contact_email   TEXT,
  contact_phone   TEXT,
  industry        TEXT,
  created_by      UUID,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.companies ENABLE ROW LEVEL SECURITY;

CREATE TRIGGER update_companies_updated_at
  BEFORE UPDATE ON public.companies
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE POLICY "Authenticated users see companies"
  ON public.companies FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Super admins manage companies"
  ON public.companies FOR ALL
  USING (public.has_role(auth.uid(), 'super_admin'));

CREATE POLICY "Munkaltato manages own companies"
  ON public.companies FOR ALL
  USING (public.has_role(auth.uid(), 'munkaltato'));

-- ============================================================
-- 6. USER_COMPANY_RELATIONS
-- ============================================================
CREATE TABLE public.user_company_relations (
  id          UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id     UUID NOT NULL,
  company_id  UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  role        public.app_role NOT NULL DEFAULT 'munkavallalo',
  position    TEXT,
  is_active   BOOLEAN NOT NULL DEFAULT true,
  start_date  DATE,
  end_date    DATE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, company_id, role)
);

ALTER TABLE public.user_company_relations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users see own company relations"
  ON public.user_company_relations FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Munkaltato sees their company members"
  ON public.user_company_relations FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.user_company_relations ucr
      WHERE ucr.user_id = auth.uid()
        AND ucr.company_id = user_company_relations.company_id
        AND ucr.role = 'munkaltato'
    )
  );

CREATE POLICY "Super admins manage company relations"
  ON public.user_company_relations FOR ALL
  USING (public.has_role(auth.uid(), 'super_admin'));

CREATE POLICY "Munkaltato inserts employees"
  ON public.user_company_relations FOR INSERT
  WITH CHECK (
    public.has_role(auth.uid(), 'munkaltato') OR
    public.has_role(auth.uid(), 'super_admin')
  );

-- ============================================================
-- 7. SERVICES
-- ============================================================
CREATE TABLE public.services (
  id           UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name         TEXT NOT NULL,
  description  TEXT,
  duration_min INTEGER NOT NULL DEFAULT 30,
  category     TEXT,
  is_active    BOOLEAN NOT NULL DEFAULT true,
  price        NUMERIC(10,2),
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;

CREATE TRIGGER update_services_updated_at
  BEFORE UPDATE ON public.services
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE POLICY "Services readable by authenticated"
  ON public.services FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Super admins manage services"
  ON public.services FOR ALL
  USING (public.has_role(auth.uid(), 'super_admin'));

-- ============================================================
-- 8. LOCATIONS
-- ============================================================
CREATE TABLE public.locations (
  id         UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name       TEXT NOT NULL,
  address    TEXT,
  city       TEXT,
  is_active  BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.locations ENABLE ROW LEVEL SECURITY;

CREATE TRIGGER update_locations_updated_at
  BEFORE UPDATE ON public.locations
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE POLICY "Locations readable by authenticated"
  ON public.locations FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Super admins manage locations"
  ON public.locations FOR ALL
  USING (public.has_role(auth.uid(), 'super_admin'));

-- ============================================================
-- 9. APPOINTMENT_SLOTS
-- ============================================================
CREATE TABLE public.appointment_slots (
  id           UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  service_id   UUID REFERENCES public.services(id) ON DELETE SET NULL,
  location_id  UUID REFERENCES public.locations(id) ON DELETE SET NULL,
  doctor_id    UUID,
  assistant_id UUID,
  slot_start   TIMESTAMPTZ NOT NULL,
  slot_end     TIMESTAMPTZ NOT NULL,
  capacity     INTEGER NOT NULL DEFAULT 1,
  is_active    BOOLEAN NOT NULL DEFAULT true,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.appointment_slots ENABLE ROW LEVEL SECURITY;

CREATE TRIGGER update_slots_updated_at
  BEFORE UPDATE ON public.appointment_slots
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE POLICY "Slots readable by authenticated"
  ON public.appointment_slots FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Super admins manage slots"
  ON public.appointment_slots FOR ALL
  USING (public.has_role(auth.uid(), 'super_admin'));

CREATE POLICY "Uzemorvos manages slots"
  ON public.appointment_slots FOR ALL
  USING (public.has_role(auth.uid(), 'uzemorvos'));

-- ============================================================
-- 10. APPOINTMENTS
-- ============================================================
CREATE TABLE public.appointments (
  id          UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  slot_id     UUID REFERENCES public.appointment_slots(id) ON DELETE SET NULL,
  patient_id  UUID NOT NULL,
  service_id  UUID REFERENCES public.services(id) ON DELETE SET NULL,
  doctor_id   UUID,
  status      public.appointment_status NOT NULL DEFAULT 'pending',
  notes       TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;

CREATE TRIGGER update_appointments_updated_at
  BEFORE UPDATE ON public.appointments
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE POLICY "Patients see own appointments"
  ON public.appointments FOR SELECT
  USING (auth.uid() = patient_id);

CREATE POLICY "Patients insert own appointments"
  ON public.appointments FOR INSERT
  WITH CHECK (auth.uid() = patient_id);

CREATE POLICY "Patients update own appointments"
  ON public.appointments FOR UPDATE
  USING (auth.uid() = patient_id);

CREATE POLICY "Doctors see their appointments"
  ON public.appointments FOR SELECT
  USING (auth.uid() = doctor_id);

CREATE POLICY "Doctors update their appointments"
  ON public.appointments FOR UPDATE
  USING (auth.uid() = doctor_id);

CREATE POLICY "Haziorvos sees all appointments"
  ON public.appointments FOR SELECT
  USING (public.has_role(auth.uid(), 'haziorvos'));

CREATE POLICY "Uzemorvos sees all appointments"
  ON public.appointments FOR SELECT
  USING (public.has_role(auth.uid(), 'uzemorvos'));

CREATE POLICY "Super admins manage appointments"
  ON public.appointments FOR ALL
  USING (public.has_role(auth.uid(), 'super_admin'));

-- ============================================================
-- 11. MEDICAL_OPINIONS
-- ============================================================
CREATE TABLE public.medical_opinions (
  id              UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  patient_id      UUID NOT NULL,
  doctor_id       UUID NOT NULL,
  company_id      UUID REFERENCES public.companies(id) ON DELETE SET NULL,
  appointment_id  UUID REFERENCES public.appointments(id) ON DELETE SET NULL,
  opinion_date    DATE NOT NULL DEFAULT CURRENT_DATE,
  valid_until     DATE,
  status          public.opinion_status NOT NULL DEFAULT 'alkalmas',
  notes           TEXT,
  pdf_url         TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.medical_opinions ENABLE ROW LEVEL SECURITY;

CREATE TRIGGER update_opinions_updated_at
  BEFORE UPDATE ON public.medical_opinions
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE POLICY "Patients see own opinions"
  ON public.medical_opinions FOR SELECT
  USING (auth.uid() = patient_id);

CREATE POLICY "Doctors manage their opinions"
  ON public.medical_opinions FOR ALL
  USING (auth.uid() = doctor_id);

CREATE POLICY "Munkaltato sees company opinions"
  ON public.medical_opinions FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.user_company_relations ucr
      WHERE ucr.user_id = auth.uid()
        AND ucr.company_id = medical_opinions.company_id
        AND ucr.role = 'munkaltato'
    )
  );

CREATE POLICY "Super admins manage all opinions"
  ON public.medical_opinions FOR ALL
  USING (public.has_role(auth.uid(), 'super_admin'));

-- ============================================================
-- 12. QUESTIONNAIRES + SUBMISSIONS
-- ============================================================
CREATE TABLE public.questionnaires (
  id          UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title       TEXT NOT NULL,
  description TEXT,
  fields      JSONB NOT NULL DEFAULT '[]',
  is_active   BOOLEAN NOT NULL DEFAULT true,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.questionnaires ENABLE ROW LEVEL SECURITY;

CREATE TRIGGER update_questionnaires_updated_at
  BEFORE UPDATE ON public.questionnaires
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE POLICY "Questionnaires readable by authenticated"
  ON public.questionnaires FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Super admins manage questionnaires"
  ON public.questionnaires FOR ALL
  USING (public.has_role(auth.uid(), 'super_admin'));

CREATE TABLE public.questionnaire_submissions (
  id                UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  questionnaire_id  UUID NOT NULL REFERENCES public.questionnaires(id) ON DELETE CASCADE,
  user_id           UUID NOT NULL,
  answers           JSONB NOT NULL DEFAULT '{}',
  submitted_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.questionnaire_submissions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users see own submissions"
  ON public.questionnaire_submissions FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users insert own submissions"
  ON public.questionnaire_submissions FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Uzemorvos sees all submissions"
  ON public.questionnaire_submissions FOR SELECT
  USING (public.has_role(auth.uid(), 'uzemorvos'));

CREATE POLICY "Haziorvos sees submissions"
  ON public.questionnaire_submissions FOR SELECT
  USING (public.has_role(auth.uid(), 'haziorvos'));

CREATE POLICY "Super admins manage submissions"
  ON public.questionnaire_submissions FOR ALL
  USING (public.has_role(auth.uid(), 'super_admin'));

-- ============================================================
-- 13. REQUESTS
-- ============================================================
CREATE TABLE public.requests (
  id           UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  requester_id UUID NOT NULL,
  assignee_id  UUID,
  type         TEXT NOT NULL,
  subject      TEXT,
  description  TEXT,
  status       public.request_status NOT NULL DEFAULT 'pending',
  response     TEXT,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.requests ENABLE ROW LEVEL SECURITY;

CREATE TRIGGER update_requests_updated_at
  BEFORE UPDATE ON public.requests
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE POLICY "Users see own requests"
  ON public.requests FOR SELECT
  USING (auth.uid() = requester_id OR auth.uid() = assignee_id);

CREATE POLICY "Users insert own requests"
  ON public.requests FOR INSERT
  WITH CHECK (auth.uid() = requester_id);

CREATE POLICY "Assignee updates requests"
  ON public.requests FOR UPDATE
  USING (auth.uid() = assignee_id OR auth.uid() = requester_id);

CREATE POLICY "Haziorvos sees all requests"
  ON public.requests FOR SELECT
  USING (public.has_role(auth.uid(), 'haziorvos'));

CREATE POLICY "Haziorvos updates requests"
  ON public.requests FOR UPDATE
  USING (public.has_role(auth.uid(), 'haziorvos'));

CREATE POLICY "Super admins manage all requests"
  ON public.requests FOR ALL
  USING (public.has_role(auth.uid(), 'super_admin'));

-- ============================================================
-- 14. MESSAGES
-- ============================================================
CREATE TABLE public.messages (
  id           UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  sender_id    UUID NOT NULL,
  recipient_id UUID,
  group_role   public.app_role,
  subject      TEXT,
  body         TEXT NOT NULL,
  is_read      BOOLEAN NOT NULL DEFAULT false,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users see own messages"
  ON public.messages FOR SELECT
  USING (
    auth.uid() = sender_id
    OR auth.uid() = recipient_id
    OR (group_role IS NOT NULL AND public.has_role(auth.uid(), group_role))
  );

CREATE POLICY "Users send messages"
  ON public.messages FOR INSERT
  WITH CHECK (auth.uid() = sender_id);

CREATE POLICY "Super admins manage messages"
  ON public.messages FOR ALL
  USING (public.has_role(auth.uid(), 'super_admin'));

-- ============================================================
-- 15. SITE_SETTINGS (CMS)
-- ============================================================
CREATE TABLE public.site_settings (
  id          UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  key         TEXT NOT NULL UNIQUE,
  value       TEXT,
  value_json  JSONB,
  label       TEXT,
  section     TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;

CREATE TRIGGER update_site_settings_updated_at
  BEFORE UPDATE ON public.site_settings
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE POLICY "Site settings readable by everyone"
  ON public.site_settings FOR SELECT
  USING (true);

CREATE POLICY "Super admins manage site settings"
  ON public.site_settings FOR ALL
  USING (public.has_role(auth.uid(), 'super_admin'));

-- ============================================================
-- 16. NAVIGATION_LINKS
-- ============================================================
CREATE TABLE public.navigation_links (
  id         UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  label      TEXT NOT NULL,
  href       TEXT NOT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_active  BOOLEAN NOT NULL DEFAULT true,
  parent_id  UUID REFERENCES public.navigation_links(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.navigation_links ENABLE ROW LEVEL SECURITY;

CREATE TRIGGER update_nav_links_updated_at
  BEFORE UPDATE ON public.navigation_links
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE POLICY "Nav links readable by everyone"
  ON public.navigation_links FOR SELECT
  USING (true);

CREATE POLICY "Super admins manage nav links"
  ON public.navigation_links FOR ALL
  USING (public.has_role(auth.uid(), 'super_admin'));

-- ============================================================
-- 17. PAGES_CONTENT
-- ============================================================
CREATE TABLE public.pages_content (
  id           UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  page_key     TEXT NOT NULL,
  section      TEXT NOT NULL,
  content      TEXT,
  content_json JSONB,
  is_active    BOOLEAN NOT NULL DEFAULT true,
  sort_order   INTEGER NOT NULL DEFAULT 0,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (page_key, section)
);

ALTER TABLE public.pages_content ENABLE ROW LEVEL SECURITY;

CREATE TRIGGER update_pages_content_updated_at
  BEFORE UPDATE ON public.pages_content
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE POLICY "Pages content readable by everyone"
  ON public.pages_content FOR SELECT
  USING (true);

CREATE POLICY "Super admins manage pages content"
  ON public.pages_content FOR ALL
  USING (public.has_role(auth.uid(), 'super_admin'));

-- ============================================================
-- 18. HEALTH_REPORTS
-- ============================================================
CREATE TABLE public.health_reports (
  id              UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id         UUID NOT NULL,
  report_date     DATE NOT NULL DEFAULT CURRENT_DATE,
  weight_kg       NUMERIC(5,2),
  height_cm       NUMERIC(5,1),
  blood_pressure_systolic  INTEGER,
  blood_pressure_diastolic INTEGER,
  heart_rate      INTEGER,
  blood_sugar     NUMERIC(5,2),
  notes           TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.health_reports ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage own health reports"
  ON public.health_reports FOR ALL
  USING (auth.uid() = user_id);

CREATE POLICY "Haziorvos sees health reports"
  ON public.health_reports FOR SELECT
  USING (public.has_role(auth.uid(), 'haziorvos'));

CREATE POLICY "Super admins see all health reports"
  ON public.health_reports FOR SELECT
  USING (public.has_role(auth.uid(), 'super_admin'));
