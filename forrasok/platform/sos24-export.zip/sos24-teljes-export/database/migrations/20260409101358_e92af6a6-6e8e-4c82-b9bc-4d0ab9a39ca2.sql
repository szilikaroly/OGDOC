
-- ALTER tables FIRST (so RLS can reference new columns)
ALTER TABLE public.user_company_relations
  ADD COLUMN IF NOT EXISTS site_id uuid,
  ADD COLUMN IF NOT EXISTS work_area_id uuid,
  ADD COLUMN IF NOT EXISTS workplace_id uuid;

ALTER TABLE public.referrals
  ADD COLUMN IF NOT EXISTS work_area_id uuid,
  ADD COLUMN IF NOT EXISTS workplace_id uuid,
  ADD COLUMN IF NOT EXISTS risk_assessment_id uuid;

-- Enums (IF NOT EXISTS not supported for TYPE, use DO block)
DO $$ BEGIN
  CREATE TYPE public.hazard_category AS ENUM (
    'physical', 'chemical', 'biological', 'ergonomic',
    'psychosocial', 'equipment', 'environment', 'fire', 'other'
  );
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE TYPE public.risk_assessment_status AS ENUM (
    'draft', 'in_review', 'approved', 'archived'
  );
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE TYPE public.action_status AS ENUM (
    'planned', 'in_progress', 'completed'
  );
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE TYPE public.action_hierarchy AS ENUM (
    'elimination', 'substitution', 'engineering', 'admin', 'ppe'
  );
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- ============================================================
-- TABLE: company_sites
-- ============================================================
CREATE TABLE public.company_sites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  name text NOT NULL,
  address text,
  city text,
  postal_code text,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.company_sites ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Super admins manage company_sites" ON public.company_sites FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'super_admin')) WITH CHECK (public.has_role(auth.uid(), 'super_admin'));

CREATE POLICY "Uzemorvos manages company_sites" ON public.company_sites FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'uzemorvos')) WITH CHECK (public.has_role(auth.uid(), 'uzemorvos'));

CREATE POLICY "Munkaltato sees own company sites" ON public.company_sites FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.user_company_relations
    WHERE user_company_relations.user_id = auth.uid()
      AND user_company_relations.company_id = company_sites.company_id
      AND user_company_relations.is_active = true
  ));

CREATE POLICY "Munkaltato manages own company sites" ON public.company_sites FOR ALL TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.user_company_relations
    WHERE user_company_relations.user_id = auth.uid()
      AND user_company_relations.company_id = company_sites.company_id
      AND user_company_relations.role = 'munkaltato'
      AND user_company_relations.is_active = true
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM public.user_company_relations
    WHERE user_company_relations.user_id = auth.uid()
      AND user_company_relations.company_id = company_sites.company_id
      AND user_company_relations.role = 'munkaltato'
      AND user_company_relations.is_active = true
  ));

CREATE TRIGGER update_company_sites_updated_at BEFORE UPDATE ON public.company_sites
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ============================================================
-- TABLE: work_areas
-- ============================================================
CREATE TABLE public.work_areas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  site_id uuid NOT NULL REFERENCES public.company_sites(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  area_size_m2 numeric,
  floor_plan_url text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.work_areas ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Super admins manage work_areas" ON public.work_areas FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'super_admin')) WITH CHECK (public.has_role(auth.uid(), 'super_admin'));

CREATE POLICY "Uzemorvos manages work_areas" ON public.work_areas FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'uzemorvos')) WITH CHECK (public.has_role(auth.uid(), 'uzemorvos'));

CREATE POLICY "Company members see work_areas" ON public.work_areas FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.company_sites cs
    JOIN public.user_company_relations ucr ON ucr.company_id = cs.company_id
    WHERE cs.id = work_areas.site_id
      AND ucr.user_id = auth.uid()
      AND ucr.is_active = true
  ));

CREATE POLICY "Munkaltato manages work_areas" ON public.work_areas FOR ALL TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.company_sites cs
    JOIN public.user_company_relations ucr ON ucr.company_id = cs.company_id
    WHERE cs.id = work_areas.site_id
      AND ucr.user_id = auth.uid()
      AND ucr.role = 'munkaltato'
      AND ucr.is_active = true
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM public.company_sites cs
    JOIN public.user_company_relations ucr ON ucr.company_id = cs.company_id
    WHERE cs.id = work_areas.site_id
      AND ucr.user_id = auth.uid()
      AND ucr.role = 'munkaltato'
      AND ucr.is_active = true
  ));

CREATE TRIGGER update_work_areas_updated_at BEFORE UPDATE ON public.work_areas
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ============================================================
-- TABLE: workplaces
-- ============================================================
CREATE TABLE public.workplaces (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  work_area_id uuid NOT NULL REFERENCES public.work_areas(id) ON DELETE CASCADE,
  name text NOT NULL,
  code text,
  description text,
  equipment_list jsonb DEFAULT '[]'::jsonb,
  employee_count integer DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.workplaces ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Super admins manage workplaces" ON public.workplaces FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'super_admin')) WITH CHECK (public.has_role(auth.uid(), 'super_admin'));

CREATE POLICY "Uzemorvos manages workplaces" ON public.workplaces FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'uzemorvos')) WITH CHECK (public.has_role(auth.uid(), 'uzemorvos'));

CREATE POLICY "Company members see workplaces" ON public.workplaces FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.work_areas wa
    JOIN public.company_sites cs ON cs.id = wa.site_id
    JOIN public.user_company_relations ucr ON ucr.company_id = cs.company_id
    WHERE wa.id = workplaces.work_area_id
      AND ucr.user_id = auth.uid()
      AND ucr.is_active = true
  ));

CREATE POLICY "Munkaltato manages workplaces" ON public.workplaces FOR ALL TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.work_areas wa
    JOIN public.company_sites cs ON cs.id = wa.site_id
    JOIN public.user_company_relations ucr ON ucr.company_id = cs.company_id
    WHERE wa.id = workplaces.work_area_id
      AND ucr.user_id = auth.uid()
      AND ucr.role = 'munkaltato'
      AND ucr.is_active = true
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM public.work_areas wa
    JOIN public.company_sites cs ON cs.id = wa.site_id
    JOIN public.user_company_relations ucr ON ucr.company_id = cs.company_id
    WHERE wa.id = workplaces.work_area_id
      AND ucr.user_id = auth.uid()
      AND ucr.role = 'munkaltato'
      AND ucr.is_active = true
  ));

CREATE TRIGGER update_workplaces_updated_at BEFORE UPDATE ON public.workplaces
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Now add FKs on the already-altered columns
ALTER TABLE public.user_company_relations
  ADD CONSTRAINT ucr_site_id_fk FOREIGN KEY (site_id) REFERENCES public.company_sites(id) ON DELETE SET NULL,
  ADD CONSTRAINT ucr_work_area_id_fk FOREIGN KEY (work_area_id) REFERENCES public.work_areas(id) ON DELETE SET NULL,
  ADD CONSTRAINT ucr_workplace_id_fk FOREIGN KEY (workplace_id) REFERENCES public.workplaces(id) ON DELETE SET NULL;

-- ============================================================
-- TABLE: risk_assessments
-- ============================================================
CREATE TABLE public.risk_assessments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  work_area_id uuid NOT NULL REFERENCES public.work_areas(id) ON DELETE CASCADE,
  title text NOT NULL DEFAULT '',
  assessment_date date NOT NULL DEFAULT CURRENT_DATE,
  assessor_name text,
  assessor_qualification text,
  status public.risk_assessment_status NOT NULL DEFAULT 'draft',
  approved_by uuid,
  approved_at timestamptz,
  next_review_date date,
  review_frequency_months integer DEFAULT 12,
  previous_assessment_id uuid REFERENCES public.risk_assessments(id),
  context_analysis jsonb DEFAULT '{}'::jsonb,
  summary_notes text,
  document_url text,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.risk_assessments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Super admins manage risk_assessments" ON public.risk_assessments FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'super_admin')) WITH CHECK (public.has_role(auth.uid(), 'super_admin'));

CREATE POLICY "Uzemorvos manages risk_assessments" ON public.risk_assessments FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'uzemorvos')) WITH CHECK (public.has_role(auth.uid(), 'uzemorvos'));

CREATE POLICY "Munkaltato sees own company assessments" ON public.risk_assessments FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.user_company_relations
    WHERE user_company_relations.user_id = auth.uid()
      AND user_company_relations.company_id = risk_assessments.company_id
      AND user_company_relations.role = 'munkaltato'
      AND user_company_relations.is_active = true
  ));

CREATE POLICY "Munkavallalo sees own work area assessments" ON public.risk_assessments FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.user_company_relations
    WHERE user_company_relations.user_id = auth.uid()
      AND user_company_relations.company_id = risk_assessments.company_id
      AND user_company_relations.work_area_id = risk_assessments.work_area_id
      AND user_company_relations.is_active = true
  ));

CREATE TRIGGER update_risk_assessments_updated_at BEFORE UPDATE ON public.risk_assessments
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Add FK for referrals now
ALTER TABLE public.referrals
  ADD CONSTRAINT referrals_work_area_id_fk FOREIGN KEY (work_area_id) REFERENCES public.work_areas(id) ON DELETE SET NULL,
  ADD CONSTRAINT referrals_workplace_id_fk FOREIGN KEY (workplace_id) REFERENCES public.workplaces(id) ON DELETE SET NULL,
  ADD CONSTRAINT referrals_risk_assessment_id_fk FOREIGN KEY (risk_assessment_id) REFERENCES public.risk_assessments(id) ON DELETE SET NULL;

-- ============================================================
-- TABLE: risk_assessment_hazards
-- ============================================================
CREATE TABLE public.risk_assessment_hazards (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  risk_assessment_id uuid NOT NULL REFERENCES public.risk_assessments(id) ON DELETE CASCADE,
  workplace_id uuid REFERENCES public.workplaces(id) ON DELETE SET NULL,
  hazard_category public.hazard_category NOT NULL DEFAULT 'other',
  hazard_subcategory text,
  hazard_name text NOT NULL,
  hazard_description text,
  exposed_count integer DEFAULT 0,
  exposure_duration text,
  exposure_frequency text,
  probability integer DEFAULT 1 CHECK (probability >= 1 AND probability <= 4),
  severity integer DEFAULT 1 CHECK (severity >= 1 AND severity <= 4),
  risk_level integer GENERATED ALWAYS AS (probability * severity) STORED,
  risk_category text GENERATED ALWAYS AS (
    CASE
      WHEN probability * severity <= 2 THEN 'trivial'
      WHEN probability * severity <= 4 THEN 'tolerable'
      WHEN probability * severity <= 6 THEN 'moderate'
      WHEN probability * severity <= 9 THEN 'substantial'
      ELSE 'intolerable'
    END
  ) STORED,
  current_controls text,
  required_actions text,
  action_responsible text,
  action_deadline date,
  action_status public.action_status DEFAULT 'planned',
  action_hierarchy public.action_hierarchy,
  residual_probability integer CHECK (residual_probability IS NULL OR (residual_probability >= 1 AND residual_probability <= 4)),
  residual_severity integer CHECK (residual_severity IS NULL OR (residual_severity >= 1 AND residual_severity <= 4)),
  residual_risk_level integer GENERATED ALWAYS AS (
    CASE WHEN residual_probability IS NOT NULL AND residual_severity IS NOT NULL
      THEN residual_probability * residual_severity
      ELSE NULL
    END
  ) STORED,
  substance_ids uuid[] DEFAULT '{}',
  ai_suggested boolean DEFAULT false,
  sort_order integer DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.risk_assessment_hazards ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Super admins manage hazards" ON public.risk_assessment_hazards FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'super_admin')) WITH CHECK (public.has_role(auth.uid(), 'super_admin'));

CREATE POLICY "Uzemorvos manages hazards" ON public.risk_assessment_hazards FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'uzemorvos')) WITH CHECK (public.has_role(auth.uid(), 'uzemorvos'));

CREATE POLICY "Company members see hazards" ON public.risk_assessment_hazards FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.risk_assessments ra
    JOIN public.user_company_relations ucr ON ucr.company_id = ra.company_id
    WHERE ra.id = risk_assessment_hazards.risk_assessment_id
      AND ucr.user_id = auth.uid()
      AND ucr.is_active = true
  ));

-- ============================================================
-- TABLE: risk_assessment_photos
-- ============================================================
CREATE TABLE public.risk_assessment_photos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  risk_assessment_id uuid NOT NULL REFERENCES public.risk_assessments(id) ON DELETE CASCADE,
  work_area_id uuid REFERENCES public.work_areas(id) ON DELETE SET NULL,
  workplace_id uuid REFERENCES public.workplaces(id) ON DELETE SET NULL,
  file_path text NOT NULL,
  file_name text NOT NULL,
  caption text,
  ai_analysis jsonb,
  uploaded_by uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.risk_assessment_photos ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Super admins manage photos" ON public.risk_assessment_photos FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'super_admin')) WITH CHECK (public.has_role(auth.uid(), 'super_admin'));

CREATE POLICY "Uzemorvos manages photos" ON public.risk_assessment_photos FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'uzemorvos')) WITH CHECK (public.has_role(auth.uid(), 'uzemorvos'));

CREATE POLICY "Company members see photos" ON public.risk_assessment_photos FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.risk_assessments ra
    JOIN public.user_company_relations ucr ON ucr.company_id = ra.company_id
    WHERE ra.id = risk_assessment_photos.risk_assessment_id
      AND ucr.user_id = auth.uid()
      AND ucr.is_active = true
  ));

CREATE POLICY "Munkaltato inserts photos" ON public.risk_assessment_photos FOR INSERT TO authenticated
  WITH CHECK (EXISTS (
    SELECT 1 FROM public.risk_assessments ra
    JOIN public.user_company_relations ucr ON ucr.company_id = ra.company_id
    WHERE ra.id = risk_assessment_photos.risk_assessment_id
      AND ucr.user_id = auth.uid()
      AND ucr.role = 'munkaltato'
      AND ucr.is_active = true
  ));

-- ============================================================
-- Storage bucket
-- ============================================================
INSERT INTO storage.buckets (id, name, public) VALUES ('risk-assessment-photos', 'risk-assessment-photos', false)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Auth users upload risk photos" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'risk-assessment-photos');

CREATE POLICY "Auth users read risk photos" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'risk-assessment-photos');

CREATE POLICY "Admins delete risk photos" ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'risk-assessment-photos' AND (
    public.has_role(auth.uid(), 'super_admin') OR public.has_role(auth.uid(), 'uzemorvos')
  ));

-- ============================================================
-- Indexes
-- ============================================================
CREATE INDEX idx_company_sites_company ON public.company_sites(company_id);
CREATE INDEX idx_work_areas_site ON public.work_areas(site_id);
CREATE INDEX idx_workplaces_work_area ON public.workplaces(work_area_id);
CREATE INDEX idx_risk_assessments_company ON public.risk_assessments(company_id);
CREATE INDEX idx_risk_assessments_work_area ON public.risk_assessments(work_area_id);
CREATE INDEX idx_risk_assessment_hazards_assessment ON public.risk_assessment_hazards(risk_assessment_id);
CREATE INDEX idx_risk_assessment_photos_assessment ON public.risk_assessment_photos(risk_assessment_id);
CREATE INDEX idx_ucr_site ON public.user_company_relations(site_id);
CREATE INDEX idx_ucr_work_area ON public.user_company_relations(work_area_id);
CREATE INDEX idx_referrals_work_area ON public.referrals(work_area_id);
