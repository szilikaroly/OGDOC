
-- Allow public (unauthenticated) users to read active locations
DROP POLICY IF EXISTS "Locations readable by authenticated" ON public.locations;
CREATE POLICY "Locations readable by everyone"
  ON public.locations
  FOR SELECT
  TO public
  USING (true);
