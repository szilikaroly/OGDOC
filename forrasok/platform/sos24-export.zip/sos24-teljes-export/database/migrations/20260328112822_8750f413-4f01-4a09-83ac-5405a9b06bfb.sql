-- Fix 1: user_roles - drop messaging policy (own roles policy already exists)
DROP POLICY IF EXISTS "Authenticated see user_roles for messaging" ON public.user_roles;

-- Fix 2: documents - remove overly permissive public INSERT
DROP POLICY IF EXISTS "Service inserts documents" ON public.documents;

-- Fix 3: audit_logs - remove overly permissive public INSERT
DROP POLICY IF EXISTS "Service inserts audit logs" ON public.audit_logs;

-- Fix 4: notifications - remove overly permissive public INSERT
DROP POLICY IF EXISTS "Service inserts notifications" ON public.notifications;

-- Fix 5: companies - restrict SELECT to company members + admins
DROP POLICY IF EXISTS "Authenticated users see companies" ON public.companies;
CREATE POLICY "Company members and admins see companies"
  ON public.companies FOR SELECT TO authenticated
  USING (
    public.has_role(auth.uid(), 'super_admin')
    OR public.has_role(auth.uid(), 'uzemorvos')
    OR EXISTS (
      SELECT 1 FROM public.user_company_relations
      WHERE user_company_relations.company_id = companies.id
        AND user_company_relations.user_id = auth.uid()
        AND user_company_relations.is_active = true
    )
  );

-- Fix 6: is_employer_of_patient - add is_active filter
CREATE OR REPLACE FUNCTION public.is_employer_of_patient(_employer_id uuid, _patient_id uuid)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_company_relations emp
    JOIN public.user_company_relations pat ON pat.company_id = emp.company_id
    WHERE emp.user_id = _employer_id
      AND emp.role = 'munkaltato'
      AND emp.is_active = true
      AND pat.user_id = _patient_id
      AND pat.is_active = true
  )
$$;

-- Fix 7: is_company_member - add is_active filter
CREATE OR REPLACE FUNCTION public.is_company_member(_user_id uuid, _company_id uuid, _role app_role)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_company_relations
    WHERE user_id = _user_id
      AND company_id = _company_id
      AND role = _role
      AND is_active = true
  )
$$;

-- Fix 8: Set search_path on email RPC functions
CREATE OR REPLACE FUNCTION public.enqueue_email(queue_name text, payload jsonb)
 RETURNS bigint
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $$
BEGIN
  RETURN pgmq.send(queue_name, payload);
EXCEPTION WHEN undefined_table THEN
  PERFORM pgmq.create(queue_name);
  RETURN pgmq.send(queue_name, payload);
END;
$$;

CREATE OR REPLACE FUNCTION public.read_email_batch(queue_name text, batch_size integer, vt integer)
 RETURNS TABLE(msg_id bigint, read_ct integer, message jsonb)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $$
BEGIN
  RETURN QUERY SELECT r.msg_id, r.read_ct, r.message FROM pgmq.read(queue_name, vt, batch_size) r;
EXCEPTION WHEN undefined_table THEN
  PERFORM pgmq.create(queue_name);
  RETURN;
END;
$$;

CREATE OR REPLACE FUNCTION public.delete_email(queue_name text, message_id bigint)
 RETURNS boolean
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $$
BEGIN
  RETURN pgmq.delete(queue_name, message_id);
EXCEPTION WHEN undefined_table THEN
  RETURN FALSE;
END;
$$;

CREATE OR REPLACE FUNCTION public.move_to_dlq(source_queue text, dlq_name text, message_id bigint, payload jsonb)
 RETURNS bigint
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $$
DECLARE new_id BIGINT;
BEGIN
  SELECT pgmq.send(dlq_name, payload) INTO new_id;
  PERFORM pgmq.delete(source_queue, message_id);
  RETURN new_id;
EXCEPTION WHEN undefined_table THEN
  BEGIN
    PERFORM pgmq.create(dlq_name);
  EXCEPTION WHEN OTHERS THEN
    NULL;
  END;
  SELECT pgmq.send(dlq_name, payload) INTO new_id;
  BEGIN
    PERFORM pgmq.delete(source_queue, message_id);
  EXCEPTION WHEN undefined_table THEN
    NULL;
  END;
  RETURN new_id;
END;
$$;