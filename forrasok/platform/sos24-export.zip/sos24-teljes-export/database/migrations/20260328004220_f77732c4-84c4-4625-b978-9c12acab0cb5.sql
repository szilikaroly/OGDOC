
-- Use DROP IF EXISTS + CREATE to safely add triggers
DROP TRIGGER IF EXISTS audit_examinations ON public.examinations;
DROP TRIGGER IF EXISTS audit_medical_opinions ON public.medical_opinions;
DROP TRIGGER IF EXISTS audit_patient_cards ON public.patient_cards;
DROP TRIGGER IF EXISTS audit_referrals ON public.referrals;
DROP TRIGGER IF EXISTS audit_appointments ON public.appointments;
DROP TRIGGER IF EXISTS audit_documents ON public.documents;
DROP TRIGGER IF EXISTS audit_vaccinations ON public.vaccinations;
DROP TRIGGER IF EXISTS audit_medication_requests ON public.medication_requests;
DROP TRIGGER IF EXISTS audit_profiles ON public.profiles;

CREATE TRIGGER audit_examinations AFTER INSERT OR UPDATE OR DELETE ON public.examinations FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();
CREATE TRIGGER audit_medical_opinions AFTER INSERT OR UPDATE OR DELETE ON public.medical_opinions FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();
CREATE TRIGGER audit_patient_cards AFTER INSERT OR UPDATE OR DELETE ON public.patient_cards FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();
CREATE TRIGGER audit_referrals AFTER INSERT OR UPDATE OR DELETE ON public.referrals FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();
CREATE TRIGGER audit_appointments AFTER INSERT OR UPDATE OR DELETE ON public.appointments FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();
CREATE TRIGGER audit_documents AFTER INSERT OR UPDATE OR DELETE ON public.documents FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();
CREATE TRIGGER audit_vaccinations AFTER INSERT OR UPDATE OR DELETE ON public.vaccinations FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();
CREATE TRIGGER audit_medication_requests AFTER INSERT OR UPDATE OR DELETE ON public.medication_requests FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();
CREATE TRIGGER audit_profiles AFTER INSERT OR UPDATE OR DELETE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();

-- Auto-update referral status when questionnaire is submitted
CREATE OR REPLACE FUNCTION public.auto_update_referral_on_questionnaire()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  UPDATE public.referrals
  SET status = 'questionnaire_filled', updated_at = now()
  WHERE employee_id = NEW.user_id
    AND status IN ('sent', 'appointment_booked')
    AND updated_at = (
      SELECT MAX(updated_at) FROM public.referrals
      WHERE employee_id = NEW.user_id AND status IN ('sent', 'appointment_booked')
    );
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS auto_referral_questionnaire_status ON public.questionnaire_submissions;
CREATE TRIGGER auto_referral_questionnaire_status
AFTER INSERT ON public.questionnaire_submissions
FOR EACH ROW EXECUTE FUNCTION public.auto_update_referral_on_questionnaire();
