
-- Document template configuration table
CREATE TABLE public.document_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  document_type TEXT NOT NULL,
  name TEXT NOT NULL,
  fields JSONB NOT NULL DEFAULT '[]'::jsonb,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(document_type)
);

-- Enable RLS
ALTER TABLE public.document_templates ENABLE ROW LEVEL SECURITY;

-- Anyone can read (templates are needed for rendering documents)
CREATE POLICY "Anyone can read document templates"
  ON public.document_templates FOR SELECT
  TO authenticated
  USING (true);

-- Only super_admin can modify
CREATE POLICY "Super admins manage document templates"
  ON public.document_templates FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'super_admin'))
  WITH CHECK (public.has_role(auth.uid(), 'super_admin'));

-- Trigger for updated_at
CREATE TRIGGER update_document_templates_updated_at
  BEFORE UPDATE ON public.document_templates
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Seed default templates with all fields enabled
INSERT INTO public.document_templates (document_type, name, fields) VALUES
('opinion', 'Alkalmassági vélemény', '[
  {"key":"header_regulation","label":"Munkavédelmi szabályzat fejléc","source":"static","visible":true,"order":1},
  {"key":"service_name","label":"Szolgálat megnevezése","source":"service","visible":true,"order":2},
  {"key":"patient_name","label":"Páciens neve","source":"profile.full_name","visible":true,"order":3},
  {"key":"patient_taj","label":"TAJ szám","source":"profile.taj_number","visible":false,"order":4},
  {"key":"patient_birth","label":"Születési dátum","source":"profile.birth_date","visible":false,"order":5},
  {"key":"position","label":"Munkakör","source":"referral.position","visible":true,"order":6},
  {"key":"status_boxes","label":"Alkalmasság jelölő dobozok","source":"examination.result","visible":true,"order":7},
  {"key":"restrictions","label":"Korlátozások","source":"examination.restrictions","visible":true,"order":8},
  {"key":"valid_until","label":"Érvényesség","source":"examination.valid_until","visible":true,"order":9},
  {"key":"opinion_date","label":"Kelt dátum","source":"opinion.opinion_date","visible":true,"order":10},
  {"key":"stamp","label":"P.H. pecsét hely","source":"static","visible":true,"order":11},
  {"key":"signature","label":"Orvosi aláírás","source":"profile.signature_url","visible":true,"order":12},
  {"key":"ai_notes","label":"AI megjegyzés","source":"examination.ai_notes","visible":false,"order":13},
  {"key":"notes","label":"Megjegyzés","source":"opinion.notes","visible":true,"order":14}
]'::jsonb),
('exam_sheet', 'Vizsgálati jegyzőkönyv', '[
  {"key":"patient_name","label":"Páciens neve","source":"profile.full_name","visible":true,"order":1},
  {"key":"patient_taj","label":"TAJ szám","source":"profile.taj_number","visible":true,"order":2},
  {"key":"exam_type","label":"Vizsgálat típusa","source":"examination.exam_type","visible":true,"order":3},
  {"key":"exam_date","label":"Vizsgálat dátuma","source":"examination.created_at","visible":true,"order":4},
  {"key":"anamnesis","label":"Anamnézis","source":"examination.patient_data","visible":true,"order":5},
  {"key":"clinical_findings","label":"Fizikális vizsgálat","source":"examination.clinical_findings","visible":true,"order":6},
  {"key":"result","label":"Eredmény","source":"examination.result","visible":true,"order":7},
  {"key":"valid_until","label":"Érvényesség","source":"examination.valid_until","visible":true,"order":8},
  {"key":"restrictions","label":"Korlátozások","source":"examination.restrictions","visible":true,"order":9},
  {"key":"ai_notes","label":"AI megjegyzés","source":"examination.ai_notes","visible":false,"order":10},
  {"key":"questionnaire_data","label":"Kérdőív adatok","source":"questionnaire","visible":true,"order":11},
  {"key":"patient_card","label":"Törzskarton adatok","source":"patient_card","visible":true,"order":12},
  {"key":"signature","label":"Orvosi aláírás","source":"profile.signature_url","visible":true,"order":13}
]'::jsonb),
('referral', 'Beutaló', '[
  {"key":"company_name","label":"Cég neve","source":"company.name","visible":true,"order":1},
  {"key":"employee_name","label":"Munkavállaló neve","source":"profile.full_name","visible":true,"order":2},
  {"key":"employee_taj","label":"TAJ szám","source":"profile.taj_number","visible":true,"order":3},
  {"key":"position","label":"Munkakör","source":"referral.position","visible":true,"order":4},
  {"key":"exam_reason","label":"Vizsgálat oka","source":"referral.exam_reason","visible":true,"order":5},
  {"key":"risk_factors","label":"Kockázati tényezők","source":"referral.risk_factors","visible":true,"order":6},
  {"key":"feor","label":"FEOR kód","source":"referral.feor","visible":true,"order":7},
  {"key":"unit_name","label":"Szervezeti egység","source":"referral.unit_name","visible":true,"order":8}
]'::jsonb),
('vaccination_cert', 'Oltásigazolás', '[
  {"key":"patient_name","label":"Páciens neve","source":"profile.full_name","visible":true,"order":1},
  {"key":"patient_taj","label":"TAJ szám","source":"profile.taj_number","visible":true,"order":2},
  {"key":"patient_birth","label":"Születési dátum","source":"profile.birth_date","visible":true,"order":3},
  {"key":"vaccine_name","label":"Oltóanyag neve","source":"vaccination.vaccine_name","visible":true,"order":4},
  {"key":"administered_date","label":"Oltás dátuma","source":"vaccination.administered_date","visible":true,"order":5},
  {"key":"lot_number","label":"Sarzsszám","source":"vaccination.lot_number","visible":true,"order":6},
  {"key":"expiry_date","label":"Lejárat","source":"vaccination.expiry_date","visible":true,"order":7},
  {"key":"administered_by","label":"Beadta","source":"vaccination.administered_by","visible":true,"order":8},
  {"key":"signature","label":"Orvosi aláírás","source":"profile.signature_url","visible":true,"order":9}
]'::jsonb),
('certificate', 'Igazolás', '[
  {"key":"patient_name","label":"Páciens neve","source":"profile.full_name","visible":true,"order":1},
  {"key":"patient_taj","label":"TAJ szám","source":"profile.taj_number","visible":true,"order":2},
  {"key":"patient_birth","label":"Születési dátum","source":"profile.birth_date","visible":true,"order":3},
  {"key":"content","label":"Igazolás tartalma","source":"custom","visible":true,"order":4},
  {"key":"date","label":"Kelt dátum","source":"static","visible":true,"order":5},
  {"key":"signature","label":"Orvosi aláírás","source":"profile.signature_url","visible":true,"order":6}
]'::jsonb);
