
-- ============================================================
-- 1. Locations: remove public anonymous SELECT, add SECURITY DEFINER RPC for landing page
-- ============================================================
DROP POLICY IF EXISTS "Locations readable by everyone" ON public.locations;
DROP POLICY IF EXISTS "Locations readable by authenticated" ON public.locations;

CREATE POLICY "Locations readable by authenticated"
  ON public.locations
  FOR SELECT
  TO authenticated
  USING (true);

REVOKE SELECT ON public.locations FROM anon;

CREATE OR REPLACE FUNCTION public.get_public_locations()
RETURNS TABLE (
  id uuid,
  name text,
  address text,
  city text,
  email text,
  phone text,
  whatsapp text,
  google_maps_url text,
  description text
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT id, name, address, city, email, phone, whatsapp, google_maps_url, description
  FROM public.locations
  WHERE is_active = true
  ORDER BY name;
$$;

GRANT EXECUTE ON FUNCTION public.get_public_locations() TO anon, authenticated;

-- ============================================================
-- 2. Storage: restrict risk-assessment-photos bucket to company members
-- ============================================================
DROP POLICY IF EXISTS "Auth users read risk photos" ON storage.objects;
DROP POLICY IF EXISTS "Auth users upload risk photos" ON storage.objects;

-- Path convention: "{risk_assessment_id}/{filename}"
CREATE POLICY "Risk photos read: company members and staff"
  ON storage.objects FOR SELECT TO authenticated
  USING (
    bucket_id = 'risk-assessment-photos'
    AND (
      public.has_role(auth.uid(), 'super_admin')
      OR public.has_role(auth.uid(), 'uzemorvos')
      OR EXISTS (
        SELECT 1
        FROM public.risk_assessments ra
        JOIN public.user_company_relations ucr
          ON ucr.company_id = ra.company_id
        WHERE ra.id::text = split_part(storage.objects.name, '/', 1)
          AND ucr.user_id = auth.uid()
          AND ucr.is_active = true
      )
    )
  );

CREATE POLICY "Risk photos upload: company members and staff"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'risk-assessment-photos'
    AND (
      public.has_role(auth.uid(), 'super_admin')
      OR public.has_role(auth.uid(), 'uzemorvos')
      OR EXISTS (
        SELECT 1
        FROM public.risk_assessments ra
        JOIN public.user_company_relations ucr
          ON ucr.company_id = ra.company_id
        WHERE ra.id::text = split_part(storage.objects.name, '/', 1)
          AND ucr.user_id = auth.uid()
          AND ucr.is_active = true
          AND ucr.role IN ('munkaltato', 'uzemorvos', 'super_admin')
      )
    )
  );
