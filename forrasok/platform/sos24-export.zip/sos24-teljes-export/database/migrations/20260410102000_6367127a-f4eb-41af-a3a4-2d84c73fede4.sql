
CREATE TABLE public.lab_packages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  icon text DEFAULT '📦',
  test_ids text[] NOT NULL DEFAULT '{}',
  is_active boolean NOT NULL DEFAULT true,
  display_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.lab_packages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read active packages"
  ON public.lab_packages FOR SELECT
  USING (is_active = true);

CREATE POLICY "Super admins can manage packages"
  ON public.lab_packages FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'super_admin'))
  WITH CHECK (public.has_role(auth.uid(), 'super_admin'));

CREATE TRIGGER update_lab_packages_updated_at
  BEFORE UPDATE ON public.lab_packages
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();
