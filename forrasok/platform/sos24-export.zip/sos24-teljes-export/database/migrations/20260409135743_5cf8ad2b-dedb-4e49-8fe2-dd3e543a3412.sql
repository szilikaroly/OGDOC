
-- Create lab_requests table
CREATE TABLE public.lab_requests (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  request_number TEXT NOT NULL DEFAULT '',
  patient_id UUID NOT NULL,
  physician_id UUID NOT NULL,
  requested_tests JSONB NOT NULL DEFAULT '[]'::jsonb,
  priority TEXT NOT NULL DEFAULT 'routine',
  scheduled_date DATE,
  notes TEXT,
  cost_bearer TEXT DEFAULT 'taj',
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.lab_requests ENABLE ROW LEVEL SECURITY;

-- Auto-increment request number trigger
CREATE OR REPLACE FUNCTION public.generate_lab_request_number()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  seq_num INTEGER;
BEGIN
  SELECT COALESCE(MAX(
    CASE WHEN request_number ~ '^LKR-\d{4}-\d+$'
    THEN CAST(SPLIT_PART(request_number, '-', 3) AS INTEGER)
    ELSE 0 END
  ), 0) + 1
  INTO seq_num
  FROM public.lab_requests
  WHERE request_number LIKE 'LKR-' || EXTRACT(YEAR FROM now())::text || '-%';

  NEW.request_number := 'LKR-' || EXTRACT(YEAR FROM now())::text || '-' || LPAD(seq_num::text, 4, '0');
  RETURN NEW;
END;
$$;

CREATE TRIGGER set_lab_request_number
BEFORE INSERT ON public.lab_requests
FOR EACH ROW
EXECUTE FUNCTION public.generate_lab_request_number();

-- Updated_at trigger
CREATE TRIGGER update_lab_requests_updated_at
BEFORE UPDATE ON public.lab_requests
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- RLS Policies

-- Doctors (haziorvos, uzemorvos) can manage all lab requests
CREATE POLICY "Haziorvos manages lab requests"
ON public.lab_requests
FOR ALL
TO authenticated
USING (has_role(auth.uid(), 'haziorvos'::app_role))
WITH CHECK (has_role(auth.uid(), 'haziorvos'::app_role));

CREATE POLICY "Uzemorvos manages lab requests"
ON public.lab_requests
FOR ALL
TO authenticated
USING (has_role(auth.uid(), 'uzemorvos'::app_role))
WITH CHECK (has_role(auth.uid(), 'uzemorvos'::app_role));

-- Super admins manage all
CREATE POLICY "Super admins manage lab requests"
ON public.lab_requests
FOR ALL
TO authenticated
USING (has_role(auth.uid(), 'super_admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'super_admin'::app_role));

-- Patients can see their own requests
CREATE POLICY "Patients see own lab requests"
ON public.lab_requests
FOR SELECT
TO authenticated
USING (auth.uid() = patient_id);

-- Employers can see employee lab requests
CREATE POLICY "Munkaltato sees employee lab requests"
ON public.lab_requests
FOR SELECT
TO authenticated
USING (is_employer_of_patient(auth.uid(), patient_id));
