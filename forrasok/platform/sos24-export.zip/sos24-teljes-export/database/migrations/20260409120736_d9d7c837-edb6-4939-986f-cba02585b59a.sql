ALTER TABLE public.user_company_relations 
ADD COLUMN feor_code text,
ADD COLUMN feor_name text;