
-- Add contract pricing fields to companies
ALTER TABLE public.companies
  ADD COLUMN IF NOT EXISTS contract_category text CHECK (contract_category IN ('A', 'B', 'C', 'D')),
  ADD COLUMN IF NOT EXISTS pricing_type text CHECK (pricing_type IN ('fix', 'per_capita', 'monthly')),
  ADD COLUMN IF NOT EXISTS contract_price numeric DEFAULT NULL;
