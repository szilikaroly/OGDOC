
ALTER TABLE public.security_events
  ADD COLUMN IF NOT EXISTS function_name text,
  ADD COLUMN IF NOT EXISTS resource_type text,
  ADD COLUMN IF NOT EXISTS resource_id text,
  ADD COLUMN IF NOT EXISTS action text,
  ADD COLUMN IF NOT EXISTS duration_ms integer,
  ADD COLUMN IF NOT EXISTS status_code integer;

CREATE INDEX IF NOT EXISTS idx_security_events_function_name ON public.security_events(function_name) WHERE function_name IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_security_events_event_type ON public.security_events(event_type);
CREATE INDEX IF NOT EXISTS idx_security_events_created_at ON public.security_events(created_at DESC);

-- Allow edge functions (service_role) to insert
GRANT INSERT ON public.security_events TO service_role;
