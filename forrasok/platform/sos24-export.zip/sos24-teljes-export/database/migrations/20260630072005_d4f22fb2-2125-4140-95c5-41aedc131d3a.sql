CREATE OR REPLACE FUNCTION public.admin_get_user_providers(_user_ids uuid[])
RETURNS TABLE(
  user_id uuid,
  providers text[],
  last_google_sign_in_at timestamptz,
  last_apple_sign_in_at timestamptz,
  last_email_sign_in_at timestamptz,
  google_email text
)
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.has_role(auth.uid(), 'super_admin'::app_role) THEN
    RAISE EXCEPTION 'forbidden: super_admin role required';
  END IF;

  RETURN QUERY
  SELECT
    i.user_id,
    ARRAY_AGG(DISTINCT i.provider ORDER BY i.provider) AS providers,
    MAX(CASE WHEN i.provider = 'google' THEN i.last_sign_in_at END) AS last_google_sign_in_at,
    MAX(CASE WHEN i.provider = 'apple'  THEN i.last_sign_in_at END) AS last_apple_sign_in_at,
    MAX(CASE WHEN i.provider = 'email'  THEN i.last_sign_in_at END) AS last_email_sign_in_at,
    (ARRAY_AGG(i.identity_data->>'email' ORDER BY i.last_sign_in_at DESC NULLS LAST)
       FILTER (WHERE i.provider = 'google'))[1] AS google_email
  FROM auth.identities i
  WHERE i.user_id = ANY(_user_ids)
  GROUP BY i.user_id;
END;
$$;

REVOKE ALL ON FUNCTION public.admin_get_user_providers(uuid[]) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.admin_get_user_providers(uuid[]) TO authenticated, service_role;