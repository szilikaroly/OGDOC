
-- Add certificates table for doctor-issued certificates
CREATE TABLE public.certificates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  doctor_id uuid NOT NULL,
  patient_id uuid NOT NULL,
  certificate_type text NOT NULL CHECK (certificate_type IN ('megjelenes', 'special', 'keresokeptelen')),
  certificate_date date NOT NULL DEFAULT CURRENT_DATE,
  valid_from date,
  valid_until date,
  purpose text,
  notes text,
  pdf_url text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.certificates ENABLE ROW LEVEL SECURITY;

-- Doctors manage their own certificates
CREATE POLICY "Doctors manage own certificates"
ON public.certificates FOR ALL TO authenticated
USING (auth.uid() = doctor_id)
WITH CHECK (auth.uid() = doctor_id);

-- Patients see their own certificates
CREATE POLICY "Patients see own certificates"
ON public.certificates FOR SELECT TO authenticated
USING (auth.uid() = patient_id);

-- Super admins manage all
CREATE POLICY "Super admins manage certificates"
ON public.certificates FOR ALL TO authenticated
USING (has_role(auth.uid(), 'super_admin'::app_role));

-- Employer sees employee certificates
CREATE POLICY "Munkaltato sees employee certificates"
ON public.certificates FOR SELECT TO authenticated
USING (is_employer_of_patient(auth.uid(), patient_id));
