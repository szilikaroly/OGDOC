
-- doctor_recommendations table
CREATE TABLE public.doctor_recommendations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  doctor_id UUID NOT NULL,
  patient_id UUID NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('screening_plan', 'diet_plan')),
  title TEXT NOT NULL DEFAULT '',
  plan_markdown TEXT NOT NULL DEFAULT '',
  duration_days INTEGER DEFAULT NULL,
  preferences JSONB DEFAULT '{}'::jsonb,
  is_read BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.doctor_recommendations ENABLE ROW LEVEL SECURITY;

-- Doctors manage their own recommendations
CREATE POLICY "Doctors manage own recommendations"
  ON public.doctor_recommendations FOR ALL
  TO authenticated
  USING (auth.uid() = doctor_id)
  WITH CHECK (auth.uid() = doctor_id);

-- Patients see their own recommendations
CREATE POLICY "Patients see own recommendations"
  ON public.doctor_recommendations FOR SELECT
  TO authenticated
  USING (auth.uid() = patient_id);

-- Patients can update is_read on own recommendations
CREATE POLICY "Patients update own recommendations read status"
  ON public.doctor_recommendations FOR UPDATE
  TO authenticated
  USING (auth.uid() = patient_id)
  WITH CHECK (auth.uid() = patient_id);

-- Super admins manage all
CREATE POLICY "Super admins manage recommendations"
  ON public.doctor_recommendations FOR ALL
  TO authenticated
  USING (has_role(auth.uid(), 'super_admin'::app_role));
