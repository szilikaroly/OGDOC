CREATE OR REPLACE FUNCTION public.search_icd_codes(
  _query text,
  _version text DEFAULT 'icd10',
  _limit integer DEFAULT 20
)
RETURNS TABLE(
  id uuid,
  code text,
  version public.icd_version,
  label_hu text,
  label_en text,
  parent_code text,
  level integer,
  synonyms text[],
  category text,
  is_active boolean
)
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT id, code, version, label_hu, label_en, parent_code, level, synonyms, category, is_active
  FROM public.icd_codes
  WHERE is_active = true
    AND version = _version::public.icd_version
    AND (
      code ILIKE '%' || _query || '%'
      OR label_hu ILIKE '%' || _query || '%'
      OR label_en ILIKE '%' || _query || '%'
      OR category ILIKE '%' || _query || '%'
      OR EXISTS (
        SELECT 1 FROM unnest(synonyms) s
        WHERE s ILIKE '%' || _query || '%'
      )
    )
  ORDER BY code
  LIMIT LEAST(GREATEST(COALESCE(_limit, 20), 1), 100);
$$;

CREATE OR REPLACE FUNCTION public.validate_icd_code(
  _code text,
  _version text DEFAULT 'icd10'
)
RETURNS boolean
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  _exists boolean;
BEGIN
  SELECT EXISTS (
    SELECT 1 FROM public.icd_codes
    WHERE code = _code
      AND version = _version::public.icd_version
      AND is_active = true
  ) INTO _exists;

  IF NOT _exists THEN
    PERFORM public.log_security_event(
      'invalid_icd_code',
      'warn',
      'icd_codes',
      'validate',
      NULL,
      'Invalid ICD code attempted: ' || _code || ' (' || _version || ')',
      NULL,
      NULL,
      jsonb_build_object('code', _code, 'version', _version)
    );
  END IF;

  RETURN _exists;
END;
$$;

GRANT EXECUTE ON FUNCTION public.search_icd_codes(text, text, integer) TO authenticated;
GRANT EXECUTE ON FUNCTION public.search_icd_codes(text, text, integer) TO service_role;
GRANT EXECUTE ON FUNCTION public.validate_icd_code(text, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.validate_icd_code(text, text) TO service_role;