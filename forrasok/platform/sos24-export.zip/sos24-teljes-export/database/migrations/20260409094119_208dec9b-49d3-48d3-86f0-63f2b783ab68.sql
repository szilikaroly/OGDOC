
-- 1. Hazardous substances reference table
CREATE TABLE public.hazardous_substances (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  ec_number text DEFAULT '',
  cas_number text DEFAULT '',
  reason_for_inclusion text DEFAULT '',
  source text NOT NULL DEFAULT 'echa_candidate',
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

CREATE INDEX idx_hazardous_substances_cas ON public.hazardous_substances(cas_number);
CREATE INDEX idx_hazardous_substances_name ON public.hazardous_substances USING gin(to_tsvector('simple', name));

ALTER TABLE public.hazardous_substances ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read substances"
  ON public.hazardous_substances FOR SELECT
  TO authenticated USING (true);

CREATE POLICY "Super admins manage substances"
  ON public.hazardous_substances FOR ALL
  TO authenticated
  USING (has_role(auth.uid(), 'super_admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'super_admin'::app_role));

CREATE POLICY "Uzemorvos manages substances"
  ON public.hazardous_substances FOR ALL
  TO authenticated
  USING (has_role(auth.uid(), 'uzemorvos'::app_role))
  WITH CHECK (has_role(auth.uid(), 'uzemorvos'::app_role));

-- 2. Company hazardous substances junction table
CREATE TABLE public.company_hazardous_substances (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  company_id uuid NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  substance_id uuid NOT NULL REFERENCES public.hazardous_substances(id) ON DELETE CASCADE,
  usage_description text DEFAULT '',
  annual_quantity text DEFAULT '',
  exposure_type text DEFAULT '',
  ppe_required text DEFAULT '',
  created_by uuid,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE(company_id, substance_id)
);

ALTER TABLE public.company_hazardous_substances ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Super admins manage company substances"
  ON public.company_hazardous_substances FOR ALL
  TO authenticated
  USING (has_role(auth.uid(), 'super_admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'super_admin'::app_role));

CREATE POLICY "Uzemorvos manages company substances"
  ON public.company_hazardous_substances FOR ALL
  TO authenticated
  USING (has_role(auth.uid(), 'uzemorvos'::app_role))
  WITH CHECK (has_role(auth.uid(), 'uzemorvos'::app_role));

CREATE POLICY "Munkaltato manages own company substances"
  ON public.company_hazardous_substances FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.user_company_relations
    WHERE user_id = auth.uid() AND company_id = company_hazardous_substances.company_id
      AND role = 'munkaltato' AND is_active = true
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM public.user_company_relations
    WHERE user_id = auth.uid() AND company_id = company_hazardous_substances.company_id
      AND role = 'munkaltato' AND is_active = true
  ));

CREATE POLICY "Company members can view company substances"
  ON public.company_hazardous_substances FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.user_company_relations
    WHERE user_id = auth.uid() AND company_id = company_hazardous_substances.company_id
      AND is_active = true
  ));

-- 3. Add hazard_substances array to user_company_relations
ALTER TABLE public.user_company_relations
  ADD COLUMN hazard_substances uuid[] DEFAULT '{}';
