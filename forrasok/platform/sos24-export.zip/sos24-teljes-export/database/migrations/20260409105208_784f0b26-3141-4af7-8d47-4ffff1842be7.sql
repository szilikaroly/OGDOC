
CREATE TABLE public.noise_vibration_measurements (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  risk_assessment_id uuid NOT NULL REFERENCES public.risk_assessments(id) ON DELETE CASCADE,
  workplace_id uuid REFERENCES public.workplaces(id) ON DELETE SET NULL,
  measurement_type text NOT NULL CHECK (measurement_type IN ('noise_room', 'noise_1m', 'vibration_wbv', 'vibration_hav')),
  value_db numeric,
  value_ms2 numeric,
  peak_value numeric,
  duration_seconds integer NOT NULL DEFAULT 10,
  frequency_data jsonb DEFAULT '[]'::jsonb,
  location_description text,
  notes text,
  measured_by uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.noise_vibration_measurements ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Super admins manage measurements"
  ON public.noise_vibration_measurements FOR ALL
  TO authenticated
  USING (has_role(auth.uid(), 'super_admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'super_admin'::app_role));

CREATE POLICY "Uzemorvos manages measurements"
  ON public.noise_vibration_measurements FOR ALL
  TO authenticated
  USING (has_role(auth.uid(), 'uzemorvos'::app_role))
  WITH CHECK (has_role(auth.uid(), 'uzemorvos'::app_role));

CREATE POLICY "Authenticated users can create measurements"
  ON public.noise_vibration_measurements FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = measured_by);

CREATE POLICY "Users can read own measurements"
  ON public.noise_vibration_measurements FOR SELECT
  TO authenticated
  USING (auth.uid() = measured_by);

CREATE POLICY "Munkaltato reads company measurements"
  ON public.noise_vibration_measurements FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM risk_assessments ra
      JOIN user_company_relations ucr ON ucr.company_id = ra.company_id
      WHERE ra.id = noise_vibration_measurements.risk_assessment_id
        AND ucr.user_id = auth.uid()
        AND ucr.role = 'munkaltato'
        AND ucr.is_active = true
    )
  );

CREATE INDEX idx_nvm_risk_assessment ON public.noise_vibration_measurements(risk_assessment_id);
CREATE INDEX idx_nvm_type ON public.noise_vibration_measurements(measurement_type);
