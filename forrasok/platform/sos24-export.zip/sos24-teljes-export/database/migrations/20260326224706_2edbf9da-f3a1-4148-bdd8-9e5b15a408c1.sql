DROP POLICY IF EXISTS "Services readable by authenticated" ON public.services;
CREATE POLICY "Services readable by everyone" ON public.services FOR SELECT TO public USING (true);