REVOKE EXECUTE ON FUNCTION public.admin_get_recovery_status(uuid[]) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.admin_get_recovery_status(uuid[]) TO authenticated, service_role;