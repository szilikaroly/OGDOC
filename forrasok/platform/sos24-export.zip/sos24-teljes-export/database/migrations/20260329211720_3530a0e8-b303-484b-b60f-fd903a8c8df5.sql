
CREATE TABLE public.health_plans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  preferences JSONB DEFAULT '{}'::jsonb,
  plan_markdown TEXT NOT NULL,
  generated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.health_plans ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own health plans"
  ON public.health_plans FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert own health plans"
  ON public.health_plans FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Doctors can view patient health plans"
  ON public.health_plans FOR SELECT
  TO authenticated
  USING (
    public.has_role(auth.uid(), 'haziorvos') OR
    public.has_role(auth.uid(), 'uzemorvos') OR
    public.has_role(auth.uid(), 'praxistag')
  );
