# SOS24 Portál — Első lépések

Teljes export: forráskód + adatbázis séma + törzsadatok + dokumentáció.
Export dátuma: **2026-09-01**

## Gyorsindítás

```bash
# 1) Függőségek
npm install

# 2) Környezet
cp .env.example .env      # töltsd ki a backend URL-t és a publikus kulcsot

# 3) Adatbázis
psql "$DB_URL" -f database/schema-public-with-grants.sql
psql "$DB_URL" -f database/reference-data.sql
psql "$DB_URL" -f database/storage-policies.sql   # bucket-ek létrehozása UTÁN

# 4) Edge function-ök deploy-olása (supabase/functions/*)

# 5) Fejlesztői szerver
npm run dev

# 6) Tesztek
npm run test          # vitest
npx playwright test   # e2e
```

## Mit olvass el elsőként

1. `docs/EXPORT-KALAUZ.md` — **tételes magyarázat a csomag minden részéhez**
2. `docs/PROGRAMFA.md` — fájl- és modulfa
3. `docs/UJRAEPITES.md` — részletes újraépítési recept
4. `docs/MASTER-PROMPT.md` — egy prompttal újragenerálható specifikáció
5. `docs/DEBUG-TESZT-MATRIX.md` — hibakeresés és tesztlefedettség

## Technológia

React 18 · Vite 5 · TypeScript 5 · Tailwind CSS 3 · shadcn/ui · TanStack Query ·
Supabase (Postgres + Auth + Storage + Deno Edge Functions) · i18next (7 nyelv)

## Figyelmeztetés

A csomag **nem** tartalmaz titkokat és **nem** tartalmaz személyes/egészségügyi
adatokat (GDPR). A séma minden táblát létrehoz, az érintett táblák üresen indulnak.
