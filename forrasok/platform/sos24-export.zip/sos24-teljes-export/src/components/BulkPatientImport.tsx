import { useState, useRef } from "react";
import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Upload, Download, FileSpreadsheet, CheckCircle2, XCircle, Loader2, AlertTriangle } from "lucide-react";
import * as XLSX from "xlsx";
import { exportImportLog, type ImportLogRow } from "@/lib/import-export";
import BulkImportHistory from "./BulkImportHistory";

type Status = "pending" | "success" | "error" | "duplicate";

interface PatientRow {
  full_name: string;
  email: string;
  taj_number?: string;
  birth_date?: string;
  birth_place?: string;
  birth_name?: string;
  mother_name?: string;
  phone?: string;
  address?: string;
  gender?: string;
  position?: string;
  feor_code?: string;
  feor_name?: string;
  site_name?: string;
  workplace_name?: string;
  status: Status;
  error?: string;
}

interface BulkPatientImportProps {
  onComplete?: () => void;
  /** Role assigned to the new users. Defaults to munkavallalo. */
  targetRole?: "munkavallalo" | "praxistag";
  /** When true, also renders the import history list under the buttons. */
  showHistory?: boolean;
}

function parseExcelDate(v: unknown): string {
  if (v == null || v === "") return "";
  if (typeof v === "number") {
    const ms = Math.round((v - 25569) * 86400 * 1000);
    const d = new Date(ms);
    if (!isNaN(d.getTime())) return d.toISOString().slice(0, 10);
  }
  if (v instanceof Date && !isNaN(v.getTime())) return v.toISOString().slice(0, 10);
  if (typeof v === "string") {
    const s = v.trim();
    const iso = s.match(/^(\d{4})[-./](\d{1,2})[-./](\d{1,2})$/);
    if (iso) return `${iso[1]}-${iso[2].padStart(2, "0")}-${iso[3].padStart(2, "0")}`;
    const hu = s.match(/^(\d{1,2})[-./](\d{1,2})[-./](\d{4})$/);
    if (hu) return `${hu[3]}-${hu[2].padStart(2, "0")}-${hu[1].padStart(2, "0")}`;
    const d = new Date(s);
    if (!isNaN(d.getTime())) return d.toISOString().slice(0, 10);
  }
  return "";
}

function normalizeGender(v: string): string | undefined {
  const s = v.toLowerCase().trim();
  if (!s) return undefined;
  if (["ferfi", "férfi", "f", "male", "m"].includes(s)) return "ferfi";
  if (["no", "nő", "nő ", "n", "female", "w"].includes(s)) return "no";
  return undefined;
}

function normalizeTaj(v: string): string {
  return v.replace(/[\s-]/g, "").trim();
}

type Filter = "all" | "pending" | "duplicate" | "error" | "success";

export default function BulkPatientImport({ onComplete, targetRole = "munkavallalo", showHistory = true }: BulkPatientImportProps) {
  const { toast } = useToast();
  const { t } = useTranslation();
  const fileRef = useRef<HTMLInputElement>(null);
  const [open, setOpen] = useState(false);
  const [rows, setRows] = useState<PatientRow[]>([]);
  const [fileName, setFileName] = useState<string>("");
  const [importing, setImporting] = useState(false);
  const [done, setDone] = useState(false);
  const [checking, setChecking] = useState(false);
  const [filter, setFilter] = useState<Filter>("all");
  const [historyKey, setHistoryKey] = useState(0);
  const [processed, setProcessed] = useState(0);
  const [liveCounts, setLiveCounts] = useState({ success: 0, duplicate: 0, error: 0 });
  const [importTotal, setImportTotal] = useState(0);

  const downloadTemplate = () => {
    const wb = XLSX.utils.book_new();
    const data = [
      [
        "Teljes név*", "Email cím", "TAJ szám*", "Születési dátum (ÉÉÉÉ-HH-NN)",
        "Születési hely", "Születési név", "Anyja neve",
        "Telefon", "Cím", "Nem (ferfi/no)",
        "Munkakör", "FEOR kód", "FEOR megnevezés",
        "Telephely", "Munkahely",
      ],
      [
        "Példa János", "pelda@email.hu", "123456789", "1990-05-15",
        "Budapest", "Példa János", "Kiss Mária",
        "+36301234567", "Budapest, Fő u. 1.", "ferfi",
        "Raktáros", "9329", "Egyéb anyagmozgatók",
        "Budapest telephely", "Raktár",
      ],
    ];
    const ws = XLSX.utils.aoa_to_sheet(data);
    XLSX.utils.book_append_sheet(wb, ws, "Páciensek");
    XLSX.writeFile(wb, "paciens_import_minta.xlsx");
  };

  const col = (row: Record<string, any>, ...keys: string[]): string => {
    for (const k of keys) {
      const v = row[k];
      if (v != null && String(v).trim() !== "") return String(v).trim();
    }
    return "";
  };

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = async (evt) => {
      try {
        const wb = XLSX.read(evt.target?.result, { type: "binary" });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const json = XLSX.utils.sheet_to_json<Record<string, any>>(ws, { raw: true });

        const parsed: PatientRow[] = json.map((row) => {
          const name = col(row, "Teljes név*", "Teljes név", "full_name", "Név", "Name");
          const email = col(row, "Email cím*", "Email cím", "email", "Email", "E-Mail", "E-mail");
          const tajRaw = col(row, "TAJ szám*", "TAJ szám", "taj_number", "TAJ", "TAJ / Azonosító", "Azonosító");
          const taj = tajRaw ? normalizeTaj(tajRaw) : "";
          const birthRaw = row["Születési dátum (ÉÉÉÉ-HH-NN)"] ?? row["Születési dátum"] ?? row["Születés dátuma"] ?? row["birth_date"];
          const birth = parseExcelDate(birthRaw);
          const birthPlace = col(row, "Születési hely", "Születés helye", "birth_place");
          const birthName = col(row, "Születési név", "birth_name");
          const motherName = col(row, "Anyja neve", "mother_name");
          const phone = col(row, "Telefon", "phone", "Telefonszám");
          const addressParts = [
            col(row, "Irányítószám"),
            col(row, "Város"),
            col(row, "Utca"),
            col(row, "Hsz", "Házszám"),
          ].filter(Boolean).join(" ");
          const address = col(row, "Cím", "address") || addressParts;
          const gender = normalizeGender(col(row, "Nem (ferfi/no)", "gender", "Nem", "Neme"));
          const position = col(row, "Munkakör", "position");
          const feorCode = col(row, "FEOR kód", "feor_code", "FEOR");
          const feorName = col(row, "FEOR megnevezés", "feor_name");
          const siteName = col(row, "Telephely", "site_name");
          const workplaceName = col(row, "Munkahely", "workplace_name");

          const errors: string[] = [];
          if (!name) errors.push("Név hiányzik");
          if (!email && !taj) errors.push("Email vagy TAJ szükséges");
          if (email && !email.includes("@")) errors.push("Érvénytelen email");

          return {
            full_name: name,
            email: email ? email.toLowerCase() : "",
            taj_number: taj || undefined,
            birth_date: birth || undefined,
            birth_place: birthPlace || undefined,
            birth_name: birthName || undefined,
            mother_name: motherName || undefined,
            phone: phone || undefined,
            address: address || undefined,
            gender,
            position: position || undefined,
            feor_code: feorCode || undefined,
            feor_name: feorName || undefined,
            site_name: siteName || undefined,
            workplace_name: workplaceName || undefined,
            status: errors.length ? ("error" as const) : ("pending" as const),
            error: errors.join(", ") || undefined,
          };
        });

        setChecking(true);
        await markDuplicates(parsed);
        setChecking(false);

        setRows(parsed);
        setFilter("all");
        setDone(false);
        setOpen(true);
      } catch (err: any) {
        toast({ variant: "destructive", title: t("common.error"), description: err?.message || "Hibás fájl" });
      }
    };
    reader.readAsBinaryString(file);
    e.target.value = "";
  };

  const markDuplicates = async (list: PatientRow[]) => {
    const tajSet = new Set<string>();
    const emailSet = new Set<string>();
    const nbSet = new Set<string>();
    const nbKey = (n: string, b?: string) => `${n.toLowerCase().trim()}|${b || ""}`;

    for (const r of list) {
      if (r.status === "error") continue;
      const dupReasons: string[] = [];
      if (r.taj_number && tajSet.has(r.taj_number)) dupReasons.push("TAJ ismétlődik a fájlban");
      if (r.email && emailSet.has(r.email)) dupReasons.push("Email ismétlődik a fájlban");
      if (r.birth_date && r.full_name && nbSet.has(nbKey(r.full_name, r.birth_date))) dupReasons.push("Név+szül.dátum ismétlődik");
      if (dupReasons.length) {
        r.status = "duplicate";
        r.error = dupReasons.join(", ");
      } else {
        if (r.taj_number) tajSet.add(r.taj_number);
        if (r.email) emailSet.add(r.email);
        if (r.birth_date && r.full_name) nbSet.add(nbKey(r.full_name, r.birth_date));
      }
    }

    const tajList = list.filter((r) => r.status === "pending" && r.taj_number).map((r) => r.taj_number!);
    if (tajList.length > 0) {
      const { data: existing } = await supabase
        .from("profiles")
        .select("taj_number, full_name, birth_date")
        .in("taj_number", tajList);
      const existingTajs = new Set((existing ?? []).map((p: any) => p.taj_number));
      for (const r of list) {
        if (r.status === "pending" && r.taj_number && existingTajs.has(r.taj_number)) {
          r.status = "duplicate";
          r.error = "TAJ már létezik a rendszerben";
        }
      }
    }

    const remaining = list.filter((r) => r.status === "pending" && r.birth_date && r.full_name);
    if (remaining.length > 0) {
      const dates = Array.from(new Set(remaining.map((r) => r.birth_date!)));
      const { data: nb } = await supabase
        .from("profiles")
        .select("full_name, birth_date")
        .in("birth_date", dates);
      const nbExisting = new Set((nb ?? []).map((p: any) => nbKey(p.full_name, p.birth_date)));
      for (const r of remaining) {
        if (r.status === "pending" && nbExisting.has(nbKey(r.full_name, r.birth_date!))) {
          r.status = "duplicate";
          r.error = "Név+születési dátum egyezik meglévő pácienssel";
        }
      }
    }
  };

  const saveLog = async (finalRows: PatientRow[]) => {
    try {
      const { data: u } = await supabase.auth.getUser();
      const uid = u?.user?.id;
      if (!uid) return;
      const details: ImportLogRow[] = finalRows.map((r) => ({
        full_name: r.full_name,
        email: r.email,
        taj_number: r.taj_number,
        birth_date: r.birth_date,
        birth_place: r.birth_place,
        birth_name: r.birth_name,
        mother_name: r.mother_name,
        phone: r.phone,
        address: r.address,
        gender: r.gender,
        position: r.position,
        feor_code: r.feor_code,
        feor_name: r.feor_name,
        site_name: r.site_name,
        workplace_name: r.workplace_name,
        status: r.status,
        error: r.error,
        reason_category:
          r.status === "duplicate" ? "duplicate" :
          r.status === "error" ? (r.error?.toLowerCase().includes("rendszerhiba") ? "system" : "validation") :
          "ok",
        reason_detail: r.error,
      }));
      const counts = {
        total_rows: finalRows.length,
        success_count: finalRows.filter(r => r.status === "success").length,
        duplicate_count: finalRows.filter(r => r.status === "duplicate").length,
        error_count: finalRows.filter(r => r.status === "error").length,
        new_count: finalRows.filter(r => r.status === "pending" || r.status === "success").length,
      };
      await supabase.from("bulk_import_logs").insert({
        user_id: uid,
        import_type: "patients",
        file_name: fileName || null,
        details: details as any,
        ...counts,
      });
      setHistoryKey((k) => k + 1);
    } catch (e) {
      console.error("[saveLog] failed", e);
    }
  };

  const runImport = async () => {
    setImporting(true);
    setProcessed(0);
    setLiveCounts({ success: 0, duplicate: 0, error: 0 });
    const updated = [...rows];

    const validPatients = updated
      .map((row, i) => ({ row, i }))
      .filter(({ row }) => row.status === "pending");

    setImportTotal(validPatients.length);

    if (validPatients.length === 0) {
      setImporting(false);
      return;
    }

    const CHUNK = 5;
    const counters = { success: 0, duplicate: 0, error: 0 };

    for (let start = 0; start < validPatients.length; start += CHUNK) {
      const chunk = validPatients.slice(start, start + CHUNK);
      try {
        const { data, error } = await supabase.functions.invoke("bulk-create-patients", {
          body: {
            target_role: targetRole,
            patients: chunk.map(({ row }) => ({
              email: row.email || undefined,
              full_name: row.full_name,
              taj_number: row.taj_number,
              birth_date: row.birth_date,
              birth_place: row.birth_place,
              birth_name: row.birth_name,
              mother_name: row.mother_name,
              phone: row.phone,
              address: row.address,
              gender: row.gender,
              position: row.position,
              feor_code: row.feor_code,
              feor_name: row.feor_name,
              site_name: row.site_name,
              workplace_name: row.workplace_name,
            })),
          },
        });

        if (error) throw new Error(error.message);
        const results = (data?.results as Array<{ email?: string; status: "success" | "error" | "duplicate"; error?: string }>) ?? [];

        for (let ri = 0; ri < chunk.length; ri++) {
          const originalIndex = chunk[ri].i;
          const res = results[ri] ?? { status: "error" as const, error: "Ismeretlen válasz" };
          updated[originalIndex] = { ...updated[originalIndex], status: res.status, error: res.error };
          counters[res.status]++;
        }
      } catch (err: any) {
        for (const { i } of chunk) {
          updated[i] = { ...updated[i], status: "error", error: err.message };
          counters.error++;
        }
      }

      setRows([...updated]);
      setProcessed(start + chunk.length);
      setLiveCounts({ ...counters });
    }

    setImporting(false);
    setDone(true);
    toast({ title: t("import.importDone", { success: counters.success, total: validPatients.length }) });
    await saveLog(updated);
    onComplete?.();
  };


  const toLogRows = (list: PatientRow[]) =>
    list.map((r) => ({
      full_name: r.full_name,
      email: r.email,
      taj_number: r.taj_number,
      birth_date: r.birth_date,
      birth_place: r.birth_place,
      birth_name: r.birth_name,
      mother_name: r.mother_name,
      phone: r.phone,
      address: r.address,
      gender: r.gender,
      position: r.position,
      feor_code: r.feor_code,
      feor_name: r.feor_name,
      site_name: r.site_name,
      workplace_name: r.workplace_name,
      status: r.status,
      error: r.error,
      reason_category:
        r.status === "duplicate" ? ("duplicate" as const)
        : r.status === "error" ? ("validation" as const)
        : ("ok" as const),
      reason_detail: r.error,
    }));

  const exportResults = () => {
    exportImportLog(toLogRows(rows), `import_eredmeny_${(fileName || "").replace(/\.[^.]+$/, "")}`);
  };

  const exportErrors = () => {
    const errs = rows.filter((r) => r.status === "error");
    if (errs.length === 0) {
      toast({ title: "Nincs hibás sor", description: "Az előnézetben nincs érvénytelen sor letöltéshez." });
      return;
    }
    exportImportLog(toLogRows(errs), `import_hibak_${(fileName || "").replace(/\.[^.]+$/, "")}`);
  };

  const validCount = rows.filter((r) => r.status === "pending").length;
  const successCount = rows.filter((r) => r.status === "success").length;
  const errorCount = rows.filter((r) => r.status === "error").length;
  const dupCount = rows.filter((r) => r.status === "duplicate").length;

  const visibleRows = rows.filter((r) => filter === "all" ? true : r.status === filter);

  return (
    <>
      <div className="flex gap-2 flex-wrap">
        <Button variant="outline" size="sm" onClick={downloadTemplate}>
          <Download className="h-4 w-4 mr-1" /> {t("import.templateXls")}
        </Button>
        <Button variant="outline" size="sm" onClick={() => fileRef.current?.click()}>
          <Upload className="h-4 w-4 mr-1" /> {t("import.patientImport")}
        </Button>
        <input ref={fileRef} type="file" accept=".xlsx,.xls" className="hidden" onChange={handleFile} />
      </div>

      {showHistory && <BulkImportHistory key={historyKey} autoOpenLatest pollIntervalMs={historyKey > 0 ? 0 : 15000} />}

      <Dialog open={open} onOpenChange={(v) => !importing && setOpen(v)}>
        <DialogContent className="max-w-5xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileSpreadsheet className="h-5 w-5" /> {t("import.previewTitle")}
            </DialogTitle>
          </DialogHeader>

          {/* Summary card */}
          <Card>
            <CardContent className="p-4">
              <div className="grid grid-cols-2 md:grid-cols-5 gap-3 text-sm">
                <SummaryStat label="Összes sor" value={rows.length} />
                <SummaryStat label={done ? "Sikeres" : "Importálható (új)"} value={done ? successCount : validCount} tone="success" />
                <SummaryStat label="Duplum" value={dupCount} tone="warning" />
                <SummaryStat label="Hiba" value={errorCount} tone="error" />
                <div className="text-muted-foreground truncate" title={fileName}>
                  <div className="text-xs uppercase">Fájl</div>
                  <div className="font-medium truncate">{fileName || "—"}</div>
                </div>
              </div>
              {checking && (
                <div className="mt-2 text-xs text-muted-foreground">
                  <Loader2 className="h-3 w-3 inline animate-spin mr-1" />Duplum ellenőrzés folyamatban...
                </div>
              )}
              {importing && (
                <div className="mt-3 space-y-1">
                  <div className="flex justify-between text-xs text-muted-foreground flex-wrap gap-2">
                    <span>
                      <Loader2 className="h-3 w-3 inline animate-spin mr-1" />
                      Importálás: {processed} / {importTotal}
                    </span>
                    <span>
                      <span className="text-green-600 font-medium">{liveCounts.success} új</span>
                      {" · "}
                      <span className="text-yellow-600 font-medium">{liveCounts.duplicate} duplum</span>
                      {" · "}
                      <span className="text-destructive font-medium">{liveCounts.error} hiba</span>
                    </span>
                  </div>
                  <Progress value={importTotal > 0 ? (processed / importTotal) * 100 : 0} />
                </div>
              )}
            </CardContent>
          </Card>



          {/* Filter */}
          <div className="flex justify-between items-center flex-wrap gap-2">
            <ToggleGroup type="single" value={filter} onValueChange={(v) => v && setFilter(v as Filter)} size="sm">
              <ToggleGroupItem value="all">Mind ({rows.length})</ToggleGroupItem>
              {!done && <ToggleGroupItem value="pending">Új ({validCount})</ToggleGroupItem>}
              {done && <ToggleGroupItem value="success">Sikeres ({successCount})</ToggleGroupItem>}
              <ToggleGroupItem value="duplicate">Duplum ({dupCount})</ToggleGroupItem>
              <ToggleGroupItem value="error">Hiba ({errorCount})</ToggleGroupItem>
            </ToggleGroup>
            {done && (
              <Button variant="outline" size="sm" onClick={exportResults}>
                <Download className="h-4 w-4 mr-1" /> Eredmény letöltése
              </Button>
            )}
            <Button
              variant="outline"
              size="sm"
              onClick={exportErrors}
              disabled={errorCount === 0}
              title={errorCount === 0 ? "Nincs hibás sor" : "Csak a hibás sorok exportálása"}
            >
              <XCircle className="h-4 w-4 mr-1 text-destructive" /> Hibajelentés ({errorCount})
            </Button>
          </div>

          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Név</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>TAJ</TableHead>
                  <TableHead>Szül. dátum</TableHead>
                  <TableHead>Státusz</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {visibleRows.map((r, i) => (
                  <TableRow key={i}>
                    <TableCell className="font-medium">{r.full_name || "—"}</TableCell>
                    <TableCell>{r.email || "—"}</TableCell>
                    <TableCell>{r.taj_number || "—"}</TableCell>
                    <TableCell>{r.birth_date || "—"}</TableCell>
                    <TableCell>
                      {r.status === "pending" && <Badge variant="secondary">Új</Badge>}
                      {r.status === "success" && <Badge className="bg-green-600"><CheckCircle2 className="h-3 w-3 mr-1" />OK</Badge>}
                      {r.status === "duplicate" && <Badge variant="outline" className="border-yellow-500 text-yellow-700" title={r.error}><AlertTriangle className="h-3 w-3 mr-1" />{(r.error || "Duplum").slice(0, 40)}</Badge>}
                      {r.status === "error" && <Badge variant="destructive" title={r.error}><XCircle className="h-3 w-3 mr-1" />{r.error?.slice(0, 40)}</Badge>}
                    </TableCell>
                  </TableRow>
                ))}
                {visibleRows.length === 0 && (
                  <TableRow><TableCell colSpan={5} className="text-center text-muted-foreground py-6">Nincs megjeleníthető sor.</TableCell></TableRow>
                )}
              </TableBody>
            </Table>
          </div>

          <div className="flex justify-between items-center pt-2 gap-2 flex-wrap">
            <div className="text-sm text-muted-foreground">
              {!done && validCount > 0 && <>Megerősítés után <b>{validCount}</b> új páciens kerül létrehozásra.</>}
              {done && <>Az import napló elmentve. Az előzményekből bármikor letöltheted újra.</>}
            </div>
            {!done && (
              <Button onClick={runImport} disabled={importing || validCount === 0 || checking}>
                {importing && <Loader2 className="h-4 w-4 mr-1 animate-spin" />}
                {importing ? "Importálás..." : `Importálás megerősítése (${validCount})`}
              </Button>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

function SummaryStat({ label, value, tone }: { label: string; value: number; tone?: "success" | "warning" | "error" }) {
  const color =
    tone === "success" ? "text-green-600" :
    tone === "warning" ? "text-yellow-600" :
    tone === "error" ? "text-destructive" :
    "text-foreground";
  return (
    <div>
      <div className="text-xs uppercase text-muted-foreground">{label}</div>
      <div className={`text-2xl font-bold ${color}`}>{value}</div>
    </div>
  );
}

