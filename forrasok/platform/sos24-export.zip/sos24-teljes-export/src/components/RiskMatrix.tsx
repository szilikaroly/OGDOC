import { RISK_MATRIX_COLORS, getRiskCategory, RISK_CATEGORY_LABELS } from "@/lib/hazard-catalog";
import { useTranslation } from "react-i18next";
import { cn } from "@/lib/utils";

export default function RiskMatrix() {
  const { i18n } = useTranslation();
  const lang = i18n.language === "hu" ? "hu" : "en";

  const probLabels = [4, 3, 2, 1];
  const sevLabels = [1, 2, 3, 4];

  return (
    <div className="overflow-auto">
      <table className="border-collapse text-xs w-full max-w-md">
        <thead>
          <tr>
            <th className="p-1 border text-left" rowSpan={2}>P \ S</th>
            {sevLabels.map(s => (
              <th key={s} className="p-1 border text-center">{s}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {probLabels.map(p => (
            <tr key={p}>
              <td className="p-1 border font-medium">{p}</td>
              {sevLabels.map(s => {
                const cat = getRiskCategory(p, s);
                return (
                  <td
                    key={s}
                    className={cn("p-1 border text-center font-semibold", RISK_MATRIX_COLORS[cat])}
                  >
                    {p * s}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
      <div className="flex flex-wrap gap-2 mt-2">
        {Object.entries(RISK_CATEGORY_LABELS).map(([key, labels]) => (
          <span key={key} className={cn("text-xs px-2 py-0.5 rounded border", RISK_MATRIX_COLORS[key])}>
            {labels[lang]}
          </span>
        ))}
      </div>
    </div>
  );
}
