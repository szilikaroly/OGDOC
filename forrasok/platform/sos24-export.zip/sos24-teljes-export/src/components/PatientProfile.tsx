import { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { User, Heart, Save, Upload } from "lucide-react";
import { toast } from "sonner";

interface ProfileForm {
  full_name: string;
  phone: string;
  address: string;
  taj_number: string;
  birth_date: string;
  birth_place: string;
  mother_name: string;
  gender: string;
  blood_type: string;
}

interface PatientCardForm {
  drug_allergies: string;
  chronic_diseases: string;
  regular_medications: string;
}

interface BiometricForm {
  weight_kg: string;
  height_cm: string;
}

export default function PatientProfile() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const qc = useQueryClient();

  const [profile, setProfile] = useState<ProfileForm>({
    full_name: "", phone: "", address: "", taj_number: "",
    birth_date: "", birth_place: "", mother_name: "", gender: "", blood_type: "",
  });
  const [card, setCard] = useState<PatientCardForm>({
    drug_allergies: "", chronic_diseases: "", regular_medications: "",
  });
  const [bio, setBio] = useState<BiometricForm>({ weight_kg: "", height_cm: "" });

  const { data: profileData } = useQuery({
    queryKey: ["my-profile", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase.from("profiles")
        .select("*").eq("user_id", user!.id).maybeSingle();
      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  const { data: cardData } = useQuery({
    queryKey: ["my-patient-card", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase.from("patient_cards")
        .select("*").eq("user_id", user!.id).maybeSingle();
      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  const { data: latestReport } = useQuery({
    queryKey: ["my-latest-report", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase.from("health_reports")
        .select("weight_kg, height_cm")
        .eq("user_id", user!.id)
        .order("report_date", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  useEffect(() => {
    if (profileData) {
      setProfile({
        full_name: profileData.full_name || "",
        phone: profileData.phone || "",
        address: profileData.address || "",
        taj_number: profileData.taj_number || "",
        birth_date: profileData.birth_date || "",
        birth_place: profileData.birth_place || "",
        mother_name: profileData.mother_name || "",
        gender: profileData.gender || "",
        blood_type: profileData.blood_type || "",
      });
    }
  }, [profileData]);

  useEffect(() => {
    if (cardData) {
      setCard({
        drug_allergies: cardData.drug_allergies || "",
        chronic_diseases: cardData.chronic_diseases || "",
        regular_medications: cardData.regular_medications || "",
      });
    }
  }, [cardData]);

  useEffect(() => {
    if (latestReport) {
      setBio({
        weight_kg: latestReport.weight_kg?.toString() || "",
        height_cm: latestReport.height_cm?.toString() || "",
      });
    }
  }, [latestReport]);

  const saveMut = useMutation({
    mutationFn: async () => {
      // Update profile
      const { error: pErr } = await supabase.from("profiles")
        .update({
          full_name: profile.full_name,
          phone: profile.phone || null,
          address: profile.address || null,
          taj_number: profile.taj_number || null,
          birth_date: profile.birth_date || null,
          birth_place: profile.birth_place || null,
          mother_name: profile.mother_name || null,
          gender: (profile.gender || null) as any,
          blood_type: (profile.blood_type || null) as any,
        })
        .eq("user_id", user!.id);
      if (pErr) throw pErr;

      // Upsert patient card
      const { error: cErr } = await supabase.from("patient_cards")
        .upsert({
          user_id: user!.id,
          drug_allergies: card.drug_allergies || null,
          chronic_diseases: card.chronic_diseases || null,
          regular_medications: card.regular_medications || null,
        }, { onConflict: "user_id" });
      if (cErr) throw cErr;

      // Upsert latest health report for biometrics
      if (bio.weight_kg || bio.height_cm) {
        const { error: hErr } = await supabase.from("health_reports")
          .upsert({
            user_id: user!.id,
            weight_kg: bio.weight_kg ? parseFloat(bio.weight_kg) : null,
            height_cm: bio.height_cm ? parseFloat(bio.height_cm) : null,
            report_date: new Date().toISOString().split("T")[0],
          }, { onConflict: "user_id" as any, ignoreDuplicates: false });
        // If upsert fails (no unique constraint on user_id), insert
        if (hErr) {
          await supabase.from("health_reports").insert({
            user_id: user!.id,
            weight_kg: bio.weight_kg ? parseFloat(bio.weight_kg) : null,
            height_cm: bio.height_cm ? parseFloat(bio.height_cm) : null,
          });
        }
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["my-profile"] });
      qc.invalidateQueries({ queryKey: ["my-patient-card"] });
      qc.invalidateQueries({ queryKey: ["my-latest-report"] });
      toast.success(t("common.saved"));
    },
    onError: (e: any) => toast.error(e.message),
  });

  const handleFileImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const XLSX = await import("xlsx");
      const data = await file.arrayBuffer();
      const wb = XLSX.read(data);
      const ws = wb.Sheets[wb.SheetNames[0]];
      const rows: any[] = XLSX.utils.sheet_to_json(ws);
      if (rows.length === 0) { toast.error("Üres fájl"); return; }
      const r = rows[0];
      // Map common column names
      setProfile(p => ({
        ...p,
        full_name: r["Név"] || r["Name"] || r["full_name"] || p.full_name,
        phone: r["Telefon"] || r["Phone"] || r["phone"] || p.phone,
        taj_number: r["TAJ"] || r["TAJ szám"] || r["taj_number"] || p.taj_number,
        birth_date: r["Születési dátum"] || r["birth_date"] || p.birth_date,
        birth_place: r["Születési hely"] || r["birth_place"] || p.birth_place,
        mother_name: r["Anyja neve"] || r["mother_name"] || p.mother_name,
        address: r["Lakcím"] || r["Address"] || r["address"] || p.address,
      }));
      setCard(c => ({
        ...c,
        drug_allergies: r["Allergiák"] || r["Allergies"] || r["drug_allergies"] || c.drug_allergies,
      }));
      setBio(b => ({
        ...b,
        weight_kg: r["Testsúly"] || r["Weight"] || r["weight_kg"] || b.weight_kg,
        height_cm: r["Testmagasság"] || r["Height"] || r["height_cm"] || b.height_cm,
      }));
      toast.success("Adatok importálva – ellenőrizd és mentsd!");
    } catch (err: any) {
      toast.error("Import hiba: " + err.message);
    }
    e.target.value = "";
  };

  const genderOptions = [
    { value: "ferfi", label: "Férfi" },
    { value: "no", label: "Nő" },
    { value: "egyeb", label: "Egyéb" },
  ];

  const bloodOptions = ["A+", "A-", "B+", "B-", "AB+", "AB-", "0+", "0-"];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <User className="h-6 w-6 text-secondary" />
          <h1 className="text-2xl font-bold">Profil</h1>
        </div>
        <div className="flex items-center gap-2">
          <label className="cursor-pointer">
            <input type="file" accept=".xlsx,.xls,.csv" className="hidden" onChange={handleFileImport} />
            <Button variant="outline" size="sm" asChild>
              <span><Upload className="h-4 w-4 mr-1" /> Importálás Excelből</span>
            </Button>
          </label>
        </div>
      </div>

      {/* Personal data */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Személyes adatok</CardTitle>
          <CardDescription>Azonosításhoz szükséges alapadatok</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1">
              <Label className="text-xs">Teljes név</Label>
              <Input value={profile.full_name} onChange={e => setProfile(p => ({ ...p, full_name: e.target.value }))} />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">TAJ szám</Label>
              <Input value={profile.taj_number} onChange={e => setProfile(p => ({ ...p, taj_number: e.target.value }))} placeholder="123 456 789" />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Születési hely</Label>
              <Input value={profile.birth_place} onChange={e => setProfile(p => ({ ...p, birth_place: e.target.value }))} />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Születési idő</Label>
              <Input type="date" value={profile.birth_date} onChange={e => setProfile(p => ({ ...p, birth_date: e.target.value }))} />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Anyja neve</Label>
              <Input value={profile.mother_name} onChange={e => setProfile(p => ({ ...p, mother_name: e.target.value }))} />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Nem</Label>
              <Select value={profile.gender} onValueChange={v => setProfile(p => ({ ...p, gender: v }))}>
                <SelectTrigger><SelectValue placeholder="Válasszon..." /></SelectTrigger>
                <SelectContent>
                  {genderOptions.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Contact */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Elérhetőségek</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1">
              <Label className="text-xs">Telefonszám</Label>
              <Input value={profile.phone} onChange={e => setProfile(p => ({ ...p, phone: e.target.value }))} placeholder="+36 30 123 4567" />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Lakcím</Label>
              <Input value={profile.address} onChange={e => setProfile(p => ({ ...p, address: e.target.value }))} />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Health */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Heart className="h-5 w-5 text-destructive" />
            Egészségügyi adatok
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="space-y-1">
              <Label className="text-xs">Vércsoport</Label>
              <Select value={profile.blood_type} onValueChange={v => setProfile(p => ({ ...p, blood_type: v }))}>
                <SelectTrigger><SelectValue placeholder="—" /></SelectTrigger>
                <SelectContent>
                  {bloodOptions.map(b => <SelectItem key={b} value={b}>{b}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Testsúly (kg)</Label>
              <Input type="number" value={bio.weight_kg} onChange={e => setBio(b => ({ ...b, weight_kg: e.target.value }))} placeholder="75" />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Testmagasság (cm)</Label>
              <Input type="number" value={bio.height_cm} onChange={e => setBio(b => ({ ...b, height_cm: e.target.value }))} placeholder="175" />
            </div>
          </div>
          <Separator />
          <div className="space-y-1">
            <Label className="text-xs">Allergiák / Gyógyszerérzékenység</Label>
            <Textarea value={card.drug_allergies} onChange={e => setCard(c => ({ ...c, drug_allergies: e.target.value }))} placeholder="Penicillin, Aszpirin..." rows={2} />
          </div>
          <div className="space-y-1">
            <Label className="text-xs">Krónikus betegségek</Label>
            <Textarea value={card.chronic_diseases} onChange={e => setCard(c => ({ ...c, chronic_diseases: e.target.value }))} placeholder="Cukorbetegség, Magas vérnyomás..." rows={2} />
          </div>
          <div className="space-y-1">
            <Label className="text-xs">Rendszeres gyógyszerek</Label>
            <Textarea value={card.regular_medications} onChange={e => setCard(c => ({ ...c, regular_medications: e.target.value }))} placeholder="Metformin 500mg, Ramipril 5mg..." rows={2} />
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button onClick={() => saveMut.mutate()} disabled={saveMut.isPending} size="lg">
          <Save className="h-4 w-4 mr-2" />
          {saveMut.isPending ? "Mentés..." : t("common.save")}
        </Button>
      </div>
    </div>
  );
}
