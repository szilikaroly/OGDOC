import { useState } from "react";
import { useTranslation } from "react-i18next";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Languages, Loader2, X } from "lucide-react";
import { cn } from "@/lib/utils";

interface AiTranslateButtonProps {
  text: string;
  className?: string;
  size?: "sm" | "xs";
}

export default function AiTranslateButton({ text, className, size = "xs" }: AiTranslateButtonProps) {
  const { t, i18n } = useTranslation();
  const [translated, setTranslated] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [error, setError] = useState(false);

  const handleTranslate = async () => {
    if (translated) {
      setOpen(true);
      return;
    }
    setLoading(true);
    setError(false);
    try {
      const { data, error: fnError } = await supabase.functions.invoke("ai-translate", {
        body: { text, target_language: i18n.language, is_html: false },
      });
      if (fnError) throw fnError;
      setTranslated(data.translated);
      setOpen(true);
    } catch {
      setError(true);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className={cn(
            size === "xs" ? "h-5 w-5" : "h-6 w-6",
            "rounded-full opacity-60 hover:opacity-100",
            className
          )}
          onClick={handleTranslate}
          disabled={loading || !text}
          title={t("translate.aiTranslate")}
        >
          {loading ? (
            <Loader2 className={cn(size === "xs" ? "h-3 w-3" : "h-3.5 w-3.5", "animate-spin")} />
          ) : (
            <Languages className={size === "xs" ? "h-3 w-3" : "h-3.5 w-3.5"} />
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-72 text-sm" side="top">
        <div className="flex items-center justify-between mb-1">
          <span className="text-xs font-medium text-muted-foreground">{t("translate.translation")}</span>
          <Button variant="ghost" size="icon" className="h-4 w-4" onClick={() => setOpen(false)}>
            <X className="h-3 w-3" />
          </Button>
        </div>
        {error ? (
          <p className="text-destructive text-xs">{t("translate.error")}</p>
        ) : (
          <p className="whitespace-pre-wrap">{translated}</p>
        )}
      </PopoverContent>
    </Popover>
  );
}
