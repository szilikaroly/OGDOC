import { useState } from "react";
import { useTranslation } from "react-i18next";
import TravelVaccinationAdvisor from "@/components/TravelVaccinationAdvisor";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Syringe, AlertTriangle, Search } from "lucide-react";
import { format, differenceInDays } from "date-fns";
import { hu } from "date-fns/locale";
import ExportButton from "@/components/ExportButton";

export default function DoctorVaccinations() {
  const { t } = useTranslation();
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<"all" | "expiring" | "expired">("all");

  const { data: vaccinations, isLoading } = useQuery({
    queryKey: ["doctor-vaccinations"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("vaccinations")
        .select("*")
        .order("administered_date", { ascending: false });
      if (error) throw error;

      const userIds = [...new Set(data.map((v) => v.user_id))];
      const { data: profiles } = await supabase
        .from("profiles")
        .select("user_id, full_name, taj_number")
        .in("user_id", userIds);

      const nameMap = Object.fromEntries(
        (profiles ?? []).map((p) => [p.user_id, { name: p.full_name, taj: p.taj_number }])
      );

      return data.map((v) => ({
        ...v,
        patient_name: nameMap[v.user_id]?.name ?? "—",
        patient_taj: nameMap[v.user_id]?.taj ?? "",
      }));
    },
  });

  const getExpiryBadge = (expiry: string | null) => {
    if (!expiry) return <span className="text-muted-foreground">—</span>;
    const days = differenceInDays(new Date(expiry), new Date());
    if (days < 0) return <Badge variant="destructive">{t("vaccinations.expiredDays", { days: Math.abs(days) })}</Badge>;
    if (days <= 30) return <Badge variant="destructive" className="flex items-center gap-1"><AlertTriangle className="h-3 w-3" />{t("vaccinations.daysLeft", { days })}</Badge>;
    if (days <= 90) return <Badge variant="secondary">{t("vaccinations.daysLeft", { days })}</Badge>;
    return <Badge variant="outline">{format(new Date(expiry), "yyyy.MM.dd")}</Badge>;
  };

  const filtered = (vaccinations ?? []).filter((v) => {
    const matchesSearch =
      !search ||
      v.patient_name.toLowerCase().includes(search.toLowerCase()) ||
      v.vaccine_name.toLowerCase().includes(search.toLowerCase()) ||
      (v.patient_taj ?? "").includes(search);

    if (!matchesSearch) return false;

    if (filter === "expired") {
      return v.expiry_date && differenceInDays(new Date(v.expiry_date), new Date()) < 0;
    }
    if (filter === "expiring") {
      return v.expiry_date && differenceInDays(new Date(v.expiry_date), new Date()) <= 30 && differenceInDays(new Date(v.expiry_date), new Date()) >= 0;
    }
    return true;
  });

  if (isLoading) {
    return <div className="flex justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Syringe className="h-6 w-6 text-secondary" />
          <h1 className="text-2xl font-bold">{t("vaccinations.title")}</h1>
        </div>
        <ExportButton
          filename="oltasok"
          headers={[t("vaccinations.patient"), "TAJ", t("vaccinations.vaccine"), t("vaccinations.administered"), t("vaccinations.expiry"), t("vaccinations.lotNumber"), t("vaccinations.administeredBy")]}
          rows={filtered.map((v) => [
            v.patient_name, v.patient_taj ?? "", v.vaccine_name,
            v.administered_date, v.expiry_date ?? "", v.lot_number ?? "", v.administered_by ?? "",
          ])}
        />
      </div>

      <div className="flex gap-3 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder={t("vaccinations.searchPlaceholder")}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={filter} onValueChange={(v) => setFilter(v as any)}>
          <SelectTrigger className="w-[180px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t("vaccinations.all")}</SelectItem>
            <SelectItem value="expiring">{t("vaccinations.expiringSoon")}</SelectItem>
            <SelectItem value="expired">{t("vaccinations.expired")}</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <TravelVaccinationAdvisor />

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">{t("vaccinations.title")} ({filtered.length})</CardTitle>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t("vaccinations.patient")}</TableHead>
                <TableHead>TAJ</TableHead>
                <TableHead>{t("vaccinations.vaccine")}</TableHead>
                <TableHead>{t("vaccinations.administered")}</TableHead>
                <TableHead>{t("vaccinations.expiry")}</TableHead>
                <TableHead>{t("vaccinations.lotNumber")}</TableHead>
                <TableHead>{t("vaccinations.administeredBy")}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((v) => (
                <TableRow key={v.id}>
                  <TableCell className="font-medium">{v.patient_name}</TableCell>
                  <TableCell className="text-muted-foreground">{v.patient_taj || "—"}</TableCell>
                  <TableCell>{v.vaccine_name}</TableCell>
                  <TableCell>{format(new Date(v.administered_date), "yyyy.MM.dd", { locale: hu })}</TableCell>
                  <TableCell>{getExpiryBadge(v.expiry_date)}</TableCell>
                  <TableCell className="text-muted-foreground">{v.lot_number || "—"}</TableCell>
                  <TableCell>{v.administered_by || "—"}</TableCell>
                </TableRow>
              ))}
              {filtered.length === 0 && (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                    {t("vaccinations.noResults")}
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
