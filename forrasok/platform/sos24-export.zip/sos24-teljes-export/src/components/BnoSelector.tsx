import { useTranslation } from "react-i18next";
import { Badge } from "@/components/ui/badge";
import { X } from "lucide-react";

interface BnoSelectorProps {
  codes: string[];
  onRemove: (code: string) => void;
  version?: string;
  emptyText?: string;
}

export default function BnoSelector({ codes, onRemove, version = "icd10", emptyText }: BnoSelectorProps) {
  const { t } = useTranslation();

  if (codes.length === 0) {
    return (
      <p className="text-sm text-muted-foreground italic">
        {emptyText || t("icd.noSelectedCodes")}
      </p>
    );
  }

  return (
    <div className="flex flex-wrap gap-1.5">
      {codes.map((code) => (
        <Badge key={code} variant="secondary" className="gap-1 text-xs font-mono">
          <span className="text-primary">{code}</span>
          <span className="uppercase text-[10px] text-muted-foreground">{version}</span>
          <button
            type="button"
            onClick={() => onRemove(code)}
            className="ml-1 hover:text-destructive"
            aria-label={t("common.remove")}
          >
            <X className="h-3 w-3" />
          </button>
        </Badge>
      ))}
    </div>
  );
}
