import { useState, useRef, useEffect, useCallback } from "react";
import { useTranslation } from "react-i18next";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { useIcdCodes, type IcdCode, type IcdVersion } from "@/hooks/use-icd-codes";
import { useIcdAiSuggest } from "@/hooks/use-icd-ai-suggest";
import { Search, Sparkles, X, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface BnoSearchProps {
  value?: string;
  values?: string[];
  onChange: (code: string) => void;
  onRemove?: (code: string) => void;
  multiple?: boolean;
  version?: IcdVersion;
  onVersionChange?: (version: IcdVersion) => void;
  placeholder?: string;
  className?: string;
  showAiSuggest?: boolean;
}

export default function BnoSearch({
  value = "",
  values = [],
  onChange,
  onRemove,
  multiple = false,
  version = "icd10",
  onVersionChange,
  placeholder,
  className,
  showAiSuggest = true,
}: BnoSearchProps) {
  const { t } = useTranslation();
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [aiOpen, setAiOpen] = useState(false);
  const [aiDescription, setAiDescription] = useState("");
  const debounceRef = useRef<ReturnType<typeof setTimeout>>();
  const containerRef = useRef<HTMLDivElement>(null);

  const { data: results = [], isLoading } = useIcdCodes(query, version, 20, open);
  const { suggest, isSuggesting } = useIcdAiSuggest();
  const [aiResults, setAiResults] = useState<IcdCode[]>([]);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const handleChange = useCallback(
    (value: string) => {
      setQuery(value);
      if (debounceRef.current) clearTimeout(debounceRef.current);
      debounceRef.current = setTimeout(() => {
        setOpen(true);
      }, 250);
    },
    []
  );

  const handleSelect = (code: IcdCode) => {
    onChange(code.code);
    if (!multiple) {
      setQuery("");
      setOpen(false);
    } else {
      setQuery("");
      setOpen(false);
    }
  };

  const handleAiSuggest = async () => {
    if (!aiDescription.trim()) return;
    const suggestions = await suggest(aiDescription.trim(), version, 8);
    setAiResults(suggestions);
  };

  const selectedSet = new Set(values);
  const isSelected = (code: string) => selectedSet.has(code) || (!multiple && value === code);

  return (
    <div ref={containerRef} className={cn("relative", className)}>
      {multiple && values.length > 0 && (
        <div className="flex flex-wrap gap-1.5 mb-2">
          {values.map((code) => (
            <Badge key={code} variant="secondary" className="gap-1 font-mono text-xs">
              {code}
              {onRemove && (
                <button
                  type="button"
                  onClick={() => onRemove(code)}
                  className="ml-1 hover:text-destructive"
                  aria-label={t("common.remove")}
                >
                  <X className="h-3 w-3" />
                </button>
              )}
            </Badge>
          ))}
        </div>
      )}

      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => handleChange(e.target.value)}
            onFocus={() => {
              if (query.trim().length >= 2) setOpen(true);
            }}
            placeholder={placeholder || t("icd.searchPlaceholder")}
            className="pl-9"
          />
        </div>
        {onVersionChange && (
          <div className="flex rounded-md border overflow-hidden">
            <Button
              type="button"
              variant={version === "icd10" ? "default" : "ghost"}
              size="sm"
              onClick={() => onVersionChange("icd10")}
              className="rounded-none px-3"
            >
              ICD-10
            </Button>
            <Button
              type="button"
              variant={version === "icd11" ? "default" : "ghost"}
              size="sm"
              onClick={() => onVersionChange("icd11")}
              className="rounded-none px-3"
            >
              ICD-11
            </Button>
          </div>
        )}
        {showAiSuggest && (
          <Button
            type="button"
            variant="outline"
            size="icon"
            onClick={() => setAiOpen(true)}
            title={t("icd.aiSuggestTitle")}
          >
            <Sparkles className="h-4 w-4" />
          </Button>
        )}
      </div>

      {open && (
        <div className="absolute z-50 mt-1 w-full rounded-md border bg-popover shadow-lg max-h-72 overflow-y-auto">
          {isLoading && (
            <div className="flex items-center gap-2 px-3 py-2 text-sm text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" />
              {t("icd.searching")}
            </div>
          )}
          {!isLoading && results.length === 0 && query.trim().length >= 2 && (
            <div className="px-3 py-2 text-sm text-muted-foreground">{t("icd.noResults")}</div>
          )}
          {!isLoading && query.trim().length < 2 && (
            <div className="px-3 py-2 text-sm text-muted-foreground">{t("icd.typeToSearch")}</div>
          )}
          {results.map((code) => (
            <button
              key={code.id}
              type="button"
              onClick={() => handleSelect(code)}
              disabled={isSelected(code.code)}
              className={cn(
                "w-full text-left px-3 py-2 text-sm hover:bg-accent hover:text-accent-foreground transition-colors flex items-start gap-2",
                isSelected(code.code) && "opacity-50 cursor-not-allowed"
              )}
            >
              <span className="font-mono text-xs font-medium text-primary min-w-[4rem] shrink-0">
                {code.code}
              </span>
              <span className="flex-1 truncate">
                {code.label_hu}
                {code.label_en && code.label_en !== code.label_hu && (
                  <span className="block text-xs text-muted-foreground">{code.label_en}</span>
                )}
              </span>
              {code.category && (
                <Badge variant="outline" className="text-[10px] shrink-0">
                  {code.category}
                </Badge>
              )}
            </button>
          ))}
        </div>
      )}

      <Dialog open={aiOpen} onOpenChange={setAiOpen}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle>{t("icd.aiSuggestTitle")}</DialogTitle>
            <DialogDescription>{t("icd.aiSuggestDescription")}</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <Textarea
              value={aiDescription}
              onChange={(e) => setAiDescription(e.target.value)}
              placeholder={t("icd.aiSuggestPlaceholder")}
              rows={4}
            />
            <Button
              type="button"
              onClick={handleAiSuggest}
              disabled={isSuggesting || !aiDescription.trim()}
              className="w-full"
            >
              {isSuggesting ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  {t("icd.aiSuggesting")}
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4 mr-2" />
                  {t("icd.aiSuggestButton")}
                </>
              )}
            </Button>

            {aiResults.length > 0 && (
              <div className="space-y-2">
                <p className="text-sm font-medium">{t("icd.aiResults")}</p>
                <div className="rounded-md border divide-y">
                  {aiResults.map((code) => (
                    <button
                      key={code.id}
                      type="button"
                      onClick={() => {
                        handleSelect(code);
                        setAiOpen(false);
                        setAiDescription("");
                        setAiResults([]);
                      }}
                      disabled={isSelected(code.code)}
                      className={cn(
                        "w-full text-left px-3 py-2 text-sm hover:bg-accent transition-colors flex items-start gap-2",
                        isSelected(code.code) && "opacity-50 cursor-not-allowed"
                      )}
                    >
                      <span className="font-mono text-xs font-medium text-primary min-w-[4rem] shrink-0">
                        {code.code}
                      </span>
                      <span className="flex-1">{code.label_hu}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
