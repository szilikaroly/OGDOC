interface ReferralData {
  company_name: string;
  company_address?: string | null;
  company_tax_number?: string | null;
  company_phone?: string | null;
  company_email?: string | null;
  company_teaor?: string | null;
  employee_name: string;
  employee_birth_date?: string | null;
  employee_address?: string | null;
  employee_taj?: string | null;
  employee_birth_place?: string | null;
  employee_mother_name?: string | null;
  position?: string | null;
  feor?: string | null;
  unit_name?: string | null;
  exam_reason: string;
  risk_factors: Record<string, boolean>;
  created_at: string;
}

interface PrintableReferralProps {
  referral: ReferralData;
}

// Official risk factor table matching the document
const RISK_TABLE_LEFT = [
  { num: "1.", label: "Kézi anyagmozgatás" },
  { num: "1.1", label: "5 kp-20 kp" },
  { num: "1.2", label: ">20 kp-50 kp" },
  { num: "1.3", label: ">50 kp" },
  { num: "2.", label: "Fokozott baleseti veszély (magasban végzett, villamos üzemi feszültség alatti munka), egyéb" },
  { num: "3.", label: "Kényszertest\u00ADhelyzet (görnyedés, guggolás)" },
  { num: "4.", label: "Ülés" },
  { num: "5.", label: "Állás" },
  { num: "6.", label: "Járás" },
  { num: "7.", label: "Terhelő munkahelyi klíma (meleg, hideg, nedves, változó)" },
  { num: "8.", label: "Zaj" },
  { num: "9.", label: "Ionizáló sugárzás" },
  { num: "10.", label: "Nem-ionizáló sugárzás" },
  { num: "11.", label: "Helyileg ható vibráció" },
  { num: "12.", label: "Egésztest-vibráció" },
  { num: "13.", label: "Ergonómiai tényezők" },
];

const RISK_TABLE_RIGHT = [
  { num: "14.", label: "Porok, megnevezve" },
  { num: "15.", label: "Vegyi anyagok megnevezve" },
  { num: "16.", label: "Járványügyi érdekből kiemelt munka-kör" },
  { num: "17.", label: "Fertőzésveszély" },
  { num: "18.", label: "Fokozott pszichés terhelés" },
  { num: "19.", label: "Képernyő előtt végzett munka" },
  { num: "20.", label: "Éjszakai műszakban végzett munka" },
  { num: "21.", label: "Pszichoszociális tényezők" },
  { num: "22.", label: "Egyéni védőeszköz általi terhelés" },
  { num: "23.", label: "Egyéb" },
];

// Map i18n keys to table numbers (new format)
const RISK_KEY_MAPPING: Record<string, string> = {
  "referralRiskFactors.manualHandling": "1.",
  "referralRiskFactors.heavyPhysical": "1.1",
  "referralRiskFactors.forcedPosition": "3.",
  "referralRiskFactors.screenWork": "19.",
  "referralRiskFactors.noise": "8.",
  "referralRiskFactors.vibrationHand": "11.",
  "referralRiskFactors.vibrationBody": "12.",
  "referralRiskFactors.ionizingRadiation": "9.",
  "referralRiskFactors.nonIonizingRadiation": "10.",
  "referralRiskFactors.chemicalAirway": "15.",
  "referralRiskFactors.chemicalSkin": "15.",
  "referralRiskFactors.biologicalAgent": "16.",
  "referralRiskFactors.dustFibrogenic": "14.",
  "referralRiskFactors.dustNonFibrogenic": "14.",
  "referralRiskFactors.nightShift": "20.",
  "referralRiskFactors.highTemperature": "7.",
  "referralRiskFactors.lowTemperature": "7.",
  "referralRiskFactors.heightWork": "2.",
  "referralRiskFactors.depthWork": "2.",
  "referralRiskFactors.driving": "2.",
  "referralRiskFactors.aloneWork": "13.",
  "referralRiskFactors.psychosocial": "18.",
  "referralRiskFactors.other": "23.",
};

// Legacy mapping for old Hungarian-stored data (backward compatibility)
const LEGACY_RISK_MAPPING: Record<string, string> = {
  "Kézi anyagmozgatás": "1.",
  "Fokozott fizikai igénybevétel": "1.1",
  "Kényszerhelyzet": "3.",
  "Képernyős munkavégzés": "19.",
  "Zaj": "8.",
  "Rezgés (kéz-kar)": "11.",
  "Rezgés (egésztest)": "12.",
  "Ionizáló sugárzás": "9.",
  "Nem ionizáló sugárzás": "10.",
  "Vegyi anyag (légúti)": "15.",
  "Vegyi anyag (bőr)": "15.",
  "Biológiai kóroki tényező": "16.",
  "Por (fibrogenizáló)": "14.",
  "Por (nem fibrogenizáló)": "14.",
  "Éjszakai műszak": "20.",
  "Magas hőmérséklet": "7.",
  "Alacsony hőmérséklet": "7.",
  "Magasban végzett munka": "2.",
  "Mélységben végzett munka": "2.",
  "Gépjárművezetés": "2.",
  "Egyedül végzett munka": "13.",
  "Fokozott pszichés terhelés": "18.",
  "Egyéb": "23.",
};

const EXAM_REASON_LABELS: Record<string, string> = {
  "Munkába lépés előtti": "munkába lépés előtti",
  "Munkakör változás": "munkakör (hely) változás előtti",
  "Időszakos": "időszakos",
  "Soron kívüli": "soron kívüli",
  "Záróvizsgálat": "záróvizsgálat",
};

export default function PrintableReferral({ referral }: PrintableReferralProps) {
  const activeRiskNums = new Set<string>();
  Object.entries(referral.risk_factors).forEach(([key, val]) => {
    if (!val) return;
    // Try i18n key mapping first, then legacy Hungarian mapping
    const num = RISK_KEY_MAPPING[key] || LEGACY_RISK_MAPPING[key];
    if (num) activeRiskNums.add(num);
  });

  const today = new Date(referral.created_at);
  const year = today.getFullYear();
  const month = today.toLocaleString("hu-HU", { month: "long" });
  const day = today.getDate();

  const reasonText = EXAM_REASON_LABELS[referral.exam_reason] || referral.exam_reason;

  return (
    <div className="hidden print:block print:text-black" style={{ fontFamily: "'Times New Roman', serif", fontSize: "11px", lineHeight: "1.4" }}>
      {/* PAGE 1 */}
      <div style={{ padding: "40px 50px" }}>
        {/* Company header */}
        <div style={{ borderBottom: "1px dotted #000", paddingBottom: 4, marginBottom: 2, fontSize: "10px" }}>
          <strong>{referral.company_name}</strong>
          {referral.company_address && <span> — {referral.company_address}</span>}
        </div>
        <div style={{ fontSize: "10px", marginBottom: 4 }}>
          {referral.company_tax_number && <span>Adószám: {referral.company_tax_number} | </span>}
          {referral.company_phone && <span>Tel: {referral.company_phone} | </span>}
          {referral.company_email && <span>{referral.company_email}</span>}
        </div>
        {referral.company_teaor && (
          <div style={{ fontSize: "10px", marginBottom: 4 }}>
            TEÁOR: {referral.company_teaor}
          </div>
        )}
        <div style={{ fontSize: "10px", marginBottom: 24 }}>
          A munkáltató megnevezése<br />
          cégszerű bélyegzője
        </div>

        {/* Title */}
        <h1 style={{ textAlign: "center", fontWeight: "bold", fontSize: "14px", marginBottom: 4 }}>
          Beutalás munkaköri orvosi alkalmassági vizsgálatra<sup>1</sup>
        </h1>
        <p style={{ textAlign: "center", fontSize: "11px", marginBottom: 20 }}>
          (A munkáltató tölti ki!)
        </p>

        {/* Employee data */}
        <div style={{ marginBottom: 6 }}>
          A munkavállaló neve: <span style={{ borderBottom: "1px solid #000", display: "inline-block", minWidth: 250, textAlign: "center", fontWeight: "bold" }}>{referral.employee_name}</span>
          {" "}Születési hely: <span style={{ borderBottom: "1px solid #000", display: "inline-block", minWidth: 120, textAlign: "center" }}>
            {referral.employee_birth_place || "………"}
          </span>
          {" "}idő: <span style={{ borderBottom: "1px solid #000", display: "inline-block", minWidth: 80, textAlign: "center" }}>
            {referral.employee_birth_date ? new Date(referral.employee_birth_date).toLocaleDateString("hu-HU") : "………"}
          </span>
        </div>
        <div style={{ marginBottom: 6 }}>
          Anyja neve: <span style={{ borderBottom: "1px solid #000", display: "inline-block", minWidth: 300, textAlign: "center" }}>
            {referral.employee_mother_name || ""}
          </span>
        </div>
        <div style={{ marginBottom: 6 }}>
          Lakcíme: <span style={{ borderBottom: "1px solid #000", display: "inline-block", minWidth: 500, textAlign: "center" }}>
            {referral.employee_address || ""}
          </span>
        </div>
        <div style={{ marginBottom: 6 }}>
          Munkaköre: <span style={{ borderBottom: "1px solid #000", display: "inline-block", minWidth: 200, textAlign: "center", fontWeight: "bold" }}>
            {referral.position || ""}
          </span>
          {" "}TAJ száma: <span style={{ borderBottom: "1px solid #000", display: "inline-block", minWidth: 120, textAlign: "center" }}>
            {referral.employee_taj || ""}
          </span>
        </div>
        <div style={{ marginBottom: 6 }}>
          FEOR: <span style={{ borderBottom: "1px solid #000", display: "inline-block", minWidth: 100, textAlign: "center" }}>
            {referral.feor || ""}
          </span>
          {" "}Egység megnevezés: <span style={{ borderBottom: "1px solid #000", display: "inline-block", minWidth: 250, textAlign: "center" }}>
            {referral.unit_name || ""}
          </span>
        </div>
        <div style={{ marginBottom: 24 }}>
          A vizsgálat oka: <span style={{ textDecoration: "underline", fontWeight: "bold" }}>{reasonText}</span><sup>2</sup>
        </div>

        {/* Risk factors table */}
        <h2 style={{ textAlign: "center", fontWeight: "bold", fontSize: "12px", marginBottom: 8 }}>
          A munkakör (munkahely) főbb egészségkárosító kockázatai<sup>3</sup>
        </h2>

        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "10px", marginBottom: 20 }}>
          <thead>
            <tr>
              <th colSpan={3} style={{ border: "1px solid #000", padding: "3px 6px", textAlign: "center" }}>Kockázat</th>
              <th colSpan={2} style={{ border: "1px solid #000", padding: "3px 6px", textAlign: "center" }}>A munkaidő</th>
              <th colSpan={3} style={{ border: "1px solid #000", padding: "3px 6px", textAlign: "center" }}>Kockázat</th>
              <th colSpan={2} style={{ border: "1px solid #000", padding: "3px 6px", textAlign: "center" }}>A munkaidő</th>
            </tr>
            <tr>
              <th style={{ border: "1px solid #000", padding: "2px 4px", width: "30px" }}>jelzése</th>
              <th style={{ border: "1px solid #000", padding: "2px 4px" }}>megnevezése</th>
              <th style={{ border: "1px solid #000", padding: "2px 4px", width: "50px" }}>egészében</th>
              <th style={{ border: "1px solid #000", padding: "2px 4px", width: "40px" }}>egy részben</th>
              <th style={{ border: "1px solid #000", padding: "2px 4px", width: "10px" }}></th>
              <th style={{ border: "1px solid #000", padding: "2px 4px", width: "30px" }}>jelzése</th>
              <th style={{ border: "1px solid #000", padding: "2px 4px" }}>megnevezése</th>
              <th style={{ border: "1px solid #000", padding: "2px 4px", width: "50px" }}>egészében</th>
              <th style={{ border: "1px solid #000", padding: "2px 4px", width: "40px" }}>egy részben</th>
            </tr>
          </thead>
          <tbody>
            {RISK_TABLE_LEFT.map((left, i) => {
              const right = RISK_TABLE_RIGHT[i];
              const leftActive = activeRiskNums.has(left.num);
              const rightActive = right ? activeRiskNums.has(right.num) : false;
              return (
                <tr key={i}>
                  <td style={{ border: "1px solid #000", padding: "2px 4px", textAlign: "center" }}>{left.num}</td>
                  <td style={{ border: "1px solid #000", padding: "2px 4px", fontSize: "9px" }}>{left.label}</td>
                  <td style={{ border: "1px solid #000", padding: "2px 4px", textAlign: "center", fontWeight: "bold", fontSize: "14px" }}>
                    {leftActive ? "X" : ""}
                  </td>
                  <td style={{ border: "1px solid #000", padding: "2px 4px", textAlign: "center" }}></td>
                  {/* spacer */}
                  <td style={{ border: "none", width: 8 }}></td>
                  {right ? (
                    <>
                      <td style={{ border: "1px solid #000", padding: "2px 4px", textAlign: "center" }}>{right.num}</td>
                      <td style={{ border: "1px solid #000", padding: "2px 4px", fontSize: "9px" }}>{right.label}</td>
                      <td style={{ border: "1px solid #000", padding: "2px 4px", textAlign: "center", fontWeight: "bold", fontSize: "14px" }}>
                        {rightActive ? "X" : ""}
                      </td>
                      <td style={{ border: "1px solid #000", padding: "2px 4px", textAlign: "center" }}></td>
                    </>
                  ) : (
                    <>
                      <td style={{ border: "1px solid #000", padding: "2px 4px" }}></td>
                      <td style={{ border: "1px solid #000", padding: "2px 4px" }}></td>
                      <td style={{ border: "1px solid #000", padding: "2px 4px" }}></td>
                      <td style={{ border: "1px solid #000", padding: "2px 4px" }}></td>
                    </>
                  )}
                </tr>
              );
            })}
          </tbody>
        </table>

        {/* Date and signature */}
        <div style={{ marginBottom: 40 }}>
          Szeged, {year}. év {month} {day}. napján
        </div>

        <div style={{ textAlign: "center", marginBottom: 30 }}>P.H.</div>

        <div style={{ textAlign: "right" }}>
          <div style={{ borderBottom: "1px dotted #000", width: 250, display: "inline-block", marginBottom: 4 }}></div>
          <div style={{ fontSize: "10px" }}>munkáltató aláírása, hiteles bélyegzője</div>
        </div>

        {/* Footnotes */}
        <div style={{ borderTop: "1px solid #000", marginTop: 40, paddingTop: 8, fontSize: "8px" }}>
          <p><sup>1</sup> Időszakos alkalmassági vizsgálathoz e nyomtatvány hátoldalán lévő beutaló is használható.</p>
          <p><sup>2</sup> Kérjük a megfelelő szövegrészt aláhúzni!</p>
          <p><sup>3</sup> A megnevezett munkakörben fennálló kockázatok megfelelő rovatába tintával kell X-et írni, ahol több tényező van felsorolva, a megfelelőt kérjük aláhúzni!</p>
        </div>
      </div>

      {/* PAGE 2 */}
      <div style={{ pageBreakBefore: "always", padding: "60px 50px" }}>
        <div style={{ marginBottom: 6 }}>
          Munkáltató megnevezése: <span style={{ borderBottom: "1px solid #000", display: "inline-block", minWidth: 300, textAlign: "center", fontWeight: "bold" }}>
            {referral.company_name}
          </span>
          {referral.company_address && <span> — {referral.company_address}</span>}
        </div>
        {referral.company_teaor && (
          <div style={{ marginBottom: 6, fontSize: "10px" }}>
            TEÁOR: {referral.company_teaor}
          </div>
        )}
        <div style={{ marginBottom: 20 }}></div>

        <h2 style={{ textAlign: "center", fontWeight: "bold", fontSize: "14px", marginBottom: 20 }}>
          Beutalás munkaköri orvosi alkalmassági vizsgálatra
        </h2>

        <div style={{ marginBottom: 6 }}>
          A munkavállaló neve: <span style={{ borderBottom: "1px solid #000", display: "inline-block", minWidth: 250, textAlign: "center", fontWeight: "bold" }}>{referral.employee_name}</span>
          {" "}Születési hely: <span style={{ borderBottom: "1px solid #000", display: "inline-block", minWidth: 120, textAlign: "center" }}>
            {referral.employee_birth_place || "………"}
          </span>
          {" "}idő: <span style={{ borderBottom: "1px solid #000", display: "inline-block", minWidth: 80, textAlign: "center" }}>
            {referral.employee_birth_date ? new Date(referral.employee_birth_date).toLocaleDateString("hu-HU") : "………"}
          </span>
        </div>
        <div style={{ marginBottom: 6 }}>
          Anyja neve: <span style={{ borderBottom: "1px solid #000", display: "inline-block", minWidth: 300, textAlign: "center" }}>
            {referral.employee_mother_name || ""}
          </span>
        </div>
        <div style={{ marginBottom: 6 }}>
          Lakcíme: <span style={{ borderBottom: "1px solid #000", display: "inline-block", minWidth: 500, textAlign: "center" }}>
            {referral.employee_address || ""}
          </span>
        </div>
        <div style={{ marginBottom: 6 }}>
          Munkaköre: <span style={{ borderBottom: "1px solid #000", display: "inline-block", minWidth: 200, textAlign: "center", fontWeight: "bold" }}>
            {referral.position || ""}
          </span>
          {" "}TAJ száma: <span style={{ borderBottom: "1px solid #000", display: "inline-block", minWidth: 120, textAlign: "center" }}>
            {referral.employee_taj || ""}
          </span>
        </div>
        <div style={{ marginBottom: 6 }}>
          FEOR: <span style={{ borderBottom: "1px solid #000", display: "inline-block", minWidth: 100, textAlign: "center" }}>
            {referral.feor || ""}
          </span>
          {" "}Egység megnevezés: <span style={{ borderBottom: "1px solid #000", display: "inline-block", minWidth: 250, textAlign: "center" }}>
            {referral.unit_name || ""}
          </span>
        </div>

        <div style={{ marginTop: 20, marginBottom: 20 }}>
          Kérem nevezett munkaköri alkalmasságra vonatkozó vélemény közlését.
        </div>

        <div style={{ marginBottom: 40 }}>
          Szeged, {year}. év {month} {day}. napján
        </div>

        <div style={{ textAlign: "center", marginBottom: 30 }}>P.H.</div>

        <div style={{ textAlign: "right" }}>
          <div style={{ borderBottom: "1px dotted #000", width: 200, display: "inline-block", marginBottom: 4 }}></div>
          <div style={{ fontSize: "10px" }}>munkáltató aláírása</div>
        </div>
      </div>
    </div>
  );
}
