import { useState } from "react";
import { useTranslation } from "react-i18next";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Upload, Trash2, PenLine } from "lucide-react";
import { useQuery, useQueryClient } from "@tanstack/react-query";

export default function DoctorSignatureUpload() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [uploading, setUploading] = useState(false);

  const { data: signatureUrl, isLoading } = useQuery({
    queryKey: ["doctor-signature", user?.id],
    queryFn: async () => {
      const { data } = await supabase.from("profiles").select("signature_url").eq("user_id", user!.id).single();
      const storedPath = (data as any)?.signature_url as string | null;
      if (!storedPath) return null;
      if (storedPath.startsWith("http")) {
        const match = storedPath.match(/\/signatures\/(.+?)(\?|$)/);
        if (match) {
          const { data: signedData } = await supabase.storage.from("signatures").createSignedUrl(match[1], 3600);
          return signedData?.signedUrl ?? null;
        }
        return storedPath;
      }
      const { data: signedData } = await supabase.storage.from("signatures").createSignedUrl(storedPath, 3600);
      return signedData?.signedUrl ?? null;
    },
    enabled: !!user,
  });

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    if (!file.type.startsWith("image/")) {
      toast({ variant: "destructive", title: t("common.error"), description: t("signature.imageOnly") });
      return;
    }
    setUploading(true);
    try {
      const ext = file.name.split(".").pop();
      const path = `${user.id}/signature.${ext}`;
      await supabase.storage.from("signatures").remove([path]);
      const { error: uploadError } = await supabase.storage.from("signatures").upload(path, file, { upsert: true });
      if (uploadError) throw uploadError;
      const { error: updateError } = await supabase.from("profiles").update({ signature_url: path } as any).eq("user_id", user.id);
      if (updateError) throw updateError;
      qc.invalidateQueries({ queryKey: ["doctor-signature"] });
      toast({ title: t("signature.uploaded") });
    } catch (err: any) {
      toast({ variant: "destructive", title: t("common.error"), description: err.message });
    } finally {
      setUploading(false);
    }
  };

  const handleRemove = async () => {
    if (!user) return;
    setUploading(true);
    try {
      const { data: files } = await supabase.storage.from("signatures").list(user.id);
      if (files?.length) await supabase.storage.from("signatures").remove(files.map((f) => `${user.id}/${f.name}`));
      await supabase.from("profiles").update({ signature_url: null } as any).eq("user_id", user.id);
      qc.invalidateQueries({ queryKey: ["doctor-signature"] });
      toast({ title: t("signature.removed") });
    } catch (err: any) {
      toast({ variant: "destructive", title: t("common.error"), description: err.message });
    } finally {
      setUploading(false);
    }
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <PenLine className="h-4 w-4" /> {t("signature.title")}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {isLoading ? (
          <div className="h-20 flex items-center justify-center"><div className="h-6 w-6 animate-spin rounded-full border-2 border-secondary border-t-transparent" /></div>
        ) : signatureUrl ? (
          <div className="space-y-3">
            <div className="border rounded-md p-3 bg-muted/30">
              <img src={signatureUrl} alt={t("signature.title")} className="max-h-24 mx-auto object-contain" />
            </div>
            <div className="flex gap-2">
              <Label htmlFor="sig-replace" className="cursor-pointer">
                <Button variant="outline" size="sm" asChild disabled={uploading}><span><Upload className="h-3.5 w-3.5 mr-1" /> {t("signature.replace")}</span></Button>
              </Label>
              <Input id="sig-replace" type="file" accept="image/*" className="hidden" onChange={handleUpload} />
              <Button variant="destructive" size="sm" onClick={handleRemove} disabled={uploading}>
                <Trash2 className="h-3.5 w-3.5 mr-1" /> {t("signature.remove")}
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">{t("signature.desc")}</p>
            <Label htmlFor="sig-upload" className="cursor-pointer">
              <Button variant="outline" size="sm" asChild disabled={uploading}><span><Upload className="h-3.5 w-3.5 mr-1" /> {t("signature.upload")}</span></Button>
            </Label>
            <Input id="sig-upload" type="file" accept="image/*" className="hidden" onChange={handleUpload} />
          </div>
        )}
      </CardContent>
    </Card>
  );
}
