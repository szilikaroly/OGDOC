import { useState, useEffect, useRef, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth, type AppRole } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { MessageSquare, Send, Users, User } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { useTranslation } from "react-i18next";
import AiTranslateButton from "@/components/AiTranslateButton";

const GROUP_ROLES: AppRole[] = ["super_admin", "haziorvos", "uzemorvos", "munkaltato", "munkavallalo", "praxistag"];

// Role hierarchy: who can message whom (direct messages)
const ALLOWED_TARGETS: Record<AppRole, AppRole[]> = {
  super_admin: ["super_admin", "haziorvos", "uzemorvos", "munkaltato", "munkavallalo", "praxistag"],
  haziorvos: ["praxistag", "haziorvos"],
  praxistag: ["haziorvos", "praxistag"],
  uzemorvos: ["munkavallalo", "uzemorvos"],
  munkaltato: ["munkavallalo", "munkaltato"],
  munkavallalo: ["uzemorvos", "munkaltato", "munkavallalo"],
};

export default function MessagesPage() {
  const { user, roles, hasRole } = useAuth();
  const { toast } = useToast();
  const { t, i18n } = useTranslation();
  const qc = useQueryClient();
  const isAdmin = hasRole("super_admin");
  const [tab, setTab] = useState("direct");
  const [newMsg, setNewMsg] = useState("");
  const [subject, setSubject] = useState("");
  const [recipientId, setRecipientId] = useState("");
  const [groupRole, setGroupRole] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if ("Notification" in window && Notification.permission === "default") {
      Notification.requestPermission();
    }
  }, []);

  // Fetch all profiles with their roles for display
  const { data: profilesWithRoles } = useQuery({
    queryKey: ["all-profiles-with-roles"],
    queryFn: async () => {
      const { data: profiles, error } = await supabase
        .from("profiles")
        .select("user_id, full_name")
        .order("full_name");
      if (error) throw error;

      const { data: rolesData } = await supabase
        .from("user_roles")
        .select("user_id, role");

      return (profiles ?? []).map((p) => ({
        ...p,
        roles: (rolesData ?? []).filter((r) => r.user_id === p.user_id).map((r) => r.role),
      }));
    },
    enabled: !!user,
  });

  // Filter profiles based on role hierarchy
  const filteredProfiles = useMemo(() => {
    if (!profilesWithRoles || !user) return [];
    const activeRole = roles[0] as AppRole;
    const allowedTargetRoles = ALLOWED_TARGETS[activeRole] ?? [];

    return profilesWithRoles.filter(
      (p) =>
        p.user_id !== user.id &&
        p.roles.some((r) => allowedTargetRoles.includes(r as AppRole))
    );
  }, [profilesWithRoles, user, roles]);

  const { data: messages, isLoading } = useQuery({
    queryKey: ["my-messages"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("messages")
        .select("*")
        .or(`sender_id.eq.${user!.id},recipient_id.eq.${user!.id},group_role.in.(${roles.join(",")})`)
        .order("created_at", { ascending: true });
      if (error) throw error;
      return data;
    },
    enabled: !!user,
    refetchInterval: 15000,
  });

  const unreadCount = useMemo(() => {
    if (!messages || !user) return 0;
    return messages.filter(
      (m) => !m.is_read && m.sender_id !== user.id && (m.recipient_id === user.id || (m.group_role && roles.includes(m.group_role as AppRole)))
    ).length;
  }, [messages, user, roles]);

  useEffect(() => {
    if (!user) return;
    const channel = supabase
      .channel("messages-realtime")
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "messages" }, (payload) => {
        const msg = payload.new as any;
        if (msg.sender_id !== user.id) {
          const senderName = (profilesWithRoles ?? []).find((p) => p.user_id === msg.sender_id)?.full_name ?? t("messages.someone");
          if ("Notification" in window && Notification.permission === "granted") {
            new Notification(t("messages.newMessage"), {
              body: `${senderName}: ${msg.body?.substring(0, 80)}`,
              icon: "/placeholder.svg",
              tag: msg.id,
            });
          }
          toast({ title: t("messages.newMessage"), description: `${senderName}: ${msg.body?.substring(0, 60)}` });
        }
        qc.invalidateQueries({ queryKey: ["my-messages"] });
        qc.invalidateQueries({ queryKey: ["unread-count"] });
      })
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [user, qc, profilesWithRoles, toast, t]);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const markRead = useMutation({
    mutationFn: async (messageIds: string[]) => {
      if (!messageIds.length) return;
      const { error } = await supabase
        .from("messages")
        .update({ is_read: true })
        .in("id", messageIds)
        .eq("recipient_id", user!.id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["my-messages"] });
      qc.invalidateQueries({ queryKey: ["unread-count"] });
    },
  });

  useEffect(() => {
    if (!messages || !user) return;
    const unreadIds = messages
      .filter((m) => !m.is_read && m.recipient_id === user.id)
      .map((m) => m.id);
    if (unreadIds.length > 0) {
      markRead.mutate(unreadIds);
    }
  }, [messages, user]);

  const sendMessage = useMutation({
    mutationFn: async () => {
      const isGroup = tab === "group";
      const { error } = await supabase.from("messages").insert({
        sender_id: user!.id,
        recipient_id: isGroup ? null : (recipientId || null),
        group_role: isGroup ? (groupRole as AppRole) : null,
        body: newMsg,
        subject: subject || null,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      setNewMsg("");
      setSubject("");
      qc.invalidateQueries({ queryKey: ["my-messages"] });
    },
    onError: (e: any) => toast({ variant: "destructive", title: t("messages.error"), description: e.message }),
  });

  const getProfileName = (id: string) => (profilesWithRoles ?? []).find((p) => p.user_id === id)?.full_name ?? t("messages.unknown");

  const filteredMessages = useMemo(() => {
    if (!messages) return [];
    if (tab === "direct") return messages.filter((m) => !m.group_role);
    return messages.filter((m) => !!m.group_role);
  }, [messages, tab]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <MessageSquare className="h-6 w-6 text-secondary" />
        <h1 className="text-2xl font-bold">{t("messages.title")}</h1>
        {unreadCount > 0 && (
          <Badge variant="destructive" className="text-xs">{unreadCount} {t("messages.unread")}</Badge>
        )}
      </div>

      <Card className="flex flex-col h-[65vh]">
        <CardHeader className="pb-2">
          {isAdmin ? (
            <Tabs value={tab} onValueChange={setTab}>
              <TabsList>
                <TabsTrigger value="direct" className="gap-1.5">
                  <User className="h-3.5 w-3.5" /> {t("messages.direct")}
                </TabsTrigger>
                <TabsTrigger value="group" className="gap-1.5">
                  <Users className="h-3.5 w-3.5" /> {t("messages.group")}
                </TabsTrigger>
              </TabsList>
            </Tabs>
          ) : (
            <CardTitle className="text-lg flex items-center gap-2">
              <User className="h-4 w-4" /> {t("messages.directMessages")}
            </CardTitle>
          )}
        </CardHeader>
        <CardContent className="flex-1 flex flex-col min-h-0">
          <ScrollArea className="flex-1 pr-4">
            <div className="space-y-3">
              {filteredMessages.map((m) => {
                const isMine = m.sender_id === user?.id;
                return (
                  <div key={m.id} className={cn("flex", isMine ? "justify-end" : "justify-start")}>
                    <div
                      className={cn(
                        "max-w-[70%] rounded-lg px-3 py-2",
                        isMine ? "bg-primary text-primary-foreground" : "bg-muted",
                        !m.is_read && !isMine && "ring-2 ring-secondary/50"
                      )}
                    >
                      <div className="flex items-center gap-2 mb-1">
                        <p className="text-xs font-medium">{isMine ? t("messages.me") : getProfileName(m.sender_id)}</p>
                        {m.group_role && (
                          <Badge variant="outline" className="text-[9px] h-4 px-1">
                            → {t(`roles.${m.group_role}`)}
                          </Badge>
                        )}
                      </div>
                      {m.subject && <p className="text-xs font-semibold mb-0.5">{m.subject}</p>}
                      <p className="text-sm whitespace-pre-wrap">{m.body}</p>
                      <div className="flex items-center gap-1 mt-1">
                        <p className="text-[10px] opacity-70">
                          {new Date(m.created_at).toLocaleString(i18n.language === "hu" ? "hu-HU" : undefined)}
                        </p>
                        <AiTranslateButton text={m.body} />
                      </div>
                    </div>
                  </div>
                );
              })}
              {filteredMessages.length === 0 && (
                <p className="text-center text-muted-foreground text-sm py-8">{t("messages.noMessages")}</p>
              )}
              <div ref={scrollRef} />
            </div>
          </ScrollArea>

          <div className="space-y-2 pt-3 border-t mt-3">
            <div className="flex gap-2">
              {tab === "direct" || !isAdmin ? (
                <Select value={recipientId} onValueChange={setRecipientId}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder={t("messages.recipient")} />
                  </SelectTrigger>
                  <SelectContent>
                    {filteredProfiles.map((p) => (
                      <SelectItem key={p.user_id} value={p.user_id}>
                        {p.full_name}
                        <span className="text-muted-foreground text-xs ml-1">
                          ({p.roles.map((r) => t(`roles.${r}`)).join(", ")})
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              ) : (
                <Select value={groupRole} onValueChange={setGroupRole}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder={t("messages.groupTarget")} />
                  </SelectTrigger>
                  <SelectContent>
                    {GROUP_ROLES.map((r) => (
                      <SelectItem key={r} value={r}>{t(`roles.${r}`)}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
              <Input
                placeholder={t("messages.subjectOptional")}
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                className="w-40"
              />
            </div>
            <div className="flex gap-2">
              <Input
                className="flex-1"
                placeholder={t("messages.messagePlaceholder")}
                value={newMsg}
                onChange={(e) => setNewMsg(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey && newMsg) {
                    e.preventDefault();
                    sendMessage.mutate();
                  }
                }}
              />
              <Button
                onClick={() => sendMessage.mutate()}
                disabled={
                  !newMsg || sendMessage.isPending ||
                  (tab === "direct" && !recipientId) ||
                  (tab === "group" && isAdmin && !groupRole)
                }
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}