import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Save, Plus, Trash2 } from "lucide-react";
import MedicationSearch from "@/components/MedicationSearch";
import { useTranslation } from "react-i18next";

const FAMILY_MEMBERS = ["apa", "anya", "testver"] as const;
const FAMILY_MEMBER_LABELS: Record<string, string> = { apa: "Apa", anya: "Anya", testver: "Testvér" };
const ORGAN_SYSTEMS = [
  { key: "cardiovascular", label: "Szív-érrendszeri" },
  { key: "respiratory", label: "Légzőszervi" },
  { key: "cancer", label: "Daganatos" },
  { key: "digestive", label: "Emésztőszervi" },
  { key: "metabolic", label: "Anyagcsere" },
  { key: "psychiatric", label: "Pszichiátriai" },
  { key: "other", label: "Egyéb" },
];

const EXPOSURE_CATEGORIES = [
  {
    key: "fizikai", label: "Fizikai kóroki tényezők",
    items: ["Zaj", "Vibráció (kéz-kar)", "Vibráció (egész test)", "Ionizáló sugárzás", "Nem ionizáló sugárzás", "Mikroklíma (meleg)", "Mikroklíma (hideg)", "Túlnyomás", "Por (szervetlen)", "Por (szerves)"],
  },
  {
    key: "kemiai", label: "Kémiai kóroki tényezők",
    items: ["Oldószerek", "Fémek és vegyületeik", "Peszticidek", "Rákkeltő anyagok", "Allergizáló vegyi anyagok", "Mérgező gázok/gőzök", "Egyéb veszélyes anyagok"],
  },
  {
    key: "biologiai", label: "Biológiai kóroki tényezők",
    items: ["Fertőző anyagok", "Allergének (biológiai)", "Élősködők", "Gomba", "Állati fehérjék"],
  },
  {
    key: "ergonomiai", label: "Ergonómiai / pszichoszociális",
    items: ["Kényszerhelyzet", "Ismétlődő mozdulatok", "Nehéz fizikai munka", "Képernyős munkavégzés", "Éjszakai műszak", "Pszichés terhelés"],
  },
];

interface OccupationHistoryItem {
  position: string;
  exposure: string;
  duration_years: string;
}

interface PatientCardFormProps {
  cardForm: Record<string, any>;
  setCardForm: (fn: (prev: any) => any) => void;
  onSave: () => void;
  onCancel: () => void;
  isSaving: boolean;
  profile?: { full_name?: string; taj_number?: string; birth_date?: string; birth_place?: string; mother_name?: string; address?: string; phone?: string; gender?: string } | null;
}

export default function PatientCardForm({ cardForm, setCardForm, onSave, onCancel, isSaving, profile }: PatientCardFormProps) {
  const { t } = useTranslation();
  const [newOccHistory, setNewOccHistory] = useState<OccupationHistoryItem>({ position: "", exposure: "", duration_years: "" });

  const familyHistory = cardForm.family_history ?? {};
  const smoking = cardForm.smoking ?? {};
  const occHistory: OccupationHistoryItem[] = cardForm.occupation_history ?? [];
  const exposures = cardForm.exposures ?? {};

  const setFamilyHistory = (member: string, organ: string, value: boolean) => {
    setCardForm((f: any) => ({
      ...f,
      family_history: {
        ...f.family_history,
        [member]: { ...(f.family_history?.[member] ?? {}), [organ]: value },
      },
    }));
  };

  const addOccHistory = () => {
    if (!newOccHistory.position) return;
    setCardForm((f: any) => ({
      ...f,
      occupation_history: [...(f.occupation_history ?? []), newOccHistory],
    }));
    setNewOccHistory({ position: "", exposure: "", duration_years: "" });
  };

  const removeOccHistory = (idx: number) => {
    setCardForm((f: any) => ({
      ...f,
      occupation_history: (f.occupation_history ?? []).filter((_: any, i: number) => i !== idx),
    }));
  };

  const toggleExposure = (category: string, item: string) => {
    setCardForm((f: any) => {
      const catItems: string[] = f.exposures?.[category] ?? [];
      const newItems = catItems.includes(item) ? catItems.filter((i: string) => i !== item) : [...catItems, item];
      return { ...f, exposures: { ...f.exposures, [category]: newItems } };
    });
  };

  return (
    <div className="space-y-6">
      {/* 1. Személyes adatok — read-only */}
      {profile && (
        <div className="rounded-lg border bg-muted/30 p-4">
          <h3 className="font-semibold mb-2">Személyes adatok</h3>
          <p className="text-xs text-muted-foreground mb-2">A személyes adatok a Profilban módosíthatók.</p>
          <div className="grid gap-2 text-sm md:grid-cols-3">
            <div><span className="text-muted-foreground">Név:</span> {profile.full_name || "—"}</div>
            <div><span className="text-muted-foreground">TAJ:</span> {profile.taj_number || "—"}</div>
            <div><span className="text-muted-foreground">Születési hely:</span> {profile.birth_place || "—"}</div>
            <div><span className="text-muted-foreground">Született:</span> {profile.birth_date ? new Date(profile.birth_date).toLocaleDateString("hu-HU") : "—"}</div>
            <div><span className="text-muted-foreground">Anyja neve:</span> {profile.mother_name || "—"}</div>
            <div><span className="text-muted-foreground">Lakcím:</span> {profile.address || "—"}</div>
            <div><span className="text-muted-foreground">Telefon:</span> {profile.phone || "—"}</div>
            <div><span className="text-muted-foreground">Nem:</span> {profile.gender === "ferfi" ? "Férfi" : profile.gender === "no" ? "Nő" : "—"}</div>
          </div>
        </div>
      )}

      {/* 2. Iskolai/Szakmai végzettség + Értesítési cím */}
      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-1.5"><Label>Iskolai végzettség</Label><Input value={cardForm.education ?? ""} onChange={(e) => setCardForm((f: any) => ({ ...f, education: e.target.value }))} /></div>
        <div className="space-y-1.5"><Label>Szakmai képzettség</Label><Input value={cardForm.professional_qual ?? ""} onChange={(e) => setCardForm((f: any) => ({ ...f, professional_qual: e.target.value }))} /></div>
        <div className="space-y-1.5"><Label>{t("inner.occupationLabel")}</Label><Input value={cardForm.occupation} onChange={(e) => setCardForm((f: any) => ({ ...f, occupation: e.target.value }))} /></div>
        <div className="space-y-1.5"><Label>{t("inner.workplace")}</Label><Input value={cardForm.employer_name} onChange={(e) => setCardForm((f: any) => ({ ...f, employer_name: e.target.value }))} /></div>
        <div className="space-y-1.5"><Label>{t("inner.maritalStatus")}</Label><Input value={cardForm.marital_status} onChange={(e) => setCardForm((f: any) => ({ ...f, marital_status: e.target.value }))} /></div>
        <div className="space-y-1.5"><Label>Értesítési cím</Label><Input value={cardForm.notification_address ?? ""} onChange={(e) => setCardForm((f: any) => ({ ...f, notification_address: e.target.value }))} /></div>
      </div>

      {/* 3. Családi anamnézis mátrix */}
      <div>
        <h3 className="font-semibold mb-2">Családi anamnézis</h3>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-32">Családtag</TableHead>
                {ORGAN_SYSTEMS.map((o) => (<TableHead key={o.key} className="text-center text-xs">{o.label}</TableHead>))}
              </TableRow>
            </TableHeader>
            <TableBody>
              {FAMILY_MEMBERS.map((member) => (
                <TableRow key={member}>
                  <TableCell className="font-medium">{FAMILY_MEMBER_LABELS[member]}</TableCell>
                  {ORGAN_SYSTEMS.map((o) => (
                    <TableCell key={o.key} className="text-center">
                      <Checkbox
                        checked={!!familyHistory[member]?.[o.key]}
                        onCheckedChange={(v) => setFamilyHistory(member, o.key, !!v)}
                      />
                    </TableCell>
                  ))}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>

      {/* 4. Foglalkozási anamnézis */}
      <div>
        <h3 className="font-semibold mb-2">Foglalkozási anamnézis</h3>
        {occHistory.length > 0 && (
          <Table>
            <TableHeader><TableRow><TableHead>Munkakör</TableHead><TableHead>Expozíció</TableHead><TableHead>Időtartam (év)</TableHead><TableHead></TableHead></TableRow></TableHeader>
            <TableBody>
              {occHistory.map((item, idx) => (
                <TableRow key={idx}>
                  <TableCell>{item.position}</TableCell>
                  <TableCell>{item.exposure}</TableCell>
                  <TableCell>{item.duration_years}</TableCell>
                  <TableCell><Button variant="ghost" size="icon" onClick={() => removeOccHistory(idx)}><Trash2 className="h-4 w-4" /></Button></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
        <div className="flex gap-2 mt-2">
          <Input placeholder="Munkakör" value={newOccHistory.position} onChange={(e) => setNewOccHistory((p) => ({ ...p, position: e.target.value }))} />
          <Input placeholder="Expozíció" value={newOccHistory.exposure} onChange={(e) => setNewOccHistory((p) => ({ ...p, exposure: e.target.value }))} />
          <Input placeholder="Év" className="w-20" value={newOccHistory.duration_years} onChange={(e) => setNewOccHistory((p) => ({ ...p, duration_years: e.target.value }))} />
          <Button variant="outline" onClick={addOccHistory}><Plus className="h-4 w-4" /></Button>
        </div>
      </div>

      {/* 5. Életmód */}
      <div>
        <h3 className="font-semibold mb-2">Életmód</h3>
        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-1.5">
            <Label>{t("inner.smokingLabel")}</Label>
            <Select value={smoking.status ?? "nem"} onValueChange={(v) => setCardForm((f: any) => ({ ...f, smoking: { ...f.smoking, status: v } }))}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="nem">{t("inner.smokingNo")}</SelectItem>
                <SelectItem value="igen">{t("inner.smokingYes")}</SelectItem>
                <SelectItem value="leszokott">{t("inner.smokingQuit")}</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {(smoking.status === "igen" || smoking.status === "leszokott") && (
            <>
              <div className="space-y-1.5"><Label>Mennyiség (szál/nap)</Label><Input value={smoking.amount ?? ""} onChange={(e) => setCardForm((f: any) => ({ ...f, smoking: { ...f.smoking, amount: e.target.value } }))} /></div>
              <div className="space-y-1.5"><Label>Mióta / Meddig (év)</Label><Input value={smoking.duration ?? ""} onChange={(e) => setCardForm((f: any) => ({ ...f, smoking: { ...f.smoking, duration: e.target.value } }))} /></div>
            </>
          )}
          <div className="space-y-1.5">
            <Label>{t("inner.alcoholLabel")}</Label>
            <Select value={cardForm.alcohol ?? "nem"} onValueChange={(v) => setCardForm((f: any) => ({ ...f, alcohol: v }))}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="nem">{t("inner.alcoholNo")}</SelectItem>
                <SelectItem value="alkalomszeruen">{t("inner.alcoholOccasional")}</SelectItem>
                <SelectItem value="rendszeresen">{t("inner.alcoholRegular")}</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Sportolás</Label>
            <Select value={cardForm.sports_habit ?? ""} onValueChange={(v) => setCardForm((f: any) => ({ ...f, sports_habit: v }))}>
              <SelectTrigger><SelectValue placeholder="Válasszon" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="rendszeres">Rendszeres</SelectItem>
                <SelectItem value="rendszertelen">Rendszertelen</SelectItem>
                <SelectItem value="nem">Nem sportol</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Étkezési szokás</Label>
            <Select value={cardForm.eating_habit ?? ""} onValueChange={(v) => setCardForm((f: any) => ({ ...f, eating_habit: v }))}>
              <SelectTrigger><SelectValue placeholder="Válasszon" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="korszeru">Korszerű</SelectItem>
                <SelectItem value="korszerutlen">Korszerűtlen</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* 6. Allergiás túlérzékenység */}
      <div className="space-y-1.5">
        <Label>{t("inner.drugAllergyLabel")}</Label>
        <Textarea value={cardForm.drug_allergies} onChange={(e) => setCardForm((f: any) => ({ ...f, drug_allergies: e.target.value }))} rows={2} />
        <MedicationSearch placeholder={t("inner.searchMedAllergy")} onSelect={(name) => setCardForm((f: any) => ({ ...f, drug_allergies: f.drug_allergies ? `${f.drug_allergies}, ${name}` : name }))} />
      </div>

      {/* 7. Bejelentett foglalkozási betegségek */}
      <div className="space-y-1.5">
        <Label>Bejelentett foglalkozási betegségek / fokozott expozíciók</Label>
        <Textarea value={cardForm.reported_occupational_diseases ?? ""} onChange={(e) => setCardForm((f: any) => ({ ...f, reported_occupational_diseases: e.target.value }))} rows={2} />
      </div>

      {/* 8. Előző betegségek, műtétek, balesetek */}
      <div className="space-y-1.5">
        <Label>Előző betegségek, műtétek, balesetek</Label>
        <Textarea value={cardForm.surgeries} onChange={(e) => setCardForm((f: any) => ({ ...f, surgeries: e.target.value }))} rows={2} />
      </div>

      {/* 9. Jelenlegi idült betegségek */}
      <div className="space-y-1.5"><Label>{t("inner.chronicDiseasesLabel")}</Label><Textarea value={cardForm.chronic_diseases} onChange={(e) => setCardForm((f: any) => ({ ...f, chronic_diseases: e.target.value }))} rows={2} /></div>

      {/* 10. Rendszeres gyógyszerszedés */}
      <div className="space-y-1.5">
        <Label>{t("inner.regularMedsLabel")}</Label>
        <Textarea value={cardForm.regular_medications} onChange={(e) => setCardForm((f: any) => ({ ...f, regular_medications: e.target.value }))} rows={2} />
        <MedicationSearch placeholder={t("inner.searchMedAdd")} onSelect={(name) => setCardForm((f: any) => ({ ...f, regular_medications: f.regular_medications ? `${f.regular_medications}, ${name}` : name }))} />
      </div>

      {/* 11-12. Jogosítvány + Katonai szolgálat */}
      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-1.5"><Label>{t("inner.lastChestXray")}</Label><Input type="date" value={cardForm.last_chest_xray} onChange={(e) => setCardForm((f: any) => ({ ...f, last_chest_xray: e.target.value }))} /></div>
        <div className="space-y-1.5"><Label>{t("inner.lastGynecology")}</Label><Input type="date" value={cardForm.last_gynecology} onChange={(e) => setCardForm((f: any) => ({ ...f, last_gynecology: e.target.value }))} /></div>
        <div className="space-y-1.5"><Label>{t("inner.previousDoctor")}</Label><Input value={cardForm.previous_doctor} onChange={(e) => setCardForm((f: any) => ({ ...f, previous_doctor: e.target.value }))} /></div>
      </div>
      <div className="flex gap-6">
        <div className="flex items-center gap-2"><Switch checked={cardForm.drivers_license} onCheckedChange={(v) => setCardForm((f: any) => ({ ...f, drivers_license: v }))} /><Label>{t("inner.hasDriversLicense")}</Label></div>
        <div className="flex items-center gap-2"><Switch checked={cardForm.military_service ?? false} onCheckedChange={(v) => setCardForm((f: any) => ({ ...f, military_service: v }))} /><Label>Katonai szolgálat</Label></div>
      </div>

      {/* 13. Kockázati expozíciók */}
      <div>
        <h3 className="font-semibold mb-2">Kockázati expozíciók</h3>
        <div className="grid gap-4 md:grid-cols-2">
          {EXPOSURE_CATEGORIES.map((cat) => (
            <div key={cat.key} className="rounded-lg border p-3">
              <h4 className="font-medium text-sm mb-2">{cat.label}</h4>
              <div className="space-y-1.5">
                {cat.items.map((item) => (
                  <div key={item} className="flex items-center gap-2">
                    <Checkbox
                      checked={(exposures[cat.key] ?? []).includes(item)}
                      onCheckedChange={() => toggleExposure(cat.key, item)}
                    />
                    <span className="text-sm">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Egyéb megjegyzés */}
      <div className="space-y-1.5"><Label>{t("inner.otherNoteLabel")}</Label><Textarea value={cardForm.other_notes} onChange={(e) => setCardForm((f: any) => ({ ...f, other_notes: e.target.value }))} rows={2} /></div>

      {/* Save / Cancel */}
      <div className="flex gap-2">
        <Button onClick={onSave} disabled={isSaving}><Save className="h-4 w-4 mr-2" />{t("inner.save")}</Button>
        <Button variant="outline" onClick={onCancel}>{t("inner.cancelAction")}</Button>
      </div>
    </div>
  );
}
