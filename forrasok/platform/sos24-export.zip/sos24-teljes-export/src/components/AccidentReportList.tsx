import { useState, useRef } from "react";
import { useTranslation } from "react-i18next";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, FileText, Eye, Printer } from "lucide-react";
import AccidentReportForm from "./AccidentReportForm";
import PrintableAccidentReport from "./PrintableAccidentReport";
import { format } from "date-fns";

interface AccidentReportListProps {
  companyId: string;
  readOnly?: boolean;
}

export default function AccidentReportList({ companyId, readOnly }: AccidentReportListProps) {
  const { t } = useTranslation();
  const [creating, setCreating] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [printingReport, setPrintingReport] = useState<Record<string, any> | null>(null);
  const printRef = useRef<HTMLDivElement>(null);

  const { data: reports, isLoading } = useQuery({
    queryKey: ["accident-reports", companyId],
    queryFn: async () => {
      const { data, error } = await supabase.from("accident_reports" as any).select("*").eq("company_id", companyId).order("created_at", { ascending: false });
      if (error) throw error;
      return data || [];
    },
  });

  const handlePrint = (report: Record<string, any>) => {
    setPrintingReport(report);
    setTimeout(() => {
      window.print();
    }, 500);
  };

  if (creating || editingId) {
    return (
      <div className="space-y-4">
        <Button variant="outline" onClick={() => { setCreating(false); setEditingId(null); }}>
          ← {t("common.back")}
        </Button>
        <AccidentReportForm companyId={companyId} reportId={editingId || undefined} onSaved={() => { setCreating(false); setEditingId(null); }} />
      </div>
    );
  }

  const statusColor = (s: string) => {
    switch (s) {
      case "draft": return "secondary";
      case "submitted": return "default";
      case "reviewed": return "outline";
      default: return "secondary";
    }
  };

  return (
    <>
      <Card className="print:hidden">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            {t("accident.reports")}
          </CardTitle>
          {!readOnly && (
            <Button onClick={() => setCreating(true)}>
              <Plus className="h-4 w-4 mr-1" />{t("accident.newReport")}
            </Button>
          )}
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-8"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>
          ) : !reports?.length ? (
            <p className="text-center py-8 text-muted-foreground">{t("accident.noReports")}</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t("accident.registrationNumber")}</TableHead>
                  <TableHead>{t("accident.injuredName")}</TableHead>
                  <TableHead>{t("accident.accidentDate")}</TableHead>
                  <TableHead>{t("common.status")}</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {reports.map((r: any) => (
                  <TableRow key={r.id}>
                    <TableCell className="font-mono">{r.registration_number || "—"}</TableCell>
                    <TableCell>{r.injured_name || "—"}</TableCell>
                    <TableCell>{r.accident_date ? format(new Date(r.accident_date), "yyyy.MM.dd") : "—"}</TableCell>
                    <TableCell>
                      <Badge variant={statusColor(r.status)}>{t(`accident.status_${r.status}`)}</Badge>
                    </TableCell>
                    <TableCell className="flex gap-1">
                      <Button size="sm" variant="ghost" onClick={() => setEditingId(r.id)}>
                        <Eye className="h-4 w-4 mr-1" />{readOnly ? t("common.view") : t("common.edit")}
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => handlePrint(r)}>
                        <Printer className="h-4 w-4 mr-1" />{t("common.print")}
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Printable area - only visible during print */}
      {printingReport && (
        <div ref={printRef} className="hidden print:block">
          <PrintableAccidentReport report={printingReport} />
        </div>
      )}
    </>
  );
}
