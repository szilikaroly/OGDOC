import { HAZARD_CATEGORIES, getRiskCategory, RISK_CATEGORY_LABELS, HazardCategoryKey } from "@/lib/hazard-catalog";

interface HazardRow {
  hazard_name: string;
  hazard_category: string;
  probability: number;
  severity: number;
  risk_level: number | null;
  current_controls: string | null;
  required_actions: string | null;
  action_responsible: string | null;
  action_deadline: string | null;
  action_hierarchy: string | null;
  exposed_count: number | null;
  residual_probability: number | null;
  residual_severity: number | null;
}

interface PrintableRiskAssessmentProps {
  assessment: {
    title: string;
    company_name: string;
    work_area_name: string;
    site_name: string;
    assessment_date: string;
    assessor_name: string | null;
    assessor_qualification: string | null;
    next_review_date: string | null;
    status: string;
    summary_notes: string | null;
  };
  hazards: HazardRow[];
}

const RISK_COLORS: Record<string, string> = {
  trivial: "#22c55e",
  tolerable: "#eab308",
  moderate: "#f97316",
  substantial: "#ef4444",
  intolerable: "#7f1d1d",
};

export default function PrintableRiskAssessment({ assessment, hazards }: PrintableRiskAssessmentProps) {
  const groupedByCategory = hazards.reduce<Record<string, HazardRow[]>>((acc, h) => {
    const cat = h.hazard_category || "other";
    if (!acc[cat]) acc[cat] = [];
    acc[cat].push(h);
    return acc;
  }, {});

  const d = new Date(assessment.assessment_date);
  const dateStr = d.toLocaleDateString("hu-HU");

  return (
    <div className="hidden print:block print:text-black" style={{ fontFamily: "'Times New Roman', serif", fontSize: "11px", lineHeight: "1.5" }}>
      {/* COVER PAGE */}
      <div style={{ padding: "60px 50px" }}>
        <h1 style={{ textAlign: "center", fontWeight: "bold", fontSize: "18px", marginBottom: 8 }}>
          KOCKÁZATÉRTÉKELÉS
        </h1>
        <h2 style={{ textAlign: "center", fontSize: "14px", marginBottom: 30 }}>
          ISO 45001 szerinti munkavédelmi kockázatértékelés
        </h2>

        <table style={{ width: "100%", borderCollapse: "collapse", marginBottom: 30 }}>
          <tbody>
            {[
              ["Cég:", assessment.company_name],
              ["Telephely:", assessment.site_name],
              ["Munkaterület:", assessment.work_area_name],
              ["Értékelés címe:", assessment.title],
              ["Dátum:", dateStr],
              ["Értékelő:", assessment.assessor_name || ""],
              ["Végzettség:", assessment.assessor_qualification || ""],
              ["Következő felülvizsgálat:", assessment.next_review_date ? new Date(assessment.next_review_date).toLocaleDateString("hu-HU") : "—"],
              ["Státusz:", assessment.status === "approved" ? "Jóváhagyott" : assessment.status === "draft" ? "Tervezet" : assessment.status],
            ].map(([label, value], i) => (
              <tr key={i}>
                <td style={{ padding: "4px 8px", fontWeight: "bold", width: "35%", borderBottom: "1px solid #ccc" }}>{label}</td>
                <td style={{ padding: "4px 8px", borderBottom: "1px solid #ccc" }}>{value}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <div style={{ marginTop: 20 }}>
          <p style={{ fontWeight: "bold", marginBottom: 4 }}>Összefoglalás:</p>
          <p>{assessment.summary_notes || "—"}</p>
        </div>

        <div style={{ marginTop: 40 }}>
          <p style={{ fontWeight: "bold" }}>Statisztika:</p>
          <p>Azonosított veszélyforrások: {hazards.length}</p>
          <p>Intézkedést igénylő (≥6): {hazards.filter(h => (h.probability * h.severity) >= 6).length}</p>
        </div>
      </div>

      {/* HAZARD TABLE */}
      <div style={{ pageBreakBefore: "always", padding: "40px 30px" }}>
        <h2 style={{ textAlign: "center", fontWeight: "bold", fontSize: "14px", marginBottom: 12 }}>
          Veszélyazonosítás és kockázatértékelés
        </h2>

        {Object.entries(groupedByCategory).map(([cat, items]) => {
          const catInfo = HAZARD_CATEGORIES[cat as HazardCategoryKey];
          return (
            <div key={cat} style={{ marginBottom: 16 }}>
              <h3 style={{ fontWeight: "bold", fontSize: "12px", marginBottom: 4, borderBottom: "1px solid #000", paddingBottom: 2 }}>
                {catInfo?.hu ?? cat}
              </h3>
              <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "9px", marginBottom: 8 }}>
                <thead>
                  <tr style={{ backgroundColor: "#f3f4f6" }}>
                    <th style={{ border: "1px solid #000", padding: "3px 4px", textAlign: "left" }}>Veszélyforrás</th>
                    <th style={{ border: "1px solid #000", padding: "3px 4px", width: 30, textAlign: "center" }}>P</th>
                    <th style={{ border: "1px solid #000", padding: "3px 4px", width: 30, textAlign: "center" }}>S</th>
                    <th style={{ border: "1px solid #000", padding: "3px 4px", width: 35, textAlign: "center" }}>R</th>
                    <th style={{ border: "1px solid #000", padding: "3px 4px", width: 60, textAlign: "center" }}>Kategória</th>
                    <th style={{ border: "1px solid #000", padding: "3px 4px", width: 40, textAlign: "center" }}>Fő</th>
                    <th style={{ border: "1px solid #000", padding: "3px 4px" }}>Jelenlegi védekezés</th>
                    <th style={{ border: "1px solid #000", padding: "3px 4px" }}>Intézkedés</th>
                    <th style={{ border: "1px solid #000", padding: "3px 4px", width: 60 }}>Felelős</th>
                    <th style={{ border: "1px solid #000", padding: "3px 4px", width: 50 }}>Határidő</th>
                    <th style={{ border: "1px solid #000", padding: "3px 4px", width: 30, textAlign: "center" }}>MK</th>
                  </tr>
                </thead>
                <tbody>
                  {items.map((h, i) => {
                    const risk = h.probability * h.severity;
                    const rCat = getRiskCategory(h.probability, h.severity);
                    const residual = (h.residual_probability ?? 1) * (h.residual_severity ?? 1);
                    return (
                      <tr key={i}>
                        <td style={{ border: "1px solid #000", padding: "2px 4px" }}>{h.hazard_name}</td>
                        <td style={{ border: "1px solid #000", padding: "2px 4px", textAlign: "center" }}>{h.probability}</td>
                        <td style={{ border: "1px solid #000", padding: "2px 4px", textAlign: "center" }}>{h.severity}</td>
                        <td style={{ border: "1px solid #000", padding: "2px 4px", textAlign: "center", fontWeight: "bold", color: RISK_COLORS[rCat] }}>{risk}</td>
                        <td style={{ border: "1px solid #000", padding: "2px 4px", textAlign: "center", fontSize: "8px" }}>{RISK_CATEGORY_LABELS[rCat]?.hu}</td>
                        <td style={{ border: "1px solid #000", padding: "2px 4px", textAlign: "center" }}>{h.exposed_count ?? ""}</td>
                        <td style={{ border: "1px solid #000", padding: "2px 4px", fontSize: "8px" }}>{h.current_controls ?? ""}</td>
                        <td style={{ border: "1px solid #000", padding: "2px 4px", fontSize: "8px" }}>{h.required_actions ?? ""}</td>
                        <td style={{ border: "1px solid #000", padding: "2px 4px", fontSize: "8px" }}>{h.action_responsible ?? ""}</td>
                        <td style={{ border: "1px solid #000", padding: "2px 4px", fontSize: "8px" }}>{h.action_deadline ? new Date(h.action_deadline).toLocaleDateString("hu-HU") : ""}</td>
                        <td style={{ border: "1px solid #000", padding: "2px 4px", textAlign: "center" }}>{residual}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          );
        })}

        {/* Risk matrix legend */}
        <div style={{ marginTop: 20, fontSize: "9px" }}>
          <p style={{ fontWeight: "bold", marginBottom: 4 }}>Jelmagyarázat: P = Valószínűség, S = Súlyosság, R = Kockázati szint (P×S), MK = Maradék kockázat</p>
          <p>1-2: Triviális (elfogadható) | 3-4: Tolerálható | 5-6: Mérsékelt | 8-9: Jelentős | 12-16: Elviselhetetlen</p>
        </div>

        {/* Signature block */}
        <div style={{ marginTop: 60, display: "flex", justifyContent: "space-between" }}>
          <div>
            <div style={{ borderBottom: "1px dotted #000", width: 200, marginBottom: 4 }}>&nbsp;</div>
            <div style={{ fontSize: "9px" }}>Értékelő aláírása</div>
          </div>
          <div>
            <div style={{ borderBottom: "1px dotted #000", width: 200, marginBottom: 4 }}>&nbsp;</div>
            <div style={{ fontSize: "9px" }}>Jóváhagyó aláírása</div>
          </div>
        </div>
      </div>
    </div>
  );
}
