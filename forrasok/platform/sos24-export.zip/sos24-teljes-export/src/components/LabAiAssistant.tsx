import { useState } from "react";
import { LAB_TEST_CATALOG, type LabTest } from "@/lib/labTestCatalog";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Sparkles, Loader2, Plus, AlertTriangle, ListOrdered } from "lucide-react";

interface Recommendation {
  test_id: string;
  reason: string;
  priority: "alap" | "kiegészítő" | "célzott";
}
interface AiResult {
  summary: string;
  recommendations: Recommendation[];
  disclaimer: string;
}

interface Props {
  onAddToCart: (testIds: string[]) => void;
  cart: Set<string>;
  getPrice: (t: LabTest) => number;
}

const PRIORITY_ORDER: Record<Recommendation["priority"], number> = {
  alap: 0,
  célzott: 1,
  kiegészítő: 2,
};

export default function LabAiAssistant({ onAddToCart, cart, getPrice }: Props) {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [symptoms, setSymptoms] = useState("");
  const [mode, setMode] = useState<"suggest" | "order">("suggest");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<AiResult | null>(null);
  const [selected, setSelected] = useState<Set<string>>(new Set());

  const ask = async () => {
    if (symptoms.trim().length < 5) {
      toast({ title: "Kérjük írja le részletesebben a panaszt", variant: "destructive" });
      return;
    }
    setLoading(true);
    setResult(null);
    setSelected(new Set());
    try {
      const compactCatalog = LAB_TEST_CATALOG
        .filter((t) => t.status === "active")
        .map((t) => ({ id: t.id, name: t.name, shortName: t.shortName, specialty: t.specialty, sampleType: t.sampleType }));

      const { data, error } = await supabase.functions.invoke("ai-lab-recommend", {
        body: { symptoms, mode, catalog: compactCatalog },
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      const r = data as AiResult;
      if (!r.recommendations?.length) {
        toast({ title: "Az AI nem talált megfelelő vizsgálatot", description: "Próbálja meg részletesebben leírni a panaszt." });
      } else {
        // Pre-select all suggested
        setSelected(new Set(r.recommendations.map((x) => x.test_id)));
      }
      setResult(r);
    } catch (err: any) {
      toast({ title: "Hiba", description: err?.message ?? "Ismeretlen hiba", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const toggleSelect = (id: string) => {
    setSelected((prev) => {
      const s = new Set(prev);
      s.has(id) ? s.delete(id) : s.add(id);
      return s;
    });
  };

  const confirmAdd = () => {
    if (selected.size === 0) return;
    onAddToCart(Array.from(selected));
    toast({ title: `${selected.size} javasolt vizsgálat hozzáadva a kosárhoz` });
    setOpen(false);
    setResult(null);
    setSymptoms("");
  };

  const ordered = result
    ? [...result.recommendations].sort((a, b) => PRIORITY_ORDER[a.priority] - PRIORITY_ORDER[b.priority])
    : [];

  if (!open) {
    return (
      <Card className="border-primary/30 bg-gradient-to-br from-primary/5 to-transparent">
        <CardContent className="py-4 flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
              <Sparkles className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-sm font-semibold text-foreground">AI laborjavasló</p>
              <p className="text-xs text-muted-foreground">Írja le a panaszát vagy kérdését — a rendszer javaslatot tesz a megfelelő laborvizsgálatokra.</p>
            </div>
          </div>
          <Button size="sm" onClick={() => setOpen(true)} className="gap-1.5">
            <Sparkles className="w-3.5 h-3.5" /> Indítás
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-primary/40">
      <CardContent className="py-4 space-y-3">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-primary" />
          <p className="text-sm font-semibold">AI laborjavasló</p>
          <Button size="sm" variant="ghost" className="ml-auto h-7 text-xs" onClick={() => { setOpen(false); setResult(null); }}>
            Bezár
          </Button>
        </div>

        <Textarea
          value={symptoms}
          onChange={(e) => setSymptoms(e.target.value)}
          placeholder="Pl. Fáradtság, hajhullás, gyakori felfázás… vagy: Szeretnék egy átfogó éves szűrést 45 éves férfiként."
          rows={3}
          disabled={loading}
        />

        <RadioGroup value={mode} onValueChange={(v) => setMode(v as "suggest" | "order")} className="flex gap-4 text-sm">
          <div className="flex items-center gap-1.5">
            <RadioGroupItem value="suggest" id="mode-suggest" />
            <Label htmlFor="mode-suggest" className="text-xs cursor-pointer">Vizsgálatokat javasol</Label>
          </div>
          <div className="flex items-center gap-1.5">
            <RadioGroupItem value="order" id="mode-order" />
            <Label htmlFor="mode-order" className="text-xs cursor-pointer flex items-center gap-1"><ListOrdered className="w-3 h-3" /> Sorrendet is javasol</Label>
          </div>
        </RadioGroup>

        <Button onClick={ask} disabled={loading} className="w-full gap-2" size="sm">
          {loading ? <><Loader2 className="w-4 h-4 animate-spin" /> Elemzés…</> : <><Sparkles className="w-4 h-4" /> Javaslat kérése</>}
        </Button>

        {result && (
          <div className="space-y-3 pt-2 border-t">
            <div className="text-xs bg-muted/40 rounded-lg p-3 space-y-2">
              <p className="font-medium text-foreground">{result.summary}</p>
              {result.disclaimer && (
                <p className="flex items-start gap-1.5 text-muted-foreground">
                  <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5 text-primary" />
                  <span>{result.disclaimer}</span>
                </p>
              )}
            </div>

            {ordered.length > 0 && (
              <>
                <div className="flex items-center justify-between">
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                    {mode === "order" ? "Javasolt sorrend" : "Javasolt vizsgálatok"} ({ordered.length})
                  </p>
                  <Badge variant="secondary" className="text-[10px]">{selected.size} kiválasztva</Badge>
                </div>
                <ScrollArea className="h-64 border rounded-lg">
                  <div className="p-2 space-y-1">
                    {ordered.map((rec, idx) => {
                      const test = LAB_TEST_CATALOG.find((t) => t.id === rec.test_id);
                      if (!test) return null;
                      const isSelected = selected.has(rec.test_id);
                      const inCart = cart.has(rec.test_id);
                      return (
                        <div
                          key={rec.test_id}
                          onClick={() => toggleSelect(rec.test_id)}
                          className={`flex items-start gap-2 p-2 rounded-lg cursor-pointer transition-colors ${
                            isSelected ? "bg-primary/10 border border-primary/30" : "hover:bg-muted/40 border border-transparent"
                          }`}
                        >
                          {mode === "order" && (
                            <span className="text-xs font-bold text-primary w-5 shrink-0 mt-0.5">{idx + 1}.</span>
                          )}
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-sm font-medium">{test.name}</span>
                              <Badge variant="outline" className="text-[9px] px-1 py-0 h-4">{rec.priority}</Badge>
                              {inCart && <Badge className="text-[9px] px-1 py-0 h-4 bg-primary/20 text-primary">kosárban</Badge>}
                            </div>
                            <p className="text-[11px] text-muted-foreground mt-0.5">{rec.reason}</p>
                          </div>
                          <span className="text-xs font-semibold whitespace-nowrap">{getPrice(test).toLocaleString("hu-HU")} Ft</span>
                        </div>
                      );
                    })}
                  </div>
                </ScrollArea>
                <Button onClick={confirmAdd} disabled={selected.size === 0} className="w-full gap-2" size="sm">
                  <Plus className="w-4 h-4" /> Kiválasztottak hozzáadása a kosárhoz ({selected.size})
                </Button>
              </>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
