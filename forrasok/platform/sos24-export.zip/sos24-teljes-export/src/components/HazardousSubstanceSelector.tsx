import { useState, useMemo } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Search, Plus, X, FlaskConical } from "lucide-react";
import { toast } from "sonner";

interface HazardousSubstanceSelectorProps {
  companyId: string;
  readOnly?: boolean;
}

interface Substance {
  id: string;
  name: string;
  ec_number: string;
  cas_number: string;
  reason_for_inclusion: string;
  source: string;
}

interface CompanySubstance {
  id: string;
  company_id: string;
  substance_id: string;
  usage_description: string;
  annual_quantity: string;
  exposure_type: string;
  ppe_required: string;
  substance?: Substance;
}

export default function HazardousSubstanceSelector({ companyId, readOnly = false }: HazardousSubstanceSelectorProps) {
  const { t } = useTranslation();
  const qc = useQueryClient();
  const [searchQuery, setSearchQuery] = useState("");

  const { data: allSubstances } = useQuery({
    queryKey: ["hazardous-substances"],
    queryFn: async () => {
      const allRows: Substance[] = [];
      const BATCH = 1000;
      let from = 0;
      while (true) {
        const { data, error } = await (supabase as any)
          .from("hazardous_substances")
          .select("id, name, ec_number, cas_number, reason_for_inclusion, source")
          .eq("is_active", true)
          .order("name")
          .range(from, from + BATCH - 1);
        if (error) throw error;
        allRows.push(...(data as Substance[]));
        if (!data || data.length < BATCH) break;
        from += BATCH;
      }
      return allRows;
    },
  });

  const { data: companySubstances, isLoading } = useQuery({
    queryKey: ["company-hazardous-substances", companyId],
    queryFn: async () => {
      const { data, error } = await (supabase as any)
        .from("company_hazardous_substances")
        .select("id, company_id, substance_id, usage_description, annual_quantity, exposure_type, ppe_required")
        .eq("company_id", companyId);
      if (error) throw error;
      // Join with substances
      const substanceIds = (data as any[]).map((cs: any) => cs.substance_id);
      const { data: subs } = await (supabase as any)
        .from("hazardous_substances")
        .select("id, name, ec_number, cas_number, reason_for_inclusion, source")
        .in("id", substanceIds.length > 0 ? substanceIds : ["00000000-0000-0000-0000-000000000000"]);
      return (data as any[]).map((cs: any) => ({
        ...cs,
        substance: (subs ?? []).find((s: any) => s.id === cs.substance_id),
      })) as CompanySubstance[];
    },
    enabled: !!companyId,
  });

  const addMut = useMutation({
    mutationFn: async (substanceId: string) => {
      const { error } = await (supabase as any)
        .from("company_hazardous_substances")
        .insert({ company_id: companyId, substance_id: substanceId });
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["company-hazardous-substances", companyId] });
      toast.success(t("substances.added"));
    },
    onError: (e: any) => toast.error(e.message),
  });

  const removeMut = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await (supabase as any)
        .from("company_hazardous_substances")
        .delete()
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["company-hazardous-substances", companyId] });
      toast.success(t("substances.removed"));
    },
    onError: (e: any) => toast.error(e.message),
  });

  const assignedIds = useMemo(() => new Set((companySubstances ?? []).map(cs => cs.substance_id)), [companySubstances]);

  const filteredSubstances = useMemo(() => {
    if (!searchQuery.trim() || !allSubstances) return [];
    const q = searchQuery.toLowerCase();
    return allSubstances
      .filter(s => !assignedIds.has(s.id))
      .filter(s =>
        s.name?.toLowerCase().includes(q) ||
        s.cas_number?.toLowerCase().includes(q) ||
        s.ec_number?.toLowerCase().includes(q)
      )
      .slice(0, 20);
  }, [searchQuery, allSubstances, assignedIds]);

  const getReasonBadges = (reason: string) => {
    if (!reason) return null;
    return reason.split("#").map((r, i) => {
      const short = r.includes("Carcinogenic") ? "CMR" :
        r.includes("Mutagenic") ? "MUT" :
        r.includes("Toxic for reproduction") ? "REP" :
        r.includes("PBT") ? "PBT" :
        r.includes("vPvB") ? "vPvB" :
        r.includes("Endocrine") ? "ED" :
        r.includes("Respiratory") ? "RESP" :
        r.includes("Equivalent") ? "ELoC" : r.substring(0, 10);
      const variant = short === "CMR" || short === "MUT" ? "destructive" : "outline";
      return <Badge key={i} variant={variant as any} className="text-[9px] mr-0.5">{short}</Badge>;
    });
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <FlaskConical className="h-4 w-4" />
          {t("substances.title")}
          <Badge variant="secondary" className="ml-auto">{companySubstances?.length ?? 0}</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {/* Search to add */}
        {!readOnly && (
          <div className="space-y-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t("substances.searchPlaceholder")}
                className="pl-9 text-sm"
              />
            </div>
            {filteredSubstances.length > 0 && (
              <ScrollArea className="max-h-48 border rounded-md">
                <div className="p-1">
                  {filteredSubstances.map(s => (
                    <button
                      key={s.id}
                      className="flex items-center justify-between w-full text-left px-2 py-1.5 text-sm hover:bg-muted/50 rounded"
                      onClick={() => { addMut.mutate(s.id); setSearchQuery(""); }}
                    >
                      <div className="flex-1 min-w-0">
                        <span className="font-medium truncate block">{s.name}</span>
                        <span className="text-xs text-muted-foreground">
                          {s.cas_number && `CAS: ${s.cas_number}`}
                          {s.ec_number && ` · EC: ${s.ec_number}`}
                        </span>
                      </div>
                      <Plus className="h-3.5 w-3.5 shrink-0 ml-2 text-muted-foreground" />
                    </button>
                  ))}
                </div>
              </ScrollArea>
            )}
          </div>
        )}

        {/* Assigned substances */}
        {(companySubstances ?? []).length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-4">{t("substances.none")}</p>
        ) : (
          <ScrollArea className="max-h-64">
            <div className="space-y-1">
              {(companySubstances ?? []).map(cs => (
                <div key={cs.id} className="flex items-center gap-2 px-2 py-1.5 border rounded text-sm group">
                  <div className="flex-1 min-w-0">
                    <span className="font-medium block truncate">{cs.substance?.name ?? "?"}</span>
                    <div className="flex items-center gap-1 flex-wrap">
                      {cs.substance?.cas_number && (
                        <span className="text-xs text-muted-foreground">CAS: {cs.substance.cas_number}</span>
                      )}
                      {cs.substance?.reason_for_inclusion && getReasonBadges(cs.substance.reason_for_inclusion)}
                    </div>
                  </div>
                  {!readOnly && (
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-6 w-6 opacity-0 group-hover:opacity-100"
                      onClick={() => removeMut.mutate(cs.id)}
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  );
}
