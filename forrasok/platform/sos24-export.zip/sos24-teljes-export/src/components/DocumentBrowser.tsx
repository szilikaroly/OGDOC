import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Download, FileText, Eye, Printer } from "lucide-react";
import { toast } from "sonner";
import { useTranslation } from "react-i18next";

interface DocumentBrowserProps {
  userId?: string;
  title?: string;
  showPatient?: boolean;
}

export default function DocumentBrowser({ userId, title, showPatient = false }: DocumentBrowserProps) {
  const { user } = useAuth();
  const { t, i18n } = useTranslation();
  const [viewUrl, setViewUrl] = useState<string | null>(null);
  const [viewName, setViewName] = useState("");

  const DOC_TYPE_LABELS: Record<string, string> = {
    opinion: t("documents.opinion"),
    examination: t("documents.examination"),
    referral: t("documents.referral"),
    certificate: t("documents.certificate"),
    upload: t("documents.upload"),
  };

  const displayTitle = title ?? t("dashboard.documents");

  const { data: documents, isLoading } = useQuery({
    queryKey: ["documents", userId ?? user?.id],
    queryFn: async () => {
      let query = supabase
        .from("documents")
        .select("*")
        .order("created_at", { ascending: false });

      if (userId) {
        query = query.eq("user_id", userId);
      }

      const { data, error } = await query;
      if (error) throw error;

      if (showPatient && data.length > 0) {
        const userIds = [...new Set(data.map((d: any) => d.user_id))];
        const { data: profiles } = await supabase
          .from("profiles")
          .select("user_id, full_name")
          .in("user_id", userIds);
        const nameMap = Object.fromEntries(
          (profiles ?? []).map((p) => [p.user_id, p.full_name])
        );
        return data.map((d: any) => ({ ...d, patient_name: nameMap[d.user_id] ?? "—" }));
      }

      return data;
    },
    enabled: !!user,
  });

  const handleDownload = async (doc: any) => {
    try {
      const { data, error } = await supabase.storage
        .from("medical-documents")
        .download(doc.file_path);
      if (error) throw error;
      const url = URL.createObjectURL(data);
      const a = document.createElement("a");
      a.href = url;
      a.download = doc.file_name;
      a.click();
      URL.revokeObjectURL(url);
    } catch (e: any) {
      toast.error(`${t("documents.downloadError")}: ${e.message}`);
    }
  };

  const handleView = async (doc: any) => {
    try {
      const { data, error } = await supabase.storage
        .from("medical-documents")
        .download(doc.file_path);
      if (error) throw error;
      const url = URL.createObjectURL(data);
      setViewUrl(url);
      setViewName(doc.file_name);
    } catch (e: any) {
      toast.error(`${t("documents.openError")}: ${e.message}`);
    }
  };

  const handlePrint = () => {
    if (!viewUrl) return;
    const printWindow = window.open(viewUrl, "_blank");
    if (printWindow) {
      printWindow.addEventListener("load", () => {
        printWindow.print();
      });
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" />
      </div>
    );
  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <FileText className="h-5 w-5 text-secondary" />
            {displayTitle} ({documents?.length ?? 0})
          </CardTitle>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                {showPatient && <TableHead>{t("documents.patient")}</TableHead>}
                <TableHead>{t("documents.type")}</TableHead>
                <TableHead>{t("documents.fileName")}</TableHead>
                <TableHead>{t("documents.date")}</TableHead>
                <TableHead>{t("documents.action")}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {(documents ?? []).map((doc: any) => (
                <TableRow key={doc.id}>
                  {showPatient && <TableCell className="font-medium">{doc.patient_name ?? "—"}</TableCell>}
                  <TableCell>
                    <Badge variant="secondary">
                      {DOC_TYPE_LABELS[doc.document_type] ?? doc.document_type}
                    </Badge>
                  </TableCell>
                  <TableCell className="max-w-[200px] truncate">{doc.file_name}</TableCell>
                  <TableCell>{new Date(doc.created_at).toLocaleDateString(i18n.language === "hu" ? "hu-HU" : undefined)}</TableCell>
                  <TableCell className="space-x-1">
                    <Button size="sm" variant="outline" onClick={() => handleView(doc)}>
                      <Eye className="h-4 w-4 mr-1" />{t("documents.open")}
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => handleDownload(doc)}>
                      <Download className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
              {(documents ?? []).length === 0 && (
                <TableRow>
                  <TableCell colSpan={showPatient ? 5 : 4} className="text-center text-muted-foreground py-8">
                    {t("documents.noDocuments")}
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Document viewer dialog with print support */}
      <Dialog open={!!viewUrl} onOpenChange={(open) => { if (!open) { if (viewUrl) URL.revokeObjectURL(viewUrl); setViewUrl(null); } }}>
        <DialogContent className="max-w-4xl h-[85vh] flex flex-col">
          <DialogHeader className="flex-shrink-0">
            <DialogTitle className="flex items-center justify-between">
              <span className="truncate mr-4">{viewName}</span>
              <Button size="sm" variant="outline" onClick={handlePrint}>
                <Printer className="h-4 w-4 mr-1" /> {t("documents.print")}
              </Button>
            </DialogTitle>
          </DialogHeader>
          <div className="flex-1 min-h-0">
            {viewUrl && (
              <iframe
                src={viewUrl}
                className="w-full h-full rounded-md border"
                title={viewName}
              />
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}