import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { LAB_TEST_CATALOG, SPECIALTIES, type LabTest } from '@/lib/labTestCatalog';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { Package, Plus, Pencil, Trash2, Search, GripVertical, CheckCircle } from 'lucide-react';

interface LabPackage {
  id: string;
  name: string;
  description: string | null;
  target_audience: string | null;
  icon: string;
  test_ids: string[];
  is_active: boolean;
  display_order: number;
}

export default function LabPackageEditor() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [editing, setEditing] = useState<LabPackage | null>(null);
  const [showDialog, setShowDialog] = useState(false);

  const { data: packages, isLoading } = useQuery({
    queryKey: ['lab-packages-admin'],
    queryFn: async () => {
      const { data, error } = await (supabase as any)
        .from('lab_packages')
        .select('*')
        .order('display_order', { ascending: true });
      if (error) throw error;
      return data as LabPackage[];
    },
  });

  const upsert = useMutation({
    mutationFn: async (pkg: Partial<LabPackage> & { id?: string }) => {
      if (pkg.id) {
        const { error } = await (supabase as any).from('lab_packages').update(pkg).eq('id', pkg.id);
        if (error) throw error;
      } else {
        const { error } = await (supabase as any).from('lab_packages').insert(pkg);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['lab-packages-admin'] });
      qc.invalidateQueries({ queryKey: ['lab-packages'] });
      setShowDialog(false);
      setEditing(null);
      toast({ title: 'Csomag mentve' });
    },
    onError: (err: any) => toast({ title: 'Hiba', description: err.message, variant: 'destructive' }),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await (supabase as any).from('lab_packages').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['lab-packages-admin'] });
      qc.invalidateQueries({ queryKey: ['lab-packages'] });
      toast({ title: 'Csomag törölve' });
    },
  });

  const openNew = () => {
    setEditing({ id: '', name: '', description: '', target_audience: '', icon: '📦', test_ids: [], is_active: true, display_order: (packages?.length ?? 0) + 1 });
    setShowDialog(true);
  };

  const openEdit = (pkg: LabPackage) => {
    setEditing({ ...pkg });
    setShowDialog(true);
  };

  const getTestCount = (ids: string[]) => ids.filter(id => LAB_TEST_CATALOG.some(t => t.id === id)).length;

  if (isLoading) return <div className="flex justify-center py-8"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">{(packages ?? []).length} csomag</p>
        <Button onClick={openNew} size="sm" className="gap-1.5"><Plus className="w-4 h-4" /> Új csomag</Button>
      </div>

      <div className="grid gap-3">
        {(packages ?? []).map(pkg => (
          <Card key={pkg.id} className={`${!pkg.is_active ? 'opacity-50' : ''}`}>
            <CardContent className="flex items-center gap-4 py-4">
              <span className="text-2xl">{pkg.icon}</span>
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-sm">{pkg.name}</div>
                {pkg.description && <p className="text-xs text-muted-foreground truncate">{pkg.description}</p>}
                <div className="flex gap-2 mt-1">
                  <Badge variant="secondary" className="text-xs">{getTestCount(pkg.test_ids)} vizsgálat</Badge>
                  {!pkg.is_active && <Badge variant="outline" className="text-xs">Inaktív</Badge>}
                </div>
              </div>
              <div className="flex gap-1">
                <Button size="sm" variant="ghost" onClick={() => openEdit(pkg)}><Pencil className="w-4 h-4" /></Button>
                <Button size="sm" variant="ghost" onClick={() => { if (confirm('Biztosan törli?')) remove.mutate(pkg.id); }}><Trash2 className="w-4 h-4 text-destructive" /></Button>
              </div>
            </CardContent>
          </Card>
        ))}
        {(packages ?? []).length === 0 && (
          <p className="text-center text-muted-foreground py-8 text-sm">Még nincs csomag. Kattintson az "Új csomag" gombra!</p>
        )}
      </div>

      <Dialog open={showDialog} onOpenChange={v => { if (!v) { setShowDialog(false); setEditing(null); } }}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing?.id ? 'Csomag szerkesztése' : 'Új csomag létrehozása'}</DialogTitle>
          </DialogHeader>
          {editing && <PackageForm pkg={editing} onChange={setEditing} onSave={() => {
            if (!editing.name) { toast({ title: 'Név megadása kötelező', variant: 'destructive' }); return; }
            if (editing.test_ids.length === 0) { toast({ title: 'Legalább egy vizsgálat szükséges', variant: 'destructive' }); return; }
            const payload: any = { name: editing.name, description: editing.description || null, target_audience: editing.target_audience || null, icon: editing.icon, test_ids: editing.test_ids, is_active: editing.is_active, display_order: editing.display_order };
            if (editing.id) payload.id = editing.id;
            upsert.mutate(payload);
          }} saving={upsert.isPending} />}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function PackageForm({ pkg, onChange, onSave, saving }: { pkg: LabPackage; onChange: (p: LabPackage) => void; onSave: () => void; saving: boolean }) {
  const [search, setSearch] = useState('');
  const [filterSpec, setFilterSpec] = useState('all');

  const filtered = LAB_TEST_CATALOG.filter(t => {
    if (t.status !== 'active') return false;
    const q = search.toLowerCase();
    const matchSearch = !q || t.name.toLowerCase().includes(q) || t.shortName.toLowerCase().includes(q);
    const matchSpec = filterSpec === 'all' || t.specialty === filterSpec;
    return matchSearch && matchSpec;
  });

  const grouped: Record<string, LabTest[]> = {};
  filtered.forEach(t => { if (!grouped[t.specialty]) grouped[t.specialty] = []; grouped[t.specialty].push(t); });

  const toggle = (id: string) => {
    const ids = new Set(pkg.test_ids);
    ids.has(id) ? ids.delete(id) : ids.add(id);
    onChange({ ...pkg, test_ids: [...ids] });
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-1.5">
          <Label>Csomag neve *</Label>
          <Input value={pkg.name} onChange={e => onChange({ ...pkg, name: e.target.value })} placeholder="pl. Alapszűrés csomag" />
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div className="space-y-1.5">
            <Label>Ikon</Label>
            <Input value={pkg.icon} onChange={e => onChange({ ...pkg, icon: e.target.value })} placeholder="📦" maxLength={4} />
          </div>
          <div className="space-y-1.5">
            <Label>Sorrend</Label>
            <Input type="number" value={pkg.display_order} onChange={e => onChange({ ...pkg, display_order: parseInt(e.target.value) || 0 })} />
          </div>
        </div>
      </div>
      <div className="space-y-1.5">
        <Label>Leírás</Label>
        <Textarea value={pkg.description ?? ''} onChange={e => onChange({ ...pkg, description: e.target.value })} rows={2} placeholder="Rövid leírás a csomagról…" />
      </div>
      <div className="space-y-1.5">
        <Label>Kinek ajánljuk?</Label>
        <Textarea value={pkg.target_audience ?? ''} onChange={e => onChange({ ...pkg, target_audience: e.target.value })} rows={2} placeholder="pl. 40 év fölötti férfiaknak, családtervezés előtt álló nőknek…" />
      </div>
      <div className="flex items-center gap-2">
        <Switch checked={pkg.is_active} onCheckedChange={v => onChange({ ...pkg, is_active: v })} />
        <Label>Aktív</Label>
      </div>

      <div className="border-t pt-4">
        <div className="flex items-center justify-between mb-3">
          <Label className="text-sm font-semibold">Vizsgálatok kiválasztása</Label>
          <Badge variant="secondary">{pkg.test_ids.length} kiválasztva</Badge>
        </div>
        <div className="flex gap-2 mb-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Keresés…" className="pl-9 text-sm" />
          </div>
          <select value={filterSpec} onChange={e => setFilterSpec(e.target.value)} className="border rounded px-2 text-sm bg-background">
            <option value="all">Összes</option>
            {SPECIALTIES.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
        <ScrollArea className="h-64 border rounded-lg">
          <div className="p-2 space-y-0.5">
            {Object.entries(grouped).map(([spec, tests]) => (
              <div key={spec}>
                <div className="text-[10px] font-bold uppercase text-muted-foreground px-2 py-1 bg-muted/50 rounded">{spec}</div>
                {tests.map(t => {
                  const selected = pkg.test_ids.includes(t.id);
                  return (
                    <div key={t.id} onClick={() => toggle(t.id)} className={`flex items-center gap-2 px-2 py-1.5 rounded cursor-pointer text-sm ${selected ? 'bg-primary/10' : 'hover:bg-muted/40'}`}>
                      {selected ? <CheckCircle className="w-4 h-4 text-primary shrink-0" /> : <div className="w-4 h-4 border rounded shrink-0" />}
                      <span className="flex-1">{t.name}</span>
                      <span className="text-xs text-muted-foreground">{t.sampleType}</span>
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        </ScrollArea>
      </div>

      <Button onClick={onSave} disabled={saving} className="w-full">
        {saving ? 'Mentés…' : 'Csomag mentése'}
      </Button>
    </div>
  );
}
