import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Cookie } from "lucide-react";
import { useTranslation } from "react-i18next";

export default function CookieBanner() {
  const [visible, setVisible] = useState(false);
  const { t } = useTranslation();

  useEffect(() => {
    const consent = localStorage.getItem("cookie_consent");
    if (!consent) setVisible(true);
  }, []);

  const accept = () => {
    localStorage.setItem("cookie_consent", "accepted");
    setVisible(false);
  };

  const decline = () => {
    localStorage.setItem("cookie_consent", "declined");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-card border-t shadow-lg p-4 md:p-6">
      <div className="max-w-5xl mx-auto flex flex-col sm:flex-row items-center gap-4">
        <Cookie className="h-6 w-6 text-secondary flex-shrink-0" />
        <p className="text-sm text-muted-foreground flex-1">
          {t('cookie.message')}
        </p>
        <div className="flex gap-2 flex-shrink-0">
          <Button variant="outline" size="sm" onClick={decline}>
            {t('cookie.decline')}
          </Button>
          <Button size="sm" onClick={accept}>
            {t('cookie.accept')}
          </Button>
        </div>
      </div>
    </div>
  );
}
