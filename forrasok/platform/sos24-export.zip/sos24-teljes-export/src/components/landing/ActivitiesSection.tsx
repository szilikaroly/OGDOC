import { useTranslation } from "react-i18next";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { getIcon } from "@/lib/icon-map";
import { ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { useContentTranslations } from "@/hooks/use-content-translations";

interface Activity {
  id: string;
  name: string;
  slug: string;
  short_description: string | null;
  icon_name: string | null;
  is_active: boolean;
}

export default function ActivitiesSection() {
  const { t } = useTranslation();
  const { ct } = useContentTranslations("activities");
  const { data: activities, isLoading } = useQuery({
    queryKey: ["landing-activities"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("activities")
        .select("id, name, slug, short_description, icon_name, is_active")
        .eq("is_active", true)
        .order("sort_order");
      if (error) throw error;
      return data as Activity[];
    },
  });

  if (isLoading) {
    return (
      <section className="py-24 bg-muted/30">
        <div className="container mx-auto px-4 lg:px-8">
          <Skeleton className="mx-auto mb-12 h-8 w-64" />
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <Skeleton key={i} className="h-40 rounded-xl" />
            ))}
          </div>
        </div>
      </section>
    );
  }

  if (!activities?.length) return null;

  return (
    <section id="tevekenysegek" className="py-24 bg-muted/30">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="mx-auto max-w-2xl text-center mb-16">
          <div className="mx-auto mb-4 h-px w-16 bg-gradient-gold" />
          <h2 className="text-3xl font-bold text-foreground md:text-4xl">
            {t("activities.sectionTitle")}
          </h2>
          <p className="mt-4 text-muted-foreground">
            {t("activities.sectionSubtitle")}
          </p>
        </div>

        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {activities.map((activity) => {
            const Icon = getIcon(activity.icon_name);
            return (
              <Link key={activity.id} to={`/tevekenyseg/${activity.slug}`}>
                <Card className="group h-full border-border/50 bg-gradient-card hover:shadow-lg hover:border-secondary/30 transition-all duration-300 cursor-pointer">
                  <CardContent className="p-6 flex flex-col h-full">
                    <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-accent text-secondary mb-4 group-hover:scale-110 transition-transform">
                      <Icon className="h-6 w-6" />
                    </div>
                    <h3 className="font-semibold text-foreground mb-2">
                      {ct(activity.id, "name", activity.name)}
                    </h3>
                    {activity.short_description && (
                      <p className="text-sm text-muted-foreground leading-relaxed flex-1">
                        {ct(activity.id, "short_description", activity.short_description)}
                      </p>
                    )}
                    <div className="flex items-center gap-1 text-secondary text-sm font-medium mt-3 group-hover:gap-2 transition-all">
                      {t("activities.details")} <ArrowRight className="h-4 w-4" />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
}
