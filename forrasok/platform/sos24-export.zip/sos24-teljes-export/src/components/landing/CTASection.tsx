import { Link } from "react-router-dom";
import { usePageContent } from "@/hooks/use-cms";
import { useContentTranslations } from "@/hooks/use-content-translations";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowRight } from "lucide-react";
import { sanitizeRichHtml } from "@/lib/sanitize-html";


export default function CTASection() {
  const { data: content, isLoading } = usePageContent("home");
  const { ct } = useContentTranslations("pages_content");

  const ctaRaw = content?.sections?.cta as { title?: string; description?: string; button_text?: string; button_link?: string } | undefined;
  const ctaId = content?.sectionIds?.cta;

  const title = ctaId ? ct(ctaId, "title", ctaRaw?.title) : ctaRaw?.title;
  const description = ctaId ? ct(ctaId, "description", ctaRaw?.description) : ctaRaw?.description;
  const buttonText = ctaId ? ct(ctaId, "button_text", ctaRaw?.button_text) : ctaRaw?.button_text;

  return (
    <section className="py-24 bg-gradient-hero">
      <div className="container mx-auto px-4 text-center lg:px-8">
        {isLoading ? (
          <div className="mx-auto max-w-2xl space-y-4">
            <Skeleton className="mx-auto h-8 w-72 bg-navy-700/30" />
            <Skeleton className="mx-auto h-5 w-96 bg-navy-700/30" />
            <Skeleton className="mx-auto h-12 w-40 bg-navy-700/30" />
          </div>
        ) : (
          <div className="mx-auto max-w-2xl space-y-6 animate-fade-in">
            <h2 className="text-3xl font-bold text-primary-foreground md:text-4xl">
              {title}
            </h2>
            {description && (
              <div className="text-lg text-navy-300 prose prose-invert max-w-none [&_p]:text-navy-300" dangerouslySetInnerHTML={{ __html: sanitizeRichHtml(description) }} />
            )}
            {buttonText && (
              <Button
                asChild
                size="lg"
                className="bg-secondary text-secondary-foreground shadow-gold hover:bg-secondary/90 px-8 py-6"
              >
                <Link to={ctaRaw?.button_link ?? "/register"}>
                  {buttonText}
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
            )}
          </div>
        )}
      </div>
    </section>
  );
}
