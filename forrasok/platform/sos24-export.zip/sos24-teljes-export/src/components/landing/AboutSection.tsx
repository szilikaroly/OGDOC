import { usePageContent } from "@/hooks/use-cms";
import { useContentTranslations } from "@/hooks/use-content-translations";
import { Skeleton } from "@/components/ui/skeleton";
import { getIcon } from "@/lib/icon-map";
import { sanitizeRichHtml } from "@/lib/sanitize-html";


interface Feature {
  icon: string;
  label: string;
}

export default function AboutSection() {
  const { data: content, isLoading } = usePageContent("home");
  const { ct } = useContentTranslations("pages_content");

  const aboutRaw = content?.sections?.about as { title?: string; description?: string; features?: Feature[] } | undefined;
  const aboutId = content?.sectionIds?.about;

  const title = aboutId ? ct(aboutId, "title", aboutRaw?.title) : aboutRaw?.title;
  const description = aboutId ? ct(aboutId, "description", aboutRaw?.description) : aboutRaw?.description;

  return (
    <section id="rolunk" className="py-24 bg-muted/30">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="mx-auto max-w-3xl text-center">
          {isLoading ? (
            <>
              <Skeleton className="mx-auto mb-4 h-8 w-40" />
              <Skeleton className="mx-auto h-5 w-full" />
              <Skeleton className="mx-auto mt-2 h-5 w-4/5" />
            </>
          ) : (
            <>
              <div className="mx-auto mb-4 h-px w-16 bg-gradient-gold" />
              <h2 className="text-3xl font-bold text-foreground md:text-4xl">{title}</h2>
              {description && (
                <div className="mt-6 text-lg leading-relaxed text-muted-foreground prose dark:prose-invert max-w-none" dangerouslySetInnerHTML={{ __html: sanitizeRichHtml(description) }} />
              )}
            </>
          )}

          <div className="mt-12 grid gap-8 sm:grid-cols-3">
            {(aboutRaw?.features ?? []).map((f, i) => {
              const Icon = getIcon(f.icon);
              return (
                <div key={i} className="flex flex-col items-center gap-3">
                  <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-accent text-secondary">
                    <Icon className="h-6 w-6" />
                  </div>
                  <span className="text-sm font-medium text-foreground">{f.label}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
