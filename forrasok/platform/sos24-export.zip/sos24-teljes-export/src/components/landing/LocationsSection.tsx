import { useTranslation } from "react-i18next";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { MapPin, Phone, Mail, MessageCircle, ExternalLink } from "lucide-react";
import { useContentTranslations } from "@/hooks/use-content-translations";

export default function LocationsSection() {
  const { t } = useTranslation();
  const { ct } = useContentTranslations("locations");
  const { data: locations, isLoading } = useQuery({
    queryKey: ["public-locations"],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("get_public_locations");
      if (error) throw error;
      return data ?? [];
    },
    staleTime: 5 * 60 * 1000,
  });

  if (!isLoading && (!locations || locations.length === 0)) return null;

  return (
    <section id="helyszinek" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-foreground md:text-4xl">{t("locations.sectionTitle")}</h2>
          <p className="mt-3 text-muted-foreground text-lg">{t("locations.sectionSubtitle")}</p>
        </div>

        {isLoading ? (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-56 rounded-xl" />
            ))}
          </div>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {locations!.map((loc) => (
              <Card key={loc.id} className="border-border/50 shadow-md hover:shadow-lg transition-shadow">
                <CardContent className="p-6 space-y-4">
                  <div className="flex items-start gap-3">
                    <div className="rounded-lg bg-primary/10 p-2.5">
                      <MapPin className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg text-foreground">{ct(loc.id, "name", loc.name)}</h3>
                      {loc.city && <p className="text-sm text-muted-foreground">{loc.city}</p>}
                    </div>
                  </div>

                  {loc.address && (
                    <p className="text-sm text-muted-foreground pl-[52px]">{loc.address}</p>
                  )}

                  {loc.description && (
                    <p className="text-sm text-muted-foreground pl-[52px]">{ct(loc.id, "description", loc.description)}</p>
                  )}

                  <div className="flex flex-wrap gap-2 pl-[52px]">
                    {loc.phone && (
                      <a
                        href={`tel:${loc.phone}`}
                        className="inline-flex items-center gap-1.5 rounded-full bg-primary/10 px-3 py-1.5 text-xs font-medium text-primary hover:bg-primary/20 transition-colors"
                        title={t("locations.call")}
                      >
                        <Phone className="h-3.5 w-3.5" />
                        {loc.phone}
                      </a>
                    )}
                    {loc.email && (
                      <a
                        href={`mailto:${loc.email}`}
                        className="inline-flex items-center gap-1.5 rounded-full bg-primary/10 px-3 py-1.5 text-xs font-medium text-primary hover:bg-primary/20 transition-colors"
                        title={t("admin.email")}
                      >
                        <Mail className="h-3.5 w-3.5" />
                        {loc.email}
                      </a>
                    )}
                    {loc.whatsapp && (
                      <a
                        href={`https://wa.me/${loc.whatsapp.replace(/[^0-9]/g, "")}`}
                        target="_blank"
                        rel="noopener"
                        className="inline-flex items-center gap-1.5 rounded-full bg-green-500/10 px-3 py-1.5 text-xs font-medium text-green-600 hover:bg-green-500/20 transition-colors"
                        title="WhatsApp"
                      >
                        <MessageCircle className="h-3.5 w-3.5" />
                        WhatsApp
                      </a>
                    )}
                    {loc.google_maps_url && (
                      <a
                        href={loc.google_maps_url}
                        target="_blank"
                        rel="noopener"
                        className="inline-flex items-center gap-1.5 rounded-full bg-secondary/10 px-3 py-1.5 text-xs font-medium text-secondary-foreground hover:bg-secondary/20 transition-colors"
                        title={t("locations.map")}
                      >
                        <ExternalLink className="h-3.5 w-3.5" />
                        {t("locations.map")}
                      </a>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
