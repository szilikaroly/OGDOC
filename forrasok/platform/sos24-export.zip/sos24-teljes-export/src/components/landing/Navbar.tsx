import { useState, useEffect, useRef } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useSiteSettings, useSiteSettingsIdMap, useNavigationLinks, useActivities } from "@/hooks/use-cms";
import { useContentTranslations, useSiteSettingsTranslations } from "@/hooks/use-content-translations";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Menu, X, LogOut, LayoutDashboard, ChevronDown, FlaskConical } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import LanguageSwitcher from "@/components/LanguageSwitcher";
import { useTranslation } from "react-i18next";
import { getIcon } from "@/lib/icon-map";

export default function Navbar() {
  const { data: settings, isLoading: settingsLoading } = useSiteSettings();
  const { data: idMap } = useSiteSettingsIdMap();
  const { data: links, isLoading: linksLoading } = useNavigationLinks();
  const { data: activities } = useActivities();
  const { ct } = useContentTranslations("navigation_links");
  const { ct: ctAct } = useContentTranslations("activities");
  const { ctSetting } = useSiteSettingsTranslations();
  const { user, signOut, activeRole } = useAuth();
  const navigate = useNavigate();
  const handleSignOut = async () => {
    await signOut();
    navigate("/login", { replace: true });
  };

  const dashboardPath = activeRole
    ? { super_admin: "/admin", haziorvos: "/haziorvos", uzemorvos: "/uzemorvos", munkaltato: "/munkaltato", munkavallalo: "/munkavallalo", praxistag: "/praxistag" }[activeRole] ?? "/"
    : "/";
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [mobileActivitiesOpen, setMobileActivitiesOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const { t } = useTranslation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Close dropdown on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const siteNameId = idMap?.["site_name"] ?? "";
  const siteName = siteNameId ? ctSetting(siteNameId, settings?.site_name) : (settings?.site_name ?? "");
  const navLinks = (links ?? []).filter((l) => l.href !== "/login" || !user);
  const isLoading = settingsLoading || linksLoading;

  // Detect which nav link is the "activities" parent (href contains "tevekenyseg" or "/#tevekenysegek")
  const isActivitiesLink = (href: string) =>
    href.includes("tevekenyseg") || href.includes("tevekenysegeink");

  const renderDesktopLink = (link: { id: string; href: string; label: string }) => {
    if (isActivitiesLink(link.href) && activities && activities.length > 0) {
      return (
        <div key={link.id} className="relative" ref={dropdownRef}>
          <Link
            to="/tevekenysegeink"
            className="flex items-center gap-1 text-sm font-medium text-foreground/80 transition-colors hover:text-secondary"
            onMouseEnter={() => setDropdownOpen(true)}
          >
            {ct(link.id, "label", link.label)}
            <ChevronDown className="h-3.5 w-3.5" />
          </Link>
          {dropdownOpen && (
            <div
              className="absolute left-0 top-full mt-2 w-72 rounded-xl border bg-popover p-2 shadow-lg z-50 animate-fade-in"
              onMouseEnter={() => setDropdownOpen(true)}
              onMouseLeave={() => setDropdownOpen(false)}
            >
              {activities.map((a) => {
                const Icon = getIcon(a.icon_name ?? "");
                return (
                  <Link
                    key={a.id}
                    to={`/tevekenyseg/${a.slug}`}
                    className="flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors hover:bg-accent"
                    onClick={() => setDropdownOpen(false)}
                  >
                    {Icon && <Icon className="h-4 w-4 text-primary shrink-0" />}
                    <span>{ctAct(a.id, "name", a.name)}</span>
                  </Link>
                );
              })}
              <div className="mt-1 border-t pt-1">
                <Link
                  to="/tevekenysegeink"
                  className="block rounded-lg px-3 py-2 text-sm font-medium text-primary hover:bg-accent transition-colors"
                  onClick={() => setDropdownOpen(false)}
                >
                  {t("activities.viewAll", "Összes tevékenység →")}
                </Link>
              </div>
            </div>
          )}
        </div>
      );
    }
    return (
      <Link
        key={link.id}
        to={link.href}
        className="text-sm font-medium text-foreground/80 transition-colors hover:text-secondary"
      >
        {ct(link.id, "label", link.label)}
      </Link>
    );
  };

  return (
    <nav
      className={`fixed top-0 z-50 w-full transition-all duration-300 ${
        scrolled ? "glass-card shadow-md" : "bg-transparent"
      }`}
    >
      <div className="container mx-auto flex h-16 items-center justify-between px-4 lg:px-8 bg-primary-foreground text-primary">
        <Link to="/" className="flex items-center gap-2 font-display text-xl font-bold text-gradient-gold">
          <img src="/logo.png" alt="Logo" className="h-10 w-10 object-contain" />
          {isLoading ? <Skeleton className="h-6 w-28" /> : siteName}
        </Link>

        <div className="hidden items-center gap-6 md:flex">
          {isLoading
            ? Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-4 w-16" />)
            : navLinks.map((link) => renderDesktopLink(link))}
          <Link
            to="/labor"
            className="flex items-center gap-1.5 text-sm font-medium text-foreground/80 transition-colors hover:text-secondary"
          >
            <FlaskConical className="h-4 w-4" />
            {t("nav.labShop", "Labor vizsgálat")}
          </Link>
          {user && (
            <>
              <Button variant="default" size="sm" asChild>
                <Link to={dashboardPath}>
                  <LayoutDashboard className="mr-1 h-4 w-4" /> {t('nav.dashboard')}
                </Link>
              </Button>
              <Button variant="ghost" size="sm" onClick={handleSignOut}>
                <LogOut className="mr-1 h-4 w-4" /> {t('nav.logout')}
              </Button>
            </>
          )}
          <LanguageSwitcher />
        </div>

        <button className="md:hidden" onClick={() => setMenuOpen(!menuOpen)} aria-label={t('nav.menu')}>
          {menuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {menuOpen && (
        <div className="glass-card border-t md:hidden animate-fade-in">
          <div className="container mx-auto flex flex-col gap-2 px-4 py-4">
            {navLinks.map((link) => {
              if (isActivitiesLink(link.href) && activities && activities.length > 0) {
                return (
                  <div key={link.id}>
                    <button
                      className="flex w-full items-center justify-between rounded-md px-3 py-2 text-sm font-medium transition-colors hover:bg-accent"
                      onClick={() => setMobileActivitiesOpen(!mobileActivitiesOpen)}
                    >
                      {ct(link.id, "label", link.label)}
                      <ChevronDown className={`h-4 w-4 transition-transform ${mobileActivitiesOpen ? "rotate-180" : ""}`} />
                    </button>
                    {mobileActivitiesOpen && (
                      <div className="ml-4 flex flex-col gap-1 mt-1">
                        {activities.map((a) => (
                          <Link
                            key={a.id}
                            to={`/tevekenyseg/${a.slug}`}
                            className="rounded-md px-3 py-1.5 text-sm transition-colors hover:bg-accent"
                            onClick={() => setMenuOpen(false)}
                          >
                            {ctAct(a.id, "name", a.name)}
                          </Link>
                        ))}
                        <Link
                          to="/tevekenysegeink"
                          className="rounded-md px-3 py-1.5 text-sm font-medium text-primary"
                          onClick={() => setMenuOpen(false)}
                        >
                          {t("activities.viewAll", "Összes tevékenység →")}
                        </Link>
                      </div>
                    )}
                  </div>
                );
              }
              return (
                <Link
                  key={link.id}
                  to={link.href}
                  className="rounded-md px-3 py-2 text-sm font-medium transition-colors hover:bg-accent"
                  onClick={() => setMenuOpen(false)}
                >
                  {ct(link.id, "label", link.label)}
                </Link>
              );
            })}
            <Link
              to="/labor"
              className="flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium transition-colors hover:bg-accent"
              onClick={() => setMenuOpen(false)}
            >
              <FlaskConical className="h-4 w-4" />
              {t("nav.labShop", "Labor vizsgálat")}
            </Link>
            {user && (
              <>
                <Button variant="default" size="sm" asChild>
                  <Link to={dashboardPath} onClick={() => setMenuOpen(false)}>
                    <LayoutDashboard className="mr-1 h-4 w-4" /> {t('nav.dashboard')}
                  </Link>
                </Button>
                <Button variant="ghost" size="sm" onClick={() => { setMenuOpen(false); handleSignOut(); }}>
                  <LogOut className="mr-1 h-4 w-4" /> {t('nav.logout')}
                </Button>
              </>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}
