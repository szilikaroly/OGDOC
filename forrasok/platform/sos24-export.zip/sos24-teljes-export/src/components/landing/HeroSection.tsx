import { Link } from "react-router-dom";
import { useSiteSettings, useSiteSettingsIdMap, usePageContent } from "@/hooks/use-cms";
import { useSiteSettingsTranslations, useContentTranslations } from "@/hooks/use-content-translations";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowRight } from "lucide-react";
import { useTranslation } from "react-i18next";
import { sanitizeRichHtml } from "@/lib/sanitize-html";


export default function HeroSection() {
  const { t, i18n } = useTranslation();
  const lang = i18n.language;
  const { data: settings, isLoading: sLoading } = useSiteSettings();
  const { data: idMap } = useSiteSettingsIdMap();
  const { data: content, isLoading: cLoading } = usePageContent("home");
  const { ctSetting } = useSiteSettingsTranslations();
  const { ct } = useContentTranslations("pages_content");

  const isLoading = sLoading || cLoading;

  const ts = (key: string) => {
    const id = idMap?.[key];
    const original = settings?.[key] ?? "";
    if (!id || lang === "hu") return original;
    return ctSetting(id, original) || original;
  };

  const heroRaw = content?.sections?.hero as { title?: string; subtitle?: string } | undefined;
  const heroId = content?.sectionIds?.hero;

  const title = (heroId ? ct(heroId, "title", heroRaw?.title) : heroRaw?.title) ?? ts("hero_title") ?? "";
  const subtitle = (heroId ? ct(heroId, "subtitle", heroRaw?.subtitle) : heroRaw?.subtitle) ?? ts("hero_subtitle") ?? "";
  const ctaText = ts("hero_cta_text") ?? "";
  const ctaLink = settings?.hero_cta_link ?? "/register";

  return (
    <section className="relative flex min-h-[85vh] items-center justify-center bg-gradient-hero overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -right-20 -top-20 h-96 w-96 rounded-full bg-secondary/5 blur-3xl" />
        <div className="absolute -bottom-32 -left-32 h-[500px] w-[500px] rounded-full bg-secondary/3 blur-3xl" />
      </div>

      <div className="container relative z-10 mx-auto px-4 text-center lg:px-8">
        {isLoading ? (
          <div className="mx-auto max-w-3xl space-y-6">
            <Skeleton className="mx-auto h-14 w-3/4 bg-navy-700/30" />
            <Skeleton className="mx-auto h-6 w-2/3 bg-navy-700/30" />
            <Skeleton className="mx-auto h-12 w-48 bg-navy-700/30" />
          </div>
        ) : (
          <div className="mx-auto max-w-3xl space-y-8 animate-fade-in">
            <div className="mx-auto mb-4 h-px w-16 bg-gradient-gold" />
            <h1 className="text-4xl font-bold leading-tight text-primary-foreground md:text-5xl lg:text-6xl">
              <span className="text-gradient-gold">{title}</span>
            </h1>
            {subtitle && (
              <div className="mx-auto max-w-2xl text-lg leading-relaxed text-navy-300 md:text-xl prose prose-invert max-w-none [&_p]:text-navy-300" dangerouslySetInnerHTML={{ __html: sanitizeRichHtml(subtitle) }} />
            )}
            {ctaText && (
              <Button
                asChild
                size="lg"
                className="bg-secondary text-secondary-foreground shadow-gold hover:bg-secondary/90 text-base px-8 py-6"
              >
                <Link to={ctaLink}>
                  {ctaText}
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
            )}
          </div>
        )}
      </div>
    </section>
  );
}
