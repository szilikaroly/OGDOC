import React, { useMemo } from "react";
import { useTranslation } from "react-i18next";
import { useServices, usePageContent } from "@/hooks/use-cms";
import { useContentTranslations } from "@/hooks/use-content-translations";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { getIcon } from "@/lib/icon-map";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function ServicesSection() {
  const { t } = useTranslation();
  const { data: services, isLoading: sLoading } = useServices();
  const { data: content, isLoading: cLoading } = usePageContent("home");
  const { ct } = useContentTranslations("services");
  const { ct: ctPage } = useContentTranslations("pages_content");

  const introRaw = content?.sections?.services_intro as { title?: string; description?: string } | undefined;
  const introId = content?.sectionIds?.services_intro;

  const introTitle = introId ? ctPage(introId, "title", introRaw?.title) : introRaw?.title;
  const introDesc = introId ? ctPage(introId, "description", introRaw?.description) : introRaw?.description;

  const categories = useMemo(() => {
    if (!services) return [];
    const catMap = new Map<string, typeof services>();
    services.forEach((svc) => {
      const cat = ct(svc.id, "category", svc.category) || t("landing.otherCategory");
      if (!catMap.has(cat)) catMap.set(cat, []);
      catMap.get(cat)!.push(svc);
    });
    return Array.from(catMap.entries()).map(([name, items]) => ({ name, items }));
  }, [services, ct, t]);

  return (
    <section id="szolgaltatasok" className="py-24 bg-background">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="mx-auto max-w-2xl text-center mb-16">
          {cLoading ? (
            <>
              <Skeleton className="mx-auto mb-4 h-8 w-64" />
              <Skeleton className="mx-auto h-5 w-96" />
            </>
          ) : (
            <>
              <div className="mx-auto mb-4 h-px w-16 bg-gradient-gold" />
              <h2 className="text-3xl font-bold text-foreground md:text-4xl">{introTitle}</h2>
              <p className="mt-4 text-muted-foreground">{introDesc}</p>
            </>
          )}
        </div>

        {sLoading ? (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <Card key={i} className="card-luxury">
                <CardHeader><Skeleton className="h-8 w-8 rounded-full" /><Skeleton className="mt-3 h-5 w-40" /></CardHeader>
                <CardContent><Skeleton className="h-4 w-full" /><Skeleton className="mt-2 h-4 w-3/4" /></CardContent>
              </Card>
            ))}
          </div>
        ) : categories.length > 1 ? (
          <Tabs defaultValue={categories[0]?.name} className="w-full">
            <TabsList className="mb-8 flex flex-wrap h-auto gap-2 bg-transparent justify-center">
              {categories.map((cat) => (
                <TabsTrigger key={cat.name} value={cat.name} className="data-[state=active]:bg-secondary data-[state=active]:text-secondary-foreground">
                  {cat.name}
                </TabsTrigger>
              ))}
            </TabsList>
            {categories.map((cat) => (
              <TabsContent key={cat.name} value={cat.name}>
                <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                  {cat.items.map((svc) => (
                    <ServiceCard key={svc.id} svc={svc} ct={ct} />
                  ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        ) : (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {services?.map((svc) => <ServiceCard key={svc.id} svc={svc} ct={ct} />)}
          </div>
        )}
      </div>
    </section>
  );
}

const ServiceCard = React.forwardRef<HTMLDivElement, { svc: { id: string; name: string; description: string | null; icon_name: string | null; price: number | null }; ct: (id: string, field: string, orig: string | null | undefined) => string }>(({ svc, ct }, ref) => {
  const Icon = getIcon(svc.icon_name);
  return (
    <Card ref={ref} className="card-luxury border-border/50 bg-gradient-card">
      <CardHeader>
        <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-accent text-secondary">
          <Icon className="h-8 w-8" />
        </div>
        <CardTitle className="mt-3 text-lg">{ct(svc.id, "name", svc.name)}</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground leading-relaxed">{ct(svc.id, "description", svc.description)}</p>
        {svc.price != null && svc.price > 0 && (
          <p className="mt-3 text-sm font-semibold text-secondary">
            {svc.price.toLocaleString("hu-HU")} Ft
          </p>
        )}
      </CardContent>
    </Card>
  );
});
ServiceCard.displayName = "ServiceCard";
