import { Link } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { FlaskConical, ShieldCheck, Clock, Home, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function LabSection() {
  const { t } = useTranslation();

  const features = [
    {
      icon: FlaskConical,
      title: t("lab.section.wideRange", "Széles vizsgálati paletta"),
      description: t("lab.section.wideRangeDesc", "700+ laborvizsgálat közül választhat, az alapszűréstől a speciális hormon- és immunológiai vizsgálatokig."),
    },
    {
      icon: ShieldCheck,
      title: t("lab.section.noRegistration", "Regisztráció nélkül"),
      description: t("lab.section.noRegistrationDesc", "Adja meg nevét, e-mail címét és telefonszámát – nem szükséges fiók létrehozása."),
    },
    {
      icon: Clock,
      title: t("lab.section.quickOrder", "Gyors megrendelés"),
      description: t("lab.section.quickOrderDesc", "Válassza ki a kívánt vizsgálatokat, adja meg adatait, és mi felvesszük Önnel a kapcsolatot."),
    },
    {
      icon: Home,
      title: t("lab.section.homeSampling", "Otthoni mintavétel"),
      description: t("lab.section.homeSamplingDesc", "Kényelmes otthoni vérvétel lehetőség, felár ellenében az Ön otthonában."),
    },
  ];

  return (
    <section id="labor" className="py-20 bg-gradient-to-b from-background to-muted/30">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 rounded-full border border-secondary/30 bg-secondary/5 px-4 py-1.5 text-sm font-medium text-secondary mb-4">
            <FlaskConical className="h-4 w-4" />
            {t("lab.section.badge", "Labor Vizsgálatok")}
          </div>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            {t("lab.section.title", "Magán laborvizsgálat rendelés")}
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            {t("lab.section.subtitle", "Rendeljen laborvizsgálatot egyszerűen, regisztráció nélkül. Válasszon egyedi vizsgálatokat vagy előre összeállított csomagokat.")}
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {features.map((feature, i) => (
            <div
              key={i}
              className="group rounded-2xl border bg-card p-6 shadow-sm transition-all hover:shadow-md hover:-translate-y-1"
            >
              <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-secondary/10 text-secondary group-hover:bg-secondary group-hover:text-secondary-foreground transition-colors">
                <feature.icon className="h-6 w-6" />
              </div>
              <h3 className="font-semibold text-lg mb-2">{feature.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>

        <div className="text-center">
          <Button size="lg" asChild className="gap-2 text-base px-8">
            <Link to="/labor">
              {t("lab.section.cta", "Vizsgálat rendelés")}
              <ArrowRight className="h-5 w-5" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
}
