import { Link } from "react-router-dom";
import { useSiteSettings, useSiteSettingsIdMap, useNavigationLinks, useActivities } from "@/hooks/use-cms";
import { useContentTranslations, useSiteSettingsTranslations } from "@/hooks/use-content-translations";
import { Skeleton } from "@/components/ui/skeleton";
import { Mail, Phone, MapPin, ArrowRight } from "lucide-react";
import { useTranslation } from "react-i18next";

export default function Footer() {
  const { t, i18n } = useTranslation();
  const lang = i18n.language;
  const { data: settings, isLoading: sLoading } = useSiteSettings();
  const { data: idMap } = useSiteSettingsIdMap();
  const { data: links, isLoading: lLoading } = useNavigationLinks();
  const { data: activities } = useActivities();
  const { ct } = useContentTranslations("navigation_links");
  const { ct: ctAct } = useContentTranslations("activities");
  const { ctSetting } = useSiteSettingsTranslations();

  const isLoading = sLoading || lLoading;

  const ts = (key: string) => {
    const id = idMap?.[key];
    const translated = id ? ctSetting(id, settings?.[key]) : undefined;
    if (lang !== "hu" && translated && translated === settings?.[key]) return "";
    return translated || (settings?.[key] ?? "");
  };

  const footerActivities = (activities ?? []).slice(0, 8);

  return (
    <footer id="kapcsolat" className="bg-navy-950 text-navy-300">
      <div className="container mx-auto px-4 py-16 lg:px-8">
        <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-4">
          {/* Brand */}
          <div>
            {isLoading ? (
              <Skeleton className="h-6 w-32 bg-navy-800" />
            ) : (
              <Link to="/" className="font-display text-xl font-bold text-gradient-gold">
                {ts("site_name")}
              </Link>
            )}
            <p className="mt-4 text-sm leading-relaxed text-navy-400">
              {ts("footer_text")}
            </p>
          </div>

          {/* Navigation */}
          <div>
            <h4 className="mb-4 text-sm font-semibold uppercase tracking-wider text-navy-200">
              {ts("footer_nav_title") || t("landing.navigation")}
            </h4>
            <div className="flex flex-col gap-2">
              {isLoading
                ? Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-4 w-24 bg-navy-800" />)
                : links?.map((link) => (
                    <Link
                      key={link.id}
                      to={link.href}
                      className="text-sm transition-colors hover:text-secondary"
                    >
                      {ct(link.id, "label", link.label)}
                    </Link>
                  ))}
            </div>
          </div>

          {/* Activities */}
          {footerActivities.length > 0 && (
            <div>
              <h4 className="mb-4 text-sm font-semibold uppercase tracking-wider text-navy-200">
                {t("activities.pageTitle", "Tevékenységeink")}
              </h4>
              <div className="flex flex-col gap-2">
                {footerActivities.map((a) => (
                  <Link
                    key={a.id}
                    to={`/tevekenyseg/${a.slug}`}
                    className="text-sm transition-colors hover:text-secondary"
                  >
                    {ctAct(a.id, "name", a.name)}
                  </Link>
                ))}
                {(activities ?? []).length > 8 && (
                  <Link
                    to="/tevekenysegeink"
                    className="flex items-center gap-1 text-sm font-medium text-secondary hover:text-secondary/80 transition-colors mt-1"
                  >
                    {t("activities.viewAll", "Összes tevékenység →")}
                  </Link>
                )}
              </div>
            </div>
          )}

          {/* Contact */}
          <div>
            <h4 className="mb-4 text-sm font-semibold uppercase tracking-wider text-navy-200">
              {ts("footer_contact_title") || t("landing.contact")}
            </h4>
            <div className="flex flex-col gap-3 text-sm">
              {settings?.contact_email && (
                <a href={`mailto:${settings.contact_email}`} className="flex items-center gap-2 hover:text-secondary transition-colors">
                  <Mail className="h-4 w-4 text-secondary" />
                  {settings.contact_email}
                </a>
              )}
              {settings?.contact_phone && (
                <a href={`tel:${settings.contact_phone}`} className="flex items-center gap-2 hover:text-secondary transition-colors">
                  <Phone className="h-4 w-4 text-secondary" />
                  {settings.contact_phone}
                </a>
              )}
              {settings?.contact_address && (
                <span className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-secondary" />
                  {settings.contact_address}
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="divider-gold mt-12 mb-6" />
        <p className="text-center text-xs text-navy-500">
          {ts("footer_text")}
        </p>
      </div>
    </footer>
  );
}
