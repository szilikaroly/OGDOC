import { useState } from "react";
import { useTranslation } from "react-i18next";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { FileDown, Loader2 } from "lucide-react";
import { toast } from "sonner";

interface GeneratePdfButtonProps {
  type: "opinion" | "examination" | "referral";
  recordId: string;
  label?: string;
  variant?: "default" | "outline" | "ghost" | "secondary";
  size?: "default" | "sm" | "lg" | "icon";
}

export default function GeneratePdfButton({
  type,
  recordId,
  label = "PDF",
  variant = "outline",
  size = "sm",
}: GeneratePdfButtonProps) {
  const { t } = useTranslation();
  const [loading, setLoading] = useState(false);

  const handleGenerate = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("generate-pdf", {
        body: { type, record_id: recordId },
      });

      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      toast.success(`${data.document_type} generálva`, {
        description: data.file_name,
      });

      const { data: urlData, error: urlError } = await supabase.storage
        .from("medical-documents")
        .createSignedUrl(data.file_path, 3600);

      if (urlError) throw urlError;

      window.open(urlData.signedUrl, "_blank");
    } catch (e: any) {
      toast.error(t("pdfError"), {
        description: e.message,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Button size={size} variant={variant} onClick={handleGenerate} disabled={loading}>
      {loading ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <FileDown className="h-4 w-4 mr-1" />}
      {label}
    </Button>
  );
}