import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Download, History, Loader2, ChevronDown, ChevronUp } from "lucide-react";

type Row = {
  id: string;
  created_at: string;
  status: string;
  error_message: string | null;
  message_id: string | null;
  recipient_email: string;
  metadata: Record<string, unknown> | null;
};

const SUCCESS = new Set(["sent"]);
const FAIL = new Set(["failed", "bounced", "complained", "suppressed", "dlq"]);

const statusTone = (s: string) =>
  SUCCESS.has(s)
    ? "bg-green-500/15 text-green-700 dark:text-green-300 border-green-500/30"
    : FAIL.has(s)
    ? "bg-red-500/15 text-red-700 dark:text-red-300 border-red-500/30"
    : "bg-yellow-500/15 text-yellow-700 dark:text-yellow-300 border-yellow-500/30";

function csvEscape(v: unknown): string {
  if (v === null || v === undefined) return "";
  const s = typeof v === "string" ? v : JSON.stringify(v);
  return /[",\n;]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

function downloadCsv(rows: Row[], filename: string) {
  const header = ["created_at", "status", "error_message", "message_id", "recipient_email", "metadata"];
  const lines = [
    header.join(","),
    ...rows.map((r) =>
      [r.created_at, r.status, r.error_message ?? "", r.message_id ?? "", r.recipient_email, r.metadata ?? ""]
        .map(csvEscape)
        .join(","),
    ),
  ];
  const blob = new Blob(["\ufeff" + lines.join("\n")], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

type Props = {
  userId: string;
  userLabel: string;
  defaultOpen?: boolean;
  limit?: number;
};

export default function RecoveryHistoryPanel({ userId, userLabel, defaultOpen = false, limit = 10 }: Props) {
  const [open, setOpen] = useState(defaultOpen);

  const { data, isLoading, error, refetch, isFetching } = useQuery({
    queryKey: ["admin-recovery-history", userId, limit],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("admin_get_recovery_history", {
        _user_id: userId,
        _limit: limit,
      });
      if (error) throw error;
      return (data ?? []) as Row[];
    },
    enabled: open,
    staleTime: 30_000,
  });

  const rows = data ?? [];

  return (
    <div className="rounded-md border bg-muted/30">
      <button
        type="button"
        className="w-full flex items-center justify-between gap-2 px-3 py-2 text-xs font-medium"
        onClick={() => setOpen((v) => !v)}
      >
        <span className="inline-flex items-center gap-1.5">
          <History className="h-3.5 w-3.5" />
          Recovery előzmény (utolsó {limit})
        </span>
        {open ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
      </button>

      {open && (
        <div className="px-3 pb-3 space-y-2">
          <div className="flex items-center justify-between gap-2">
            <p className="text-[11px] text-muted-foreground">
              {isLoading || isFetching ? "Betöltés…" : `${rows.length} bejegyzés`}
            </p>
            <div className="flex gap-1">
              <Button size="sm" variant="ghost" className="h-7 px-2 text-xs" onClick={() => refetch()} disabled={isFetching}>
                {isFetching ? <Loader2 className="h-3 w-3 animate-spin" /> : "Frissítés"}
              </Button>
              <Button
                size="sm"
                variant="outline"
                className="h-7 px-2 text-xs"
                disabled={rows.length === 0}
                onClick={() => {
                  const safe = userLabel.replace(/[^a-z0-9_-]+/gi, "_").slice(0, 40) || "user";
                  const ts = new Date().toISOString().slice(0, 10);
                  downloadCsv(rows, `recovery-history_${safe}_${ts}.csv`);
                }}
              >
                <Download className="h-3 w-3 mr-1" /> CSV
              </Button>
            </div>
          </div>

          {error && (
            <p className="text-xs text-destructive">Hiba a lekérdezésnél: {(error as Error).message}</p>
          )}

          {!isLoading && rows.length === 0 && !error && (
            <p className="text-xs text-muted-foreground italic">Nincs rögzített recovery kísérlet.</p>
          )}

          {rows.length > 0 && (
            <ul className="space-y-1.5 max-h-64 overflow-y-auto pr-1">
              {rows.map((r) => (
                <li key={r.id} className="rounded border bg-background p-2 text-xs space-y-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-muted-foreground">
                      {new Date(r.created_at).toLocaleString("hu-HU")}
                    </span>
                    <Badge variant="outline" className={`text-[10px] ${statusTone(r.status)}`}>
                      {r.status}
                    </Badge>
                  </div>
                  {r.error_message && (
                    <p className="text-red-600 dark:text-red-400 break-words">{r.error_message}</p>
                  )}
                  {r.message_id && (
                    <p className="text-muted-foreground truncate" title={r.message_id}>
                      id: {r.message_id}
                    </p>
                  )}
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}
