import { useQuery } from "@tanstack/react-query";
import { AlertTriangle, Bell, RefreshCw, ShieldAlert } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

type RecentEvent = {
  recipient_email: string | null;
  status: string;
  error_message: string | null;
  created_at: string;
};

type Summary = {
  total_failures: number;
  failed_count: number;
  suppressed_count: number;
  bounced_count: number;
  complained_count: number;
  dlq_count: number;
  affected_recipients: number;
  last_event_at: string | null;
  recent: RecentEvent[];
};

const fmt = (iso: string | null) =>
  iso ? new Date(iso).toLocaleString("hu-HU", { dateStyle: "short", timeStyle: "short" }) : "—";

const statusVariant = (s: string): "destructive" | "secondary" | "outline" => {
  if (s === "suppressed") return "secondary";
  return "destructive";
};

const statusLabel = (s: string) => {
  switch (s) {
    case "failed": return "Sikertelen";
    case "dlq": return "Sikertelen (DLQ)";
    case "bounced": return "Visszapattant";
    case "complained": return "Panasz";
    case "suppressed": return "Letiltva";
    default: return s;
  }
};

export default function RecoveryFailuresSummary({ days = 7 }: { days?: number }) {
  const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString();

  const { data, isLoading, refetch, isFetching } = useQuery({
    queryKey: ["admin-recovery-failures-summary", days],
    queryFn: async (): Promise<Summary | null> => {
      const { data, error } = await supabase.rpc("admin_recovery_failures_summary", { _since: since });
      if (error) throw error;
      const row = Array.isArray(data) ? data[0] : data;
      return (row as Summary) ?? null;
    },
    refetchInterval: 60_000,
  });

  const total = data?.total_failures ?? 0;

  return (
    <Card className={total > 0 ? "border-destructive/40" : undefined}>
      <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0">
        <div className="flex items-center gap-2">
          <ShieldAlert className={`h-5 w-5 ${total > 0 ? "text-destructive" : "text-muted-foreground"}`} />
          <CardTitle className="text-lg">
            Jelszó-visszaállító hibák — utolsó {days} nap
          </CardTitle>
        </div>
        <div className="flex items-center gap-2">
          {total > 0 && (
            <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
              <Bell className="h-3.5 w-3.5" /> admin értesítés aktív
            </span>
          )}
          <Button size="sm" variant="outline" onClick={() => refetch()} disabled={isFetching}>
            <RefreshCw className={`h-4 w-4 mr-1 ${isFetching ? "animate-spin" : ""}`} />
            Frissítés
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {isLoading ? (
          <p className="text-sm text-muted-foreground">Betöltés…</p>
        ) : total === 0 ? (
          <p className="text-sm text-muted-foreground">
            Az elmúlt {days} napban nem volt sikertelen vagy letiltott jelszó-visszaállító e-mail.
          </p>
        ) : (
          <>
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-2">
              <Stat label="Összes" value={total} highlight />
              <Stat label="Sikertelen" value={data!.failed_count + data!.dlq_count} />
              <Stat label="Letiltva" value={data!.suppressed_count} />
              <Stat label="Visszapattant" value={data!.bounced_count} />
              <Stat label="Panasz" value={data!.complained_count} />
              <Stat label="Érintett címek" value={data!.affected_recipients} />
            </div>
            <div className="text-xs text-muted-foreground">
              Utolsó esemény: {fmt(data!.last_event_at)}
            </div>
            <div className="rounded-md border divide-y">
              {data!.recent.map((r, i) => (
                <div key={i} className="flex items-start justify-between gap-3 p-2 text-sm">
                  <div className="min-w-0">
                    <div className="font-medium truncate">{r.recipient_email ?? "—"}</div>
                    {r.error_message && (
                      <div className="text-xs text-muted-foreground line-clamp-2 break-words">
                        {r.error_message}
                      </div>
                    )}
                  </div>
                  <div className="flex flex-col items-end gap-1 shrink-0">
                    <Badge variant={statusVariant(r.status)} className="whitespace-nowrap">
                      {statusLabel(r.status)}
                    </Badge>
                    <span className="text-xs text-muted-foreground whitespace-nowrap">{fmt(r.created_at)}</span>
                  </div>
                </div>
              ))}
            </div>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <AlertTriangle className="h-3.5 w-3.5" />
              Minden új hiba automatikusan értesítést generál minden szuper adminnak.
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}

function Stat({ label, value, highlight }: { label: string; value: number; highlight?: boolean }) {
  return (
    <div className={`rounded-md border p-2 ${highlight ? "bg-destructive/5 border-destructive/30" : ""}`}>
      <div className="text-[11px] uppercase tracking-wide text-muted-foreground">{label}</div>
      <div className={`text-xl font-semibold ${highlight ? "text-destructive" : ""}`}>{value}</div>
    </div>
  );
}
