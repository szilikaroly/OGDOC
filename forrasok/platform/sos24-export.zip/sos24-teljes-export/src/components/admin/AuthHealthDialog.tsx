import { useMemo } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ShieldCheck, AlertTriangle, XCircle, Info, Mail, KeyRound, Pencil, Plus, CheckCircle2 } from "lucide-react";
import { evaluateUser, type RecoveryRow, type Finding, type Severity, severityRank } from "@/lib/auth-diagnostics";

type ProfileLite = { user_id: string; full_name: string | null };

export type AuthHealthAction =
  | { type: "send_recovery_link"; userId: string }
  | { type: "set_password_direct"; userId: string }
  | { type: "edit_email"; userId: string }
  | { type: "add_role"; userId: string };

type Props = {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  profiles: ProfileLite[];
  recoveryMap?: Map<string, RecoveryRow>;
  roleCounts: Map<string, number>;
  onAction: (action: AuthHealthAction) => void;
};

const sevIcon = (s: Severity) => {
  if (s === "error") return <XCircle className="h-3.5 w-3.5" />;
  if (s === "warn") return <AlertTriangle className="h-3.5 w-3.5" />;
  return <Info className="h-3.5 w-3.5" />;
};
const sevCls = (s: Severity) => {
  if (s === "error") return "bg-red-500/15 text-red-700 dark:text-red-300 border-red-500/30";
  if (s === "warn") return "bg-yellow-500/15 text-yellow-700 dark:text-yellow-300 border-yellow-500/30";
  return "bg-blue-500/15 text-blue-700 dark:text-blue-300 border-blue-500/30";
};

const actionIcon = (a: Finding["action"]) => {
  switch (a) {
    case "send_recovery_link": return <Mail className="h-3.5 w-3.5" />;
    case "set_password_direct": return <KeyRound className="h-3.5 w-3.5" />;
    case "edit_email": return <Pencil className="h-3.5 w-3.5" />;
    case "add_role": return <Plus className="h-3.5 w-3.5" />;
    default: return null;
  }
};

export default function AuthHealthDialog({ open, onOpenChange, profiles, recoveryMap, roleCounts, onAction }: Props) {
  const rows = useMemo(() => {
    const out: { profile: ProfileLite; rec?: RecoveryRow; findings: Finding[] }[] = [];
    for (const p of profiles) {
      const rec = recoveryMap?.get(p.user_id);
      const findings = evaluateUser(rec, { hasAnyRole: (roleCounts.get(p.user_id) ?? 0) > 0 });
      if (findings.length > 0) out.push({ profile: p, rec, findings });
    }
    out.sort((a, b) => {
      const av = Math.min(...a.findings.map((f) => severityRank[f.severity]));
      const bv = Math.min(...b.findings.map((f) => severityRank[f.severity]));
      return av - bv;
    });
    return out;
  }, [profiles, recoveryMap, roleCounts]);

  const stats = useMemo(() => {
    const total = profiles.length;
    let unconfirmed = 0, failedRecovery = 0, stale = 0;
    const ninetyDays = 90 * 24 * 60 * 60 * 1000;
    for (const p of profiles) {
      const rec = recoveryMap?.get(p.user_id);
      if (!rec) continue;
      if (!rec.email_confirmed_at) unconfirmed++;
      if (rec.last_recovery_status && ["dlq", "failed", "bounced", "suppressed", "complained"].includes(rec.last_recovery_status)) {
        failedRecovery++;
      }
      if (rec.last_sign_in_at && Date.now() - new Date(rec.last_sign_in_at).getTime() > ninetyDays) stale++;
    }
    return { total, unconfirmed, failedRecovery, stale, withFindings: rows.length };
  }, [profiles, recoveryMap, rows]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-5xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ShieldCheck className="h-5 w-5 text-secondary" />
            Auth ellenőrzés
          </DialogTitle>
          <DialogDescription>
            Felhasználói bejelentkezési állapot, e-mail megerősítés és jelszó-visszaállítási problémák, valamint javasolt javítási lépések.
          </DialogDescription>
        </DialogHeader>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          <StatCard label="Összes felhasználó" value={stats.total} />
          <StatCard label="Problémás" value={stats.withFindings} tone={stats.withFindings > 0 ? "warn" : "ok"} />
          <StatCard label="Meg nem erősített email" value={stats.unconfirmed} tone={stats.unconfirmed > 0 ? "warn" : "ok"} />
          <StatCard label="Sikertelen recovery" value={stats.failedRecovery} tone={stats.failedRecovery > 0 ? "error" : "ok"} />
          <StatCard label="90+ napja inaktív" value={stats.stale} />
        </div>

        {rows.length === 0 ? (
          <Card>
            <CardContent className="py-10 flex flex-col items-center justify-center text-center gap-2">
              <CheckCircle2 className="h-8 w-8 text-green-500" />
              <p className="font-medium">Nincs észlelt probléma.</p>
              <p className="text-sm text-muted-foreground">Minden felhasználó megerősített emaillel és aktív állapottal rendelkezik.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Felhasználó</TableHead>
                  <TableHead>Diagnózis</TableHead>
                  <TableHead className="w-[220px]">Javasolt javítás</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map(({ profile, rec, findings }) => (
                  <TableRow key={profile.user_id} className="align-top">
                    <TableCell className="min-w-[180px]">
                      <div className="font-medium">{profile.full_name ?? "—"}</div>
                      <div className="text-xs text-muted-foreground break-all">{rec?.email ?? "—"}</div>
                    </TableCell>
                    <TableCell>
                      <ul className="space-y-2">
                        {findings.map((f) => (
                          <li key={f.key} className="space-y-1">
                            <span className={`inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-[11px] font-medium ${sevCls(f.severity)}`}>
                              {sevIcon(f.severity)}{f.title}
                            </span>
                            <p className="text-xs text-muted-foreground">{f.description}</p>
                          </li>
                        ))}
                      </ul>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-col gap-1.5">
                        {findings.filter((f) => f.action !== "none").slice(0, 3).map((f) => (
                          <Button
                            key={f.key}
                            size="sm"
                            variant="outline"
                            className="justify-start text-xs h-8"
                            onClick={() => {
                              onAction({ type: f.action as any, userId: profile.user_id });
                              onOpenChange(false);
                            }}
                          >
                            <span className="mr-1.5">{actionIcon(f.action)}</span>
                            {f.actionLabel}
                          </Button>
                        ))}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

function StatCard({ label, value, tone }: { label: string; value: number; tone?: "ok" | "warn" | "error" }) {
  const cls =
    tone === "error" ? "text-red-600 dark:text-red-400" :
    tone === "warn" ? "text-yellow-600 dark:text-yellow-400" :
    tone === "ok" ? "text-green-600 dark:text-green-400" :
    "text-foreground";
  return (
    <Card>
      <CardContent className="p-3">
        <div className="text-[11px] uppercase tracking-wide text-muted-foreground">{label}</div>
        <div className={`text-2xl font-bold ${cls}`}>{value}</div>
      </CardContent>
    </Card>
  );
}
