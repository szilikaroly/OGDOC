import { useState } from "react";
import { useTranslation } from "react-i18next";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Plane, Shield, AlertTriangle, CheckCircle, Loader2, Bug } from "lucide-react";

interface VaccineItem {
  name: string;
  reason: string;
  timing: string;
  doses: number;
  notes?: string;
}

interface Recommendations {
  destination: string;
  mandatory: VaccineItem[];
  recommended: VaccineItem[];
  skippable?: string[];
  generalAdvice: string;
  malariaRisk: string;
  malariaAdvice?: string;
}

export default function TravelVaccinationAdvisor({ existingVaccines }: { existingVaccines?: string[] }) {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [destination, setDestination] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<Recommendations | null>(null);

  const handleSearch = async () => {
    if (!destination.trim()) return;
    setLoading(true);
    setResult(null);
    try {
      const { data, error } = await supabase.functions.invoke("ai-travel-vaccines", {
        body: { destination: destination.trim(), existingVaccines: existingVaccines ?? [] },
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      setResult(data);
    } catch (e: any) {
      toast({ variant: "destructive", title: t("common.error"), description: e.message });
    } finally {
      setLoading(false);
    }
  };

  const malariaColor = (risk: string) => {
    if (risk === "high") return "destructive";
    if (risk === "moderate") return "destructive";
    if (risk === "low") return "secondary";
    return "outline";
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <Plane className="h-5 w-5 text-primary" />
          {t("vaccinations.travelAdvisor")}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Input
            placeholder={t("vaccinations.travelDestinationPlaceholder")}
            value={destination}
            onChange={(e) => setDestination(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSearch()}
            className="flex-1"
          />
          <Button onClick={handleSearch} disabled={loading || !destination.trim()}>
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : t("vaccinations.travelSearch")}
          </Button>
        </div>

        {result && (
          <div className="space-y-4 animate-in fade-in">
            <h3 className="font-semibold text-lg">{result.destination}</h3>

            {/* Mandatory */}
            {result.mandatory.length > 0 && (
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-destructive font-medium">
                  <Shield className="h-4 w-4" />
                  {t("vaccinations.mandatoryVaccines")}
                </div>
                <div className="grid gap-2">
                  {result.mandatory.map((v, i) => (
                    <div key={i} className="rounded-lg border border-destructive/30 bg-destructive/5 p-3">
                      <div className="flex items-start justify-between">
                        <div>
                          <span className="font-medium">{v.name}</span>
                          <Badge variant="destructive" className="ml-2 text-xs">{t("vaccinations.mandatory")}</Badge>
                        </div>
                        <span className="text-sm text-muted-foreground">{v.doses} {t("vaccinations.doseUnit")}</span>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">{v.reason}</p>
                      <p className="text-sm mt-1">⏱ {v.timing}</p>
                      {v.notes && <p className="text-xs text-muted-foreground mt-1">{v.notes}</p>}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Recommended */}
            {result.recommended.length > 0 && (
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-primary font-medium">
                  <CheckCircle className="h-4 w-4" />
                  {t("vaccinations.recommendedVaccines")}
                </div>
                <div className="grid gap-2">
                  {result.recommended.map((v, i) => (
                    <div key={i} className="rounded-lg border p-3">
                      <div className="flex items-start justify-between">
                        <div>
                          <span className="font-medium">{v.name}</span>
                          <Badge variant="secondary" className="ml-2 text-xs">{t("vaccinations.recommendedLabel")}</Badge>
                        </div>
                        <span className="text-sm text-muted-foreground">{v.doses} {t("vaccinations.doseUnit")}</span>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">{v.reason}</p>
                      <p className="text-sm mt-1">⏱ {v.timing}</p>
                      {v.notes && <p className="text-xs text-muted-foreground mt-1">{v.notes}</p>}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Skippable */}
            {result.skippable && result.skippable.length > 0 && (
              <div className="rounded-lg bg-muted/50 p-3">
                <p className="text-sm font-medium">{t("vaccinations.alreadyHave")}:</p>
                <div className="flex flex-wrap gap-1 mt-1">
                  {result.skippable.map((v, i) => (
                    <Badge key={i} variant="outline" className="text-xs">{v} ✓</Badge>
                  ))}
                </div>
              </div>
            )}

            {/* Malaria */}
            {result.malariaRisk !== "none" && (
              <div className="rounded-lg border border-destructive/30 bg-destructive/5 p-3">
                <div className="flex items-center gap-2">
                  <Bug className="h-4 w-4 text-destructive" />
                  <span className="font-medium">{t("vaccinations.malariaRisk")}</span>
                  <Badge variant={malariaColor(result.malariaRisk)}>{result.malariaRisk}</Badge>
                </div>
                {result.malariaAdvice && <p className="text-sm text-muted-foreground mt-1">{result.malariaAdvice}</p>}
              </div>
            )}

            {/* General advice */}
            <div className="rounded-lg bg-muted/50 p-3">
              <div className="flex items-center gap-2 mb-1">
                <AlertTriangle className="h-4 w-4 text-primary" />
                <span className="font-medium text-sm">{t("vaccinations.generalAdvice")}</span>
              </div>
              <p className="text-sm text-muted-foreground">{result.generalAdvice}</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
