import { useState, useRef, useCallback, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Mic, MicOff, Save, AlertTriangle } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

interface NoiseMeterProps {
  riskAssessmentId: string | null;
  workplaceId?: string;
}

// Hungarian OEL thresholds (MSZ EN ISO 9612)
const THRESHOLDS = {
  lower: 80,   // alsó küszöb – figyelmeztető szint
  upper: 85,   // felső küszöb – intézkedési szint
  peak: 137,   // csúcs dB(C)
};

function getNoiseColor(db: number): string {
  if (db < 70) return "bg-green-500";
  if (db < THRESHOLDS.lower) return "bg-yellow-500";
  if (db < THRESHOLDS.upper) return "bg-orange-500";
  return "bg-red-500";
}

function getNoiseLabel(db: number, t: any): string {
  if (db < 70) return t("measurement.noiseSafe");
  if (db < THRESHOLDS.lower) return t("measurement.noiseModerate");
  if (db < THRESHOLDS.upper) return t("measurement.noiseWarning");
  return t("measurement.noiseDanger");
}

export default function NoiseMeter({ riskAssessmentId, workplaceId }: NoiseMeterProps) {
  const { t } = useTranslation();
  const { user } = useAuth();
  const [measuring, setMeasuring] = useState(false);
  const [measurementType, setMeasurementType] = useState<"noise_room" | "noise_1m">("noise_room");
  const [currentDb, setCurrentDb] = useState(0);
  const [peakDb, setPeakDb] = useState(0);
  const [avgDb, setAvgDb] = useState(0);
  const [minDb, setMinDb] = useState(999);
  const [duration, setDuration] = useState(0);
  const [locationDesc, setLocationDesc] = useState("");
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);
  const [history, setHistory] = useState<number[]>([]);

  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const animFrameRef = useRef<number>(0);
  const startTimeRef = useRef(0);
  const samplesRef = useRef<number[]>([]);

  const stopMeasuring = useCallback(() => {
    setMeasuring(false);
    cancelAnimationFrame(animFrameRef.current);
    streamRef.current?.getTracks().forEach(t => t.stop());
    audioContextRef.current?.close();
    audioContextRef.current = null;

    if (samplesRef.current.length > 0) {
      const avg = samplesRef.current.reduce((a, b) => a + b, 0) / samplesRef.current.length;
      setAvgDb(Math.round(avg * 10) / 10);
      setHistory(samplesRef.current.map(v => Math.round(v)));
    }
  }, []);

  const startMeasuring = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const ctx = new AudioContext();
      audioContextRef.current = ctx;
      const source = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 2048;
      analyser.smoothingTimeConstant = 0.3;
      source.connect(analyser);
      analyserRef.current = analyser;

      setMeasuring(true);
      setPeakDb(0);
      setMinDb(999);
      setAvgDb(0);
      setDuration(0);
      samplesRef.current = [];
      startTimeRef.current = Date.now();

      const dataArray = new Float32Array(analyser.fftSize);

      const measure = () => {
        if (!audioContextRef.current) return;
        analyser.getFloatTimeDomainData(dataArray);

        // Calculate RMS
        let sumSq = 0;
        for (let i = 0; i < dataArray.length; i++) {
          sumSq += dataArray[i] * dataArray[i];
        }
        const rms = Math.sqrt(sumSq / dataArray.length);

        // Convert to dB (reference: 1.0 = 94 dB SPL for typical microphone calibration)
        // This is approximate — phone mics vary. We use a +94 dB offset as a rough calibration.
        const db = Math.max(0, 20 * Math.log10(rms + 1e-10) + 94);
        const roundedDb = Math.round(db * 10) / 10;

        setCurrentDb(roundedDb);
        setPeakDb(prev => Math.max(prev, roundedDb));
        setMinDb(prev => Math.min(prev, roundedDb));
        samplesRef.current.push(roundedDb);

        const elapsed = Math.floor((Date.now() - startTimeRef.current) / 1000);
        setDuration(elapsed);

        animFrameRef.current = requestAnimationFrame(measure);
      };

      measure();
    } catch (err: any) {
      toast.error(t("measurement.micError"));
    }
  }, [t]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      cancelAnimationFrame(animFrameRef.current);
      streamRef.current?.getTracks().forEach(t => t.stop());
      audioContextRef.current?.close();
    };
  }, []);

  const handleSave = async () => {
    if (!riskAssessmentId) {
      toast.error(t("measurement.saveFirstAssessment"));
      return;
    }
    setSaving(true);
    try {
      const { error } = await supabase.from("noise_vibration_measurements").insert({
        risk_assessment_id: riskAssessmentId,
        workplace_id: workplaceId || null,
        measurement_type: measurementType,
        value_db: avgDb,
        peak_value: peakDb,
        duration_seconds: duration,
        frequency_data: history.length > 100
          ? history.filter((_, i) => i % Math.ceil(history.length / 100) === 0)
          : history,
        location_description: locationDesc || null,
        notes: notes || null,
        measured_by: user?.id,
      });
      if (error) throw error;
      toast.success(t("common.saved"));
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setSaving(false);
    }
  };

  const barWidth = Math.min(100, (currentDb / 120) * 100);

  return (
    <Card>
      <CardHeader className="py-3">
        <CardTitle className="text-sm flex items-center gap-2">
          <Mic className="h-4 w-4" />
          {t("measurement.noiseMeter")}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Type selector */}
        <div className="flex gap-3 items-end">
          <div className="flex-1">
            <Label>{t("measurement.measurementType")}</Label>
            <Select value={measurementType} onValueChange={(v: any) => setMeasurementType(v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="noise_room">{t("measurement.noiseRoom")}</SelectItem>
                <SelectItem value="noise_1m">{t("measurement.noise1m")}</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button
            onClick={measuring ? stopMeasuring : startMeasuring}
            variant={measuring ? "destructive" : "default"}
            className="gap-1"
          >
            {measuring ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
            {measuring ? t("measurement.stop") : t("measurement.start")}
          </Button>
        </div>

        {/* Live meter */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="font-mono text-2xl font-bold">{currentDb.toFixed(1)} dB</span>
            <span className="text-muted-foreground">{duration}s</span>
          </div>
          <div className="h-6 bg-muted rounded-full overflow-hidden relative">
            <div
              className={`h-full transition-all duration-100 ${getNoiseColor(currentDb)} rounded-full`}
              style={{ width: `${barWidth}%` }}
            />
            {/* Threshold markers */}
            <div className="absolute top-0 h-full w-px bg-yellow-600" style={{ left: `${(THRESHOLDS.lower / 120) * 100}%` }} />
            <div className="absolute top-0 h-full w-px bg-red-600" style={{ left: `${(THRESHOLDS.upper / 120) * 100}%` }} />
          </div>
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>0 dB</span>
            <span className="text-yellow-600">{THRESHOLDS.lower} dB</span>
            <span className="text-red-600">{THRESHOLDS.upper} dB</span>
            <span>120 dB</span>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-2 text-center">
          <div className="bg-muted p-2 rounded">
            <div className="text-xs text-muted-foreground">{t("measurement.avg")}</div>
            <div className="font-mono font-bold">{avgDb.toFixed(1)}</div>
          </div>
          <div className="bg-muted p-2 rounded">
            <div className="text-xs text-muted-foreground">{t("measurement.peak")}</div>
            <div className="font-mono font-bold">{peakDb.toFixed(1)}</div>
          </div>
          <div className="bg-muted p-2 rounded">
            <div className="text-xs text-muted-foreground">{t("measurement.min")}</div>
            <div className="font-mono font-bold">{minDb < 999 ? minDb.toFixed(1) : "—"}</div>
          </div>
        </div>

        {/* Legal reference */}
        {avgDb > 0 && (
          <div className={`p-3 rounded-lg border ${avgDb >= THRESHOLDS.upper ? "bg-red-50 border-red-200 dark:bg-red-950 dark:border-red-800" : avgDb >= THRESHOLDS.lower ? "bg-yellow-50 border-yellow-200 dark:bg-yellow-950 dark:border-yellow-800" : "bg-green-50 border-green-200 dark:bg-green-950 dark:border-green-800"}`}>
            <div className="flex items-center gap-2">
              {avgDb >= THRESHOLDS.lower && <AlertTriangle className="h-4 w-4" />}
              <Badge variant="outline" className={getNoiseColor(avgDb) + " text-white border-0"}>
                {getNoiseLabel(avgDb, t)}
              </Badge>
            </div>
            <p className="text-xs mt-1 text-muted-foreground">
              {t("measurement.legalRef")} — LEX,8h: {THRESHOLDS.lower}/{THRESHOLDS.upper} dB(A)
            </p>
          </div>
        )}

        {/* History mini chart */}
        {history.length > 0 && (
          <div className="h-16 flex items-end gap-px">
            {history.slice(-100).map((v, i) => (
              <div
                key={i}
                className={`flex-1 min-w-[2px] ${getNoiseColor(v)} rounded-t`}
                style={{ height: `${Math.min(100, (v / 120) * 100)}%` }}
              />
            ))}
          </div>
        )}

        {/* Save section */}
        {avgDb > 0 && !measuring && (
          <div className="space-y-2 border-t pt-3">
            <div>
              <Label>{t("measurement.locationDescription")}</Label>
              <Input value={locationDesc} onChange={e => setLocationDesc(e.target.value)} placeholder={t("measurement.locationPlaceholder")} />
            </div>
            <div>
              <Label>{t("measurement.notes")}</Label>
              <Textarea value={notes} onChange={e => setNotes(e.target.value)} rows={2} />
            </div>
            <Button onClick={handleSave} disabled={saving} className="w-full gap-1">
              <Save className="h-4 w-4" />
              {t("measurement.saveResult")}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
