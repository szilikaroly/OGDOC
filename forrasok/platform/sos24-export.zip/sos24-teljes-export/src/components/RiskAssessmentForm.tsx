import { useState, useEffect, useCallback } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { toast } from "sonner";
import { Loader2, Camera, Sparkles, Printer, Check, X, Mic, Activity } from "lucide-react";
import AiAnalysisPanel from "@/components/AiAnalysisPanel";
import RiskMatrix from "@/components/RiskMatrix";
import HazardousSubstanceSelector from "@/components/HazardousSubstanceSelector";
import NoiseMeter from "@/components/NoiseMeter";
import VibrationMeter from "@/components/VibrationMeter";
import RiskPhotoAnalysis from "@/components/RiskPhotoAnalysis";
import {
  HAZARD_CATALOG, HAZARD_CATEGORIES, HazardCategoryKey,
  getRiskCategory, RISK_MATRIX_COLORS, RISK_CATEGORY_LABELS,
  PROBABILITY_LABELS, SEVERITY_LABELS,
  ACTION_HIERARCHY_LABELS, EXPOSURE_FREQUENCY_OPTIONS, EXPOSURE_DURATION_OPTIONS,
} from "@/lib/hazard-catalog";

interface RiskAssessmentFormProps {
  assessmentId: string | null;
  onClose: () => void;
}

interface HazardEntry {
  catalogId: string;
  enabled: boolean;
  probability: number;
  severity: number;
  exposedCount: number;
  exposureDuration: string;
  exposureFrequency: string;
  currentControls: string;
  requiredActions: string;
  actionResponsible: string;
  actionDeadline: string;
  actionHierarchy: string;
  actionStatus: string;
  residualProbability: number;
  residualSeverity: number;
  substanceIds: string[];
  notes: string;
}

export default function RiskAssessmentForm({ assessmentId, onClose }: RiskAssessmentFormProps) {
  const { t, i18n } = useTranslation();
  const lang = i18n.language === "hu" ? "hu" : "en";
  const { user } = useAuth();
  const qc = useQueryClient();
  const [tab, setTab] = useState("basic");
  const [saving, setSaving] = useState(false);

  // Basic data
  const [companyId, setCompanyId] = useState("");
  const [siteId, setSiteId] = useState("");
  const [workAreaId, setWorkAreaId] = useState("");
  const [title, setTitle] = useState("");
  const [assessmentDate, setAssessmentDate] = useState(new Date().toISOString().slice(0, 10));
  const [assessorName, setAssessorName] = useState("");
  const [assessorQual, setAssessorQual] = useState("");
  const [nextReviewDate, setNextReviewDate] = useState("");
  const [reviewFrequency, setReviewFrequency] = useState(12);
  const [status, setStatus] = useState("draft");
  const [summaryNotes, setSummaryNotes] = useState("");

  // Hazards
  const [hazards, setHazards] = useState<Record<string, HazardEntry>>({});

  // Companies
  const { data: companies = [] } = useQuery({
    queryKey: ["companies"],
    queryFn: async () => {
      const { data } = await supabase.from("companies").select("id, name, industry").order("name");
      return data ?? [];
    },
  });

  // Sites
  const { data: sites = [] } = useQuery({
    queryKey: ["company_sites", companyId],
    queryFn: async () => {
      if (!companyId) return [];
      const { data } = await supabase.from("company_sites").select("*").eq("company_id", companyId).order("name");
      return data ?? [];
    },
    enabled: !!companyId,
  });

  // Work areas
  const { data: workAreas = [] } = useQuery({
    queryKey: ["work_areas_for_site", siteId],
    queryFn: async () => {
      if (!siteId) return [];
      const { data } = await supabase.from("work_areas").select("*").eq("site_id", siteId).order("name");
      return data ?? [];
    },
    enabled: !!siteId,
  });

  // Load existing
  useEffect(() => {
    if (!assessmentId) return;
    (async () => {
      const { data: ra } = await supabase.from("risk_assessments").select("*").eq("id", assessmentId).single();
      if (!ra) return;
      setCompanyId(ra.company_id);
      setTitle(ra.title);
      setAssessmentDate(ra.assessment_date);
      setAssessorName(ra.assessor_name ?? "");
      setAssessorQual(ra.assessor_qualification ?? "");
      setNextReviewDate(ra.next_review_date ?? "");
      setReviewFrequency(ra.review_frequency_months ?? 12);
      setStatus(ra.status);
      setSummaryNotes(ra.summary_notes ?? "");
      setWorkAreaId(ra.work_area_id);

      // Load site from work area
      const { data: wa } = await supabase.from("work_areas").select("site_id").eq("id", ra.work_area_id).single();
      if (wa) setSiteId(wa.site_id);

      // Load hazards
      const { data: existingHazards } = await supabase
        .from("risk_assessment_hazards")
        .select("*")
        .eq("risk_assessment_id", assessmentId)
        .order("sort_order");
      if (existingHazards) {
        const map: Record<string, HazardEntry> = {};
        existingHazards.forEach((h: any) => {
          const catalogItem = HAZARD_CATALOG.find(c =>
            c.name_hu === h.hazard_name || c.name_en === h.hazard_name
          );
          const key = catalogItem?.id ?? h.id;
          map[key] = {
            catalogId: key,
            enabled: true,
            probability: h.probability,
            severity: h.severity,
            exposedCount: h.exposed_count ?? 0,
            exposureDuration: h.exposure_duration ?? "",
            exposureFrequency: h.exposure_frequency ?? "",
            currentControls: h.current_controls ?? "",
            requiredActions: h.required_actions ?? "",
            actionResponsible: h.action_responsible ?? "",
            actionDeadline: h.action_deadline ?? "",
            actionHierarchy: h.action_hierarchy ?? "",
            actionStatus: h.action_status ?? "planned",
            residualProbability: h.residual_probability ?? 1,
            residualSeverity: h.residual_severity ?? 1,
            substanceIds: h.substance_ids ?? [],
            notes: "",
          };
        });
        setHazards(map);
      }
    })();
  }, [assessmentId]);

  // Profile for assessor name
  useEffect(() => {
    if (assessorName || assessmentId) return;
    if (!user) return;
    supabase.from("profiles").select("full_name").eq("user_id", user.id).single().then(({ data }) => {
      if (data?.full_name) setAssessorName(data.full_name);
    });
  }, [user, assessmentId]);

  const toggleHazard = (catalogId: string, checked: boolean) => {
    setHazards(prev => {
      const next = { ...prev };
      if (checked) {
        const item = HAZARD_CATALOG.find(c => c.id === catalogId);
        next[catalogId] = {
          catalogId,
          enabled: true,
          probability: 1,
          severity: item?.default_severity ?? 1,
          exposedCount: 0,
          exposureDuration: "",
          exposureFrequency: "",
          currentControls: "",
          requiredActions: "",
          actionResponsible: "",
          actionDeadline: "",
          actionHierarchy: "",
          actionStatus: "planned",
          residualProbability: 1,
          residualSeverity: 1,
          substanceIds: [],
          notes: "",
        };
      } else {
        delete next[catalogId];
      }
      return next;
    });
  };

  const updateHazard = (catalogId: string, field: keyof HazardEntry, value: any) => {
    setHazards(prev => ({
      ...prev,
      [catalogId]: { ...prev[catalogId], [field]: value },
    }));
  };

  const enabledHazards = Object.values(hazards).filter(h => h.enabled);
  const actionRequired = enabledHazards.filter(h => h.probability * h.severity >= 6);

  const handleSave = async () => {
    if (!companyId || !workAreaId) {
      toast.error(t("common.required"));
      return;
    }
    setSaving(true);
    try {
      let raId = assessmentId;
      const payload = {
        company_id: companyId,
        work_area_id: workAreaId,
        title,
        assessment_date: assessmentDate,
        assessor_name: assessorName,
        assessor_qualification: assessorQual,
        next_review_date: nextReviewDate || null,
        review_frequency_months: reviewFrequency,
        status: status as any,
        summary_notes: summaryNotes || null,
        created_by: user?.id,
      };

      if (raId) {
        const { error } = await supabase.from("risk_assessments").update(payload).eq("id", raId);
        if (error) throw error;
      } else {
        const { data, error } = await supabase.from("risk_assessments").insert(payload).select("id").single();
        if (error) throw error;
        raId = data.id;
      }

      // Delete existing hazards, re-insert
      await supabase.from("risk_assessment_hazards").delete().eq("risk_assessment_id", raId!);

      const hazardRows = enabledHazards.map((h, i) => {
        const catalogItem = HAZARD_CATALOG.find(c => c.id === h.catalogId);
        return {
          risk_assessment_id: raId!,
          hazard_category: (catalogItem?.category ?? "other") as any,
          hazard_subcategory: catalogItem?.subcategory ?? null,
          hazard_name: lang === "hu" ? (catalogItem?.name_hu ?? h.catalogId) : (catalogItem?.name_en ?? h.catalogId),
          probability: h.probability,
          severity: h.severity,
          exposed_count: h.exposedCount,
          exposure_duration: h.exposureDuration || null,
          exposure_frequency: h.exposureFrequency || null,
          current_controls: h.currentControls || null,
          required_actions: h.requiredActions || null,
          action_responsible: h.actionResponsible || null,
          action_deadline: h.actionDeadline || null,
          action_hierarchy: (h.actionHierarchy || null) as any,
          action_status: (h.actionStatus || "planned") as any,
          residual_probability: h.residualProbability || null,
          residual_severity: h.residualSeverity || null,
          substance_ids: h.substanceIds,
          sort_order: i,
        };
      });

      if (hazardRows.length > 0) {
        const { error } = await supabase.from("risk_assessment_hazards").insert(hazardRows);
        if (error) throw error;
      }

      toast.success(t("common.saved"));
      onClose();
    } catch (e: any) {
      toast.error(e.message ?? "Hiba");
    } finally {
      setSaving(false);
    }
  };

  const categories = Object.keys(HAZARD_CATEGORIES) as HazardCategoryKey[];

  return (
    <div className="space-y-4">
      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="flex flex-wrap">
          <TabsTrigger value="basic">{t("risk.basicData")}</TabsTrigger>
          <TabsTrigger value="hazards">{t("risk.hazardIdentification")}</TabsTrigger>
          <TabsTrigger value="evaluation">{t("risk.riskEvaluation")}</TabsTrigger>
          <TabsTrigger value="actions">{t("risk.actionPlan")}</TabsTrigger>
          <TabsTrigger value="measurements" className="gap-1">
            <Mic className="h-3 w-3" />
            {t("measurement.measurements")}
          </TabsTrigger>
          <TabsTrigger value="summary">{t("risk.summary")}</TabsTrigger>
        </TabsList>

        {/* === BASIC DATA === */}
        <TabsContent value="basic" className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>{t("risk.company")}</Label>
              <Select value={companyId} onValueChange={v => { setCompanyId(v); setSiteId(""); setWorkAreaId(""); }}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {companies.map((c: any) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>{t("risk.site")}</Label>
              <Select value={siteId} onValueChange={v => { setSiteId(v); setWorkAreaId(""); }} disabled={!companyId}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {sites.map((s: any) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>{t("risk.workArea")}</Label>
              <Select value={workAreaId} onValueChange={setWorkAreaId} disabled={!siteId}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {workAreas.map((wa: any) => <SelectItem key={wa.id} value={wa.id}>{wa.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>{t("risk.assessmentDate")}</Label>
              <Input type="date" value={assessmentDate} onChange={e => setAssessmentDate(e.target.value)} />
            </div>
            <div>
              <Label>{t("risk.assessorName")}</Label>
              <Input value={assessorName} onChange={e => setAssessorName(e.target.value)} />
            </div>
            <div>
              <Label>{t("risk.assessorQualification")}</Label>
              <Input value={assessorQual} onChange={e => setAssessorQual(e.target.value)} />
            </div>
            <div>
              <Label>{t("risk.nextReviewDate")}</Label>
              <Input type="date" value={nextReviewDate} onChange={e => setNextReviewDate(e.target.value)} />
            </div>
            <div>
              <Label>{t("risk.reviewFrequency")}</Label>
              <Input type="number" value={reviewFrequency} onChange={e => setReviewFrequency(Number(e.target.value))} />
            </div>
          </div>
          <div>
            <Label>{t("risk.status")}</Label>
            <Select value={status} onValueChange={setStatus}>
              <SelectTrigger className="w-[200px]"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="draft">{t("risk.statusDraft")}</SelectItem>
                <SelectItem value="in_review">{t("risk.statusInReview")}</SelectItem>
                <SelectItem value="approved">{t("risk.statusApproved")}</SelectItem>
                <SelectItem value="archived">{t("risk.statusArchived")}</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </TabsContent>

        {/* === HAZARD IDENTIFICATION === */}
        <TabsContent value="hazards" className="space-y-4">
          {/* Photo Analysis */}
          <RiskPhotoAnalysis
            assessmentId={assessmentId}
            workAreaId={workAreaId}
            onAdoptHazards={(adopted) => {
              adopted.forEach(h => {
                // Try to match catalog item
                const match = HAZARD_CATALOG.find(c => c.id === h.catalogMatch);
                if (match && !hazards[match.id]) {
                  toggleHazard(match.id, true);
                  // Update severity/probability from AI
                  setTimeout(() => {
                    updateHazard(match.id, "severity", h.severity);
                    updateHazard(match.id, "probability", h.probability);
                    if (h.description) updateHazard(match.id, "notes", h.description);
                  }, 0);
                }
              });
            }}
          />

          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground">{t("risk.selectHazards")}</p>
            <AiAnalysisPanel
              type="risk_assessment_hazards"
              title={lang === "hu" ? "AI veszélyforrás-javaslat" : "AI Hazard Suggestions"}
              buttonLabel={lang === "hu" ? "AI javaslat" : "AI Suggest"}
              data={{
                companyName: companies.find((c: any) => c.id === companyId)?.name,
                siteName: sites.find((s: any) => s.id === siteId)?.name,
                workAreaName: workAreas.find((wa: any) => wa.id === workAreaId)?.name,
                industry: companies.find((c: any) => c.id === companyId)?.industry,
                selectedHazards: enabledHazards.map(h => {
                  const item = HAZARD_CATALOG.find(c => c.id === h.catalogId);
                  return {
                    name: item?.[lang === "hu" ? "name_hu" : "name_en"] ?? h.catalogId,
                    category: item?.category,
                    severity: h.severity,
                  };
                }),
              }}
            />
          </div>
          <Accordion type="multiple" className="space-y-2">
            {categories.map(cat => {
              const catInfo = HAZARD_CATEGORIES[cat];
              const items = HAZARD_CATALOG.filter(h => h.category === cat);
              const selected = items.filter(h => !!hazards[h.id]);
              return (
                <AccordionItem key={cat} value={cat} className="border rounded-lg px-4">
                  <AccordionTrigger className="hover:no-underline">
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{catInfo[lang]}</span>
                      {selected.length > 0 && (
                        <Badge variant="secondary" className="text-xs">{selected.length}</Badge>
                      )}
                    </div>
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-2">
                      {items.map(item => (
                        <div key={item.id} className="flex items-start gap-2 py-1">
                          <Checkbox
                            checked={!!hazards[item.id]}
                            onCheckedChange={checked => toggleHazard(item.id, !!checked)}
                          />
                          <div className="flex-1">
                            <span className="text-sm">{item[lang === "hu" ? "name_hu" : "name_en"]}</span>
                            {item.monitoring && (
                              <span className="text-xs text-muted-foreground ml-2">📊 {item.monitoring}</span>
                            )}
                            {item.ppe && (
                              <span className="text-xs text-muted-foreground ml-2">🦺 {item.ppe}</span>
                            )}
                          </div>
                          <Badge variant="outline" className="text-xs">S:{item.default_severity}</Badge>
                        </div>
                      ))}
                    </div>
                  </AccordionContent>
                </AccordionItem>
              );
            })}
          </Accordion>

          {/* Chemical hazards: substance selector */}
          {companyId && enabledHazards.some(h => {
            const cat = HAZARD_CATALOG.find(c => c.id === h.catalogId);
            return cat?.category === "chemical";
          }) && (
            <Card>
              <CardHeader className="py-3">
                <CardTitle className="text-sm">{t("risk.substances")}</CardTitle>
              </CardHeader>
              <CardContent>
                <HazardousSubstanceSelector companyId={companyId} />
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* === RISK EVALUATION === */}
        <TabsContent value="evaluation" className="space-y-4">
          <RiskMatrix />
          {enabledHazards.length === 0 ? (
            <p className="text-muted-foreground text-sm">{t("risk.selectHazards")}</p>
          ) : (
            <div className="space-y-3">
              {enabledHazards.map(h => {
                const item = HAZARD_CATALOG.find(c => c.id === h.catalogId);
                const riskCat = getRiskCategory(h.probability, h.severity);
                return (
                  <Card key={h.catalogId}>
                    <CardContent className="py-3 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-sm">{item?.[lang === "hu" ? "name_hu" : "name_en"]}</span>
                        <Badge className={RISK_MATRIX_COLORS[riskCat]}>
                          {h.probability * h.severity} — {RISK_CATEGORY_LABELS[riskCat]?.[lang]}
                        </Badge>
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                        <div>
                          <Label className="text-xs">{t("risk.probability")}</Label>
                          <Select value={String(h.probability)} onValueChange={v => updateHazard(h.catalogId, "probability", Number(v))}>
                            <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                            <SelectContent>
                              {[1, 2, 3, 4].map(n => (
                                <SelectItem key={n} value={String(n)}>{n} — {PROBABILITY_LABELS[n as 1][lang]}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label className="text-xs">{t("risk.severity")}</Label>
                          <Select value={String(h.severity)} onValueChange={v => updateHazard(h.catalogId, "severity", Number(v))}>
                            <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                            <SelectContent>
                              {[1, 2, 3, 4].map(n => (
                                <SelectItem key={n} value={String(n)}>{n} — {SEVERITY_LABELS[n as 1][lang]}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label className="text-xs">{t("risk.exposedCount")}</Label>
                          <Input type="number" className="h-8 text-xs" value={h.exposedCount} onChange={e => updateHazard(h.catalogId, "exposedCount", Number(e.target.value))} />
                        </div>
                        <div>
                          <Label className="text-xs">{t("risk.exposureFrequency")}</Label>
                          <Select value={h.exposureFrequency} onValueChange={v => updateHazard(h.catalogId, "exposureFrequency", v)}>
                            <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                            <SelectContent>
                              {EXPOSURE_FREQUENCY_OPTIONS.map(o => (
                                <SelectItem key={o.value} value={o.value}>{o[lang]}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div>
                        <Label className="text-xs">{t("risk.currentControls")}</Label>
                        <Input className="h-8 text-xs" value={h.currentControls} onChange={e => updateHazard(h.catalogId, "currentControls", e.target.value)} />
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>

        {/* === ACTION PLAN === */}
        <TabsContent value="actions" className="space-y-4">
          <div className="flex items-center justify-between">
            <span />
            <AiAnalysisPanel
              type="risk_assessment_actions"
              title={lang === "hu" ? "AI intézkedési terv javaslat" : "AI Action Plan Suggestions"}
              buttonLabel={lang === "hu" ? "AI intézkedési terv" : "AI Action Plan"}
              data={{
                companyName: companies.find((c: any) => c.id === companyId)?.name,
                workAreaName: workAreas.find((wa: any) => wa.id === workAreaId)?.name,
                hazards: enabledHazards.map(h => {
                  const item = HAZARD_CATALOG.find(c => c.id === h.catalogId);
                  return {
                    name: item?.[lang === "hu" ? "name_hu" : "name_en"] ?? h.catalogId,
                    category: item?.category,
                    probability: h.probability,
                    severity: h.severity,
                    currentControls: h.currentControls,
                    requiredActions: h.requiredActions,
                  };
                }),
              }}
            />
          </div>
          {actionRequired.length === 0 ? (
            <p className="text-muted-foreground text-sm">
              {enabledHazards.length === 0 ? t("risk.selectHazards") : "Nincs 6-os vagy magasabb kockázatú tétel."}
            </p>
          ) : (
            <div className="space-y-3">
              {actionRequired.map(h => {
                const item = HAZARD_CATALOG.find(c => c.id === h.catalogId);
                const riskCat = getRiskCategory(h.probability, h.severity);
                return (
                  <Card key={h.catalogId}>
                    <CardContent className="py-3 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-sm">{item?.[lang === "hu" ? "name_hu" : "name_en"]}</span>
                        <Badge className={RISK_MATRIX_COLORS[riskCat]}>{h.probability * h.severity}</Badge>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <Label className="text-xs">{t("risk.requiredActions")}</Label>
                          <Textarea className="text-xs min-h-[60px]" value={h.requiredActions} onChange={e => updateHazard(h.catalogId, "requiredActions", e.target.value)} />
                        </div>
                        <div className="space-y-2">
                          <div>
                            <Label className="text-xs">{t("risk.actionHierarchy")}</Label>
                            <Select value={h.actionHierarchy} onValueChange={v => updateHazard(h.catalogId, "actionHierarchy", v)}>
                              <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                              <SelectContent>
                                {Object.entries(ACTION_HIERARCHY_LABELS).map(([k, v]) => (
                                  <SelectItem key={k} value={k}>{v[lang]}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <Label className="text-xs">{t("risk.actionResponsible")}</Label>
                            <Input className="h-8 text-xs" value={h.actionResponsible} onChange={e => updateHazard(h.catalogId, "actionResponsible", e.target.value)} />
                          </div>
                          <div>
                            <Label className="text-xs">{t("risk.actionDeadline")}</Label>
                            <Input type="date" className="h-8 text-xs" value={h.actionDeadline} onChange={e => updateHazard(h.catalogId, "actionDeadline", e.target.value)} />
                          </div>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <Label className="text-xs">{t("risk.residualRisk")}: {t("risk.probability")}</Label>
                          <Select value={String(h.residualProbability)} onValueChange={v => updateHazard(h.catalogId, "residualProbability", Number(v))}>
                            <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                            <SelectContent>
                              {[1, 2, 3, 4].map(n => <SelectItem key={n} value={String(n)}>{n}</SelectItem>)}
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label className="text-xs">{t("risk.residualRisk")}: {t("risk.severity")}</Label>
                          <Select value={String(h.residualSeverity)} onValueChange={v => updateHazard(h.catalogId, "residualSeverity", Number(v))}>
                            <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                            <SelectContent>
                              {[1, 2, 3, 4].map(n => <SelectItem key={n} value={String(n)}>{n}</SelectItem>)}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>

        {/* === MEASUREMENTS === */}
        <TabsContent value="measurements" className="space-y-4">
          {!assessmentId && (
            <Card>
              <CardContent className="py-6 text-center text-muted-foreground">
                <p>{t("measurement.saveFirstAssessment")}</p>
              </CardContent>
            </Card>
          )}
          <div className="grid md:grid-cols-2 gap-4">
            <NoiseMeter riskAssessmentId={assessmentId} workplaceId={undefined} />
            <VibrationMeter riskAssessmentId={assessmentId} workplaceId={undefined} />
          </div>
        </TabsContent>

        {/* === SUMMARY === */}
        <TabsContent value="summary" className="space-y-4">
          <Card>
            <CardContent className="py-4 space-y-3">
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <p className="text-2xl font-bold">{enabledHazards.length}</p>
                  <p className="text-xs text-muted-foreground">{t("risk.hazardIdentification")}</p>
                </div>
                <div>
                  <p className="text-2xl font-bold text-destructive">{actionRequired.length}</p>
                  <p className="text-xs text-muted-foreground">{t("risk.actionPlan")}</p>
                </div>
                <div>
                  <p className="text-2xl font-bold">{enabledHazards.filter(h => h.probability * h.severity <= 4).length}</p>
                  <p className="text-xs text-muted-foreground">{t("risk.tolerable")}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <div>
            <Label>{t("risk.summaryNotes")}</Label>
            <Textarea value={summaryNotes} onChange={e => setSummaryNotes(e.target.value)} className="min-h-[100px]" />
          </div>

          <AiAnalysisPanel
            type="risk_assessment_summary"
            title={lang === "hu" ? "AI összefoglaló jelentés" : "AI Summary Report"}
            buttonLabel={lang === "hu" ? "AI összefoglaló" : "AI Summary"}
            variant="default"
            data={{
              companyName: companies.find((c: any) => c.id === companyId)?.name,
              siteName: sites.find((s: any) => s.id === siteId)?.name,
              workAreaName: workAreas.find((wa: any) => wa.id === workAreaId)?.name,
              assessorName,
              assessmentDate,
              totalHazards: enabledHazards.length,
              highRiskCount: actionRequired.length,
              tolerableCount: enabledHazards.filter(h => h.probability * h.severity <= 4).length,
              summaryNotes,
              hazards: enabledHazards.map(h => {
                const item = HAZARD_CATALOG.find(c => c.id === h.catalogId);
                return {
                  name: item?.[lang === "hu" ? "name_hu" : "name_en"] ?? h.catalogId,
                  category: item?.category,
                  probability: h.probability,
                  severity: h.severity,
                  currentControls: h.currentControls,
                  requiredActions: h.requiredActions,
                  residualProbability: h.residualProbability,
                  residualSeverity: h.residualSeverity,
                };
              }),
            }}
          />

          <div className="flex gap-2">
            <Button onClick={() => window.print()} variant="outline">
              <Printer className="h-4 w-4 mr-1" />
              {t("risk.printAssessment")}
            </Button>
          </div>
        </TabsContent>
      </Tabs>

      {/* Save / Cancel */}
      <div className="flex justify-end gap-2 pt-4 border-t">
        <Button variant="outline" onClick={onClose}>{t("common.cancel")}</Button>
        <Button onClick={handleSave} disabled={saving}>
          {saving && <Loader2 className="h-4 w-4 mr-1 animate-spin" />}
          {t("common.save")}
        </Button>
      </div>
    </div>
  );
}
