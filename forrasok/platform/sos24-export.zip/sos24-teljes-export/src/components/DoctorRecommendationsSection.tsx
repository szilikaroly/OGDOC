import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Stethoscope, Salad, ArrowLeft, Printer } from "lucide-react";
import ReactMarkdown from "react-markdown";
import { format } from "date-fns";
import { hu } from "date-fns/locale";
import { useState } from "react";

export default function DoctorRecommendationsSection() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const qc = useQueryClient();
  const [viewingRec, setViewingRec] = useState<any>(null);

  const { data: recommendations } = useQuery({
    queryKey: ["my-doctor-recommendations", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase.from("doctor_recommendations").select("*").eq("patient_id", user!.id).order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  const markRead = useMutation({
    mutationFn: async (id: string) => { await supabase.from("doctor_recommendations").update({ is_read: true }).eq("id", id); },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["my-doctor-recommendations"] }),
  });

  const unreadCount = (recommendations ?? []).filter((r: any) => !r.is_read).length;

  if (viewingRec) {
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-2 print:hidden">
          <Button variant="ghost" size="sm" onClick={() => setViewingRec(null)}>
            <ArrowLeft className="h-4 w-4 mr-1" /> {t("common.back")}
          </Button>
          <h3 className="font-semibold">{viewingRec.title}</h3>
          <Button variant="outline" size="sm" onClick={() => window.print()} className="ml-auto">
            <Printer className="h-4 w-4 mr-1" /> {t("common.print")}
          </Button>
        </div>
        <Badge variant="secondary" className="text-xs print:hidden">
          {format(new Date(viewingRec.created_at), "yyyy. MMMM d. HH:mm", { locale: hu })}
        </Badge>
        <Card className="print:shadow-none print:border-none">
          <CardContent className="pt-6 prose prose-sm max-w-none dark:prose-invert print:prose-headings:text-black print:prose-p:text-black">
            <ReactMarkdown>{viewingRec.plan_markdown}</ReactMarkdown>
          </CardContent>
        </Card>
        <p className="text-xs text-muted-foreground text-center italic print:text-black">
          {t("doctorRecs.disclaimer")}
        </p>
      </div>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          <Stethoscope className="h-5 w-5 text-blue-500" />
          {t("doctorRecs.title")}
          {unreadCount > 0 && <Badge variant="destructive" className="text-xs">{t("doctorRecs.newCount", { count: unreadCount })}</Badge>}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {(recommendations ?? []).length === 0 ? (
          <p className="text-sm text-muted-foreground">{t("doctorRecs.noRecommendation")}</p>
        ) : (
          <div className="space-y-2">
            {recommendations!.map((rec: any) => (
              <button key={rec.id} onClick={() => { setViewingRec(rec); if (!rec.is_read) markRead.mutate(rec.id); }}
                className="w-full flex items-center justify-between p-3 rounded-lg border hover:bg-muted/50 transition-colors text-left">
                <div className="flex items-center gap-3">
                  {rec.type === "screening_plan" ? <Stethoscope className="h-4 w-4 text-blue-500" /> : <Salad className="h-4 w-4 text-green-500" />}
                  <div>
                    <p className="text-sm font-medium">{rec.title}</p>
                    <p className="text-xs text-muted-foreground">{format(new Date(rec.created_at), "yyyy. MMMM d. HH:mm", { locale: hu })}</p>
                  </div>
                </div>
                <Badge variant={rec.is_read ? "secondary" : "default"} className="text-xs">{rec.is_read ? t("doctorRecs.read") : t("doctorRecs.new")}</Badge>
              </button>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
