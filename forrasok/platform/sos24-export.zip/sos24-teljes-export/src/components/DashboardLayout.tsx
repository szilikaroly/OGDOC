import { Outlet, useNavigate } from "react-router-dom";
import { useAuth, type AppRole } from "@/contexts/AuthContext";
import { useSiteSettings } from "@/hooks/use-cms";
import { NavLink } from "@/components/NavLink";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
  useSidebar,
} from "@/components/ui/sidebar";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { LogOut, User, ChevronDown, Check } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { useUnreadMessages } from "@/hooks/use-unread-messages";
import { Badge } from "@/components/ui/badge";
import NotificationBell from "@/components/NotificationBell";
import LanguageSwitcher from "@/components/LanguageSwitcher";
import { useTranslation } from "react-i18next";

export interface NavItem {
  title: string;
  url: string;
  icon: LucideIcon;
  badge?: number;
}

interface DashboardLayoutProps {
  navItems: NavItem[];
  groupLabel: string;
}

function DashboardSidebar({ navItems, groupLabel }: DashboardLayoutProps) {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const { data: settings } = useSiteSettings();

  return (
    <Sidebar collapsible="icon" className="border-r border-sidebar-border">
      <div className="flex h-14 items-center border-b border-sidebar-border px-4">
        {!collapsed && (
          <span className="font-display text-sm font-bold text-gradient-gold truncate">
            {settings?.site_name}
          </span>
        )}
      </div>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>{groupLabel}</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {navItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <NavLink
                      to={item.url}
                      end
                      className="hover:bg-sidebar-accent/50"
                      activeClassName="bg-sidebar-accent text-sidebar-primary font-medium"
                    >
                      <item.icon className="mr-2 h-4 w-4 shrink-0" />
                      {!collapsed && <span className="flex-1">{item.title}</span>}
                      {!collapsed && item.badge != null && item.badge > 0 && (
                        <Badge variant="destructive" className="ml-auto h-5 min-w-5 px-1 text-[10px] justify-center">
                          {item.badge > 99 ? "99+" : item.badge}
                        </Badge>
                      )}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}

const ROLE_REDIRECTS: Record<AppRole, string> = {
  super_admin: "/admin",
  haziorvos: "/haziorvos",
  uzemorvos: "/uzemorvos",
  munkaltato: "/munkaltato",
  munkavallalo: "/munkavallalo",
  praxistag: "/praxistag",
};

export default function DashboardLayout({ navItems, groupLabel }: DashboardLayoutProps) {
  const { profile, roles, activeRole, setActiveRole, signOut } = useAuth();
  const navigate = useNavigate();
  const { t } = useTranslation();
  const initials = (profile?.full_name ?? "?")
    .split(" ")
    .map((n) => n[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

  const handleRoleSwitch = (role: AppRole) => {
    setActiveRole(role);
    navigate(ROLE_REDIRECTS[role] ?? "/", { replace: true });
  };

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <DashboardSidebar navItems={navItems} groupLabel={groupLabel} />
        <div className="flex-1 flex flex-col min-w-0">
          <header className="sticky top-0 z-30 flex h-14 items-center gap-4 border-b border-border bg-card px-4">
            <SidebarTrigger />
            <div className="flex-1" />

            <NotificationBell />
            <LanguageSwitcher />

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="gap-2 px-2">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback className="bg-secondary text-secondary-foreground text-xs">
                      {initials}
                    </AvatarFallback>
                  </Avatar>
                  <div className="hidden md:flex flex-col items-start text-xs">
                    <span className="font-medium text-foreground">{profile?.full_name}</span>
                    <span className="text-muted-foreground">
                      {activeRole ? t(`roles.${activeRole}`) : ""}
                    </span>
                  </div>
                  <ChevronDown className="h-4 w-4 text-muted-foreground" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                {roles.length > 1 && (
                  <>
                    <div className="px-2 py-1.5 text-xs font-semibold text-muted-foreground">
                      {t('nav.menu')}
                    </div>
                    {roles.map((role) => (
                      <DropdownMenuItem
                        key={role}
                        onClick={() => handleRoleSwitch(role)}
                        className={activeRole === role ? "bg-accent font-medium" : ""}
                      >
                        {activeRole === role ? (
                          <Check className="mr-2 h-4 w-4 text-primary" />
                        ) : (
                          <User className="mr-2 h-4 w-4" />
                        )}
                        {t(`roles.${role}`)}
                      </DropdownMenuItem>
                    ))}
                    <DropdownMenuSeparator />
                  </>
                )}
                <DropdownMenuItem
                  onClick={() => signOut().then(() => navigate("/login", { replace: true }))}
                  className="text-destructive focus:text-destructive"
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  {t('nav.logout')}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </header>

          <main className="flex-1 p-3 sm:p-6 safe-bottom">
            <Outlet />
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
