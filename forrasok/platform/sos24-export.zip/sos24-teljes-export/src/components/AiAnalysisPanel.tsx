import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Sparkles, Loader2, X } from "lucide-react";
import { toast } from "sonner";
import ReactMarkdown from "react-markdown";

interface AiAnalysisPanelProps {
  type: "risk_analysis" | "employer_summary" | "questionnaire_recommend" | "anomaly_detection" | "risk_assessment_hazards" | "risk_assessment_actions" | "risk_assessment_summary";
  data: any;
  title: string;
  buttonLabel?: string;
  variant?: "default" | "outline" | "secondary";
}

const TYPE_ICONS: Record<string, string> = {
  risk_analysis: "🔬",
  employer_summary: "📊",
  questionnaire_recommend: "📋",
  anomaly_detection: "📈",
  risk_assessment_hazards: "⚠️",
  risk_assessment_actions: "🛡️",
  risk_assessment_summary: "📝",
};

export default function AiAnalysisPanel({
  type,
  data,
  title,
  buttonLabel = "AI elemzés",
  variant = "outline",
}: AiAnalysisPanelProps) {
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);

  const runAnalysis = async () => {
    setLoading(true);
    setOpen(true);
    try {
      const { data: result, error } = await supabase.functions.invoke("ai-analysis", {
        body: { type, data },
      });
      if (error) throw error;
      if (result?.error) throw new Error(result.error);
      setAnalysis(result.analysis);
    } catch (e: any) {
      toast.error("AI elemzési hiba", { description: e.message });
      setAnalysis(null);
    } finally {
      setLoading(false);
    }
  };

  if (!open) {
    return (
      <Button size="sm" variant={variant} onClick={runAnalysis} disabled={loading}>
        {loading ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <Sparkles className="h-4 w-4 mr-1" />}
        {buttonLabel}
      </Button>
    );
  }

  return (
    <Card className="border-secondary/30 bg-secondary/5">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <span>{TYPE_ICONS[type]}</span>
            {title}
          </CardTitle>
          <Button size="icon" variant="ghost" onClick={() => { setOpen(false); setAnalysis(null); }}>
            <X className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="flex items-center gap-3 py-6">
            <Loader2 className="h-5 w-5 animate-spin text-secondary" />
            <span className="text-sm text-muted-foreground">AI elemzés folyamatban...</span>
          </div>
        ) : analysis ? (
          <div className="prose prose-sm max-w-none dark:prose-invert">
            <ReactMarkdown>{analysis}</ReactMarkdown>
          </div>
        ) : (
          <p className="text-sm text-muted-foreground">Nem sikerült az elemzés</p>
        )}
      </CardContent>
    </Card>
  );
}
