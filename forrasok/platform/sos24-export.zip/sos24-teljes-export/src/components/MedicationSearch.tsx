import { useState, useCallback, useRef, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { X, Search, Pill } from "lucide-react";
import { cn } from "@/lib/utils";

interface MedicationSearchProps {
  onSelect: (name: string) => void;
  placeholder?: string;
  multiple?: boolean;
  selectedItems?: string[];
  onRemove?: (name: string) => void;
  className?: string;
}

export default function MedicationSearch({
  onSelect,
  placeholder,
  multiple = false,
  selectedItems = [],
  onRemove,
  className,
}: MedicationSearchProps) {
  const { t } = useTranslation();
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<string[]>([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const debounceRef = useRef<ReturnType<typeof setTimeout>>();
  const containerRef = useRef<HTMLDivElement>(null);

  const search = useCallback(async (q: string) => {
    if (q.length < 2) {
      setResults([]);
      return;
    }
    setLoading(true);
    const { data } = await supabase
      .from("medications")
      .select("name")
      .ilike("name", `%${q}%`)
      .limit(20);
    setResults((data ?? []).map((d) => d.name));
    setLoading(false);
  }, []);

  const handleChange = (value: string) => {
    setQuery(value);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => search(value), 300);
    setOpen(true);
  };

  const handleSelect = (name: string) => {
    onSelect(name);
    if (!multiple) {
      setQuery("");
      setOpen(false);
      setResults([]);
    }
  };

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  return (
    <div ref={containerRef} className={cn("relative", className)}>
      {multiple && selectedItems.length > 0 && (
        <div className="flex flex-wrap gap-1 mb-2">
          {selectedItems.map((item) => (
            <Badge key={item} variant="secondary" className="gap-1">
              <Pill className="h-3 w-3" />
              {item}
              {onRemove && (
                <button onClick={() => onRemove(item)} className="ml-1 hover:text-destructive">
                  <X className="h-3 w-3" />
                </button>
              )}
            </Badge>
          ))}
        </div>
      )}
      <div className="relative">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          value={query}
          onChange={(e) => handleChange(e.target.value)}
          onFocus={() => query.length >= 2 && setOpen(true)}
          placeholder={placeholder || t("medication.searchPlaceholder")}
          className="pl-9"
        />
      </div>
      {open && (results.length > 0 || loading) && (
        <div className="absolute z-50 mt-1 w-full rounded-md border bg-popover shadow-lg max-h-60 overflow-y-auto">
          {loading && (
            <div className="px-3 py-2 text-sm text-muted-foreground">{t("medication.searching")}</div>
          )}
          {results.map((name) => (
            <button
              key={name}
              type="button"
              onClick={() => handleSelect(name)}
              className={cn(
                "w-full text-left px-3 py-2 text-sm hover:bg-accent hover:text-accent-foreground transition-colors",
                selectedItems.includes(name) && "bg-accent/50"
              )}
            >
              <Pill className="inline h-3 w-3 mr-2 text-muted-foreground" />
              {name}
            </button>
          ))}
          {!loading && results.length === 0 && query.length >= 2 && (
            <div className="px-3 py-2 text-sm text-muted-foreground">{t("medication.noResults")}</div>
          )}
        </div>
      )}
    </div>
  );
}