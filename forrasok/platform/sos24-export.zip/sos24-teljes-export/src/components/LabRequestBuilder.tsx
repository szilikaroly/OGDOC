import { useState, useEffect, useMemo } from 'react';
import { useLabPackages } from '@/hooks/use-lab-packages';
import { useLabPricing, calculateDisplayPrice } from '@/hooks/use-lab-pricing';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Search, FlaskConical, Plus, Calendar, FileText, Download,
  RefreshCw, CheckCircle, Clock, AlertTriangle, XCircle,
  Trash2, ChevronDown, ChevronUp, User, BarChart2,
} from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
} from 'recharts';
import { LAB_TEST_CATALOG, SPECIALTIES, SAMPLE_TYPES, type LabTest } from '@/lib/labTestCatalog';
import { printLabRequest } from '@/lib/printLabRequest';

interface LabRequest {
  id: string;
  request_number: string;
  patient_id: string;
  physician_id: string;
  requested_tests: LabTest[];
  priority: 'routine' | 'urgent' | 'stat';
  scheduled_date: string | null;
  notes: string | null;
  cost_bearer: string | null;
  status: string;
  created_at: string;
  patient_name?: string;
}

interface Patient {
  user_id: string;
  full_name: string;
  birth_date?: string | null;
  taj_number?: string | null;
  address?: string | null;
  mother_name?: string | null;
  gender?: string | null;
  phone?: string | null;
}

interface Props {
  prefillPatientId?: string;
  prefillPatientName?: string;
  onClose?: () => void;
}

const statusConfig: Record<string, { label: string; color: string; icon: React.ReactNode }> = {
  pending:   { label: 'Függőben', color: 'bg-secondary text-muted-foreground border-border', icon: <Clock className="w-3 h-3" /> },
  sent:      { label: 'Elküldve', color: 'bg-primary/15 text-primary border-primary/30', icon: <CheckCircle className="w-3 h-3" /> },
  partial:   { label: 'Részleges', color: 'bg-yellow-500/15 text-yellow-700 border-yellow-500/30', icon: <AlertTriangle className="w-3 h-3" /> },
  completed: { label: 'Kész', color: 'bg-primary/20 text-primary border-primary/40', icon: <CheckCircle className="w-3 h-3" /> },
  cancelled: { label: 'Törölve', color: 'bg-destructive/15 text-destructive border-destructive/30', icon: <XCircle className="w-3 h-3" /> },
};

const priorityConfig: Record<string, { label: string; color: string }> = {
  routine: { label: 'Rutin', color: 'bg-secondary text-muted-foreground' },
  urgent:  { label: 'Sürgős', color: 'bg-yellow-500/15 text-yellow-700' },
  stat:    { label: 'AZONNALI', color: 'bg-destructive/15 text-destructive' },
};

const costBearerLabels: Record<string, string> = { taj: 'TAJ', self: 'Önfizető', employer: 'Munkáltató' };

export default function LabRequestBuilder({ prefillPatientId, prefillPatientName, onClose }: Props) {
  const { user } = useAuth();
  const { toast } = useToast();
  const { t } = useTranslation();
  const { data: dbPkgs } = useLabPackages();
  const { overrides: pricingOverrides, markup: pricingMarkup, loading: pricingLoading } = useLabPricing();
  const [requests, setRequests] = useState<LabRequest[]>([]);
  const [patients, setPatients] = useState<Patient[]>([]);
  const [physicianName, setPhysicianName] = useState('');
  const [loading, setLoading] = useState(false);
  const [patientId, setPatientId] = useState(prefillPatientId ?? '');
  const [priority, setPriority] = useState<'routine' | 'urgent' | 'stat'>('routine');
  const [scheduledDate, setScheduledDate] = useState(new Date().toISOString().slice(0, 10));
  const [costBearer, setCostBearer] = useState<'taj' | 'self' | 'employer'>('taj');
  const [notes, setNotes] = useState('');
  const [selectedTests, setSelectedTests] = useState<Set<string>>(new Set());
  const [saving, setSaving] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterSpecialty, setFilterSpecialty] = useState('all');
  const [filterSample, setFilterSample] = useState('all');
  const [expandedSpecialties, setExpandedSpecialties] = useState<Set<string>>(new Set());
  const [listSearch, setListSearch] = useState('');
  const [listStatus, setListStatus] = useState('all');
  const [listPriority, setListPriority] = useState('all');
  const [patientSearch, setPatientSearch] = useState('');

  useEffect(() => {
    if (!user) return;
    fetchAll();
    supabase.from('profiles').select('full_name').eq('user_id', user.id).maybeSingle().then(({ data }) => {
      if (data?.full_name) setPhysicianName(data.full_name);
    });
  }, [user]);

  const fetchAll = async () => {
    if (!user) return;
    setLoading(true);
    const [reqRes, patRes] = await Promise.all([
      supabase.from('lab_requests').select('*').order('created_at', { ascending: false }).limit(200),
      supabase.from('profiles').select('user_id, full_name, birth_date, taj_number, address, mother_name, gender, phone'),
    ]);

    const nameMap = Object.fromEntries((patRes.data ?? []).map(p => [p.user_id, p.full_name]));
    setPatients((patRes.data ?? []).map(p => ({ user_id: p.user_id, full_name: p.full_name, birth_date: p.birth_date, taj_number: p.taj_number, address: p.address, mother_name: p.mother_name, gender: p.gender, phone: p.phone })));

    if (reqRes.data) {
      setRequests(reqRes.data.map(r => ({
        ...r,
        requested_tests: (r.requested_tests as unknown as LabTest[]) ?? [],
        patient_name: nameMap[r.patient_id] ?? '—',
      })) as LabRequest[]);
    }
    setLoading(false);
  };

  const activeCatalog = useMemo(() => {
    return LAB_TEST_CATALOG.filter(t => {
      if (t.status !== 'active') return false;
      const q = searchQuery.toLowerCase();
      const matchSearch = !q || t.name.toLowerCase().includes(q) || t.shortName.toLowerCase().includes(q) || t.id.toLowerCase().includes(q) || t.oenoCode.toLowerCase().includes(q);
      const matchSpec = filterSpecialty === 'all' || t.specialty === filterSpecialty;
      const matchSample = filterSample === 'all' || t.sampleType === filterSample;
      return matchSearch && matchSpec && matchSample;
    });
  }, [searchQuery, filterSpecialty, filterSample]);

  const grouped = useMemo(() => {
    const g: Record<string, LabTest[]> = {};
    activeCatalog.forEach(t => { if (!g[t.specialty]) g[t.specialty] = []; g[t.specialty].push(t); });
    return g;
  }, [activeCatalog]);

  const toggleTest = (id: string) => {
    setSelectedTests(prev => { const s = new Set(prev); s.has(id) ? s.delete(id) : s.add(id); return s; });
  };

  const applyTemplate = (testIds: string[]) => {
    setSelectedTests(prev => {
      const s = new Set(prev);
      testIds.forEach(id => s.add(id));
      return s;
    });
    toast({ title: '✅ Csomag hozzáadva', description: `${testIds.length} vizsgálat hozzáadva.` });
  };

  const selectedList = LAB_TEST_CATALOG.filter(t => selectedTests.has(t.id));

  const getTestPrice = (test: LabTest) => calculateDisplayPrice(test, pricingOverrides, pricingMarkup, test.id);

  const selectedTotalPrice = selectedList.reduce((sum, t) => sum + getTestPrice(t), 0);

  const getPatientProfile = (): Patient | undefined => patients.find(s => s.user_id === patientId);

  const handleSave = async () => {
    if (!user) return;
    if (!patientId) { toast({ title: 'Hiba', description: 'Válassz páciensst!', variant: 'destructive' }); return; }
    if (selectedTests.size === 0) { toast({ title: 'Hiba', description: 'Legalább egy vizsgálatot válassz ki!', variant: 'destructive' }); return; }
    setSaving(true);
    const { error } = await supabase.from('lab_requests' as any).insert({
      request_number: '',
      patient_id: patientId,
      physician_id: user.id,
      requested_tests: selectedList as any,
      priority,
      scheduled_date: scheduledDate || null,
      cost_bearer: costBearer,
      notes: notes || null,
      status: 'pending',
    });
    setSaving(false);
    if (error) { toast({ title: 'Hiba', description: error.message, variant: 'destructive' }); return; }
    toast({ title: '✅ Labor kérés rögzítve', description: `${selectedTests.size} vizsgálattal.` });
    if (!prefillPatientId) setPatientId('');
    setSelectedTests(new Set());
    setNotes('');
    setPriority('routine');
    fetchAll();
  };

  const handlePrint = () => {
    if (selectedTests.size === 0) { toast({ title: 'Hiba', description: 'Válassz ki vizsgálatokat!', variant: 'destructive' }); return; }
    const p = getPatientProfile();
    printLabRequest({
      requestNumber: `LKR-${new Date().getFullYear()}-TERV`,
      patientName: p?.full_name ?? prefillPatientName ?? '—',
      dateOfBirth: p?.birth_date ?? undefined,
      tajNumber: p?.taj_number ?? undefined,
      motherName: p?.mother_name ?? undefined,
      patientAddress: p?.address ?? undefined,
      patientGender: p?.gender ?? undefined,
      patientPhone: p?.phone ?? undefined,
      physicianName: physicianName || user?.email || 'Orvos',
      scheduledDate,
      costBearer,
      priority,
      notes,
      selectedTests: selectedList,
      createdAt: new Date().toISOString(),
    });
  };

  const handlePrintExisting = (req: LabRequest) => {
    printLabRequest({
      requestNumber: req.request_number,
      patientName: req.patient_name ?? '—',
      physicianName: physicianName || user?.email || 'Orvos',
      scheduledDate: req.scheduled_date ?? undefined,
      costBearer: (req.cost_bearer as any) ?? undefined,
      priority: req.priority,
      notes: req.notes || undefined,
      selectedTests: req.requested_tests,
      createdAt: req.created_at,
    });
  };

  const handleStatusChange = async (id: string, newStatus: string) => {
    const { error } = await supabase.from('lab_requests' as any).update({ status: newStatus }).eq('id', id);
    if (error) { toast({ title: 'Hiba', description: error.message, variant: 'destructive' }); return; }
    setRequests(prev => prev.map(r => r.id === id ? { ...r, status: newStatus } : r));
  };

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('lab_requests' as any).delete().eq('id', id);
    if (error) { toast({ title: 'Hiba', description: error.message, variant: 'destructive' }); return; }
    setRequests(prev => prev.filter(r => r.id !== id));
    toast({ title: 'Törölve' });
  };

  const filteredRequests = requests.filter(r => {
    const q = listSearch.toLowerCase();
    const matchSearch = !q || (r.patient_name ?? '').toLowerCase().includes(q) || r.request_number.toLowerCase().includes(q);
    const matchStatus = listStatus === 'all' || r.status === listStatus;
    const matchPriority = listPriority === 'all' || r.priority === listPriority;
    return matchSearch && matchStatus && matchPriority;
  });

  const today = new Date().toISOString().slice(0, 10);
  const tomorrow = new Date(Date.now() + 86400000).toISOString().slice(0, 10);
  const upcomingCount = requests.filter(r => r.scheduled_date === today || r.scheduled_date === tomorrow).length;

  const toggleSpecialty = (s: string) => {
    setExpandedSpecialties(prev => { const n = new Set(prev); n.has(s) ? n.delete(s) : n.add(s); return n; });
  };

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="font-bold text-xl flex items-center gap-2 text-foreground">
            <FlaskConical className="w-5 h-5 text-primary" /> {t('lab.title')}
          </h2>
          <p className="text-muted-foreground text-sm mt-0.5">
            {requests.length} {t('lab.requestCount')} · {LAB_TEST_CATALOG.filter(t => t.status === 'active').length} {t('lab.activeTests')}
          </p>
        </div>
        {onClose && <Button variant="ghost" size="sm" onClick={onClose}>{t('common.close')}</Button>}
      </div>

      <Tabs defaultValue="new">
        <TabsList className="w-full grid grid-cols-3">
          <TabsTrigger value="new"><Plus className="w-3.5 h-3.5 mr-1.5" /> {t('lab.newRequest')}</TabsTrigger>
          <TabsTrigger value="list">
            <FileText className="w-3.5 h-3.5 mr-1.5" /> {t('lab.requestList')}
            {requests.length > 0 && <Badge className="ml-1.5 h-4 text-[10px] px-1.5 bg-primary/20 text-primary border-0">{requests.length}</Badge>}
          </TabsTrigger>
          <TabsTrigger value="scheduled">
            <Calendar className="w-3.5 h-3.5 mr-1.5" /> {t('lab.scheduled')}
            {upcomingCount > 0 && <Badge className="ml-1.5 h-4 text-[10px] px-1.5 bg-yellow-500/20 text-yellow-700 border-0">{upcomingCount}</Badge>}
          </TabsTrigger>
        </TabsList>

        {/* NEW REQUEST TAB */}
        <TabsContent value="new" className="space-y-4 mt-4">
          {/* Patient search */}
          <Card className="border-border">
            <CardContent className="p-4 space-y-3">
              <Label className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{t('lab.patient')}</Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  value={patientSearch}
                  onChange={e => setPatientSearch(e.target.value)}
                  placeholder="Keresés: név, TAJ szám, születési dátum…"
                  className="pl-9 text-sm"
                />
              </div>
              {patientSearch.length >= 2 && !patientId && (
                <div className="border border-border rounded-lg max-h-48 overflow-y-auto">
                  {patients.filter(p => {
                    const q = patientSearch.toLowerCase();
                    return p.full_name.toLowerCase().includes(q) ||
                      (p.taj_number && p.taj_number.includes(q)) ||
                      (p.birth_date && p.birth_date.includes(q));
                  }).slice(0, 20).map(p => (
                    <button key={p.user_id} onClick={() => { setPatientId(p.user_id); setPatientSearch(p.full_name); }}
                      className="w-full text-left px-3 py-2 hover:bg-muted/50 border-b border-border last:border-0 transition-colors">
                      <div className="font-medium text-sm text-foreground">{p.full_name}</div>
                      <div className="text-xs text-muted-foreground flex gap-3">
                        {p.taj_number && <span>TAJ: {p.taj_number}</span>}
                        {p.birth_date && <span>Szül.: {new Date(p.birth_date).toLocaleDateString('hu-HU')}</span>}
                      </div>
                    </button>
                  ))}
                  {patients.filter(p => {
                    const q = patientSearch.toLowerCase();
                    return p.full_name.toLowerCase().includes(q) ||
                      (p.taj_number && p.taj_number.includes(q)) ||
                      (p.birth_date && p.birth_date.includes(q));
                  }).length === 0 && (
                    <div className="text-center text-muted-foreground text-sm py-3">Nincs találat</div>
                  )}
                </div>
              )}
              {patientId && (() => {
                const p = getPatientProfile();
                if (!p) return null;
                return (
                  <div className="border border-primary/30 bg-primary/5 rounded-lg p-3 flex items-start justify-between">
                    <div className="space-y-1">
                      <div className="font-semibold text-foreground flex items-center gap-2">
                        <User className="w-4 h-4 text-primary" /> {p.full_name}
                      </div>
                      <div className="text-xs text-muted-foreground grid grid-cols-2 gap-x-6 gap-y-0.5">
                        {p.taj_number && <span>TAJ: <strong>{p.taj_number}</strong></span>}
                        {p.birth_date && <span>Születési dátum: <strong>{new Date(p.birth_date).toLocaleDateString('hu-HU')}</strong></span>}
                        {p.gender && <span>Nem: <strong>{p.gender === 'male' ? 'Férfi' : p.gender === 'female' ? 'Nő' : p.gender}</strong></span>}
                        {p.mother_name && <span>Anyja neve: <strong>{p.mother_name}</strong></span>}
                        {p.address && <span className="col-span-2">Cím: <strong>{p.address}</strong></span>}
                        {p.phone && <span>Telefon: <strong>{p.phone}</strong></span>}
                      </div>
                    </div>
                    <Button variant="ghost" size="sm" onClick={() => { setPatientId(''); setPatientSearch(''); }}>
                      <XCircle className="w-4 h-4" />
                    </Button>
                  </div>
                );
              })()}
            </CardContent>
          </Card>

          <Card className="border-border">
            <CardContent className="p-4 grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{t('lab.priorityLabel')}</Label>
                <Select value={priority} onValueChange={v => setPriority(v as any)}>
                  <SelectTrigger className="text-sm"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="routine">{t('lab.priority.routine')}</SelectItem>
                    <SelectItem value="urgent">{t('lab.priority.urgent')}</SelectItem>
                    <SelectItem value="stat">{t('lab.priority.stat')}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{t('lab.sampleDate')}</Label>
                <Input type="date" value={scheduledDate} onChange={e => setScheduledDate(e.target.value)} className="text-sm" />
              </div>
              <div className="space-y-2">
                <Label className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{t('lab.costBearerLabel')}</Label>
                <Select value={costBearer} onValueChange={v => setCostBearer(v as any)}>
                  <SelectTrigger className="text-sm"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="taj">🏥 {t('lab.costBearer.taj')}</SelectItem>
                    <SelectItem value="self">💳 {t('lab.costBearer.self')}</SelectItem>
                    <SelectItem value="employer">🏢 {t('lab.costBearer.employer')}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Templates */}
          <div>
            {(dbPkgs ?? []).length > 0 && (
              <>
                <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">{t('lab.templates')}</p>
                <div className="flex flex-wrap gap-2">
                  {(dbPkgs ?? []).map(pkg => {
                    const allIn = (pkg.test_ids ?? []).every(id => selectedTests.has(id));
                    return (
                      <button key={pkg.id} onClick={() => applyTemplate(pkg.test_ids ?? [])} disabled={allIn}
                        className={`text-xs flex items-center gap-1.5 px-3 py-1.5 rounded-full border transition-colors font-medium ${allIn ? 'opacity-50 cursor-default border-muted bg-muted/30' : 'border-secondary/30 bg-secondary/5 text-secondary-foreground hover:bg-secondary/10'}`}>
                        {pkg.icon} {pkg.name} <span className="text-muted-foreground">({(pkg.test_ids ?? []).length})</span>
                      </button>
                    );
                  })}
                  {selectedTests.size > 0 && (
                    <button onClick={() => setSelectedTests(new Set())}
                      className="text-xs flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-destructive/30 bg-destructive/5 text-destructive hover:bg-destructive/10 transition-colors font-medium">
                      <Trash2 className="w-3 h-3" /> {t('common.delete')} ({selectedTests.size})
                    </button>
                  )}
                </div>
              </>
            )}
          </div>

          {/* Search & filters */}
          <div className="flex flex-wrap gap-2 items-center">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input value={searchQuery} onChange={e => setSearchQuery(e.target.value)} placeholder={t('lab.searchPlaceholder')} className="pl-9 text-sm" />
            </div>
            <Select value={filterSpecialty} onValueChange={setFilterSpecialty}>
              <SelectTrigger className="w-[170px] text-xs"><SelectValue placeholder={t('lab.specialty')} /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t('lab.allSpecialties')}</SelectItem>
                {SPECIALTIES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={filterSample} onValueChange={setFilterSample}>
              <SelectTrigger className="w-[160px] text-xs"><SelectValue placeholder={t('lab.sampleType')} /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t('lab.allSamples')}</SelectItem>
                {SAMPLE_TYPES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
              </SelectContent>
            </Select>
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <span className="font-medium text-foreground">{activeCatalog.length}</span> {t('lab.results')}
            </div>
          </div>

          {/* Test catalog */}
          <ScrollArea className="h-[420px] border border-border rounded-xl bg-muted/20">
            <div className="p-2 space-y-1">
              {Object.entries(grouped).map(([specialty, tests]) => {
                const isExpanded = expandedSpecialties.has(specialty) || !!searchQuery || filterSpecialty !== 'all';
                const selectedInGroup = tests.filter(t => selectedTests.has(t.id)).length;
                return (
                  <div key={specialty}>
                    <button onClick={() => toggleSpecialty(specialty)}
                      className="w-full flex items-center justify-between px-3 py-2 rounded-lg bg-muted/60 hover:bg-muted transition-colors text-left">
                      <span className="text-xs font-bold text-foreground uppercase tracking-wide">{specialty}</span>
                      <div className="flex items-center gap-2">
                        {selectedInGroup > 0 && <Badge className="h-4 text-[10px] px-1.5 bg-primary/20 text-primary border-0">{selectedInGroup}</Badge>}
                        <span className="text-[10px] text-muted-foreground">{tests.length}</span>
                        {isExpanded ? <ChevronUp className="w-3 h-3 text-muted-foreground" /> : <ChevronDown className="w-3 h-3 text-muted-foreground" />}
                      </div>
                    </button>
                    {isExpanded && (
                      <div className="mt-0.5 space-y-0.5">
                        {tests.map(test => {
                          const checked = selectedTests.has(test.id);
                          return (
                            <label key={test.id}
                              className={`flex items-start gap-2 px-3 py-2 rounded-lg cursor-pointer transition-colors select-none ${checked ? 'bg-primary/10 border border-primary/20' : 'hover:bg-muted/60'}`}>
                              <Checkbox checked={checked} onCheckedChange={() => toggleTest(test.id)} className="mt-0.5 shrink-0" />
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <span className="font-mono text-[10px] text-muted-foreground w-12 shrink-0">{test.id}</span>
                                  <span className="text-sm font-medium text-foreground">{test.name}</span>
                                  {test.shortName && test.shortName !== test.name && (
                                    <span className="text-[10px] font-mono text-muted-foreground bg-muted px-1.5 py-0.5 rounded">{test.shortName}</span>
                                  )}
                                </div>
                                <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                                  <span className="text-[10px] text-muted-foreground">🧪 {test.sampleType}</span>
                                  {test.referenceRange && <span className="text-[10px] text-muted-foreground/60">Ref: {test.referenceRange}</span>}
                                  {costBearer === 'self' && (
                                    <span className="text-[10px] font-semibold text-primary">
                                      {getTestPrice(test).toLocaleString('hu-HU')} Ft
                                    </span>
                                  )}
                                </div>
                              </div>
                            </label>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })}
              {Object.keys(grouped).length === 0 && (
                <div className="text-center py-12 text-muted-foreground text-sm">
                  <Search className="w-6 h-6 mx-auto mb-2 opacity-40" /> {t('lab.noResults')}
                </div>
              )}
            </div>
          </ScrollArea>

          <div className="space-y-1.5">
            <Label className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{t('lab.notes')}</Label>
            <Textarea value={notes} onChange={e => setNotes(e.target.value)} placeholder={t('lab.notesPlaceholder')} rows={2} className="text-sm" />
          </div>

          <div className="flex items-center justify-between gap-3 flex-wrap pt-2 border-t border-border">
            <div className="flex items-center gap-2 flex-wrap">
              <div className={`px-3 py-1.5 rounded-lg text-sm font-semibold ${selectedTests.size > 0 ? 'bg-primary/10 text-primary' : 'bg-muted text-muted-foreground'}`}>
                {selectedTests.size > 0 ? `${selectedTests.size} ${t('lab.testsSelected')}` : t('lab.noTestSelected')}
              </div>
              {selectedTests.size > 0 && (
                <div className="text-xs text-muted-foreground">
                  🧪 {[...new Set(selectedList.map(t => t.sampleType))].filter(s => s !== 'N/A').join(' · ')}
                </div>
              )}
              {selectedTests.size > 0 && costBearer === 'self' && (
                <div className="px-3 py-1.5 rounded-lg text-sm font-bold bg-primary/15 text-primary">
                  Összesen: {selectedTotalPrice.toLocaleString('hu-HU')} Ft
                </div>
              )}
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={handlePrint} disabled={selectedTests.size === 0}>
                <Download className="w-3.5 h-3.5 mr-1.5" /> PDF
              </Button>
              <Button size="sm" onClick={handleSave} disabled={saving || selectedTests.size === 0 || !patientId}>
                {saving ? <RefreshCw className="w-3.5 h-3.5 mr-1.5 animate-spin" /> : <Plus className="w-3.5 h-3.5 mr-1.5" />}
                {t('lab.saveRequest')}
              </Button>
            </div>
          </div>
        </TabsContent>

        {/* REQUESTS LIST TAB */}
        <TabsContent value="list" className="space-y-3 mt-4">
          <div className="flex flex-wrap gap-2">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input value={listSearch} onChange={e => setListSearch(e.target.value)} placeholder={t('lab.searchRequests')} className="pl-9 text-sm" />
            </div>
            <Select value={listStatus} onValueChange={setListStatus}>
              <SelectTrigger className="w-[140px] text-xs"><SelectValue placeholder={t('lab.statusLabel')} /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t('lab.allStatuses')}</SelectItem>
                {Object.entries(statusConfig).map(([k, v]) => <SelectItem key={k} value={k}>{v.label}</SelectItem>)}
              </SelectContent>
            </Select>
            <Button variant="ghost" size="sm" onClick={fetchAll}>
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </Button>
          </div>

          {/* Monthly stats chart */}
          {(() => {
            const now = new Date();
            const months = Array.from({ length: 6 }, (_, i) => {
              const d = new Date(now.getFullYear(), now.getMonth() - (5 - i), 1);
              return { key: `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`, label: d.toLocaleDateString('hu-HU', { month: 'short', year: '2-digit' }), keres: 0 };
            });
            requests.forEach(r => { const mk = r.created_at.slice(0, 7); const b = months.find(m => m.key === mk); if (b) b.keres += 1; });
            return (
              <Card className="border-border bg-card">
                <CardHeader className="pb-2 pt-4 px-4">
                  <CardTitle className="text-sm font-bold flex items-center gap-2 text-foreground">
                    <BarChart2 className="w-4 h-4 text-primary" /> {t('lab.monthlyStats')}
                  </CardTitle>
                </CardHeader>
                <CardContent className="px-4 pb-4">
                  <ResponsiveContainer width="100%" height={180}>
                    <BarChart data={months}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                      <XAxis dataKey="label" tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} allowDecimals={false} width={28} />
                      <Tooltip contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '8px', fontSize: 12 }} />
                      <Bar dataKey="keres" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} maxBarSize={36} name={t('lab.requestCount')} />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            );
          })()}

          <div className="overflow-auto rounded-xl border border-border">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-muted/60 border-b border-border">
                  <th className="text-left px-3 py-2.5 text-xs font-bold text-muted-foreground">{t('lab.requestNum')}</th>
                  <th className="text-left px-3 py-2.5 text-xs font-bold text-muted-foreground">{t('lab.patient')}</th>
                  <th className="text-left px-3 py-2.5 text-xs font-bold text-muted-foreground hidden md:table-cell">{t('lab.sampleDate')}</th>
                  <th className="text-left px-3 py-2.5 text-xs font-bold text-muted-foreground hidden lg:table-cell">{t('lab.costBearerLabel')}</th>
                  <th className="text-left px-3 py-2.5 text-xs font-bold text-muted-foreground">{t('lab.tests')}</th>
                  <th className="text-left px-3 py-2.5 text-xs font-bold text-muted-foreground">{t('lab.statusLabel')}</th>
                  <th className="text-right px-3 py-2.5 text-xs font-bold text-muted-foreground">{t('lab.actions')}</th>
                </tr>
              </thead>
              <tbody>
                {filteredRequests.map(req => {
                  const sc = statusConfig[req.status] ?? statusConfig.pending;
                  const pc = priorityConfig[req.priority] ?? priorityConfig.routine;
                  return (
                    <tr key={req.id} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                      <td className="px-3 py-2.5">
                        <div className="font-mono text-xs text-foreground">{req.request_number}</div>
                        <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${pc.color}`}>{pc.label}</span>
                      </td>
                      <td className="px-3 py-2.5 font-medium text-foreground text-sm">{req.patient_name}</td>
                      <td className="px-3 py-2.5 hidden md:table-cell text-xs text-muted-foreground">
                        {req.scheduled_date ? new Date(req.scheduled_date).toLocaleDateString('hu-HU') : '—'}
                      </td>
                      <td className="px-3 py-2.5 hidden lg:table-cell text-xs">
                        {req.cost_bearer ? <span className="px-1.5 py-0.5 rounded bg-secondary text-muted-foreground text-[10px] font-semibold">{costBearerLabels[req.cost_bearer] ?? req.cost_bearer}</span> : '—'}
                      </td>
                      <td className="px-3 py-2.5">
                        <span className="text-sm font-semibold text-foreground">{Array.isArray(req.requested_tests) ? req.requested_tests.length : 0}</span>
                      </td>
                      <td className="px-3 py-2.5">
                        <Select value={req.status} onValueChange={v => handleStatusChange(req.id, v)}>
                          <SelectTrigger className="h-7 text-xs border-0 bg-transparent p-0 hover:bg-muted rounded-md px-2 gap-1">
                            <div className={`flex items-center gap-1 px-2 py-0.5 rounded-full border text-[10px] font-semibold ${sc.color}`}>
                              {sc.icon} {sc.label}
                            </div>
                          </SelectTrigger>
                          <SelectContent>
                            {Object.entries(statusConfig).map(([k, v]) => (
                              <SelectItem key={k} value={k}><div className="flex items-center gap-1.5">{v.icon} {v.label}</div></SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </td>
                      <td className="px-3 py-2.5 text-right">
                        <div className="flex justify-end gap-1">
                          <Button variant="ghost" size="sm" className="h-7 w-7 p-0" onClick={() => handlePrintExisting(req)}>
                            <Download className="w-3.5 h-3.5" />
                          </Button>
                          <Button variant="ghost" size="sm" className="h-7 w-7 p-0 text-destructive hover:text-destructive" onClick={() => handleDelete(req.id)}>
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
                {filteredRequests.length === 0 && (
                  <tr><td colSpan={7} className="text-center py-12 text-muted-foreground text-sm">
                    {loading ? <RefreshCw className="w-5 h-5 animate-spin mx-auto" /> : t('lab.noRequests')}
                  </td></tr>
                )}
              </tbody>
            </table>
          </div>
        </TabsContent>

        {/* SCHEDULED TAB */}
        <TabsContent value="scheduled" className="space-y-3 mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <h3 className="text-sm font-bold text-foreground mb-2 flex items-center gap-2">
                <Calendar className="w-4 h-4 text-primary" /> {t('lab.today')} ({today})
              </h3>
              <div className="space-y-2">
                {requests.filter(r => r.scheduled_date === today).map(req => (
                  <Card key={req.id} className="border-border">
                    <CardContent className="p-3 flex items-center justify-between">
                      <div>
                        <div className="font-medium text-sm text-foreground">{req.patient_name}</div>
                        <div className="text-xs text-muted-foreground">{req.request_number} · {req.requested_tests.length} vizsgálat</div>
                      </div>
                      <Button variant="ghost" size="sm" onClick={() => handlePrintExisting(req)}><Download className="w-4 h-4" /></Button>
                    </CardContent>
                  </Card>
                ))}
                {requests.filter(r => r.scheduled_date === today).length === 0 && (
                  <p className="text-xs text-muted-foreground py-4 text-center border border-dashed border-border rounded-xl">{t('lab.noScheduledToday')}</p>
                )}
              </div>
            </div>
            <div>
              <h3 className="text-sm font-bold text-foreground mb-2 flex items-center gap-2">
                <Calendar className="w-4 h-4 text-muted-foreground" /> {t('lab.tomorrow')} ({tomorrow})
              </h3>
              <div className="space-y-2">
                {requests.filter(r => r.scheduled_date === tomorrow).map(req => (
                  <Card key={req.id} className="border-border">
                    <CardContent className="p-3 flex items-center justify-between">
                      <div>
                        <div className="font-medium text-sm text-foreground">{req.patient_name}</div>
                        <div className="text-xs text-muted-foreground">{req.request_number} · {req.requested_tests.length} vizsgálat</div>
                      </div>
                      <Button variant="ghost" size="sm" onClick={() => handlePrintExisting(req)}><Download className="w-4 h-4" /></Button>
                    </CardContent>
                  </Card>
                ))}
                {requests.filter(r => r.scheduled_date === tomorrow).length === 0 && (
                  <p className="text-xs text-muted-foreground py-4 text-center border border-dashed border-border rounded-xl">{t('lab.noScheduledTomorrow')}</p>
                )}
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
