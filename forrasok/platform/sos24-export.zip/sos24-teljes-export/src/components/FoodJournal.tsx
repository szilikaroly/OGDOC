import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Plus, TrendingUp, Camera, Loader2 } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { format } from "date-fns";
import { hu } from "date-fns/locale";
import { useTranslation } from "react-i18next";

export default function FoodJournal() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [form, setForm] = useState({
    meal_type: "lunch", food_description: "", calories_estimated: "", protein_g: "", carbs_g: "", fat_g: "", fiber_g: "", notes: ""
  });

  const { data: entries, isLoading } = useQuery({
    queryKey: ["food-journal", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase.from("food_journal").select("*").eq("user_id", user!.id).order("entry_date", { ascending: false }).limit(90);
      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  const addEntry = useMutation({
    mutationFn: async (aiAnalyzed: boolean) => {
      const row: Record<string, any> = { user_id: user!.id, meal_type: form.meal_type, ai_analyzed: aiAnalyzed };
      if (form.food_description) row.food_description = form.food_description;
      if (form.calories_estimated) row.calories_estimated = Number(form.calories_estimated);
      if (form.protein_g) row.protein_g = Number(form.protein_g);
      if (form.carbs_g) row.carbs_g = Number(form.carbs_g);
      if (form.fat_g) row.fat_g = Number(form.fat_g);
      if (form.fiber_g) row.fiber_g = Number(form.fiber_g);
      if (form.notes) row.notes = form.notes;
      const { error } = await supabase.from("food_journal").insert(row as any);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["food-journal"] });
      toast({ title: t("inner.entrySaved") });
      setOpen(false);
      setForm({ meal_type: "lunch", food_description: "", calories_estimated: "", protein_g: "", carbs_g: "", fat_g: "", fiber_g: "", notes: "" });
    },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  const handlePhotoAnalysis = async (file: File) => {
    setAiLoading(true);
    try {
      const reader = new FileReader();
      const base64 = await new Promise<string>((resolve) => {
        reader.onload = () => resolve((reader.result as string).split(",")[1]);
        reader.readAsDataURL(file);
      });

      const { data, error } = await supabase.functions.invoke("ai-health-image-analysis", {
        body: { mode: "food", image_base64: base64, mime_type: file.type },
      });
      if (error) throw error;
      const r = data.result;
      setForm((p) => ({
        ...p,
        food_description: r.food_description || p.food_description,
        calories_estimated: r.calories_estimated?.toString() || p.calories_estimated,
        protein_g: r.protein_g?.toString() || p.protein_g,
        carbs_g: r.carbs_g?.toString() || p.carbs_g,
        fat_g: r.fat_g?.toString() || p.fat_g,
        fiber_g: r.fiber_g?.toString() || p.fiber_g,
      }));
      toast({ title: t("inner.aiAnalyzed") });
    } catch (e: any) {
      toast({ variant: "destructive", title: t("common.error"), description: e.message });
    } finally {
      setAiLoading(false);
    }
  };

  const todayCalories = (entries ?? [])
    .filter((e) => e.entry_date === format(new Date(), "yyyy-MM-dd"))
    .reduce((sum, e) => sum + (e.calories_estimated || 0), 0);

  const chartData = [...(entries ?? [])]
    .reverse()
    .reduce((acc: { date: string; calories: number }[], e) => {
      const d = format(new Date(e.entry_date), "MM.dd", { locale: hu });
      const existing = acc.find((a) => a.date === d);
      if (existing) existing.calories += e.calories_estimated || 0;
      else acc.push({ date: d, calories: e.calories_estimated || 0 });
      return acc;
    }, []);

  if (isLoading) return <div className="flex justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold">{t("inner.foodJournal")}</h2>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button><Plus className="h-4 w-4 mr-1" /> {t("inner.newFoodEntry")}</Button></DialogTrigger>
          <DialogContent className="max-h-[90vh] overflow-y-auto">
            <DialogHeader><DialogTitle>{t("inner.newFoodEntry")}</DialogTitle></DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>{t("inner.mealType")}</Label>
                <Select value={form.meal_type} onValueChange={(v) => setForm((p) => ({ ...p, meal_type: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="breakfast">{t("inner.breakfast")}</SelectItem>
                    <SelectItem value="lunch">{t("inner.lunch")}</SelectItem>
                    <SelectItem value="dinner">{t("inner.dinner")}</SelectItem>
                    <SelectItem value="snack">{t("inner.snack")}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" className="w-full" disabled={aiLoading} onClick={() => document.getElementById("food-photo-input")?.click()}>
                  {aiLoading ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Camera className="h-4 w-4 mr-1" />}
                  {aiLoading ? t("inner.aiAnalyzing") : t("inner.aiAnalyzePhoto")}
                </Button>
                <input id="food-photo-input" type="file" accept="image/*" capture="environment" className="hidden" onChange={(e) => e.target.files?.[0] && handlePhotoAnalysis(e.target.files[0])} />
              </div>
              <div><Label>{t("inner.foodDescription")}</Label><Textarea value={form.food_description} onChange={(e) => setForm((p) => ({ ...p, food_description: e.target.value }))} /></div>
              <div className="grid grid-cols-2 gap-4">
                <div><Label>{t("inner.calories")}</Label><Input type="number" value={form.calories_estimated} onChange={(e) => setForm((p) => ({ ...p, calories_estimated: e.target.value }))} placeholder="500" /></div>
                <div><Label>{t("inner.protein")}</Label><Input type="number" step="0.1" value={form.protein_g} onChange={(e) => setForm((p) => ({ ...p, protein_g: e.target.value }))} placeholder="25" /></div>
                <div><Label>{t("inner.carbs")}</Label><Input type="number" step="0.1" value={form.carbs_g} onChange={(e) => setForm((p) => ({ ...p, carbs_g: e.target.value }))} placeholder="60" /></div>
                <div><Label>{t("inner.fat")}</Label><Input type="number" step="0.1" value={form.fat_g} onChange={(e) => setForm((p) => ({ ...p, fat_g: e.target.value }))} placeholder="15" /></div>
                <div><Label>{t("inner.fiber")}</Label><Input type="number" step="0.1" value={form.fiber_g} onChange={(e) => setForm((p) => ({ ...p, fiber_g: e.target.value }))} placeholder="5" /></div>
              </div>
              <div><Label>{t("inner.comment")}</Label><Textarea value={form.notes} onChange={(e) => setForm((p) => ({ ...p, notes: e.target.value }))} /></div>
              <Button className="w-full" onClick={() => addEntry.mutate(false)} disabled={addEntry.isPending}>
                {addEntry.isPending ? t("inner.saving") : t("inner.save")}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader><CardTitle className="text-base">{t("inner.dailyCalories")}</CardTitle></CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-primary">{todayCalories} <span className="text-sm font-normal text-muted-foreground">{t("inner.kcalToday")}</span></div>
          </CardContent>
        </Card>
        {chartData.length > 1 && (
          <Card>
            <CardHeader><CardTitle className="text-base flex items-center gap-2"><TrendingUp className="h-4 w-4" /> {t("inner.caloriesTrend")}</CardTitle></CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" fontSize={12} />
                  <YAxis fontSize={12} />
                  <Tooltip />
                  <Line type="monotone" dataKey="calories" name={t("inner.calories")} stroke="hsl(var(--primary))" dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}
      </div>

      <Card>
        <CardHeader><CardTitle className="text-lg">{t("inner.lastEntries")}</CardTitle></CardHeader>
        <CardContent className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b text-left">
                <th className="pb-2 pr-4">{t("inner.date")}</th>
                <th className="pb-2 pr-4">{t("inner.mealType")}</th>
                <th className="pb-2 pr-4">{t("inner.foodDescription")}</th>
                <th className="pb-2 pr-4">{t("inner.calories")}</th>
                <th className="pb-2">{t("inner.comment")}</th>
              </tr>
            </thead>
            <tbody>
              {(entries ?? []).map((e) => (
                <tr key={e.id} className="border-b last:border-0">
                  <td className="py-2 pr-4">{format(new Date(e.entry_date), "yyyy.MM.dd", { locale: hu })}</td>
                  <td className="py-2 pr-4">{t(`inner.${e.meal_type}`)}</td>
                  <td className="py-2 pr-4 max-w-[200px] truncate">{e.food_description || "—"}</td>
                  <td className="py-2 pr-4">{e.calories_estimated ? `${e.calories_estimated} kcal` : "—"}</td>
                  <td className="py-2 text-muted-foreground truncate max-w-[150px]">{e.notes || "—"}</td>
                </tr>
              ))}
              {(!entries || entries.length === 0) && (
                <tr><td colSpan={5} className="py-8 text-center text-muted-foreground">{t("inner.noFoodEntryYet")}</td></tr>
              )}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}
