import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import {
  TERRITORIAL_CODES, REPORT_TYPES, STAFF_CATEGORIES, CITIZENSHIP_CODES, GENDER_CODES,
  EMPLOYMENT_TYPE_CODES, EMPLOYMENT_NATURE_CODES, INJURY_TYPE_CODES, BODY_PART_CODES,
  WORK_LOCATION_CODES, INJURY_SEVERITY_CODES, SAFETY_DEVICE_OPTIONS, SAFETY_REP_AGREEMENT,
} from "@/lib/accident-codes";

interface Props {
  report: Record<string, any>;
}

const codeName = (codes: { code: string; name: string }[], val: string | null) => {
  if (!val) return "";
  const found = codes.find(c => c.code === val);
  return found ? `${found.code} — ${found.name}` : val;
};

export default function PrintableAccidentReport({ report }: Props) {
  const r = report;
  const [photoSignedUrls, setPhotoSignedUrls] = useState<string[]>([]);

  useEffect(() => {
    const loadPhotos = async () => {
      if (!r.photos?.length) return;
      const urls: string[] = [];
      for (const p of r.photos) {
        const { data } = await supabase.storage.from("accident-photos").createSignedUrl(p, 3600);
        if (data?.signedUrl) urls.push(data.signedUrl);
      }
      setPhotoSignedUrls(urls);
    };
    loadPhotos();
  }, [r.photos]);

  const Cell = ({ label, value, span = 1 }: { label: string; value?: string | number | null; span?: number }) => (
    <td colSpan={span} className="border border-foreground/30 p-1.5 text-xs align-top">
      <div className="text-[10px] text-muted-foreground leading-tight mb-0.5">{label}</div>
      <div className="font-medium min-h-[1.2em]">{value || ""}</div>
    </td>
  );

  const SectionHeader = ({ label }: { label: string }) => (
    <tr>
      <td colSpan={6} className="border border-foreground/30 bg-muted/50 p-1.5 text-xs font-bold uppercase tracking-wide">
        {label}
      </td>
    </tr>
  );

  return (
    <div className="print-area bg-background text-foreground p-6 max-w-[210mm] mx-auto text-sm leading-tight"
      style={{ fontFamily: "Times New Roman, serif" }}
    >
      {/* Header */}
      <div className="text-center mb-4 space-y-1">
        <h1 className="text-base font-bold uppercase tracking-wide">
          Munkabaleseti Jegyzőkönyv
        </h1>
        <p className="text-xs text-muted-foreground">
          (A munkavédelemről szóló 1993. évi XCIII. törvény 64. § (1) bekezdése alapján)
        </p>
        <p className="text-xs font-semibold">MBJKV 2025</p>
      </div>

      {/* Registration info */}
      <table className="w-full border-collapse mb-2">
        <tbody>
          <tr>
            <Cell label="Nyilvántartási szám" value={r.registration_number} span={2} />
            <Cell label="Területi kód" value={codeName(TERRITORIAL_CODES, r.territorial_code)} span={2} />
            <Cell label="Adatszolgáltatás jellege" value={codeName(REPORT_TYPES, r.report_type)} span={2} />
          </tr>
        </tbody>
      </table>

      {/* A) Employer */}
      <table className="w-full border-collapse mb-2">
        <tbody>
          <SectionHeader label="A) A munkáltató adatai" />
          <tr>
            <Cell label="Munkáltató neve" value={r.employer_name} span={3} />
            <Cell label="Címe" value={r.employer_address} span={3} />
          </tr>
          <tr>
            <Cell label="Telefon" value={r.employer_phone} span={2} />
            <Cell label="Fax" value={r.employer_fax} />
            <Cell label="Mobil" value={r.employer_mobile} span={2} />
            <Cell label="E-mail" value={r.employer_email} />
          </tr>
          <tr>
            <Cell label="Adószám" value={r.employer_tax_number} span={3} />
            <Cell label="Adóazonosító jel" value={r.employer_tax_id} span={3} />
          </tr>
          <tr>
            <Cell label="Gazdálkodási forma" value={r.employer_org_form} span={2} />
            <Cell label="Főtevékenység (TEÁOR)" value={r.employer_teaor_main} span={2} />
            <Cell label="Helyi egység tev." value={r.employer_teaor_local} span={2} />
          </tr>
          <tr>
            <Cell label="Összlétszám-kategória" value={codeName(STAFF_CATEGORIES, r.employer_total_staff_category)} span={3} />
            <Cell label="Helyi egys. létszám-kat." value={codeName(STAFF_CATEGORIES, r.employer_local_staff_category)} span={3} />
          </tr>
        </tbody>
      </table>

      {/* B) Injured */}
      <table className="w-full border-collapse mb-2">
        <tbody>
          <SectionHeader label="B) A sérült adatai" />
          <tr>
            <Cell label="Sérült neve" value={r.injured_name} span={3} />
            <Cell label="TAJ szám" value={r.injured_taj} span={3} />
          </tr>
          <tr>
            <Cell label="Születési név" value={r.injured_birth_name} span={3} />
            <Cell label="Anyja neve" value={r.injured_mother_name} span={3} />
          </tr>
          <tr>
            <Cell label="Születési hely" value={r.injured_birth_place} span={2} />
            <Cell label="Születési idő" value={r.injured_birth_date} />
            <Cell label="Neme" value={codeName(GENDER_CODES, r.injured_gender)} />
            <Cell label="Állampolgárság" value={codeName(CITIZENSHIP_CODES, r.injured_citizenship)} span={2} />
          </tr>
          <tr>
            <Cell label="Lakcím" value={r.injured_address} span={4} />
            <Cell label="Telefonszám" value={r.injured_phone} span={2} />
          </tr>
          <tr>
            <Cell label="Foglalkozás (FEOR)" value={r.injured_feor_code ? `${r.injured_feor_code} — ${r.injured_feor_name || ""}` : ""} span={2} />
            <Cell label="Foglalkoztatási jogviszony" value={codeName(EMPLOYMENT_TYPE_CODES, r.injured_employment_type)} span={2} />
            <Cell label="Foglalkoztatás jellege" value={codeName(EMPLOYMENT_NATURE_CODES, r.injured_employment_nature)} span={2} />
          </tr>
        </tbody>
      </table>

      {/* C) Accident data */}
      <table className="w-full border-collapse mb-2">
        <tbody>
          <SectionHeader label="C) A munkabaleset adatai" />
          <tr>
            <Cell label="Baleset dátuma" value={r.accident_date} span={2} />
            <Cell label="Időpont (óra)" value={r.accident_time_hour} />
            <Cell label="Hányadik munkaórában" value={r.injury_work_hour} />
            <Cell label="Sérülés típusa" value={codeName(INJURY_TYPE_CODES, r.injury_type_code)} span={2} />
          </tr>
          <tr>
            <Cell label="Sérült testrész" value={codeName(BODY_PART_CODES, r.injured_body_part_code)} span={2} />
            <Cell label="Munkavégzési hely" value={codeName(WORK_LOCATION_CODES, r.work_location_code)} span={2} />
            <Cell label="Sérülés súlyossága" value={codeName(INJURY_SEVERITY_CODES, r.injury_severity_code)} span={2} />
          </tr>
          <tr>
            <Cell label="Baleset földrajzi helye" value={r.accident_geo_location} span={3} />
            <Cell label="Településazonosító" value={r.accident_geo_code} />
            <Cell label="Munkaképtelen napok" value={r.disability_days} span={2} />
          </tr>
          {r.gps_lat && r.gps_lng && (
            <tr>
              <Cell label="GPS koordináták" value={`${Number(r.gps_lat).toFixed(6)}, ${Number(r.gps_lng).toFixed(6)}`} span={6} />
            </tr>
          )}
        </tbody>
      </table>

      {/* D) Description */}
      <table className="w-full border-collapse mb-2">
        <tbody>
          <SectionHeader label="D) A munkabaleset részletes leírása" />
          <tr>
            <td colSpan={6} className="border border-foreground/30 p-2 text-xs whitespace-pre-wrap min-h-[80px]">
              {r.detailed_description || ""}
            </td>
          </tr>
        </tbody>
      </table>

      {/* E) Additional info */}
      <table className="w-full border-collapse mb-2">
        <tbody>
          <SectionHeader label="E) Egyéb információk" />
          <tr>
            <Cell label="Munkahelyi környezet" value={r.workplace_environment} span={3} />
            <Cell label="Munkafolyamat" value={r.work_process} span={3} />
          </tr>
          <tr>
            <Cell label="Sérült fizikai tevékenysége" value={r.physical_activity} span={3} />
            <Cell label="Tárgyi tényezője" value={r.physical_activity_material} span={3} />
          </tr>
          <tr>
            <Cell label="Kiváltó esemény" value={r.triggering_event} span={3} />
            <Cell label="Tárgyi tényezője" value={r.triggering_event_material} span={3} />
          </tr>
          <tr>
            <Cell label="Sérülést okozó érintkezés módja" value={r.injury_contact_mode} span={3} />
            <Cell label="Tárgyi tényezője" value={r.injury_contact_material} span={3} />
          </tr>
          <tr>
            <Cell label="Személyi tényező (sérült)" value={r.personal_factor_injured} span={3} />
            <Cell label="Személyi tényező (munkáltató)" value={r.personal_factor_employer} span={3} />
          </tr>
          <tr>
            <Cell label="Védőburkolat" value={codeName(SAFETY_DEVICE_OPTIONS, r.safety_device_guard)} />
            <Cell label="Védőberendezés" value={codeName(SAFETY_DEVICE_OPTIONS, r.safety_device_protection)} />
            <Cell label="Jelzőberendezés" value={codeName(SAFETY_DEVICE_OPTIONS, r.safety_device_signal)} />
            <Cell label="Egyéni védőeszköz" value={codeName(SAFETY_DEVICE_OPTIONS, r.safety_device_ppe)} />
            <Cell label="Egyéb védelmi megoldás" value={codeName(SAFETY_DEVICE_OPTIONS, r.safety_device_other)} span={2} />
          </tr>
        </tbody>
      </table>

      {/* F) Causes */}
      <table className="w-full border-collapse mb-2">
        <tbody>
          <SectionHeader label="F) A balesethez vezető okok" />
          <tr>
            <td colSpan={6} className="border border-foreground/30 p-2 text-xs whitespace-pre-wrap min-h-[60px]">
              {r.accident_causes || ""}
            </td>
          </tr>
        </tbody>
      </table>

      {/* G) Prevention */}
      <table className="w-full border-collapse mb-2">
        <tbody>
          <SectionHeader label="G) Megelőzési intézkedések" />
          <tr>
            <td colSpan={6} className="border border-foreground/30 p-2 text-xs whitespace-pre-wrap min-h-[60px]">
              {r.prevention_measures || ""}
            </td>
          </tr>
        </tbody>
      </table>

      {/* H) Attachments */}
      <table className="w-full border-collapse mb-2">
        <tbody>
          <SectionHeader label="H) Mellékletek, megjegyzések" />
          <tr>
            <td colSpan={6} className="border border-foreground/30 p-2 text-xs whitespace-pre-wrap min-h-[40px]">
              {r.attachments_notes || ""}
            </td>
          </tr>
        </tbody>
      </table>

      {/* Photos */}
      {photoSignedUrls.length > 0 && (
        <div className="mb-2">
          <div className="text-xs font-bold uppercase tracking-wide bg-muted/50 border border-foreground/30 p-1.5 mb-0">
            Helyszíni fényképek
          </div>
          <div className="grid grid-cols-2 gap-2 border border-foreground/30 border-t-0 p-2">
            {photoSignedUrls.map((url, i) => (
              <img key={i} src={url} alt={`Helyszíni fotó ${i + 1}`} className="w-full h-auto max-h-[200px] object-contain border" />
            ))}
          </div>
        </div>
      )}

      {/* I) Investigators */}
      <table className="w-full border-collapse mb-2">
        <tbody>
          <SectionHeader label="I) A kivizsgálás résztvevői" />
          <tr>
            <td colSpan={6} className="border border-foreground/30 p-0">
              <table className="w-full">
                <tbody>
                  <tr className="text-[10px] text-muted-foreground">
                    <td className="p-1 border-r border-foreground/30 w-1/4">Szerepkör</td>
                    <td className="p-1 border-r border-foreground/30 w-1/4">Név</td>
                    <td className="p-1 border-r border-foreground/30 w-1/4">Dátum</td>
                    <td className="p-1 w-1/4">Egyéb</td>
                  </tr>
                  <tr className="text-xs">
                    <td className="p-1.5 border-r border-t border-foreground/30 font-medium">Munkavédelmi képviselő</td>
                    <td className="p-1.5 border-r border-t border-foreground/30">{r.safety_rep_name || ""}</td>
                    <td className="p-1.5 border-r border-t border-foreground/30">{r.safety_rep_date || ""}</td>
                    <td className="p-1.5 border-t border-foreground/30">{codeName(SAFETY_REP_AGREEMENT, r.safety_rep_agreement)}</td>
                  </tr>
                  <tr className="text-xs">
                    <td className="p-1.5 border-r border-t border-foreground/30 font-medium">Baleset kivizsgálója</td>
                    <td className="p-1.5 border-r border-t border-foreground/30">{r.investigator_name || ""}</td>
                    <td className="p-1.5 border-r border-t border-foreground/30">{r.investigator_date || ""}</td>
                    <td className="p-1.5 border-t border-foreground/30">Iratszám: {r.investigator_cert_no || ""}</td>
                  </tr>
                  <tr className="text-xs">
                    <td className="p-1.5 border-r border-t border-foreground/30 font-medium">Fogl.eü. orvos</td>
                    <td className="p-1.5 border-r border-t border-foreground/30">{r.doctor_name || ""}</td>
                    <td className="p-1.5 border-r border-t border-foreground/30">{r.doctor_date || ""}</td>
                    <td className="p-1.5 border-t border-foreground/30">Pecsétszám: {r.doctor_stamp_no || ""}</td>
                  </tr>
                  <tr className="text-xs">
                    <td className="p-1.5 border-r border-t border-foreground/30 font-medium">Munkáltató képv.</td>
                    <td className="p-1.5 border-r border-t border-foreground/30">{r.employer_rep_name || ""}</td>
                    <td className="p-1.5 border-r border-t border-foreground/30">{r.employer_rep_date || ""}</td>
                    <td className="p-1.5 border-t border-foreground/30">Beosztás: {r.employer_rep_position || ""}</td>
                  </tr>
                </tbody>
              </table>
            </td>
          </tr>
        </tbody>
      </table>

      {/* Footer */}
      <div className="text-center text-[10px] text-muted-foreground mt-6 pt-2 border-t border-foreground/20">
        Készült: {new Date().toLocaleDateString("hu-HU")} — Munkabaleseti Jegyzőkönyv (MBJKV 2025)
      </div>
    </div>
  );
}
