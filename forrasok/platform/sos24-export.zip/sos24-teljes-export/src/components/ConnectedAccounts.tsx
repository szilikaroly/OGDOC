import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { UserIdentity } from "@supabase/supabase-js";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Link2, Unlink, Mail } from "lucide-react";

const PROVIDER_LABELS: Record<string, string> = {
  google: "Google",
  email: "E-mail / jelszó",
  apple: "Apple",
};

type LinkableProvider = "google" | "apple";

export default function ConnectedAccounts() {
  const { toast } = useToast();
  const [identities, setIdentities] = useState<UserIdentity[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.auth.getUserIdentities();
    if (error) {
      toast({ variant: "destructive", title: "Hiba", description: error.message });
    } else {
      setIdentities((data?.identities ?? []) as UserIdentity[]);
    }
    setLoading(false);
  }, [toast]);

  useEffect(() => { load(); }, [load]);

  const linkProvider = async (provider: LinkableProvider) => {
    // Megakadályozzuk a duplikált linkelést ugyanahhoz a providerhez
    if (identities.some((i) => i.provider === provider)) {
      toast({
        title: "Már össze van kapcsolva",
        description: `${PROVIDER_LABELS[provider]} fiók már aktív.`,
      });
      return;
    }
    setBusy(provider);
    const { error } = await supabase.auth.linkIdentity({
      provider,
      options: { redirectTo: `${window.location.origin}/munkavallalo/settings` },
    });
    if (error) {
      toast({ variant: "destructive", title: "Nem sikerült összekapcsolni", description: error.message });
      setBusy(null);
    }
  };

  const unlink = async (identity: UserIdentity) => {
    if (identities.length <= 1) {
      toast({
        variant: "destructive",
        title: "Nem leválasztható",
        description: "Legalább egy bejelentkezési módnak maradnia kell.",
      });
      return;
    }
    // Az unlinkIdentity a teljes UserIdentity objektumot várja (identity_id alapján azonosít)
    if (!identity.identity_id) {
      toast({
        variant: "destructive",
        title: "Hiba",
        description: "Hiányzó identity azonosító – frissítsd az oldalt és próbáld újra.",
      });
      return;
    }
    setBusy(identity.identity_id);
    const { error } = await supabase.auth.unlinkIdentity(identity);
    if (error) {
      toast({ variant: "destructive", title: "Hiba", description: error.message });
    } else {
      toast({
        title: "Leválasztva",
        description: PROVIDER_LABELS[identity.provider] ?? identity.provider,
      });
      await load();
    }
    setBusy(null);
  };

  const hasGoogle = identities.some((i) => i.provider === "google");
  const hasApple = identities.some((i) => i.provider === "apple");

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          <Link2 className="h-5 w-5" /> Összekapcsolt fiókok
        </CardTitle>
        <CardDescription>
          Kapcsold össze a Google vagy Apple fiókodat, hogy ugyanazzal az e-mail címmel azonos felhasználóként lépj be.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {loading ? (
          <p className="text-sm text-muted-foreground">Betöltés…</p>
        ) : (
          <ul className="space-y-2">
            {identities.map((id) => {
              const email = (id.identity_data as { email?: string } | null)?.email;
              const key = id.identity_id ?? `${id.provider}-${id.id}`;
              return (
                <li key={key} className="flex items-center justify-between rounded-md border p-3">
                  <div className="flex items-center gap-3">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <div className="text-sm font-medium">{PROVIDER_LABELS[id.provider] ?? id.provider}</div>
                      {email && <div className="text-xs text-muted-foreground">{email}</div>}
                    </div>
                    <Badge variant="secondary">Aktív</Badge>
                  </div>
                  {id.provider !== "email" && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => unlink(id)}
                      disabled={busy === id.identity_id || identities.length <= 1}
                    >
                      <Unlink className="h-4 w-4 mr-1" />
                      {busy === id.identity_id ? "Leválasztás…" : "Leválasztás"}
                    </Button>
                  )}
                </li>
              );
            })}
          </ul>
        )}

        <div className="flex flex-wrap gap-2">
          {!hasGoogle && (
            <Button onClick={() => linkProvider("google")} disabled={busy === "google"} variant="outline">
              <Link2 className="h-4 w-4 mr-2" />
              {busy === "google" ? "Átirányítás…" : "Google fiók összekapcsolása"}
            </Button>
          )}

          {!hasApple && (
            <Button onClick={() => linkProvider("apple")} disabled={busy === "apple"} variant="outline">
              <Link2 className="h-4 w-4 mr-2" />
              {busy === "apple" ? "Átirányítás…" : "Apple fiók összekapcsolása"}
            </Button>
          )}
        </div>

        <p className="text-xs text-muted-foreground">
          Ha új Google vagy Apple bejelentkezésnél már létezik fiók az adott e-mail címmel, a rendszer automatikusan
          ahhoz társítja az identitást – így nem jön létre duplikátum.
        </p>
      </CardContent>
    </Card>
  );
}
