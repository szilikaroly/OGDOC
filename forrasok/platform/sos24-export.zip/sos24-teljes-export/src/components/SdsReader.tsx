import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AlertTriangle, Upload, Loader2, FlaskConical, ShieldAlert, Activity } from "lucide-react";
import { toast } from "sonner";

interface SdsAnalysis {
  substance_name: string;
  cas_number: string;
  ec_number: string;
  hazard_statements: { code: string; text: string; category: string }[];
  precautionary_statements: { code: string; text: string }[];
  ghs_classification: string[];
  exposure_limits: { type: string; value: string; unit: string }[];
  ppe_required: string[];
  first_aid: string[];
  fire_fighting: string[];
  physical_properties: Record<string, string>;
  risk_level: "low" | "medium" | "high" | "very_high";
  matched_svhc: boolean;
  svhc_reason: string | null;
}

interface CumulativeRisk {
  total_risk_score: number;
  category: string;
  dominant_hazards: string[];
  combined_exposure_concerns: string[];
  recommended_controls: string[];
  monitoring_requirements: string[];
}

export default function SdsReader() {
  const { t } = useTranslation();
  const [sdsText, setSdsText] = useState("");
  const [analyzing, setAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<SdsAnalysis | null>(null);
  const [workAreaId, setWorkAreaId] = useState("");
  const [cumulativeRisk, setCumulativeRisk] = useState<CumulativeRisk | null>(null);
  const [calcCumulative, setCalcCumulative] = useState(false);

  // Fetch work areas for cumulative risk
  const { data: workAreas } = useQuery({
    queryKey: ["all-work-areas"],
    queryFn: async () => {
      const { data: sites } = await (supabase as any).from("company_sites").select("id, name, company_id");
      const { data: areas } = await (supabase as any).from("work_areas").select("id, name, site_id");
      const { data: companies } = await (supabase as any).from("companies").select("id, name");
      return (areas ?? []).map((a: any) => {
        const site = (sites ?? []).find((s: any) => s.id === a.site_id);
        const company = site ? (companies ?? []).find((c: any) => c.id === site.company_id) : null;
        return { ...a, siteName: site?.name, companyName: company?.name };
      });
    },
  });

  const analyzeSds = async () => {
    if (!sdsText.trim()) { toast.error(t("substances.sdsEmpty")); return; }
    setAnalyzing(true);
    setAnalysis(null);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const res = await supabase.functions.invoke("ai-sds-analysis", {
        body: { sds_text: sdsText, work_area_id: workAreaId || undefined },
      });
      if (res.error) throw res.error;
      setAnalysis(res.data.analysis);
      if (res.data.cumulative_risk) setCumulativeRisk(res.data.cumulative_risk);
    } catch (e: any) {
      toast.error(e.message || t("substances.sdsError"));
    } finally {
      setAnalyzing(false);
    }
  };

  const calculateCumulativeRisk = async () => {
    if (!workAreaId) { toast.error(t("substances.selectWorkArea")); return; }
    setCalcCumulative(true);
    setCumulativeRisk(null);
    try {
      const res = await supabase.functions.invoke("ai-sds-analysis", {
        body: { work_area_id: workAreaId, cumulative_only: true },
      });
      if (res.error) throw res.error;
      setCumulativeRisk(res.data.cumulative_risk);
    } catch (e: any) {
      toast.error(e.message || t("substances.sdsError"));
    } finally {
      setCalcCumulative(false);
    }
  };

  const riskColor = (level: string) => {
    switch (level) {
      case "low": return "bg-green-100 text-green-800";
      case "medium": return "bg-yellow-100 text-yellow-800";
      case "high": return "bg-orange-100 text-orange-800";
      case "very_high": return "bg-red-100 text-red-800";
      default: return "bg-muted text-muted-foreground";
    }
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Upload className="h-4 w-4" />
            {t("substances.sdsInput")}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>{t("substances.pasteSds")}</Label>
            <Textarea
              value={sdsText}
              onChange={e => setSdsText(e.target.value)}
              placeholder={t("substances.sdsPlaceholder")}
              rows={8}
              className="font-mono text-xs"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>{t("substances.workArea")}</Label>
              <Select value={workAreaId} onValueChange={setWorkAreaId}>
                <SelectTrigger><SelectValue placeholder={t("substances.selectWorkArea")} /></SelectTrigger>
                <SelectContent>
                  {(workAreas ?? []).map((wa: any) => (
                    <SelectItem key={wa.id} value={wa.id}>
                      {wa.companyName} → {wa.siteName} → {wa.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex gap-2">
            <Button onClick={analyzeSds} disabled={analyzing || !sdsText.trim()}>
              {analyzing ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <FlaskConical className="h-4 w-4 mr-2" />}
              {t("substances.analyzeSds")}
            </Button>
            {workAreaId && (
              <Button variant="outline" onClick={calculateCumulativeRisk} disabled={calcCumulative}>
                {calcCumulative ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Activity className="h-4 w-4 mr-2" />}
                {t("substances.cumulativeRisk")}
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* SDS Analysis Result */}
      {analysis && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <FlaskConical className="h-4 w-4" />
              {analysis.substance_name}
              <Badge className={riskColor(analysis.risk_level)}>
                {t(`substances.risk_${analysis.risk_level}`)}
              </Badge>
              {analysis.matched_svhc && (
                <Badge variant="destructive">SVHC</Badge>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
              <div><span className="text-muted-foreground">CAS:</span> <span className="font-mono">{analysis.cas_number || "-"}</span></div>
              <div><span className="text-muted-foreground">EC:</span> <span className="font-mono">{analysis.ec_number || "-"}</span></div>
              {analysis.svhc_reason && (
                <div className="col-span-2"><span className="text-muted-foreground">SVHC:</span> {analysis.svhc_reason}</div>
              )}
            </div>

            {/* GHS Classification */}
            {analysis.ghs_classification?.length > 0 && (
              <div>
                <Label className="text-sm font-semibold">{t("substances.ghsClassification")}</Label>
                <div className="flex flex-wrap gap-1 mt-1">
                  {analysis.ghs_classification.map((g, i) => (
                    <Badge key={i} variant="outline">{g}</Badge>
                  ))}
                </div>
              </div>
            )}

            {/* Hazard Statements */}
            {analysis.hazard_statements?.length > 0 && (
              <div>
                <Label className="text-sm font-semibold">{t("substances.hazardStatements")}</Label>
                <ScrollArea className="max-h-48">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-20">{t("substances.code")}</TableHead>
                        <TableHead>{t("substances.statement")}</TableHead>
                        <TableHead className="w-32">{t("substances.category")}</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {analysis.hazard_statements.map((h, i) => (
                        <TableRow key={i}>
                          <TableCell className="font-mono text-xs">{h.code}</TableCell>
                          <TableCell className="text-sm">{h.text}</TableCell>
                          <TableCell><Badge variant="outline" className="text-xs">{h.category}</Badge></TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </ScrollArea>
              </div>
            )}

            {/* Exposure Limits */}
            {analysis.exposure_limits?.length > 0 && (
              <div>
                <Label className="text-sm font-semibold">{t("substances.exposureLimits")}</Label>
                <div className="grid grid-cols-3 gap-2 mt-1">
                  {analysis.exposure_limits.map((el, i) => (
                    <Card key={i} className="p-2">
                      <div className="text-xs text-muted-foreground">{el.type}</div>
                      <div className="font-semibold">{el.value} {el.unit}</div>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {/* PPE */}
            {analysis.ppe_required?.length > 0 && (
              <div>
                <Label className="text-sm font-semibold">{t("substances.ppeRequired")}</Label>
                <div className="flex flex-wrap gap-1 mt-1">
                  {analysis.ppe_required.map((p, i) => (
                    <Badge key={i} variant="secondary">{p}</Badge>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Cumulative Risk */}
      {cumulativeRisk && (
        <Card className="border-orange-200">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <ShieldAlert className="h-4 w-4" />
              {t("substances.cumulativeRiskTitle")}
              <Badge className={riskColor(cumulativeRisk.category)}>
                {t("substances.riskScore")}: {cumulativeRisk.total_risk_score}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {cumulativeRisk.dominant_hazards?.length > 0 && (
              <div>
                <Label className="text-sm font-semibold">{t("substances.dominantHazards")}</Label>
                <ul className="list-disc list-inside text-sm mt-1 space-y-0.5">
                  {cumulativeRisk.dominant_hazards.map((h, i) => <li key={i}>{h}</li>)}
                </ul>
              </div>
            )}
            {cumulativeRisk.combined_exposure_concerns?.length > 0 && (
              <div>
                <Label className="text-sm font-semibold">{t("substances.combinedExposure")}</Label>
                <ul className="list-disc list-inside text-sm mt-1 space-y-0.5">
                  {cumulativeRisk.combined_exposure_concerns.map((c, i) => <li key={i}>{c}</li>)}
                </ul>
              </div>
            )}
            {cumulativeRisk.recommended_controls?.length > 0 && (
              <div>
                <Label className="text-sm font-semibold">{t("substances.recommendedControls")}</Label>
                <ul className="list-disc list-inside text-sm mt-1 space-y-0.5">
                  {cumulativeRisk.recommended_controls.map((c, i) => <li key={i}>{c}</li>)}
                </ul>
              </div>
            )}
            {cumulativeRisk.monitoring_requirements?.length > 0 && (
              <div>
                <Label className="text-sm font-semibold">{t("substances.monitoringReq")}</Label>
                <ul className="list-disc list-inside text-sm mt-1 space-y-0.5">
                  {cumulativeRisk.monitoring_requirements.map((m, i) => <li key={i}>{m}</li>)}
                </ul>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
