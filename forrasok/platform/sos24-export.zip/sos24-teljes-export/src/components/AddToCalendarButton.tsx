import { Button } from "@/components/ui/button";
import { CalendarPlus } from "lucide-react";
import { downloadICS } from "@/lib/ics-generator";
import { useTranslation } from "react-i18next";

interface AddToCalendarButtonProps {
  title: string;
  startDate: Date;
  endDate: Date;
  description?: string;
  location?: string;
  className?: string;
}

export default function AddToCalendarButton({
  title,
  startDate,
  endDate,
  description,
  location,
  className,
}: AddToCalendarButtonProps) {
  const { t } = useTranslation();
  return (
    <Button
      variant="outline"
      size="sm"
      className={className}
      onClick={() =>
        downloadICS({ title, startDate, endDate, description, location })
      }
    >
      <CalendarPlus className="h-4 w-4 mr-1" />
      {t("calendar.addToCalendar")}
    </Button>
  );
}
