import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { History, Download, Eye, Loader2, CheckCircle2, XCircle, AlertTriangle, RefreshCw } from "lucide-react";
import { exportImportLog, type ImportLogRow } from "@/lib/import-export";


const AUTO_OPEN_PREF_KEY = "bulkImportHistory.autoOpenLatest";
const AUTO_REFRESH_PREF_KEY = "bulkImportHistory.autoRefresh";
const AUTO_REFRESH_INTERVAL_KEY = "bulkImportHistory.autoRefreshMs";
const REFRESH_OPTIONS = [
  { label: "10 mp", value: 10000 },
  { label: "20 mp", value: 20000 },
  { label: "60 mp", value: 60000 },
];


interface LogRow {
  id: string;
  created_at: string;
  file_name: string | null;
  total_rows: number;
  success_count: number;
  duplicate_count: number;
  error_count: number;
  new_count: number;
  details: ImportLogRow[];
}

interface BulkImportHistoryProps {
  /** When true, automatically opens the most recent log in the details modal after each (re)load. */
  autoOpenLatest?: boolean;
  /** Polling interval in ms. 0 disables polling. Defaults to 0. */
  pollIntervalMs?: number;
}

export default function BulkImportHistory({ autoOpenLatest = false, pollIntervalMs = 0 }: BulkImportHistoryProps = {}) {
  const [logs, setLogs] = useState<LogRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [consecutiveFailures, setConsecutiveFailures] = useState(0);
  const [countdown, setCountdown] = useState<string | null>(null);
  const [permanentError, setPermanentError] = useState(false);
  const [viewing, setViewing] = useState<LogRow | null>(null);
  const [lastSeenId, setLastSeenId] = useState<string | null>(null);
  const initializedRef = useRef(false);
  const reqSeqRef = useRef(0);
  const inFlightRef = useRef(false);
  const mountedRef = useRef(true);
  const failuresRef = useRef(0);
  const backoffTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const spinnerTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const countdownIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const nextRetryAtRef = useRef<number | null>(null);

  // Backoff config: 2s, 4s, 8s, 16s, 32s, capped at 60s.
  const BACKOFF_BASE_MS = 2000;
  const BACKOFF_MAX_MS = 60000;
  // Don't reveal the spinner for fast background polls — avoids flicker.
  const SPINNER_REVEAL_DELAY_MS = 600;
  // Don't surface the error banner for a single transient failure.
  const ERROR_VISIBILITY_THRESHOLD = 2;
  // After this many consecutive failures we give up and show a permanent error.
  const MAX_RETRY_ATTEMPTS = 6;

  const [autoOpenEnabled, setAutoOpenEnabled] = useState<boolean>(() => {
    if (typeof window === "undefined") return autoOpenLatest;
    const v = window.localStorage.getItem(AUTO_OPEN_PREF_KEY);
    return v === null ? autoOpenLatest : v === "1";
  });

  const [autoRefreshEnabled, setAutoRefreshEnabled] = useState<boolean>(() => {
    if (typeof window === "undefined") return pollIntervalMs > 0;
    const v = window.localStorage.getItem(AUTO_REFRESH_PREF_KEY);
    return v === null ? pollIntervalMs > 0 : v === "1";
  });
  const [refreshIntervalMs, setRefreshIntervalMs] = useState<number>(() => {
    if (typeof window === "undefined") return pollIntervalMs > 0 ? pollIntervalMs : 15000;
    const v = window.localStorage.getItem(AUTO_REFRESH_INTERVAL_KEY);
    const parsed = v ? parseInt(v, 10) : NaN;
    return Number.isFinite(parsed) && parsed >= 5000 ? parsed : 15000;
  });
  const [lastRefreshAt, setLastRefreshAt] = useState<Date | null>(null);

  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
      if (backoffTimerRef.current) clearTimeout(backoffTimerRef.current);
      if (spinnerTimerRef.current) clearTimeout(spinnerTimerRef.current);
      if (intervalRef.current) clearInterval(intervalRef.current);
      if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
      nextRetryAtRef.current = null;
    };
  }, []);

  useEffect(() => {
    if (typeof window !== "undefined") {
      window.localStorage.setItem(AUTO_OPEN_PREF_KEY, autoOpenEnabled ? "1" : "0");
    }
  }, [autoOpenEnabled]);

  useEffect(() => {
    if (typeof window !== "undefined") {
      window.localStorage.setItem(AUTO_REFRESH_PREF_KEY, autoRefreshEnabled ? "1" : "0");
      window.localStorage.setItem(AUTO_REFRESH_INTERVAL_KEY, String(refreshIntervalMs));
    }
  }, [autoRefreshEnabled, refreshIntervalMs]);

  const scheduleBackoffRetry = () => {
    if (backoffTimerRef.current) clearTimeout(backoffTimerRef.current);
    if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
    if (failuresRef.current >= MAX_RETRY_ATTEMPTS) {
      setPermanentError(true);
      setCountdown(null);
      return;
    }
    const attempt = failuresRef.current;
    const delay = Math.min(BACKOFF_MAX_MS, BACKOFF_BASE_MS * Math.pow(2, Math.max(0, attempt - 1)));
    nextRetryAtRef.current = Date.now() + delay;

    countdownIntervalRef.current = setInterval(() => {
      if (!mountedRef.current || !nextRetryAtRef.current) {
        if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
        countdownIntervalRef.current = null;
        setCountdown(null);
        return;
      }
      const remainingSec = Math.max(0, Math.ceil((nextRetryAtRef.current - Date.now()) / 1000));
      if (remainingSec <= 0) {
        setCountdown(null);
      } else {
        setCountdown(`${remainingSec} mp`);
      }
    }, 1000);
    setCountdown(`${Math.ceil(delay / 1000)} mp`);

    backoffTimerRef.current = setTimeout(() => {
      backoffTimerRef.current = null;
      nextRetryAtRef.current = null;
      if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
      countdownIntervalRef.current = null;
      setCountdown(null);
      if (mountedRef.current) load({ silent: true });
    }, delay);
  };

  const load = async (opts: { silent?: boolean; manual?: boolean } = {}) => {
    // Drop overlapping polls so the UI never shows stale data over fresher data.
    if (inFlightRef.current) return;
    inFlightRef.current = true;
    const mySeq = ++reqSeqRef.current;

    // Reset permanent error / backoff state on explicit manual refresh.
    if (opts.manual) {
      failuresRef.current = 0;
      setConsecutiveFailures(0);
      setPermanentError(false);
      setError(null);
      if (backoffTimerRef.current) {
        clearTimeout(backoffTimerRef.current);
        backoffTimerRef.current = null;
      }
      if (countdownIntervalRef.current) {
        clearInterval(countdownIntervalRef.current);
        countdownIntervalRef.current = null;
      }
      nextRetryAtRef.current = null;
      setCountdown(null);
    }

    // Reveal the spinner only if the request is slow — prevents flicker on fast polls.
    // Manual refresh shows it immediately for responsive feedback.
    if (spinnerTimerRef.current) clearTimeout(spinnerTimerRef.current);
    if (opts.manual) {
      setRefreshing(true);
    } else {
      spinnerTimerRef.current = setTimeout(() => {
        if (mountedRef.current && inFlightRef.current && mySeq === reqSeqRef.current) {
          setRefreshing(true);
        }
      }, SPINNER_REVEAL_DELAY_MS);
    }

    try {
      const { data, error: queryError } = await supabase
        .from("bulk_import_logs")
        .select("*")
        .eq("import_type", "patients")
        .order("created_at", { ascending: false })
        .limit(20);
      // Discard responses from a stale request or after unmount.
      if (!mountedRef.current || mySeq !== reqSeqRef.current) return;
      if (queryError) {
        failuresRef.current += 1;
        setConsecutiveFailures(failuresRef.current);
        if (failuresRef.current >= ERROR_VISIBILITY_THRESHOLD) {
          setError(queryError.message || "Ismeretlen hiba az importnapló lekérésekor.");
        }
        if (autoRefreshEnabled) scheduleBackoffRetry();
      } else {
        failuresRef.current = 0;
        setConsecutiveFailures(0);
        setError(null);
        setPermanentError(false);
        setLogs((data || []) as unknown as LogRow[]);
        setLastRefreshAt(new Date());
      }
    } catch (e: unknown) {
      if (!mountedRef.current || mySeq !== reqSeqRef.current) return;
      failuresRef.current += 1;
      setConsecutiveFailures(failuresRef.current);
      if (failuresRef.current >= ERROR_VISIBILITY_THRESHOLD) {
        setError(e instanceof Error ? e.message : "Hálózati hiba az importnapló lekérésekor.");
      }
      if (autoRefreshEnabled) scheduleBackoffRetry();
    } finally {
      if (mountedRef.current && mySeq === reqSeqRef.current) {
        setLoading(false);
        if (spinnerTimerRef.current) {
          clearTimeout(spinnerTimerRef.current);
          spinnerTimerRef.current = null;
        }
        setRefreshing(false);
      }
      inFlightRef.current = false;
    }
  };

  useEffect(() => {
    setLoading(true);
    failuresRef.current = 0;
    if (backoffTimerRef.current) {
      clearTimeout(backoffTimerRef.current);
      backoffTimerRef.current = null;
    }
    load();
    if (autoRefreshEnabled && refreshIntervalMs > 0) {
      intervalRef.current = setInterval(() => {
        // Skip the regular tick while a backoff retry is pending — the retry
        // timer owns the next attempt to honor exponential spacing.
        if (backoffTimerRef.current) return;
        load({ silent: true });
      }, refreshIntervalMs);
      return () => {
        if (intervalRef.current) clearInterval(intervalRef.current);
        intervalRef.current = null;
      };
    }
  }, [autoRefreshEnabled, refreshIntervalMs]);

  // A log is "ready" when its details are present and no row is still pending.
  const isLogReady = (l: LogRow | undefined | null): boolean => {
    if (!l) return false;
    const details = l.details || [];
    if (details.length === 0) return false;
    if (details.length < l.total_rows) return false;
    return !details.some((r) => r.status === "pending");
  };

  // Auto-open the most recent log when it changes — but only after the first
  // load has settled, only when not refreshing, and only when the log is ready.
  useEffect(() => {
    if (loading || refreshing || error) return;
    if (logs.length === 0) return;
    const latest = logs[0];

    // On the very first successful load, seed lastSeenId without opening so we
    // don't pop up a stale log on mount.
    if (!initializedRef.current) {
      initializedRef.current = true;
      setLastSeenId(latest.id);
      return;
    }

    if (!autoOpenEnabled) return;
    if (latest.id === lastSeenId) return;
    if (!isLogReady(latest)) return; // wait until details are fully populated

    setLastSeenId(latest.id);
    setViewing(latest);
  }, [logs, autoOpenEnabled, lastSeenId, loading, refreshing, error]);



  if (loading) {
    return (
      <Card className="mt-4">
        <CardContent className="p-4 text-sm text-muted-foreground flex items-center gap-2">
          <Loader2 className="h-4 w-4 animate-spin" /> Import napló betöltése...
        </CardContent>
      </Card>
    );
  }

  if (error && logs.length === 0) {
    return (
      <Card className="mt-4 border-destructive/40">
        <CardContent className="p-4 text-sm flex items-center justify-between gap-2">
          <span className="flex items-center gap-2 text-destructive">
            <XCircle className="h-4 w-4" /> Nem sikerült betölteni az importnaplót: {error}
          </span>
          <Button variant="outline" size="sm" onClick={() => load({ manual: true })} disabled={refreshing}>
            <RefreshCw className={`h-3.5 w-3.5 mr-1 ${refreshing ? "animate-spin" : ""}`} /> Újrapróbálom
          </Button>
        </CardContent>
      </Card>
    );
  }

  if (logs.length === 0) {
    return (
      <Card className="mt-4">
        <CardContent className="p-4 text-sm text-muted-foreground flex items-center gap-2">
          <History className="h-4 w-4" /> Még nincs korábbi import.
        </CardContent>
      </Card>
    );
  }


  const latest = logs[0];

  return (
    <Card className="mt-4">
      <CardHeader className="pb-2">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <CardTitle className="text-base flex items-center gap-2"><History className="h-4 w-4" /> Korábbi importok</CardTitle>
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-2">
              <Switch
                id="auto-refresh"
                checked={autoRefreshEnabled}
                onCheckedChange={setAutoRefreshEnabled}
              />
              <Label htmlFor="auto-refresh" className="text-xs text-muted-foreground cursor-pointer">
                Automatikus frissítés
              </Label>
              <select
                aria-label="Frissítési intervallum"
                disabled={!autoRefreshEnabled}
                value={refreshIntervalMs}
                onChange={(e) => setRefreshIntervalMs(parseInt(e.target.value, 10))}
                className="h-7 rounded-md border bg-background px-1.5 text-xs disabled:opacity-50"
              >
                {REFRESH_OPTIONS.map((o) => (
                  <option key={o.value} value={o.value}>{o.label}</option>
                ))}
              </select>
              <Button variant="ghost" size="sm" className="h-7 px-2" onClick={() => load({ manual: true })} disabled={refreshing} title="Frissítés most">
                <RefreshCw className={`h-3.5 w-3.5 ${refreshing ? "animate-spin" : ""}`} />
              </Button>

              {lastRefreshAt && (
                <span className="text-[11px] text-muted-foreground">
                  {lastRefreshAt.toLocaleTimeString("hu-HU")}
                </span>
              )}
            </div>
            <div className="flex items-center gap-2">
              <Switch
                id="auto-open-latest"
                checked={autoOpenEnabled}
                onCheckedChange={setAutoOpenEnabled}
              />
              <Label htmlFor="auto-open-latest" className="text-xs text-muted-foreground cursor-pointer">
                Automatikus megnyitás új importnál
              </Label>
            </div>
          </div>
        </div>
      </CardHeader>


      <CardContent>
        {(error || permanentError) && (
          <div className="mb-3 flex items-center justify-between gap-2 rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs text-destructive">
            <span className="flex items-center gap-1.5">
              <AlertTriangle className="h-3.5 w-3.5" />
              {permanentError
                ? `Az automatikus frissítés ${MAX_RETRY_ATTEMPTS} próbálkozás után sem sikerült. A megjelenített adatok nem naprakészek. Kérjük, frissítse manuálisan.`
                : `Frissítés nem sikerült (${consecutiveFailures}. próbálkozás): ${error}. A megjelenített adat lehet, hogy nem naprakész.`}
              {!permanentError && autoRefreshEnabled && backoffTimerRef.current
                ? ` Újrapróbálkozás ${countdown ? `${countdown} múlva` : "hamarosan"}…`
                : ""}
            </span>
            <Button variant="ghost" size="sm" className="h-6 px-2 text-destructive hover:text-destructive" onClick={() => load({ manual: true })} disabled={refreshing}>
              <RefreshCw className={`h-3 w-3 mr-1 ${refreshing ? "animate-spin" : ""}`} /> {permanentError ? "Manuális frissítés" : "Újra"}
            </Button>
          </div>
        )}

        <div className="mb-3 rounded-md border bg-muted/40 p-3 text-sm">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="font-medium">
              Legutóbbi import — {new Date(latest.created_at).toLocaleString("hu-HU")}
              {latest.file_name ? <span className="text-muted-foreground"> · {latest.file_name}</span> : null}
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="secondary">Összes: {latest.total_rows}</Badge>
              <Badge className="bg-green-600">Sikeres: {latest.success_count}</Badge>
              {latest.duplicate_count > 0 && <Badge variant="outline" className="border-yellow-500 text-yellow-700">Duplum: {latest.duplicate_count}</Badge>}
              {latest.error_count > 0 && <Badge variant="destructive">Hiba: {latest.error_count}</Badge>}
              <Button variant="outline" size="sm" onClick={() => setViewing(latest)}>
                <Eye className="h-4 w-4 mr-1" /> Részletek
              </Button>
            </div>
          </div>
        </div>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Dátum</TableHead>
                <TableHead>Fájl</TableHead>
                <TableHead>Összes</TableHead>
                <TableHead>Sikeres</TableHead>
                <TableHead>Duplum</TableHead>
                <TableHead>Hiba</TableHead>
                <TableHead className="text-right">Művelet</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {logs.map((l) => (
                <TableRow key={l.id}>
                  <TableCell className="whitespace-nowrap">{new Date(l.created_at).toLocaleString("hu-HU")}</TableCell>
                  <TableCell className="max-w-[220px] truncate" title={l.file_name || ""}>{l.file_name || "—"}</TableCell>
                  <TableCell><Badge variant="secondary">{l.total_rows}</Badge></TableCell>
                  <TableCell><Badge className="bg-green-600">{l.success_count}</Badge></TableCell>
                  <TableCell>{l.duplicate_count > 0 ? <Badge variant="outline" className="border-yellow-500 text-yellow-700">{l.duplicate_count}</Badge> : "—"}</TableCell>
                  <TableCell>{l.error_count > 0 ? <Badge variant="destructive">{l.error_count}</Badge> : "—"}</TableCell>
                  <TableCell className="text-right space-x-1">
                    <Button variant="ghost" size="sm" onClick={() => setViewing(l)}>
                      <Eye className="h-4 w-4 mr-1" /> Megnyit
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => exportImportLog(l.details || [], `import_napo_${l.id.slice(0, 8)}`)}>
                      <Download className="h-4 w-4 mr-1" /> XLSX
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>

      <Dialog open={!!viewing} onOpenChange={(v) => !v && setViewing(null)}>
        <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Import napló — {viewing?.file_name || "—"}</DialogTitle>
          </DialogHeader>
          {viewing && (
            <>
              <div className="flex flex-wrap gap-2 text-sm">
                <Badge variant="secondary">{viewing.total_rows} összes</Badge>
                <Badge className="bg-green-600">{viewing.success_count} sikeres</Badge>
                {viewing.duplicate_count > 0 && <Badge variant="outline" className="border-yellow-500 text-yellow-700">{viewing.duplicate_count} duplum</Badge>}
                {viewing.error_count > 0 && <Badge variant="destructive">{viewing.error_count} hiba</Badge>}
                <span className="text-muted-foreground">{new Date(viewing.created_at).toLocaleString("hu-HU")}</span>
              </div>

              <div className="space-y-3 mt-3">
                {(viewing.details || []).map((r, i) => {
                  const fields: Array<[string, string | undefined]> = [
                    ["Teljes név", r.full_name],
                    ["Email", r.email],
                    ["TAJ szám", r.taj_number],
                    ["Születési dátum", r.birth_date],
                    ["Születési hely", r.birth_place],
                    ["Születési név", r.birth_name],
                    ["Anyja neve", r.mother_name],
                    ["Telefon", r.phone],
                    ["Cím", r.address],
                    ["Nem", r.gender],
                    ["Munkakör", r.position],
                    ["FEOR kód", r.feor_code],
                    ["FEOR megnevezés", r.feor_name],
                    ["Telephely", r.site_name],
                    ["Munkahely", r.workplace_name],
                  ];
                  const bio = fields.filter(([k]) => ["TAJ szám", "Születési dátum", "Születési hely", "Születési név", "Anyja neve", "Nem"].includes(k));
                  const input = fields.filter(([k]) => !bio.find(([bk]) => bk === k));
                  const reasonLabel =
                    r.status === "duplicate" ? "Duplikáció oka"
                    : r.status === "error" ? "Érvénytelenítés oka"
                    : r.status === "success" ? "Eredmény"
                    : "Megjegyzés";
                  const reasonText = r.reason_detail || r.error || (r.status === "success" ? "Sikeresen importálva." : "—");
                  const reasonClass =
                    r.status === "duplicate" ? "border-yellow-500/60 bg-yellow-50 dark:bg-yellow-950/30 text-yellow-900 dark:text-yellow-200"
                    : r.status === "error" ? "border-destructive/60 bg-destructive/10 text-destructive"
                    : "border-green-500/60 bg-green-50 dark:bg-green-950/30 text-green-900 dark:text-green-200";

                  return (
                    <div key={i} className="border rounded-lg p-3">
                      <div className="flex items-center justify-between gap-2 mb-2">
                        <div className="font-medium text-sm">
                          #{i + 1} · {r.full_name || "—"}
                        </div>
                        {r.status === "success" && <Badge className="bg-green-600"><CheckCircle2 className="h-3 w-3 mr-1" />Sikeres</Badge>}
                        {r.status === "duplicate" && <Badge variant="outline" className="border-yellow-500 text-yellow-700"><AlertTriangle className="h-3 w-3 mr-1" />Duplum</Badge>}
                        {r.status === "error" && <Badge variant="destructive"><XCircle className="h-3 w-3 mr-1" />Hiba</Badge>}
                        {r.status === "pending" && <Badge variant="secondary">Vár</Badge>}
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div>
                          <div className="text-xs uppercase tracking-wide text-muted-foreground mb-1">Bemeneti adatok</div>
                          <dl className="text-xs grid grid-cols-[140px_1fr] gap-y-1">
                            {input.map(([k, v]) => (
                              <div key={k} className="contents">
                                <dt className="text-muted-foreground">{k}</dt>
                                <dd className="break-words">{v || <span className="text-muted-foreground/60">—</span>}</dd>
                              </div>
                            ))}
                          </dl>
                        </div>
                        <div>
                          <div className="text-xs uppercase tracking-wide text-muted-foreground mb-1">Felismert biometria / azonosítók</div>
                          <dl className="text-xs grid grid-cols-[140px_1fr] gap-y-1">
                            {bio.map(([k, v]) => (
                              <div key={k} className="contents">
                                <dt className="text-muted-foreground">{k}</dt>
                                <dd className="break-words">{v || <span className="text-muted-foreground/60">—</span>}</dd>
                              </div>
                            ))}
                          </dl>
                        </div>
                      </div>

                      <div className={`mt-3 border rounded-md px-3 py-2 text-xs ${reasonClass}`}>
                        <div className="font-medium mb-0.5">{reasonLabel}{r.reason_category ? ` · ${r.reason_category}` : ""}</div>
                        <div className="whitespace-pre-wrap">{reasonText}</div>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="flex justify-end pt-2">
                <Button variant="outline" onClick={() => exportImportLog(viewing.details || [], `import_napo_${viewing.id.slice(0, 8)}`)}>
                  <Download className="h-4 w-4 mr-1" /> XLSX letöltése
                </Button>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </Card>
  );
}
