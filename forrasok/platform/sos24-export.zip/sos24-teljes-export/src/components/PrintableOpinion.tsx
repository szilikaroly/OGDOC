import { useDocumentTemplate, isFieldVisible } from "@/hooks/use-document-templates";

interface PrintableOpinionProps {
  opinion: {
    patient_name: string;
    patient_taj?: string;
    patient_birth?: string;
    doctor_name: string;
    company_name?: string;
    opinion_date: string;
    valid_until?: string | null;
    status: string;
    notes?: string | null;
    position?: string | null;
    restrictions?: string | null;
    signature_url?: string | null;
  };
  serviceName?: string;
}

const STATUS_LABELS: Record<string, string> = {
  alkalmas: "ALKALMAS",
  nem_alkalmas: "NEM ALKALMAS",
  feltetelesen_alkalmas: "FELTÉTELESEN ALKALMAS",
  ideiglenes: "IDEIGLENESEN NEM ALKALMAS",
};

export default function PrintableOpinion({ opinion, serviceName }: PrintableOpinionProps) {
  const { data: template } = useDocumentTemplate("opinion");
  const show = (key: string) => isFieldVisible(template, key);

  const isAlkalmas = opinion.status === "alkalmas";
  const isIdeiglenes = opinion.status === "ideiglenes" || opinion.status === "feltetelesen_alkalmas";
  const isNemAlkalmas = opinion.status === "nem_alkalmas";

  return (
    <div className="hidden print:block print:p-8 print:text-black" style={{ fontFamily: "'Times New Roman', serif" }}>
      {/* Header */}
      {show("header_regulation") && (
        <div className="flex justify-between items-start mb-2 text-xs italic">
          <span>Munkavédelmi szabályzat</span>
          <span>5. sz. melléklet</span>
        </div>
      )}

      {/* Title */}
      <h1 className="text-center text-base font-bold mt-8 mb-10">
        Elsőfokú munkaköri/szakmai orvosi alkalmassági vélemény
      </h1>

      {/* Service name */}
      {show("service_name") && (
        <div className="mb-6 text-sm">
          <span>Foglalkozás-egészségügyi szolgálat megnevezése: </span>
          <span className="border-b border-black inline-block min-w-[300px]">
            {serviceName || ""}
          </span>
        </div>
      )}

      {/* Body */}
      <div className="text-sm space-y-4">
        <p>A vizsgálat eredménye alapján</p>

        {/* Patient name line */}
        {show("patient_name") && (
          <div className="flex items-end gap-2">
            <span className="border-b border-black flex-1 text-center font-medium pb-0.5">
              {opinion.patient_name}
            </span>
            <span className="whitespace-nowrap">munkavállaló/hallgató</span>
          </div>
        )}

        {/* TAJ */}
        {show("patient_taj") && opinion.patient_taj && (
          <div className="flex items-end gap-2">
            <span>TAJ szám: </span>
            <span className="border-b border-black flex-1 text-center font-medium pb-0.5">
              {opinion.patient_taj}
            </span>
          </div>
        )}

        {/* Birth date */}
        {show("patient_birth") && opinion.patient_birth && (
          <div className="flex items-end gap-2">
            <span>Születési dátum: </span>
            <span className="border-b border-black flex-1 text-center font-medium pb-0.5">
              {new Date(opinion.patient_birth).toLocaleDateString("hu-HU")}
            </span>
          </div>
        )}

        {/* Position line */}
        {show("position") && (
          <div className="flex items-end gap-2">
            <span className="border-b border-black flex-1 text-center font-medium pb-0.5">
              {opinion.position || ""}
            </span>
            <span className="whitespace-nowrap">munkakörben/szakmában</span>
          </div>
        )}

        {/* Status boxes */}
        {show("status_boxes") && (
          <div className="flex justify-center gap-8 mt-8 mb-8">
            <div className={`border-2 border-black px-6 py-3 text-center text-sm font-bold ${isAlkalmas ? "bg-black text-white" : ""}`}>
              ALKALMAS
            </div>
            <div className={`border-2 border-black px-6 py-3 text-center text-sm font-bold ${isIdeiglenes ? "bg-black text-white" : ""}`}>
              IDEIGLENESEN<br />NEM ALKALMAS
            </div>
            <div className={`border-2 border-black px-6 py-3 text-center text-sm font-bold ${isNemAlkalmas ? "bg-black text-white" : ""}`}>
              NEM ALKALMAS
            </div>
          </div>
        )}

        {/* Restrictions */}
        {show("restrictions") && (
          <div className="mt-6">
            <p className="font-bold mb-2">Nevezett munkaköri/szakmai alkalmasságát érintő korlátozás:</p>
            <p className="border-b border-black min-h-[24px] pb-1">
              {opinion.restrictions || ""}
            </p>
          </div>
        )}

        {/* Notes */}
        {show("notes") && opinion.notes && (
          <div className="mt-4">
            <p className="font-bold mb-2">Megjegyzés:</p>
            <p className="border-b border-black min-h-[24px] pb-1">
              {opinion.notes}
            </p>
          </div>
        )}

        {/* AI notes - hidden by default in seed */}
        {show("ai_notes") && (
          <div className="mt-4">
            <p className="font-bold mb-2">AI megjegyzés:</p>
            <p className="border-b border-black min-h-[24px] pb-1">
              {opinion.notes}
            </p>
          </div>
        )}

        {/* Temporary note */}
        {show("valid_until") && isIdeiglenes && opinion.valid_until && (
          <p className="mt-4 text-sm">
            Ideiglenesen nem alkalmas minősítés esetén a legközelebbi vizsgálat{" "}
            <span className="border-b border-black px-2">
              {new Date(opinion.valid_until).toLocaleDateString("hu-HU")}
            </span>
          </p>
        )}

        {/* Date */}
        {show("opinion_date") && (
          <div className="mt-12">
            <span>Kelt: </span>
            <span className="border-b border-black inline-block min-w-[200px] text-center">
              {new Date(opinion.opinion_date).toLocaleDateString("hu-HU")}
            </span>
          </div>
        )}

        {/* Stamp */}
        {show("stamp") && <div className="text-center mt-8">P. H.</div>}

        {/* Signature */}
        {show("signature") && (
          <div className="flex justify-end mt-8">
            <div className="text-center">
              {opinion.signature_url ? (
                <img
                  src={opinion.signature_url}
                  alt="Orvosi aláírás"
                  className="h-16 mx-auto mb-1 object-contain"
                />
              ) : (
                <div className="border-b border-black w-48 mb-1" />
              )}
              <span className="text-xs">véleményező orvos</span>
              <p className="font-medium mt-1">Dr. {opinion.doctor_name}</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
