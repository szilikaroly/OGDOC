import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { Plus, Pencil, Trash2, GripVertical, Check, X, FolderOpen } from "lucide-react";

interface Category {
  id: string;
  name: string;
  sort_order: number;
  is_active: boolean;
}

export default function ServiceCategoryManager() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [newName, setNewName] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState("");

  const { data: categories, isLoading } = useQuery({
    queryKey: ["service-categories-all"],
    queryFn: async () => {
      const { data, error } = await (supabase as any)
        .from("service_categories")
        .select("id, name, sort_order, is_active")
        .order("sort_order");
      if (error) throw error;
      return data as Category[];
    },
  });

  const addMut = useMutation({
    mutationFn: async (name: string) => {
      const maxOrder = Math.max(0, ...(categories ?? []).map((c) => c.sort_order));
      const { error } = await (supabase as any)
        .from("service_categories")
        .insert({ name, sort_order: maxOrder + 1, is_active: true });
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["service-categories-all"] });
      qc.invalidateQueries({ queryKey: ["service-categories"] });
      setNewName("");
      toast({ title: t("admin.categoryCreated") });
    },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  const updateMut = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: Partial<Category> }) => {
      const { error } = await (supabase as any)
        .from("service_categories")
        .update(updates)
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["service-categories-all"] });
      qc.invalidateQueries({ queryKey: ["service-categories"] });
      setEditingId(null);
      toast({ title: t("admin.categoryUpdated") });
    },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  const deleteMut = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await (supabase as any)
        .from("service_categories")
        .delete()
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["service-categories-all"] });
      qc.invalidateQueries({ queryKey: ["service-categories"] });
      toast({ title: t("admin.categoryDeleted") });
    },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  const startEdit = (cat: Category) => {
    setEditingId(cat.id);
    setEditName(cat.name);
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <FolderOpen className="h-4 w-4 text-secondary" />
          {t("admin.categoryManagement")}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex gap-2">
          <Input
            placeholder={t("admin.newCategoryPlaceholder")}
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && newName.trim() && addMut.mutate(newName.trim())}
            className="flex-1"
          />
          <Button size="sm" onClick={() => newName.trim() && addMut.mutate(newName.trim())} disabled={!newName.trim() || addMut.isPending}>
            <Plus className="h-4 w-4" />
          </Button>
        </div>

        {isLoading ? (
          <p className="text-sm text-muted-foreground">{t("common.loading")}</p>
        ) : (
          <div className="space-y-1">
            {(categories ?? []).map((cat) => (
              <div key={cat.id} className="flex items-center gap-2 rounded-md border px-3 py-2">
                <GripVertical className="h-4 w-4 text-muted-foreground/50 shrink-0" />
                {editingId === cat.id ? (
                  <>
                    <Input
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      className="h-8 flex-1"
                      autoFocus
                      onKeyDown={(e) => {
                        if (e.key === "Enter" && editName.trim()) updateMut.mutate({ id: cat.id, updates: { name: editName.trim() } });
                        if (e.key === "Escape") setEditingId(null);
                      }}
                    />
                    <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => updateMut.mutate({ id: cat.id, updates: { name: editName.trim() } })}>
                      <Check className="h-3.5 w-3.5 text-green-500" />
                    </Button>
                    <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => setEditingId(null)}>
                      <X className="h-3.5 w-3.5" />
                    </Button>
                  </>
                ) : (
                  <>
                    <span className={`flex-1 text-sm ${!cat.is_active ? "text-muted-foreground line-through" : ""}`}>{cat.name}</span>
                    <Switch
                      checked={cat.is_active}
                      onCheckedChange={(v) => updateMut.mutate({ id: cat.id, updates: { is_active: v } })}
                      className="scale-75"
                    />
                    <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => startEdit(cat)}>
                      <Pencil className="h-3.5 w-3.5" />
                    </Button>
                    <Button size="icon" variant="ghost" className="h-7 w-7 text-destructive hover:text-destructive" onClick={() => deleteMut.mutate(cat.id)}>
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </>
                )}
              </div>
            ))}
            {(categories ?? []).length === 0 && (
              <p className="text-sm text-muted-foreground text-center py-4">{t("admin.noCategories")}</p>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
