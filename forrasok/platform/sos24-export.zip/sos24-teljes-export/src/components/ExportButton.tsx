import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";
import { exportToCsv } from "@/hooks/use-csv-export";

interface ExportButtonProps {
  filename: string;
  headers: string[];
  rows: string[][];
  label?: string;
  disabled?: boolean;
}

export default function ExportButton({ filename, headers, rows, label = "CSV export", disabled }: ExportButtonProps) {
  return (
    <Button
      variant="outline"
      size="sm"
      disabled={disabled || !rows.length}
      onClick={() => exportToCsv(filename, headers, rows)}
    >
      <Download className="h-4 w-4 mr-1" />
      {label}
    </Button>
  );
}
