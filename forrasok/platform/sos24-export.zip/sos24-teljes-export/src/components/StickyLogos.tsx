import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

interface StickyLogo {
  corner: "top-left" | "top-right" | "bottom-left" | "bottom-right";
  image_url: string;
  link_url?: string;
  size?: number; // px, default 64
  enabled: boolean;
}

const positionClasses: Record<string, string> = {
  "top-left": "top-20 left-4",
  "top-right": "top-20 right-4",
  "bottom-left": "bottom-4 left-4",
  "bottom-right": "bottom-4 right-4",
};

export default function StickyLogos() {
  const { data: logos } = useQuery({
    queryKey: ["sticky-logos"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("site_settings")
        .select("value_json")
        .eq("key", "sticky_logos")
        .single();
      if (error) return [];
      return (data?.value_json as unknown as StickyLogo[] | null) ?? [];
    },
    staleTime: 5 * 60 * 1000,
  });

  const activeLogos = (logos ?? []).filter((l) => l.enabled && l.image_url);

  if (!activeLogos.length) return null;

  return (
    <>
      {activeLogos.map((logo) => {
        const size = logo.size || 64;
        const img = (
          <img
            src={logo.image_url}
            alt=""
            style={{ width: size, height: size }}
            className="object-contain drop-shadow-lg transition-transform hover:scale-110"
          />
        );
        return (
          <div
            key={logo.corner}
            className={`fixed z-40 ${positionClasses[logo.corner] ?? ""}`}
          >
            {logo.link_url ? (
              <a href={logo.link_url} target="_blank" rel="noopener noreferrer">
                {img}
              </a>
            ) : (
              img
            )}
          </div>
        );
      })}
    </>
  );
}
