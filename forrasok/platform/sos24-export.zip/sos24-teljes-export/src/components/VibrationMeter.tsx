import { useState, useRef, useCallback, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Smartphone, Square, Save, AlertTriangle, Activity } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

interface VibrationMeterProps {
  riskAssessmentId: string | null;
  workplaceId?: string;
}

// EU 2002/44/EC thresholds
const THRESHOLDS = {
  hav: { action: 2.5, limit: 5.0 },   // m/s² A(8) kéz-kar
  wbv: { action: 0.5, limit: 1.15 },   // m/s² A(8) egész test
};

function getVibColor(ms2: number, type: "vibration_wbv" | "vibration_hav"): string {
  const th = type === "vibration_hav" ? THRESHOLDS.hav : THRESHOLDS.wbv;
  if (ms2 < th.action * 0.5) return "bg-green-500";
  if (ms2 < th.action) return "bg-yellow-500";
  if (ms2 < th.limit) return "bg-orange-500";
  return "bg-red-500";
}

function getVibLabel(ms2: number, type: "vibration_wbv" | "vibration_hav", t: any): string {
  const th = type === "vibration_hav" ? THRESHOLDS.hav : THRESHOLDS.wbv;
  if (ms2 < th.action * 0.5) return t("measurement.vibSafe");
  if (ms2 < th.action) return t("measurement.vibModerate");
  if (ms2 < th.limit) return t("measurement.vibWarning");
  return t("measurement.vibDanger");
}

export default function VibrationMeter({ riskAssessmentId, workplaceId }: VibrationMeterProps) {
  const { t } = useTranslation();
  const { user } = useAuth();
  const [measuring, setMeasuring] = useState(false);
  const [measurementType, setMeasurementType] = useState<"vibration_wbv" | "vibration_hav">("vibration_hav");
  const [currentMs2, setCurrentMs2] = useState(0);
  const [peakMs2, setPeakMs2] = useState(0);
  const [avgMs2, setAvgMs2] = useState(0);
  const [duration, setDuration] = useState(0);
  const [locationDesc, setLocationDesc] = useState("");
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);
  const [history, setHistory] = useState<number[]>([]);
  const [supported, setSupported] = useState(true);
  const [axisData, setAxisData] = useState({ x: 0, y: 0, z: 0 });

  const startTimeRef = useRef(0);
  const samplesRef = useRef<number[]>([]);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const listenerRef = useRef<((e: DeviceMotionEvent) => void) | null>(null);

  useEffect(() => {
    if (!("DeviceMotionEvent" in window)) {
      setSupported(false);
    }
    return () => {
      if (listenerRef.current) {
        window.removeEventListener("devicemotion", listenerRef.current);
      }
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, []);

  const stopMeasuring = useCallback(() => {
    setMeasuring(false);
    if (listenerRef.current) {
      window.removeEventListener("devicemotion", listenerRef.current);
      listenerRef.current = null;
    }
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }

    if (samplesRef.current.length > 0) {
      const avg = samplesRef.current.reduce((a, b) => a + b, 0) / samplesRef.current.length;
      setAvgMs2(Math.round(avg * 100) / 100);
      setHistory(samplesRef.current.map(v => Math.round(v * 100) / 100));
    }
  }, []);

  const startMeasuring = useCallback(async () => {
    // iOS 13+ requires permission
    if (typeof (DeviceMotionEvent as any).requestPermission === "function") {
      try {
        const perm = await (DeviceMotionEvent as any).requestPermission();
        if (perm !== "granted") {
          toast.error(t("measurement.motionPermDenied"));
          return;
        }
      } catch {
        toast.error(t("measurement.motionPermDenied"));
        return;
      }
    }

    setMeasuring(true);
    setPeakMs2(0);
    setAvgMs2(0);
    setDuration(0);
    samplesRef.current = [];
    startTimeRef.current = Date.now();

    const handler = (e: DeviceMotionEvent) => {
      const acc = e.accelerationIncludingGravity;
      if (!acc) return;

      const x = acc.x ?? 0;
      const y = acc.y ?? 0;
      const z = acc.z ?? 0;

      // Remove gravity component (approximate)
      // For WBV: we mainly care about the vertical axis
      // For HAV: we care about the resultant vector
      let magnitude: number;
      if (measurementType === "vibration_wbv") {
        // Assume phone is on a surface, z-axis is vertical
        magnitude = Math.abs(z - 9.81); // subtract gravity
      } else {
        // HAV: resultant of all axes minus gravity
        const gRemoved = Math.sqrt(x * x + y * y + (z - 9.81) * (z - 9.81));
        magnitude = gRemoved;
      }

      const rounded = Math.round(magnitude * 100) / 100;
      setCurrentMs2(rounded);
      setAxisData({ x: Math.round(x * 100) / 100, y: Math.round(y * 100) / 100, z: Math.round(z * 100) / 100 });
      setPeakMs2(prev => Math.max(prev, rounded));
      samplesRef.current.push(rounded);
    };

    listenerRef.current = handler;
    window.addEventListener("devicemotion", handler);

    intervalRef.current = setInterval(() => {
      const elapsed = Math.floor((Date.now() - startTimeRef.current) / 1000);
      setDuration(elapsed);
    }, 1000);
  }, [measurementType, t]);

  const handleSave = async () => {
    if (!riskAssessmentId) {
      toast.error(t("measurement.saveFirstAssessment"));
      return;
    }
    setSaving(true);
    try {
      const { error } = await supabase.from("noise_vibration_measurements").insert({
        risk_assessment_id: riskAssessmentId,
        workplace_id: workplaceId || null,
        measurement_type: measurementType,
        value_ms2: avgMs2,
        peak_value: peakMs2,
        duration_seconds: duration,
        frequency_data: history.length > 100
          ? history.filter((_, i) => i % Math.ceil(history.length / 100) === 0)
          : history,
        location_description: locationDesc || null,
        notes: notes || null,
        measured_by: user?.id,
      });
      if (error) throw error;
      toast.success(t("common.saved"));
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setSaving(false);
    }
  };

  const th = measurementType === "vibration_hav" ? THRESHOLDS.hav : THRESHOLDS.wbv;
  const maxScale = th.limit * 2;
  const barWidth = Math.min(100, (currentMs2 / maxScale) * 100);

  if (!supported) {
    return (
      <Card>
        <CardContent className="py-8 text-center text-muted-foreground">
          <Smartphone className="h-8 w-8 mx-auto mb-2 opacity-50" />
          <p>{t("measurement.vibNotSupported")}</p>
          <p className="text-xs mt-1">{t("measurement.vibUsePhone")}</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="py-3">
        <CardTitle className="text-sm flex items-center gap-2">
          <Activity className="h-4 w-4" />
          {t("measurement.vibrationMeter")}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Type selector */}
        <div className="flex gap-3 items-end">
          <div className="flex-1">
            <Label>{t("measurement.measurementType")}</Label>
            <Select value={measurementType} onValueChange={(v: any) => setMeasurementType(v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="vibration_hav">{t("measurement.vibHAV")}</SelectItem>
                <SelectItem value="vibration_wbv">{t("measurement.vibWBV")}</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button
            onClick={measuring ? stopMeasuring : startMeasuring}
            variant={measuring ? "destructive" : "default"}
            className="gap-1"
          >
            {measuring ? <Square className="h-4 w-4" /> : <Smartphone className="h-4 w-4" />}
            {measuring ? t("measurement.stop") : t("measurement.start")}
          </Button>
        </div>

        {/* Instruction */}
        <p className="text-xs text-muted-foreground">
          {measurementType === "vibration_hav"
            ? t("measurement.havInstruction")
            : t("measurement.wbvInstruction")}
        </p>

        {/* Live meter */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="font-mono text-2xl font-bold">{currentMs2.toFixed(2)} m/s²</span>
            <span className="text-muted-foreground">{duration}s</span>
          </div>
          <div className="h-6 bg-muted rounded-full overflow-hidden relative">
            <div
              className={`h-full transition-all duration-100 ${getVibColor(currentMs2, measurementType)} rounded-full`}
              style={{ width: `${barWidth}%` }}
            />
            <div className="absolute top-0 h-full w-px bg-yellow-600" style={{ left: `${(th.action / maxScale) * 100}%` }} />
            <div className="absolute top-0 h-full w-px bg-red-600" style={{ left: `${(th.limit / maxScale) * 100}%` }} />
          </div>
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>0</span>
            <span className="text-yellow-600">{th.action} m/s²</span>
            <span className="text-red-600">{th.limit} m/s²</span>
            <span>{maxScale} m/s²</span>
          </div>
        </div>

        {/* Axis breakdown */}
        {measuring && (
          <div className="grid grid-cols-3 gap-2 text-center text-xs">
            <div className="bg-muted p-1 rounded">
              <span className="text-muted-foreground">X:</span> {axisData.x}
            </div>
            <div className="bg-muted p-1 rounded">
              <span className="text-muted-foreground">Y:</span> {axisData.y}
            </div>
            <div className="bg-muted p-1 rounded">
              <span className="text-muted-foreground">Z:</span> {axisData.z}
            </div>
          </div>
        )}

        {/* Stats */}
        <div className="grid grid-cols-2 gap-2 text-center">
          <div className="bg-muted p-2 rounded">
            <div className="text-xs text-muted-foreground">{t("measurement.avg")}</div>
            <div className="font-mono font-bold">{avgMs2.toFixed(2)}</div>
          </div>
          <div className="bg-muted p-2 rounded">
            <div className="text-xs text-muted-foreground">{t("measurement.peak")}</div>
            <div className="font-mono font-bold">{peakMs2.toFixed(2)}</div>
          </div>
        </div>

        {/* Legal reference */}
        {avgMs2 > 0 && !measuring && (
          <div className={`p-3 rounded-lg border ${avgMs2 >= th.limit ? "bg-red-50 border-red-200 dark:bg-red-950 dark:border-red-800" : avgMs2 >= th.action ? "bg-yellow-50 border-yellow-200 dark:bg-yellow-950 dark:border-yellow-800" : "bg-green-50 border-green-200 dark:bg-green-950 dark:border-green-800"}`}>
            <div className="flex items-center gap-2">
              {avgMs2 >= th.action && <AlertTriangle className="h-4 w-4" />}
              <Badge variant="outline" className={getVibColor(avgMs2, measurementType) + " text-white border-0"}>
                {getVibLabel(avgMs2, measurementType, t)}
              </Badge>
            </div>
            <p className="text-xs mt-1 text-muted-foreground">
              {t("measurement.vibLegalRef")} — {measurementType === "vibration_hav" ? "HAV" : "WBV"} A(8): {th.action}/{th.limit} m/s²
            </p>
          </div>
        )}

        {/* History mini chart */}
        {history.length > 0 && (
          <div className="h-16 flex items-end gap-px">
            {history.slice(-100).map((v, i) => (
              <div
                key={i}
                className={`flex-1 min-w-[2px] ${getVibColor(v, measurementType)} rounded-t`}
                style={{ height: `${Math.min(100, (v / maxScale) * 100)}%` }}
              />
            ))}
          </div>
        )}

        {/* Save section */}
        {avgMs2 > 0 && !measuring && (
          <div className="space-y-2 border-t pt-3">
            <div>
              <Label>{t("measurement.locationDescription")}</Label>
              <Input value={locationDesc} onChange={e => setLocationDesc(e.target.value)} placeholder={t("measurement.locationPlaceholder")} />
            </div>
            <div>
              <Label>{t("measurement.notes")}</Label>
              <Textarea value={notes} onChange={e => setNotes(e.target.value)} rows={2} />
            </div>
            <Button onClick={handleSave} disabled={saving} className="w-full gap-1">
              <Save className="h-4 w-4" />
              {t("measurement.saveResult")}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
