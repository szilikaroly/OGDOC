import { forwardRef } from "react";

interface ProfileData {
  full_name?: string;
  taj_number?: string;
  birth_date?: string;
  birth_place?: string;
  mother_name?: string;
  address?: string;
  phone?: string;
  gender?: string;
}

interface PatientCardData {
  education?: string;
  professional_qual?: string;
  notification_address?: string;
  occupation?: string;
  employer_name?: string;
  marital_status?: string;
  drug_allergies?: string;
  chronic_diseases?: string;
  regular_medications?: string;
  surgeries?: string;
  smoking?: any;
  alcohol?: string;
  sports_habit?: string;
  eating_habit?: string;
  family_history?: any;
  occupation_history?: any[];
  reported_occupational_diseases?: string;
  military_service?: boolean;
  drivers_license?: boolean;
  exposures?: any;
  last_chest_xray?: string;
  last_gynecology?: string;
  previous_doctor?: string;
  other_notes?: string;
}

interface Props {
  profile: ProfileData;
  card: PatientCardData;
}

const PrintablePatientCard = forwardRef<HTMLDivElement, Props>(({ profile, card }, ref) => {
  const smoking = card.smoking ?? {};
  const familyHistory = card.family_history ?? {};
  const occHistory: any[] = card.occupation_history ?? [];
  const exposures = card.exposures ?? {};

  const FAMILY_MEMBERS = [
    { key: "apa", label: "Apa" },
    { key: "anya", label: "Anya" },
    { key: "testver", label: "Testvér" },
  ];
  const ORGANS = [
    { key: "cardiovascular", label: "Szív-ér" },
    { key: "respiratory", label: "Légző" },
    { key: "cancer", label: "Daganat" },
    { key: "digestive", label: "Emésztő" },
    { key: "metabolic", label: "Anyagcsere" },
    { key: "psychiatric", label: "Pszichiátriai" },
    { key: "other", label: "Egyéb" },
  ];

  const smokingText = smoking.status === "igen"
    ? `Igen (${smoking.amount || "?"} szál/nap, ${smoking.duration || "?"} éve)`
    : smoking.status === "leszokott"
    ? `Leszokott (${smoking.duration || "?"} éve)`
    : "Nem";

  return (
    <div ref={ref} className="print-only bg-white text-black p-6 text-xs leading-relaxed" style={{ fontFamily: "Times New Roman, serif" }}>
      <style>{`
        @media print {
          .print-only { display: block !important; }
          .print-only table { border-collapse: collapse; width: 100%; }
          .print-only td, .print-only th { border: 1px solid #000; padding: 2px 4px; }
        }
        @media screen { .print-only { display: none; } }
      `}</style>

      <h2 className="text-center font-bold text-sm mb-4">MUNKAVÁLLALÓ EGÉSZSÉGÜGYI TÖRZSLAPJA</h2>

      {/* Személyes adatok */}
      <table className="w-full mb-3 border border-black" style={{ borderCollapse: "collapse" }}>
        <tbody>
          <tr>
            <td className="border border-black p-1 font-bold w-1/4">Név</td>
            <td className="border border-black p-1">{profile.full_name || ""}</td>
            <td className="border border-black p-1 font-bold w-1/4">TAJ</td>
            <td className="border border-black p-1">{profile.taj_number || ""}</td>
          </tr>
          <tr>
            <td className="border border-black p-1 font-bold">Születési hely, idő</td>
            <td className="border border-black p-1">{profile.birth_place || ""}, {profile.birth_date ? new Date(profile.birth_date).toLocaleDateString("hu-HU") : ""}</td>
            <td className="border border-black p-1 font-bold">Anyja neve</td>
            <td className="border border-black p-1">{profile.mother_name || ""}</td>
          </tr>
          <tr>
            <td className="border border-black p-1 font-bold">Lakcím</td>
            <td className="border border-black p-1" colSpan={3}>{profile.address || ""}</td>
          </tr>
          <tr>
            <td className="border border-black p-1 font-bold">Telefon</td>
            <td className="border border-black p-1">{profile.phone || ""}</td>
            <td className="border border-black p-1 font-bold">Nem</td>
            <td className="border border-black p-1">{profile.gender === "ferfi" ? "Férfi" : profile.gender === "no" ? "Nő" : ""}</td>
          </tr>
          <tr>
            <td className="border border-black p-1 font-bold">Iskolai végzettség</td>
            <td className="border border-black p-1">{card.education || ""}</td>
            <td className="border border-black p-1 font-bold">Szakmai képzettség</td>
            <td className="border border-black p-1">{card.professional_qual || ""}</td>
          </tr>
          <tr>
            <td className="border border-black p-1 font-bold">Foglalkozás</td>
            <td className="border border-black p-1">{card.occupation || ""}</td>
            <td className="border border-black p-1 font-bold">Munkahely</td>
            <td className="border border-black p-1">{card.employer_name || ""}</td>
          </tr>
          <tr>
            <td className="border border-black p-1 font-bold">Családi állapot</td>
            <td className="border border-black p-1">{card.marital_status || ""}</td>
            <td className="border border-black p-1 font-bold">Értesítési cím</td>
            <td className="border border-black p-1">{card.notification_address || ""}</td>
          </tr>
        </tbody>
      </table>

      {/* Családi anamnézis */}
      <h3 className="font-bold mb-1">Családi anamnézis</h3>
      <table className="w-full mb-3 border border-black" style={{ borderCollapse: "collapse" }}>
        <thead>
          <tr>
            <th className="border border-black p-1 text-left">Családtag</th>
            {ORGANS.map((o) => <th key={o.key} className="border border-black p-1 text-center">{o.label}</th>)}
          </tr>
        </thead>
        <tbody>
          {FAMILY_MEMBERS.map((m) => (
            <tr key={m.key}>
              <td className="border border-black p-1">{m.label}</td>
              {ORGANS.map((o) => (
                <td key={o.key} className="border border-black p-1 text-center">
                  {familyHistory[m.key]?.[o.key] ? "✓" : ""}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>

      {/* Foglalkozási anamnézis */}
      {occHistory.length > 0 && (
        <>
          <h3 className="font-bold mb-1">Foglalkozási anamnézis</h3>
          <table className="w-full mb-3 border border-black" style={{ borderCollapse: "collapse" }}>
            <thead><tr><th className="border border-black p-1">Munkakör</th><th className="border border-black p-1">Expozíció</th><th className="border border-black p-1">Időtartam (év)</th></tr></thead>
            <tbody>
              {occHistory.map((item, i) => (
                <tr key={i}><td className="border border-black p-1">{item.position}</td><td className="border border-black p-1">{item.exposure}</td><td className="border border-black p-1">{item.duration_years}</td></tr>
              ))}
            </tbody>
          </table>
        </>
      )}

      {/* Életmód */}
      <h3 className="font-bold mb-1">Életmód</h3>
      <table className="w-full mb-3 border border-black" style={{ borderCollapse: "collapse" }}>
        <tbody>
          <tr><td className="border border-black p-1 font-bold w-1/4">Dohányzás</td><td className="border border-black p-1">{smokingText}</td></tr>
          <tr><td className="border border-black p-1 font-bold">Alkohol</td><td className="border border-black p-1">{card.alcohol === "alkalomszeruen" ? "Alkalomszerűen" : card.alcohol === "rendszeresen" ? "Rendszeresen" : "Nem"}</td></tr>
          <tr><td className="border border-black p-1 font-bold">Sportolás</td><td className="border border-black p-1">{card.sports_habit === "rendszeres" ? "Rendszeres" : card.sports_habit === "rendszertelen" ? "Rendszertelen" : "Nem sportol"}</td></tr>
          <tr><td className="border border-black p-1 font-bold">Étkezési szokás</td><td className="border border-black p-1">{card.eating_habit === "korszeru" ? "Korszerű" : card.eating_habit === "korszerutlen" ? "Korszerűtlen" : "—"}</td></tr>
        </tbody>
      </table>

      {/* Klinikai adatok */}
      <table className="w-full mb-3 border border-black" style={{ borderCollapse: "collapse" }}>
        <tbody>
          <tr><td className="border border-black p-1 font-bold w-1/4">Allergiák</td><td className="border border-black p-1">{card.drug_allergies || "Nincs"}</td></tr>
          <tr><td className="border border-black p-1 font-bold">Foglalkozási betegségek</td><td className="border border-black p-1">{card.reported_occupational_diseases || "Nincs"}</td></tr>
          <tr><td className="border border-black p-1 font-bold">Előző betegségek, műtétek</td><td className="border border-black p-1">{card.surgeries || "Nincs"}</td></tr>
          <tr><td className="border border-black p-1 font-bold">Krónikus betegségek</td><td className="border border-black p-1">{card.chronic_diseases || "Nincs"}</td></tr>
          <tr><td className="border border-black p-1 font-bold">Rendszeres gyógyszerek</td><td className="border border-black p-1">{card.regular_medications || "Nincs"}</td></tr>
          <tr><td className="border border-black p-1 font-bold">Jogosítvány</td><td className="border border-black p-1">{card.drivers_license ? "Van" : "Nincs"}</td></tr>
          <tr><td className="border border-black p-1 font-bold">Katonai szolgálat</td><td className="border border-black p-1">{card.military_service ? "Volt" : "Nem volt"}</td></tr>
          <tr><td className="border border-black p-1 font-bold">Utolsó tüdőszűrés</td><td className="border border-black p-1">{card.last_chest_xray ? new Date(card.last_chest_xray).toLocaleDateString("hu-HU") : "—"}</td></tr>
          <tr><td className="border border-black p-1 font-bold">Utolsó nőgyógyászat</td><td className="border border-black p-1">{card.last_gynecology ? new Date(card.last_gynecology).toLocaleDateString("hu-HU") : "—"}</td></tr>
          <tr><td className="border border-black p-1 font-bold">Előző háziorvos</td><td className="border border-black p-1">{card.previous_doctor || "—"}</td></tr>
        </tbody>
      </table>

      {/* Kockázati expozíciók */}
      {Object.keys(exposures).some((k) => exposures[k]?.length > 0) && (
        <>
          <h3 className="font-bold mb-1">Kockázati expozíciók</h3>
          <div className="mb-3">
            {Object.entries(exposures).map(([cat, items]: [string, any]) =>
              items?.length > 0 ? (
                <div key={cat} className="mb-1">
                  <span className="font-bold capitalize">{cat}:</span> {items.join(", ")}
                </div>
              ) : null
            )}
          </div>
        </>
      )}

      {card.other_notes && (
        <div className="mb-3"><span className="font-bold">Egyéb megjegyzés:</span> {card.other_notes}</div>
      )}

      <div className="mt-8 flex justify-between">
        <div>Kelt: ________________</div>
        <div>Aláírás: ________________</div>
      </div>
    </div>
  );
});

PrintablePatientCard.displayName = "PrintablePatientCard";
export default PrintablePatientCard;
