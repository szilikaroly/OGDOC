import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Image, RefreshCw, Loader2, ExternalLink } from "lucide-react";

interface OgImageGeneratorProps {
  title: string;
  subtitle?: string;
  slug: string;
  currentOgImage?: string | null;
  onImageGenerated?: (url: string) => void;
}

export default function OgImageGenerator({
  title,
  subtitle,
  slug,
  currentOgImage,
  onImageGenerated,
}: OgImageGeneratorProps) {
  const [loading, setLoading] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(currentOgImage || null);

  const generate = async (regenerate = false) => {
    if (!title || !slug) {
      toast.error("Cím és slug szükséges a generáláshoz");
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("ai-og-image", {
        body: { title, subtitle, slug, regenerate },
      });

      if (error) throw error;
      if (!data?.success) throw new Error(data?.error || "Ismeretlen hiba");

      setPreviewUrl(data.url);
      onImageGenerated?.(data.url);
      toast.success(
        data.cached
          ? "Meglévő OG kép betöltve"
          : "OG kép sikeresen generálva!"
      );
    } catch (e: any) {
      console.error("OG image generation error:", e);
      if (e.message?.includes("RATE_LIMIT") || e.status === 429) {
        toast.error("Túl sok kérés, próbáld újra később");
      } else if (e.message?.includes("PAYMENT_REQUIRED") || e.status === 402) {
        toast.error("AI kredit szükséges, töltsd fel az egyenleged");
      } else {
        toast.error("Hiba az OG kép generálásakor");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardContent className="p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="text-sm font-medium flex items-center gap-2">
            <Image className="h-4 w-4" />
            Open Graph kép
          </h4>
          <div className="flex gap-2">
            {previewUrl && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => generate(true)}
                disabled={loading}
              >
                {loading ? (
                  <Loader2 className="h-3 w-3 animate-spin mr-1" />
                ) : (
                  <RefreshCw className="h-3 w-3 mr-1" />
                )}
                Újragenerálás
              </Button>
            )}
            <Button
              size="sm"
              onClick={() => generate(!previewUrl)}
              disabled={loading}
            >
              {loading ? (
                <Loader2 className="h-3 w-3 animate-spin mr-1" />
              ) : (
                <Image className="h-3 w-3 mr-1" />
              )}
              {previewUrl ? "Betöltés" : "Generálás"}
            </Button>
          </div>
        </div>

        {previewUrl && (
          <div className="space-y-2">
            <div className="rounded-md overflow-hidden border">
              <img
                src={`${previewUrl}?t=${Date.now()}`}
                alt="OG preview"
                className="w-full aspect-[1200/630] object-cover"
              />
            </div>
            <a
              href={previewUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs text-muted-foreground hover:text-primary flex items-center gap-1"
            >
              <ExternalLink className="h-3 w-3" />
              Megnyitás új lapon
            </a>
          </div>
        )}

        {!previewUrl && !loading && (
          <p className="text-xs text-muted-foreground">
            Generálj egyedi megosztási képet AI segítségével a cím alapján.
          </p>
        )}
      </CardContent>
    </Card>
  );
}
