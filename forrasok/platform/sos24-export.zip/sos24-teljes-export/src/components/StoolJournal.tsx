import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Plus, Camera, Loader2 } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { format } from "date-fns";
import { hu } from "date-fns/locale";
import { useTranslation } from "react-i18next";

const BRISTOL_COLORS = ["#8B4513", "#A0522D", "#CD853F", "#DEB887", "#F5DEB3", "#FFEFD5", "#FFF8DC"];

export default function StoolJournal() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [form, setForm] = useState({
    bristol_type: "", color: "", blood_present: false, mucus_present: false, pain_level: "", notes: ""
  });

  const { data: entries, isLoading } = useQuery({
    queryKey: ["stool-journal", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase.from("stool_journal").select("*").eq("user_id", user!.id).order("entry_date", { ascending: false }).limit(90);
      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  const addEntry = useMutation({
    mutationFn: async (aiAnalyzed: boolean) => {
      const row: Record<string, any> = { user_id: user!.id, ai_analyzed: aiAnalyzed };
      if (form.bristol_type) row.bristol_type = Number(form.bristol_type);
      if (form.color) row.color = form.color;
      row.blood_present = form.blood_present;
      row.mucus_present = form.mucus_present;
      if (form.pain_level) row.pain_level = Number(form.pain_level);
      if (form.notes) row.notes = form.notes;
      const { error } = await supabase.from("stool_journal").insert(row as any);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["stool-journal"] });
      toast({ title: t("inner.entrySaved") });
      setOpen(false);
      setForm({ bristol_type: "", color: "", blood_present: false, mucus_present: false, pain_level: "", notes: "" });
    },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  const handlePhotoAnalysis = async (file: File) => {
    setAiLoading(true);
    try {
      const reader = new FileReader();
      const base64 = await new Promise<string>((resolve) => {
        reader.onload = () => resolve((reader.result as string).split(",")[1]);
        reader.readAsDataURL(file);
      });
      const { data, error } = await supabase.functions.invoke("ai-health-image-analysis", {
        body: { mode: "stool", image_base64: base64, mime_type: file.type },
      });
      if (error) throw error;
      const r = data.result;
      setForm((p) => ({
        ...p,
        bristol_type: r.bristol_type?.toString() || p.bristol_type,
        color: r.color || p.color,
        blood_present: r.blood_present ?? p.blood_present,
        mucus_present: r.mucus_present ?? p.mucus_present,
      }));
      toast({ title: t("inner.aiAnalyzed") });
    } catch (e: any) {
      toast({ variant: "destructive", title: t("common.error"), description: e.message });
    } finally {
      setAiLoading(false);
    }
  };

  const bristolDistribution = Array.from({ length: 7 }, (_, i) => ({
    type: `${i + 1}`,
    label: t(`inner.bristol${i + 1}`).split("–")[0].trim(),
    count: (entries ?? []).filter((e) => e.bristol_type === i + 1).length,
  }));

  if (isLoading) return <div className="flex justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold">{t("inner.stoolJournal")}</h2>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button><Plus className="h-4 w-4 mr-1" /> {t("inner.newStoolEntry")}</Button></DialogTrigger>
          <DialogContent className="max-h-[90vh] overflow-y-auto">
            <DialogHeader><DialogTitle>{t("inner.newStoolEntry")}</DialogTitle></DialogHeader>
            <div className="space-y-4">
              <div className="flex gap-2">
                <Button variant="outline" className="w-full" disabled={aiLoading} onClick={() => document.getElementById("stool-photo-input")?.click()}>
                  {aiLoading ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Camera className="h-4 w-4 mr-1" />}
                  {aiLoading ? t("inner.aiAnalyzing") : t("inner.aiAnalyzePhoto")}
                </Button>
                <input id="stool-photo-input" type="file" accept="image/*" capture="environment" className="hidden" onChange={(e) => e.target.files?.[0] && handlePhotoAnalysis(e.target.files[0])} />
              </div>

              <div>
                <Label>{t("inner.bristolScale")}</Label>
                <div className="grid gap-2 mt-2">
                  {[1, 2, 3, 4, 5, 6, 7].map((n) => (
                    <button
                      key={n}
                      type="button"
                      onClick={() => setForm((p) => ({ ...p, bristol_type: n.toString() }))}
                      className={`text-left px-3 py-2 rounded-md border text-sm transition-colors ${form.bristol_type === n.toString() ? "border-primary bg-primary/10 font-medium" : "border-border hover:bg-muted"}`}
                    >
                      {t(`inner.bristol${n}`)}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div><Label>{t("inner.stoolColor")}</Label><Input value={form.color} onChange={(e) => setForm((p) => ({ ...p, color: e.target.value }))} placeholder="Barna" /></div>
                <div><Label>{t("inner.painLevel")}</Label><Input type="number" min="0" max="10" value={form.pain_level} onChange={(e) => setForm((p) => ({ ...p, pain_level: e.target.value }))} placeholder="0" /></div>
              </div>
              <div className="flex gap-6">
                <div className="flex items-center gap-2"><Switch checked={form.blood_present} onCheckedChange={(v) => setForm((p) => ({ ...p, blood_present: v }))} /><Label>{t("inner.bloodPresent")}</Label></div>
                <div className="flex items-center gap-2"><Switch checked={form.mucus_present} onCheckedChange={(v) => setForm((p) => ({ ...p, mucus_present: v }))} /><Label>{t("inner.mucusPresent")}</Label></div>
              </div>
              <div><Label>{t("inner.comment")}</Label><Textarea value={form.notes} onChange={(e) => setForm((p) => ({ ...p, notes: e.target.value }))} /></div>
              <Button className="w-full" onClick={() => addEntry.mutate(false)} disabled={addEntry.isPending}>
                {addEntry.isPending ? t("inner.saving") : t("inner.save")}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {(entries ?? []).length > 0 && (
        <Card>
          <CardHeader><CardTitle className="text-base">{t("inner.bristolDistribution")}</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={bristolDistribution}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="type" fontSize={12} />
                <YAxis fontSize={12} allowDecimals={false} />
                <Tooltip />
                <Bar dataKey="count" name={t("inner.bristolType")}>
                  {bristolDistribution.map((_, i) => (
                    <Cell key={i} fill={BRISTOL_COLORS[i]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader><CardTitle className="text-lg">{t("inner.lastEntries")}</CardTitle></CardHeader>
        <CardContent className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b text-left">
                <th className="pb-2 pr-4">{t("inner.date")}</th>
                <th className="pb-2 pr-4">{t("inner.bristolType")}</th>
                <th className="pb-2 pr-4">{t("inner.stoolColor")}</th>
                <th className="pb-2 pr-4">{t("inner.painLevel")}</th>
                <th className="pb-2">{t("inner.comment")}</th>
              </tr>
            </thead>
            <tbody>
              {(entries ?? []).map((e) => (
                <tr key={e.id} className="border-b last:border-0">
                  <td className="py-2 pr-4">{format(new Date(e.entry_date), "yyyy.MM.dd", { locale: hu })}</td>
                  <td className="py-2 pr-4">{e.bristol_type ? `${e.bristol_type}` : "—"}</td>
                  <td className="py-2 pr-4">{e.color || "—"}</td>
                  <td className="py-2 pr-4">{e.pain_level != null ? `${e.pain_level}/10` : "—"}</td>
                  <td className="py-2 text-muted-foreground truncate max-w-[200px]">{e.notes || "—"}</td>
                </tr>
              ))}
              {(!entries || entries.length === 0) && (
                <tr><td colSpan={5} className="py-8 text-center text-muted-foreground">{t("inner.noStoolEntryYet")}</td></tr>
              )}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}
