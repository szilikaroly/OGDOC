import { useState, useRef } from "react";
import { useTranslation } from "react-i18next";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import {
  Camera, Upload, Loader2, ShieldAlert, Eye, Wind, Footprints,
  HardHat, Factory, ThumbsUp, AlertTriangle, ChevronDown, ChevronUp, Plus,
} from "lucide-react";

interface PhotoAnalysisResult {
  imageUrl: string;
  fileName: string;
  analysis: any;
  photoId?: string;
}

interface RiskPhotoAnalysisProps {
  assessmentId: string | null;
  workAreaId: string;
  onAdoptHazards?: (hazards: Array<{ catalogMatch: string; name: string; severity: number; probability: number; description: string }>) => void;
}

export default function RiskPhotoAnalysis({ assessmentId, workAreaId, onAdoptHazards }: RiskPhotoAnalysisProps) {
  const { t, i18n } = useTranslation();
  const lang = i18n.language === "hu" ? "hu" : "en";
  const { user } = useAuth();
  const fileRef = useRef<HTMLInputElement>(null);
  const cameraRef = useRef<HTMLInputElement>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [results, setResults] = useState<PhotoAnalysisResult[]>([]);
  const [expandedIdx, setExpandedIdx] = useState<number | null>(null);

  const processFile = async (file: File) => {
    setAnalyzing(true);
    try {
      const base64 = await new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve((reader.result as string).split(",")[1]);
        reader.readAsDataURL(file);
      });

      // Call AI analysis
      const { data, error } = await supabase.functions.invoke("ai-risk-photo-analysis", {
        body: { image_base64: base64, mime_type: file.type },
      });
      if (error) throw error;

      // Upload photo to storage if assessment exists
      let photoId: string | undefined;
      const objectUrl = URL.createObjectURL(file);

      if (assessmentId) {
        const path = `${assessmentId}/${Date.now()}_${file.name}`;
        const { error: uploadErr } = await supabase.storage.from("risk-assessment-photos").upload(path, file);
        if (uploadErr) console.error("Upload error:", uploadErr);
        else {
          const { data: photoRow } = await supabase.from("risk_assessment_photos").insert({
            risk_assessment_id: assessmentId,
            file_name: file.name,
            file_path: path,
            ai_analysis: data.analysis,
            work_area_id: workAreaId || null,
            uploaded_by: user?.id,
          }).select("id").single();
          photoId = photoRow?.id;
        }
      }

      setResults(prev => [...prev, {
        imageUrl: objectUrl,
        fileName: file.name,
        analysis: data.analysis,
        photoId,
      }]);
      setExpandedIdx(results.length);
      toast.success(lang === "hu" ? "Fénykép elemzés kész" : "Photo analysis complete");
    } catch (err: any) {
      console.error(err);
      toast.error(err.message || (lang === "hu" ? "Elemzési hiba" : "Analysis error"));
    } finally {
      setAnalyzing(false);
    }
  };

  const handleFiles = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    Array.from(files).forEach(processFile);
    e.target.value = "";
  };

  const adoptHazards = (analysis: any) => {
    if (!onAdoptHazards || !analysis?.hazards?.length) return;
    const mapped = analysis.hazards.map((h: any) => ({
      catalogMatch: h.catalog_match || "",
      name: h.name,
      severity: h.severity || 2,
      probability: h.probability || 2,
      description: h.description || "",
    }));
    onAdoptHazards(mapped);
    toast.success(lang === "hu"
      ? `${mapped.length} veszélyforrás átvéve`
      : `${mapped.length} hazards adopted`);
  };

  const riskColor = (level: string) => {
    switch (level) {
      case "critical": return "text-red-600 bg-red-50 border-red-200";
      case "high": return "text-orange-600 bg-orange-50 border-orange-200";
      case "medium": return "text-yellow-600 bg-yellow-50 border-yellow-200";
      default: return "text-green-600 bg-green-50 border-green-200";
    }
  };

  return (
    <Card>
      <CardHeader className="py-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm flex items-center gap-2">
            <Camera className="h-4 w-4" />
            {lang === "hu" ? "Fényképes helyszínelemzés" : "Photo Site Analysis"}
          </CardTitle>
          <div className="flex gap-2">
            <input ref={cameraRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={handleFiles} />
            <input ref={fileRef} type="file" accept="image/*" multiple className="hidden" onChange={handleFiles} />
            <Button size="sm" variant="outline" onClick={() => cameraRef.current?.click()} disabled={analyzing}>
              <Camera className="h-4 w-4 mr-1" />
              {lang === "hu" ? "Kamera" : "Camera"}
            </Button>
            <Button size="sm" variant="outline" onClick={() => fileRef.current?.click()} disabled={analyzing}>
              <Upload className="h-4 w-4 mr-1" />
              {lang === "hu" ? "Feltöltés" : "Upload"}
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {analyzing && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground py-4 justify-center">
            <Loader2 className="h-4 w-4 animate-spin" />
            {lang === "hu" ? "AI elemzés folyamatban..." : "AI analysis in progress..."}
          </div>
        )}

        {results.map((r, idx) => (
          <div key={idx} className="border rounded-lg overflow-hidden">
            <button
              className="w-full flex items-center gap-3 p-3 hover:bg-muted/50 text-left"
              onClick={() => setExpandedIdx(expandedIdx === idx ? null : idx)}
            >
              <img src={r.imageUrl} alt={r.fileName} className="w-16 h-16 object-cover rounded" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{r.fileName}</p>
                {r.analysis?.hazards && (
                  <p className="text-xs text-muted-foreground">
                    {r.analysis.hazards.length} {lang === "hu" ? "veszélyforrás" : "hazards"}
                  </p>
                )}
              </div>
              {expandedIdx === idx ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
            </button>

            {expandedIdx === idx && r.analysis && (
              <div className="border-t p-3 space-y-3">
                {/* Workplace Description */}
                {r.analysis.workplace_description && (
                  <Section icon={<Factory className="h-4 w-4" />} title={lang === "hu" ? "Munkaterület leírása" : "Workplace Description"}>
                    <dl className="grid grid-cols-2 gap-1 text-xs">
                      {Object.entries(r.analysis.workplace_description).map(([k, v]) => (
                        <div key={k}>
                          <dt className="font-medium capitalize">{k.replace(/_/g, " ")}</dt>
                          <dd className="text-muted-foreground">{String(v)}</dd>
                        </div>
                      ))}
                    </dl>
                  </Section>
                )}

                {/* Atmosphere */}
                {r.analysis.atmosphere && (
                  <Section icon={<Eye className="h-4 w-4" />} title={lang === "hu" ? "Hangulat & szervezettség" : "Atmosphere & Organization"}>
                    <p className="text-xs">{r.analysis.atmosphere.general_impression}</p>
                    {r.analysis.atmosphere.housekeeping_score && (
                      <Badge variant="outline" className="text-xs mt-1">
                        Housekeeping: {r.analysis.atmosphere.housekeeping_score}/5
                      </Badge>
                    )}
                  </Section>
                )}

                {/* Worker Clothing & PPE */}
                {r.analysis.worker_clothing && (
                  <Section icon={<HardHat className="h-4 w-4" />} title={lang === "hu" ? "Ruházat & védőfelszerelés" : "Clothing & PPE"}>
                    <div className="space-y-1 text-xs">
                      {r.analysis.worker_clothing.observed_ppe?.length > 0 && (
                        <div><span className="font-medium">{lang === "hu" ? "Viselt PPE:" : "Worn PPE:"}</span> {r.analysis.worker_clothing.observed_ppe.join(", ")}</div>
                      )}
                      {r.analysis.worker_clothing.missing_ppe?.length > 0 && (
                        <div className="text-destructive"><span className="font-medium">{lang === "hu" ? "Hiányzó PPE:" : "Missing PPE:"}</span> {r.analysis.worker_clothing.missing_ppe.join(", ")}</div>
                      )}
                      {r.analysis.worker_clothing.notes && <p className="text-muted-foreground">{r.analysis.worker_clothing.notes}</p>}
                    </div>
                  </Section>
                )}

                {/* Slip/Trip/Fall */}
                {r.analysis.slip_trip_fall && (
                  <Section icon={<Footprints className="h-4 w-4" />} title={lang === "hu" ? "Csúszás / Botlás / Esés" : "Slip / Trip / Fall"}>
                    <div className="space-y-1 text-xs">
                      <p>{r.analysis.slip_trip_fall.floor_condition}</p>
                      {r.analysis.slip_trip_fall.obstacles?.length > 0 && (
                        <div><span className="font-medium">{lang === "hu" ? "Akadályok:" : "Obstacles:"}</span> {r.analysis.slip_trip_fall.obstacles.join(", ")}</div>
                      )}
                      {r.analysis.slip_trip_fall.height_risks && <p>{r.analysis.slip_trip_fall.height_risks}</p>}
                      {r.analysis.slip_trip_fall.risk_level && (
                        <Badge className={`text-xs ${riskColor(r.analysis.slip_trip_fall.risk_level)}`}>
                          {r.analysis.slip_trip_fall.risk_level.toUpperCase()}
                        </Badge>
                      )}
                    </div>
                  </Section>
                )}

                {/* Dust & Fumes */}
                {r.analysis.dust_fumes && (
                  <Section icon={<Wind className="h-4 w-4" />} title={lang === "hu" ? "Por & Gőzök" : "Dust & Fumes"}>
                    <div className="space-y-1 text-xs">
                      {r.analysis.dust_fumes.visible_dust && <p className="text-destructive">{r.analysis.dust_fumes.dust_description}</p>}
                      {r.analysis.dust_fumes.fumes_vapors && <p className="text-destructive">{r.analysis.dust_fumes.fumes_description}</p>}
                      {!r.analysis.dust_fumes.visible_dust && !r.analysis.dust_fumes.fumes_vapors && (
                        <p className="text-green-600">{lang === "hu" ? "Nem észlelhető por vagy gőz" : "No visible dust or fumes"}</p>
                      )}
                      {r.analysis.dust_fumes.risk_level && (
                        <Badge className={`text-xs ${riskColor(r.analysis.dust_fumes.risk_level)}`}>
                          {r.analysis.dust_fumes.risk_level.toUpperCase()}
                        </Badge>
                      )}
                    </div>
                  </Section>
                )}

                {/* Work Phase */}
                {r.analysis.work_phase && (
                  <Section icon={<Factory className="h-4 w-4" />} title={lang === "hu" ? "Munkafázis" : "Work Phase"}>
                    <div className="space-y-1 text-xs">
                      <p className="font-medium">{r.analysis.work_phase.identified_phase}</p>
                      {r.analysis.work_phase.equipment_visible?.length > 0 && (
                        <div><span className="font-medium">{lang === "hu" ? "Gépek/eszközök:" : "Equipment:"}</span> {r.analysis.work_phase.equipment_visible.join(", ")}</div>
                      )}
                      {r.analysis.work_phase.materials_visible?.length > 0 && (
                        <div><span className="font-medium">{lang === "hu" ? "Anyagok:" : "Materials:"}</span> {r.analysis.work_phase.materials_visible.join(", ")}</div>
                      )}
                    </div>
                  </Section>
                )}

                {/* PPE Compliance */}
                {r.analysis.ppe_compliance && (
                  <Section icon={<ShieldAlert className="h-4 w-4" />} title={lang === "hu" ? "PPE megfelelőség" : "PPE Compliance"}>
                    <div className="space-y-1 text-xs">
                      <Badge variant="outline">{lang === "hu" ? "Pontszám" : "Score"}: {r.analysis.ppe_compliance.overall_score}/5</Badge>
                      <p>{r.analysis.ppe_compliance.recommendation}</p>
                    </div>
                  </Section>
                )}

                {/* Hazards */}
                {r.analysis.hazards?.length > 0 && (
                  <Section icon={<AlertTriangle className="h-4 w-4" />} title={lang === "hu" ? "Azonosított veszélyforrások" : "Identified Hazards"}>
                    <div className="space-y-2">
                      {r.analysis.hazards.map((h: any, i: number) => (
                        <div key={i} className="border rounded p-2 text-xs space-y-1">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className="text-xs">{h.category}</Badge>
                            <span className="font-medium">{h.name}</span>
                          </div>
                          <p className="text-muted-foreground">{h.description}</p>
                          <div className="flex gap-2">
                            <Badge variant="secondary" className="text-xs">S: {h.severity}</Badge>
                            <Badge variant="secondary" className="text-xs">P: {h.probability}</Badge>
                          </div>
                          {h.recommendation && <p className="text-primary text-xs">💡 {h.recommendation}</p>}
                        </div>
                      ))}
                      <Button
                        size="sm"
                        variant="default"
                        className="w-full mt-2"
                        onClick={() => adoptHazards(r.analysis)}
                      >
                        <Plus className="h-4 w-4 mr-1" />
                        {lang === "hu" ? "Veszélyforrások átvétele a kockázatértékelésbe" : "Adopt hazards to risk assessment"}
                      </Button>
                    </div>
                  </Section>
                )}

                {/* Positive aspects */}
                {r.analysis.positive_aspects?.length > 0 && (
                  <Section icon={<ThumbsUp className="h-4 w-4" />} title={lang === "hu" ? "Pozitívumok" : "Positive Aspects"}>
                    <ul className="text-xs space-y-1">
                      {r.analysis.positive_aspects.map((p: string, i: number) => (
                        <li key={i} className="flex items-start gap-1">
                          <span className="text-green-500">✓</span> {p}
                        </li>
                      ))}
                    </ul>
                  </Section>
                )}
              </div>
            )}
          </div>
        ))}

        {results.length === 0 && !analyzing && (
          <p className="text-xs text-muted-foreground text-center py-2">
            {lang === "hu"
              ? "Töltsön fel fényképet a munkaterületről az AI elemzéshez"
              : "Upload a workplace photo for AI analysis"}
          </p>
        )}
      </CardContent>
    </Card>
  );
}

function Section({ icon, title, children }: { icon: React.ReactNode; title: string; children: React.ReactNode }) {
  return (
    <div className="border rounded-lg p-2">
      <div className="flex items-center gap-2 mb-1">
        {icon}
        <span className="text-xs font-semibold">{title}</span>
      </div>
      {children}
    </div>
  );
}
