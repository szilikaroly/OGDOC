import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Label } from "@/components/ui/label";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import {
  Accordion, AccordionContent, AccordionItem, AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Upload, Loader2, FlaskConical, ShieldAlert, Trash2, FileText,
  AlertTriangle, Beaker, Activity,
} from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

interface WorkAreaSdsUploadProps {
  workAreaId: string;
  workAreaName: string;
  readOnly?: boolean;
}

interface MixtureComponent {
  name: string;
  cas_number?: string;
  ec_number?: string;
  concentration_min?: number;
  concentration_max?: number;
  concentration_unit?: string;
  classification?: string;
  hazard_statements?: string[];
}

export default function WorkAreaSdsUpload({ workAreaId, workAreaName, readOnly = false }: WorkAreaSdsUploadProps) {
  const { t } = useTranslation();
  const { user } = useAuth();
  const qc = useQueryClient();
  const [uploading, setUploading] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [selectedDoc, setSelectedDoc] = useState<any>(null);

  const { data: sdsDocs = [], isLoading } = useQuery({
    queryKey: ["work-area-sds", workAreaId],
    queryFn: async () => {
      const { data, error } = await (supabase as any)
        .from("work_area_sds_documents")
        .select("*")
        .eq("work_area_id", workAreaId)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data || [];
    },
    enabled: !!workAreaId,
  });

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    if (!file.type.includes("pdf")) {
      toast.error(t("substances.onlyPdf"));
      return;
    }
    if (file.size > 20 * 1024 * 1024) {
      toast.error(t("substances.fileTooLarge"));
      return;
    }

    setUploading(true);
    setAnalyzing(true);

    try {
      // Upload PDF to storage
      const filePath = `${user.id}/${workAreaId}/${Date.now()}_${file.name}`;
      const { error: uploadErr } = await supabase.storage
        .from("sds-documents")
        .upload(filePath, file);
      if (uploadErr) throw uploadErr;

      // Read file as base64
      const reader = new FileReader();
      const base64 = await new Promise<string>((resolve, reject) => {
        reader.onload = () => {
          const result = reader.result as string;
          resolve(result.split(",")[1]);
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });

      // Call AI analysis with PDF base64
      const { data, error: fnErr } = await supabase.functions.invoke("ai-sds-analysis", {
        body: {
          sds_pdf_base64: base64,
          work_area_id: workAreaId,
          file_name: file.name,
          file_path: filePath,
        },
      });
      if (fnErr) throw fnErr;

      if (data?.saved) {
        toast.success(t("substances.sdsUploaded"));
        qc.invalidateQueries({ queryKey: ["work-area-sds", workAreaId] });
      } else if (data?.analysis) {
        // Manually save if not saved by the edge function
        const a = data.analysis;
        const { error: insertErr } = await (supabase as any)
          .from("work_area_sds_documents")
          .insert({
            work_area_id: workAreaId,
            file_name: file.name,
            file_path: filePath,
            substance_name: a.substance_name || null,
            cas_number: a.cas_number || null,
            ec_number: a.ec_number || null,
            is_mixture: a.is_mixture || false,
            mixture_components: a.mixture_components || [],
            analysis_data: a,
            risk_level: a.risk_level || null,
            uploaded_by: user.id,
          });
        if (insertErr) throw insertErr;
        toast.success(t("substances.sdsUploaded"));
        qc.invalidateQueries({ queryKey: ["work-area-sds", workAreaId] });
      }
    } catch (err: any) {
      console.error(err);
      toast.error(err.message || t("substances.sdsError"));
    } finally {
      setUploading(false);
      setAnalyzing(false);
      // Reset input
      e.target.value = "";
    }
  };

  const handleDelete = async (doc: any) => {
    if (!confirm(t("common.confirmDelete"))) return;
    try {
      await supabase.storage.from("sds-documents").remove([doc.file_path]);
      const { error } = await (supabase as any)
        .from("work_area_sds_documents")
        .delete()
        .eq("id", doc.id);
      if (error) throw error;
      toast.success(t("common.deleted"));
      qc.invalidateQueries({ queryKey: ["work-area-sds", workAreaId] });
    } catch {
      toast.error(t("common.error"));
    }
  };

  const riskColor = (level: string) => {
    switch (level) {
      case "low": return "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400";
      case "medium": return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400";
      case "high": return "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400";
      case "very_high": return "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400";
      default: return "bg-muted text-muted-foreground";
    }
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <h5 className="text-xs font-semibold flex items-center gap-1.5">
          <FlaskConical className="h-3.5 w-3.5 text-secondary" />
          {t("substances.sdsDocuments")}
          {sdsDocs.length > 0 && (
            <Badge variant="secondary" className="text-[10px] h-4 px-1">{sdsDocs.length}</Badge>
          )}
        </h5>
        {!readOnly && (
          <label className="cursor-pointer">
            <input
              type="file"
              accept=".pdf"
              className="hidden"
              onChange={handleFileUpload}
              disabled={uploading}
            />
            <Button variant="outline" size="sm" className="h-6 text-xs" asChild disabled={uploading}>
              <span>
                {uploading ? (
                  <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                ) : (
                  <Upload className="h-3 w-3 mr-1" />
                )}
                {analyzing ? t("substances.analyzing") : t("substances.uploadSds")}
              </span>
            </Button>
          </label>
        )}
      </div>

      {isLoading && (
        <div className="flex justify-center py-2">
          <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
        </div>
      )}

      {sdsDocs.length === 0 && !isLoading && (
        <p className="text-muted-foreground text-[11px]">{t("substances.noSdsDocuments")}</p>
      )}

      {sdsDocs.map((doc: any) => (
        <div
          key={doc.id}
          className="flex items-center justify-between text-xs py-1.5 px-2 rounded bg-background border cursor-pointer hover:bg-accent/30 transition-colors"
          onClick={() => setSelectedDoc(doc)}
        >
          <div className="flex items-center gap-2 min-w-0">
            <FileText className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
            <div className="min-w-0">
              <span className="font-medium truncate block">{doc.substance_name || doc.file_name}</span>
              <div className="flex items-center gap-1.5 mt-0.5">
                {doc.cas_number && <span className="text-muted-foreground font-mono text-[10px]">CAS: {doc.cas_number}</span>}
                {doc.is_mixture && (
                  <Badge variant="outline" className="text-[9px] h-3.5 px-1">
                    <Beaker className="h-2.5 w-2.5 mr-0.5" />
                    {t("substances.mixture")}
                  </Badge>
                )}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            {doc.risk_level && (
              <Badge className={cn("text-[9px] h-4", riskColor(doc.risk_level))}>
                {t(`substances.risk_${doc.risk_level}`)}
              </Badge>
            )}
            {!readOnly && (
              <Button
                variant="ghost"
                size="icon"
                className="h-5 w-5"
                onClick={(e) => { e.stopPropagation(); handleDelete(doc); }}
              >
                <Trash2 className="h-3 w-3" />
              </Button>
            )}
          </div>
        </div>
      ))}

      {/* Detail Dialog */}
      <Dialog open={!!selectedDoc} onOpenChange={(open) => !open && setSelectedDoc(null)}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          {selectedDoc && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <FlaskConical className="h-5 w-5" />
                  {selectedDoc.substance_name || selectedDoc.file_name}
                  {selectedDoc.risk_level && (
                    <Badge className={riskColor(selectedDoc.risk_level)}>
                      {t(`substances.risk_${selectedDoc.risk_level}`)}
                    </Badge>
                  )}
                  {selectedDoc.is_mixture && (
                    <Badge variant="outline">
                      <Beaker className="h-3 w-3 mr-1" />
                      {t("substances.mixture")}
                    </Badge>
                  )}
                </DialogTitle>
              </DialogHeader>
              <SdsDocumentDetail doc={selectedDoc} />
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function SdsDocumentDetail({ doc }: { doc: any }) {
  const { t } = useTranslation();
  const analysis = doc.analysis_data;
  const mixComponents: MixtureComponent[] = doc.mixture_components || [];

  if (!analysis) {
    return <p className="text-sm text-muted-foreground">{t("substances.noAnalysisData")}</p>;
  }

  return (
    <div className="space-y-4">
      {/* Basic info */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
        <div><span className="text-muted-foreground">CAS:</span> <span className="font-mono">{analysis.cas_number || "-"}</span></div>
        <div><span className="text-muted-foreground">EC:</span> <span className="font-mono">{analysis.ec_number || "-"}</span></div>
        {analysis.matched_svhc && (
          <div className="col-span-2">
            <Badge variant="destructive">SVHC</Badge>
            <span className="text-sm ml-1">{analysis.svhc_reason}</span>
          </div>
        )}
      </div>

      {/* Mixture Components */}
      {mixComponents.length > 0 && (
        <Card className="border-secondary/30">
          <CardHeader className="py-2 px-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Beaker className="h-4 w-4 text-secondary" />
              {t("substances.mixtureComponents")} ({mixComponents.length})
            </CardTitle>
          </CardHeader>
          <CardContent className="py-1 px-3">
            <ScrollArea className="max-h-60">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-xs">{t("substances.componentName")}</TableHead>
                    <TableHead className="text-xs w-24">CAS</TableHead>
                    <TableHead className="text-xs w-28">{t("substances.concentration")}</TableHead>
                    <TableHead className="text-xs">{t("substances.classification")}</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {mixComponents.map((comp: MixtureComponent, i: number) => (
                    <TableRow key={i}>
                      <TableCell className="text-xs font-medium">{comp.name}</TableCell>
                      <TableCell className="text-xs font-mono">{comp.cas_number || "-"}</TableCell>
                      <TableCell className="text-xs">
                        {comp.concentration_min != null
                          ? `${comp.concentration_min}${comp.concentration_max != null && comp.concentration_max !== comp.concentration_min ? `-${comp.concentration_max}` : ''} ${comp.concentration_unit || '%'}`
                          : "-"}
                      </TableCell>
                      <TableCell className="text-xs">
                        {comp.classification || "-"}
                        {comp.hazard_statements?.length ? (
                          <div className="flex flex-wrap gap-0.5 mt-0.5">
                            {comp.hazard_statements.map((h, j) => (
                              <Badge key={j} variant="outline" className="text-[9px] h-4 px-1">{h}</Badge>
                            ))}
                          </div>
                        ) : null}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </ScrollArea>
          </CardContent>
        </Card>
      )}

      {/* Synergy risks for mixtures */}
      {analysis.mixture_synergy_risks?.length > 0 && (
        <Card className="border-destructive/30">
          <CardHeader className="py-2 px-3">
            <CardTitle className="text-sm flex items-center gap-2 text-destructive">
              <AlertTriangle className="h-4 w-4" />
              {t("substances.synergyRisks")}
            </CardTitle>
          </CardHeader>
          <CardContent className="py-1 px-3">
            <ul className="list-disc list-inside text-xs space-y-0.5">
              {analysis.mixture_synergy_risks.map((r: string, i: number) => (
                <li key={i}>{r}</li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      {/* GHS Classification */}
      {analysis.ghs_classification?.length > 0 && (
        <div>
          <Label className="text-sm font-semibold">{t("substances.ghsClassification")}</Label>
          <div className="flex flex-wrap gap-1 mt-1">
            {analysis.ghs_classification.map((g: string, i: number) => (
              <Badge key={i} variant="outline">{g}</Badge>
            ))}
          </div>
        </div>
      )}

      {/* Hazard Statements */}
      {analysis.hazard_statements?.length > 0 && (
        <Accordion type="single" collapsible>
          <AccordionItem value="hazards">
            <AccordionTrigger className="text-sm font-semibold py-1">
              {t("substances.hazardStatements")} ({analysis.hazard_statements.length})
            </AccordionTrigger>
            <AccordionContent>
              <ScrollArea className="max-h-40">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-20 text-xs">{t("substances.code")}</TableHead>
                      <TableHead className="text-xs">{t("substances.statement")}</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {analysis.hazard_statements.map((h: any, i: number) => (
                      <TableRow key={i}>
                        <TableCell className="font-mono text-xs">{h.code}</TableCell>
                        <TableCell className="text-xs">{h.text}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </ScrollArea>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      )}

      {/* Exposure Limits */}
      {analysis.exposure_limits?.length > 0 && (
        <div>
          <Label className="text-sm font-semibold">{t("substances.exposureLimits")}</Label>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mt-1">
            {analysis.exposure_limits.map((el: any, i: number) => (
              <Card key={i} className="p-2">
                <div className="text-[10px] text-muted-foreground">{el.type}{el.component ? ` (${el.component})` : ''}</div>
                <div className="font-semibold text-sm">{el.value} {el.unit}</div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* PPE */}
      {analysis.ppe_required?.length > 0 && (
        <div>
          <Label className="text-sm font-semibold">{t("substances.ppeRequired")}</Label>
          <div className="flex flex-wrap gap-1 mt-1">
            {analysis.ppe_required.map((p: string, i: number) => (
              <Badge key={i} variant="secondary">{p}</Badge>
            ))}
          </div>
        </div>
      )}

      {/* Incompatible materials */}
      {analysis.incompatible_materials?.length > 0 && (
        <div>
          <Label className="text-sm font-semibold">{t("substances.incompatibleMaterials")}</Label>
          <div className="flex flex-wrap gap-1 mt-1">
            {analysis.incompatible_materials.map((m: string, i: number) => (
              <Badge key={i} variant="destructive" className="text-xs">{m}</Badge>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
