import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Plus, Trash2, Building2, MapPin, Briefcase, Pencil } from "lucide-react";
import { toast } from "sonner";
import { Textarea } from "@/components/ui/textarea";
import WorkAreaSdsUpload from "@/components/WorkAreaSdsUpload";

interface WorkAreaManagerProps {
  companyId: string;
  readOnly?: boolean;
}

export default function WorkAreaManager({ companyId, readOnly = false }: WorkAreaManagerProps) {
  const { t } = useTranslation();
  const qc = useQueryClient();

  // --- Sites ---
  const { data: sites = [] } = useQuery({
    queryKey: ["company_sites", companyId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("company_sites")
        .select("*")
        .eq("company_id", companyId)
        .order("name");
      if (error) throw error;
      return data;
    },
    enabled: !!companyId,
  });

  // --- Work Areas ---
  const siteIds = sites.map((s: any) => s.id);
  const { data: workAreas = [] } = useQuery({
    queryKey: ["work_areas", siteIds],
    queryFn: async () => {
      if (!siteIds.length) return [];
      const { data, error } = await supabase
        .from("work_areas")
        .select("*")
        .in("site_id", siteIds)
        .order("name");
      if (error) throw error;
      return data;
    },
    enabled: siteIds.length > 0,
  });

  // --- Workplaces ---
  const waIds = workAreas.map((w: any) => w.id);
  const { data: workplaces = [] } = useQuery({
    queryKey: ["workplaces", waIds],
    queryFn: async () => {
      if (!waIds.length) return [];
      const { data, error } = await supabase
        .from("workplaces")
        .select("*")
        .in("work_area_id", waIds)
        .order("name");
      if (error) throw error;
      return data;
    },
    enabled: waIds.length > 0,
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold flex items-center gap-2">
          <Building2 className="h-5 w-5" />
          {t("risk.sites")}
        </h3>
        {!readOnly && (
          <SiteFormDialog companyId={companyId} onSuccess={() => qc.invalidateQueries({ queryKey: ["company_sites", companyId] })} />
        )}
      </div>

      {sites.length === 0 && (
        <p className="text-muted-foreground text-sm">{t("risk.noSites")}</p>
      )}

      <Accordion type="multiple" className="space-y-2">
        {sites.map((site: any) => {
          const siteWorkAreas = workAreas.filter((wa: any) => wa.site_id === site.id);
          return (
            <AccordionItem key={site.id} value={site.id} className="border rounded-lg px-4">
              <AccordionTrigger className="hover:no-underline">
                <div className="flex items-center gap-2 text-left">
                  <MapPin className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <span className="font-medium">{site.name}</span>
                    {site.city && <span className="text-muted-foreground text-sm ml-2">({site.city})</span>}
                  </div>
                </div>
              </AccordionTrigger>
              <AccordionContent className="space-y-3 pt-2">
                <div className="text-sm text-muted-foreground">
                  {site.address && <span>{site.address}</span>}
                  {site.postal_code && <span>, {site.postal_code}</span>}
                </div>

                {!readOnly && (
                  <div className="flex gap-2">
                    <SiteFormDialog companyId={companyId} site={site} onSuccess={() => qc.invalidateQueries({ queryKey: ["company_sites", companyId] })} />
                    <DeleteButton
                      label={t("risk.deleteSite")}
                      onDelete={async () => {
                        const { error } = await supabase.from("company_sites").delete().eq("id", site.id);
                        if (error) throw error;
                        qc.invalidateQueries({ queryKey: ["company_sites", companyId] });
                      }}
                    />
                  </div>
                )}

                <div className="ml-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm font-medium">{t("risk.workAreas")}</h4>
                    {!readOnly && (
                      <WorkAreaFormDialog siteId={site.id} onSuccess={() => qc.invalidateQueries({ queryKey: ["work_areas"] })} />
                    )}
                  </div>

                  {siteWorkAreas.length === 0 && (
                    <p className="text-muted-foreground text-xs">{t("risk.noWorkAreas")}</p>
                  )}

                  {siteWorkAreas.map((wa: any) => {
                    const waWorkplaces = workplaces.filter((wp: any) => wp.work_area_id === wa.id);
                    return (
                      <Card key={wa.id} className="bg-muted/30">
                        <CardHeader className="py-2 px-3">
                          <CardTitle className="text-sm flex items-center gap-2">
                            <Briefcase className="h-3.5 w-3.5" />
                            {wa.name}
                            {wa.area_size_m2 && <span className="text-muted-foreground font-normal">({wa.area_size_m2} m²)</span>}
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="py-1 px-3 space-y-2">
                          {wa.description && <p className="text-xs text-muted-foreground">{wa.description}</p>}

                          {/* SDS Documents Upload */}
                          <WorkAreaSdsUpload workAreaId={wa.id} workAreaName={wa.name} readOnly={readOnly} />
                          {!readOnly && (
                            <div className="flex gap-2">
                              <WorkAreaFormDialog siteId={wa.site_id} workArea={wa} onSuccess={() => qc.invalidateQueries({ queryKey: ["work_areas"] })} />
                              <DeleteButton
                                label={t("risk.deleteWorkArea")}
                                onDelete={async () => {
                                  const { error } = await supabase.from("work_areas").delete().eq("id", wa.id);
                                  if (error) throw error;
                                  qc.invalidateQueries({ queryKey: ["work_areas"] });
                                }}
                              />
                            </div>
                          )}

                          <div className="ml-4 space-y-1">
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-medium">{t("risk.workplaces")}</span>
                              {!readOnly && (
                                <WorkplaceFormDialog workAreaId={wa.id} onSuccess={() => qc.invalidateQueries({ queryKey: ["workplaces"] })} />
                              )}
                            </div>
                            {waWorkplaces.length === 0 && (
                              <p className="text-muted-foreground text-xs">{t("risk.noWorkplaces")}</p>
                            )}
                            {waWorkplaces.map((wp: any) => (
                              <div key={wp.id} className="flex items-center justify-between text-xs py-1 px-2 rounded bg-background">
                                <span>
                                  {wp.name}
                                  {wp.code && <span className="text-muted-foreground ml-1">[{wp.code}]</span>}
                                  {wp.employee_count > 0 && <span className="text-muted-foreground ml-1">({wp.employee_count} fő)</span>}
                                </span>
                                {!readOnly && (
                                  <div className="flex gap-1">
                                    <WorkplaceFormDialog workAreaId={wa.id} workplace={wp} onSuccess={() => qc.invalidateQueries({ queryKey: ["workplaces"] })} />
                                    <DeleteButton
                                      label={t("risk.deleteWorkplace")}
                                      onDelete={async () => {
                                        const { error } = await supabase.from("workplaces").delete().eq("id", wp.id);
                                        if (error) throw error;
                                        qc.invalidateQueries({ queryKey: ["workplaces"] });
                                      }}
                                    />
                                  </div>
                                )}
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </AccordionContent>
            </AccordionItem>
          );
        })}
      </Accordion>
    </div>
  );
}

// --- Sub-components ---

function DeleteButton({ label, onDelete }: { label: string; onDelete: () => Promise<void> }) {
  const [loading, setLoading] = useState(false);
  return (
    <Button
      variant="ghost"
      size="icon"
      className="h-6 w-6"
      disabled={loading}
      title={label}
      onClick={async () => {
        if (!confirm(label + "?")) return;
        setLoading(true);
        try { await onDelete(); toast.success(label); } catch { toast.error("Hiba"); } finally { setLoading(false); }
      }}
    >
      <Trash2 className="h-3 w-3" />
    </Button>
  );
}

function SiteFormDialog({ companyId, site, onSuccess }: { companyId: string; site?: any; onSuccess: () => void }) {
  const { t } = useTranslation();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: site?.name ?? "", address: site?.address ?? "", city: site?.city ?? "", postal_code: site?.postal_code ?? "" });
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    if (!form.name.trim()) return;
    setSaving(true);
    try {
      if (site) {
        const { error } = await supabase.from("company_sites").update(form).eq("id", site.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("company_sites").insert({ ...form, company_id: companyId });
        if (error) throw error;
      }
      onSuccess();
      setOpen(false);
      if (!site) setForm({ name: "", address: "", city: "", postal_code: "" });
    } catch { toast.error("Hiba"); } finally { setSaving(false); }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant={site ? "ghost" : "outline"} size={site ? "icon" : "sm"} className={site ? "h-6 w-6" : ""}>
          {site ? <Pencil className="h-3 w-3" /> : <><Plus className="h-4 w-4 mr-1" />{t("risk.addSite")}</>}
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>{site ? t("risk.editSite") : t("risk.addSite")}</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div><Label>{t("risk.siteName")}</Label><Input value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} /></div>
          <div><Label>{t("common.address")}</Label><Input value={form.address} onChange={e => setForm(p => ({ ...p, address: e.target.value }))} /></div>
          <div className="grid grid-cols-2 gap-2">
            <div><Label>{t("common.city")}</Label><Input value={form.city} onChange={e => setForm(p => ({ ...p, city: e.target.value }))} /></div>
            <div><Label>{t("risk.postalCode")}</Label><Input value={form.postal_code} onChange={e => setForm(p => ({ ...p, postal_code: e.target.value }))} /></div>
          </div>
          <Button onClick={handleSave} disabled={saving || !form.name.trim()} className="w-full">
            {saving ? t("common.saving") : t("common.save")}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function WorkAreaFormDialog({ siteId, workArea, onSuccess }: { siteId: string; workArea?: any; onSuccess: () => void }) {
  const { t } = useTranslation();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: workArea?.name ?? "", description: workArea?.description ?? "", area_size_m2: workArea?.area_size_m2 ?? "" });
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    if (!form.name.trim()) return;
    setSaving(true);
    try {
      const payload = { ...form, area_size_m2: form.area_size_m2 ? Number(form.area_size_m2) : null };
      if (workArea) {
        const { error } = await supabase.from("work_areas").update(payload).eq("id", workArea.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("work_areas").insert({ ...payload, site_id: siteId });
        if (error) throw error;
      }
      onSuccess();
      setOpen(false);
      if (!workArea) setForm({ name: "", description: "", area_size_m2: "" });
    } catch { toast.error("Hiba"); } finally { setSaving(false); }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant={workArea ? "ghost" : "outline"} size={workArea ? "icon" : "sm"} className={workArea ? "h-6 w-6" : "h-7 text-xs"}>
          {workArea ? <Pencil className="h-3 w-3" /> : <><Plus className="h-3 w-3 mr-1" />{t("risk.addWorkArea")}</>}
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>{workArea ? t("risk.editWorkArea") : t("risk.addWorkArea")}</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div><Label>{t("risk.workAreaName")}</Label><Input value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} /></div>
          <div><Label>{t("risk.description")}</Label><Textarea value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} /></div>
          <div><Label>{t("risk.areaSize")}</Label><Input type="number" value={form.area_size_m2} onChange={e => setForm(p => ({ ...p, area_size_m2: e.target.value }))} /></div>
          <Button onClick={handleSave} disabled={saving || !form.name.trim()} className="w-full">
            {saving ? t("common.saving") : t("common.save")}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function WorkplaceFormDialog({ workAreaId, workplace, onSuccess }: { workAreaId: string; workplace?: any; onSuccess: () => void }) {
  const { t } = useTranslation();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    name: workplace?.name ?? "",
    code: workplace?.code ?? "",
    description: workplace?.description ?? "",
    employee_count: workplace?.employee_count ?? 0,
  });
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    if (!form.name.trim()) return;
    setSaving(true);
    try {
      const payload = { ...form, employee_count: Number(form.employee_count) || 0 };
      if (workplace) {
        const { error } = await supabase.from("workplaces").update(payload).eq("id", workplace.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("workplaces").insert({ ...payload, work_area_id: workAreaId });
        if (error) throw error;
      }
      onSuccess();
      setOpen(false);
      if (!workplace) setForm({ name: "", code: "", description: "", employee_count: 0 });
    } catch { toast.error("Hiba"); } finally { setSaving(false); }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant={workplace ? "ghost" : "outline"} size={workplace ? "icon" : "sm"} className={workplace ? "h-5 w-5" : "h-6 text-xs"}>
          {workplace ? <Pencil className="h-2.5 w-2.5" /> : <><Plus className="h-3 w-3 mr-1" />{t("risk.addWorkplace")}</>}
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>{workplace ? t("risk.editWorkplace") : t("risk.addWorkplace")}</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div><Label>{t("risk.workplaceName")}</Label><Input value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} /></div>
          <div><Label>{t("risk.workplaceCode")}</Label><Input value={form.code} onChange={e => setForm(p => ({ ...p, code: e.target.value }))} /></div>
          <div><Label>{t("risk.description")}</Label><Textarea value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} /></div>
          <div><Label>{t("risk.employeeCount")}</Label><Input type="number" value={form.employee_count} onChange={e => setForm(p => ({ ...p, employee_count: e.target.value }))} /></div>
          <Button onClick={handleSave} disabled={saving || !form.name.trim()} className="w-full">
            {saving ? t("common.saving") : t("common.save")}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
