import { useState, useMemo, useEffect, useRef } from 'react';
import { LAB_TEST_CATALOG, SPECIALTIES, type LabTest } from '@/lib/labTestCatalog';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Search, Save, RotateCcw, CircleDollarSign, ChevronDown, ChevronUp, Wrench, Home, AlertTriangle, ShieldCheck, Info, Bug, ListChecks, X } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Checkbox } from '@/components/ui/checkbox';
import { detectMarkupBakedIn, explainDisplayPrice } from '@/hooks/use-lab-pricing';

type Override = { points: number; priceHuf: number };

function MarkupEditor({ onMarkupChange }: { onMarkupChange?: (m: number) => void }) {
  const { toast } = useToast();
  const [markup, setMarkup] = useState<number | null>(null);
  const [homeFee, setHomeFee] = useState<number | null>(null);
  const [markupInput, setMarkupInput] = useState('');
  const [homeFeeInput, setHomeFeeInput] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (supabase as any)
      .from('lab_markup_config')
      .select('markup_huf, home_sampling_fee_huf')
      .maybeSingle()
      .then(({ data }: { data: { markup_huf: number; home_sampling_fee_huf: number } | null }) => {
        const m = data?.markup_huf ?? 0;
        const h = data?.home_sampling_fee_huf ?? 0;
        setMarkup(m);
        setHomeFee(h);
        setMarkupInput(String(m));
        setHomeFeeInput(String(h));
        onMarkupChange?.(m);
      });
  }, [onMarkupChange]);

  const handleSave = async () => {
    const mVal = parseInt(markupInput, 10);
    const hVal = parseInt(homeFeeInput, 10);
    if (isNaN(mVal) || mVal < 0 || isNaN(hVal) || hVal < 0) {
      toast({ title: 'Érvénytelen érték', variant: 'destructive' });
      return;
    }
    setSaving(true);
    try {
      const { data: existing } = await (supabase as any).from('lab_markup_config').select('id').maybeSingle();
      if (existing?.id) {
        await (supabase as any).from('lab_markup_config').update({ markup_huf: mVal, home_sampling_fee_huf: hVal, updated_at: new Date().toISOString() }).eq('id', existing.id);
      } else {
        await (supabase as any).from('lab_markup_config').insert({ markup_huf: mVal, home_sampling_fee_huf: hVal });
      }
      setMarkup(mVal);
      setHomeFee(hVal);
      onMarkupChange?.(mVal);
      toast({ title: '✅ Beállítások mentve' });
    } catch (err) {
      toast({ title: 'Hiba', description: err instanceof Error ? err.message : 'Ismeretlen hiba', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="flex flex-wrap items-end gap-4 p-4 bg-primary/5 rounded-xl border border-primary/20">
      <div className="flex-1 min-w-[200px]">
        <p className="text-xs font-semibold text-foreground flex items-center gap-1.5 mb-1">
          <Wrench className="w-3.5 h-3.5 text-primary" /> Globális labor felár (Ft/vizsgálat)
        </p>
        <p className="text-[11px] text-muted-foreground">
          Jelenlegi: {markup !== null ? `${markup.toLocaleString('hu-HU')} Ft` : '…'}
        </p>
      </div>
      <div className="flex items-center gap-2">
        <div className="space-y-1">
          <span className="text-[10px] text-muted-foreground">Felár/vizsgálat</span>
          <Input type="number" min="0" value={markupInput} onChange={e => setMarkupInput(e.target.value)} className="w-28 h-8 text-sm text-center" />
        </div>
        <div className="space-y-1">
          <span className="text-[10px] text-muted-foreground flex items-center gap-1"><Home className="w-3 h-3" /> Otthoni díj</span>
          <Input type="number" min="0" value={homeFeeInput} onChange={e => setHomeFeeInput(e.target.value)} className="w-28 h-8 text-sm text-center" />
        </div>
        <Button size="sm" onClick={handleSave} disabled={saving} className="h-8 gap-1.5 self-end">
          <Save className="w-3.5 h-3.5" />
          {saving ? 'Ment...' : 'Mentés'}
        </Button>
      </div>
    </div>
  );
}

export default function LabPricingEditor() {
  const { toast } = useToast();
  const [overrides, setOverrides] = useState<Record<string, Override>>({});
  const [search, setSearch] = useState('');
  const [filterSpecialty, setFilterSpecialty] = useState('all');
  const [expandedSpecialties, setExpandedSpecialties] = useState<Set<string>>(new Set());
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const [currentMarkup, setCurrentMarkup] = useState(0);
  const SELECTION_STORAGE_KEY = 'lab-pricing-editor:selectedIds';
  const [selectedIds, setSelectedIds] = useState<Set<string>>(() => {
    if (typeof window === 'undefined') return new Set();
    try {
      const raw = window.localStorage.getItem(SELECTION_STORAGE_KEY);
      if (!raw) return new Set();
      const arr = JSON.parse(raw);
      return Array.isArray(arr) ? new Set(arr.filter((x): x is string => typeof x === 'string')) : new Set();
    } catch {
      return new Set();
    }
  });
  const [bulkTraceOpen, setBulkTraceOpen] = useState(false);
  const activeCatalogRef = useRef<LabTest[]>([]);

  // Persist selection across reloads
  useEffect(() => {
    try {
      if (selectedIds.size === 0) {
        window.localStorage.removeItem(SELECTION_STORAGE_KEY);
      } else {
        window.localStorage.setItem(SELECTION_STORAGE_KEY, JSON.stringify([...selectedIds]));
      }
    } catch {
      // ignore quota / privacy-mode errors
    }
  }, [selectedIds]);

  const toggleSelect = (id: string) =>
    setSelectedIds(prev => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n; });
  const clearSelection = () => setSelectedIds(new Set());
  const selectVisible = () => {
    setSelectedIds(prev => {
      const n = new Set(prev);
      activeCatalogRef.current.forEach(t => n.add(t.id));
      return n;
    });
  };

  /** Tests where override price suspiciously equals base + markup (markup baked in by mistake). */
  const suspiciousElemiTests = useMemo(() => {
    if (currentMarkup <= 0) return [] as LabTest[];
    return LAB_TEST_CATALOG.filter(t => detectMarkupBakedIn(t, overrides[t.id], currentMarkup));
  }, [overrides, currentMarkup]);

  const elemiCount = useMemo(() => LAB_TEST_CATALOG.filter(t => t.type === 'Elemi').length, []);

  useEffect(() => {
    (supabase as any)
      .from('lab_pricing_config')
      .select('test_id, points, price_huf')
      .then(({ data }: { data: { test_id: string; points: number; price_huf: number }[] | null }) => {
        if (!data) return;
        const map: Record<string, Override> = {};
        data.forEach(row => { map[row.test_id] = { points: row.points, priceHuf: row.price_huf }; });
        setOverrides(map);
      });
  }, []);

  const getPoints = (t: LabTest) => overrides[t.id]?.points ?? t.points;
  const getPrice = (t: LabTest) => overrides[t.id]?.priceHuf ?? t.priceHuf;

  const activeCatalog = useMemo(() => {
    return LAB_TEST_CATALOG.filter(t => {
      const q = search.toLowerCase();
      const matchSearch = !q || t.name.toLowerCase().includes(q) || t.shortName.toLowerCase().includes(q) || t.id.toLowerCase().includes(q);
      const matchSpec = filterSpecialty === 'all' || t.specialty === filterSpecialty;
      return matchSearch && matchSpec;
    });
  }, [search, filterSpecialty]);
  activeCatalogRef.current = activeCatalog;

  const selectedTests = useMemo(
    () => LAB_TEST_CATALOG.filter(t => selectedIds.has(t.id)),
    [selectedIds],
  );
  const bulkTraces = useMemo(
    () => selectedTests.map(t => ({
      test: t,
      trace: explainDisplayPrice(t, overrides, { markup_huf: currentMarkup }, t.id),
    })),
    [selectedTests, overrides, currentMarkup],
  );
  const bulkTotals = useMemo(() => {
    const sumBase = bulkTraces.reduce((s, x) => s + x.trace.basePrice, 0);
    const sumFinal = bulkTraces.reduce((s, x) => s + x.trace.finalPrice, 0);
    const elemiCount = bulkTraces.filter(x => x.trace.isElemi).length;
    const markupApplied = bulkTraces.filter(x => x.trace.markupApplied).length;
    return { sumBase, sumFinal, sumMarkup: sumFinal - sumBase, elemiCount, markupApplied };
  }, [bulkTraces]);

  const grouped = useMemo(() => {
    const g: Record<string, LabTest[]> = {};
    activeCatalog.forEach(t => {
      if (!g[t.specialty]) g[t.specialty] = [];
      g[t.specialty].push(t);
    });
    return g;
  }, [activeCatalog]);

  const updateField = (id: string, field: 'points' | 'priceHuf', value: string) => {
    const num = parseInt(value, 10);
    if (isNaN(num) || num < 0) return;
    const base = LAB_TEST_CATALOG.find(t => t.id === id)!;
    setOverrides(prev => ({
      ...prev,
      [id]: {
        points: field === 'points' ? num : (prev[id]?.points ?? base.points),
        priceHuf: field === 'priceHuf' ? num : (prev[id]?.priceHuf ?? base.priceHuf),
      }
    }));
    setDirty(true);
  };

  const resetTest = (id: string) => {
    setOverrides(prev => { const next = { ...prev }; delete next[id]; return next; });
    setDirty(true);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const rows = Object.entries(overrides).map(([test_id, v]) => ({
        test_id,
        points: Math.max(1, Math.min(9999, v.points)),
        price_huf: Math.max(0, Math.min(9999999, v.priceHuf)),
        updated_at: new Date().toISOString(),
      }));
      if (rows.length > 0) {
        const { error } = await (supabase as any).from('lab_pricing_config').upsert(rows, { onConflict: 'test_id' });
        if (error) throw error;
      }
      setDirty(false);
      toast({ title: '✅ Árak mentve' });
    } catch (err) {
      toast({ title: 'Hiba', description: err instanceof Error ? err.message : 'Ismeretlen hiba', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const handleResetAll = async () => {
    try {
      await (supabase as any).from('lab_pricing_config').delete().neq('test_id', '');
      setOverrides({});
      setDirty(false);
      toast({ title: 'Visszaállítva' });
    } catch (err) {
      toast({ title: 'Hiba', description: err instanceof Error ? err.message : 'Ismeretlen hiba', variant: 'destructive' });
    }
  };

  const toggleSpecialty = (s: string) =>
    setExpandedSpecialties(prev => { const n = new Set(prev); n.has(s) ? n.delete(s) : n.add(s); return n; });

  const overrideCount = Object.keys(overrides).length;

  return (
    <TooltipProvider delayDuration={150}>
    <div className="space-y-4">
      <MarkupEditor onMarkupChange={setCurrentMarkup} />

      {currentMarkup > 0 && (
        <div className="flex items-start gap-2 p-3 rounded-lg border border-blue-500/30 bg-blue-500/5 text-xs">
          <Info className="w-4 h-4 text-blue-500 mt-0.5 shrink-0" />
          <div className="text-foreground/90">
            <span className="font-semibold">Markup szabály:</span> A globális{' '}
            <span className="font-semibold">{currentMarkup.toLocaleString('hu-HU')} Ft</span> felár
            csak panelek/csomagok/speciális tesztek árához adódik hozzá megjelenítéskor.{' '}
            <span className="font-semibold">{elemiCount} elemi vizsgálat</span> (Nátrium, Kálium, GOT, …) MINDIG az itt megadott alapáron jelenik meg, markup nélkül.
          </div>
        </div>
      )}

      {suspiciousElemiTests.length > 0 && (
        <div className="flex items-start gap-2 p-3 rounded-lg border border-amber-500/40 bg-amber-500/10 text-xs">
          <AlertTriangle className="w-4 h-4 text-amber-600 mt-0.5 shrink-0" />
          <div className="text-foreground/90 space-y-1">
            <div>
              <span className="font-semibold">Figyelem:</span> {suspiciousElemiTests.length} elemi tesztnél az egyedi ár pont
              megegyezik az <em>alapár + markup</em> összegével — könnyen lehet, hogy valaki tévedésből beleszámolta a felárat.
              Az elemi tesztek a vásárló oldalán <strong>úgyse kapnak markupot</strong>, ezért az itt megadott ár a végleges.
            </div>
            <div className="flex flex-wrap gap-1 pt-1">
              {suspiciousElemiTests.slice(0, 8).map(t => (
                <Badge key={t.id} variant="outline" className="text-[10px] h-5 border-amber-500/40">
                  {t.id} – {t.name}
                </Badge>
              ))}
              {suspiciousElemiTests.length > 8 && (
                <Badge variant="outline" className="text-[10px] h-5">+{suspiciousElemiTests.length - 8} további</Badge>
              )}
            </div>
          </div>
        </div>
      )}

      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h3 className="text-base font-semibold text-foreground flex items-center gap-2">
            <CircleDollarSign className="w-4 h-4 text-primary" /> Labor vizsgálat árazás
          </h3>
          <p className="text-xs text-muted-foreground mt-0.5">
            Egyedi árak beállítása vizsgálatonként.
            {overrideCount > 0 && <Badge className="ml-2 h-4 text-[10px] px-1.5" variant="secondary">{overrideCount} egyedi ár</Badge>}
          </p>
        </div>
        <div className="flex gap-2">
          {dirty && (
            <Button size="sm" onClick={handleSave} disabled={saving} className="gap-1.5">
              <Save className="w-3.5 h-3.5" /> {saving ? 'Mentés...' : 'Mentés'}
            </Button>
          )}
          <Button variant="outline" size="sm" onClick={handleResetAll} className="gap-1.5 text-muted-foreground">
            <RotateCcw className="w-3.5 h-3.5" /> Alap visszaállítás
          </Button>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Keresés: név, kód…" className="pl-9 text-sm" />
        </div>
        <Select value={filterSpecialty} onValueChange={setFilterSpecialty}>
          <SelectTrigger className="w-full sm:w-[200px] text-xs h-9"><SelectValue placeholder="Szakterület" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Összes szakterület</SelectItem>
            {SPECIALTIES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      {selectedIds.size > 0 && (
        <div className="flex items-center justify-between gap-2 p-2 rounded-lg border border-primary/30 bg-primary/5 text-xs">
          <div className="flex items-center gap-2">
            <ListChecks className="w-4 h-4 text-primary" />
            <span className="font-semibold text-foreground">{selectedIds.size} kijelölt vizsgálat</span>
            <span className="text-muted-foreground">— összes végső ár jelenleg:{' '}
              <span className="font-mono font-semibold text-foreground">{bulkTotals.sumFinal.toLocaleString('hu-HU')} Ft</span>
              {bulkTotals.sumMarkup > 0 && (
                <span className="text-muted-foreground"> (+{bulkTotals.sumMarkup.toLocaleString('hu-HU')} Ft markup)</span>
              )}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Button size="sm" variant="default" onClick={() => setBulkTraceOpen(true)} className="h-7 gap-1.5">
              <Bug className="w-3.5 h-3.5" /> Trace mind
            </Button>
            <Button size="sm" variant="outline" onClick={selectVisible} className="h-7 gap-1.5">
              <ListChecks className="w-3.5 h-3.5" /> + látható
            </Button>
            <Button size="sm" variant="ghost" onClick={clearSelection} className="h-7 gap-1.5">
              <X className="w-3.5 h-3.5" /> Törlés
            </Button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-[auto_1fr_auto_auto_auto] gap-2 px-3 py-1.5 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground bg-muted/40 rounded-lg border border-border">
        <span className="w-5 text-center">✓</span>
        <span>Vizsgálat</span>
        <span className="w-28 text-center">Ft ár</span>
        <span className="w-10 text-center">Trace</span>
        <span className="w-14 text-center">Reset</span>
      </div>

      <ScrollArea className="h-[520px] border border-border rounded-xl">
        <div className="p-2 space-y-1">
          {Object.entries(grouped).map(([specialty, tests]) => {
            const isExpanded = expandedSpecialties.has(specialty) || !!search || filterSpecialty !== 'all';
            const customCount = tests.filter(t => overrides[t.id]).length;
            return (
              <div key={specialty}>
                <button
                  onClick={() => toggleSpecialty(specialty)}
                  className="w-full flex items-center justify-between px-3 py-2 rounded-lg bg-muted/60 hover:bg-muted transition-colors text-left"
                >
                  <span className="text-xs font-semibold text-foreground uppercase tracking-wide">{specialty}</span>
                  <div className="flex items-center gap-2">
                    {customCount > 0 && <Badge variant="secondary" className="h-4 text-[10px] px-1.5">{customCount} egyedi</Badge>}
                    <span className="text-[10px] text-muted-foreground">{tests.length} tétel</span>
                    {isExpanded ? <ChevronUp className="w-3 h-3 text-muted-foreground" /> : <ChevronDown className="w-3 h-3 text-muted-foreground" />}
                  </div>
                </button>
                {isExpanded && (
                  <div className="mt-0.5 space-y-0.5">
                    {tests.map(test => {
                      const hasOverride = !!overrides[test.id];
                      const price = getPrice(test);
                      const isElemi = test.type === 'Elemi';
                      const isSuspicious = detectMarkupBakedIn(test, overrides[test.id], currentMarkup);
                      const isSelected = selectedIds.has(test.id);
                      return (
                        <div
                          key={test.id}
                          className={`grid grid-cols-[auto_1fr_auto_auto_auto] gap-2 items-center px-3 py-2 rounded-lg transition-colors ${
                            isSelected
                              ? 'bg-primary/10 border border-primary/40'
                              : isSuspicious
                                ? 'bg-amber-500/10 border border-amber-500/40'
                                : hasOverride
                                  ? 'bg-primary/5 border border-primary/20'
                                  : 'hover:bg-muted/40'
                          }`}
                        >
                          <div className="w-5 flex justify-center">
                            <Checkbox
                              checked={isSelected}
                              onCheckedChange={() => toggleSelect(test.id)}
                              aria-label={`Kijelölés: ${test.name}`}
                            />
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="font-mono text-[10px] text-muted-foreground">{test.id}</span>
                              <span className="text-xs font-medium text-foreground truncate">{test.name}</span>
                              {hasOverride && <span className="text-[9px] bg-primary/10 text-primary px-1 rounded font-semibold">EGYEDI</span>}
                              {isElemi && currentMarkup > 0 && (
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <span className="inline-flex items-center gap-0.5 text-[9px] bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 px-1 rounded font-semibold">
                                      <ShieldCheck className="w-2.5 h-2.5" /> ELEMI
                                    </span>
                                  </TooltipTrigger>
                                  <TooltipContent side="top" className="max-w-[260px] text-xs">
                                    Elemi vizsgálat — a vásárló oldalán <strong>nem</strong> kapja meg a {currentMarkup.toLocaleString('hu-HU')} Ft globális felárat. A megadott ár a végleges megjelenítendő ár.
                                  </TooltipContent>
                                </Tooltip>
                              )}
                              {isSuspicious && (
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <span className="inline-flex items-center gap-0.5 text-[9px] bg-amber-500/15 text-amber-700 dark:text-amber-400 px-1 rounded font-semibold">
                                      <AlertTriangle className="w-2.5 h-2.5" /> GYANÚS
                                    </span>
                                  </TooltipTrigger>
                                  <TooltipContent side="top" className="max-w-[280px] text-xs">
                                    Az egyedi ár pont = katalógusalap ({test.priceHuf.toLocaleString('hu-HU')} Ft) + markup ({currentMarkup.toLocaleString('hu-HU')} Ft). Lehet, hogy tévedésből beleszámolta a felárat. Elemi tesztnél nem kell — állítsa vissza vagy adja meg a tényleges nettó árat.
                                  </TooltipContent>
                                </Tooltip>
                              )}
                            </div>
                            <div className="text-[10px] text-muted-foreground">🧪 {test.sampleType}</div>
                          </div>
                          <div className="w-28 flex items-center gap-1">
                            <Input
                              type="number"
                              min="0"
                              max="9999999"
                              value={price}
                              onChange={e => updateField(test.id, 'priceHuf', e.target.value)}
                              className="h-7 text-xs text-center px-1 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                            />
                            <span className="text-[10px] text-muted-foreground">Ft</span>
                          </div>
                          <div className="w-10 flex justify-center">
                            <Popover>
                              <PopoverTrigger asChild>
                                <button
                                  className="text-muted-foreground hover:text-primary transition-colors p-1 rounded hover:bg-primary/10"
                                  title="Számítás magyarázata"
                                >
                                  <Bug className="w-3 h-3" />
                                </button>
                              </PopoverTrigger>
                              <PopoverContent side="left" className="w-[420px] text-xs p-3 space-y-2">
                                {(() => {
                                  const trace = explainDisplayPrice(test, overrides, { markup_huf: currentMarkup }, test.id);
                                  return (
                                    <>
                                      <div className="flex items-center justify-between gap-2 pb-2 border-b border-border">
                                        <span className="font-mono text-[10px] text-muted-foreground">{test.id}</span>
                                        <span className="font-semibold text-foreground truncate">{test.name}</span>
                                        <Badge variant={trace.isElemi ? 'secondary' : 'default'} className="h-4 text-[10px]">
                                          {trace.testType}
                                        </Badge>
                                      </div>
                                      <ol className="space-y-1 list-none">
                                        {trace.steps.map((s, i) => (
                                          <li key={i} className="text-foreground/90 leading-relaxed">{s}</li>
                                        ))}
                                      </ol>
                                      <div className="pt-2 mt-2 border-t border-border grid grid-cols-2 gap-x-3 gap-y-1 text-[10px] text-muted-foreground">
                                        <span>Katalógus alap:</span><span className="text-right font-mono text-foreground">{trace.catalogPrice} Ft</span>
                                        <span>Override:</span><span className="text-right font-mono text-foreground">{trace.hasOverride ? `${trace.overridePrice} Ft` : '—'}</span>
                                        <span>Markup (globális):</span><span className="text-right font-mono text-foreground">{trace.markupHuf} Ft</span>
                                        <span>Markup alkalmazva:</span><span className={`text-right font-mono ${trace.markupApplied ? 'text-amber-600' : 'text-emerald-600'}`}>{trace.markupApplied ? 'IGEN' : 'NEM'}</span>
                                        {trace.markupSkipReason && (
                                          <><span className="col-span-2 text-[10px] text-emerald-700 dark:text-emerald-400 italic pt-1">↳ {trace.markupSkipReason}</span></>
                                        )}
                                        <span className="font-semibold text-foreground pt-1">Végső ár:</span>
                                        <span className="text-right font-mono font-bold text-foreground pt-1">{trace.finalPrice} Ft</span>
                                      </div>
                                    </>
                                  );
                                })()}
                              </PopoverContent>
                            </Popover>
                          </div>
                          <div className="w-14 flex justify-center">
                            {hasOverride ? (
                              <button
                                onClick={() => resetTest(test.id)}
                                className="text-[10px] text-muted-foreground hover:text-destructive transition-colors px-1.5 py-0.5 rounded hover:bg-destructive/10"
                              >
                                <RotateCcw className="w-3 h-3" />
                              </button>
                            ) : (
                              <span className="text-[10px] text-muted-foreground/30">—</span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </ScrollArea>

      {dirty && (
        <div className="flex items-center justify-between pt-3 border-t border-border">
          <p className="text-xs text-muted-foreground">{overrideCount} vizsgálatnál van egyedi ár</p>
          <Button onClick={handleSave} disabled={saving} className="gap-1.5">
            <Save className="w-4 h-4" /> {saving ? 'Mentés...' : 'Mentés'}
          </Button>
        </div>
      )}

      <Dialog open={bulkTraceOpen} onOpenChange={setBulkTraceOpen}>
        <DialogContent className="max-w-3xl max-h-[85vh] flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Bug className="w-4 h-4 text-primary" />
              Tömeges ár-trace ({bulkTraces.length} vizsgálat)
            </DialogTitle>
            <DialogDescription className="text-xs">
              Jelenlegi globális markup: <span className="font-mono font-semibold">{currentMarkup.toLocaleString('hu-HU')} Ft</span>.
              Az alábbi listán látható, hogy melyik teszt miért kap (vagy nem kap) felárat, és mennyi a végső ár.
            </DialogDescription>
          </DialogHeader>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 p-3 rounded-lg bg-muted/40 border border-border text-xs">
            <div>
              <div className="text-[10px] text-muted-foreground uppercase">Alap összesen</div>
              <div className="font-mono font-semibold text-foreground">{bulkTotals.sumBase.toLocaleString('hu-HU')} Ft</div>
            </div>
            <div>
              <div className="text-[10px] text-muted-foreground uppercase">Markup hozzáadva</div>
              <div className="font-mono font-semibold text-amber-600">+{bulkTotals.sumMarkup.toLocaleString('hu-HU')} Ft</div>
            </div>
            <div>
              <div className="text-[10px] text-muted-foreground uppercase">Végső összeg</div>
              <div className="font-mono font-bold text-foreground">{bulkTotals.sumFinal.toLocaleString('hu-HU')} Ft</div>
            </div>
            <div>
              <div className="text-[10px] text-muted-foreground uppercase">Markup kihagyva</div>
              <div className="font-semibold text-emerald-600">{bulkTotals.elemiCount} elemi / {bulkTraces.length}</div>
            </div>
          </div>

          <ScrollArea className="flex-1 -mx-2 px-2">
            <div className="space-y-2 py-2">
              {bulkTraces.map(({ test, trace }) => (
                <div
                  key={test.id}
                  className={`rounded-lg border p-3 text-xs space-y-1.5 ${
                    trace.markupApplied
                      ? 'border-amber-500/30 bg-amber-500/5'
                      : 'border-emerald-500/30 bg-emerald-500/5'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="font-mono text-[10px] text-muted-foreground">{test.id}</span>
                      <span className="font-semibold text-foreground truncate">{test.name}</span>
                      <Badge variant={trace.isElemi ? 'secondary' : 'default'} className="h-4 text-[10px]">
                        {trace.testType}
                      </Badge>
                      {trace.hasOverride && (
                        <span className="text-[9px] bg-primary/10 text-primary px-1 rounded font-semibold">EGYEDI</span>
                      )}
                    </div>
                    <div className="flex items-baseline gap-1.5 font-mono">
                      <span className="text-muted-foreground text-[10px]">{trace.basePrice.toLocaleString('hu-HU')}</span>
                      {trace.markupApplied && (
                        <span className="text-amber-600 text-[10px]">+{trace.markupHuf.toLocaleString('hu-HU')}</span>
                      )}
                      <span className="text-foreground font-bold">= {trace.finalPrice.toLocaleString('hu-HU')} Ft</span>
                    </div>
                  </div>
                  <ol className="space-y-0.5 list-none pl-1 text-foreground/85 leading-relaxed">
                    {trace.steps.map((s, i) => (
                      <li key={i}>{s}</li>
                    ))}
                  </ol>
                  {trace.markupSkipReason && (
                    <div className="text-[10px] text-emerald-700 dark:text-emerald-400 italic">
                      ↳ {trace.markupSkipReason}
                    </div>
                  )}
                </div>
              ))}
              {bulkTraces.length === 0 && (
                <div className="text-center text-muted-foreground py-8 text-sm">
                  Nincs kiválasztott vizsgálat.
                </div>
              )}
            </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </div>
    </TooltipProvider>
  );
}
