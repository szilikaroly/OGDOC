import { useState, useMemo, useRef, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { Input } from "@/components/ui/input";
import { FEOR_CODES } from "@/lib/feor-codes";
import { Search } from "lucide-react";

interface FeorSearchProps {
  value: string;
  onChange: (value: string) => void;
  onPositionChange?: (name: string) => void;
  placeholder?: string;
}

export default function FeorSearch({ value, onChange, onPositionChange, placeholder }: FeorSearchProps) {
  const { t } = useTranslation();
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const wrapperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (wrapperRef.current && !wrapperRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const filtered = useMemo(() => {
    const q = (search || value).toLowerCase().trim();
    if (!q) return FEOR_CODES.slice(0, 30);
    return FEOR_CODES.filter(
      (f) => f.code.includes(q) || f.name.toLowerCase().includes(q)
    ).slice(0, 50);
  }, [search, value]);

  const displayValue = useMemo(() => {
    if (!value) return "";
    const match = FEOR_CODES.find((f) => f.code === value);
    return match ? `${match.code} — ${match.name}` : value;
  }, [value]);

  return (
    <div ref={wrapperRef} className="relative">
      <div className="relative">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          className="pl-8"
          placeholder={placeholder || t("companies.feorPlaceholder")}
          value={open ? search : displayValue}
          onChange={(e) => {
            setSearch(e.target.value);
            onChange(e.target.value);
            if (!open) setOpen(true);
          }}
          onFocus={() => {
            setSearch(value);
            setOpen(true);
          }}
        />
      </div>
      {open && filtered.length > 0 && (
        <div className="absolute z-50 mt-1 w-full max-h-56 overflow-y-auto rounded-md border bg-popover shadow-md">
          {filtered.map((f) => (
            <button
              key={f.code + f.name}
              type="button"
              className="flex w-full items-center gap-2 px-3 py-2 text-left text-sm hover:bg-accent transition-colors"
              onClick={() => {
                onChange(f.code);
                onPositionChange?.(f.name);
                setSearch("");
                setOpen(false);
              }}
            >
              <span className="font-mono text-xs font-medium text-primary min-w-[3rem]">{f.code}</span>
              <span className="text-foreground truncate">{f.name}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}