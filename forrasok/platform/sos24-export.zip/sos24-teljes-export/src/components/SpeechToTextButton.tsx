import { useState, useRef } from "react";
import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import { Mic, MicOff, Loader2 } from "lucide-react";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface SpeechToTextButtonProps {
  onResult: (text: string) => void;
  className?: string;
}

export default function SpeechToTextButton({ onResult, className }: SpeechToTextButtonProps) {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [recording, setRecording] = useState(false);
  const [processing, setProcessing] = useState(false);
  const mediaRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream, { mimeType: "audio/webm" });
      chunksRef.current = [];
      recorder.ondataavailable = e => { if (e.data.size > 0) chunksRef.current.push(e.data); };
      recorder.onstop = async () => {
        stream.getTracks().forEach(t => t.stop());
        const blob = new Blob(chunksRef.current, { type: "audio/webm" });
        await processAudio(blob);
      };
      recorder.start();
      mediaRef.current = recorder;
      setRecording(true);
    } catch {
      toast({ variant: "destructive", title: t("accident.micError") });
    }
  };

  const stopRecording = () => {
    mediaRef.current?.stop();
    setRecording(false);
  };

  const processAudio = async (blob: Blob) => {
    setProcessing(true);
    try {
      const reader = new FileReader();
      const base64 = await new Promise<string>((res, rej) => {
        reader.onloadend = () => res((reader.result as string).split(",")[1]);
        reader.onerror = rej;
        reader.readAsDataURL(blob);
      });

      const { data, error } = await supabase.functions.invoke("ai-speech-to-text", {
        body: { audio_base64: base64, mime_type: "audio/webm" },
      });
      if (error) throw error;
      const text = data?.translated_text || data?.original_text || "";
      if (text) onResult(text);
      else toast({ variant: "destructive", title: t("accident.sttNoResult") });
    } catch (e: any) {
      toast({ variant: "destructive", title: t("common.error"), description: e.message });
    } finally {
      setProcessing(false);
    }
  };

  if (processing) {
    return <Button type="button" size="icon" variant="outline" disabled className={className}><Loader2 className="h-4 w-4 animate-spin" /></Button>;
  }

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Button
          type="button"
          size="icon"
          variant={recording ? "destructive" : "outline"}
          className={`${className} ${recording ? "animate-pulse" : ""}`}
          onClick={recording ? stopRecording : startRecording}
        >
          {recording ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
        </Button>
      </TooltipTrigger>
      <TooltipContent>{t("accident.sttTooltip")}</TooltipContent>
    </Tooltip>
  );
}
