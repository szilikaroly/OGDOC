import { useState, useEffect, useRef } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { ChevronLeft, ChevronRight, Save, FileText, MapPin, Camera, X, Loader2 } from "lucide-react";
import SpeechToTextButton from "./SpeechToTextButton";
import TeaorSearch from "./TeaorSearch";
import FeorSearch from "./FeorSearch";
import BnoSearch from "./BnoSearch";
import {
  TERRITORIAL_CODES, REPORT_TYPES, STAFF_CATEGORIES, CITIZENSHIP_CODES, GENDER_CODES,
  EMPLOYMENT_TYPE_CODES, EMPLOYMENT_NATURE_CODES, INJURY_TYPE_CODES, BODY_PART_CODES,
  WORK_LOCATION_CODES, INJURY_SEVERITY_CODES, SAFETY_DEVICE_OPTIONS, SAFETY_REP_AGREEMENT,
} from "@/lib/accident-codes";

interface AccidentReportFormProps {
  companyId: string;
  reportId?: string;
  onSaved?: () => void;
}

const STEPS = ["employer", "injured", "accident", "description", "additional", "causes", "photos", "investigators"] as const;

export default function AccidentReportForm({ companyId, reportId, onSaved }: AccidentReportFormProps) {
  const { t } = useTranslation();
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [step, setStep] = useState(0);
  const [form, setForm] = useState<Record<string, any>>({});
  const [photoUrls, setPhotoUrls] = useState<string[]>([]);
  const [uploading, setUploading] = useState(false);
  const [gpsLoading, setGpsLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load company data for auto-fill
  const { data: company } = useQuery({
    queryKey: ["company-for-accident", companyId],
    queryFn: async () => {
      const { data } = await supabase.from("companies").select("*").eq("id", companyId).single();
      return data;
    },
  });

  // Load employees for selection
  const { data: employees } = useQuery({
    queryKey: ["company-employees-accident", companyId],
    queryFn: async () => {
      const { data: rels } = await supabase.from("user_company_relations" as any).select("user_id, feor_code, feor_name").eq("company_id", companyId).eq("is_active", true);
      if (!rels?.length) return [];
      const ids = (rels as any[]).map((r: any) => r.user_id);
      const { data: profiles } = await supabase.from("profiles").select("*").in("user_id", ids);
      return (profiles || []).map((p: any) => {
        const rel = (rels as any[]).find((r: any) => r.user_id === p.user_id);
        return { ...p, feor_code: rel?.feor_code, feor_name: rel?.feor_name };
      });
    },
  });

  // Load TEÁOR codes
  const { data: teaorCodes } = useQuery({
    queryKey: ["company-teaor", companyId],
    queryFn: async () => {
      const { data } = await supabase.from("company_teaor_codes" as any).select("*").eq("company_id", companyId);
      return data || [];
    },
  });

  // Load existing report
  const { data: existingReport } = useQuery({
    queryKey: ["accident-report", reportId],
    queryFn: async () => {
      if (!reportId) return null;
      const { data } = await supabase.from("accident_reports" as any).select("*").eq("id", reportId).single();
      return data;
    },
    enabled: !!reportId,
  });

  // Auto-fill employer data from database
  useEffect(() => {
    if (existingReport) {
      setForm(existingReport as any);
      if ((existingReport as any).photos) {
        setPhotoUrls((existingReport as any).photos || []);
      }
      return;
    }
    if (company && !form.employer_name) {
      const primaryTeaor = teaorCodes?.find((t: any) => t.is_primary);
      const allTeaorStr = teaorCodes?.map((t: any) => `${t.teaor_code}`).join(", ") || "";
      setForm(prev => ({
        ...prev,
        employer_name: company.name,
        employer_address: company.address || "",
        employer_phone: company.contact_phone || "",
        employer_email: company.contact_email || "",
        employer_tax_number: company.tax_number || "",
        employer_tax_id: company.registration_no || "",
        employer_teaor_main: primaryTeaor ? `${(primaryTeaor as any).teaor_code}` : "",
        employer_teaor_local: allTeaorStr,
        report_type: "1",
      }));
    }
  }, [company, teaorCodes, existingReport]);

  const set = (key: string, value: any) => setForm(prev => ({ ...prev, [key]: value }));

  // GPS capture
  const captureGps = () => {
    if (!navigator.geolocation) {
      toast({ variant: "destructive", title: t("accident.gpsNotSupported") });
      return;
    }
    setGpsLoading(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        set("gps_lat", pos.coords.latitude);
        set("gps_lng", pos.coords.longitude);
        set("accident_geo_location", `${pos.coords.latitude.toFixed(6)}, ${pos.coords.longitude.toFixed(6)}`);
        setGpsLoading(false);
        toast({ title: t("accident.gpsAcquired") });
      },
      (err) => {
        setGpsLoading(false);
        toast({ variant: "destructive", title: t("accident.gpsError"), description: err.message });
      },
      { enableHighAccuracy: true, timeout: 15000 }
    );
  };

  // Photo upload
  const uploadPhotos = async (files: FileList) => {
    setUploading(true);
    const newPaths: string[] = [];
    for (const file of Array.from(files)) {
      const ext = file.name.split(".").pop();
      const path = `${companyId}/${Date.now()}_${Math.random().toString(36).slice(2)}.${ext}`;
      const { error } = await supabase.storage.from("accident-photos").upload(path, file);
      if (!error) newPaths.push(path);
    }
    const updated = [...photoUrls, ...newPaths];
    setPhotoUrls(updated);
    set("photos", updated);
    setUploading(false);
  };

  const removePhoto = async (path: string) => {
    await supabase.storage.from("accident-photos").remove([path]);
    const updated = photoUrls.filter(p => p !== path);
    setPhotoUrls(updated);
    set("photos", updated);
  };

  // Get signed URLs for display
  const [signedUrls, setSignedUrls] = useState<Record<string, string>>({});
  useEffect(() => {
    if (!photoUrls.length) return;
    const load = async () => {
      const urls: Record<string, string> = {};
      for (const p of photoUrls) {
        const { data } = await supabase.storage.from("accident-photos").createSignedUrl(p, 3600);
        if (data?.signedUrl) urls[p] = data.signedUrl;
      }
      setSignedUrls(urls);
    };
    load();
  }, [photoUrls]);

  const save = useMutation({
    mutationFn: async () => {
      const { id: _id, created_at: _ca, updated_at: _ua, ...rest } = form;
      const payload = {
        ...rest,
        company_id: companyId,
        created_by: user!.id,
        employee_id: form.employee_id || user!.id,
        photos: photoUrls,
      };
      if (reportId) {
        const { error } = await supabase.from("accident_reports" as any).update(payload).eq("id", reportId);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("accident_reports" as any).insert(payload);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["accident-reports"] });
      toast({ title: t("accident.saved") });
      onSaved?.();
    },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  const selectEmployee = (userId: string) => {
    const emp = employees?.find((e: any) => e.user_id === userId);
    if (!emp) return;
    setForm(prev => ({
      ...prev,
      employee_id: userId,
      injured_name: (emp as any).full_name || "",
      injured_taj: (emp as any).taj_number || "",
      injured_birth_date: (emp as any).birth_date || "",
      injured_birth_place: (emp as any).birth_place || "",
      injured_mother_name: (emp as any).mother_name || "",
      injured_gender: (emp as any).gender === "ferfi" ? "1" : (emp as any).gender === "no" ? "2" : "",
      injured_address: (emp as any).address || "",
      injured_phone: (emp as any).phone || "",
      injured_feor_code: (emp as any).feor_code || "",
      injured_feor_name: (emp as any).feor_name || "",
    }));
  };

  const SttField = ({ label, field, multiline = false }: { label: string; field: string; multiline?: boolean }) => (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      <div className="flex gap-2">
        {multiline ? (
          <Textarea value={form[field] || ""} onChange={e => set(field, e.target.value)} className="flex-1" rows={4} />
        ) : (
          <Input value={form[field] || ""} onChange={e => set(field, e.target.value)} className="flex-1" />
        )}
        <SpeechToTextButton onResult={text => set(field, (form[field] || "") + " " + text)} />
      </div>
    </div>
  );

  const CodeSelect = ({ label, field, codes }: { label: string; field: string; codes: { code: string; name: string }[] }) => (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      <Select value={form[field] || ""} onValueChange={v => set(field, v)}>
        <SelectTrigger><SelectValue placeholder={t("common.select")} /></SelectTrigger>
        <SelectContent>
          {codes.map(c => <SelectItem key={c.code} value={c.code}>{c.code} — {c.name}</SelectItem>)}
        </SelectContent>
      </Select>
    </div>
  );

  const Field = ({ label, field, type = "text" }: { label: string; field: string; type?: string }) => (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      <Input type={type} value={form[field] || ""} onChange={e => set(field, e.target.value)} />
    </div>
  );

  const renderStep = () => {
    switch (STEPS[step]) {
      case "employer":
        return (
          <div className="grid gap-4 md:grid-cols-2">
            <Field label={t("accident.employerName")} field="employer_name" />
            <Field label={t("accident.employerAddress")} field="employer_address" />
            <Field label={t("accident.employerPhone")} field="employer_phone" />
            <Field label={t("accident.employerEmail")} field="employer_email" />
            <Field label={t("accident.employerTaxNumber")} field="employer_tax_number" />
            <Field label={t("accident.employerTaxId")} field="employer_tax_id" />
            <Field label={t("accident.employerOrgForm")} field="employer_org_form" />
            <div className="space-y-1.5">
              <Label>{t("accident.employerTeaorMain")}</Label>
              <TeaorSearch value={form.employer_teaor_main || ""} onChange={(code) => set("employer_teaor_main", code)} />
            </div>
            <div className="space-y-1.5">
              <Label>{t("accident.employerTeaorLocal")}</Label>
              <TeaorSearch value={form.employer_teaor_local || ""} onChange={(code) => set("employer_teaor_local", code)} />
            </div>
            <CodeSelect label={t("accident.totalStaffCategory")} field="employer_total_staff_category" codes={STAFF_CATEGORIES} />
            <CodeSelect label={t("accident.localStaffCategory")} field="employer_local_staff_category" codes={STAFF_CATEGORIES} />
            <CodeSelect label={t("accident.territorialCode")} field="territorial_code" codes={TERRITORIAL_CODES} />
            <CodeSelect label={t("accident.reportType")} field="report_type" codes={REPORT_TYPES} />
            <Field label={t("accident.registrationNumber")} field="registration_number" />
          </div>
        );
      case "injured":
        return (
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label>{t("accident.selectEmployee")}</Label>
              <Select value={form.employee_id || ""} onValueChange={selectEmployee}>
                <SelectTrigger><SelectValue placeholder={t("accident.selectEmployee")} /></SelectTrigger>
                <SelectContent>
                  {employees?.map((e: any) => <SelectItem key={e.user_id} value={e.user_id}>{e.full_name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              <Field label={t("accident.injuredName")} field="injured_name" />
              <Field label={t("accident.injuredTaj")} field="injured_taj" />
              <Field label={t("accident.injuredBirthName")} field="injured_birth_name" />
              <Field label={t("accident.injuredMotherName")} field="injured_mother_name" />
              <Field label={t("accident.injuredBirthPlace")} field="injured_birth_place" />
              <Field label={t("accident.injuredBirthDate")} field="injured_birth_date" type="date" />
              <CodeSelect label={t("accident.injuredGender")} field="injured_gender" codes={GENDER_CODES} />
              <CodeSelect label={t("accident.injuredCitizenship")} field="injured_citizenship" codes={CITIZENSHIP_CODES} />
              <Field label={t("accident.injuredAddress")} field="injured_address" />
              <Field label={t("accident.injuredPhone")} field="injured_phone" />
              <div className="space-y-1.5">
                <Label>{t("accident.injuredFeor")}</Label>
                <FeorSearch value={form.injured_feor_code || ""} onChange={v => set("injured_feor_code", v)} onPositionChange={n => set("injured_feor_name", n)} />
              </div>
              <CodeSelect label={t("accident.employmentType")} field="injured_employment_type" codes={EMPLOYMENT_TYPE_CODES} />
              <CodeSelect label={t("accident.employmentNature")} field="injured_employment_nature" codes={EMPLOYMENT_NATURE_CODES} />
            </div>
          </div>
        );
      case "accident":
        return (
          <div className="grid gap-4 md:grid-cols-2">
            <Field label={t("accident.accidentDate")} field="accident_date" type="date" />
            <Field label={t("accident.accidentTimeHour")} field="accident_time_hour" />
            <Field label={t("accident.injuryWorkHour")} field="injury_work_hour" />
            <CodeSelect label={t("accident.injuryType")} field="injury_type_code" codes={INJURY_TYPE_CODES} />
            <CodeSelect label={t("accident.injuredBodyPart")} field="injured_body_part_code" codes={BODY_PART_CODES} />
            <CodeSelect label={t("accident.workLocation")} field="work_location_code" codes={WORK_LOCATION_CODES} />
            <div className="space-y-1.5">
              <Label>{t("accident.accidentGeoLocation")}</Label>
              <div className="flex gap-2">
                <Input value={form.accident_geo_location || ""} onChange={e => set("accident_geo_location", e.target.value)} className="flex-1" />
                <Button type="button" variant="outline" size="icon" onClick={captureGps} disabled={gpsLoading}>
                  {gpsLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <MapPin className="h-4 w-4" />}
                </Button>
              </div>
              {form.gps_lat && form.gps_lng && (
                <p className="text-xs text-muted-foreground">
                  GPS: {Number(form.gps_lat).toFixed(6)}, {Number(form.gps_lng).toFixed(6)}
                  <a
                    href={`https://www.google.com/maps?q=${form.gps_lat},${form.gps_lng}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="ml-2 text-primary underline"
                  >
                    {t("accident.viewOnMap")}
                  </a>
                </p>
              )}
            </div>
            <Field label={t("accident.accidentGeoCode")} field="accident_geo_code" />
            <CodeSelect label={t("accident.injurySeverity")} field="injury_severity_code" codes={INJURY_SEVERITY_CODES} />
            <Field label={t("accident.disabilityDays")} field="disability_days" type="number" />
          </div>
        );
      case "description":
        return (
          <div className="space-y-4">
            <SttField label={t("accident.detailedDescription")} field="detailed_description" multiline />
            <div className="space-y-1.5">
              <Label>{t("icd.injuryCodes")}</Label>
              <BnoSearch
                values={form.icd_codes || []}
                onChange={(code) => setForm(prev => ({ ...prev, icd_codes: [...(prev.icd_codes || []), code] }))}
                onRemove={(code) => setForm(prev => ({ ...prev, icd_codes: (prev.icd_codes || []).filter((c: string) => c !== code) }))}
                multiple
              />
            </div>
          </div>
        );
      case "additional":
        return (
          <div className="space-y-4">
            <SttField label={t("accident.workplaceEnvironment")} field="workplace_environment" />
            <SttField label={t("accident.workProcess")} field="work_process" />
            <SttField label={t("accident.physicalActivity")} field="physical_activity" />
            <SttField label={t("accident.physicalActivityMaterial")} field="physical_activity_material" />
            <SttField label={t("accident.triggeringEvent")} field="triggering_event" />
            <SttField label={t("accident.triggeringEventMaterial")} field="triggering_event_material" />
            <SttField label={t("accident.injuryContactMode")} field="injury_contact_mode" />
            <SttField label={t("accident.injuryContactMaterial")} field="injury_contact_material" />
            <SttField label={t("accident.personalFactorInjured")} field="personal_factor_injured" />
            <SttField label={t("accident.personalFactorEmployer")} field="personal_factor_employer" />
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              <CodeSelect label={t("accident.safetyGuard")} field="safety_device_guard" codes={SAFETY_DEVICE_OPTIONS} />
              <CodeSelect label={t("accident.safetyProtection")} field="safety_device_protection" codes={SAFETY_DEVICE_OPTIONS} />
              <CodeSelect label={t("accident.safetySignal")} field="safety_device_signal" codes={SAFETY_DEVICE_OPTIONS} />
              <CodeSelect label={t("accident.safetyPpe")} field="safety_device_ppe" codes={SAFETY_DEVICE_OPTIONS} />
              <CodeSelect label={t("accident.safetyOther")} field="safety_device_other" codes={SAFETY_DEVICE_OPTIONS} />
            </div>
          </div>
        );
      case "causes":
        return (
          <div className="space-y-4">
            <SttField label={t("accident.accidentCauses")} field="accident_causes" multiline />
            <SttField label={t("accident.preventionMeasures")} field="prevention_measures" multiline />
            <SttField label={t("accident.attachmentsNotes")} field="attachments_notes" multiline />
          </div>
        );
      case "photos":
        return (
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Button type="button" variant="outline" onClick={() => fileInputRef.current?.click()} disabled={uploading}>
                {uploading ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Camera className="h-4 w-4 mr-1" />}
                {t("accident.addPhoto")}
              </Button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                multiple
                capture="environment"
                className="hidden"
                onChange={e => e.target.files?.length && uploadPhotos(e.target.files)}
              />
              <span className="text-sm text-muted-foreground">{t("accident.photoHint")}</span>
            </div>
            {photoUrls.length > 0 && (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                {photoUrls.map((path) => (
                  <div key={path} className="relative group rounded-lg overflow-hidden border bg-muted aspect-square">
                    {signedUrls[path] ? (
                      <img src={signedUrls[path]} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                      </div>
                    )}
                    <button
                      type="button"
                      onClick={() => removePhoto(path)}
                      className="absolute top-1 right-1 bg-destructive text-destructive-foreground rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      case "investigators":
        return (
          <div className="space-y-6">
            <h3 className="font-medium">{t("accident.safetyRep")}</h3>
            <div className="grid gap-4 md:grid-cols-3">
              <Field label={t("accident.name")} field="safety_rep_name" />
              <Field label={t("accident.date")} field="safety_rep_date" type="date" />
              <CodeSelect label={t("accident.agreement")} field="safety_rep_agreement" codes={SAFETY_REP_AGREEMENT} />
            </div>
            <h3 className="font-medium">{t("accident.investigator")}</h3>
            <div className="grid gap-4 md:grid-cols-3">
              <Field label={t("accident.name")} field="investigator_name" />
              <Field label={t("accident.date")} field="investigator_date" type="date" />
              <Field label={t("accident.certNo")} field="investigator_cert_no" />
            </div>
            <h3 className="font-medium">{t("accident.doctor")}</h3>
            <div className="grid gap-4 md:grid-cols-3">
              <Field label={t("accident.name")} field="doctor_name" />
              <Field label={t("accident.date")} field="doctor_date" type="date" />
              <Field label={t("accident.stampNo")} field="doctor_stamp_no" />
            </div>
            <h3 className="font-medium">{t("accident.employerRep")}</h3>
            <div className="grid gap-4 md:grid-cols-3">
              <Field label={t("accident.name")} field="employer_rep_name" />
              <Field label={t("accident.position")} field="employer_rep_position" />
              <Field label={t("accident.date")} field="employer_rep_date" type="date" />
            </div>
          </div>
        );
    }
  };

  const stepLabels = [
    t("accident.stepEmployer"),
    t("accident.stepInjured"),
    t("accident.stepAccident"),
    t("accident.stepDescription"),
    t("accident.stepAdditional"),
    t("accident.stepCauses"),
    t("accident.stepPhotos"),
    t("accident.stepInvestigators"),
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="h-5 w-5" />
          {t("accident.reportTitle")}
        </CardTitle>
        <div className="flex gap-1 mt-2 flex-wrap">
          {stepLabels.map((label, i) => (
            <button key={i} type="button" onClick={() => setStep(i)}
              className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${i === step ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-accent"}`}
            >{i + 1}. {label}</button>
          ))}
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {renderStep()}
        <div className="flex justify-between pt-4">
          <Button variant="outline" onClick={() => setStep(s => s - 1)} disabled={step === 0}>
            <ChevronLeft className="h-4 w-4 mr-1" />{t("common.back")}
          </Button>
          <div className="flex gap-2">
            <Button variant="secondary" onClick={() => { set("status", "draft"); save.mutate(); }} disabled={save.isPending}>
              <Save className="h-4 w-4 mr-1" />{t("accident.saveDraft")}
            </Button>
            {step === STEPS.length - 1 ? (
              <Button onClick={() => { set("status", "submitted"); save.mutate(); }} disabled={save.isPending}>
                {t("accident.submit")}
              </Button>
            ) : (
              <Button onClick={() => setStep(s => s + 1)}>
                {t("common.next")}<ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
