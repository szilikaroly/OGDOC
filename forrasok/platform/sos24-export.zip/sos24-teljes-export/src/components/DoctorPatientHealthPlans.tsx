import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Loader2, Heart, Search, FileText, Sparkles, Send, Printer, ArrowLeft, Salad, Stethoscope } from "lucide-react";
import ReactMarkdown from "react-markdown";
import { toast } from "sonner";
import { format } from "date-fns";
import { hu } from "date-fns/locale";

export default function DoctorPatientHealthPlans() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const qc = useQueryClient();
  const [selectedPatientId, setSelectedPatientId] = useState<string>("");
  const [patientSearch, setPatientSearch] = useState("");
  const [screeningNotes, setScreeningNotes] = useState("");
  const [screeningResult, setScreeningResult] = useState<string | null>(null);
  const [dietDays, setDietDays] = useState(7);
  const [dietNotes, setDietNotes] = useState("");
  const [dietResult, setDietResult] = useState<string | null>(null);
  const [viewingPlan, setViewingPlan] = useState<any>(null);

  const { data: patients } = useQuery({
    queryKey: ["doctor-patients"],
    queryFn: async () => {
      const { data, error } = await supabase.from("profiles").select("user_id, full_name, birth_date, taj_number").order("full_name");
      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  const filteredPatients = (patients ?? []).filter(
    (p) => p.user_id !== user?.id && (patientSearch === "" || p.full_name?.toLowerCase().includes(patientSearch.toLowerCase()) || p.taj_number?.includes(patientSearch))
  );

  const { data: healthPlans } = useQuery({
    queryKey: ["patient-health-plans", selectedPatientId],
    queryFn: async () => {
      const { data, error } = await supabase.from("health_plans").select("*").eq("user_id", selectedPatientId).order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
    enabled: !!selectedPatientId,
  });

  const { data: sentRecommendations } = useQuery({
    queryKey: ["doctor-recommendations-sent", selectedPatientId, user?.id],
    queryFn: async () => {
      const { data, error } = await supabase.from("doctor_recommendations").select("*").eq("doctor_id", user!.id).eq("patient_id", selectedPatientId).order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
    enabled: !!selectedPatientId && !!user,
  });

  const generatePlan = useMutation({
    mutationFn: async ({ type, notes, duration_days }: { type: string; notes: string; duration_days?: number }) => {
      const { data, error } = await supabase.functions.invoke("ai-doctor-recommendation", { body: { type, patient_id: selectedPatientId, notes, duration_days } });
      if (error) throw error;
      return data;
    },
    onSuccess: (data) => {
      if (data.type === "screening_plan") setScreeningResult(data.plan);
      else setDietResult(data.plan);
      toast.success(t("doctorPlans.planGenerated"));
    },
    onError: () => toast.error(t("doctorPlans.generateError")),
  });

  const sendRecommendation = useMutation({
    mutationFn: async ({ type, plan, title }: { type: string; plan: string; title: string }) => {
      const { error } = await supabase.from("doctor_recommendations").insert({
        doctor_id: user!.id, patient_id: selectedPatientId, type, title, plan_markdown: plan,
        duration_days: type === "diet_plan" ? dietDays : null,
        preferences: { notes: type === "screening_plan" ? screeningNotes : dietNotes },
      });
      if (error) throw error;
      await supabase.functions.invoke("send-notification", {
        body: { type: type === "screening_plan" ? "screening_plan" : "diet_plan", recipient_id: selectedPatientId, sender_id: user!.id, data: { title, link: "/munkavallalo/health-plan" } },
      });
    },
    onSuccess: () => {
      toast.success(t("doctorPlans.sentSuccess"));
      if (screeningResult) setScreeningResult(null);
      if (dietResult) setDietResult(null);
      setScreeningNotes("");
      setDietNotes("");
      qc.invalidateQueries({ queryKey: ["doctor-recommendations-sent"] });
    },
    onError: () => toast.error(t("doctorPlans.sendError")),
  });

  const selectedPatient = patients?.find((p) => p.user_id === selectedPatientId);

  if (viewingPlan) {
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm" onClick={() => setViewingPlan(null)}>
            <ArrowLeft className="h-4 w-4 mr-1" /> {t("common.back")}
          </Button>
          <h2 className="text-lg font-semibold">{viewingPlan.title || t("healthPlan.personalPlan")}</h2>
          <Button variant="outline" size="sm" onClick={() => window.print()} className="ml-auto print:hidden">
            <Printer className="h-4 w-4 mr-1" /> {t("common.print")}
          </Button>
        </div>
        <Badge variant="secondary" className="text-xs print:hidden">
          {format(new Date(viewingPlan.generated_at || viewingPlan.created_at), "yyyy. MMMM d. HH:mm", { locale: hu })}
        </Badge>
        <Card className="print:shadow-none print:border-none">
          <CardContent className="pt-6 prose prose-sm max-w-none dark:prose-invert">
            <ReactMarkdown>{viewingPlan.plan_markdown}</ReactMarkdown>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Heart className="h-6 w-6 text-primary" />
        <h1 className="text-2xl font-bold">{t("doctorPlans.title")}</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">{t("doctorPlans.selectPatient")}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Input placeholder={t("doctorPlans.searchPlaceholder")} value={patientSearch} onChange={(e) => setPatientSearch(e.target.value)} className="max-w-md" />
          {patientSearch && (
            <div className="max-h-48 overflow-y-auto border rounded-md divide-y">
              {filteredPatients.slice(0, 20).map((p) => (
                <button key={p.user_id} className={`w-full text-left px-3 py-2 hover:bg-muted/50 transition-colors flex justify-between items-center ${selectedPatientId === p.user_id ? "bg-primary/10" : ""}`}
                  onClick={() => { setSelectedPatientId(p.user_id); setPatientSearch(""); setScreeningResult(null); setDietResult(null); setViewingPlan(null); }}>
                  <span className="font-medium text-sm">{p.full_name}</span>
                  <span className="text-xs text-muted-foreground">{p.taj_number && `TAJ: ${p.taj_number}`}{p.birth_date && ` • ${p.birth_date}`}</span>
                </button>
              ))}
              {filteredPatients.length === 0 && <p className="px-3 py-2 text-sm text-muted-foreground">{t("doctorPlans.noResults")}</p>}
            </div>
          )}
          {selectedPatient && (
            <div className="flex items-center gap-2 p-2 bg-muted/50 rounded-md">
              <Search className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium">{selectedPatient.full_name}</span>
              {selectedPatient.taj_number && <Badge variant="outline" className="text-xs">TAJ: {selectedPatient.taj_number}</Badge>}
            </div>
          )}
        </CardContent>
      </Card>

      {selectedPatientId && (
        <Tabs defaultValue="plans">
          <TabsList className="w-full justify-start">
            <TabsTrigger value="plans"><FileText className="h-4 w-4 mr-1" /> {t("doctorPlans.healthPlans")}</TabsTrigger>
            <TabsTrigger value="screening"><Stethoscope className="h-4 w-4 mr-1" /> {t("doctorPlans.screeningPlan")}</TabsTrigger>
            <TabsTrigger value="diet"><Salad className="h-4 w-4 mr-1" /> {t("doctorPlans.dietPlan")}</TabsTrigger>
          </TabsList>

          <TabsContent value="plans">
            <div className="space-y-4">
              <Card>
                <CardHeader><CardTitle className="text-base">{t("doctorPlans.patientOwnPlans")}</CardTitle></CardHeader>
                <CardContent>
                  {(healthPlans ?? []).length === 0 ? (
                    <p className="text-sm text-muted-foreground">{t("doctorPlans.noSavedPlan")}</p>
                  ) : (
                    <div className="space-y-2">
                      {healthPlans!.map((hp: any) => (
                        <button key={hp.id} onClick={() => setViewingPlan(hp)} className="w-full flex items-center justify-between p-3 rounded-lg border hover:bg-muted/50 transition-colors text-left">
                          <div className="flex items-center gap-3">
                            <Heart className="h-4 w-4 text-primary" />
                            <div>
                              <p className="text-sm font-medium">{t("healthPlan.planDate", { date: format(new Date(hp.generated_at), "yyyy. MMMM d.", { locale: hu }) })}</p>
                              <p className="text-xs text-muted-foreground">{(hp.preferences as any)?.goals ? `${t("healthPlan.goalPrefix")}${((hp.preferences as any).goals as string).substring(0, 60)}...` : t("healthPlan.generalPlan")}</p>
                            </div>
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader><CardTitle className="text-base">{t("doctorPlans.sentRecommendations")}</CardTitle></CardHeader>
                <CardContent>
                  {(sentRecommendations ?? []).length === 0 ? (
                    <p className="text-sm text-muted-foreground">{t("doctorPlans.noSentRecommendation")}</p>
                  ) : (
                    <div className="space-y-2">
                      {sentRecommendations!.map((rec: any) => (
                        <button key={rec.id} onClick={() => setViewingPlan(rec)} className="w-full flex items-center justify-between p-3 rounded-lg border hover:bg-muted/50 transition-colors text-left">
                          <div className="flex items-center gap-3">
                            {rec.type === "screening_plan" ? <Stethoscope className="h-4 w-4 text-blue-500" /> : <Salad className="h-4 w-4 text-green-500" />}
                            <div>
                              <p className="text-sm font-medium">{rec.title}</p>
                              <p className="text-xs text-muted-foreground">{format(new Date(rec.created_at), "yyyy. MMMM d. HH:mm", { locale: hu })}</p>
                            </div>
                          </div>
                          <Badge variant={rec.is_read ? "secondary" : "default"} className="text-xs">{rec.is_read ? t("doctorPlans.read") : t("doctorPlans.new")}</Badge>
                        </button>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="screening">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2"><Stethoscope className="h-5 w-5 text-blue-500" />{t("doctorPlans.aiScreeningPlan")}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-1.5">
                  <Label>{t("doctorPlans.doctorNote")}</Label>
                  <Textarea placeholder={t("doctorPlans.doctorNotePlaceholder")} value={screeningNotes} onChange={(e) => setScreeningNotes(e.target.value)} rows={3} />
                </div>
                {!screeningResult ? (
                  <Button onClick={() => generatePlan.mutate({ type: "screening_plan", notes: screeningNotes })} disabled={generatePlan.isPending} className="gap-2">
                    {generatePlan.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
                    {t("doctorPlans.generateScreening")}
                  </Button>
                ) : (
                  <div className="space-y-4">
                    <Card className="bg-muted/30"><CardContent className="pt-4 prose prose-sm max-w-none dark:prose-invert"><ReactMarkdown>{screeningResult}</ReactMarkdown></CardContent></Card>
                    <div className="flex gap-2">
                      <Button onClick={() => sendRecommendation.mutate({ type: "screening_plan", plan: screeningResult, title: t("doctorPlans.screeningTitle") })} disabled={sendRecommendation.isPending} className="gap-2">
                        {sendRecommendation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                        {t("doctorPlans.sendToPatient")}
                      </Button>
                      <Button variant="outline" onClick={() => setScreeningResult(null)}>{t("doctorPlans.regenerate")}</Button>
                      <Button variant="outline" onClick={() => window.print()}><Printer className="h-4 w-4 mr-1" /> {t("common.print")}</Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="diet">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2"><Salad className="h-5 w-5 text-green-500" />{t("doctorPlans.aiDietPlan")}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-1.5">
                  <Label>{t("doctorPlans.dietDuration", { days: dietDays })}</Label>
                  <Slider value={[dietDays]} onValueChange={([v]) => setDietDays(v)} min={1} max={30} step={1} />
                  <div className="flex justify-between text-xs text-muted-foreground"><span>1 {t("doctorPlans.dayUnit")}</span><span>30 {t("doctorPlans.daysUnit")}</span></div>
                </div>
                <div className="space-y-1.5">
                  <Label>{t("doctorPlans.specialNeeds")}</Label>
                  <Textarea placeholder={t("doctorPlans.specialNeedsPlaceholder")} value={dietNotes} onChange={(e) => setDietNotes(e.target.value)} rows={3} />
                </div>
                {!dietResult ? (
                  <Button onClick={() => generatePlan.mutate({ type: "diet_plan", notes: dietNotes, duration_days: dietDays })} disabled={generatePlan.isPending} className="gap-2">
                    {generatePlan.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
                    {t("doctorPlans.generateDiet", { days: dietDays })}
                  </Button>
                ) : (
                  <div className="space-y-4">
                    <Card className="bg-muted/30"><CardContent className="pt-4 prose prose-sm max-w-none dark:prose-invert"><ReactMarkdown>{dietResult}</ReactMarkdown></CardContent></Card>
                    <div className="flex gap-2">
                      <Button onClick={() => sendRecommendation.mutate({ type: "diet_plan", plan: dietResult, title: t("doctorPlans.dietTitle", { days: dietDays }) })} disabled={sendRecommendation.isPending} className="gap-2">
                        {sendRecommendation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                        {t("doctorPlans.sendToPatient")}
                      </Button>
                      <Button variant="outline" onClick={() => setDietResult(null)}>{t("doctorPlans.regenerate")}</Button>
                      <Button variant="outline" onClick={() => window.print()}><Printer className="h-4 w-4 mr-1" /> {t("common.print")}</Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}
