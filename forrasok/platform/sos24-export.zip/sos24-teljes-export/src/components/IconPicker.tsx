import { useState } from "react";
import { useTranslation } from "react-i18next";
import { cn } from "@/lib/utils";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  ShieldCheck, Users, Award, Stethoscope, FileCheck, CalendarCheck,
  ClipboardList, HeartPulse, Activity, Syringe, Pill, Thermometer,
  Brain, Eye, Baby, Bone, Heart, Microscope, Scan, Clipboard,
  MapPin, Building2, Phone, Mail, Globe, Search, Settings, Star,
  Clock, AlertCircle, CheckCircle, FileText, Calendar, Home,
  Briefcase, UserCheck, Truck, Shield, Zap, Target, TrendingUp,
  type LucideIcon,
} from "lucide-react";

const ICONS: Record<string, LucideIcon> = {
  ShieldCheck, Users, Award, Stethoscope, FileCheck, CalendarCheck,
  ClipboardList, HeartPulse, Activity, Syringe, Pill, Thermometer,
  Brain, Eye, Baby, Bone, Heart, Microscope, Scan, Clipboard,
  MapPin, Building2, Phone, Mail, Globe, Search, Settings, Star,
  Clock, AlertCircle, CheckCircle, FileText, Calendar, Home,
  Briefcase, UserCheck, Truck, Shield, Zap, Target, TrendingUp,
};

interface IconPickerProps {
  value: string;
  onChange: (name: string) => void;
  label?: string;
}

export default function IconPicker({ value, onChange, label }: IconPickerProps) {
  const { t } = useTranslation();
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");

  const filtered = Object.entries(ICONS).filter(([name]) =>
    name.toLowerCase().includes(search.toLowerCase())
  );

  const SelectedIcon = value ? ICONS[value] : null;

  return (
    <div className="space-y-1.5">
      {label && <Label>{label}</Label>}
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button variant="outline" className="w-full justify-start gap-2 h-10">
            {SelectedIcon ? (
              <>
                <SelectedIcon className="h-4 w-4" />
                <span className="text-sm">{value}</span>
              </>
            ) : (
              <span className="text-muted-foreground text-sm">{t("iconPicker.selectIcon")}</span>
            )}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-72 p-2" align="start">
          <Input
            placeholder={t("iconPicker.searchPlaceholder")}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="mb-2 h-8 text-sm"
          />
          <ScrollArea className="h-48">
            <div className="grid grid-cols-6 gap-1">
              {filtered.map(([name, Icon]) => (
                <button
                  key={name}
                  type="button"
                  title={name}
                  onClick={() => { onChange(name); setOpen(false); }}
                  className={cn(
                    "flex items-center justify-center rounded p-2 hover:bg-accent transition-colors",
                    value === name && "bg-primary/20 ring-1 ring-primary"
                  )}
                >
                  <Icon className="h-4 w-4" />
                </button>
              ))}
            </div>
          </ScrollArea>
          {value && (
            <Button
              variant="ghost"
              size="sm"
              className="w-full mt-1 text-xs"
              onClick={() => { onChange(""); setOpen(false); }}
            >
              {t("iconPicker.removeIcon")}
            </Button>
          )}
        </PopoverContent>
      </Popover>
    </div>
  );
}