import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { FileBadge, Plus, Printer, Eye } from "lucide-react";
import { toast } from "sonner";

const CERT_TYPE_KEYS: Record<string, string> = {
  megjelenes: "certificates.megjelenes",
  special: "certificates.special",
  keresokeptelen: "certificates.keresokeptelen",
};

interface CertForm {
  patient_id: string;
  certificate_type: string;
  certificate_date: string;
  valid_from: string;
  valid_until: string;
  purpose: string;
  notes: string;
}

const emptyCert: CertForm = {
  patient_id: "", certificate_type: "megjelenes",
  certificate_date: new Date().toISOString().split("T")[0],
  valid_from: "", valid_until: "", purpose: "", notes: "",
};

export default function DoctorCertificates() {
  const { t, i18n } = useTranslation();
  const { user } = useAuth();
  const qc = useQueryClient();
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState<CertForm>(emptyCert);
  const [previewCert, setPreviewCert] = useState<any>(null);
  const [search, setSearch] = useState("");

  // Fetch patients
  const { data: patients } = useQuery({
    queryKey: ["all-patients-for-cert"],
    queryFn: async () => {
      const { data, error } = await supabase.from("profiles").select("user_id, full_name, taj_number").order("full_name");
      if (error) throw error;
      return data ?? [];
    },
    enabled: !!user,
  });

  // Fetch certificates
  const { data: certs, isLoading } = useQuery({
    queryKey: ["doctor-certificates", user?.id],
    queryFn: async () => {
      const { data, error } = await (supabase as any).from("certificates")
        .select("*").eq("doctor_id", user!.id).order("created_at", { ascending: false });
      if (error) throw error;
      // Enrich with patient names
      const patientIds = [...new Set((data as any[]).map((c: any) => c.patient_id))];
      if (patientIds.length === 0) return data as any[];
      const { data: profiles } = await supabase.from("profiles").select("user_id, full_name, taj_number").in("user_id", patientIds);
      const nameMap = Object.fromEntries((profiles ?? []).map(p => [p.user_id, p]));
      return (data as any[]).map((c: any) => ({ ...c, patient: nameMap[c.patient_id] }));
    },
    enabled: !!user,
  });

  const createMut = useMutation({
    mutationFn: async () => {
      const { error } = await (supabase as any).from("certificates").insert({
        doctor_id: user!.id,
        patient_id: form.patient_id,
        certificate_type: form.certificate_type,
        certificate_date: form.certificate_date,
        valid_from: form.valid_from || null,
        valid_until: form.valid_until || null,
        purpose: form.purpose || null,
        notes: form.notes || null,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["doctor-certificates"] });
      setShowCreate(false);
      setForm(emptyCert);
      toast.success(t("certificates.created"));
    },
    onError: (e: any) => toast.error(e.message),
  });

  const filteredPatients = (patients ?? []).filter(p =>
    !search || p.full_name.toLowerCase().includes(search.toLowerCase()) || (p.taj_number ?? "").includes(search)
  );

  const handlePrint = (cert: any) => {
    setPreviewCert(cert);
  };

  const doPrint = () => {
    window.print();
  };

  const selectedPatient = (patients ?? []).find(p => p.user_id === form.patient_id);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <FileBadge className="h-6 w-6 text-secondary" />
          <h1 className="text-2xl font-bold">{t("certificates.title")}</h1>
        </div>
        <Button onClick={() => { setForm(emptyCert); setShowCreate(true); }}>
          <Plus className="h-4 w-4 mr-1" /> {t("certificates.new")}
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">{t("certificates.issued")} ({certs?.length ?? 0})</CardTitle>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t("inner.patient")}</TableHead>
                <TableHead>{t("inner.type")}</TableHead>
                <TableHead>{t("inner.date")}</TableHead>
                <TableHead>{t("certificates.goalNote")}</TableHead>
                <TableHead className="w-20">{t("inner.action")}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {(certs ?? []).map((c: any) => (
                <TableRow key={c.id}>
                  <TableCell className="font-medium">{c.patient?.full_name ?? "—"}</TableCell>
                  <TableCell>
                    <Badge variant="outline">{t(CERT_TYPE_KEYS[c.certificate_type] ?? "certificates.title")}</Badge>
                  </TableCell>
                  <TableCell>{new Date(c.certificate_date).toLocaleDateString("hu-HU")}</TableCell>
                  <TableCell className="max-w-[200px] truncate">{c.purpose || c.notes || "—"}</TableCell>
                  <TableCell>
                    <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => handlePrint(c)}>
                      <Eye className="h-3.5 w-3.5" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
              {(certs ?? []).length === 0 && (
                <TableRow><TableCell colSpan={5} className="text-center text-muted-foreground py-8">{t("certificates.noCertificates")}</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Create dialog */}
      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{t("certificates.newTitle")}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-2">
            <div className="space-y-2">
              <Label>{t("certificates.searchPatient")}</Label>
              <Input value={search} onChange={e => setSearch(e.target.value)} placeholder={t("certificates.searchPlaceholder")} />
              {search && filteredPatients.length > 0 && !form.patient_id && (
                <div className="border rounded-md max-h-40 overflow-y-auto">
                  {filteredPatients.slice(0, 10).map(p => (
                    <button key={p.user_id} className="w-full text-left px-3 py-2 hover:bg-muted text-sm"
                      onClick={() => { setForm(f => ({ ...f, patient_id: p.user_id })); setSearch(""); }}>
                      {p.full_name} {p.taj_number ? `(${p.taj_number})` : ""}
                    </button>
                  ))}
                </div>
              )}
              {selectedPatient && (
                <div className="flex items-center gap-2">
                  <Badge>{selectedPatient.full_name}</Badge>
                  <Button variant="ghost" size="sm" onClick={() => setForm(f => ({ ...f, patient_id: "" }))}>×</Button>
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label>{t("certificates.certType")}</Label>
              <Select value={form.certificate_type} onValueChange={v => setForm(f => ({ ...f, certificate_type: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {["megjelenes", "special", "keresokeptelen"].map(ct => <SelectItem key={ct} value={ct}>{t(CERT_TYPE_KEYS[ct])}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-xs">{t("certificates.issueDate")}</Label>
                <Input type="date" value={form.certificate_date} onChange={e => setForm(f => ({ ...f, certificate_date: e.target.value }))} />
              </div>
              {form.certificate_type === "keresokeptelen" && (
                <>
                  <div className="space-y-1">
                    <Label className="text-xs">{t("certificates.validFrom")}</Label>
                    <Input type="date" value={form.valid_from} onChange={e => setForm(f => ({ ...f, valid_from: e.target.value }))} />
                  </div>
                  <div className="space-y-1 col-span-2 sm:col-span-1">
                    <Label className="text-xs">{t("certificates.validUntil")}</Label>
                    <Input type="date" value={form.valid_until} onChange={e => setForm(f => ({ ...f, valid_until: e.target.value }))} />
                  </div>
                </>
              )}
            </div>

            <div className="space-y-1">
              <Label className="text-xs">{t("certificates.purpose")}</Label>
              <Input value={form.purpose} onChange={e => setForm(f => ({ ...f, purpose: e.target.value }))} placeholder={t("certificates.purposePlaceholder")} />
            </div>

            <div className="space-y-1">
              <Label className="text-xs">{t("certificates.notes")}</Label>
              <Textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} rows={3} />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setShowCreate(false)}>{t("common.cancel")}</Button>
              <Button onClick={() => createMut.mutate()} disabled={createMut.isPending || !form.patient_id}>
                {t("certificates.issue")}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Print preview dialog */}
      <Dialog open={!!previewCert} onOpenChange={(open) => !open && setPreviewCert(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between">
              <span>{t("certificates.preview")}</span>
              <Button size="sm" variant="outline" onClick={doPrint}>
                <Printer className="h-4 w-4 mr-1" /> {t("certificates.print")}
              </Button>
            </DialogTitle>
          </DialogHeader>
          {previewCert && (
            <div className="print-area space-y-4 p-6 border rounded-md bg-white text-black">
              <div className="text-center space-y-1">
                <h2 className="text-xl font-bold uppercase">
                  {t(CERT_TYPE_KEYS[previewCert.certificate_type] ?? "certificates.title")}
                </h2>
                <p className="text-sm text-gray-600">
                  {t("certificates.issueDate")}: {new Date(previewCert.certificate_date).toLocaleDateString(i18n.language === "hu" ? "hu-HU" : undefined)}
                </p>
              </div>
              <Separator />
              <div className="space-y-2 text-sm">
                <p><strong>{t("certificates.patientName")}:</strong> {previewCert.patient?.full_name ?? "—"}</p>
                <p><strong>{t("certificates.tajNumber")}:</strong> {previewCert.patient?.taj_number ?? "—"}</p>
                {previewCert.purpose && <p><strong>{t("certificates.purposeLabel")}:</strong> {previewCert.purpose}</p>}
                {previewCert.certificate_type === "keresokeptelen" && previewCert.valid_from && (
                  <p><strong>{t("certificates.valid")}:</strong> {new Date(previewCert.valid_from).toLocaleDateString(i18n.language === "hu" ? "hu-HU" : undefined)} – {previewCert.valid_until ? new Date(previewCert.valid_until).toLocaleDateString(i18n.language === "hu" ? "hu-HU" : undefined) : t("certificates.untilRevoked")}</p>
                )}
                {previewCert.notes && (
                  <>
                    <Separator />
                    <p>{previewCert.notes}</p>
                  </>
                )}
              </div>
              <div className="pt-8 flex justify-between text-sm">
                <div className="text-center">
                  <div className="border-t border-black w-40 mx-auto" />
                  <p className="mt-1">{t("certificates.doctorSignature")}</p>
                </div>
                <div className="text-center">
                  <div className="border-t border-black w-40 mx-auto" />
                  <p className="mt-1">{t("certificates.stamp")}</p>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
