import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Calendar, Plus } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import AddToCalendarButton from "@/components/AddToCalendarButton";

export default function PraxistagAppointments() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedSlot, setSelectedSlot] = useState("");
  const [notes, setNotes] = useState("");

  const STATUS_LABELS: Record<string, string> = {
    pending: t("inner.pending"), confirmed: t("inner.confirmed"), cancelled: t("inner.cancelled"), completed: t("inner.completedStatus"), no_show: t("inner.noShow"),
  };

  const { data: appointments, isLoading } = useQuery({
    queryKey: ["praxistag-appointments", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("appointments")
        .select("*, appointment_slots(slot_start, slot_end, location_id, service_id), services(name)")
        .eq("patient_id", user!.id)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  const { data: slots } = useQuery({
    queryKey: ["available-slots-praxistag"],
    queryFn: async () => {
      const { data: rawSlots, error } = await supabase
        .from("appointment_slots")
        .select("id, slot_start, slot_end, capacity, service_id, location_id, doctor_id")
        .eq("is_active", true)
        .gte("slot_start", new Date().toISOString())
        .order("slot_start");
      if (error) throw error;
      if (!rawSlots?.length) return [];

      const slotIds = rawSlots.map((s) => s.id);
      const { data: bookings } = await supabase
        .from("appointments")
        .select("slot_id")
        .in("slot_id", slotIds)
        .neq("status", "cancelled");

      const bookingCounts: Record<string, number> = {};
      (bookings ?? []).forEach((b) => {
        bookingCounts[b.slot_id!] = (bookingCounts[b.slot_id!] ?? 0) + 1;
      });

      const serviceIds = [...new Set(rawSlots.map((s) => s.service_id).filter(Boolean))] as string[];
      const { data: services } = serviceIds.length
        ? await supabase.from("services").select("id, name").in("id", serviceIds)
        : { data: [] };

      const locationIds = [...new Set(rawSlots.map((s) => s.location_id).filter(Boolean))] as string[];
      const { data: locations } = locationIds.length
        ? await supabase.from("locations").select("id, name").in("id", locationIds)
        : { data: [] };

      const doctorIds = [...new Set(rawSlots.map((s) => s.doctor_id).filter(Boolean))] as string[];
      const { data: doctors } = doctorIds.length
        ? await supabase.from("profiles").select("user_id, full_name").in("user_id", doctorIds)
        : { data: [] };

      return rawSlots.map((s) => ({
        ...s,
        booked: bookingCounts[s.id] ?? 0,
        isFull: (bookingCounts[s.id] ?? 0) >= s.capacity,
        serviceName: (services ?? []).find((sv) => sv.id === s.service_id)?.name,
        locationName: (locations ?? []).find((l) => l.id === s.location_id)?.name,
        doctorName: (doctors ?? []).find((d) => d.user_id === s.doctor_id)?.full_name,
      }));
    },
  });

  const book = useMutation({
    mutationFn: async () => {
      const slot = (slots ?? []).find((s) => s.id === selectedSlot);
      if (!slot) throw new Error(t("inner.slotNotFound"));
      if (slot.isFull) throw new Error(t("inner.slotFull"));

      const { count } = await supabase.from("appointments").select("id", { count: "exact", head: true }).eq("slot_id", selectedSlot).neq("status", "cancelled");
      if ((count ?? 0) >= slot.capacity) throw new Error(t("inner.slotFull"));

      const { error } = await supabase.from("appointments").insert({
        patient_id: user!.id,
        slot_id: selectedSlot,
        doctor_id: slot.doctor_id,
        service_id: slot.service_id,
        notes: notes || null,
      });
      if (error) throw error;

      if (slot.doctor_id) {
        await supabase.functions.invoke("send-notification", {
          body: {
            type: "appointment_confirmed",
            recipient_id: slot.doctor_id,
            sender_id: user!.id,
            data: {
              date: new Date(slot.slot_start).toLocaleString("hu-HU"),
              service: slot.serviceName || "",
            },
          },
        });
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["praxistag-appointments"] });
      qc.invalidateQueries({ queryKey: ["available-slots-praxistag"] });
      toast({ title: t("inner.appointmentBooked") });
      setDialogOpen(false);
      setSelectedSlot("");
      setNotes("");
    },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  if (isLoading) return <div className="flex items-center justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>;

  const availableSlots = (slots ?? []).filter((s) => !s.isFull);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3"><Calendar className="h-6 w-6 text-secondary" /><h1 className="text-2xl font-bold">{t("inner.myAppointments")}</h1></div>
        <Button onClick={() => setDialogOpen(true)}><Plus className="h-4 w-4 mr-2" />{t("inner.newBooking")}</Button>
      </div>
      <Card>
        <CardHeader><CardTitle className="text-lg">{t("inner.myBookings")} ({appointments?.length ?? 0})</CardTitle></CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader><TableRow><TableHead>{t("common.status")}</TableHead><TableHead>{t("inner.notes")}</TableHead><TableHead>{t("inner.date")}</TableHead><TableHead></TableHead></TableRow></TableHeader>
            <TableBody>
              {(appointments ?? []).map((a) => {
                const slot = (a as any).appointment_slots;
                const serviceName = (a as any).services?.name;
                return (
                  <TableRow key={a.id}>
                    <TableCell><Badge variant={a.status === "confirmed" ? "default" : a.status === "cancelled" ? "destructive" : "secondary"}>{STATUS_LABELS[a.status] ?? a.status}</Badge></TableCell>
                    <TableCell>{a.notes || "—"}</TableCell>
                    <TableCell>{slot ? new Date(slot.slot_start).toLocaleString("hu-HU") : new Date(a.created_at).toLocaleDateString("hu-HU")}</TableCell>
                    <TableCell>
                      {slot && a.status !== "cancelled" && (
                        <AddToCalendarButton
                          title={serviceName || t("inner.appointment")}
                          startDate={new Date(slot.slot_start)}
                          endDate={new Date(slot.slot_end)}
                          description={a.notes || undefined}
                        />
                      )}
                    </TableCell>
                  </TableRow>
                );
              })}
              {(appointments ?? []).length === 0 && <TableRow><TableCell colSpan={4} className="text-center text-muted-foreground py-8">{t("inner.noAppointment")}</TableCell></TableRow>}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{t("inner.bookAppointment")}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label>{t("inner.appointmentSlot")} ({availableSlots.length} {t("inner.available")})</Label>
              <Select value={selectedSlot} onValueChange={setSelectedSlot}>
                <SelectTrigger><SelectValue placeholder={t("inner.selectSlot")} /></SelectTrigger>
                <SelectContent>
                  {availableSlots.map((s) => (
                    <SelectItem key={s.id} value={s.id}>
                      {new Date(s.slot_start).toLocaleString("hu-HU")} — {new Date(s.slot_end).toLocaleTimeString("hu-HU")}
                      {s.doctorName ? ` | Dr. ${s.doctorName}` : ""}
                      {s.serviceName ? ` | ${s.serviceName}` : ""}
                      {s.locationName ? ` | ${s.locationName}` : ""}
                      {` (${s.capacity - s.booked} ${t("inner.places")})`}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label>{t("inner.optionalNote")}</Label><Textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} /></div>
            <Button className="w-full" onClick={() => book.mutate()} disabled={book.isPending || !selectedSlot}>{t("inner.book")}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
