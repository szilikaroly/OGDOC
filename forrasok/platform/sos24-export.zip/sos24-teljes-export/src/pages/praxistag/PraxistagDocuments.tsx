import { useState, useRef } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import {
  FileText, Upload, Download, Eye, Sparkles, Loader2, AlertTriangle, ClipboardCheck,
  Calendar, Stethoscope, Filter,
} from "lucide-react";

interface AiAnalysis {
  summary?: string;
  patient_card_updates?: Record<string, string>;
  has_abnormality?: boolean;
  abnormality_details?: string;
  recommended_specialty?: string;
  recommended_action?: string;
  urgency?: string;
}

export default function PraxistagDocuments() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const fileRef = useRef<HTMLInputElement>(null);
  const [uploadOpen, setUploadOpen] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [filterTag, setFilterTag] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = useState<AiAnalysis | null>(null);
  const [analyzing, setAnalyzing] = useState(false);

  const RESULT_LABELS: Record<string, { label: string; variant: "default" | "destructive" | "secondary" }> = {
    alkalmas: { label: t("inner.fit"), variant: "default" },
    nem_alkalmas: { label: t("inner.unfit"), variant: "destructive" },
    feltetelesen_alkalmas: { label: t("inner.conditionallyFit"), variant: "secondary" },
    ideiglenes: { label: t("inner.temporary"), variant: "secondary" },
  };

  const { data: tags } = useQuery({
    queryKey: ["document-tags"],
    queryFn: async () => {
      const { data, error } = await supabase.from("document_tags").select("id, label").eq("is_active", true).order("sort_order");
      if (error) throw error;
      return data;
    },
  });

  const { data: documents, isLoading } = useQuery({
    queryKey: ["praxistag-docs", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase.from("documents").select("*").eq("user_id", user!.id).order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  const { data: examinations } = useQuery({
    queryKey: ["praxistag-examinations", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("examinations")
        .select("id, exam_type, result, restrictions, valid_until, created_at, doctor_id, workflow_status")
        .eq("patient_id", user!.id)
        .order("created_at", { ascending: false });
      if (error) throw error;
      if (data.length === 0) return [];
      const doctorIds = [...new Set(data.map((e) => e.doctor_id))];
      const { data: profiles } = await supabase.from("profiles").select("user_id, full_name").in("user_id", doctorIds);
      return data.map((e) => ({
        ...e,
        doctor_name: profiles?.find((p) => p.user_id === e.doctor_id)?.full_name ?? "—",
      }));
    },
    enabled: !!user,
  });

  const uploadDoc = useMutation({
    mutationFn: async () => {
      if (!selectedFile || !user) throw new Error(t("inner.noFileSelected"));
      const filePath = `${user.id}/${Date.now()}_${selectedFile.name}`;
      const { error: storageErr } = await supabase.storage.from("medical-documents").upload(filePath, selectedFile);
      if (storageErr) throw storageErr;
      const { data: docData, error: docErr } = await supabase
        .from("documents")
        .insert({ user_id: user.id, created_by: user.id, document_type: "upload", file_name: selectedFile.name, file_path: filePath, file_size: selectedFile.size, mime_type: selectedFile.type || "application/octet-stream", tags: selectedTags } as any)
        .select("id").single();
      if (docErr) throw docErr;
      return docData.id;
    },
    onSuccess: async (docId) => {
      qc.invalidateQueries({ queryKey: ["praxistag-docs"] });
      toast({ title: t("inner.documentUploaded") });
      setAnalyzing(true);
      try {
        const { data, error } = await supabase.functions.invoke("ai-document-analysis", {
          body: { document_id: docId, file_name: selectedFile!.name, tags: selectedTags, document_type: selectedTags[0] || "upload" },
        });
        if (!error && data) { setAnalysisResult(data); qc.invalidateQueries({ queryKey: ["praxistag-docs"] }); }
      } catch { /* silent */ }
      setAnalyzing(false);
    },
    onError: (e: any) => toast({ variant: "destructive", title: t("inner.uploadError"), description: e.message }),
  });

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => { setSelectedFile(e.target.files?.[0] ?? null); setAnalysisResult(null); };
  const toggleTag = (tag: string) => { setSelectedTags((prev) => prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]); };

  const handleView = async (doc: any) => {
    try { const { data, error } = await supabase.storage.from("medical-documents").download(doc.file_path); if (error) throw error; window.open(URL.createObjectURL(data), "_blank"); }
    catch (e: any) { toast({ variant: "destructive", title: t("common.error"), description: e.message }); }
  };

  const handleDownload = async (doc: any) => {
    try { const { data, error } = await supabase.storage.from("medical-documents").download(doc.file_path); if (error) throw error; const a = document.createElement("a"); a.href = URL.createObjectURL(data); a.download = doc.file_name; a.click(); }
    catch (e: any) { toast({ variant: "destructive", title: t("common.error"), description: e.message }); }
  };

  const filteredDocs = filterTag ? (documents ?? []).filter((d: any) => d.tags?.includes(filterTag)) : (documents ?? []);

  if (isLoading) return <div className="flex justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3"><FileText className="h-6 w-6 text-secondary" /><h1 className="text-2xl font-bold">{t("inner.documents")}</h1></div>
        <Dialog open={uploadOpen} onOpenChange={(v) => { setUploadOpen(v); if (!v) { setSelectedFile(null); setSelectedTags([]); setAnalysisResult(null); } }}>
          <DialogTrigger asChild><Button><Upload className="h-4 w-4 mr-1" /> {t("inner.documentUpload")}</Button></DialogTrigger>
          <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
            <DialogHeader><DialogTitle>{t("inner.documentUpload")}</DialogTitle></DialogHeader>
            <div className="space-y-4">
              <div><Label>{t("inner.selectFile")}</Label><Input ref={fileRef} type="file" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx" onChange={handleFileSelect} /></div>
              <div>
                <Label>{t("inner.documentTypeMulti")}</Label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {(tags ?? []).map((tg) => (
                    <Badge key={tg.id} variant={selectedTags.includes(tg.label) ? "default" : "outline"} className="cursor-pointer hover:bg-secondary/20 transition-colors" onClick={() => toggleTag(tg.label)}>{tg.label}</Badge>
                  ))}
                </div>
              </div>
              <Button className="w-full" onClick={() => uploadDoc.mutate()} disabled={!selectedFile || uploadDoc.isPending || analyzing}>
                {(uploadDoc.isPending || analyzing) ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Upload className="h-4 w-4 mr-1" />}
                {analyzing ? t("inner.aiAnalyzing") : uploadDoc.isPending ? t("inner.uploading") : t("inner.uploadAndAnalyze")}
              </Button>
              {analysisResult && (
                <Card className="border-secondary/30">
                  <CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><Sparkles className="h-4 w-4 text-secondary" /> {t("inner.aiAnalysisResult")}</CardTitle></CardHeader>
                  <CardContent className="space-y-3 text-sm">
                    <p>{analysisResult.summary}</p>
                    {analysisResult.patient_card_updates && Object.keys(analysisResult.patient_card_updates).length > 0 && (
                      <div className="p-2 rounded bg-secondary/10">
                        <p className="font-medium text-xs mb-1">{t("inner.patientCardUpdated")}:</p>
                        {Object.entries(analysisResult.patient_card_updates).map(([k, v]) => (<p key={k} className="text-xs text-muted-foreground">• {k}: {v}</p>))}
                      </div>
                    )}
                    {analysisResult.has_abnormality && (
                      <div className="p-3 rounded-md bg-destructive/10 space-y-2">
                        <div className="flex items-start gap-2">
                          <AlertTriangle className="h-4 w-4 mt-0.5 text-destructive shrink-0" />
                          <div>
                            <p className="font-medium text-destructive">{analysisResult.abnormality_details}</p>
                            {analysisResult.recommended_specialty && (<div className="flex items-center gap-2 mt-2"><Stethoscope className="h-3 w-3" /><span>{t("inner.suggested")}: <strong>{analysisResult.recommended_specialty}</strong></span></div>)}
                            {analysisResult.recommended_action && <p className="text-xs mt-1">{analysisResult.recommended_action}</p>}
                          </div>
                        </div>
                        <Button size="sm" variant="outline" className="w-full" onClick={() => { setUploadOpen(false); window.location.href = "/praxistag/referral-request"; }}>
                          <Calendar className="h-3 w-3 mr-1" /> {t("inner.startReferral")}
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex items-center gap-2 flex-wrap">
        <Filter className="h-4 w-4 text-muted-foreground" />
        <Badge variant={filterTag === null ? "default" : "outline"} className="cursor-pointer" onClick={() => setFilterTag(null)}>{t("inner.all")}</Badge>
        {(tags ?? []).map((tg) => (<Badge key={tg.id} variant={filterTag === tg.label ? "default" : "outline"} className="cursor-pointer" onClick={() => setFilterTag(filterTag === tg.label ? null : tg.label)}>{tg.label}</Badge>))}
      </div>

      {examinations && examinations.length > 0 && (
        <Card>
          <CardHeader><CardTitle className="text-lg flex items-center gap-2"><ClipboardCheck className="h-5 w-5" /> {t("inner.examResults")} ({examinations.length})</CardTitle></CardHeader>
          <CardContent className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow><TableHead>{t("inner.examination")}</TableHead><TableHead>{t("inner.result")}</TableHead><TableHead>{t("inner.doctor")}</TableHead><TableHead>{t("inner.validUntil")}</TableHead><TableHead>{t("inner.restrictions")}</TableHead><TableHead>{t("inner.date")}</TableHead></TableRow></TableHeader>
              <TableBody>
                {examinations.map((e) => {
                  const r = RESULT_LABELS[e.result] ?? { label: e.result, variant: "secondary" as const };
                  return (
                    <TableRow key={e.id}>
                      <TableCell className="font-medium">{e.exam_type}</TableCell>
                      <TableCell><Badge variant={r.variant}>{r.label}</Badge></TableCell>
                      <TableCell>{e.doctor_name}</TableCell>
                      <TableCell>{e.valid_until ? new Date(e.valid_until).toLocaleDateString("hu-HU") : "—"}</TableCell>
                      <TableCell className="max-w-[200px] truncate text-muted-foreground">{e.restrictions || "—"}</TableCell>
                      <TableCell>{new Date(e.created_at).toLocaleDateString("hu-HU")}</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">{t("inner.documents")} ({filteredDocs.length})</CardTitle>
          {filterTag && <CardDescription>{t("inner.filterBy")}: {filterTag}</CardDescription>}
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader><TableRow><TableHead>{t("inner.fileName")}</TableHead><TableHead>{t("inner.type")}</TableHead><TableHead>AI</TableHead><TableHead>{t("inner.date")}</TableHead><TableHead>{t("inner.action")}</TableHead></TableRow></TableHeader>
            <TableBody>
              {filteredDocs.map((doc: any) => {
                const ai = doc.ai_analysis as AiAnalysis | null;
                return (
                  <TableRow key={doc.id}>
                    <TableCell className="font-medium max-w-[200px] truncate">{doc.file_name}</TableCell>
                    <TableCell><div className="flex flex-wrap gap-1">{doc.tags?.length > 0 ? doc.tags.map((tg: string) => <Badge key={tg} variant="secondary" className="text-xs">{tg}</Badge>) : <Badge variant="outline" className="text-xs">{doc.document_type}</Badge>}</div></TableCell>
                    <TableCell>{ai?.has_abnormality ? (<Badge variant="destructive" className="text-xs"><AlertTriangle className="h-3 w-3 mr-1" />{t("inner.deviation")}</Badge>) : ai ? (<Badge variant="outline" className="text-xs"><Sparkles className="h-3 w-3 mr-1" />OK</Badge>) : null}</TableCell>
                    <TableCell>{new Date(doc.created_at).toLocaleDateString("hu-HU")}</TableCell>
                    <TableCell className="space-x-1">
                      <Button size="sm" variant="outline" onClick={() => handleView(doc)}><Eye className="h-4 w-4" /></Button>
                      <Button size="sm" variant="ghost" onClick={() => handleDownload(doc)}><Download className="h-4 w-4" /></Button>
                    </TableCell>
                  </TableRow>
                );
              })}
              {filteredDocs.length === 0 && (<TableRow><TableCell colSpan={5} className="text-center text-muted-foreground py-8">{t("inner.noDocument")}{filterTag ? ` (${filterTag})` : ""}</TableCell></TableRow>)}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
