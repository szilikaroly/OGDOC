import { useTranslation } from "react-i18next";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/contexts/AuthContext";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Calendar, HeartPulse, MessageSquare } from "lucide-react";
import { LineChart, Line, ResponsiveContainer, XAxis, YAxis, Tooltip, Legend } from "recharts";

export default function PraxistagDashboard() {
  const { t } = useTranslation();
  const { profile, user } = useAuth();

  const { data: nextAppointment } = useQuery({
    queryKey: ["praxistag-next-appointment"],
    queryFn: async () => {
      const { data } = await supabase.from("appointments").select("created_at").eq("patient_id", user!.id).in("status", ["pending", "confirmed"]).order("created_at", { ascending: true }).limit(1);
      if (data?.length) return new Date(data[0].created_at).toLocaleDateString();
      return t("page.none");
    },
    enabled: !!user,
  });

  const { data: healthCount } = useQuery({
    queryKey: ["praxistag-health-count"],
    queryFn: async () => {
      const { count } = await supabase.from("health_reports").select("id", { count: "exact", head: true }).eq("user_id", user!.id);
      return count ?? 0;
    },
    enabled: !!user,
  });

  const { data: unreadMessages } = useQuery({
    queryKey: ["praxistag-unread-messages"],
    queryFn: async () => {
      const { count } = await supabase.from("messages").select("id", { count: "exact", head: true }).eq("recipient_id", user!.id).eq("is_read", false);
      return count ?? 0;
    },
    enabled: !!user,
  });

  const { data: healthTrend } = useQuery({
    queryKey: ["praxistag-health-trend"],
    queryFn: async () => {
      const { data } = await supabase.from("health_reports").select("report_date, blood_pressure_systolic, blood_pressure_diastolic, heart_rate").eq("user_id", user!.id).order("report_date", { ascending: true }).limit(10);
      return (data ?? []).map((r) => ({
        [t("page.date")]: r.report_date,
        [t("page.systolic")]: r.blood_pressure_systolic,
        [t("page.diastolic")]: r.blood_pressure_diastolic,
        [t("page.pulse")]: r.heart_rate,
      }));
    },
    enabled: !!user,
  });

  const { data: recentMessages } = useQuery({
    queryKey: ["praxistag-recent-messages"],
    queryFn: async () => {
      const { data } = await supabase.from("messages").select("id, subject, sender_id, created_at").eq("recipient_id", user!.id).order("created_at", { ascending: false }).limit(3);
      if (!data?.length) return [];
      const senderIds = [...new Set(data.map((m) => m.sender_id))];
      const { data: profiles } = await supabase.from("profiles").select("user_id, full_name").in("user_id", senderIds);
      const nameMap = Object.fromEntries(profiles?.map((p) => [p.user_id, p.full_name]) ?? []);
      return data.map((m) => ({ ...m, senderName: nameMap[m.sender_id] || "—" }));
    },
    enabled: !!user,
  });

  const stats = [
    { label: t("page.nextAppointment"), icon: Calendar, value: nextAppointment ?? "—" },
    { label: t("page.healthData"), icon: HeartPulse, value: healthCount ?? "—" },
    { label: t("page.unreadMessages"), icon: MessageSquare, value: unreadMessages ?? "—" },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">{t("page.welcomeUser", { name: profile?.full_name })}</h1>
        <p className="text-muted-foreground">{t("page.praxisOverview")}</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        {stats.map((s) => (
          <Card key={s.label} className="card-luxury">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">{s.label}</CardTitle>
              <s.icon className="h-5 w-5 text-secondary" />
            </CardHeader>
            <CardContent><p className="text-2xl font-bold">{s.value}</p></CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">{t("page.healthTrend")}</CardTitle></CardHeader>
        <CardContent>
          {healthTrend?.length ? (
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={healthTrend}>
                <XAxis dataKey={t("page.date")} tick={{ fontSize: 11 }} />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey={t("page.systolic")} stroke="hsl(var(--chart-1))" strokeWidth={2} dot={{ r: 3 }} />
                <Line type="monotone" dataKey={t("page.diastolic")} stroke="hsl(var(--chart-2))" strokeWidth={2} dot={{ r: 3 }} />
                <Line type="monotone" dataKey={t("page.pulse")} stroke="hsl(var(--chart-3))" strokeWidth={2} dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          ) : <p className="text-muted-foreground text-sm">{t("page.noMeasurementData")}</p>}
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">{t("page.recentMessages")}</CardTitle></CardHeader>
        <CardContent>
          {recentMessages?.length ? (
            <div className="space-y-3">
              {recentMessages.map((m) => (
                <div key={m.id} className="flex items-center justify-between border-b border-border pb-2 last:border-0">
                  <div>
                    <p className="font-medium text-sm">{m.subject || t("page.noSubject")}</p>
                    <p className="text-xs text-muted-foreground">{m.senderName}</p>
                  </div>
                  <p className="text-xs text-muted-foreground">{new Date(m.created_at).toLocaleDateString()}</p>
                </div>
              ))}
            </div>
          ) : <p className="text-muted-foreground text-sm">{t("page.noMessage")}</p>}
        </CardContent>
      </Card>
    </div>
  );
}
