import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useMutation } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Stethoscope, Sparkles, Send, Loader2, AlertTriangle, CheckCircle2 } from "lucide-react";

const SPECIALTIES = [
  "Belgyógyászat", "Ortopédia", "Bőrgyógyászat", "Szemészet",
  "Fül-orr-gégészet", "Neurológia", "Urológia", "Nőgyógyászat",
  "Kardiológia", "Gasztroenterológia", "Reumatológia", "Pszichiátria",
  "Sebészet", "Tüdőgyógyászat", "Endokrinológia", "Allergológia",
  "Onkológia", "Nefrológia", "Hematológia", "Fizikoterápia",
  "Fogászat", "Radiológia",
];

interface TriageResult {
  summary: string;
  suggested_specialty: string;
  urgency: string;
  followup_questions: string[];
  reasoning: string;
}

export default function PraxistagReferralRequest() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [symptoms, setSymptoms] = useState("");
  const [specialtySearch, setSpecialtySearch] = useState("");
  const [selectedSpecialty, setSelectedSpecialty] = useState("");
  const [triage, setTriage] = useState<TriageResult | null>(null);
  const [followupAnswers, setFollowupAnswers] = useState<string[]>([]);
  const [sent, setSent] = useState(false);

  const filteredSpecialties = SPECIALTIES.filter((s) => s.toLowerCase().includes(specialtySearch.toLowerCase()));

  const aiTriage = useMutation({
    mutationFn: async () => {
      const { data: profile } = await supabase.from("profiles").select("birth_date, gender").eq("user_id", user!.id).single();
      let age: number | undefined;
      if (profile?.birth_date) { age = Math.floor((Date.now() - new Date(profile.birth_date).getTime()) / (365.25 * 24 * 60 * 60 * 1000)); }
      const { data, error } = await supabase.functions.invoke("ai-triage", { body: { symptoms, age, gender: profile?.gender } });
      if (error) throw new Error(error.message);
      return data as TriageResult;
    },
    onSuccess: (data) => {
      setTriage(data);
      setFollowupAnswers(new Array(data.followup_questions?.length ?? 0).fill(""));
      if (data.suggested_specialty && !selectedSpecialty) setSelectedSpecialty(data.suggested_specialty);
    },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  const submitRequest = useMutation({
    mutationFn: async () => {
      const description = [
        `${t("inner.complaint")}: ${symptoms}`,
        triage?.summary ? `\nAI: ${triage.summary}` : "",
        triage?.reasoning ? `AI: ${triage.reasoning}` : "",
        followupAnswers.some((a) => a.trim())
          ? `\n${t("inner.followupQuestions")}:\n${triage?.followup_questions?.map((q, i) => `- ${q}: ${followupAnswers[i] || "—"}`).join("\n")}`
          : "",
      ].join("\n");
      const { error } = await supabase.from("requests").insert({
        requester_id: user!.id, type: "beutalo_keres",
        subject: `${t("inner.referralRequest")}: ${selectedSpecialty || "—"}`, description,
      });
      if (error) throw error;
    },
    onSuccess: () => { toast({ title: t("inner.requestSent"), description: t("inner.requestSentDesc") }); setSent(true); },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  const urgencyColor: Record<string, string> = {
    alacsony: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
    közepes: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
    magas: "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200",
    azonnali: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
  };

  if (sent) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-3"><Stethoscope className="h-6 w-6 text-secondary" /><h1 className="text-2xl font-bold">{t("inner.referralRequest")}</h1></div>
        <Card>
          <CardContent className="py-12 text-center space-y-4">
            <CheckCircle2 className="h-12 w-12 mx-auto text-green-500" />
            <h2 className="text-xl font-semibold">{t("inner.requestSent")}</h2>
            <p className="text-muted-foreground">{t("inner.requestSentDesc")}</p>
            <Button variant="outline" onClick={() => { setSent(false); setSymptoms(""); setTriage(null); setSelectedSpecialty(""); }}>{t("inner.newRequest")}</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3"><Stethoscope className="h-6 w-6 text-secondary" /><h1 className="text-2xl font-bold">{t("inner.referralRequest")}</h1></div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">1. {t("inner.describeSymptoms")}</CardTitle>
          <CardDescription>{t("inner.describeInDetail")}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea value={symptoms} onChange={(e) => setSymptoms(e.target.value)} placeholder={t("inner.symptomsPlaceholder")} rows={4} />
          <Button onClick={() => aiTriage.mutate()} disabled={symptoms.trim().length < 10 || aiTriage.isPending}>
            {aiTriage.isPending ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Sparkles className="h-4 w-4 mr-1" />}
            {aiTriage.isPending ? t("inner.analyzing") : t("inner.aiAnalysis")}
          </Button>
        </CardContent>
      </Card>

      {triage && (
        <Card className="border-secondary/30">
          <CardHeader><CardTitle className="text-lg flex items-center gap-2"><Sparkles className="h-5 w-5 text-secondary" /> {t("inner.aiTriageResult")}</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-3 flex-wrap">
              <Badge className={urgencyColor[triage.urgency] || ""}>{triage.urgency} {t("inner.urgency")}</Badge>
              <Badge variant="outline">{t("inner.suggested")}: {triage.suggested_specialty}</Badge>
            </div>
            <p className="text-sm">{triage.summary}</p>
            <p className="text-sm text-muted-foreground">{triage.reasoning}</p>

            {triage.urgency === "azonnali" && (
              <div className="flex items-start gap-2 p-3 rounded-md bg-destructive/10 text-destructive">
                <AlertTriangle className="h-5 w-5 mt-0.5 shrink-0" />
                <p className="text-sm font-medium">{t("inner.immediateWarning")}</p>
              </div>
            )}

            {triage.followup_questions?.length > 0 && (
              <div className="space-y-3 border-t pt-3">
                <p className="text-sm font-medium">{t("inner.followupQuestions")}:</p>
                {triage.followup_questions.map((q, i) => (
                  <div key={i}>
                    <Label className="text-sm text-muted-foreground">{q}</Label>
                    <Input value={followupAnswers[i] ?? ""} onChange={(e) => setFollowupAnswers((prev) => { const n = [...prev]; n[i] = e.target.value; return n; })} className="mt-1" />
                  </div>
                ))}
              </div>
            )}

            <p className="text-xs text-muted-foreground italic">⚠️ {t("inner.aiDisclaimer")}</p>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">2. {t("inner.selectSpecialty")}</CardTitle>
          <CardDescription>{t("inner.acceptAiSuggestion")}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <Input placeholder={t("inner.searchSpecialties")} value={specialtySearch} onChange={(e) => setSpecialtySearch(e.target.value)} />
          <div className="flex flex-wrap gap-2">
            {filteredSpecialties.map((s) => (
              <Badge key={s} variant={selectedSpecialty === s ? "default" : "outline"} className="cursor-pointer hover:bg-secondary/20 transition-colors" onClick={() => setSelectedSpecialty(s)}>{s}</Badge>
            ))}
          </div>
          {selectedSpecialty && <p className="text-sm">{t("inner.selected")}: <span className="font-semibold">{selectedSpecialty}</span></p>}
        </CardContent>
      </Card>

      <Card>
        <CardContent className="pt-6">
          <Button className="w-full" size="lg" onClick={() => submitRequest.mutate()} disabled={!symptoms.trim() || submitRequest.isPending}>
            {submitRequest.isPending ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Send className="h-4 w-4 mr-2" />}
            {t("inner.submitReferral")}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
