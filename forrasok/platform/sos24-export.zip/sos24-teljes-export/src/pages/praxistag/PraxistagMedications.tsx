import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { Pill, Send } from "lucide-react";
import MedicationSearch from "@/components/MedicationSearch";

export default function PraxistagMedications() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();

  const [selected, setSelected] = useState<string[]>([]);
  const [requestType, setRequestType] = useState("allando");
  const [notes, setNotes] = useState("");

  const typeLabels: Record<string, string> = {
    allando: t("inner.permanent"), eseti: t("inner.occasional"), panasz: t("inner.complaint"),
  };
  const statusConfig: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
    pending: { label: t("inner.pending"), variant: "outline" },
    approved: { label: t("inner.approved"), variant: "default" },
    rejected: { label: t("inner.rejected"), variant: "destructive" },
  };

  const { data: requests, isLoading } = useQuery({
    queryKey: ["my-med-requests", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase.from("medication_requests").select("*").eq("patient_id", user!.id).order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  const previousMeds = Array.from(new Set((requests ?? []).filter((r) => r.status === "approved").map((r) => r.medication_name)));

  const submit = useMutation({
    mutationFn: async () => {
      if (selected.length === 0) throw new Error(t("inner.selectAtLeastOne"));
      if (requestType === "panasz" && !notes.trim()) throw new Error(t("inner.complaintNoteRequired"));
      const rows = selected.map((name) => ({ patient_id: user!.id, medication_name: name, request_type: requestType, notes: notes.trim() || null }));
      const { error } = await supabase.from("medication_requests").insert(rows);
      if (error) throw error;
    },
    onSuccess: async () => {
      qc.invalidateQueries({ queryKey: ["my-med-requests"] });
      toast({ title: t("inner.medicationRequestSent") });
      try {
        const { data: haziorvosUsers } = await supabase.from("user_roles").select("user_id").eq("role", "haziorvos");
        for (const doc of haziorvosUsers ?? []) {
          await supabase.functions.invoke("send-notification", {
            body: { type: "medication_response", recipient_id: doc.user_id, sender_id: user!.id, data: { medication: selected.join(", "), status: "pending", response: t("inner.medicationRequestSent") } },
          });
        }
      } catch (e) { console.error("Notification error:", e); }
      setSelected([]);
      setNotes("");
    },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3"><Pill className="h-6 w-6 text-secondary" /><h1 className="text-2xl font-bold">{t("inner.medicationRequest")}</h1></div>

      <Tabs defaultValue="new">
        <TabsList>
          <TabsTrigger value="new">{t("inner.newRequest")}</TabsTrigger>
          <TabsTrigger value="history">{t("inner.previousRequests")}</TabsTrigger>
        </TabsList>

        <TabsContent value="new">
          <Card>
            <CardHeader><CardTitle className="text-lg">{t("inner.prescriptionRequest")}</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-1.5">
                <Label>{t("inner.searchMedication")}</Label>
                <MedicationSearch multiple selectedItems={selected} onSelect={(name) => !selected.includes(name) && setSelected([...selected, name])} onRemove={(name) => setSelected(selected.filter((s) => s !== name))} />
                {previousMeds.length > 0 && (
                  <div className="mt-2">
                    <p className="text-xs text-muted-foreground mb-1.5">{t("inner.previouslyPrescribed")}:</p>
                    <div className="flex flex-wrap gap-1.5">
                      {previousMeds.map((name) => (
                        <Button key={name} type="button" variant={selected.includes(name) ? "default" : "outline"} size="sm" className="h-7 text-xs" onClick={() => selected.includes(name) ? setSelected(selected.filter((s) => s !== name)) : setSelected([...selected, name])}>
                          <Pill className="h-3 w-3 mr-1" />{name}
                        </Button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
              <div className="space-y-1.5">
                <Label>{t("inner.requestType")}</Label>
                <Select value={requestType} onValueChange={setRequestType}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="allando">{t("inner.permanent")}</SelectItem>
                    <SelectItem value="eseti">{t("inner.occasional")}</SelectItem>
                    <SelectItem value="panasz">{t("inner.complaint")}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {requestType === "panasz" ? (
                <div className="space-y-1.5"><Label>{t("inner.complaintDescription")} *</Label><Textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={3} placeholder={t("inner.describeComplaint")} /></div>
              ) : (
                <div className="space-y-1.5"><Label>{t("inner.optionalNote")}</Label><Textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} /></div>
              )}
              <Button onClick={() => submit.mutate()} disabled={submit.isPending || selected.length === 0}>
                <Send className="h-4 w-4 mr-2" />{t("inner.sendRequest")} ({selected.length})
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history">
          <Card>
            <CardHeader><CardTitle className="text-lg">{t("inner.previousRequests")}</CardTitle></CardHeader>
            <CardContent className="overflow-x-auto">
              {isLoading ? (
                <div className="flex justify-center py-8"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>
              ) : (
                <Table>
                  <TableHeader><TableRow><TableHead>{t("inner.date")}</TableHead><TableHead>{t("inner.medication")}</TableHead><TableHead>{t("inner.type")}</TableHead><TableHead>{t("common.status")}</TableHead><TableHead>{t("inner.doctorResponse")}</TableHead></TableRow></TableHeader>
                  <TableBody>
                    {(requests ?? []).map((r) => {
                      const sc = statusConfig[r.status] ?? statusConfig.pending;
                      return (
                        <TableRow key={r.id}>
                          <TableCell className="whitespace-nowrap">{new Date(r.created_at).toLocaleDateString("hu-HU")}</TableCell>
                          <TableCell className="font-medium">{r.medication_name}</TableCell>
                          <TableCell><Badge variant="secondary">{typeLabels[r.request_type] ?? r.request_type}</Badge></TableCell>
                          <TableCell><Badge variant={sc.variant}>{sc.label}</Badge></TableCell>
                          <TableCell className="max-w-xs truncate">{r.doctor_response || "—"}</TableCell>
                        </TableRow>
                      );
                    })}
                    {(requests ?? []).length === 0 && (<TableRow><TableCell colSpan={5} className="text-center text-muted-foreground py-8">{t("inner.noRequest")}</TableCell></TableRow>)}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
