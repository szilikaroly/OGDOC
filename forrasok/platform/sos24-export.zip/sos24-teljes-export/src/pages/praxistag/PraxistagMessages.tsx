import { useState, useEffect, useRef, useMemo } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { MessageSquare, Send } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import AiTranslateButton from "@/components/AiTranslateButton";

export default function PraxistagMessages() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [newMsg, setNewMsg] = useState("");
  const [recipientId, setRecipientId] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  const { data: allowedProfiles } = useQuery({
    queryKey: ["praxistag-message-profiles"],
    queryFn: async () => {
      const { data: haziorvosRoles } = await supabase.from("user_roles").select("user_id").eq("role", "haziorvos");
      const haziorvosIds = (haziorvosRoles ?? []).map((r) => r.user_id);
      const { data: praxistagRoles } = await supabase.from("user_roles").select("user_id").eq("role", "praxistag");
      const praxistagIds = (praxistagRoles ?? []).map((r) => r.user_id);
      const allIds = [...new Set([...haziorvosIds, ...praxistagIds])];
      if (!allIds.length) return [];
      const { data: profiles } = await supabase.from("profiles").select("user_id, full_name").in("user_id", allIds).order("full_name");
      const roleMap = new Map<string, string[]>();
      for (const r of [...(haziorvosRoles ?? [])]) roleMap.set(r.user_id, [...(roleMap.get(r.user_id) ?? []), t("inner.familyDoctor")]);
      for (const r of [...(praxistagRoles ?? [])]) roleMap.set(r.user_id, [...(roleMap.get(r.user_id) ?? []), t("inner.practiceStaff")]);
      return (profiles ?? []).map((p) => ({ ...p, roleLabels: roleMap.get(p.user_id) ?? [] }));
    },
  });

  const { data: messages, isLoading } = useQuery({
    queryKey: ["my-messages", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase.from("messages").select("*").or(`sender_id.eq.${user!.id},recipient_id.eq.${user!.id}`).order("created_at", { ascending: true });
      if (error) throw error;
      const { data: groupData } = await supabase.from("messages").select("*").eq("group_role", "praxistag").order("created_at", { ascending: true });
      const allMessages = [...(data ?? []), ...(groupData ?? [])];
      const unique = Array.from(new Map(allMessages.map((m) => [m.id, m])).values());
      return unique.sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
    },
    enabled: !!user,
  });

  useEffect(() => {
    if (!user) return;
    const channel = supabase.channel("messages-realtime").on("postgres_changes", { event: "*", schema: "public", table: "messages" }, () => { qc.invalidateQueries({ queryKey: ["my-messages"] }); }).subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [user, qc]);

  useEffect(() => { scrollRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  const sendMessage = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("messages").insert({ sender_id: user!.id, recipient_id: recipientId || null, body: newMsg });
      if (error) throw error;
    },
    onSuccess: () => { setNewMsg(""); qc.invalidateQueries({ queryKey: ["my-messages"] }); },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  const getProfileName = (id: string) => (allowedProfiles ?? []).find((p) => p.user_id === id)?.full_name ?? t("inner.unknown");

  const directMessages = useMemo(() => {
    return (messages ?? []).filter((m) => !m.group_role || m.group_role === "praxistag");
  }, [messages]);

  if (isLoading) return <div className="flex items-center justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3"><MessageSquare className="h-6 w-6 text-secondary" /><h1 className="text-2xl font-bold">{t("inner.messages")}</h1></div>

      <Card className="flex flex-col h-[60vh]">
        <CardHeader className="pb-2"><CardTitle className="text-lg">{t("inner.messagesWithDoctor")}</CardTitle></CardHeader>
        <CardContent className="flex-1 flex flex-col min-h-0">
          <ScrollArea className="flex-1 pr-4">
            <div className="space-y-3">
              {directMessages.map((m) => {
                const isMine = m.sender_id === user?.id;
                return (
                  <div key={m.id} className={cn("flex", isMine ? "justify-end" : "justify-start")}>
                    <div className={cn("max-w-[70%] rounded-lg px-3 py-2", isMine ? "bg-primary text-primary-foreground" : "bg-muted")}>
                      <p className="text-xs font-medium mb-1">{isMine ? t("inner.me") : getProfileName(m.sender_id)}</p>
                      {m.subject && <p className="text-xs font-semibold mb-0.5">{m.subject}</p>}
                      <p className="text-sm">{m.body}</p>
                      <div className="flex items-center gap-1 mt-1">
                        <p className="text-[10px] opacity-70">{new Date(m.created_at).toLocaleString("hu-HU")}</p>
                        <AiTranslateButton text={m.body} />
                      </div>
                    </div>
                  </div>
                );
              })}
              {directMessages.length === 0 && (<p className="text-center text-muted-foreground text-sm py-8">{t("inner.noMessages")}</p>)}
              <div ref={scrollRef} />
            </div>
          </ScrollArea>

          <div className="flex gap-2 pt-3 border-t mt-3">
            <Select value={recipientId} onValueChange={setRecipientId}>
              <SelectTrigger className="w-48"><SelectValue placeholder={t("inner.recipient")} /></SelectTrigger>
              <SelectContent>
                {(allowedProfiles ?? []).filter((p) => p.user_id !== user?.id).map((p) => (
                  <SelectItem key={p.user_id} value={p.user_id}>{p.full_name}<span className="text-muted-foreground text-xs ml-1">({p.roleLabels.join(", ")})</span></SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Input className="flex-1" placeholder={t("inner.message") + "..."} value={newMsg} onChange={(e) => setNewMsg(e.target.value)} onKeyDown={(e) => e.key === "Enter" && newMsg && recipientId && sendMessage.mutate()} />
            <Button onClick={() => sendMessage.mutate()} disabled={!newMsg || !recipientId || sendMessage.isPending}><Send className="h-4 w-4" /></Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
