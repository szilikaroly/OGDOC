import { useTranslation } from "react-i18next";
import { LayoutDashboard, Calendar, HeartPulse, FileText, MessageSquare, Pill, Stethoscope, BookHeart, ClipboardList, User, Sparkles, FlaskConical } from "lucide-react";
import DashboardLayout, { type NavItem } from "@/components/DashboardLayout";
import { useUnreadMessages } from "@/hooks/use-unread-messages";

export default function PraxistagLayout() {
  const { t } = useTranslation();
  const unread = useUnreadMessages();
  const NAV: NavItem[] = [
    { title: t('dashboard.overview'), url: "/praxistag", icon: LayoutDashboard },
    { title: t('dashboard.profile'), url: "/praxistag/profile", icon: User },
    { title: t('nav.myAppointments'), url: "/praxistag/appointments", icon: Calendar },
    { title: t('nav.healthData'), url: "/praxistag/health", icon: HeartPulse },
    { title: t('nav.healthJournal'), url: "/praxistag/journal", icon: BookHeart },
    { title: t('nav.medicationRequest'), url: "/praxistag/medications", icon: Pill },
    { title: t('nav.referralRequest'), url: "/praxistag/referral-request", icon: Stethoscope },
    { title: t('dashboard.documents'), url: "/praxistag/documents", icon: FileText },
    { title: t('nav.labShop', 'Labor vizsgálat'), url: "/praxistag/labor", icon: FlaskConical },
    { title: t('dashboard.questionnaires'), url: "/praxistag/questionnaires", icon: ClipboardList },
    { title: t('dashboard.healthPlan'), url: "/praxistag/health-plan", icon: Sparkles },
    { title: t('dashboard.messages'), url: "/praxistag/messages", icon: MessageSquare, badge: unread },
  ];
  return <DashboardLayout navItems={NAV} groupLabel={t('roles.praxistag')} />;
}
