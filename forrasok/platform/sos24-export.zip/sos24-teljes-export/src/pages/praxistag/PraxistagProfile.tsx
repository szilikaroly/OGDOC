import PatientProfile from "@/components/PatientProfile";
export default function PraxistagProfile() {
  return <PatientProfile />;
}
