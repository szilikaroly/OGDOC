import MunkavallaloHealth from "@/pages/munkavallalo/MunkavallaloHealth";

// Praxistag health page reuses the same törzskarton + health reports component
export default function PraxistagHealth() {
  return <MunkavallaloHealth />;
}
