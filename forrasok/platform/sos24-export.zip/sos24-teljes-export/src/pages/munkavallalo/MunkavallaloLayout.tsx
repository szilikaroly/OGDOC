import { useTranslation } from "react-i18next";
import { LayoutDashboard, Calendar, FileText, HeartPulse, ClipboardList, MessageSquare, FolderOpen, Shield, ShieldCheck, BookHeart, Syringe, Settings, User, Sparkles, AlertTriangle, FlaskConical } from "lucide-react";
import DashboardLayout, { type NavItem } from "@/components/DashboardLayout";
import { useUnreadMessages } from "@/hooks/use-unread-messages";

export default function MunkavallaloLayout() {
  const { t } = useTranslation();
  const unread = useUnreadMessages();
  const NAV: NavItem[] = [
    { title: t('dashboard.overview'), url: "/munkavallalo", icon: LayoutDashboard },
    { title: t('dashboard.profile'), url: "/munkavallalo/profile", icon: User },
    { title: t('nav.myAppointments'), url: "/munkavallalo/appointments", icon: Calendar },
    { title: t('nav.healthData'), url: "/munkavallalo/health", icon: HeartPulse },
    { title: t('nav.healthJournal'), url: "/munkavallalo/journal", icon: BookHeart },
    { title: t('dashboard.vaccinations'), url: "/munkavallalo/vaccinations", icon: Syringe },
    { title: t('dashboard.opinions'), url: "/munkavallalo/opinions", icon: FileText },
    { title: t('dashboard.questionnaires'), url: "/munkavallalo/questionnaires", icon: ClipboardList },
    { title: t('dashboard.healthPlan'), url: "/munkavallalo/health-plan", icon: Sparkles },
    { title: t('dashboard.documents'), url: "/munkavallalo/documents", icon: FolderOpen },
    { title: t('accident.myReports'), url: "/munkavallalo/accidents", icon: AlertTriangle },
    { title: t('nav.labShop', 'Labor vizsgálat'), url: "/munkavallalo/labor", icon: FlaskConical },
    { title: t('dashboard.dataAccess'), url: "/munkavallalo/data-access", icon: Shield },
    { title: t('dashboard.gdpr'), url: "/munkavallalo/gdpr", icon: ShieldCheck },
    { title: t('dashboard.messages'), url: "/munkavallalo/messages", icon: MessageSquare, badge: unread },
    { title: t('common.settings'), url: "/munkavallalo/settings", icon: Settings },
  ];
  return <DashboardLayout navItems={NAV} groupLabel={t('roles.munkavallalo')} />;
}
