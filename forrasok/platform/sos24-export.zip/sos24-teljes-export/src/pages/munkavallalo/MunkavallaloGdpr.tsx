import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Shield, Download, Trash2, AlertTriangle } from "lucide-react";
import { useTranslation } from "react-i18next";

const STATUS_VARIANT: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
  pending: "outline",
  processing: "secondary",
  completed: "default",
  rejected: "destructive",
};

export default function MunkavallaloGdpr() {
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const { t } = useTranslation();

  const STATUS_LABELS: Record<string, string> = {
    pending: t('gdpr.pending'),
    processing: t('gdpr.processing'),
    completed: t('gdpr.completed'),
    rejected: t('gdpr.rejected'),
  };

  const { data: requests, isLoading } = useQuery({
    queryKey: ["gdpr-requests", user?.id],
    queryFn: async () => {
      const { data, error } = await (supabase as any)
        .from("gdpr_requests")
        .select("*")
        .eq("user_id", user!.id)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as any[];
    },
    enabled: !!user,
  });

  const createRequest = useMutation({
    mutationFn: async (type: "export" | "delete") => {
      const { error } = await (supabase as any).from("gdpr_requests").insert({
        user_id: user!.id,
        type,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["gdpr-requests"] });
      toast({ title: t('gdpr.title'), description: t('gdpr.exportDesc') });
      setDeleteDialogOpen(false);
    },
    onError: (e: any) => toast({ variant: "destructive", title: t('common.close'), description: e.message }),
  });

  const hasPendingExport = (requests ?? []).some((r: any) => r.type === "export" && r.status === "pending");
  const hasPendingDelete = (requests ?? []).some((r: any) => r.type === "delete" && r.status === "pending");

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Shield className="h-6 w-6 text-secondary" />
        <h1 className="text-2xl font-bold">{t('gdpr.title')}</h1>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Download className="h-5 w-5" />
              {t('gdpr.exportTitle')}
            </CardTitle>
            <CardDescription>{t('gdpr.exportDesc')}</CardDescription>
          </CardHeader>
          <CardContent>
            <Button
              onClick={() => createRequest.mutate("export")}
              disabled={createRequest.isPending || hasPendingExport}
            >
              {hasPendingExport ? `${t('gdpr.pending')}...` : t('gdpr.exportButton')}
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2 text-destructive">
              <Trash2 className="h-5 w-5" />
              {t('gdpr.deleteTitle')}
            </CardTitle>
            <CardDescription>{t('gdpr.deleteDesc')}</CardDescription>
          </CardHeader>
          <CardContent>
            <Button
              variant="destructive"
              onClick={() => setDeleteDialogOpen(true)}
              disabled={createRequest.isPending || hasPendingDelete}
            >
              {hasPendingDelete ? `${t('gdpr.pending')}...` : t('gdpr.deleteButton')}
            </Button>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">{t('gdpr.previousRequests')}</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-8">
              <div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" />
            </div>
          ) : (requests ?? []).length === 0 ? (
            <p className="text-muted-foreground text-center py-4">{t('common.noData')}</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t('common.name')}</TableHead>
                  <TableHead>{t('common.status')}</TableHead>
                  <TableHead>{t('common.date')}</TableHead>
                  <TableHead>{t('common.details')}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {(requests ?? []).map((r: any) => (
                  <TableRow key={r.id}>
                    <TableCell>
                      {r.type === "export" ? t('gdpr.exportTitle') : t('gdpr.deleteTitle')}
                    </TableCell>
                    <TableCell>
                      <Badge variant={STATUS_VARIANT[r.status] ?? "outline"}>
                        {STATUS_LABELS[r.status] ?? r.status}
                      </Badge>
                    </TableCell>
                    <TableCell>{new Date(r.created_at).toLocaleDateString("hu-HU")}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">{r.notes ?? "—"}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-destructive">
              <AlertTriangle className="h-5 w-5" />
              {t('gdpr.deleteConfirm')}
            </DialogTitle>
            <DialogDescription>{t('gdpr.deleteWarning')}</DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>{t('common.cancel')}</Button>
            <Button
              variant="destructive"
              onClick={() => createRequest.mutate("delete")}
              disabled={createRequest.isPending}
            >
              {t('common.yes')}, {t('gdpr.deleteButton')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
