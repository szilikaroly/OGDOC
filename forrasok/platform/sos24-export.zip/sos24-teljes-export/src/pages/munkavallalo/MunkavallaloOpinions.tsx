import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FileText, Printer } from "lucide-react";
import PrintableOpinion from "@/components/PrintableOpinion";

export default function MunkavallaloOpinions() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const [printOpinion, setPrintOpinion] = useState<any>(null);

  const { data: opinions, isLoading } = useQuery({
    queryKey: ["my-opinions", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase.from("medical_opinions").select("*").eq("patient_id", user!.id).order("opinion_date", { ascending: false });
      if (error) throw error;
      const docIds = [...new Set(data.map((o) => o.doctor_id))];
      const { data: profiles } = await supabase.from("profiles").select("user_id, full_name, signature_url").in("user_id", docIds);
      const { data: myProfile } = await supabase.from("profiles").select("full_name, taj_number, birth_date").eq("user_id", user!.id).single();
      const { resolveSignatureUrl } = await import("@/lib/storage-utils");
      const enriched = await Promise.all(data.map(async (o) => {
        const rawSigUrl = (profiles ?? []).find((p) => p.user_id === o.doctor_id)?.signature_url ?? null;
        const resolvedSig = await resolveSignatureUrl(rawSigUrl);
        return {
          ...o,
          doctor_name: (profiles ?? []).find((p) => p.user_id === o.doctor_id)?.full_name ?? "—",
          signature_url: resolvedSig,
          patient_name: myProfile?.full_name ?? "—",
          patient_taj: myProfile?.taj_number ?? "",
          patient_birth: myProfile?.birth_date ?? "",
        };
      }));
      return enriched;
    },
    enabled: !!user,
  });

  const handlePrint = (o: any) => {
    setPrintOpinion(o);
    setTimeout(() => window.print(), 300);
  };

  if (isLoading) return <div className="flex items-center justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>;

  return (
    <div className="space-y-6">
      {printOpinion && <PrintableOpinion opinion={printOpinion} />}
      <div className="flex items-center gap-3 print:hidden"><FileText className="h-6 w-6 text-secondary" /><h1 className="text-2xl font-bold">{t('inner.myOpinions')}</h1></div>
      <Card className="print:hidden">
        <CardHeader><CardTitle className="text-lg">{t('inner.myFitnessOpinions')} ({opinions?.length ?? 0})</CardTitle></CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader><TableRow><TableHead>{t('inner.doctor')}</TableHead><TableHead>{t('inner.date')}</TableHead><TableHead>{t('inner.validUntil')}</TableHead><TableHead>{t('inner.result')}</TableHead><TableHead>{t('inner.action')}</TableHead></TableRow></TableHeader>
            <TableBody>
              {(opinions ?? []).map((o) => (
                <TableRow key={o.id}>
                  <TableCell className="font-medium">{o.doctor_name}</TableCell>
                  <TableCell>{new Date(o.opinion_date).toLocaleDateString("hu-HU")}</TableCell>
                  <TableCell>{o.valid_until ? new Date(o.valid_until).toLocaleDateString("hu-HU") : "—"}</TableCell>
                  <TableCell><Badge variant={o.status === "alkalmas" ? "default" : o.status === "nem_alkalmas" ? "destructive" : "secondary"}>{t(`inner.${o.status === "alkalmas" ? "fit" : o.status === "nem_alkalmas" ? "unfit" : o.status === "feltetelesen_alkalmas" ? "conditionallyFit" : "temporary"}`)}</Badge></TableCell>
                  <TableCell><Button size="sm" variant="outline" onClick={() => handlePrint(o)}><Printer className="h-4 w-4 mr-1" />{t('inner.print')}</Button></TableCell>
                </TableRow>
              ))}
              {(opinions ?? []).length === 0 && <TableRow><TableCell colSpan={5} className="text-center text-muted-foreground py-8">{t('inner.noOpinion')}</TableCell></TableRow>}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
