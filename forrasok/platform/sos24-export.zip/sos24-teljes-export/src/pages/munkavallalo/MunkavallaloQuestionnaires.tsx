import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { ClipboardList, AlertCircle, Brain, Loader2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useTranslation } from "react-i18next";
import ReactMarkdown from "react-markdown";

interface FieldDef { key: string; label: string; type: "text" | "number" | "textarea" | "yesno" | "select" | "multiselect"; options?: string[]; }
interface SectionDef { section: string; fields: FieldDef[]; }

function isSectioned(fields: any): fields is SectionDef[] {
  return Array.isArray(fields) && fields.length > 0 && "section" in fields[0];
}

function FieldInput({ field, value, onChange, t }: { field: FieldDef; value: any; onChange: (val: any) => void; t: (key: string) => string }) {
  switch (field.type) {
    case "yesno":
      return (
        <RadioGroup value={value || ""} onValueChange={onChange} className="flex gap-4">
          <div className="flex items-center space-x-2"><RadioGroupItem value="igen" id={`${field.key}-yes`} /><label htmlFor={`${field.key}-yes`} className="text-sm cursor-pointer">{t("inner.yesLabel")}</label></div>
          <div className="flex items-center space-x-2"><RadioGroupItem value="nem" id={`${field.key}-no`} /><label htmlFor={`${field.key}-no`} className="text-sm cursor-pointer">{t("inner.noLabel")}</label></div>
        </RadioGroup>
      );
    case "select":
      return (
        <Select value={value || ""} onValueChange={onChange}>
          <SelectTrigger><SelectValue placeholder={t("inner.select")} /></SelectTrigger>
          <SelectContent>{(field.options ?? []).map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
        </Select>
      );
    case "multiselect": {
      const selected: string[] = Array.isArray(value) ? value : [];
      return (
        <div className="grid grid-cols-2 gap-1.5">
          {(field.options ?? []).map((o) => (
            <div key={o} className="flex items-center space-x-2">
              <Checkbox id={`${field.key}-${o}`} checked={selected.includes(o)} onCheckedChange={(v) => { onChange(v ? [...selected, o] : selected.filter((s) => s !== o)); }} />
              <label htmlFor={`${field.key}-${o}`} className="text-sm cursor-pointer">{o}</label>
            </div>
          ))}
        </div>
      );
    }
    case "number": return <Input type="number" value={value || ""} onChange={(e) => onChange(e.target.value)} />;
    case "textarea": return <Textarea value={value || ""} onChange={(e) => onChange(e.target.value)} rows={2} />;
    default: return <Input value={value || ""} onChange={(e) => onChange(e.target.value)} />;
  }
}

export default function MunkavallaloQuestionnaires() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [filling, setFilling] = useState<any>(null);
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [currentSection, setCurrentSection] = useState(0);
  const [viewingEval, setViewingEval] = useState<any>(null);

  const { data: questionnaires } = useQuery({
    queryKey: ["active-questionnaires"],
    queryFn: async () => { const { data, error } = await supabase.from("questionnaires").select("*").eq("is_active", true).order("title"); if (error) throw error; return data; },
  });

  const { data: mySubmissions, isLoading } = useQuery({
    queryKey: ["my-submissions", user?.id],
    queryFn: async () => { const { data, error } = await supabase.from("questionnaire_submissions").select("id, questionnaire_id, submitted_at, score, risk_category, ai_evaluation").eq("user_id", user!.id).order("submitted_at", { ascending: false }); if (error) throw error; return data; },
    enabled: !!user,
  });

  // Fetch pending assignments for this patient
  const { data: myAssignments } = useQuery({
    queryKey: ["my-questionnaire-assignments", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("questionnaire_assignments")
        .select("*")
        .eq("patient_id", user!.id)
        .eq("status", "pending")
        .order("created_at", { ascending: false });
      if (error) throw error;
      // Get questionnaire titles
      const qIds = [...new Set(data.map((a: any) => a.questionnaire_id))];
      if (qIds.length === 0) return [];
      const { data: quests } = await supabase.from("questionnaires").select("id, title").in("id", qIds);
      return data.map((a: any) => ({
        ...a,
        questionnaire_title: (quests ?? []).find((q) => q.id === a.questionnaire_id)?.title ?? "—",
      }));
    },
    enabled: !!user,
  });

  const submit = useMutation({
    mutationFn: async () => {
      const { data: inserted, error } = await supabase.from("questionnaire_submissions").insert({ questionnaire_id: filling.id, user_id: user!.id, answers }).select("id").single();
      if (error) throw error;

      // Mark any matching assignment as completed
      if (myAssignments?.length) {
        const matchingAssignment = myAssignments.find((a: any) => a.questionnaire_id === filling.id);
        if (matchingAssignment) {
          await supabase.from("questionnaire_assignments").update({ status: "completed", completed_at: new Date().toISOString() }).eq("id", matchingAssignment.id);
        }
      }

      // Trigger AI scoring
      try {
        await supabase.functions.invoke("ai-questionnaire-scoring", {
          body: { submission_id: inserted.id },
        });
      } catch (e) {
        console.warn("AI scoring failed:", e);
      }

      return inserted;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["my-submissions"] });
      qc.invalidateQueries({ queryKey: ["my-questionnaire-assignments"] });
      toast({ title: t("inner.questionnaireSubmitted") });
      setFilling(null);
      setAnswers({});
      setCurrentSection(0);
    },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  const getRiskColor = (category: string) => {
    if (!category) return "secondary";
    const lower = category.toLowerCase();
    if (lower.includes("alacsony") || lower.includes("minimális") || lower.includes("nincs")) return "default";
    if (lower.includes("enyhe") || lower.includes("enyhén")) return "secondary";
    if (lower.includes("közepes")) return "outline";
    return "destructive";
  };

  if (isLoading) return <div className="flex items-center justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>;

  const rawFields = filling ? filling.fields : null;
  const sectioned = rawFields && isSectioned(rawFields);
  const sections: SectionDef[] = sectioned ? rawFields : [];
  const flatFields: FieldDef[] = sectioned ? [] : (Array.isArray(rawFields) ? rawFields : []);
  const totalSections = sectioned ? sections.length : 1;
  const currentSectionData = sectioned ? sections[currentSection] : null;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3"><ClipboardList className="h-6 w-6 text-secondary" /><h1 className="text-2xl font-bold">{t("inner.questionnairesTitle")}</h1></div>

      {/* Pending assignments alert */}
      {(myAssignments ?? []).length > 0 && (
        <Alert className="border-secondary">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            <strong>Orvosa kéri, hogy töltse ki a következő kérdőív(ek)et:</strong>
            <ul className="mt-2 space-y-1">
              {(myAssignments ?? []).map((a: any) => (
                <li key={a.id} className="flex items-center gap-2">
                  <Badge variant="secondary">{a.questionnaire_title}</Badge>
                  {a.message && <span className="text-sm text-muted-foreground">— {a.message}</span>}
                  <Button
                    size="sm"
                    variant="default"
                    className="ml-auto"
                    onClick={() => {
                      const q = (questionnaires ?? []).find((q) => q.id === a.questionnaire_id);
                      if (q) { setFilling(q); setAnswers({}); setCurrentSection(0); }
                    }}
                  >
                    Kitöltés most
                  </Button>
                </li>
              ))}
            </ul>
          </AlertDescription>
        </Alert>
      )}

      <div className="grid gap-4 md:grid-cols-2">
        {(questionnaires ?? []).map((q) => {
          const alreadyFilled = (mySubmissions ?? []).some((s) => s.questionnaire_id === q.id);
          const isAssigned = (myAssignments ?? []).some((a: any) => a.questionnaire_id === q.id);
          return (
            <Card key={q.id} className={isAssigned ? "ring-2 ring-secondary" : ""}>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  {q.title}
                  {isAssigned && <Badge variant="secondary" className="text-xs">Orvos kéri</Badge>}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-3">{q.description || t("inner.noDescription")}</p>
                <Button size="sm" onClick={() => { setFilling(q); setAnswers({}); setCurrentSection(0); }} disabled={alreadyFilled}>
                  {alreadyFilled ? t("inner.alreadyFilled") : t("inner.fill")}
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Previous submissions with scores */}
      {(mySubmissions ?? []).length > 0 && (
        <Card>
          <CardHeader><CardTitle className="text-lg">{t("inner.previousSubmissions")}</CardTitle></CardHeader>
          <CardContent className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t("inner.questionnaire")}</TableHead>
                  <TableHead>{t("inner.submittedAt")}</TableHead>
                  <TableHead>Pontszám</TableHead>
                  <TableHead>Értékelés</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {(mySubmissions ?? []).map((s: any) => (
                  <TableRow key={s.id}>
                    <TableCell>{(questionnaires ?? []).find((q) => q.id === s.questionnaire_id)?.title ?? "—"}</TableCell>
                    <TableCell>{new Date(s.submitted_at).toLocaleDateString("hu-HU")}</TableCell>
                    <TableCell>{s.score != null ? <span className="font-bold">{s.score}</span> : "—"}</TableCell>
                    <TableCell>
                      {s.risk_category ? <Badge variant={getRiskColor(s.risk_category)}>{s.risk_category}</Badge> : "—"}
                    </TableCell>
                    <TableCell>
                      {s.ai_evaluation && (
                        <Button size="sm" variant="ghost" onClick={() => setViewingEval({ ...s, questionnaire_title: (questionnaires ?? []).find((q) => q.id === s.questionnaire_id)?.title ?? "—" })}>
                          <Brain className="h-3 w-3 mr-1" /> Részletek
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* Fill dialog */}
      <Dialog open={!!filling} onOpenChange={(open) => { if (!open) { setFilling(null); setCurrentSection(0); } }}>
        <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{filling?.title}</DialogTitle>
            {sectioned && <p className="text-sm text-muted-foreground">{currentSection + 1} / {totalSections} — {currentSectionData?.section}</p>}
          </DialogHeader>

          {sectioned && currentSectionData && (
            <div className="space-y-4">
              <h3 className="font-semibold text-base border-b pb-2">{currentSectionData.section}</h3>
              {currentSectionData.fields.map((field) => (
                <div key={field.key} className="space-y-1.5">
                  <Label>{field.label}</Label>
                  <FieldInput field={field} value={answers[field.key]} onChange={(val) => setAnswers((a) => ({ ...a, [field.key]: val }))} t={t} />
                </div>
              ))}
              <Separator />
              <div className="flex gap-2">
                {currentSection > 0 && <Button variant="outline" onClick={() => setCurrentSection((s) => s - 1)}>{t("inner.backStep")}</Button>}
                {currentSection < totalSections - 1 ? (
                  <Button className="flex-1" onClick={() => setCurrentSection((s) => s + 1)}>{t("inner.nextStep")}</Button>
                ) : (
                  <div className="flex-1 space-y-3">
                    <div className="bg-muted p-3 rounded-md text-xs text-muted-foreground">{t("inner.consentText")}</div>
                    <Button className="w-full" onClick={() => submit.mutate()} disabled={submit.isPending}>
                      {submit.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                      {t("inner.submitAndAccept")}
                    </Button>
                  </div>
                )}
              </div>
            </div>
          )}

          {!sectioned && (
            <div className="space-y-4">
              {flatFields.map((field: any, i: number) => (
                <div key={i} className="space-y-1.5">
                  <Label>{field.label || `${t("inner.questionLabel")} ${i + 1}`}</Label>
                  {field.type === "textarea" ? (
                    <Textarea value={answers[field.label] ?? ""} onChange={(e) => setAnswers((a) => ({ ...a, [field.label]: e.target.value }))} />
                  ) : (
                    <Input value={answers[field.label] ?? ""} onChange={(e) => setAnswers((a) => ({ ...a, [field.label]: e.target.value }))} />
                  )}
                </div>
              ))}
              {flatFields.length === 0 && <p className="text-muted-foreground">{t("inner.noFieldsDefined")}</p>}
              <Button className="w-full" onClick={() => submit.mutate()} disabled={submit.isPending}>
                {submit.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                {t("inner.submit")}
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* AI Evaluation details */}
      <Dialog open={!!viewingEval} onOpenChange={(open) => !open && setViewingEval(null)}>
        <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>AI Értékelés — {viewingEval?.questionnaire_title}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="flex gap-4 text-sm">
              <div><strong>Pontszám:</strong> {viewingEval?.score}</div>
            </div>
            {viewingEval?.risk_category && (
              <Badge variant={getRiskColor(viewingEval.risk_category)} className="text-sm">{viewingEval.risk_category}</Badge>
            )}
            <div className="prose prose-sm max-w-none dark:prose-invert">
              <ReactMarkdown>{viewingEval?.ai_evaluation || ""}</ReactMarkdown>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
