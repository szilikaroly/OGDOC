import { useTranslation } from "react-i18next";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/contexts/AuthContext";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Calendar, HeartPulse, FileText, ClipboardCheck } from "lucide-react";
import { LineChart, Line, ResponsiveContainer, XAxis, YAxis, Tooltip, Legend } from "recharts";
import { Badge } from "@/components/ui/badge";

export default function MunkavallatoDashboard() {
  const { t } = useTranslation();
  const { profile, user } = useAuth();

  const RESULT_LABELS: Record<string, string> = {
    alkalmas: t("page.fit"), nem_alkalmas: t("page.unfit"),
    feltetelesen_alkalmas: t("page.conditionallyFit"), ideiglenes: t("page.temporary"),
  };

  const { data: nextAppointment } = useQuery({
    queryKey: ["munkavallalo-next-appointment"],
    queryFn: async () => {
      const { data } = await supabase.from("appointments").select("created_at, slot_id").eq("patient_id", user!.id).eq("status", "confirmed").order("created_at", { ascending: true }).limit(1);
      if (data?.length) return new Date(data[0].created_at).toLocaleDateString();
      return t("page.none");
    },
    enabled: !!user,
  });

  const { data: lastOpinion } = useQuery({
    queryKey: ["munkavallalo-last-opinion"],
    queryFn: async () => {
      const { data } = await supabase.from("medical_opinions").select("status, opinion_date").eq("patient_id", user!.id).order("opinion_date", { ascending: false }).limit(1);
      if (data?.length) return RESULT_LABELS[data[0].status] ?? data[0].status;
      return t("page.none");
    },
    enabled: !!user,
  });

  const { data: healthCount } = useQuery({
    queryKey: ["munkavallalo-health-count"],
    queryFn: async () => {
      const { count } = await supabase.from("health_reports").select("id", { count: "exact", head: true }).eq("user_id", user!.id);
      return count ?? 0;
    },
    enabled: !!user,
  });

  const { data: hasPatientCard } = useQuery({
    queryKey: ["munkavallalo-patient-card"],
    queryFn: async () => {
      const { count } = await supabase.from("patient_cards").select("id", { count: "exact", head: true }).eq("user_id", user!.id);
      return (count ?? 0) > 0 ? t("page.patientCardFilled") : t("page.patientCardMissing");
    },
    enabled: !!user,
  });

  const { data: healthTrend } = useQuery({
    queryKey: ["munkavallalo-health-trend"],
    queryFn: async () => {
      const { data } = await supabase.from("health_reports").select("report_date, blood_pressure_systolic, blood_pressure_diastolic, heart_rate").eq("user_id", user!.id).order("report_date", { ascending: true }).limit(10);
      return (data ?? []).map((r) => ({
        [t("page.date")]: r.report_date,
        [t("page.systolic")]: r.blood_pressure_systolic,
        [t("page.diastolic")]: r.blood_pressure_diastolic,
        [t("page.pulse")]: r.heart_rate,
      }));
    },
    enabled: !!user,
  });

  const { data: opinions } = useQuery({
    queryKey: ["munkavallalo-opinions-timeline"],
    queryFn: async () => {
      const { data } = await supabase.from("medical_opinions").select("id, opinion_date, status, valid_until").eq("patient_id", user!.id).order("opinion_date", { ascending: false }).limit(5);
      return data ?? [];
    },
    enabled: !!user,
  });

  const stats = [
    { label: t("page.nextAppointment"), icon: Calendar, value: nextAppointment ?? "—" },
    { label: t("page.lastOpinion"), icon: FileText, value: lastOpinion ?? "—" },
    { label: t("page.healthMeasurements"), icon: HeartPulse, value: healthCount ?? "—" },
    { label: t("page.patientCard"), icon: ClipboardCheck, value: hasPatientCard ?? "—" },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">{t("page.welcomeUser", { name: profile?.full_name })}</h1>
        <p className="text-muted-foreground">{t("page.employeeOverview")}</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s) => (
          <Card key={s.label} className="card-luxury">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">{s.label}</CardTitle>
              <s.icon className="h-5 w-5 text-secondary" />
            </CardHeader>
            <CardContent><p className="text-2xl font-bold">{s.value}</p></CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">{t("page.healthTrend")}</CardTitle></CardHeader>
        <CardContent>
          {healthTrend?.length ? (
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={healthTrend}>
                <XAxis dataKey={t("page.date")} tick={{ fontSize: 11 }} />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey={t("page.systolic")} stroke="hsl(var(--chart-1))" strokeWidth={2} dot={{ r: 3 }} />
                <Line type="monotone" dataKey={t("page.diastolic")} stroke="hsl(var(--chart-2))" strokeWidth={2} dot={{ r: 3 }} />
                <Line type="monotone" dataKey={t("page.pulse")} stroke="hsl(var(--chart-3))" strokeWidth={2} dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          ) : <p className="text-muted-foreground text-sm">{t("page.noMeasurementData")}</p>}
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">{t("page.fitnessOpinions")}</CardTitle></CardHeader>
        <CardContent>
          {opinions?.length ? (
            <div className="space-y-3">
              {opinions.map((o) => (
                <div key={o.id} className="flex items-center justify-between border-b border-border pb-2 last:border-0">
                  <div>
                    <p className="font-medium text-sm">{o.opinion_date}</p>
                    <p className="text-xs text-muted-foreground">{t("page.validUntil", { date: o.valid_until ?? "—" })}</p>
                  </div>
                  <Badge variant={o.status === "alkalmas" ? "default" : "destructive"}>{RESULT_LABELS[o.status] || o.status}</Badge>
                </div>
              ))}
            </div>
          ) : <p className="text-muted-foreground text-sm">{t("page.noOpinion")}</p>}
        </CardContent>
      </Card>
    </div>
  );
}
