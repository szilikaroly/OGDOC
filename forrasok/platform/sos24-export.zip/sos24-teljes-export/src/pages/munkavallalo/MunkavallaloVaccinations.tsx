import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import TravelVaccinationAdvisor from "@/components/TravelVaccinationAdvisor";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { Syringe, Plus, AlertTriangle } from "lucide-react";
import { format, differenceInDays } from "date-fns";
import { hu } from "date-fns/locale";
import { useTranslation } from "react-i18next";

export default function MunkavallaloVaccinations() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ vaccine_name: "", administered_date: "", expiry_date: "", lot_number: "", administered_by: "", notes: "" });

  const { data: vaccinations, isLoading } = useQuery({
    queryKey: ["vaccinations", user?.id],
    queryFn: async () => { const { data, error } = await supabase.from("vaccinations").select("*").eq("user_id", user!.id).order("administered_date", { ascending: false }); if (error) throw error; return data; },
    enabled: !!user,
  });

  const addVacc = useMutation({
    mutationFn: async () => {
      if (!form.vaccine_name || !form.administered_date) throw new Error(t("inner.nameAndDateRequired"));
      const row: Record<string, any> = { user_id: user!.id, vaccine_name: form.vaccine_name, administered_date: form.administered_date };
      if (form.expiry_date) row.expiry_date = form.expiry_date;
      if (form.lot_number) row.lot_number = form.lot_number;
      if (form.administered_by) row.administered_by = form.administered_by;
      if (form.notes) row.notes = form.notes;
      const { error } = await supabase.from("vaccinations").insert(row as any);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["vaccinations"] });
      toast({ title: t("inner.vaccinationRecorded") });
      setOpen(false);
      setForm({ vaccine_name: "", administered_date: "", expiry_date: "", lot_number: "", administered_by: "", notes: "" });
    },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  const getExpiryBadge = (expiry: string | null) => {
    if (!expiry) return null;
    const days = differenceInDays(new Date(expiry), new Date());
    if (days < 0) return <Badge variant="destructive">{t("inner.vaccineExpired")}</Badge>;
    if (days <= 30) return <Badge variant="destructive" className="flex items-center gap-1"><AlertTriangle className="h-3 w-3" />{days} {t("inner.dayUnit")}</Badge>;
    if (days <= 90) return <Badge variant="secondary">{days} {t("inner.dayUnit")}</Badge>;
    return <Badge variant="outline">{format(new Date(expiry), "yyyy.MM.dd")}</Badge>;
  };

  if (isLoading) return <div className="flex justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3"><Syringe className="h-6 w-6 text-secondary" /><h1 className="text-2xl font-bold">{t("inner.vaccinationRegistry")}</h1></div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button><Plus className="h-4 w-4 mr-1" /> {t("inner.addVaccination")}</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>{t("inner.newVaccination")}</DialogTitle></DialogHeader>
            <div className="space-y-4">
              <div><Label>{t("inner.vaccineName")} *</Label><Input value={form.vaccine_name} onChange={(e) => setForm((p) => ({ ...p, vaccine_name: e.target.value }))} placeholder={t("inner.vaccineNamePlaceholder")} /></div>
              <div className="grid grid-cols-2 gap-4">
                <div><Label>{t("inner.administeredDate")} *</Label><Input type="date" value={form.administered_date} onChange={(e) => setForm((p) => ({ ...p, administered_date: e.target.value }))} /></div>
                <div><Label>{t("inner.expiryDate")}</Label><Input type="date" value={form.expiry_date} onChange={(e) => setForm((p) => ({ ...p, expiry_date: e.target.value }))} /></div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div><Label>{t("inner.lotNumber")}</Label><Input value={form.lot_number} onChange={(e) => setForm((p) => ({ ...p, lot_number: e.target.value }))} /></div>
                <div><Label>{t("inner.administeredBy")}</Label><Input value={form.administered_by} onChange={(e) => setForm((p) => ({ ...p, administered_by: e.target.value }))} placeholder={t("inner.doctorNamePlaceholder")} /></div>
              </div>
              <div><Label>{t("inner.comment")}</Label><Textarea value={form.notes} onChange={(e) => setForm((p) => ({ ...p, notes: e.target.value }))} /></div>
              <Button onClick={() => addVacc.mutate()} disabled={addVacc.isPending} className="w-full">{addVacc.isPending ? t("inner.saving") : t("inner.save")}</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <TravelVaccinationAdvisor existingVaccines={(vaccinations ?? []).map(v => v.vaccine_name)} />

      <Card>
        <CardHeader><CardTitle className="text-lg">{t("inner.vaccinations")} ({vaccinations?.length ?? 0})</CardTitle></CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t("inner.vaccine")}</TableHead>
                <TableHead>{t("inner.administeredLabel")}</TableHead>
                <TableHead>{t("inner.expiryLabel")}</TableHead>
                <TableHead>{t("inner.lotNumber")}</TableHead>
                <TableHead>{t("inner.administeredBy")}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {(vaccinations ?? []).map((v) => (
                <TableRow key={v.id}>
                  <TableCell className="font-medium">{v.vaccine_name}</TableCell>
                  <TableCell>{format(new Date(v.administered_date), "yyyy.MM.dd", { locale: hu })}</TableCell>
                  <TableCell>{getExpiryBadge(v.expiry_date)}</TableCell>
                  <TableCell className="text-muted-foreground">{v.lot_number || "—"}</TableCell>
                  <TableCell>{v.administered_by || "—"}</TableCell>
                </TableRow>
              ))}
              {(!vaccinations || vaccinations.length === 0) && (
                <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">{t("inner.noVaccination")}</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}