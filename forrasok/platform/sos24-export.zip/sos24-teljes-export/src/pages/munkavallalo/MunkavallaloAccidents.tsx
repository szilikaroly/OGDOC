import { useTranslation } from "react-i18next";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { FileText } from "lucide-react";
import { format } from "date-fns";

export default function MunkavallaloAccidents() {
  const { t } = useTranslation();
  const { user } = useAuth();

  const { data: reports, isLoading } = useQuery({
    queryKey: ["my-accidents", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase.from("accident_reports" as any).select("*").eq("employee_id", user!.id).order("created_at", { ascending: false });
      if (error) throw error;
      return data || [];
    },
    enabled: !!user,
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="h-5 w-5" />
          {t("accident.myReports")}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex justify-center py-8"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>
        ) : !reports?.length ? (
          <p className="text-center py-8 text-muted-foreground">{t("accident.noReports")}</p>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t("accident.registrationNumber")}</TableHead>
                <TableHead>{t("accident.accidentDate")}</TableHead>
                <TableHead>{t("accident.injuryType")}</TableHead>
                <TableHead>{t("common.status")}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {reports.map((r: any) => (
                <TableRow key={r.id}>
                  <TableCell className="font-mono">{r.registration_number || "—"}</TableCell>
                  <TableCell>{r.accident_date ? format(new Date(r.accident_date), "yyyy.MM.dd") : "—"}</TableCell>
                  <TableCell>{r.injury_type_code || "—"}</TableCell>
                  <TableCell>
                    <Badge variant={r.status === "draft" ? "secondary" : "default"}>{t(`accident.status_${r.status}`)}</Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}
