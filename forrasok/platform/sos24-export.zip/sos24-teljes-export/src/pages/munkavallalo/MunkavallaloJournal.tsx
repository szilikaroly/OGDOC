import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { BookHeart, Plus, TrendingUp, Camera, Loader2 } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { format } from "date-fns";
import { hu } from "date-fns/locale";
import { useTranslation } from "react-i18next";
import FoodJournal from "@/components/FoodJournal";
import StoolJournal from "@/components/StoolJournal";

export default function MunkavallaloJournal() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [form, setForm] = useState({ blood_pressure_systolic: "", blood_pressure_diastolic: "", heart_rate: "", weight_kg: "", blood_sugar: "", temperature: "", notes: "" });

  const { data: entries, isLoading } = useQuery({
    queryKey: ["health-journal", user?.id],
    queryFn: async () => { const { data, error } = await supabase.from("health_journal").select("*").eq("user_id", user!.id).order("entry_date", { ascending: false }).limit(90); if (error) throw error; return data; },
    enabled: !!user,
  });

  const addEntry = useMutation({
    mutationFn: async () => {
      const row: Record<string, any> = { user_id: user!.id };
      if (form.blood_pressure_systolic) row.blood_pressure_systolic = Number(form.blood_pressure_systolic);
      if (form.blood_pressure_diastolic) row.blood_pressure_diastolic = Number(form.blood_pressure_diastolic);
      if (form.heart_rate) row.heart_rate = Number(form.heart_rate);
      if (form.weight_kg) row.weight_kg = Number(form.weight_kg);
      if (form.blood_sugar) row.blood_sugar = Number(form.blood_sugar);
      if (form.temperature) row.temperature = Number(form.temperature);
      if (form.notes) row.notes = form.notes;
      const { error } = await supabase.from("health_journal").insert(row as any);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["health-journal"] });
      toast({ title: t("inner.entrySaved") });
      setOpen(false);
      setForm({ blood_pressure_systolic: "", blood_pressure_diastolic: "", heart_rate: "", weight_kg: "", blood_sugar: "", temperature: "", notes: "" });
    },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  const handleBpPhotoAnalysis = async (file: File) => {
    setAiLoading(true);
    try {
      const reader = new FileReader();
      const base64 = await new Promise<string>((resolve) => {
        reader.onload = () => resolve((reader.result as string).split(",")[1]);
        reader.readAsDataURL(file);
      });
      const { data, error } = await supabase.functions.invoke("ai-health-image-analysis", {
        body: { mode: "blood_pressure", image_base64: base64, mime_type: file.type },
      });
      if (error) throw error;
      const r = data.result;
      setForm((p) => ({
        ...p,
        blood_pressure_systolic: r.systolic?.toString() || p.blood_pressure_systolic,
        blood_pressure_diastolic: r.diastolic?.toString() || p.blood_pressure_diastolic,
        heart_rate: r.heart_rate?.toString() || p.heart_rate,
      }));
      toast({ title: t("inner.aiAnalyzed") });
    } catch (e: any) {
      toast({ variant: "destructive", title: t("common.error"), description: e.message });
    } finally {
      setAiLoading(false);
    }
  };

  const chartData = [...(entries ?? [])].reverse().map((e) => ({
    date: format(new Date(e.entry_date), "MM.dd", { locale: hu }),
    systolic: e.blood_pressure_systolic,
    diastolic: e.blood_pressure_diastolic,
    heartRate: e.heart_rate,
    weight: e.weight_kg ? Number(e.weight_kg) : null,
  }));

  if (isLoading) return <div className="flex justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <BookHeart className="h-6 w-6 text-secondary" />
        <h1 className="text-2xl font-bold">{t("inner.healthJournal")}</h1>
      </div>

      <Tabs defaultValue="measurements" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="measurements">{t("inner.tabMeasurements")}</TabsTrigger>
          <TabsTrigger value="food">{t("inner.tabFood")}</TabsTrigger>
          <TabsTrigger value="stool">{t("inner.tabStool")}</TabsTrigger>
        </TabsList>

        <TabsContent value="measurements" className="space-y-6">
          <div className="flex justify-end">
            <Dialog open={open} onOpenChange={setOpen}>
              <DialogTrigger asChild><Button><Plus className="h-4 w-4 mr-1" /> {t("inner.newEntry")}</Button></DialogTrigger>
              <DialogContent>
                <DialogHeader><DialogTitle>{t("inner.dailyMeasurement")}</DialogTitle></DialogHeader>
                <div className="space-y-4">
                  <div className="flex gap-2">
                    <Button variant="outline" className="w-full" disabled={aiLoading} onClick={() => document.getElementById("bp-photo-input")?.click()}>
                      {aiLoading ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Camera className="h-4 w-4 mr-1" />}
                      {aiLoading ? t("inner.aiAnalyzing") : t("inner.aiAnalyzePhoto")}
                    </Button>
                    <input id="bp-photo-input" type="file" accept="image/*" capture="environment" className="hidden" onChange={(e) => e.target.files?.[0] && handleBpPhotoAnalysis(e.target.files[0])} />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div><Label>{t("inner.systolic")}</Label><Input type="number" value={form.blood_pressure_systolic} onChange={(e) => setForm((p) => ({ ...p, blood_pressure_systolic: e.target.value }))} placeholder="120" /></div>
                    <div><Label>{t("inner.diastolic")}</Label><Input type="number" value={form.blood_pressure_diastolic} onChange={(e) => setForm((p) => ({ ...p, blood_pressure_diastolic: e.target.value }))} placeholder="80" /></div>
                    <div><Label>{t("inner.pulseBpm")}</Label><Input type="number" value={form.heart_rate} onChange={(e) => setForm((p) => ({ ...p, heart_rate: e.target.value }))} placeholder="72" /></div>
                    <div><Label>{t("inner.weightKg")}</Label><Input type="number" step="0.1" value={form.weight_kg} onChange={(e) => setForm((p) => ({ ...p, weight_kg: e.target.value }))} placeholder="75.0" /></div>
                    <div><Label>{t("inner.bloodSugarMmol")}</Label><Input type="number" step="0.1" value={form.blood_sugar} onChange={(e) => setForm((p) => ({ ...p, blood_sugar: e.target.value }))} placeholder="5.5" /></div>
                    <div><Label>{t("inner.temperatureC")}</Label><Input type="number" step="0.1" value={form.temperature} onChange={(e) => setForm((p) => ({ ...p, temperature: e.target.value }))} placeholder="36.6" /></div>
                  </div>
                  <div><Label>{t("inner.comment")}</Label><Textarea value={form.notes} onChange={(e) => setForm((p) => ({ ...p, notes: e.target.value }))} /></div>
                  <Button className="w-full" onClick={() => addEntry.mutate()} disabled={addEntry.isPending}>{addEntry.isPending ? t("inner.saving") : t("inner.save")}</Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          {chartData.length > 1 && (
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader><CardTitle className="text-base flex items-center gap-2"><TrendingUp className="h-4 w-4" /> {t("inner.bloodPressureAndPulse")}</CardTitle></CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <LineChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" fontSize={12} />
                      <YAxis fontSize={12} />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="systolic" name={t("inner.systolicLabel")} stroke="hsl(var(--destructive))" dot={false} />
                      <Line type="monotone" dataKey="diastolic" name={t("inner.diastolicLabel")} stroke="hsl(var(--primary))" dot={false} />
                      <Line type="monotone" dataKey="heartRate" name={t("inner.pulseLabel")} stroke="hsl(var(--secondary))" dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
              <Card>
                <CardHeader><CardTitle className="text-base flex items-center gap-2"><TrendingUp className="h-4 w-4" /> {t("inner.bodyWeight")}</CardTitle></CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <LineChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" fontSize={12} />
                      <YAxis fontSize={12} domain={["auto", "auto"]} />
                      <Tooltip />
                      <Line type="monotone" dataKey="weight" name={t("inner.bodyWeightKg")} stroke="hsl(var(--accent-foreground))" dot={false} connectNulls />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          )}

          <Card>
            <CardHeader><CardTitle className="text-lg">{t("inner.lastEntries")}</CardTitle></CardHeader>
            <CardContent className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b text-left">
                    <th className="pb-2 pr-4">{t("inner.date")}</th>
                    <th className="pb-2 pr-4">{t("inner.bloodPressure")}</th>
                    <th className="pb-2 pr-4">{t("inner.heartRate")}</th>
                    <th className="pb-2 pr-4">{t("inner.weight")}</th>
                    <th className="pb-2 pr-4">{t("inner.bloodSugar")}</th>
                    <th className="pb-2">{t("inner.comment")}</th>
                  </tr>
                </thead>
                <tbody>
                  {(entries ?? []).map((e) => (
                    <tr key={e.id} className="border-b last:border-0">
                      <td className="py-2 pr-4">{format(new Date(e.entry_date), "yyyy.MM.dd", { locale: hu })}</td>
                      <td className="py-2 pr-4">{e.blood_pressure_systolic && e.blood_pressure_diastolic ? `${e.blood_pressure_systolic}/${e.blood_pressure_diastolic}` : "—"}</td>
                      <td className="py-2 pr-4">{e.heart_rate ?? "—"}</td>
                      <td className="py-2 pr-4">{e.weight_kg ? `${e.weight_kg} kg` : "—"}</td>
                      <td className="py-2 pr-4">{e.blood_sugar ? `${e.blood_sugar} mmol/L` : "—"}</td>
                      <td className="py-2 text-muted-foreground truncate max-w-[200px]">{e.notes || "—"}</td>
                    </tr>
                  ))}
                  {(!entries || entries.length === 0) && (
                    <tr><td colSpan={6} className="py-8 text-center text-muted-foreground">{t("inner.noEntryYet")}</td></tr>
                  )}
                </tbody>
              </table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="food">
          <FoodJournal />
        </TabsContent>

        <TabsContent value="stool">
          <StoolJournal />
        </TabsContent>
      </Tabs>
    </div>
  );
}
