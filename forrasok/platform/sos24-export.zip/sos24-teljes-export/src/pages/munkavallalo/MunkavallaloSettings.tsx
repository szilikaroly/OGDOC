import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Settings, Bell, Mail } from "lucide-react";
import ConnectedAccounts from "@/components/ConnectedAccounts";

interface Prefs {
  email_appointments: boolean;
  email_reminders: boolean;
  email_opinions: boolean;
  email_vaccinations: boolean;
  inapp_appointments: boolean;
  inapp_reminders: boolean;
  inapp_opinions: boolean;
  inapp_vaccinations: boolean;
}

const defaultPrefs: Prefs = {
  email_appointments: true,
  email_reminders: true,
  email_opinions: true,
  email_vaccinations: true,
  inapp_appointments: true,
  inapp_reminders: true,
  inapp_opinions: true,
  inapp_vaccinations: true,
};

export default function MunkavallaloSettings() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [prefs, setPrefs] = useState<Prefs>(defaultPrefs);

  const labelKeys: Record<string, string> = {
    appointments: "inner.appointmentReminders",
    reminders: "inner.expiryWarnings",
    opinions: "inner.opinionsExams",
    vaccinations: "inner.vaccinationExpiry",
  };

  const { data: savedPrefs } = useQuery({
    queryKey: ["notification-prefs", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("notification_preferences")
        .select("*")
        .eq("user_id", user!.id)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  useEffect(() => {
    if (savedPrefs) {
      setPrefs({
        email_appointments: savedPrefs.email_appointments,
        email_reminders: savedPrefs.email_reminders,
        email_opinions: savedPrefs.email_opinions,
        email_vaccinations: savedPrefs.email_vaccinations,
        inapp_appointments: savedPrefs.inapp_appointments,
        inapp_reminders: savedPrefs.inapp_reminders,
        inapp_opinions: savedPrefs.inapp_opinions,
        inapp_vaccinations: savedPrefs.inapp_vaccinations,
      });
    }
  }, [savedPrefs]);

  const save = useMutation({
    mutationFn: async () => {
      const { error } = await supabase
        .from("notification_preferences")
        .upsert({ user_id: user!.id, ...prefs }, { onConflict: "user_id" });
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["notification-prefs"] });
      toast({ title: t('inner.savedSettings') });
    },
    onError: (e: any) => toast({ variant: "destructive", title: t('common.error'), description: e.message }),
  });

  const categories = ["appointments", "reminders", "opinions", "vaccinations"] as const;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Settings className="h-6 w-6 text-secondary" />
        <h1 className="text-2xl font-bold">{t('inner.settingsTitle')}</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">{t('inner.notificationPrefs')}</CardTitle>
          <CardDescription>{t('inner.notificationPrefsDesc')}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="grid grid-cols-3 gap-4 text-sm font-medium text-muted-foreground border-b pb-2">
              <div>{t('inner.category')}</div>
              <div className="flex items-center gap-1"><Mail className="h-4 w-4" /> {t('inner.email')}</div>
              <div className="flex items-center gap-1"><Bell className="h-4 w-4" /> {t('inner.inApp')}</div>
            </div>
            {categories.map((cat) => (
              <div key={cat} className="grid grid-cols-3 gap-4 items-center">
                <Label className="text-sm">{t(labelKeys[cat])}</Label>
                <Switch
                  checked={prefs[`email_${cat}` as keyof Prefs]}
                  onCheckedChange={(v) => setPrefs((p) => ({ ...p, [`email_${cat}`]: v }))}
                />
                <Switch
                  checked={prefs[`inapp_${cat}` as keyof Prefs]}
                  onCheckedChange={(v) => setPrefs((p) => ({ ...p, [`inapp_${cat}`]: v }))}
                />
              </div>
            ))}
          </div>
          <Button className="mt-6" onClick={() => save.mutate()} disabled={save.isPending}>
            {save.isPending ? t('inner.saving') : t('common.save')}
          </Button>
        </CardContent>
      </Card>

      <ConnectedAccounts />
    </div>
  );
}
