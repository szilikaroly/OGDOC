import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Eye, Shield } from "lucide-react";
import { useTranslation } from "react-i18next";

export default function MunkavallaloDataAccess() {
  const { user } = useAuth();
  const { t, i18n } = useTranslation();

  const TABLE_LABELS: Record<string, string> = {
    examinations: t("dataAccess.examination"),
    medical_opinions: t("dataAccess.opinion"),
    patient_cards: t("dataAccess.patientCard"),
    documents: t("dataAccess.document"),
    referrals: t("dataAccess.referral"),
  };

  const ACTION_LABELS: Record<string, string> = {
    INSERT: t("dataAccess.insertAction"),
    UPDATE: t("dataAccess.updateAction"),
    DELETE: t("dataAccess.deleteAction"),
  };

  const { data: logs, isLoading } = useQuery({
    queryKey: ["my-audit-logs", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("audit_logs")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(100);

      if (error) throw error;

      // Fetch user names
      const userIds = [...new Set((data ?? []).map((l: any) => l.user_id).filter(Boolean))];
      let nameMap: Record<string, string> = {};
      if (userIds.length > 0) {
        const { data: profiles } = await supabase
          .from("profiles")
          .select("user_id, full_name")
          .in("user_id", userIds);
        nameMap = Object.fromEntries((profiles ?? []).map((p) => [p.user_id, p.full_name]));
      }

      return (data ?? []).map((l: any) => ({ ...l, user_name: nameMap[l.user_id] ?? t("dataAccess.system") }));
    },
    enabled: !!user,
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Shield className="h-6 w-6 text-secondary" />
        <h1 className="text-2xl font-bold">{t("dataAccess.title")}</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Eye className="h-5 w-5 text-muted-foreground" />
            {t("dataAccess.whoHasAccess")}
          </CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-muted-foreground space-y-2">
          <p>{t("dataAccess.gdprInfo")}</p>
          <p>{t("dataAccess.auditInfo")}</p>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="overflow-x-auto p-0">
          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" />
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t("dataAccess.timestamp")}</TableHead>
                  <TableHead>{t("dataAccess.performedBy")}</TableHead>
                  <TableHead>{t("dataAccess.type")}</TableHead>
                  <TableHead>{t("dataAccess.action")}</TableHead>
                  <TableHead>{t("dataAccess.details")}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {(logs ?? []).map((log: any) => (
                  <TableRow key={log.id}>
                    <TableCell className="whitespace-nowrap text-sm">
                      {new Date(log.created_at).toLocaleString(i18n.language === "hu" ? "hu-HU" : undefined)}
                    </TableCell>
                    <TableCell className="font-medium">{log.user_name}</TableCell>
                    <TableCell>
                      <Badge variant="secondary">
                        {TABLE_LABELS[log.table_name] ?? log.table_name}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">
                        {ACTION_LABELS[log.action] ?? log.action}
                      </Badge>
                    </TableCell>
                    <TableCell className="max-w-[200px] truncate text-sm text-muted-foreground">
                      {(log.changed_fields ?? []).join(", ") || t("dataAccess.newEntry")}
                    </TableCell>
                  </TableRow>
                ))}
                {(logs ?? []).length === 0 && (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                      {t("dataAccess.noEntries")}
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}