import PatientProfile from "@/components/PatientProfile";
export default function MunkavallaloProfile() {
  return <PatientProfile />;
}
