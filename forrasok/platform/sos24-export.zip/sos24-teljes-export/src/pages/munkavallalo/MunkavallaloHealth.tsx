import { useState, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { HeartPulse, Printer } from "lucide-react";
import AiAnalysisPanel from "@/components/AiAnalysisPanel";
import PatientCardForm from "@/components/PatientCardForm";
import PrintablePatientCard from "@/components/PrintablePatientCard";
import { useTranslation } from "react-i18next";

export default function MunkavallaloHealth() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const printRef = useRef<HTMLDivElement>(null);

  const { data: profile } = useQuery({
    queryKey: ["my-profile", user?.id],
    queryFn: async () => {
      const { data } = await supabase.from("profiles").select("full_name, taj_number, birth_date, birth_place, mother_name, address, phone, gender").eq("user_id", user!.id).single();
      return data;
    },
    enabled: !!user,
  });

  const { data: card, isLoading: cardLoading } = useQuery({
    queryKey: ["my-patient-card", user?.id],
    queryFn: async () => { const { data } = await supabase.from("patient_cards").select("*").eq("user_id", user!.id).single(); return data; },
    enabled: !!user,
  });

  const [cardForm, setCardForm] = useState<Record<string, any> | null>(null);
  const editingCard = cardForm !== null;

  const saveCard = useMutation({
    mutationFn: async () => {
      if (!cardForm) return;
      const payload = {
        user_id: user!.id,
        drug_allergies: cardForm.drug_allergies || null,
        chronic_diseases: cardForm.chronic_diseases || null,
        regular_medications: cardForm.regular_medications || null,
        family_history: cardForm.family_history || {},
        surgeries: cardForm.surgeries || null,
        smoking: cardForm.smoking || {},
        alcohol: cardForm.alcohol || null,
        last_chest_xray: cardForm.last_chest_xray || null,
        last_gynecology: cardForm.last_gynecology || null,
        pregnancies: cardForm.pregnancies || null,
        other_notes: cardForm.other_notes || null,
        occupation: cardForm.occupation || null,
        employer_name: cardForm.employer_name || null,
        marital_status: cardForm.marital_status || null,
        drivers_license: cardForm.drivers_license || false,
        previous_doctor: cardForm.previous_doctor || null,
        education: cardForm.education || null,
        professional_qual: cardForm.professional_qual || null,
        notification_address: cardForm.notification_address || null,
        sports_habit: cardForm.sports_habit || null,
        eating_habit: cardForm.eating_habit || null,
        occupation_history: cardForm.occupation_history || [],
        reported_occupational_diseases: cardForm.reported_occupational_diseases || null,
        military_service: cardForm.military_service || false,
        exposures: cardForm.exposures || {},
      };
      if (card) { const { error } = await supabase.from("patient_cards").update(payload).eq("id", card.id); if (error) throw error; }
      else { const { error } = await supabase.from("patient_cards").insert(payload); if (error) throw error; }
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["my-patient-card"] }); toast({ title: t("inner.patientCardSaved") }); setCardForm(null); },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  const startEditCard = () => {
    setCardForm({
      drug_allergies: card?.drug_allergies ?? "",
      chronic_diseases: card?.chronic_diseases ?? "",
      regular_medications: card?.regular_medications ?? "",
      family_history: card?.family_history ?? {},
      surgeries: card?.surgeries ?? "",
      smoking: card?.smoking ?? { status: "nem", amount: "", duration: "" },
      alcohol: card?.alcohol ?? "nem",
      last_chest_xray: card?.last_chest_xray ?? "",
      last_gynecology: card?.last_gynecology ?? "",
      pregnancies: card?.pregnancies ?? "",
      other_notes: card?.other_notes ?? "",
      occupation: card?.occupation ?? "",
      employer_name: card?.employer_name ?? "",
      marital_status: card?.marital_status ?? "",
      drivers_license: card?.drivers_license ?? false,
      previous_doctor: card?.previous_doctor ?? "",
      education: (card as any)?.education ?? "",
      professional_qual: (card as any)?.professional_qual ?? "",
      notification_address: (card as any)?.notification_address ?? "",
      sports_habit: (card as any)?.sports_habit ?? "",
      eating_habit: (card as any)?.eating_habit ?? "",
      occupation_history: (card as any)?.occupation_history ?? [],
      reported_occupational_diseases: (card as any)?.reported_occupational_diseases ?? "",
      military_service: (card as any)?.military_service ?? false,
      exposures: (card as any)?.exposures ?? {},
    });
  };

  const handlePrint = () => {
    const content = printRef.current;
    if (!content) return;
    const iframe = document.createElement("iframe");
    iframe.style.position = "absolute";
    iframe.style.width = "0";
    iframe.style.height = "0";
    iframe.style.border = "none";
    document.body.appendChild(iframe);
    const doc = iframe.contentWindow?.document;
    if (!doc) return;
    doc.open();
    doc.write(`<html><head><style>
      body { font-family: 'Times New Roman', serif; font-size: 11px; margin: 15mm; }
      table { border-collapse: collapse; width: 100%; margin-bottom: 8px; }
      td, th { border: 1px solid #000; padding: 2px 4px; }
      h2 { text-align: center; font-size: 14px; margin-bottom: 12px; }
      h3 { font-size: 12px; margin: 8px 0 4px; }
    </style></head><body>${content.innerHTML}</body></html>`);
    doc.close();
    iframe.contentWindow?.focus();
    iframe.contentWindow?.print();
    setTimeout(() => document.body.removeChild(iframe), 1000);
  };

  const { data: reports } = useQuery({
    queryKey: ["my-health-reports", user?.id],
    queryFn: async () => { const { data, error } = await supabase.from("health_reports").select("*").eq("user_id", user!.id).order("report_date", { ascending: false }); if (error) throw error; return data; },
    enabled: !!user,
  });

  const { data: journalEntries } = useQuery({
    queryKey: ["my-journal-for-measurements", user?.id],
    queryFn: async () => { const { data, error } = await supabase.from("health_journal").select("*").eq("user_id", user!.id).order("entry_date", { ascending: false }); if (error) throw error; return data; },
    enabled: !!user,
  });

  const mergedMeasurements = (() => {
    const items: Array<{ id: string; date: string; weight_kg: number | null; height_cm: number | null; blood_pressure_systolic: number | null; blood_pressure_diastolic: number | null; heart_rate: number | null; blood_sugar: number | null; source: string }> = [];
    (reports ?? []).forEach((r) => items.push({ id: r.id, date: r.report_date, weight_kg: r.weight_kg, height_cm: r.height_cm, blood_pressure_systolic: r.blood_pressure_systolic, blood_pressure_diastolic: r.blood_pressure_diastolic, heart_rate: r.heart_rate, blood_sugar: r.blood_sugar, source: "report" }));
    (journalEntries ?? []).forEach((j) => items.push({ id: j.id, date: j.entry_date, weight_kg: j.weight_kg, height_cm: null, blood_pressure_systolic: j.blood_pressure_systolic, blood_pressure_diastolic: j.blood_pressure_diastolic, heart_rate: j.heart_rate, blood_sugar: j.blood_sugar, source: "journal" }));
    items.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    return items;
  })();

  if (cardLoading) return <div className="flex items-center justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>;

  const smoking = card?.smoking as any ?? {};
  const familyHistory = card?.family_history as any ?? {};
  const occHistory = (card as any)?.occupation_history ?? [];
  const exposures = (card as any)?.exposures ?? {};

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3"><HeartPulse className="h-6 w-6 text-secondary" /><h1 className="text-2xl font-bold">{t("inner.healthData")}</h1></div>

      <Tabs defaultValue="torzskarton">
        <TabsList><TabsTrigger value="torzskarton">{t("inner.patientCard")}</TabsTrigger><TabsTrigger value="meresek">{t("inner.measurements")}</TabsTrigger><TabsTrigger value="ai">{t("inner.aiAnalysis")}</TabsTrigger></TabsList>

        <TabsContent value="torzskarton">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">{t("inner.patientCard")}</CardTitle>
                <div className="flex gap-2">
                  {!editingCard && card && <Button variant="outline" onClick={handlePrint}><Printer className="h-4 w-4 mr-2" />{t("common.print")}</Button>}
                  {!editingCard && <Button onClick={startEditCard}>{card ? t("inner.edit") : t("inner.fillForm")}</Button>}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {editingCard ? (
                <PatientCardForm
                  cardForm={cardForm!}
                  setCardForm={setCardForm as any}
                  onSave={() => saveCard.mutate()}
                  onCancel={() => setCardForm(null)}
                  isSaving={saveCard.isPending}
                  profile={profile}
                />
              ) : card ? (
                <div className="space-y-4">
                  {/* Személyes adatok */}
                  {profile && (
                    <div className="rounded-lg border bg-muted/30 p-3">
                      <h3 className="font-semibold text-sm mb-2">{t("patientProfile.personalData")}</h3>
                      <div className="grid gap-2 text-sm md:grid-cols-3">
                        <div><span className="text-muted-foreground">{t("patientProfile.fullName")}:</span> {profile.full_name || "—"}</div>
                        <div><span className="text-muted-foreground">{t("patientProfile.tajNumber")}:</span> {profile.taj_number || "—"}</div>
                        <div><span className="text-muted-foreground">{t("patientProfile.birthDate")}:</span> {profile.birth_place || ""} {profile.birth_date ? new Date(profile.birth_date).toLocaleDateString("hu-HU") : ""}</div>
                        <div><span className="text-muted-foreground">{t("patientProfile.motherName")}:</span> {profile.mother_name || "—"}</div>
                        <div><span className="text-muted-foreground">{t("patientProfile.address")}:</span> {profile.address || "—"}</div>
                      </div>
                    </div>
                  )}

                  <div className="grid gap-3 text-sm md:grid-cols-2">
                    <div><span className="text-muted-foreground">{t("patientProfile.education")}:</span> {(card as any).education || "—"}</div>
                    <div><span className="text-muted-foreground">{t("patientProfile.professionalQual")}:</span> {(card as any).professional_qual || "—"}</div>
                    <div><span className="text-muted-foreground">{t("inner.occupationLabel")}:</span> {card.occupation || "—"}</div>
                    <div><span className="text-muted-foreground">{t("inner.workplace")}:</span> {card.employer_name || "—"}</div>
                    <div><span className="text-muted-foreground">{t("inner.maritalStatus")}:</span> {card.marital_status || "—"}</div>
                    <div><span className="text-muted-foreground">{t("patientProfile.notificationAddress")}:</span> {(card as any).notification_address || "—"}</div>
                    <div><span className="text-muted-foreground">{t("inner.drugAllergyLabel")}:</span> {card.drug_allergies || "—"}</div>
                    <div><span className="text-muted-foreground">{t("inner.chronicDiseasesLabel")}:</span> {card.chronic_diseases || "—"}</div>
                    <div><span className="text-muted-foreground">{t("inner.regularMedsLabel")}:</span> {card.regular_medications || "—"}</div>
                    <div><span className="text-muted-foreground">{t("inner.surgeriesLabel")}:</span> {card.surgeries || "—"}</div>
                    <div><span className="text-muted-foreground">{t("inner.smokingLabel")}:</span> {smoking.status === "igen" ? t("patientProfile.smokingYesDesc", { amount: smoking.amount || "?" }) : smoking.status === "leszokott" ? t("patientProfile.smokingQuitDesc") : t("patientProfile.smokingNoDesc")}</div>
                    <div><span className="text-muted-foreground">{t("inner.alcoholLabel")}:</span> {card.alcohol === "alkalomszeruen" ? t("patientProfile.alcoholOccasional") : card.alcohol === "rendszeresen" ? t("patientProfile.alcoholRegular") : t("patientProfile.alcoholNo")}</div>
                    <div><span className="text-muted-foreground">{t("patientProfile.sportsHabit")}:</span> {(card as any).sports_habit === "rendszeres" ? t("patientProfile.sportRegular") : (card as any).sports_habit === "rendszertelen" ? t("patientProfile.sportIrregular") : t("patientProfile.sportNone")}</div>
                    <div><span className="text-muted-foreground">{t("patientProfile.eatingHabit")}:</span> {(card as any).eating_habit === "korszeru" ? t("patientProfile.eatingModern") : (card as any).eating_habit === "korszerutlen" ? t("patientProfile.eatingOutdated") : "—"}</div>
                    <div><span className="text-muted-foreground">{t("inner.hasDriversLicense")}:</span> {card.drivers_license ? t("inner.driversLicenseYes") : t("inner.driversLicenseNo")}</div>
                    <div><span className="text-muted-foreground">{t("patientProfile.militaryService")}:</span> {(card as any).military_service ? t("patientProfile.militaryYes") : t("patientProfile.militaryNo")}</div>
                    <div><span className="text-muted-foreground">{t("patientProfile.occupationalDiseases")}:</span> {(card as any).reported_occupational_diseases || "—"}</div>
                    <div><span className="text-muted-foreground">{t("inner.previousDoctor")}:</span> {card.previous_doctor || "—"}</div>
                  </div>

                  {/* Családi anamnézis */}
                  {Object.keys(familyHistory).length > 0 && (
                    <div>
                      <h4 className="font-semibold text-sm mb-1">{t("patientProfile.familyHistory")}</h4>
                      <div className="text-sm text-muted-foreground">
                        {Object.entries(familyHistory).map(([member, organs]: [string, any]) => {
                          const active = Object.entries(organs ?? {}).filter(([, v]) => v).map(([k]) => k);
                          return active.length > 0 ? <div key={member}><span className="font-medium">{member === "apa" ? t("patientProfile.fatherLabel") : member === "anya" ? t("patientProfile.motherLabel") : t("patientProfile.siblingLabel")}:</span> {active.join(", ")}</div> : null;
                        })}
                      </div>
                    </div>
                  )}

                  {/* Foglalkozási anamnézis */}
                  {occHistory.length > 0 && (
                    <div>
                      <h4 className="font-semibold text-sm mb-1">{t("patientProfile.occupationHistory")}</h4>
                      <div className="text-sm text-muted-foreground">
                        {occHistory.map((item: any, i: number) => (
                          <div key={i}>{item.position} — {item.exposure} ({item.duration_years} év)</div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Kockázati expozíciók */}
                  {Object.keys(exposures).some((k) => exposures[k]?.length > 0) && (
                    <div>
                      <h4 className="font-semibold text-sm mb-1">{t("patientProfile.riskExposures")}</h4>
                      <div className="text-sm text-muted-foreground">
                        {Object.entries(exposures).map(([cat, items]: [string, any]) =>
                          items?.length > 0 ? <div key={cat}><span className="font-medium capitalize">{cat}:</span> {items.join(", ")}</div> : null
                        )}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <p className="text-muted-foreground">{t("inner.noPatientCardYet")}</p>
              )}
            </CardContent>
          </Card>

          {/* Hidden printable */}
          {card && profile && (
            <PrintablePatientCard ref={printRef} profile={profile} card={card as any} />
          )}
        </TabsContent>

        <TabsContent value="meresek">
          <Card>
            <CardHeader><CardTitle className="text-lg">{t("inner.healthMeasurements")}</CardTitle></CardHeader>
            <CardContent className="overflow-x-auto">
              <Table>
                <TableHeader><TableRow><TableHead>{t("inner.date")}</TableHead><TableHead>{t("inner.weight")}</TableHead><TableHead>{t("inner.height")}</TableHead><TableHead>{t("inner.bloodPressure")}</TableHead><TableHead>{t("inner.heartRate")}</TableHead><TableHead>{t("inner.bloodSugar")}</TableHead><TableHead>{t("inner.source")}</TableHead></TableRow></TableHeader>
                <TableBody>
                  {mergedMeasurements.map((r) => (
                    <TableRow key={`${r.source}-${r.id}`}>
                      <TableCell>{new Date(r.date).toLocaleDateString("hu-HU")}</TableCell>
                      <TableCell>{r.weight_kg ? `${r.weight_kg} kg` : "—"}</TableCell>
                      <TableCell>{r.height_cm ? `${r.height_cm} cm` : "—"}</TableCell>
                      <TableCell>{r.blood_pressure_systolic && r.blood_pressure_diastolic ? `${r.blood_pressure_systolic}/${r.blood_pressure_diastolic}` : "—"}</TableCell>
                      <TableCell>{r.heart_rate ?? "—"}</TableCell>
                      <TableCell>{r.blood_sugar ? `${r.blood_sugar}` : "—"}</TableCell>
                      <TableCell><Badge variant={r.source === "journal" ? "secondary" : "outline"}>{r.source === "journal" ? t("inner.journal") : t("inner.doctorReport")}</Badge></TableCell>
                    </TableRow>
                  ))}
                  {mergedMeasurements.length === 0 && <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-8">{t("inner.noMeasurement")}</TableCell></TableRow>}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="ai">
          <Card>
            <CardHeader><CardTitle className="text-lg">{t("inner.healthTrendAnalysis")}</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground">{t("inner.aiTrendDesc")}</p>
              {mergedMeasurements.length >= 2 ? (
                <AiAnalysisPanel type="anomaly_detection" data={{ reports: mergedMeasurements }} title={t("inner.anomalyDetection")} buttonLabel={t("inner.analyzeMeasurements")} variant="default" />
              ) : (
                <p className="text-muted-foreground text-sm">{t("inner.minMeasurementsNeeded")}</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
