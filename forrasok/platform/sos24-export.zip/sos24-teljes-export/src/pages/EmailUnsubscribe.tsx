import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle, XCircle, Loader2, MailX } from "lucide-react";

type Status = "loading" | "valid" | "already" | "invalid" | "success" | "error";

const EmailUnsubscribe = () => {
  const [searchParams] = useSearchParams();
  const token = searchParams.get("token");
  const [status, setStatus] = useState<Status>("loading");
  const [processing, setProcessing] = useState(false);

  useEffect(() => {
    if (!token) { setStatus("invalid"); return; }

    const validate = async () => {
      try {
        const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
        const anonKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
        const res = await fetch(
          `${supabaseUrl}/functions/v1/handle-email-unsubscribe?token=${token}`,
          { headers: { apikey: anonKey } }
        );
        const data = await res.json();
        if (!res.ok) { setStatus("invalid"); return; }
        if (data.valid === false && data.reason === "already_unsubscribed") {
          setStatus("already");
        } else if (data.valid) {
          setStatus("valid");
        } else {
          setStatus("invalid");
        }
      } catch { setStatus("error"); }
    };
    validate();
  }, [token]);

  const handleUnsubscribe = async () => {
    setProcessing(true);
    try {
      const { data, error } = await supabase.functions.invoke("handle-email-unsubscribe", {
        body: { token },
      });
      if (error) throw error;
      if (data?.success) { setStatus("success"); }
      else if (data?.reason === "already_unsubscribed") { setStatus("already"); }
      else { setStatus("error"); }
    } catch { setStatus("error"); }
    finally { setProcessing(false); }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4">
            {status === "loading" && <Loader2 className="h-12 w-12 animate-spin text-muted-foreground" />}
            {status === "valid" && <MailX className="h-12 w-12 text-primary" />}
            {status === "success" && <CheckCircle className="h-12 w-12 text-primary" />}
            {status === "already" && <CheckCircle className="h-12 w-12 text-muted-foreground" />}
            {(status === "invalid" || status === "error") && <XCircle className="h-12 w-12 text-destructive" />}
          </div>
          <CardTitle>
            {status === "loading" && "Ellenőrzés..."}
            {status === "valid" && "Leiratkozás megerősítése"}
            {status === "success" && "Sikeresen leiratkozott"}
            {status === "already" && "Már leiratkozott"}
            {status === "invalid" && "Érvénytelen link"}
            {status === "error" && "Hiba történt"}
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center space-y-4">
          {status === "valid" && (
            <>
              <p className="text-muted-foreground text-sm">
                Biztosan le szeretne iratkozni az e-mail értesítésekről?
              </p>
              <Button onClick={handleUnsubscribe} disabled={processing} variant="destructive">
                {processing ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                Leiratkozás
              </Button>
            </>
          )}
          {status === "success" && (
            <p className="text-muted-foreground text-sm">
              Nem fog több e-mail értesítést kapni. Ha meggondolja magát, lépjen be fiókjába.
            </p>
          )}
          {status === "already" && (
            <p className="text-muted-foreground text-sm">
              Ez az e-mail cím már korábban leiratkozott.
            </p>
          )}
          {status === "invalid" && (
            <p className="text-muted-foreground text-sm">
              A leiratkozási link érvénytelen vagy lejárt.
            </p>
          )}
          {status === "error" && (
            <p className="text-muted-foreground text-sm">
              Hiba történt a feldolgozás során. Kérjük, próbálja újra később.
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default EmailUnsubscribe;
