import { useTranslation } from "react-i18next";
import { LayoutDashboard, Users, Calendar, FileText, ClipboardList, MessageSquare, FolderOpen, Pill, Syringe, FileBadge, Heart, FlaskConical } from "lucide-react";
import DashboardLayout, { type NavItem } from "@/components/DashboardLayout";
import { useUnreadMessages } from "@/hooks/use-unread-messages";

export default function HaziorvosLayout() {
  const { t } = useTranslation();
  const unread = useUnreadMessages();
  const NAV: NavItem[] = [
    { title: t('dashboard.overview'), url: "/haziorvos", icon: LayoutDashboard },
    { title: t('dashboard.patients'), url: "/haziorvos/patients", icon: Users },
    { title: t('dashboard.appointments'), url: "/haziorvos/appointments", icon: Calendar },
    { title: t('nav.prescriptionRequests'), url: "/haziorvos/med-requests", icon: Pill },
    { title: t('nav.requests'), url: "/haziorvos/requests", icon: FileText },
    { title: t('dashboard.certificates'), url: "/haziorvos/certificates", icon: FileBadge },
    { title: t('dashboard.questionnaires'), url: "/haziorvos/questionnaires", icon: ClipboardList },
    { title: t('dashboard.documents'), url: "/haziorvos/documents", icon: FolderOpen },
    { title: t('dashboard.vaccinations'), url: "/haziorvos/vaccinations", icon: Syringe },
    { title: t('dashboard.healthPlans'), url: "/haziorvos/health-plans", icon: Heart },
    { title: t('dashboard.labRequests'), url: "/haziorvos/lab-requests", icon: FlaskConical },
    { title: t('dashboard.messages'), url: "/haziorvos/messages", icon: MessageSquare, badge: unread },
  ];
  return <DashboardLayout navItems={NAV} groupLabel={t('roles.haziorvos')} />;
}
