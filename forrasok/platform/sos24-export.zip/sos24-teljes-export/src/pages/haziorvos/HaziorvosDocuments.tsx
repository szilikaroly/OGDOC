import { useTranslation } from "react-i18next";
import { FileText } from "lucide-react";
import DocumentBrowser from "@/components/DocumentBrowser";

export default function HaziorvosDocuments() {
  const { t } = useTranslation();
  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <FileText className="h-6 w-6 text-secondary" />
        <h1 className="text-2xl font-bold">{t('inner.documents')}</h1>
      </div>
      <DocumentBrowser />
    </div>
  );
}
