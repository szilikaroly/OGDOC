import { useTranslation } from "react-i18next";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/contexts/AuthContext";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Users, Calendar, FileText } from "lucide-react";
import DoctorSignatureUpload from "@/components/DoctorSignatureUpload";
import { BarChart, Bar, PieChart, Pie, Cell, ResponsiveContainer, XAxis, YAxis, Tooltip } from "recharts";
import { format, subMonths, startOfMonth } from "date-fns";

const STATUS_COLORS: Record<string, string> = {
  pending: "hsl(var(--chart-3))",
  approved: "hsl(var(--chart-2))",
  rejected: "hsl(var(--chart-1))",
  completed: "hsl(var(--chart-4))",
};

export default function HaziorvosDashboard() {
  const { t } = useTranslation();
  const { profile } = useAuth();

  const STATUS_LABELS: Record<string, string> = {
    pending: t("page.pending"), approved: t("page.approved"),
    rejected: t("page.rejected"), completed: t("page.done"),
  };

  const { data: patientCount } = useQuery({
    queryKey: ["haziorvos-patients-count"],
    queryFn: async () => {
      const { count } = await supabase.from("profiles").select("id", { count: "exact", head: true });
      return count ?? 0;
    },
  });

  const { data: todayAppointments } = useQuery({
    queryKey: ["haziorvos-today-appointments"],
    queryFn: async () => {
      const today = new Date().toISOString().split("T")[0];
      const { count } = await supabase.from("appointments").select("id", { count: "exact", head: true }).gte("created_at", `${today}T00:00:00`).lt("created_at", `${today}T23:59:59`);
      return count ?? 0;
    },
  });

  const { data: openRequests } = useQuery({
    queryKey: ["haziorvos-open-requests"],
    queryFn: async () => {
      const { count } = await supabase.from("requests").select("id", { count: "exact", head: true }).eq("status", "pending");
      return count ?? 0;
    },
  });

  const { data: monthlyRequests } = useQuery({
    queryKey: ["haziorvos-monthly-requests"],
    queryFn: async () => {
      const sixMonthsAgo = subMonths(new Date(), 6).toISOString();
      const { data } = await supabase.from("requests").select("created_at").gte("created_at", sixMonthsAgo);
      const buckets: Record<string, number> = {};
      for (let i = 5; i >= 0; i--) {
        buckets[format(subMonths(new Date(), i), "yyyy-MM")] = 0;
      }
      data?.forEach((r) => {
        const m = r.created_at.substring(0, 7);
        if (buckets[m] !== undefined) buckets[m]++;
      });
      return Object.entries(buckets).map(([month, count]) => ({
        month: format(startOfMonth(new Date(month + "-01")), "MMM"),
        [t("page.request")]: count,
      }));
    },
  });

  const { data: statusDist } = useQuery({
    queryKey: ["haziorvos-status-dist"],
    queryFn: async () => {
      const { data } = await supabase.from("requests").select("status");
      const counts: Record<string, number> = {};
      data?.forEach((r) => { counts[r.status] = (counts[r.status] || 0) + 1; });
      return Object.entries(counts).map(([name, value]) => ({
        name: STATUS_LABELS[name] || name, value,
        color: STATUS_COLORS[name] || "hsl(var(--chart-5))",
      }));
    },
  });

  const stats = [
    { label: t("page.patients"), icon: Users, value: patientCount ?? "—" },
    { label: t("page.todayAppointments"), icon: Calendar, value: todayAppointments ?? "—" },
    { label: t("page.openRequests"), icon: FileText, value: openRequests ?? "—" },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">{t("page.welcomeDoctor", { name: profile?.full_name })}</h1>
        <p className="text-muted-foreground">{t("page.gpOverview")}</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        {stats.map((s) => (
          <Card key={s.label} className="card-luxury">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">{s.label}</CardTitle>
              <s.icon className="h-5 w-5 text-secondary" />
            </CardHeader>
            <CardContent><p className="text-2xl font-bold">{s.value}</p></CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader><CardTitle className="text-base">{t("page.monthlyRequests")}</CardTitle></CardHeader>
          <CardContent>
            {monthlyRequests?.length ? (
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={monthlyRequests}>
                  <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                  <YAxis allowDecimals={false} />
                  <Tooltip />
                  <Bar dataKey={t("page.request")} fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : <p className="text-muted-foreground text-sm">{t("common.noData")}</p>}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">{t("page.requestStatusDist")}</CardTitle></CardHeader>
          <CardContent>
            {statusDist?.length ? (
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie data={statusDist} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
                    {statusDist.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            ) : <p className="text-muted-foreground text-sm">{t("common.noData")}</p>}
          </CardContent>
        </Card>
      </div>

      <DoctorSignatureUpload />
    </div>
  );
}
