import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { FileText, Check, X, Eye } from "lucide-react";
import { useState } from "react";
import AiTranslateButton from "@/components/AiTranslateButton";

export default function HaziorvosRequests() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [respondTo, setRespondTo] = useState<any>(null);
  const [response, setResponse] = useState("");

  const STATUS_LABELS: Record<string, string> = {
    pending: t('inner.pending'), approved: t('inner.approved'), rejected: t('inner.rejected'), completed: t('inner.completed'),
  };

  const { data: requests, isLoading } = useQuery({
    queryKey: ["haziorvos-requests"],
    queryFn: async () => {
      const { data, error } = await supabase.from("requests").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      const ids = [...new Set(data.map((r) => r.requester_id))];
      const { data: profiles } = await supabase.from("profiles").select("user_id, full_name").in("user_id", ids);
      return data.map((r) => ({
        ...r,
        requester_name: (profiles ?? []).find((p) => p.user_id === r.requester_id)?.full_name ?? "—",
      }));
    },
  });

  const respond = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const { error } = await supabase.from("requests").update({ status: status as any, response: response || null }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["haziorvos-requests"] });
      toast({ title: t('inner.requestUpdated') });
      setRespondTo(null);
      setResponse("");
    },
  });

  if (isLoading) {
    return <div className="flex items-center justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <FileText className="h-6 w-6 text-secondary" />
        <h1 className="text-2xl font-bold">{t('inner.requests')}</h1>
      </div>
      <Card>
        <CardHeader><CardTitle className="text-lg">{t('inner.receivedRequests')} ({requests?.length ?? 0})</CardTitle></CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t('inner.requester')}</TableHead>
                <TableHead>{t('inner.type')}</TableHead>
                <TableHead>{t('inner.subject')}</TableHead>
                <TableHead>{t('inner.status')}</TableHead>
                <TableHead>{t('inner.date')}</TableHead>
                <TableHead>{t('inner.actions')}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {(requests ?? []).map((r) => (
                <TableRow key={r.id}>
                  <TableCell className="font-medium">{r.requester_name}</TableCell>
                  <TableCell>{r.type}</TableCell>
                  <TableCell className="max-w-[200px]">
                    <span className="truncate inline-block max-w-[180px] align-middle">{r.subject || "—"}</span>
                    {r.subject && <AiTranslateButton text={r.subject} className="inline-flex align-middle ml-1" />}
                  </TableCell>
                  <TableCell>
                    <Badge variant={r.status === "approved" ? "default" : r.status === "rejected" ? "destructive" : "secondary"}>
                      {STATUS_LABELS[r.status] ?? r.status}
                    </Badge>
                  </TableCell>
                  <TableCell>{new Date(r.created_at).toLocaleDateString("hu-HU")}</TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      <Button size="sm" variant="ghost" onClick={() => { setRespondTo(r); setResponse(r.response ?? ""); }}>
                        <Eye className="h-4 w-4" />
                      </Button>
                      {r.status === "pending" && (
                        <>
                          <Button size="sm" variant="ghost" onClick={() => respond.mutate({ id: r.id, status: "approved" })}><Check className="h-4 w-4 text-green-500" /></Button>
                          <Button size="sm" variant="ghost" onClick={() => respond.mutate({ id: r.id, status: "rejected" })}><X className="h-4 w-4 text-destructive" /></Button>
                        </>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
              {(requests ?? []).length === 0 && (
                <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-8">{t('inner.noRequest')}</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={!!respondTo} onOpenChange={(open) => !open && setRespondTo(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>{t('inner.requestDetails')}</DialogTitle></DialogHeader>
          {respondTo && (
            <div className="space-y-3">
              <div><span className="text-muted-foreground text-sm">{t('inner.requester')}:</span> <span className="font-medium">{respondTo.requester_name}</span></div>
              <div><span className="text-muted-foreground text-sm">{t('inner.type')}:</span> {respondTo.type}</div>
              <div>
                <span className="text-muted-foreground text-sm">{t('inner.description')}:</span>
                {respondTo.description && <AiTranslateButton text={respondTo.description} size="sm" className="inline-flex align-middle ml-1" />}
                <p className="mt-1">{respondTo.description || "—"}</p>
              </div>
              {respondTo.response && (
                <div>
                  <span className="text-muted-foreground text-sm">{t('inner.respond')}:</span>
                  <AiTranslateButton text={respondTo.response} size="sm" className="inline-flex align-middle ml-1" />
                  <p className="mt-1">{respondTo.response}</p>
                </div>
              )}
              <div className="space-y-1.5">
                <span className="text-muted-foreground text-sm">{t('inner.respond')}:</span>
                <Textarea value={response} onChange={(e) => setResponse(e.target.value)} rows={3} />
              </div>
              {respondTo.status === "pending" && (
                <div className="flex gap-2">
                  <Button className="flex-1" onClick={() => respond.mutate({ id: respondTo.id, status: "approved" })}>{t('inner.accept')}</Button>
                  <Button className="flex-1" variant="destructive" onClick={() => respond.mutate({ id: respondTo.id, status: "rejected" })}>{t('inner.reject')}</Button>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
