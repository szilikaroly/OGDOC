import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Users, Eye, Search } from "lucide-react";
import BulkPatientImport from "@/components/BulkPatientImport";

export default function HaziorvosPatients() {
  const { t } = useTranslation();
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [selectedPatient, setSelectedPatient] = useState<any>(null);

  const { data: profiles, isLoading } = useQuery({
    queryKey: ["haziorvos-patients"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("user_id, full_name, taj_number, birth_date, phone, gender, blood_type, address")
        .order("full_name");
      if (error) throw error;
      return data;
    },
  });

  const { data: patientCard } = useQuery({
    queryKey: ["patient-card", selectedPatient?.user_id],
    queryFn: async () => {
      const { data } = await supabase
        .from("patient_cards")
        .select("*")
        .eq("user_id", selectedPatient!.user_id)
        .single();
      return data;
    },
    enabled: !!selectedPatient,
  });

  const filtered = (profiles ?? []).filter((p) =>
    p.full_name.toLowerCase().includes(search.toLowerCase()) ||
    (p.taj_number ?? "").includes(search)
  );

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Users className="h-6 w-6 text-secondary" />
          <h1 className="text-2xl font-bold">{t('inner.patients')}</h1>
        </div>
        <BulkPatientImport targetRole="praxistag" onComplete={() => qc.invalidateQueries({ queryKey: ["haziorvos-patients"] })} />
      </div>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder={t('inner.searchByNameOrTaj')}
          className="pl-9"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">{t('inner.patients')} ({filtered.length})</CardTitle>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t('inner.name')}</TableHead>
                <TableHead>{t('inner.tajNumber')}</TableHead>
                <TableHead>{t('inner.birthDate')}</TableHead>
                <TableHead>{t('inner.phone')}</TableHead>
                <TableHead>{t('inner.gender')}</TableHead>
                <TableHead className="w-20">{t('common.details')}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((p) => (
                <TableRow key={p.user_id}>
                  <TableCell className="font-medium">{p.full_name}</TableCell>
                  <TableCell>{p.taj_number || "—"}</TableCell>
                  <TableCell>{p.birth_date ? new Date(p.birth_date).toLocaleDateString("hu-HU") : "—"}</TableCell>
                  <TableCell>{p.phone || "—"}</TableCell>
                  <TableCell>{p.gender === "ferfi" ? t('inner.male') : p.gender === "no" ? t('inner.female') : p.gender ?? "—"}</TableCell>
                  <TableCell>
                    <Button size="sm" variant="ghost" onClick={() => setSelectedPatient(p)}>
                      <Eye className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={!!selectedPatient} onOpenChange={(open) => !open && setSelectedPatient(null)}>
        <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{selectedPatient?.full_name} — {t('inner.patientCardTitle')}</DialogTitle>
          </DialogHeader>
          {selectedPatient && (
            <div className="space-y-3 text-sm">
              <div className="grid grid-cols-2 gap-2">
                <div><span className="text-muted-foreground">{t('inner.taj')}:</span> {selectedPatient.taj_number || "—"}</div>
                <div><span className="text-muted-foreground">{t('inner.bloodType')}:</span> {selectedPatient.blood_type || "—"}</div>
                <div><span className="text-muted-foreground">{t('inner.birthDate')}:</span> {selectedPatient.birth_date ? new Date(selectedPatient.birth_date).toLocaleDateString("hu-HU") : "—"}</div>
                <div><span className="text-muted-foreground">{t('inner.address')}:</span> {selectedPatient.address || "—"}</div>
              </div>
              {patientCard ? (
                <div className="space-y-2 border-t pt-3">
                  <h3 className="font-semibold">{t('inner.patientCardData')}</h3>
                  <div><span className="text-muted-foreground">{t('inner.drugAllergies')}:</span> {patientCard.drug_allergies || "—"}</div>
                  <div><span className="text-muted-foreground">{t('inner.chronicDiseases')}:</span> {patientCard.chronic_diseases || "—"}</div>
                  <div><span className="text-muted-foreground">{t('inner.regularMedications')}:</span> {patientCard.regular_medications || "—"}</div>
                  <div><span className="text-muted-foreground">{t('inner.surgeries')}:</span> {patientCard.surgeries || "—"}</div>
                  <div><span className="text-muted-foreground">{t('inner.smoking')}:</span> {typeof patientCard.smoking === "object" && patientCard.smoking !== null ? (patientCard.smoking as any).status || "—" : "—"}</div>
                  <div><span className="text-muted-foreground">{t('inner.alcohol')}:</span> {patientCard.alcohol || "—"}</div>
                  <div><span className="text-muted-foreground">{t('inner.occupation')}:</span> {patientCard.occupation || "—"}</div>
                </div>
              ) : (
                <p className="text-muted-foreground pt-3 border-t">{t('inner.noPatientCard')}</p>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
