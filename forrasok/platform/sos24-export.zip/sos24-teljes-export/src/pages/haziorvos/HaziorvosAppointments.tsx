import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Calendar, Check, X } from "lucide-react";

export default function HaziorvosAppointments() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const qc = useQueryClient();

  const STATUS_LABELS: Record<string, string> = {
    pending: t('inner.pending'), confirmed: t('inner.confirmed'), cancelled: t('inner.cancelled'), completed: t('inner.completed'), no_show: t('inner.noShow'),
  };

  const { data: appointments, isLoading } = useQuery({
    queryKey: ["haziorvos-appointments"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("appointments")
        .select("id, patient_id, doctor_id, status, notes, created_at, slot_id")
        .order("created_at", { ascending: false });
      if (error) throw error;
      const ids = [...new Set([...data.map((a) => a.patient_id), ...data.filter((a) => a.doctor_id).map((a) => a.doctor_id!)])];
      const { data: profiles } = await supabase.from("profiles").select("user_id, full_name").in("user_id", ids);
      return data.map((a) => ({
        ...a,
        patient_name: (profiles ?? []).find((p) => p.user_id === a.patient_id)?.full_name ?? "—",
      }));
    },
  });

  const updateStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const { error } = await supabase.from("appointments").update({ status: status as any }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["haziorvos-appointments"] });
      toast({ title: t('inner.appointmentStatusUpdated') });
    },
  });

  if (isLoading) {
    return <div className="flex items-center justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Calendar className="h-6 w-6 text-secondary" />
        <h1 className="text-2xl font-bold">{t('inner.appointments')}</h1>
      </div>
      <Card>
        <CardHeader><CardTitle className="text-lg">{t('inner.appointments')} ({appointments?.length ?? 0})</CardTitle></CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t('inner.patient')}</TableHead>
                <TableHead>{t('inner.status')}</TableHead>
                <TableHead>{t('inner.notes')}</TableHead>
                <TableHead>{t('inner.date')}</TableHead>
                <TableHead>{t('inner.actions')}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {(appointments ?? []).map((a) => (
                <TableRow key={a.id}>
                  <TableCell className="font-medium">{a.patient_name}</TableCell>
                  <TableCell>
                    <Badge variant={a.status === "confirmed" ? "default" : a.status === "cancelled" ? "destructive" : "secondary"}>
                      {STATUS_LABELS[a.status] ?? a.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="max-w-[200px] truncate">{a.notes || "—"}</TableCell>
                  <TableCell>{new Date(a.created_at).toLocaleDateString("hu-HU")}</TableCell>
                  <TableCell>
                    {a.status === "pending" && (
                      <div className="flex gap-1">
                        <Button size="sm" variant="ghost" onClick={() => updateStatus.mutate({ id: a.id, status: "confirmed" })}><Check className="h-4 w-4 text-green-500" /></Button>
                        <Button size="sm" variant="ghost" onClick={() => updateStatus.mutate({ id: a.id, status: "cancelled" })}><X className="h-4 w-4 text-destructive" /></Button>
                      </div>
                    )}
                    {a.status === "confirmed" && (
                      <Button size="sm" variant="ghost" onClick={() => updateStatus.mutate({ id: a.id, status: "completed" })}>
                        <Check className="h-4 w-4" /> {t('inner.completed')}
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              ))}
              {(appointments ?? []).length === 0 && (
                <TableRow><TableCell colSpan={5} className="text-center text-muted-foreground py-8">{t('inner.noAppointment')}</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
