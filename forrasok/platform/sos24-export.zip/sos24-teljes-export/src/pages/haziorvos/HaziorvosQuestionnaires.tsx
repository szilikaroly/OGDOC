import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { ClipboardList, Send, Brain, Loader2 } from "lucide-react";
import ReactMarkdown from "react-markdown";

export default function HaziorvosQuestionnaires() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [assignDialogOpen, setAssignDialogOpen] = useState(false);
  const [selectedPatient, setSelectedPatient] = useState("");
  const [selectedQuestionnaire, setSelectedQuestionnaire] = useState("");
  const [assignMessage, setAssignMessage] = useState("");
  const [viewingEval, setViewingEval] = useState<any>(null);
  const [scoringId, setScoringId] = useState<string | null>(null);

  const { data: submissions, isLoading } = useQuery({
    queryKey: ["haziorvos-questionnaire-submissions"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("questionnaire_submissions")
        .select("id, questionnaire_id, user_id, submitted_at, answers, score, risk_category, ai_evaluation")
        .order("submitted_at", { ascending: false });
      if (error) throw error;
      const qIds = [...new Set(data.map((s) => s.questionnaire_id))];
      const uIds = [...new Set(data.map((s) => s.user_id))];
      const [{ data: questionnaires }, { data: profiles }] = await Promise.all([
        supabase.from("questionnaires").select("id, title").in("id", qIds),
        supabase.from("profiles").select("user_id, full_name").in("user_id", uIds),
      ]);
      return data.map((s) => ({
        ...s,
        questionnaire_title: (questionnaires ?? []).find((q) => q.id === s.questionnaire_id)?.title ?? "—",
        user_name: (profiles ?? []).find((p) => p.user_id === s.user_id)?.full_name ?? "—",
      }));
    },
  });

  const { data: patients } = useQuery({
    queryKey: ["haziorvos-patients-for-assign"],
    queryFn: async () => {
      const { data, error } = await supabase.from("profiles").select("user_id, full_name").order("full_name");
      if (error) throw error;
      return data;
    },
  });

  const { data: questionnaires } = useQuery({
    queryKey: ["active-questionnaires-for-assign"],
    queryFn: async () => {
      const { data, error } = await supabase.from("questionnaires").select("id, title").eq("is_active", true).order("title");
      if (error) throw error;
      return data;
    },
  });

  const { data: assignments } = useQuery({
    queryKey: ["haziorvos-questionnaire-assignments"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("questionnaire_assignments")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      const pIds = [...new Set(data.map((a: any) => a.patient_id))];
      const qIds = [...new Set(data.map((a: any) => a.questionnaire_id))];
      const [{ data: profiles }, { data: quests }] = await Promise.all([
        supabase.from("profiles").select("user_id, full_name").in("user_id", pIds.length ? pIds : ["none"]),
        supabase.from("questionnaires").select("id, title").in("id", qIds.length ? qIds : ["none"]),
      ]);
      return data.map((a: any) => ({
        ...a,
        patient_name: (profiles ?? []).find((p) => p.user_id === a.patient_id)?.full_name ?? "—",
        questionnaire_title: (quests ?? []).find((q) => q.id === a.questionnaire_id)?.title ?? "—",
      }));
    },
  });

  const assignMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("questionnaire_assignments").insert({
        questionnaire_id: selectedQuestionnaire,
        patient_id: selectedPatient,
        assigned_by: user!.id,
        message: assignMessage || null,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["haziorvos-questionnaire-assignments"] });
      toast({ title: "Kérdőív felszólítás elküldve" });
      setAssignDialogOpen(false);
      setSelectedPatient("");
      setSelectedQuestionnaire("");
      setAssignMessage("");
    },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  const scoreMutation = useMutation({
    mutationFn: async (submissionId: string) => {
      setScoringId(submissionId);
      const { data, error } = await supabase.functions.invoke("ai-questionnaire-scoring", {
        body: { submission_id: submissionId },
      });
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["haziorvos-questionnaire-submissions"] });
      toast({ title: "Pontozás és AI értékelés kész" });
      setScoringId(null);
    },
    onError: (e: any) => {
      toast({ variant: "destructive", title: t("common.error"), description: e.message });
      setScoringId(null);
    },
  });

  const getRiskColor = (category: string) => {
    if (!category) return "secondary";
    const lower = category.toLowerCase();
    if (lower.includes("alacsony") || lower.includes("minimális") || lower.includes("nincs")) return "default";
    if (lower.includes("enyhe") || lower.includes("enyhén")) return "secondary";
    if (lower.includes("közepes")) return "outline";
    return "destructive";
  };

  if (isLoading) {
    return <div className="flex items-center justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <ClipboardList className="h-6 w-6 text-secondary" />
          <h1 className="text-2xl font-bold">{t("inner.questionnaireSubmissions")}</h1>
        </div>
        <Button onClick={() => setAssignDialogOpen(true)}>
          <Send className="h-4 w-4 mr-2" />
          Kérdőív küldése páciensnek
        </Button>
      </div>

      {/* Pending assignments */}
      {(assignments ?? []).length > 0 && (
        <Card>
          <CardHeader><CardTitle className="text-lg">Kiküldött felszólítások ({assignments?.length ?? 0})</CardTitle></CardHeader>
          <CardContent className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t("inner.patient")}</TableHead>
                  <TableHead>{t("inner.questionnaire")}</TableHead>
                  <TableHead>{t("inner.status")}</TableHead>
                  <TableHead>Üzenet</TableHead>
                  <TableHead>{t("inner.date")}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {(assignments ?? []).map((a: any) => (
                  <TableRow key={a.id}>
                    <TableCell className="font-medium">{a.patient_name}</TableCell>
                    <TableCell>{a.questionnaire_title}</TableCell>
                    <TableCell>
                      <Badge variant={a.status === "completed" ? "default" : "secondary"}>
                        {a.status === "completed" ? "Kitöltve" : "Függőben"}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground max-w-[200px] truncate">{a.message || "—"}</TableCell>
                    <TableCell>{new Date(a.created_at).toLocaleDateString("hu-HU")}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* Submissions with scoring */}
      <Card>
        <CardHeader><CardTitle className="text-lg">{t("inner.submissions")} ({submissions?.length ?? 0})</CardTitle></CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t("inner.patient")}</TableHead>
                <TableHead>{t("inner.questionnaire")}</TableHead>
                <TableHead>{t("inner.submittedAt")}</TableHead>
                <TableHead>Pontszám</TableHead>
                <TableHead>Rizikó</TableHead>
                <TableHead>{t("inner.actions")}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {(submissions ?? []).map((s: any) => (
                <TableRow key={s.id}>
                  <TableCell className="font-medium">{s.user_name}</TableCell>
                  <TableCell>{s.questionnaire_title}</TableCell>
                  <TableCell>{new Date(s.submitted_at).toLocaleDateString("hu-HU")}</TableCell>
                  <TableCell>
                    {s.score != null ? <span className="font-bold">{s.score}</span> : "—"}
                  </TableCell>
                  <TableCell>
                    {s.risk_category ? (
                      <Badge variant={getRiskColor(s.risk_category)}>{s.risk_category}</Badge>
                    ) : "—"}
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => scoreMutation.mutate(s.id)}
                        disabled={scoringId === s.id}
                      >
                        {scoringId === s.id ? <Loader2 className="h-3 w-3 animate-spin" /> : <Brain className="h-3 w-3" />}
                        <span className="ml-1">{s.score != null ? "Újra" : "AI értékelés"}</span>
                      </Button>
                      {s.ai_evaluation && (
                        <Button size="sm" variant="ghost" onClick={() => setViewingEval(s)}>
                          Részletek
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
              {(submissions ?? []).length === 0 && (
                <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-8">{t("inner.noSubmission")}</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Assign dialog */}
      <Dialog open={assignDialogOpen} onOpenChange={setAssignDialogOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Kérdőív kitöltési felszólítás küldése</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>{t("inner.patient")}</Label>
              <Select value={selectedPatient} onValueChange={setSelectedPatient}>
                <SelectTrigger><SelectValue placeholder={t("inner.selectPatient")} /></SelectTrigger>
                <SelectContent>
                  {(patients ?? []).map((p) => (
                    <SelectItem key={p.user_id} value={p.user_id}>{p.full_name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>{t("inner.questionnaire")}</Label>
              <Select value={selectedQuestionnaire} onValueChange={setSelectedQuestionnaire}>
                <SelectTrigger><SelectValue placeholder="Válasszon kérdőívet" /></SelectTrigger>
                <SelectContent>
                  {(questionnaires ?? []).map((q) => (
                    <SelectItem key={q.id} value={q.id}>{q.title}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Üzenet (opcionális)</Label>
              <Textarea
                value={assignMessage}
                onChange={(e) => setAssignMessage(e.target.value)}
                placeholder="Pl.: Kérem töltse ki a kérdőívet a következő vizsgálat előtt..."
                rows={3}
              />
            </div>
            <Button
              className="w-full"
              onClick={() => assignMutation.mutate()}
              disabled={!selectedPatient || !selectedQuestionnaire || assignMutation.isPending}
            >
              <Send className="h-4 w-4 mr-2" />
              Felszólítás küldése
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* AI Evaluation details dialog */}
      <Dialog open={!!viewingEval} onOpenChange={(open) => !open && setViewingEval(null)}>
        <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>AI Értékelés — {viewingEval?.questionnaire_title}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="flex gap-4 text-sm">
              <div><strong>Páciens:</strong> {viewingEval?.user_name}</div>
              <div><strong>Pontszám:</strong> {viewingEval?.score}</div>
            </div>
            {viewingEval?.risk_category && (
              <Badge variant={getRiskColor(viewingEval.risk_category)} className="text-sm">{viewingEval.risk_category}</Badge>
            )}
            <div className="prose prose-sm max-w-none dark:prose-invert">
              <ReactMarkdown>{viewingEval?.ai_evaluation || ""}</ReactMarkdown>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
