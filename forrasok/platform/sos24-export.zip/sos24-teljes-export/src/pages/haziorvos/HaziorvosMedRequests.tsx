import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Pill, CheckCircle, XCircle } from "lucide-react";

export default function HaziorvosMedRequests() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();

  const typeLabels: Record<string, string> = {
    allando: t('inner.permanent'), eseti: t('inner.occasional'), panasz: t('inner.complaintType'),
  };
  const statusConfig: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
    pending: { label: t('inner.pending'), variant: "outline" },
    approved: { label: t('inner.approved'), variant: "default" },
    rejected: { label: t('inner.rejected'), variant: "destructive" },
  };

  const [responding, setResponding] = useState<any | null>(null);
  const [response, setResponse] = useState("");

  const { data: requests, isLoading } = useQuery({
    queryKey: ["all-med-requests"],
    queryFn: async () => {
      const { data, error } = await supabase.from("medication_requests").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      const patientIds = [...new Set(data.map((r) => r.patient_id))];
      const { data: profiles } = await supabase.from("profiles").select("user_id, full_name").in("user_id", patientIds);
      const nameMap = new Map((profiles ?? []).map((p) => [p.user_id, p.full_name]));
      return data.map((r) => ({ ...r, patient_name: nameMap.get(r.patient_id) ?? "—" }));
    },
  });

  const updateRequest = useMutation({
    mutationFn: async ({ id, status, doctor_response }: { id: string; status: string; doctor_response: string }) => {
      const { error } = await supabase.from("medication_requests").update({ status, doctor_response }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: (_data, variables) => {
      qc.invalidateQueries({ queryKey: ["all-med-requests"] });
      toast({ title: t('inner.requestAnswered') });
      const req = (requests ?? []).find((r) => r.id === variables.id);
      if (req) {
        supabase.functions.invoke("send-notification", {
          body: { type: "medication_response", recipient_id: req.patient_id, sender_id: user!.id, data: { medication: req.medication_name, status: variables.status, response: variables.doctor_response || "" } },
        }).catch((e) => console.error("Notification error:", e));

        // Send prescription-ready email when approved
        if (variables.status === "approved") {
          supabase.functions.invoke("send-transactional-email", {
            body: {
              templateName: "prescription-ready",
              to: req.patient_id,
              data: {
                patientName: req.patient_name,
                medicationName: req.medication_name,
                doctorName: "Háziorvos",
                notes: variables.doctor_response || "",
              },
            },
          }).catch((e) => console.error("Prescription email error:", e));
        }
      }
      setResponding(null);
      setResponse("");
    },
    onError: (e: any) => toast({ variant: "destructive", title: t('common.error'), description: e.message }),
  });

  const handleAction = (status: "approved" | "rejected") => {
    if (!responding) return;
    updateRequest.mutate({ id: responding.id, status, doctor_response: response.trim() || null });
  };

  const pendingCount = (requests ?? []).filter((r) => r.status === "pending").length;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Pill className="h-6 w-6 text-secondary" />
        <h1 className="text-2xl font-bold">{t('inner.prescriptionRequests')}</h1>
        {pendingCount > 0 && <Badge variant="destructive">{pendingCount} {t('inner.new')}</Badge>}
      </div>
      <Card>
        <CardHeader><CardTitle className="text-lg">{t('inner.receivedPrescriptions')}</CardTitle></CardHeader>
        <CardContent className="overflow-x-auto">
          {isLoading ? (
            <div className="flex justify-center py-8"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t('inner.date')}</TableHead>
                  <TableHead>{t('inner.patient')}</TableHead>
                  <TableHead>{t('inner.medication')}</TableHead>
                  <TableHead>{t('inner.type')}</TableHead>
                  <TableHead>{t('inner.notes')}</TableHead>
                  <TableHead>{t('inner.status')}</TableHead>
                  <TableHead>{t('inner.action')}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {(requests ?? []).map((r) => {
                  const sc = statusConfig[r.status] ?? statusConfig.pending;
                  return (
                    <TableRow key={r.id}>
                      <TableCell className="whitespace-nowrap">{new Date(r.created_at).toLocaleDateString("hu-HU")}</TableCell>
                      <TableCell className="font-medium">{r.patient_name}</TableCell>
                      <TableCell>{r.medication_name}</TableCell>
                      <TableCell><Badge variant="secondary">{typeLabels[r.request_type] ?? r.request_type}</Badge></TableCell>
                      <TableCell className="max-w-xs truncate">{r.notes || "—"}</TableCell>
                      <TableCell><Badge variant={sc.variant}>{sc.label}</Badge></TableCell>
                      <TableCell>
                        {r.status === "pending" ? (
                          <Button size="sm" variant="outline" onClick={() => { setResponding(r); setResponse(""); }}>{t('inner.respond')}</Button>
                        ) : (
                          <span className="text-sm text-muted-foreground">{r.doctor_response || "—"}</span>
                        )}
                      </TableCell>
                    </TableRow>
                  );
                })}
                {(requests ?? []).length === 0 && (
                  <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-8">{t('inner.noPrescription')}</TableCell></TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={!!responding} onOpenChange={(o) => !o && setResponding(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>{t('inner.prescriptionResponse')}</DialogTitle></DialogHeader>
          {responding && (
            <div className="space-y-3">
              <div className="text-sm"><span className="text-muted-foreground">{t('inner.patient')}:</span> {responding.patient_name}</div>
              <div className="text-sm"><span className="text-muted-foreground">{t('inner.medication')}:</span> {responding.medication_name}</div>
              <div className="text-sm"><span className="text-muted-foreground">{t('inner.type')}:</span> {typeLabels[responding.request_type]}</div>
              {responding.notes && <div className="text-sm"><span className="text-muted-foreground">{t('inner.patientNote')}:</span> {responding.notes}</div>}
              <Textarea placeholder={t('inner.doctorResponse')} value={response} onChange={(e) => setResponse(e.target.value)} rows={3} />
            </div>
          )}
          <DialogFooter className="gap-2">
            <Button variant="destructive" onClick={() => handleAction("rejected")} disabled={updateRequest.isPending}>
              <XCircle className="h-4 w-4 mr-2" />{t('inner.reject')}
            </Button>
            <Button onClick={() => handleAction("approved")} disabled={updateRequest.isPending}>
              <CheckCircle className="h-4 w-4 mr-2" />{t('inner.accept')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
