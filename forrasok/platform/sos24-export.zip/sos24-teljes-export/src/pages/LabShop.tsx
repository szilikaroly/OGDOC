import { useState, useMemo } from "react";
import { LAB_TEST_CATALOG, SPECIALTIES, type LabTest } from "@/lib/labTestCatalog";
import { useLabPricing, calculateDisplayPrice } from "@/hooks/use-lab-pricing";
import { useLabPackages } from "@/hooks/use-lab-packages";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { HoverCard, HoverCardContent, HoverCardTrigger } from "@/components/ui/hover-card";
import { useToast } from "@/hooks/use-toast";
import { printLabRequest } from "@/lib/printLabRequest";
import LabAiAssistant from "@/components/LabAiAssistant";
import {
  FlaskConical, Search, ShoppingCart, Plus, Minus, Trash2, MapPin, Home, Send, CheckCircle, Package, ChevronDown, ChevronUp, Printer, Users,
} from "lucide-react";

export default function LabShop() {
  const { toast } = useToast();
  const { overrides, markup, loading: pricingLoading } = useLabPricing();
  const { data: dbPackages } = useLabPackages();
  const [search, setSearch] = useState("");
  const [filterSpecialty, setFilterSpecialty] = useState("all");
  const [cart, setCart] = useState<Set<string>>(new Set());
  const [expandedSpecialties, setExpandedSpecialties] = useState<Set<string>>(new Set());
  const [samplingType, setSamplingType] = useState<"location" | "home">("location");
  const [locationId, setLocationId] = useState("");
  const [homeAddress, setHomeAddress] = useState("");
  const [preferredDate, setPreferredDate] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [notes, setNotes] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [lastOrderNumber, setLastOrderNumber] = useState('');
  const [step, setStep] = useState<"browse" | "checkout">("browse");

  const { data: locations } = useQuery({
    queryKey: ["public-locations"],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("get_public_locations");
      if (error) throw error;
      return data ?? [];
    },
    refetchInterval: 30_000,
    refetchOnWindowFocus: true,
    staleTime: 25_000,
  });

  const getPrice = (t: LabTest) => calculateDisplayPrice(t, overrides, markup, t.id);

  const activeCatalog = useMemo(() => {
    return LAB_TEST_CATALOG.filter(t => {
      if (t.status !== "active") return false;
      const q = search.toLowerCase();
      const matchSearch = !q || t.name.toLowerCase().includes(q) || t.shortName.toLowerCase().includes(q);
      const matchSpec = filterSpecialty === "all" || t.specialty === filterSpecialty;
      return matchSearch && matchSpec;
    });
  }, [search, filterSpecialty]);

  const grouped = useMemo(() => {
    const g: Record<string, LabTest[]> = {};
    activeCatalog.forEach(t => { if (!g[t.specialty]) g[t.specialty] = []; g[t.specialty].push(t); });
    return g;
  }, [activeCatalog]);

  const cartItems = LAB_TEST_CATALOG.filter(t => cart.has(t.id));
  const subtotal = cartItems.reduce((sum, t) => sum + getPrice(t), 0);
  const homeFee = samplingType === "home" ? markup.home_sampling_fee_huf : 0;
  const total = subtotal + homeFee;

  const toggleCart = (id: string) => {
    setCart(prev => { const s = new Set(prev); s.has(id) ? s.delete(id) : s.add(id); return s; });
  };

  const addPackageToCart = (testIds: string[], packageName?: string) => {
    setCart(prev => {
      const s = new Set(prev);
      testIds.forEach(id => s.add(id));
      return s;
    });
    if (packageName) {
      toast({ title: `${packageName} hozzáadva`, description: `${testIds.length} vizsgálat hozzáadva a kosárhoz` });
    }
  };

  const handleSubmit = async () => {
    if (!name || !email || !phone) {
      toast({ title: "Kérjük töltse ki az összes kötelező mezőt", variant: "destructive" });
      return;
    }
    if (samplingType === "location" && !locationId) {
      toast({ title: "Válasszon mintavételi helyszínt", variant: "destructive" });
      return;
    }
    if (samplingType === "home" && !homeAddress) {
      toast({ title: "Adja meg a mintavételi címet", variant: "destructive" });
      return;
    }
    setSubmitting(true);
    try {
      const orderedTests = cartItems.map(t => ({ id: t.id, name: t.name, shortName: t.shortName, priceHuf: getPrice(t), sampleType: t.sampleType }));
      const { data: insertedData, error } = await (supabase as any).rpc("create_public_lab_order", {
        _customer_name: name,
        _customer_email: email,
        _customer_phone: phone,
        _ordered_tests: orderedTests,
        _sampling_type: samplingType,
        _location_id: samplingType === "location" ? locationId : null,
        _home_address: samplingType === "home" ? homeAddress : null,
        _preferred_date: preferredDate || null,
        _notes: notes || null,
        _total_price_huf: total,
      });
      if (error) throw error;
      const row = Array.isArray(insertedData) ? insertedData[0] : insertedData;
      setLastOrderNumber(row?.order_number ?? '');
      setSubmitted(true);
    } catch (err: any) {
      toast({ title: "Hiba történt", description: err.message, variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  };

  const toggleSpecialty = (s: string) =>
    setExpandedSpecialties(prev => { const n = new Set(prev); n.has(s) ? n.delete(s) : n.add(s); return n; });

  const handlePrintOrder = () => {
    const tests = cartItems.map(t => ({
      id: t.id, leCode: t.leCode, name: t.name, shortName: t.shortName, specialty: t.specialty, type: t.type,
      unit: t.unit, ucumCode: t.ucumCode, oenoCode: t.oenoCode, loincCode: t.loincCode, extraDataHint: t.extraDataHint,
      sampleType: t.sampleType, status: 'active' as const, points: t.points, priceHuf: getPrice(t),
    }));
    printLabRequest({
      requestNumber: lastOrderNumber || 'WEBSHOP',
      patientName: name || '—',
      physicianName: 'SOS-24 Labor',
      scheduledDate: preferredDate || undefined,
      priority: 'routine',
      notes: notes || undefined,
      selectedTests: tests,
      createdAt: new Date().toISOString(),
    });
  };

  const packages = dbPackages ?? [];

  if (submitted) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <Card className="max-w-md w-full text-center">
          <CardContent className="pt-8 pb-8 space-y-4">
            <CheckCircle className="w-16 h-16 text-primary mx-auto" />
            <h2 className="text-2xl font-bold">Köszönjük megrendelését!</h2>
            {lastOrderNumber && <p className="font-mono text-lg">{lastOrderNumber}</p>}
            <p className="text-muted-foreground">Hamarosan felvesszük Önnel a kapcsolatot a megadott elérhetőségeken a pontos időpont egyeztetéséhez.</p>
            <div className="flex gap-2 justify-center">
              <Button variant="outline" onClick={handlePrintOrder} className="gap-2">
                <Printer className="w-4 h-4" /> Kérőlap nyomtatása
              </Button>
              <Button onClick={() => { setSubmitted(false); setCart(new Set()); setStep("browse"); }}>Új rendelés</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-primary/5 border-b">
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center gap-3 mb-2">
            <FlaskConical className="w-8 h-8 text-primary" />
            <h1 className="text-3xl font-bold text-foreground">Labor Vizsgálatok</h1>
          </div>
          <p className="text-muted-foreground max-w-2xl">
            Válassza ki a kívánt laborvizsgálatokat, és rendelje meg online! Mintavétel rendelőnkben vagy otthonában.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        {step === "browse" ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left: catalog */}
            <div className="lg:col-span-2 space-y-4">
              {/* AI assistant */}
              <LabAiAssistant
                onAddToCart={(ids) => addPackageToCart(ids)}
                cart={cart}
                getPrice={getPrice}
              />

              {/* Templates */}
              {packages.length > 0 && (
                <div className="space-y-2">
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Csomagajánlatok</p>
                  <div className="flex flex-wrap gap-2">
                    {packages.map(pkg => {
                      const pkgTests = pkg.test_ids
                        .map(id => LAB_TEST_CATALOG.find(x => x.id === id))
                        .filter((t): t is LabTest => !!t);
                      const pkgPrice = pkgTests.reduce((sum, t) => sum + getPrice(t), 0);
                      const allInCart = pkg.test_ids.every(id => cart.has(id));
                      return (
                        <HoverCard key={pkg.id} openDelay={150} closeDelay={100}>
                          <HoverCardTrigger asChild>
                            <Button variant={allInCart ? "default" : "outline"} size="sm" onClick={() => addPackageToCart(pkg.test_ids, pkg.name)} disabled={allInCart} className="gap-1.5 text-xs">
                              <Package className="w-3 h-3" /> {pkg.icon} {pkg.name}
                              <span className="text-[10px] opacity-70">({pkgPrice.toLocaleString("hu-HU")} Ft)</span>
                            </Button>
                          </HoverCardTrigger>
                          <HoverCardContent className="w-96 p-0" align="start">
                            <div className="p-4 space-y-3">
                              <div>
                                <div className="flex items-center gap-2 mb-1">
                                  <span className="text-lg">{pkg.icon}</span>
                                  <h4 className="font-semibold text-sm">{pkg.name}</h4>
                                </div>
                                {pkg.description && (
                                  <p className="text-xs text-muted-foreground">{pkg.description}</p>
                                )}
                              </div>

                              {pkg.target_audience && (
                                <div className="bg-primary/5 border border-primary/20 rounded-lg p-2.5">
                                  <p className="text-[10px] font-semibold text-primary uppercase tracking-wide flex items-center gap-1 mb-1">
                                    <Users className="w-3 h-3" /> Kinek ajánljuk
                                  </p>
                                  <p className="text-xs text-foreground">{pkg.target_audience}</p>
                                </div>
                              )}

                              <div>
                                <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide mb-1.5">
                                  Tartalom ({pkgTests.length} vizsgálat)
                                </p>
                                <ScrollArea className="h-48 -mx-1 px-1">
                                  <ul className="space-y-1">
                                    {pkgTests.map(t => (
                                      <li key={t.id} className="flex items-center justify-between text-xs gap-2 py-0.5">
                                        <span className="truncate">{t.name}</span>
                                        <span className="text-muted-foreground whitespace-nowrap">{getPrice(t).toLocaleString("hu-HU")} Ft</span>
                                      </li>
                                    ))}
                                  </ul>
                                </ScrollArea>
                              </div>

                              <div className="flex items-center justify-between pt-2 border-t">
                                <span className="text-xs text-muted-foreground">Csomagár</span>
                                <span className="text-sm font-bold text-primary">{pkgPrice.toLocaleString("hu-HU")} Ft</span>
                              </div>
                            </div>
                          </HoverCardContent>
                        </HoverCard>
                      );
                    })}
                  </div>
                </div>
              )}

              <div className="flex flex-col sm:flex-row gap-2">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Keresés vizsgálat neve…" className="pl-9" />
                </div>
                <Select value={filterSpecialty} onValueChange={setFilterSpecialty}>
                  <SelectTrigger className="w-full sm:w-[200px]"><SelectValue placeholder="Szakterület" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Összes</SelectItem>
                    {SPECIALTIES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>

              <ScrollArea className="h-[60vh] border rounded-xl">
                <div className="p-3 space-y-1">
                  {Object.entries(grouped).map(([specialty, tests]) => {
                    const isExpanded = expandedSpecialties.has(specialty) || !!search || filterSpecialty !== "all";
                    return (
                      <div key={specialty}>
                        <button onClick={() => toggleSpecialty(specialty)} className="w-full flex items-center justify-between px-3 py-2 rounded-lg bg-muted/60 hover:bg-muted transition-colors text-left">
                          <span className="text-xs font-semibold uppercase tracking-wide">{specialty}</span>
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] text-muted-foreground">{tests.length} vizsgálat</span>
                            {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                          </div>
                        </button>
                        {isExpanded && (
                          <div className="mt-0.5 space-y-0.5">
                            {tests.map(test => {
                              const inCart = cart.has(test.id);
                              const price = getPrice(test);
                              return (
                                <div key={test.id} className={`flex items-center justify-between px-3 py-2.5 rounded-lg transition-colors cursor-pointer ${inCart ? "bg-primary/10 border border-primary/20" : "hover:bg-muted/40"}`} onClick={() => toggleCart(test.id)}>
                                  <div className="min-w-0 flex-1">
                                    <div className="text-sm font-medium">{test.name}</div>
                                    <div className="text-[10px] text-muted-foreground flex gap-2">
                                      <span>🧪 {test.sampleType}</span>
                                      {test.referenceRange && <span>📊 {test.referenceRange}</span>}
                                    </div>
                                  </div>
                                  <div className="flex items-center gap-3 shrink-0">
                                    <span className="text-sm font-semibold">{price.toLocaleString("hu-HU")} Ft</span>
                                    {inCart ? (
                                      <Badge className="bg-primary text-primary-foreground gap-1"><CheckCircle className="w-3 h-3" /> Kosárban</Badge>
                                    ) : (
                                      <Button size="sm" variant="outline" className="h-7 text-xs gap-1" onClick={e => { e.stopPropagation(); toggleCart(test.id); }}>
                                        <Plus className="w-3 h-3" /> Kosárba
                                      </Button>
                                    )}
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </ScrollArea>
            </div>

            {/* Right: cart */}
            <div>
              <Card className="sticky top-4">
                <CardContent className="pt-6 space-y-4">
                  <div className="flex items-center gap-2 font-semibold">
                    <ShoppingCart className="w-5 h-5 text-primary" /> Kosár
                    {cart.size > 0 && <Badge variant="secondary">{cart.size}</Badge>}
                  </div>
                  {cartItems.length === 0 ? (
                    <p className="text-sm text-muted-foreground py-4 text-center">A kosár üres. Válasszon vizsgálatokat a katalógusból!</p>
                  ) : (
                    <>
                      <div className="space-y-1 max-h-64 overflow-y-auto">
                        {cartItems.map(t => (
                          <div key={t.id} className="flex items-center justify-between text-sm py-1.5 px-2 rounded bg-muted/30">
                            <span className="truncate flex-1">{t.name}</span>
                            <div className="flex items-center gap-2 shrink-0">
                              <span className="text-xs text-muted-foreground">{getPrice(t).toLocaleString("hu-HU")} Ft</span>
                              <button onClick={() => toggleCart(t.id)} className="text-muted-foreground hover:text-destructive">
                                <Trash2 className="w-3 h-3" />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                      <div className="border-t pt-3 space-y-1 text-sm">
                        <div className="flex justify-between"><span>Vizsgálatok:</span><span>{subtotal.toLocaleString("hu-HU")} Ft</span></div>
                        {samplingType === "home" && <div className="flex justify-between text-muted-foreground"><span>Otthoni mintavétel:</span><span>+{homeFee.toLocaleString("hu-HU")} Ft</span></div>}
                        <div className="flex justify-between font-bold text-lg pt-1"><span>Összesen:</span><span>{total.toLocaleString("hu-HU")} Ft</span></div>
                      </div>
                      <Button className="w-full" size="lg" onClick={() => setStep("checkout")}>
                        Tovább a megrendeléshez
                      </Button>
                    </>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        ) : (
          /* Checkout */
          <div className="max-w-2xl mx-auto space-y-6">
            <Button variant="ghost" onClick={() => setStep("browse")} className="mb-2">← Vissza a katalógushoz</Button>

            <Card>
              <CardContent className="pt-6 space-y-4">
                <h2 className="text-lg font-semibold">Személyes adatok</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <Label>Teljes név *</Label>
                    <Input value={name} onChange={e => setName(e.target.value)} placeholder="Kovács János" />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Email *</Label>
                    <Input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="email@pelda.hu" />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Telefon *</Label>
                    <Input value={phone} onChange={e => setPhone(e.target.value)} placeholder="+36 30 123 4567" />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Preferált dátum</Label>
                    <Input type="date" value={preferredDate} onChange={e => setPreferredDate(e.target.value)} />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6 space-y-4">
                <h2 className="text-lg font-semibold">Mintavétel helye</h2>
                <RadioGroup value={samplingType} onValueChange={v => setSamplingType(v as any)} className="flex flex-col gap-3">
                  <label className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${samplingType === "location" ? "border-primary bg-primary/5" : "hover:bg-muted/40"}`}>
                    <RadioGroupItem value="location" />
                    <MapPin className="w-5 h-5 text-primary" />
                    <div>
                      <p className="font-medium text-sm">Rendelőben</p>
                      <p className="text-xs text-muted-foreground">Személyes mintavétel valamelyik rendelőnkben</p>
                    </div>
                  </label>
                  <label className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${samplingType === "home" ? "border-primary bg-primary/5" : "hover:bg-muted/40"}`}>
                    <RadioGroupItem value="home" />
                    <Home className="w-5 h-5 text-primary" />
                    <div>
                      <p className="font-medium text-sm">Otthoni mintavétel</p>
                      <p className="text-xs text-muted-foreground">Munkatársunk az Ön otthonában veszi le a mintát (+{markup.home_sampling_fee_huf.toLocaleString("hu-HU")} Ft)</p>
                    </div>
                  </label>
                </RadioGroup>
                {samplingType === "location" && (
                  <Select value={locationId} onValueChange={setLocationId}>
                    <SelectTrigger><SelectValue placeholder="Válasszon helyszínt…" /></SelectTrigger>
                    <SelectContent>
                      {(locations ?? []).map(l => (
                        <SelectItem key={l.id} value={l.id}>{l.name} – {l.address}, {l.city}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
                {samplingType === "home" && (
                  <div className="space-y-1.5">
                    <Label>Mintavétel címe *</Label>
                    <Input value={homeAddress} onChange={e => setHomeAddress(e.target.value)} placeholder="1234 Budapest, Példa utca 1." />
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6 space-y-3">
                <h2 className="text-lg font-semibold">Megrendelés összesítő</h2>
                {cartItems.map(t => (
                  <div key={t.id} className="flex justify-between text-sm py-1">
                    <span>{t.name}</span>
                    <span>{getPrice(t).toLocaleString("hu-HU")} Ft</span>
                  </div>
                ))}
                {samplingType === "home" && (
                  <div className="flex justify-between text-sm py-1 text-muted-foreground">
                    <span>Otthoni mintavételi díj</span>
                    <span>{homeFee.toLocaleString("hu-HU")} Ft</span>
                  </div>
                )}
                <div className="flex justify-between font-bold text-lg border-t pt-2">
                  <span>Összesen:</span>
                  <span>{total.toLocaleString("hu-HU")} Ft</span>
                </div>
                <Textarea value={notes} onChange={e => setNotes(e.target.value)} placeholder="Megjegyzés (opcionális)" rows={2} />
                <Button className="w-full" size="lg" onClick={handleSubmit} disabled={submitting}>
                  <Send className="w-4 h-4 mr-2" />
                  {submitting ? "Küldés…" : "Megrendelés elküldése"}
                </Button>
                <p className="text-xs text-center text-muted-foreground">A fizetés a mintavételkor történik. Rendelését e-mailben visszaigazoljuk.</p>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
