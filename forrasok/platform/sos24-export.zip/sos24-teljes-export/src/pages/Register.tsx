import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertTriangle, Info, XCircle } from "lucide-react";
import {
  getFriendlyOAuthError,
  readOAuthErrorFromUrl,
  clearOAuthErrorFromUrl,
  type FriendlyOAuthError,
  type OAuthProvider,
} from "@/lib/oauth-errors";
import { getAuthErrorToast } from "@/lib/auth-errors";

import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useSiteSettings, useSiteSettingsIdMap } from "@/hooks/use-cms";
import { useSiteSettingsTranslations } from "@/hooks/use-content-translations";
import { useToast } from "@/hooks/use-toast";
import { UserPlus } from "lucide-react";
import LanguageSwitcher from "@/components/LanguageSwitcher";
import { Checkbox } from "@/components/ui/checkbox";
import { useTranslation } from "react-i18next";
import type { AppRole } from "@/contexts/AuthContext";

const ROLE_REDIRECTS: Record<AppRole, string> = {
  super_admin: "/admin",
  haziorvos: "/haziorvos",
  uzemorvos: "/uzemorvos",
  munkaltato: "/munkaltato",
  munkavallalo: "/munkavallalo",
  praxistag: "/praxistag",
};

async function redirectAfterOAuth(navigate: (to: string, opts?: { replace?: boolean }) => void) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    navigate("/login", { replace: true });
    return;
  }
  const { data: rolesData } = await supabase
    .from("user_roles")
    .select("role")
    .eq("user_id", user.id);
  const roles = (rolesData ?? []).map((r) => r.role as AppRole);
  const savedRole = localStorage.getItem("activeRole") as AppRole | null;
  const activeRole = savedRole && roles.includes(savedRole) ? savedRole : roles[0];
  if (activeRole && ROLE_REDIRECTS[activeRole]) {
    navigate(ROLE_REDIRECTS[activeRole], { replace: true });
  } else {
    // New OAuth user with no role assigned yet → land on profile
    navigate("/munkavallalo", { replace: true });
  }
}

export default function Register() {
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [appleLoading, setAppleLoading] = useState(false);
  const [oauthError, setOauthError] = useState<FriendlyOAuthError | null>(null);
  const navigate = useNavigate();
  const { toast } = useToast();
  const { data: s } = useSiteSettings();
  const { data: idMap } = useSiteSettingsIdMap();
  const { ctSetting } = useSiteSettingsTranslations();
  const { t } = useTranslation();

  const { i18n } = useTranslation();
  const lang = i18n.language;

  const ts = (key: string, fallbackKey: string) => {
    const id = idMap?.[key];
    const translated = id ? ctSetting(id, s?.[key]) : undefined;
    if (lang !== "hu" && translated && translated === s?.[key]) return t(fallbackKey);
    return translated || t(fallbackKey);
  };

  const registerSchema = z.object({
    fullName: z.string().trim().min(2, t('auth.minChars', { count: 2 })).max(100),
    email: z.string().trim().email(t('auth.validEmail')).max(255),
    password: z.string().min(6, t('auth.minChars', { count: 6 })).max(128),
    confirmPassword: z.string(),
    consent: z.literal(true, { errorMap: () => ({ message: t('auth.consentRequired') }) }),
  }).refine((d) => d.password === d.confirmPassword, {
    message: t('auth.passwordsNoMatch'),
    path: ["confirmPassword"],
  });

  type RegisterForm = z.infer<typeof registerSchema>;

  const form = useForm<RegisterForm>({
    resolver: zodResolver(registerSchema),
    defaultValues: { fullName: "", email: "", password: "", confirmPassword: "", consent: false as any },
  });

  const onSubmit = async (values: RegisterForm) => {
    setLoading(true);
    try {
      const { error } = await supabase.auth.signUp({
        email: values.email,
        password: values.password,
        options: {
          data: { full_name: values.fullName },
          emailRedirectTo: window.location.origin,
        },
      });
      if (error) throw error;

      toast({
        title: t('auth.registerTitle'),
        description: t('auth.confirmEmailSent'),
      });
      navigate("/login");
    } catch (err: unknown) {
      toast(getAuthErrorToast(err, t, "auth.registerTitle"));

    } finally {
      setLoading(false);
    }
  };

  const reportOAuthError = (provider: OAuthProvider, err: unknown) => {
    const friendly = getFriendlyOAuthError(provider, err);
    setOauthError(friendly);
    toast({
      variant: friendly.severity === "info" ? "default" : "destructive",
      title: friendly.title,
      description: friendly.hint
        ? `${friendly.description} ${friendly.hint}`
        : friendly.description,
    });
    // eslint-disable-next-line no-console
    console.warn("[oauth]", provider, friendly.code, err);
  };

  const handleGoogleSignIn = async () => {
    setOauthError(null);
    setGoogleLoading(true);
    try {
      const result = await lovable.auth.signInWithOAuth("google", {
        redirect_uri: window.location.origin,
      });
      if (result.error) throw result.error;
      if (result.redirected) return;
      toast({
        title: t('auth.registerTitle'),
        description: t('auth.googleSuccess', { defaultValue: 'Sikeres regisztráció' }),
      });
      await redirectAfterOAuth(navigate);
    } catch (err: unknown) {
      reportOAuthError("google", err);
      setGoogleLoading(false);
    }
  };

  const handleAppleSignIn = async () => {
    setOauthError(null);
    setAppleLoading(true);
    try {
      const result = await lovable.auth.signInWithOAuth("apple", {
        redirect_uri: window.location.origin,
      });
      if (result.error) throw result.error;
      if (result.redirected) return;
      toast({
        title: t('auth.registerTitle'),
        description: t('auth.appleSuccess', { defaultValue: 'Sikeres regisztráció' }),
      });
      await redirectAfterOAuth(navigate);
    } catch (err: unknown) {
      reportOAuthError("apple", err);
      setAppleLoading(false);
    }
  };

  useEffect(() => {
    const urlErr = readOAuthErrorFromUrl();
    if (urlErr) {
      const provider: OAuthProvider =
        document.referrer.toLowerCase().includes("apple") ? "apple" : "google";
      reportOAuthError(provider, urlErr);
      clearOAuthErrorFromUrl();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);



  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-hero px-4 relative">
      <div className="absolute top-4 right-4">
        <LanguageSwitcher />
      </div>
      <Card className="w-full max-w-md border-border/50 bg-card shadow-luxury">
        <CardHeader className="text-center">
          <Link to="/" className="mx-auto mb-2 font-display text-2xl font-bold text-gradient-gold">
            {ts("site_name", "common.name")}
          </Link>
          <CardTitle className="text-xl">{ts("auth_register_title", "auth.registerTitle")}</CardTitle>
          <CardDescription>{ts("auth_register_subtitle", "auth.registerSubtitle")}</CardDescription>
        </CardHeader>
        <CardContent>
          {oauthError && (
            <Alert
              role="alert"
              className={
                "mb-4 " +
                (oauthError.severity === "info"
                  ? "border-blue-500/40 bg-blue-500/10 text-blue-700 dark:text-blue-300"
                  : oauthError.severity === "warning"
                  ? "border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300"
                  : "border-red-500/40 bg-red-500/10 text-red-700 dark:text-red-300")
              }
            >
              {oauthError.severity === "info" ? (
                <Info className="h-4 w-4" />
              ) : oauthError.severity === "warning" ? (
                <AlertTriangle className="h-4 w-4" />
              ) : (
                <XCircle className="h-4 w-4" />
              )}
              <AlertTitle>{oauthError.title}</AlertTitle>
              <AlertDescription className="space-y-1">
                <div>{oauthError.description}</div>
                {oauthError.hint && (
                  <div className="text-xs opacity-80">{oauthError.hint}</div>
                )}
              </AlertDescription>
            </Alert>
          )}
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="fullName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{ts("auth_name_label", "auth.fullName")}</FormLabel>
                    <FormControl>
                      <Input placeholder="Kovács János" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{ts("auth_email_label", "auth.email")}</FormLabel>
                    <FormControl>
                      <Input type="email" placeholder="email@example.com" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{ts("auth_password_label", "auth.password")}</FormLabel>
                    <FormControl>
                      <Input type="password" placeholder="••••••••" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="confirmPassword"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{ts("auth_confirm_password_label", "auth.confirmPassword")}</FormLabel>
                    <FormControl>
                      <Input type="password" placeholder="••••••••" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="consent"
                render={({ field }) => (
                  <FormItem className="space-y-2">
                    <div className="max-h-32 overflow-y-auto rounded-md border p-3 text-xs text-muted-foreground leading-relaxed">
                      {t('questionnaire.consentText')}
                    </div>
                    <div className="flex items-start space-x-2">
                      <FormControl>
                        <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                      </FormControl>
                      <FormLabel className="text-sm font-normal leading-tight cursor-pointer">
                        {t('auth.acceptConsent')}
                      </FormLabel>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button type="submit" className="w-full bg-secondary text-secondary-foreground hover:bg-secondary/90" disabled={loading}>
                <UserPlus className="mr-2 h-4 w-4" />
                {loading ? `${t('auth.registerTitle')}...` : ts("auth_register_button", "auth.registerTitle")}
              </Button>
            </form>
          </Form>
          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-card px-2 text-muted-foreground">
                {t('auth.orContinueWith')}
              </span>
            </div>
          </div>
          <Button
            type="button"
            variant="outline"
            className="w-full"
            onClick={handleGoogleSignIn}
            disabled={googleLoading}
          >
            <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05" />
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
            </svg>
            {googleLoading ? t('common.loading') : t('auth.googleRegister')}
          </Button>
          <Button
            type="button"
            variant="outline"
            className="w-full mt-2"
            onClick={handleAppleSignIn}
            disabled={appleLoading}
          >
            <svg className="mr-2 h-4 w-4" viewBox="0 0 384 512" fill="currentColor">
              <path d="M318.7 268.7c-.2-36.7 16.4-64.4 50-84.8-18.8-26.9-47.2-41.7-84.7-44.6-35.5-2.8-74.3 20.7-88.5 20.7-15 0-49.4-19.7-76.4-19.7C63.3 141.2 4 184.8 4 273.5q0 39.3 14.4 81.2c12.8 36.7 59 126.7 107.2 125.2 25.2-.6 43-17.9 75.8-17.9 31.8 0 48.3 17.9 76.4 17.9 48.6-.7 90.4-82.5 102.6-119.3-65.2-30.7-61.7-90-61.7-91.9zM254.5 96.5c25.9-30.7 23.5-58.7 22.7-68.7-23.4 1.4-50.5 16-65.9 33.9-17 19.2-27 43-24.8 65.7 25.3 1.9 48.4-11 67.9-30.9z"/>
            </svg>
            {appleLoading ? t('common.loading') : t('auth.appleRegister')}
          </Button>
          <p className="mt-6 text-center text-sm text-muted-foreground">
            {ts("auth_has_account", "auth.hasAccount")}{" "}
            <Link to="/login" className="font-medium text-secondary hover:underline">
              {t('auth.loginTitle')}
            </Link>
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
