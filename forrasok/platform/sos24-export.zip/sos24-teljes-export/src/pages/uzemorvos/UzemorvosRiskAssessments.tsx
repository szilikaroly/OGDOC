import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Shield, Eye, Pencil } from "lucide-react";
import { format } from "date-fns";
import RiskAssessmentForm from "@/components/RiskAssessmentForm";

const STATUS_COLORS: Record<string, string> = {
  draft: "bg-muted text-muted-foreground",
  in_review: "bg-yellow-100 text-yellow-800",
  approved: "bg-green-100 text-green-800",
  archived: "bg-gray-100 text-gray-600",
};

export default function UzemorvosRiskAssessments() {
  const { t } = useTranslation();
  const qc = useQueryClient();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);
  const [filterCompany, setFilterCompany] = useState<string>("all");
  const [filterStatus, setFilterStatus] = useState<string>("all");

  const { data: companies = [] } = useQuery({
    queryKey: ["companies"],
    queryFn: async () => {
      const { data } = await supabase.from("companies").select("id, name").order("name");
      return data ?? [];
    },
  });

  const { data: assessments = [], isLoading } = useQuery({
    queryKey: ["risk_assessments", filterCompany, filterStatus],
    queryFn: async () => {
      let q = supabase
        .from("risk_assessments")
        .select("*, work_areas!inner(name, company_sites!inner(name))")
        .order("created_at", { ascending: false });
      if (filterCompany !== "all") q = q.eq("company_id", filterCompany) as any;
      if (filterStatus !== "all") q = q.eq("status", filterStatus as any);
      const { data, error } = await q;
      if (error) throw error;
      return data ?? [];
    },
  });

  const companyMap = Object.fromEntries(companies.map((c: any) => [c.id, c.name]));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Shield className="h-6 w-6" />
          {t("risk.riskAssessments")}
        </h1>
        <Button onClick={() => { setSelectedId(null); setCreating(true); }}>
          <Plus className="h-4 w-4 mr-1" />
          {t("risk.newAssessment")}
        </Button>
      </div>

      {/* Filters */}
      <div className="flex gap-3">
        <Select value={filterCompany} onValueChange={setFilterCompany}>
          <SelectTrigger className="w-[200px]">
            <SelectValue placeholder={t("risk.company")} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t("common.all")}</SelectItem>
            {companies.map((c: any) => (
              <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder={t("risk.status")} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t("common.all")}</SelectItem>
            <SelectItem value="draft">{t("risk.statusDraft")}</SelectItem>
            <SelectItem value="in_review">{t("risk.statusInReview")}</SelectItem>
            <SelectItem value="approved">{t("risk.statusApproved")}</SelectItem>
            <SelectItem value="archived">{t("risk.statusArchived")}</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      {assessments.length === 0 && !isLoading ? (
        <Card>
          <CardContent className="py-10 text-center text-muted-foreground">
            <p>{t("risk.noAssessments")}</p>
            <p className="text-sm">{t("risk.createFirst")}</p>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t("risk.company")}</TableHead>
                <TableHead>{t("risk.workArea")}</TableHead>
                <TableHead>{t("risk.assessmentDate")}</TableHead>
                <TableHead>{t("risk.assessorName")}</TableHead>
                <TableHead>{t("risk.status")}</TableHead>
                <TableHead>{t("risk.nextReviewDate")}</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {assessments.map((a: any) => (
                <TableRow key={a.id}>
                  <TableCell>{companyMap[a.company_id] ?? "—"}</TableCell>
                  <TableCell>{(a.work_areas as any)?.name ?? "—"}</TableCell>
                  <TableCell>{format(new Date(a.assessment_date), "yyyy-MM-dd")}</TableCell>
                  <TableCell>{a.assessor_name ?? "—"}</TableCell>
                  <TableCell>
                    <Badge className={STATUS_COLORS[a.status] ?? ""} variant="outline">
                      {t(`risk.status${a.status.charAt(0).toUpperCase() + a.status.slice(1).replace("_", "")}` as any) ?? a.status}
                    </Badge>
                  </TableCell>
                  <TableCell>{a.next_review_date ? format(new Date(a.next_review_date), "yyyy-MM-dd") : "—"}</TableCell>
                  <TableCell>
                    <Button variant="ghost" size="icon" onClick={() => { setSelectedId(a.id); setCreating(true); }}>
                      <Pencil className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      )}

      {/* Form dialog */}
      <Dialog open={creating} onOpenChange={setCreating}>
        <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{selectedId ? t("risk.editAssessment") : t("risk.newAssessment")}</DialogTitle>
          </DialogHeader>
          <RiskAssessmentForm
            assessmentId={selectedId}
            onClose={() => {
              setCreating(false);
              qc.invalidateQueries({ queryKey: ["risk_assessments"] });
            }}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
