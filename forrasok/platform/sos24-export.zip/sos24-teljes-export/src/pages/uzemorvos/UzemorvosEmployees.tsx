import { useTranslation } from "react-i18next";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Users } from "lucide-react";
import BulkPatientImport from "@/components/BulkPatientImport";

export default function UzemorvosEmployees() {
  const { t } = useTranslation();
  const qc = useQueryClient();
  const { data: profiles, isLoading } = useQuery({
    queryKey: ["uzemorvos-employees"],
    queryFn: async () => {
      const { data, error } = await supabase.from("profiles").select("user_id, full_name, taj_number, phone, birth_date").order("full_name");
      if (error) throw error;
      return data;
    },
  });

  if (isLoading) return <div className="flex items-center justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Users className="h-6 w-6 text-secondary" />
          <h1 className="text-2xl font-bold">{t('inner.employees')}</h1>
        </div>
        <BulkPatientImport onComplete={() => qc.invalidateQueries({ queryKey: ["uzemorvos-employees"] })} />
      </div>
      <Card>
        <CardHeader><CardTitle className="text-lg">{t('inner.employees')} ({profiles?.length ?? 0})</CardTitle></CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader><TableRow><TableHead>{t('inner.name')}</TableHead><TableHead>{t('inner.taj')}</TableHead><TableHead>{t('inner.birthDate')}</TableHead><TableHead>{t('inner.phone')}</TableHead></TableRow></TableHeader>
            <TableBody>
              {(profiles ?? []).map((p) => (
                <TableRow key={p.user_id}>
                  <TableCell className="font-medium">{p.full_name}</TableCell>
                  <TableCell>{p.taj_number || "—"}</TableCell>
                  <TableCell>{p.birth_date ? new Date(p.birth_date).toLocaleDateString("hu-HU") : "—"}</TableCell>
                  <TableCell>{p.phone || "—"}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
