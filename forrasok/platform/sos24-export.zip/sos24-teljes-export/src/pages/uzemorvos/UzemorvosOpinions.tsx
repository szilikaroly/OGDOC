import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { FileText, Plus, Printer } from "lucide-react";
import SignaturePad from "@/components/SignaturePad";
import ExportButton from "@/components/ExportButton";
import PrintableOpinion from "@/components/PrintableOpinion";
import DocumentBrowser from "@/components/DocumentBrowser";
import BnoSearch from "@/components/BnoSearch";

export default function UzemorvosOpinions() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [printOpinion, setPrintOpinion] = useState<any>(null);
  const [form, setForm] = useState({ patient_id: "", company_id: "", status: "alkalmas", valid_until: "", notes: "", signature_data: "", icd_codes: [] as string[] });

  const STATUS_OPTIONS = [
    { value: "alkalmas", label: t('inner.fit') },
    { value: "nem_alkalmas", label: t('inner.unfit') },
    { value: "feltetelesen_alkalmas", label: t('inner.conditionallyFit') },
    { value: "ideiglenes", label: t('inner.temporary') },
  ];

  const { data: profiles } = useQuery({
    queryKey: ["uzemorvos-profiles-for-opinions"],
    queryFn: async () => {
      const { data } = await supabase.from("profiles").select("user_id, full_name, taj_number, birth_date").order("full_name");
      return data ?? [];
    },
  });

  const { data: companies } = useQuery({
    queryKey: ["uzemorvos-companies-for-opinions"],
    queryFn: async () => {
      const { data } = await supabase.from("companies").select("id, name, address").order("name");
      return data ?? [];
    },
  });

  const { data: opinions, isLoading } = useQuery({
    queryKey: ["uzemorvos-opinions"],
    queryFn: async () => {
      const { data, error } = await supabase.from("medical_opinions").select("*").order("opinion_date", { ascending: false });
      if (error) throw error;
      const ids = [...new Set([...data.map((o) => o.patient_id), ...data.map((o) => o.doctor_id)])];
      const { data: profs } = await supabase.from("profiles").select("user_id, full_name, taj_number, birth_date, signature_url").in("user_id", ids);
      const compIds = [...new Set(data.map((o) => o.company_id).filter(Boolean))] as string[];
      const { data: comps } = compIds.length ? await supabase.from("companies").select("id, name").in("id", compIds) : { data: [] };
      
      const examRefIds = data.filter(o => o.appointment_id).map(o => o.appointment_id);
      let positionMap: Record<string, string> = {};
      if (examRefIds.length) {
        const { data: exams } = await supabase.from("examinations").select("appointment_id, referral_id").in("appointment_id", examRefIds);
        const refIds = (exams ?? []).map(e => e.referral_id).filter(Boolean);
        if (refIds.length) {
          const { data: refs } = await supabase.from("referrals").select("id, position").in("id", refIds);
          const refMap = Object.fromEntries((refs ?? []).map(r => [r.id, r.position]));
          (exams ?? []).forEach(e => {
            if (e.referral_id && refMap[e.referral_id]) {
              positionMap[e.appointment_id] = refMap[e.referral_id];
            }
          });
        }
      }

      // Resolve signature URLs from private storage
      const { resolveSignatureUrl } = await import("@/lib/storage-utils");
      const enriched = await Promise.all(data.map(async (o) => {
        const rawSigUrl = (profs ?? []).find((p) => p.user_id === o.doctor_id)?.signature_url ?? null;
        const resolvedSig = await resolveSignatureUrl(rawSigUrl);
        return {
          ...o,
          patient_name: (profs ?? []).find((p) => p.user_id === o.patient_id)?.full_name ?? "—",
          patient_taj: (profs ?? []).find((p) => p.user_id === o.patient_id)?.taj_number ?? "",
          patient_birth: (profs ?? []).find((p) => p.user_id === o.patient_id)?.birth_date ?? "",
          doctor_name: (profs ?? []).find((p) => p.user_id === o.doctor_id)?.full_name ?? "—",
          signature_url: resolvedSig,
          company_name: (comps ?? []).find((c) => c.id === o.company_id)?.name ?? "",
          position: o.appointment_id ? positionMap[o.appointment_id] ?? "" : "",
        };
      }));
      return enriched;
    },
  });

  const createOpinion = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("medical_opinions").insert({
        patient_id: form.patient_id, doctor_id: user!.id, company_id: form.company_id || null,
        status: form.status as any, valid_until: form.valid_until || null, notes: form.notes || null,
        signature_data: form.signature_data || null,
        icd_codes: form.icd_codes,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["uzemorvos-opinions"] });
      toast({ title: t('inner.opinionCreated') });
      setDialogOpen(false);
      setForm({ patient_id: "", company_id: "", status: "alkalmas", valid_until: "", notes: "", signature_data: "", icd_codes: [] });
    },
    onError: (e: any) => toast({ variant: "destructive", title: t('common.error'), description: e.message }),
  });

  const handlePrint = (opinion: any) => {
    setPrintOpinion(opinion);
    setTimeout(() => window.print(), 300);
  };

  if (isLoading) return <div className="flex items-center justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>;

  return (
    <div className="space-y-6">
      {printOpinion && <PrintableOpinion opinion={printOpinion} />}

      <div className="flex items-center justify-between print:hidden">
        <div className="flex items-center gap-3"><FileText className="h-6 w-6 text-secondary" /><h1 className="text-2xl font-bold">{t('inner.fitnessOpinions')}</h1></div>
        <div className="flex gap-2">
          <ExportButton
            filename="velemenyek"
            headers={[t('inner.patient'), t('inner.doctor'), t('inner.date'), t('inner.validUntil'), t('inner.result')]}
            rows={(opinions ?? []).map((o) => [o.patient_name, o.doctor_name, o.opinion_date, o.valid_until || "", STATUS_OPTIONS.find((s) => s.value === o.status)?.label ?? o.status])}
          />
          <Button onClick={() => setDialogOpen(true)}><Plus className="h-4 w-4 mr-2" />{t('inner.newOpinion')}</Button>
        </div>
      </div>
      <Card className="print:hidden">
        <CardHeader><CardTitle className="text-lg">{t('page.opinions')} ({opinions?.length ?? 0})</CardTitle></CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader><TableRow><TableHead>{t('inner.patient')}</TableHead><TableHead>{t('inner.doctor')}</TableHead><TableHead>{t('inner.date')}</TableHead><TableHead>{t('inner.validUntil')}</TableHead><TableHead>{t('inner.result')}</TableHead><TableHead>{t('inner.action')}</TableHead></TableRow></TableHeader>
            <TableBody>
              {(opinions ?? []).map((o) => (
                <TableRow key={o.id}>
                  <TableCell className="font-medium">{o.patient_name}</TableCell>
                  <TableCell>{o.doctor_name}</TableCell>
                  <TableCell>{new Date(o.opinion_date).toLocaleDateString("hu-HU")}</TableCell>
                  <TableCell>{o.valid_until ? new Date(o.valid_until).toLocaleDateString("hu-HU") : "—"}</TableCell>
                  <TableCell><Badge variant={o.status === "alkalmas" ? "default" : o.status === "nem_alkalmas" ? "destructive" : "secondary"}>{STATUS_OPTIONS.find((s) => s.value === o.status)?.label ?? o.status}</Badge></TableCell>
                  <TableCell className="space-x-1"><Button size="sm" variant="outline" onClick={() => handlePrint(o)}><Printer className="h-4 w-4 mr-1" />{t('inner.print')}</Button></TableCell>
                </TableRow>
              ))}
              {(opinions ?? []).length === 0 && <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-8">{t('inner.noOpinion')}</TableCell></TableRow>}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{t('inner.newOpinionTitle')}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label>{t('inner.patient')}</Label>
              <Select value={form.patient_id} onValueChange={(v) => setForm((f) => ({ ...f, patient_id: v }))}><SelectTrigger><SelectValue placeholder={t('inner.select')} /></SelectTrigger><SelectContent>{(profiles ?? []).map((p) => <SelectItem key={p.user_id} value={p.user_id}>{p.full_name}</SelectItem>)}</SelectContent></Select>
            </div>
            <div className="space-y-1.5">
              <Label>{t('inner.companyOptional')}</Label>
              <Select value={form.company_id} onValueChange={(v) => setForm((f) => ({ ...f, company_id: v }))}><SelectTrigger><SelectValue placeholder={t('inner.select')} /></SelectTrigger><SelectContent>{(companies ?? []).map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent></Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>{t('inner.result')}</Label>
                <Select value={form.status} onValueChange={(v) => setForm((f) => ({ ...f, status: v }))}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{STATUS_OPTIONS.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}</SelectContent></Select>
              </div>
              <div className="space-y-1.5"><Label>{t('inner.validity')}</Label><Input type="date" value={form.valid_until} onChange={(e) => setForm((f) => ({ ...f, valid_until: e.target.value }))} /></div>
            </div>
            <div className="space-y-1.5"><Label>{t('inner.notes')}</Label><Textarea value={form.notes} onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))} rows={3} /></div>
            <div className="space-y-1.5">
              <Label>{t('icd.diagnosisCodes')}</Label>
              <BnoSearch
                values={form.icd_codes}
                onChange={(code) => setForm((f) => ({ ...f, icd_codes: [...f.icd_codes, code] }))}
                onRemove={(code) => setForm((f) => ({ ...f, icd_codes: f.icd_codes.filter((c) => c !== code) }))}
                multiple
              />
            </div>
            <div className="space-y-1.5">
              <Label>{t('inner.digitalSignature')}</Label>
              <SignaturePad onSave={(sig) => setForm((f) => ({ ...f, signature_data: sig }))} />
              {form.signature_data && <p className="text-xs text-green-600">{t('inner.signatureSaved')}</p>}
            </div>
            <Button className="w-full" onClick={() => createOpinion.mutate()} disabled={createOpinion.isPending || !form.patient_id}>{t('inner.createOpinion')}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
