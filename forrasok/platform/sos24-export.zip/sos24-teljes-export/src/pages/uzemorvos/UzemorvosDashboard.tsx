import { useTranslation } from "react-i18next";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/contexts/AuthContext";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { FileCheck, Calendar, Building2, FileUp } from "lucide-react";
import DoctorSignatureUpload from "@/components/DoctorSignatureUpload";
import { BarChart, Bar, PieChart, Pie, Cell, ResponsiveContainer, XAxis, YAxis, Tooltip } from "recharts";
import { format, subWeeks, startOfWeek, endOfWeek } from "date-fns";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from "react-router-dom";

const RESULT_COLORS: Record<string, string> = {
  alkalmas: "hsl(var(--chart-2))",
  nem_alkalmas: "hsl(var(--chart-1))",
  feltetelesen_alkalmas: "hsl(var(--chart-3))",
  ideiglenes: "hsl(var(--chart-4))",
};

export default function UzemorvosDashboard() {
  const { t } = useTranslation();
  const { profile, user } = useAuth();
  const navigate = useNavigate();

  const RESULT_LABELS: Record<string, string> = {
    alkalmas: t("page.fit"), nem_alkalmas: t("page.unfit"),
    feltetelesen_alkalmas: t("page.conditionallyFit"), ideiglenes: t("page.temporary"),
  };

  const { data: todayExams } = useQuery({
    queryKey: ["uzemorvos-today-exams"],
    queryFn: async () => {
      const today = new Date().toISOString().split("T")[0];
      const { count } = await supabase.from("examinations").select("id", { count: "exact", head: true }).eq("doctor_id", user!.id).gte("created_at", `${today}T00:00:00`);
      return count ?? 0;
    },
    enabled: !!user,
  });

  const { data: companyCount } = useQuery({
    queryKey: ["uzemorvos-companies"],
    queryFn: async () => {
      const { count } = await supabase.from("companies").select("id", { count: "exact", head: true });
      return count ?? 0;
    },
  });

  const { data: pendingReferrals } = useQuery({
    queryKey: ["uzemorvos-pending-referrals"],
    queryFn: async () => {
      const { count } = await supabase.from("referrals").select("id", { count: "exact", head: true }).eq("status", "sent");
      return count ?? 0;
    },
  });

  const { data: todaySlots } = useQuery({
    queryKey: ["uzemorvos-today-slots"],
    queryFn: async () => {
      const today = new Date().toISOString().split("T")[0];
      const { count } = await supabase.from("appointment_slots").select("id", { count: "exact", head: true }).gte("slot_start", `${today}T00:00:00`).lt("slot_start", `${today}T23:59:59`);
      return count ?? 0;
    },
  });

  const { data: weeklyExams } = useQuery({
    queryKey: ["uzemorvos-weekly-exams"],
    queryFn: async () => {
      const fourWeeksAgo = subWeeks(new Date(), 4).toISOString();
      const { data } = await supabase.from("examinations").select("created_at").eq("doctor_id", user!.id).gte("created_at", fourWeeksAgo);
      const buckets: { label: string; start: Date; end: Date; count: number }[] = [];
      for (let i = 3; i >= 0; i--) {
        const s = startOfWeek(subWeeks(new Date(), i), { weekStartsOn: 1 });
        const e = endOfWeek(subWeeks(new Date(), i), { weekStartsOn: 1 });
        buckets.push({ label: format(s, "MM.dd"), start: s, end: e, count: 0 });
      }
      data?.forEach((ex) => {
        const d = new Date(ex.created_at);
        const bucket = buckets.find((b) => d >= b.start && d <= b.end);
        if (bucket) bucket.count++;
      });
      return buckets.map((b) => ({ [t("page.week")]: b.label, [t("page.exam")]: b.count }));
    },
    enabled: !!user,
  });

  const { data: resultDist } = useQuery({
    queryKey: ["uzemorvos-result-dist"],
    queryFn: async () => {
      const { data } = await supabase.from("examinations").select("result").eq("doctor_id", user!.id);
      const counts: Record<string, number> = {};
      data?.forEach((e) => { counts[e.result] = (counts[e.result] || 0) + 1; });
      return Object.entries(counts).map(([name, value]) => ({ name: RESULT_LABELS[name] || name, value, color: RESULT_COLORS[name] || "hsl(var(--chart-5))" }));
    },
    enabled: !!user,
  });

  const { data: expiringExams } = useQuery({
    queryKey: ["uzemorvos-expiring-exams"],
    queryFn: async () => {
      const today = new Date().toISOString().split("T")[0];
      const in30 = new Date(Date.now() + 30 * 86400000).toISOString().split("T")[0];
      const { data } = await supabase.from("examinations").select("id, patient_id, valid_until, result, exam_type").eq("doctor_id", user!.id).not("valid_until", "is", null).lte("valid_until", in30).order("valid_until", { ascending: true }).limit(10);
      if (!data?.length) return [];
      const ids = [...new Set(data.map((e) => e.patient_id))];
      const { data: profiles } = await supabase.from("profiles").select("user_id, full_name").in("user_id", ids);
      const nameMap = Object.fromEntries(profiles?.map((p) => [p.user_id, p.full_name]) ?? []);
      return data.map((e) => ({ ...e, patientName: nameMap[e.patient_id] || "—", expired: e.valid_until! < today }));
    },
    enabled: !!user,
  });

  const { data: pendingReferralsList } = useQuery({
    queryKey: ["uzemorvos-pending-referrals-list"],
    queryFn: async () => {
      const { data } = await supabase.from("referrals").select("id, employee_id, exam_reason, created_at, company_id").eq("status", "sent").order("created_at", { ascending: false }).limit(5);
      if (!data?.length) return [];
      const empIds = [...new Set(data.map((r) => r.employee_id))];
      const compIds = [...new Set(data.map((r) => r.company_id))];
      const [{ data: profiles }, { data: companies }] = await Promise.all([
        supabase.from("profiles").select("user_id, full_name").in("user_id", empIds),
        supabase.from("companies").select("id, name").in("id", compIds),
      ]);
      const nameMap = Object.fromEntries(profiles?.map((p) => [p.user_id, p.full_name]) ?? []);
      const compMap = Object.fromEntries(companies?.map((c) => [c.id, c.name]) ?? []);
      return data.map((r) => ({ ...r, employeeName: nameMap[r.employee_id] || "—", companyName: compMap[r.company_id] || "—" }));
    },
  });

  const stats = [
    { label: t("page.todayExams"), icon: FileCheck, value: todayExams ?? "—" },
    { label: t("page.appointmentsToday"), icon: Calendar, value: todaySlots ?? "—" },
    { label: t("page.companies"), icon: Building2, value: companyCount ?? "—" },
    { label: t("page.incomingReferrals"), icon: FileUp, value: pendingReferrals ?? "—" },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">{t("page.welcomeDoctor", { name: profile?.full_name })}</h1>
        <p className="text-muted-foreground">{t("page.doctorOverview")}</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s) => (
          <Card key={s.label} className="card-luxury">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">{s.label}</CardTitle>
              <s.icon className="h-5 w-5 text-secondary" />
            </CardHeader>
            <CardContent><p className="text-2xl font-bold">{s.value}</p></CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader><CardTitle className="text-base">{t("page.weeklyExams")}</CardTitle></CardHeader>
          <CardContent>
            {weeklyExams?.length ? (
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={weeklyExams}>
                  <XAxis dataKey={t("page.week")} tick={{ fontSize: 12 }} />
                  <YAxis allowDecimals={false} />
                  <Tooltip />
                  <Bar dataKey={t("page.exam")} fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : <p className="text-muted-foreground text-sm">{t("common.noData")}</p>}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">{t("page.resultDistribution")}</CardTitle></CardHeader>
          <CardContent>
            {resultDist?.length ? (
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie data={resultDist} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
                    {resultDist.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            ) : <p className="text-muted-foreground text-sm">{t("common.noData")}</p>}
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader><CardTitle className="text-base">{t("page.expiringExamsShort")}</CardTitle></CardHeader>
           <CardContent className="overflow-x-auto">
            {expiringExams?.length ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>{t("page.patient")}</TableHead>
                    <TableHead>{t("page.type")}</TableHead>
                    <TableHead>{t("page.expiry")}</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {expiringExams.map((e) => (
                    <TableRow key={e.id} className={e.expired ? "bg-destructive/10" : "bg-yellow-500/10"}>
                      <TableCell>{e.patientName}</TableCell>
                      <TableCell>{e.exam_type}</TableCell>
                      <TableCell>{e.valid_until}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : <p className="text-muted-foreground text-sm">{t("page.noExpiringExam")}</p>}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">{t("page.pendingReferrals")}</CardTitle></CardHeader>
           <CardContent className="overflow-x-auto">
            {pendingReferralsList?.length ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>{t("page.employee")}</TableHead>
                    <TableHead>{t("page.company")}</TableHead>
                    <TableHead>{t("page.reason")}</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pendingReferralsList.map((r) => (
                    <TableRow key={r.id} className="cursor-pointer hover:bg-muted/50" onClick={() => navigate("/uzemorvos/referrals")}>
                      <TableCell>{r.employeeName}</TableCell>
                      <TableCell>{r.companyName}</TableCell>
                      <TableCell>{r.exam_reason}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : <p className="text-muted-foreground text-sm">{t("page.noPendingReferral")}</p>}
          </CardContent>
        </Card>
      </div>

      <DoctorSignatureUpload />
    </div>
  );
}
