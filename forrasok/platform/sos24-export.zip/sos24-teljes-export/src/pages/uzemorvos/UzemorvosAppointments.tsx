import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Calendar, ChevronLeft, ChevronRight, Check, X, Search, Sparkles, GripVertical, Clock } from "lucide-react";
import DOMPurify from "dompurify";
import { isNonWorkingDay, isHoliday } from "@/lib/hungarian-holidays";
import { cn } from "@/lib/utils";
import { useTranslation } from "react-i18next";

// Helpers
function startOfWeek(d: Date): Date {
  const r = new Date(d);
  const day = r.getDay();
  const diff = day === 0 ? -6 : 1 - day;
  r.setDate(r.getDate() + diff);
  r.setHours(0, 0, 0, 0);
  return r;
}
function addDays(d: Date, n: number): Date {
  const r = new Date(d);
  r.setDate(r.getDate() + n);
  return r;
}
function formatDate(d: Date): string {
  return d.toISOString().split("T")[0];
}
function timeStr(d: string) {
  return new Date(d).toLocaleTimeString("hu-HU", { hour: "2-digit", minute: "2-digit" });
}

const STATUS_COLORS: Record<string, string> = {
  pending: "bg-amber-100 border-amber-300 dark:bg-amber-950/40",
  confirmed: "bg-emerald-100 border-emerald-300 dark:bg-emerald-950/40",
  cancelled: "bg-red-100 border-red-300 dark:bg-red-950/40 opacity-50",
  completed: "bg-blue-100 border-blue-300 dark:bg-blue-950/40",
  no_show: "bg-gray-100 border-gray-300 dark:bg-gray-950/40 opacity-50",
};

export default function UzemorvosAppointments() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [weekStart, setWeekStart] = useState(() => startOfWeek(new Date()));
  const [selectedAppointment, setSelectedAppointment] = useState<any>(null);
  const [detailOpen, setDetailOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [aiOpen, setAiOpen] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiResult, setAiResult] = useState("");
  const [aiComplaint, setAiComplaint] = useState("");
  const [searchFilters, setSearchFilters] = useState({ dateFrom: "", dateTo: "", service_id: "", location_id: "" });
  const [dragItem, setDragItem] = useState<string | null>(null);

  const DAY_NAMES = [t("inner.monday"), t("inner.tuesday"), t("inner.wednesday"), t("inner.thursday"), t("inner.friday"), t("inner.saturday"), t("inner.sunday")];
  const STATUS_LABELS: Record<string, string> = {
    pending: t("inner.pending"), confirmed: t("inner.confirmed"), cancelled: t("inner.cancelled"), completed: t("inner.completed"), no_show: t("inner.noShow"),
  };

  const weekEnd = addDays(weekStart, 6);

  const { data: slots } = useQuery({
    queryKey: ["uzemorvos-calendar-slots", formatDate(weekStart)],
    queryFn: async () => {
      const from = new Date(weekStart);
      const to = addDays(weekStart, 7);
      const { data, error } = await supabase
        .from("appointment_slots")
        .select("*")
        .gte("slot_start", from.toISOString())
        .lt("slot_start", to.toISOString())
        .eq("is_active", true)
        .order("slot_start");
      if (error) throw error;
      return data;
    },
  });

  const { data: appointments, isLoading } = useQuery({
    queryKey: ["uzemorvos-calendar-appts", formatDate(weekStart)],
    queryFn: async () => {
      const slotIds = (slots ?? []).map((s) => s.id);
      if (!slotIds.length) return [];
      const { data, error } = await supabase
        .from("appointments")
        .select("*")
        .in("slot_id", slotIds)
        .order("created_at");
      if (error) throw error;
      const pIds = [...new Set(data.map((a) => a.patient_id))];
      const { data: profiles } = pIds.length
        ? await supabase.from("profiles").select("user_id, full_name, taj_number").in("user_id", pIds)
        : { data: [] };
      return data.map((a) => ({
        ...a,
        patient_name: (profiles ?? []).find((p) => p.user_id === a.patient_id)?.full_name ?? "—",
        patient_taj: (profiles ?? []).find((p) => p.user_id === a.patient_id)?.taj_number ?? "",
      }));
    },
    enabled: (slots ?? []).length > 0,
  });

  const { data: allAppointments } = useQuery({
    queryKey: ["uzemorvos-all-appointments"],
    queryFn: async () => {
      const { data, error } = await supabase.from("appointments").select("*").order("created_at", { ascending: false }).limit(100);
      if (error) throw error;
      const pIds = [...new Set(data.map((a) => a.patient_id))];
      const { data: profiles } = pIds.length
        ? await supabase.from("profiles").select("user_id, full_name").in("user_id", pIds)
        : { data: [] };
      return data.map((a) => ({
        ...a,
        patient_name: (profiles ?? []).find((p) => p.user_id === a.patient_id)?.full_name ?? "—",
      }));
    },
  });

  const { data: services } = useQuery({
    queryKey: ["calendar-services"],
    queryFn: async () => {
      const { data } = await supabase.from("services").select("id, name, duration_min").eq("is_active", true).order("name");
      return data ?? [];
    },
  });

  const { data: locations } = useQuery({
    queryKey: ["calendar-locations"],
    queryFn: async () => {
      const { data } = await supabase.from("locations").select("id, name").eq("is_active", true).order("name");
      return data ?? [];
    },
  });

  const { data: freeSlots, refetch: searchSlots, isFetching: searchLoading } = useQuery({
    queryKey: ["free-slot-search", searchFilters],
    queryFn: async () => {
      let q = supabase
        .from("appointment_slots")
        .select("*")
        .eq("is_active", true)
        .gte("slot_start", searchFilters.dateFrom ? `${searchFilters.dateFrom}T00:00:00` : new Date().toISOString())
        .order("slot_start")
        .limit(50);
      if (searchFilters.dateTo) q = q.lte("slot_start", `${searchFilters.dateTo}T23:59:59`);
      if (searchFilters.service_id) q = q.eq("service_id", searchFilters.service_id);
      if (searchFilters.location_id) q = q.eq("location_id", searchFilters.location_id);
      const { data, error } = await q;
      if (error) throw error;

      const slotIds = data.map((s) => s.id);
      const { data: bookings } = slotIds.length
        ? await supabase.from("appointments").select("slot_id").in("slot_id", slotIds).neq("status", "cancelled")
        : { data: [] };
      const counts: Record<string, number> = {};
      (bookings ?? []).forEach((b) => { counts[b.slot_id!] = (counts[b.slot_id!] ?? 0) + 1; });

      return data
        .map((s) => ({ ...s, booked: counts[s.id] ?? 0, free: s.capacity - (counts[s.id] ?? 0) }))
        .filter((s) => s.free > 0);
    },
    enabled: false,
  });

  const calendarData = useMemo(() => {
    const map: Record<string, { slots: any[]; appointments: any[] }> = {};
    for (let i = 0; i < 7; i++) {
      map[formatDate(addDays(weekStart, i))] = { slots: [], appointments: [] };
    }
    for (const s of slots ?? []) {
      const day = s.slot_start.split("T")[0];
      if (map[day]) map[day].slots.push(s);
    }
    for (const a of appointments ?? []) {
      const slot = (slots ?? []).find((s) => s.id === a.slot_id);
      if (slot) {
        const day = slot.slot_start.split("T")[0];
        if (map[day]) map[day].appointments.push({ ...a, slot });
      }
    }
    return map;
  }, [slots, appointments, weekStart]);

  const updateStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const { error } = await supabase.from("appointments").update({ status: status as any }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["uzemorvos-calendar-appts"] });
      qc.invalidateQueries({ queryKey: ["uzemorvos-all-appointments"] });
      toast({ title: t("inner.statusUpdated") });
      setDetailOpen(false);
    },
  });

  const moveAppointment = useMutation({
    mutationFn: async ({ appointmentId, newSlotId }: { appointmentId: string; newSlotId: string }) => {
      const slot = (slots ?? []).find((s) => s.id === newSlotId);
      if (!slot) throw new Error(t("inner.slotNotFound"));
      const { count } = await supabase.from("appointments").select("id", { count: "exact", head: true }).eq("slot_id", newSlotId).neq("status", "cancelled");
      if ((count ?? 0) >= slot.capacity) throw new Error(t("inner.slotFull"));

      const { error } = await supabase.from("appointments").update({ slot_id: newSlotId }).eq("id", appointmentId);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["uzemorvos-calendar-appts"] });
      toast({ title: t("inner.appointmentMoved") });
    },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  const handleDrop = (slotId: string) => {
    if (dragItem) {
      moveAppointment.mutate({ appointmentId: dragItem, newSlotId: slotId });
      setDragItem(null);
    }
  };

  const generateAiSuggestion = async () => {
    setAiLoading(true);
    setAiResult("");
    try {
      const { data, error } = await supabase.functions.invoke("ai-analysis", {
        body: {
          type: "appointment_suggestion",
          context: {
            complaint: aiComplaint,
            available_slots: (freeSlots ?? []).slice(0, 20).map((s) => ({
              id: s.id, start: s.slot_start, end: s.slot_end, service_id: s.service_id, location_id: s.location_id,
            })),
            services: services?.map((s) => ({ id: s.id, name: s.name, duration: s.duration_min })),
            locations: locations?.map((l) => ({ id: l.id, name: l.name })),
          },
        },
      });
      if (error) throw error;
      setAiResult(data?.analysis || data?.result || t("inner.noData"));
    } catch (e: any) {
      toast({ variant: "destructive", title: t("inner.aiError"), description: e.message });
    } finally {
      setAiLoading(false);
    }
  };

  const getServiceName = (id: string | null) => (services ?? []).find((s) => s.id === id)?.name ?? "";
  const getLocationName = (id: string | null) => (locations ?? []).find((l) => l.id === id)?.name ?? "";

  if (isLoading) return <div className="flex items-center justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <Calendar className="h-6 w-6 text-secondary" />
          <h1 className="text-2xl font-bold">{t("inner.appointments")}</h1>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={() => { setSearchOpen(true); searchSlots(); }}>
            <Search className="h-4 w-4 mr-1" />{t("inner.freeSlotSearch")}
          </Button>
          <Button variant="outline" size="sm" onClick={() => setAiOpen(true)}>
            <Sparkles className="h-4 w-4 mr-1" />{t("inner.aiAppointmentSuggestion")}
          </Button>
        </div>
      </div>

      <Tabs defaultValue="calendar">
        <TabsList>
          <TabsTrigger value="calendar">{t("inner.calendarView")}</TabsTrigger>
          <TabsTrigger value="list">{t("inner.listView")}</TabsTrigger>
        </TabsList>

        <TabsContent value="calendar" className="space-y-4">
          <div className="flex items-center justify-between">
            <Button variant="ghost" size="sm" onClick={() => setWeekStart(addDays(weekStart, -7))}>
              <ChevronLeft className="h-4 w-4 mr-1" />{t("inner.previousWeek")}
            </Button>
            <div className="text-sm font-medium">
              {weekStart.toLocaleDateString("hu-HU", { year: "numeric", month: "long", day: "numeric" })}
              {" – "}
              {weekEnd.toLocaleDateString("hu-HU", { year: "numeric", month: "long", day: "numeric" })}
            </div>
            <div className="flex gap-1">
              <Button variant="ghost" size="sm" onClick={() => setWeekStart(startOfWeek(new Date()))}>{t("inner.today")}</Button>
              <Button variant="ghost" size="sm" onClick={() => setWeekStart(addDays(weekStart, 7))}>
                {t("inner.nextWeek")}<ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-7 gap-2">
            {Array.from({ length: 7 }).map((_, i) => {
              const day = addDays(weekStart, i);
              const dateStr = formatDate(day);
              const dayData = calendarData[dateStr] ?? { slots: [], appointments: [] };
              const nonWorking = isNonWorkingDay(day);
              const holiday = isHoliday(day);
              const isToday = formatDate(new Date()) === dateStr;

              return (
                <Card key={dateStr} className={cn("min-h-[150px] flex flex-col", nonWorking && "opacity-60", isToday && "ring-2 ring-secondary")}>
                  <CardHeader className="p-2 pb-1">
                    <div className="flex items-center justify-between">
                      <div>
                        <span className={cn("text-xs font-semibold", isToday && "text-secondary")}>{DAY_NAMES[i]}</span>
                        <p className="text-lg font-bold leading-tight">{day.getDate()}</p>
                      </div>
                      {dayData.slots.length > 0 && (
                        <Badge variant="outline" className="text-[10px]">{dayData.slots.length} slot</Badge>
                      )}
                    </div>
                    {nonWorking && <Badge variant="secondary" className="text-[10px] mt-1 w-fit">{holiday?.name ?? t("inner.nonWorkingDay")}</Badge>}
                  </CardHeader>
                  <CardContent className="p-2 pt-0 flex-1 space-y-1 overflow-y-auto max-h-[300px]">
                    {dayData.slots.map((slot) => {
                      const slotAppts = dayData.appointments.filter((a) => a.slot_id === slot.id && a.status !== "cancelled");
                      const isFull = slotAppts.length >= slot.capacity;
                      return (
                        <div
                          key={slot.id}
                          className={cn(
                            "rounded border p-1.5 text-[11px] space-y-0.5 transition-colors",
                            isFull ? "bg-muted/50 border-muted-foreground/20" : "bg-primary/5 border-primary/20",
                            dragItem && !isFull && "ring-1 ring-dashed ring-primary/40"
                          )}
                          onDragOver={(e) => { if (!isFull) e.preventDefault(); }}
                          onDrop={() => { if (!isFull) handleDrop(slot.id); }}
                        >
                          <div className="flex justify-between items-center">
                            <span className="font-semibold">{timeStr(slot.slot_start)}–{timeStr(slot.slot_end)}</span>
                            <span className="text-muted-foreground">{slotAppts.length}/{slot.capacity}</span>
                          </div>
                          {slot.service_id && <p className="text-muted-foreground truncate">{getServiceName(slot.service_id)}</p>}
                          {slotAppts.map((appt) => (
                            <div
                              key={appt.id}
                              draggable
                              onDragStart={() => setDragItem(appt.id)}
                              onDragEnd={() => setDragItem(null)}
                              onClick={() => { setSelectedAppointment(appt); setDetailOpen(true); }}
                              className={cn("rounded px-1.5 py-0.5 border cursor-pointer flex items-center gap-1", STATUS_COLORS[appt.status] ?? "")}
                            >
                              <GripVertical className="h-3 w-3 text-muted-foreground/50 shrink-0" />
                              <span className="truncate font-medium">{appt.patient_name}</span>
                            </div>
                          ))}
                        </div>
                      );
                    })}
                    {dayData.slots.length === 0 && !nonWorking && (
                      <p className="text-[10px] text-muted-foreground text-center pt-4">{t("inner.noSlot")}</p>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="list">
          <Card>
            <CardHeader><CardTitle className="text-lg">{t("inner.recentAppointments")}</CardTitle></CardHeader>
            <CardContent className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-2 px-2">{t("inner.patient")}</th>
                    <th className="text-left py-2 px-2">{t("inner.status")}</th>
                    <th className="text-left py-2 px-2">{t("inner.notes")}</th>
                    <th className="text-left py-2 px-2">{t("inner.date")}</th>
                    <th className="text-left py-2 px-2">{t("inner.actions")}</th>
                  </tr>
                </thead>
                <tbody>
                  {(allAppointments ?? []).map((a) => (
                    <tr key={a.id} className="border-b hover:bg-muted/50">
                      <td className="py-2 px-2 font-medium">{a.patient_name}</td>
                      <td className="py-2 px-2"><Badge variant={a.status === "confirmed" ? "default" : a.status === "cancelled" ? "destructive" : "secondary"}>{STATUS_LABELS[a.status] ?? a.status}</Badge></td>
                      <td className="py-2 px-2 max-w-[200px] truncate">{a.notes || "—"}</td>
                      <td className="py-2 px-2">{new Date(a.created_at).toLocaleDateString("hu-HU")}</td>
                      <td className="py-2 px-2">
                        {a.status === "pending" && (
                          <div className="flex gap-1">
                            <Button size="sm" variant="ghost" onClick={() => updateStatus.mutate({ id: a.id, status: "confirmed" })}><Check className="h-4 w-4 text-primary" /></Button>
                            <Button size="sm" variant="ghost" onClick={() => updateStatus.mutate({ id: a.id, status: "cancelled" })}><X className="h-4 w-4 text-destructive" /></Button>
                          </div>
                        )}
                      </td>
                    </tr>
                  ))}
                  {(allAppointments ?? []).length === 0 && (
                    <tr><td colSpan={5} className="text-center py-8 text-muted-foreground">{t("inner.noAppointment")}</td></tr>
                  )}
                </tbody>
              </table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{t("inner.appointmentDetails")}</DialogTitle></DialogHeader>
          {selectedAppointment && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div><Label className="text-xs text-muted-foreground">{t("inner.patient")}</Label><p className="font-medium">{selectedAppointment.patient_name}</p></div>
                <div><Label className="text-xs text-muted-foreground">{t("inner.taj")}</Label><p>{selectedAppointment.patient_taj || "—"}</p></div>
                <div><Label className="text-xs text-muted-foreground">{t("inner.status")}</Label><p><Badge variant={selectedAppointment.status === "confirmed" ? "default" : "secondary"}>{STATUS_LABELS[selectedAppointment.status]}</Badge></p></div>
                {selectedAppointment.slot && (
                  <div><Label className="text-xs text-muted-foreground">{t("inner.appointments")}</Label><p>{timeStr(selectedAppointment.slot.slot_start)}–{timeStr(selectedAppointment.slot.slot_end)}</p></div>
                )}
              </div>
              {selectedAppointment.notes && <div><Label className="text-xs text-muted-foreground">{t("inner.notes")}</Label><p className="text-sm">{selectedAppointment.notes}</p></div>}
              <div className="flex gap-2 pt-2">
                {selectedAppointment.status === "pending" && (
                  <>
                    <Button size="sm" onClick={() => updateStatus.mutate({ id: selectedAppointment.id, status: "confirmed" })}><Check className="h-4 w-4 mr-1" />{t("inner.confirm")}</Button>
                    <Button size="sm" variant="destructive" onClick={() => updateStatus.mutate({ id: selectedAppointment.id, status: "cancelled" })}><X className="h-4 w-4 mr-1" />{t("inner.reject")}</Button>
                  </>
                )}
                {selectedAppointment.status === "confirmed" && (
                  <Button size="sm" onClick={() => updateStatus.mutate({ id: selectedAppointment.id, status: "completed" })}><Check className="h-4 w-4 mr-1" />{t("inner.completed")}</Button>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={searchOpen} onOpenChange={setSearchOpen}>
        <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{t("inner.freeSlotSearchTitle")}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1"><Label className="text-xs">{t("inner.dateFrom")}</Label><Input type="date" value={searchFilters.dateFrom} onChange={(e) => setSearchFilters((f) => ({ ...f, dateFrom: e.target.value }))} /></div>
              <div className="space-y-1"><Label className="text-xs">{t("inner.dateTo")}</Label><Input type="date" value={searchFilters.dateTo} onChange={(e) => setSearchFilters((f) => ({ ...f, dateTo: e.target.value }))} /></div>
              <div className="space-y-1">
                <Label className="text-xs">{t("inner.service")}</Label>
                <Select value={searchFilters.service_id} onValueChange={(v) => setSearchFilters((f) => ({ ...f, service_id: v === "all" ? "" : v }))}>
                  <SelectTrigger><SelectValue placeholder={t("inner.allOption")} /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">{t("inner.allOption")}</SelectItem>
                    {(services ?? []).map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label className="text-xs">{t("inner.location")}</Label>
                <Select value={searchFilters.location_id} onValueChange={(v) => setSearchFilters((f) => ({ ...f, location_id: v === "all" ? "" : v }))}>
                  <SelectTrigger><SelectValue placeholder={t("inner.allOption")} /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">{t("inner.allOption")}</SelectItem>
                    {(locations ?? []).map((l) => <SelectItem key={l.id} value={l.id}>{l.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <Button className="w-full" onClick={() => searchSlots()} disabled={searchLoading}>
              <Search className="h-4 w-4 mr-1" />{searchLoading ? t("inner.searching") : t("inner.search")}
            </Button>

            {freeSlots && (
              <div className="space-y-2">
                <p className="text-sm font-medium">{freeSlots.length} {t("inner.freeSlots")}</p>
                {freeSlots.map((s) => (
                  <div key={s.id} className="flex items-center justify-between p-2 rounded border text-sm">
                    <div>
                      <p className="font-medium">
                        {new Date(s.slot_start).toLocaleDateString("hu-HU")} {timeStr(s.slot_start)}–{timeStr(s.slot_end)}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {s.service_id ? getServiceName(s.service_id) : ""}
                        {s.location_id ? ` • ${getLocationName(s.location_id)}` : ""}
                      </p>
                    </div>
                    <Badge variant="outline">{s.free} {t("inner.spot")}</Badge>
                  </div>
                ))}
                {freeSlots.length === 0 && <p className="text-sm text-muted-foreground text-center py-4">{t("inner.noFreeSlots")}</p>}
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={aiOpen} onOpenChange={setAiOpen}>
        <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
          <DialogHeader><DialogTitle><Sparkles className="h-5 w-5 inline mr-2" />{t("inner.aiAppointmentSuggestion")}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label>{t("inner.complaintDescription")}</Label>
              <Textarea value={aiComplaint} onChange={(e) => setAiComplaint(e.target.value)} rows={3} placeholder={t("inner.complaintPlaceholder")} />
            </div>
            <Button
              className="w-full"
              onClick={() => { searchSlots(); setTimeout(generateAiSuggestion, 500); }}
              disabled={aiLoading || !aiComplaint.trim()}
            >
              <Sparkles className="h-4 w-4 mr-1" />{aiLoading ? t("inner.analyzing") : t("inner.generateSuggestion")}
            </Button>
            {aiResult && (
              <div className="prose prose-sm max-w-none p-3 bg-muted rounded-md">
                <div dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(aiResult.replace(/\n/g, "<br>"), { ALLOWED_TAGS: ["br","strong","em","p","ul","ol","li","h3"], ALLOWED_ATTR: [] }) }} />
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}