import { useTranslation } from "react-i18next";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ClipboardList } from "lucide-react";

export default function UzemorvosQuestionnaires() {
  const { t } = useTranslation();
  const { data: submissions, isLoading } = useQuery({
    queryKey: ["uzemorvos-submissions"],
    queryFn: async () => {
      const { data, error } = await supabase.from("questionnaire_submissions").select("id, questionnaire_id, user_id, submitted_at, answers").order("submitted_at", { ascending: false });
      if (error) throw error;
      const qIds = [...new Set(data.map((s) => s.questionnaire_id))];
      const uIds = [...new Set(data.map((s) => s.user_id))];
      const [{ data: questionnaires }, { data: profiles }] = await Promise.all([
        supabase.from("questionnaires").select("id, title").in("id", qIds),
        supabase.from("profiles").select("user_id, full_name").in("user_id", uIds),
      ]);
      return data.map((s) => ({
        ...s,
        questionnaire_title: (questionnaires ?? []).find((q) => q.id === s.questionnaire_id)?.title ?? "—",
        user_name: (profiles ?? []).find((p) => p.user_id === s.user_id)?.full_name ?? "—",
      }));
    },
  });

  if (isLoading) return <div className="flex items-center justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3"><ClipboardList className="h-6 w-6 text-secondary" /><h1 className="text-2xl font-bold">{t('inner.questionnaires')}</h1></div>
      <Card>
        <CardHeader><CardTitle className="text-lg">{t('inner.submissions')} ({submissions?.length ?? 0})</CardTitle></CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader><TableRow><TableHead>{t('inner.filledBy')}</TableHead><TableHead>{t('inner.questionnaire')}</TableHead><TableHead>{t('inner.submittedAt')}</TableHead></TableRow></TableHeader>
            <TableBody>
              {(submissions ?? []).map((s) => (
                <TableRow key={s.id}>
                  <TableCell className="font-medium">{s.user_name}</TableCell>
                  <TableCell>{s.questionnaire_title}</TableCell>
                  <TableCell>{new Date(s.submitted_at).toLocaleDateString("hu-HU")}</TableCell>
                </TableRow>
              ))}
              {(submissions ?? []).length === 0 && <TableRow><TableCell colSpan={3} className="text-center text-muted-foreground py-8">{t('inner.noSubmission')}</TableCell></TableRow>}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
