import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/contexts/AuthContext";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { BarChart, Bar, PieChart, Pie, Cell, LineChart, Line, ResponsiveContainer, XAxis, YAxis, Tooltip, Legend, CartesianGrid } from "recharts";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Printer, AlertTriangle, Download } from "lucide-react";
import ExportButton from "@/components/ExportButton";
import * as XLSX from "xlsx";
import { useTranslation } from "react-i18next";

const RESULT_COLORS: Record<string, string> = {
  alkalmas: "hsl(var(--chart-2))", nem_alkalmas: "hsl(var(--chart-1))",
  feltetelesen_alkalmas: "hsl(var(--chart-3))", ideiglenes: "hsl(var(--chart-4))",
};

export default function UzemorvosStatistics() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const [dateFrom, setDateFrom] = useState(() => {
    const d = new Date(); d.setMonth(d.getMonth() - 6);
    return d.toISOString().split("T")[0];
  });
  const [dateTo, setDateTo] = useState(() => new Date().toISOString().split("T")[0]);

  const RESULT_LABELS: Record<string, string> = {
    alkalmas: t("inner.fit"), nem_alkalmas: t("inner.unfit"),
    feltetelesen_alkalmas: t("inner.conditionallyFit"), ideiglenes: t("inner.temporary"),
  };

  const { data: exams } = useQuery({
    queryKey: ["uzemorvos-stats-exams", user?.id, dateFrom, dateTo],
    queryFn: async () => {
      const { data } = await supabase
        .from("examinations")
        .select("id, patient_id, exam_type, result, valid_until, created_at")
        .eq("doctor_id", user!.id)
        .gte("created_at", dateFrom)
        .lte("created_at", dateTo + "T23:59:59")
        .order("created_at", { ascending: true });
      const ids = [...new Set(data?.map((e) => e.patient_id) ?? [])];
      const { data: profiles } = ids.length
        ? await supabase.from("profiles").select("user_id, full_name").in("user_id", ids)
        : { data: [] };
      const nameMap = Object.fromEntries(profiles?.map((p) => [p.user_id, p.full_name]) ?? []);
      return (data ?? []).map((e) => ({ ...e, patientName: nameMap[e.patient_id] || "—" }));
    },
    enabled: !!user,
  });

  const { data: opinions } = useQuery({
    queryKey: ["uzemorvos-stats-opinions", user?.id, dateFrom, dateTo],
    queryFn: async () => {
      const { data } = await supabase
        .from("medical_opinions")
        .select("id, status, opinion_date")
        .eq("doctor_id", user!.id)
        .gte("opinion_date", dateFrom)
        .lte("opinion_date", dateTo);
      return data ?? [];
    },
    enabled: !!user,
  });

  const { data: appointments } = useQuery({
    queryKey: ["uzemorvos-stats-appts", user?.id, dateFrom, dateTo],
    queryFn: async () => {
      const { data } = await supabase
        .from("appointments")
        .select("id, status, created_at")
        .eq("doctor_id", user!.id)
        .gte("created_at", dateFrom)
        .lte("created_at", dateTo + "T23:59:59");
      return data ?? [];
    },
    enabled: !!user,
  });

  const resultDist = exams
    ? Object.entries(
        exams.reduce<Record<string, number>>((acc, e) => { acc[e.result] = (acc[e.result] || 0) + 1; return acc; }, {})
      ).map(([name, value]) => ({ name: RESULT_LABELS[name] || name, value, color: RESULT_COLORS[name] || "hsl(var(--chart-5))" }))
    : [];

  const monthlyTrend = exams
    ? (() => {
        const months: Record<string, Record<string, number>> = {};
        exams.forEach((e) => {
          const m = e.created_at.slice(0, 7);
          if (!months[m]) months[m] = { total: 0, alkalmas: 0, nem_alkalmas: 0, feltetelesen_alkalmas: 0, ideiglenes: 0 };
          months[m].total++;
          months[m][e.result] = (months[m][e.result] || 0) + 1;
        });
        return Object.entries(months)
          .map(([month, counts]) => ({ month, ...counts }))
          .sort((a, b) => a.month.localeCompare(b.month));
      })()
    : [];

  const examTypeDist = exams
    ? Object.entries(
        exams.reduce<Record<string, number>>((acc, e) => { acc[e.exam_type] = (acc[e.exam_type] || 0) + 1; return acc; }, {})
      ).map(([type, count]) => ({ type, count })).sort((a, b) => b.count - a.count)
    : [];

  const today = new Date().toISOString().split("T")[0];
  const in60 = new Date(Date.now() + 60 * 86400000).toISOString().split("T")[0];
  const expiringExams = (exams ?? []).filter((e) => e.valid_until && e.valid_until >= today && e.valid_until <= in60)
    .sort((a, b) => (a.valid_until ?? "").localeCompare(b.valid_until ?? ""));
  const expiredExams = (exams ?? []).filter((e) => e.valid_until && e.valid_until < today);

  const csvHeaders = [t("inner.employee"), t("inner.type"), t("inner.result"), t("inner.validUntil"), t("inner.date")];
  const csvRows = (exams ?? []).map((e) => [
    e.patientName, e.exam_type, RESULT_LABELS[e.result] || e.result, e.valid_until || "", e.created_at.slice(0, 10),
  ]);

  const exportXls = () => {
    const ws = XLSX.utils.aoa_to_sheet([csvHeaders, ...csvRows]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, t("inner.examinations"));
    XLSX.writeFile(wb, "uzemorvos_vizsgalatok.xlsx");
  };

  return (
    <div className="space-y-6 print:space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h1 className="text-2xl font-bold text-foreground">{t("inner.statistics")}</h1>
          <p className="text-muted-foreground text-sm">{t("inner.doctorActivitySummary")}</p>
        </div>
        <div className="flex gap-2 print:hidden">
          <ExportButton filename="uzemorvos_vizsgalatok" headers={csvHeaders} rows={csvRows} />
          <Button variant="outline" size="sm" onClick={exportXls}>
            <Download className="h-4 w-4 mr-1" /> {t("inner.xls")}
          </Button>
          <Button variant="outline" size="sm" onClick={() => window.print()}>
            <Printer className="h-4 w-4 mr-1" /> {t("inner.printPdf")}
          </Button>
        </div>
      </div>

      <div className="flex gap-2 items-end print:hidden flex-wrap">
        <div>
          <label className="text-xs text-muted-foreground">{t("inner.periodStart")}</label>
          <Input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className="w-40" />
        </div>
        <div>
          <label className="text-xs text-muted-foreground">{t("inner.periodEnd")}</label>
          <Input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} className="w-40" />
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        <Card><CardHeader className="pb-2"><CardTitle className="text-sm text-muted-foreground">{t("inner.examinations")}</CardTitle></CardHeader><CardContent><p className="text-2xl font-bold">{exams?.length ?? 0}</p></CardContent></Card>
        <Card><CardHeader className="pb-2"><CardTitle className="text-sm text-muted-foreground">{t("inner.fitnessOpinions")}</CardTitle></CardHeader><CardContent><p className="text-2xl font-bold">{opinions?.length ?? 0}</p></CardContent></Card>
        <Card><CardHeader className="pb-2"><CardTitle className="text-sm text-muted-foreground">{t("inner.appointments")}</CardTitle></CardHeader><CardContent><p className="text-2xl font-bold">{appointments?.length ?? 0}</p></CardContent></Card>
        <Card><CardHeader className="pb-2"><CardTitle className="text-sm text-muted-foreground">{t("inner.fitPercent")}</CardTitle></CardHeader><CardContent><p className="text-2xl font-bold">{exams?.length ? `${((exams.filter((e) => e.result === "alkalmas").length / exams.length) * 100).toFixed(0)}%` : "—"}</p></CardContent></Card>
        <Card><CardHeader className="pb-2"><CardTitle className="text-sm text-muted-foreground">{t("inner.expiredExpiring")}</CardTitle></CardHeader><CardContent><p className="text-2xl font-bold text-destructive">{expiredExams.length} <span className="text-warning">/ {expiringExams.length}</span></p></CardContent></Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader><CardTitle className="text-base">{t("inner.monthlyTrend")}</CardTitle></CardHeader>
          <CardContent>
            {monthlyTrend.length ? (
              <ResponsiveContainer width="100%" height={280}>
                <LineChart data={monthlyTrend}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                  <YAxis allowDecimals={false} />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="total" name={t("inner.chartTotal")} stroke="hsl(var(--primary))" strokeWidth={2} />
                  <Line type="monotone" dataKey="alkalmas" name={t("inner.chartFit")} stroke="hsl(var(--chart-2))" strokeDasharray="5 5" />
                  <Line type="monotone" dataKey="nem_alkalmas" name={t("inner.chartUnfit")} stroke="hsl(var(--chart-1))" strokeDasharray="5 5" />
                </LineChart>
              </ResponsiveContainer>
            ) : <p className="text-sm text-muted-foreground">{t("inner.noData")}</p>}
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle className="text-base">{t("inner.resultDistribution")}</CardTitle></CardHeader>
          <CardContent>
            {resultDist.length ? (
              <ResponsiveContainer width="100%" height={280}>
                <PieChart>
                  <Pie data={resultDist} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
                    {resultDist.map((e, i) => <Cell key={i} fill={e.color} />)}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            ) : <p className="text-sm text-muted-foreground">{t("inner.noData")}</p>}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">{t("inner.examTypes")}</CardTitle></CardHeader>
        <CardContent>
          {examTypeDist.length ? (
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={examTypeDist} layout="vertical">
                <XAxis type="number" allowDecimals={false} />
                <YAxis dataKey="type" type="category" width={180} tick={{ fontSize: 11 }} />
                <Tooltip />
                <Bar dataKey="count" fill="hsl(var(--secondary))" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : <p className="text-sm text-muted-foreground">{t("inner.noData")}</p>}
        </CardContent>
      </Card>

      {expiringExams.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-warning" />
              {t("inner.expiringExams60", { count: expiringExams.length })}
            </CardTitle>
          </CardHeader>
          <CardContent className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t("inner.employee")}</TableHead>
                  <TableHead>{t("inner.type")}</TableHead>
                  <TableHead>{t("inner.result")}</TableHead>
                  <TableHead>{t("inner.validUntil")}</TableHead>
                  <TableHead>{t("inner.remainingDays")}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {expiringExams.map((e) => {
                  const daysLeft = Math.ceil((new Date(e.valid_until!).getTime() - Date.now()) / 86400000);
                  return (
                    <TableRow key={e.id}>
                      <TableCell className="font-medium">{e.patientName}</TableCell>
                      <TableCell>{e.exam_type}</TableCell>
                      <TableCell><Badge variant="secondary">{RESULT_LABELS[e.result] || e.result}</Badge></TableCell>
                      <TableCell>{e.valid_until}</TableCell>
                      <TableCell>
                        <Badge variant={daysLeft <= 30 ? "destructive" : "secondary"}>{daysLeft} {t("inner.dayUnit")}</Badge>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </div>
  );
}