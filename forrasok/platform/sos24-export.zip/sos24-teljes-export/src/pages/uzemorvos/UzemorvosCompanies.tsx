import { useState, useMemo } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Building2, Pencil, Save, X, Users, ChevronDown, ChevronRight, Plus, Search } from "lucide-react";
import { toast } from "sonner";
import FeorSearch from "@/components/FeorSearch";
import HazardousSubstanceSelector from "@/components/HazardousSubstanceSelector";
import WorkAreaManager from "@/components/WorkAreaManager";

const RISK_FACTOR_KEYS = [
  "riskFactors.chemicals", "riskFactors.noise", "riskFactors.vibration", "riskFactors.dust",
  "riskFactors.screenWork", "riskFactors.heavyPhysical",
  "riskFactors.nightShift", "riskFactors.heightWork",
  "riskFactors.heatStress", "riskFactors.biologicalRisk", "riskFactors.radiation",
  "riskFactors.forcedPosition", "riskFactors.psychosocial", "riskFactors.drivingOperating",
];

const CATEGORY_OPTIONS = ["A", "B", "C", "D"] as const;
const PRICING_TYPE_OPTIONS = [
  { value: "fix", label: "Fix ár" },
  { value: "per_capita", label: "Fő/ár" },
  { value: "monthly", label: "Havidíjas" },
] as const;

const PRICING_LABELS: Record<string, string> = { fix: "Fix", per_capita: "Fő/ár", monthly: "Havidíjas" };

interface CompanyRow {
  id: string;
  name: string;
  tax_number: string | null;
  address: string | null;
  contact_email: string | null;
  contact_phone: string | null;
  industry: string | null;
  registration_no: string | null;
  contract_category: string | null;
  pricing_type: string | null;
  contract_price: number | null;
}

interface EmployeeRelation {
  id: string;
  user_id: string;
  position: string | null;
  is_active: boolean;
  risk_factors: Record<string, boolean> | null;
  profile: { full_name: string; taj_number: string | null } | null;
}

export default function UzemorvosCompanies() {
  const { t } = useTranslation();
  const qc = useQueryClient();
  const [searchQuery, setSearchQuery] = useState("");
  const [editCompany, setEditCompany] = useState<CompanyRow | null>(null);
  const [isNewCompany, setIsNewCompany] = useState(false);
  const [expandedCompany, setExpandedCompany] = useState<string | null>(null);
  const [editEmpId, setEditEmpId] = useState<string | null>(null);
  const [editPosition, setEditPosition] = useState("");
  const [editRisks, setEditRisks] = useState<string[]>([]);
  const [customRisk, setCustomRisk] = useState("");

  // Company form state
  const [formName, setFormName] = useState("");
  const [formTax, setFormTax] = useState("");
  const [formAddr, setFormAddr] = useState("");
  const [formEmail, setFormEmail] = useState("");
  const [formPhone, setFormPhone] = useState("");
  const [formIndustry, setFormIndustry] = useState("");
  const [formRegNo, setFormRegNo] = useState("");
  const [formCategory, setFormCategory] = useState("");
  const [formPricingType, setFormPricingType] = useState("");
  const [formPrice, setFormPrice] = useState("");

  const { data: companies, isLoading } = useQuery({
    queryKey: ["uzemorvos-companies"],
    queryFn: async () => {
      const { data, error } = await supabase.from("companies").select("*").order("name");
      if (error) throw error;
      return data ?? [];
    },
  });

  const filteredCompanies = useMemo(() => {
    const list = Array.isArray(companies) ? companies : [];
    if (!searchQuery.trim()) return list;
    const q = searchQuery.toLowerCase();
    return list.filter((c) =>
      c.name?.toLowerCase().includes(q) ||
      c.tax_number?.toLowerCase().includes(q) ||
      c.address?.toLowerCase().includes(q) ||
      c.contact_email?.toLowerCase().includes(q) ||
      c.industry?.toLowerCase().includes(q)
    );
  }, [companies, searchQuery]);

  const { data: employees } = useQuery({
    queryKey: ["uzemorvos-company-employees", expandedCompany],
    queryFn: async () => {
      const { data, error } = await (supabase as any)
        .from("user_company_relations")
        .select("id, user_id, position, is_active, risk_factors")
        .eq("company_id", expandedCompany)
        .eq("is_active", true)
        .order("created_at", { ascending: false });
      if (error) throw error;
      const userIds = (data as any[]).map((e: any) => e.user_id);
      if (userIds.length === 0) return [];
      const { data: profiles } = await supabase.from("profiles").select("user_id, full_name, taj_number").in("user_id", userIds);
      return (data as any[]).map((e: any) => ({
        ...e,
        profile: (profiles ?? []).find((p) => p.user_id === e.user_id) || null,
      })) as EmployeeRelation[];
    },
    enabled: !!expandedCompany,
  });

  const companyMut = useMutation({
    mutationFn: async (c: CompanyRow & { _isNew?: boolean }) => {
      const row = {
        name: c.name, tax_number: c.tax_number, address: c.address,
        contact_email: c.contact_email, contact_phone: c.contact_phone,
        industry: c.industry, registration_no: c.registration_no,
        contract_category: c.contract_category, pricing_type: c.pricing_type,
        contract_price: c.contract_price,
      };
      if (c._isNew) {
        const { error } = await supabase.from("companies").insert(row);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("companies").update(row).eq("id", c.id);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["uzemorvos-companies"] });
      setEditCompany(null);
      setIsNewCompany(false);
      toast.success(t("common.saved"));
    },
    onError: (e: any) => toast.error(e.message),
  });

  const empMut = useMutation({
    mutationFn: async ({ id, position, risk_factors }: { id: string; position: string; risk_factors: string[] }) => {
      const rfObj: Record<string, boolean> = {};
      risk_factors.forEach((r) => { rfObj[r] = true; });
      const { error } = await (supabase as any).from("user_company_relations").update({ position, risk_factors: rfObj }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["uzemorvos-company-employees"] });
      setEditEmpId(null);
      toast.success(t("common.saved"));
    },
    onError: (e: any) => toast.error(e.message),
  });

  const resetForm = () => {
    setFormName(""); setFormTax(""); setFormAddr(""); setFormEmail("");
    setFormPhone(""); setFormIndustry(""); setFormRegNo("");
    setFormCategory(""); setFormPricingType(""); setFormPrice("");
  };

  const openCompanyEdit = (c: CompanyRow) => {
    setEditCompany(c);
    setIsNewCompany(false);
    setFormName(c.name); setFormTax(c.tax_number || ""); setFormAddr(c.address || "");
    setFormEmail(c.contact_email || ""); setFormPhone(c.contact_phone || "");
    setFormIndustry(c.industry || ""); setFormRegNo(c.registration_no || "");
    setFormCategory(c.contract_category || ""); setFormPricingType(c.pricing_type || "");
    setFormPrice(c.contract_price != null ? String(c.contract_price) : "");
  };

  const openNewCompany = () => {
    resetForm();
    setIsNewCompany(true);
    setEditCompany({ id: "", name: "", tax_number: null, address: null, contact_email: null, contact_phone: null, industry: null, registration_no: null, contract_category: null, pricing_type: null, contract_price: null });
  };

  const saveCompany = () => {
    if (!editCompany) return;
    companyMut.mutate({
      ...editCompany,
      name: formName, tax_number: formTax || null, address: formAddr || null,
      contact_email: formEmail || null, contact_phone: formPhone || null,
      industry: formIndustry || null, registration_no: formRegNo || null,
      contract_category: formCategory || null, pricing_type: formPricingType || null,
      contract_price: formPrice ? parseFloat(formPrice) : null,
      _isNew: isNewCompany,
    } as any);
  };

  const openEmpEdit = (emp: EmployeeRelation) => {
    setEditEmpId(emp.id);
    setEditPosition(emp.position || "");
    const rf = emp.risk_factors;
    if (rf && typeof rf === "object") {
      setEditRisks(Object.keys(rf).filter((k) => rf[k]));
    } else { setEditRisks([]); }
    setCustomRisk("");
  };

  const saveEmp = () => {
    if (!editEmpId) return;
    empMut.mutate({ id: editEmpId, position: editPosition, risk_factors: editRisks });
  };

  const toggleRisk = (risk: string) => setEditRisks((prev) => prev.includes(risk) ? prev.filter((r) => r !== risk) : [...prev, risk]);
  const addCustomRisk = () => { const t = customRisk.trim(); if (t && !editRisks.includes(t)) { setEditRisks((p) => [...p, t]); setCustomRisk(""); } };
  const getRiskList = (rf: Record<string, boolean> | null): string[] => { if (!rf || typeof rf !== "object") return []; return Object.keys(rf).filter((k) => rf[k]); };
  const toggleExpand = (id: string) => setExpandedCompany((prev) => prev === id ? null : id);

  if (isLoading) return <div className="flex items-center justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>;

  const editingEmp = employees?.find((e) => e.id === editEmpId);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Building2 className="h-6 w-6 text-secondary" />
          <h1 className="text-2xl font-bold">{t('inner.companies')}</h1>
        </div>
        <Button onClick={openNewCompany}><Plus className="h-4 w-4 mr-2" />Új cég</Button>
      </div>

      {/* Search */}
      <div className="relative max-w-sm">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input className="pl-8" placeholder="Keresés név, adószám, cím..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
      </div>

      <Card>
        <CardHeader><CardTitle className="text-lg">{t('inner.companies')} ({filteredCompanies.length})</CardTitle></CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-8"></TableHead>
                <TableHead>{t('inner.name')}</TableHead>
                <TableHead>{t('inner.taxNumber')}</TableHead>
                <TableHead>{t('inner.address')}</TableHead>
                <TableHead>Kategória</TableHead>
                <TableHead>Díjazás</TableHead>
                <TableHead>{t('inner.email')}</TableHead>
                <TableHead className="w-10"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredCompanies.map((c) => (
                <>
                  <TableRow key={c.id} className="cursor-pointer hover:bg-muted/50" onClick={() => toggleExpand(c.id)}>
                    <TableCell className="px-2">
                      {expandedCompany === c.id ? <ChevronDown className="h-4 w-4 text-muted-foreground" /> : <ChevronRight className="h-4 w-4 text-muted-foreground" />}
                    </TableCell>
                    <TableCell className="font-medium">{c.name}</TableCell>
                    <TableCell>{c.tax_number || "—"}</TableCell>
                    <TableCell className="max-w-40 truncate">{c.address || "—"}</TableCell>
                    <TableCell>
                      {c.contract_category ? <Badge variant="outline">{c.contract_category}</Badge> : "—"}
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">
                        {c.pricing_type ? (
                          <span>{PRICING_LABELS[c.pricing_type] || c.pricing_type}{c.contract_price != null ? ` — ${c.contract_price.toLocaleString("hu-HU")} Ft` : ""}</span>
                        ) : "—"}
                      </div>
                    </TableCell>
                    <TableCell>{c.contact_email || "—"}</TableCell>
                    <TableCell>
                      <Button size="icon" variant="ghost" className="h-7 w-7" onClick={(e) => { e.stopPropagation(); openCompanyEdit(c); }}>
                        <Pencil className="h-3.5 w-3.5" />
                      </Button>
                    </TableCell>
                  </TableRow>
                  {expandedCompany === c.id && (
                    <TableRow key={`${c.id}-emp`}>
                      <TableCell colSpan={8} className="bg-muted/30 p-0">
                        <div className="p-4">
                          <div className="flex items-center gap-2 mb-3">
                            <Users className="h-4 w-4 text-muted-foreground" />
                            <span className="text-sm font-medium">Munkavállalók ({employees?.length ?? 0})</span>
                          </div>
                          {employees && employees.length > 0 ? (
                            <Table>
                              <TableHeader>
                                <TableRow>
                                  <TableHead>{t('inner.name')}</TableHead>
                                  <TableHead>{t('inner.taj')}</TableHead>
                                  <TableHead>{t('inner.position')}</TableHead>
                                  <TableHead>Kockázati tényezők</TableHead>
                                  <TableHead className="w-10"></TableHead>
                                </TableRow>
                              </TableHeader>
                              <TableBody>
                                {employees.map((emp) => {
                                  const risks = getRiskList(emp.risk_factors);
                                  return (
                                    <TableRow key={emp.id}>
                                      <TableCell className="font-medium">{emp.profile?.full_name || "—"}</TableCell>
                                      <TableCell>{emp.profile?.taj_number || "—"}</TableCell>
                                      <TableCell>{emp.position || "—"}</TableCell>
                                      <TableCell>
                                        <div className="flex flex-wrap gap-1">
                                        {risks.length > 0 ? risks.map((r) => (
                                            <Badge key={r} variant="outline" className="text-[10px]">{t(r, r)}</Badge>
                                          )) : <span className="text-muted-foreground text-xs">—</span>}
                                        </div>
                                      </TableCell>
                                      <TableCell>
                                        <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => openEmpEdit(emp)}>
                                          <Pencil className="h-3.5 w-3.5" />
                                        </Button>
                                      </TableCell>
                                    </TableRow>
                                  );
                                })}
                              </TableBody>
                            </Table>
                          ) : (
                            <p className="text-sm text-muted-foreground">Nincs munkavállaló ehhez a céghez.</p>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  )}
                </>
              ))}
              {filteredCompanies.length === 0 && (
                <TableRow><TableCell colSpan={8} className="text-center text-muted-foreground py-8">
                  {searchQuery ? "Nincs találat a keresésre." : "Nincs cég az adatbázisban."}
                </TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Company edit/create dialog */}
      <Dialog open={!!editCompany} onOpenChange={(open) => { if (!open) { setEditCompany(null); setIsNewCompany(false); } }}>
        <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Building2 className="h-4 w-4" />
              {isNewCompany ? "Új cég létrehozása" : "Cég szerkesztése"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3 mt-2">
            <div className="space-y-1">
              <Label>{t('inner.name')} *</Label>
              <Input value={formName} onChange={(e) => setFormName(e.target.value)} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label>{t('inner.taxNumber')}</Label>
                <Input value={formTax} onChange={(e) => setFormTax(e.target.value)} />
              </div>
              <div className="space-y-1">
                <Label>Cégjegyzékszám</Label>
                <Input value={formRegNo} onChange={(e) => setFormRegNo(e.target.value)} />
              </div>
            </div>
            <div className="space-y-1">
              <Label>{t('inner.address')}</Label>
              <Input value={formAddr} onChange={(e) => setFormAddr(e.target.value)} />
            </div>
            <div className="space-y-1">
              <Label>Iparág</Label>
              <Input value={formIndustry} onChange={(e) => setFormIndustry(e.target.value)} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label>{t('inner.email')}</Label>
                <Input value={formEmail} onChange={(e) => setFormEmail(e.target.value)} />
              </div>
              <div className="space-y-1">
                <Label>{t('inner.phone')}</Label>
                <Input value={formPhone} onChange={(e) => setFormPhone(e.target.value)} />
              </div>
            </div>

            {/* Contract pricing */}
            <div className="border-t pt-3 mt-3">
              <p className="text-sm font-semibold mb-2">Szerződési feltételek</p>
              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-1">
                  <Label>Kategória</Label>
                  <Select value={formCategory} onValueChange={setFormCategory}>
                    <SelectTrigger><SelectValue placeholder="—" /></SelectTrigger>
                    <SelectContent>
                      {CATEGORY_OPTIONS.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1">
                  <Label>Díjazás típusa</Label>
                  <Select value={formPricingType} onValueChange={setFormPricingType}>
                    <SelectTrigger><SelectValue placeholder="—" /></SelectTrigger>
                    <SelectContent>
                      {PRICING_TYPE_OPTIONS.map((p) => <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1">
                  <Label>Ár (Ft)</Label>
                  <Input type="number" value={formPrice} onChange={(e) => setFormPrice(e.target.value)} placeholder="0" />
                </div>
              </div>
            </div>

            {/* Hazardous substances - only for existing companies */}
            {editCompany && !isNewCompany && (
              <div className="border-t pt-3 mt-3">
                <HazardousSubstanceSelector companyId={editCompany.id} />
              </div>
            )}

            {/* Work Area Manager - only for existing companies */}
            {editCompany && !isNewCompany && (
              <div className="border-t pt-3 mt-3">
                <WorkAreaManager companyId={editCompany.id} />
              </div>
            )}

            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => { setEditCompany(null); setIsNewCompany(false); }}>
                <X className="h-4 w-4 mr-1" />{t("common.cancel")}
              </Button>
              <Button onClick={saveCompany} disabled={companyMut.isPending || !formName.trim()}>
                <Save className="h-4 w-4 mr-1" />{isNewCompany ? "Létrehozás" : t("common.save")}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Employee edit dialog */}
      <Dialog open={!!editEmpId} onOpenChange={(open) => !open && setEditEmpId(null)}>
        <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Pencil className="h-4 w-4" />
              {editingEmp?.profile?.full_name} – Munkakör és kockázatok
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-2">
            <div className="space-y-2">
              <Label>FEOR kód / Munkakör</Label>
              <FeorSearch value="" onChange={() => {}} onPositionChange={(name) => setEditPosition(name)} placeholder="FEOR kód keresése..." />
            </div>
            <div className="space-y-2">
              <Label>Munkakör (egyéni)</Label>
              <Input value={editPosition} onChange={(e) => setEditPosition(e.target.value)} placeholder="pl. Raktáros, Irodai dolgozó..." />
            </div>
            <div className="space-y-2">
              <Label>Kockázati tényezők</Label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-60 overflow-y-auto border rounded-md p-3">
                {RISK_FACTOR_KEYS.map((key) => (
                  <label key={key} className="flex items-center gap-2 text-sm cursor-pointer hover:bg-muted/50 rounded px-1 py-0.5">
                    <Checkbox checked={editRisks.includes(key)} onCheckedChange={() => toggleRisk(key)} />
                    {t(key)}
                  </label>
                ))}
                {editRisks.filter((r) => !RISK_FACTOR_KEYS.includes(r)).map((risk) => (
                  <label key={risk} className="flex items-center gap-2 text-sm cursor-pointer hover:bg-muted/50 rounded px-1 py-0.5">
                    <Checkbox checked={true} onCheckedChange={() => toggleRisk(risk)} />
                    <span className="italic">{t(risk, risk)}</span>
                  </label>
                ))}
              </div>
              <div className="flex gap-2">
                <Input value={customRisk} onChange={(e) => setCustomRisk(e.target.value)} placeholder="Egyéb kockázat..." className="text-sm" onKeyDown={(e) => e.key === "Enter" && addCustomRisk()} />
                <Button variant="outline" size="sm" onClick={addCustomRisk} disabled={!customRisk.trim()}>Hozzáadás</Button>
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setEditEmpId(null)}>
                <X className="h-4 w-4 mr-1" />{t("common.cancel")}
              </Button>
              <Button onClick={saveEmp} disabled={empMut.isPending}>
                <Save className="h-4 w-4 mr-1" />{t("common.save")}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
