import { useState, useEffect, useCallback } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { FileCheck, Plus, Sparkles, Printer, ClipboardList, History, Mic } from "lucide-react";
import SpeechToTextButton from "@/components/SpeechToTextButton";
import { useSearchParams } from "react-router-dom";
import PrintableOpinion from "@/components/PrintableOpinion";
import ExportButton from "@/components/ExportButton";
import { useTranslation } from "react-i18next";
import { useDocumentTemplate, isFieldVisible } from "@/hooks/use-document-templates";

const EXAM_TYPE_KEYS = ["examPreliminary", "examPeriodic", "examExtraordinary", "examFinal"] as const;
const EXAM_TYPE_VALUES = ["Előzetes", "Időszakos", "Soron kívüli", "Záró"];

const RESTRICTION_OPTIONS = [
  "Magasban végzett munka tilos",
  "Éjszakai műszak tilos",
  "Nehéz fizikai munka tilos",
  "Képernyő előtti munka korlátozva",
  "Zajterhelés kerülendő",
  "Vegyi anyagokkal való érintkezés tilos",
  "Gépjárművezetés tilos",
  "Emelés korlátozva (max 10 kg)",
  "Emelés korlátozva (max 20 kg)",
  "Állandó állás tilos",
  "Fokozott figyelmet igénylő munka tilos",
  "Ionizáló sugárzás tilos",
  "Egyéni légzésvédő eszköz viselése kötelező",
  "Rendszeres orvosi kontroll szükséges",
];

const AUDIO_FREQS = ["250", "500", "1k", "2k", "4k", "6k", "8k"] as const;

const defaultClinicalFindings = () => ({
  blood_pressure: "", heart_rate: "", ekg: "", vc: "",
  skin: "", tattoo: "",
  body_status: "Kp. fejlett, Kp. táplált beteg. Kp. vértelt bőr és nyh-k, icterus nincs, cyanosis nincs, oedema: nincs",
  oral_pharynx: "", teeth: "sanált/hiányos", tongue: "enyhén lepedékes", pharynx: "norm",
  lymph_nodes: "neg.", thyroid: "norm. tap.",
  cardiovascular: "Relatív szívtompulat megtartott, ritmusos szívműködés, szívhangok: zörej nincs; carotisok, femoralis felett zörej: nem hallható.",
  vessels: "ADP, ATP tapintható.", varicosity: "min.grad.",
  lungs: "alaplégzés", lung_xray_date: "", spirometry: "",
  fvc: "", fev1: "", pef: "", fev1_fvc: "",
  abdomen: "szintben", abdomen_resistance: "nincs", abdomen_palpation: "puha", bowel_sounds: "norm.", rdv: "páciens kérésére mellőztük",
  musculoskeletal: "tartás norm., járás kornak megfelelő. Alakilag és formailag ép mozgásszervek.",
  vision_right: "", vision_right_corr: "", vision_left: "", vision_left_corr: "", color_vision: "megtartott",
  hearing_right_speech: "érti", hearing_right_whisper: "érti",
  hearing_left_speech: "érti", hearing_left_whisper: "érti",
  audio_right_250: "20", audio_right_500: "20", audio_right_1k: "20", audio_right_2k: "20", audio_right_4k: "20", audio_right_6k: "20", audio_right_8k: "20",
  audio_left_250: "20", audio_left_500: "20", audio_left_1k: "20", audio_left_2k: "20", audio_left_4k: "20", audio_left_6k: "20", audio_left_8k: "20",
  hearing_condition: "",
  audiometry: "",
  neuro_focal: "Durva neur. gócjel nincs.",
  neuro_consciousness: "igen", neuro_orientation: "igen",
  neuro_reflexes: "norm.", neuro_blind_walk: "norm.",
  neuro_romberg: "neg.", neuro_tremor: "stress jellegű",
  other: "",
});

const emptyForm = () => ({
  patient_id: "", exam_type: "", referral_id: "",
  patient_data: { anamnesis: "", medications: "", allergies: "", complaints: "", diseases: "", hospital: "", surgeries: "",
    weight_kg: "", height_cm: "", address: "" },
  clinical_findings: defaultClinicalFindings(),
  result: "alkalmas", restrictions: "", valid_until: "", ai_notes: "",
  auto_opinion: true, next_lab_control: "",
});

export default function UzemorvosExaminations() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [searchParams, setSearchParams] = useSearchParams();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [step, setStep] = useState(1);
  const [aiLoading, setAiLoading] = useState(false);
  const [printExam, setPrintExam] = useState<any>(null);
  const [printProfile, setPrintProfile] = useState<any>(null);
  const [printCard, setPrintCard] = useState<any>(null);
  const [printQuestionnaire, setPrintQuestionnaire] = useState<any>(null);
  const [form, setForm] = useState(emptyForm());
  const [questionnaireData, setQuestionnaireData] = useState<any>(null);
  const { data: examSheetTemplate } = useDocumentTemplate("exam_sheet");

  const RESULT_OPTIONS = [
    { value: "alkalmas", label: t("inner.fit") },
    { value: "nem_alkalmas", label: t("inner.unfit") },
    { value: "feltetelesen_alkalmas", label: t("inner.conditionallyFit") },
    { value: "ideiglenes", label: t("inner.temporary") },
  ];

  const EXAM_TYPES = EXAM_TYPE_KEYS.map((k, i) => ({ label: t(`inner.${k}`), value: EXAM_TYPE_VALUES[i] }));

  // Load patient profile biometric data
  const loadPatientProfileData = useCallback(async (patientId: string) => {
    const [{ data: patientCard }, { data: healthReport }, { data: profileRow }] = await Promise.all([
      supabase.from("patient_cards").select("*").eq("user_id", patientId).maybeSingle(),
      supabase.from("health_reports").select("weight_kg, height_cm").eq("user_id", patientId).order("report_date", { ascending: false }).limit(1).maybeSingle(),
      supabase.from("profiles").select("address").eq("user_id", patientId).maybeSingle(),
    ]);
    const pc = patientCard as any;
    setForm((f) => ({
      ...f,
      patient_data: {
        ...f.patient_data,
        allergies: pc?.drug_allergies || f.patient_data.allergies,
        medications: pc?.regular_medications || f.patient_data.medications,
        diseases: pc?.chronic_diseases || f.patient_data.diseases,
        weight_kg: healthReport?.weight_kg?.toString() || f.patient_data.weight_kg,
        height_cm: healthReport?.height_cm?.toString() || f.patient_data.height_cm,
        address: profileRow?.address || f.patient_data.address,
        surgeries: pc?.surgeries || f.patient_data.surgeries,
        anamnesis: [
          pc?.occupation ? `Foglalkozás: ${pc.occupation}` : "",
          pc?.education ? `Végzettség: ${pc.education}` : "",
          pc?.smoking?.status === "igen" ? `Dohányzik (${pc.smoking.amount || "?"} szál/nap)` : pc?.smoking?.status === "leszokott" ? "Leszokott dohányos" : "",
          pc?.alcohol && pc.alcohol !== "nem" ? `Alkohol: ${pc.alcohol}` : "",
          pc?.reported_occupational_diseases ? `Foglalkozási betegségek: ${pc.reported_occupational_diseases}` : "",
        ].filter(Boolean).join("; ") || f.patient_data.anamnesis,
      },
    }));
  }, []);

  // Load questionnaire submissions when patient is selected
  const loadQuestionnaireData = useCallback(async (patientId: string) => {
    const { data: submissions } = await supabase
      .from("questionnaire_submissions")
      .select("id, questionnaire_id, answers, submitted_at")
      .eq("user_id", patientId)
      .order("submitted_at", { ascending: false })
      .limit(5);
    if (!submissions?.length) { setQuestionnaireData(null); return; }
    const qIds = [...new Set(submissions.map((s) => s.questionnaire_id))];
    const { data: questionnaires } = await supabase.from("questionnaires").select("id, title, fields").in("id", qIds);
    const qMap = Object.fromEntries((questionnaires ?? []).map((q) => [q.id, q]));
    const enriched = submissions.map((s) => ({ ...s, title: qMap[s.questionnaire_id]?.title ?? t("inner.questionnaire"), fields: qMap[s.questionnaire_id]?.fields }));
    setQuestionnaireData(enriched);
    
    const latest = submissions[0];
    const answers = latest.answers as Record<string, any>;
    if (answers) {
      setForm((f) => ({
        ...f,
        patient_data: {
          ...f.patient_data,
          complaints: answers.panasz || answers.complaints || answers.jelenlegi_panaszok || f.patient_data.complaints,
          diseases: answers.betegsegek || answers.diseases || answers.korabbi_betegsegek || f.patient_data.diseases,
          medications: answers.gyogyszerek || answers.medications || answers.rendszeres_gyogyszerek || f.patient_data.medications,
          allergies: answers.allergiak || answers.allergies || answers.gyogyszer_allergia || f.patient_data.allergies,
          hospital: answers.korhaz || answers.hospital || answers.korhazi_kezeles || f.patient_data.hospital,
          surgeries: answers.mutetek || answers.surgeries || answers.korabbi_mutetek || f.patient_data.surgeries,
        },
      }));
    }
  }, [t]);

  const loadPreviousExam = useCallback(async (patientId: string) => {
    const { data: prevExams } = await supabase
      .from("examinations")
      .select("*")
      .eq("patient_id", patientId)
      .order("created_at", { ascending: false })
      .limit(5);
    if (!prevExams?.length) {
      toast({ title: t("inner.noPreviousExam") });
      return null;
    }
    const prev = prevExams[0];
    const pd = prev.patient_data as any ?? {};
    const cf = prev.clinical_findings as any ?? {};
    setForm((f) => ({
      ...f,
      patient_data: {
        anamnesis: pd.anamnesis || f.patient_data.anamnesis,
        medications: pd.medications || f.patient_data.medications,
        allergies: pd.allergies || f.patient_data.allergies,
        complaints: pd.complaints || f.patient_data.complaints,
        diseases: pd.diseases || f.patient_data.diseases,
        hospital: pd.hospital || f.patient_data.hospital,
        surgeries: pd.surgeries || f.patient_data.surgeries,
        weight_kg: pd.weight_kg || f.patient_data.weight_kg,
        height_cm: pd.height_cm || f.patient_data.height_cm,
        address: pd.address || f.patient_data.address,
      },
      clinical_findings: { ...f.clinical_findings, ...cf },
      restrictions: prev.restrictions || f.restrictions,
    }));
    toast({ title: t("inner.previousExamLoaded") });
    return prevExams;
  }, [t, toast]);

  useEffect(() => {
    const refId = searchParams.get("referral_id");
    const patientId = searchParams.get("patient_id");
    const examType = searchParams.get("exam_type");
    if (refId && patientId) {
      setForm(f => ({ ...f, referral_id: refId, patient_id: patientId, exam_type: examType || f.exam_type }));
      setDialogOpen(true);
      setStep(1);
      setSearchParams({}, { replace: true });
      loadPatientProfileData(patientId);
      loadQuestionnaireData(patientId);
    }
  }, [searchParams, setSearchParams, loadQuestionnaireData, loadPatientProfileData]);

  const { data: profiles } = useQuery({
    queryKey: ["uzemorvos-all-profiles"],
    queryFn: async () => {
      const { data, error } = await supabase.from("profiles").select("user_id, full_name, taj_number, signature_url, birth_date, birth_place, mother_name, address, phone, gender").order("full_name");
      if (error) throw error;
      return data;
    },
  });

  const { data: examinations, isLoading } = useQuery({
    queryKey: ["uzemorvos-examinations"],
    queryFn: async () => {
      const { data, error } = await supabase.from("examinations").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      const pIds = [...new Set(data.map((e) => e.patient_id))];
      const { data: profs } = await supabase.from("profiles").select("user_id, full_name, taj_number").in("user_id", pIds);
      return data.map((e) => ({
        ...e,
        patient_name: (profs ?? []).find((p) => p.user_id === e.patient_id)?.full_name ?? "—",
        patient_taj: (profs ?? []).find((p) => p.user_id === e.patient_id)?.taj_number ?? "",
      }));
    },
  });

  const createExam = useMutation({
    mutationFn: async () => {
      const { data: exam, error } = await (supabase as any).from("examinations").insert({
        patient_id: form.patient_id,
        doctor_id: user!.id,
        exam_type: form.exam_type,
        patient_data: form.patient_data,
        clinical_findings: form.clinical_findings,
        result: form.result as any,
        restrictions: form.restrictions || null,
        valid_until: form.valid_until || null,
        ai_notes: form.ai_notes || null,
        referral_id: form.referral_id || null,
        next_lab_control: form.next_lab_control || null,
      }).select("id").single();
      if (error) throw error;

      if (form.auto_opinion) {
        let companyId: string | null = null;
        if (form.referral_id) {
          const { data: ref } = await supabase.from("referrals").select("company_id").eq("id", form.referral_id).single();
          companyId = ref?.company_id ?? null;
        }

        await supabase.from("medical_opinions").insert({
          patient_id: form.patient_id,
          doctor_id: user!.id,
          company_id: companyId,
          status: form.result as any,
          valid_until: form.valid_until || null,
          notes: form.restrictions || null,
        });

        await supabase.functions.invoke("send-notification", {
          body: {
            type: "opinion_ready",
            recipient_id: form.patient_id,
            sender_id: user!.id,
            data: { result: RESULT_OPTIONS.find(r => r.value === form.result)?.label || form.result, valid_until: form.valid_until ? new Date(form.valid_until).toLocaleDateString("hu-HU") : "" },
          },
        });
      }

      if (form.referral_id) {
        await supabase.from("referrals").update({ status: "completed" as any }).eq("id", form.referral_id);
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["uzemorvos-examinations"] });
      qc.invalidateQueries({ queryKey: ["uzemorvos-opinions"] });
      qc.invalidateQueries({ queryKey: ["uzemorvos-referrals"] });
      toast({ title: form.auto_opinion ? t("inner.examAndOpinionSaved") : t("inner.examSaved") });
      setDialogOpen(false);
      setStep(1);
      setForm(emptyForm());
    },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  const generateAiNote = async () => {
    setAiLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("ai-medical-note", {
        body: { patient_data: form.patient_data, clinical_findings: form.clinical_findings, exam_type: form.exam_type },
      });
      if (error) throw error;
      setForm((f) => ({ ...f, ai_notes: data.note }));
      toast({ title: t("inner.aiNoteGenerated") });
    } catch (e: any) {
      toast({ variant: "destructive", title: t("inner.aiError"), description: e.message });
    } finally {
      setAiLoading(false);
    }
  };

  const generateAiOpinionDraft = async () => {
    setAiLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("ai-opinion-draft", {
        body: { patient_data: form.patient_data, clinical_findings: form.clinical_findings, exam_type: form.exam_type, restrictions: form.restrictions },
      });
      if (error) throw error;
      setForm((f) => ({ ...f, ai_notes: data.draft }));
      toast({ title: t("inner.aiOpinionGenerated") });
    } catch (e: any) {
      toast({ variant: "destructive", title: t("inner.aiError"), description: e.message });
    } finally {
      setAiLoading(false);
    }
  };

  const handlePrint = async (exam: any) => {
    const doctorProfile = (profiles ?? []).find((p) => p.user_id === exam.doctor_id);
    const patientProfile = (profiles ?? []).find((p) => p.user_id === exam.patient_id);
    
    // Load patient card for print
    const { data: card } = await supabase.from("patient_cards").select("*").eq("user_id", exam.patient_id).maybeSingle();
    
    // Load questionnaire data for print
    const { data: subs } = await supabase
      .from("questionnaire_submissions")
      .select("id, questionnaire_id, answers, submitted_at")
      .eq("user_id", exam.patient_id)
      .order("submitted_at", { ascending: false })
      .limit(5);
    let qData: any[] = [];
    if (subs?.length) {
      const qIds = [...new Set(subs.map(s => s.questionnaire_id))];
      const { data: qs } = await supabase.from("questionnaires").select("id, title, fields").in("id", qIds);
      const qMap = Object.fromEntries((qs ?? []).map(q => [q.id, q]));
      qData = subs.map(s => ({ ...s, title: qMap[s.questionnaire_id]?.title ?? "Kérdőív", fields: qMap[s.questionnaire_id]?.fields }));
    }

    const { resolveSignatureUrl } = await import("@/lib/storage-utils");
    const resolvedSig = await resolveSignatureUrl(doctorProfile?.signature_url ?? null);
    setPrintExam({ ...exam, signature_url: resolvedSig, doctor_name: doctorProfile?.full_name ?? "—" });
    setPrintProfile(patientProfile ?? null);
    setPrintCard(card ?? null);
    setPrintQuestionnaire(qData.length ? qData : null);
    setTimeout(() => window.print(), 300);
  };

  if (isLoading) return <div className="flex items-center justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>;

  const cf = (key: string) => (printExam?.clinical_findings as any)?.[key] || "—";
  const pd = (key: string) => (printExam?.patient_data as any)?.[key] || "";

  return (
    <div className="space-y-6">
      {/* ===== FULL PRINTABLE EXAM SHEET ===== */}
      {printExam && (
        <div className="hidden print:block print:p-4 text-[11px] leading-tight">
          <h1 className="text-base font-bold text-center mb-3 uppercase">Foglalkozás-egészségügyi vizsgálati jegyzőkönyv</h1>

          {/* 1. Personal Data */}
          <div className="border p-2 mb-2">
            <h2 className="font-bold text-xs mb-1 border-b pb-0.5">I. Személyes adatok</h2>
            <div className="grid grid-cols-2 gap-x-4 gap-y-0.5">
              <p><strong>Név:</strong> {printExam.patient_name}</p>
              <p><strong>TAJ:</strong> {printProfile?.taj_number || "—"}</p>
              <p><strong>Születési hely, idő:</strong> {printProfile?.birth_place || ""} {printProfile?.birth_date ? new Date(printProfile.birth_date).toLocaleDateString("hu-HU") : ""}</p>
              <p><strong>Anyja neve:</strong> {printProfile?.mother_name || "—"}</p>
              <p><strong>Lakcím:</strong> {printProfile?.address || pd("address") || "—"}</p>
              <p><strong>Nem:</strong> {printProfile?.gender === "ferfi" ? "Férfi" : printProfile?.gender === "no" ? "Nő" : "—"}</p>
            </div>
            <p><strong>Vizsgálat típusa:</strong> {printExam.exam_type} &nbsp; <strong>Dátum:</strong> {new Date(printExam.created_at).toLocaleDateString("hu-HU")}</p>
          </div>

          {/* 2. Questionnaire Data */}
          {printQuestionnaire && (
            <div className="border p-2 mb-2">
              <h2 className="font-bold text-xs mb-1 border-b pb-0.5">II. Kérdőív adatok</h2>
              {printQuestionnaire.map((q: any) => {
                const answers = q.answers as Record<string, any>;
                return (
                  <div key={q.id} className="mb-1">
                    <p className="font-semibold text-[10px]">{q.title} ({new Date(q.submitted_at).toLocaleDateString("hu-HU")})</p>
                    <div className="grid grid-cols-2 gap-x-3">
                      {Object.entries(answers).map(([k, v]) => (
                        <p key={k} className="text-[10px]"><strong>{k}:</strong> {String(v)}</p>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* 3. Patient Card / Anamnesis */}
          <div className="border p-2 mb-2">
            <h2 className="font-bold text-xs mb-1 border-b pb-0.5">III. Törzskarton adatok / Anamnézis</h2>
            <div className="grid grid-cols-2 gap-x-4 gap-y-0.5">
              {printCard?.education && <p><strong>Végzettség:</strong> {printCard.education}</p>}
              {printCard?.professional_qual && <p><strong>Szakmai képzettség:</strong> {printCard.professional_qual}</p>}
              {printCard?.occupation && <p><strong>Munkakör:</strong> {printCard.occupation}</p>}
              {printCard?.employer_name && <p><strong>Munkáltató:</strong> {printCard.employer_name}</p>}
              <p><strong>Allergiák:</strong> {printCard?.drug_allergies || pd("allergies") || "—"}</p>
              <p><strong>Krónikus betegségek:</strong> {printCard?.chronic_diseases || pd("diseases") || "—"}</p>
              <p><strong>Rendszeres gyógyszerek:</strong> {printCard?.regular_medications || pd("medications") || "—"}</p>
              <p><strong>Műtétek, balesetek:</strong> {printCard?.surgeries || pd("surgeries") || "—"}</p>
              {printCard?.reported_occupational_diseases && <p><strong>Foglalkozási betegségek:</strong> {printCard.reported_occupational_diseases}</p>}
              <p><strong>Dohányzás:</strong> {(printCard?.smoking as any)?.status === "igen" ? `Igen (${(printCard?.smoking as any)?.amount || "?"} szál/nap)` : (printCard?.smoking as any)?.status === "leszokott" ? "Leszokott" : "Nem"}</p>
              <p><strong>Alkohol:</strong> {printCard?.alcohol || "nem"}</p>
              {printCard?.sports_habit && <p><strong>Sportolás:</strong> {printCard.sports_habit}</p>}
              {printCard?.eating_habit && <p><strong>Étkezés:</strong> {printCard.eating_habit}</p>}
              <p><strong>Jogosítvány:</strong> {printCard?.drivers_license ? "Van" : "Nincs"}</p>
              <p><strong>Katonai szolgálat:</strong> {printCard?.military_service ? "Volt" : "Nem volt"}</p>
            </div>
            {pd("complaints") && <p className="mt-1"><strong>Panaszok:</strong> {pd("complaints")}</p>}
            {pd("hospital") && <p><strong>Kórházi kezelés:</strong> {pd("hospital")}</p>}
            {pd("anamnesis") && <p><strong>Anamnézis:</strong> {pd("anamnesis")}</p>}
          </div>

          {/* 4. Biometrics & Vitals */}
          <div className="border p-2 mb-2">
            <h2 className="font-bold text-xs mb-1 border-b pb-0.5">IV. Biometriai adatok és vitális jelek</h2>
            <div className="grid grid-cols-4 gap-x-3 gap-y-0.5">
              <p><strong>Testsúly:</strong> {pd("weight_kg") || "—"} kg</p>
              <p><strong>Testmagasság:</strong> {pd("height_cm") || "—"} cm</p>
              <p><strong>BMI:</strong> {pd("weight_kg") && pd("height_cm") ? (Number(pd("weight_kg")) / Math.pow(Number(pd("height_cm")) / 100, 2)).toFixed(1) : "—"}</p>
              <p>&nbsp;</p>
              <p><strong>RR:</strong> {cf("blood_pressure") || "—"} Hgmm</p>
              <p><strong>Pulzus:</strong> {cf("heart_rate") || "—"} bpm</p>
              <p><strong>EKG:</strong> {cf("ekg") || "—"}</p>
              <p><strong>VC:</strong> {cf("vc") || "—"}</p>
            </div>
          </div>

          {/* 5. Physical Exam */}
          <div className="border p-2 mb-2">
            <h2 className="font-bold text-xs mb-1 border-b pb-0.5">V. Fizikális vizsgálat</h2>
            <p><strong>Általános állapot:</strong> {cf("body_status")}</p>
            <div className="grid grid-cols-2 gap-x-4 gap-y-0.5 mt-0.5">
              <p><strong>Bőr:</strong> {cf("skin") || "ép"}</p>
              <p><strong>Tetoválás:</strong> {cf("tattoo") || "nincs"}</p>
              <p><strong>Száj és garat:</strong> {cf("oral_pharynx") || "—"}</p>
              <p><strong>Fogazat:</strong> {cf("teeth")}</p>
              <p><strong>Nyelv:</strong> {cf("tongue")}</p>
              <p><strong>Garatképletek:</strong> {cf("pharynx")}</p>
              <p><strong>Nyirokcsomók:</strong> {cf("lymph_nodes")}</p>
              <p><strong>Pajzsmirigy:</strong> {cf("thyroid")}</p>
            </div>
          </div>

          {/* 6. Cardiovascular */}
          <div className="border p-2 mb-2">
            <h2 className="font-bold text-xs mb-1 border-b pb-0.5">VI. Cardiovascularis status</h2>
            <p>{cf("cardiovascular")}</p>
            <p><strong>Erek:</strong> {cf("vessels")} &nbsp; <strong>Varicositas:</strong> {cf("varicosity")}</p>
          </div>

          {/* 7. Lungs + Spirometry */}
          <div className="border p-2 mb-2">
            <h2 className="font-bold text-xs mb-1 border-b pb-0.5">VII. Tüdő és légzésfunkció</h2>
            <p><strong>Tüdő:</strong> {cf("lungs")}</p>
            {cf("lung_xray_date") !== "—" && <p><strong>Tüdőszűrés dátuma:</strong> {cf("lung_xray_date")}</p>}
            <div className="grid grid-cols-4 gap-x-3 mt-0.5">
              <p><strong>FVC:</strong> {cf("fvc") || "—"} %</p>
              <p><strong>FEV1:</strong> {cf("fev1") || "—"} %</p>
              <p><strong>PEF:</strong> {cf("pef") || "—"} %</p>
              <p><strong>FEV1/FVC:</strong> {cf("fev1_fvc") || "—"} %</p>
            </div>
          </div>

          {/* 8. Abdomen */}
          <div className="border p-2 mb-2">
            <h2 className="font-bold text-xs mb-1 border-b pb-0.5">VIII. Has</h2>
            <p>Has-mellkas: <strong>{cf("abdomen")}</strong>. Rezisztencia: <strong>{cf("abdomen_resistance")}</strong>. Tapintása: <strong>{cf("abdomen_palpation")}</strong>. Bélhangok: <strong>{cf("bowel_sounds")}</strong>.</p>
            <p><strong>RDV:</strong> {cf("rdv")}</p>
          </div>

          {/* 9. Musculoskeletal */}
          <div className="border p-2 mb-2">
            <h2 className="font-bold text-xs mb-1 border-b pb-0.5">IX. Mozgásszervi eltérések</h2>
            <p>{cf("musculoskeletal")}</p>
          </div>

          {/* 10. Vision */}
          <div className="border p-2 mb-2">
            <h2 className="font-bold text-xs mb-1 border-b pb-0.5">X. Visus</h2>
            <div className="grid grid-cols-4 gap-x-3">
              <p><strong>Jobb:</strong> {cf("vision_right") || "—"}/10</p>
              <p><strong>Korr:</strong> {cf("vision_right_corr") || "—"}</p>
              <p><strong>Bal:</strong> {cf("vision_left") || "—"}/10</p>
              <p><strong>Korr:</strong> {cf("vision_left_corr") || "—"}</p>
            </div>
            <p><strong>Színlátás:</strong> {cf("color_vision")}</p>
          </div>

          {/* 11. Hearing + Audiometry */}
          <div className="border p-2 mb-2">
            <h2 className="font-bold text-xs mb-1 border-b pb-0.5">XI. Hallás</h2>
            {cf("hearing_condition") !== "—" && <p><strong>Vizsgálati körülmény:</strong> {cf("hearing_condition")}</p>}
            <table className="w-full border-collapse border text-[10px] mt-1">
              <thead>
                <tr className="bg-muted/30">
                  <th className="border p-0.5"></th>
                  <th className="border p-0.5">Beszéd</th>
                  <th className="border p-0.5">Suttogás</th>
                  <th className="border p-0.5">250Hz</th>
                  <th className="border p-0.5">500Hz</th>
                  <th className="border p-0.5">1kHz</th>
                  <th className="border p-0.5">2kHz</th>
                  <th className="border p-0.5">4kHz</th>
                  <th className="border p-0.5">6kHz</th>
                  <th className="border p-0.5">8kHz</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border p-0.5 font-bold">Jobb</td>
                  <td className="border p-0.5 text-center">{cf("hearing_right_speech")}</td>
                  <td className="border p-0.5 text-center">{cf("hearing_right_whisper")}</td>
                  {AUDIO_FREQS.map(f => <td key={`r${f}`} className="border p-0.5 text-center">{cf(`audio_right_${f}`)}dB</td>)}
                </tr>
                <tr>
                  <td className="border p-0.5 font-bold">Bal</td>
                  <td className="border p-0.5 text-center">{cf("hearing_left_speech")}</td>
                  <td className="border p-0.5 text-center">{cf("hearing_left_whisper")}</td>
                  {AUDIO_FREQS.map(f => <td key={`l${f}`} className="border p-0.5 text-center">{cf(`audio_left_${f}`)}dB</td>)}
                </tr>
              </tbody>
            </table>
          </div>

          {/* 12. Neurological */}
          <div className="border p-2 mb-2">
            <h2 className="font-bold text-xs mb-1 border-b pb-0.5">XII. Neurológiai status</h2>
            <p>{cf("neuro_focal")}</p>
            <div className="grid grid-cols-3 gap-x-3 gap-y-0.5">
              <p><strong>Tudati állapot tiszta:</strong> {cf("neuro_consciousness")}</p>
              <p><strong>Térben, időben orientált:</strong> {cf("neuro_orientation")}</p>
              <p><strong>Ínreflexek:</strong> {cf("neuro_reflexes")}</p>
              <p><strong>Vakjárás:</strong> {cf("neuro_blind_walk")}</p>
              <p><strong>Romberg:</strong> {cf("neuro_romberg")}</p>
              <p><strong>Tremor:</strong> {cf("neuro_tremor")}</p>
            </div>
          </div>

          {/* 13. Result */}
          <div className="border p-2 mb-2">
            <h2 className="font-bold text-xs mb-1 border-b pb-0.5">XIII. Eredmény</h2>
            <p><strong>Minősítés:</strong> {RESULT_OPTIONS.find(r => r.value === printExam.result)?.label || printExam.result}</p>
            {printExam.restrictions && <p><strong>Korlátozások:</strong> {printExam.restrictions}</p>}
            <p><strong>Érvényes:</strong> {printExam.valid_until ? new Date(printExam.valid_until).toLocaleDateString("hu-HU") + "-ig" : "—"}</p>
            {printExam.ai_notes && <p><strong>Megjegyzés:</strong> {printExam.ai_notes}</p>}
          </div>

          {/* 14. Consent */}
          <div className="border p-2 mb-2">
            <p className="text-[9px] leading-snug text-justify">{t("questionnaire.consentText")}</p>
          </div>

          {/* 15. Signatures */}
          <div className="flex justify-between mt-4 pt-2 border-t">
            <div className="text-center">
              <p className="text-[9px]">Páciens aláírása</p>
              <div className="mt-6 border-b w-36 mx-auto" />
            </div>
            <div className="text-center">
              <p className="text-[9px]">Orvos aláírása / pecsét</p>
              {printExam.signature_url ? (
                <img src={printExam.signature_url} alt="Aláírás" className="h-12 mt-1 object-contain mx-auto" />
              ) : (
                <div className="mt-6 border-b w-36 mx-auto" />
              )}
              <p className="text-[9px] mt-1">{printExam.doctor_name}</p>
            </div>
            <div className="text-center">
              <p className="text-[9px]">Dátum</p>
              <p className="text-[10px] mt-4">{new Date(printExam.created_at).toLocaleDateString("hu-HU")}</p>
            </div>
          </div>
        </div>
      )}

      <div className="flex items-center justify-between print:hidden">
        <div className="flex items-center gap-3"><FileCheck className="h-6 w-6 text-secondary" /><h1 className="text-2xl font-bold">{t("inner.examinations")}</h1></div>
        <div className="flex gap-2">
          <ExportButton
            filename="vizsgalatok"
            headers={[t("inner.patient"), t("inner.type"), t("inner.result"), t("inner.validUntil"), t("inner.date")]}
            rows={(examinations ?? []).map((e) => [e.patient_name, e.exam_type, RESULT_OPTIONS.find((r) => r.value === e.result)?.label ?? e.result, e.valid_until || "", new Date(e.created_at).toLocaleDateString("hu-HU")])}
          />
          <Button onClick={() => { setForm(emptyForm()); setQuestionnaireData(null); setDialogOpen(true); setStep(1); }}><Plus className="h-4 w-4 mr-2" />{t("inner.newExam")}</Button>
        </div>
      </div>

      <Card className="print:hidden">
        <CardHeader><CardTitle className="text-lg">{t("inner.examinations")} ({examinations?.length ?? 0})</CardTitle></CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader><TableRow><TableHead>{t("inner.patient")}</TableHead><TableHead>{t("inner.type")}</TableHead><TableHead>{t("inner.result")}</TableHead><TableHead>{t("inner.validUntil")}</TableHead><TableHead>{t("inner.date")}</TableHead><TableHead>{t("inner.actions")}</TableHead></TableRow></TableHeader>
            <TableBody>
              {(examinations ?? []).map((e) => (
                <TableRow key={e.id}>
                  <TableCell className="font-medium">{e.patient_name}</TableCell>
                  <TableCell>{e.exam_type}</TableCell>
                  <TableCell><Badge variant={e.result === "alkalmas" ? "default" : e.result === "nem_alkalmas" ? "destructive" : "secondary"}>{RESULT_OPTIONS.find((r) => r.value === e.result)?.label ?? e.result}</Badge></TableCell>
                  <TableCell>{e.valid_until ? new Date(e.valid_until).toLocaleDateString("hu-HU") : "—"}</TableCell>
                  <TableCell>{new Date(e.created_at).toLocaleDateString("hu-HU")}</TableCell>
                  <TableCell className="space-x-1">
                    <Button size="sm" variant="outline" onClick={() => handlePrint(e)}><Printer className="h-4 w-4 mr-1" />{t("inner.print")}</Button>
                  </TableCell>
                </TableRow>
              ))}
              {(examinations ?? []).length === 0 && <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-8">{t("inner.noExam")}</TableCell></TableRow>}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {t("inner.newExamTitle", { step, total: 3 })}
              {form.referral_id && <Badge variant="secondary" className="ml-2">{t("inner.fromReferral")}</Badge>}
            </DialogTitle>
          </DialogHeader>
          {step === 1 && (
            <div className="space-y-4">
              <div className="space-y-1.5">
                <Label>{t("inner.patient")}</Label>
                <Select value={form.patient_id} onValueChange={(v) => { setForm((f) => ({ ...f, patient_id: v })); loadPatientProfileData(v); loadQuestionnaireData(v); }}>
                  <SelectTrigger><SelectValue placeholder={t("inner.selectPatient")} /></SelectTrigger>
                  <SelectContent>{(profiles ?? []).map((p) => <SelectItem key={p.user_id} value={p.user_id}>{p.full_name} {p.taj_number ? `(${p.taj_number})` : ""}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>{t("inner.examType")}</Label>
                <Select value={form.exam_type} onValueChange={(v) => setForm((f) => ({ ...f, exam_type: v }))}>
                  <SelectTrigger><SelectValue placeholder={t("inner.selectType")} /></SelectTrigger>
                  <SelectContent>{EXAM_TYPES.map((et) => <SelectItem key={et.value} value={et.value}>{et.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              {questionnaireData && questionnaireData.length > 0 && (
                <Card className="border-secondary/50 bg-secondary/5">
                  <CardContent className="pt-3 pb-3">
                    <div className="flex items-center gap-2 mb-2">
                      <ClipboardList className="h-4 w-4 text-secondary" />
                      <span className="text-sm font-semibold text-secondary">{t("inner.questionnaireLoaded")}</span>
                    </div>
                    <div className="space-y-1">
                      {questionnaireData.map((q: any) => (
                        <div key={q.id} className="text-xs text-muted-foreground">
                          ✓ {q.title} — {new Date(q.submitted_at).toLocaleDateString("hu-HU")}
                        </div>
                      ))}
                    </div>
                    <p className="text-xs text-muted-foreground mt-1 italic">{t("inner.autoFilledNote")}</p>
                  </CardContent>
                </Card>
              )}
              {form.patient_id && (
                <div className="flex gap-2">
                  <Button type="button" variant="outline" size="sm" onClick={() => loadPreviousExam(form.patient_id)} className="gap-1.5">
                    <History className="h-4 w-4" />{t("inner.loadPreviousExam")}
                  </Button>
                  <Button type="button" variant="outline" size="sm" onClick={() => loadQuestionnaireData(form.patient_id)} className="gap-1.5">
                    <ClipboardList className="h-4 w-4" />{t("inner.loadPreviousQuestionnaire")}
                  </Button>
                </div>
              )}
              <h3 className="font-semibold pt-2">{t("inner.anamnesis")}</h3>
              <div className="space-y-1.5"><Label className="flex items-center gap-2">{t("inner.complaint")} <SpeechToTextButton onResult={(txt) => setForm(f => ({ ...f, patient_data: { ...f.patient_data, complaints: (f.patient_data.complaints ? f.patient_data.complaints + " " : "") + txt } }))} /></Label><Textarea value={form.patient_data.complaints} onChange={(e) => setForm((f) => ({ ...f, patient_data: { ...f.patient_data, complaints: e.target.value } }))} rows={2} /></div>
              <div className="space-y-1.5"><Label className="flex items-center gap-2">{t("inner.diseases")} <SpeechToTextButton onResult={(txt) => setForm(f => ({ ...f, patient_data: { ...f.patient_data, diseases: (f.patient_data.diseases ? f.patient_data.diseases + " " : "") + txt } }))} /></Label><Textarea value={form.patient_data.diseases} onChange={(e) => setForm((f) => ({ ...f, patient_data: { ...f.patient_data, diseases: e.target.value } }))} rows={2} /></div>
              <div className="space-y-1.5"><Label>{t("inner.hospitalCare")}</Label><Input value={form.patient_data.hospital} onChange={(e) => setForm((f) => ({ ...f, patient_data: { ...f.patient_data, hospital: e.target.value } }))} /></div>
              <div className="space-y-1.5"><Label>{t("inner.surgeries")}</Label><Input value={form.patient_data.surgeries} onChange={(e) => setForm((f) => ({ ...f, patient_data: { ...f.patient_data, surgeries: e.target.value } }))} /></div>
              <div className="space-y-1.5"><Label>{t("inner.medications")}</Label><Input value={form.patient_data.medications} onChange={(e) => setForm((f) => ({ ...f, patient_data: { ...f.patient_data, medications: e.target.value } }))} /></div>
              <div className="space-y-1.5"><Label>{t("inner.allergies")}</Label><Input value={form.patient_data.allergies} onChange={(e) => setForm((f) => ({ ...f, patient_data: { ...f.patient_data, allergies: e.target.value } }))} /></div>
              
              <h3 className="font-semibold pt-2">Biometriai adatok</h3>
              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-1"><Label className="text-xs">Testsúly (kg)</Label><Input value={form.patient_data.weight_kg} onChange={(e) => setForm((f) => ({ ...f, patient_data: { ...f.patient_data, weight_kg: e.target.value } }))} placeholder="75" /></div>
                <div className="space-y-1"><Label className="text-xs">Testmagasság (cm)</Label><Input value={form.patient_data.height_cm} onChange={(e) => setForm((f) => ({ ...f, patient_data: { ...f.patient_data, height_cm: e.target.value } }))} placeholder="175" /></div>
                <div className="space-y-1"><Label className="text-xs">Lakcím</Label><Input value={form.patient_data.address} onChange={(e) => setForm((f) => ({ ...f, patient_data: { ...f.patient_data, address: e.target.value } }))} /></div>
              </div>

              <Button className="w-full" onClick={() => setStep(2)} disabled={!form.patient_id || !form.exam_type}>{t("inner.forward")}</Button>
            </div>
          )}
          {step === 2 && (
            <div className="space-y-4">
              <h3 className="font-semibold">{t("inner.vitalSigns")}</h3>
              <div className="grid grid-cols-2 gap-3">
                {[["RR (Hgmm)", "blood_pressure", "120/80"], ["Pulzus (bpm)", "heart_rate", "72"], ["VC (mmol/l)", "vc", ""], ["EKG", "ekg", ""]].map(([label, key, ph]) => (
                  <div key={key} className="space-y-1"><Label className="text-xs">{label}</Label><Input placeholder={ph} value={(form.clinical_findings as any)[key]} onChange={(e) => setForm((f) => ({ ...f, clinical_findings: { ...f.clinical_findings, [key]: e.target.value } }))} /></div>
                ))}
              </div>

              <h3 className="font-semibold pt-2">{t("inner.physicalExam")}</h3>
              <div className="grid grid-cols-2 gap-3">
                {[[t("inner.skinLabel"), "skin"], [t("inner.tattoo"), "tattoo"], [t("inner.bodyStatus"), "body_status"], [t("inner.oralPharynx"), "oral_pharynx"], [t("inner.teeth"), "teeth"], ["Nyelv", "tongue"], ["Garatképletek", "pharynx"], [t("inner.lymphNodes"), "lymph_nodes"], [t("inner.thyroid"), "thyroid"]].map(([label, key]) => (
                  <div key={key} className="space-y-1"><Label className="text-xs">{label}</Label><Input value={(form.clinical_findings as any)[key]} onChange={(e) => setForm((f) => ({ ...f, clinical_findings: { ...f.clinical_findings, [key]: e.target.value } }))} /></div>
                ))}
              </div>

              <h3 className="font-semibold pt-2">{t("inner.cardiovascularSection")}</h3>
              <div className="grid grid-cols-2 gap-3">
                {[[t("inner.cardiovascularStatus"), "cardiovascular"], [t("inner.vessels"), "vessels"], ["Varicositas", "varicosity"], [t("inner.lungs"), "lungs"], [t("inner.chestXrayDate"), "lung_xray_date"]].map(([label, key]) => (
                  <div key={key} className="space-y-1"><Label className="text-xs">{label}</Label><Input value={(form.clinical_findings as any)[key]} onChange={(e) => setForm((f) => ({ ...f, clinical_findings: { ...f.clinical_findings, [key]: e.target.value } }))} /></div>
                ))}
              </div>

              <h3 className="font-semibold pt-2">{t("inner.respiratoryFunction")}</h3>
              <div className="grid grid-cols-4 gap-3">
                {[["FVC %", "fvc"], ["FEV1 %", "fev1"], ["PEF %", "pef"], ["FEV1/FVC %", "fev1_fvc"]].map(([label, key]) => (
                  <div key={key} className="space-y-1"><Label className="text-xs">{label}</Label><Input value={(form.clinical_findings as any)[key]} onChange={(e) => setForm((f) => ({ ...f, clinical_findings: { ...f.clinical_findings, [key]: e.target.value } }))} /></div>
                ))}
              </div>

              <h3 className="font-semibold pt-2">Has</h3>
              <div className="grid grid-cols-2 gap-3">
                {[["Has-mellkas", "abdomen"], ["Rezisztencia", "abdomen_resistance"], [t("inner.abdominalPalpation"), "abdomen_palpation"], [t("inner.bowelSounds"), "bowel_sounds"], ["RDV", "rdv"]].map(([label, key]) => (
                  <div key={key} className="space-y-1"><Label className="text-xs">{label}</Label><Input value={(form.clinical_findings as any)[key]} onChange={(e) => setForm((f) => ({ ...f, clinical_findings: { ...f.clinical_findings, [key]: e.target.value } }))} /></div>
                ))}
              </div>

              <h3 className="font-semibold pt-2">{t("inner.musculoskeletal")}</h3>
              <div className="space-y-1"><Label className="text-xs">{t("inner.musculoskeletalFindings")}</Label><Input value={form.clinical_findings.musculoskeletal} onChange={(e) => setForm((f) => ({ ...f, clinical_findings: { ...f.clinical_findings, musculoskeletal: e.target.value } }))} /></div>

              <h3 className="font-semibold pt-2">{t("inner.vision")}</h3>
              <div className="grid grid-cols-2 gap-3">
                {[[t("inner.visionRight"), "vision_right"], [t("inner.visionRightCorr"), "vision_right_corr"], [t("inner.visionLeft"), "vision_left"], [t("inner.visionLeftCorr"), "vision_left_corr"], [t("inner.colorVision"), "color_vision"]].map(([label, key]) => (
                  <div key={key} className="space-y-1"><Label className="text-xs">{label}</Label><Input value={(form.clinical_findings as any)[key]} onChange={(e) => setForm((f) => ({ ...f, clinical_findings: { ...f.clinical_findings, [key]: e.target.value } }))} /></div>
                ))}
              </div>

              <h3 className="font-semibold pt-2">{t("inner.hearing")}</h3>
              <div className="grid grid-cols-2 gap-3">
                {[[t("inner.hearingRightSpeech"), "hearing_right_speech"], [t("inner.hearingRightWhisper"), "hearing_right_whisper"], [t("inner.hearingLeftSpeech"), "hearing_left_speech"], [t("inner.hearingLeftWhisper"), "hearing_left_whisper"]].map(([label, key]) => (
                  <div key={key} className="space-y-1"><Label className="text-xs">{label}</Label><Input value={(form.clinical_findings as any)[key]} onChange={(e) => setForm((f) => ({ ...f, clinical_findings: { ...f.clinical_findings, [key]: e.target.value } }))} /></div>
                ))}
              </div>
              <div className="space-y-1"><Label className="text-xs">Vizsgálati körülmény</Label><Input value={form.clinical_findings.hearing_condition} onChange={(e) => setForm((f) => ({ ...f, clinical_findings: { ...f.clinical_findings, hearing_condition: e.target.value } }))} /></div>

              {/* Audiometry Table */}
              <div className="border rounded-md p-3">
                <Label className="text-xs font-semibold mb-2 block">Audiometria (dB)</Label>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs border-collapse">
                    <thead>
                      <tr>
                        <th className="border p-1 bg-muted/50"></th>
                        {AUDIO_FREQS.map(f => <th key={f} className="border p-1 bg-muted/50">{f === "1k" ? "1kHz" : f === "2k" ? "2kHz" : f === "4k" ? "4kHz" : f === "6k" ? "6kHz" : f === "8k" ? "8kHz" : `${f}Hz`}</th>)}
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td className="border p-1 font-semibold">Jobb</td>
                        {AUDIO_FREQS.map(freq => (
                          <td key={`r_${freq}`} className="border p-0">
                            <Input className="h-7 text-xs text-center border-0 rounded-none" value={(form.clinical_findings as any)[`audio_right_${freq}`]} onChange={(e) => setForm(f => ({ ...f, clinical_findings: { ...f.clinical_findings, [`audio_right_${freq}`]: e.target.value } }))} />
                          </td>
                        ))}
                      </tr>
                      <tr>
                        <td className="border p-1 font-semibold">Bal</td>
                        {AUDIO_FREQS.map(freq => (
                          <td key={`l_${freq}`} className="border p-0">
                            <Input className="h-7 text-xs text-center border-0 rounded-none" value={(form.clinical_findings as any)[`audio_left_${freq}`]} onChange={(e) => setForm(f => ({ ...f, clinical_findings: { ...f.clinical_findings, [`audio_left_${freq}`]: e.target.value } }))} />
                          </td>
                        ))}
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              <h3 className="font-semibold pt-2">{t("inner.neurologicalStatus")}</h3>
              <div className="grid grid-cols-2 gap-3">
                {[[t("inner.consciousness"), "neuro_consciousness"], [t("inner.orientation"), "neuro_orientation"], [t("inner.focalSign"), "neuro_focal"], [t("inner.reflexes"), "neuro_reflexes"], [t("inner.romberg"), "neuro_romberg"], [t("inner.tremor"), "neuro_tremor"], [t("inner.blindWalk"), "neuro_blind_walk"]].map(([label, key]) => (
                  <div key={key} className="space-y-1"><Label className="text-xs">{label}</Label><Input value={(form.clinical_findings as any)[key]} onChange={(e) => setForm((f) => ({ ...f, clinical_findings: { ...f.clinical_findings, [key]: e.target.value } }))} /></div>
                ))}
              </div>

              <div className="space-y-1"><Label className="text-xs flex items-center gap-2">{t("inner.otherNote")} <SpeechToTextButton onResult={(txt) => setForm(f => ({ ...f, clinical_findings: { ...f.clinical_findings, other: (f.clinical_findings.other ? f.clinical_findings.other + " " : "") + txt } }))} /></Label><Textarea value={form.clinical_findings.other} onChange={(e) => setForm((f) => ({ ...f, clinical_findings: { ...f.clinical_findings, other: e.target.value } }))} rows={2} /></div>

              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setStep(1)}>{t("inner.backward")}</Button>
                <Button className="flex-1" onClick={() => setStep(3)}>{t("inner.forward")}</Button>
              </div>
            </div>
          )}
          {step === 3 && (
            <div className="space-y-4">
              <h3 className="font-semibold">{t("inner.resultAndAiNote")}</h3>
              <Button variant="outline" className="w-full" onClick={generateAiOpinionDraft} disabled={aiLoading}>
                <Sparkles className="h-4 w-4 mr-1" />{aiLoading ? t("inner.generatingAiOpinion") : t("inner.aiOpinionSuggestion")}
              </Button>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label>{t("inner.result")}</Label>
                  <Select value={form.result} onValueChange={(v) => setForm((f) => ({ ...f, result: v }))}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{RESULT_OPTIONS.map((r) => <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>)}</SelectContent></Select>
                </div>
                <div className="space-y-1.5"><Label>{t("inner.validity")}</Label><Input type="date" value={form.valid_until} onChange={(e) => setForm((f) => ({ ...f, valid_until: e.target.value }))} /></div>
              </div>
              <div className="space-y-1.5">
                <Label>Következő labor kontroll dátuma</Label>
                <Input type="date" value={form.next_lab_control} onChange={(e) => setForm((f) => ({ ...f, next_lab_control: e.target.value }))} />
                <p className="text-xs text-muted-foreground">Ha megadja, a rendszer automatikusan emlékeztetőt küld a páciensnek és az orvosnak.</p>
              </div>
              <div className="space-y-1.5">
                <Label>{t("inner.restrictions")}</Label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 max-h-48 overflow-y-auto border rounded-md p-3">
                  {RESTRICTION_OPTIONS.map((r) => {
                    const selected = (form.restrictions || "").split("; ").filter(Boolean);
                    const isChecked = selected.includes(r);
                    return (
                      <div key={r} className="flex items-center space-x-2">
                        <Checkbox
                          id={`restriction-${r}`}
                          checked={isChecked}
                          onCheckedChange={(v) => {
                            const newList = v ? [...selected, r] : selected.filter((s) => s !== r);
                            setForm((f) => ({ ...f, restrictions: newList.join("; ") }));
                          }}
                        />
                        <label htmlFor={`restriction-${r}`} className="text-sm cursor-pointer leading-tight">{r}</label>
                      </div>
                    );
                  })}
                </div>
                <Textarea value={form.restrictions} onChange={(e) => setForm((f) => ({ ...f, restrictions: e.target.value }))} rows={2} placeholder={t("inner.otherRestriction")} className="mt-2" />
              </div>
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <Label>{t("inner.aiMedicalNote")}</Label>
                  <Button size="sm" variant="outline" onClick={generateAiNote} disabled={aiLoading}><Sparkles className="h-4 w-4 mr-1" />{aiLoading ? t("inner.generating") : t("inner.aiGenerate")}</Button>
                </div>
                <Textarea value={form.ai_notes} onChange={(e) => setForm((f) => ({ ...f, ai_notes: e.target.value }))} rows={4} placeholder={t("inner.aiNotePlaceholder")} />
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="auto-opinion" checked={form.auto_opinion} onCheckedChange={(v) => setForm(f => ({ ...f, auto_opinion: !!v }))} />
                <label htmlFor="auto-opinion" className="text-sm cursor-pointer">{t("inner.autoCreateOpinion")}</label>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setStep(2)}>{t("inner.backward")}</Button>
                <Button className="flex-1" onClick={() => createExam.mutate()} disabled={createExam.isPending}>{t("inner.saveExam")}</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
