import { useTranslation } from "react-i18next";
import { LayoutDashboard, Users, Calendar, FileCheck, Building2, ClipboardList, FileUp, FileText, MessageSquare, FolderOpen, BarChart3, Syringe, FileBadge, Heart, Shield, FlaskConical } from "lucide-react";
import DashboardLayout, { type NavItem } from "@/components/DashboardLayout";
import { useUnreadMessages } from "@/hooks/use-unread-messages";

export default function UzemorvosLayout() {
  const { t } = useTranslation();
  const unread = useUnreadMessages();
  const NAV: NavItem[] = [
    { title: t('dashboard.overview'), url: "/uzemorvos", icon: LayoutDashboard },
    { title: t('dashboard.examinations'), url: "/uzemorvos/examinations", icon: FileCheck },
    { title: t('dashboard.appointments'), url: "/uzemorvos/appointments", icon: Calendar },
    { title: t('dashboard.employees'), url: "/uzemorvos/employees", icon: Users },
    { title: t('dashboard.companies'), url: "/uzemorvos/companies", icon: Building2 },
    { title: t('dashboard.referrals'), url: "/uzemorvos/referrals", icon: FileUp },
    { title: t('dashboard.opinions'), url: "/uzemorvos/opinions", icon: FileText },
    { title: t('dashboard.certificates'), url: "/uzemorvos/certificates", icon: FileBadge },
    { title: t('dashboard.questionnaires'), url: "/uzemorvos/questionnaires", icon: ClipboardList },
    { title: t('dashboard.documents'), url: "/uzemorvos/documents", icon: FolderOpen },
    { title: t('dashboard.vaccinations'), url: "/uzemorvos/vaccinations", icon: Syringe },
    { title: t('dashboard.statistics'), url: "/uzemorvos/statistics", icon: BarChart3 },
    { title: t('dashboard.healthPlans'), url: "/uzemorvos/health-plans", icon: Heart },
    { title: t('risk.riskAssessments'), url: "/uzemorvos/risk-assessments", icon: Shield },
    { title: t('dashboard.labRequests'), url: "/uzemorvos/lab-requests", icon: FlaskConical },
    { title: t('dashboard.messages'), url: "/uzemorvos/messages", icon: MessageSquare, badge: unread },
  ];
  return <DashboardLayout navItems={NAV} groupLabel={t('roles.uzemorvos')} />;
}
