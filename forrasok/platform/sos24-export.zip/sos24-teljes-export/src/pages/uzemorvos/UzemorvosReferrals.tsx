import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { FileUp, FileCheck, Printer } from "lucide-react";
import ExportButton from "@/components/ExportButton";
import { useNavigate } from "react-router-dom";
import AiAnalysisPanel from "@/components/AiAnalysisPanel";
import PrintableReferral from "@/components/PrintableReferral";

export default function UzemorvosReferrals() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const [printRef, setPrintRef] = useState<any>(null);

  const STATUS_LABELS: Record<string, string> = { draft: t('inner.draft'), sent: t('inner.sent'), completed: t('inner.completed') };

  const { data: referrals, isLoading } = useQuery({
    queryKey: ["uzemorvos-referrals"],
    queryFn: async () => {
      const { data, error } = await supabase.from("referrals").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      const empIds = [...new Set(data.map((r) => r.employee_id))];
      const { data: profiles } = await supabase.from("profiles").select("user_id, full_name, birth_date, birth_place, address, taj_number, mother_name").in("user_id", empIds);
      const compIds = [...new Set(data.map((r) => r.company_id))];
      const { data: companies } = await supabase.from("companies").select("id, name, address, tax_number, contact_phone, contact_email").in("id", compIds);
      // Load TEÁOR codes for all companies
      const { data: teaorCodes } = await supabase.from("company_teaor_codes").select("company_id, teaor_code, teaor_name, is_primary").in("company_id", compIds);
      return data.map((r) => {
        const profile = (profiles ?? []).find((p) => p.user_id === r.employee_id);
        const company = (companies ?? []).find((c) => c.id === r.company_id);
        const primaryTeaor = (teaorCodes ?? []).find((t: any) => t.company_id === r.company_id && t.is_primary);
        return {
          ...r,
          employee_name: profile?.full_name ?? "—",
          employee_birth_date: profile?.birth_date ?? null,
          employee_birth_place: profile?.birth_place ?? null,
          employee_address: profile?.address ?? null,
          employee_taj: profile?.taj_number ?? null,
          employee_mother_name: profile?.mother_name ?? null,
          company_name: company?.name ?? "—",
          company_address: company?.address ?? null,
          company_tax_number: company?.tax_number ?? null,
          company_phone: company?.contact_phone ?? null,
          company_email: company?.contact_email ?? null,
          company_teaor: primaryTeaor ? `${primaryTeaor.teaor_code} — ${primaryTeaor.teaor_name || ""}` : null,
        };
      });
    },
  });

  const markCompleted = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("referrals").update({ status: "completed" as any }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["uzemorvos-referrals"] }); toast({ title: t('inner.referralCompleted') }); },
  });

  const handleStartExam = (referral: any) => {
    navigate(`/uzemorvos/examinations?referral_id=${referral.id}&patient_id=${referral.employee_id}&exam_type=${encodeURIComponent(referral.exam_reason)}`);
  };

  if (isLoading) return <div className="flex items-center justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>;

  return (
    <div className="space-y-6">
      {printRef && <PrintableReferral referral={printRef} />}
      <div className="print:hidden space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3"><FileUp className="h-6 w-6 text-secondary" /><h1 className="text-2xl font-bold">{t('inner.referrals')}</h1></div>
        <ExportButton
          filename="beutalok"
          headers={[t('inner.employee'), t('inner.company'), t('inner.position'), t('inner.reason'), t('inner.status')]}
          rows={(referrals ?? []).map((r) => [r.employee_name, r.company_name, r.position || "", r.exam_reason, STATUS_LABELS[r.status] ?? r.status])}
        />
      </div>
      <Card>
        <CardHeader><CardTitle className="text-lg">{t('inner.receivedReferrals')} ({referrals?.length ?? 0})</CardTitle></CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader><TableRow><TableHead>{t('inner.employee')}</TableHead><TableHead>{t('inner.company')}</TableHead><TableHead>{t('inner.position')}</TableHead><TableHead>{t('inner.reason')}</TableHead><TableHead>{t('inner.status')}</TableHead><TableHead>{t('inner.ai')}</TableHead><TableHead>{t('inner.action')}</TableHead></TableRow></TableHeader>
            <TableBody>
              {(referrals ?? []).map((r) => (
                <TableRow key={r.id}>
                  <TableCell className="font-medium">{r.employee_name}</TableCell>
                  <TableCell>{r.company_name}</TableCell>
                  <TableCell>{r.position || "—"}</TableCell>
                  <TableCell>{r.exam_reason}</TableCell>
                  <TableCell><Badge variant={r.status === "completed" ? "default" : "secondary"}>{STATUS_LABELS[r.status] ?? r.status}</Badge></TableCell>
                  <TableCell>
                    <AiAnalysisPanel
                      type="risk_analysis"
                      data={{ position: r.position, feor: r.feor, exam_reason: r.exam_reason, unit_name: r.unit_name, risk_factors: r.risk_factors }}
                      title={t('inner.riskAnalysis')}
                      buttonLabel={t('inner.risk')}
                    />
                  </TableCell>
                  <TableCell className="space-x-2">
                    <Button size="sm" variant="outline" onClick={() => { setPrintRef({ employee_name: r.employee_name, company_name: r.company_name, company_address: r.company_address, company_tax_number: r.company_tax_number, company_phone: r.company_phone, company_email: r.company_email, company_teaor: r.company_teaor, position: r.position, unit_name: r.unit_name, exam_reason: r.exam_reason, risk_factors: r.risk_factors ?? {}, created_at: r.created_at, feor: r.feor, employee_birth_date: r.employee_birth_date, employee_birth_place: r.employee_birth_place, employee_address: r.employee_address, employee_taj: r.employee_taj, employee_mother_name: r.employee_mother_name }); setTimeout(() => window.print(), 300); }}><Printer className="h-4 w-4 mr-1" />{t('inner.print')}</Button>
                    {r.status === "sent" && (
                      <>
                        <Button size="sm" variant="default" onClick={() => handleStartExam(r)}>
                          <FileCheck className="h-4 w-4 mr-1" />{t('inner.startExam')}
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => markCompleted.mutate(r.id)} disabled={markCompleted.isPending}>
                          {t('inner.completed')}
                        </Button>
                      </>
                    )}
                  </TableCell>
                </TableRow>
              ))}
              {(referrals ?? []).length === 0 && <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-8">{t('inner.noReferral')}</TableCell></TableRow>}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
    </div>
  );
}
