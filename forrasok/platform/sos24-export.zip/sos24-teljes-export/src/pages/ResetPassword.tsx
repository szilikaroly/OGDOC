import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useSiteSettings, useSiteSettingsIdMap } from "@/hooks/use-cms";
import { useSiteSettingsTranslations } from "@/hooks/use-content-translations";
import { useToast } from "@/hooks/use-toast";
import { KeyRound, Mail, Loader2, AlertTriangle } from "lucide-react";
import LanguageSwitcher from "@/components/LanguageSwitcher";
import { useTranslation } from "react-i18next";
import { translateAuthError } from "@/lib/auth-errors";

type Stage = "checking" | "recovery" | "request";


export default function ResetPassword() {
  const [loading, setLoading] = useState(false);
  const [stage, setStage] = useState<Stage>("checking");
  const [linkError, setLinkError] = useState<string | null>(null);
  const navigate = useNavigate();
  const { toast } = useToast();
  const { data: s } = useSiteSettings();
  const { data: idMap } = useSiteSettingsIdMap();
  const { ctSetting } = useSiteSettingsTranslations();
  const { t, i18n } = useTranslation();
  const lang = i18n.language;

  const ts = (key: string, fallbackKey: string) => {
    const id = idMap?.[key];
    const translated = id ? ctSetting(id, s?.[key]) : undefined;
    if (lang !== "hu" && translated && translated === s?.[key]) return t(fallbackKey);
    return translated || t(fallbackKey);
  };

  /** Handle recovery-link landing in all known formats. */
  useEffect(() => {
    let cancelled = false;

    const cleanUrl = () => {
      try {
        window.history.replaceState({}, "", window.location.pathname);
      } catch { /* ignore */ }
    };

    const enterRecovery = () => {
      if (cancelled) return;
      setStage("recovery");
      setLinkError(null);
    };

    const fail = (key: string) => {
      if (cancelled) return;
      setLinkError(t(key));
      setStage("request");
      cleanUrl();
    };

    (async () => {
      const url = new URL(window.location.href);
      const hash = new URLSearchParams(window.location.hash.replace(/^#/, ""));
      const search = url.searchParams;

      // 1) Error coming back from Supabase (hash or query)
      const errCode = hash.get("error_code") || search.get("error_code") || "";
      const errDesc = hash.get("error_description") || search.get("error_description") || "";
      const err = hash.get("error") || search.get("error") || "";
      if (errCode || err) {
        if (errCode === "otp_expired") return fail("auth.linkExpired");
        if (err === "access_denied") return fail("auth.linkInvalid");
        if (cancelled) return;
        setLinkError(errDesc || t("auth.linkErrorGeneric"));
        setStage("request");
        cleanUrl();
        return;
      }

      // Register listener early — supabase-js fires PASSWORD_RECOVERY when it
      // finishes processing the hash on its own.
      const { data: sub } = supabase.auth.onAuthStateChange((event) => {
        if (event === "PASSWORD_RECOVERY") enterRecovery();
      });

      try {
        // 2) Modern OTP token-hash recovery link (?token_hash=...&type=recovery)
        const tokenHash = search.get("token_hash");
        const type = search.get("type");
        if (tokenHash && type === "recovery") {
          const { error } = await supabase.auth.verifyOtp({ token_hash: tokenHash, type: "recovery" });
          if (error) { sub.subscription.unsubscribe(); return fail(/expired/i.test(error.message) ? "auth.linkExpired" : "auth.linkInvalid"); }
          cleanUrl();
          enterRecovery();
          return;
        }

        // 3) PKCE code flow (?code=...)
        const code = search.get("code");
        if (code) {
          const { error } = await supabase.auth.exchangeCodeForSession(window.location.href);
          if (error) { sub.subscription.unsubscribe(); return fail(/expired/i.test(error.message) ? "auth.linkExpired" : "auth.linkInvalid"); }
          cleanUrl();
          enterRecovery();
          return;
        }

        // 4) Hash-style access_token=... (handled by supabase-js automatically).
        // Wait briefly for PASSWORD_RECOVERY or an existing session, otherwise show the request form.
        if (window.location.hash.includes("access_token") || window.location.hash.includes("type=recovery")) {
          // Give supabase-js a tick to process the URL hash.
          await new Promise((r) => setTimeout(r, 300));
          const { data } = await supabase.auth.getSession();
          if (data.session) {
            cleanUrl();
            enterRecovery();
            return;
          }
        }

        // 5) No recovery context at all → show request form.
        if (!cancelled) setStage("request");
        // Keep the listener for late PASSWORD_RECOVERY events (e.g. slow tick).
        setTimeout(() => sub.subscription.unsubscribe(), 5000);
      } catch (e: any) {
        sub.subscription.unsubscribe();
        if (cancelled) return;
        setLinkError(translateAuthError(e, t));
        setStage("request");
      }
    })();

    return () => { cancelled = true; };
  }, [t]);

  // === Forms ===
  const requestSchema = z.object({
    email: z.string().trim().email(t("auth.validEmail")).max(255),
  });

  const resetSchema = z.object({
    password: z.string()
      .min(8, t("auth.passwordTooShort"))
      .max(128)
      .refine((v) => /[A-Za-z]/.test(v) && /\d/.test(v), { message: t("auth.passwordNeedsLetterNumber") }),
    confirmPassword: z.string(),
  }).refine((d) => d.password === d.confirmPassword, {
    message: t("auth.passwordsNoMatch"),
    path: ["confirmPassword"],
  });

  const requestForm = useForm<z.infer<typeof requestSchema>>({
    resolver: zodResolver(requestSchema),
    defaultValues: { email: "" },
  });

  const resetForm = useForm<z.infer<typeof resetSchema>>({
    resolver: zodResolver(resetSchema),
    defaultValues: { password: "", confirmPassword: "" },
  });

  const onRequestReset = async (values: z.infer<typeof requestSchema>) => {
    setLoading(true);
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(values.email, {
        redirectTo: `${window.location.origin}/reset-password`,
      });
      if (error) throw error;
      toast({
        title: t("auth.resetPassword"),
        description: t("auth.resetLinkSentGeneric"),
      });
      setLinkError(null);
    } catch (err: any) {
      toast({ variant: "destructive", title: t("common.error"), description: translateAuthError(err, t) });
    } finally {
      setLoading(false);
    }
  };

  const onResetPassword = async (values: z.infer<typeof resetSchema>) => {
    setLoading(true);
    try {
      const { error } = await supabase.auth.updateUser({ password: values.password });
      if (error) throw error;
      // Clean recovery session so the user must log in with the new password
      await supabase.auth.signOut().catch(() => { /* ignore */ });
      toast({ title: t("auth.setNewPassword"), description: t("auth.passwordSaved") });
      navigate("/login?passwordChanged=1", { replace: true });
    } catch (err: any) {
      const msg = translateAuthError(err, t);
      // Surface as inline form error when relevant
      if (/jelszó|password/i.test(msg)) {
        resetForm.setError("password", { message: msg });
      } else {
        toast({ variant: "destructive", title: t("common.error"), description: msg });
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-hero px-4 relative">
      <div className="absolute top-4 right-4">
        <LanguageSwitcher />
      </div>
      <Card className="w-full max-w-md border-border/50 bg-card shadow-luxury">
        <CardHeader className="text-center">
          <Link to="/" className="mx-auto mb-2 font-display text-2xl font-bold text-gradient-gold">
            {ts("site_name", "common.name")}
          </Link>
          <CardTitle className="text-xl">
            {stage === "recovery"
              ? ts("auth_reset_title_recovery", "auth.setNewPassword")
              : ts("auth_reset_title", "auth.resetPassword")}
          </CardTitle>
          <CardDescription>
            {stage === "recovery"
              ? ts("auth_reset_subtitle_recovery", "auth.enterNewPassword")
              : ts("auth_reset_subtitle", "auth.resetEmailDesc")}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {stage === "checking" && (
            <div className="flex flex-col items-center gap-2 py-6 text-sm text-muted-foreground">
              <Loader2 className="h-5 w-5 animate-spin" />
              {t("auth.verifyingLink")}
            </div>
          )}

          {stage === "request" && linkError && (
            <Alert variant="destructive" className="mb-4">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>{linkError}</AlertDescription>
            </Alert>
          )}

          {stage === "recovery" ? (
            <Form {...resetForm}>
              <form onSubmit={resetForm.handleSubmit(onResetPassword)} className="space-y-4">
                <FormField control={resetForm.control} name="password" render={({ field }) => (
                  <FormItem>
                    <FormLabel>{ts("auth_new_password_label", "auth.newPassword")}</FormLabel>
                    <FormControl><Input type="password" autoComplete="new-password" placeholder="••••••••" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={resetForm.control} name="confirmPassword" render={({ field }) => (
                  <FormItem>
                    <FormLabel>{ts("auth_confirm_password_label", "auth.confirmPassword")}</FormLabel>
                    <FormControl><Input type="password" autoComplete="new-password" placeholder="••••••••" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <Button type="submit" className="w-full bg-secondary text-secondary-foreground hover:bg-secondary/90" disabled={loading}>
                  {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <KeyRound className="mr-2 h-4 w-4" />}
                  {loading ? `${t("auth.savePassword")}...` : ts("auth_reset_button_save", "auth.savePassword")}
                </Button>
              </form>
            </Form>
          ) : stage === "request" ? (
            <Form {...requestForm}>
              <form onSubmit={requestForm.handleSubmit(onRequestReset)} className="space-y-4">
                <FormField control={requestForm.control} name="email" render={({ field }) => (
                  <FormItem>
                    <FormLabel>{ts("auth_email_label", "auth.email")}</FormLabel>
                    <FormControl><Input type="email" autoComplete="email" placeholder="email@example.com" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <Button type="submit" className="w-full bg-secondary text-secondary-foreground hover:bg-secondary/90" disabled={loading}>
                  {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Mail className="mr-2 h-4 w-4" />}
                  {loading ? `${t("auth.sendResetLink")}...` : ts("auth_reset_button", "auth.sendResetLink")}
                </Button>
              </form>
            </Form>
          ) : null}

          <p className="mt-6 text-center text-sm text-muted-foreground">
            <Link to="/login" className="font-medium text-secondary hover:underline">
              {ts("auth_back_to_login", "auth.backToLogin")}
            </Link>
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
