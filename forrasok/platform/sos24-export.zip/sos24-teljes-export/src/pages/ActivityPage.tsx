import { useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useContentTranslations } from "@/hooks/use-content-translations";
import Navbar from "@/components/landing/Navbar";
import Footer from "@/components/landing/Footer";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Calendar } from "lucide-react";
import { getIcon } from "@/lib/icon-map";
import { useTranslation } from "react-i18next";
import { sanitizeRichHtml } from "@/lib/sanitize-html";


interface Activity {
  id: string;
  name: string;
  slug: string;
  short_description: string | null;
  long_description: string | null;
  icon_name: string | null;
  image_url: string | null;
  seo_title: string | null;
  seo_description: string | null;
  seo_keywords: string | null;
  og_title: string | null;
  og_description: string | null;
  og_image: string | null;
  page_content: string | null;
}

export default function ActivityPage() {
  const { slug } = useParams<{ slug: string }>();
  const { t } = useTranslation();
  const { ct } = useContentTranslations("activities");

  const { data: activity, isLoading } = useQuery({
    queryKey: ["activity", slug],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("activities")
        .select("*")
        .eq("slug", slug!)
        .eq("is_active", true)
        .single();
      if (error) throw error;
      return data as Activity;
    },
    enabled: !!slug,
  });

  // Set SEO meta tags from activity data
  useEffect(() => {
    if (!activity) return;
    const prev = document.title;
    const title = ct(activity.id, "seo_title", activity.seo_title) || ct(activity.id, "name", activity.name);
    document.title = title;
    const setMeta = (attr: string, name: string, content: string | null, isProp = false) => {
      if (!content) return;
      const a = isProp ? "property" : "name";
      let el = document.querySelector(`meta[${a}="${name}"]`) as HTMLMetaElement | null;
      if (!el) { el = document.createElement("meta"); el.setAttribute(a, name); document.head.appendChild(el); }
      el.content = content;
    };
    setMeta("name", "description", ct(activity.id, "seo_description", activity.seo_description));
    setMeta("name", "keywords", activity.seo_keywords);
    setMeta("property", "og:title", ct(activity.id, "seo_title", activity.og_title || activity.seo_title), true);
    setMeta("property", "og:description", ct(activity.id, "seo_description", activity.og_description || activity.seo_description), true);
    setMeta("property", "og:image", activity.og_image || activity.image_url, true);
    return () => { document.title = prev; };
  }, [activity, ct]);

  const Icon = activity ? getIcon(activity.icon_name) : null;

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1">
        {isLoading ? (
          <div className="container mx-auto px-4 py-24 max-w-4xl">
            <Skeleton className="h-10 w-64 mb-4" />
            <Skeleton className="h-6 w-96 mb-8" />
            <Skeleton className="h-96 w-full" />
          </div>
        ) : !activity ? (
          <div className="container mx-auto px-4 py-24 text-center">
            <h1 className="text-2xl font-bold mb-4">{t("activities.notFound")}</h1>
            <Link to="/"><Button variant="outline"><ArrowLeft className="h-4 w-4 mr-2" /> {t("activities.backToHome")}</Button></Link>
          </div>
        ) : (
          <>
            {/* Hero */}
            <section className="bg-muted/30 py-16 md:py-24">
              <div className="container mx-auto px-4 max-w-4xl">
                <Link to="/#tevekenysegek" className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground mb-6 transition-colors">
                  <ArrowLeft className="h-4 w-4 mr-1" /> {t("activities.back")}
                </Link>
                <div className="flex items-start gap-4 md:gap-6">
                  {Icon && (
                    <div className="flex h-16 w-16 md:h-20 md:w-20 shrink-0 items-center justify-center rounded-2xl bg-accent text-secondary">
                      <Icon className="h-8 w-8 md:h-10 md:w-10" />
                    </div>
                  )}
                  <div>
                    <h1 className="text-3xl md:text-4xl font-bold text-foreground">
                      {ct(activity.id, "name", activity.name)}
                    </h1>
                    {activity.long_description && (
                      <div className="mt-3 text-lg text-muted-foreground leading-relaxed prose prose-lg dark:prose-invert max-w-none" dangerouslySetInnerHTML={{ __html: sanitizeRichHtml(ct(activity.id, "long_description", activity.long_description)) }} />
                    )}
                  </div>
                </div>
              </div>
            </section>

            {/* Content */}
            {activity.page_content && (
              <section className="py-16">
                <div className="container mx-auto px-4 max-w-4xl">
                  <div className="prose prose-lg dark:prose-invert max-w-none" dangerouslySetInnerHTML={{ __html: sanitizeRichHtml(ct(activity.id, "page_content", activity.page_content)) }} />
                </div>
              </section>
            )}

            {/* CTA */}
            <section className="py-16 bg-muted/30">
              <div className="container mx-auto px-4 max-w-2xl text-center">
                <h2 className="text-2xl font-bold mb-4">{t("activities.ctaTitle")}</h2>
                <p className="text-muted-foreground mb-6">{t("activities.ctaDescription")}</p>
                <div className="flex flex-wrap justify-center gap-3">
                  <Link to="/login">
                    <Button size="lg"><Calendar className="h-5 w-5 mr-2" /> {t("activities.bookAppointment")}</Button>
                  </Link>
                  <Link to="/#helyszinek">
                    <Button size="lg" variant="outline">{t("activities.contact")}</Button>
                  </Link>
                </div>
              </div>
            </section>
          </>
        )}
      </main>
      <Footer />
    </div>
  );
}
