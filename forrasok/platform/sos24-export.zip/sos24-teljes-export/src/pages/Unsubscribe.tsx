import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MailX, CheckCircle, AlertCircle, Loader2 } from "lucide-react";

type Status = "loading" | "valid" | "already" | "invalid" | "success" | "error";

export default function Unsubscribe() {
  const [searchParams] = useSearchParams();
  const token = searchParams.get("token");
  const [status, setStatus] = useState<Status>("loading");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!token) {
      setStatus("invalid");
      return;
    }
    (async () => {
      try {
        const { data, error } = await supabase.functions.invoke("handle-email-unsubscribe", {
          method: "GET",
          headers: { "Content-Type": "application/json" },
          body: null,
        });
        // Try GET with query param
        const res = await fetch(
          `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/handle-email-unsubscribe?token=${token}`,
          { headers: { "Content-Type": "application/json" } }
        );
        const json = await res.json();
        if (json.status === "valid") setStatus("valid");
        else if (json.status === "already_unsubscribed") setStatus("already");
        else setStatus("invalid");
      } catch {
        setStatus("invalid");
      }
    })();
  }, [token]);

  const handleUnsubscribe = async () => {
    setSubmitting(true);
    try {
      const res = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/handle-email-unsubscribe`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ token }),
        }
      );
      const json = await res.json();
      if (json.success || json.status === "unsubscribed") setStatus("success");
      else setStatus("error");
    } catch {
      setStatus("error");
    }
    setSubmitting(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <MailX className="mx-auto h-12 w-12 text-muted-foreground mb-2" />
          <CardTitle>Email leiratkozás</CardTitle>
        </CardHeader>
        <CardContent className="text-center space-y-4">
          {status === "loading" && (
            <div className="flex items-center justify-center gap-2 text-muted-foreground">
              <Loader2 className="h-5 w-5 animate-spin" />
              <span>Ellenőrzés...</span>
            </div>
          )}
          {status === "valid" && (
            <>
              <p className="text-muted-foreground">
                Biztosan le szeretne iratkozni az email értesítésekről?
              </p>
              <Button onClick={handleUnsubscribe} disabled={submitting} variant="destructive">
                {submitting ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                Leiratkozás megerősítése
              </Button>
            </>
          )}
          {status === "already" && (
            <div className="flex flex-col items-center gap-2 text-muted-foreground">
              <CheckCircle className="h-8 w-8 text-green-500" />
              <p>Ön már leiratkozott az email értesítésekről.</p>
            </div>
          )}
          {status === "success" && (
            <div className="flex flex-col items-center gap-2">
              <CheckCircle className="h-8 w-8 text-green-500" />
              <p className="text-muted-foreground">Sikeresen leiratkozott. Nem fog több email értesítést kapni.</p>
            </div>
          )}
          {status === "invalid" && (
            <div className="flex flex-col items-center gap-2 text-muted-foreground">
              <AlertCircle className="h-8 w-8 text-destructive" />
              <p>Érvénytelen vagy lejárt leiratkozási link.</p>
            </div>
          )}
          {status === "error" && (
            <div className="flex flex-col items-center gap-2 text-muted-foreground">
              <AlertCircle className="h-8 w-8 text-destructive" />
              <p>Hiba történt a leiratkozás során. Kérjük, próbálja újra később.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
