import Navbar from "@/components/landing/Navbar";
import HeroSection from "@/components/landing/HeroSection";
import ActivitiesSection from "@/components/landing/ActivitiesSection";
import ServicesSection from "@/components/landing/ServicesSection";
import LabSection from "@/components/landing/LabSection";
import AboutSection from "@/components/landing/AboutSection";
import CTASection from "@/components/landing/CTASection";
import LocationsSection from "@/components/landing/LocationsSection";
import Footer from "@/components/landing/Footer";
import StickyLogos from "@/components/StickyLogos";

const Index = () => (
  <div className="min-h-screen">
    <Navbar />
    <HeroSection />
    <ActivitiesSection />
    <ServicesSection />
    <LabSection />
    <AboutSection />
    <CTASection />
    <LocationsSection />
    <Footer />
    <StickyLogos />
  </div>
);

export default Index;
