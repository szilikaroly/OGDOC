import { useEffect } from "react";
import { Link } from "react-router-dom";
import { useActivities } from "@/hooks/use-cms";
import { useContentTranslations } from "@/hooks/use-content-translations";
import Navbar from "@/components/landing/Navbar";
import Footer from "@/components/landing/Footer";
import { Skeleton } from "@/components/ui/skeleton";
import { getIcon } from "@/lib/icon-map";
import { useTranslation } from "react-i18next";
import { ArrowRight } from "lucide-react";

export default function ActivitiesListPage() {
  const { t } = useTranslation();
  const { data: activities, isLoading } = useActivities();
  const { ct } = useContentTranslations("activities");

  useEffect(() => {
    document.title = t("activities.pageTitle", "Tevékenységeink");
  }, [t]);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      <main className="flex-1 pt-24 pb-16">
        <div className="container mx-auto px-4 lg:px-8">
          <h1 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-2">
            {t("activities.pageTitle", "Tevékenységeink")}
          </h1>
          <p className="text-muted-foreground mb-10 max-w-2xl">
            {t("activities.pageDescription", "Ismerje meg szolgáltatásainkat és szakterületeinket.")}
          </p>

          {isLoading ? (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {Array.from({ length: 6 }).map((_, i) => (
                <Skeleton key={i} className="h-48 rounded-xl" />
              ))}
            </div>
          ) : (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {activities?.map((a) => {
                const Icon = getIcon(a.icon_name ?? "");
                return (
                  <Link
                    key={a.id}
                    to={`/tevekenyseg/${a.slug}`}
                    className="group rounded-xl border bg-card p-6 shadow-sm transition-all hover:shadow-md hover:border-primary/30"
                  >
                    <div className="flex items-start gap-4">
                      {Icon && (
                        <div className="rounded-lg bg-primary/10 p-2.5 text-primary">
                          <Icon className="h-6 w-6" />
                        </div>
                      )}
                      <div className="flex-1 min-w-0">
                        <h2 className="font-semibold text-foreground group-hover:text-primary transition-colors">
                          {ct(a.id, "name", a.name)}
                        </h2>
                        {a.short_description && (
                          <p className="mt-1.5 text-sm text-muted-foreground line-clamp-3">
                            {ct(a.id, "short_description", a.short_description)}
                          </p>
                        )}
                      </div>
                    </div>
                    <div className="mt-4 flex items-center text-sm font-medium text-primary opacity-0 group-hover:opacity-100 transition-opacity">
                      {t("common.readMore", "Tovább")} <ArrowRight className="ml-1 h-4 w-4" />
                    </div>
                  </Link>
                );
              })}
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
}
