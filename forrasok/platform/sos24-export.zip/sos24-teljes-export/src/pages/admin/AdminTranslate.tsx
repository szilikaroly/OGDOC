import { useState, useMemo, useEffect } from "react";
import { useTranslation } from "react-i18next";
import i18n from "@/i18n/i18n";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { useToast } from "@/hooks/use-toast";
import { Languages, Loader2, CheckCircle, AlertCircle, Download, Search, ChevronDown, ChevronRight, Copy, Save, RefreshCw, Globe, Database } from "lucide-react";

import huJson from "@/i18n/hu.json";
import enJson from "@/i18n/en.json";
import deJson from "@/i18n/de.json";
import roJson from "@/i18n/ro.json";
import srJson from "@/i18n/sr.json";
import zhJson from "@/i18n/zh.json";
import filJson from "@/i18n/fil.json";

const LANGS = [
  { value: "hu", label: "Magyar", json: huJson },
  { value: "en", label: "English", json: enJson },
  { value: "de", label: "Deutsch", json: deJson },
  { value: "ro", label: "Română", json: roJson },
  { value: "sr", label: "Srpski", json: srJson },
  { value: "zh", label: "中文", json: zhJson },
  { value: "fil", label: "Filipino", json: filJson },
];

function flattenObj(obj: any, prefix = ""): Record<string, string> {
  const result: Record<string, string> = {};
  for (const key of Object.keys(obj)) {
    const path = prefix ? `${prefix}.${key}` : key;
    if (typeof obj[key] === "object" && obj[key] !== null && !Array.isArray(obj[key])) {
      Object.assign(result, flattenObj(obj[key], path));
    } else {
      result[path] = String(obj[key]);
    }
  }
  return result;
}

function unflattenObj(flat: Record<string, string>): any {
  const result: any = {};
  for (const [path, value] of Object.entries(flat)) {
    const keys = path.split(".");
    let current = result;
    for (let i = 0; i < keys.length - 1; i++) {
      if (!current[keys[i]]) current[keys[i]] = {};
      current = current[keys[i]];
    }
    current[keys[keys.length - 1]] = value;
  }
  return result;
}

// --- Missing Keys Finder Component ---
function MissingKeysFinder() {
  const [refLang, setRefLang] = useState("hu");
  const [searchQuery, setSearchQuery] = useState("");
  const [expandedNs, setExpandedNs] = useState<Set<string>>(new Set());
  const [expandedLang, setExpandedLang] = useState<string | null>(null);
  const { toast } = useToast();

  const refFlat = useMemo(() => {
    const lang = LANGS.find((l) => l.value === refLang);
    return lang ? flattenObj(lang.json) : {};
  }, [refLang]);

  const allFlats = useMemo(() => {
    return LANGS.filter((l) => l.value !== refLang).map((l) => ({
      ...l,
      flat: flattenObj(l.json),
    }));
  }, [refLang]);

  // Per-language missing keys
  const missingByLang = useMemo(() => {
    const refKeys = Object.keys(refFlat);
    return allFlats.map((l) => {
      const missing = refKeys.filter((k) => !l.flat[k]);
      const identical = refKeys.filter((k) => l.flat[k] && l.flat[k] === refFlat[k]);
      const extra = Object.keys(l.flat).filter((k) => !refFlat[k]);
      return { ...l, missing, identical, extra, total: refKeys.length };
    });
  }, [refFlat, allFlats]);

  // Filtered and grouped
  const getFilteredGrouped = (keys: string[]) => {
    const filtered = searchQuery
      ? keys.filter((k) => k.toLowerCase().includes(searchQuery.toLowerCase()))
      : keys;
    const grouped: Record<string, string[]> = {};
    filtered.forEach((k) => {
      const ns = k.split(".")[0];
      if (!grouped[ns]) grouped[ns] = [];
      grouped[ns].push(k);
    });
    return { filtered, grouped };
  };

  const toggleNs = (ns: string) => {
    setExpandedNs((prev) => {
      const next = new Set(prev);
      next.has(ns) ? next.delete(ns) : next.add(ns);
      return next;
    });
  };

  const copyKeys = (keys: string[]) => {
    const obj: Record<string, string> = {};
    keys.forEach((k) => { obj[k] = refFlat[k] || ""; });
    navigator.clipboard.writeText(JSON.stringify(obj, null, 2));
    toast({ title: `${keys.length} kulcs vágólapra másolva` });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          <Search className="h-5 w-5" />
          Hiányzó kulcsok kereső
        </CardTitle>
        <CardDescription>
          Részletes áttekintés a hiányzó, azonos és extra fordítási kulcsokról nyelvenként.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <Label>Referencia nyelv (alap)</Label>
            <Select value={refLang} onValueChange={setRefLang}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {LANGS.map((l) => <SelectItem key={l.value} value={l.value}>{l.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Kulcs keresés</Label>
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="pl. inner.patient, landing..."
                className="pl-9"
              />
            </div>
          </div>
        </div>

        {/* Summary table */}
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nyelv</TableHead>
              <TableHead className="text-center">Összes</TableHead>
              <TableHead className="text-center">Hiányzó</TableHead>
              <TableHead className="text-center">Azonos</TableHead>
              <TableHead className="text-center">Extra</TableHead>
              <TableHead className="text-center">Lefedettség</TableHead>
              <TableHead></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {missingByLang.map((l) => {
              const coverage = Math.round(((l.total - l.missing.length) / l.total) * 100);
              const isExpanded = expandedLang === l.value;
              return (
                <>
                  <TableRow
                    key={l.value}
                    className="cursor-pointer hover:bg-muted/50"
                    onClick={() => setExpandedLang(isExpanded ? null : l.value)}
                  >
                    <TableCell className="font-medium flex items-center gap-2">
                      {isExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                      {l.label}
                    </TableCell>
                    <TableCell className="text-center">{Object.keys(l.flat).length}</TableCell>
                    <TableCell className="text-center">
                      <Badge variant={l.missing.length > 0 ? "destructive" : "default"}>{l.missing.length}</Badge>
                    </TableCell>
                    <TableCell className="text-center">
                      <Badge variant={l.identical.length > 0 ? "secondary" : "default"}>{l.identical.length}</Badge>
                    </TableCell>
                    <TableCell className="text-center">
                      <Badge variant={l.extra.length > 0 ? "outline" : "default"}>{l.extra.length}</Badge>
                    </TableCell>
                    <TableCell className="text-center">
                      <div className="flex items-center gap-2 justify-center">
                        <Progress value={coverage} className="w-16 h-2" />
                        <span className={`text-sm font-medium ${coverage === 100 ? "text-green-600" : coverage >= 80 ? "text-yellow-600" : "text-destructive"}`}>
                          {coverage}%
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>
                      {l.missing.length > 0 && (
                        <Button size="sm" variant="ghost" onClick={(e) => { e.stopPropagation(); copyKeys(l.missing); }}>
                          <Copy className="h-3 w-3" />
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                  {isExpanded && (
                    <TableRow key={`${l.value}-detail`}>
                      <TableCell colSpan={7} className="p-0">
                        <div className="bg-muted/30 p-4 space-y-2 max-h-[400px] overflow-y-auto">
                          {l.missing.length > 0 && (
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <h4 className="text-sm font-semibold text-destructive">Hiányzó kulcsok ({l.missing.length})</h4>
                                <Button size="sm" variant="outline" onClick={() => copyKeys(l.missing)}>
                                  <Copy className="h-3 w-3 mr-1" /> Összes másolása
                                </Button>
                              </div>
                              {(() => {
                                const { grouped } = getFilteredGrouped(l.missing);
                                return Object.entries(grouped).sort().map(([ns, keys]) => (
                                  <Collapsible key={ns} open={expandedNs.has(`${l.value}-missing-${ns}`)} onOpenChange={() => toggleNs(`${l.value}-missing-${ns}`)}>
                                    <CollapsibleTrigger className="flex items-center gap-2 w-full text-left text-sm font-medium hover:text-secondary py-1">
                                      {expandedNs.has(`${l.value}-missing-${ns}`) ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
                                      <span className="font-mono text-xs bg-destructive/10 text-destructive px-1.5 py-0.5 rounded">{ns}</span>
                                      <Badge variant="destructive" className="text-xs">{keys.length}</Badge>
                                    </CollapsibleTrigger>
                                    <CollapsibleContent>
                                      <div className="ml-5 space-y-0.5 py-1">
                                        {keys.map((k) => (
                                          <div key={k} className="flex items-center gap-2 text-xs font-mono py-0.5">
                                            <span className="text-muted-foreground">{k}</span>
                                            <span className="text-foreground/70">= "{refFlat[k]}"</span>
                                          </div>
                                        ))}
                                      </div>
                                    </CollapsibleContent>
                                  </Collapsible>
                                ));
                              })()}
                            </div>
                          )}
                          {l.identical.length > 0 && (
                            <div className="space-y-2 pt-2 border-t">
                              <h4 className="text-sm font-semibold text-yellow-600">Azonos értékű kulcsok ({l.identical.length})</h4>
                              {(() => {
                                const { grouped } = getFilteredGrouped(l.identical);
                                return Object.entries(grouped).sort().map(([ns, keys]) => (
                                  <Collapsible key={ns} open={expandedNs.has(`${l.value}-ident-${ns}`)} onOpenChange={() => toggleNs(`${l.value}-ident-${ns}`)}>
                                    <CollapsibleTrigger className="flex items-center gap-2 w-full text-left text-sm font-medium hover:text-secondary py-1">
                                      {expandedNs.has(`${l.value}-ident-${ns}`) ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
                                      <span className="font-mono text-xs bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-400 px-1.5 py-0.5 rounded">{ns}</span>
                                      <Badge variant="secondary" className="text-xs">{keys.length}</Badge>
                                    </CollapsibleTrigger>
                                    <CollapsibleContent>
                                      <div className="ml-5 space-y-0.5 py-1">
                                        {keys.map((k) => (
                                          <div key={k} className="text-xs font-mono text-muted-foreground py-0.5">{k} = "{refFlat[k]}"</div>
                                        ))}
                                      </div>
                                    </CollapsibleContent>
                                  </Collapsible>
                                ));
                              })()}
                            </div>
                          )}
                          {l.extra.length > 0 && (
                            <div className="space-y-2 pt-2 border-t">
                              <h4 className="text-sm font-semibold text-blue-600">Extra kulcsok (nincs a referenciában) ({l.extra.length})</h4>
                              <div className="ml-2 space-y-0.5">
                                {l.extra.slice(0, 50).map((k) => (
                                  <div key={k} className="text-xs font-mono text-muted-foreground py-0.5">{k} = "{l.flat[k]}"</div>
                                ))}
                                {l.extra.length > 50 && <p className="text-xs text-muted-foreground">...és még {l.extra.length - 50} kulcs</p>}
                              </div>
                            </div>
                          )}
                          {l.missing.length === 0 && l.identical.length === 0 && l.extra.length === 0 && (
                            <div className="flex items-center gap-2 text-green-600 text-sm">
                              <CheckCircle className="h-4 w-4" /> Minden kulcs rendben!
                            </div>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  )}
                </>
              );
            })}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}

// --- Main Component ---
export default function AdminTranslate() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [sourceLang, setSourceLang] = useState("hu");
  const [targetLang, setTargetLang] = useState("en");
  const [isTranslating, setIsTranslating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [translatedKeys, setTranslatedKeys] = useState<Record<string, string>>({});
  const [errors, setErrors] = useState<string[]>([]);
  const [selectedNamespace, setSelectedNamespace] = useState("all");
  const [isSaving, setIsSaving] = useState(false);

  const sourceFlat = useMemo(() => {
    const lang = LANGS.find((l) => l.value === sourceLang);
    return lang ? flattenObj(lang.json) : {};
  }, [sourceLang]);

  const targetFlat = useMemo(() => {
    const lang = LANGS.find((l) => l.value === targetLang);
    return lang ? flattenObj(lang.json) : {};
  }, [targetLang]);

  const namespaces = useMemo(() => {
    const ns = new Set<string>();
    Object.keys(sourceFlat).forEach((k) => ns.add(k.split(".")[0]));
    return Array.from(ns).sort();
  }, [sourceFlat]);

  const missingKeys = useMemo(() => {
    const keys = selectedNamespace === "all"
      ? Object.keys(sourceFlat)
      : Object.keys(sourceFlat).filter((k) => k.startsWith(selectedNamespace + "."));
    return keys.filter((k) => !targetFlat[k] || targetFlat[k] === sourceFlat[k]);
  }, [sourceFlat, targetFlat, selectedNamespace]);

  const stats = useMemo(() => {
    const totalKeys = Object.keys(sourceFlat).length;
    const targetKeys = Object.keys(targetFlat).length;
    const matching = Object.keys(sourceFlat).filter((k) => targetFlat[k] && targetFlat[k] !== sourceFlat[k]).length;
    return { totalKeys, targetKeys, translated: matching, missing: totalKeys - matching };
  }, [sourceFlat, targetFlat]);

  const translateBatch = async () => {
    if (sourceLang === targetLang) {
      toast({ variant: "destructive", title: "Hiba", description: "A forrás és célnyelv nem lehet azonos!" });
      return;
    }

    setIsTranslating(true);
    setProgress(0);
    setTranslatedKeys({});
    setErrors([]);

    const keysToTranslate = missingKeys;
    const BATCH_SIZE = 30;
    const result: Record<string, string> = {};
    const errs: string[] = [];

    for (let i = 0; i < keysToTranslate.length; i += BATCH_SIZE) {
      const batch = keysToTranslate.slice(i, i + BATCH_SIZE);
      const batchObj: Record<string, string> = {};
      batch.forEach((k) => { batchObj[k] = sourceFlat[k]; });

      try {
        const { data, error } = await supabase.functions.invoke("ai-translate", {
          body: {
            text: JSON.stringify(batchObj, null, 2),
            target_language: targetLang,
            is_html: false,
          },
        });
        if (error) throw error;

        let parsed: Record<string, string> = {};
        try {
          let cleaned = data.translated || "";
          cleaned = cleaned.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
          parsed = JSON.parse(cleaned);
        } catch {
          errs.push(`Batch ${Math.floor(i / BATCH_SIZE) + 1}: JSON parse hiba`);
        }

        Object.assign(result, parsed);
      } catch (e: any) {
        errs.push(`Batch ${Math.floor(i / BATCH_SIZE) + 1}: ${e.message}`);
      }

      setProgress(Math.min(100, Math.round(((i + BATCH_SIZE) / keysToTranslate.length) * 100)));
      setTranslatedKeys({ ...result });

      if (i + BATCH_SIZE < keysToTranslate.length) {
        await new Promise((r) => setTimeout(r, 1500));
      }
    }

    setErrors(errs);
    setIsTranslating(false);
    setProgress(100);

    if (Object.keys(result).length > 0) {
      // Auto-save to DB and apply in real-time
      await saveAndApply(result);
    }
  };


  const saveAndApply = async (keys: Record<string, string>) => {
    setIsSaving(true);
    try {
      const nested = unflattenObj(keys);

      // Upsert: merge with existing overrides in DB
      const { data: existing } = await supabase
        .from("i18n_overrides")
        .select("translations")
        .eq("language", targetLang)
        .maybeSingle();

      const merged = { ...(existing?.translations as Record<string, unknown> || {}), ...nested };

      const { error } = await supabase
        .from("i18n_overrides")
        .upsert(
          { language: targetLang, translations: merged, updated_by: (await supabase.auth.getUser()).data.user?.id },
          { onConflict: "language" }
        );

      if (error) throw error;

      // Apply immediately to running i18n instance
      i18n.addResourceBundle(targetLang, "translation", merged, true, true);

      toast({ title: `${Object.keys(keys).length} kulcs mentve és azonnal alkalmazva!` });
    } catch (e: any) {
      toast({ variant: "destructive", title: "Mentési hiba", description: e.message });
    } finally {
      setIsSaving(false);
    }
  };

  const exportResult = () => {
    const targetLangObj = LANGS.find((l) => l.value === targetLang);
    const existing = targetLangObj ? flattenObj(targetLangObj.json) : {};
    const merged = { ...existing, ...translatedKeys };
    const nested = unflattenObj(merged);
    const json = JSON.stringify(nested, null, 2);

    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${targetLang}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Languages className="h-6 w-6 text-secondary" />
        <h1 className="text-2xl font-bold">AI Fordító</h1>
      </div>

      {/* Language Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {LANGS.map((lang) => {
          const flat = flattenObj(lang.json);
          const count = Object.keys(flat).length;
          const huFlat = flattenObj(huJson);
          const huCount = Object.keys(huFlat).length;
          const pct = Math.round((count / huCount) * 100);
          return (
            <Card key={lang.value}>
              <CardContent className="pt-4 text-center">
                <p className="text-lg font-bold">{lang.label}</p>
                <p className="text-2xl font-bold text-secondary">{count}</p>
                <p className="text-xs text-muted-foreground">{pct}% ({huCount} kulcsból)</p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Missing Keys Finder */}
      <MissingKeysFinder />

      {/* Translation Tool */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Languages className="h-5 w-5" />
            Tömeges AI fordítás
          </CardTitle>
          <CardDescription>
            Válassz forrás- és célnyelvet, majd fordíttasd le a hiányzó vagy azonos kulcsokat AI segítségével.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-1.5">
              <Label>Forrásnyelv</Label>
              <Select value={sourceLang} onValueChange={setSourceLang}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {LANGS.map((l) => <SelectItem key={l.value} value={l.value}>{l.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Célnyelv</Label>
              <Select value={targetLang} onValueChange={setTargetLang}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {LANGS.map((l) => <SelectItem key={l.value} value={l.value}>{l.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Névtér szűrő</Label>
              <Select value={selectedNamespace} onValueChange={setSelectedNamespace}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Összes</SelectItem>
                  {namespaces.map((ns) => <SelectItem key={ns} value={ns}>{ns}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex items-center gap-4 flex-wrap">
            <Badge variant="outline" className="text-sm">
              Összes kulcs: {stats.totalKeys}
            </Badge>
            <Badge variant="secondary" className="text-sm">
              Lefordított: {stats.translated}
            </Badge>
            <Badge variant="destructive" className="text-sm">
              Hiányzó/azonos: {missingKeys.length}
            </Badge>
          </div>

          {isTranslating && (
            <div className="space-y-2">
              <Progress value={progress} />
              <p className="text-sm text-muted-foreground text-center">{progress}% — Fordítás folyamatban...</p>
            </div>
          )}

          <div className="flex gap-2">
            <Button onClick={translateBatch} disabled={isTranslating || isSaving || missingKeys.length === 0}>
              {isTranslating ? (
                <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Fordítás és mentés...</>
              ) : (
                <><Languages className="h-4 w-4 mr-2" />Hiányzó kulcsok fordítása ({missingKeys.length})</>
              )}
            </Button>
            {Object.keys(translatedKeys).length > 0 && (
              <>
                <Button variant="secondary" onClick={() => saveAndApply(translatedKeys)} disabled={isSaving}>
                  {isSaving ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
                  Mentés és alkalmazás
                </Button>
                <Button variant="outline" onClick={exportResult}>
                  <Download className="h-4 w-4 mr-2" />
                  {targetLang}.json letöltése
                </Button>
              </>
            )}
          </div>

          {isSaving && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <RefreshCw className="h-4 w-4 animate-spin" />
              Mentés és valós idejű alkalmazás folyamatban...
            </div>
          )}

          {errors.length > 0 && (
            <div className="rounded-md border border-destructive/50 bg-destructive/5 p-3 space-y-1">
              <p className="text-sm font-medium flex items-center gap-1 text-destructive">
                <AlertCircle className="h-4 w-4" /> Hibák:
              </p>
              {errors.map((e, i) => <p key={i} className="text-xs text-muted-foreground">{e}</p>)}
            </div>
          )}

          {Object.keys(translatedKeys).length > 0 && (
            <div className="space-y-2">
              <Label className="flex items-center gap-1">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Lefordított kulcsok előnézete ({Object.keys(translatedKeys).length})
              </Label>
              <Textarea
                readOnly
                value={JSON.stringify(translatedKeys, null, 2)}
                rows={12}
                className="font-mono text-xs"
              />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Content Translation */}
      <ContentTranslationManager />

      {/* Bulk Translate All */}
      <TranslateAllMissing />
    </div>
  );
}

// --- Content Translation Manager ---
const CONTENT_TABLES = [
  { value: "activities", label: "Tevékenységek", fields: ["name", "short_description", "long_description", "page_content", "seo_title", "seo_description"] },
  { value: "services", label: "Szolgáltatások", fields: ["name", "description", "category"] },
  { value: "navigation_links", label: "Navigáció", fields: ["label"] },
  { value: "site_settings", label: "Oldal beállítások", fields: ["value"] },
  { value: "pages_content", label: "Oldal tartalmak", fields: ["content"] },
  { value: "locations", label: "Helyszínek", fields: ["name", "description"] },
  { value: "document_templates", label: "Dokumentum sablonok", fields: ["name"] },
  { value: "questionnaires", label: "Kérdőívek", fields: ["title", "description"] },
];

const TRANSLATABLE_SETTINGS_KEYS = [
  "site_name", "footer_text", "footer_nav_title", "footer_contact_title",
  "hero_title", "hero_subtitle", "hero_cta_text",
  "auth_login_title", "auth_login_subtitle", "auth_register_title", "auth_register_subtitle",
];

async function fetchTableRecords(tableName: string) {
  if (tableName === "site_settings") {
    const { data, error } = await supabase
      .from("site_settings")
      .select("id, key, value")
      .in("key", TRANSLATABLE_SETTINGS_KEYS);
    if (error) throw error;
    return (data ?? []).map((r) => ({ id: r.id, _label: r.key, _fields: { value: r.value ?? "" } }));
  }
  if (tableName === "navigation_links") {
    const { data, error } = await supabase.from("navigation_links").select("id, label").eq("is_active", true).order("sort_order");
    if (error) throw error;
    return (data ?? []).map((r) => ({ id: r.id, _label: r.label, _fields: { label: r.label } }));
  }
  if (tableName === "services") {
    const { data, error } = await supabase.from("services").select("id, name, description, category").eq("is_active", true).order("name");
    if (error) throw error;
    return (data ?? []).map((r) => ({ id: r.id, _label: r.name, _fields: { name: r.name, description: r.description ?? "", category: r.category ?? "" } }));
  }
  if (tableName === "pages_content") {
    const { data, error } = await supabase.from("pages_content").select("id, page_key, section, content, content_json").eq("is_active", true).order("sort_order");
    if (error) throw error;
    return (data ?? []).map((r) => {
      // For JSON content, stringify meaningful fields
      let contentStr = r.content ?? "";
      if (r.content_json && typeof r.content_json === "object") {
        contentStr = JSON.stringify(r.content_json);
      }
      return { id: r.id, _label: `${r.page_key} / ${r.section}`, _fields: { content: contentStr } };
    });
  }
  if (tableName === "locations") {
    const { data, error } = await supabase.from("locations").select("id, name, description").eq("is_active", true).order("name");
    if (error) throw error;
    return (data ?? []).map((r) => ({ id: r.id, _label: r.name, _fields: { name: r.name, description: r.description ?? "" } }));
  }
  // activities (default)
  if (tableName === "document_templates") {
    const { data, error } = await supabase.from("document_templates").select("id, name").eq("is_active", true).order("name");
    if (error) throw error;
    return (data ?? []).map((r) => ({ id: r.id, _label: r.name, _fields: { name: r.name } }));
  }
  if (tableName === "questionnaires") {
    const { data, error } = await supabase.from("questionnaires").select("id, title, description").eq("is_active", true).order("title");
    if (error) throw error;
    return (data ?? []).map((r) => ({ id: r.id, _label: r.title, _fields: { title: r.title, description: r.description ?? "" } }));
  }
  const { data, error } = await supabase.from("activities").select("id, name, short_description, long_description, page_content, seo_title, seo_description").eq("is_active", true).order("sort_order");
  if (error) throw error;
  return (data ?? []).map((r) => ({
    id: r.id,
    _label: r.name,
    _fields: {
      name: r.name,
      short_description: r.short_description ?? "",
      long_description: r.long_description ?? "",
      page_content: r.page_content ?? "",
      seo_title: r.seo_title ?? "",
      seo_description: r.seo_description ?? "",
    },
  }));
}

function ContentTranslationManager() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedTable, setSelectedTable] = useState("activities");
  const [targetLang, setTargetLang] = useState("en");
  const [isTranslating, setIsTranslating] = useState(false);
  const [progress, setProgress] = useState(0);

  const tableConfig = CONTENT_TABLES.find((t) => t.value === selectedTable)!;

  // Fetch records from selected table
  const { data: records, isLoading: recordsLoading } = useQuery({
    queryKey: ["content-translate-records", selectedTable],
    queryFn: async () => {
      return fetchTableRecords(selectedTable);
    },
  });

  // Fetch existing translations
  const { data: existingTranslations } = useQuery({
    queryKey: ["content-translations-admin", selectedTable, targetLang],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("content_translations")
        .select("record_id, field_name, value")
        .eq("table_name", selectedTable)
        .eq("language", targetLang);
      if (error) throw error;
      const map = new Map<string, string>();
      data?.forEach((r) => map.set(`${r.record_id}::${r.field_name}`, r.value));
      return map;
    },
  });

  // Count missing
  const missingCount = useMemo(() => {
    if (!records || !existingTranslations) return 0;
    let count = 0;
    records.forEach((rec) => {
      Object.entries(rec._fields).forEach(([field, val]) => {
        if (val && !existingTranslations.has(`${rec.id}::${field}`)) count++;
      });
    });
    return count;
  }, [records, existingTranslations]);

  const translateAll = async () => {
    if (!records) return;
    setIsTranslating(true);
    setProgress(0);

    // Collect all texts to translate
    const items: { recordId: string; field: string; text: string }[] = [];
    records.forEach((rec) => {
      Object.entries(rec._fields).forEach(([field, val]) => {
        if (val && !existingTranslations?.has(`${rec.id}::${field}`)) {
          items.push({ recordId: rec.id, field, text: val as string });
        }
      });
    });

    if (items.length === 0) {
      toast({ title: "Nincs fordítandó tartalom!" });
      setIsTranslating(false);
      return;
    }

    const BATCH_SIZE = 20;
    const errors: string[] = [];

    for (let i = 0; i < items.length; i += BATCH_SIZE) {
      const batch = items.slice(i, i + BATCH_SIZE);
      const batchObj: Record<string, string> = {};
      batch.forEach((item, idx) => { batchObj[`item_${idx}`] = item.text; });

      try {
        const langLabel = LANGS.find((l) => l.value === targetLang)?.label ?? targetLang;
        const { data, error } = await supabase.functions.invoke("ai-translate", {
          body: {
            text: JSON.stringify(batchObj, null, 2),
            target_language: langLabel,
            is_html: false,
          },
        });
        if (error) throw error;

        let parsed: Record<string, string> = {};
        try {
          let cleaned = data.translated || "";
          cleaned = cleaned.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
          parsed = JSON.parse(cleaned);
        } catch {
          errors.push(`Batch ${Math.floor(i / BATCH_SIZE) + 1}: JSON parse hiba`);
          continue;
        }

        // Save to DB
        const upsertRows = batch.map((item, idx) => ({
          table_name: selectedTable,
          record_id: item.recordId,
          field_name: item.field,
          language: targetLang,
          value: parsed[`item_${idx}`] || item.text,
        }));

        const { error: upsertError } = await supabase
          .from("content_translations")
          .upsert(upsertRows, { onConflict: "table_name,record_id,field_name,language" });

        if (upsertError) errors.push(`DB hiba: ${upsertError.message}`);
      } catch (e: any) {
        errors.push(`Batch ${Math.floor(i / BATCH_SIZE) + 1}: ${e.message}`);
      }

      setProgress(Math.min(100, Math.round(((i + BATCH_SIZE) / items.length) * 100)));
      if (i + BATCH_SIZE < items.length) await new Promise((r) => setTimeout(r, 1500));
    }

    queryClient.invalidateQueries({ queryKey: ["content-translations-admin", selectedTable, targetLang] });
    queryClient.invalidateQueries({ queryKey: ["content-translations"] });

    if (errors.length > 0) {
      toast({ variant: "destructive", title: "Részleges hiba", description: errors.join("; ") });
    } else {
      toast({ title: `${items.length} tartalom sikeresen lefordítva!` });
    }

    setIsTranslating(false);
    setProgress(100);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          <Database className="h-5 w-5" />
          Tartalom fordítás (adatbázis)
        </CardTitle>
        <CardDescription>
          Adatbázisban tárolt tartalmak (tevékenységek, szolgáltatások, menü, beállítások) AI fordítása.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <Label>Tábla</Label>
            <Select value={selectedTable} onValueChange={setSelectedTable}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {CONTENT_TABLES.map((t) => (
                  <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Célnyelv</Label>
            <Select value={targetLang} onValueChange={setTargetLang}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {LANGS.filter((l) => l.value !== "hu").map((l) => (
                  <SelectItem key={l.value} value={l.value}>{l.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="flex items-center gap-4 flex-wrap">
          <Badge variant="outline">Rekordok: {records?.length ?? 0}</Badge>
          <Badge variant="outline">Mezők: {tableConfig.fields.join(", ")}</Badge>
          <Badge variant={missingCount > 0 ? "destructive" : "default"}>
            Hiányzó: {missingCount}
          </Badge>
        </div>

        {/* Records preview */}
        {!recordsLoading && records && records.length > 0 && (
          <div className="max-h-[300px] overflow-y-auto border rounded-md">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Rekord</TableHead>
                  {tableConfig.fields.map((f) => (
                    <TableHead key={f} className="text-center">{f}</TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {records.map((rec) => (
                  <TableRow key={rec.id}>
                    <TableCell className="font-medium text-sm max-w-[200px] truncate">{rec._label}</TableCell>
                    {tableConfig.fields.map((f) => {
                      const hasTranslation = existingTranslations?.has(`${rec.id}::${f}`);
                      const hasOriginal = !!rec._fields[f];
                      return (
                        <TableCell key={f} className="text-center">
                          {!hasOriginal ? (
                            <span className="text-muted-foreground text-xs">—</span>
                          ) : hasTranslation ? (
                            <CheckCircle className="h-4 w-4 text-green-500 mx-auto" />
                          ) : (
                            <AlertCircle className="h-4 w-4 text-destructive mx-auto" />
                          )}
                        </TableCell>
                      );
                    })}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}

        {isTranslating && (
          <div className="space-y-2">
            <Progress value={progress} />
            <p className="text-sm text-muted-foreground text-center">{progress}% — Tartalom fordítás folyamatban...</p>
          </div>
        )}

        <Button onClick={translateAll} disabled={isTranslating || missingCount === 0}>
          {isTranslating ? (
            <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Fordítás...</>
          ) : (
            <><Globe className="h-4 w-4 mr-2" />Hiányzó tartalmak fordítása ({missingCount})</>
          )}
        </Button>
      </CardContent>
    </Card>
  );
}

// --- Translate All Missing for All Languages ---
const TARGET_LANGS = LANGS.filter((l) => l.value !== "hu");

function TranslateAllMissing() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isRunning, setIsRunning] = useState(false);
  const [currentStep, setCurrentStep] = useState("");
  const [progress, setProgress] = useState(0);
  const [log, setLog] = useState<string[]>([]);

  const addLog = (msg: string) => setLog((prev) => [...prev, msg]);

  const runAll = async () => {
    setIsRunning(true);
    setProgress(0);
    setLog([]);

    const totalSteps = CONTENT_TABLES.length * TARGET_LANGS.length;
    let completedSteps = 0;
    let totalTranslated = 0;

    // Part 1: Content translations (DB-based)
    for (const table of CONTENT_TABLES) {
      for (const lang of TARGET_LANGS) {
        setCurrentStep(`${table.label} → ${lang.label}`);
        try {
          // Fetch records
          const records = await fetchTableRecords(table.value);

          // Fetch existing translations
          const { data: existing } = await supabase
            .from("content_translations")
            .select("record_id, field_name")
            .eq("table_name", table.value)
            .eq("language", lang.value);

          const existingSet = new Set((existing ?? []).map((r) => `${r.record_id}::${r.field_name}`));

          // Collect missing
          const items: { recordId: string; field: string; text: string }[] = [];
          records.forEach((rec) => {
            Object.entries(rec._fields).forEach(([field, val]) => {
              if (val && !existingSet.has(`${rec.id}::${field}`)) {
                items.push({ recordId: rec.id, field, text: val as string });
              }
            });
          });

          if (items.length === 0) {
            addLog(`✓ ${table.label} → ${lang.label}: nincs hiányzó`);
          } else {
            // Translate in batches
            const BATCH_SIZE = 20;
            let batchErrors = 0;

            for (let i = 0; i < items.length; i += BATCH_SIZE) {
              const batch = items.slice(i, i + BATCH_SIZE);
              const batchObj: Record<string, string> = {};
              batch.forEach((item, idx) => { batchObj[`item_${idx}`] = item.text; });

              try {
                const { data, error } = await supabase.functions.invoke("ai-translate", {
                  body: {
                    text: JSON.stringify(batchObj, null, 2),
                    target_language: lang.value,
                    is_html: false,
                  },
                });
                if (error) throw error;

                let parsed: Record<string, string> = {};
                try {
                  let cleaned = data.translated || "";
                  cleaned = cleaned.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
                  parsed = JSON.parse(cleaned);
                } catch {
                  batchErrors++;
                  continue;
                }

                const upsertRows = batch.map((item, idx) => ({
                  table_name: table.value,
                  record_id: item.recordId,
                  field_name: item.field,
                  language: lang.value,
                  value: parsed[`item_${idx}`] || item.text,
                }));

                await supabase
                  .from("content_translations")
                  .upsert(upsertRows, { onConflict: "table_name,record_id,field_name,language" });

                totalTranslated += batch.length;
              } catch {
                batchErrors++;
              }

              if (i + BATCH_SIZE < items.length) await new Promise((r) => setTimeout(r, 1500));
            }

            addLog(`✓ ${table.label} → ${lang.label}: ${items.length - batchErrors} elem lefordítva`);
          }
        } catch (e: any) {
          addLog(`✗ ${table.label} → ${lang.label}: ${e.message}`);
        }

        completedSteps++;
        setProgress(Math.round((completedSteps / totalSteps) * 100));
      }
    }

    // Part 2: i18n keys (JSON-based) for all languages
    setCurrentStep("i18n kulcsok fordítása...");
    const huFlat = flattenObj(huJson);
    const huKeys = Object.keys(huFlat);

    for (const lang of TARGET_LANGS) {
      const langFlat = flattenObj(lang.json);

      // Load DB overrides
      const { data: overrideRow } = await supabase
        .from("i18n_overrides")
        .select("translations")
        .eq("language", lang.value)
        .maybeSingle();

      const overrideFlat = overrideRow?.translations
        ? flattenObj(overrideRow.translations as Record<string, unknown>)
        : {};

      const missing = huKeys.filter((k) => !langFlat[k] && !overrideFlat[k]);

      if (missing.length === 0) {
        addLog(`✓ i18n → ${lang.label}: nincs hiányzó kulcs`);
        continue;
      }

      setCurrentStep(`i18n → ${lang.label} (${missing.length} kulcs)`);
      const BATCH_SIZE = 30;
      const result: Record<string, string> = {};

      for (let i = 0; i < missing.length; i += BATCH_SIZE) {
        const batch = missing.slice(i, i + BATCH_SIZE);
        const batchObj: Record<string, string> = {};
        batch.forEach((k) => { batchObj[k] = huFlat[k]; });

        try {
          const { data, error } = await supabase.functions.invoke("ai-translate", {
            body: {
              text: JSON.stringify(batchObj, null, 2),
              target_language: lang.value,
              is_html: false,
            },
          });
          if (error) throw error;

          let parsed: Record<string, string> = {};
          try {
            let cleaned = data.translated || "";
            cleaned = cleaned.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
            parsed = JSON.parse(cleaned);
          } catch { /* skip */ }

          Object.assign(result, parsed);
        } catch { /* skip */ }

        if (i + BATCH_SIZE < missing.length) await new Promise((r) => setTimeout(r, 1500));
      }

      if (Object.keys(result).length > 0) {
        const nested = unflattenObj(result);
        const existing = overrideRow?.translations as Record<string, unknown> || {};
        const merged = { ...existing, ...nested };

        await supabase
          .from("i18n_overrides")
          .upsert(
            { language: lang.value, translations: merged, updated_by: (await supabase.auth.getUser()).data.user?.id },
            { onConflict: "language" }
          );

        i18n.addResourceBundle(lang.value, "translation", merged, true, true);
        totalTranslated += Object.keys(result).length;
      }

      addLog(`✓ i18n → ${lang.label}: ${Object.keys(result).length}/${missing.length} kulcs lefordítva`);
    }

    queryClient.invalidateQueries({ queryKey: ["content-translations"] });
    queryClient.invalidateQueries({ queryKey: ["content-translations-admin"] });

    setCurrentStep("");
    setProgress(100);
    setIsRunning(false);

    toast({ title: `Kész! Összesen ${totalTranslated} elem lefordítva minden nyelvre.` });
  };

  return (
    <Card className="border-secondary/30">
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          <Globe className="h-5 w-5 text-secondary" />
          Minden hiányzó elem fordítása minden nyelvre
        </CardTitle>
        <CardDescription>
          Egyetlen kattintással lefordítja az összes hiányzó i18n kulcsot és adatbázis tartalmat minden támogatott nyelvre.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <Button
          size="lg"
          onClick={runAll}
          disabled={isRunning}
          className="w-full"
        >
          {isRunning ? (
            <><Loader2 className="h-4 w-4 mr-2 animate-spin" />{currentStep}</>
          ) : (
            <><Globe className="h-4 w-4 mr-2" />Teljes fordítás indítása ({TARGET_LANGS.length} nyelv × {CONTENT_TABLES.length + 1} forrás)</>
          )}
        </Button>

        {isRunning && (
          <div className="space-y-2">
            <Progress value={progress} />
            <p className="text-sm text-muted-foreground text-center">{progress}%</p>
          </div>
        )}

        {log.length > 0 && (
          <div className="max-h-[300px] overflow-y-auto border rounded-md p-3 bg-muted/30 space-y-1">
            {log.map((line, i) => (
              <p key={i} className={`text-xs font-mono ${line.startsWith("✗") ? "text-destructive" : "text-muted-foreground"}`}>
                {line}
              </p>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
