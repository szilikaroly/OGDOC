import { useState, useMemo, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line, Legend, PieChart, Pie, Cell,
} from "recharts";
import {
  Search, Plus, Pencil, Trash2, Sparkles, Loader2, BarChart3, Globe, Eye,
  AlertTriangle, CheckCircle2, XCircle, TrendingUp, Bot, Languages, Zap,
  Share2, Copy, RefreshCw, Radio, FileText, Shield, ExternalLink, Link2,
  Activity, LinkIcon, Gauge, Unlink
} from "lucide-react";

interface SeoPage {
  id: string;
  page_path: string;
  title: string | null;
  description: string | null;
  og_title: string | null;
  og_description: string | null;
  og_image: string | null;
  keywords: string | null;
  canonical_url: string | null;
  noindex: boolean;
}

interface AuditResult {
  score: number;
  grade: string;
  issues: { severity: string; message: string }[];
  suggestions: string[];
}

interface KeywordResult {
  primary_keywords: { keyword: string; search_volume: string; competition: string; relevance: number }[];
  long_tail_keywords: string[];
  related_topics: string[];
  suggested_headings: string[];
}

const emptyForm = {
  page_path: "", title: "", description: "", og_title: "", og_description: "",
  og_image: "", keywords: "", canonical_url: "", noindex: false,
};

const KNOWN_ROUTES = [
  "/", "/login", "/register", "/reset-password",
  "/admin", "/uzemorvos", "/haziorvos", "/munkaltato", "/munkavallalo", "/praxistag",
];

const LANGUAGES = [
  { code: "en", label: "English", flag: "🇬🇧" },
  { code: "de", label: "Deutsch", flag: "🇩🇪" },
  { code: "ro", label: "Română", flag: "🇷🇴" },
  { code: "sr", label: "Srpski", flag: "🇷🇸" },
  { code: "zh", label: "中文", flag: "🇨🇳" },
  { code: "fil", label: "Filipino", flag: "🇵🇭" },
];

const VITALS_THRESHOLDS: Record<string, { good: number; poor: number; unit: string; label: string }> = {
  LCP: { good: 2500, poor: 4000, unit: "ms", label: "Largest Contentful Paint" },
  FID: { good: 100, poor: 300, unit: "ms", label: "First Input Delay" },
  CLS: { good: 0.1, poor: 0.25, unit: "", label: "Cumulative Layout Shift" },
  INP: { good: 200, poor: 500, unit: "ms", label: "Interaction to Next Paint" },
  TTFB: { good: 800, poor: 1800, unit: "ms", label: "Time to First Byte" },
};

const CHART_COLORS = ["hsl(var(--secondary))", "hsl(var(--primary))", "#f59e0b", "#10b981", "#8b5cf6"];

export default function AdminSEO() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [editing, setEditing] = useState<SeoPage | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [activeTab, setActiveTab] = useState("dashboard");
  const [auditResults, setAuditResults] = useState<Record<string, AuditResult>>({});
  const [auditRunning, setAuditRunning] = useState(false);
  const [keywordResult, setKeywordResult] = useState<KeywordResult | null>(null);
  const [keywordLoading, setKeywordLoading] = useState(false);
  const [keywordPath, setKeywordPath] = useState("");
  const [bulkLoading, setBulkLoading] = useState(false);
  const [chatbotPromo, setChatbotPromo] = useState<any>(null);
  const [chatbotLoading, setChatbotLoading] = useState(false);
  const [previewPage, setPreviewPage] = useState<SeoPage | null>(null);
  const [translateLoading, setTranslateLoading] = useState<string | null>(null);
  const [llmsTxt, setLlmsTxt] = useState("");
  const [llmsFullTxt, setLlmsFullTxt] = useState("");
  const [llmsGenerating, setLlmsGenerating] = useState(false);
  const [llmsSaving, setLlmsSaving] = useState(false);
  const [aiSimulation, setAiSimulation] = useState("");
  const [aiSimLoading, setAiSimLoading] = useState(false);
  // New states
  const [linkAnalysis, setLinkAnalysis] = useState<any>(null);
  const [linkAnalysisLoading, setLinkAnalysisLoading] = useState(false);
  const [brokenLinks, setBrokenLinks] = useState<any>(null);
  const [brokenLinksLoading, setBrokenLinksLoading] = useState(false);

  const { data: pages, isLoading } = useQuery({
    queryKey: ["admin-seo-pages"],
    queryFn: async () => {
      const { data, error } = await (supabase as any).from("seo_pages").select("*").order("page_path");
      if (error) throw error;
      return data as SeoPage[];
    },
  });

  const { data: activities } = useQuery({
    queryKey: ["seo-activities"],
    queryFn: async () => {
      const { data } = await supabase.from("activities").select("slug").eq("is_active", true);
      return data?.map(a => `/tevekenysegeink/${a.slug}`) ?? [];
    },
  });

  // Load existing llms.txt from site_settings
  useQuery({
    queryKey: ["llms-txt-settings"],
    queryFn: async () => {
      const { data } = await (supabase as any).from("site_settings").select("key, value").in("key", ["llms_txt", "llms_full_txt"]);
      if (data) {
        for (const row of data) {
          if (row.key === "llms_txt") setLlmsTxt(row.value || "");
          if (row.key === "llms_full_txt") setLlmsFullTxt(row.value || "");
        }
      }
      return data;
    },
  });

  // Page views data
  const { data: pageViewsData } = useQuery({
    queryKey: ["admin-page-views"],
    queryFn: async () => {
      const { data } = await (supabase as any)
        .from("page_views")
        .select("page_path, created_at")
        .order("created_at", { ascending: false })
        .limit(1000);
      return data ?? [];
    },
    enabled: activeTab === "performance",
  });

  // SEO audit scores history
  const { data: auditHistory } = useQuery({
    queryKey: ["admin-audit-history"],
    queryFn: async () => {
      const { data } = await (supabase as any)
        .from("seo_audit_scores")
        .select("*")
        .order("created_at", { ascending: true })
        .limit(100);
      return data ?? [];
    },
    enabled: activeTab === "performance",
  });

  // Web vitals data
  const { data: webVitalsData } = useQuery({
    queryKey: ["admin-web-vitals"],
    queryFn: async () => {
      const { data } = await (supabase as any)
        .from("web_vitals")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(500);
      return data ?? [];
    },
    enabled: activeTab === "webvitals",
  });

  const allRoutes = useMemo(() => {
    const routes = new Set(KNOWN_ROUTES);
    activities?.forEach(r => routes.add(r));
    return Array.from(routes).sort();
  }, [activities]);

  const coveredPaths = new Set(pages?.map(p => p.page_path) ?? []);
  const missingPaths = allRoutes.filter(r => !coveredPaths.has(r));
  const avgScore = useMemo(() => {
    const scores = Object.values(auditResults).map(a => a.score);
    return scores.length ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) : null;
  }, [auditResults]);

  // Computed chart data
  const pageViewsByDay = useMemo(() => {
    if (!pageViewsData?.length) return [];
    const days: Record<string, number> = {};
    for (const pv of pageViewsData) {
      const day = pv.created_at?.split("T")[0];
      if (day) days[day] = (days[day] || 0) + 1;
    }
    return Object.entries(days).sort().slice(-14).map(([day, count]) => ({ day: day.slice(5), count }));
  }, [pageViewsData]);

  const topPages = useMemo(() => {
    if (!pageViewsData?.length) return [];
    const counts: Record<string, number> = {};
    for (const pv of pageViewsData) counts[pv.page_path] = (counts[pv.page_path] || 0) + 1;
    return Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 10).map(([path, count]) => ({ path, count }));
  }, [pageViewsData]);

  const vitalsAverages = useMemo(() => {
    if (!webVitalsData?.length) return {};
    const groups: Record<string, number[]> = {};
    for (const v of webVitalsData) {
      if (!groups[v.metric_name]) groups[v.metric_name] = [];
      groups[v.metric_name].push(Number(v.value));
    }
    const result: Record<string, number> = {};
    for (const [name, vals] of Object.entries(groups)) {
      result[name] = vals.reduce((a, b) => a + b, 0) / vals.length;
    }
    return result;
  }, [webVitalsData]);

  const upsert = useMutation({
    mutationFn: async (values: typeof form & { id?: string }) => {
      const row = {
        page_path: values.page_path,
        title: values.title || null,
        description: values.description || null,
        og_title: values.og_title || null,
        og_description: values.og_description || null,
        og_image: values.og_image || null,
        keywords: values.keywords || null,
        canonical_url: values.canonical_url || null,
        noindex: values.noindex,
      };
      if (values.id) {
        const { error } = await (supabase as any).from("seo_pages").update(row).eq("id", values.id);
        if (error) throw error;
      } else {
        const { error } = await (supabase as any).from("seo_pages").insert(row);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-seo-pages"] });
      toast({ title: t("common.success") });
      setDialogOpen(false);
      setEditing(null);
      setForm(emptyForm);
    },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  const deleteMut = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await (supabase as any).from("seo_pages").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-seo-pages"] });
      toast({ title: t("common.success") });
    },
  });

  const generateAI = async () => {
    if (!form.page_path) return;
    setAiLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("ai-seo", {
        body: { action: "generate", page_path: form.page_path, current_title: form.title, current_description: form.description },
      });
      if (error) throw error;
      if (data) {
        setForm(f => ({ ...f, title: data.title || f.title, description: data.description || f.description, og_title: data.og_title || f.og_title, og_description: data.og_description || f.og_description, keywords: data.keywords || f.keywords }));
        toast({ title: t("admin.aiSuggestionsLoaded") });
      }
    } catch (e: any) { toast({ variant: "destructive", title: t("admin.aiError"), description: e.message }); }
    finally { setAiLoading(false); }
  };

  const runFullAudit = async () => {
    if (!pages?.length) return;
    setAuditRunning(true);
    const results: Record<string, AuditResult> = {};
    for (const p of pages) {
      try {
        const { data } = await supabase.functions.invoke("ai-seo", {
          body: { action: "audit", ...p },
        });
        if (data) {
          results[p.id] = data;
          // Save audit score
          await (supabase as any).from("seo_audit_scores").insert({
            page_path: p.page_path,
            score: data.score,
            grade: data.grade,
          });
        }
      } catch { /* skip */ }
    }
    setAuditResults(results);
    setAuditRunning(false);
    toast({ title: t("admin.auditDone", { count: Object.keys(results).length }) });
  };

  const runKeywordAnalysis = async () => {
    if (!keywordPath) return;
    setKeywordLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("ai-seo", {
        body: { action: "keywords", page_path: keywordPath },
      });
      if (error) throw error;
      setKeywordResult(data);
    } catch (e: any) { toast({ variant: "destructive", title: t("admin.aiError"), description: e.message }); }
    finally { setKeywordLoading(false); }
  };

  const bulkGenerate = async () => {
    if (!missingPaths.length) return;
    setBulkLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("ai-seo", {
        body: { action: "bulk_generate", pages: missingPaths },
      });
      if (error) throw error;
      if (data?.results) {
        for (const r of data.results) {
          await (supabase as any).from("seo_pages").insert({
            page_path: r.page_path, title: r.title, description: r.description,
            og_title: r.og_title, og_description: r.og_description, keywords: r.keywords, noindex: false,
          });
        }
        qc.invalidateQueries({ queryKey: ["admin-seo-pages"] });
        toast({ title: t("admin.pagesGenerated", { count: data.results.length }) });
      }
    } catch (e: any) { toast({ variant: "destructive", title: t("admin.aiError"), description: e.message }); }
    finally { setBulkLoading(false); }
  };

  const generateChatbotPromo = async () => {
    setChatbotLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("ai-seo", {
        body: { action: "chatbot_promo" },
      });
      if (error) throw error;
      setChatbotPromo(data);
      toast({ title: t("admin.chatbotPromoGenerated") });
    } catch (e: any) { toast({ variant: "destructive", title: t("admin.aiError"), description: e.message }); }
    finally { setChatbotLoading(false); }
  };

  const translateSeo = async (page: SeoPage, langCode: string) => {
    setTranslateLoading(`${page.id}-${langCode}`);
    try {
      const { data, error } = await supabase.functions.invoke("ai-seo", {
        body: {
          action: "translate_seo", target_language: langCode,
          title: page.title, description: page.description,
          og_title: page.og_title, og_description: page.og_description, keywords: page.keywords,
        },
      });
      if (error) throw error;
      const fields = ["title", "description", "og_title", "og_description", "keywords"];
      for (const field of fields) {
        if (data[field]) {
          await (supabase as any).from("content_translations").upsert({
            table_name: "seo_pages", record_id: page.id, field_name: field,
            language: langCode, value: data[field],
          }, { onConflict: "table_name,record_id,field_name,language" });
        }
      }
      toast({ title: t("admin.seoTranslationSaved", { lang: langCode }) });
    } catch (e: any) { toast({ variant: "destructive", title: t("common.error"), description: e.message }); }
    finally { setTranslateLoading(null); }
  };

  const generateLlmsTxt = async () => {
    setLlmsGenerating(true);
    try {
      const { data: services } = await supabase.from("services").select("name, short_description").eq("is_active", true);
      const { data: locations } = await supabase.from("locations").select("name, address, city, phone, email").eq("is_active", true);
      const { data, error } = await supabase.functions.invoke("ai-seo", {
        body: { action: "generate_llms_txt", services: services || [], locations: locations || [] },
      });
      if (error) throw error;
      if (data?.short) setLlmsTxt(data.short);
      if (data?.full) setLlmsFullTxt(data.full);
      toast({ title: "llms.txt generálva!" });
    } catch (e: any) { toast({ variant: "destructive", title: "Hiba", description: e.message }); }
    finally { setLlmsGenerating(false); }
  };

  const saveLlmsTxt = async () => {
    setLlmsSaving(true);
    try {
      for (const [key, value] of [["llms_txt", llmsTxt], ["llms_full_txt", llmsFullTxt]]) {
        await (supabase as any).from("site_settings").upsert({ key, value }, { onConflict: "key" });
      }
      toast({ title: "llms.txt mentve!" });
    } catch (e: any) { toast({ variant: "destructive", title: "Hiba", description: e.message }); }
    finally { setLlmsSaving(false); }
  };

  const simulateAiView = async () => {
    setAiSimLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("ai-seo", {
        body: { action: "simulate_ai_view", llms_txt: llmsTxt, site_url: "https://sos24.lovable.app" },
      });
      if (error) throw error;
      setAiSimulation(data?.simulation || "Nincs válasz");
    } catch (e: any) { toast({ variant: "destructive", title: "Hiba", description: e.message }); }
    finally { setAiSimLoading(false); }
  };

  const runLinkAnalysis = async () => {
    setLinkAnalysisLoading(true);
    try {
      const { data: navLinks } = await supabase.from("navigation_links").select("*").eq("is_active", true);
      const { data, error } = await supabase.functions.invoke("ai-seo", {
        body: {
          action: "analyze_links",
          navigation_links: navLinks || [],
          seo_pages: pages || [],
        },
      });
      if (error) throw error;
      setLinkAnalysis(data);
      toast({ title: "Link elemzés kész!" });
    } catch (e: any) { toast({ variant: "destructive", title: "Hiba", description: e.message }); }
    finally { setLinkAnalysisLoading(false); }
  };

  const runBrokenLinkCheck = async () => {
    setBrokenLinksLoading(true);
    try {
      const { data: navLinks } = await supabase.from("navigation_links").select("href").eq("is_active", true);
      const urls = (navLinks || [])
        .map((l: any) => l.href)
        .filter((h: string) => h.startsWith("http"))
        .slice(0, 50);
      const { data, error } = await supabase.functions.invoke("ai-seo", {
        body: { action: "check_links", urls },
      });
      if (error) throw error;
      setBrokenLinks(data);
      toast({ title: `${data?.checked || 0} link ellenőrizve` });
    } catch (e: any) { toast({ variant: "destructive", title: "Hiba", description: e.message }); }
    finally { setBrokenLinksLoading(false); }
  };

  const openEdit = (p: SeoPage) => {
    setEditing(p);
    setForm({
      page_path: p.page_path, title: p.title ?? "", description: p.description ?? "",
      og_title: p.og_title ?? "", og_description: p.og_description ?? "",
      og_image: p.og_image ?? "", keywords: p.keywords ?? "",
      canonical_url: p.canonical_url ?? "", noindex: p.noindex,
    });
    setDialogOpen(true);
  };

  const openNew = () => { setEditing(null); setForm(emptyForm); setDialogOpen(true); };

  const gradeColor = (grade: string) => {
    if (grade === "A") return "text-green-600";
    if (grade === "B") return "text-emerald-600";
    if (grade === "C") return "text-yellow-600";
    if (grade === "D") return "text-orange-600";
    return "text-red-600";
  };

  const vitalColor = (metric: string, value: number) => {
    const threshold = VITALS_THRESHOLDS[metric];
    if (!threshold) return "text-muted-foreground";
    if (value <= threshold.good) return "text-green-600";
    if (value <= threshold.poor) return "text-yellow-600";
    return "text-red-600";
  };

  const vitalBadge = (metric: string, value: number) => {
    const threshold = VITALS_THRESHOLDS[metric];
    if (!threshold) return "secondary";
    if (value <= threshold.good) return "default" as const;
    if (value <= threshold.poor) return "secondary" as const;
    return "destructive" as const;
  };

  if (isLoading) {
    return <div className="flex items-center justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Search className="h-6 w-6 text-secondary" />
          <h1 className="text-2xl font-bold">{t("admin.seoCenter")}</h1>
        </div>
        <Button onClick={openNew}><Plus className="h-4 w-4 mr-2" /> {t("admin.newPage")}</Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <ScrollArea className="w-full">
          <TabsList className="inline-flex w-auto min-w-full">
            <TabsTrigger value="dashboard" className="gap-1"><BarChart3 className="h-3.5 w-3.5" /> {t("admin.dashboard")}</TabsTrigger>
            <TabsTrigger value="pages" className="gap-1"><Globe className="h-3.5 w-3.5" /> {t("admin.pages")}</TabsTrigger>
            <TabsTrigger value="audit" className="gap-1"><CheckCircle2 className="h-3.5 w-3.5" /> {t("admin.audit")}</TabsTrigger>
            <TabsTrigger value="keywords" className="gap-1"><TrendingUp className="h-3.5 w-3.5" /> {t("admin.keywordsTab")}</TabsTrigger>
            <TabsTrigger value="chatbot" className="gap-1"><Bot className="h-3.5 w-3.5" /> {t("admin.aiPromo")}</TabsTrigger>
            <TabsTrigger value="social" className="gap-1"><Share2 className="h-3.5 w-3.5" /> {t("admin.preview")}</TabsTrigger>
            <TabsTrigger value="aiSearch" className="gap-1"><Radio className="h-3.5 w-3.5" /> AI Keresők</TabsTrigger>
            <TabsTrigger value="performance" className="gap-1"><Activity className="h-3.5 w-3.5" /> Teljesítmény</TabsTrigger>
            <TabsTrigger value="links" className="gap-1"><Link2 className="h-3.5 w-3.5" /> Link elemző</TabsTrigger>
            <TabsTrigger value="webvitals" className="gap-1"><Gauge className="h-3.5 w-3.5" /> Web Vitals</TabsTrigger>
            <TabsTrigger value="brokenlinks" className="gap-1"><Unlink className="h-3.5 w-3.5" /> Link ellenőrző</TabsTrigger>
          </TabsList>
          <ScrollBar orientation="horizontal" />
        </ScrollArea>

        {/* ========== DASHBOARD ========== */}
        <TabsContent value="dashboard" className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="pt-6 text-center">
                <div className="text-3xl font-bold text-secondary">{pages?.length ?? 0}</div>
                <p className="text-sm text-muted-foreground mt-1">{t("admin.configuredPages")}</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6 text-center">
                <div className="text-3xl font-bold">{allRoutes.length > 0 ? Math.round(((pages?.length ?? 0) / allRoutes.length) * 100) : 0}%</div>
                <p className="text-sm text-muted-foreground mt-1">{t("admin.coverage")}</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6 text-center">
                <div className={`text-3xl font-bold ${missingPaths.length > 0 ? "text-orange-600" : "text-green-600"}`}>{missingPaths.length}</div>
                <p className="text-sm text-muted-foreground mt-1">{t("admin.missingSeo")}</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6 text-center">
                <div className="text-3xl font-bold">{avgScore ?? "—"}</div>
                <p className="text-sm text-muted-foreground mt-1">{t("admin.avgAuditScore")}</p>
              </CardContent>
            </Card>
          </div>

          {missingPaths.length > 0 && (
            <Card className="border-orange-200 bg-orange-50 dark:bg-orange-950/20">
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-orange-600 mt-0.5" />
                  <div className="flex-1">
                    <p className="font-medium">{t("admin.missingSeoConfigs")}</p>
                    <p className="text-sm text-muted-foreground mt-1">{missingPaths.join(", ")}</p>
                    <Button size="sm" className="mt-3" onClick={bulkGenerate} disabled={bulkLoading}>
                      {bulkLoading ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <Zap className="h-4 w-4 mr-1" />}
                      {t("admin.aiBulkGenerate", { count: missingPaths.length })}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <CardTitle className="text-base">{t("admin.quickActions")}</CardTitle>
            </CardHeader>
            <CardContent className="flex flex-wrap gap-2">
              <Button variant="outline" onClick={() => setActiveTab("audit")} size="sm">
                <CheckCircle2 className="h-4 w-4 mr-1" /> {t("admin.startAudit")}
              </Button>
              <Button variant="outline" onClick={() => setActiveTab("keywords")} size="sm">
                <TrendingUp className="h-4 w-4 mr-1" /> {t("admin.keywordAnalysis")}
              </Button>
              <Button variant="outline" onClick={() => setActiveTab("chatbot")} size="sm">
                <Bot className="h-4 w-4 mr-1" /> {t("admin.chatbotPromo")}
              </Button>
              <Button variant="outline" onClick={() => setActiveTab("social")} size="sm">
                <Eye className="h-4 w-4 mr-1" /> {t("admin.socialPreview")}
              </Button>
              <Button variant="outline" onClick={() => setActiveTab("performance")} size="sm">
                <Activity className="h-4 w-4 mr-1" /> Teljesítmény
              </Button>
              <Button variant="outline" onClick={() => setActiveTab("webvitals")} size="sm">
                <Gauge className="h-4 w-4 mr-1" /> Web Vitals
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ========== PAGES ========== */}
        <TabsContent value="pages">
          <Card>
            <CardContent className="overflow-x-auto pt-6">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Útvonal</TableHead>
                    <TableHead>Title</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Audit</TableHead>
                    <TableHead>Noindex</TableHead>
                    <TableHead className="w-32">Műveletek</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {(pages ?? []).map(p => (
                    <TableRow key={p.id}>
                      <TableCell className="font-medium font-mono text-sm">{p.page_path}</TableCell>
                      <TableCell className="max-w-[180px] truncate text-sm">{p.title || "—"}</TableCell>
                      <TableCell className="max-w-[180px] truncate text-sm text-muted-foreground">{p.description || "—"}</TableCell>
                      <TableCell>
                        {auditResults[p.id] ? (
                          <Badge variant="outline" className={gradeColor(auditResults[p.id].grade)}>
                            {auditResults[p.id].grade} ({auditResults[p.id].score})
                          </Badge>
                        ) : "—"}
                      </TableCell>
                      <TableCell>{p.noindex ? <Badge variant="destructive">Noindex</Badge> : "—"}</TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button size="sm" variant="ghost" onClick={() => openEdit(p)}><Pencil className="h-4 w-4" /></Button>
                          <Button size="sm" variant="ghost" onClick={() => setPreviewPage(p)}><Eye className="h-4 w-4" /></Button>
                          <Button size="sm" variant="ghost" className="text-destructive" onClick={() => deleteMut.mutate(p.id)}><Trash2 className="h-4 w-4" /></Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ========== AUDIT ========== */}
        <TabsContent value="audit" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>SEO Audit</CardTitle>
                  <CardDescription>AI értékeli minden oldal SEO minőségét</CardDescription>
                </div>
                <Button onClick={runFullAudit} disabled={auditRunning}>
                  {auditRunning ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <RefreshCw className="h-4 w-4 mr-1" />}
                  Audit futtatása
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {Object.keys(auditResults).length === 0 ? (
                <p className="text-muted-foreground text-center py-8">Kattints az "Audit futtatása" gombra az elemzés indításához</p>
              ) : (
                <div className="space-y-4">
                  {pages?.map(p => {
                    const audit = auditResults[p.id];
                    if (!audit) return null;
                    return (
                      <Card key={p.id} className="p-4">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-sm font-medium">{p.page_path}</span>
                            <Badge variant="outline" className={gradeColor(audit.grade)}>
                              {audit.grade}
                            </Badge>
                          </div>
                          <span className="text-lg font-bold">{audit.score}/100</span>
                        </div>
                        <Progress value={audit.score} className="h-2 mb-3" />
                        {audit.issues.length > 0 && (
                          <div className="space-y-1 mb-2">
                            {audit.issues.map((issue, i) => (
                              <div key={i} className="flex items-start gap-2 text-sm">
                                {issue.severity === "critical" ? <XCircle className="h-4 w-4 text-red-500 mt-0.5 shrink-0" /> :
                                  issue.severity === "warning" ? <AlertTriangle className="h-4 w-4 text-yellow-500 mt-0.5 shrink-0" /> :
                                    <CheckCircle2 className="h-4 w-4 text-blue-500 mt-0.5 shrink-0" />}
                                <span>{issue.message}</span>
                              </div>
                            ))}
                          </div>
                        )}
                        {audit.suggestions.length > 0 && (
                          <div className="bg-muted/50 rounded p-2 mt-2">
                            <p className="text-xs font-medium mb-1">Javaslatok:</p>
                            <ul className="text-xs text-muted-foreground list-disc pl-4 space-y-0.5">
                              {audit.suggestions.map((s, i) => <li key={i}>{s}</li>)}
                            </ul>
                          </div>
                        )}
                      </Card>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ========== KEYWORDS ========== */}
        <TabsContent value="keywords" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Kulcsszó elemzés & javaslat</CardTitle>
              <CardDescription>AI-alapú kulcsszókutatás az oldal tartalma alapján</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <Input
                  placeholder="Oldal útvonala, pl. /"
                  value={keywordPath}
                  onChange={e => setKeywordPath(e.target.value)}
                />
                <Button onClick={runKeywordAnalysis} disabled={keywordLoading || !keywordPath}>
                  {keywordLoading ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <TrendingUp className="h-4 w-4 mr-1" />}
                  Elemzés
                </Button>
              </div>

              {keywordResult && (
                <div className="grid md:grid-cols-2 gap-4">
                  <Card className="p-4">
                    <h4 className="font-medium text-sm mb-2">Elsődleges kulcsszavak</h4>
                    <div className="space-y-2">
                      {keywordResult.primary_keywords?.map((kw, i) => (
                        <div key={i} className="flex items-center justify-between text-sm">
                          <span className="font-medium">{kw.keyword}</span>
                          <div className="flex gap-2">
                            <Badge variant={kw.search_volume === "high" ? "default" : "secondary"} className="text-xs">
                              {kw.search_volume === "high" ? "Magas" : kw.search_volume === "medium" ? "Közepes" : "Alacsony"}
                            </Badge>
                            <span className="text-muted-foreground">{kw.relevance}/10</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </Card>
                  <Card className="p-4">
                    <h4 className="font-medium text-sm mb-2">Long-tail kulcsszavak</h4>
                    <div className="flex flex-wrap gap-1">
                      {keywordResult.long_tail_keywords?.map((kw, i) => (
                        <Badge key={i} variant="outline" className="text-xs">{kw}</Badge>
                      ))}
                    </div>
                    <h4 className="font-medium text-sm mb-2 mt-4">Kapcsolódó témák</h4>
                    <div className="flex flex-wrap gap-1">
                      {keywordResult.related_topics?.map((rt, i) => (
                        <Badge key={i} variant="secondary" className="text-xs">{rt}</Badge>
                      ))}
                    </div>
                  </Card>
                  {keywordResult.suggested_headings?.length > 0 && (
                    <Card className="p-4 md:col-span-2">
                      <h4 className="font-medium text-sm mb-2">Javasolt címsorok (H2/H3)</h4>
                      <ul className="text-sm space-y-1 list-disc pl-4">
                        {keywordResult.suggested_headings.map((h, i) => <li key={i}>{h}</li>)}
                      </ul>
                    </Card>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ========== AI CHATBOT PROMO ========== */}
        <TabsContent value="chatbot" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2"><Bot className="h-5 w-5" /> AI Chatbot Promóció</CardTitle>
                  <CardDescription>Strukturált tartalom generálása ChatGPT, Gemini, Perplexity és más AI chatbotoknak</CardDescription>
                </div>
                <Button onClick={generateChatbotPromo} disabled={chatbotLoading}>
                  {chatbotLoading ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <Sparkles className="h-4 w-4 mr-1" />}
                  Generálás
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {!chatbotPromo ? (
                <p className="text-muted-foreground text-center py-8">Kattints a "Generálás" gombra az AI promo tartalom létrehozásához</p>
              ) : (
                <div className="space-y-4">
                  {chatbotPromo.ai_summary && (
                    <Card className="p-4 bg-muted/30">
                      <h4 className="font-medium text-sm mb-1">AI Összefoglaló (chatbotok számára)</h4>
                      <p className="text-sm">{chatbotPromo.ai_summary}</p>
                      <Button size="sm" variant="ghost" className="mt-2" onClick={() => { navigator.clipboard.writeText(chatbotPromo.ai_summary); toast({ title: "Másolva" }); }}>
                        <Copy className="h-3.5 w-3.5 mr-1" /> Másolás
                      </Button>
                    </Card>
                  )}
                  {chatbotPromo.competitive_advantages?.length > 0 && (
                    <Card className="p-4">
                      <h4 className="font-medium text-sm mb-2">Versenyelőnyök</h4>
                      <ul className="text-sm space-y-1">
                        {chatbotPromo.competitive_advantages.map((a: string, i: number) => (
                          <li key={i} className="flex items-start gap-2"><CheckCircle2 className="h-4 w-4 text-green-600 shrink-0 mt-0.5" />{a}</li>
                        ))}
                      </ul>
                    </Card>
                  )}
                  {chatbotPromo.key_facts?.length > 0 && (
                    <Card className="p-4">
                      <h4 className="font-medium text-sm mb-2">Kulcs tények</h4>
                      <div className="grid grid-cols-2 gap-2">
                        {chatbotPromo.key_facts.map((f: any, i: number) => (
                          <div key={i} className="text-sm"><span className="font-medium">{f.label}:</span> {f.value}</div>
                        ))}
                      </div>
                    </Card>
                  )}
                  {chatbotPromo.schema_org && (
                    <Card className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium text-sm">Schema.org JSON-LD</h4>
                        <Button size="sm" variant="ghost" onClick={() => { navigator.clipboard.writeText(JSON.stringify(chatbotPromo.schema_org, null, 2)); toast({ title: "Másolva" }); }}>
                          <Copy className="h-3.5 w-3.5 mr-1" /> Másolás
                        </Button>
                      </div>
                      <pre className="bg-muted rounded p-2 text-xs overflow-auto max-h-40">{JSON.stringify(chatbotPromo.schema_org, null, 2)}</pre>
                    </Card>
                  )}
                  {chatbotPromo.faq_schema?.length > 0 && (
                    <Card className="p-4">
                      <h4 className="font-medium text-sm mb-2">FAQ Structured Data</h4>
                      <div className="space-y-2">
                        {chatbotPromo.faq_schema.map((faq: any, i: number) => (
                          <div key={i} className="text-sm">
                            <p className="font-medium">K: {faq.question || faq.name}</p>
                            <p className="text-muted-foreground">V: {faq.answer || faq.acceptedAnswer?.text}</p>
                          </div>
                        ))}
                      </div>
                    </Card>
                  )}
                  {chatbotPromo.meta_prompt_suggestion && (
                    <Card className="p-4 border-secondary/30 bg-secondary/5">
                      <h4 className="font-medium text-sm mb-1">Javasolt AI prompt (felhasználók számára)</h4>
                      <p className="text-sm italic">"{chatbotPromo.meta_prompt_suggestion}"</p>
                      <Button size="sm" variant="ghost" className="mt-2" onClick={() => { navigator.clipboard.writeText(chatbotPromo.meta_prompt_suggestion); toast({ title: "Másolva" }); }}>
                        <Copy className="h-3.5 w-3.5 mr-1" /> Másolás
                      </Button>
                    </Card>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ========== SOCIAL / GOOGLE PREVIEW ========== */}
        <TabsContent value="social" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Google & Social Media Előnézet</CardTitle>
              <CardDescription>Válassz egy oldalt az előnézetek megtekintéséhez</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2 mb-6">
                {pages?.map(p => (
                  <Button key={p.id} variant={previewPage?.id === p.id ? "default" : "outline"} size="sm"
                    onClick={() => setPreviewPage(p)}>
                    {p.page_path}
                  </Button>
                ))}
              </div>

              {previewPage && (
                <div className="space-y-6">
                  <div>
                    <h4 className="font-medium text-sm mb-2 flex items-center gap-2"><Search className="h-4 w-4" /> Google keresési találat</h4>
                    <div className="border rounded-lg p-4 bg-background max-w-xl">
                      <p className="text-xs text-green-700 dark:text-green-400 mb-0.5">sos24.lovable.app{previewPage.page_path}</p>
                      <p className="text-blue-700 dark:text-blue-400 text-lg hover:underline cursor-pointer leading-tight">
                        {previewPage.title || "Nincs title megadva"}
                      </p>
                      <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                        {previewPage.description || "Nincs description megadva"}
                      </p>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium text-sm mb-2 flex items-center gap-2"><Share2 className="h-4 w-4" /> Facebook / LinkedIn</h4>
                    <div className="border rounded-lg overflow-hidden max-w-md">
                      {previewPage.og_image && (
                        <div className="bg-muted h-52 flex items-center justify-center">
                          <img src={previewPage.og_image} alt="OG" className="max-h-full object-cover w-full" />
                        </div>
                      )}
                      <div className="p-3 bg-muted/30">
                        <p className="text-xs text-muted-foreground uppercase">sos24.lovable.app</p>
                        <p className="font-medium text-sm">{previewPage.og_title || previewPage.title || "Nincs OG title"}</p>
                        <p className="text-xs text-muted-foreground line-clamp-2">{previewPage.og_description || previewPage.description || ""}</p>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium text-sm mb-2">📸 Instagram / 🎵 TikTok</h4>
                    <div className="border rounded-lg p-4 bg-muted/20 max-w-md">
                      <p className="text-sm text-muted-foreground">Az Instagram és TikTok bio linkek a fő OG meta adatokat használják.</p>
                      <ul className="text-sm mt-2 space-y-1 list-disc pl-4">
                        <li className={previewPage.og_image ? "text-green-600" : "text-red-600"}>
                          OG kép: {previewPage.og_image ? "✓ Beállítva" : "✗ Hiányzik"}
                        </li>
                        <li className={previewPage.og_title ? "text-green-600" : "text-red-600"}>
                          OG cím: {previewPage.og_title ? "✓ Beállítva" : "✗ Hiányzik"}
                        </li>
                        <li className={previewPage.og_description ? "text-green-600" : "text-red-600"}>
                          OG leírás: {previewPage.og_description ? "✓ Beállítva" : "✗ Hiányzik"}
                        </li>
                      </ul>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium text-sm mb-2 flex items-center gap-2"><Languages className="h-4 w-4" /> Többnyelvű SEO fordítás</h4>
                    <div className="flex flex-wrap gap-2">
                      {LANGUAGES.map(lang => (
                        <Button key={lang.code} variant="outline" size="sm"
                          disabled={translateLoading === `${previewPage.id}-${lang.code}`}
                          onClick={() => translateSeo(previewPage, lang.code)}>
                          {translateLoading === `${previewPage.id}-${lang.code}` ?
                            <Loader2 className="h-3.5 w-3.5 animate-spin mr-1" /> : <span className="mr-1">{lang.flag}</span>}
                          {lang.label}
                        </Button>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ========== AI KERESŐK ========== */}
        <TabsContent value="aiSearch" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Shield className="h-5 w-5" /> AI Keresők Státusz</CardTitle>
              <CardDescription>Aktív AI protokollok és fájlok</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div className="flex items-center gap-2 p-3 rounded-lg border">
                  <CheckCircle2 className="h-4 w-4 text-green-600" />
                  <div>
                    <p className="text-sm font-medium">robots.txt</p>
                    <p className="text-xs text-muted-foreground">AI crawlerek engedélyezve</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 p-3 rounded-lg border">
                  <CheckCircle2 className="h-4 w-4 text-green-600" />
                  <div>
                    <p className="text-sm font-medium">ai-plugin.json</p>
                    <p className="text-xs text-muted-foreground">Manifest aktív</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 p-3 rounded-lg border">
                  {llmsTxt ? <CheckCircle2 className="h-4 w-4 text-green-600" /> : <XCircle className="h-4 w-4 text-red-500" />}
                  <div>
                    <p className="text-sm font-medium">llms.txt</p>
                    <p className="text-xs text-muted-foreground">{llmsTxt ? "Konfigurálva" : "Nincs beállítva"}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 p-3 rounded-lg border">
                  <CheckCircle2 className="h-4 w-4 text-green-600" />
                  <div>
                    <p className="text-sm font-medium">Schema.org</p>
                    <p className="text-xs text-muted-foreground">JSON-LD aktív</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2"><FileText className="h-5 w-5" /> llms.txt szerkesztő</CardTitle>
                  <CardDescription>Rövid összefoglaló az AI rendszereknek</CardDescription>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" onClick={generateLlmsTxt} disabled={llmsGenerating}>
                    {llmsGenerating ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <Sparkles className="h-4 w-4 mr-1" />}
                    AI generálás
                  </Button>
                  <Button onClick={saveLlmsTxt} disabled={llmsSaving}>
                    {llmsSaving ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : null}
                    Mentés
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Textarea value={llmsTxt} onChange={e => setLlmsTxt(e.target.value)} rows={10} placeholder="# S.O.S. 24 KFT..." className="font-mono text-sm" />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><FileText className="h-5 w-5" /> llms-full.txt szerkesztő</CardTitle>
              <CardDescription>Részletes verzió</CardDescription>
            </CardHeader>
            <CardContent>
              <Textarea value={llmsFullTxt} onChange={e => setLlmsFullTxt(e.target.value)} rows={15} placeholder="# S.O.S. 24 KFT — Részletes leírás..." className="font-mono text-sm" />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2"><Bot className="h-5 w-5" /> Hogyan lát minket egy AI?</CardTitle>
                  <CardDescription>Szimuláció: mit válaszolna egy chatbot</CardDescription>
                </div>
                <Button variant="outline" onClick={simulateAiView} disabled={aiSimLoading}>
                  {aiSimLoading ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <Eye className="h-4 w-4 mr-1" />}
                  Szimuláció indítása
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {aiSimulation ? (
                <div className="bg-muted/30 rounded-lg p-4 space-y-2">
                  <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground mb-2">
                    <Bot className="h-4 w-4" /> AI chatbot válasza:
                  </div>
                  <div className="text-sm whitespace-pre-wrap">{aiSimulation}</div>
                  <Button size="sm" variant="ghost" className="mt-2" onClick={() => { navigator.clipboard.writeText(aiSimulation); toast({ title: "Másolva" }); }}>
                    <Copy className="h-3.5 w-3.5 mr-1" /> Másolás
                  </Button>
                </div>
              ) : (
                <p className="text-muted-foreground text-center py-8">Kattints a "Szimuláció indítása" gombra</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ========== PERFORMANCE ========== */}
        <TabsContent value="performance" className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Oldalmegtekintések (utolsó 14 nap)</CardTitle>
              </CardHeader>
              <CardContent>
                {pageViewsByDay.length > 0 ? (
                  <ResponsiveContainer width="100%" height={250}>
                    <BarChart data={pageViewsByDay}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="day" fontSize={12} />
                      <YAxis fontSize={12} />
                      <Tooltip />
                      <Bar dataKey="count" fill="hsl(var(--secondary))" name="Megtekintések" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <p className="text-muted-foreground text-center py-8">Még nincs elegendő adat</p>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Top oldalak</CardTitle>
              </CardHeader>
              <CardContent>
                {topPages.length > 0 ? (
                  <div className="space-y-2">
                    {topPages.map((p, i) => (
                      <div key={i} className="flex items-center justify-between text-sm">
                        <span className="font-mono truncate max-w-[200px]">{p.path}</span>
                        <div className="flex items-center gap-2">
                          <Progress value={Math.min((p.count / (topPages[0]?.count || 1)) * 100, 100)} className="h-2 w-20" />
                          <span className="font-medium w-10 text-right">{p.count}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-muted-foreground text-center py-8">Még nincs elegendő adat</p>
                )}
              </CardContent>
            </Card>
          </div>

          {auditHistory && auditHistory.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Audit pontszám trend</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <LineChart data={auditHistory.map((a: any) => ({ date: a.created_at?.split("T")[0]?.slice(5), score: a.score, path: a.page_path }))}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" fontSize={12} />
                    <YAxis domain={[0, 100]} fontSize={12} />
                    <Tooltip />
                    <Line type="monotone" dataKey="score" stroke="hsl(var(--secondary))" strokeWidth={2} dot={{ r: 3 }} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* ========== LINK ANALYZER ========== */}
        <TabsContent value="links" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2"><Link2 className="h-5 w-5" /> Belső link elemző</CardTitle>
                  <CardDescription>AI elemzi a linkstruktúrát és javaslatokat ad</CardDescription>
                </div>
                <Button onClick={runLinkAnalysis} disabled={linkAnalysisLoading}>
                  {linkAnalysisLoading ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <RefreshCw className="h-4 w-4 mr-1" />}
                  Elemzés indítása
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {!linkAnalysis ? (
                <p className="text-muted-foreground text-center py-8">Kattints az "Elemzés indítása" gombra</p>
              ) : (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <Card className="p-4 text-center">
                      <div className="text-2xl font-bold text-secondary">{linkAnalysis.link_count ?? 0}</div>
                      <p className="text-sm text-muted-foreground">Összes link</p>
                    </Card>
                    <Card className="p-4 text-center">
                      <div className="text-2xl font-bold">{linkAnalysis.avg_depth?.toFixed(1) ?? "—"}</div>
                      <p className="text-sm text-muted-foreground">Átlagos mélység</p>
                    </Card>
                  </div>

                  {linkAnalysis.orphan_pages?.length > 0 && (
                    <Card className="p-4 border-orange-200">
                      <h4 className="font-medium text-sm mb-2 flex items-center gap-2">
                        <AlertTriangle className="h-4 w-4 text-orange-500" /> Árva oldalak
                      </h4>
                      <div className="space-y-1">
                        {linkAnalysis.orphan_pages.map((op: any, i: number) => (
                          <div key={i} className="text-sm flex items-center justify-between">
                            <span className="font-mono">{op.path}</span>
                            <span className="text-muted-foreground text-xs">{op.reason}</span>
                          </div>
                        ))}
                      </div>
                    </Card>
                  )}

                  {linkAnalysis.deep_pages?.length > 0 && (
                    <Card className="p-4">
                      <h4 className="font-medium text-sm mb-2">Túl mély oldalak</h4>
                      <div className="space-y-1">
                        {linkAnalysis.deep_pages.map((dp: any, i: number) => (
                          <div key={i} className="text-sm flex items-center justify-between">
                            <span className="font-mono">{dp.path}</span>
                            <Badge variant="secondary">{dp.depth} kattintás</Badge>
                          </div>
                        ))}
                      </div>
                    </Card>
                  )}

                  {linkAnalysis.recommendations?.length > 0 && (
                    <Card className="p-4 bg-muted/30">
                      <h4 className="font-medium text-sm mb-2">Javaslatok</h4>
                      <ul className="text-sm space-y-1 list-disc pl-4">
                        {linkAnalysis.recommendations.map((r: string, i: number) => <li key={i}>{r}</li>)}
                      </ul>
                    </Card>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ========== WEB VITALS ========== */}
        <TabsContent value="webvitals" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Gauge className="h-5 w-5" /> Core Web Vitals</CardTitle>
              <CardDescription>A böngészők automatikusan mérik és rögzítik a teljesítményt</CardDescription>
            </CardHeader>
            <CardContent>
              {Object.keys(vitalsAverages).length > 0 ? (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {Object.entries(VITALS_THRESHOLDS).map(([metric, threshold]) => {
                    const value = vitalsAverages[metric];
                    if (value === undefined) return null;
                    return (
                      <Card key={metric} className="p-4">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm font-medium">{metric}</span>
                          <Badge variant={vitalBadge(metric, value)}>
                            {value <= threshold.good ? "Jó" : value <= threshold.poor ? "Javítandó" : "Gyenge"}
                          </Badge>
                        </div>
                        <div className={`text-2xl font-bold ${vitalColor(metric, value)}`}>
                          {metric === "CLS" ? value.toFixed(3) : Math.round(value)}{threshold.unit}
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">{threshold.label}</p>
                        <div className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
                          <span className="text-green-600">Jó: ≤{threshold.good}{threshold.unit}</span>
                          <span className="text-red-600">Gyenge: &gt;{threshold.poor}{threshold.unit}</span>
                        </div>
                      </Card>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Gauge className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
                  <p className="text-muted-foreground">Még nincs Web Vitals adat.</p>
                  <p className="text-sm text-muted-foreground mt-1">A mérések automatikusan indulnak a látogatók böngészőjéből.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ========== BROKEN LINKS ========== */}
        <TabsContent value="brokenlinks" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2"><Unlink className="h-5 w-5" /> Törött link ellenőrző</CardTitle>
                  <CardDescription>Külső linkek HTTP státusz ellenőrzése (max 50 URL)</CardDescription>
                </div>
                <Button onClick={runBrokenLinkCheck} disabled={brokenLinksLoading}>
                  {brokenLinksLoading ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <RefreshCw className="h-4 w-4 mr-1" />}
                  Ellenőrzés
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {!brokenLinks ? (
                <p className="text-muted-foreground text-center py-8">Kattints az "Ellenőrzés" gombra a linkek vizsgálatához</p>
              ) : (
                <div className="space-y-3">
                  <div className="flex gap-4 text-sm">
                    <span>Ellenőrizve: <strong>{brokenLinks.checked}</strong></span>
                    <span className={brokenLinks.broken > 0 ? "text-red-600" : "text-green-600"}>
                      Törött: <strong>{brokenLinks.broken}</strong>
                    </span>
                  </div>
                  <div className="space-y-2">
                    {brokenLinks.results?.map((r: any, i: number) => (
                      <div key={i} className={`flex items-center justify-between text-sm p-2 rounded border ${r.ok ? "border-green-200 bg-green-50 dark:bg-green-950/20" : "border-red-200 bg-red-50 dark:bg-red-950/20"}`}>
                        <span className="font-mono truncate max-w-[400px]">{r.url}</span>
                        <div className="flex items-center gap-2">
                          {r.ok ? (
                            <Badge variant="outline" className="text-green-600">{r.status}</Badge>
                          ) : (
                            <Badge variant="destructive">{r.status || r.error || "Hiba"}</Badge>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* ========== EDIT DIALOG ========== */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing ? "SEO szerkesztése" : "Új SEO oldal"}</DialogTitle>
            <DialogDescription>Meta adatok szerkesztése és AI javaslatok</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="flex gap-2 items-end">
              <div className="flex-1 space-y-1.5">
                <Label>Útvonal</Label>
                <Input value={form.page_path} onChange={e => setForm(f => ({ ...f, page_path: e.target.value }))} placeholder="/" />
              </div>
              <Button variant="outline" onClick={generateAI} disabled={aiLoading || !form.page_path}>
                {aiLoading ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <Sparkles className="h-4 w-4 mr-1" />}
                AI javaslat
              </Button>
            </div>
            <div className="space-y-1.5">
              <Label>Meta Title</Label>
              <Input value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} />
              <p className="text-xs text-muted-foreground">
                {form.title.length}/60 karakter
                {form.title.length > 60 && <span className="text-red-500 ml-1">— Túl hosszú!</span>}
              </p>
            </div>
            <div className="space-y-1.5">
              <Label>Meta Description</Label>
              <Textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} rows={2} />
              <p className="text-xs text-muted-foreground">
                {form.description.length}/160 karakter
                {form.description.length > 160 && <span className="text-red-500 ml-1">— Túl hosszú!</span>}
              </p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>OG Title</Label>
                <Input value={form.og_title} onChange={e => setForm(f => ({ ...f, og_title: e.target.value }))} />
              </div>
              <div className="space-y-1.5">
                <Label>OG Image URL</Label>
                <Input value={form.og_image} onChange={e => setForm(f => ({ ...f, og_image: e.target.value }))} />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>OG Description</Label>
              <Textarea value={form.og_description} onChange={e => setForm(f => ({ ...f, og_description: e.target.value }))} rows={2} />
            </div>
            <div className="space-y-1.5">
              <Label>Kulcsszavak</Label>
              <Input value={form.keywords} onChange={e => setForm(f => ({ ...f, keywords: e.target.value }))} placeholder="kulcsszó1, kulcsszó2, ..." />
            </div>
            <div className="space-y-1.5">
              <Label>Canonical URL</Label>
              <Input value={form.canonical_url} onChange={e => setForm(f => ({ ...f, canonical_url: e.target.value }))} />
            </div>
            <div className="flex items-center gap-2">
              <Switch checked={form.noindex} onCheckedChange={v => setForm(f => ({ ...f, noindex: v }))} />
              <Label>Noindex (keresőrobotok kizárása)</Label>
            </div>
            <Button className="w-full" onClick={() => upsert.mutate({ ...form, id: editing?.id })} disabled={upsert.isPending || !form.page_path}>
              {editing ? t("common.save") : t("common.create")}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
