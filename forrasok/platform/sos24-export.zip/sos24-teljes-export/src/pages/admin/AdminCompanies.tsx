import { useState, useMemo } from "react";
import WorkAreaManager from "@/components/WorkAreaManager";
import { supabase } from "@/integrations/supabase/client";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Building2, Plus, Pencil, UserPlus, Send, Search } from "lucide-react";

const CATEGORY_OPTIONS = ["A", "B", "C", "D"] as const;
const PRICING_TYPE_KEYS: { value: string; key: string }[] = [
  { value: "fix", key: "admin.fixPrice" },
  { value: "per_capita", key: "admin.perCapita" },
  { value: "monthly", key: "admin.monthly" },
];
const PRICING_LABEL_KEYS: Record<string, string> = { fix: "admin.fixPrice", per_capita: "admin.perCapita", monthly: "admin.monthly" };

interface Company {
  id: string;
  name: string;
  tax_number: string | null;
  address: string | null;
  contact_email: string | null;
  contact_phone: string | null;
  industry: string | null;
  contract_category: string | null;
  pricing_type: string | null;
  contract_price: number | null;
  created_at: string;
}

const emptyCompanyForm = {
  name: "", tax_number: "", address: "", contact_email: "", contact_phone: "", industry: "",
  contract_category: "", pricing_type: "", contract_price: "",
};

const emptyInviteForm = {
  email: "", full_name: "", company_id: "", company_name: "", tax_number: "", address: "", contact_phone: "",
};

export default function AdminCompanies() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [searchQuery, setSearchQuery] = useState("");
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [inviteDialogOpen, setInviteDialogOpen] = useState(false);
  const [editing, setEditing] = useState<Company | null>(null);
  const [companyForm, setCompanyForm] = useState(emptyCompanyForm);
  const [inviteForm, setInviteForm] = useState(emptyInviteForm);
  const [inviteMode, setInviteMode] = useState<"existing" | "new">("new");

  const { data: companies, isLoading } = useQuery({
    queryKey: ["admin-companies"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("companies")
        .select("id, name, tax_number, address, contact_email, contact_phone, industry, contract_category, pricing_type, contract_price, created_at")
        .order("name");
      if (error) throw error;
      return data as Company[];
    },
  });

  const filteredCompanies = useMemo(() => {
    const list = companies ?? [];
    if (!searchQuery.trim()) return list;
    const q = searchQuery.toLowerCase();
    return list.filter((c) =>
      c.name?.toLowerCase().includes(q) ||
      c.tax_number?.toLowerCase().includes(q) ||
      c.address?.toLowerCase().includes(q) ||
      c.contact_email?.toLowerCase().includes(q) ||
      c.industry?.toLowerCase().includes(q)
    );
  }, [companies, searchQuery]);

  const { data: companyRelations } = useQuery({
    queryKey: ["admin-company-relations"],
    queryFn: async () => {
      const { data, error } = await supabase.from("user_company_relations").select("id, user_id, company_id, role, is_active, position");
      if (error) throw error;
      return data ?? [];
    },
  });

  const { data: profiles } = useQuery({
    queryKey: ["admin-profiles-for-companies"],
    queryFn: async () => {
      const { data } = await supabase.from("profiles").select("user_id, full_name").order("full_name");
      return data ?? [];
    },
  });

  const upsertCompany = useMutation({
    mutationFn: async (values: typeof companyForm & { id?: string }) => {
      const row = {
        name: values.name,
        tax_number: values.tax_number || null,
        address: values.address || null,
        contact_email: values.contact_email || null,
        contact_phone: values.contact_phone || null,
        industry: values.industry || null,
        contract_category: values.contract_category || null,
        pricing_type: values.pricing_type || null,
        contract_price: values.contract_price ? parseFloat(values.contract_price) : null,
      };
      if (values.id) {
        const { error } = await supabase.from("companies").update(row).eq("id", values.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("companies").insert(row);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-companies"] });
      toast({ title: editing ? t("admin.companyUpdated") : t("admin.companyCreated") });
      setEditDialogOpen(false);
      setEditing(null);
      setCompanyForm(emptyCompanyForm);
    },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  const inviteEmployer = useMutation({
    mutationFn: async (values: typeof inviteForm) => {
      const { data, error } = await supabase.functions.invoke("invite-employer", {
        body: {
          email: values.email, full_name: values.full_name,
          company_name: inviteMode === "new" ? values.company_name : undefined,
          company_id: inviteMode === "existing" ? values.company_id : undefined,
          tax_number: inviteMode === "new" ? values.tax_number : undefined,
          address: inviteMode === "new" ? values.address : undefined,
          contact_phone: inviteMode === "new" ? values.contact_phone : undefined,
        },
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      return data;
    },
    onSuccess: (data) => {
      qc.invalidateQueries({ queryKey: ["admin-companies"] });
      qc.invalidateQueries({ queryKey: ["admin-company-relations"] });
      qc.invalidateQueries({ queryKey: ["admin-profiles-for-companies"] });
      toast({ title: t("admin.inviteSent"), description: data?.message });
      setInviteDialogOpen(false);
      setInviteForm(emptyInviteForm);
    },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  const openEdit = (c: Company) => {
    setEditing(c);
    setCompanyForm({
      name: c.name, tax_number: c.tax_number ?? "", address: c.address ?? "",
      contact_email: c.contact_email ?? "", contact_phone: c.contact_phone ?? "",
      industry: c.industry ?? "",
      contract_category: c.contract_category ?? "", pricing_type: c.pricing_type ?? "",
      contract_price: c.contract_price != null ? String(c.contract_price) : "",
    });
    setEditDialogOpen(true);
  };

  const openNewCompany = () => { setEditing(null); setCompanyForm(emptyCompanyForm); setEditDialogOpen(true); };
  const getProfileName = (userId: string) => profiles?.find(p => p.user_id === userId)?.full_name ?? "—";
  const getCompanyMembers = (companyId: string) => (companyRelations ?? []).filter(r => r.company_id === companyId);

  if (isLoading) return <div className="flex items-center justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Building2 className="h-6 w-6 text-secondary" />
          <h1 className="text-2xl font-bold">{t("admin.companiesTitle")}</h1>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={openNewCompany}><Plus className="h-4 w-4 mr-2" />{t("admin.newCompany")}</Button>
          <Button onClick={() => setInviteDialogOpen(true)}><UserPlus className="h-4 w-4 mr-2" />{t("admin.inviteEmployer")}</Button>
        </div>
      </div>

      {/* Search */}
      <div className="relative max-w-sm">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input className="pl-8" placeholder={t("admin.searchCompanyPlaceholder")} value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">{t("admin.companiesTitle")} ({filteredCompanies.length})</CardTitle>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t("admin.companyName")}</TableHead>
                <TableHead>{t("admin.taxNumber")}</TableHead>
                <TableHead>{t("admin.address")}</TableHead>
                <TableHead>{t("admin.category")}</TableHead>
                <TableHead>{t("admin.pricingType")}</TableHead>
                <TableHead>{t("admin.members")}</TableHead>
                <TableHead>{t("admin.createdAt")}</TableHead>
                <TableHead className="w-20">{t("common.actions")}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredCompanies.map((c) => {
                const members = getCompanyMembers(c.id);
                return (
                  <TableRow key={c.id}>
                    <TableCell className="font-medium">{c.name}</TableCell>
                    <TableCell>{c.tax_number || "—"}</TableCell>
                    <TableCell className="max-w-48 truncate">{c.address || "—"}</TableCell>
                    <TableCell>
                      {c.contract_category ? <Badge variant="outline">{c.contract_category}</Badge> : "—"}
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">
                        {c.pricing_type ? (
                          <span>{t(PRICING_LABEL_KEYS[c.pricing_type] || "") || c.pricing_type}{c.contract_price != null ? ` — ${c.contract_price.toLocaleString("hu-HU")} Ft` : ""}</span>
                        ) : "—"}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {members.length === 0 ? (
                          <span className="text-xs text-muted-foreground">{t("admin.noMembers")}</span>
                        ) : (
                          members.slice(0, 3).map(m => (
                            <Badge key={m.id} variant="secondary" className="text-xs">
                              {getProfileName(m.user_id)}
                              <span className="ml-1 text-muted-foreground">({m.role === "munkaltato" ? "M" : "D"})</span>
                            </Badge>
                          ))
                        )}
                        {members.length > 3 && <Badge variant="outline" className="text-xs">+{members.length - 3}</Badge>}
                      </div>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">{new Date(c.created_at).toLocaleDateString("hu-HU")}</TableCell>
                    <TableCell>
                      <Button size="sm" variant="ghost" onClick={() => openEdit(c)}><Pencil className="h-4 w-4" /></Button>
                    </TableCell>
                  </TableRow>
                );
              })}
              {filteredCompanies.length === 0 && (
                <TableRow><TableCell colSpan={8} className="text-center text-muted-foreground py-8">
                  {searchQuery ? t("admin.noSearchResults") : t("admin.noCompaniesInDb")}
                </TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Edit/Create Company Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing ? t("admin.editCompany") : t("admin.newCompany")}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label>{t("admin.companyName")} *</Label>
              <Input value={companyForm.name} onChange={e => setCompanyForm(f => ({ ...f, name: e.target.value }))} />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>{t("admin.taxNumber")}</Label>
                <Input value={companyForm.tax_number} onChange={e => setCompanyForm(f => ({ ...f, tax_number: e.target.value }))} />
              </div>
              <div className="space-y-1.5">
                <Label>{t("admin.industry")}</Label>
                <Input value={companyForm.industry} onChange={e => setCompanyForm(f => ({ ...f, industry: e.target.value }))} />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>{t("admin.address")}</Label>
              <Input value={companyForm.address} onChange={e => setCompanyForm(f => ({ ...f, address: e.target.value }))} />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>{t("admin.email")}</Label>
                <Input type="email" value={companyForm.contact_email} onChange={e => setCompanyForm(f => ({ ...f, contact_email: e.target.value }))} />
              </div>
              <div className="space-y-1.5">
                <Label>{t("admin.phone")}</Label>
                <Input value={companyForm.contact_phone} onChange={e => setCompanyForm(f => ({ ...f, contact_phone: e.target.value }))} />
              </div>
            </div>

            {/* Contract pricing */}
            <div className="border-t pt-3 mt-1">
               <p className="text-sm font-semibold mb-2">{t("admin.contractTerms")}</p>
              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-1.5">
                  <Label>{t("admin.category")}</Label>
                  <Select value={companyForm.contract_category} onValueChange={v => setCompanyForm(f => ({ ...f, contract_category: v }))}>
                    <SelectTrigger><SelectValue placeholder="—" /></SelectTrigger>
                    <SelectContent>
                      {CATEGORY_OPTIONS.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                 <div className="space-y-1.5">
                  <Label>{t("admin.pricingType")}</Label>
                  <Select value={companyForm.pricing_type} onValueChange={v => setCompanyForm(f => ({ ...f, pricing_type: v }))}>
                    <SelectTrigger><SelectValue placeholder="—" /></SelectTrigger>
                    <SelectContent>
                      {PRICING_TYPE_KEYS.map((p) => <SelectItem key={p.value} value={p.value}>{t(p.key)}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                 <div className="space-y-1.5">
                  <Label>{t("admin.priceFt")}</Label>
                  <Input type="number" value={companyForm.contract_price} onChange={e => setCompanyForm(f => ({ ...f, contract_price: e.target.value }))} placeholder="0" />
                </div>
              </div>
            </div>

            {/* Sites / Work Areas / Workplaces */}
            {editing && (
              <div className="border-t pt-3 mt-1">
                <WorkAreaManager companyId={editing.id} />
              </div>
            )}

            <Button className="w-full" disabled={!companyForm.name || upsertCompany.isPending}
              onClick={() => upsertCompany.mutate({ ...companyForm, id: editing?.id })}>
              {editing ? t("common.save") : t("common.create")}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Invite Employer Dialog */}
      <Dialog open={inviteDialogOpen} onOpenChange={setInviteDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Send className="h-5 w-5" />{t("admin.inviteEmployer")}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>{t("admin.inviteName")} *</Label>
                <Input value={inviteForm.full_name} onChange={e => setInviteForm(f => ({ ...f, full_name: e.target.value }))} placeholder={t("admin.inviteFullName")} />
              </div>
              <div className="space-y-1.5">
                <Label>{t("admin.inviteEmail")} *</Label>
                <Input type="email" value={inviteForm.email} onChange={e => setInviteForm(f => ({ ...f, email: e.target.value }))} placeholder="email@ceg.hu" />
              </div>
            </div>
            <Tabs value={inviteMode} onValueChange={v => setInviteMode(v as "existing" | "new")}>
              <TabsList className="w-full">
                <TabsTrigger value="new" className="flex-1">{t("admin.createNewCompany")}</TabsTrigger>
                <TabsTrigger value="existing" className="flex-1">{t("admin.existingCompany")}</TabsTrigger>
              </TabsList>
              <TabsContent value="new" className="space-y-3 mt-3">
                <div className="space-y-1.5">
                  <Label>{t("admin.companyName")} *</Label>
                  <Input value={inviteForm.company_name} onChange={e => setInviteForm(f => ({ ...f, company_name: e.target.value }))} />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <Label>{t("admin.taxNumber")}</Label>
                    <Input value={inviteForm.tax_number} onChange={e => setInviteForm(f => ({ ...f, tax_number: e.target.value }))} />
                  </div>
                  <div className="space-y-1.5">
                    <Label>{t("admin.phone")}</Label>
                    <Input value={inviteForm.contact_phone} onChange={e => setInviteForm(f => ({ ...f, contact_phone: e.target.value }))} />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label>{t("admin.address")}</Label>
                  <Input value={inviteForm.address} onChange={e => setInviteForm(f => ({ ...f, address: e.target.value }))} />
                </div>
              </TabsContent>
              <TabsContent value="existing" className="space-y-3 mt-3">
                <div className="space-y-1.5">
                  <Label>{t("admin.selectCompany")} *</Label>
                  <Select value={inviteForm.company_id} onValueChange={v => setInviteForm(f => ({ ...f, company_id: v }))}>
                    <SelectTrigger><SelectValue placeholder={t("admin.selectCompanyPlaceholder")} /></SelectTrigger>
                    <SelectContent>
                      {(companies ?? []).map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </TabsContent>
            </Tabs>
            <div className="rounded-lg bg-muted/50 p-3 text-sm text-muted-foreground">
              <p>{t("admin.inviteNote")}</p>
            </div>
            <Button className="w-full" disabled={
              !inviteForm.email || !inviteForm.full_name || inviteEmployer.isPending ||
              (inviteMode === "new" && !inviteForm.company_name) ||
              (inviteMode === "existing" && !inviteForm.company_id)
            } onClick={() => inviteEmployer.mutate(inviteForm)}>
              <Send className="h-4 w-4 mr-2" />{t("admin.sendInvite")}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
