import { useState, useMemo } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Plus, Pencil, Trash2, FlaskConical, Upload, FileText, ExternalLink, AlertTriangle } from "lucide-react";
import { toast } from "sonner";
import SdsReader from "@/components/SdsReader";

interface Substance {
  id: string;
  name: string;
  description: string | null;
  ec_number: string | null;
  cas_number: string | null;
  reason_for_inclusion: string | null;
  source: string;
  is_active: boolean;
  date_of_inclusion: string | null;
  decision_url: string | null;
  iuclid_dataset_url: string | null;
  support_document_url: string | null;
  remarks: string | null;
  created_at: string;
}

const SOURCE_LABELS: Record<string, string> = {
  echa_candidate: "ECHA Candidate (SVHC)",
  reach_svhc: "REACH SVHC",
  reach_restriction: "REACH Restriction",
  pops: "POPs (Persistent Organic Pollutants)",
};

const SOURCE_COLORS: Record<string, string> = {
  echa_candidate: "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200",
  reach_svhc: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
  reach_restriction: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
  pops: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200",
};

const REASON_CATEGORIES = [
  "Carcinogenic (Article 57a)",
  "Mutagenic (Article 57b)",
  "Toxic for reproduction (Article 57c)",
  "PBT (Article 57d)",
  "vPvB (Article 57e)",
  "Endocrine disrupting properties (Article 57(f) - environment)",
  "Endocrine disrupting properties (Article 57(f) - human health)",
  "Equivalent level of concern having probable serious effects to the environment (Article 57(f) - environment)",
  "Equivalent level of concern having probable serious effects to human health (Article 57(f) - human health)",
  "Respiratory sensitising properties (Article 57(f) - human health)",
  "Specific target organ toxicity after repeated exposure (Article 57(f) - human health)",
];

export default function AdminSubstances() {
  const { t } = useTranslation();
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [reasonFilter, setReasonFilter] = useState("all");
  const [sourceFilter, setSourceFilter] = useState("all");
  const [showInactive, setShowInactive] = useState(false);
  const [editSubstance, setEditSubstance] = useState<Substance | null>(null);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [page, setPage] = useState(0);
  const PAGE_SIZE = 50;

  const { data: substances, isLoading } = useQuery({
    queryKey: ["admin-substances", showInactive],
    queryFn: async () => {
      const allRows: Substance[] = [];
      const BATCH = 1000;
      let from = 0;
      while (true) {
        let q = (supabase as any)
          .from("hazardous_substances")
          .select("*")
          .order("name")
          .range(from, from + BATCH - 1);
        if (!showInactive) q = q.eq("is_active", true);
        const { data, error } = await q;
        if (error) throw error;
        allRows.push(...(data as Substance[]));
        if (!data || data.length < BATCH) break;
        from += BATCH;
      }
      return allRows;
    },
  });

  const filtered = useMemo(() => {
    if (!substances) return [];
    let result = substances;
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(s =>
        s.name?.toLowerCase().includes(q) ||
        s.cas_number?.toLowerCase().includes(q) ||
        s.ec_number?.toLowerCase().includes(q) ||
        s.description?.toLowerCase().includes(q)
      );
    }
    if (reasonFilter !== "all") {
      result = result.filter(s => s.reason_for_inclusion?.includes(reasonFilter));
    }
    if (sourceFilter !== "all") {
      result = result.filter(s => s.source === sourceFilter);
    }
    return result;
  }, [substances, search, reasonFilter, sourceFilter]);

  const paged = useMemo(() => filtered.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE), [filtered, page]);
  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);

  const saveMut = useMutation({
    mutationFn: async (substance: Partial<Substance> & { id?: string }) => {
      if (substance.id) {
        const { error } = await (supabase as any)
          .from("hazardous_substances")
          .update(substance)
          .eq("id", substance.id);
        if (error) throw error;
      } else {
        const { error } = await (supabase as any)
          .from("hazardous_substances")
          .insert(substance);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-substances"] });
      qc.invalidateQueries({ queryKey: ["hazardous-substances"] });
      setIsFormOpen(false);
      setEditSubstance(null);
      toast.success(t("common.saved"));
    },
    onError: (e: any) => toast.error(e.message),
  });

  const deleteMut = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await (supabase as any)
        .from("hazardous_substances")
        .update({ is_active: false })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-substances"] });
      toast.success(t("common.deleted"));
    },
  });

  const getReasonShort = (reason: string | null) => {
    if (!reason) return null;
    return reason.split("#").map((r, i) => {
      const short = r.includes("Carcinogenic") ? "CMR" :
        r.includes("Mutagenic") ? "MUT" :
        r.includes("Toxic for reproduction") ? "REP" :
        r.includes("PBT") ? "PBT" :
        r.includes("vPvB") ? "vPvB" :
        r.includes("Endocrine") ? "ED" :
        r.includes("Respiratory") ? "RESP" :
        r.includes("Equivalent") ? "ELoC" :
        r.includes("Specific target") ? "STOT" : r.substring(0, 8);
      const variant = ["CMR", "MUT", "STOT"].includes(short) ? "destructive" : "outline";
      return <Badge key={i} variant={variant as any} className="text-[9px] mr-0.5">{short}</Badge>;
    });
  };

  const sources = useMemo(() => {
    if (!substances) return [];
    return [...new Set(substances.map(s => s.source))].sort();
  }, [substances]);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <FlaskConical className="h-6 w-6" />
          {t("substances.databaseTitle")}
          <Badge variant="secondary">{filtered.length}</Badge>
        </h1>
        <Button onClick={() => { setEditSubstance(null); setIsFormOpen(true); }}>
          <Plus className="h-4 w-4 mr-2" />{t("common.add")}
        </Button>
      </div>

      <Tabs defaultValue="database">
        <TabsList>
          <TabsTrigger value="database">
            <FlaskConical className="h-4 w-4 mr-1" />
            {t("substances.databaseTitle")}
          </TabsTrigger>
          <TabsTrigger value="sds">
            <FileText className="h-4 w-4 mr-1" />
            {t("substances.sdsReader")}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="database" className="space-y-4">
          {/* Filters */}
          <Card>
            <CardContent className="pt-4">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    value={search}
                    onChange={e => { setSearch(e.target.value); setPage(0); }}
                    placeholder={t("substances.searchPlaceholder")}
                    className="pl-9"
                  />
                </div>
                <Select value={reasonFilter} onValueChange={v => { setReasonFilter(v); setPage(0); }}>
                  <SelectTrigger><SelectValue placeholder={t("substances.filterByReason")} /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">{t("common.all")}</SelectItem>
                    <SelectItem value="Carcinogenic">CMR - Rákkeltő</SelectItem>
                    <SelectItem value="Mutagenic">MUT - Mutagén</SelectItem>
                    <SelectItem value="Toxic for reproduction">REP - Reprodukciót károsító</SelectItem>
                    <SelectItem value="PBT">PBT</SelectItem>
                    <SelectItem value="vPvB">vPvB</SelectItem>
                    <SelectItem value="Endocrine">ED - Endokrin károsító</SelectItem>
                    <SelectItem value="Respiratory">RESP - Légzőszervi szenzibilizáló</SelectItem>
                    <SelectItem value="Specific target">STOT - Célszervi toxicitás</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={sourceFilter} onValueChange={v => { setSourceFilter(v); setPage(0); }}>
                  <SelectTrigger><SelectValue placeholder={t("substances.filterBySource")} /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">{t("common.all")}</SelectItem>
                    {sources.map(s => <SelectItem key={s} value={s}>{SOURCE_LABELS[s] || s}</SelectItem>)}
                  </SelectContent>
                </Select>
                <div className="flex items-center gap-2">
                  <Switch checked={showInactive} onCheckedChange={setShowInactive} />
                  <Label className="text-sm">{t("substances.showInactive")}</Label>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Table */}
          <Card>
            <CardContent className="p-0">
              <ScrollArea className="max-h-[600px]">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[300px]">{t("substances.name")}</TableHead>
                      <TableHead>{t("substances.ecNumber")}</TableHead>
                      <TableHead>{t("substances.casNumber")}</TableHead>
                      <TableHead>{t("substances.reason")}</TableHead>
                      <TableHead>{t("substances.dateOfInclusion")}</TableHead>
                      <TableHead>{t("substances.source")}</TableHead>
                      <TableHead className="w-[100px]"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paged.map(s => (
                      <TableRow key={s.id} className={!s.is_active ? "opacity-50" : ""}>
                        <TableCell>
                          <div className="max-w-[300px]">
                            <span className="font-medium text-sm block truncate">{s.name}</span>
                            {s.description && <span className="text-xs text-muted-foreground truncate block">{s.description}</span>}
                          </div>
                        </TableCell>
                        <TableCell className="text-sm font-mono">{s.ec_number || "-"}</TableCell>
                        <TableCell className="text-sm font-mono">{s.cas_number || "-"}</TableCell>
                        <TableCell>
                          <div className="flex flex-wrap gap-0.5">{getReasonShort(s.reason_for_inclusion)}</div>
                        </TableCell>
                        <TableCell className="text-sm">{s.date_of_inclusion || "-"}</TableCell>
                        <TableCell><Badge variant="outline" className={`text-xs ${SOURCE_COLORS[s.source] || ""}`}>{SOURCE_LABELS[s.source] || s.source}</Badge></TableCell>
                        <TableCell>
                          <div className="flex gap-1">
                            {s.decision_url && (
                              <Button size="icon" variant="ghost" className="h-7 w-7" asChild>
                                <a href={s.decision_url} target="_blank" rel="noopener"><ExternalLink className="h-3 w-3" /></a>
                              </Button>
                            )}
                            <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => { setEditSubstance(s); setIsFormOpen(true); }}>
                              <Pencil className="h-3 w-3" />
                            </Button>
                            {s.is_active && (
                              <Button size="icon" variant="ghost" className="h-7 w-7 text-destructive" onClick={() => deleteMut.mutate(s.id)}>
                                <Trash2 className="h-3 w-3" />
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </ScrollArea>
              {totalPages > 1 && (
                <div className="flex items-center justify-between p-3 border-t">
                  <span className="text-sm text-muted-foreground">
                    {page * PAGE_SIZE + 1}-{Math.min((page + 1) * PAGE_SIZE, filtered.length)} / {filtered.length}
                  </span>
                  <div className="flex gap-1">
                    <Button size="sm" variant="outline" disabled={page === 0} onClick={() => setPage(p => p - 1)}>←</Button>
                    <Button size="sm" variant="outline" disabled={page >= totalPages - 1} onClick={() => setPage(p => p + 1)}>→</Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sds">
          <SdsReader />
        </TabsContent>
      </Tabs>

      {/* Edit/Add dialog */}
      <SubstanceFormDialog
        open={isFormOpen}
        onOpenChange={setIsFormOpen}
        substance={editSubstance}
        onSave={saveMut.mutate}
        saving={saveMut.isPending}
      />
    </div>
  );
}

function SubstanceFormDialog({ open, onOpenChange, substance, onSave, saving }: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  substance: Substance | null;
  onSave: (s: Partial<Substance>) => void;
  saving: boolean;
}) {
  const { t } = useTranslation();
  const [form, setForm] = useState<Partial<Substance>>({});

  const resetForm = () => {
    if (substance) {
      setForm({ ...substance });
    } else {
      setForm({ name: "", source: "manual", is_active: true });
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => { if (o) resetForm(); onOpenChange(o); }}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{substance ? t("substances.edit") : t("substances.addNew")}</DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-4">
          <div className="col-span-2">
            <Label>{t("substances.name")} *</Label>
            <Input value={form.name || ""} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
          </div>
          <div className="col-span-2">
            <Label>{t("substances.description")}</Label>
            <Textarea value={form.description || ""} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} rows={2} />
          </div>
          <div>
            <Label>{t("substances.ecNumber")}</Label>
            <Input value={form.ec_number || ""} onChange={e => setForm(f => ({ ...f, ec_number: e.target.value }))} placeholder="xxx-xxx-x" />
          </div>
          <div>
            <Label>{t("substances.casNumber")}</Label>
            <Input value={form.cas_number || ""} onChange={e => setForm(f => ({ ...f, cas_number: e.target.value }))} placeholder="xxxxx-xx-x" />
          </div>
          <div className="col-span-2">
            <Label>{t("substances.reason")}</Label>
            <Select value={form.reason_for_inclusion || ""} onValueChange={v => setForm(f => ({ ...f, reason_for_inclusion: v }))}>
              <SelectTrigger><SelectValue placeholder={t("substances.selectReason")} /></SelectTrigger>
              <SelectContent>
                {REASON_CATEGORIES.map(r => <SelectItem key={r} value={r}>{r}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>{t("substances.dateOfInclusion")}</Label>
            <Input type="date" value={form.date_of_inclusion || ""} onChange={e => setForm(f => ({ ...f, date_of_inclusion: e.target.value }))} />
          </div>
          <div>
            <Label>{t("substances.source")}</Label>
            <Input value={form.source || ""} onChange={e => setForm(f => ({ ...f, source: e.target.value }))} />
          </div>
          <div className="col-span-2">
            <Label>Decision URL</Label>
            <Input value={form.decision_url || ""} onChange={e => setForm(f => ({ ...f, decision_url: e.target.value }))} />
          </div>
          <div className="col-span-2">
            <Label>{t("substances.remarks")}</Label>
            <Textarea value={form.remarks || ""} onChange={e => setForm(f => ({ ...f, remarks: e.target.value }))} rows={3} />
          </div>
          <div className="col-span-2 flex items-center gap-2">
            <Switch checked={form.is_active !== false} onCheckedChange={v => setForm(f => ({ ...f, is_active: v }))} />
            <Label>{t("common.active")}</Label>
          </div>
        </div>
        <div className="flex justify-end gap-2 mt-4">
          <Button variant="outline" onClick={() => onOpenChange(false)}>{t("common.cancel")}</Button>
          <Button onClick={() => onSave(form)} disabled={saving || !form.name?.trim()}>
            {saving ? "..." : t("common.save")}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
