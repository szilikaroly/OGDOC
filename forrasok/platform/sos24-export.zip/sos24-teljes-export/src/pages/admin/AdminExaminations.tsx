import { useTranslation } from "react-i18next";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { ClipboardCheck, Search, Download } from "lucide-react";
import { useState, useMemo, useCallback } from "react";

function daysDiff(dateStr: string) {
  return (new Date(dateStr).getTime() - Date.now()) / (1000 * 60 * 60 * 24);
}

export default function AdminExaminations() {
  const { t } = useTranslation();
  const [search, setSearch] = useState("");
  const [filterResult, setFilterResult] = useState<string>("all");

  const RESULT_LABELS: Record<string, { label: string; variant: "default" | "destructive" | "secondary" | "outline" }> = {
    alkalmas: { label: t("admin.fit"), variant: "default" },
    nem_alkalmas: { label: t("admin.unfit"), variant: "destructive" },
    feltetelesen_alkalmas: { label: t("admin.conditionallyFit"), variant: "secondary" },
    ideiglenes: { label: t("admin.temporary"), variant: "outline" },
  };

  const { data: examinations, isLoading } = useQuery({
    queryKey: ["admin-examinations"],
    queryFn: async () => {
      const { data, error } = await supabase.from("examinations").select("id, patient_id, doctor_id, exam_type, result, valid_until, created_at, restrictions, referral_id").order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  const { data: profiles } = useQuery({ queryKey: ["admin-profiles-exam"], queryFn: async () => { const { data } = await supabase.from("profiles").select("user_id, full_name"); return data ?? []; } });
  const { data: companies } = useQuery({ queryKey: ["admin-companies-exam"], queryFn: async () => { const { data } = await supabase.from("companies").select("id, name"); return data ?? []; } });
  const { data: referrals } = useQuery({ queryKey: ["admin-referrals-exam"], queryFn: async () => { const { data } = await supabase.from("referrals").select("id, company_id, employee_id"); return data ?? []; } });

  const getName = (userId: string) => profiles?.find(p => p.user_id === userId)?.full_name ?? "—";
  const getCompanyForExam = (referralId: string | null) => {
    if (!referralId) return "—";
    const ref = referrals?.find(r => r.id === referralId);
    if (!ref) return "—";
    return companies?.find(c => c.id === ref.company_id)?.name ?? "—";
  };

  const filtered = useMemo(() => {
    let list = examinations ?? [];
    if (filterResult !== "all") list = list.filter(e => e.result === filterResult);
    if (search) {
      const s = search.toLowerCase();
      list = list.filter(e => getName(e.patient_id).toLowerCase().includes(s) || getName(e.doctor_id).toLowerCase().includes(s) || e.exam_type.toLowerCase().includes(s));
    }
    return list;
  }, [examinations, filterResult, search, profiles]);

  const exportCsv = useCallback(() => {
    if (!filtered.length) return;
    const rows = [[t("admin.patient"), t("admin.doctor"), t("admin.examType"), t("admin.company"), t("admin.result"), t("admin.validUntil"), t("common.date")]];
    filtered.forEach(e => {
      rows.push([getName(e.patient_id), getName(e.doctor_id), e.exam_type, getCompanyForExam(e.referral_id), RESULT_LABELS[e.result]?.label ?? e.result, e.valid_until ? new Date(e.valid_until).toLocaleDateString("hu-HU") : "", new Date(e.created_at).toLocaleDateString("hu-HU")]);
    });
    const csv = rows.map(r => r.map(c => `"${c}"`).join(",")).join("\n");
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = `vizsgalatok_${new Date().toISOString().slice(0, 10)}.csv`; a.click(); URL.revokeObjectURL(url);
  }, [filtered, profiles, referrals, companies]);

  if (isLoading) {
    return <div className="flex items-center justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>;
  }

  const stats = {
    total: examinations?.length ?? 0,
    alkalmas: examinations?.filter(e => e.result === "alkalmas").length ?? 0,
    nem_alkalmas: examinations?.filter(e => e.result === "nem_alkalmas").length ?? 0,
    expiringSoon: examinations?.filter(e => e.valid_until && daysDiff(e.valid_until) > 0 && daysDiff(e.valid_until) <= 30).length ?? 0,
    expired: examinations?.filter(e => e.valid_until && daysDiff(e.valid_until) <= 0).length ?? 0,
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <ClipboardCheck className="h-6 w-6 text-secondary" />
        <h1 className="text-2xl font-bold">{t("admin.examinationsTitle")}</h1>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card><CardContent className="pt-4 text-center"><p className="text-2xl font-bold">{stats.total}</p><p className="text-sm text-muted-foreground">{t("admin.total")}</p></CardContent></Card>
        <Card><CardContent className="pt-4 text-center"><p className="text-2xl font-bold text-green-600">{stats.alkalmas}</p><p className="text-sm text-muted-foreground">{t("admin.fit")}</p></CardContent></Card>
        <Card><CardContent className="pt-4 text-center"><p className="text-2xl font-bold text-destructive">{stats.nem_alkalmas}</p><p className="text-sm text-muted-foreground">{t("admin.unfit")}</p></CardContent></Card>
        <Card><CardContent className="pt-4 text-center"><p className="text-2xl font-bold text-yellow-600">{stats.expiringSoon}</p><p className="text-sm text-muted-foreground">{t("admin.expiringSoon")}</p></CardContent></Card>
        <Card><CardContent className="pt-4 text-center"><p className="text-2xl font-bold text-destructive">{stats.expired}</p><p className="text-sm text-muted-foreground">{t("admin.expired")}</p></CardContent></Card>
      </div>

      <div className="flex gap-3 items-center">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder={t("admin.searchByNameDoctorType")} value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
        </div>
        <Select value={filterResult} onValueChange={setFilterResult}>
          <SelectTrigger className="w-48"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t("admin.allResults")}</SelectItem>
            <SelectItem value="alkalmas">{t("admin.fit")}</SelectItem>
            <SelectItem value="nem_alkalmas">{t("admin.unfit")}</SelectItem>
            <SelectItem value="feltetelesen_alkalmas">{t("admin.conditionallyFit")}</SelectItem>
            <SelectItem value="ideiglenes">{t("admin.temporary")}</SelectItem>
          </SelectContent>
        </Select>
        <Button variant="outline" size="sm" onClick={exportCsv} disabled={!filtered.length}><Download className="h-4 w-4 mr-1" />{t("admin.csvExport")}</Button>
      </div>

      <Card>
        <CardHeader><CardTitle className="text-lg">{t("admin.examinations")} ({filtered.length})</CardTitle></CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t("admin.patient")}</TableHead>
                <TableHead>{t("admin.doctor")}</TableHead>
                <TableHead>{t("admin.examType")}</TableHead>
                <TableHead>{t("admin.company")}</TableHead>
                <TableHead>{t("admin.result")}</TableHead>
                <TableHead>{t("admin.validUntil")}</TableHead>
                <TableHead>{t("common.date")}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map(e => {
                const resultInfo = RESULT_LABELS[e.result] ?? { label: e.result, variant: "secondary" as const };
                const days = e.valid_until ? daysDiff(e.valid_until) : null;
                const isExpiring = days !== null && days > 0 && days <= 30;
                const isExpired = days !== null && days <= 0;
                return (
                  <TableRow key={e.id} className={isExpired ? "bg-destructive/5" : isExpiring ? "bg-yellow-50 dark:bg-yellow-950/20" : ""}>
                    <TableCell className="font-medium">{getName(e.patient_id)}</TableCell>
                    <TableCell>{getName(e.doctor_id)}</TableCell>
                    <TableCell>{e.exam_type}</TableCell>
                    <TableCell>{getCompanyForExam(e.referral_id)}</TableCell>
                    <TableCell><Badge variant={resultInfo.variant}>{resultInfo.label}</Badge></TableCell>
                    <TableCell>
                      {e.valid_until ? (
                        <span className={isExpired ? "text-destructive font-semibold" : isExpiring ? "text-yellow-600 font-medium" : ""}>
                          {new Date(e.valid_until).toLocaleDateString("hu-HU")}
                          {isExpired && " ❌"}{isExpiring && " ⚠️"}
                        </span>
                      ) : "—"}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">{new Date(e.created_at).toLocaleDateString("hu-HU")}</TableCell>
                  </TableRow>
                );
              })}
              {filtered.length === 0 && (<TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-8">{t("admin.noResult")}</TableCell></TableRow>)}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}