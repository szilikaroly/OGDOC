import { useEffect, useMemo, useState } from "react";
import { z } from "zod";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Plus, Trash2, Users, Pencil, KeyRound, Send, Loader2, AlertTriangle, CheckCircle2, Clock, XCircle, Filter, ShieldCheck, Check, Mail, UserCog, Apple, Chrome, KeySquare } from "lucide-react";
import type { AppRole } from "@/contexts/AuthContext";
import AuthHealthDialog, { type AuthHealthAction } from "@/components/admin/AuthHealthDialog";
import RecoveryHistoryPanel from "@/components/admin/RecoveryHistoryPanel";
import RecoveryFailuresSummary from "@/components/admin/RecoveryFailuresSummary";

const ALL_ROLES: AppRole[] = ["super_admin", "haziorvos", "uzemorvos", "munkaltato", "munkavallalo", "praxistag"];

type RecoveryStatus = {
  user_id: string;
  email: string;
  recovery_sent_at: string | null;
  last_sign_in_at: string | null;
  email_confirmed_at: string | null;
  last_recovery_status: string | null;
  last_recovery_error: string | null;
  last_recovery_log_at: string | null;
  user_created_at?: string | null;
  has_password?: boolean | null;
  last_admin_direct_at?: string | null;
  last_admin_direct_by?: string | null;
  last_action_kind?: "admin_direct" | "email_recovery" | null;
  last_action_at?: string | null;
};

type ProviderInfo = {
  user_id: string;
  providers: string[] | null;
  last_google_sign_in_at: string | null;
  last_apple_sign_in_at: string | null;
  last_email_sign_in_at: string | null;
  google_email: string | null;
};

const providerBadges = (p?: ProviderInfo) => {
  if (!p || !p.providers || p.providers.length === 0) {
    return <span className="text-xs text-muted-foreground">—</span>;
  }
  const cfg: Record<string, { label: string; cls: string; Icon: any; lastAt?: string | null; tipExtra?: string }> = {
    google: {
      label: "Google",
      cls: "bg-red-500/10 text-red-700 dark:text-red-300 border-red-500/30",
      Icon: Chrome,
      lastAt: p.last_google_sign_in_at,
      tipExtra: p.google_email ? `\nGoogle e-mail: ${p.google_email}` : "",
    },
    apple: {
      label: "Apple",
      cls: "bg-zinc-500/15 text-zinc-700 dark:text-zinc-300 border-zinc-500/30",
      Icon: Apple,
      lastAt: p.last_apple_sign_in_at,
    },
    email: {
      label: "E-mail",
      cls: "bg-sky-500/10 text-sky-700 dark:text-sky-300 border-sky-500/30",
      Icon: KeySquare,
      lastAt: p.last_email_sign_in_at,
    },
  };
  return (
    <div className="flex flex-wrap items-center gap-1">
      {p.providers.map((prov) => {
        const c = cfg[prov] ?? { label: prov, cls: "bg-muted text-muted-foreground border-border", Icon: ShieldCheck, lastAt: null };
        const I = c.Icon;
        const tip = c.lastAt
          ? `${c.label} utolsó belépés: ${new Date(c.lastAt).toLocaleString("hu-HU")}${c.tipExtra ?? ""}`
          : `${c.label} fiók összekötve${c.tipExtra ?? ""}`;
        return (
          <span
            key={prov}
            className={`inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-[10px] font-medium ${c.cls}`}
            title={tip}
          >
            <I className="h-3 w-3" />
            {c.label}
          </span>
        );
      })}
    </div>
  );
};

const kindBadge = (kind: RecoveryStatus["last_action_kind"], at?: string | null) => {
  if (!kind) return null;
  const isDirect = kind === "admin_direct";
  const label = isDirect ? "Admin közvetlen" : "E-mail link";
  const Icon = isDirect ? UserCog : Mail;
  const cls = isDirect
    ? "bg-blue-500/15 text-blue-700 dark:text-blue-300 border-blue-500/30"
    : "bg-purple-500/15 text-purple-700 dark:text-purple-300 border-purple-500/30";
  const tip = isDirect
    ? "Utolsó akció: az admin közvetlenül beállította a jelszót (admin workflow)."
    : "Utolsó akció: a felhasználó/admin által indított e-mailes jelszó-visszaállító link.";
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-[10px] font-medium ${cls}`}
      title={at ? `${tip}\nIdőpont: ${new Date(at).toLocaleString("hu-HU")}` : tip}
    >
      <Icon className="h-3 w-3" />{label}
    </span>
  );
};

const relTime = (iso: string | null): string => {
  if (!iso) return "—";
  const d = new Date(iso).getTime();
  const diff = Date.now() - d;
  const m = Math.floor(diff / 60000);
  if (m < 1) return "épp most";
  if (m < 60) return `${m} perce`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h} órája`;
  const days = Math.floor(h / 24);
  if (days < 30) return `${days} napja`;
  return new Date(iso).toLocaleDateString("hu-HU");
};

const statusBadge = (s: string | null) => {
  if (!s) return null;
  const map: Record<string, { label: string; cls: string; Icon: any }> = {
    sent:       { label: "Kiküldve",   cls: "bg-green-500/15 text-green-700 dark:text-green-300 border-green-500/30", Icon: CheckCircle2 },
    pending:    { label: "Sorban",     cls: "bg-yellow-500/15 text-yellow-700 dark:text-yellow-300 border-yellow-500/30", Icon: Clock },
    dlq:        { label: "Sikertelen", cls: "bg-red-500/15 text-red-700 dark:text-red-300 border-red-500/30", Icon: XCircle },
    failed:     { label: "Hiba",       cls: "bg-red-500/15 text-red-700 dark:text-red-300 border-red-500/30", Icon: XCircle },
    suppressed: { label: "Letiltva",   cls: "bg-muted text-muted-foreground border-border", Icon: AlertTriangle },
    bounced:    { label: "Visszapattant", cls: "bg-red-500/15 text-red-700 dark:text-red-300 border-red-500/30", Icon: XCircle },
    complained: { label: "Panasz",     cls: "bg-red-500/15 text-red-700 dark:text-red-300 border-red-500/30", Icon: XCircle },
  };
  const cfg = map[s] ?? { label: s, cls: "bg-muted text-muted-foreground border-border", Icon: Clock };
  const I = cfg.Icon;
  return (
    <span className={`inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-[10px] font-medium ${cfg.cls}`}>
      <I className="h-3 w-3" />{cfg.label}
    </span>
  );
};

type ProfileRow = {
  id: string;
  user_id: string;
  full_name: string | null;
  phone: string | null;
  created_at: string;
};

export default function AdminUsers() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [addRoleUser, setAddRoleUser] = useState<string | null>(null);
  const [selectedRole, setSelectedRole] = useState<AppRole | "">("");

  const [editUser, setEditUser] = useState<ProfileRow | null>(null);
  const [editEmail, setEditEmail] = useState("");
  const [editPhone, setEditPhone] = useState("");
  const [editName, setEditName] = useState("");
  const [editLoading, setEditLoading] = useState(false);
  const [origEmail, setOrigEmail] = useState("");
  const [origPhone, setOrigPhone] = useState("");
  const [origName, setOrigName] = useState("");
  const [debEmail, setDebEmail] = useState("");
  const [debPhone, setDebPhone] = useState("");
  const [emailAvail, setEmailAvail] = useState<null | { available: boolean; checking: boolean }>(null);
  const [phoneAvail, setPhoneAvail] = useState<null | { available: boolean; checking: boolean; ownerName?: string }>(null);

  const normalizePhone = (s: string) => s.replace(/[^\d+]/g, "");
  const editSchema = useMemo(() => z.object({
    name: z.string().trim().min(1, "Kötelező").max(100, "Max 100 karakter"),
    email: z.union([
      z.literal(""),
      z.string().trim().email("Érvénytelen email cím").max(255, "Max 255 karakter"),
    ]),
    phone: z.union([
      z.literal(""),
      z.string().trim().regex(/^\+?[0-9\s\-()]{6,20}$/, "Érvénytelen telefonszám"),
    ]),
  }), []);

  const fieldErrors = useMemo(() => {
    const parsed = editSchema.safeParse({ name: editName, email: editEmail, phone: editPhone });
    if (parsed.success) return {} as Record<string, string>;
    const out: Record<string, string> = {};
    for (const issue of parsed.error.issues) {
      const key = issue.path[0] as string;
      if (!out[key]) out[key] = issue.message;
    }
    return out;
  }, [editName, editEmail, editPhone, editSchema]);


  const [pwdUser, setPwdUser] = useState<ProfileRow | null>(null);
  const [pwdMode, setPwdMode] = useState<"link" | "direct">("link");
  const [pwdValue, setPwdValue] = useState("");
  const [pwdLoading, setPwdLoading] = useState(false);

  const ROLE_LABELS: Record<AppRole, string> = {
    super_admin: t("roles.super_admin"),
    haziorvos: t("roles.haziorvos"),
    uzemorvos: t("roles.uzemorvos"),
    munkaltato: t("roles.munkaltato"),
    munkavallalo: t("roles.munkavallalo"),
    praxistag: t("roles.praxistag"),
  };

  const { data: profiles, isLoading } = useQuery({
    queryKey: ["admin-profiles"],
    queryFn: async () => {
      const { data, error } = await supabase.from("profiles").select("id, user_id, full_name, phone, created_at").order("created_at", { ascending: false });
      if (error) throw error;
      return data as ProfileRow[];
    },
  });

  const { data: allRoles } = useQuery({
    queryKey: ["admin-user-roles"],
    queryFn: async () => {
      const { data, error } = await supabase.from("user_roles").select("id, user_id, role");
      if (error) throw error;
      return data;
    },
  });

  const userIds = (profiles ?? []).map((p) => p.user_id);
  const { data: recoveryMap } = useQuery({
    queryKey: ["admin-recovery-status", userIds.length, userIds.join(",")],
    enabled: userIds.length > 0,
    queryFn: async () => {
      const { data, error } = await supabase.rpc("admin_get_recovery_status", { _user_ids: userIds });
      if (error) throw error;
      const map = new Map<string, RecoveryStatus>();
      (data as RecoveryStatus[] | null)?.forEach((r) => map.set(r.user_id, r));
      return map;
    },
    refetchInterval: 60_000,
    staleTime: 30_000,
  });

  const { data: providerMap } = useQuery({
    queryKey: ["admin-user-providers", userIds.length, userIds.join(",")],
    enabled: userIds.length > 0,
    queryFn: async () => {
      const { data, error } = await supabase.rpc("admin_get_user_providers", { _user_ids: userIds });
      if (error) throw error;
      const map = new Map<string, ProviderInfo>();
      (data as ProviderInfo[] | null)?.forEach((r) => map.set(r.user_id, r));
      return map;
    },
    refetchInterval: 60_000,
    staleTime: 30_000,
  });

  const [onlyProblematic, setOnlyProblematic] = useState(false);
  const [authHealthOpen, setAuthHealthOpen] = useState(false);
  const isProblematic = (r?: RecoveryStatus): boolean => {
    if (!r) return false;
    if (!r.email_confirmed_at) return true;
    if (r.last_recovery_status && ["pending", "dlq", "failed", "suppressed", "bounced", "complained"].includes(r.last_recovery_status)) return true;
    return false;
  };

  const roleCounts = new Map<string, number>();
  (allRoles ?? []).forEach((r: any) => roleCounts.set(r.user_id, (roleCounts.get(r.user_id) ?? 0) + 1));

  const handleAuthHealthAction = (action: AuthHealthAction) => {
    const profile = (profiles ?? []).find((p) => p.user_id === action.userId);
    if (!profile) return;
    switch (action.type) {
      case "send_recovery_link":
        setPwdUser(profile); setPwdMode("link"); setPwdValue("");
        break;
      case "set_password_direct":
        setPwdUser(profile); setPwdMode("direct"); setPwdValue("");
        break;
      case "edit_email":
        openEdit(profile);
        break;
      case "add_role":
        setAddRoleUser(profile.user_id);
        break;
    }
  };

  const addRole = useMutation({
    mutationFn: async ({ userId, role }: { userId: string; role: AppRole }) => {
      const { error } = await supabase.from("user_roles").insert({ user_id: userId, role });
      if (error) throw error;
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["admin-user-roles"] }); toast({ title: t("admin.roleAdded") }); setAddRoleUser(null); setSelectedRole(""); },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  const removeRole = useMutation({
    mutationFn: async (roleId: string) => {
      const { error } = await supabase.from("user_roles").delete().eq("id", roleId);
      if (error) throw error;
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["admin-user-roles"] }); toast({ title: t("admin.roleRemoved") }); },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  const getRolesForUser = (userId: string) => (allRoles ?? []).filter((r) => r.user_id === userId);

  const openEdit = async (p: ProfileRow) => {
    setEditUser(p);
    setEditName(p.full_name ?? "");
    setEditPhone(p.phone ?? "");
    setEditEmail("");
    setOrigName(p.full_name ?? "");
    setOrigPhone(p.phone ?? "");
    setOrigEmail("");
    setEmailAvail(null);
    setPhoneAvail(null);
    // Fetch current email via admin function — show only when admin
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (user?.id === p.user_id) {
        setEditEmail(user.email ?? "");
        setOrigEmail(user.email ?? "");
      }
    } catch { /* ignore */ }
  };

  // Debounce email/phone changes
  useEffect(() => {
    const id = setTimeout(() => setDebEmail(editEmail.trim().toLowerCase()), 400);
    return () => clearTimeout(id);
  }, [editEmail]);
  useEffect(() => {
    const id = setTimeout(() => setDebPhone(normalizePhone(editPhone)), 400);
    return () => clearTimeout(id);
  }, [editPhone]);

  // Email availability check
  useEffect(() => {
    if (!editUser) return;
    const same = debEmail === origEmail.trim().toLowerCase();
    if (!debEmail || same || fieldErrors.email) { setEmailAvail(null); return; }
    let cancelled = false;
    setEmailAvail({ available: false, checking: true });
    (async () => {
      try {
        const { data, error } = await supabase.functions.invoke("admin-check-email-available", {
          body: { email: debEmail, exclude_user_id: editUser.user_id },
        });
        if (cancelled) return;
        if (error || (data as any)?.error) {
          setEmailAvail({ available: false, checking: false });
          return;
        }
        setEmailAvail({ available: !!(data as any).available, checking: false });
      } catch {
        if (!cancelled) setEmailAvail({ available: false, checking: false });
      }
    })();
    return () => { cancelled = true; };
  }, [debEmail, editUser, origEmail, fieldErrors.email]);

  // Phone availability check (profiles table)
  useEffect(() => {
    if (!editUser) return;
    const same = debPhone === normalizePhone(origPhone);
    if (!debPhone || same || fieldErrors.phone) { setPhoneAvail(null); return; }
    let cancelled = false;
    setPhoneAvail({ available: false, checking: true });
    (async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("user_id, full_name, phone")
        .neq("user_id", editUser.user_id)
        .limit(50);
      if (cancelled) return;
      if (error) { setPhoneAvail({ available: false, checking: false }); return; }
      const hit = (data ?? []).find((r: any) => normalizePhone(r.phone ?? "") === debPhone);
      setPhoneAvail({ available: !hit, checking: false, ownerName: hit?.full_name ?? undefined });
    })();
    return () => { cancelled = true; };
  }, [debPhone, editUser, origPhone, fieldErrors.phone]);

  const hasChanges =
    editName.trim() !== origName.trim() ||
    editEmail.trim() !== origEmail.trim() ||
    normalizePhone(editPhone) !== normalizePhone(origPhone);
  const checking = !!emailAvail?.checking || !!phoneAvail?.checking;
  const emailBlocked = !!emailAvail && !emailAvail.checking && !emailAvail.available;
  const phoneBlocked = !!phoneAvail && !phoneAvail.checking && !phoneAvail.available;
  const canSave = !editLoading && hasChanges && !checking &&
    !fieldErrors.name && !fieldErrors.email && !fieldErrors.phone &&
    !emailBlocked && !phoneBlocked;


  const saveEdit = async () => {
    if (!editUser) return;
    setEditLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("admin-update-user", {
        body: {
          user_id: editUser.user_id,
          email: editEmail.trim() || undefined,
          phone: editPhone.trim(),
          full_name: editName.trim() || undefined,
        },
      });
      if (error || (data as any)?.error) throw new Error((data as any)?.error || error?.message);
      toast({ title: "Felhasználói adatok mentve" });
      qc.invalidateQueries({ queryKey: ["admin-profiles"] });
      setEditUser(null);
    } catch (err: any) {
      toast({ variant: "destructive", title: t("common.error"), description: err.message });
    } finally {
      setEditLoading(false);
    }
  };

  const submitPassword = async () => {
    if (!pwdUser) return;
    setPwdLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("admin-set-user-password", {
        body: {
          user_id: pwdUser.user_id,
          mode: pwdMode,
          new_password: pwdMode === "direct" ? pwdValue : undefined,
          redirect_to: `${window.location.origin}/reset-password`,
        },
      });
      if (error || (data as any)?.error) throw new Error((data as any)?.error || error?.message);
      toast({
        title: pwdMode === "link" ? "Jelszó-visszaállító link elküldve" : "Új jelszó beállítva",
      });
      qc.invalidateQueries({ queryKey: ["admin-recovery-status"] });
      setPwdUser(null);
      setPwdValue("");
    } catch (err: any) {
      toast({ variant: "destructive", title: t("common.error"), description: err.message });
    } finally {
      setPwdLoading(false);
    }
  };

  if (isLoading) {
    return <div className="flex items-center justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>;
  }

  const renderActions = (p: ProfileRow) => (
    <div className="flex gap-1">
      <Button size="sm" variant="outline" onClick={() => setAddRoleUser(p.user_id)} title="Szerepkör">
        <Plus className="h-4 w-4" />
      </Button>
      <Button size="sm" variant="outline" onClick={() => openEdit(p)} title="Adatok szerkesztése">
        <Pencil className="h-4 w-4" />
      </Button>
      <Button size="sm" variant="outline" onClick={() => { setPwdUser(p); setPwdMode("link"); setPwdValue(""); }} title="Jelszó">
        <KeyRound className="h-4 w-4" />
      </Button>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Users className="h-6 w-6 text-secondary" />
        <h1 className="text-2xl font-bold">{t("admin.usersTitle")}</h1>
      </div>

      <RecoveryFailuresSummary days={7} />

      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0">

          <CardTitle className="text-lg">{t("admin.allUsers")} ({profiles?.length ?? 0})</CardTitle>
          <div className="flex items-center gap-2">
            <Button size="sm" variant="outline" onClick={() => setAuthHealthOpen(true)} title="Auth állapot ellenőrzése és javaslatok">
              <ShieldCheck className="h-4 w-4 mr-1" />
              Auth ellenőrzés
            </Button>
            <Button
              size="sm"
              variant={onlyProblematic ? "default" : "outline"}
              onClick={() => setOnlyProblematic((v) => !v)}
              title="Csak függő/hibás recovery vagy meg nem erősített email"
            >
              <Filter className="h-4 w-4 mr-1" />
              {onlyProblematic ? "Mind mutatása" : "Csak problémás"}
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {(() => {
            const visible = (profiles ?? []).filter((p) => !onlyProblematic || isProblematic(recoveryMap?.get(p.user_id)));
            return (
              <>
                <div className="hidden md:block overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>{t("common.name")}</TableHead>
                        <TableHead>{t("admin.phone")}</TableHead>
                        <TableHead>{t("admin.roles")}</TableHead>
                        <TableHead>Jelszó / Belépés</TableHead>
                        <TableHead>{t("admin.registration")}</TableHead>
                        <TableHead className="w-32">{t("common.actions")}</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {visible.map((p) => {
                        const userRoles = getRolesForUser(p.user_id);
                        const rec = recoveryMap?.get(p.user_id);
                        const prov = providerMap?.get(p.user_id);
                        const userRolesEmpty = userRoles.length === 0;
                        const hasOAuth = !!prov?.providers?.some((x) => x === "google" || x === "apple");
                        return (
                          <TableRow key={p.id}>
                            <TableCell className="font-medium">
                              <div className="flex items-center gap-1">
                                {p.full_name || "—"}
                                {rec && !rec.email_confirmed_at && (
                                  <span title="Email nincs megerősítve">
                                    <AlertTriangle className="h-3.5 w-3.5 text-yellow-600" />
                                  </span>
                                )}
                              </div>
                            </TableCell>
                            <TableCell>{p.phone || "—"}</TableCell>
                            <TableCell>
                              <div className="flex flex-wrap gap-1">
                                {userRoles.map((r) => (
                                  <Badge key={r.id} variant="secondary" className="gap-1">
                                    {ROLE_LABELS[r.role as AppRole] ?? r.role}
                                    <button onClick={() => removeRole.mutate(r.id)} className="ml-1 hover:text-destructive" title={t("admin.roleRemoved")}><Trash2 className="h-3 w-3" /></button>
                                  </Badge>
                                ))}
                                {userRolesEmpty && (
                                  <span className={`text-xs ${hasOAuth ? "text-yellow-700 dark:text-yellow-300 font-medium inline-flex items-center gap-1" : "text-muted-foreground"}`} title={hasOAuth ? "OAuth (Google/Apple) bejelentkezés szerepkör nélkül — kérjük rendelj hozzá jogosultságot." : undefined}>
                                    {hasOAuth && <AlertTriangle className="h-3 w-3" />}
                                    {t("admin.noRole")}
                                  </span>
                                )}
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="space-y-0.5 text-xs">
                                <div className="flex items-center gap-1">
                                  <KeyRound className="h-3 w-3 text-muted-foreground" />
                                  {rec?.last_recovery_log_at || rec?.recovery_sent_at ? (
                                    <>
                                      <span className="text-muted-foreground">{relTime(rec.last_recovery_log_at ?? rec.recovery_sent_at)}</span>
                                     {statusBadge(rec.last_recovery_status)}
                                      {kindBadge(rec.last_action_kind, rec.last_action_at)}
                                    </>
                                  ) : (
                                    <span className="text-muted-foreground">Nincs kérés</span>
                                  )}
                                </div>
                                <div className="flex items-center gap-1 text-muted-foreground">
                                  <span className="opacity-60">→</span>
                                  <span>Belépés: {rec?.last_sign_in_at ? relTime(rec.last_sign_in_at) : "soha"}</span>
                                </div>
                                <div className="flex items-center gap-1 pt-0.5">
                                  <span className="text-muted-foreground">Mód:</span>
                                  {providerBadges(prov)}
                                </div>
                                {prov?.last_google_sign_in_at && (
                                  <div className="text-muted-foreground">
                                    Google: {relTime(prov.last_google_sign_in_at)}
                                  </div>
                                )}
                              </div>
                            </TableCell>
                            <TableCell className="text-sm text-muted-foreground">{new Date(p.created_at).toLocaleDateString("hu-HU")}</TableCell>
                            <TableCell>{renderActions(p)}</TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>

                <div className="md:hidden space-y-3">
                  {visible.map((p) => {
                    const userRoles = getRolesForUser(p.user_id);
                    const rec = recoveryMap?.get(p.user_id);
                    const prov = providerMap?.get(p.user_id);
                    const hasOAuth = !!prov?.providers?.some((x) => x === "google" || x === "apple");
                    return (
                      <div key={p.id} className="rounded-lg border p-3 space-y-2">
                        <div className="flex items-center justify-between">
                          <p className="font-medium flex items-center gap-1">
                            {p.full_name || "—"}
                            {rec && !rec.email_confirmed_at && (
                              <span title="Email nincs megerősítve"><AlertTriangle className="h-3.5 w-3.5 text-yellow-600" /></span>
                            )}
                          </p>
                          {renderActions(p)}
                        </div>
                        {p.phone && <p className="text-sm text-muted-foreground">{p.phone}</p>}
                        <div className="flex flex-wrap gap-1">
                          {userRoles.map((r) => (
                            <Badge key={r.id} variant="secondary" className="gap-1 text-xs">
                              {ROLE_LABELS[r.role as AppRole] ?? r.role}
                              <button onClick={() => removeRole.mutate(r.id)} className="ml-1 hover:text-destructive"><Trash2 className="h-3 w-3" /></button>
                            </Badge>
                          ))}
                          {userRoles.length === 0 && (
                            <span className={`text-xs ${hasOAuth ? "text-yellow-700 dark:text-yellow-300 font-medium inline-flex items-center gap-1" : "text-muted-foreground"}`}>
                              {hasOAuth && <AlertTriangle className="h-3 w-3" />}
                              {t("admin.noRole")}
                            </span>
                          )}
                        </div>
                        <div className="text-xs space-y-0.5">
                          <div className="flex items-center gap-1">
                            <KeyRound className="h-3 w-3 text-muted-foreground" />
                            {rec?.last_recovery_log_at || rec?.recovery_sent_at ? (
                              <>
                                <span className="text-muted-foreground">{relTime(rec.last_recovery_log_at ?? rec.recovery_sent_at)}</span>
                                {statusBadge(rec.last_recovery_status)}
                                {kindBadge(rec.last_action_kind, rec.last_action_at)}
                              </>
                            ) : (
                              <span className="text-muted-foreground">Nincs jelszó-kérés</span>
                            )}
                          </div>
                          <p className="text-muted-foreground">Belépés: {rec?.last_sign_in_at ? relTime(rec.last_sign_in_at) : "soha"}</p>
                          <div className="flex items-center gap-1 flex-wrap">
                            <span className="text-muted-foreground">Mód:</span>
                            {providerBadges(prov)}
                          </div>
                          {prov?.last_google_sign_in_at && (
                            <p className="text-muted-foreground">Google: {relTime(prov.last_google_sign_in_at)}</p>
                          )}
                          <p className="text-muted-foreground">{t("admin.registration")}: {new Date(p.created_at).toLocaleDateString("hu-HU")}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {visible.length === 0 && (
                  <p className="text-sm text-muted-foreground text-center py-6">Nincs a szűrésnek megfelelő felhasználó.</p>
                )}
              </>
            );
          })()}
        </CardContent>
      </Card>

      <Dialog open={!!addRoleUser} onOpenChange={(open) => { if (!open) { setAddRoleUser(null); setSelectedRole(""); } }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t("admin.addRole")} — {(profiles ?? []).find((p) => p.user_id === addRoleUser)?.full_name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Select value={selectedRole} onValueChange={(v) => setSelectedRole(v as AppRole)}>
              <SelectTrigger><SelectValue placeholder={t("admin.selectRole")} /></SelectTrigger>
              <SelectContent>
                {ALL_ROLES.filter((r) => !getRolesForUser(addRoleUser ?? "").some((ur) => ur.role === r)).map((r) => (
                  <SelectItem key={r} value={r}>{ROLE_LABELS[r]}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button className="w-full" disabled={!selectedRole || addRole.isPending} onClick={() => { if (selectedRole && addRoleUser) addRole.mutate({ userId: addRoleUser, role: selectedRole as AppRole }); }}>
              {t("admin.addRole")}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit user data */}
      <Dialog open={!!editUser} onOpenChange={(open) => !open && setEditUser(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Felhasználói adatok — {editUser?.full_name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1">
              <Label>Teljes név</Label>
              <Input value={editName} onChange={(e) => setEditName(e.target.value)} aria-invalid={!!fieldErrors.name} />
              {fieldErrors.name && <p className="text-xs text-destructive">{fieldErrors.name}</p>}
            </div>
            <div className="space-y-1">
              <Label>Email</Label>
              <Input type="email" placeholder="új email cím (üresen hagyva nem változik)" value={editEmail} onChange={(e) => setEditEmail(e.target.value)} aria-invalid={!!fieldErrors.email || emailBlocked} />
              {fieldErrors.email ? (
                <p className="text-xs text-destructive">{fieldErrors.email}</p>
              ) : emailAvail?.checking ? (
                <p className="text-xs text-muted-foreground inline-flex items-center gap-1"><Loader2 className="h-3 w-3 animate-spin" /> Ellenőrzés…</p>
              ) : emailAvail && !emailAvail.available ? (
                <p className="text-xs text-destructive">Ez az email cím már regisztrálva van</p>
              ) : emailAvail && emailAvail.available ? (
                <p className="text-xs text-green-600 inline-flex items-center gap-1"><Check className="h-3 w-3" /> Elérhető</p>
              ) : (
                <p className="text-xs text-muted-foreground">Az email módosítása felülírja a bejelentkezési címet.</p>
              )}
            </div>
            <div className="space-y-1">
              <Label>Telefon</Label>
              <Input value={editPhone} onChange={(e) => setEditPhone(e.target.value)} aria-invalid={!!fieldErrors.phone || phoneBlocked} />
              {fieldErrors.phone ? (
                <p className="text-xs text-destructive">{fieldErrors.phone}</p>
              ) : phoneAvail?.checking ? (
                <p className="text-xs text-muted-foreground inline-flex items-center gap-1"><Loader2 className="h-3 w-3 animate-spin" /> Ellenőrzés…</p>
              ) : phoneAvail && !phoneAvail.available ? (
                <p className="text-xs text-destructive">Ezt a telefonszámot már használja{phoneAvail.ownerName ? `: ${phoneAvail.ownerName}` : ""}</p>
              ) : phoneAvail && phoneAvail.available ? (
                <p className="text-xs text-green-600 inline-flex items-center gap-1"><Check className="h-3 w-3" /> Elérhető</p>
              ) : null}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditUser(null)}>Mégse</Button>
            <Button onClick={saveEdit} disabled={!canSave}>
              {editLoading && <Loader2 className="h-4 w-4 mr-1 animate-spin" />}
              Mentés
            </Button>
          </DialogFooter>

        </DialogContent>
      </Dialog>

      {/* Password management */}
      <Dialog open={!!pwdUser} onOpenChange={(open) => !open && setPwdUser(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Jelszó kezelése — {pwdUser?.full_name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            {(() => {
              const rec = pwdUser ? recoveryMap?.get(pwdUser.user_id) : undefined;
              if (!rec) return null;
              return (
                <div className="rounded-md border bg-muted/40 p-2.5 text-xs space-y-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-muted-foreground">Utolsó akció típusa:</span>
                    <div className="flex items-center gap-1">
                      {rec.last_action_kind
                        ? <>{kindBadge(rec.last_action_kind, rec.last_action_at)}<span className="text-muted-foreground">{rec.last_action_at ? relTime(rec.last_action_at) : ""}</span></>
                        : <span>—</span>}
                    </div>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-muted-foreground">Utolsó e-mail kérés:</span>
                    <div className="flex items-center gap-1">
                      {rec.last_recovery_log_at || rec.recovery_sent_at
                        ? <><span>{relTime(rec.last_recovery_log_at ?? rec.recovery_sent_at)}</span>{statusBadge(rec.last_recovery_status)}</>
                        : <span>—</span>}
                    </div>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-muted-foreground">Utolsó admin közvetlen beállítás:</span>
                    <span>{rec.last_admin_direct_at ? relTime(rec.last_admin_direct_at) : "—"}</span>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-muted-foreground">Utolsó belépés:</span>
                    <span>{rec.last_sign_in_at ? relTime(rec.last_sign_in_at) : "soha"}</span>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-muted-foreground">Email megerősítve:</span>
                    <span className={rec.email_confirmed_at ? "" : "text-yellow-700 dark:text-yellow-300 font-medium"}>
                      {rec.email_confirmed_at ? "igen" : "NEM"}
                    </span>
                  </div>
                  {rec.last_recovery_error && (
                    <p className="text-red-600 dark:text-red-400 pt-1 break-words"><strong>Hiba:</strong> {rec.last_recovery_error}</p>
                  )}
                </div>
              );
            })()}
            {pwdUser && (
              <RecoveryHistoryPanel
                userId={pwdUser.user_id}
                userLabel={pwdUser.full_name ?? pwdUser.user_id}
                limit={10}
              />
            )}
            <Select value={pwdMode} onValueChange={(v) => setPwdMode(v as "link" | "direct")}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="link">Visszaállító link emailben (ajánlott)</SelectItem>
                <SelectItem value="direct">Új jelszó közvetlen beállítása</SelectItem>
              </SelectContent>
            </Select>
            {pwdMode === "link" && (
              <p className="text-xs text-muted-foreground">
                A link kb. <strong>1 óráig</strong> érvényes. Kérd meg a felhasználót, hogy ellenőrizze a <strong>spam</strong> mappát is.
                Az új jelszót a <code>/reset-password</code> oldalon tudja beállítani.
              </p>
            )}
            {pwdMode === "direct" && (
              <div className="space-y-1">
                <Label>Új jelszó (min. 8 karakter)</Label>
                <Input type="text" autoComplete="new-password" value={pwdValue} onChange={(e) => setPwdValue(e.target.value)} placeholder="Új jelszó" />
                <p className="text-xs text-muted-foreground">Ha be van állítva email sablon, a felhasználó emailben is megkapja.</p>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setPwdUser(null)}>Mégse</Button>
            <Button onClick={submitPassword} disabled={pwdLoading || (pwdMode === "direct" && pwdValue.length < 8)}>
              {pwdLoading ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Send className="h-4 w-4 mr-1" />}
              {pwdMode === "link" ? "Link küldése" : "Jelszó beállítása"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AuthHealthDialog
        open={authHealthOpen}
        onOpenChange={setAuthHealthOpen}
        profiles={(profiles ?? []).map((p) => ({ user_id: p.user_id, full_name: p.full_name }))}
        recoveryMap={recoveryMap as any}
        roleCounts={roleCounts}
        onAction={handleAuthHealthAction}
      />
    </div>
  );
}
