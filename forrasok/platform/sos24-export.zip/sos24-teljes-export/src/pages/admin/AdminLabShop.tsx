import { useTranslation } from "react-i18next";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import LabPricingEditor from "@/components/LabPricingEditor";
import LabPackageEditor from "@/components/LabPackageEditor";
import AdminLabOrders from "./AdminLabOrders";
import { FlaskConical } from "lucide-react";

export default function AdminLabShop() {
  const { t } = useTranslation();

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <FlaskConical className="h-6 w-6 text-secondary" />
        <h1 className="text-2xl font-bold">Labor Webshop Kezelés</h1>
      </div>

      <Tabs defaultValue="orders">
        <TabsList>
          <TabsTrigger value="orders">Megrendelések</TabsTrigger>
          <TabsTrigger value="packages">Csomagok</TabsTrigger>
          <TabsTrigger value="pricing">Árazás</TabsTrigger>
        </TabsList>
        <TabsContent value="orders" className="mt-4">
          <AdminLabOrders />
        </TabsContent>
        <TabsContent value="packages" className="mt-4">
          <LabPackageEditor />
        </TabsContent>
        <TabsContent value="pricing" className="mt-4">
          <LabPricingEditor />
        </TabsContent>
      </Tabs>
    </div>
  );
}
