import { useState, useMemo } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { ClipboardList, Search, Eye, CheckCircle, Clock, XCircle, Truck, MapPin, Phone, Mail, Calendar, Printer } from "lucide-react";
import { printLabRequest } from "@/lib/printLabRequest";

interface LabOrder {
  id: string;
  order_number: string;
  customer_name: string;
  customer_email: string;
  customer_phone: string;
  ordered_tests: any[];
  sampling_type: string;
  location_id: string | null;
  home_address: string | null;
  preferred_date: string | null;
  notes: string | null;
  total_price_huf: number;
  status: string;
  created_at: string;
}

const statusConfig: Record<string, { label: string; color: string; icon: any }> = {
  pending:   { label: 'Új', color: 'bg-yellow-100 text-yellow-800 border-yellow-300', icon: Clock },
  confirmed: { label: 'Megerősítve', color: 'bg-blue-100 text-blue-800 border-blue-300', icon: CheckCircle },
  completed: { label: 'Kész', color: 'bg-green-100 text-green-800 border-green-300', icon: CheckCircle },
  cancelled: { label: 'Törölve', color: 'bg-red-100 text-red-800 border-red-300', icon: XCircle },
};

export default function AdminLabOrders() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [selectedOrder, setSelectedOrder] = useState<LabOrder | null>(null);

  const { data: orders, isLoading } = useQuery({
    queryKey: ["admin-lab-orders"],
    queryFn: async () => {
      const { data, error } = await (supabase as any)
        .from("lab_orders")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as LabOrder[];
    },
  });

  const updateStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const { error } = await (supabase as any).from("lab_orders").update({ status }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-lab-orders"] });
      toast({ title: "Státusz frissítve" });
    },
  });

  const filtered = useMemo(() => {
    let list = orders ?? [];
    if (filterStatus !== "all") list = list.filter(o => o.status === filterStatus);
    if (search) {
      const q = search.toLowerCase();
      list = list.filter(o =>
        o.customer_name.toLowerCase().includes(q) ||
        o.order_number.toLowerCase().includes(q) ||
        o.customer_email.toLowerCase().includes(q)
      );
    }
    return list;
  }, [orders, filterStatus, search]);

  if (isLoading) {
    return <div className="flex items-center justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <ClipboardList className="h-6 w-6 text-secondary" />
        <h1 className="text-2xl font-bold">Labor megrendelések</h1>
        <Badge variant="secondary">{(orders ?? []).length} rendelés</Badge>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Keresés név, szám, email…" value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
        </div>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-full sm:w-48"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Összes státusz</SelectItem>
            {Object.entries(statusConfig).map(([k, v]) => <SelectItem key={k} value={k}>{v.label}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <Card>
        <CardContent className="pt-6">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Szám</TableHead>
                <TableHead>Ügyfél</TableHead>
                <TableHead>Típus</TableHead>
                <TableHead>Vizsgálatok</TableHead>
                <TableHead>Összeg</TableHead>
                <TableHead>Státusz</TableHead>
                <TableHead>Dátum</TableHead>
                <TableHead className="w-20"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map(o => {
                const sc = statusConfig[o.status] || statusConfig.pending;
                const Icon = sc.icon;
                return (
                  <TableRow key={o.id}>
                    <TableCell className="font-mono text-xs">{o.order_number}</TableCell>
                    <TableCell>
                      <div className="text-sm font-medium">{o.customer_name}</div>
                      <div className="text-xs text-muted-foreground">{o.customer_email}</div>
                    </TableCell>
                    <TableCell>
                      {o.sampling_type === 'home' ? (
                        <Badge variant="outline" className="gap-1"><Truck className="w-3 h-3" /> Otthoni</Badge>
                      ) : (
                        <Badge variant="outline" className="gap-1"><MapPin className="w-3 h-3" /> Rendelő</Badge>
                      )}
                    </TableCell>
                    <TableCell>{o.ordered_tests?.length ?? 0} db</TableCell>
                    <TableCell className="font-medium">{o.total_price_huf?.toLocaleString('hu-HU')} Ft</TableCell>
                    <TableCell>
                      <Badge className={`${sc.color} border gap-1`}>
                        <Icon className="w-3 h-3" /> {sc.label}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {new Date(o.created_at).toLocaleDateString('hu-HU')}
                    </TableCell>
                    <TableCell>
                      <Button size="sm" variant="ghost" onClick={() => setSelectedOrder(o)}>
                        <Eye className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
              {filtered.length === 0 && (
                <TableRow>
                  <TableCell colSpan={8} className="text-center text-muted-foreground py-8">
                    Nincs találat
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={!!selectedOrder} onOpenChange={() => setSelectedOrder(null)}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Rendelés: {selectedOrder?.order_number}</DialogTitle>
            <DialogDescription>Részletek és státusz kezelés</DialogDescription>
          </DialogHeader>
          {selectedOrder && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="flex items-center gap-2"><Mail className="w-4 h-4 text-muted-foreground" />{selectedOrder.customer_email}</div>
                <div className="flex items-center gap-2"><Phone className="w-4 h-4 text-muted-foreground" />{selectedOrder.customer_phone}</div>
                <div className="flex items-center gap-2">
                  {selectedOrder.sampling_type === 'home' ? <Truck className="w-4 h-4 text-muted-foreground" /> : <MapPin className="w-4 h-4 text-muted-foreground" />}
                  {selectedOrder.sampling_type === 'home' ? 'Otthoni mintavétel' : 'Rendelői mintavétel'}
                </div>
                {selectedOrder.preferred_date && (
                  <div className="flex items-center gap-2"><Calendar className="w-4 h-4 text-muted-foreground" />{selectedOrder.preferred_date}</div>
                )}
              </div>
              {selectedOrder.home_address && (
                <div className="p-3 bg-muted/50 rounded-lg text-sm">
                  <span className="font-medium">Cím:</span> {selectedOrder.home_address}
                </div>
              )}
              <div>
                <p className="text-sm font-medium mb-2">Megrendelt vizsgálatok ({selectedOrder.ordered_tests?.length}):</p>
                <div className="space-y-1">
                  {(selectedOrder.ordered_tests ?? []).map((t: any, i: number) => (
                    <div key={i} className="flex items-center justify-between text-xs py-1 px-2 rounded bg-muted/30">
                      <span>{t.name || t.id}</span>
                      <span className="text-muted-foreground">{t.priceHuf?.toLocaleString('hu-HU')} Ft</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="flex items-center justify-between font-semibold text-sm border-t pt-3">
                <span>Összesen:</span>
                <span>{selectedOrder.total_price_huf?.toLocaleString('hu-HU')} Ft</span>
              </div>
              {selectedOrder.notes && (
                <div className="p-3 bg-muted/50 rounded-lg text-sm">
                  <span className="font-medium">Megjegyzés:</span> {selectedOrder.notes}
                </div>
              )}
              <Button variant="outline" size="sm" className="w-full gap-2" onClick={() => {
                const tests = (selectedOrder.ordered_tests ?? []).map((t: any) => ({
                  id: t.id, leCode: '', name: t.name || t.id, shortName: t.shortName || '', specialty: '', type: 'Elemi',
                  unit: '', ucumCode: '', oenoCode: '', loincCode: '', extraDataHint: '', sampleType: t.sampleType || 'Szérum', status: 'active' as const, points: 0, priceHuf: t.priceHuf || 0,
                }));
                printLabRequest({
                  requestNumber: selectedOrder.order_number,
                  patientName: selectedOrder.customer_name,
                  physicianName: 'SOS-24 Labor',
                  scheduledDate: selectedOrder.preferred_date ?? undefined,
                  priority: 'routine',
                  notes: selectedOrder.notes ?? undefined,
                  selectedTests: tests,
                  createdAt: selectedOrder.created_at,
                });
              }}>
                <Printer className="w-4 h-4" /> Kérőlap nyomtatása
              </Button>
              <div className="flex gap-2 flex-wrap">
                {['pending', 'confirmed', 'completed', 'cancelled'].map(s => {
                  const sc = statusConfig[s];
                  return (
                    <Button
                      key={s}
                      size="sm"
                      variant={selectedOrder.status === s ? 'default' : 'outline'}
                      disabled={selectedOrder.status === s}
                      onClick={() => {
                        updateStatus.mutate({ id: selectedOrder.id, status: s });
                        setSelectedOrder({ ...selectedOrder, status: s });
                      }}
                    >
                      {sc.label}
                    </Button>
                  );
                })}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
