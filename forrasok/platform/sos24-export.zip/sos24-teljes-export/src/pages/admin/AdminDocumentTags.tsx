import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, Tags } from "lucide-react";

export default function AdminDocumentTags() {
  const { t } = useTranslation();
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [label, setLabel] = useState("");
  const [sortOrder, setSortOrder] = useState(0);
  const [isActive, setIsActive] = useState(true);

  const { data: tags, isLoading } = useQuery({
    queryKey: ["document-tags"],
    queryFn: async () => {
      const { data, error } = await supabase.from("document_tags").select("*").order("sort_order", { ascending: true });
      if (error) throw error;
      return data;
    },
  });

  const upsert = useMutation({
    mutationFn: async () => {
      if (editId) {
        const { error } = await supabase.from("document_tags").update({ label, sort_order: sortOrder, is_active: isActive }).eq("id", editId);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("document_tags").insert({ label, sort_order: sortOrder, is_active: isActive });
        if (error) throw error;
      }
    },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["document-tags"] }); toast.success(editId ? t("admin.tagUpdated") : t("admin.tagCreated")); resetForm(); },
    onError: () => toast.error(t("admin.tagError")),
  });

  const deleteMut = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("document_tags").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["document-tags"] }); toast.success(t("admin.tagDeleted")); },
    onError: () => toast.error(t("admin.tagDeleteError")),
  });

  const resetForm = () => { setOpen(false); setEditId(null); setLabel(""); setSortOrder(0); setIsActive(true); };

  const startEdit = (tag: any) => { setEditId(tag.id); setLabel(tag.label); setSortOrder(tag.sort_order); setIsActive(tag.is_active); setOpen(true); };

  if (isLoading) {
    return <div className="flex justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" /></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Tags className="h-6 w-6 text-primary" />
          <h1 className="text-2xl font-bold">{t("admin.documentTagsTitle")}</h1>
        </div>
        <Dialog open={open} onOpenChange={(v) => { if (!v) resetForm(); else setOpen(true); }}>
          <DialogTrigger asChild>
            <Button><Plus className="h-4 w-4 mr-2" />{t("admin.newTag")}</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editId ? t("admin.editTag") : t("admin.newTag")}</DialogTitle>
            </DialogHeader>
            <form onSubmit={(e) => { e.preventDefault(); upsert.mutate(); }} className="space-y-4">
              <div className="space-y-2"><Label>{t("admin.labelName")}</Label><Input value={label} onChange={(e) => setLabel(e.target.value)} required /></div>
              <div className="space-y-2"><Label>{t("admin.sortOrder")}</Label><Input type="number" value={sortOrder} onChange={(e) => setSortOrder(Number(e.target.value))} /></div>
              <div className="flex items-center gap-2"><Switch checked={isActive} onCheckedChange={setIsActive} /><Label>{t("admin.active")}</Label></div>
              <Button type="submit" className="w-full" disabled={!label.trim() || upsert.isPending}>{editId ? t("common.save") : t("common.create")}</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader><CardTitle className="text-lg">{t("admin.tags")} ({tags?.length ?? 0})</CardTitle></CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-12">#</TableHead>
                <TableHead>{t("admin.labelName")}</TableHead>
                <TableHead>{t("admin.status")}</TableHead>
                <TableHead className="text-right">{t("common.actions")}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {(tags ?? []).map((tag) => (
                <TableRow key={tag.id}>
                  <TableCell className="text-muted-foreground">{tag.sort_order}</TableCell>
                  <TableCell className="font-medium">{tag.label}</TableCell>
                  <TableCell><Badge variant={tag.is_active ? "default" : "secondary"}>{tag.is_active ? t("admin.active") : t("admin.inactive")}</Badge></TableCell>
                  <TableCell className="text-right space-x-2">
                    <Button variant="ghost" size="icon" onClick={() => startEdit(tag)}><Pencil className="h-4 w-4" /></Button>
                    <Button variant="ghost" size="icon" onClick={() => deleteMut.mutate(tag.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                  </TableCell>
                </TableRow>
              ))}
              {(tags ?? []).length === 0 && (
                <TableRow><TableCell colSpan={4} className="text-center py-8 text-muted-foreground">{t("admin.noTags")}</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}