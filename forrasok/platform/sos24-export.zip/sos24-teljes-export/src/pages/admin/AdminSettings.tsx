import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Settings, Save, Loader2, Globe } from "lucide-react";
import { autoTranslateSiteSetting } from "@/lib/auto-translate-cms";

interface SettingRow {
  id: string;
  key: string;
  value: string | null;
  label: string | null;
  section: string | null;
}

export default function AdminSettings() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [edits, setEdits] = useState<Record<string, string>>({});
  const [autoTranslating, setAutoTranslating] = useState(false);
  const [autoTranslateLang, setAutoTranslateLang] = useState("");

  const { data: settings, isLoading } = useQuery({
    queryKey: ["admin-site-settings"],
    queryFn: async () => {
      const { data, error } = await supabase.from("site_settings").select("id, key, value, label, section").order("section").order("key");
      if (error) throw error;
      return data as SettingRow[];
    },
  });

  const saveMutation = useMutation({
    mutationFn: async ({ id, value }: { id: string; value: string }) => {
      const { error } = await supabase.from("site_settings").update({ value }).eq("id", id);
      if (error) throw error;
      return { id, value };
    },
    onSuccess: async ({ id, value }) => {
      qc.invalidateQueries({ queryKey: ["admin-site-settings"] });
      qc.invalidateQueries({ queryKey: ["site-settings"] });
      toast({ title: t("admin.settingSaved") });

      // Auto-translate in background
      if (value.trim()) {
        setAutoTranslating(true);
        const result = await autoTranslateSiteSetting(id, value, (lang) => setAutoTranslateLang(lang));
        setAutoTranslating(false);
        setAutoTranslateLang("");
        qc.invalidateQueries({ queryKey: ["content-translations"] });
        if (result.failed.length > 0) {
          toast({ title: "Fordítás részben kész", description: `${result.success} sikeres, ${result.failed.length} sikertelen`, variant: "destructive" });
        } else if (result.success > 0) {
          toast({ title: "✅ Automatikus fordítás kész", description: `${result.success} fordítás mentve (6 nyelv)` });
        }
      }
    },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  const sections = [...new Set((settings ?? []).map((s) => s.section ?? "general"))];

  const handleChange = (id: string, value: string) => setEdits((prev) => ({ ...prev, [id]: value }));

  const handleSave = (setting: SettingRow) => {
    const newValue = edits[setting.id] ?? setting.value ?? "";
    saveMutation.mutate({ id: setting.id, value: newValue });
    setEdits((prev) => { const next = { ...prev }; delete next[setting.id]; return next; });
  };

  if (isLoading) {
    return <div className="flex items-center justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>;
  }

  return (
    <div className="space-y-6">
      {autoTranslating && (
        <div className="flex items-center gap-3 rounded-lg border border-primary/30 bg-primary/5 p-3 text-sm animate-fade-in">
          <Loader2 className="h-4 w-4 animate-spin text-primary" />
          <Globe className="h-4 w-4 text-primary" />
          <span className="text-foreground">Automatikus fordítás folyamatban{autoTranslateLang ? ` (${autoTranslateLang.toUpperCase()})` : ''}…</span>
        </div>
      )}
      <div className="flex items-center gap-3">
        <Settings className="h-6 w-6 text-secondary" />
        <h1 className="text-2xl font-bold">{t("admin.settingsTitle")}</h1>
      </div>

      <Tabs defaultValue={sections[0]} className="w-full">
        <TabsList className="flex-wrap h-auto">
          {sections.map((sec) => (
            <TabsTrigger key={sec} value={sec} className="capitalize">{sec}</TabsTrigger>
          ))}
        </TabsList>

        {sections.map((sec) => (
          <TabsContent key={sec} value={sec}>
            <Card>
              <CardHeader><CardTitle className="text-lg capitalize">{sec}</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                {(settings ?? []).filter((s) => (s.section ?? "general") === sec).map((s) => (
                  <div key={s.id} className="flex items-end gap-3">
                    <div className="flex-1 space-y-1.5">
                      <Label htmlFor={s.id} className="text-sm">{s.label || s.key}</Label>
                      <Input id={s.id} value={edits[s.id] ?? s.value ?? ""} onChange={(e) => handleChange(s.id, e.target.value)} />
                    </div>
                    <Button size="sm" onClick={() => handleSave(s)} disabled={saveMutation.isPending || (edits[s.id] === undefined && true) || edits[s.id] === s.value}>
                      <Save className="h-4 w-4 mr-1" />{t("common.save")}
                    </Button>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}