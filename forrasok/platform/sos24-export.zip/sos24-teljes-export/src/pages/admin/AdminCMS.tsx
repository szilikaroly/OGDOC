import { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import WysiwygEditor from "@/components/WysiwygEditor";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { FileText, Plus, Pencil, Trash2, Image, Languages, Loader2, Globe } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { autoTranslatePageContent } from "@/lib/auto-translate-cms";
import { sanitizeRichHtml } from "@/lib/sanitize-html";


interface PageContent {
  id: string;
  page_key: string;
  section: string;
  content: string | null;
  content_json: any;
  is_active: boolean;
  sort_order: number;
}

interface StickyLogo {
  corner: "top-left" | "top-right" | "bottom-left" | "bottom-right";
  image_url: string;
  link_url: string;
  size: number;
  enabled: boolean;
}

const CORNERS = [
  { key: "top-left" as const, label: "Bal felső" },
  { key: "top-right" as const, label: "Jobb felső" },
  { key: "bottom-left" as const, label: "Bal alsó" },
  { key: "bottom-right" as const, label: "Jobb alsó" },
];

const defaultLogos: StickyLogo[] = CORNERS.map((c) => ({
  corner: c.key,
  image_url: "",
  link_url: "",
  size: 64,
  enabled: false,
}));

const emptyForm = {
  page_key: "",
  section: "",
  content: "",
  content_json: "",
  is_active: true,
  sort_order: 0,
};

// ─── Sticky Logos Editor ───────────────────────────────
function StickyLogosEditor() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [logos, setLogos] = useState<StickyLogo[]>(defaultLogos);

  const { data: existing, isLoading } = useQuery({
    queryKey: ["sticky-logos-admin"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("site_settings")
        .select("id, value_json")
        .eq("key", "sticky_logos")
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  useEffect(() => {
    if (existing?.value_json) {
      const saved = existing.value_json as unknown as StickyLogo[];
      // Merge with defaults so all 4 corners exist
      const merged = CORNERS.map((c) => {
        const found = saved.find((s) => s.corner === c.key);
        return found ?? { corner: c.key, image_url: "", link_url: "", size: 64, enabled: false };
      });
      setLogos(merged);
    }
  }, [existing]);

  const save = useMutation({
    mutationFn: async () => {
      if (existing?.id) {
        const { error } = await supabase
          .from("site_settings")
          .update({ value_json: logos as any, updated_at: new Date().toISOString() })
          .eq("id", existing.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("site_settings").insert({
          key: "sticky_logos",
          label: "Sticky logók",
          section: "design",
          value_json: logos as any,
        });
        if (error) throw error;
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["sticky-logos-admin"] });
      qc.invalidateQueries({ queryKey: ["sticky-logos"] });
      toast({ title: "Sticky logók mentve" });
    },
    onError: (e: any) => toast({ variant: "destructive", title: "Hiba", description: e.message }),
  });

  const update = (corner: string, patch: Partial<StickyLogo>) => {
    setLogos((prev) => prev.map((l) => (l.corner === corner ? { ...l, ...patch } : l)));
  };

  if (isLoading) return null;

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Image className="h-5 w-5 text-secondary" />
          <CardTitle className="text-lg">Sticky logók (sarkok)</CardTitle>
        </div>
        <CardDescription>Maximum 4 logó, sarkonként beállítható. A logók a főoldalon jelennek meg fixálva.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {logos.map((logo) => {
            const cornerLabel = CORNERS.find((c) => c.key === logo.corner)?.label ?? logo.corner;
            return (
              <Card key={logo.corner} className={`transition-opacity ${logo.enabled ? "" : "opacity-60"}`}>
                <CardContent className="pt-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-sm">{cornerLabel}</span>
                    <div className="flex items-center gap-2">
                      <Label className="text-xs">Aktív</Label>
                      <Switch checked={logo.enabled} onCheckedChange={(v) => update(logo.corner, { enabled: v })} />
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs">Kép URL</Label>
                    <Input
                      value={logo.image_url}
                      onChange={(e) => update(logo.corner, { image_url: e.target.value })}
                      placeholder="https://example.com/logo.png"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs">Link URL (opcionális)</Label>
                    <Input
                      value={logo.link_url}
                      onChange={(e) => update(logo.corner, { link_url: e.target.value })}
                      placeholder="https://example.com"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs">Méret (px): {logo.size}</Label>
                    <Input
                      type="range"
                      min={32}
                      max={128}
                      step={8}
                      value={logo.size}
                      onChange={(e) => update(logo.corner, { size: parseInt(e.target.value) })}
                      className="cursor-pointer"
                    />
                  </div>
                  {logo.image_url && (
                    <div className="flex justify-center p-2 rounded bg-muted/50">
                      <img src={logo.image_url} alt="" style={{ width: logo.size, height: logo.size }} className="object-contain" />
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
        <Button onClick={() => save.mutate()} disabled={save.isPending} className="w-full">
          {save.isPending ? "Mentés..." : "Sticky logók mentése"}
        </Button>
      </CardContent>
    </Card>
  );
}

// ─── Main CMS Page ─────────────────────────────────────
export default function AdminCMS() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [editing, setEditing] = useState<PageContent | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [translateDialogOpen, setTranslateDialogOpen] = useState(false);
  const [translateTarget, setTranslateTarget] = useState<PageContent | null>(null);
  const [translateLang, setTranslateLang] = useState("en");
  const [translatedContent, setTranslatedContent] = useState("");
  const [translatedJson, setTranslatedJson] = useState("");
  const [autoTranslating, setAutoTranslating] = useState(false);
  const [autoTranslateLang, setAutoTranslateLang] = useState("");

  const { data: pages, isLoading } = useQuery({
    queryKey: ["admin-pages-content"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("pages_content")
        .select("*")
        .order("page_key")
        .order("sort_order");
      if (error) throw error;
      return data as PageContent[];
    },
  });

  const upsert = useMutation({
    mutationFn: async (values: typeof form & { id?: string }): Promise<string> => {
      let contentJson = null;
      if (values.content_json) {
        try {
          contentJson = JSON.parse(values.content_json);
        } catch {
          throw new Error("Érvénytelen JSON formátum");
        }
      }

      const row = {
        page_key: values.page_key,
        section: values.section,
        content: values.content || null,
        content_json: contentJson,
        is_active: values.is_active,
        sort_order: values.sort_order,
      };

      if (values.id) {
        const { error } = await supabase.from("pages_content").update(row).eq("id", values.id);
        if (error) throw error;
        return values.id;
      } else {
        const { data, error } = await supabase.from("pages_content").insert(row).select("id").single();
        if (error) throw error;
        return data.id;
      }
    },
    onSuccess: async (recordId: string) => {
      qc.invalidateQueries({ queryKey: ["admin-pages-content"] });
      qc.invalidateQueries({ queryKey: ["pages-content"] });
      toast({ title: editing ? "Tartalom frissítve" : "Tartalom létrehozva" });

      const savedContent = form.content || null;
      const savedJson = form.content_json ? (() => { try { return JSON.parse(form.content_json); } catch { return null; } })() : null;

      setDialogOpen(false);
      setEditing(null);
      setForm(emptyForm);

      // Auto-translate in background
      if (savedContent || savedJson) {
        setAutoTranslating(true);
        setAutoTranslateLang("");
        const result = await autoTranslatePageContent(recordId, savedContent, savedJson, (lang) => setAutoTranslateLang(lang));
        setAutoTranslating(false);
        setAutoTranslateLang("");
        qc.invalidateQueries({ queryKey: ["content-translations"] });
        if (result.failed.length > 0) {
          toast({ title: `Fordítás részben kész`, description: `${result.success} sikeres, ${result.failed.length} sikertelen`, variant: "destructive" });
        } else if (result.success > 0) {
          toast({ title: `✅ Automatikus fordítás kész`, description: `${result.success} fordítás mentve (6 nyelv)` });
        }
      }
    },
    onError: (e: any) => {
      toast({ variant: "destructive", title: "Hiba", description: e.message });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("pages_content").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-pages-content"] });
      toast({ title: "Tartalom törölve" });
    },
    onError: (e: any) => {
      toast({ variant: "destructive", title: "Hiba", description: e.message });
    },
  });

  const openEdit = (p: PageContent) => {
    setEditing(p);
    setForm({
      page_key: p.page_key,
      section: p.section,
      content: p.content ?? "",
      content_json: p.content_json ? JSON.stringify(p.content_json, null, 2) : "",
      is_active: p.is_active,
      sort_order: p.sort_order,
    });
    setDialogOpen(true);
  };

  const openNew = () => {
    setEditing(null);
    setForm(emptyForm);
    setDialogOpen(true);
  };

  const TRANSLATE_LANGS = [
    { value: "hu", label: "Magyar" },
    { value: "en", label: "English" },
    { value: "de", label: "Deutsch" },
    { value: "ro", label: "Română" },
    { value: "sr", label: "Srpski" },
    { value: "zh", label: "中文" },
    { value: "fil", label: "Filipino" },
  ];

  const translateMutation = useMutation({
    mutationFn: async ({ content, contentJson, lang }: { content: string | null; contentJson: any; lang: string }) => {
      const results: { translated?: string; translatedJson?: string } = {};

      if (content) {
        const { data, error } = await supabase.functions.invoke("ai-translate", {
          body: { text: content, target_language: lang, is_html: true },
        });
        if (error) throw error;
        results.translated = data.translated;
      }

      if (contentJson) {
        const jsonStr = typeof contentJson === "string" ? contentJson : JSON.stringify(contentJson, null, 2);
        const { data, error } = await supabase.functions.invoke("ai-translate", {
          body: { text: jsonStr, target_language: lang, is_html: false },
        });
        if (error) throw error;
        results.translatedJson = data.translated;
      }

      return results;
    },
    onSuccess: (data) => {
      setTranslatedContent(data.translated ?? "");
      setTranslatedJson(data.translatedJson ?? "");
      toast({ title: "Fordítás kész!" });
    },
    onError: (e: any) => toast({ variant: "destructive", title: "Fordítási hiba", description: e.message }),
  });

  const openTranslate = (p: PageContent) => {
    setTranslateTarget(p);
    setTranslatedContent("");
    setTranslatedJson("");
    setTranslateLang("en");
    setTranslateDialogOpen(true);
  };

  const saveTranslation = () => {
    if (!translateTarget) return;
    const newPageKey = `${translateTarget.page_key}_${translateLang}`;
    setEditing(null);
    setForm({
      page_key: newPageKey,
      section: translateTarget.section,
      content: translatedContent,
      content_json: translatedJson,
      is_active: translateTarget.is_active,
      sort_order: translateTarget.sort_order,
    });
    setTranslateDialogOpen(false);
    setDialogOpen(true);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {autoTranslating && (
        <div className="flex items-center gap-3 rounded-lg border border-primary/30 bg-primary/5 p-3 text-sm animate-fade-in">
          <Loader2 className="h-4 w-4 animate-spin text-primary" />
          <Globe className="h-4 w-4 text-primary" />
          <span className="text-foreground">Automatikus fordítás folyamatban{autoTranslateLang ? ` (${autoTranslateLang.toUpperCase()})` : ''}…</span>
        </div>
      )}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <FileText className="h-6 w-6 text-secondary" />
          <h1 className="text-2xl font-bold">Tartalom kezelés (CMS)</h1>
        </div>
        <Button onClick={openNew}>
          <Plus className="h-4 w-4 mr-2" />
          Új tartalom
        </Button>
      </div>

      {/* Sticky Logos Section */}
      <StickyLogosEditor />

      <Card>
        <CardContent className="overflow-x-auto pt-6">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Oldal</TableHead>
                <TableHead>Szekció</TableHead>
                <TableHead>Tartalom</TableHead>
                <TableHead>Sorrend</TableHead>
                <TableHead>Aktív</TableHead>
                <TableHead className="w-24">Művelet</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {(pages ?? []).map((p) => (
                <TableRow key={p.id}>
                  <TableCell className="font-medium">{p.page_key}</TableCell>
                  <TableCell>{p.section}</TableCell>
                  <TableCell className="max-w-[200px] truncate text-sm text-muted-foreground">
                    {p.content || (p.content_json ? "JSON" : "—")}
                  </TableCell>
                  <TableCell>{p.sort_order}</TableCell>
                  <TableCell>
                    <span className={p.is_active ? "text-green-500" : "text-muted-foreground"}>
                      {p.is_active ? "Igen" : "Nem"}
                    </span>
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      <Button size="sm" variant="ghost" onClick={() => openEdit(p)}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => openTranslate(p)} title="Fordítás">
                        <Languages className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-destructive hover:text-destructive"
                        onClick={() => deleteMutation.mutate(p.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing ? "Tartalom szerkesztése" : "Új tartalom"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>Oldal kulcs</Label>
                <Input
                  value={form.page_key}
                  onChange={(e) => setForm((f) => ({ ...f, page_key: e.target.value }))}
                  placeholder="home"
                />
              </div>
              <div className="space-y-1.5">
                <Label>Szekció</Label>
                <Input
                  value={form.section}
                  onChange={(e) => setForm((f) => ({ ...f, section: e.target.value }))}
                  placeholder="hero"
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Tartalom (WYSIWYG)</Label>
              <WysiwygEditor
                content={form.content}
                onChange={(html) => setForm((f) => ({ ...f, content: html }))}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Tartalom (JSON)</Label>
              <Textarea
                value={form.content_json}
                onChange={(e) => setForm((f) => ({ ...f, content_json: e.target.value }))}
                rows={8}
                className="font-mono text-sm"
                placeholder='{"title": "...", "description": "..."}'
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>Sorrend</Label>
                <Input
                  type="number"
                  value={form.sort_order}
                  onChange={(e) => setForm((f) => ({ ...f, sort_order: parseInt(e.target.value) || 0 }))}
                />
              </div>
              <div className="flex items-center gap-2 pt-6">
                <Switch
                  checked={form.is_active}
                  onCheckedChange={(v) => setForm((f) => ({ ...f, is_active: v }))}
                />
                <Label>Aktív</Label>
              </div>
            </div>
            <Button
              className="w-full"
              onClick={() => upsert.mutate({ ...form, id: editing?.id })}
              disabled={upsert.isPending || !form.page_key || !form.section}
            >
              {editing ? "Mentés" : "Létrehozás"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Translate Dialog */}
      <Dialog open={translateDialogOpen} onOpenChange={setTranslateDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Languages className="h-5 w-5" />
              AI fordítás
            </DialogTitle>
          </DialogHeader>
          {translateTarget && (
            <div className="space-y-4">
              <div className="rounded-md bg-muted p-3 text-sm">
                <strong>{translateTarget.page_key}</strong> / {translateTarget.section}
              </div>

              <div className="flex items-end gap-3">
                <div className="flex-1 space-y-1.5">
                  <Label>Célnyelv</Label>
                  <Select value={translateLang} onValueChange={setTranslateLang}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {TRANSLATE_LANGS.map((l) => (
                        <SelectItem key={l.value} value={l.value}>{l.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <Button
                  onClick={() => translateMutation.mutate({
                    content: translateTarget.content,
                    contentJson: translateTarget.content_json,
                    lang: translateLang,
                  })}
                  disabled={translateMutation.isPending}
                >
                  {translateMutation.isPending ? (
                    <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Fordítás...</>
                  ) : (
                    <><Languages className="h-4 w-4 mr-2" />Fordítás</>
                  )}
                </Button>
              </div>

              {translatedContent && (
                <div className="space-y-1.5">
                  <Label>Lefordított tartalom (HTML)</Label>
                  <div
                    className="rounded-md border p-3 prose prose-sm max-w-none bg-background"
                    dangerouslySetInnerHTML={{ __html: sanitizeRichHtml(translatedContent) }}
                  />
                </div>
              )}

              {translatedJson && (
                <div className="space-y-1.5">
                  <Label>Lefordított tartalom (JSON/szöveg)</Label>
                  <Textarea
                    value={translatedJson}
                    onChange={(e) => setTranslatedJson(e.target.value)}
                    rows={6}
                    className="font-mono text-sm"
                  />
                </div>
              )}

              {(translatedContent || translatedJson) && (
                <Button className="w-full" onClick={saveTranslation}>
                  Mentés új tartalomként ({translateTarget.page_key}_{translateLang})
                </Button>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
