import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Mail, Eye, RefreshCw, Code, Edit3, Send, Stethoscope, FlaskConical, CalendarHeart, FileText, Bell } from "lucide-react";
import { toast } from "sonner";

interface TemplatePreview {
  templateName: string;
  displayName: string;
  subject: string;
  html: string;
  previewData: Record<string, string>;
  error?: string;
}

const TEMPLATE_CATEGORIES: Record<string, { label: string; icon: React.ReactNode; templates: string[] }> = {
  appointment: {
    label: "Időpont",
    icon: <Stethoscope className="h-4 w-4" />,
    templates: ["appointment-confirmed"],
  },
  medical: {
    label: "Orvosi",
    icon: <FileText className="h-4 w-4" />,
    templates: ["opinion-ready", "referral-received", "medication-response", "prescription-ready"],
  },
  lab: {
    label: "Labor",
    icon: <FlaskConical className="h-4 w-4" />,
    templates: ["lab-control-reminder"],
  },
  events: {
    label: "Események",
    icon: <CalendarHeart className="h-4 w-4" />,
    templates: ["health-day-invitation"],
  },
  general: {
    label: "Egyedi",
    icon: <Bell className="h-4 w-4" />,
    templates: ["general-notification"],
  },
};

export default function AdminEmailTemplates() {
  const { t } = useTranslation();
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null);
  const [customData, setCustomData] = useState<Record<string, string>>({});
  const [viewMode, setViewMode] = useState<"preview" | "source">("preview");
  const [testEmail, setTestEmail] = useState("");
  const [showTestSend, setShowTestSend] = useState(false);

  const { data: templates, isLoading, refetch } = useQuery({
    queryKey: ["email-templates"],
    queryFn: async () => {
      const { data, error } = await supabase.functions.invoke("admin-preview-email", {
        body: {},
      });
      if (error) throw error;
      return (data as { templates: TemplatePreview[] }).templates;
    },
  });

  const renderMutation = useMutation({
    mutationFn: async ({ templateName, templateData }: { templateName: string; templateData: Record<string, string> }) => {
      const { data, error } = await supabase.functions.invoke("admin-preview-email", {
        body: { templateName, templateData },
      });
      if (error) throw error;
      return data as TemplatePreview;
    },
    onSuccess: (data) => {
      setSelectedTemplate(data.templateName);
      toast.success(t("email.rerendered"));
    },
    onError: (err) => {
      toast.error(t("common.error") + ": " + (err as Error).message);
    },
  });

  const sendTestMutation = useMutation({
    mutationFn: async ({ templateName, recipientEmail, templateData }: { templateName: string; recipientEmail: string; templateData: Record<string, string> }) => {
      const { data, error } = await supabase.functions.invoke("send-transactional-email", {
        body: {
          templateName,
          recipientEmail,
          idempotencyKey: `test-${templateName}-${Date.now()}`,
          templateData,
        },
      });
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      toast.success(t("email.sent"));
      setShowTestSend(false);
      setTestEmail("");
    },
    onError: (err) => {
      toast.error(t("email.sendError") + ": " + (err as Error).message);
    },
  });

  const selected = templates?.find((t) => t.templateName === selectedTemplate);

  const handleSelectTemplate = (name: string) => {
    const tpl = templates?.find((t) => t.templateName === name);
    setSelectedTemplate(name);
    setCustomData(tpl?.previewData || {});
    setViewMode("preview");
    setShowTestSend(false);
  };

  const handleRerender = () => {
    if (!selectedTemplate) return;
    renderMutation.mutate({ templateName: selectedTemplate, templateData: customData });
  };

  const handleSendTest = () => {
    if (!selectedTemplate || !testEmail) return;
    sendTestMutation.mutate({
      templateName: selectedTemplate,
      recipientEmail: testEmail,
      templateData: customData,
    });
  };

  const renderedHtml = renderMutation.data?.templateName === selectedTemplate
    ? renderMutation.data.html
    : selected?.html;

  const renderedSubject = renderMutation.data?.templateName === selectedTemplate
    ? renderMutation.data.subject
    : selected?.subject;

  const getCategorizedTemplates = () => {
    if (!templates) return [];
    const categorized: { category: string; label: string; icon: React.ReactNode; items: TemplatePreview[] }[] = [];
    const assigned = new Set<string>();

    for (const [catKey, catDef] of Object.entries(TEMPLATE_CATEGORIES)) {
      const items = catDef.templates
        .map((name) => templates.find((t) => t.templateName === name))
        .filter(Boolean) as TemplatePreview[];
      if (items.length > 0) {
        categorized.push({ category: catKey, label: catDef.label, icon: catDef.icon, items });
        items.forEach((i) => assigned.add(i.templateName));
      }
    }

    const uncategorized = templates.filter((t) => !assigned.has(t.templateName));
    if (uncategorized.length > 0) {
      categorized.push({ category: "other", label: "Egyéb", icon: <Mail className="h-4 w-4" />, items: uncategorized });
    }

    return categorized;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Mail className="h-6 w-6" />
            {t("email.templates")}
          </h1>
          <p className="text-muted-foreground mt-1">{t("email.templatesDesc")}</p>
        </div>
        <Button variant="outline" size="sm" onClick={() => refetch()}>
          <RefreshCw className="h-4 w-4 mr-2" />
          {t("email.refresh")}
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Template list by category */}
        <div className="lg:col-span-4 space-y-4">
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">
            {t("email.templatesCount")} ({templates?.length ?? 0})
          </h2>
          {isLoading ? (
            Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-20 w-full" />
            ))
          ) : (
            getCategorizedTemplates().map((group) => (
              <div key={group.category} className="space-y-2">
                <div className="flex items-center gap-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider px-1">
                  {group.icon}
                  {group.label}
                </div>
                {group.items.map((tpl) => (
                  <Card
                    key={tpl.templateName}
                    className={`cursor-pointer transition-all hover:shadow-md ${
                      selectedTemplate === tpl.templateName ? "ring-2 ring-primary shadow-md" : ""
                    }`}
                    onClick={() => handleSelectTemplate(tpl.templateName)}
                  >
                    <CardContent className="p-3">
                      <div className="flex items-start justify-between">
                        <div className="min-w-0">
                          <p className="font-medium text-sm truncate">{tpl.displayName}</p>
                          <p className="text-xs text-muted-foreground mt-0.5 truncate">{tpl.subject}</p>
                        </div>
                        {tpl.error ? (
                          <Badge variant="destructive" className="shrink-0 ml-2 text-[10px]">{t("email.errorBadge")}</Badge>
                        ) : null}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ))
          )}
        </div>

        {/* Preview & editor */}
        <div className="lg:col-span-8">
          {!selectedTemplate ? (
            <Card className="h-96 flex items-center justify-center">
              <div className="text-center text-muted-foreground">
                <Mail className="h-12 w-12 mx-auto mb-3 opacity-30" />
                <p>{t("email.selectTemplate")}</p>
              </div>
            </Card>
          ) : (
            <div className="space-y-4">
              {/* Subject line */}
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 text-sm">
                    <span className="font-semibold text-muted-foreground">{t("email.subject")}:</span>
                    <span>{renderedSubject}</span>
                  </div>
                </CardContent>
              </Card>

              <Tabs value={viewMode} onValueChange={(v) => setViewMode(v as "preview" | "source")}>
                <div className="flex items-center justify-between">
                  <TabsList>
                    <TabsTrigger value="preview" className="gap-1.5">
                      <Eye className="h-4 w-4" /> {t("email.preview")}
                    </TabsTrigger>
                    <TabsTrigger value="source" className="gap-1.5">
                      <Code className="h-4 w-4" /> {t("email.htmlSource")}
                    </TabsTrigger>
                  </TabsList>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowTestSend(!showTestSend)}
                  >
                    <Send className="h-4 w-4 mr-2" />
                    {t("email.sendTest")}
                  </Button>
                </div>

                <TabsContent value="preview" className="mt-3">
                  <Card>
                    <CardContent className="p-0">
                      <iframe
                        srcDoc={renderedHtml || ""}
                        className="w-full border-0 rounded-lg"
                        style={{ minHeight: 500 }}
                        title={t("email.preview")}
                        sandbox="allow-same-origin"
                      />
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="source" className="mt-3">
                  <Card>
                    <CardContent className="p-4">
                      <pre className="text-xs overflow-auto max-h-[500px] bg-muted p-4 rounded-md">
                        <code>{renderedHtml || ""}</code>
                      </pre>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>

              {/* Test email send panel */}
              {showTestSend && (
                <Card className="border-primary/30 bg-primary/5">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base flex items-center gap-2">
                      <Send className="h-4 w-4" />
                      {t("email.sendTest")}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <p className="text-xs text-muted-foreground">{t("email.sendTestDesc")}</p>
                    <div className="flex items-end gap-3">
                      <div className="flex-1 space-y-1">
                        <Label className="text-xs">{t("email.recipientEmail")}</Label>
                        <Input
                          type="email"
                          value={testEmail}
                          onChange={(e) => setTestEmail(e.target.value)}
                          placeholder="test@example.com"
                          className="text-sm"
                        />
                      </div>
                      <Button
                        onClick={handleSendTest}
                        disabled={sendTestMutation.isPending || !testEmail}
                      >
                        {sendTestMutation.isPending ? (
                          <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                        ) : (
                          <Send className="h-4 w-4 mr-2" />
                        )}
                        {sendTestMutation.isPending ? t("email.sending") : t("common.send")}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Template data editor */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Edit3 className="h-4 w-4" />
                    {t("email.editData")}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-xs text-muted-foreground">{t("email.editDataDesc")}</p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {Object.entries(customData).map(([key, value]) => (
                      <div key={key} className="space-y-1">
                        <Label className="text-xs font-mono">{key}</Label>
                        <Input
                          value={value}
                          onChange={(e) =>
                            setCustomData((prev) => ({ ...prev, [key]: e.target.value }))
                          }
                          className="text-sm"
                        />
                      </div>
                    ))}
                  </div>
                  <AddFieldRow
                    onAdd={(key, value) => setCustomData((prev) => ({ ...prev, [key]: value }))}
                    t={t}
                  />
                  <Button
                    onClick={handleRerender}
                    disabled={renderMutation.isPending}
                    className="w-full sm:w-auto"
                  >
                    {renderMutation.isPending ? (
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                    ) : (
                      <Eye className="h-4 w-4 mr-2" />
                    )}
                    {t("email.rerender")}
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function AddFieldRow({ onAdd, t }: { onAdd: (key: string, value: string) => void; t: (k: string) => string }) {
  const [newKey, setNewKey] = useState("");
  const [newValue, setNewValue] = useState("");

  const handleAdd = () => {
    if (!newKey.trim()) return;
    onAdd(newKey.trim(), newValue);
    setNewKey("");
    setNewValue("");
  };

  return (
    <div className="flex items-end gap-2">
      <div className="space-y-1 flex-1">
        <Label className="text-xs">{t("email.newFieldName")}</Label>
        <Input
          value={newKey}
          onChange={(e) => setNewKey(e.target.value)}
          placeholder="pl. patient_name"
          className="text-sm"
        />
      </div>
      <div className="space-y-1 flex-1">
        <Label className="text-xs">{t("email.fieldValue")}</Label>
        <Input
          value={newValue}
          onChange={(e) => setNewValue(e.target.value)}
          placeholder="pl. Kovács János"
          className="text-sm"
        />
      </div>
      <Button variant="outline" size="sm" onClick={handleAdd} disabled={!newKey.trim()}>
        {t("email.add")}
      </Button>
    </div>
  );
}
