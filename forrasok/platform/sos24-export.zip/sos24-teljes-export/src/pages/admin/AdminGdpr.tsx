import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { Shield, Check, X } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";

export default function AdminGdpr() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();

  const STATUS_LABELS: Record<string, string> = {
    pending: t("gdpr.pending"),
    processing: t("gdpr.processing"),
    completed: t("gdpr.completed"),
    rejected: t("gdpr.rejected"),
  };

  const STATUS_VARIANT: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
    pending: "outline", processing: "secondary", completed: "default", rejected: "destructive",
  };

  const { data: requests, isLoading } = useQuery({
    queryKey: ["admin-gdpr-requests"],
    queryFn: async () => {
      const { data, error } = await (supabase as any).from("gdpr_requests").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      const userIds = [...new Set((data as any[]).map((r: any) => r.user_id))];
      const { data: profiles } = await supabase.from("profiles").select("user_id, full_name").in("user_id", userIds);
      const nameMap: Record<string, string> = {};
      (profiles ?? []).forEach((p) => { nameMap[p.user_id] = p.full_name; });
      return (data as any[]).map((r: any) => ({ ...r, user_name: nameMap[r.user_id] ?? "—" }));
    },
  });

  const updateStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const { error } = await (supabase as any).from("gdpr_requests").update({ status, processed_by: user?.id, processed_at: new Date().toISOString() }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["admin-gdpr-requests"] }); toast({ title: t("common.success") }); },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Shield className="h-6 w-6 text-secondary" />
        <h1 className="text-2xl font-bold">{t("admin.gdprTitle")}</h1>
      </div>

      <Card>
        <CardContent className="overflow-x-auto pt-6">
          {isLoading ? (
            <div className="flex justify-center py-8"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>
          ) : (requests ?? []).length === 0 ? (
            <p className="text-muted-foreground text-center py-8">{t("admin.noGdprRequest")}</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t("admin.user")}</TableHead>
                  <TableHead>{t("common.status")}</TableHead>
                  <TableHead>{t("common.status")}</TableHead>
                  <TableHead>{t("common.date")}</TableHead>
                  <TableHead>{t("common.actions")}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {(requests ?? []).map((r: any) => (
                  <TableRow key={r.id}>
                    <TableCell className="font-medium">{r.user_name}</TableCell>
                    <TableCell>{r.type === "export" ? t("admin.dataExport") : t("admin.dataDeletion")}</TableCell>
                    <TableCell><Badge variant={STATUS_VARIANT[r.status] ?? "outline"}>{STATUS_LABELS[r.status] ?? r.status}</Badge></TableCell>
                    <TableCell>{new Date(r.created_at).toLocaleDateString("hu-HU")}</TableCell>
                    <TableCell>
                      {r.status === "pending" && (
                        <div className="flex gap-1">
                          <Button size="sm" variant="outline" onClick={() => updateStatus.mutate({ id: r.id, status: "processing" })}>{t("admin.processing")}</Button>
                          <Button size="sm" variant="ghost" className="text-destructive" onClick={() => updateStatus.mutate({ id: r.id, status: "rejected" })}><X className="h-4 w-4" /></Button>
                        </div>
                      )}
                      {r.status === "processing" && (
                        <Button size="sm" onClick={() => updateStatus.mutate({ id: r.id, status: "completed" })}><Check className="h-4 w-4 mr-1" /> {t("admin.done")}</Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}