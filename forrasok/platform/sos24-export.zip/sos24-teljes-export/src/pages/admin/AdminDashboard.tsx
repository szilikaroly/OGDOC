import { useTranslation } from "react-i18next";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/contexts/AuthContext";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Users, Calendar, FileText, Activity, Building2, MessageSquare } from "lucide-react";
import { BarChart, Bar, PieChart, Pie, Cell, ResponsiveContainer, XAxis, YAxis, Tooltip } from "recharts";
import { format, subMonths, startOfMonth } from "date-fns";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

const RESULT_COLORS: Record<string, string> = {
  alkalmas: "hsl(var(--chart-2))",
  nem_alkalmas: "hsl(var(--chart-1))",
  feltetelesen_alkalmas: "hsl(var(--chart-3))",
  ideiglenes: "hsl(var(--chart-4))",
};

export default function AdminDashboard() {
  const { t } = useTranslation();
  const { profile } = useAuth();

  const RESULT_LABELS: Record<string, string> = {
    alkalmas: t("page.fit"),
    nem_alkalmas: t("page.unfit"),
    feltetelesen_alkalmas: t("page.conditionallyFit"),
    ideiglenes: t("page.temporary"),
  };

  const { data: userCount } = useQuery({
    queryKey: ["admin-stat-users"],
    queryFn: async () => {
      const { count } = await supabase.from("profiles").select("id", { count: "exact", head: true });
      return count ?? 0;
    },
  });

  const { data: todayAppointments } = useQuery({
    queryKey: ["admin-stat-appointments-today"],
    queryFn: async () => {
      const today = new Date().toISOString().split("T")[0];
      const { count } = await supabase.from("appointment_slots").select("id", { count: "exact", head: true }).gte("slot_start", `${today}T00:00:00`).lt("slot_start", `${today}T23:59:59`);
      return count ?? 0;
    },
  });

  const { data: activeServices } = useQuery({
    queryKey: ["admin-stat-services"],
    queryFn: async () => {
      const { count } = await supabase.from("services").select("id", { count: "exact", head: true }).eq("is_active", true);
      return count ?? 0;
    },
  });

  const { data: companyCount } = useQuery({
    queryKey: ["admin-stat-companies"],
    queryFn: async () => {
      const { count } = await supabase.from("companies").select("id", { count: "exact", head: true });
      return count ?? 0;
    },
  });

  const { data: pendingRequests } = useQuery({
    queryKey: ["admin-stat-pending-requests"],
    queryFn: async () => {
      const { count } = await supabase.from("requests").select("id", { count: "exact", head: true }).eq("status", "pending");
      return count ?? 0;
    },
  });

  const { data: unreadMessages } = useQuery({
    queryKey: ["admin-stat-unread-messages"],
    queryFn: async () => {
      const { count } = await supabase.from("messages").select("id", { count: "exact", head: true }).eq("is_read", false);
      return count ?? 0;
    },
  });

  const { data: monthlyExams } = useQuery({
    queryKey: ["admin-monthly-exams"],
    queryFn: async () => {
      const sixMonthsAgo = subMonths(new Date(), 6).toISOString();
      const { data } = await supabase.from("examinations").select("created_at").gte("created_at", sixMonthsAgo);
      const buckets: Record<string, number> = {};
      for (let i = 5; i >= 0; i--) {
        const m = format(subMonths(new Date(), i), "yyyy-MM");
        buckets[m] = 0;
      }
      data?.forEach((e) => {
        const m = e.created_at.substring(0, 7);
        if (buckets[m] !== undefined) buckets[m]++;
      });
      return Object.entries(buckets).map(([month, count]) => ({
        month: format(startOfMonth(new Date(month + "-01")), "MMM"),
        [t("page.exam")]: count,
      }));
    },
  });

  const { data: resultDist } = useQuery({
    queryKey: ["admin-result-dist"],
    queryFn: async () => {
      const { data } = await supabase.from("examinations").select("result");
      const counts: Record<string, number> = {};
      data?.forEach((e) => { counts[e.result] = (counts[e.result] || 0) + 1; });
      return Object.entries(counts).map(([name, value]) => ({ name: RESULT_LABELS[name] || name, value, color: RESULT_COLORS[name] || "hsl(var(--chart-5))" }));
    },
  });

  const { data: expiringExams } = useQuery({
    queryKey: ["admin-expiring-exams"],
    queryFn: async () => {
      const today = new Date().toISOString().split("T")[0];
      const in30 = new Date(Date.now() + 30 * 86400000).toISOString().split("T")[0];
      const { data } = await supabase.from("examinations").select("id, patient_id, valid_until, result, exam_type").not("valid_until", "is", null).lte("valid_until", in30).order("valid_until", { ascending: true }).limit(10);
      if (!data?.length) return [];
      const patientIds = [...new Set(data.map((e) => e.patient_id))];
      const { data: profiles } = await supabase.from("profiles").select("user_id, full_name").in("user_id", patientIds);
      const nameMap = Object.fromEntries(profiles?.map((p) => [p.user_id, p.full_name]) ?? []);
      return data.map((e) => ({
        ...e,
        patientName: nameMap[e.patient_id] || "—",
        expired: e.valid_until! < today,
      }));
    },
  });

  const stats = [
    { label: t("page.users"), icon: Users, value: userCount ?? "—" },
    { label: t("page.todayAppointments"), icon: Calendar, value: todayAppointments ?? "—" },
    { label: t("page.activeServices"), icon: FileText, value: activeServices ?? "—" },
    { label: t("page.companies"), icon: Building2, value: companyCount ?? "—" },
    { label: t("page.openRequests"), icon: Activity, value: pendingRequests ?? "—" },
    { label: t("page.unreadMessages"), icon: MessageSquare, value: unreadMessages ?? "—" },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">{t("page.welcomeUser", { name: profile?.full_name ?? "Admin" })}</h1>
        <p className="text-muted-foreground">{t("page.adminOverview")}</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {stats.map((s) => (
          <Card key={s.label} className="card-luxury">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">{s.label}</CardTitle>
              <s.icon className="h-5 w-5 text-secondary" />
            </CardHeader>
            <CardContent><p className="text-2xl font-bold">{s.value}</p></CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader><CardTitle className="text-base">{t("page.monthlyExams")}</CardTitle></CardHeader>
          <CardContent>
            {monthlyExams?.length ? (
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={monthlyExams}>
                  <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                  <YAxis allowDecimals={false} />
                  <Tooltip />
                  <Bar dataKey={t("page.exam")} fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : <p className="text-muted-foreground text-sm">{t("common.noData")}</p>}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">{t("page.fitnessDistribution")}</CardTitle></CardHeader>
          <CardContent>
            {resultDist?.length ? (
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie data={resultDist} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
                    {resultDist.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            ) : <p className="text-muted-foreground text-sm">{t("common.noData")}</p>}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">{t("page.expiringExams")}</CardTitle></CardHeader>
         <CardContent className="overflow-x-auto">
          {expiringExams?.length ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t("page.patient")}</TableHead>
                  <TableHead>{t("page.type")}</TableHead>
                  <TableHead>{t("page.result")}</TableHead>
                  <TableHead>{t("page.expiry")}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {expiringExams.map((e) => (
                  <TableRow key={e.id} className={e.expired ? "bg-destructive/10" : "bg-yellow-500/10"}>
                    <TableCell>{e.patientName}</TableCell>
                    <TableCell>{e.exam_type}</TableCell>
                    <TableCell><Badge variant={e.expired ? "destructive" : "secondary"}>{RESULT_LABELS[e.result] || e.result}</Badge></TableCell>
                    <TableCell>{e.valid_until}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : <p className="text-muted-foreground text-sm">{t("page.noExpiringExam")}</p>}
        </CardContent>
      </Card>
    </div>
  );
}
