import UzemorvosRiskAssessments from "@/pages/uzemorvos/UzemorvosRiskAssessments";

export default function AdminRiskAssessments() {
  return <UzemorvosRiskAssessments />;
}
