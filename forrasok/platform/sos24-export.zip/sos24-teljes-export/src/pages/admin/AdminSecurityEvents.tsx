import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { AlertTriangle, RefreshCw, ShieldAlert } from "lucide-react";
import { format } from "date-fns";
import { hu } from "date-fns/locale";

type SecurityEvent = {
  id: string;
  event_type: string;
  severity: "info" | "warn" | "error" | "critical";
  user_id: string | null;
  user_email: string | null;
  table_name: string | null;
  operation: string | null;
  error_code: string | null;
  error_message: string | null;
  route: string | null;
  user_agent: string | null;
  metadata: Record<string, unknown>;
  created_at: string;
  function_name: string | null;
  action: string | null;
  resource_type: string | null;
  resource_id: string | null;
  duration_ms: number | null;
  status_code: number | null;
};


const RANGES: Record<string, number> = {
  "1h": 60 * 60 * 1000,
  "24h": 24 * 60 * 60 * 1000,
  "7d": 7 * 24 * 60 * 60 * 1000,
  "30d": 30 * 24 * 60 * 60 * 1000,
};

const severityColor: Record<string, string> = {
  info: "bg-muted text-muted-foreground",
  warn: "bg-yellow-500/15 text-yellow-700 dark:text-yellow-400",
  error: "bg-orange-500/15 text-orange-700 dark:text-orange-400",
  critical: "bg-destructive/15 text-destructive",
};

export default function AdminSecurityEvents() {
  const [range, setRange] = useState<keyof typeof RANGES>("24h");
  const [severity, setSeverity] = useState<string>("all");
  const [eventType, setEventType] = useState<string>("all");
  const [search, setSearch] = useState("");

  const since = useMemo(
    () => new Date(Date.now() - RANGES[range]).toISOString(),
    [range],
  );

  const { data, isLoading, refetch, isFetching } = useQuery({
    queryKey: ["security-events", since, severity, eventType],
    queryFn: async () => {
      let q = (supabase as any)
        .from("security_events")
        .select("*")
        .gte("created_at", since)
        .order("created_at", { ascending: false })
        .limit(500);
      if (severity !== "all") q = q.eq("severity", severity);
      if (eventType !== "all") q = q.eq("event_type", eventType);
      const { data, error } = await q;
      if (error) throw error;
      return data as SecurityEvent[];
    },
    refetchInterval: 30_000,
  });

  const filtered = useMemo(() => {
    if (!data) return [];
    if (!search.trim()) return data;
    const s = search.toLowerCase();
    return data.filter(
      (e) =>
        (e.user_email ?? "").toLowerCase().includes(s) ||
        (e.error_message ?? "").toLowerCase().includes(s) ||
        (e.table_name ?? "").toLowerCase().includes(s) ||
        (e.route ?? "").toLowerCase().includes(s) ||
        (e.function_name ?? "").toLowerCase().includes(s) ||
        (e.action ?? "").toLowerCase().includes(s) ||
        (e.resource_type ?? "").toLowerCase().includes(s) ||
        (e.resource_id ?? "").toLowerCase().includes(s),
    );
  }, [data, search]);


  const stats = useMemo(() => {
    const list = data ?? [];
    const uniqueUsers = new Set(list.map((e) => e.user_id ?? "anon")).size;
    const alerts = list.filter(
      (e) => e.severity === "critical" || e.severity === "error",
    ).length;
    const rls = list.filter((e) => e.event_type === "rls_denied").length;
    return { total: list.length, uniqueUsers, alerts, rls };
  }, [data]);

  const eventTypes = useMemo(() => {
    const set = new Set((data ?? []).map((e) => e.event_type));
    return Array.from(set).sort();
  }, [data]);

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <ShieldAlert className="h-6 w-6 text-destructive" />
            Biztonsági események
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Megtagadott adatbázis-hozzáférések (RLS / permission denied) és
            riasztások.
          </p>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => refetch()}
          disabled={isFetching}
        >
          <RefreshCw
            className={`h-4 w-4 mr-2 ${isFetching ? "animate-spin" : ""}`}
          />
          Frissítés
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <StatCard label="Összes esemény" value={stats.total} />
        <StatCard label="RLS megtagadás" value={stats.rls} />
        <StatCard label="Érintett felhasználók" value={stats.uniqueUsers} />
        <StatCard
          label="Riasztások (error/critical)"
          value={stats.alerts}
          highlight={stats.alerts > 0}
        />
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Szűrők</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-4">
          <Select value={range} onValueChange={(v) => setRange(v as any)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1h">Utolsó 1 óra</SelectItem>
              <SelectItem value="24h">Utolsó 24 óra</SelectItem>
              <SelectItem value="7d">Utolsó 7 nap</SelectItem>
              <SelectItem value="30d">Utolsó 30 nap</SelectItem>
            </SelectContent>
          </Select>

          <Select value={severity} onValueChange={setSeverity}>
            <SelectTrigger>
              <SelectValue placeholder="Súlyosság" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Összes súlyosság</SelectItem>
              <SelectItem value="info">info</SelectItem>
              <SelectItem value="warn">warn</SelectItem>
              <SelectItem value="error">error</SelectItem>
              <SelectItem value="critical">critical</SelectItem>
            </SelectContent>
          </Select>

          <Select value={eventType} onValueChange={setEventType}>
            <SelectTrigger>
              <SelectValue placeholder="Típus" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Összes típus</SelectItem>
              {eventTypes.map((t) => (
                <SelectItem key={t} value={t}>
                  {t}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Input
            placeholder="Keresés (email, tábla, üzenet)…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">
            Események ({filtered.length})
          </CardTitle>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Idő</TableHead>
                <TableHead>Súlyosság</TableHead>
                <TableHead>Típus</TableHead>
                <TableHead>Felhasználó</TableHead>
                <TableHead>Edge function / művelet</TableHead>
                <TableHead>Erőforrás</TableHead>
                <TableHead>Státusz</TableHead>
                <TableHead>Tábla / művelet</TableHead>
                <TableHead>Hiba</TableHead>
                <TableHead>Útvonal</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={10} className="text-center py-8">
                    Betöltés…
                  </TableCell>
                </TableRow>
              ) : filtered.length === 0 ? (
                <TableRow>
                  <TableCell
                    colSpan={10}
                    className="text-center py-8 text-muted-foreground"
                  >
                    Nincs esemény ebben az időszakban.
                  </TableCell>
                </TableRow>
              ) : (
                filtered.map((e) => (
                  <TableRow key={e.id}>
                    <TableCell className="whitespace-nowrap text-xs">
                      {format(new Date(e.created_at), "yyyy-MM-dd HH:mm:ss", {
                        locale: hu,
                      })}
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant="outline"
                        className={severityColor[e.severity] ?? ""}
                      >
                        {e.severity}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-xs font-mono">
                      {e.event_type}
                    </TableCell>
                    <TableCell className="text-xs">
                      {e.user_email ?? (
                        <span className="text-muted-foreground italic">
                          névtelen
                        </span>
                      )}
                    </TableCell>
                    <TableCell className="text-xs">
                      {e.function_name ? (
                        <span className="font-mono">{e.function_name}</span>
                      ) : "—"}
                      {e.action ? ` · ${e.action}` : ""}
                      {typeof e.duration_ms === "number" ? (
                        <span className="text-muted-foreground"> ({e.duration_ms}ms)</span>
                      ) : null}
                    </TableCell>
                    <TableCell className="text-xs">
                      {e.resource_type ?? "—"}
                      {e.resource_id ? (
                        <div className="font-mono text-[10px] text-muted-foreground truncate max-w-[160px]" title={e.resource_id}>
                          {e.resource_id}
                        </div>
                      ) : null}
                    </TableCell>
                    <TableCell className="text-xs">
                      {typeof e.status_code === "number" ? (
                        <Badge variant={e.status_code >= 400 ? "destructive" : "secondary"}>
                          {e.status_code}
                        </Badge>
                      ) : "—"}
                    </TableCell>
                    <TableCell className="text-xs">
                      {e.table_name ?? "—"}
                      {e.operation ? ` · ${e.operation}` : ""}
                    </TableCell>
                    <TableCell className="text-xs max-w-md truncate" title={e.error_message ?? ""}>
                      {e.error_code ? (
                        <Badge variant="secondary" className="mr-1">
                          {e.error_code}
                        </Badge>
                      ) : null}
                      {e.error_message ?? "—"}
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {e.route ?? "—"}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>

          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-yellow-500" />
            Hogyan kerülnek ide események?
          </CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-muted-foreground space-y-2">
          <p>
            A frontend kódban használd a <code>reportSupabaseError(error, &#123;
            table, operation &#125;)</code> helpert (
            <code>src/lib/security-monitor.ts</code>) a Supabase hívások hiba
            ágában. Csak az RLS / permission denied jellegű hibákat naplózza,
            minden mást figyelmen kívül hagy.
          </p>
          <p>
            Egy háttér cron 5 percenként összesít: ha egy felhasználó több mint
            10 megtagadást generál 5 percen belül, <code>critical</code>{" "}
            riasztást szúr be, és e-mailt küld az összes super_admin
            felhasználónak.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

function StatCard({
  label,
  value,
  highlight,
}: {
  label: string;
  value: number;
  highlight?: boolean;
}) {
  return (
    <Card className={highlight ? "border-destructive" : ""}>
      <CardContent className="pt-6">
        <div className="text-xs text-muted-foreground">{label}</div>
        <div
          className={`text-2xl font-bold mt-1 ${
            highlight ? "text-destructive" : ""
          }`}
        >
          {value}
        </div>
      </CardContent>
    </Card>
  );
}
