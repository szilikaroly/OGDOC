import { useTranslation } from "react-i18next";
import { LayoutDashboard, Settings, Users, FileText, Calendar, MapPin, Clipboard, MessageSquare, Menu, Search, Building2, ClipboardCheck, Shield, ShieldCheck, ShieldAlert, Tags, Mail, Languages, Sparkles, FileOutput, AlertTriangle, FlaskConical, Megaphone, ShoppingCart, BookOpen } from "lucide-react";
import DashboardLayout, { type NavItem } from "@/components/DashboardLayout";
import { useUnreadMessages } from "@/hooks/use-unread-messages";

export default function AdminLayout() {
  const { t } = useTranslation();
  const unread = useUnreadMessages();
  const NAV: NavItem[] = [
    { title: t('dashboard.overview'), url: "/admin", icon: LayoutDashboard },
    { title: t('nav.users'), url: "/admin/users", icon: Users },
    { title: t('nav.companiesEmployers'), url: "/admin/companies", icon: Building2 },
    { title: t('dashboard.examinations'), url: "/admin/examinations", icon: ClipboardCheck },
    { title: t('nav.services'), url: "/admin/services", icon: Clipboard },
    { title: t('nav.activities'), url: "/admin/activities", icon: Sparkles },
    { title: t('nav.locations'), url: "/admin/locations", icon: MapPin },
    { title: t('dashboard.appointments'), url: "/admin/slots", icon: Calendar },
    { title: t('nav.cms'), url: "/admin/cms", icon: FileText },
    { title: t('nav.menuManagement'), url: "/admin/navigation", icon: Menu },
    { title: t('nav.seo'), url: "/admin/seo", icon: Search },
    { title: t('nav.aiTranslator'), url: "/admin/translate", icon: Languages },
    { title: t('dashboard.messages'), url: "/admin/messages", icon: MessageSquare, badge: unread },
    { title: t('nav.documentTags'), url: "/admin/document-tags", icon: Tags },
    { title: t('nav.emailTemplates'), url: "/admin/email-templates", icon: Mail },
    { title: t('admin.documentTemplates'), url: "/admin/document-templates", icon: FileOutput },
    { title: t('risk.riskAssessments'), url: "/admin/risk-assessments", icon: AlertTriangle },
    { title: t('substances.databaseTitle'), url: "/admin/substances", icon: FlaskConical },
    { title: "Marketing", url: "/admin/marketing", icon: Megaphone },
    { title: "Labor Webshop", url: "/admin/lab-shop", icon: ShoppingCart },
    { title: "BNO/ICD törzs", url: "/admin/icd-codes", icon: BookOpen },
    { title: t('nav.auditLog'), url: "/admin/audit-log", icon: Shield },
    { title: "Biztonsági események", url: "/admin/security-events", icon: ShieldAlert },
    { title: t('dashboard.gdpr'), url: "/admin/gdpr", icon: ShieldCheck },
    { title: t('common.settings'), url: "/admin/settings", icon: Settings },
  ];
  return <DashboardLayout navItems={NAV} groupLabel={t('nav.administration')} />;
}
