import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Shield, Search } from "lucide-react";

const ACTION_COLORS: Record<string, string> = {
  INSERT: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
  UPDATE: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
  DELETE: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
};

export default function AdminAuditLog() {
  const { t } = useTranslation();
  const [tableFilter, setTableFilter] = useState<string>("all");
  const [actionFilter, setActionFilter] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState("");

  const TABLE_LABELS: Record<string, string> = {
    examinations: t("dashboard.examinations"),
    medical_opinions: t("dashboard.opinions"),
    patient_cards: t("inner.patientCard"),
    documents: t("dashboard.documents"),
    referrals: t("dashboard.referrals"),
  };

  const { data: logs, isLoading } = useQuery({
    queryKey: ["audit-logs", tableFilter, actionFilter],
    queryFn: async () => {
      let query = supabase
        .from("audit_logs")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(200);

      if (tableFilter !== "all") query = query.eq("table_name", tableFilter);
      if (actionFilter !== "all") query = query.eq("action", actionFilter);

      const { data, error } = await query;
      if (error) throw error;

      const userIds = [...new Set((data ?? []).map((l: any) => l.user_id).filter(Boolean))];
      let nameMap: Record<string, string> = {};
      if (userIds.length > 0) {
        const { data: profiles } = await supabase
          .from("profiles")
          .select("user_id, full_name")
          .in("user_id", userIds);
        nameMap = Object.fromEntries((profiles ?? []).map((p) => [p.user_id, p.full_name]));
      }

      return (data ?? []).map((l: any) => ({ ...l, user_name: nameMap[l.user_id] ?? t("admin.system") }));
    },
  });

  const filtered = (logs ?? []).filter((l: any) => {
    if (!searchTerm) return true;
    const s = searchTerm.toLowerCase();
    return (
      l.user_name?.toLowerCase().includes(s) ||
      l.record_id?.toLowerCase().includes(s) ||
      (l.changed_fields ?? []).some((f: string) => f.toLowerCase().includes(s))
    );
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Shield className="h-6 w-6 text-secondary" />
        <h1 className="text-2xl font-bold">{t("admin.auditLogTitle")}</h1>
        <Badge variant="outline" className="ml-2">{filtered.length} {t("admin.entries")}</Badge>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">{t("admin.filters")}</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-4">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder={t("admin.searchByNameRecordField")}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={tableFilter} onValueChange={setTableFilter}>
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder={t("admin.table")} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t("admin.allTables")}</SelectItem>
              {Object.entries(TABLE_LABELS).map(([k, v]) => (
                <SelectItem key={k} value={k}>{v}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={actionFilter} onValueChange={setActionFilter}>
            <SelectTrigger className="w-[160px]">
              <SelectValue placeholder={t("admin.action")} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t("admin.allActions")}</SelectItem>
              <SelectItem value="INSERT">{t("admin.insertAction")}</SelectItem>
              <SelectItem value="UPDATE">{t("admin.updateAction")}</SelectItem>
              <SelectItem value="DELETE">{t("admin.deleteAction")}</SelectItem>
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="overflow-x-auto p-0">
          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" />
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t("admin.timestamp")}</TableHead>
                  <TableHead>{t("admin.user")}</TableHead>
                  <TableHead>{t("admin.table")}</TableHead>
                  <TableHead>{t("admin.action")}</TableHead>
                  <TableHead>{t("admin.changedFields")}</TableHead>
                  <TableHead>{t("admin.recordId")}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((log: any) => (
                  <TableRow key={log.id}>
                    <TableCell className="whitespace-nowrap text-sm">
                      {new Date(log.created_at).toLocaleString("hu-HU")}
                    </TableCell>
                    <TableCell className="font-medium">{log.user_name}</TableCell>
                    <TableCell>
                      <Badge variant="secondary">
                        {TABLE_LABELS[log.table_name] ?? log.table_name}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-semibold ${ACTION_COLORS[log.action] ?? ""}`}>
                        {log.action === "INSERT" ? t("admin.insertAction") : log.action === "UPDATE" ? t("admin.updateAction") : t("admin.deleteAction")}
                      </span>
                    </TableCell>
                    <TableCell className="max-w-[200px] truncate text-sm text-muted-foreground">
                      {(log.changed_fields ?? []).join(", ") || "—"}
                    </TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground">
                      {log.record_id?.substring(0, 8)}…
                    </TableCell>
                  </TableRow>
                ))}
                {filtered.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                      {t("admin.noAuditEntries")}
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}