import { useState, useMemo } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { Calendar, Plus, ChevronLeft, ChevronRight, Trash2, Copy, AlertTriangle } from "lucide-react";
import { isNonWorkingDay, isHoliday } from "@/lib/hungarian-holidays";
import { cn } from "@/lib/utils";

// Helpers
function startOfWeek(d: Date): Date {
  const r = new Date(d);
  const day = r.getDay();
  const diff = day === 0 ? -6 : 1 - day;
  r.setDate(r.getDate() + diff);
  r.setHours(0, 0, 0, 0);
  return r;
}

function addDays(d: Date, n: number): Date {
  const r = new Date(d);
  r.setDate(r.getDate() + n);
  return r;
}

function formatDate(d: Date): string {
  return d.toISOString().split("T")[0];
}

const DAY_NAMES = ["Hétfő", "Kedd", "Szerda", "Csütörtök", "Péntek", "Szombat", "Vasárnap"];

export default function AdminSlots() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [weekStart, setWeekStart] = useState(() => startOfWeek(new Date()));
  const [singleOpen, setSingleOpen] = useState(false);
  const [bulkOpen, setBulkOpen] = useState(false);
  const [selectedLocations, setSelectedLocations] = useState<string[]>([]);

  // Single slot form
  const [singleForm, setSingleForm] = useState({
    date: "",
    startTime: "08:00",
    endTime: "08:30",
    capacity: "1",
    doctor_id: "",
    service_id: "",
    location_id: "",
  });

  // Bulk form
  const [bulkForm, setBulkForm] = useState({
    dateFrom: "",
    dateTo: "",
    startTime: "08:00",
    endTime: "16:00",
    slotDuration: "30",
    capacity: "1",
    doctor_id: "",
    service_id: "",
    location_id: "",
    days: [true, true, true, true, true, false, false] as boolean[], // Mon-Sun
    skipHolidays: true,
  });

  const weekEnd = addDays(weekStart, 6);

  // Fetch data
  const { data: slots, isLoading } = useQuery({
    queryKey: ["admin-slots", formatDate(weekStart)],
    queryFn: async () => {
      const from = new Date(weekStart);
      from.setHours(0, 0, 0, 0);
      const to = addDays(weekStart, 7);
      const { data, error } = await supabase
        .from("appointment_slots")
        .select("*")
        .gte("slot_start", from.toISOString())
        .lt("slot_start", to.toISOString())
        .order("slot_start");
      if (error) throw error;
      return data;
    },
  });

  const { data: doctors } = useQuery({
    queryKey: ["slot-doctors"],
    queryFn: async () => {
      const { data: doctorRoles } = await supabase
        .from("user_roles")
        .select("user_id")
        .in("role", ["uzemorvos", "haziorvos"]);
      if (!doctorRoles?.length) return [];
      const ids = doctorRoles.map((r) => r.user_id);
      const { data: profiles } = await supabase
        .from("profiles")
        .select("user_id, full_name")
        .in("user_id", ids);
      return profiles ?? [];
    },
  });

  const { data: services } = useQuery({
    queryKey: ["slot-services"],
    queryFn: async () => {
      const { data } = await supabase.from("services").select("id, name").eq("is_active", true).order("name");
      return data ?? [];
    },
  });

  const { data: locations } = useQuery({
    queryKey: ["slot-locations"],
    queryFn: async () => {
      const { data } = await supabase.from("locations").select("id, name, city").eq("is_active", true).order("name");
      return data ?? [];
    },
  });

  // Group slots by day
  const LOCATION_COLORS = ["border-blue-400 bg-blue-50 dark:bg-blue-950/30", "border-emerald-400 bg-emerald-50 dark:bg-emerald-950/30", "border-amber-400 bg-amber-50 dark:bg-amber-950/30", "border-purple-400 bg-purple-50 dark:bg-purple-950/30", "border-rose-400 bg-rose-50 dark:bg-rose-950/30"];

  const getLocationColor = (locationId: string | null) => {
    if (!locationId) return "";
    const idx = (locations ?? []).findIndex((l) => l.id === locationId);
    return idx >= 0 ? LOCATION_COLORS[idx % LOCATION_COLORS.length] : "";
  };

  const slotsByDay = useMemo(() => {
    const map: Record<string, typeof slots> = {};
    for (let i = 0; i < 7; i++) {
      map[formatDate(addDays(weekStart, i))] = [];
    }
    for (const s of slots ?? []) {
      const day = s.slot_start.split("T")[0];
      if (!map[day]) continue;
      // Apply location filter
      if (selectedLocations.length > 0 && s.location_id && !selectedLocations.includes(s.location_id)) continue;
      map[day]!.push(s);
    }
    return map;
  }, [slots, weekStart, selectedLocations]);

  // Mutations
  const createSlot = useMutation({
    mutationFn: async () => {
      const slotStart = `${singleForm.date}T${singleForm.startTime}:00`;
      const slotEnd = `${singleForm.date}T${singleForm.endTime}:00`;

      // Collision detection
      if (singleForm.doctor_id && singleForm.doctor_id !== "none") {
        const { data: conflicts } = await supabase
          .from("appointment_slots")
          .select("id")
          .eq("doctor_id", singleForm.doctor_id)
          .lt("slot_start", slotEnd)
          .gt("slot_end", slotStart);
        if (conflicts && conflicts.length > 0) {
          throw new Error(`Ütközés: az orvosnak ${conflicts.length} slot-ja van ebben az időszakban!`);
        }
      }

      const { error } = await supabase.from("appointment_slots").insert({
        slot_start: slotStart,
        slot_end: slotEnd,
        capacity: parseInt(singleForm.capacity) || 1,
        doctor_id: singleForm.doctor_id || null,
        service_id: singleForm.service_id || null,
        location_id: singleForm.location_id || null,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-slots"] });
      toast({ title: "Időpont sáv létrehozva" });
      setSingleOpen(false);
    },
    onError: (e: any) => toast({ variant: "destructive", title: "Hiba", description: e.message }),
  });

  const bulkCreate = useMutation({
    mutationFn: async () => {
      const from = new Date(bulkForm.dateFrom);
      const to = new Date(bulkForm.dateTo);
      const duration = parseInt(bulkForm.slotDuration) || 30;
      const cap = parseInt(bulkForm.capacity) || 1;
      const inserts: any[] = [];

      for (let d = new Date(from); d <= to; d = addDays(d, 1)) {
        const dayOfWeek = d.getDay();
        const idx = dayOfWeek === 0 ? 6 : dayOfWeek - 1; // Mon=0
        if (!bulkForm.days[idx]) continue;
        if (bulkForm.skipHolidays && isNonWorkingDay(d)) continue;

        const dateStr = formatDate(d);
        const [startH, startM] = bulkForm.startTime.split(":").map(Number);
        const [endH, endM] = bulkForm.endTime.split(":").map(Number);
        const startMin = startH * 60 + startM;
        const endMin = endH * 60 + endM;

        for (let m = startMin; m + duration <= endMin; m += duration) {
          const sh = Math.floor(m / 60);
          const sm = m % 60;
          const eh = Math.floor((m + duration) / 60);
          const em = (m + duration) % 60;
          inserts.push({
            slot_start: `${dateStr}T${String(sh).padStart(2, "0")}:${String(sm).padStart(2, "0")}:00`,
            slot_end: `${dateStr}T${String(eh).padStart(2, "0")}:${String(em).padStart(2, "0")}:00`,
            capacity: cap,
            doctor_id: bulkForm.doctor_id || null,
            service_id: bulkForm.service_id || null,
            location_id: bulkForm.location_id || null,
          });
        }
      }

      if (inserts.length === 0) throw new Error("Nincs generálható időpont a megadott feltételekkel");

      // Insert in batches of 100
      for (let i = 0; i < inserts.length; i += 100) {
        const batch = inserts.slice(i, i + 100);
        const { error } = await supabase.from("appointment_slots").insert(batch);
        if (error) throw error;
      }

      return inserts.length;
    },
    onSuccess: (count) => {
      qc.invalidateQueries({ queryKey: ["admin-slots"] });
      toast({ title: `${count} időpont sáv generálva` });
      setBulkOpen(false);
    },
    onError: (e: any) => toast({ variant: "destructive", title: "Hiba", description: e.message }),
  });

  const deleteSlot = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("appointment_slots").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-slots"] });
      toast({ title: "Slot törölve" });
    },
  });

  const toggleSlot = useMutation({
    mutationFn: async ({ id, is_active }: { id: string; is_active: boolean }) => {
      const { error } = await supabase.from("appointment_slots").update({ is_active }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["admin-slots"] }),
  });

  const getDoctorName = (id: string | null) => (doctors ?? []).find((d) => d.user_id === id)?.full_name ?? "";
  const getServiceName = (id: string | null) => (services ?? []).find((s) => s.id === id)?.name ?? "";
  const getLocationName = (id: string | null) => (locations ?? []).find((l) => l.id === id)?.name ?? "";

  const openSingleForDate = (dateStr: string) => {
    setSingleForm((f) => ({ ...f, date: dateStr }));
    setSingleOpen(true);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-3">
          <Calendar className="h-6 w-6 text-secondary" />
          <h1 className="text-2xl font-bold">Naptár konfigurátor</h1>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setBulkOpen(true)}>
            <Copy className="h-4 w-4 mr-2" />
            Tömeges generálás
          </Button>
          <Button onClick={() => { setSingleForm((f) => ({ ...f, date: formatDate(new Date()) })); setSingleOpen(true); }}>
            <Plus className="h-4 w-4 mr-2" />
            Új slot
          </Button>
        </div>
      </div>

      {/* Week navigation */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-2">
        <Button variant="ghost" size="sm" onClick={() => setWeekStart(addDays(weekStart, -7))}>
          <ChevronLeft className="h-4 w-4 mr-1" /> Előző hét
        </Button>
        <div className="text-sm font-medium text-center">
          {weekStart.toLocaleDateString("hu-HU", { year: "numeric", month: "long", day: "numeric" })}
          {" – "}
          {weekEnd.toLocaleDateString("hu-HU", { year: "numeric", month: "long", day: "numeric" })}
        </div>
        <div className="flex gap-2">
          <Button variant="ghost" size="sm" onClick={() => setWeekStart(startOfWeek(new Date()))}>
            Ma
          </Button>
          <Button variant="ghost" size="sm" onClick={() => setWeekStart(addDays(weekStart, 7))}>
            Következő hét <ChevronRight className="h-4 w-4 ml-1" />
          </Button>
        </div>
      </div>

      {/* Location filter */}
      {(locations ?? []).length > 0 && (
        <div className="flex flex-wrap gap-2 items-center">
          <span className="text-sm text-muted-foreground mr-1">Helyszínek:</span>
          <Badge
            variant={selectedLocations.length === 0 ? "default" : "outline"}
            className="cursor-pointer"
            onClick={() => setSelectedLocations([])}
          >
            Mind
          </Badge>
          {(locations ?? []).map((l, idx) => (
            <Badge
              key={l.id}
              variant={selectedLocations.includes(l.id) ? "default" : "outline"}
              className={cn("cursor-pointer", selectedLocations.includes(l.id) && LOCATION_COLORS[idx % LOCATION_COLORS.length])}
              onClick={() => {
                setSelectedLocations((prev) =>
                  prev.includes(l.id) ? prev.filter((id) => id !== l.id) : [...prev, l.id]
                );
              }}
            >
              {l.name}
            </Badge>
          ))}
        </div>
      )}

      {/* Weekly grid — responsive: 1 col mobile, 2 cols tablet, 7 cols desktop */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-7 gap-2">
        {Array.from({ length: 7 }).map((_, i) => {
          const day = addDays(weekStart, i);
          const dateStr = formatDate(day);
          const daySlots = slotsByDay[dateStr] ?? [];
          const nonWorking = isNonWorkingDay(day);
          const holiday = isHoliday(day);
          const isToday = formatDate(new Date()) === dateStr;

          return (
            <Card
              key={dateStr}
              className={cn(
                "min-h-[120px] lg:min-h-[200px] flex flex-col",
                nonWorking && "opacity-75",
                isToday && "ring-2 ring-secondary"
              )}
            >
              <CardHeader className="p-2 pb-1">
                <div className="flex items-center justify-between">
                  <div>
                    <span className={cn("text-xs font-semibold", isToday && "text-secondary")}>
                      {DAY_NAMES[i]}
                    </span>
                    <p className="text-lg font-bold leading-tight">{day.getDate()}</p>
                  </div>
                  {!nonWorking && (
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-6 w-6 p-0"
                      onClick={() => openSingleForDate(dateStr)}
                    >
                      <Plus className="h-3 w-3" />
                    </Button>
                  )}
                </div>
                {nonWorking && (
                  <Badge variant="secondary" className="text-[10px] mt-1 w-fit">
                    {holiday?.name ?? nonWorking.reason}
                  </Badge>
                )}
              </CardHeader>
              <CardContent className="p-2 pt-0 flex-1 space-y-1 overflow-y-auto max-h-[300px]">
                {daySlots.map((s) => {
                  const start = new Date(s.slot_start);
                  const end = new Date(s.slot_end);
                  return (
                    <div
                      key={s.id}
                      className={cn(
                        "rounded border p-1.5 text-[11px] space-y-0.5 group relative",
                        s.is_active
                          ? s.location_id ? getLocationColor(s.location_id) : "bg-primary/10 border-primary/20"
                          : "bg-muted border-muted-foreground/20 opacity-60"
                      )}
                    >
                      <div className="flex justify-between items-center">
                        <span className="font-semibold">
                          {start.toLocaleTimeString("hu-HU", { hour: "2-digit", minute: "2-digit" })}–
                          {end.toLocaleTimeString("hu-HU", { hour: "2-digit", minute: "2-digit" })}
                        </span>
                        <div className="hidden group-hover:flex gap-0.5">
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-5 w-5 p-0"
                            onClick={() => toggleSlot.mutate({ id: s.id, is_active: !s.is_active })}
                          >
                            <span className="text-[9px]">{s.is_active ? "⏸" : "▶"}</span>
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-5 w-5 p-0 text-destructive"
                            onClick={() => deleteSlot.mutate(s.id)}
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                      <div className="text-muted-foreground">
                        {s.capacity > 1 && <span>👥{s.capacity} </span>}
                        {s.doctor_id && <span>{getDoctorName(s.doctor_id)} </span>}
                        {s.service_id && <span>• {getServiceName(s.service_id)} </span>}
                        {s.location_id && <span>• {getLocationName(s.location_id)}</span>}
                      </div>
                    </div>
                  );
                })}
                {daySlots.length === 0 && !nonWorking && (
                  <p className="text-[10px] text-muted-foreground text-center pt-4">Nincs slot</p>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Single slot dialog */}
      <Dialog open={singleOpen} onOpenChange={setSingleOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Új időpont sáv</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label>Dátum</Label>
              <Input type="date" value={singleForm.date} onChange={(e) => setSingleForm((f) => ({ ...f, date: e.target.value }))} />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>Kezdés</Label>
                <Input type="time" value={singleForm.startTime} onChange={(e) => setSingleForm((f) => ({ ...f, startTime: e.target.value }))} />
              </div>
              <div className="space-y-1.5">
                <Label>Vége</Label>
                <Input type="time" value={singleForm.endTime} onChange={(e) => setSingleForm((f) => ({ ...f, endTime: e.target.value }))} />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Kapacitás</Label>
              <Input type="number" min="1" value={singleForm.capacity} onChange={(e) => setSingleForm((f) => ({ ...f, capacity: e.target.value }))} />
            </div>
            <div className="space-y-1.5">
              <Label>Orvos (opcionális)</Label>
              <Select value={singleForm.doctor_id} onValueChange={(v) => setSingleForm((f) => ({ ...f, doctor_id: v }))}>
                <SelectTrigger><SelectValue placeholder="Válasszon orvost" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">— Nincs —</SelectItem>
                  {(doctors ?? []).map((d) => <SelectItem key={d.user_id} value={d.user_id}>{d.full_name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Szolgáltatás (opcionális)</Label>
              <Select value={singleForm.service_id} onValueChange={(v) => setSingleForm((f) => ({ ...f, service_id: v }))}>
                <SelectTrigger><SelectValue placeholder="Válasszon szolgáltatást" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">— Nincs —</SelectItem>
                  {(services ?? []).map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Helyszín (opcionális)</Label>
              <Select value={singleForm.location_id} onValueChange={(v) => setSingleForm((f) => ({ ...f, location_id: v }))}>
                <SelectTrigger><SelectValue placeholder="Válasszon helyszínt" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">— Nincs —</SelectItem>
                  {(locations ?? []).map((l) => <SelectItem key={l.id} value={l.id}>{l.name}{l.city ? ` (${l.city})` : ""}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <Button
              className="w-full"
              onClick={() => createSlot.mutate()}
              disabled={createSlot.isPending || !singleForm.date}
            >
              Létrehozás
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Bulk generation dialog */}
      <Dialog open={bulkOpen} onOpenChange={setBulkOpen}>
        <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Tömeges slot generálás</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>Kezdő dátum</Label>
                <Input type="date" value={bulkForm.dateFrom} onChange={(e) => setBulkForm((f) => ({ ...f, dateFrom: e.target.value }))} />
              </div>
              <div className="space-y-1.5">
                <Label>Záró dátum</Label>
                <Input type="date" value={bulkForm.dateTo} onChange={(e) => setBulkForm((f) => ({ ...f, dateTo: e.target.value }))} />
              </div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-1.5">
                <Label>Napi kezdés</Label>
                <Input type="time" value={bulkForm.startTime} onChange={(e) => setBulkForm((f) => ({ ...f, startTime: e.target.value }))} />
              </div>
              <div className="space-y-1.5">
                <Label>Napi vége</Label>
                <Input type="time" value={bulkForm.endTime} onChange={(e) => setBulkForm((f) => ({ ...f, endTime: e.target.value }))} />
              </div>
              <div className="space-y-1.5">
                <Label>Slot időtartam (perc)</Label>
                <Input type="number" min="5" step="5" value={bulkForm.slotDuration} onChange={(e) => setBulkForm((f) => ({ ...f, slotDuration: e.target.value }))} />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Kapacitás / slot</Label>
              <Input type="number" min="1" value={bulkForm.capacity} onChange={(e) => setBulkForm((f) => ({ ...f, capacity: e.target.value }))} />
            </div>

            <div className="space-y-2">
              <Label className="text-sm font-semibold">Napok</Label>
              <div className="flex gap-3 flex-wrap">
                {DAY_NAMES.map((name, i) => (
                  <div key={i} className="flex items-center gap-1.5">
                    <Checkbox
                      checked={bulkForm.days[i]}
                      onCheckedChange={(checked) =>
                        setBulkForm((f) => {
                          const days = [...f.days];
                          days[i] = !!checked;
                          return { ...f, days };
                        })
                      }
                    />
                    <span className="text-xs">{name.slice(0, 3)}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Switch checked={bulkForm.skipHolidays} onCheckedChange={(v) => setBulkForm((f) => ({ ...f, skipHolidays: v }))} />
              <Label className="text-sm">Ünnepnapok és hétvégék kihagyása</Label>
            </div>

            <div className="space-y-1.5">
              <Label>Orvos (opcionális)</Label>
              <Select value={bulkForm.doctor_id} onValueChange={(v) => setBulkForm((f) => ({ ...f, doctor_id: v }))}>
                <SelectTrigger><SelectValue placeholder="Válasszon" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">— Nincs —</SelectItem>
                  {(doctors ?? []).map((d) => <SelectItem key={d.user_id} value={d.user_id}>{d.full_name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Szolgáltatás (opcionális)</Label>
              <Select value={bulkForm.service_id} onValueChange={(v) => setBulkForm((f) => ({ ...f, service_id: v }))}>
                <SelectTrigger><SelectValue placeholder="Válasszon" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">— Nincs —</SelectItem>
                  {(services ?? []).map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Helyszín (opcionális)</Label>
              <Select value={bulkForm.location_id} onValueChange={(v) => setBulkForm((f) => ({ ...f, location_id: v }))}>
                <SelectTrigger><SelectValue placeholder="Válasszon" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">— Nincs —</SelectItem>
                  {(locations ?? []).map((l) => <SelectItem key={l.id} value={l.id}>{l.name}{l.city ? ` (${l.city})` : ""}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            <Button
              className="w-full"
              onClick={() => bulkCreate.mutate()}
              disabled={bulkCreate.isPending || !bulkForm.dateFrom || !bulkForm.dateTo}
            >
              {bulkCreate.isPending ? "Generálás..." : "Slotok generálása"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
