import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { MapPin, Plus, Pencil, Trash2, Phone, Mail, ExternalLink, MessageCircle } from "lucide-react";

interface LocationRow {
  id: string;
  name: string;
  address: string | null;
  city: string | null;
  email: string | null;
  phone: string | null;
  whatsapp: string | null;
  google_maps_url: string | null;
  responsible_user_id: string | null;
  description: string | null;
  is_active: boolean;
}

const emptyForm = {
  name: "", address: "", city: "", email: "", phone: "", whatsapp: "",
  google_maps_url: "", responsible_user_id: "", description: "", is_active: true,
};

export default function AdminLocations() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [editing, setEditing] = useState<LocationRow | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [dialogOpen, setDialogOpen] = useState(false);

  const { data: locations, isLoading } = useQuery({
    queryKey: ["admin-locations"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("locations")
        .select("id, name, address, city, is_active, email, phone, whatsapp, google_maps_url, responsible_user_id, description")
        .order("name");
      if (error) throw error;
      return data as LocationRow[];
    },
  });

  const { data: profiles } = useQuery({
    queryKey: ["location-profiles"],
    queryFn: async () => {
      const { data } = await supabase.from("profiles").select("user_id, full_name").order("full_name");
      return data ?? [];
    },
  });

  const upsert = useMutation({
    mutationFn: async (values: typeof form & { id?: string }) => {
      const row = {
        name: values.name, address: values.address || null, city: values.city || null,
        email: values.email || null, phone: values.phone || null, whatsapp: values.whatsapp || null,
        google_maps_url: values.google_maps_url || null, responsible_user_id: values.responsible_user_id || null,
        description: values.description || null, is_active: values.is_active,
      };
      if (values.id) {
        const { error } = await supabase.from("locations").update(row).eq("id", values.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("locations").insert(row);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-locations"] });
      toast({ title: editing ? t("admin.locationUpdated") : t("admin.locationCreated") });
      setDialogOpen(false); setEditing(null); setForm(emptyForm);
    },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  const deleteMut = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("locations").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["admin-locations"] }); toast({ title: t("admin.locationDeleted") }); },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  const getProfileName = (id: string | null) => (profiles ?? []).find((p) => p.user_id === id)?.full_name ?? "";

  const openEdit = (l: LocationRow) => {
    setEditing(l);
    setForm({
      name: l.name, address: l.address ?? "", city: l.city ?? "",
      email: l.email ?? "", phone: l.phone ?? "", whatsapp: l.whatsapp ?? "",
      google_maps_url: l.google_maps_url ?? "", responsible_user_id: l.responsible_user_id ?? "",
      description: l.description ?? "", is_active: l.is_active,
    });
    setDialogOpen(true);
  };

  const openNew = () => { setEditing(null); setForm(emptyForm); setDialogOpen(true); };

  if (isLoading) {
    return <div className="flex items-center justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <MapPin className="h-6 w-6 text-secondary" />
          <h1 className="text-2xl font-bold">{t("admin.locationsTitle")}</h1>
        </div>
        <Button onClick={openNew}><Plus className="h-4 w-4 mr-2" /> {t("admin.newLocation")}</Button>
      </div>

      <Card>
        <CardContent className="overflow-x-auto pt-6">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t("common.name")}</TableHead>
                <TableHead>{t("admin.city")}</TableHead>
                <TableHead>{t("admin.address")}</TableHead>
                <TableHead>{t("admin.contact")}</TableHead>
                <TableHead>{t("admin.responsiblePerson")}</TableHead>
                <TableHead>{t("admin.active")}</TableHead>
                <TableHead className="w-24">{t("common.actions")}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {(locations ?? []).map((l) => (
                <TableRow key={l.id}>
                  <TableCell className="font-medium">{l.name}</TableCell>
                  <TableCell>{l.city || "—"}</TableCell>
                  <TableCell>{l.address || "—"}</TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      {l.phone && <a href={`tel:${l.phone}`} className="inline-flex items-center justify-center h-7 w-7 rounded hover:bg-accent" title={l.phone}><Phone className="h-3.5 w-3.5 text-primary" /></a>}
                      {l.email && <a href={`mailto:${l.email}`} className="inline-flex items-center justify-center h-7 w-7 rounded hover:bg-accent" title={l.email}><Mail className="h-3.5 w-3.5 text-primary" /></a>}
                      {l.whatsapp && <a href={`https://wa.me/${l.whatsapp.replace(/[^0-9]/g, "")}`} target="_blank" rel="noopener" className="inline-flex items-center justify-center h-7 w-7 rounded hover:bg-accent" title="WhatsApp"><MessageCircle className="h-3.5 w-3.5 text-green-500" /></a>}
                      {l.google_maps_url && <a href={l.google_maps_url} target="_blank" rel="noopener" className="inline-flex items-center justify-center h-7 w-7 rounded hover:bg-accent" title="Google Maps"><ExternalLink className="h-3.5 w-3.5 text-muted-foreground" /></a>}
                    </div>
                  </TableCell>
                  <TableCell className="text-sm">{getProfileName(l.responsible_user_id) || "—"}</TableCell>
                  <TableCell>
                    <span className={l.is_active ? "text-green-500" : "text-muted-foreground"}>{l.is_active ? t("common.yes") : t("common.no")}</span>
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      <Button size="sm" variant="ghost" onClick={() => openEdit(l)}><Pencil className="h-4 w-4" /></Button>
                      <Button size="sm" variant="ghost" className="text-destructive hover:text-destructive" onClick={() => deleteMut.mutate(l.id)}><Trash2 className="h-4 w-4" /></Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing ? t("admin.editLocation") : t("admin.newLocation")}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5"><Label>{t("common.name")}</Label><Input value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} /></div>
              <div className="space-y-1.5"><Label>{t("admin.city")}</Label><Input value={form.city} onChange={(e) => setForm((f) => ({ ...f, city: e.target.value }))} /></div>
            </div>
            <div className="space-y-1.5"><Label>{t("admin.address")}</Label><Input value={form.address} onChange={(e) => setForm((f) => ({ ...f, address: e.target.value }))} /></div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5"><Label>{t("admin.email")}</Label><Input type="email" value={form.email} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} /></div>
              <div className="space-y-1.5"><Label>{t("admin.phone")}</Label><Input value={form.phone} onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))} placeholder="+36..." /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5"><Label>{t("admin.whatsapp")}</Label><Input value={form.whatsapp} onChange={(e) => setForm((f) => ({ ...f, whatsapp: e.target.value }))} placeholder="+36..." /></div>
              <div className="space-y-1.5"><Label>{t("admin.googleMapsUrl")}</Label><Input value={form.google_maps_url} onChange={(e) => setForm((f) => ({ ...f, google_maps_url: e.target.value }))} placeholder="https://maps.google.com/..." /></div>
            </div>
            <div className="space-y-1.5">
              <Label>{t("admin.responsiblePerson")}</Label>
              <Select value={form.responsible_user_id} onValueChange={(v) => setForm((f) => ({ ...f, responsible_user_id: v }))}>
                <SelectTrigger><SelectValue placeholder={t("admin.selectResponsible")} /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">{t("admin.none")}</SelectItem>
                  {(profiles ?? []).map((p) => <SelectItem key={p.user_id} value={p.user_id}>{p.full_name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label>{t("admin.description")}</Label><Textarea value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} rows={3} /></div>
            <div className="flex items-center gap-2">
              <Switch checked={form.is_active} onCheckedChange={(v) => setForm((f) => ({ ...f, is_active: v }))} />
              <Label>{t("admin.active")}</Label>
            </div>
            <Button className="w-full" onClick={() => upsert.mutate({ ...form, id: editing?.id })} disabled={upsert.isPending || !form.name}>
              {editing ? t("common.save") : t("common.create")}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}