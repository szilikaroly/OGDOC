import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import { exportToCsv } from "@/hooks/use-csv-export";
import ReactMarkdown from "react-markdown";
import {
  Search, TrendingUp, DollarSign, FileText, History, BarChart3, Plus, Trash2, Loader2, Globe, ArrowRight, AlertTriangle, CheckCircle, XCircle, MapPin
} from "lucide-react";

// ─── Types ───────────────────────────────────────────────────────────

type CompetitorUrl = { id: string; url: string; name: string; is_active: boolean; created_at: string };
type Analysis = { id: string; competitor_url_id: string | null; analysis_type: string; results: any; created_at: string };

// ─── API helpers ─────────────────────────────────────────────────────

async function invoke(action: string, params: Record<string, any> = {}) {
  const { data, error } = await supabase.functions.invoke("ai-marketing", {
    body: { action, ...params },
  });
  if (error) throw new Error(error.message);
  if (!data?.success) throw new Error(data?.error || "Unknown error");
  return data.data;
}

// ─── Main component ─────────────────────────────────────────────────

export default function AdminMarketing() {
  const { t } = useTranslation();
  const qc = useQueryClient();

  // ── Competitor URLs ──
  const { data: urls = [], isLoading: urlsLoading } = useQuery({
    queryKey: ["competitor-urls"],
    queryFn: async () => {
      const { data, error } = await supabase.from("competitor_urls").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      return data as CompetitorUrl[];
    },
  });

  // ── All analyses ──
  const { data: analyses = [] } = useQuery({
    queryKey: ["competitor-analyses"],
    queryFn: async () => {
      const { data, error } = await supabase.from("competitor_analyses").select("*").order("created_at", { ascending: false }).limit(100);
      if (error) throw error;
      return data as Analysis[];
    },
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Marketing Központ</h1>
        <p className="text-muted-foreground">AI-alapú versenytárs-elemzés, tartalom javaslatok és marketing trendek</p>
      </div>

      <Tabs defaultValue="search" className="space-y-4">
        <TabsList className="flex flex-wrap h-auto gap-1">
          <TabsTrigger value="search" className="gap-1"><Globe className="h-4 w-4" />Kereső</TabsTrigger>
          <TabsTrigger value="seo" className="gap-1"><Search className="h-4 w-4" />SEO Elemző</TabsTrigger>
          <TabsTrigger value="content" className="gap-1"><FileText className="h-4 w-4" />Tartalom</TabsTrigger>
          <TabsTrigger value="pricing" className="gap-1"><DollarSign className="h-4 w-4" />Ár/Akció</TabsTrigger>
          <TabsTrigger value="trends" className="gap-1"><TrendingUp className="h-4 w-4" />Trendek</TabsTrigger>
          <TabsTrigger value="history" className="gap-1"><History className="h-4 w-4" />Előzmények</TabsTrigger>
          <TabsTrigger value="reports" className="gap-1"><BarChart3 className="h-4 w-4" />Riportok</TabsTrigger>
        </TabsList>

        <TabsContent value="search">
          <SearchTab urls={urls} qc={qc} />
        </TabsContent>
        <TabsContent value="seo">
          <SeoTab urls={urls} urlsLoading={urlsLoading} qc={qc} analyses={analyses} />
        </TabsContent>
        <TabsContent value="content">
          <ContentTab urls={urls} analyses={analyses} qc={qc} />
        </TabsContent>
        <TabsContent value="pricing">
          <PricingTab urls={urls} analyses={analyses} qc={qc} />
        </TabsContent>
        <TabsContent value="trends">
          <TrendsTab analyses={analyses} qc={qc} />
        </TabsContent>
        <TabsContent value="history">
          <HistoryTab analyses={analyses} urls={urls} />
        </TabsContent>
        <TabsContent value="reports">
          <ReportsTab analyses={analyses} qc={qc} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

// ─── Search Tab ──────────────────────────────────────────────────────

const CITIES = ["Budapest", "Debrecen", "Szeged", "Pécs", "Miskolc", "Győr", "Nyíregyháza", "Kecskemét", "Székesfehérvár", "Szombathely"];

type SearchResult = { url: string; name: string; description: string; relevance: string; city?: string };

function SearchTab({ urls, qc }: { urls: CompetitorUrl[]; qc: any }) {
  const [city, setCity] = useState(CITIES[0]);
  const [results, setResults] = useState<SearchResult[]>([]);
  const [addingUrl, setAddingUrl] = useState<string | null>(null);

  const existingUrls = new Set(urls.map((u) => u.url));

  const searchMut = useMutation({
    mutationFn: (params: { scope: "local" | "national"; city?: string }) => invoke("search_competitors", params),
    onSuccess: (data) => {
      setResults(data.competitors || []);
      qc.invalidateQueries({ queryKey: ["competitor-analyses"] });
      toast.success(`${data.competitors?.length || 0} versenytárs találat!`);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const addMut = useMutation({
    mutationFn: async (comp: SearchResult) => {
      setAddingUrl(comp.url);
      const { error } = await supabase.from("competitor_urls").insert({
        url: comp.url,
        name: comp.name,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["competitor-urls"] });
      toast.success("Versenytárs hozzáadva a figyeléshez!");
      setAddingUrl(null);
    },
    onError: (e: Error) => { toast.error(e.message); setAddingUrl(null); },
  });

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Globe className="h-5 w-5" />Versenytárs Kereső</CardTitle>
          <CardDescription>AI-alapú versenytárs felderítés — lokális (város) vagy országos keresés</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="flex items-center gap-2 flex-1">
              <MapPin className="h-4 w-4 text-muted-foreground shrink-0" />
              <Select value={city} onValueChange={setCity}>
                <SelectTrigger className="w-[200px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {CITIES.map((c) => (
                    <SelectItem key={c} value={c}>{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button onClick={() => searchMut.mutate({ scope: "local", city })} disabled={searchMut.isPending}>
                {searchMut.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <Search className="h-4 w-4 mr-1" />}
                Lokális keresés
              </Button>
            </div>
            <Separator orientation="vertical" className="hidden sm:block h-10" />
            <Button variant="outline" onClick={() => searchMut.mutate({ scope: "national" })} disabled={searchMut.isPending}>
              {searchMut.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <Globe className="h-4 w-4 mr-1" />}
              Országos keresés
            </Button>
          </div>
        </CardContent>
      </Card>

      {results.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Találatok ({results.length})</CardTitle>
            <CardDescription>Kattints a "Hozzáadás" gombra a versenytárs figyeléséhez (max 5)</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {results.map((comp, i) => {
              const alreadyAdded = existingUrls.has(comp.url);
              return (
                <div key={i} className="border rounded-lg p-4 space-y-2">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-semibold">{comp.name}</span>
                        <Badge variant={comp.relevance === "high" ? "default" : comp.relevance === "medium" ? "secondary" : "outline"}>
                          {comp.relevance === "high" ? "Magas" : comp.relevance === "medium" ? "Közepes" : "Alacsony"} relevancia
                        </Badge>
                        {comp.city && <Badge variant="outline"><MapPin className="h-3 w-3 mr-1" />{comp.city}</Badge>}
                      </div>
                      <p className="text-sm text-muted-foreground truncate mt-1">{comp.url}</p>
                      <p className="text-sm mt-1">{comp.description}</p>
                    </div>
                    <Button
                      size="sm"
                      variant={alreadyAdded ? "ghost" : "default"}
                      disabled={alreadyAdded || addMut.isPending || urls.length >= 5}
                      onClick={() => addMut.mutate(comp)}
                    >
                      {addingUrl === comp.url ? <Loader2 className="h-3 w-3 animate-spin mr-1" /> : <Plus className="h-3 w-3 mr-1" />}
                      {alreadyAdded ? "Már figyelt" : "Hozzáadás"}
                    </Button>
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// ─── SEO Tab ─────────────────────────────────────────────────────────

function SeoTab({ urls, urlsLoading, qc, analyses }: { urls: CompetitorUrl[]; urlsLoading: boolean; qc: any; analyses: Analysis[] }) {
  const [newUrl, setNewUrl] = useState("");
  const [scrapeResult, setScrapeResult] = useState<any>(null);
  const [compareResult, setCompareResult] = useState<any>(null);

  const scrapeMut = useMutation({
    mutationFn: (url: string) => invoke("scrape_competitor", { url }),
    onSuccess: (data) => {
      setScrapeResult(data);
      qc.invalidateQueries({ queryKey: ["competitor-urls"] });
      qc.invalidateQueries({ queryKey: ["competitor-analyses"] });
      toast.success("Oldal sikeresen elemezve!");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const compareMut = useMutation({
    mutationFn: async (params: { competitor_data: any; competitor_url_id: string }) => {
      // Fetch own SEO data
      const { data: ownSeo } = await supabase.from("seo_pages" as any).select("*").limit(20);
      return invoke("compare_seo", { ...params, own_seo: ownSeo || [] });
    },
    onSuccess: (data) => {
      setCompareResult(data);
      qc.invalidateQueries({ queryKey: ["competitor-analyses"] });
      toast.success("SEO összehasonlítás kész!");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const deleteMut = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("competitor_urls").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["competitor-urls"] });
      toast.success("Versenytárs törölve");
    },
  });

  const handleScrape = () => {
    if (!newUrl.trim()) return;
    let url = newUrl.trim();
    if (!url.startsWith("http")) url = `https://${url}`;
    scrapeMut.mutate(url);
  };

  const lastScrape = (urlId: string) => analyses.find((a) => a.competitor_url_id === urlId && a.analysis_type === "scrape");

  return (
    <div className="space-y-6">
      {/* Add competitor */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Globe className="h-5 w-5" />Versenytárs URL hozzáadása és elemzése</CardTitle>
          <CardDescription>Add meg a versenytárs weboldalának URL-jét az SEO elemzéshez (max 5)</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2">
            <Input
              placeholder="https://versenytars.hu"
              value={newUrl}
              onChange={(e) => setNewUrl(e.target.value)}
              disabled={scrapeMut.isPending || urls.length >= 5}
            />
            <Button onClick={handleScrape} disabled={scrapeMut.isPending || !newUrl.trim() || urls.length >= 5}>
              {scrapeMut.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
              Elemzés
            </Button>
          </div>
          {urls.length >= 5 && <p className="text-sm text-muted-foreground mt-2">Maximum 5 versenytárs figyelhető.</p>}
        </CardContent>
      </Card>

      {/* Competitor list */}
      {urls.length > 0 && (
        <Card>
          <CardHeader><CardTitle>Figyelt versenytársak ({urls.length}/5)</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {urls.map((u) => {
              const scrape = lastScrape(u.id);
              return (
                <div key={u.id} className="flex items-center justify-between border rounded-lg p-3">
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">{u.name || u.url}</p>
                    <p className="text-sm text-muted-foreground truncate">{u.url}</p>
                  </div>
                  <div className="flex items-center gap-2 ml-2">
                    <Button size="sm" variant="outline" onClick={() => scrapeMut.mutate(u.url)} disabled={scrapeMut.isPending}>
                      <Search className="h-3 w-3 mr-1" />Újra
                    </Button>
                    {scrape && (
                      <Button
                        size="sm"
                        variant="secondary"
                        onClick={() => compareMut.mutate({ competitor_data: scrape.results, competitor_url_id: u.id })}
                        disabled={compareMut.isPending}
                      >
                        {compareMut.isPending ? <Loader2 className="h-3 w-3 animate-spin" /> : <ArrowRight className="h-3 w-3 mr-1" />}
                        SEO összehasonlítás
                      </Button>
                    )}
                    <Button size="sm" variant="ghost" onClick={() => deleteMut.mutate(u.id)}><Trash2 className="h-3 w-3" /></Button>
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>
      )}

      {/* Scrape result */}
      {scrapeResult && (
        <Card>
          <CardHeader><CardTitle>Scrape eredmény</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            <p><strong>Title:</strong> {scrapeResult.title || "—"}</p>
            <p><strong>Description:</strong> {scrapeResult.description || "—"}</p>
            <p><strong>Headings ({scrapeResult.headings?.length || 0}):</strong></p>
            <div className="bg-muted rounded p-2 max-h-40 overflow-auto text-sm">
              {scrapeResult.headings?.map((h: string, i: number) => <div key={i}>{h}</div>)}
            </div>
            {scrapeResult.schemaOrg && (
              <>
                <p><strong>Schema.org:</strong></p>
                <pre className="bg-muted rounded p-2 max-h-40 overflow-auto text-xs">{scrapeResult.schemaOrg}</pre>
              </>
            )}
          </CardContent>
        </Card>
      )}

      {/* Compare result */}
      {compareResult && <SeoCompareResult data={compareResult} />}
    </div>
  );
}

function SeoCompareResult({ data }: { data: any }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>SEO Összehasonlítás</CardTitle>
        <div className="flex gap-4 mt-2">
          <Badge variant="outline" className="text-lg px-3 py-1">Saját: {data.score?.own ?? "?"}/100</Badge>
          <Badge variant="secondary" className="text-lg px-3 py-1">Versenytárs: {data.score?.competitor ?? "?"}/100</Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {data.comparison?.length > 0 && (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead><tr className="border-b"><th className="text-left py-2">Szempont</th><th className="text-left py-2">Saját</th><th className="text-left py-2">Versenytárs</th><th className="text-left py-2">Javaslat</th></tr></thead>
              <tbody>
                {data.comparison.map((c: any, i: number) => (
                  <tr key={i} className="border-b"><td className="py-2 font-medium">{c.aspect}</td><td className="py-2">{c.own}</td><td className="py-2">{c.competitor}</td><td className="py-2 text-muted-foreground">{c.recommendation}</td></tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <div className="grid md:grid-cols-3 gap-4">
          <div>
            <h4 className="font-semibold flex items-center gap-1 mb-1"><CheckCircle className="h-4 w-4 text-green-600" />Erősségek</h4>
            <ul className="text-sm space-y-1">{data.strengths?.map((s: string, i: number) => <li key={i}>• {s}</li>)}</ul>
          </div>
          <div>
            <h4 className="font-semibold flex items-center gap-1 mb-1"><XCircle className="h-4 w-4 text-red-600" />Gyengeségek</h4>
            <ul className="text-sm space-y-1">{data.weaknesses?.map((w: string, i: number) => <li key={i}>• {w}</li>)}</ul>
          </div>
          <div>
            <h4 className="font-semibold flex items-center gap-1 mb-1"><AlertTriangle className="h-4 w-4 text-yellow-600" />Gap-ek</h4>
            <ul className="text-sm space-y-1">{data.gaps?.map((g: string, i: number) => <li key={i}>• {g}</li>)}</ul>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// ─── Content Tab ─────────────────────────────────────────────────────

function ContentTab({ urls, analyses, qc }: { urls: CompetitorUrl[]; analyses: Analysis[]; qc: any }) {
  const [result, setResult] = useState<any>(null);
  const [selectedUrl, setSelectedUrl] = useState("");

  const mut = useMutation({
    mutationFn: async (urlId: string) => {
      const scrape = analyses.find((a) => a.competitor_url_id === urlId && a.analysis_type === "scrape");
      if (!scrape) throw new Error("Először elemezd a versenytárs oldalt az SEO tab-on!");
      const { data: services } = await supabase.from("services").select("name, description, price").limit(50);
      return invoke("content_suggestions", { competitor_data: scrape.results, own_services: services || [], competitor_url_id: urlId });
    },
    onSuccess: (data) => { setResult(data); qc.invalidateQueries({ queryKey: ["competitor-analyses"] }); toast.success("Tartalom javaslatok elkészültek!"); },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Tartalom Bővítési Javaslatok</CardTitle>
          <CardDescription>AI elemzi a versenytárs tartalmát és javaslatokat tesz a saját oldal bővítésére</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex gap-2 flex-wrap">
            {urls.map((u) => (
              <Button key={u.id} variant={selectedUrl === u.id ? "default" : "outline"} size="sm"
                onClick={() => { setSelectedUrl(u.id); mut.mutate(u.id); }}
                disabled={mut.isPending}
              >
                {mut.isPending && selectedUrl === u.id ? <Loader2 className="h-3 w-3 animate-spin mr-1" /> : null}
                {u.name || u.url}
              </Button>
            ))}
          </div>
          {urls.length === 0 && <p className="text-muted-foreground">Először adj hozzá versenytársakat az SEO tab-on.</p>}
        </CardContent>
      </Card>

      {result?.suggestions && (
        <Card>
          <CardHeader><CardTitle>Javaslatok</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {result.suggestions.map((s: any, i: number) => (
              <div key={i} className="border rounded-lg p-3 space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-medium">{s.service}</span>
                  <Badge variant={s.priority === "high" ? "destructive" : s.priority === "medium" ? "default" : "secondary"}>{s.priority}</Badge>
                </div>
                <p className="text-sm text-muted-foreground"><strong>Gap:</strong> {s.gap}</p>
                <p className="text-sm"><strong>Javaslat:</strong> {s.recommendation}</p>
                {s.estimated_impact && <p className="text-sm text-muted-foreground">Várható hatás: {s.estimated_impact}</p>}
              </div>
            ))}
            {result.missing_topics?.length > 0 && (
              <div className="mt-4">
                <h4 className="font-semibold mb-1">Hiányzó témák:</h4>
                <div className="flex flex-wrap gap-1">{result.missing_topics.map((t: string, i: number) => <Badge key={i} variant="outline">{t}</Badge>)}</div>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// ─── Pricing Tab ─────────────────────────────────────────────────────

function PricingTab({ urls, analyses, qc }: { urls: CompetitorUrl[]; analyses: Analysis[]; qc: any }) {
  const [result, setResult] = useState<any>(null);
  const [selectedUrl, setSelectedUrl] = useState("");

  const mut = useMutation({
    mutationFn: async (urlId: string) => {
      const scrape = analyses.find((a) => a.competitor_url_id === urlId && a.analysis_type === "scrape");
      if (!scrape) throw new Error("Először elemezd a versenytárs oldalt!");
      const { data: services } = await supabase.from("services").select("name, price").limit(50);
      return invoke("analyze_pricing", { competitor_data: scrape.results, own_prices: services || [], competitor_url_id: urlId });
    },
    onSuccess: (data) => { setResult(data); qc.invalidateQueries({ queryKey: ["competitor-analyses"] }); toast.success("Ár elemzés kész!"); },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><DollarSign className="h-5 w-5" />Ár/Akció Figyelő</CardTitle>
          <CardDescription>Versenytárs árak és akciók kinyerése és összehasonlítása</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2 flex-wrap">
            {urls.map((u) => (
              <Button key={u.id} variant={selectedUrl === u.id ? "default" : "outline"} size="sm"
                onClick={() => { setSelectedUrl(u.id); mut.mutate(u.id); }}
                disabled={mut.isPending}
              >
                {mut.isPending && selectedUrl === u.id ? <Loader2 className="h-3 w-3 animate-spin mr-1" /> : null}
                {u.name || u.url}
              </Button>
            ))}
          </div>
          {urls.length === 0 && <p className="text-muted-foreground">Először adj hozzá versenytársakat az SEO tab-on.</p>}
        </CardContent>
      </Card>

      {result && (
        <Card>
          <CardHeader><CardTitle>Ár Összehasonlítás</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            {result.pricing_comparison?.length > 0 && (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead><tr className="border-b"><th className="text-left py-2">Szolgáltatás</th><th className="text-left py-2">Saját ár</th><th className="text-left py-2">Versenytárs ár</th><th className="text-left py-2">Különbség</th><th className="text-left py-2">Javaslat</th></tr></thead>
                  <tbody>
                    {result.pricing_comparison.map((p: any, i: number) => (
                      <tr key={i} className="border-b"><td className="py-2">{p.service}</td><td className="py-2">{p.own_price}</td><td className="py-2">{p.competitor_price}</td><td className="py-2">{p.difference}</td><td className="py-2 text-muted-foreground">{p.recommendation}</td></tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            {result.promotions_found?.length > 0 && (
              <div>
                <h4 className="font-semibold mb-1">Talált akciók:</h4>
                <ul className="text-sm space-y-1">{result.promotions_found.map((p: string, i: number) => <li key={i}>• {p}</li>)}</ul>
              </div>
            )}
            {result.market_position && <p className="text-sm"><strong>Piaci pozíció:</strong> {result.market_position}</p>}
            {result.pricing_strategy && <p className="text-sm"><strong>Árstratégia javaslat:</strong> {result.pricing_strategy}</p>}
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// ─── Trends Tab ──────────────────────────────────────────────────────

function TrendsTab({ analyses, qc }: { analyses: Analysis[]; qc: any }) {
  const [result, setResult] = useState<any>(null);

  const mut = useMutation({
    mutationFn: () => invoke("predict_trends", {
      analyses_history: analyses.slice(0, 20).map((a) => ({ type: a.analysis_type, results: a.results, date: a.created_at })),
      market_context: { industry: "foglalkozás-egészségügy", country: "Magyarország", year: new Date().getFullYear() },
    }),
    onSuccess: (data) => { setResult(data); qc.invalidateQueries({ queryKey: ["competitor-analyses"] }); toast.success("Trend előrejelzés kész!"); },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><TrendingUp className="h-5 w-5" />Marketing Trend Előrejelzés</CardTitle>
          <CardDescription>AI-alapú trend elemzés és versenyintenzitás becslés a foglalkozás-egészségügy területén</CardDescription>
        </CardHeader>
        <CardContent>
          <Button onClick={() => mut.mutate()} disabled={mut.isPending}>
            {mut.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <TrendingUp className="h-4 w-4 mr-1" />}
            Trend előrejelzés futtatása
          </Button>
        </CardContent>
      </Card>

      {result && (
        <>
          {result.trends?.length > 0 && (
            <Card>
              <CardHeader><CardTitle>Trendek</CardTitle></CardHeader>
              <CardContent className="space-y-2">
                {result.trends.map((tr: any, i: number) => (
                  <div key={i} className="flex items-center gap-3 border rounded p-2">
                    <Badge variant={tr.direction === "rising" ? "default" : tr.direction === "declining" ? "destructive" : "secondary"}>
                      {tr.direction === "rising" ? "↑" : tr.direction === "declining" ? "↓" : "→"} {tr.direction}
                    </Badge>
                    <Badge variant={tr.impact === "high" ? "destructive" : "outline"}>{tr.impact}</Badge>
                    <span className="font-medium flex-1">{tr.trend}</span>
                    {tr.timeframe && <span className="text-sm text-muted-foreground">{tr.timeframe}</span>}
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {result.competition_intensity && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  Versenyintenzitás
                  <Badge variant={result.competition_intensity.overall === "high" ? "destructive" : "secondary"}>
                    {result.competition_intensity.overall}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {result.competition_intensity.by_keyword?.map((kw: any, i: number) => (
                  <div key={i} className="flex items-center gap-3 py-1 border-b last:border-0">
                    <span className="font-medium">{kw.keyword}</span>
                    <Badge variant={kw.intensity === "high" ? "destructive" : kw.intensity === "low" ? "secondary" : "outline"}>{kw.intensity}</Badge>
                    <span className="text-sm text-muted-foreground flex-1">{kw.recommendation}</span>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {result.warnings?.length > 0 && (
            <Card className="border-destructive">
              <CardHeader><CardTitle className="flex items-center gap-2"><AlertTriangle className="h-5 w-5 text-destructive" />Figyelmeztetések</CardTitle></CardHeader>
              <CardContent>
                <ul className="space-y-1">{result.warnings.map((w: string, i: number) => <li key={i} className="text-sm">⚠️ {w}</li>)}</ul>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  );
}

// ─── History Tab ─────────────────────────────────────────────────────

function HistoryTab({ analyses, urls }: { analyses: Analysis[]; urls: CompetitorUrl[] }) {
  const urlMap = Object.fromEntries(urls.map((u) => [u.id, u]));
  const typeLabels: Record<string, string> = {
    scrape: "Scrape", seo_compare: "SEO összehasonlítás", content_gap: "Tartalom javaslat",
    pricing: "Ár elemzés", trend: "Trend előrejelzés", report: "Riport",
  };

  const handleExport = () => {
    const headers = ["Dátum", "Típus", "Versenytárs", "Eredmény (JSON)"];
    const rows = analyses.map((a) => [
      new Date(a.created_at).toLocaleString("hu"),
      typeLabels[a.analysis_type] || a.analysis_type,
      a.competitor_url_id ? urlMap[a.competitor_url_id]?.name || a.competitor_url_id : "—",
      JSON.stringify(a.results).slice(0, 500),
    ]);
    exportToCsv("marketing_elemzesek", headers, rows);
  };

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between">
        <div>
          <CardTitle>Keresési Előzmények</CardTitle>
          <CardDescription>{analyses.length} elemzés összesen</CardDescription>
        </div>
        <Button variant="outline" size="sm" onClick={handleExport}>CSV Export</Button>
      </CardHeader>
      <CardContent>
        <div className="space-y-2 max-h-[600px] overflow-auto">
          {analyses.map((a) => (
            <div key={a.id} className="flex items-center gap-3 border rounded p-2 text-sm">
              <span className="text-muted-foreground w-36 shrink-0">{new Date(a.created_at).toLocaleString("hu")}</span>
              <Badge variant="outline">{typeLabels[a.analysis_type] || a.analysis_type}</Badge>
              <span className="truncate flex-1">{a.competitor_url_id ? urlMap[a.competitor_url_id]?.name || "—" : "Általános"}</span>
            </div>
          ))}
          {analyses.length === 0 && <p className="text-muted-foreground text-center py-8">Még nincsenek elemzések.</p>}
        </div>
      </CardContent>
    </Card>
  );
}

// ─── Reports Tab ─────────────────────────────────────────────────────

function ReportsTab({ analyses, qc }: { analyses: Analysis[]; qc: any }) {
  const [report, setReport] = useState<string | null>(null);

  const mut = useMutation({
    mutationFn: () => invoke("generate_report", { analyses: analyses.slice(0, 30).map((a) => ({ type: a.analysis_type, results: a.results, date: a.created_at })) }),
    onSuccess: (data) => { setReport(data.report_markdown); qc.invalidateQueries({ queryKey: ["competitor-analyses"] }); toast.success("Riport elkészült!"); },
    onError: (e: Error) => toast.error(e.message),
  });

  // Show last saved report if available
  const lastReport = analyses.find((a) => a.analysis_type === "report");

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><BarChart3 className="h-5 w-5" />Executive Summary Generálás</CardTitle>
          <CardDescription>AI-generált összefoglaló riport az összes elemzés alapján</CardDescription>
        </CardHeader>
        <CardContent>
          <Button onClick={() => mut.mutate()} disabled={mut.isPending || analyses.length === 0}>
            {mut.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <FileText className="h-4 w-4 mr-1" />}
            Riport generálása
          </Button>
          {analyses.length === 0 && <p className="text-sm text-muted-foreground mt-2">Először futtass elemzéseket a többi tab-on.</p>}
        </CardContent>
      </Card>

      {(report || lastReport) && (
        <Card>
          <CardHeader><CardTitle>Marketing Riport</CardTitle></CardHeader>
          <CardContent className="prose prose-sm max-w-none dark:prose-invert">
            <ReactMarkdown>{report || lastReport?.results?.report_markdown || ""}</ReactMarkdown>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
