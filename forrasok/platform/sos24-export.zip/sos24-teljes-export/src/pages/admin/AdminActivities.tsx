import { useState, useRef } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Sparkles, Plus, Pencil, Trash2, Loader2, Wand2, GripVertical, Eye } from "lucide-react";
import { getIcon } from "@/lib/icon-map";
import IconPicker from "@/components/IconPicker";
import WysiwygEditor from "@/components/WysiwygEditor";
import OgImageGenerator from "@/components/OgImageGenerator";

interface Activity {
  id: string;
  name: string;
  slug: string;
  short_description: string | null;
  long_description: string | null;
  icon_name: string | null;
  image_url: string | null;
  seo_title: string | null;
  seo_description: string | null;
  seo_keywords: string | null;
  og_title: string | null;
  og_description: string | null;
  og_image: string | null;
  page_content: string | null;
  is_active: boolean;
  sort_order: number;
}

const emptyForm: Partial<Activity> = {
  name: "", slug: "", short_description: "", long_description: "",
  icon_name: "Stethoscope", image_url: "", seo_title: "", seo_description: "",
  seo_keywords: "", og_title: "", og_description: "", og_image: "",
  page_content: "", is_active: true, sort_order: 0,
};

function slugify(text: string): string {
  return text.toLowerCase()
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}

export default function AdminActivities() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState<Partial<Activity>>(emptyForm);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [aiLoading, setAiLoading] = useState<string | null>(null);
  const dragItem = useRef<number | null>(null);
  const dragOverItem = useRef<number | null>(null);
  const [dragIdx, setDragIdx] = useState<number | null>(null);

  const { data: activities, isLoading } = useQuery({
    queryKey: ["admin-activities"],
    queryFn: async () => {
      const { data, error } = await supabase.from("activities").select("*").order("sort_order");
      if (error) throw error;
      return data as Activity[];
    },
  });

  const upsert = useMutation({
    mutationFn: async () => {
      const payload = { ...form, slug: form.slug || slugify(form.name || "") };
      if (editingId) {
        const { error } = await supabase.from("activities").update(payload).eq("id", editingId);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("activities").insert(payload as any);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-activities"] });
      toast({ title: editingId ? t("common.saved") : t("common.created") });
      closeDialog();
    },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("activities").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["admin-activities"] }); toast({ title: t("common.deleted") }); },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  const reorder = useMutation({
    mutationFn: async (items: Activity[]) => {
      const updates = items.map((a, i) => supabase.from("activities").update({ sort_order: i }).eq("id", a.id));
      await Promise.all(updates);
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["admin-activities"] }),
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  const handleDragEnd = () => {
    if (dragItem.current === null || dragOverItem.current === null || !activities) {
      setDragIdx(null);
      return;
    }
    const reordered = [...activities];
    const [removed] = reordered.splice(dragItem.current, 1);
    reordered.splice(dragOverItem.current, 0, removed);
    dragItem.current = null;
    dragOverItem.current = null;
    setDragIdx(null);
    reorder.mutate(reordered);
  };

  const openCreate = () => { setEditingId(null); setForm(emptyForm); setDialogOpen(true); };
  const openEdit = (a: Activity) => { setEditingId(a.id); setForm(a); setDialogOpen(true); };
  const closeDialog = () => { setDialogOpen(false); setEditingId(null); setForm(emptyForm); };

  const aiGenerate = async (mode: "generate" | "refine" | "seo") => {
    if (!form.name?.trim()) { toast({ variant: "destructive", title: t("admin.nameRequired") }); return; }
    setAiLoading(mode);
    try {
      const body: any = { name: form.name, mode, language: "hu" };
      if (mode === "refine") {
        body.existing_content = { short: form.short_description, long: form.long_description, page: form.page_content };
      } else if (mode === "seo") {
        body.existing_content = form.page_content;
      }
      const { data, error } = await supabase.functions.invoke("ai-activity-content", { body });
      if (error) throw new Error(error.message);
      if (data.error) throw new Error(data.error);
      setForm((prev) => ({
        ...prev,
        ...(data.short_description && { short_description: data.short_description }),
        ...(data.long_description && { long_description: data.long_description }),
        ...(data.page_content && { page_content: data.page_content }),
        ...(data.seo_title && { seo_title: data.seo_title }),
        ...(data.seo_description && { seo_description: data.seo_description }),
        ...(data.seo_keywords && { seo_keywords: data.seo_keywords }),
        ...(data.og_title && { og_title: data.og_title }),
        ...(data.og_description && { og_description: data.og_description }),
        ...(data.suggested_icon && { icon_name: data.suggested_icon }),
        ...(!prev.slug && { slug: slugify(prev.name || "") }),
      }));
      toast({ title: t("admin.aiContentGenerated") });
    } catch (e: any) {
      toast({ variant: "destructive", title: t("admin.aiError"), description: e.message });
    } finally {
      setAiLoading(null);
    }
  };

  const set = (key: string, val: any) => setForm((p) => ({ ...p, [key]: val }));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Sparkles className="h-6 w-6 text-secondary" />
           <h1 className="text-2xl font-bold">{t("admin.activitiesTitle")}</h1>
        </div>
        <Button onClick={openCreate}><Plus className="h-4 w-4 mr-1" /> {t("admin.newActivity")}</Button>
      </div>

      <Card>
        <CardHeader><CardTitle className="text-lg">{t("admin.activitiesCount", { count: activities?.length ?? 0 })}</CardTitle></CardHeader>
        <CardContent className="overflow-x-auto">
          {isLoading ? (
            <div className="flex justify-center py-8"><Loader2 className="h-8 w-8 animate-spin text-muted-foreground" /></div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-8"></TableHead>
                   <TableHead>{t("admin.iconLabel")}</TableHead>
                  <TableHead>{t("common.name")}</TableHead>
                  <TableHead>{t("admin.slugLabel")}</TableHead>
                  <TableHead>{t("admin.shortDesc")}</TableHead>
                  <TableHead>{t("admin.seo")}</TableHead>
                  <TableHead>{t("admin.active")}</TableHead>
                  <TableHead>{t("common.actions")}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {(activities ?? []).map((a, idx) => {
                  const Icon = getIcon(a.icon_name);
                  return (
                    <TableRow
                      key={a.id}
                      draggable
                      onDragStart={() => { dragItem.current = idx; setDragIdx(idx); }}
                      onDragEnter={() => { dragOverItem.current = idx; }}
                      onDragOver={(e) => e.preventDefault()}
                      onDragEnd={handleDragEnd}
                      className={`cursor-grab active:cursor-grabbing ${dragIdx === idx ? "opacity-50" : ""}`}
                    >
                      <TableCell><GripVertical className="h-4 w-4 text-muted-foreground" /></TableCell>
                      <TableCell><Icon className="h-5 w-5 text-secondary" /></TableCell>
                      <TableCell className="font-medium">{a.name}</TableCell>
                      <TableCell className="text-muted-foreground text-sm">/{a.slug}</TableCell>
                      <TableCell className="max-w-[200px] truncate text-sm text-muted-foreground">{a.short_description || "—"}</TableCell>
                      <TableCell>
                        {a.seo_title ? <Badge variant="default" className="text-xs">✓</Badge> : <Badge variant="outline" className="text-xs">—</Badge>}
                      </TableCell>
                      <TableCell><Badge variant={a.is_active ? "default" : "secondary"}>{a.is_active ? t("common.yes") : t("common.no")}</Badge></TableCell>
                      <TableCell className="space-x-1">
                        <Button size="sm" variant="outline" onClick={() => openEdit(a)}><Pencil className="h-4 w-4" /></Button>
                        <Button size="sm" variant="outline" onClick={() => window.open(`/tevekenyseg/${a.slug}`, "_blank")}><Eye className="h-4 w-4" /></Button>
                        <Button size="sm" variant="ghost" className="text-destructive" onClick={() => remove.mutate(a.id)}><Trash2 className="h-4 w-4" /></Button>
                      </TableCell>
                    </TableRow>
                  );
                })}
                {(activities ?? []).length === 0 && (
                  <TableRow><TableCell colSpan={8} className="text-center text-muted-foreground py-8">{t("admin.noActivities")}</TableCell></TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={(v) => { if (!v) closeDialog(); else setDialogOpen(v); }}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingId ? t("admin.editActivity") : t("admin.newActivity")}</DialogTitle>
          </DialogHeader>

          <div className="flex flex-wrap gap-2 mb-4">
            <Button variant="outline" size="sm" onClick={() => aiGenerate("generate")} disabled={!!aiLoading}>
              {aiLoading === "generate" ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Sparkles className="h-4 w-4 mr-1" />}
              {t("admin.aiGenerate")}
            </Button>
            <Button variant="outline" size="sm" onClick={() => aiGenerate("refine")} disabled={!!aiLoading || !form.short_description}>
              {aiLoading === "refine" ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Wand2 className="h-4 w-4 mr-1" />}
              {t("admin.aiRefine")}
            </Button>
            <Button variant="outline" size="sm" onClick={() => aiGenerate("seo")} disabled={!!aiLoading}>
              {aiLoading === "seo" ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Sparkles className="h-4 w-4 mr-1" />}
              {t("admin.seoGenerate")}
            </Button>
          </div>

          <Tabs defaultValue="basic">
             <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="basic">{t("admin.basicData")}</TabsTrigger>
              <TabsTrigger value="content">{t("admin.content")}</TabsTrigger>
              <TabsTrigger value="seo">{t("admin.seo")}</TabsTrigger>
            </TabsList>

            <TabsContent value="basic" className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label>{t("admin.nameLabel")}</Label>
                  <Input value={form.name || ""} onChange={(e) => { set("name", e.target.value); if (!editingId) set("slug", slugify(e.target.value)); }} />
                </div>
                <div className="space-y-1.5">
                  <Label>{t("admin.slugLabel")}</Label>
                  <Input value={form.slug || ""} onChange={(e) => set("slug", e.target.value)} />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label>{t("admin.iconLabel")}</Label>
                  <IconPicker value={form.icon_name || "Stethoscope"} onChange={(v) => set("icon_name", v)} />
                </div>
                <div className="space-y-1.5">
                  <Label>{t("admin.imageUrl")}</Label>
                  <Input value={form.image_url || ""} onChange={(e) => set("image_url", e.target.value)} placeholder="https://..." />
                </div>
              </div>
              <div className="space-y-1.5">
                 <Label>{t("admin.shortDesc")}</Label>
                <Textarea value={form.short_description || ""} onChange={(e) => set("short_description", e.target.value)} rows={2} />
              </div>
              <div className="space-y-1.5">
                 <Label>{t("admin.longDesc")}</Label>
                <Textarea value={form.long_description || ""} onChange={(e) => set("long_description", e.target.value)} rows={4} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center gap-2">
                  <Switch checked={form.is_active ?? true} onCheckedChange={(v) => set("is_active", v)} />
                  <Label>{t("admin.active")}</Label>
                </div>
                <div className="space-y-1.5">
                  <Label>{t("admin.order")}</Label>
                  <Input type="number" value={form.sort_order ?? 0} onChange={(e) => set("sort_order", parseInt(e.target.value) || 0)} />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="content" className="space-y-4 mt-4">
              <div className="space-y-1.5">
                <Label>{t("admin.pageContent")}</Label>
                <Textarea value={form.page_content || ""} onChange={(e) => set("page_content", e.target.value)} rows={16} className="font-mono text-sm" />
              </div>
            </TabsContent>

            <TabsContent value="seo" className="space-y-4 mt-4">
              <div className="space-y-1.5">
                <Label>{t("admin.seoTitle60")}</Label>
                <Input value={form.seo_title || ""} onChange={(e) => set("seo_title", e.target.value)} maxLength={60} />
                <p className="text-xs text-muted-foreground">{(form.seo_title || "").length}/60</p>
              </div>
              <div className="space-y-1.5">
                <Label>{t("admin.seoDesc160")}</Label>
                <Textarea value={form.seo_description || ""} onChange={(e) => set("seo_description", e.target.value)} rows={2} maxLength={160} />
                <p className="text-xs text-muted-foreground">{(form.seo_description || "").length}/160</p>
              </div>
              <div className="space-y-1.5">
                 <Label>{t("admin.keywords")}</Label>
                <Input value={form.seo_keywords || ""} onChange={(e) => set("seo_keywords", e.target.value)} placeholder={t("admin.keywordsPlaceholder")} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label>OG Title</Label>
                  <Input value={form.og_title || ""} onChange={(e) => set("og_title", e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label>OG Image URL</Label>
                  <Input value={form.og_image || ""} onChange={(e) => set("og_image", e.target.value)} />
                </div>
                <OgImageGenerator
                  title={form.og_title || form.name || ""}
                  subtitle={form.short_description || undefined}
                  slug={form.slug || ""}
                  currentOgImage={form.og_image || null}
                  onImageGenerated={(url) => set("og_image", url)}
                />
              </div>
              <div className="space-y-1.5">
                <Label>OG Description</Label>
                <Textarea value={form.og_description || ""} onChange={(e) => set("og_description", e.target.value)} rows={2} />
              </div>
            </TabsContent>
          </Tabs>

          <div className="flex justify-end gap-2 pt-4 border-t">
             <Button variant="outline" onClick={closeDialog}>{t("admin.cancelBtn")}</Button>
            <Button onClick={() => upsert.mutate()} disabled={upsert.isPending || !form.name?.trim()}>
              {upsert.isPending && <Loader2 className="h-4 w-4 mr-1 animate-spin" />}
              {editingId ? t("common.save") : t("common.create")}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
