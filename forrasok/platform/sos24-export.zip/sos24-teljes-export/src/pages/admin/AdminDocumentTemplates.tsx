import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useDocumentTemplates, type DocumentTemplate, type TemplateField } from "@/hooks/use-document-templates";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { FileText, Save, GripVertical, Plus, Trash2 } from "lucide-react";
import { useTranslation } from "react-i18next";

const DOC_TYPE_ICONS: Record<string, string> = {
  opinion: "📋",
  exam_sheet: "🩺",
  referral: "📨",
  vaccination_cert: "💉",
  certificate: "📄",
};

const SOURCE_LABELS: Record<string, string> = {
  "static": "Statikus",
  "service": "Szolgáltatás",
  "profile.full_name": "Profil → Név",
  "profile.taj_number": "Profil → TAJ",
  "profile.birth_date": "Profil → Születési dátum",
  "profile.address": "Profil → Lakcím",
  "profile.signature_url": "Profil → Aláírás",
  "health_report": "Egészségügyi jelentés → Biometriai adatok",
  "patient_card.drug_allergies": "Törzskarton → Allergiák",
  "examination.result": "Vizsgálat → Eredmény",
  "examination.restrictions": "Vizsgálat → Korlátozások",
  "examination.valid_until": "Vizsgálat → Érvényesség",
  "examination.ai_notes": "Vizsgálat → AI megjegyzés",
  "examination.exam_type": "Vizsgálat → Típus",
  "examination.created_at": "Vizsgálat → Dátum",
  "examination.patient_data": "Vizsgálat → Anamnézis",
  "examination.clinical_findings": "Vizsgálat → Fizikális lelet",
  "opinion.opinion_date": "Vélemény → Dátum",
  "opinion.notes": "Vélemény → Megjegyzés",
  "referral.position": "Beutaló → Munkakör",
  "referral.exam_reason": "Beutaló → Vizsgálat oka",
  "referral.risk_factors": "Beutaló → Kockázati tényezők",
  "referral.feor": "Beutaló → FEOR",
  "referral.unit_name": "Beutaló → Szervezeti egység",
  "company.name": "Cég → Név",
  "questionnaire": "Kérdőív adatok",
  "patient_card": "Törzskarton",
  "vaccination.vaccine_name": "Oltás → Név",
  "vaccination.administered_date": "Oltás → Dátum",
  "vaccination.lot_number": "Oltás → Sarzsszám",
  "vaccination.expiry_date": "Oltás → Lejárat",
  "vaccination.administered_by": "Oltás → Beadta",
  "custom": "Egyedi tartalom",
};

export default function AdminDocumentTemplates() {
  const { t } = useTranslation();
  const { data: templates, isLoading } = useDocumentTemplates();
  const qc = useQueryClient();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editFields, setEditFields] = useState<TemplateField[]>([]);

  const startEdit = (template: DocumentTemplate) => {
    setEditingId(template.id);
    setEditFields([...template.fields]);
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditFields([]);
  };

  const toggleField = (index: number) => {
    setEditFields((prev) =>
      prev.map((f, i) => (i === index ? { ...f, visible: !f.visible } : f))
    );
  };

  const updateFieldLabel = (index: number, label: string) => {
    setEditFields((prev) =>
      prev.map((f, i) => (i === index ? { ...f, label } : f))
    );
  };

  const moveField = (index: number, direction: -1 | 1) => {
    const newFields = [...editFields];
    const targetIndex = index + direction;
    if (targetIndex < 0 || targetIndex >= newFields.length) return;
    [newFields[index], newFields[targetIndex]] = [newFields[targetIndex], newFields[index]];
    newFields.forEach((f, i) => (f.order = i + 1));
    setEditFields(newFields);
  };

  const addField = () => {
    setEditFields((prev) => [
      ...prev,
      {
        key: `custom_${Date.now()}`,
        label: "Új mező",
        source: "custom",
        visible: true,
        order: prev.length + 1,
      },
    ]);
  };

  const removeField = (index: number) => {
    setEditFields((prev) => {
      const updated = prev.filter((_, i) => i !== index);
      updated.forEach((f, i) => (f.order = i + 1));
      return updated;
    });
  };

  const saveMutation = useMutation({
    mutationFn: async ({ id, fields }: { id: string; fields: TemplateField[] }) => {
      const { error } = await supabase
        .from("document_templates")
        .update({ fields: fields as any })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["document-templates"] });
      qc.invalidateQueries({ queryKey: ["document-template"] });
      toast.success(t("admin.saved"));
      cancelEdit();
    },
    onError: (e: any) => toast.error(e.message),
  });

  if (isLoading) return <div className="space-y-4">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-24" />)}</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <FileText className="h-6 w-6 text-primary" />
        <div>
          <h1 className="text-2xl font-bold">{t("admin.documentTemplates")}</h1>
          <p className="text-sm text-muted-foreground">{t("admin.documentTemplatesDesc")}</p>
        </div>
      </div>

      <Accordion type="single" collapsible className="space-y-3">
        {(templates ?? []).map((tpl) => {
          const isEditing = editingId === tpl.id;
          const fields = isEditing ? editFields : tpl.fields;
          const visibleCount = fields.filter((f) => f.visible).length;

          return (
            <AccordionItem key={tpl.id} value={tpl.id} className="border rounded-lg px-4">
              <AccordionTrigger className="hover:no-underline">
                <div className="flex items-center gap-3">
                  <span className="text-xl">{DOC_TYPE_ICONS[tpl.document_type] || "📄"}</span>
                  <div className="text-left">
                    <p className="font-semibold">{tpl.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {visibleCount}/{fields.length} mező aktív
                    </p>
                  </div>
                </div>
              </AccordionTrigger>
              <AccordionContent>
                <div className="space-y-2 pb-4">
                  {fields.map((field, idx) => (
                    <div
                      key={field.key}
                      className={`flex items-center gap-3 p-2 rounded-md border ${
                        field.visible ? "bg-background" : "bg-muted/50 opacity-60"
                      }`}
                    >
                      {isEditing && (
                        <div className="flex flex-col gap-0.5">
                          <button
                            onClick={() => moveField(idx, -1)}
                            disabled={idx === 0}
                            className="text-xs text-muted-foreground hover:text-foreground disabled:opacity-30"
                          >
                            ▲
                          </button>
                          <button
                            onClick={() => moveField(idx, 1)}
                            disabled={idx === fields.length - 1}
                            className="text-xs text-muted-foreground hover:text-foreground disabled:opacity-30"
                          >
                            ▼
                          </button>
                        </div>
                      )}
                      {!isEditing && <GripVertical className="h-4 w-4 text-muted-foreground/40" />}

                      <Switch
                        checked={field.visible}
                        onCheckedChange={() => {
                          if (!isEditing) startEdit(tpl);
                          setTimeout(() => toggleField(idx), 0);
                        }}
                        disabled={!isEditing}
                      />

                      <div className="flex-1 min-w-0">
                        {isEditing ? (
                          <Input
                            value={field.label}
                            onChange={(e) => updateFieldLabel(idx, e.target.value)}
                            className="h-7 text-sm"
                          />
                        ) : (
                          <span className="text-sm font-medium">{field.label}</span>
                        )}
                      </div>

                      <Badge variant="outline" className="text-xs shrink-0">
                        {SOURCE_LABELS[field.source] || field.source}
                      </Badge>

                      {isEditing && field.source === "custom" && (
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-7 w-7"
                          onClick={() => removeField(idx)}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      )}
                    </div>
                  ))}

                  <div className="flex gap-2 pt-3">
                    {!isEditing ? (
                      <Button variant="outline" size="sm" onClick={() => startEdit(tpl)}>
                        {t("admin.edit")}
                      </Button>
                    ) : (
                      <>
                        <Button
                          size="sm"
                          onClick={() => addField()}
                          variant="outline"
                        >
                          <Plus className="h-4 w-4 mr-1" />
                          Mező hozzáadása
                        </Button>
                        <div className="flex-1" />
                        <Button variant="ghost" size="sm" onClick={cancelEdit}>
                          {t("common.cancel")}
                        </Button>
                        <Button
                          size="sm"
                          onClick={() => saveMutation.mutate({ id: tpl.id, fields: editFields })}
                          disabled={saveMutation.isPending}
                        >
                          <Save className="h-4 w-4 mr-1" />
                          {t("common.save")}
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>
          );
        })}
      </Accordion>
    </div>
  );
}
