import { useState, useMemo } from "react";
import { useTranslation } from "react-i18next";
import ServiceCategoryManager from "@/components/ServiceCategoryManager";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { Clipboard, Plus, Pencil, Trash2, Search, Sparkles, Loader2, Package, Clock, DollarSign, Check, PlusCircle } from "lucide-react";
import IconPicker from "@/components/IconPicker";
import { getIcon } from "@/lib/icon-map";

interface ServiceRow {
  id: string;
  name: string;
  description: string | null;
  category: string | null;
  duration_min: number;
  price: number | null;
  icon_name: string | null;
  is_active: boolean;
}

interface ServiceCategory {
  id: string;
  name: string;
  sort_order: number;
  is_active: boolean;
}

interface PremiumSuggestion {
  name: string;
  description: string;
  category: string;
  price_range: string;
  duration_min: number;
  icon_suggestion: string;
  is_package: boolean;
  package_includes?: string[];
}

const emptyForm = {
  name: "", description: "", category: "", duration_min: 30,
  price: 0, icon_name: "", is_active: true,
};

export default function AdminServices() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [editing, setEditing] = useState<ServiceRow | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterCategory, setFilterCategory] = useState("all");
  const [aiLoading, setAiLoading] = useState(false);

  // Premium suggestions state
  const [premiumOpen, setPremiumOpen] = useState(false);
  const [premiumLoading, setPremiumLoading] = useState(false);
  const [suggestions, setSuggestions] = useState<PremiumSuggestion[]>([]);
  const [addedNames, setAddedNames] = useState<Set<string>>(new Set());

  const generateAiDescription = async () => {
    if (!form.name) return;
    setAiLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("ai-activity-content", {
        body: { name: form.name, mode: "service_description", existing_content: form.description },
      });
      if (error) throw error;
      if (data?.description) {
        setForm((f) => ({ ...f, description: data.description }));
        toast({ title: t("admin.aiDescGenerated") });
      }
    } catch (e: any) {
      toast({ variant: "destructive", title: t("admin.aiError"), description: e.message });
    } finally {
      setAiLoading(false);
    }
  };

  const { data: services, isLoading } = useQuery({
    queryKey: ["admin-services"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("services")
        .select("id, name, description, category, duration_min, price, icon_name, is_active")
        .order("name");
      if (error) throw error;
      return data as ServiceRow[];
    },
  });

  const { data: categories } = useQuery({
    queryKey: ["service-categories"],
    queryFn: async () => {
      const { data, error } = await (supabase as any)
        .from("service_categories")
        .select("id, name, sort_order, is_active")
        .eq("is_active", true)
        .order("sort_order");
      if (error) throw error;
      return data as ServiceCategory[];
    },
  });

  const filtered = useMemo(() => {
    let list = services ?? [];
    if (filterCategory !== "all") {
      list = list.filter((s) => s.category === filterCategory);
    }
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      list = list.filter((s) =>
        s.name.toLowerCase().includes(q) || (s.category ?? "").toLowerCase().includes(q) || (s.description ?? "").toLowerCase().includes(q)
      );
    }
    return list;
  }, [services, filterCategory, searchTerm]);

  const uniqueCategories = useMemo(() => {
    const cats = new Set((services ?? []).map((s) => s.category).filter(Boolean) as string[]);
    return Array.from(cats).sort();
  }, [services]);

  const upsert = useMutation({
    mutationFn: async (values: typeof form & { id?: string }) => {
      const row = {
        name: values.name,
        description: values.description || null,
        category: values.category || null,
        duration_min: values.duration_min,
        price: values.price || null,
        icon_name: values.icon_name || null,
        is_active: values.is_active,
      };
      if (values.id) {
        const { error } = await supabase.from("services").update(row).eq("id", values.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("services").insert(row);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-services"] });
      toast({ title: editing ? t("admin.serviceUpdated") : t("admin.serviceCreated") });
      setDialogOpen(false);
      setEditing(null);
      setForm(emptyForm);
    },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  const deleteMut = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("services").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-services"] });
      toast({ title: t("admin.serviceDeleted") });
    },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  const openEdit = (s: ServiceRow) => {
    setEditing(s);
    setForm({
      name: s.name, description: s.description ?? "", category: s.category ?? "",
      duration_min: s.duration_min, price: s.price ?? 0, icon_name: s.icon_name ?? "",
      is_active: s.is_active,
    });
    setDialogOpen(true);
  };

  const openNew = () => { setEditing(null); setForm(emptyForm); setDialogOpen(true); };

  // Premium suggestions functions
  const fetchPremiumSuggestions = async () => {
    setPremiumLoading(true);
    setSuggestions([]);
    setAddedNames(new Set());
    try {
      const existingNames = (services ?? []).map((s) => s.name);
      const { data, error } = await supabase.functions.invoke("ai-activity-content", {
        body: { mode: "suggest_premium_services", existing_services: existingNames },
      });
      if (error) throw error;
      if (data?.suggestions) {
        setSuggestions(data.suggestions);
      }
    } catch (e: any) {
      toast({ variant: "destructive", title: t("admin.aiError"), description: e.message });
    } finally {
      setPremiumLoading(false);
    }
  };

  const openPremiumDialog = () => {
    setPremiumOpen(true);
    fetchPremiumSuggestions();
  };

  const addSuggestion = async (s: PremiumSuggestion) => {
    const desc = s.is_package && s.package_includes?.length
      ? `${s.description}\n\n📦 A csomag tartalma:\n${s.package_includes.map((i) => `• ${i}`).join("\n")}`
      : s.description;

    try {
      const { error } = await supabase.from("services").insert({
        name: s.name,
        description: desc,
        category: s.category,
        duration_min: s.duration_min,
        icon_name: s.icon_suggestion,
        is_active: true,
      });
      if (error) throw error;
      setAddedNames((prev) => new Set([...prev, s.name]));
      qc.invalidateQueries({ queryKey: ["admin-services"] });
      toast({ title: `${s.name} hozzáadva` });
    } catch (e: any) {
      toast({ variant: "destructive", title: t("common.error"), description: e.message });
    }
  };

  const addAllSuggestions = async () => {
    const toAdd = suggestions.filter((s) => !addedNames.has(s.name));
    for (const s of toAdd) {
      await addSuggestion(s);
    }
    toast({ title: `${toAdd.length} szolgáltatás hozzáadva` });
  };

  if (isLoading) {
    return <div className="flex items-center justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-3">
          <Clipboard className="h-6 w-6 text-secondary" />
          <h1 className="text-2xl font-bold">{t("admin.servicesTitle")}</h1>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={openPremiumDialog}>
            <Sparkles className="h-4 w-4 mr-2" />
            Prémium javaslatok
          </Button>
          <Button onClick={openNew}><Plus className="h-4 w-4 mr-2" /> {t("admin.newService")}</Button>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder={t("admin.searchByNameCategory")} value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="pl-9" />
        </div>
        <Select value={filterCategory} onValueChange={setFilterCategory}>
          <SelectTrigger className="w-full sm:w-48"><SelectValue placeholder={t("admin.categoryFilter")} /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t("admin.allCategories")}</SelectItem>
            {uniqueCategories.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <ServiceCategoryManager />

      <Card>
        <CardContent className="pt-6">
          <div className="hidden md:block overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t("admin.icon")}</TableHead>
                  <TableHead>{t("common.name")}</TableHead>
                  <TableHead>{t("admin.category")}</TableHead>
                  <TableHead>{t("admin.duration")}</TableHead>
                  <TableHead>{t("admin.price")}</TableHead>
                  <TableHead>{t("admin.active")}</TableHead>
                  <TableHead className="w-24">{t("common.actions")}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((s) => {
                  const Icon = getIcon(s.icon_name);
                  return (
                    <TableRow key={s.id}>
                      <TableCell><Icon className="h-4 w-4 text-muted-foreground" /></TableCell>
                      <TableCell className="font-medium">{s.name}</TableCell>
                      <TableCell>{s.category ? <Badge variant="secondary">{s.category}</Badge> : "—"}</TableCell>
                      <TableCell>{s.duration_min} {t("admin.minuteShort")}</TableCell>
                      <TableCell>{s.price ? `${s.price} ${t("admin.ftSuffix")}` : "—"}</TableCell>
                      <TableCell>
                        <span className={s.is_active ? "text-green-500" : "text-muted-foreground"}>{s.is_active ? t("admin.yes") : t("admin.no")}</span>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button size="sm" variant="ghost" onClick={() => openEdit(s)}><Pencil className="h-4 w-4" /></Button>
                          <Button size="sm" variant="ghost" className="text-destructive hover:text-destructive" onClick={() => deleteMut.mutate(s.id)}><Trash2 className="h-4 w-4" /></Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>

          <div className="md:hidden space-y-3">
            {filtered.map((s) => {
              const Icon = getIcon(s.icon_name);
              return (
                <div key={s.id} className="rounded-lg border p-3 space-y-1">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Icon className="h-4 w-4 text-muted-foreground" />
                      <p className="font-medium">{s.name}</p>
                    </div>
                    <div className="flex gap-1">
                      <Button size="sm" variant="ghost" onClick={() => openEdit(s)}><Pencil className="h-4 w-4" /></Button>
                      <Button size="sm" variant="ghost" className="text-destructive" onClick={() => deleteMut.mutate(s.id)}><Trash2 className="h-4 w-4" /></Button>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2 text-xs text-muted-foreground">
                    {s.category && <Badge variant="secondary" className="text-xs">{s.category}</Badge>}
                    <span>{s.duration_min} {t("admin.minuteShort")}</span>
                    {s.price && <span>{s.price} {t("admin.ftSuffix")}</span>}
                    <span className={s.is_active ? "text-green-500" : ""}>{s.is_active ? t("admin.active") : t("admin.inactive")}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Service edit/create dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing ? t("admin.editService") : t("admin.newService")}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label>{t("common.name")}</Label>
              <Input value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} />
            </div>
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <Label>{t("admin.description")}</Label>
                <Button type="button" size="sm" variant="outline" onClick={generateAiDescription} disabled={aiLoading || !form.name}>
                  {aiLoading ? <Loader2 className="h-3 w-3 mr-1 animate-spin" /> : <Sparkles className="h-3 w-3 mr-1" />}
                  {t("admin.aiGenerate")}
                </Button>
              </div>
              <Textarea value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} rows={2} />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>{t("admin.category")}</Label>
                <Select value={form.category} onValueChange={(v) => setForm((f) => ({ ...f, category: v }))}>
                  <SelectTrigger><SelectValue placeholder={t("admin.selectOption")} /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">{t("admin.none")}</SelectItem>
                    {(categories ?? []).map((c) => <SelectItem key={c.id} value={c.name}>{c.name}</SelectItem>)}
                    {uniqueCategories.filter((c) => !(categories ?? []).find((cat) => cat.name === c)).map((c) => (
                      <SelectItem key={c} value={c}>{c}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <IconPicker value={form.icon_name} onChange={(v) => setForm((f) => ({ ...f, icon_name: v }))} />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>{t("admin.durationMin")}</Label>
                <Input type="number" value={form.duration_min} onChange={(e) => setForm((f) => ({ ...f, duration_min: parseInt(e.target.value) || 0 }))} />
              </div>
              <div className="space-y-1.5">
                <Label>{t("admin.priceFt")}</Label>
                <Input type="number" value={form.price} onChange={(e) => setForm((f) => ({ ...f, price: parseInt(e.target.value) || 0 }))} />
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Switch checked={form.is_active} onCheckedChange={(v) => setForm((f) => ({ ...f, is_active: v }))} />
              <Label>{t("admin.active")}</Label>
            </div>
            <Button className="w-full" onClick={() => upsert.mutate({ ...form, id: editing?.id })} disabled={upsert.isPending || !form.name}>
              {editing ? t("common.save") : t("common.create")}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Premium suggestions dialog */}
      <Dialog open={premiumOpen} onOpenChange={setPremiumOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-primary" />
              Prémium szolgáltatások és csomagok
            </DialogTitle>
            <DialogDescription>
              AI által javasolt prémium szolgáltatások és csomagok a foglalkozás-egészségügy területéről.
            </DialogDescription>
          </DialogHeader>

          {premiumLoading ? (
            <div className="flex flex-col items-center justify-center py-16 gap-3">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <p className="text-sm text-muted-foreground">Prémium javaslatok generálása...</p>
            </div>
          ) : suggestions.length > 0 ? (
            <>
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm text-muted-foreground">{suggestions.length} javaslat</p>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={fetchPremiumSuggestions}>
                    <Sparkles className="h-3 w-3 mr-1" /> Újragenerálás
                  </Button>
                  <Button size="sm" onClick={addAllSuggestions} disabled={addedNames.size === suggestions.length}>
                    <PlusCircle className="h-3 w-3 mr-1" /> Összes hozzáadása
                  </Button>
                </div>
              </div>
              <ScrollArea className="flex-1 min-h-0 pr-3">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pb-4">
                  {suggestions.map((s, i) => {
                    const Icon = getIcon(s.icon_suggestion);
                    const added = addedNames.has(s.name);
                    return (
                      <Card key={i} className={`relative transition-opacity ${added ? "opacity-60" : ""}`}>
                        <CardContent className="p-4 space-y-2">
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex items-center gap-2">
                              <Icon className="h-5 w-5 text-primary shrink-0" />
                              <h3 className="font-semibold text-sm leading-tight">{s.name}</h3>
                            </div>
                            {s.is_package && (
                              <Badge variant="default" className="shrink-0 text-xs">
                                <Package className="h-3 w-3 mr-1" /> Csomag
                              </Badge>
                            )}
                          </div>

                          <p className="text-xs text-muted-foreground leading-relaxed">{s.description}</p>

                          {s.is_package && s.package_includes && s.package_includes.length > 0 && (
                            <div className="rounded-md bg-muted/50 p-2">
                              <p className="text-xs font-medium mb-1">A csomag tartalma:</p>
                              <ul className="text-xs text-muted-foreground space-y-0.5">
                                {s.package_includes.map((item, j) => (
                                  <li key={j} className="flex items-center gap-1">
                                    <Check className="h-3 w-3 text-primary shrink-0" />
                                    {item}
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )}

                          <div className="flex items-center gap-3 text-xs text-muted-foreground">
                            <Badge variant="secondary" className="text-xs">{s.category}</Badge>
                            <span className="flex items-center gap-1"><Clock className="h-3 w-3" />{s.duration_min} perc</span>
                            <span className="flex items-center gap-1"><DollarSign className="h-3 w-3" />{s.price_range}</span>
                          </div>

                          <Button
                            size="sm"
                            variant={added ? "secondary" : "outline"}
                            className="w-full"
                            disabled={added}
                            onClick={() => addSuggestion(s)}
                          >
                            {added ? (
                              <><Check className="h-3 w-3 mr-1" /> Hozzáadva</>
                            ) : (
                              <><Plus className="h-3 w-3 mr-1" /> Hozzáadás</>
                            )}
                          </Button>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </ScrollArea>
            </>
          ) : (
            <div className="flex flex-col items-center justify-center py-16 gap-3 text-muted-foreground">
              <Sparkles className="h-8 w-8" />
              <p className="text-sm">Nem sikerült javaslatokat generálni. Próbáld újra!</p>
              <Button size="sm" variant="outline" onClick={fetchPremiumSuggestions}>Újrapróbálás</Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
