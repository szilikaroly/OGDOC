import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { Plus, Search, Pencil, Save, X, BookOpen } from "lucide-react";
import type { IcdCode, IcdVersion } from "@/hooks/use-icd-codes";

const EMPTY_FORM = {
  code: "",
  version: "icd10" as IcdVersion,
  label_hu: "",
  label_en: "",
  parent_code: "",
  level: 0,
  synonyms: "",
  category: "",
  is_active: true,
};

export default function AdminIcdCodes() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [version, setVersion] = useState<IcdVersion | "all">("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<IcdCode | null>(null);
  const [form, setForm] = useState(EMPTY_FORM);

  const { data: codes = [], isLoading } = useQuery({
    queryKey: ["admin-icd-codes", search, version],
    queryFn: async () => {
      let q = supabase
        .from("icd_codes")
        .select("id, code, version, label_hu, label_en, parent_code, level, synonyms, category, is_active, created_at, updated_at")
        .order("code", { ascending: true })
        .limit(200);
      if (version !== "all") q = q.eq("version", version);
      if (search.trim()) q = q.or(`code.ilike.%${search.trim()}%,label_hu.ilike.%${search.trim()}%,label_en.ilike.%${search.trim()}%,synonyms.cs.{${search.trim()}}`);
      const { data, error } = await q;
      if (error) throw error;
      return (data ?? []) as IcdCode[];
    },
  });

  const saveMutation = useMutation({
    mutationFn: async () => {
      const payload = {
        code: form.code.trim(),
        version: form.version,
        label_hu: form.label_hu.trim(),
        label_en: form.label_en.trim() || null,
        parent_code: form.parent_code.trim() || null,
        level: form.level,
        synonyms: form.synonyms
          .split(",")
          .map((s) => s.trim().toLowerCase())
          .filter(Boolean),
        category: form.category.trim() || null,
        is_active: form.is_active,
      };
      if (editing) {
        const { error } = await supabase.from("icd_codes").update(payload).eq("id", editing.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("icd_codes").insert(payload);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-icd-codes"] });
      toast({ title: editing ? t("common.saved") : t("common.created") });
      closeDialog();
    },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  const toggleActive = useMutation({
    mutationFn: async ({ id, is_active }: { id: string; is_active: boolean }) => {
      const { error } = await supabase.from("icd_codes").update({ is_active }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["admin-icd-codes"] }),
  });

  const openCreate = () => {
    setEditing(null);
    setForm(EMPTY_FORM);
    setDialogOpen(true);
  };

  const openEdit = (code: IcdCode) => {
    setEditing(code);
    setForm({
      code: code.code,
      version: code.version,
      label_hu: code.label_hu,
      label_en: code.label_en || "",
      parent_code: code.parent_code || "",
      level: code.level,
      synonyms: (code.synonyms || []).join(", "),
      category: code.category || "",
      is_active: code.is_active,
    });
    setDialogOpen(true);
  };

  const closeDialog = () => {
    setDialogOpen(false);
    setEditing(null);
    setForm(EMPTY_FORM);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <BookOpen className="h-6 w-6 text-secondary" />
          <h1 className="text-2xl font-bold">{t("icd.adminTitle")}</h1>
        </div>
        <Button onClick={openCreate}>
          <Plus className="h-4 w-4 mr-2" />{t("icd.newCode")}
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">{t("icd.catalog")}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder={t("icd.searchPlaceholder")}
                className="pl-9"
              />
            </div>
            <Select value={version} onValueChange={(v) => setVersion(v as IcdVersion | "all")}>
              <SelectTrigger className="w-[160px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("icd.allVersions")}</SelectItem>
                <SelectItem value="icd10">ICD-10</SelectItem>
                <SelectItem value="icd11">ICD-11</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {isLoading ? (
            <div className="flex justify-center py-8"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>
          ) : (
            <div className="overflow-x-auto rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>{t("icd.code")}</TableHead>
                    <TableHead>{t("icd.version")}</TableHead>
                    <TableHead>{t("icd.labelHu")}</TableHead>
                    <TableHead>{t("icd.category")}</TableHead>
                    <TableHead>{t("common.status")}</TableHead>
                    <TableHead>{t("common.actions")}</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {codes.map((c) => (
                    <TableRow key={c.id}>
                      <TableCell className="font-mono font-medium">{c.code}</TableCell>
                      <TableCell><Badge variant="outline" className="uppercase">{c.version}</Badge></TableCell>
                      <TableCell>{c.label_hu}</TableCell>
                      <TableCell>{c.category || "—"}</TableCell>
                      <TableCell>
                        <Switch
                          checked={c.is_active}
                          onCheckedChange={(v) => toggleActive.mutate({ id: c.id, is_active: v })}
                        />
                      </TableCell>
                      <TableCell>
                        <Button size="sm" variant="outline" onClick={() => openEdit(c)}>
                          <Pencil className="h-3.5 w-3.5 mr-1" />{t("common.edit")}
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                  {codes.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                        {t("icd.noCodes")}
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing ? t("icd.editCode") : t("icd.newCode")}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>{t("icd.code")} *</Label>
                <Input value={form.code} onChange={(e) => setForm((f) => ({ ...f, code: e.target.value }))} />
              </div>
              <div className="space-y-1.5">
                <Label>{t("icd.version")} *</Label>
                <Select value={form.version} onValueChange={(v) => setForm((f) => ({ ...f, version: v as IcdVersion }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="icd10">ICD-10</SelectItem>
                    <SelectItem value="icd11">ICD-11</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>{t("icd.labelHu")} *</Label>
              <Input value={form.label_hu} onChange={(e) => setForm((f) => ({ ...f, label_hu: e.target.value }))} />
            </div>
            <div className="space-y-1.5">
              <Label>{t("icd.labelEn")}</Label>
              <Input value={form.label_en} onChange={(e) => setForm((f) => ({ ...f, label_en: e.target.value }))} />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>{t("icd.parentCode")}</Label>
                <Input value={form.parent_code} onChange={(e) => setForm((f) => ({ ...f, parent_code: e.target.value }))} />
              </div>
              <div className="space-y-1.5">
                <Label>{t("icd.level")}</Label>
                <Input type="number" value={form.level} onChange={(e) => setForm((f) => ({ ...f, level: parseInt(e.target.value || "0") }))} />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>{t("icd.category")}</Label>
              <Input value={form.category} onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))} />
            </div>
            <div className="space-y-1.5">
              <Label>{t("icd.synonyms")}</Label>
              <Textarea
                value={form.synonyms}
                onChange={(e) => setForm((f) => ({ ...f, synonyms: e.target.value }))}
                placeholder={t("icd.synonymsPlaceholder")}
                rows={2}
              />
            </div>
            <div className="flex items-center gap-2">
              <Switch
                checked={form.is_active}
                onCheckedChange={(v) => setForm((f) => ({ ...f, is_active: v }))}
              />
              <Label>{t("icd.isActive")}</Label>
            </div>
            <div className="flex gap-2 pt-2">
              <Button variant="outline" onClick={closeDialog} className="flex-1">
                <X className="h-4 w-4 mr-2" />{t("common.cancel")}
              </Button>
              <Button onClick={() => saveMutation.mutate()} disabled={saveMutation.isPending || !form.code.trim() || !form.label_hu.trim()} className="flex-1">
                <Save className="h-4 w-4 mr-2" />{t("common.save")}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
