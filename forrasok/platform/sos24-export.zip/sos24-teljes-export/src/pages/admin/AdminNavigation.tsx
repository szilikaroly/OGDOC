import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { Menu, Plus, Pencil, Trash2 } from "lucide-react";

interface NavLink {
  id: string;
  label: string;
  href: string;
  sort_order: number;
  is_active: boolean;
  parent_id: string | null;
}

const emptyForm = { label: "", href: "", sort_order: 0, is_active: true, parent_id: "" };

export default function AdminNavigation() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [editing, setEditing] = useState<NavLink | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [dialogOpen, setDialogOpen] = useState(false);

  const { data: links, isLoading } = useQuery({
    queryKey: ["admin-nav-links"],
    queryFn: async () => {
      const { data, error } = await supabase.from("navigation_links").select("id, label, href, sort_order, is_active, parent_id").order("sort_order");
      if (error) throw error;
      return data as NavLink[];
    },
  });

  const upsert = useMutation({
    mutationFn: async (values: typeof form & { id?: string }) => {
      const row = { label: values.label, href: values.href, sort_order: values.sort_order, is_active: values.is_active, parent_id: values.parent_id || null };
      if (values.id) {
        const { error } = await supabase.from("navigation_links").update(row).eq("id", values.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("navigation_links").insert(row);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-nav-links"] });
      qc.invalidateQueries({ queryKey: ["navigation-links"] });
      toast({ title: editing ? t("admin.menuItemUpdated") : t("admin.menuItemCreated") });
      setDialogOpen(false); setEditing(null); setForm(emptyForm);
    },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  const deleteMut = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("navigation_links").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["admin-nav-links"] }); toast({ title: t("admin.menuItemDeleted") }); },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  const openEdit = (l: NavLink) => {
    setEditing(l);
    setForm({ label: l.label, href: l.href, sort_order: l.sort_order, is_active: l.is_active, parent_id: l.parent_id ?? "" });
    setDialogOpen(true);
  };

  const openNew = () => { setEditing(null); setForm(emptyForm); setDialogOpen(true); };

  const topLinks = (links ?? []).filter((l) => !l.parent_id);
  const childLinks = (id: string) => (links ?? []).filter((l) => l.parent_id === id);

  if (isLoading) {
    return <div className="flex items-center justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Menu className="h-6 w-6 text-secondary" />
          <h1 className="text-2xl font-bold">{t("admin.navigationTitle")}</h1>
        </div>
        <Button onClick={openNew}><Plus className="h-4 w-4 mr-2" /> {t("admin.newMenuItem")}</Button>
      </div>

      <Card>
        <CardContent className="overflow-x-auto pt-6">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t("admin.menuItem")}</TableHead>
                <TableHead>{t("admin.url")}</TableHead>
                <TableHead>{t("admin.sortOrder")}</TableHead>
                <TableHead>{t("admin.active")}</TableHead>
                <TableHead className="w-24">{t("common.actions")}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {topLinks.map((l) => (
                <>
                  <TableRow key={l.id}>
                    <TableCell className="font-medium">{l.label}</TableCell>
                    <TableCell className="text-muted-foreground text-sm">{l.href}</TableCell>
                    <TableCell>{l.sort_order}</TableCell>
                    <TableCell><span className={l.is_active ? "text-green-500" : "text-muted-foreground"}>{l.is_active ? t("common.yes") : t("common.no")}</span></TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        <Button size="sm" variant="ghost" onClick={() => openEdit(l)}><Pencil className="h-4 w-4" /></Button>
                        <Button size="sm" variant="ghost" className="text-destructive" onClick={() => deleteMut.mutate(l.id)}><Trash2 className="h-4 w-4" /></Button>
                      </div>
                    </TableCell>
                  </TableRow>
                  {childLinks(l.id).map((c) => (
                    <TableRow key={c.id} className="bg-muted/30">
                      <TableCell className="pl-8 font-medium">↳ {c.label}</TableCell>
                      <TableCell className="text-muted-foreground text-sm">{c.href}</TableCell>
                      <TableCell>{c.sort_order}</TableCell>
                      <TableCell><span className={c.is_active ? "text-green-500" : "text-muted-foreground"}>{c.is_active ? t("common.yes") : t("common.no")}</span></TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button size="sm" variant="ghost" onClick={() => openEdit(c)}><Pencil className="h-4 w-4" /></Button>
                          <Button size="sm" variant="ghost" className="text-destructive" onClick={() => deleteMut.mutate(c.id)}><Trash2 className="h-4 w-4" /></Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editing ? t("admin.editMenuItem") : t("admin.newMenuItem")}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-1.5"><Label>{t("admin.labelName")}</Label><Input value={form.label} onChange={(e) => setForm((f) => ({ ...f, label: e.target.value }))} /></div>
            <div className="space-y-1.5"><Label>{t("admin.url")}</Label><Input value={form.href} onChange={(e) => setForm((f) => ({ ...f, href: e.target.value }))} placeholder="/szolgaltatasok" /></div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5"><Label>{t("admin.sortOrder")}</Label><Input type="number" value={form.sort_order} onChange={(e) => setForm((f) => ({ ...f, sort_order: parseInt(e.target.value) || 0 }))} /></div>
              <div className="space-y-1.5">
                <Label>{t("admin.parentMenuItem")}</Label>
                <Select value={form.parent_id} onValueChange={(v) => setForm((f) => ({ ...f, parent_id: v }))}>
                  <SelectTrigger><SelectValue placeholder={t("admin.noParent")} /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">{t("admin.none")}</SelectItem>
                    {topLinks.filter((l) => l.id !== editing?.id).map((l) => (<SelectItem key={l.id} value={l.id}>{l.label}</SelectItem>))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Switch checked={form.is_active} onCheckedChange={(v) => setForm((f) => ({ ...f, is_active: v }))} />
              <Label>{t("admin.active")}</Label>
            </div>
            <Button className="w-full" onClick={() => upsert.mutate({ ...form, id: editing?.id })} disabled={upsert.isPending || !form.label || !form.href}>
              {editing ? t("common.save") : t("common.create")}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}