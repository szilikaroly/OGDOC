import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Shield, Printer, Sparkles, Loader2, FileDown, Eye } from "lucide-react";
import { format } from "date-fns";
import AiAnalysisPanel from "@/components/AiAnalysisPanel";
import PrintableRiskAssessment from "@/components/PrintableRiskAssessment";
import { HAZARD_CATEGORIES, getRiskCategory, RISK_CATEGORY_LABELS, HazardCategoryKey } from "@/lib/hazard-catalog";
import DOMPurify from "dompurify";

const STATUS_COLORS: Record<string, string> = {
  draft: "bg-muted text-muted-foreground",
  in_review: "bg-yellow-100 text-yellow-800",
  approved: "bg-green-100 text-green-800",
  archived: "bg-gray-100 text-gray-600",
};

export default function MunkaltatoRiskAssessments() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const [filterStatus, setFilterStatus] = useState("all");
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [showMerged, setShowMerged] = useState(false);
  const [aiGenerating, setAiGenerating] = useState(false);
  const [aiContent, setAiContent] = useState<string | null>(null);
  const [viewingId, setViewingId] = useState<string | null>(null);

  // Get employer's companies
  const { data: companyIds = [] } = useQuery({
    queryKey: ["munkaltato-companies", user?.id],
    queryFn: async () => {
      const { data } = await supabase.from("user_company_relations").select("company_id").eq("user_id", user!.id).eq("role", "munkaltato");
      return data?.map((c) => c.company_id) ?? [];
    },
    enabled: !!user,
  });

  const { data: companies = [] } = useQuery({
    queryKey: ["munkaltato-company-names", companyIds],
    queryFn: async () => {
      const { data } = await supabase.from("companies").select("id, name, industry, address").in("id", companyIds);
      return data ?? [];
    },
    enabled: !!companyIds.length,
  });

  // Get assessments for employer's companies
  const { data: assessments = [], isLoading } = useQuery({
    queryKey: ["munkaltato-risk-assessments", companyIds, filterStatus],
    queryFn: async () => {
      let q = supabase
        .from("risk_assessments")
        .select("*, work_areas!inner(name, site_id, company_sites!inner(name))")
        .in("company_id", companyIds)
        .order("created_at", { ascending: false });
      if (filterStatus !== "all") q = q.eq("status", filterStatus as any);
      const { data } = await q;
      return data ?? [];
    },
    enabled: !!companyIds.length,
  });

  // Load hazards for selected assessments (for merged view)
  const { data: allHazards = [] } = useQuery({
    queryKey: ["munkaltato-ra-hazards", selectedIds],
    queryFn: async () => {
      if (!selectedIds.length) return [];
      const { data } = await supabase
        .from("risk_assessment_hazards")
        .select("*")
        .in("risk_assessment_id", selectedIds)
        .order("sort_order");
      return data ?? [];
    },
    enabled: selectedIds.length > 0,
  });

  // Load hazards for single view
  const { data: viewHazards = [] } = useQuery({
    queryKey: ["munkaltato-ra-hazards-view", viewingId],
    queryFn: async () => {
      if (!viewingId) return [];
      const { data } = await supabase
        .from("risk_assessment_hazards")
        .select("*")
        .eq("risk_assessment_id", viewingId)
        .order("sort_order");
      return data ?? [];
    },
    enabled: !!viewingId,
  });

  const companyMap = Object.fromEntries(companies.map((c: any) => [c.id, c]));

  const toggleSelect = (id: string) => {
    setSelectedIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  const selectAll = () => {
    if (selectedIds.length === assessments.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(assessments.map((a: any) => a.id));
    }
  };

  const selectedAssessments = assessments.filter((a: any) => selectedIds.includes(a.id));

  const handleGenerateFullDocument = async () => {
    setAiGenerating(true);
    setShowMerged(true);
    setAiContent(null);
    try {
      const hazardsByAssessment = selectedAssessments.map((a: any) => {
        const hazards = allHazards.filter((h: any) => h.risk_assessment_id === a.id);
        return {
          workArea: (a.work_areas as any)?.name,
          site: (a.work_areas as any)?.company_sites?.name,
          company: companyMap[a.company_id]?.name,
          date: a.assessment_date,
          assessor: a.assessor_name,
          hazards: hazards.map((h: any) => ({
            name: h.hazard_name,
            category: h.hazard_category,
            probability: h.probability,
            severity: h.severity,
            risk: h.probability * h.severity,
            currentControls: h.current_controls,
            requiredActions: h.required_actions,
            actionResponsible: h.action_responsible,
            actionDeadline: h.action_deadline,
            residualRisk: (h.residual_probability ?? 1) * (h.residual_severity ?? 1),
          })),
        };
      });

      const { data: result, error } = await supabase.functions.invoke("ai-analysis", {
        body: {
          type: "risk_assessment_summary",
          data: {
            companyName: companies[0]?.name,
            siteName: "Összes telephely",
            workAreaName: "Összesített kockázatértékelés",
            assessorName: selectedAssessments[0]?.assessor_name,
            assessmentDate: new Date().toISOString().slice(0, 10),
            totalHazards: allHazards.length,
            highRiskCount: allHazards.filter((h: any) => h.probability * h.severity >= 6).length,
            tolerableCount: allHazards.filter((h: any) => h.probability * h.severity <= 4).length,
            summaryNotes: `Összesített értékelés ${selectedAssessments.length} munkaterületről.\n\nMunkaterületek:\n${hazardsByAssessment.map(h => `- ${h.site} / ${h.workArea}: ${h.hazards.length} veszélyforrás`).join("\n")}`,
            hazards: allHazards.map((h: any) => ({
              name: h.hazard_name,
              category: h.hazard_category,
              probability: h.probability,
              severity: h.severity,
              currentControls: h.current_controls,
              requiredActions: h.required_actions,
              residualProbability: h.residual_probability,
              residualSeverity: h.residual_severity,
            })),
          },
        },
      });
      if (error) throw error;
      setAiContent(result.analysis);
    } catch (e: any) {
      console.error(e);
    } finally {
      setAiGenerating(false);
    }
  };

  const viewingAssessment = viewingId ? assessments.find((a: any) => a.id === viewingId) : null;

  // Stats
  const totalHazards = allHazards.length;
  const highRisk = allHazards.filter((h: any) => h.probability * h.severity >= 6).length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Shield className="h-6 w-6" />
          {t("risk.riskAssessments")}
        </h1>
        <div className="flex gap-2">
          {selectedIds.length >= 1 && (
            <Button onClick={handleGenerateFullDocument} disabled={aiGenerating}>
              {aiGenerating ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Sparkles className="h-4 w-4 mr-1" />}
              AI összesített dokumentum ({selectedIds.length})
            </Button>
          )}
        </div>
      </div>

      <div className="flex gap-3 items-center flex-wrap">
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-[180px]"><SelectValue placeholder={t("risk.status")} /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t("common.all")}</SelectItem>
            <SelectItem value="draft">{t("risk.statusDraft")}</SelectItem>
            <SelectItem value="in_review">{t("risk.statusInReview")}</SelectItem>
            <SelectItem value="approved">{t("risk.statusApproved")}</SelectItem>
            <SelectItem value="archived">{t("risk.statusArchived")}</SelectItem>
          </SelectContent>
        </Select>
        {assessments.length > 0 && (
          <Button variant="outline" size="sm" onClick={selectAll}>
            {selectedIds.length === assessments.length ? "Kijelölés törlése" : "Összes kijelölése"}
          </Button>
        )}
      </div>

      {/* Summary cards when items selected */}
      {selectedIds.length > 0 && (
        <div className="grid gap-4 sm:grid-cols-4">
          <Card><CardContent className="py-3 text-center"><p className="text-2xl font-bold">{selectedIds.length}</p><p className="text-xs text-muted-foreground">Kiválasztott területek</p></CardContent></Card>
          <Card><CardContent className="py-3 text-center"><p className="text-2xl font-bold">{totalHazards}</p><p className="text-xs text-muted-foreground">Összes veszélyforrás</p></CardContent></Card>
          <Card><CardContent className="py-3 text-center"><p className="text-2xl font-bold text-destructive">{highRisk}</p><p className="text-xs text-muted-foreground">Magas kockázat</p></CardContent></Card>
          <Card><CardContent className="py-3 text-center"><p className="text-2xl font-bold text-chart-2">{totalHazards - highRisk}</p><p className="text-xs text-muted-foreground">Elfogadható</p></CardContent></Card>
        </div>
      )}

      {/* Table */}
      {assessments.length === 0 && !isLoading ? (
        <Card>
          <CardContent className="py-10 text-center text-muted-foreground">
            <p>Nincs kockázatértékelés a céghez.</p>
            <p className="text-sm">Az üzemorvos hozza létre a kockázatértékeléseket.</p>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-10"></TableHead>
                <TableHead>{t("risk.company")}</TableHead>
                <TableHead>Telephely</TableHead>
                <TableHead>{t("risk.workArea")}</TableHead>
                <TableHead>{t("risk.assessmentDate")}</TableHead>
                <TableHead>{t("risk.assessorName")}</TableHead>
                <TableHead>{t("risk.status")}</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {assessments.map((a: any) => (
                <TableRow key={a.id} className={selectedIds.includes(a.id) ? "bg-primary/5" : ""}>
                  <TableCell>
                    <Checkbox
                      checked={selectedIds.includes(a.id)}
                      onCheckedChange={() => toggleSelect(a.id)}
                    />
                  </TableCell>
                  <TableCell>{companyMap[a.company_id]?.name ?? "—"}</TableCell>
                  <TableCell>{(a.work_areas as any)?.company_sites?.name ?? "—"}</TableCell>
                  <TableCell className="font-medium">{(a.work_areas as any)?.name ?? "—"}</TableCell>
                  <TableCell>{format(new Date(a.assessment_date), "yyyy-MM-dd")}</TableCell>
                  <TableCell>{a.assessor_name ?? "—"}</TableCell>
                  <TableCell>
                    <Badge className={STATUS_COLORS[a.status] ?? ""} variant="outline">
                      {t(`risk.status${a.status.charAt(0).toUpperCase() + a.status.slice(1).replace("_", "")}` as any)}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Button variant="ghost" size="icon" onClick={() => setViewingId(a.id)}>
                      <Eye className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      )}

      {/* Single assessment view dialog */}
      <Dialog open={!!viewingId} onOpenChange={() => setViewingId(null)}>
        <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Kockázatértékelés megtekintése</DialogTitle>
          </DialogHeader>
          {viewingAssessment && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div><span className="font-medium">Cég:</span> {companyMap[(viewingAssessment as any).company_id]?.name}</div>
                <div><span className="font-medium">Telephely:</span> {((viewingAssessment as any).work_areas as any)?.company_sites?.name}</div>
                <div><span className="font-medium">Munkaterület:</span> {((viewingAssessment as any).work_areas as any)?.name}</div>
                <div><span className="font-medium">Dátum:</span> {(viewingAssessment as any).assessment_date}</div>
                <div><span className="font-medium">Értékelő:</span> {(viewingAssessment as any).assessor_name}</div>
                <div><span className="font-medium">Következő felülvizsgálat:</span> {(viewingAssessment as any).next_review_date || "—"}</div>
              </div>

              {viewHazards.length > 0 && (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Veszélyforrás</TableHead>
                      <TableHead className="w-12 text-center">P</TableHead>
                      <TableHead className="w-12 text-center">S</TableHead>
                      <TableHead className="w-12 text-center">R</TableHead>
                      <TableHead>Jelenlegi kontrollok</TableHead>
                      <TableHead>Intézkedés</TableHead>
                      <TableHead className="w-12 text-center">MK</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {viewHazards.map((h: any) => {
                      const risk = h.probability * h.severity;
                      const rCat = getRiskCategory(h.probability, h.severity);
                      const residual = (h.residual_probability ?? 1) * (h.residual_severity ?? 1);
                      return (
                        <TableRow key={h.id}>
                          <TableCell className="font-medium text-sm">{h.hazard_name}</TableCell>
                          <TableCell className="text-center">{h.probability}</TableCell>
                          <TableCell className="text-center">{h.severity}</TableCell>
                          <TableCell className="text-center font-bold">
                            <Badge variant={risk >= 6 ? "destructive" : "secondary"}>{risk}</Badge>
                          </TableCell>
                          <TableCell className="text-xs">{h.current_controls || "—"}</TableCell>
                          <TableCell className="text-xs">{h.required_actions || "—"}</TableCell>
                          <TableCell className="text-center">{residual}</TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              )}

              <div className="flex gap-2">
                <Button variant="outline" onClick={() => window.print()}>
                  <Printer className="h-4 w-4 mr-1" /> Nyomtatás
                </Button>
                <AiAnalysisPanel
                  type="risk_assessment_summary"
                  title="AI összefoglaló"
                  buttonLabel="AI összefoglaló"
                  data={{
                    companyName: companyMap[(viewingAssessment as any).company_id]?.name,
                    siteName: ((viewingAssessment as any).work_areas as any)?.company_sites?.name,
                    workAreaName: ((viewingAssessment as any).work_areas as any)?.name,
                    assessorName: (viewingAssessment as any).assessor_name,
                    assessmentDate: (viewingAssessment as any).assessment_date,
                    totalHazards: viewHazards.length,
                    highRiskCount: viewHazards.filter((h: any) => h.probability * h.severity >= 6).length,
                    tolerableCount: viewHazards.filter((h: any) => h.probability * h.severity <= 4).length,
                    summaryNotes: (viewingAssessment as any).summary_notes,
                    hazards: viewHazards.map((h: any) => ({
                      name: h.hazard_name,
                      category: h.hazard_category,
                      probability: h.probability,
                      severity: h.severity,
                      currentControls: h.current_controls,
                      requiredActions: h.required_actions,
                      residualProbability: h.residual_probability,
                      residualSeverity: h.residual_severity,
                    })),
                  }}
                />
              </div>

              {/* Hidden printable */}
              <PrintableRiskAssessment
                assessment={{
                  title: (viewingAssessment as any).title || "Kockázatértékelés",
                  company_name: companyMap[(viewingAssessment as any).company_id]?.name || "",
                  work_area_name: ((viewingAssessment as any).work_areas as any)?.name || "",
                  site_name: ((viewingAssessment as any).work_areas as any)?.company_sites?.name || "",
                  assessment_date: (viewingAssessment as any).assessment_date,
                  assessor_name: (viewingAssessment as any).assessor_name,
                  assessor_qualification: (viewingAssessment as any).assessor_qualification,
                  next_review_date: (viewingAssessment as any).next_review_date,
                  status: (viewingAssessment as any).status,
                  summary_notes: (viewingAssessment as any).summary_notes,
                }}
                hazards={viewHazards}
              />
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Merged document dialog */}
      <Dialog open={showMerged} onOpenChange={setShowMerged}>
        <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Összesített kockázatértékelési dokumentum</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {aiGenerating ? (
              <div className="flex items-center justify-center gap-3 py-12">
                <Loader2 className="h-6 w-6 animate-spin text-primary" />
                <span className="text-muted-foreground">AI összefoglaló generálása... ({selectedIds.length} munkaterület, {allHazards.length} veszélyforrás)</span>
              </div>
            ) : aiContent ? (
              <>
                <div className="prose prose-sm max-w-none dark:prose-invert">
                  <div dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(aiContent.replace(/\n/g, "<br/>").replace(/#{1,3}\s(.+)/g, "<h3>$1</h3>").replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>"), { ALLOWED_TAGS: ["br","h3","strong","em","p","ul","ol","li"], ALLOWED_ATTR: [] }) }} />
                </div>

                {/* Detailed tables per work area */}
                {selectedAssessments.map((a: any) => {
                  const aHazards = allHazards.filter((h: any) => h.risk_assessment_id === a.id);
                  const waName = (a.work_areas as any)?.name;
                  const siteName = (a.work_areas as any)?.company_sites?.name;
                  return (
                    <Card key={a.id}>
                      <CardHeader className="py-3">
                        <CardTitle className="text-sm">{siteName} — {waName}</CardTitle>
                      </CardHeader>
                      <CardContent className="p-0 overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Veszélyforrás</TableHead>
                              <TableHead className="w-10 text-center">P</TableHead>
                              <TableHead className="w-10 text-center">S</TableHead>
                              <TableHead className="w-10 text-center">R</TableHead>
                              <TableHead>Intézkedés</TableHead>
                              <TableHead className="w-20">Felelős</TableHead>
                              <TableHead className="w-20">Határidő</TableHead>
                              <TableHead className="w-10 text-center">MK</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {aHazards.map((h: any) => {
                              const risk = h.probability * h.severity;
                              const residual = (h.residual_probability ?? 1) * (h.residual_severity ?? 1);
                              return (
                                <TableRow key={h.id}>
                                  <TableCell className="text-sm">{h.hazard_name}</TableCell>
                                  <TableCell className="text-center">{h.probability}</TableCell>
                                  <TableCell className="text-center">{h.severity}</TableCell>
                                  <TableCell className="text-center">
                                    <Badge variant={risk >= 6 ? "destructive" : "secondary"} className="text-xs">{risk}</Badge>
                                  </TableCell>
                                  <TableCell className="text-xs">{h.required_actions || "—"}</TableCell>
                                  <TableCell className="text-xs">{h.action_responsible || "—"}</TableCell>
                                  <TableCell className="text-xs">{h.action_deadline ? format(new Date(h.action_deadline), "yyyy-MM-dd") : "—"}</TableCell>
                                  <TableCell className="text-center">{residual}</TableCell>
                                </TableRow>
                              );
                            })}
                          </TableBody>
                        </Table>
                      </CardContent>
                    </Card>
                  );
                })}

                <div className="flex gap-2 print:hidden">
                  <Button onClick={() => window.print()} variant="outline">
                    <Printer className="h-4 w-4 mr-1" /> Nyomtatás
                  </Button>
                </div>
              </>
            ) : (
              <p className="text-center text-muted-foreground py-8">Nem sikerült a dokumentum generálása.</p>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
