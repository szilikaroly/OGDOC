import { useTranslation } from "react-i18next";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import AccidentReportList from "@/components/AccidentReportList";

export default function MunkaltatoAccidents() {
  const { t } = useTranslation();
  const { user } = useAuth();

  const { data: companyId } = useQuery({
    queryKey: ["my-company-id", user?.id],
    queryFn: async () => {
      const { data } = await supabase.from("user_company_relations").select("company_id").eq("user_id", user!.id).eq("role", "munkaltato").limit(1).single();
      return (data as any)?.company_id as string | null;
    },
    enabled: !!user,
  });

  if (!companyId) {
    return <div className="text-center py-12 text-muted-foreground">{t("inner.noCompanyAssigned")}</div>;
  }

  return <AccidentReportList companyId={companyId} />;
}
