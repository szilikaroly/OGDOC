import { useTranslation } from "react-i18next";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/contexts/AuthContext";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Users, Building2, FileText, FileUp } from "lucide-react";
import AiAnalysisPanel from "@/components/AiAnalysisPanel";
import { BarChart, Bar, PieChart, Pie, Cell, ResponsiveContainer, XAxis, YAxis, Tooltip } from "recharts";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

const RESULT_COLORS: Record<string, string> = {
  alkalmas: "hsl(var(--chart-2))",
  nem_alkalmas: "hsl(var(--chart-1))",
  feltetelesen_alkalmas: "hsl(var(--chart-3))",
  ideiglenes: "hsl(var(--chart-4))",
};

export default function MunkaltatoDashboard() {
  const { t } = useTranslation();
  const { profile, user } = useAuth();

  const RESULT_LABELS: Record<string, string> = {
    alkalmas: t("page.fit"), nem_alkalmas: t("page.unfit"),
    feltetelesen_alkalmas: t("page.conditionallyFit"), ideiglenes: t("page.temporary"),
  };
  const STATUS_LABELS: Record<string, string> = {
    draft: t("page.draft"), sent: t("page.sent"), completed: t("page.completed"),
  };

  const { data: employeeCount } = useQuery({
    queryKey: ["munkaltato-employee-count"],
    queryFn: async () => {
      const { data: myCompanies } = await supabase.from("user_company_relations").select("company_id").eq("user_id", user!.id).eq("role", "munkaltato");
      if (!myCompanies?.length) return 0;
      const companyIds = myCompanies.map((c) => c.company_id);
      const { count } = await supabase.from("user_company_relations").select("id", { count: "exact", head: true }).in("company_id", companyIds).eq("role", "munkavallalo");
      return count ?? 0;
    },
    enabled: !!user,
  });

  const { data: companyCount } = useQuery({
    queryKey: ["munkaltato-company-count"],
    queryFn: async () => {
      const { count } = await supabase.from("user_company_relations").select("id", { count: "exact", head: true }).eq("user_id", user!.id).eq("role", "munkaltato");
      return count ?? 0;
    },
    enabled: !!user,
  });

  const { data: referralCount } = useQuery({
    queryKey: ["munkaltato-referral-count"],
    queryFn: async () => {
      const { count } = await supabase.from("referrals").select("id", { count: "exact", head: true }).neq("status", "completed");
      return count ?? 0;
    },
  });

  const { data: opinionCount } = useQuery({
    queryKey: ["munkaltato-opinion-count"],
    queryFn: async () => {
      const { count } = await supabase.from("medical_opinions").select("id", { count: "exact", head: true });
      return count ?? 0;
    },
  });

  const { data: referralStatusData } = useQuery({
    queryKey: ["munkaltato-referral-status"],
    queryFn: async () => {
      const { data } = await supabase.from("referrals").select("status");
      const counts: Record<string, number> = { draft: 0, sent: 0, completed: 0 };
      data?.forEach((r) => { counts[r.status] = (counts[r.status] || 0) + 1; });
      return Object.entries(counts).map(([status, count]) => ({ [t("page.status")]: STATUS_LABELS[status] || status, [t("page.count")]: count }));
    },
  });

  const { data: resultDist } = useQuery({
    queryKey: ["munkaltato-result-dist"],
    queryFn: async () => {
      const { data } = await supabase.from("examinations").select("result");
      const counts: Record<string, number> = {};
      data?.forEach((e) => { counts[e.result] = (counts[e.result] || 0) + 1; });
      return Object.entries(counts).map(([name, value]) => ({ name: RESULT_LABELS[name] || name, value, color: RESULT_COLORS[name] || "hsl(var(--chart-5))" }));
    },
  });

  const { data: expiringExams } = useQuery({
    queryKey: ["munkaltato-expiring-exams"],
    queryFn: async () => {
      const today = new Date().toISOString().split("T")[0];
      const in30 = new Date(Date.now() + 30 * 86400000).toISOString().split("T")[0];
      const { data } = await supabase.from("examinations").select("id, patient_id, valid_until, result, exam_type, restrictions").not("valid_until", "is", null).lte("valid_until", in30).order("valid_until", { ascending: true }).limit(10);
      if (!data?.length) return [];
      const ids = [...new Set(data.map((e) => e.patient_id))];
      const { data: profiles } = await supabase.from("profiles").select("user_id, full_name").in("user_id", ids);
      const nameMap = Object.fromEntries(profiles?.map((p) => [p.user_id, p.full_name]) ?? []);
      return data.map((e) => ({ ...e, patientName: nameMap[e.patient_id] || "—", expired: e.valid_until! < today }));
    },
  });

  const stats = [
    { label: t("page.employees"), icon: Users, value: employeeCount ?? "—" },
    { label: t("page.companies"), icon: Building2, value: companyCount ?? "—" },
    { label: t("page.activeReferrals"), icon: FileUp, value: referralCount ?? "—" },
    { label: t("page.opinions"), icon: FileText, value: opinionCount ?? "—" },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">{t("page.welcomeUser", { name: profile?.full_name })}</h1>
        <p className="text-muted-foreground">{t("page.employerOverview")}</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s) => (
          <Card key={s.label} className="card-luxury">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">{s.label}</CardTitle>
              <s.icon className="h-5 w-5 text-secondary" />
            </CardHeader>
            <CardContent><p className="text-2xl font-bold">{s.value}</p></CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader><CardTitle className="text-base">{t("page.referralStatus")}</CardTitle></CardHeader>
          <CardContent>
            {referralStatusData?.some((d) => (d as any)[t("page.count")] > 0) ? (
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={referralStatusData}>
                  <XAxis dataKey={t("page.status")} tick={{ fontSize: 12 }} />
                  <YAxis allowDecimals={false} />
                  <Tooltip />
                  <Bar dataKey={t("page.count")} fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : <p className="text-muted-foreground text-sm">{t("common.noData")}</p>}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">{t("page.fitnessDistribution")}</CardTitle></CardHeader>
          <CardContent>
            {resultDist?.length ? (
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie data={resultDist} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
                    {resultDist.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            ) : <p className="text-muted-foreground text-sm">{t("common.noData")}</p>}
          </CardContent>
        </Card>
      </div>

      <AiAnalysisPanel
        type="employer_summary"
        data={{
          employee_count: employeeCount ?? 0,
          exam_results: resultDist?.reduce((acc: any, d: any) => { acc[d.name] = d.value; return acc; }, {}) ?? {},
          expiring_count: expiringExams?.filter((e: any) => !e.expired).length ?? 0,
          expired_count: expiringExams?.filter((e: any) => e.expired).length ?? 0,
          referral_stats: referralStatusData?.reduce((acc: any, d: any) => { acc[d[t("page.status")]] = d[t("page.count")]; return acc; }, {}) ?? {},
        }}
        title={t("page.aiEmployerSummary")}
        buttonLabel={t("page.aiGenerateSummary")}
        variant="default"
      />

      <Card>
        <CardHeader><CardTitle className="text-base">{t("page.expiringFitnessExams")}</CardTitle></CardHeader>
         <CardContent className="overflow-x-auto">
          {expiringExams?.length ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t("page.employee")}</TableHead>
                  <TableHead>{t("page.type")}</TableHead>
                  <TableHead>{t("page.result")}</TableHead>
                  <TableHead>{t("page.restrictions")}</TableHead>
                  <TableHead>{t("page.expiry")}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {expiringExams.map((e) => (
                  <TableRow key={e.id} className={e.expired ? "bg-destructive/10" : "bg-yellow-500/10"}>
                    <TableCell>{e.patientName}</TableCell>
                    <TableCell>{e.exam_type}</TableCell>
                    <TableCell><Badge variant={e.expired ? "destructive" : "secondary"}>{RESULT_LABELS[e.result] || e.result}</Badge></TableCell>
                    <TableCell className="text-sm">{e.restrictions || "—"}</TableCell>
                    <TableCell>{e.valid_until}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : <p className="text-muted-foreground text-sm">{t("page.noExpiringExam")}</p>}
        </CardContent>
      </Card>
    </div>
  );
}
