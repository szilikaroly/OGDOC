import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { FileUp, Plus, Printer, Users } from "lucide-react";
import ExportButton from "@/components/ExportButton";
import PrintableReferral from "@/components/PrintableReferral";
import { useTranslation } from "react-i18next";
import FeorSearch from "@/components/FeorSearch";
import HazardousSubstanceSelector from "@/components/HazardousSubstanceSelector";
import BnoSearch from "@/components/BnoSearch";

const EXAM_REASONS = [
  "Munkába lépés előtti",
  "Munkakör változás",
  "Időszakos",
  "Soron kívüli",
  "Záróvizsgálat",
];

const REFERRAL_RISK_KEYS = [
  "referralRiskFactors.manualHandling", "referralRiskFactors.heavyPhysical", "referralRiskFactors.forcedPosition",
  "referralRiskFactors.screenWork", "referralRiskFactors.noise", "referralRiskFactors.vibrationHand", "referralRiskFactors.vibrationBody",
  "referralRiskFactors.ionizingRadiation", "referralRiskFactors.nonIonizingRadiation", "referralRiskFactors.chemicalAirway",
  "referralRiskFactors.chemicalSkin", "referralRiskFactors.biologicalAgent", "referralRiskFactors.dustFibrogenic",
  "referralRiskFactors.dustNonFibrogenic", "referralRiskFactors.nightShift", "referralRiskFactors.highTemperature",
  "referralRiskFactors.lowTemperature", "referralRiskFactors.heightWork", "referralRiskFactors.depthWork",
  "referralRiskFactors.driving", "referralRiskFactors.aloneWork", "referralRiskFactors.psychosocial", "referralRiskFactors.other",
];

export default function MunkaltatoReferrals() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [bulkDialogOpen, setBulkDialogOpen] = useState(false);
  const [bulkExamReason, setBulkExamReason] = useState("");
  const [printRef, setPrintRef] = useState<any>(null);
  const [form, setForm] = useState({
    employee_id: "", position: "", feor: "", unit_name: "", exam_reason: "",
    risk_factors: {} as Record<string, boolean>,
    site_id: "", work_area_id: "", risk_assessment_id: "",
    icd_codes: [] as string[],
  });

  const STATUS_LABELS: Record<string, string> = {
    draft: t("inner.draft"), sent: t("inner.sent"), appointment_booked: t("inner.appointmentBooked"),
    questionnaire_filled: t("inner.questionnaireFilled"), exam_started: t("inner.examStarted"), completed: t("inner.completed"),
  };

  const EXAM_REASON_KEYS = ["reasonPreEmployment", "reasonPositionChange", "reasonPeriodic", "reasonExtraordinary", "reasonFinalExam"] as const;
  const EXAM_REASON_OPTIONS = EXAM_REASON_KEYS.map((k, i) => ({ label: t(`inner.${k}`), value: EXAM_REASONS[i] }));

  const { data: myCompany } = useQuery({
    queryKey: ["my-company-id", user?.id],
    queryFn: async () => {
      const { data } = await supabase.from("user_company_relations").select("company_id").eq("user_id", user!.id).eq("role", "munkaltato").limit(1).single();
      return data?.company_id ?? null;
    },
    enabled: !!user,
  });

  // Sites for cascaded dropdown
  const { data: sites = [] } = useQuery({
    queryKey: ["company-sites-for-referral", myCompany],
    queryFn: async () => {
      const { data } = await supabase.from("company_sites").select("id, name").eq("company_id", myCompany!).order("name");
      return data ?? [];
    },
    enabled: !!myCompany,
  });

  // Work areas for selected site
  const { data: workAreas = [] } = useQuery({
    queryKey: ["work-areas-for-referral", form.site_id],
    queryFn: async () => {
      if (!form.site_id) return [];
      const { data } = await supabase.from("work_areas").select("id, name").eq("site_id", form.site_id).order("name");
      return data ?? [];
    },
    enabled: !!form.site_id,
  });

  // Auto-load risk assessment hazards when work area is selected
  const loadRiskHazards = async (workAreaId: string) => {
    if (!workAreaId) return;
    const { data: ra } = await supabase
      .from("risk_assessments")
      .select("id")
      .eq("work_area_id", workAreaId)
      .eq("status", "approved" as any)
      .order("assessment_date", { ascending: false })
      .limit(1);
    if (!ra || ra.length === 0) return;
    const raId = ra[0].id;
    setForm(f => ({ ...f, risk_assessment_id: raId }));

    const { data: hazards } = await supabase
      .from("risk_assessment_hazards")
      .select("hazard_name")
      .eq("risk_assessment_id", raId);
    if (!hazards) return;

    // Map hazard names to i18n risk factor keys
    const HAZARD_TO_RISK: Record<string, string> = {
      "Zaj": "referralRiskFactors.noise", "Zajterhelés": "referralRiskFactors.noise",
      "Kéz-kar rezgés": "referralRiskFactors.vibrationHand", "Egésztest rezgés": "referralRiskFactors.vibrationBody",
      "Kézi anyagmozgatás": "referralRiskFactors.manualHandling",
      "Képernyő előtti munka": "referralRiskFactors.screenWork",
      "Kényszerhelyzet": "referralRiskFactors.forcedPosition",
      "Ionizáló sugárzás": "referralRiskFactors.ionizingRadiation",
      "Nem ionizáló sugárzás": "referralRiskFactors.nonIonizingRadiation",
      "Porok": "referralRiskFactors.dustFibrogenic",
      "Oldószerek": "referralRiskFactors.chemicalAirway",
      "Savas/lúgos anyagok": "referralRiskFactors.chemicalSkin",
      "Éjszakai műszak": "referralRiskFactors.nightShift",
      "Hőterhelés – meleg": "referralRiskFactors.highTemperature",
      "Hőterhelés – hideg": "referralRiskFactors.lowTemperature",
      "Leesés magasból": "referralRiskFactors.heightWork",
      "Stressz, munkahelyi nyomás": "referralRiskFactors.psychosocial",
      "Baktériumok": "referralRiskFactors.biologicalAgent",
      "Nehéz fizikai munka": "referralRiskFactors.heavyPhysical",
    };

    setForm(prev => {
      const newRisks = { ...prev.risk_factors };
      hazards.forEach(h => {
        const mapped = HAZARD_TO_RISK[h.hazard_name];
        if (mapped) newRisks[mapped] = true;
      });
      return { ...prev, risk_factors: newRisks };
    });
  };

  const { data: employees } = useQuery({
    queryKey: ["company-employee-list", myCompany],
    queryFn: async () => {
      const { data } = await (supabase as any).from("user_company_relations").select("user_id, position, risk_factors, feor_code, feor_name").eq("company_id", myCompany!).eq("is_active", true);
      const userIds = (data ?? []).map((e: any) => e.user_id);
      const { data: profiles } = await supabase.from("profiles").select("user_id, full_name, taj_number, birth_date, birth_place, address, mother_name").in("user_id", userIds);
      return (data ?? []).map((e: any) => ({
        ...e,
        full_name: (profiles ?? []).find((p) => p.user_id === e.user_id)?.full_name ?? "—",
        taj_number: (profiles ?? []).find((p) => p.user_id === e.user_id)?.taj_number ?? null,
        birth_date: (profiles ?? []).find((p) => p.user_id === e.user_id)?.birth_date ?? null,
        birth_place: (profiles ?? []).find((p) => p.user_id === e.user_id)?.birth_place ?? null,
        address: (profiles ?? []).find((p) => p.user_id === e.user_id)?.address ?? null,
        mother_name: (profiles ?? []).find((p) => p.user_id === e.user_id)?.mother_name ?? null,
      }));
    },
    enabled: !!myCompany,
  });

  const { data: companyData } = useQuery({
    queryKey: ["my-company-data", myCompany],
    queryFn: async () => {
      const { data } = await supabase.from("companies").select("name, address, tax_number, contact_phone, contact_email").eq("id", myCompany!).single();
      return data;
    },
    enabled: !!myCompany,
  });

  // Load company TEÁOR codes
  const { data: companyTeaorCodes = [] } = useQuery({
    queryKey: ["company-teaor-for-referral", myCompany],
    queryFn: async () => {
      const { data } = await supabase.from("company_teaor_codes").select("teaor_code, teaor_name, is_primary").eq("company_id", myCompany!);
      return data ?? [];
    },
    enabled: !!myCompany,
  });

  const { data: referrals, isLoading } = useQuery({
    queryKey: ["company-referrals", myCompany],
    queryFn: async () => {
      const { data, error } = await supabase.from("referrals").select("*").eq("company_id", myCompany!).order("created_at", { ascending: false });
      if (error) throw error;
      const empIds = [...new Set(data.map((r) => r.employee_id))];
      const { data: profiles } = await supabase.from("profiles").select("user_id, full_name").in("user_id", empIds);
      return data.map((r) => ({ ...r, employee_name: (profiles ?? []).find((p) => p.user_id === r.employee_id)?.full_name ?? "—" }));
    },
    enabled: !!myCompany,
  });

  const createReferral = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("referrals").insert({
        company_id: myCompany!, employee_id: form.employee_id, created_by: user!.id,
        position: form.position || null, feor: form.feor || null, unit_name: form.unit_name || null,
        exam_reason: form.exam_reason, risk_factors: form.risk_factors, status: "sent" as any,
        work_area_id: form.work_area_id || null,
        risk_assessment_id: form.risk_assessment_id || null,
        icd_codes: form.icd_codes,
      }).select("id").single();
      if (error) throw error;
      // Save FEOR back to user_company_relations
      if (form.feor) {
        const feorMatch = (await import("@/lib/feor-codes")).FEOR_CODES.find(f => f.code === form.feor);
        await (supabase as any).from("user_company_relations")
          .update({ feor_code: form.feor, feor_name: feorMatch?.name || null })
          .eq("company_id", myCompany!)
          .eq("user_id", form.employee_id)
          .eq("is_active", true);
      }
      await supabase.functions.invoke("send-notification", {
        body: { type: "referral_received", recipient_id: form.employee_id, sender_id: user!.id, data: { exam_reason: form.exam_reason, company: "" } },
      });
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["company-referrals"] });
      qc.invalidateQueries({ queryKey: ["company-employee-list"] });
      toast({ title: t("inner.referralCreated") });
      setDialogOpen(false);
      setForm({ employee_id: "", position: "", feor: "", unit_name: "", exam_reason: "", risk_factors: {}, site_id: "", work_area_id: "", risk_assessment_id: "", icd_codes: [] });
    },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  const bulkEligible = useMemo(() => {
    return (employees ?? []).filter((e) => e.taj_number && e.birth_date && e.address && e.position);
  }, [employees]);

  const bulkCreate = useMutation({
    mutationFn: async () => {
      if (!bulkExamReason) throw new Error(t("inner.selectReason"));
      if (!bulkEligible.length) throw new Error(t("inner.noEmployeeAssigned"));
      for (const emp of bulkEligible) {
        const empRisks = emp.risk_factors && typeof emp.risk_factors === "object" && !Array.isArray(emp.risk_factors)
          ? emp.risk_factors as Record<string, boolean>
          : {};
        const { error } = await supabase.from("referrals").insert({
          company_id: myCompany!, employee_id: emp.user_id, created_by: user!.id,
          position: emp.position || null, feor: emp.feor_code || null,
          exam_reason: bulkExamReason, risk_factors: empRisks, status: "sent" as any,
        });
        if (error) throw error;
        await supabase.functions.invoke("send-notification", {
          body: { type: "referral_received", recipient_id: emp.user_id, sender_id: user!.id, data: { exam_reason: bulkExamReason, company: companyData?.name || "" } },
        });
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["company-referrals"] });
      toast({ title: t("inner.bulkReferralCreated", { count: bulkEligible.length }) });
      setBulkDialogOpen(false);
      setBulkExamReason("");
    },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  const primaryTeaor = companyTeaorCodes.find((t: any) => t.is_primary);

  const handlePrint = (ref: any) => {
    const emp = (employees ?? []).find((e) => e.user_id === ref.employee_id);
    setPrintRef({
      company_name: companyData?.name ?? "", 
      company_address: companyData?.address ?? "",
      company_tax_number: companyData?.tax_number ?? "",
      company_phone: companyData?.contact_phone ?? "",
      company_email: companyData?.contact_email ?? "",
      company_teaor: primaryTeaor ? `${primaryTeaor.teaor_code} — ${primaryTeaor.teaor_name || ""}` : "",
      employee_name: ref.employee_name ?? emp?.full_name ?? "",
      employee_birth_date: emp?.birth_date ?? null, employee_birth_place: emp?.birth_place ?? null,
      employee_address: emp?.address ?? null, employee_taj: emp?.taj_number ?? null,
      employee_mother_name: emp?.mother_name ?? null,
      position: ref.position, feor: ref.feor,
      unit_name: ref.unit_name, exam_reason: ref.exam_reason, risk_factors: ref.risk_factors ?? {}, created_at: ref.created_at,
    });
    setTimeout(() => window.print(), 300);
  };

  if (isLoading) return <div className="flex items-center justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>;

  return (
    <div className="space-y-6">
      {printRef && <PrintableReferral referral={printRef} />}

      <div className="flex items-center justify-between print:hidden">
        <div className="flex items-center gap-3">
          <FileUp className="h-6 w-6 text-secondary" />
          <h1 className="text-2xl font-bold">{t("inner.referrals")}</h1>
        </div>
        <div className="flex gap-2">
          <ExportButton
            filename="beutalok"
            headers={[t("inner.employee"), t("inner.position"), t("inner.reason"), t("inner.status"), t("inner.date")]}
            rows={(referrals ?? []).map((r) => [r.employee_name, r.position || "", r.exam_reason, STATUS_LABELS[r.status] ?? r.status, new Date(r.created_at).toLocaleDateString("hu-HU")])}
          />
          <Button variant="outline" onClick={() => setBulkDialogOpen(true)}>
            <Users className="h-4 w-4 mr-2" />{t("inner.bulkReferral")}
          </Button>
          <Button onClick={() => setDialogOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />{t("inner.newReferral")}
          </Button>
        </div>
      </div>

      <Card className="print:hidden">
        <CardHeader><CardTitle className="text-lg">{t("inner.referrals")} ({referrals?.length ?? 0})</CardTitle></CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t("inner.employee")}</TableHead>
                <TableHead>{t("inner.position")}</TableHead>
                <TableHead>{t("inner.examReason")}</TableHead>
                <TableHead>{t("inner.status")}</TableHead>
                <TableHead>{t("inner.date")}</TableHead>
                <TableHead>{t("inner.actions")}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {(referrals ?? []).map((r) => (
                <TableRow key={r.id}>
                  <TableCell className="font-medium">{r.employee_name}</TableCell>
                  <TableCell>{r.position || "—"}</TableCell>
                  <TableCell>{r.exam_reason}</TableCell>
                  <TableCell><Badge variant={r.status === "completed" ? "default" : "secondary"}>{STATUS_LABELS[r.status] ?? r.status}</Badge></TableCell>
                  <TableCell>{new Date(r.created_at).toLocaleDateString("hu-HU")}</TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      <Button variant="outline" size="sm" onClick={() => handlePrint(r)}><Printer className="h-3.5 w-3.5 mr-1" />{t("inner.print")}</Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
              {(referrals ?? []).length === 0 && (
                <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-8">{t("inner.noReferral")}</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{t("inner.newReferralTitle")}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label>{t("inner.employee")}</Label>
              <Select value={form.employee_id} onValueChange={async (v) => {
                const emp = (employees ?? []).find((e) => e.user_id === v);
                // Start with employee's stored position, FEOR & risk_factors
                let autoPosition = emp?.position || "";
                let autoFeor = emp?.feor_code || "";
                let autoRisks: Record<string, boolean> = {};
                // Parse risk_factors from user_company_relations
                if (emp?.risk_factors) {
                  if (typeof emp.risk_factors === "object" && !Array.isArray(emp.risk_factors)) {
                    autoRisks = { ...emp.risk_factors as Record<string, boolean> };
                  }
                }
                // Try to load latest referral for this employee to get previous risk_factors
                if (myCompany) {
                  const { data: prevRef } = await supabase
                    .from("referrals")
                    .select("position, feor, unit_name, risk_factors")
                    .eq("employee_id", v)
                    .eq("company_id", myCompany)
                    .order("created_at", { ascending: false })
                    .limit(1);
                  if (prevRef && prevRef.length > 0) {
                    const prev = prevRef[0];
                    if (prev.risk_factors && typeof prev.risk_factors === "object") {
                      const prevRf = prev.risk_factors as Record<string, boolean>;
                      Object.keys(prevRf).forEach((k) => {
                        if (!(k in autoRisks)) autoRisks[k] = prevRf[k];
                      });
                    }
                    if (!autoPosition && prev.position) autoPosition = prev.position;
                    if (!autoFeor && prev.feor) autoFeor = prev.feor;
                    setForm((f) => ({
                      ...f,
                      employee_id: v,
                      position: autoPosition,
                      feor: autoFeor || prev.feor || f.feor,
                      unit_name: prev.unit_name || f.unit_name,
                      risk_factors: autoRisks,
                    }));
                    return;
                  }
                }
                setForm((f) => ({ ...f, employee_id: v, position: autoPosition, feor: autoFeor, risk_factors: autoRisks }));
              }}>
                <SelectTrigger><SelectValue placeholder={t("inner.selectEmployee")} /></SelectTrigger>
                <SelectContent>{(employees ?? []).map((e) => <SelectItem key={e.user_id} value={e.user_id}>{e.full_name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5"><Label>{t("inner.positionName")}</Label><Input value={form.position} onChange={(e) => setForm((f) => ({ ...f, position: e.target.value }))} /></div>
              <div className="space-y-1.5">
                <Label>{t("inner.feorCode")}</Label>
                <FeorSearch
                  value={form.feor}
                  onChange={(v) => setForm((f) => ({ ...f, feor: v }))}
                  onPositionChange={(name) => { if (!form.position) setForm((f) => ({ ...f, position: name })); }}
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>{t("risk.site")}</Label>
                <Select value={form.site_id} onValueChange={(v) => setForm(f => ({ ...f, site_id: v, work_area_id: "", risk_assessment_id: "" }))}>
                  <SelectTrigger><SelectValue placeholder="Telephely kiválasztása" /></SelectTrigger>
                  <SelectContent>{sites.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>{t("risk.workArea")}</Label>
                <Select value={form.work_area_id} onValueChange={(v) => { setForm(f => ({ ...f, work_area_id: v })); loadRiskHazards(v); }} disabled={!form.site_id}>
                  <SelectTrigger><SelectValue placeholder="Munkaterület" /></SelectTrigger>
                  <SelectContent>{workAreas.map((wa) => <SelectItem key={wa.id} value={wa.id}>{wa.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5"><Label>{t("inner.unitName")}</Label><Input value={form.unit_name} onChange={(e) => setForm((f) => ({ ...f, unit_name: e.target.value }))} /></div>
            <div className="space-y-1.5">
              <Label>{t("inner.examReason")}</Label>
              <Select value={form.exam_reason} onValueChange={(v) => setForm((f) => ({ ...f, exam_reason: v }))}>
                <SelectTrigger><SelectValue placeholder={t("inner.selectReason")} /></SelectTrigger>
                <SelectContent>{EXAM_REASON_OPTIONS.map((r) => <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label className="text-base font-semibold">{t("inner.riskFactors")}</Label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {REFERRAL_RISK_KEYS.map((key) => (
                  <div key={key} className="flex items-center gap-2">
                    <Checkbox checked={!!form.risk_factors[key]} onCheckedChange={(checked) => setForm((f) => ({ ...f, risk_factors: { ...f.risk_factors, [key]: !!checked } }))} />
                    <span className="text-sm">{t(key)}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>{t("icd.diagnosisCodes")}</Label>
              <BnoSearch
                values={form.icd_codes}
                onChange={(code) => setForm((f) => ({ ...f, icd_codes: [...f.icd_codes, code] }))}
                onRemove={(code) => setForm((f) => ({ ...f, icd_codes: f.icd_codes.filter((c) => c !== code) }))}
                multiple
              />
            </div>
            {/* Company hazardous substances (read-only on referral) */}
            {myCompany && (
              <HazardousSubstanceSelector companyId={myCompany} readOnly />
            )}
            <Button className="w-full" onClick={() => createReferral.mutate()} disabled={createReferral.isPending || !form.employee_id || !form.exam_reason}>
              {t("inner.createAndSendReferral")}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={bulkDialogOpen} onOpenChange={setBulkDialogOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{t("inner.bulkReferralTitle")}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">{t("inner.bulkReferralDesc")}</p>
            <div className="rounded-md bg-muted p-3">
              <p className="text-sm font-medium">{t("inner.eligibleEmployees")}: <span className="text-primary">{bulkEligible.length}</span> / {(employees ?? []).length}</p>
              {bulkEligible.length > 0 && (
                <ul className="mt-2 text-xs text-muted-foreground space-y-0.5 max-h-32 overflow-y-auto">
                  {bulkEligible.map((e) => <li key={e.user_id}>• {e.full_name} — {e.position}</li>)}
                </ul>
              )}
            </div>
            <div className="space-y-1.5">
              <Label>{t("inner.examReason")}</Label>
              <Select value={bulkExamReason} onValueChange={setBulkExamReason}>
                <SelectTrigger><SelectValue placeholder={t("inner.selectReason")} /></SelectTrigger>
                <SelectContent>{EXAM_REASON_OPTIONS.map((r) => <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <Button className="w-full" onClick={() => bulkCreate.mutate()} disabled={bulkCreate.isPending || !bulkExamReason || !bulkEligible.length}>
              {bulkCreate.isPending ? t("inner.sending") : t("inner.bulkReferralCreated", { count: bulkEligible.length })}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}