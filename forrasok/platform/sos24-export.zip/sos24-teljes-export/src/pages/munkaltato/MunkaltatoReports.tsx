import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/contexts/AuthContext";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { BarChart, Bar, PieChart, Pie, Cell, LineChart, Line, ResponsiveContainer, XAxis, YAxis, Tooltip, Legend, CartesianGrid } from "recharts";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Printer, Download, AlertTriangle } from "lucide-react";
import ExportButton from "@/components/ExportButton";
import * as XLSX from "xlsx";
import { useTranslation } from "react-i18next";

const RESULT_COLORS: Record<string, string> = {
  alkalmas: "hsl(var(--chart-2))", nem_alkalmas: "hsl(var(--chart-1))",
  feltetelesen_alkalmas: "hsl(var(--chart-3))", ideiglenes: "hsl(var(--chart-4))",
};

export default function MunkaltatoReports() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const [yearFrom, setYearFrom] = useState(() => `${new Date().getFullYear()}-01-01`);
  const [yearTo, setYearTo] = useState(() => `${new Date().getFullYear()}-12-31`);

  const RESULT_LABELS: Record<string, string> = {
    alkalmas: t("inner.fit"), nem_alkalmas: t("inner.unfit"),
    feltetelesen_alkalmas: t("inner.conditionallyFit"), ideiglenes: t("inner.temporary"),
  };

  const { data: companyIds } = useQuery({
    queryKey: ["munkaltato-companies", user?.id],
    queryFn: async () => {
      const { data } = await supabase.from("user_company_relations").select("company_id").eq("user_id", user!.id).eq("role", "munkaltato");
      return data?.map((c) => c.company_id) ?? [];
    },
    enabled: !!user,
  });

  const { data: companies } = useQuery({
    queryKey: ["munkaltato-company-names", companyIds],
    queryFn: async () => {
      const { data } = await supabase.from("companies").select("id, name").in("id", companyIds!);
      return data ?? [];
    },
    enabled: !!companyIds?.length,
  });

  const { data: exams } = useQuery({
    queryKey: ["report-exams", companyIds, yearFrom, yearTo],
    queryFn: async () => {
      const { data: empRels } = await supabase.from("user_company_relations").select("user_id, company_id, position").in("company_id", companyIds!).eq("role", "munkavallalo");
      const empIds = empRels?.map((e) => e.user_id) ?? [];
      if (!empIds.length) return [];
      const { data } = await supabase.from("examinations").select("id, patient_id, exam_type, result, valid_until, restrictions, created_at").in("patient_id", empIds).gte("created_at", yearFrom).lte("created_at", yearTo + "T23:59:59").order("created_at", { ascending: false });
      const ids = [...new Set(data?.map((e) => e.patient_id) ?? [])];
      const { data: profiles } = await supabase.from("profiles").select("user_id, full_name").in("user_id", ids);
      const nameMap = Object.fromEntries(profiles?.map((p) => [p.user_id, p.full_name]) ?? []);
      const empMap = Object.fromEntries(empRels?.map((e) => [e.user_id, { company_id: e.company_id, position: e.position }]) ?? []);
      return (data ?? []).map((e) => ({ ...e, patientName: nameMap[e.patient_id] || "—", companyId: empMap[e.patient_id]?.company_id, position: empMap[e.patient_id]?.position || "—" }));
    },
    enabled: !!companyIds?.length,
  });

  const { data: opinions } = useQuery({
    queryKey: ["report-opinions", companyIds, yearFrom, yearTo],
    queryFn: async () => {
      const { data } = await supabase.from("medical_opinions").select("id, patient_id, status, opinion_date, valid_until, notes").in("company_id", companyIds!).gte("opinion_date", yearFrom).lte("opinion_date", yearTo);
      const ids = [...new Set(data?.map((o) => o.patient_id) ?? [])];
      const { data: profiles } = await supabase.from("profiles").select("user_id, full_name").in("user_id", ids);
      const nameMap = Object.fromEntries(profiles?.map((p) => [p.user_id, p.full_name]) ?? []);
      return (data ?? []).map((o) => ({ ...o, patientName: nameMap[o.patient_id] || "—" }));
    },
    enabled: !!companyIds?.length,
  });

  const { data: referrals } = useQuery({
    queryKey: ["report-referrals", companyIds, yearFrom, yearTo],
    queryFn: async () => {
      const { data } = await supabase.from("referrals").select("id, employee_id, exam_reason, status, position, created_at, company_id").in("company_id", companyIds!).gte("created_at", yearFrom).lte("created_at", yearTo + "T23:59:59");
      const ids = [...new Set(data?.map((r) => r.employee_id) ?? [])];
      const { data: profiles } = await supabase.from("profiles").select("user_id, full_name").in("user_id", ids);
      const nameMap = Object.fromEntries(profiles?.map((p) => [p.user_id, p.full_name]) ?? []);
      return (data ?? []).map((r) => ({ ...r, employeeName: nameMap[r.employee_id] || "—" }));
    },
    enabled: !!companyIds?.length,
  });

  const resultDist = exams
    ? Object.entries(exams.reduce<Record<string, number>>((acc, e) => { acc[e.result] = (acc[e.result] || 0) + 1; return acc; }, {}))
        .map(([name, value]) => ({ name: RESULT_LABELS[name] || name, value, color: RESULT_COLORS[name] || "hsl(var(--chart-5))" }))
    : [];

  const monthlyTrend = exams
    ? (() => {
        const months: Record<string, number> = {};
        exams.forEach((e) => { const m = e.created_at.slice(0, 7); months[m] = (months[m] || 0) + 1; });
        return Object.entries(months).map(([month, count]) => ({ month, count })).sort((a, b) => a.month.localeCompare(b.month));
      })()
    : [];

  const positionDist = exams
    ? Object.entries(exams.reduce<Record<string, number>>((acc, e) => { acc[e.position] = (acc[e.position] || 0) + 1; return acc; }, {}))
        .map(([pos, count]) => ({ position: pos, count })).sort((a, b) => b.count - a.count).slice(0, 10)
    : [];

  const companyDist = (exams && companies && companies.length > 1)
    ? companies.map((c) => ({ name: c.name, count: exams.filter((e) => e.companyId === c.id).length }))
    : [];

  const today = new Date().toISOString().split("T")[0];
  const in60 = new Date(Date.now() + 60 * 86400000).toISOString().split("T")[0];
  const expiringExams = (exams ?? []).filter((e) => e.valid_until && e.valid_until >= today && e.valid_until <= in60).sort((a, b) => (a.valid_until ?? "").localeCompare(b.valid_until ?? ""));
  const expiredExams = (exams ?? []).filter((e) => e.valid_until && e.valid_until < today);

  const examCsvHeaders = [t("inner.employee"), t("inner.position"), t("inner.type"), t("inner.result"), t("inner.restrictions"), t("inner.validUntil"), t("inner.date")];
  const examCsvRows = (exams ?? []).map((e) => [e.patientName, e.position, e.exam_type, RESULT_LABELS[e.result] || e.result, e.restrictions || "", e.valid_until || "", e.created_at?.slice(0, 10) || ""]);

  const opinionCsvHeaders = [t("inner.employee"), t("inner.status"), t("inner.date"), t("inner.validUntil"), t("inner.notes")];
  const opinionCsvRows = (opinions ?? []).map((o) => [o.patientName, RESULT_LABELS[o.status] || o.status, o.opinion_date, o.valid_until || "", o.notes || ""]);

  const referralCsvHeaders = [t("inner.employee"), t("inner.position"), t("inner.reason"), t("inner.status"), t("inner.date")];
  const referralCsvRows = (referrals ?? []).map((r) => [r.employeeName, r.position || "", r.exam_reason, r.status, r.created_at?.slice(0, 10) || ""]);

  const exportXls = () => {
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([examCsvHeaders, ...examCsvRows]), t("inner.examinations"));
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([opinionCsvHeaders, ...opinionCsvRows]), t("inner.fitnessOpinions"));
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([referralCsvHeaders, ...referralCsvRows]), t("inner.referrals"));
    XLSX.writeFile(wb, "munkaltato_riport.xlsx");
  };

  return (
    <div className="space-y-6 print:space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h1 className="text-2xl font-bold text-foreground">{t("inner.annualReport")}</h1>
          <p className="text-muted-foreground text-sm">{t("inner.employerReportSummary")}</p>
        </div>
        <div className="flex gap-2 print:hidden">
          <Button variant="outline" size="sm" onClick={exportXls}>
            <Download className="h-4 w-4 mr-1" /> {t("inner.xlsExport")}
          </Button>
          <Button variant="outline" size="sm" onClick={() => window.print()}>
            <Printer className="h-4 w-4 mr-1" /> {t("inner.printPdf")}
          </Button>
        </div>
      </div>

      <div className="flex gap-2 items-end print:hidden flex-wrap">
        <div>
          <label className="text-xs text-muted-foreground">{t("inner.periodStart")}</label>
          <Input type="date" value={yearFrom} onChange={(e) => setYearFrom(e.target.value)} className="w-40" />
        </div>
        <div>
          <label className="text-xs text-muted-foreground">{t("inner.periodEnd")}</label>
          <Input type="date" value={yearTo} onChange={(e) => setYearTo(e.target.value)} className="w-40" />
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        <Card><CardHeader className="pb-2"><CardTitle className="text-sm text-muted-foreground">{t("inner.examinations")}</CardTitle></CardHeader><CardContent><p className="text-2xl font-bold">{exams?.length ?? 0}</p></CardContent></Card>
        <Card><CardHeader className="pb-2"><CardTitle className="text-sm text-muted-foreground">{t("inner.fitnessOpinions")}</CardTitle></CardHeader><CardContent><p className="text-2xl font-bold">{opinions?.length ?? 0}</p></CardContent></Card>
        <Card><CardHeader className="pb-2"><CardTitle className="text-sm text-muted-foreground">{t("inner.referrals")}</CardTitle></CardHeader><CardContent><p className="text-2xl font-bold">{referrals?.length ?? 0}</p></CardContent></Card>
        <Card><CardHeader className="pb-2"><CardTitle className="text-sm text-muted-foreground">{t("inner.expiring60days")}</CardTitle></CardHeader><CardContent><p className="text-2xl font-bold text-warning">{expiringExams.length}</p></CardContent></Card>
        <Card><CardHeader className="pb-2"><CardTitle className="text-sm text-muted-foreground">{t("inner.expired")}</CardTitle></CardHeader><CardContent><p className="text-2xl font-bold text-destructive">{expiredExams.length}</p></CardContent></Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader><CardTitle className="text-base">{t("inner.fitnessResults")}</CardTitle></CardHeader>
          <CardContent>
            {resultDist.length ? (
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie data={resultDist} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
                    {resultDist.map((e, i) => <Cell key={i} fill={e.color} />)}
                  </Pie>
                  <Tooltip /><Legend />
                </PieChart>
              </ResponsiveContainer>
            ) : <p className="text-sm text-muted-foreground">{t("inner.noData")}</p>}
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle className="text-base">{t("inner.monthlyExamTrend")}</CardTitle></CardHeader>
          <CardContent>
            {monthlyTrend.length ? (
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={monthlyTrend}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                  <YAxis allowDecimals={false} />
                  <Tooltip />
                  <Line type="monotone" dataKey="count" name={t("inner.examinations")} stroke="hsl(var(--primary))" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            ) : <p className="text-sm text-muted-foreground">{t("inner.noData")}</p>}
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        {positionDist.length > 0 && (
          <Card>
            <CardHeader><CardTitle className="text-base">{t("inner.positionBreakdown")}</CardTitle></CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={positionDist} layout="vertical">
                  <XAxis type="number" allowDecimals={false} />
                  <YAxis dataKey="position" type="category" width={160} tick={{ fontSize: 11 }} />
                  <Tooltip />
                  <Bar dataKey="count" fill="hsl(var(--secondary))" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}

        {companyDist.length > 0 && (
          <Card>
            <CardHeader><CardTitle className="text-base">{t("inner.companyComparison")}</CardTitle></CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={companyDist}>
                  <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                  <YAxis allowDecimals={false} />
                  <Tooltip />
                  <Bar dataKey="count" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader><CardTitle className="text-base">{t("inner.referralStatus")}</CardTitle></CardHeader>
          <CardContent>
            {referrals?.length ? (
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={[
                  { name: t("inner.chartDraft"), value: referrals.filter((r) => r.status === "draft").length },
                  { name: t("inner.chartSent"), value: referrals.filter((r) => r.status === "sent").length },
                  { name: t("inner.chartDone"), value: referrals.filter((r) => r.status === "completed").length },
                ]}>
                  <XAxis dataKey="name" />
                  <YAxis allowDecimals={false} />
                  <Tooltip />
                  <Bar dataKey="value" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : <p className="text-sm text-muted-foreground">{t("inner.noData")}</p>}
          </CardContent>
        </Card>
      </div>

      {expiringExams.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-warning" />
              {t("inner.expiringFitnessExams60", { count: expiringExams.length })}
            </CardTitle>
          </CardHeader>
          <CardContent className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t("inner.employee")}</TableHead>
                  <TableHead>{t("inner.position")}</TableHead>
                  <TableHead>{t("inner.result")}</TableHead>
                  <TableHead>{t("inner.validUntil")}</TableHead>
                  <TableHead>{t("inner.remainingDays")}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {expiringExams.map((e) => {
                  const daysLeft = Math.ceil((new Date(e.valid_until!).getTime() - Date.now()) / 86400000);
                  return (
                    <TableRow key={e.id}>
                      <TableCell className="font-medium">{e.patientName}</TableCell>
                      <TableCell>{e.position}</TableCell>
                      <TableCell><Badge variant="secondary">{RESULT_LABELS[e.result] || e.result}</Badge></TableCell>
                      <TableCell>{e.valid_until}</TableCell>
                      <TableCell><Badge variant={daysLeft <= 30 ? "destructive" : "secondary"}>{daysLeft} {t("inner.dayUnit")}</Badge></TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-base">{t("inner.examList")}</CardTitle>
          <ExportButton filename="vizsgalatok" headers={examCsvHeaders} rows={examCsvRows} />
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader><TableRow>{examCsvHeaders.map((h) => <TableHead key={h}>{h}</TableHead>)}</TableRow></TableHeader>
            <TableBody>
              {(exams ?? []).slice(0, 50).map((e) => (
                <TableRow key={e.id}>
                  <TableCell>{e.patientName}</TableCell>
                  <TableCell>{e.position}</TableCell>
                  <TableCell>{e.exam_type}</TableCell>
                  <TableCell><Badge variant={e.result === "nem_alkalmas" ? "destructive" : "secondary"}>{RESULT_LABELS[e.result] || e.result}</Badge></TableCell>
                  <TableCell className="text-sm">{e.restrictions || "—"}</TableCell>
                  <TableCell>{e.valid_until || "—"}</TableCell>
                  <TableCell>{e.created_at?.slice(0, 10)}</TableCell>
                </TableRow>
              ))}
              {!exams?.length && <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground">{t("inner.noData")}</TableCell></TableRow>}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-base">{t("inner.opinionsList")}</CardTitle>
          <ExportButton filename="velemenyek" headers={opinionCsvHeaders} rows={opinionCsvRows} />
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader><TableRow>{opinionCsvHeaders.map((h) => <TableHead key={h}>{h}</TableHead>)}</TableRow></TableHeader>
            <TableBody>
              {(opinions ?? []).slice(0, 50).map((o) => (
                <TableRow key={o.id}>
                  <TableCell>{o.patientName}</TableCell>
                  <TableCell><Badge variant={o.status === "nem_alkalmas" ? "destructive" : "secondary"}>{RESULT_LABELS[o.status] || o.status}</Badge></TableCell>
                  <TableCell>{o.opinion_date}</TableCell>
                  <TableCell>{o.valid_until || "—"}</TableCell>
                  <TableCell className="text-sm max-w-[200px] truncate">{o.notes || "—"}</TableCell>
                </TableRow>
              ))}
              {!opinions?.length && <TableRow><TableCell colSpan={5} className="text-center text-muted-foreground">{t("inner.noData")}</TableCell></TableRow>}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-base">{t("inner.referralsList")}</CardTitle>
          <ExportButton filename="beutalok" headers={referralCsvHeaders} rows={referralCsvRows} />
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader><TableRow>{referralCsvHeaders.map((h) => <TableHead key={h}>{h}</TableHead>)}</TableRow></TableHeader>
            <TableBody>
              {(referrals ?? []).slice(0, 50).map((r) => (
                <TableRow key={r.id}>
                  <TableCell>{r.employeeName}</TableCell>
                  <TableCell>{r.position || "—"}</TableCell>
                  <TableCell>{r.exam_reason}</TableCell>
                  <TableCell><Badge>{r.status}</Badge></TableCell>
                  <TableCell>{r.created_at?.slice(0, 10)}</TableCell>
                </TableRow>
              ))}
              {!referrals?.length && <TableRow><TableCell colSpan={5} className="text-center text-muted-foreground">{t("inner.noData")}</TableCell></TableRow>}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}