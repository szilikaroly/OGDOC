import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { Users, Pencil, Save, X, Search } from "lucide-react";
import { toast } from "sonner";
import ExportButton from "@/components/ExportButton";
import BulkPatientImport from "@/components/BulkPatientImport";
import FeorSearch from "@/components/FeorSearch";
import HazardousSubstanceSelector from "@/components/HazardousSubstanceSelector";

const RISK_FACTOR_KEYS = [
  "riskFactors.chemicals", "riskFactors.noise", "riskFactors.vibration", "riskFactors.dust",
  "riskFactors.screenWork", "riskFactors.heavyPhysical",
  "riskFactors.nightShift", "riskFactors.heightWork", "riskFactors.heatStress",
  "riskFactors.biologicalRisk", "riskFactors.radiation", "riskFactors.forcedPosition",
  "riskFactors.psychosocial", "riskFactors.drivingOperating",
];

interface ProfileData {
  user_id: string;
  full_name: string;
  phone: string | null;
  taj_number: string | null;
  birth_date: string | null;
  birth_place: string | null;
}

interface EmployeeRow {
  id: string;
  user_id: string;
  position: string | null;
  is_active: boolean;
  start_date: string | null;
  company_id: string;
  risk_factors?: Record<string, boolean> | string[] | null;
  profile?: ProfileData | null;
  company?: { id: string; name: string } | null;
  email?: string | null;
}

export default function MunkaltatoEmployees() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const qc = useQueryClient();
  const [searchQuery, setSearchQuery] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editPosition, setEditPosition] = useState("");
  const [editRisks, setEditRisks] = useState<string[]>([]);
  const [customRisk, setCustomRisk] = useState("");
  const [editProfile, setEditProfile] = useState({
    taj_number: "", phone: "", birth_date: "", birth_place: "", email: "",
  });

  const { data: myCompanyRelations } = useQuery({
    queryKey: ["my-company-relations", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase.from("user_company_relations").select("company_id").eq("user_id", user!.id).eq("role", "munkaltato");
      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  const companyIds = (myCompanyRelations ?? []).map((r) => r.company_id);

  const { data: employees, isLoading } = useQuery({
    queryKey: ["company-employees", companyIds],
    queryFn: async () => {
      const { data, error } = await (supabase as any).from("user_company_relations").select("id, user_id, position, is_active, start_date, company_id, risk_factors").in("company_id", companyIds).order("created_at", { ascending: false });
      if (error) throw error;
      const userIds = [...new Set((data as any[]).map((e: any) => e.user_id))];
      const { data: profiles } = await supabase.from("profiles").select("user_id, full_name, phone, taj_number, birth_date, birth_place").in("user_id", userIds);
      const { data: companies } = await supabase.from("companies").select("id, name").in("id", companyIds);
      return (data as any[]).map((e: any) => ({
        ...e,
        profile: (profiles ?? []).find((p) => p.user_id === e.user_id),
        company: (companies ?? []).find((c: any) => c.id === e.company_id),
      })) as EmployeeRow[];
    },
    enabled: companyIds.length > 0,
  });

  const updateMut = useMutation({
    mutationFn: async ({ id, position, risk_factors, userId, profileData }: {
      id: string; position: string; risk_factors: string[]; userId: string;
      profileData: { taj_number: string; phone: string; birth_date: string; birth_place: string };
    }) => {
      const rfObj: Record<string, boolean> = {};
      risk_factors.forEach((r) => { rfObj[r] = true; });
      const { error } = await (supabase as any)
        .from("user_company_relations")
        .update({ position, risk_factors: rfObj })
        .eq("id", id);
      if (error) throw error;

      // Update profile data
      const profileUpdate: any = {};
      if (profileData.taj_number !== undefined) profileUpdate.taj_number = profileData.taj_number || null;
      if (profileData.phone !== undefined) profileUpdate.phone = profileData.phone || null;
      if (profileData.birth_date !== undefined) profileUpdate.birth_date = profileData.birth_date || null;
      if (profileData.birth_place !== undefined) profileUpdate.birth_place = profileData.birth_place || null;

      const { error: profileError } = await supabase
        .from("profiles")
        .update(profileUpdate)
        .eq("user_id", userId);
      if (profileError) throw profileError;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["company-employees"] });
      setEditingId(null);
      toast.success(t("common.saved"));
    },
    onError: (e: any) => toast.error(e.message),
  });

  const startEdit = (emp: EmployeeRow) => {
    setEditingId(emp.id);
    setEditPosition(emp.position || "");
    setEditProfile({
      taj_number: emp.profile?.taj_number || "",
      phone: emp.profile?.phone || "",
      birth_date: emp.profile?.birth_date || "",
      birth_place: emp.profile?.birth_place || "",
      email: "",
    });
    const rf = emp.risk_factors;
    if (Array.isArray(rf)) setEditRisks(rf);
    else if (rf && typeof rf === "object") setEditRisks(Object.keys(rf).filter((k) => (rf as Record<string, boolean>)[k]));
    else setEditRisks([]);
    setCustomRisk("");
  };

  const handleSave = () => {
    if (!editingId || !editingEmployee) return;
    updateMut.mutate({
      id: editingId, position: editPosition, risk_factors: editRisks,
      userId: editingEmployee.user_id,
      profileData: {
        taj_number: editProfile.taj_number,
        phone: editProfile.phone,
        birth_date: editProfile.birth_date,
        birth_place: editProfile.birth_place,
      },
    });
  };

  const toggleRisk = (risk: string) => {
    setEditRisks((prev) => prev.includes(risk) ? prev.filter((r) => r !== risk) : [...prev, risk]);
  };

  const addCustomRisk = () => {
    const trimmed = customRisk.trim();
    if (trimmed && !editRisks.includes(trimmed)) {
      setEditRisks((prev) => [...prev, trimmed]);
      setCustomRisk("");
    }
  };

  const getRiskList = (emp: EmployeeRow): string[] => {
    const rf = emp.risk_factors;
    if (Array.isArray(rf)) return rf;
    if (rf && typeof rf === "object") return Object.keys(rf).filter((k) => (rf as Record<string, boolean>)[k]);
    return [];
  };

  if (isLoading) {
    return <div className="flex items-center justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>;
  }

  const editingEmployee = employees?.find((e) => e.id === editingId);

  const filteredEmployees = (employees ?? []).filter((e) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    const name = (e.profile?.full_name || "").toLowerCase();
    const taj = (e.profile?.taj_number || "").toLowerCase();
    const pos = (e.position || "").toLowerCase();
    return name.includes(q) || taj.includes(q) || pos.includes(q);
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Users className="h-6 w-6 text-secondary" />
          <h1 className="text-2xl font-bold">{t('inner.employees')}</h1>
        </div>
        <div className="flex items-center gap-2">
          <BulkPatientImport onComplete={() => qc.invalidateQueries({ queryKey: ["company-employees"] })} />
          <ExportButton
            filename="munkavallalok"
            headers={[t('inner.name'), t('inner.tajNumber'), t('admin.birthPlace'), t('admin.birthDate'), t('inner.phone'), t('inner.position'), t('companies.riskFactors'), t('inner.company'), t('inner.status')]}
            rows={(employees ?? []).map((e) => [e.profile?.full_name || "", e.profile?.taj_number || "", e.profile?.birth_place || "", e.profile?.birth_date || "", e.profile?.phone || "", e.position || "", getRiskList(e).map(r => t(r, r)).join(", "), e.company?.name || "", e.is_active ? t('inner.active') : t('inner.inactive')])}
          />
        </div>
      </div>
      <Card>
      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
        <div className="relative flex-1 w-full sm:max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t("admin.searchEmployeePlaceholder")}
            className="pl-9"
          />
        </div>
        <CardTitle className="text-lg">{t('inner.employeesCount')} ({filteredEmployees.length})</CardTitle>
      </div>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t('inner.name')}</TableHead>
                <TableHead>{t('inner.tajNumber')}</TableHead>
                 <TableHead>{t("admin.birthPlaceDate")}</TableHead>
                <TableHead>{t('inner.phone')}</TableHead>
                <TableHead>{t('inner.position')}</TableHead>
                <TableHead>{t('companies.riskFactors')}</TableHead>
                <TableHead>{t('inner.company')}</TableHead>
                <TableHead>{t('inner.status')}</TableHead>
                <TableHead className="w-10"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredEmployees.map((e) => {
                const risks = getRiskList(e);
                return (
                  <TableRow key={e.id}>
                    <TableCell className="font-medium">{e.profile?.full_name || "—"}</TableCell>
                    <TableCell>{e.profile?.taj_number || "—"}</TableCell>
                    <TableCell className="text-xs">
                      {e.profile?.birth_place || "—"}
                      <br />
                      {e.profile?.birth_date || "—"}
                    </TableCell>
                    <TableCell>{e.profile?.phone || "—"}</TableCell>
                    <TableCell>{e.position || "—"}</TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {risks.length > 0 ? risks.map((r) => (
                          <Badge key={r} variant="outline" className="text-[10px]">{t(r, r)}</Badge>
                        )) : <span className="text-muted-foreground text-xs">—</span>}
                      </div>
                    </TableCell>
                    <TableCell>{e.company?.name || "—"}</TableCell>
                    <TableCell>
                      <Badge variant={e.is_active ? "default" : "secondary"}>
                        {e.is_active ? t('inner.active') : t('inner.inactive')}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => startEdit(e)}>
                        <Pencil className="h-3.5 w-3.5" />
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
              {filteredEmployees.length === 0 && (
                <TableRow><TableCell colSpan={9} className="text-center text-muted-foreground py-8">{searchQuery ? t("inner.noResult") : t('inner.noEmployeeAssigned')}</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Edit dialog */}
      <Dialog open={!!editingId} onOpenChange={(open) => !open && setEditingId(null)}>
        <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Pencil className="h-4 w-4" />
              {editingEmployee?.profile?.full_name} – {t("admin.editing")}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-2">
            {/* Personal data section */}
            <div className="space-y-3">
              <h3 className="text-sm font-semibold text-muted-foreground">{t("admin.personalData")}</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs">{t("inner.tajNumber")}</Label>
                  <Input
                    value={editProfile.taj_number}
                    onChange={(e) => setEditProfile(p => ({ ...p, taj_number: e.target.value }))}
                    placeholder="123 456 789"
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">{t("inner.phone")}</Label>
                  <Input
                    value={editProfile.phone}
                    onChange={(e) => setEditProfile(p => ({ ...p, phone: e.target.value }))}
                    placeholder="+36 30 123 4567"
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">{t("admin.birthPlace")}</Label>
                  <Input
                    value={editProfile.birth_place}
                    onChange={(e) => setEditProfile(p => ({ ...p, birth_place: e.target.value }))}
                    placeholder="Budapest"
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">{t("admin.birthDate")}</Label>
                  <Input
                    type="date"
                    value={editProfile.birth_date}
                    onChange={(e) => setEditProfile(p => ({ ...p, birth_date: e.target.value }))}
                  />
                </div>
              </div>
            </div>

            <Separator />

            {/* Position section */}
            <div className="space-y-3">
               <h3 className="text-sm font-semibold text-muted-foreground">{t("inner.position")}</h3>
              <div className="space-y-2">
                <Label className="text-xs">{t("companies.feorSearch")}</Label>
                <FeorSearch
                  value=""
                  onChange={() => {}}
                  onPositionChange={(name) => setEditPosition(name)}
                  placeholder={t("companies.feorPlaceholder")}
                />
              </div>
              <div className="space-y-2">
                <Label className="text-xs">{t("companies.customPosition")}</Label>
                <Input
                  value={editPosition}
                  onChange={(e) => setEditPosition(e.target.value)}
                  placeholder={t("companies.customPositionPlaceholder")}
                />
              </div>
            </div>

            <Separator />

            {/* Risk factors */}
            <div className="space-y-2">
               <h3 className="text-sm font-semibold text-muted-foreground">{t("companies.riskFactors")}</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto border rounded-md p-3">
                {RISK_FACTOR_KEYS.map((key) => (
                  <label key={key} className="flex items-center gap-2 text-sm cursor-pointer hover:bg-muted/50 rounded px-1 py-0.5">
                    <Checkbox checked={editRisks.includes(key)} onCheckedChange={() => toggleRisk(key)} />
                    {t(key)}
                  </label>
                ))}
                {editRisks.filter((r) => !RISK_FACTOR_KEYS.includes(r)).map((risk) => (
                  <label key={risk} className="flex items-center gap-2 text-sm cursor-pointer hover:bg-muted/50 rounded px-1 py-0.5">
                    <Checkbox checked onCheckedChange={() => toggleRisk(risk)} />
                    <span className="italic">{t(risk, risk)}</span>
                  </label>
                ))}
              </div>
              <div className="flex gap-2">
                <Input
                  value={customRisk}
                  onChange={(e) => setCustomRisk(e.target.value)}
                  placeholder={t("companies.customRiskPlaceholder")}
                  className="text-sm"
                  onKeyDown={(e) => e.key === "Enter" && addCustomRisk()}
                />
                <Button variant="outline" size="sm" onClick={addCustomRisk} disabled={!customRisk.trim()}>
                  {t("companies.add")}
                </Button>
              </div>
            </div>

            {/* Hazardous substances from company */}
            {editingEmployee?.company_id && (
              <div className="border-t pt-3 mt-1">
                <HazardousSubstanceSelector companyId={editingEmployee.company_id} readOnly />
              </div>
            )}

            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setEditingId(null)}>
                <X className="h-4 w-4 mr-1" />
                {t("common.cancel")}
              </Button>
              <Button onClick={handleSave} disabled={updateMut.isPending}>
                <Save className="h-4 w-4 mr-1" />
                {t("common.save")}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
