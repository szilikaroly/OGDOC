import { useState, useMemo, useCallback } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FileText, Search, Download } from "lucide-react";
import { useTranslation } from "react-i18next";

function daysDiff(dateStr: string) {
  return (new Date(dateStr).getTime() - Date.now()) / (1000 * 60 * 60 * 24);
}

export default function MunkaltatoOpinions() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const [search, setSearch] = useState("");
  const [filterResult, setFilterResult] = useState("all");

  const STATUS_LABELS: Record<string, string> = {
    alkalmas: t("inner.fit"), nem_alkalmas: t("inner.unfit"),
    feltetelesen_alkalmas: t("inner.conditionallyFit"), ideiglenes: t("inner.temporary"),
  };
  const STATUS_COLORS: Record<string, "default" | "destructive" | "secondary" | "outline"> = {
    alkalmas: "default", nem_alkalmas: "destructive", feltetelesen_alkalmas: "secondary", ideiglenes: "outline",
  };

  const { data: examinations } = useQuery({
    queryKey: ["munkaltato-examinations", user?.id],
    queryFn: async () => {
      const { data } = await supabase.from("examinations").select("id, patient_id, doctor_id, exam_type, result, valid_until, created_at, restrictions, referral_id").order("created_at", { ascending: false });
      return data ?? [];
    },
    enabled: !!user,
  });

  const { data: opinions, isLoading } = useQuery({
    queryKey: ["company-opinions", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase.from("medical_opinions").select("id, patient_id, doctor_id, opinion_date, valid_until, status, notes, company_id").order("opinion_date", { ascending: false });
      if (error) throw error;
      const userIds = [...new Set([...data.map((o) => o.patient_id), ...data.map((o) => o.doctor_id)])];
      const { data: profiles } = await supabase.from("profiles").select("user_id, full_name").in("user_id", userIds);
      return data.map((o) => {
        const exam = (examinations ?? []).find((e) => e.patient_id === o.patient_id && e.result === o.status);
        return {
          ...o,
          patient_name: (profiles ?? []).find((p) => p.user_id === o.patient_id)?.full_name ?? "—",
          doctor_name: (profiles ?? []).find((p) => p.user_id === o.doctor_id)?.full_name ?? "—",
          restrictions: exam?.restrictions ?? null,
        };
      });
    },
    enabled: !!user,
  });

  const filtered = useMemo(() => {
    let list = opinions ?? [];
    if (filterResult !== "all") list = list.filter((o) => o.status === filterResult);
    if (search) {
      const s = search.toLowerCase();
      list = list.filter((o) => o.patient_name.toLowerCase().includes(s) || o.doctor_name.toLowerCase().includes(s));
    }
    return list;
  }, [opinions, filterResult, search]);

  const stats = useMemo(() => {
    const all = opinions ?? [];
    return {
      total: all.length,
      alkalmas: all.filter((o) => o.status === "alkalmas").length,
      nem_alkalmas: all.filter((o) => o.status === "nem_alkalmas").length,
      expiringSoon: all.filter((o) => o.valid_until && daysDiff(o.valid_until) > 0 && daysDiff(o.valid_until) <= 30).length,
      expired: all.filter((o) => o.valid_until && daysDiff(o.valid_until) <= 0).length,
    };
  }, [opinions]);

  const exportXls = useCallback(() => {
    if (!filtered.length) return;
    const escXml = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    const headers = [t("inner.employee"), t("inner.doctor"), t("inner.date"), t("inner.validUntil"), t("inner.result"), t("inner.restrictions")];
    let xml = '<?xml version="1.0" encoding="UTF-8"?>\n<?mso-application progid="Excel.Sheet"?>\n';
    xml += '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">\n';
    xml += '<Styles><Style ss:ID="header"><Font ss:Bold="1"/></Style>';
    xml += '<Style ss:ID="expired"><Interior ss:Color="#FEE2E2" ss:Pattern="Solid"/></Style>';
    xml += '<Style ss:ID="expiring"><Interior ss:Color="#FEF9C3" ss:Pattern="Solid"/></Style>';
    xml += '</Styles>\n';
    xml += `<Worksheet ss:Name="${t("inner.examinations")}"><Table>\n`;
    xml += "<Row>" + headers.map((h) => `<Cell ss:StyleID="header"><Data ss:Type="String">${escXml(h)}</Data></Cell>`).join("") + "</Row>\n";
    filtered.forEach((o) => {
      const days = o.valid_until ? daysDiff(o.valid_until) : null;
      const style = days !== null && days <= 0 ? ' ss:StyleID="expired"' : days !== null && days <= 30 ? ' ss:StyleID="expiring"' : "";
      const cells = [
        o.patient_name, o.doctor_name,
        new Date(o.opinion_date).toLocaleDateString("hu-HU"),
        o.valid_until ? new Date(o.valid_until).toLocaleDateString("hu-HU") : "",
        STATUS_LABELS[o.status] ?? o.status,
        o.restrictions ?? "",
      ];
      xml += `<Row${style}>` + cells.map((c) => `<Cell><Data ss:Type="String">${escXml(c)}</Data></Cell>`).join("") + "</Row>\n";
    });
    xml += "</Table></Worksheet></Workbook>";
    const blob = new Blob([xml], { type: "application/vnd.ms-excel" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `vizsgalatok_${new Date().toISOString().slice(0, 10)}.xls`;
    a.click();
    URL.revokeObjectURL(url);
  }, [filtered, t, STATUS_LABELS]);

  if (isLoading) return <div className="flex items-center justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <FileText className="h-6 w-6 text-secondary" />
        <h1 className="text-2xl font-bold">{t("inner.fitnessExams")}</h1>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card><CardContent className="pt-4 text-center"><p className="text-2xl font-bold">{stats.total}</p><p className="text-sm text-muted-foreground">{t("inner.total")}</p></CardContent></Card>
        <Card><CardContent className="pt-4 text-center"><p className="text-2xl font-bold text-green-600">{stats.alkalmas}</p><p className="text-sm text-muted-foreground">{t("inner.fit")}</p></CardContent></Card>
        <Card><CardContent className="pt-4 text-center"><p className="text-2xl font-bold text-destructive">{stats.nem_alkalmas}</p><p className="text-sm text-muted-foreground">{t("inner.unfit")}</p></CardContent></Card>
        <Card><CardContent className="pt-4 text-center"><p className="text-2xl font-bold text-yellow-600">{stats.expiringSoon}</p><p className="text-sm text-muted-foreground">{t("inner.expiresIn30days")}</p></CardContent></Card>
        <Card><CardContent className="pt-4 text-center"><p className="text-2xl font-bold text-destructive">{stats.expired}</p><p className="text-sm text-muted-foreground">{t("inner.expired")}</p></CardContent></Card>
      </div>

      <div className="flex gap-3 items-center flex-wrap">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder={t("inner.searchByNameOrDoctor")} value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
        </div>
        <Select value={filterResult} onValueChange={setFilterResult}>
          <SelectTrigger className="w-48"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t("inner.allResults")}</SelectItem>
            <SelectItem value="alkalmas">{t("inner.fit")}</SelectItem>
            <SelectItem value="nem_alkalmas">{t("inner.unfit")}</SelectItem>
            <SelectItem value="feltetelesen_alkalmas">{t("inner.conditionallyFit")}</SelectItem>
            <SelectItem value="ideiglenes">{t("inner.temporary")}</SelectItem>
          </SelectContent>
        </Select>
        <Button variant="outline" size="sm" onClick={exportXls} disabled={!filtered.length}>
          <Download className="h-4 w-4 mr-1" />{t("inner.xlsExport")}
        </Button>
      </div>

      <Card>
        <CardHeader><CardTitle className="text-lg">{t("inner.fitnessOpinions")} ({filtered.length})</CardTitle></CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t("inner.employee")}</TableHead>
                <TableHead>{t("inner.doctor")}</TableHead>
                <TableHead>{t("inner.date")}</TableHead>
                <TableHead>{t("inner.validUntil")}</TableHead>
                <TableHead>{t("inner.result")}</TableHead>
                <TableHead>{t("inner.restrictions")}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((o) => {
                const days = o.valid_until ? daysDiff(o.valid_until) : null;
                const isExpired = days !== null && days <= 0;
                const isExpiring = days !== null && days > 0 && days <= 30;
                return (
                  <TableRow key={o.id} className={isExpired ? "bg-destructive/5" : isExpiring ? "bg-yellow-50 dark:bg-yellow-950/20" : ""}>
                    <TableCell className="font-medium">{o.patient_name}</TableCell>
                    <TableCell>{o.doctor_name}</TableCell>
                    <TableCell>{new Date(o.opinion_date).toLocaleDateString("hu-HU")}</TableCell>
                    <TableCell>
                      {o.valid_until ? (
                        <span className={isExpired ? "text-destructive font-semibold" : isExpiring ? "text-yellow-600 font-medium" : ""}>
                          {new Date(o.valid_until).toLocaleDateString("hu-HU")}
                          {isExpired && " ❌"}{isExpiring && " ⚠️"}
                        </span>
                      ) : "—"}
                    </TableCell>
                    <TableCell><Badge variant={STATUS_COLORS[o.status] ?? "secondary"}>{STATUS_LABELS[o.status] ?? o.status}</Badge></TableCell>
                    <TableCell className="text-sm max-w-xs">{o.restrictions ? <span className="text-muted-foreground">{o.restrictions}</span> : "—"}</TableCell>
                  </TableRow>
                );
              })}
              {filtered.length === 0 && (
                <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-8">{t("inner.noResult")}</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}