import { useTranslation } from "react-i18next";
import { LayoutDashboard, Users, Building2, FileText, FileUp, MessageSquare, FolderOpen, BarChart3, Shield, AlertTriangle } from "lucide-react";
import DashboardLayout, { type NavItem } from "@/components/DashboardLayout";
import { useUnreadMessages } from "@/hooks/use-unread-messages";

export default function MunkaltatoLayout() {
  const { t } = useTranslation();
  const unread = useUnreadMessages();
  const NAV: NavItem[] = [
    { title: t('dashboard.overview'), url: "/munkaltato", icon: LayoutDashboard },
    { title: t('dashboard.employees'), url: "/munkaltato/employees", icon: Users },
    { title: t('nav.companyData'), url: "/munkaltato/company", icon: Building2 },
    { title: t('dashboard.referrals'), url: "/munkaltato/referrals", icon: FileUp },
    { title: t('dashboard.opinions'), url: "/munkaltato/opinions", icon: FileText },
    { title: t('dashboard.documents'), url: "/munkaltato/documents", icon: FolderOpen },
    { title: t('dashboard.reports'), url: "/munkaltato/reports", icon: BarChart3 },
    { title: t('risk.riskAssessments'), url: "/munkaltato/risk-assessments", icon: Shield },
    { title: t('accident.reports'), url: "/munkaltato/accidents", icon: AlertTriangle },
    { title: t('dashboard.messages'), url: "/munkaltato/messages", icon: MessageSquare, badge: unread },
  ];
  return <DashboardLayout navItems={NAV} groupLabel={t('roles.munkaltato')} />;
}
