import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Building2, Save, Plus, X, Star } from "lucide-react";
import WorkAreaManager from "@/components/WorkAreaManager";
import TeaorSearch from "@/components/TeaorSearch";
import { Badge } from "@/components/ui/badge";

export default function MunkaltatoCompany() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();

  const { data: company, isLoading } = useQuery({
    queryKey: ["my-company", user?.id],
    queryFn: async () => {
      const { data: rels } = await supabase.from("user_company_relations").select("company_id").eq("user_id", user!.id).eq("role", "munkaltato").limit(1).single();
      if (!rels) return null;
      const { data, error } = await supabase.from("companies").select("*").eq("id", rels.company_id).single();
      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  const [form, setForm] = useState<Record<string, string>>({});
  const isEditing = Object.keys(form).length > 0;
  const currentData = isEditing ? form : company ?? {};

  const save = useMutation({
    mutationFn: async () => {
      if (!company) return;
      const { error } = await supabase.from("companies").update({
        name: form.name, tax_number: form.tax_number || null, registration_no: form.registration_no || null,
        address: form.address || null, contact_email: form.contact_email || null, contact_phone: form.contact_phone || null, industry: form.industry || null,
      }).eq("id", company.id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["my-company"] });
      toast({ title: t('inner.companySaved') });
      setForm({});
    },
    onError: (e: any) => toast({ variant: "destructive", title: t('common.error'), description: e.message }),
  });

  const startEdit = () => {
    if (!company) return;
    setForm({
      name: company.name ?? "", tax_number: company.tax_number ?? "", registration_no: company.registration_no ?? "",
      address: company.address ?? "", contact_email: company.contact_email ?? "", contact_phone: company.contact_phone ?? "", industry: company.industry ?? "",
    });
  };

  if (isLoading) {
    return <div className="flex items-center justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-transparent" /></div>;
  }

  if (!company) {
    return <div className="text-center py-12 text-muted-foreground">{t('inner.noCompanyAssigned')}</div>;
  }

  const fields = [
    { key: "name", label: t('inner.companyName') },
    { key: "tax_number", label: t('inner.taxNumber') },
    { key: "registration_no", label: t('inner.registrationNo') },
    { key: "address", label: t('inner.address') },
    { key: "contact_email", label: t('inner.contactEmail') },
    { key: "contact_phone", label: t('inner.contactPhone') },
    { key: "industry", label: t('inner.industry') },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Building2 className="h-6 w-6 text-secondary" />
          <h1 className="text-2xl font-bold">{t('inner.companyData')}</h1>
        </div>
        {!isEditing && <Button onClick={startEdit}>{t('common.edit')}</Button>}
      </div>
      <Card>
        <CardHeader><CardTitle className="text-lg">{company.name}</CardTitle></CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            {fields.map((f) => (
              <div key={f.key} className="space-y-1.5">
                <Label>{f.label}</Label>
                {isEditing ? (
                  <Input value={(form as any)[f.key] ?? ""} onChange={(e) => setForm((prev) => ({ ...prev, [f.key]: e.target.value }))} />
                ) : (
                  <p className="text-sm text-foreground">{(currentData as any)[f.key] || "—"}</p>
                )}
              </div>
            ))}
          </div>
          {isEditing && (
            <div className="flex gap-2 mt-6">
              <Button onClick={() => save.mutate()} disabled={save.isPending}>
                <Save className="h-4 w-4 mr-2" />{t('common.save')}
              </Button>
              <Button variant="outline" onClick={() => setForm({})}>{t('common.cancel')}</Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* TEÁOR codes */}
      <TeaorSection companyId={company.id} />

      {/* Work areas - employer can manage */}
      <WorkAreaManager companyId={company.id} />
    </div>
  );
}

function TeaorSection({ companyId }: { companyId: string }) {
  const { t } = useTranslation();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [adding, setAdding] = useState(false);

  const { data: codes } = useQuery({
    queryKey: ["company-teaor", companyId],
    queryFn: async () => {
      const { data } = await supabase.from("company_teaor_codes" as any).select("*").eq("company_id", companyId).order("is_primary", { ascending: false });
      return (data || []) as any[];
    },
  });

  const addCode = useMutation({
    mutationFn: async ({ code, name }: { code: string; name: string }) => {
      const { error } = await supabase.from("company_teaor_codes" as any).insert({ company_id: companyId, teaor_code: code, teaor_name: name, is_primary: !codes?.length });
      if (error) throw error;
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["company-teaor"] }); setAdding(false); },
    onError: (e: any) => toast({ variant: "destructive", title: t("common.error"), description: e.message }),
  });

  const removeCode = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("company_teaor_codes" as any).delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["company-teaor"] }),
  });

  const setPrimary = useMutation({
    mutationFn: async (id: string) => {
      await supabase.from("company_teaor_codes" as any).update({ is_primary: false }).eq("company_id", companyId);
      const { error } = await supabase.from("company_teaor_codes" as any).update({ is_primary: true }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["company-teaor"] }),
  });

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-lg">{t("accident.teaorCodes")}</CardTitle>
        <Button size="sm" onClick={() => setAdding(true)}><Plus className="h-4 w-4 mr-1" />{t("accident.addTeaor")}</Button>
      </CardHeader>
      <CardContent className="space-y-3">
        {adding && (
          <div className="flex gap-2 items-end">
            <div className="flex-1">
              <TeaorSearch value="" onChange={(code, name) => addCode.mutate({ code, name })} />
            </div>
            <Button size="sm" variant="outline" onClick={() => setAdding(false)}>{t("common.cancel")}</Button>
          </div>
        )}
        <div className="flex flex-wrap gap-2">
          {codes?.map((c: any) => (
            <Badge key={c.id} variant={c.is_primary ? "default" : "secondary"} className="gap-1 text-sm py-1 px-3">
              {c.is_primary && <Star className="h-3 w-3" />}
              {c.teaor_code} — {c.teaor_name}
              {!c.is_primary && (
                <button type="button" onClick={() => setPrimary.mutate(c.id)} className="ml-1 hover:text-primary" title={t("accident.setPrimary")}>
                  <Star className="h-3 w-3" />
                </button>
              )}
              <button type="button" onClick={() => removeCode.mutate(c.id)} className="ml-1 hover:text-destructive"><X className="h-3 w-3" /></button>
            </Badge>
          ))}
          {!codes?.length && !adding && <p className="text-sm text-muted-foreground">{t("common.noData")}</p>}
        </div>
      </CardContent>
    </Card>
  );
}
