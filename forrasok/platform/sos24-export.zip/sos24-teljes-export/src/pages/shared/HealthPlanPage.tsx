import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useMutation, useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, Sparkles, Heart, Salad, Dumbbell, Target, RefreshCw, Printer, Save, History, FileText, Stethoscope } from "lucide-react";
import ReactMarkdown from "react-markdown";
import { toast } from "sonner";
import { format } from "date-fns";
import { hu } from "date-fns/locale";
import DoctorRecommendationsSection from "@/components/DoctorRecommendationsSection";

// ... keep existing code

interface Preferences {
  diet_preference: string;
  food_allergies: string;
  exercise_preference: string;
  physical_limitations: string;
  exercise_time: string;
  goals: string;
}

export default function HealthPlanPage() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const [step, setStep] = useState<"preferences" | "generating" | "result">("preferences");
  const [preferences, setPreferences] = useState<Preferences>({
    diet_preference: "",
    food_allergies: "",
    exercise_preference: "",
    physical_limitations: "",
    exercise_time: "",
    goals: "",
  });
  const [plan, setPlan] = useState<string>("");
  const [generatedAt, setGeneratedAt] = useState<string>("");
  const [currentPlanId, setCurrentPlanId] = useState<string | null>(null);
  const [showHistory, setShowHistory] = useState(false);

  const { data: savedPlans, refetch: refetchPlans } = useQuery({
    queryKey: ["health-plans", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("health_plans")
        .select("*")
        .eq("user_id", user!.id)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  const generate = useMutation({
    mutationFn: async () => {
      setStep("generating");
      const { data, error } = await supabase.functions.invoke("ai-health-plan", {
        body: { preferences },
      });
      if (error) throw error;
      return data;
    },
    onSuccess: (data) => {
      setPlan(data.plan);
      setGeneratedAt(data.generated_at);
      setCurrentPlanId(null);
      setStep("result");
    },
    onError: (e: any) => {
      console.error("Health plan error:", e);
      toast.error(t("healthPlan.generateError"));
      setStep("preferences");
    },
  });

  const savePlan = useMutation({
    mutationFn: async () => {
      const { data, error } = await supabase.from("health_plans").insert({
        user_id: user!.id,
        preferences: preferences as any,
        plan_markdown: plan,
        generated_at: generatedAt,
      }).select("id").single();
      if (error) throw error;
      return data;
    },
    onSuccess: (data) => {
      setCurrentPlanId(data.id);
      refetchPlans();
      toast.success(t("healthPlan.saved"));
    },
    onError: () => toast.error(t("healthPlan.saveError")),
  });

  const loadPlan = (saved: any) => {
    setPlan(saved.plan_markdown);
    setGeneratedAt(saved.generated_at);
    setCurrentPlanId(saved.id);
    if (saved.preferences) {
      setPreferences(saved.preferences as Preferences);
    }
    setShowHistory(false);
    setStep("result");
  };

  const handlePrint = () => {
    window.print();
  };

  const updatePref = (key: keyof Preferences, value: string) => {
    setPreferences((p) => ({ ...p, [key]: value }));
  };

  if (step === "generating") {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-6 print:hidden">
        <div className="relative">
          <div className="h-20 w-20 rounded-full bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center">
            <Sparkles className="h-10 w-10 text-primary animate-pulse" />
          </div>
          <Loader2 className="h-24 w-24 animate-spin text-secondary absolute -top-2 -left-2" />
        </div>
        <div className="text-center space-y-2">
          <h2 className="text-xl font-bold">{t("healthPlan.generating")}</h2>
          <p className="text-muted-foreground text-sm max-w-md">
            {t("healthPlan.aiDesc")}
          </p>
        </div>
      </div>
    );
  }

  if (step === "result") {
    return (
      <div className="space-y-6">
        <div className="hidden print:block print:mb-6">
          <div className="text-center border-b-2 border-foreground pb-4 mb-4">
            <h1 className="text-2xl font-bold">{t("healthPlan.personalPlan")}</h1>
            <p className="text-sm mt-1">
              {generatedAt ? format(new Date(generatedAt), "yyyy. MMMM d. HH:mm", { locale: hu }) : ""}
            </p>
          </div>
        </div>

        <div className="flex items-center justify-between print:hidden">
          <div className="flex items-center gap-3">
            <Heart className="h-6 w-6 text-primary" />
            <h1 className="text-2xl font-bold">{t("healthPlan.personalPlan")}</h1>
          </div>
          <div className="flex items-center gap-2 flex-wrap justify-end">
            <Badge variant="secondary" className="text-xs">
              {generatedAt ? format(new Date(generatedAt), "yyyy. MMM d. HH:mm", { locale: hu }) : ""}
            </Badge>
            {!currentPlanId && (
              <Button variant="default" size="sm" onClick={() => savePlan.mutate()} disabled={savePlan.isPending}>
                {savePlan.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <Save className="h-4 w-4 mr-1" />}
                {t("healthPlan.save")}
              </Button>
            )}
            {currentPlanId && (
              <Badge variant="outline" className="text-xs text-green-600 border-green-600">
                ✓ {t("healthPlan.savedBadge")}
              </Badge>
            )}
            <Button variant="outline" size="sm" onClick={handlePrint}>
              <Printer className="h-4 w-4 mr-1" /> {t("healthPlan.print")}
            </Button>
            <Button variant="outline" size="sm" onClick={() => { setStep("preferences"); setPlan(""); setCurrentPlanId(null); }}>
              <RefreshCw className="h-4 w-4 mr-1" /> {t("healthPlan.newPlan")}
            </Button>
          </div>
        </div>

        <Card className="print:shadow-none print:border-none">
          <CardContent className="pt-6 prose prose-sm max-w-none dark:prose-invert prose-headings:text-foreground prose-p:text-foreground/90 prose-li:text-foreground/90 prose-strong:text-foreground print:prose-headings:text-black print:prose-p:text-black print:prose-li:text-black print:prose-strong:text-black">
            <ReactMarkdown>{plan}</ReactMarkdown>
          </CardContent>
        </Card>

        <p className="text-xs text-muted-foreground text-center italic print:text-black print:mt-8">
          {t("healthPlan.disclaimer")}
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="my-plan">
        <TabsList>
          <TabsTrigger value="my-plan">
            <Heart className="h-4 w-4 mr-1" /> {t("healthPlan.myPlan")}
          </TabsTrigger>
          <TabsTrigger value="doctor-recs">
            <Stethoscope className="h-4 w-4 mr-1" /> {t("healthPlan.doctorRecs")}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="my-plan">
          <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Heart className="h-6 w-6 text-primary" />
          <h1 className="text-2xl font-bold">{t("healthPlan.digitalPlan")}</h1>
        </div>
        {(savedPlans?.length ?? 0) > 0 && (
          <Button variant="outline" size="sm" onClick={() => setShowHistory(!showHistory)}>
            <History className="h-4 w-4 mr-1" />
            {t("healthPlan.previousPlans")} ({savedPlans?.length})
          </Button>
        )}
      </div>

      {showHistory && savedPlans && savedPlans.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <History className="h-5 w-5" />
              {t("healthPlan.previousPlansList")}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {savedPlans.map((sp: any) => (
                <button
                  key={sp.id}
                  onClick={() => loadPlan(sp)}
                  className="w-full flex items-center justify-between p-3 rounded-lg border hover:bg-muted/50 transition-colors text-left"
                >
                  <div className="flex items-center gap-3">
                    <FileText className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium">
                        {t("healthPlan.planDate", { date: format(new Date(sp.generated_at), "yyyy. MMMM d.", { locale: hu }) })}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {sp.preferences?.goals ? `${t("healthPlan.goalPrefix")}${(sp.preferences.goals as string).substring(0, 60)}...` : t("healthPlan.generalPlan")}
                      </p>
                    </div>
                  </div>
                  <Badge variant="secondary" className="text-xs">
                    {format(new Date(sp.created_at), "HH:mm")}
                  </Badge>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-secondary" />
            {t("healthPlan.howItWorks")}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-4">
            {t("healthPlan.howItWorksDesc")}
          </p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { icon: Heart, label: t("healthPlan.patientCard"), color: "text-red-500" },
              { icon: Salad, label: t("healthPlan.foodJournal"), color: "text-green-500" },
              { icon: Dumbbell, label: t("healthPlan.healthJournal"), color: "text-blue-500" },
              { icon: Target, label: t("healthPlan.questionnaires"), color: "text-purple-500" },
            ].map(({ icon: Icon, label, color }) => (
              <div key={label} className="flex items-center gap-2 p-2 rounded-md bg-muted/50">
                <Icon className={`h-4 w-4 ${color}`} />
                <span className="text-xs font-medium">{label}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Salad className="h-5 w-5 text-green-600" />
            {t("healthPlan.dietPrefs")}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-1.5">
              <Label>{t("healthPlan.dietType")}</Label>
              <Select value={preferences.diet_preference} onValueChange={(v) => updatePref("diet_preference", v)}>
                <SelectTrigger><SelectValue placeholder={t("healthPlan.select")} /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="normal">{t("healthPlan.normal")}</SelectItem>
                  <SelectItem value="vegetarian">{t("healthPlan.vegetarian")}</SelectItem>
                  <SelectItem value="vegan">{t("healthPlan.vegan")}</SelectItem>
                  <SelectItem value="ketogenic">{t("healthPlan.ketogenic")}</SelectItem>
                  <SelectItem value="mediterranean">{t("healthPlan.mediterranean")}</SelectItem>
                  <SelectItem value="low_carb">{t("healthPlan.lowCarb")}</SelectItem>
                  <SelectItem value="gluten_free">{t("healthPlan.glutenFree")}</SelectItem>
                  <SelectItem value="lactose_free">{t("healthPlan.lactoseFree")}</SelectItem>
                  <SelectItem value="diabetic">{t("healthPlan.diabetic")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>{t("healthPlan.foodAllergies")}</Label>
              <Input
                placeholder={t("healthPlan.foodAllergiesPlaceholder")}
                value={preferences.food_allergies}
                onChange={(e) => updatePref("food_allergies", e.target.value)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Dumbbell className="h-5 w-5 text-blue-600" />
            {t("healthPlan.exercisePrefs")}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-1.5">
              <Label>{t("healthPlan.exerciseType")}</Label>
              <Select value={preferences.exercise_preference} onValueChange={(v) => updatePref("exercise_preference", v)}>
                <SelectTrigger><SelectValue placeholder={t("healthPlan.select")} /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="walking">{t("healthPlan.walking")}</SelectItem>
                  <SelectItem value="running">{t("healthPlan.running")}</SelectItem>
                  <SelectItem value="cycling">{t("healthPlan.cycling")}</SelectItem>
                  <SelectItem value="swimming">{t("healthPlan.swimming")}</SelectItem>
                  <SelectItem value="gym">{t("healthPlan.gym")}</SelectItem>
                  <SelectItem value="yoga">{t("healthPlan.yoga")}</SelectItem>
                  <SelectItem value="team_sport">{t("healthPlan.teamSport")}</SelectItem>
                  <SelectItem value="home">{t("healthPlan.home")}</SelectItem>
                  <SelectItem value="none">{t("healthPlan.none")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>{t("healthPlan.weeklyTime")}</Label>
              <Select value={preferences.exercise_time} onValueChange={(v) => updatePref("exercise_time", v)}>
                <SelectTrigger><SelectValue placeholder={t("healthPlan.select")} /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="30min">{t("healthPlan.lessThan30")}</SelectItem>
                  <SelectItem value="1h">{t("healthPlan.thirtyTo1h")}</SelectItem>
                  <SelectItem value="2h">{t("healthPlan.oneToTwo")}</SelectItem>
                  <SelectItem value="3h">{t("healthPlan.twoToThree")}</SelectItem>
                  <SelectItem value="5h">{t("healthPlan.threeToFive")}</SelectItem>
                  <SelectItem value="5h+">{t("healthPlan.moreThan5")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>{t("healthPlan.physicalLimitations")}</Label>
            <Input
              placeholder={t("healthPlan.physicalLimitationsPlaceholder")}
              value={preferences.physical_limitations}
              onChange={(e) => updatePref("physical_limitations", e.target.value)}
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Target className="h-5 w-5 text-purple-600" />
            {t("healthPlan.goals")}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-1.5">
            <Label>{t("healthPlan.whatGoals")}</Label>
            <Textarea
              placeholder={t("healthPlan.goalsPlaceholder")}
              value={preferences.goals}
              onChange={(e) => updatePref("goals", e.target.value)}
              rows={3}
            />
          </div>
        </CardContent>
      </Card>

      <Separator />

      <Button
        size="lg"
        className="w-full text-base gap-2"
        onClick={() => generate.mutate()}
        disabled={generate.isPending}
      >
        <Sparkles className="h-5 w-5" />
        {t("healthPlan.generatePlan")}
      </Button>

      <p className="text-xs text-muted-foreground text-center">
        {t("healthPlan.generationNote")}
      </p>
          </div>
        </TabsContent>

        <TabsContent value="doctor-recs">
          <DoctorRecommendationsSection />
        </TabsContent>
      </Tabs>
    </div>
  );
}
