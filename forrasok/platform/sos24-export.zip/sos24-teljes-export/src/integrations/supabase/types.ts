export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      accident_reports: {
        Row: {
          accident_causes: string | null
          accident_date: string | null
          accident_geo_code: string | null
          accident_geo_location: string | null
          accident_time_hour: string | null
          attachments_notes: string | null
          company_id: string
          created_at: string
          created_by: string
          detailed_description: string | null
          disability_days: number | null
          doctor_date: string | null
          doctor_name: string | null
          doctor_stamp_no: string | null
          employee_id: string
          employer_address: string | null
          employer_email: string | null
          employer_fax: string | null
          employer_local_staff_category: string | null
          employer_mobile: string | null
          employer_name: string | null
          employer_org_form: string | null
          employer_phone: string | null
          employer_rep_date: string | null
          employer_rep_name: string | null
          employer_rep_position: string | null
          employer_tax_id: string | null
          employer_tax_number: string | null
          employer_teaor_local: string | null
          employer_teaor_main: string | null
          employer_total_staff_category: string | null
          gps_lat: number | null
          gps_lng: number | null
          icd_codes: string[] | null
          id: string
          injured_address: string | null
          injured_birth_date: string | null
          injured_birth_name: string | null
          injured_birth_place: string | null
          injured_body_part_code: string | null
          injured_citizenship: string | null
          injured_employment_nature: string | null
          injured_employment_type: string | null
          injured_feor_code: string | null
          injured_feor_name: string | null
          injured_gender: string | null
          injured_mother_name: string | null
          injured_name: string | null
          injured_phone: string | null
          injured_taj: string | null
          injury_contact_material: string | null
          injury_contact_mode: string | null
          injury_severity_code: string | null
          injury_type_code: string | null
          injury_work_hour: string | null
          investigator_cert_no: string | null
          investigator_date: string | null
          investigator_name: string | null
          personal_factor_employer: string | null
          personal_factor_injured: string | null
          photos: string[] | null
          physical_activity: string | null
          physical_activity_material: string | null
          prevention_measures: string | null
          registration_number: string | null
          report_type: string | null
          safety_device_guard: string | null
          safety_device_other: string | null
          safety_device_ppe: string | null
          safety_device_protection: string | null
          safety_device_signal: string | null
          safety_rep_agreement: string | null
          safety_rep_date: string | null
          safety_rep_name: string | null
          status: string
          territorial_code: string | null
          triggering_event: string | null
          triggering_event_material: string | null
          updated_at: string
          work_location_code: string | null
          work_process: string | null
          workplace_environment: string | null
        }
        Insert: {
          accident_causes?: string | null
          accident_date?: string | null
          accident_geo_code?: string | null
          accident_geo_location?: string | null
          accident_time_hour?: string | null
          attachments_notes?: string | null
          company_id: string
          created_at?: string
          created_by: string
          detailed_description?: string | null
          disability_days?: number | null
          doctor_date?: string | null
          doctor_name?: string | null
          doctor_stamp_no?: string | null
          employee_id: string
          employer_address?: string | null
          employer_email?: string | null
          employer_fax?: string | null
          employer_local_staff_category?: string | null
          employer_mobile?: string | null
          employer_name?: string | null
          employer_org_form?: string | null
          employer_phone?: string | null
          employer_rep_date?: string | null
          employer_rep_name?: string | null
          employer_rep_position?: string | null
          employer_tax_id?: string | null
          employer_tax_number?: string | null
          employer_teaor_local?: string | null
          employer_teaor_main?: string | null
          employer_total_staff_category?: string | null
          gps_lat?: number | null
          gps_lng?: number | null
          icd_codes?: string[] | null
          id?: string
          injured_address?: string | null
          injured_birth_date?: string | null
          injured_birth_name?: string | null
          injured_birth_place?: string | null
          injured_body_part_code?: string | null
          injured_citizenship?: string | null
          injured_employment_nature?: string | null
          injured_employment_type?: string | null
          injured_feor_code?: string | null
          injured_feor_name?: string | null
          injured_gender?: string | null
          injured_mother_name?: string | null
          injured_name?: string | null
          injured_phone?: string | null
          injured_taj?: string | null
          injury_contact_material?: string | null
          injury_contact_mode?: string | null
          injury_severity_code?: string | null
          injury_type_code?: string | null
          injury_work_hour?: string | null
          investigator_cert_no?: string | null
          investigator_date?: string | null
          investigator_name?: string | null
          personal_factor_employer?: string | null
          personal_factor_injured?: string | null
          photos?: string[] | null
          physical_activity?: string | null
          physical_activity_material?: string | null
          prevention_measures?: string | null
          registration_number?: string | null
          report_type?: string | null
          safety_device_guard?: string | null
          safety_device_other?: string | null
          safety_device_ppe?: string | null
          safety_device_protection?: string | null
          safety_device_signal?: string | null
          safety_rep_agreement?: string | null
          safety_rep_date?: string | null
          safety_rep_name?: string | null
          status?: string
          territorial_code?: string | null
          triggering_event?: string | null
          triggering_event_material?: string | null
          updated_at?: string
          work_location_code?: string | null
          work_process?: string | null
          workplace_environment?: string | null
        }
        Update: {
          accident_causes?: string | null
          accident_date?: string | null
          accident_geo_code?: string | null
          accident_geo_location?: string | null
          accident_time_hour?: string | null
          attachments_notes?: string | null
          company_id?: string
          created_at?: string
          created_by?: string
          detailed_description?: string | null
          disability_days?: number | null
          doctor_date?: string | null
          doctor_name?: string | null
          doctor_stamp_no?: string | null
          employee_id?: string
          employer_address?: string | null
          employer_email?: string | null
          employer_fax?: string | null
          employer_local_staff_category?: string | null
          employer_mobile?: string | null
          employer_name?: string | null
          employer_org_form?: string | null
          employer_phone?: string | null
          employer_rep_date?: string | null
          employer_rep_name?: string | null
          employer_rep_position?: string | null
          employer_tax_id?: string | null
          employer_tax_number?: string | null
          employer_teaor_local?: string | null
          employer_teaor_main?: string | null
          employer_total_staff_category?: string | null
          gps_lat?: number | null
          gps_lng?: number | null
          icd_codes?: string[] | null
          id?: string
          injured_address?: string | null
          injured_birth_date?: string | null
          injured_birth_name?: string | null
          injured_birth_place?: string | null
          injured_body_part_code?: string | null
          injured_citizenship?: string | null
          injured_employment_nature?: string | null
          injured_employment_type?: string | null
          injured_feor_code?: string | null
          injured_feor_name?: string | null
          injured_gender?: string | null
          injured_mother_name?: string | null
          injured_name?: string | null
          injured_phone?: string | null
          injured_taj?: string | null
          injury_contact_material?: string | null
          injury_contact_mode?: string | null
          injury_severity_code?: string | null
          injury_type_code?: string | null
          injury_work_hour?: string | null
          investigator_cert_no?: string | null
          investigator_date?: string | null
          investigator_name?: string | null
          personal_factor_employer?: string | null
          personal_factor_injured?: string | null
          photos?: string[] | null
          physical_activity?: string | null
          physical_activity_material?: string | null
          prevention_measures?: string | null
          registration_number?: string | null
          report_type?: string | null
          safety_device_guard?: string | null
          safety_device_other?: string | null
          safety_device_ppe?: string | null
          safety_device_protection?: string | null
          safety_device_signal?: string | null
          safety_rep_agreement?: string | null
          safety_rep_date?: string | null
          safety_rep_name?: string | null
          status?: string
          territorial_code?: string | null
          triggering_event?: string | null
          triggering_event_material?: string | null
          updated_at?: string
          work_location_code?: string | null
          work_process?: string | null
          workplace_environment?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "accident_reports_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      activities: {
        Row: {
          created_at: string
          icon_name: string | null
          id: string
          image_url: string | null
          is_active: boolean
          long_description: string | null
          name: string
          og_description: string | null
          og_image: string | null
          og_title: string | null
          page_content: string | null
          seo_description: string | null
          seo_keywords: string | null
          seo_title: string | null
          short_description: string | null
          slug: string
          sort_order: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          icon_name?: string | null
          id?: string
          image_url?: string | null
          is_active?: boolean
          long_description?: string | null
          name: string
          og_description?: string | null
          og_image?: string | null
          og_title?: string | null
          page_content?: string | null
          seo_description?: string | null
          seo_keywords?: string | null
          seo_title?: string | null
          short_description?: string | null
          slug: string
          sort_order?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          icon_name?: string | null
          id?: string
          image_url?: string | null
          is_active?: boolean
          long_description?: string | null
          name?: string
          og_description?: string | null
          og_image?: string | null
          og_title?: string | null
          page_content?: string | null
          seo_description?: string | null
          seo_keywords?: string | null
          seo_title?: string | null
          short_description?: string | null
          slug?: string
          sort_order?: number
          updated_at?: string
        }
        Relationships: []
      }
      appointment_slots: {
        Row: {
          assistant_id: string | null
          capacity: number
          created_at: string
          doctor_id: string | null
          id: string
          is_active: boolean
          location_id: string | null
          service_id: string | null
          slot_end: string
          slot_start: string
          updated_at: string
        }
        Insert: {
          assistant_id?: string | null
          capacity?: number
          created_at?: string
          doctor_id?: string | null
          id?: string
          is_active?: boolean
          location_id?: string | null
          service_id?: string | null
          slot_end: string
          slot_start: string
          updated_at?: string
        }
        Update: {
          assistant_id?: string | null
          capacity?: number
          created_at?: string
          doctor_id?: string | null
          id?: string
          is_active?: boolean
          location_id?: string | null
          service_id?: string | null
          slot_end?: string
          slot_start?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "appointment_slots_location_id_fkey"
            columns: ["location_id"]
            isOneToOne: false
            referencedRelation: "locations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "appointment_slots_service_id_fkey"
            columns: ["service_id"]
            isOneToOne: false
            referencedRelation: "services"
            referencedColumns: ["id"]
          },
        ]
      }
      appointments: {
        Row: {
          created_at: string
          doctor_id: string | null
          id: string
          notes: string | null
          patient_id: string
          service_id: string | null
          slot_id: string | null
          status: Database["public"]["Enums"]["appointment_status"]
          updated_at: string
        }
        Insert: {
          created_at?: string
          doctor_id?: string | null
          id?: string
          notes?: string | null
          patient_id: string
          service_id?: string | null
          slot_id?: string | null
          status?: Database["public"]["Enums"]["appointment_status"]
          updated_at?: string
        }
        Update: {
          created_at?: string
          doctor_id?: string | null
          id?: string
          notes?: string | null
          patient_id?: string
          service_id?: string | null
          slot_id?: string | null
          status?: Database["public"]["Enums"]["appointment_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "appointments_service_id_fkey"
            columns: ["service_id"]
            isOneToOne: false
            referencedRelation: "services"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "appointments_slot_id_fkey"
            columns: ["slot_id"]
            isOneToOne: false
            referencedRelation: "appointment_slots"
            referencedColumns: ["id"]
          },
        ]
      }
      audit_logs: {
        Row: {
          action: string
          changed_fields: string[] | null
          created_at: string
          id: string
          ip_address: string | null
          new_data: Json | null
          old_data: Json | null
          record_id: string
          table_name: string
          user_id: string | null
        }
        Insert: {
          action: string
          changed_fields?: string[] | null
          created_at?: string
          id?: string
          ip_address?: string | null
          new_data?: Json | null
          old_data?: Json | null
          record_id: string
          table_name: string
          user_id?: string | null
        }
        Update: {
          action?: string
          changed_fields?: string[] | null
          created_at?: string
          id?: string
          ip_address?: string | null
          new_data?: Json | null
          old_data?: Json | null
          record_id?: string
          table_name?: string
          user_id?: string | null
        }
        Relationships: []
      }
      bulk_import_logs: {
        Row: {
          created_at: string
          details: Json
          duplicate_count: number
          error_count: number
          file_name: string | null
          id: string
          import_type: string
          new_count: number
          success_count: number
          total_rows: number
          user_id: string
        }
        Insert: {
          created_at?: string
          details?: Json
          duplicate_count?: number
          error_count?: number
          file_name?: string | null
          id?: string
          import_type?: string
          new_count?: number
          success_count?: number
          total_rows?: number
          user_id: string
        }
        Update: {
          created_at?: string
          details?: Json
          duplicate_count?: number
          error_count?: number
          file_name?: string | null
          id?: string
          import_type?: string
          new_count?: number
          success_count?: number
          total_rows?: number
          user_id?: string
        }
        Relationships: []
      }
      certificates: {
        Row: {
          certificate_date: string
          certificate_type: string
          created_at: string
          doctor_id: string
          id: string
          notes: string | null
          patient_id: string
          pdf_url: string | null
          purpose: string | null
          updated_at: string
          valid_from: string | null
          valid_until: string | null
        }
        Insert: {
          certificate_date?: string
          certificate_type: string
          created_at?: string
          doctor_id: string
          id?: string
          notes?: string | null
          patient_id: string
          pdf_url?: string | null
          purpose?: string | null
          updated_at?: string
          valid_from?: string | null
          valid_until?: string | null
        }
        Update: {
          certificate_date?: string
          certificate_type?: string
          created_at?: string
          doctor_id?: string
          id?: string
          notes?: string | null
          patient_id?: string
          pdf_url?: string | null
          purpose?: string | null
          updated_at?: string
          valid_from?: string | null
          valid_until?: string | null
        }
        Relationships: []
      }
      companies: {
        Row: {
          address: string | null
          contact_email: string | null
          contact_phone: string | null
          contract_category: string | null
          contract_price: number | null
          created_at: string
          created_by: string | null
          id: string
          industry: string | null
          name: string
          pricing_type: string | null
          registration_no: string | null
          tax_number: string | null
          updated_at: string
        }
        Insert: {
          address?: string | null
          contact_email?: string | null
          contact_phone?: string | null
          contract_category?: string | null
          contract_price?: number | null
          created_at?: string
          created_by?: string | null
          id?: string
          industry?: string | null
          name: string
          pricing_type?: string | null
          registration_no?: string | null
          tax_number?: string | null
          updated_at?: string
        }
        Update: {
          address?: string | null
          contact_email?: string | null
          contact_phone?: string | null
          contract_category?: string | null
          contract_price?: number | null
          created_at?: string
          created_by?: string | null
          id?: string
          industry?: string | null
          name?: string
          pricing_type?: string | null
          registration_no?: string | null
          tax_number?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      company_hazardous_substances: {
        Row: {
          annual_quantity: string | null
          company_id: string
          created_at: string
          created_by: string | null
          exposure_type: string | null
          id: string
          ppe_required: string | null
          substance_id: string
          usage_description: string | null
        }
        Insert: {
          annual_quantity?: string | null
          company_id: string
          created_at?: string
          created_by?: string | null
          exposure_type?: string | null
          id?: string
          ppe_required?: string | null
          substance_id: string
          usage_description?: string | null
        }
        Update: {
          annual_quantity?: string | null
          company_id?: string
          created_at?: string
          created_by?: string | null
          exposure_type?: string | null
          id?: string
          ppe_required?: string | null
          substance_id?: string
          usage_description?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "company_hazardous_substances_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "company_hazardous_substances_substance_id_fkey"
            columns: ["substance_id"]
            isOneToOne: false
            referencedRelation: "hazardous_substances"
            referencedColumns: ["id"]
          },
        ]
      }
      company_sites: {
        Row: {
          address: string | null
          city: string | null
          company_id: string
          created_at: string
          created_by: string | null
          id: string
          name: string
          postal_code: string | null
          updated_at: string
        }
        Insert: {
          address?: string | null
          city?: string | null
          company_id: string
          created_at?: string
          created_by?: string | null
          id?: string
          name: string
          postal_code?: string | null
          updated_at?: string
        }
        Update: {
          address?: string | null
          city?: string | null
          company_id?: string
          created_at?: string
          created_by?: string | null
          id?: string
          name?: string
          postal_code?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "company_sites_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      company_teaor_codes: {
        Row: {
          company_id: string
          created_at: string
          created_by: string | null
          id: string
          is_primary: boolean
          teaor_code: string
          teaor_name: string | null
        }
        Insert: {
          company_id: string
          created_at?: string
          created_by?: string | null
          id?: string
          is_primary?: boolean
          teaor_code: string
          teaor_name?: string | null
        }
        Update: {
          company_id?: string
          created_at?: string
          created_by?: string | null
          id?: string
          is_primary?: boolean
          teaor_code?: string
          teaor_name?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "company_teaor_codes_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      competitor_analyses: {
        Row: {
          analysis_type: string
          competitor_url_id: string | null
          created_at: string
          created_by: string | null
          id: string
          results: Json
        }
        Insert: {
          analysis_type?: string
          competitor_url_id?: string | null
          created_at?: string
          created_by?: string | null
          id?: string
          results?: Json
        }
        Update: {
          analysis_type?: string
          competitor_url_id?: string | null
          created_at?: string
          created_by?: string | null
          id?: string
          results?: Json
        }
        Relationships: [
          {
            foreignKeyName: "competitor_analyses_competitor_url_id_fkey"
            columns: ["competitor_url_id"]
            isOneToOne: false
            referencedRelation: "competitor_urls"
            referencedColumns: ["id"]
          },
        ]
      }
      competitor_urls: {
        Row: {
          created_at: string
          created_by: string | null
          id: string
          is_active: boolean
          name: string
          url: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          id?: string
          is_active?: boolean
          name?: string
          url: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          id?: string
          is_active?: boolean
          name?: string
          url?: string
        }
        Relationships: []
      }
      content_translations: {
        Row: {
          created_at: string
          field_name: string
          id: string
          language: string
          record_id: string
          table_name: string
          updated_at: string
          value: string
        }
        Insert: {
          created_at?: string
          field_name: string
          id?: string
          language: string
          record_id: string
          table_name: string
          updated_at?: string
          value: string
        }
        Update: {
          created_at?: string
          field_name?: string
          id?: string
          language?: string
          record_id?: string
          table_name?: string
          updated_at?: string
          value?: string
        }
        Relationships: []
      }
      doctor_recommendations: {
        Row: {
          created_at: string
          doctor_id: string
          duration_days: number | null
          id: string
          is_read: boolean
          patient_id: string
          plan_markdown: string
          preferences: Json | null
          title: string
          type: string
        }
        Insert: {
          created_at?: string
          doctor_id: string
          duration_days?: number | null
          id?: string
          is_read?: boolean
          patient_id: string
          plan_markdown?: string
          preferences?: Json | null
          title?: string
          type: string
        }
        Update: {
          created_at?: string
          doctor_id?: string
          duration_days?: number | null
          id?: string
          is_read?: boolean
          patient_id?: string
          plan_markdown?: string
          preferences?: Json | null
          title?: string
          type?: string
        }
        Relationships: []
      }
      document_tags: {
        Row: {
          created_at: string
          id: string
          is_active: boolean
          label: string
          sort_order: number
        }
        Insert: {
          created_at?: string
          id?: string
          is_active?: boolean
          label: string
          sort_order?: number
        }
        Update: {
          created_at?: string
          id?: string
          is_active?: boolean
          label?: string
          sort_order?: number
        }
        Relationships: []
      }
      document_templates: {
        Row: {
          created_at: string
          document_type: string
          fields: Json
          id: string
          is_active: boolean
          name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          document_type: string
          fields?: Json
          id?: string
          is_active?: boolean
          name: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          document_type?: string
          fields?: Json
          id?: string
          is_active?: boolean
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      documents: {
        Row: {
          ai_analysis: Json | null
          created_at: string
          created_by: string | null
          document_type: string
          file_name: string
          file_path: string
          file_size: number | null
          id: string
          mime_type: string | null
          related_id: string | null
          tags: string[] | null
          user_id: string
        }
        Insert: {
          ai_analysis?: Json | null
          created_at?: string
          created_by?: string | null
          document_type: string
          file_name: string
          file_path: string
          file_size?: number | null
          id?: string
          mime_type?: string | null
          related_id?: string | null
          tags?: string[] | null
          user_id: string
        }
        Update: {
          ai_analysis?: Json | null
          created_at?: string
          created_by?: string | null
          document_type?: string
          file_name?: string
          file_path?: string
          file_size?: number | null
          id?: string
          mime_type?: string | null
          related_id?: string | null
          tags?: string[] | null
          user_id?: string
        }
        Relationships: []
      }
      email_send_log: {
        Row: {
          created_at: string
          error_message: string | null
          id: string
          message_id: string | null
          metadata: Json | null
          recipient_email: string
          status: string
          template_name: string
        }
        Insert: {
          created_at?: string
          error_message?: string | null
          id?: string
          message_id?: string | null
          metadata?: Json | null
          recipient_email: string
          status: string
          template_name: string
        }
        Update: {
          created_at?: string
          error_message?: string | null
          id?: string
          message_id?: string | null
          metadata?: Json | null
          recipient_email?: string
          status?: string
          template_name?: string
        }
        Relationships: []
      }
      email_send_state: {
        Row: {
          auth_email_ttl_minutes: number
          batch_size: number
          id: number
          retry_after_until: string | null
          send_delay_ms: number
          transactional_email_ttl_minutes: number
          updated_at: string
        }
        Insert: {
          auth_email_ttl_minutes?: number
          batch_size?: number
          id?: number
          retry_after_until?: string | null
          send_delay_ms?: number
          transactional_email_ttl_minutes?: number
          updated_at?: string
        }
        Update: {
          auth_email_ttl_minutes?: number
          batch_size?: number
          id?: number
          retry_after_until?: string | null
          send_delay_ms?: number
          transactional_email_ttl_minutes?: number
          updated_at?: string
        }
        Relationships: []
      }
      email_unsubscribe_tokens: {
        Row: {
          created_at: string
          email: string
          id: string
          token: string
          used_at: string | null
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          token: string
          used_at?: string | null
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          token?: string
          used_at?: string | null
        }
        Relationships: []
      }
      examinations: {
        Row: {
          ai_notes: string | null
          appointment_id: string | null
          clinical_findings: Json | null
          created_at: string
          doctor_id: string
          exam_type: string
          id: string
          next_lab_control: string | null
          patient_data: Json | null
          patient_id: string
          referral_id: string | null
          restrictions: string | null
          result: Database["public"]["Enums"]["opinion_status"]
          valid_until: string | null
          workflow_status: string | null
        }
        Insert: {
          ai_notes?: string | null
          appointment_id?: string | null
          clinical_findings?: Json | null
          created_at?: string
          doctor_id: string
          exam_type: string
          id?: string
          next_lab_control?: string | null
          patient_data?: Json | null
          patient_id: string
          referral_id?: string | null
          restrictions?: string | null
          result?: Database["public"]["Enums"]["opinion_status"]
          valid_until?: string | null
          workflow_status?: string | null
        }
        Update: {
          ai_notes?: string | null
          appointment_id?: string | null
          clinical_findings?: Json | null
          created_at?: string
          doctor_id?: string
          exam_type?: string
          id?: string
          next_lab_control?: string | null
          patient_data?: Json | null
          patient_id?: string
          referral_id?: string | null
          restrictions?: string | null
          result?: Database["public"]["Enums"]["opinion_status"]
          valid_until?: string | null
          workflow_status?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "examinations_appointment_id_fkey"
            columns: ["appointment_id"]
            isOneToOne: false
            referencedRelation: "appointments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "examinations_referral_id_fkey"
            columns: ["referral_id"]
            isOneToOne: false
            referencedRelation: "referrals"
            referencedColumns: ["id"]
          },
        ]
      }
      food_journal: {
        Row: {
          ai_analyzed: boolean
          calories_estimated: number | null
          carbs_g: number | null
          created_at: string
          entry_date: string
          fat_g: number | null
          fiber_g: number | null
          food_description: string | null
          id: string
          image_url: string | null
          meal_type: string
          notes: string | null
          protein_g: number | null
          user_id: string
        }
        Insert: {
          ai_analyzed?: boolean
          calories_estimated?: number | null
          carbs_g?: number | null
          created_at?: string
          entry_date?: string
          fat_g?: number | null
          fiber_g?: number | null
          food_description?: string | null
          id?: string
          image_url?: string | null
          meal_type?: string
          notes?: string | null
          protein_g?: number | null
          user_id: string
        }
        Update: {
          ai_analyzed?: boolean
          calories_estimated?: number | null
          carbs_g?: number | null
          created_at?: string
          entry_date?: string
          fat_g?: number | null
          fiber_g?: number | null
          food_description?: string | null
          id?: string
          image_url?: string | null
          meal_type?: string
          notes?: string | null
          protein_g?: number | null
          user_id?: string
        }
        Relationships: []
      }
      gdpr_requests: {
        Row: {
          created_at: string
          id: string
          notes: string | null
          processed_at: string | null
          processed_by: string | null
          status: string
          type: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          notes?: string | null
          processed_at?: string | null
          processed_by?: string | null
          status?: string
          type: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          notes?: string | null
          processed_at?: string | null
          processed_by?: string | null
          status?: string
          type?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      hazardous_substances: {
        Row: {
          cas_number: string | null
          created_at: string
          date_of_inclusion: string | null
          decision_url: string | null
          description: string | null
          ec_number: string | null
          id: string
          is_active: boolean
          iuclid_dataset_url: string | null
          name: string
          reason_for_inclusion: string | null
          remarks: string | null
          source: string
          support_document_url: string | null
        }
        Insert: {
          cas_number?: string | null
          created_at?: string
          date_of_inclusion?: string | null
          decision_url?: string | null
          description?: string | null
          ec_number?: string | null
          id?: string
          is_active?: boolean
          iuclid_dataset_url?: string | null
          name: string
          reason_for_inclusion?: string | null
          remarks?: string | null
          source?: string
          support_document_url?: string | null
        }
        Update: {
          cas_number?: string | null
          created_at?: string
          date_of_inclusion?: string | null
          decision_url?: string | null
          description?: string | null
          ec_number?: string | null
          id?: string
          is_active?: boolean
          iuclid_dataset_url?: string | null
          name?: string
          reason_for_inclusion?: string | null
          remarks?: string | null
          source?: string
          support_document_url?: string | null
        }
        Relationships: []
      }
      health_journal: {
        Row: {
          blood_pressure_diastolic: number | null
          blood_pressure_systolic: number | null
          blood_sugar: number | null
          created_at: string
          entry_date: string
          heart_rate: number | null
          id: string
          notes: string | null
          temperature: number | null
          user_id: string
          weight_kg: number | null
        }
        Insert: {
          blood_pressure_diastolic?: number | null
          blood_pressure_systolic?: number | null
          blood_sugar?: number | null
          created_at?: string
          entry_date?: string
          heart_rate?: number | null
          id?: string
          notes?: string | null
          temperature?: number | null
          user_id: string
          weight_kg?: number | null
        }
        Update: {
          blood_pressure_diastolic?: number | null
          blood_pressure_systolic?: number | null
          blood_sugar?: number | null
          created_at?: string
          entry_date?: string
          heart_rate?: number | null
          id?: string
          notes?: string | null
          temperature?: number | null
          user_id?: string
          weight_kg?: number | null
        }
        Relationships: []
      }
      health_plans: {
        Row: {
          created_at: string
          generated_at: string
          id: string
          plan_markdown: string
          preferences: Json | null
          user_id: string
        }
        Insert: {
          created_at?: string
          generated_at?: string
          id?: string
          plan_markdown: string
          preferences?: Json | null
          user_id: string
        }
        Update: {
          created_at?: string
          generated_at?: string
          id?: string
          plan_markdown?: string
          preferences?: Json | null
          user_id?: string
        }
        Relationships: []
      }
      health_reports: {
        Row: {
          blood_pressure_diastolic: number | null
          blood_pressure_systolic: number | null
          blood_sugar: number | null
          created_at: string
          heart_rate: number | null
          height_cm: number | null
          id: string
          notes: string | null
          report_date: string
          user_id: string
          weight_kg: number | null
        }
        Insert: {
          blood_pressure_diastolic?: number | null
          blood_pressure_systolic?: number | null
          blood_sugar?: number | null
          created_at?: string
          heart_rate?: number | null
          height_cm?: number | null
          id?: string
          notes?: string | null
          report_date?: string
          user_id: string
          weight_kg?: number | null
        }
        Update: {
          blood_pressure_diastolic?: number | null
          blood_pressure_systolic?: number | null
          blood_sugar?: number | null
          created_at?: string
          heart_rate?: number | null
          height_cm?: number | null
          id?: string
          notes?: string | null
          report_date?: string
          user_id?: string
          weight_kg?: number | null
        }
        Relationships: []
      }
      i18n_overrides: {
        Row: {
          id: string
          language: string
          translations: Json
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          id?: string
          language: string
          translations?: Json
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          id?: string
          language?: string
          translations?: Json
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      icd_codes: {
        Row: {
          category: string | null
          code: string
          created_at: string
          id: string
          is_active: boolean
          label_en: string | null
          label_hu: string
          level: number
          parent_code: string | null
          synonyms: string[] | null
          updated_at: string
          version: Database["public"]["Enums"]["icd_version"]
        }
        Insert: {
          category?: string | null
          code: string
          created_at?: string
          id?: string
          is_active?: boolean
          label_en?: string | null
          label_hu: string
          level?: number
          parent_code?: string | null
          synonyms?: string[] | null
          updated_at?: string
          version?: Database["public"]["Enums"]["icd_version"]
        }
        Update: {
          category?: string | null
          code?: string
          created_at?: string
          id?: string
          is_active?: boolean
          label_en?: string | null
          label_hu?: string
          level?: number
          parent_code?: string | null
          synonyms?: string[] | null
          updated_at?: string
          version?: Database["public"]["Enums"]["icd_version"]
        }
        Relationships: []
      }
      lab_markup_config: {
        Row: {
          home_sampling_fee_huf: number
          id: number
          markup_huf: number
          updated_at: string
        }
        Insert: {
          home_sampling_fee_huf?: number
          id?: number
          markup_huf?: number
          updated_at?: string
        }
        Update: {
          home_sampling_fee_huf?: number
          id?: number
          markup_huf?: number
          updated_at?: string
        }
        Relationships: []
      }
      lab_orders: {
        Row: {
          created_at: string
          customer_email: string
          customer_name: string
          customer_phone: string
          home_address: string | null
          id: string
          location_id: string | null
          notes: string | null
          order_number: string
          ordered_tests: Json
          preferred_date: string | null
          sampling_type: string
          status: string
          total_price_huf: number
          updated_at: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          customer_email: string
          customer_name: string
          customer_phone: string
          home_address?: string | null
          id?: string
          location_id?: string | null
          notes?: string | null
          order_number?: string
          ordered_tests?: Json
          preferred_date?: string | null
          sampling_type?: string
          status?: string
          total_price_huf?: number
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          customer_email?: string
          customer_name?: string
          customer_phone?: string
          home_address?: string | null
          id?: string
          location_id?: string | null
          notes?: string | null
          order_number?: string
          ordered_tests?: Json
          preferred_date?: string | null
          sampling_type?: string
          status?: string
          total_price_huf?: number
          updated_at?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "lab_orders_location_id_fkey"
            columns: ["location_id"]
            isOneToOne: false
            referencedRelation: "locations"
            referencedColumns: ["id"]
          },
        ]
      }
      lab_packages: {
        Row: {
          created_at: string
          description: string | null
          display_order: number
          icon: string | null
          id: string
          is_active: boolean
          name: string
          target_audience: string | null
          test_ids: string[]
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          display_order?: number
          icon?: string | null
          id?: string
          is_active?: boolean
          name: string
          target_audience?: string | null
          test_ids?: string[]
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          display_order?: number
          icon?: string | null
          id?: string
          is_active?: boolean
          name?: string
          target_audience?: string | null
          test_ids?: string[]
          updated_at?: string
        }
        Relationships: []
      }
      lab_pricing_config: {
        Row: {
          points: number
          price_huf: number
          test_id: string
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          points?: number
          price_huf?: number
          test_id: string
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          points?: number
          price_huf?: number
          test_id?: string
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      lab_requests: {
        Row: {
          cost_bearer: string | null
          created_at: string
          id: string
          notes: string | null
          patient_id: string
          physician_id: string
          priority: string
          request_number: string
          requested_tests: Json
          scheduled_date: string | null
          status: string
          updated_at: string
        }
        Insert: {
          cost_bearer?: string | null
          created_at?: string
          id?: string
          notes?: string | null
          patient_id: string
          physician_id: string
          priority?: string
          request_number?: string
          requested_tests?: Json
          scheduled_date?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          cost_bearer?: string | null
          created_at?: string
          id?: string
          notes?: string | null
          patient_id?: string
          physician_id?: string
          priority?: string
          request_number?: string
          requested_tests?: Json
          scheduled_date?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      locations: {
        Row: {
          address: string | null
          city: string | null
          created_at: string
          description: string | null
          email: string | null
          google_maps_url: string | null
          id: string
          is_active: boolean
          name: string
          phone: string | null
          responsible_user_id: string | null
          updated_at: string
          whatsapp: string | null
        }
        Insert: {
          address?: string | null
          city?: string | null
          created_at?: string
          description?: string | null
          email?: string | null
          google_maps_url?: string | null
          id?: string
          is_active?: boolean
          name: string
          phone?: string | null
          responsible_user_id?: string | null
          updated_at?: string
          whatsapp?: string | null
        }
        Update: {
          address?: string | null
          city?: string | null
          created_at?: string
          description?: string | null
          email?: string | null
          google_maps_url?: string | null
          id?: string
          is_active?: boolean
          name?: string
          phone?: string | null
          responsible_user_id?: string | null
          updated_at?: string
          whatsapp?: string | null
        }
        Relationships: []
      }
      medical_opinions: {
        Row: {
          appointment_id: string | null
          company_id: string | null
          created_at: string
          doctor_id: string
          icd_codes: string[] | null
          id: string
          notes: string | null
          opinion_date: string
          patient_id: string
          pdf_url: string | null
          signature_data: string | null
          status: Database["public"]["Enums"]["opinion_status"]
          updated_at: string
          valid_until: string | null
        }
        Insert: {
          appointment_id?: string | null
          company_id?: string | null
          created_at?: string
          doctor_id: string
          icd_codes?: string[] | null
          id?: string
          notes?: string | null
          opinion_date?: string
          patient_id: string
          pdf_url?: string | null
          signature_data?: string | null
          status?: Database["public"]["Enums"]["opinion_status"]
          updated_at?: string
          valid_until?: string | null
        }
        Update: {
          appointment_id?: string | null
          company_id?: string | null
          created_at?: string
          doctor_id?: string
          icd_codes?: string[] | null
          id?: string
          notes?: string | null
          opinion_date?: string
          patient_id?: string
          pdf_url?: string | null
          signature_data?: string | null
          status?: Database["public"]["Enums"]["opinion_status"]
          updated_at?: string
          valid_until?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "medical_opinions_appointment_id_fkey"
            columns: ["appointment_id"]
            isOneToOne: false
            referencedRelation: "appointments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "medical_opinions_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      medication_requests: {
        Row: {
          created_at: string
          doctor_response: string | null
          id: string
          medication_name: string
          notes: string | null
          patient_id: string
          request_type: string
          status: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          doctor_response?: string | null
          id?: string
          medication_name: string
          notes?: string | null
          patient_id: string
          request_type?: string
          status?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          doctor_response?: string | null
          id?: string
          medication_name?: string
          notes?: string | null
          patient_id?: string
          request_type?: string
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      medications: {
        Row: {
          id: string
          name: string
        }
        Insert: {
          id?: string
          name: string
        }
        Update: {
          id?: string
          name?: string
        }
        Relationships: []
      }
      messages: {
        Row: {
          body: string
          created_at: string
          group_role: Database["public"]["Enums"]["app_role"] | null
          id: string
          is_read: boolean
          recipient_id: string | null
          sender_id: string
          subject: string | null
        }
        Insert: {
          body: string
          created_at?: string
          group_role?: Database["public"]["Enums"]["app_role"] | null
          id?: string
          is_read?: boolean
          recipient_id?: string | null
          sender_id: string
          subject?: string | null
        }
        Update: {
          body?: string
          created_at?: string
          group_role?: Database["public"]["Enums"]["app_role"] | null
          id?: string
          is_read?: boolean
          recipient_id?: string | null
          sender_id?: string
          subject?: string | null
        }
        Relationships: []
      }
      navigation_links: {
        Row: {
          created_at: string
          href: string
          id: string
          is_active: boolean
          label: string
          parent_id: string | null
          sort_order: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          href: string
          id?: string
          is_active?: boolean
          label: string
          parent_id?: string | null
          sort_order?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          href?: string
          id?: string
          is_active?: boolean
          label?: string
          parent_id?: string | null
          sort_order?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "navigation_links_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "navigation_links"
            referencedColumns: ["id"]
          },
        ]
      }
      noise_vibration_measurements: {
        Row: {
          created_at: string
          duration_seconds: number
          frequency_data: Json | null
          id: string
          location_description: string | null
          measured_by: string | null
          measurement_type: string
          notes: string | null
          peak_value: number | null
          risk_assessment_id: string
          value_db: number | null
          value_ms2: number | null
          workplace_id: string | null
        }
        Insert: {
          created_at?: string
          duration_seconds?: number
          frequency_data?: Json | null
          id?: string
          location_description?: string | null
          measured_by?: string | null
          measurement_type: string
          notes?: string | null
          peak_value?: number | null
          risk_assessment_id: string
          value_db?: number | null
          value_ms2?: number | null
          workplace_id?: string | null
        }
        Update: {
          created_at?: string
          duration_seconds?: number
          frequency_data?: Json | null
          id?: string
          location_description?: string | null
          measured_by?: string | null
          measurement_type?: string
          notes?: string | null
          peak_value?: number | null
          risk_assessment_id?: string
          value_db?: number | null
          value_ms2?: number | null
          workplace_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "noise_vibration_measurements_risk_assessment_id_fkey"
            columns: ["risk_assessment_id"]
            isOneToOne: false
            referencedRelation: "risk_assessments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "noise_vibration_measurements_workplace_id_fkey"
            columns: ["workplace_id"]
            isOneToOne: false
            referencedRelation: "workplaces"
            referencedColumns: ["id"]
          },
        ]
      }
      notification_preferences: {
        Row: {
          created_at: string
          email_appointments: boolean
          email_opinions: boolean
          email_reminders: boolean
          email_vaccinations: boolean
          id: string
          inapp_appointments: boolean
          inapp_opinions: boolean
          inapp_reminders: boolean
          inapp_vaccinations: boolean
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          email_appointments?: boolean
          email_opinions?: boolean
          email_reminders?: boolean
          email_vaccinations?: boolean
          id?: string
          inapp_appointments?: boolean
          inapp_opinions?: boolean
          inapp_reminders?: boolean
          inapp_vaccinations?: boolean
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          email_appointments?: boolean
          email_opinions?: boolean
          email_reminders?: boolean
          email_vaccinations?: boolean
          id?: string
          inapp_appointments?: boolean
          inapp_opinions?: boolean
          inapp_reminders?: boolean
          inapp_vaccinations?: boolean
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      notifications: {
        Row: {
          body: string | null
          created_at: string
          id: string
          is_read: boolean
          link: string | null
          title: string
          type: string
          user_id: string
        }
        Insert: {
          body?: string | null
          created_at?: string
          id?: string
          is_read?: boolean
          link?: string | null
          title: string
          type: string
          user_id: string
        }
        Update: {
          body?: string | null
          created_at?: string
          id?: string
          is_read?: boolean
          link?: string | null
          title?: string
          type?: string
          user_id?: string
        }
        Relationships: []
      }
      page_views: {
        Row: {
          created_at: string
          id: string
          page_path: string
          referrer: string | null
          user_agent: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          page_path: string
          referrer?: string | null
          user_agent?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          page_path?: string
          referrer?: string | null
          user_agent?: string | null
        }
        Relationships: []
      }
      pages_content: {
        Row: {
          content: string | null
          content_json: Json | null
          created_at: string
          id: string
          is_active: boolean
          page_key: string
          section: string
          sort_order: number
          updated_at: string
        }
        Insert: {
          content?: string | null
          content_json?: Json | null
          created_at?: string
          id?: string
          is_active?: boolean
          page_key: string
          section: string
          sort_order?: number
          updated_at?: string
        }
        Update: {
          content?: string | null
          content_json?: Json | null
          created_at?: string
          id?: string
          is_active?: boolean
          page_key?: string
          section?: string
          sort_order?: number
          updated_at?: string
        }
        Relationships: []
      }
      patient_cards: {
        Row: {
          alcohol: string | null
          chronic_diseases: string | null
          created_at: string
          drivers_license: boolean | null
          drug_allergies: string | null
          eating_habit: string | null
          education: string | null
          employer_name: string | null
          exposures: Json | null
          family_history: Json | null
          id: string
          last_chest_xray: string | null
          last_gynecology: string | null
          marital_status: string | null
          military_service: boolean | null
          notification_address: string | null
          occupation: string | null
          occupation_history: Json | null
          other_notes: string | null
          pregnancies: string | null
          previous_doctor: string | null
          professional_qual: string | null
          regular_medications: string | null
          reported_occupational_diseases: string | null
          smoking: Json | null
          sports_habit: string | null
          surgeries: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          alcohol?: string | null
          chronic_diseases?: string | null
          created_at?: string
          drivers_license?: boolean | null
          drug_allergies?: string | null
          eating_habit?: string | null
          education?: string | null
          employer_name?: string | null
          exposures?: Json | null
          family_history?: Json | null
          id?: string
          last_chest_xray?: string | null
          last_gynecology?: string | null
          marital_status?: string | null
          military_service?: boolean | null
          notification_address?: string | null
          occupation?: string | null
          occupation_history?: Json | null
          other_notes?: string | null
          pregnancies?: string | null
          previous_doctor?: string | null
          professional_qual?: string | null
          regular_medications?: string | null
          reported_occupational_diseases?: string | null
          smoking?: Json | null
          sports_habit?: string | null
          surgeries?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          alcohol?: string | null
          chronic_diseases?: string | null
          created_at?: string
          drivers_license?: boolean | null
          drug_allergies?: string | null
          eating_habit?: string | null
          education?: string | null
          employer_name?: string | null
          exposures?: Json | null
          family_history?: Json | null
          id?: string
          last_chest_xray?: string | null
          last_gynecology?: string | null
          marital_status?: string | null
          military_service?: boolean | null
          notification_address?: string | null
          occupation?: string | null
          occupation_history?: Json | null
          other_notes?: string | null
          pregnancies?: string | null
          previous_doctor?: string | null
          professional_qual?: string | null
          regular_medications?: string | null
          reported_occupational_diseases?: string | null
          smoking?: Json | null
          sports_habit?: string | null
          surgeries?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          address: string | null
          avatar_url: string | null
          birth_date: string | null
          birth_place: string | null
          blood_type: Database["public"]["Enums"]["blood_type"] | null
          created_at: string
          full_name: string
          gender: Database["public"]["Enums"]["gender_type"] | null
          id: string
          mother_name: string | null
          phone: string | null
          signature_url: string | null
          taj_number: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          address?: string | null
          avatar_url?: string | null
          birth_date?: string | null
          birth_place?: string | null
          blood_type?: Database["public"]["Enums"]["blood_type"] | null
          created_at?: string
          full_name?: string
          gender?: Database["public"]["Enums"]["gender_type"] | null
          id?: string
          mother_name?: string | null
          phone?: string | null
          signature_url?: string | null
          taj_number?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          address?: string | null
          avatar_url?: string | null
          birth_date?: string | null
          birth_place?: string | null
          blood_type?: Database["public"]["Enums"]["blood_type"] | null
          created_at?: string
          full_name?: string
          gender?: Database["public"]["Enums"]["gender_type"] | null
          id?: string
          mother_name?: string | null
          phone?: string | null
          signature_url?: string | null
          taj_number?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      questionnaire_assignments: {
        Row: {
          assigned_by: string
          completed_at: string | null
          created_at: string
          id: string
          message: string | null
          patient_id: string
          questionnaire_id: string
          status: string
        }
        Insert: {
          assigned_by: string
          completed_at?: string | null
          created_at?: string
          id?: string
          message?: string | null
          patient_id: string
          questionnaire_id: string
          status?: string
        }
        Update: {
          assigned_by?: string
          completed_at?: string | null
          created_at?: string
          id?: string
          message?: string | null
          patient_id?: string
          questionnaire_id?: string
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "questionnaire_assignments_questionnaire_id_fkey"
            columns: ["questionnaire_id"]
            isOneToOne: false
            referencedRelation: "questionnaires"
            referencedColumns: ["id"]
          },
        ]
      }
      questionnaire_submissions: {
        Row: {
          ai_evaluation: string | null
          answers: Json
          id: string
          questionnaire_id: string
          risk_category: string | null
          score: number | null
          submitted_at: string
          user_id: string
        }
        Insert: {
          ai_evaluation?: string | null
          answers?: Json
          id?: string
          questionnaire_id: string
          risk_category?: string | null
          score?: number | null
          submitted_at?: string
          user_id: string
        }
        Update: {
          ai_evaluation?: string | null
          answers?: Json
          id?: string
          questionnaire_id?: string
          risk_category?: string | null
          score?: number | null
          submitted_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "questionnaire_submissions_questionnaire_id_fkey"
            columns: ["questionnaire_id"]
            isOneToOne: false
            referencedRelation: "questionnaires"
            referencedColumns: ["id"]
          },
        ]
      }
      questionnaires: {
        Row: {
          created_at: string
          description: string | null
          fields: Json
          id: string
          is_active: boolean
          title: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          fields?: Json
          id?: string
          is_active?: boolean
          title: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          fields?: Json
          id?: string
          is_active?: boolean
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      referrals: {
        Row: {
          company_id: string
          created_at: string
          created_by: string
          employee_id: string
          exam_reason: string
          feor: string | null
          icd_codes: string[] | null
          id: string
          position: string | null
          risk_assessment_id: string | null
          risk_factors: Json | null
          status: Database["public"]["Enums"]["referral_status"]
          unit_name: string | null
          updated_at: string
          work_area_id: string | null
          workplace_id: string | null
        }
        Insert: {
          company_id: string
          created_at?: string
          created_by: string
          employee_id: string
          exam_reason: string
          feor?: string | null
          icd_codes?: string[] | null
          id?: string
          position?: string | null
          risk_assessment_id?: string | null
          risk_factors?: Json | null
          status?: Database["public"]["Enums"]["referral_status"]
          unit_name?: string | null
          updated_at?: string
          work_area_id?: string | null
          workplace_id?: string | null
        }
        Update: {
          company_id?: string
          created_at?: string
          created_by?: string
          employee_id?: string
          exam_reason?: string
          feor?: string | null
          icd_codes?: string[] | null
          id?: string
          position?: string | null
          risk_assessment_id?: string | null
          risk_factors?: Json | null
          status?: Database["public"]["Enums"]["referral_status"]
          unit_name?: string | null
          updated_at?: string
          work_area_id?: string | null
          workplace_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "referrals_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "referrals_risk_assessment_id_fk"
            columns: ["risk_assessment_id"]
            isOneToOne: false
            referencedRelation: "risk_assessments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "referrals_work_area_id_fk"
            columns: ["work_area_id"]
            isOneToOne: false
            referencedRelation: "work_areas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "referrals_workplace_id_fk"
            columns: ["workplace_id"]
            isOneToOne: false
            referencedRelation: "workplaces"
            referencedColumns: ["id"]
          },
        ]
      }
      requests: {
        Row: {
          assignee_id: string | null
          created_at: string
          description: string | null
          id: string
          requester_id: string
          response: string | null
          status: Database["public"]["Enums"]["request_status"]
          subject: string | null
          type: string
          updated_at: string
        }
        Insert: {
          assignee_id?: string | null
          created_at?: string
          description?: string | null
          id?: string
          requester_id: string
          response?: string | null
          status?: Database["public"]["Enums"]["request_status"]
          subject?: string | null
          type: string
          updated_at?: string
        }
        Update: {
          assignee_id?: string | null
          created_at?: string
          description?: string | null
          id?: string
          requester_id?: string
          response?: string | null
          status?: Database["public"]["Enums"]["request_status"]
          subject?: string | null
          type?: string
          updated_at?: string
        }
        Relationships: []
      }
      risk_assessment_hazards: {
        Row: {
          action_deadline: string | null
          action_hierarchy:
            | Database["public"]["Enums"]["action_hierarchy"]
            | null
          action_responsible: string | null
          action_status: Database["public"]["Enums"]["action_status"] | null
          ai_suggested: boolean | null
          created_at: string
          current_controls: string | null
          exposed_count: number | null
          exposure_duration: string | null
          exposure_frequency: string | null
          hazard_category: Database["public"]["Enums"]["hazard_category"]
          hazard_description: string | null
          hazard_name: string
          hazard_subcategory: string | null
          id: string
          probability: number | null
          required_actions: string | null
          residual_probability: number | null
          residual_risk_level: number | null
          residual_severity: number | null
          risk_assessment_id: string
          risk_category: string | null
          risk_level: number | null
          severity: number | null
          sort_order: number | null
          substance_ids: string[] | null
          workplace_id: string | null
        }
        Insert: {
          action_deadline?: string | null
          action_hierarchy?:
            | Database["public"]["Enums"]["action_hierarchy"]
            | null
          action_responsible?: string | null
          action_status?: Database["public"]["Enums"]["action_status"] | null
          ai_suggested?: boolean | null
          created_at?: string
          current_controls?: string | null
          exposed_count?: number | null
          exposure_duration?: string | null
          exposure_frequency?: string | null
          hazard_category?: Database["public"]["Enums"]["hazard_category"]
          hazard_description?: string | null
          hazard_name: string
          hazard_subcategory?: string | null
          id?: string
          probability?: number | null
          required_actions?: string | null
          residual_probability?: number | null
          residual_risk_level?: number | null
          residual_severity?: number | null
          risk_assessment_id: string
          risk_category?: string | null
          risk_level?: number | null
          severity?: number | null
          sort_order?: number | null
          substance_ids?: string[] | null
          workplace_id?: string | null
        }
        Update: {
          action_deadline?: string | null
          action_hierarchy?:
            | Database["public"]["Enums"]["action_hierarchy"]
            | null
          action_responsible?: string | null
          action_status?: Database["public"]["Enums"]["action_status"] | null
          ai_suggested?: boolean | null
          created_at?: string
          current_controls?: string | null
          exposed_count?: number | null
          exposure_duration?: string | null
          exposure_frequency?: string | null
          hazard_category?: Database["public"]["Enums"]["hazard_category"]
          hazard_description?: string | null
          hazard_name?: string
          hazard_subcategory?: string | null
          id?: string
          probability?: number | null
          required_actions?: string | null
          residual_probability?: number | null
          residual_risk_level?: number | null
          residual_severity?: number | null
          risk_assessment_id?: string
          risk_category?: string | null
          risk_level?: number | null
          severity?: number | null
          sort_order?: number | null
          substance_ids?: string[] | null
          workplace_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "risk_assessment_hazards_risk_assessment_id_fkey"
            columns: ["risk_assessment_id"]
            isOneToOne: false
            referencedRelation: "risk_assessments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "risk_assessment_hazards_workplace_id_fkey"
            columns: ["workplace_id"]
            isOneToOne: false
            referencedRelation: "workplaces"
            referencedColumns: ["id"]
          },
        ]
      }
      risk_assessment_photos: {
        Row: {
          ai_analysis: Json | null
          caption: string | null
          created_at: string
          file_name: string
          file_path: string
          id: string
          risk_assessment_id: string
          uploaded_by: string | null
          work_area_id: string | null
          workplace_id: string | null
        }
        Insert: {
          ai_analysis?: Json | null
          caption?: string | null
          created_at?: string
          file_name: string
          file_path: string
          id?: string
          risk_assessment_id: string
          uploaded_by?: string | null
          work_area_id?: string | null
          workplace_id?: string | null
        }
        Update: {
          ai_analysis?: Json | null
          caption?: string | null
          created_at?: string
          file_name?: string
          file_path?: string
          id?: string
          risk_assessment_id?: string
          uploaded_by?: string | null
          work_area_id?: string | null
          workplace_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "risk_assessment_photos_risk_assessment_id_fkey"
            columns: ["risk_assessment_id"]
            isOneToOne: false
            referencedRelation: "risk_assessments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "risk_assessment_photos_work_area_id_fkey"
            columns: ["work_area_id"]
            isOneToOne: false
            referencedRelation: "work_areas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "risk_assessment_photos_workplace_id_fkey"
            columns: ["workplace_id"]
            isOneToOne: false
            referencedRelation: "workplaces"
            referencedColumns: ["id"]
          },
        ]
      }
      risk_assessments: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          assessment_date: string
          assessor_name: string | null
          assessor_qualification: string | null
          company_id: string
          context_analysis: Json | null
          created_at: string
          created_by: string | null
          document_url: string | null
          id: string
          next_review_date: string | null
          previous_assessment_id: string | null
          review_frequency_months: number | null
          status: Database["public"]["Enums"]["risk_assessment_status"]
          summary_notes: string | null
          title: string
          updated_at: string
          work_area_id: string
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          assessment_date?: string
          assessor_name?: string | null
          assessor_qualification?: string | null
          company_id: string
          context_analysis?: Json | null
          created_at?: string
          created_by?: string | null
          document_url?: string | null
          id?: string
          next_review_date?: string | null
          previous_assessment_id?: string | null
          review_frequency_months?: number | null
          status?: Database["public"]["Enums"]["risk_assessment_status"]
          summary_notes?: string | null
          title?: string
          updated_at?: string
          work_area_id: string
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          assessment_date?: string
          assessor_name?: string | null
          assessor_qualification?: string | null
          company_id?: string
          context_analysis?: Json | null
          created_at?: string
          created_by?: string | null
          document_url?: string | null
          id?: string
          next_review_date?: string | null
          previous_assessment_id?: string | null
          review_frequency_months?: number | null
          status?: Database["public"]["Enums"]["risk_assessment_status"]
          summary_notes?: string | null
          title?: string
          updated_at?: string
          work_area_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "risk_assessments_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "risk_assessments_previous_assessment_id_fkey"
            columns: ["previous_assessment_id"]
            isOneToOne: false
            referencedRelation: "risk_assessments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "risk_assessments_work_area_id_fkey"
            columns: ["work_area_id"]
            isOneToOne: false
            referencedRelation: "work_areas"
            referencedColumns: ["id"]
          },
        ]
      }
      security_events: {
        Row: {
          action: string | null
          created_at: string
          duration_ms: number | null
          error_code: string | null
          error_message: string | null
          event_type: string
          function_name: string | null
          id: string
          metadata: Json
          operation: string | null
          resource_id: string | null
          resource_type: string | null
          route: string | null
          severity: string
          status_code: number | null
          table_name: string | null
          user_agent: string | null
          user_email: string | null
          user_id: string | null
        }
        Insert: {
          action?: string | null
          created_at?: string
          duration_ms?: number | null
          error_code?: string | null
          error_message?: string | null
          event_type: string
          function_name?: string | null
          id?: string
          metadata?: Json
          operation?: string | null
          resource_id?: string | null
          resource_type?: string | null
          route?: string | null
          severity?: string
          status_code?: number | null
          table_name?: string | null
          user_agent?: string | null
          user_email?: string | null
          user_id?: string | null
        }
        Update: {
          action?: string | null
          created_at?: string
          duration_ms?: number | null
          error_code?: string | null
          error_message?: string | null
          event_type?: string
          function_name?: string | null
          id?: string
          metadata?: Json
          operation?: string | null
          resource_id?: string | null
          resource_type?: string | null
          route?: string | null
          severity?: string
          status_code?: number | null
          table_name?: string | null
          user_agent?: string | null
          user_email?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      seo_audit_scores: {
        Row: {
          created_at: string
          grade: string
          id: string
          page_path: string
          score: number
        }
        Insert: {
          created_at?: string
          grade?: string
          id?: string
          page_path: string
          score?: number
        }
        Update: {
          created_at?: string
          grade?: string
          id?: string
          page_path?: string
          score?: number
        }
        Relationships: []
      }
      seo_pages: {
        Row: {
          canonical_url: string | null
          created_at: string
          description: string | null
          id: string
          keywords: string | null
          noindex: boolean
          og_description: string | null
          og_image: string | null
          og_title: string | null
          page_path: string
          title: string | null
          updated_at: string
        }
        Insert: {
          canonical_url?: string | null
          created_at?: string
          description?: string | null
          id?: string
          keywords?: string | null
          noindex?: boolean
          og_description?: string | null
          og_image?: string | null
          og_title?: string | null
          page_path: string
          title?: string | null
          updated_at?: string
        }
        Update: {
          canonical_url?: string | null
          created_at?: string
          description?: string | null
          id?: string
          keywords?: string | null
          noindex?: boolean
          og_description?: string | null
          og_image?: string | null
          og_title?: string | null
          page_path?: string
          title?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      service_categories: {
        Row: {
          created_at: string
          id: string
          is_active: boolean
          name: string
          sort_order: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_active?: boolean
          name: string
          sort_order?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          is_active?: boolean
          name?: string
          sort_order?: number
          updated_at?: string
        }
        Relationships: []
      }
      services: {
        Row: {
          category: string | null
          created_at: string
          description: string | null
          duration_min: number
          icon_name: string | null
          id: string
          is_active: boolean
          name: string
          price: number | null
          updated_at: string
        }
        Insert: {
          category?: string | null
          created_at?: string
          description?: string | null
          duration_min?: number
          icon_name?: string | null
          id?: string
          is_active?: boolean
          name: string
          price?: number | null
          updated_at?: string
        }
        Update: {
          category?: string | null
          created_at?: string
          description?: string | null
          duration_min?: number
          icon_name?: string | null
          id?: string
          is_active?: boolean
          name?: string
          price?: number | null
          updated_at?: string
        }
        Relationships: []
      }
      site_settings: {
        Row: {
          created_at: string
          id: string
          key: string
          label: string | null
          section: string | null
          updated_at: string
          value: string | null
          value_json: Json | null
        }
        Insert: {
          created_at?: string
          id?: string
          key: string
          label?: string | null
          section?: string | null
          updated_at?: string
          value?: string | null
          value_json?: Json | null
        }
        Update: {
          created_at?: string
          id?: string
          key?: string
          label?: string | null
          section?: string | null
          updated_at?: string
          value?: string | null
          value_json?: Json | null
        }
        Relationships: []
      }
      stool_journal: {
        Row: {
          ai_analyzed: boolean
          blood_present: boolean
          bristol_type: number | null
          color: string | null
          created_at: string
          entry_date: string
          id: string
          image_url: string | null
          mucus_present: boolean
          notes: string | null
          pain_level: number | null
          user_id: string
        }
        Insert: {
          ai_analyzed?: boolean
          blood_present?: boolean
          bristol_type?: number | null
          color?: string | null
          created_at?: string
          entry_date?: string
          id?: string
          image_url?: string | null
          mucus_present?: boolean
          notes?: string | null
          pain_level?: number | null
          user_id: string
        }
        Update: {
          ai_analyzed?: boolean
          blood_present?: boolean
          bristol_type?: number | null
          color?: string | null
          created_at?: string
          entry_date?: string
          id?: string
          image_url?: string | null
          mucus_present?: boolean
          notes?: string | null
          pain_level?: number | null
          user_id?: string
        }
        Relationships: []
      }
      suppressed_emails: {
        Row: {
          created_at: string
          email: string
          id: string
          metadata: Json | null
          reason: string
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          metadata?: Json | null
          reason: string
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          metadata?: Json | null
          reason?: string
        }
        Relationships: []
      }
      user_company_relations: {
        Row: {
          company_id: string
          created_at: string
          end_date: string | null
          feor_code: string | null
          feor_name: string | null
          hazard_substances: string[] | null
          id: string
          is_active: boolean
          position: string | null
          risk_factors: Json | null
          role: Database["public"]["Enums"]["app_role"]
          site_id: string | null
          start_date: string | null
          user_id: string
          work_area_id: string | null
          workplace_id: string | null
        }
        Insert: {
          company_id: string
          created_at?: string
          end_date?: string | null
          feor_code?: string | null
          feor_name?: string | null
          hazard_substances?: string[] | null
          id?: string
          is_active?: boolean
          position?: string | null
          risk_factors?: Json | null
          role?: Database["public"]["Enums"]["app_role"]
          site_id?: string | null
          start_date?: string | null
          user_id: string
          work_area_id?: string | null
          workplace_id?: string | null
        }
        Update: {
          company_id?: string
          created_at?: string
          end_date?: string | null
          feor_code?: string | null
          feor_name?: string | null
          hazard_substances?: string[] | null
          id?: string
          is_active?: boolean
          position?: string | null
          risk_factors?: Json | null
          role?: Database["public"]["Enums"]["app_role"]
          site_id?: string | null
          start_date?: string | null
          user_id?: string
          work_area_id?: string | null
          workplace_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "ucr_site_id_fk"
            columns: ["site_id"]
            isOneToOne: false
            referencedRelation: "company_sites"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ucr_work_area_id_fk"
            columns: ["work_area_id"]
            isOneToOne: false
            referencedRelation: "work_areas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ucr_workplace_id_fk"
            columns: ["workplace_id"]
            isOneToOne: false
            referencedRelation: "workplaces"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_company_relations_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          granted_at: string
          granted_by: string | null
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          granted_at?: string
          granted_by?: string | null
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          granted_at?: string
          granted_by?: string | null
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      vaccinations: {
        Row: {
          administered_by: string | null
          administered_date: string
          created_at: string
          expiry_date: string | null
          id: string
          lot_number: string | null
          notes: string | null
          updated_at: string
          user_id: string
          vaccine_name: string
        }
        Insert: {
          administered_by?: string | null
          administered_date: string
          created_at?: string
          expiry_date?: string | null
          id?: string
          lot_number?: string | null
          notes?: string | null
          updated_at?: string
          user_id: string
          vaccine_name: string
        }
        Update: {
          administered_by?: string | null
          administered_date?: string
          created_at?: string
          expiry_date?: string | null
          id?: string
          lot_number?: string | null
          notes?: string | null
          updated_at?: string
          user_id?: string
          vaccine_name?: string
        }
        Relationships: []
      }
      web_vitals: {
        Row: {
          created_at: string
          id: string
          metric_name: string
          page_path: string
          value: number
        }
        Insert: {
          created_at?: string
          id?: string
          metric_name: string
          page_path: string
          value: number
        }
        Update: {
          created_at?: string
          id?: string
          metric_name?: string
          page_path?: string
          value?: number
        }
        Relationships: []
      }
      work_area_sds_documents: {
        Row: {
          analysis_data: Json | null
          cas_number: string | null
          created_at: string
          ec_number: string | null
          file_name: string
          file_path: string
          id: string
          is_mixture: boolean | null
          mixture_components: Json | null
          risk_level: string | null
          substance_name: string | null
          updated_at: string
          uploaded_by: string | null
          work_area_id: string
        }
        Insert: {
          analysis_data?: Json | null
          cas_number?: string | null
          created_at?: string
          ec_number?: string | null
          file_name: string
          file_path: string
          id?: string
          is_mixture?: boolean | null
          mixture_components?: Json | null
          risk_level?: string | null
          substance_name?: string | null
          updated_at?: string
          uploaded_by?: string | null
          work_area_id: string
        }
        Update: {
          analysis_data?: Json | null
          cas_number?: string | null
          created_at?: string
          ec_number?: string | null
          file_name?: string
          file_path?: string
          id?: string
          is_mixture?: boolean | null
          mixture_components?: Json | null
          risk_level?: string | null
          substance_name?: string | null
          updated_at?: string
          uploaded_by?: string | null
          work_area_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "work_area_sds_documents_work_area_id_fkey"
            columns: ["work_area_id"]
            isOneToOne: false
            referencedRelation: "work_areas"
            referencedColumns: ["id"]
          },
        ]
      }
      work_areas: {
        Row: {
          area_size_m2: number | null
          created_at: string
          description: string | null
          floor_plan_url: string | null
          id: string
          name: string
          site_id: string
          updated_at: string
        }
        Insert: {
          area_size_m2?: number | null
          created_at?: string
          description?: string | null
          floor_plan_url?: string | null
          id?: string
          name: string
          site_id: string
          updated_at?: string
        }
        Update: {
          area_size_m2?: number | null
          created_at?: string
          description?: string | null
          floor_plan_url?: string | null
          id?: string
          name?: string
          site_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "work_areas_site_id_fkey"
            columns: ["site_id"]
            isOneToOne: false
            referencedRelation: "company_sites"
            referencedColumns: ["id"]
          },
        ]
      }
      workplaces: {
        Row: {
          code: string | null
          created_at: string
          description: string | null
          employee_count: number | null
          equipment_list: Json | null
          id: string
          name: string
          updated_at: string
          work_area_id: string
        }
        Insert: {
          code?: string | null
          created_at?: string
          description?: string | null
          employee_count?: number | null
          equipment_list?: Json | null
          id?: string
          name: string
          updated_at?: string
          work_area_id: string
        }
        Update: {
          code?: string | null
          created_at?: string
          description?: string | null
          employee_count?: number | null
          equipment_list?: Json | null
          id?: string
          name?: string
          updated_at?: string
          work_area_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "workplaces_work_area_id_fkey"
            columns: ["work_area_id"]
            isOneToOne: false
            referencedRelation: "work_areas"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      admin_get_recovery_history: {
        Args: { _limit?: number; _user_id: string }
        Returns: {
          created_at: string
          error_message: string
          id: string
          message_id: string
          metadata: Json
          recipient_email: string
          status: string
        }[]
      }
      admin_get_recovery_status: {
        Args: { _user_ids: string[] }
        Returns: {
          email: string
          email_confirmed_at: string
          has_password: boolean
          last_action_at: string
          last_action_kind: string
          last_admin_direct_at: string
          last_admin_direct_by: string
          last_recovery_error: string
          last_recovery_log_at: string
          last_recovery_status: string
          last_sign_in_at: string
          recovery_sent_at: string
          user_created_at: string
          user_id: string
        }[]
      }
      admin_get_user_providers: {
        Args: { _user_ids: string[] }
        Returns: {
          google_email: string
          last_apple_sign_in_at: string
          last_email_sign_in_at: string
          last_google_sign_in_at: string
          providers: string[]
          user_id: string
        }[]
      }
      admin_recovery_failures_summary: {
        Args: { _since?: string }
        Returns: {
          affected_recipients: number
          bounced_count: number
          complained_count: number
          dlq_count: number
          failed_count: number
          last_event_at: string
          recent: Json
          suppressed_count: number
          total_failures: number
        }[]
      }
      create_public_lab_order: {
        Args: {
          _customer_email: string
          _customer_name: string
          _customer_phone: string
          _home_address: string
          _location_id: string
          _notes: string
          _ordered_tests: Json
          _preferred_date: string
          _sampling_type: string
          _total_price_huf: number
        }
        Returns: {
          id: string
          order_number: string
        }[]
      }
      delete_email: {
        Args: { message_id: number; queue_name: string }
        Returns: boolean
      }
      email_queue_dispatch: { Args: never; Returns: undefined }
      enqueue_email: {
        Args: { payload: Json; queue_name: string }
        Returns: number
      }
      get_public_locations: {
        Args: never
        Returns: {
          address: string
          city: string
          description: string
          email: string
          google_maps_url: string
          id: string
          name: string
          phone: string
          whatsapp: string
        }[]
      }
      get_user_roles: {
        Args: { _user_id: string }
        Returns: Database["public"]["Enums"]["app_role"][]
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_company_member: {
        Args: {
          _company_id: string
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_employer_of_patient: {
        Args: { _employer_id: string; _patient_id: string }
        Returns: boolean
      }
      log_security_event: {
        Args: {
          _error_code?: string
          _error_message?: string
          _event_type: string
          _metadata?: Json
          _operation?: string
          _route?: string
          _severity?: string
          _table_name?: string
          _user_agent?: string
        }
        Returns: string
      }
      move_to_dlq: {
        Args: {
          dlq_name: string
          message_id: number
          payload: Json
          source_queue: string
        }
        Returns: number
      }
      read_email_batch: {
        Args: { batch_size: number; queue_name: string; vt: number }
        Returns: {
          message: Json
          msg_id: number
          read_ct: number
        }[]
      }
      search_icd_codes: {
        Args: { _limit?: number; _query: string; _version?: string }
        Returns: {
          category: string
          code: string
          id: string
          is_active: boolean
          label_en: string
          label_hu: string
          level: number
          parent_code: string
          synonyms: string[]
          version: Database["public"]["Enums"]["icd_version"]
        }[]
      }
      security_denials_summary: {
        Args: { _since: string }
        Returns: {
          denial_count: number
          last_seen: string
          sample_messages: string[]
          user_email: string
          user_id: string
        }[]
      }
      show_limit: { Args: never; Returns: number }
      show_trgm: { Args: { "": string }; Returns: string[] }
      validate_icd_code: {
        Args: { _code: string; _version?: string }
        Returns: boolean
      }
    }
    Enums: {
      action_hierarchy:
        | "elimination"
        | "substitution"
        | "engineering"
        | "admin"
        | "ppe"
      action_status: "planned" | "in_progress" | "completed"
      app_role:
        | "super_admin"
        | "haziorvos"
        | "uzemorvos"
        | "munkaltato"
        | "munkavallalo"
        | "praxistag"
      appointment_status:
        | "pending"
        | "confirmed"
        | "cancelled"
        | "completed"
        | "no_show"
      blood_type: "A+" | "A-" | "B+" | "B-" | "AB+" | "AB-" | "0+" | "0-"
      gender_type: "ferfi" | "no" | "egyeb"
      hazard_category:
        | "physical"
        | "chemical"
        | "biological"
        | "ergonomic"
        | "psychosocial"
        | "equipment"
        | "environment"
        | "fire"
        | "other"
      icd_version: "icd10" | "icd11"
      opinion_status:
        | "alkalmas"
        | "nem_alkalmas"
        | "feltetelesen_alkalmas"
        | "ideiglenes"
      referral_status:
        | "draft"
        | "sent"
        | "completed"
        | "appointment_booked"
        | "questionnaire_filled"
        | "exam_started"
      request_status: "pending" | "approved" | "rejected" | "completed"
      risk_assessment_status: "draft" | "in_review" | "approved" | "archived"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      action_hierarchy: [
        "elimination",
        "substitution",
        "engineering",
        "admin",
        "ppe",
      ],
      action_status: ["planned", "in_progress", "completed"],
      app_role: [
        "super_admin",
        "haziorvos",
        "uzemorvos",
        "munkaltato",
        "munkavallalo",
        "praxistag",
      ],
      appointment_status: [
        "pending",
        "confirmed",
        "cancelled",
        "completed",
        "no_show",
      ],
      blood_type: ["A+", "A-", "B+", "B-", "AB+", "AB-", "0+", "0-"],
      gender_type: ["ferfi", "no", "egyeb"],
      hazard_category: [
        "physical",
        "chemical",
        "biological",
        "ergonomic",
        "psychosocial",
        "equipment",
        "environment",
        "fire",
        "other",
      ],
      icd_version: ["icd10", "icd11"],
      opinion_status: [
        "alkalmas",
        "nem_alkalmas",
        "feltetelesen_alkalmas",
        "ideiglenes",
      ],
      referral_status: [
        "draft",
        "sent",
        "completed",
        "appointment_booked",
        "questionnaire_filled",
        "exam_started",
      ],
      request_status: ["pending", "approved", "rejected", "completed"],
      risk_assessment_status: ["draft", "in_review", "approved", "archived"],
    },
  },
} as const
