import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import type { LabTest } from '@/lib/labTestCatalog';

/** Step-by-step trace of a single price calculation — dev-only diagnostics. */
export interface PriceTrace {
  testId: string | undefined;
  testType: string;
  catalogPrice: number;
  hasOverride: boolean;
  overridePrice: number | null;
  basePrice: number;
  basePriceSource: 'override' | 'catalog';
  markupHuf: number;
  isElemi: boolean;
  markupApplied: boolean;
  markupSkipReason: string | null;
  finalPrice: number;
  steps: string[];
}

/**
 * Runtime toggle for verbose price tracing in dev tools.
 * Enable in browser console:  __LAB_PRICE_TRACE__ = true
 * Or per-test:                 __LAB_PRICE_TRACE_IDS__ = ['LK-34', 'LK-15']
 */
function isTraceEnabled(testId: string | undefined): boolean {
  if (typeof window === 'undefined') return false;
  const w = window as any;
  if (w.__LAB_PRICE_TRACE__ === true) return true;
  if (Array.isArray(w.__LAB_PRICE_TRACE_IDS__) && testId) {
    return w.__LAB_PRICE_TRACE_IDS__.includes(testId);
  }
  return false;
}

/**
 * Common pricing logic — markup applies to panels/packages/special tests,
 * but NOT to elementary tests (Elemi).
 *
 * Set `window.__LAB_PRICE_TRACE__ = true` in the browser console to see
 * every calculation step in the console; or `window.__LAB_PRICE_TRACE_IDS__ = ['LK-34']`
 * to trace only specific test IDs. Use `explainDisplayPrice()` for a
 * structured trace object you can inspect or display in UI.
 */
export function calculateDisplayPrice(
  test: Pick<LabTest, 'priceHuf' | 'type'>,
  overrides: Record<string, { points: number; priceHuf: number }>,
  markup: { markup_huf: number },
  testId?: string,
): number {
  const id = testId ?? (test as any).id;
  const override = id ? overrides[id] : undefined;
  const base = override?.priceHuf ?? test.priceHuf;
  const applyMarkup = test.type !== 'Elemi';
  const final = base + (applyMarkup ? markup.markup_huf : 0);

  if (isTraceEnabled(id)) {
    const trace = explainDisplayPrice(test, overrides, markup, testId);
    // eslint-disable-next-line no-console
    console.groupCollapsed(
      `%c[lab-price] ${id ?? '?'} (${test.type}) → ${final.toLocaleString('hu-HU')} Ft`,
      applyMarkup ? 'color:#d97706;font-weight:600' : 'color:#059669;font-weight:600',
    );
    trace.steps.forEach(s => console.log(s));
    console.log('trace:', trace);
    console.groupEnd();
  }

  return final;
}

/**
 * Returns a structured, human-readable trace of how a display price was computed.
 * Pure function (no side effects) — safe to call anywhere, including in production.
 */
export function explainDisplayPrice(
  test: Pick<LabTest, 'priceHuf' | 'type'>,
  overrides: Record<string, { points: number; priceHuf: number }>,
  markup: { markup_huf: number },
  testId?: string,
): PriceTrace {
  const id = testId ?? (test as any).id;
  const override = id ? overrides[id] : undefined;
  const hasOverride = !!override;
  const basePrice = override?.priceHuf ?? test.priceHuf;
  const basePriceSource: 'override' | 'catalog' = hasOverride ? 'override' : 'catalog';
  const isElemi = test.type === 'Elemi';
  const markupHuf = markup.markup_huf ?? 0;

  let markupApplied: boolean;
  let markupSkipReason: string | null = null;
  if (isElemi) {
    markupApplied = false;
    markupSkipReason = `type='Elemi' → szabály szerint elemi vizsgálat soha nem kap markupot`;
  } else if (markupHuf <= 0) {
    markupApplied = false;
    markupSkipReason = `globális markup_huf = ${markupHuf} (nincs beállítva felár)`;
  } else {
    markupApplied = true;
  }

  const finalPrice = basePrice + (markupApplied ? markupHuf : 0);

  const steps: string[] = [
    `1. Teszt: id=${id ?? '?'}, type='${test.type}', katalógus ár=${test.priceHuf} Ft`,
    hasOverride
      ? `2. Override TALÁLAT (lab_pricing_config): ${override!.priceHuf} Ft → alapár = ${basePrice} Ft`
      : `2. Override NINCS → alapár = katalógus ár = ${basePrice} Ft`,
    `3. Globális markup: ${markupHuf} Ft (lab_markup_config.markup_huf)`,
    markupApplied
      ? `4. type !== 'Elemi' → markup HOZZÁADVA: ${basePrice} + ${markupHuf} = ${finalPrice} Ft`
      : `4. Markup KIHAGYVA — ok: ${markupSkipReason}`,
    `5. Végső megjelenítendő ár: ${finalPrice} Ft`,
  ];

  return {
    testId: id,
    testType: test.type,
    catalogPrice: test.priceHuf,
    hasOverride,
    overridePrice: override?.priceHuf ?? null,
    basePrice,
    basePriceSource,
    markupHuf,
    isElemi,
    markupApplied,
    markupSkipReason,
    finalPrice,
    steps,
  };
}

/**
 * Validation: returns true if an "Elemi" test's override price suspiciously
 * equals base + markup, which usually means the markup was manually baked in
 * by mistake (Elemi tests never receive markup at display time).
 */
export function detectMarkupBakedIn(
  test: Pick<LabTest, 'priceHuf' | 'type'>,
  override: { priceHuf: number } | undefined,
  markupHuf: number,
): boolean {
  if (test.type !== 'Elemi') return false;
  if (!override || markupHuf <= 0) return false;
  return override.priceHuf === test.priceHuf + markupHuf;
}

export type LabPricingOverride = {
  test_id: string;
  points: number;
  price_huf: number;
};

export interface LabMarkupConfig {
  markup_huf: number;
  home_sampling_fee_huf: number;
}

/**
 * Fetches lab pricing overrides from the database.
 */
export function useLabPricing() {
  const [overrides, setOverrides] = useState<Record<string, { points: number; priceHuf: number }>>({});
  const [markup, setMarkup] = useState<LabMarkupConfig>({ markup_huf: 0, home_sampling_fee_huf: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      (supabase as any).from('lab_pricing_config').select('test_id, points, price_huf'),
      (supabase as any).from('lab_markup_config').select('markup_huf, home_sampling_fee_huf').maybeSingle(),
    ]).then(([pricingRes, markupRes]: [any, any]) => {
      if (pricingRes.data) {
        const map: Record<string, { points: number; priceHuf: number }> = {};
        pricingRes.data.forEach((row: LabPricingOverride) => {
          map[row.test_id] = { points: row.points, priceHuf: row.price_huf };
        });
        setOverrides(map);
      }
      if (markupRes.data) {
        setMarkup({
          markup_huf: markupRes.data.markup_huf ?? 0,
          home_sampling_fee_huf: markupRes.data.home_sampling_fee_huf ?? 0,
        });
      }
      setLoading(false);
    });
  }, []);

  return { overrides, markup, loading };
}
