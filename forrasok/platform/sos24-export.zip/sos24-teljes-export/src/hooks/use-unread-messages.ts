import { useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth, type AppRole } from "@/contexts/AuthContext";

export function useUnreadMessages() {
  const { user, roles } = useAuth();
  const qc = useQueryClient();

  const { data: unreadCount = 0 } = useQuery({
    queryKey: ["unread-count", user?.id],
    queryFn: async () => {
      if (!user) return 0;

      // Direct unread
      const { count: directCount } = await supabase
        .from("messages")
        .select("*", { count: "exact", head: true })
        .eq("recipient_id", user.id)
        .eq("is_read", false)
        .neq("sender_id", user.id);

      // Group unread (for user's roles)
      let groupCount = 0;
      if (roles.length > 0) {
        const { count } = await supabase
          .from("messages")
          .select("*", { count: "exact", head: true })
          .in("group_role", roles)
          .eq("is_read", false)
          .neq("sender_id", user.id);
        groupCount = count ?? 0;
      }

      return (directCount ?? 0) + groupCount;
    },
    enabled: !!user,
    refetchInterval: 30000, // Poll every 30s as fallback
  });

  // Realtime updates
  useEffect(() => {
    if (!user) return;
    const channel = supabase
      .channel("unread-counter")
      .on("postgres_changes", { event: "*", schema: "public", table: "messages" }, () => {
        qc.invalidateQueries({ queryKey: ["unread-count"] });
      })
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [user, qc]);

  return unreadCount;
}
