import { describe, it, expect } from 'vitest';
import { calculateDisplayPrice, detectMarkupBakedIn, explainDisplayPrice } from './use-lab-pricing';

const markup = { markup_huf: 4000 };
const noOverrides = {};

describe('calculateDisplayPrice', () => {
  describe('Elemi (elementary) tests — NO markup', () => {
    it('Nátrium (Elemi, 300 Ft) marad 300 Ft markup nélkül', () => {
      const test = { priceHuf: 300, type: 'Elemi' };
      expect(calculateDisplayPrice(test, noOverrides, markup)).toBe(300);
    });

    it('Kálium (Elemi, 230 Ft) marad 230 Ft', () => {
      const test = { priceHuf: 230, type: 'Elemi' };
      expect(calculateDisplayPrice(test, noOverrides, markup)).toBe(230);
    });

    it('Klorid (Elemi) — semmilyen markup nem adódik hozzá', () => {
      const test = { priceHuf: 250, type: 'Elemi' };
      expect(calculateDisplayPrice(test, noOverrides, markup)).toBe(250);
    });

    it('Elemi teszt nagy markup mellett is védett', () => {
      const test = { priceHuf: 500, type: 'Elemi' };
      expect(calculateDisplayPrice(test, noOverrides, { markup_huf: 99999 })).toBe(500);
    });
  });

  describe('Panel / csomag tesztek — markup HOZZÁADÓDIK', () => {
    it('Panel típusú teszt mindig megkapja a markupot', () => {
      const test = { priceHuf: 5000, type: 'Panel' };
      expect(calculateDisplayPrice(test, noOverrides, markup)).toBe(9000);
    });

    it('Csomag típusú teszt megkapja a markupot', () => {
      const test = { priceHuf: 8000, type: 'Csomag' };
      expect(calculateDisplayPrice(test, noOverrides, markup)).toBe(12000);
    });

    it('Speciális (nem-Elemi) teszt is markupos', () => {
      const test = { priceHuf: 3000, type: 'Speciális' };
      expect(calculateDisplayPrice(test, noOverrides, markup)).toBe(7000);
    });
  });

  describe('Override-ok kezelése', () => {
    it('Override felülírja az alapárat Elemi tesztnél (markup nélkül)', () => {
      const test = { priceHuf: 300, type: 'Elemi' };
      const overrides = { 'LK-34': { points: 5, priceHuf: 230 } };
      expect(calculateDisplayPrice(test, overrides, markup, 'LK-34')).toBe(230);
    });

    it('Override felülírja az alapárat panelnél (markuppal)', () => {
      const test = { priceHuf: 5000, type: 'Panel' };
      const overrides = { 'PANEL-1': { points: 30, priceHuf: 6000 } };
      expect(calculateDisplayPrice(test, overrides, markup, 'PANEL-1')).toBe(10000);
    });

    it('Hiányzó override esetén az alapár érvényes', () => {
      const test = { priceHuf: 300, type: 'Elemi' };
      const overrides = { 'OTHER-ID': { points: 5, priceHuf: 999 } };
      expect(calculateDisplayPrice(test, overrides, markup, 'LK-34')).toBe(300);
    });
  });

  describe('Élesszerű (regression) esetek', () => {
    it('REGRESSION: Nátrium soha nem lehet 4300 Ft (a hiba amit javítottunk)', () => {
      const natrium = { priceHuf: 300, type: 'Elemi' };
      const result = calculateDisplayPrice(natrium, noOverrides, { markup_huf: 4000 });
      expect(result).not.toBe(4300);
      expect(result).toBe(300);
    });

    it('Markup = 0 esetén minden teszt csak az alapárat mutatja', () => {
      const elemi = { priceHuf: 300, type: 'Elemi' };
      const panel = { priceHuf: 5000, type: 'Panel' };
      const zero = { markup_huf: 0 };
      expect(calculateDisplayPrice(elemi, noOverrides, zero)).toBe(300);
      expect(calculateDisplayPrice(panel, noOverrides, zero)).toBe(5000);
    });
  });
});

describe('detectMarkupBakedIn (admin validation)', () => {
  it('Elemi teszt + override = base+markup → GYANÚS', () => {
    const test = { priceHuf: 300, type: 'Elemi' };
    const override = { priceHuf: 4300 };
    expect(detectMarkupBakedIn(test, override, 4000)).toBe(true);
  });

  it('Elemi teszt + override ≠ base+markup → NEM gyanús', () => {
    const test = { priceHuf: 300, type: 'Elemi' };
    expect(detectMarkupBakedIn(test, { priceHuf: 350 }, 4000)).toBe(false);
    expect(detectMarkupBakedIn(test, { priceHuf: 230 }, 4000)).toBe(false);
  });

  it('Panel típusnál soha nem jelez (csak Elemi-re vonatkozik)', () => {
    const test = { priceHuf: 5000, type: 'Panel' };
    expect(detectMarkupBakedIn(test, { priceHuf: 9000 }, 4000)).toBe(false);
  });

  it('Override hiányában nem jelez', () => {
    const test = { priceHuf: 300, type: 'Elemi' };
    expect(detectMarkupBakedIn(test, undefined, 4000)).toBe(false);
  });

  it('Markup = 0 esetén nem jelez', () => {
    const test = { priceHuf: 300, type: 'Elemi' };
    expect(detectMarkupBakedIn(test, { priceHuf: 300 }, 0)).toBe(false);
  });
});

describe('explainDisplayPrice (developer trace)', () => {
  it('Elemi teszt: trace jelzi hogy markup ki van hagyva, és okot ad', () => {
    const t = { priceHuf: 300, type: 'Elemi' };
    const trace = explainDisplayPrice(t, {}, { markup_huf: 4000 }, 'LK-34');
    expect(trace.isElemi).toBe(true);
    expect(trace.markupApplied).toBe(false);
    expect(trace.markupSkipReason).toMatch(/Elemi/);
    expect(trace.finalPrice).toBe(300);
    expect(trace.basePriceSource).toBe('catalog');
    expect(trace.steps).toHaveLength(5);
  });

  it('Panel: trace jelzi hogy markup hozzáadódott', () => {
    const t = { priceHuf: 5000, type: 'Panel' };
    const trace = explainDisplayPrice(t, {}, { markup_huf: 4000 }, 'PANEL-1');
    expect(trace.markupApplied).toBe(true);
    expect(trace.markupSkipReason).toBeNull();
    expect(trace.finalPrice).toBe(9000);
    expect(trace.steps[3]).toMatch(/HOZZÁADVA/);
  });

  it('Override: trace forrása "override"', () => {
    const t = { priceHuf: 300, type: 'Elemi' };
    const trace = explainDisplayPrice(t, { 'LK-34': { points: 5, priceHuf: 230 } }, { markup_huf: 4000 }, 'LK-34');
    expect(trace.basePriceSource).toBe('override');
    expect(trace.basePrice).toBe(230);
    expect(trace.overridePrice).toBe(230);
    expect(trace.finalPrice).toBe(230);
  });

  it('Markup = 0: trace jelzi hogy nincs felár beállítva', () => {
    const t = { priceHuf: 5000, type: 'Panel' };
    const trace = explainDisplayPrice(t, {}, { markup_huf: 0 }, 'PANEL-1');
    expect(trace.markupApplied).toBe(false);
    expect(trace.markupSkipReason).toMatch(/nincs beállítva/);
    expect(trace.finalPrice).toBe(5000);
  });
});
