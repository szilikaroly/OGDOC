import { useState, useCallback } from "react";
import { useTranslation } from "react-i18next";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import type { IcdCode, IcdVersion } from "@/hooks/use-icd-codes";

export function useIcdAiSuggest() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [isSuggesting, setIsSuggesting] = useState(false);

  const suggest = useCallback(
    async (description: string, version: IcdVersion = "icd10", maxResults = 5): Promise<IcdCode[]> => {
      setIsSuggesting(true);
      try {
        const { data, error } = await supabase.functions.invoke("ai-icd-suggest", {
          body: { description, version, max_results: maxResults },
        });

        if (error) {
          console.error("ai-icd-suggest error:", error);
          toast({
            variant: "destructive",
            title: t("icd.aiSuggestErrorTitle"),
            description: error.message || t("icd.aiSuggestErrorDescription"),
          });
          return [];
        }

        const suggestions: IcdCode[] = (data?.suggestions ?? []).map((s: any) => ({
          id: s.id,
          code: s.code,
          version: s.version,
          label_hu: s.label_hu,
          label_en: s.label_en,
          parent_code: s.parent_code,
          level: s.level,
          synonyms: s.synonyms ?? [],
          category: s.category,
          is_active: s.is_active,
        }));

        if (suggestions.length === 0) {
          toast({
            title: t("icd.aiNoResultsTitle"),
            description: t("icd.aiNoResultsDescription"),
          });
        }

        return suggestions;
      } catch (e) {
        console.error("ai-icd-suggest exception:", e);
        toast({
          variant: "destructive",
          title: t("icd.aiSuggestErrorTitle"),
          description: t("icd.aiSuggestErrorDescription"),
        });
        return [];
      } finally {
        setIsSuggesting(false);
      }
    },
    [t, toast]
  );

  return { suggest, isSuggesting };
}
