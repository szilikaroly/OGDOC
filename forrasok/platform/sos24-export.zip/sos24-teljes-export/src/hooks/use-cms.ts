import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export function useSiteSettings() {
  return useQuery({
    queryKey: ["site-settings"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("site_settings")
        .select("id, key, value, value_json");
      if (error) throw error;
      const map: Record<string, string> = {};
      data?.forEach((row) => {
        map[row.key] = row.value ?? "";
      });
      return map;
    },
    staleTime: 5 * 60 * 1000,
  });
}

/** Returns a map of setting key -> setting row UUID */
export function useSiteSettingsIdMap() {
  return useQuery({
    queryKey: ["site-settings-id-map"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("site_settings")
        .select("id, key");
      if (error) throw error;
      const map: Record<string, string> = {};
      data?.forEach((row) => { map[row.key] = row.id; });
      return map;
    },
    staleTime: 5 * 60 * 1000,
  });
}

export function useNavigationLinks() {
  return useQuery({
    queryKey: ["navigation-links"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("navigation_links")
        .select("id, label, href, sort_order, parent_id")
        .eq("is_active", true)
        .order("sort_order");
      if (error) throw error;
      return data ?? [];
    },
    staleTime: 5 * 60 * 1000,
  });
}

export function usePageContent(pageKey: string) {
  return useQuery({
    queryKey: ["pages-content", pageKey],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("pages_content")
        .select("id, section, content, content_json, sort_order")
        .eq("page_key", pageKey)
        .eq("is_active", true)
        .order("sort_order");
      if (error) throw error;
      const map: Record<string, any> = {};
      const idMap: Record<string, string> = {};
      data?.forEach((row) => {
        map[row.section] = row.content_json ?? row.content ?? "";
        idMap[row.section] = row.id;
      });
      return { sections: map, sectionIds: idMap };
    },
    staleTime: 5 * 60 * 1000,
  });
}

export function useActivities() {
  return useQuery({
    queryKey: ["activities-public"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("activities")
        .select("id, name, slug, short_description, icon_name, image_url")
        .eq("is_active", true)
        .order("sort_order");
      if (error) throw error;
      return data ?? [];
    },
    staleTime: 5 * 60 * 1000,
  });
}

export function useServices() {
  return useQuery({
    queryKey: ["services"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("services")
        .select("id, name, description, category, duration_min, price, icon_name")
        .eq("is_active", true)
        .order("name");
      if (error) throw error;
      return data ?? [];
    },
    staleTime: 5 * 60 * 1000,
  });
}
