import { useEffect } from "react";
import i18n from "@/i18n/i18n";
import { supabase } from "@/integrations/supabase/client";

/**
 * Loads dynamic i18n overrides from the database and subscribes
 * to realtime changes so translations update instantly.
 */
export function useI18nOverrides() {
  useEffect(() => {
    // Load initial overrides
    const loadOverrides = async () => {
      const { data, error } = await supabase
        .from("i18n_overrides")
        .select("language, translations");

      if (error) {
        console.error("Failed to load i18n overrides:", error);
        return;
      }

      data?.forEach((row) => {
        if (row.translations && typeof row.translations === "object") {
          i18n.addResourceBundle(
            row.language,
            "translation",
            row.translations as Record<string, unknown>,
            true, // deep merge
            true  // overwrite existing
          );
        }
      });
    };

    loadOverrides();

    // Subscribe to realtime changes
    const channel = supabase
      .channel("i18n-overrides-realtime")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "i18n_overrides" },
        (payload) => {
          const record = payload.new as { language: string; translations: Record<string, unknown> } | undefined;
          if (record?.language && record?.translations) {
            i18n.addResourceBundle(
              record.language,
              "translation",
              record.translations,
              true,
              true
            );
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);
}
