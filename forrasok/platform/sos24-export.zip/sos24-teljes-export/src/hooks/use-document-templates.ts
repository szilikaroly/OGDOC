import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface TemplateField {
  key: string;
  label: string;
  source: string;
  visible: boolean;
  order: number;
}

export interface DocumentTemplate {
  id: string;
  document_type: string;
  name: string;
  fields: TemplateField[];
  is_active: boolean;
}

export function useDocumentTemplate(documentType: string) {
  return useQuery({
    queryKey: ["document-template", documentType],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("document_templates")
        .select("*")
        .eq("document_type", documentType)
        .eq("is_active", true)
        .single();
      if (error) return null;
      return {
        ...data,
        fields: (data.fields as unknown as TemplateField[]).sort((a, b) => a.order - b.order),
      } as DocumentTemplate;
    },
  });
}

export function useDocumentTemplates() {
  return useQuery({
    queryKey: ["document-templates"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("document_templates")
        .select("*")
        .order("document_type");
      if (error) throw error;
      return (data ?? []).map((d) => ({
        ...d,
        fields: (d.fields as unknown as TemplateField[]).sort((a, b) => a.order - b.order),
      })) as DocumentTemplate[];
    },
  });
}

export function isFieldVisible(template: DocumentTemplate | null | undefined, fieldKey: string): boolean {
  if (!template) return true; // default: show all if no template
  const field = template.fields.find((f) => f.key === fieldKey);
  return field ? field.visible : false;
}
