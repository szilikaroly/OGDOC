import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useLocation } from "react-router-dom";

const SUPPORTED_LANGS = ["hu", "en", "de", "ro", "sr", "zh", "fil"];

function injectJsonLd() {
  const existing = document.querySelector('script[data-jsonld="org"]');
  if (existing) return;

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": ["MedicalOrganization", "MedicalBusiness"],
    name: document.title || "Foglalkozás-egészségügyi szolgálat",
    url: window.location.origin,
    "@id": window.location.origin,
    medicalSpecialty: "OccupationalMedicine",
    description: "Foglalkozás-egészségügyi és üzemorvosi szolgáltatás. Munkaköri alkalmassági vizsgálat, előzetes és időszakos orvosi vizsgálatok.",
    telephone: "+36-62-000-000",
    address: {
      "@type": "PostalAddress",
      addressLocality: "Szeged",
      addressCountry: "HU",
    },
    availableService: {
      "@type": "MedicalProcedure",
      name: "Munkaköri alkalmassági vizsgálat",
      procedureType: "https://schema.org/DiagnosticProcedure",
    },
    sameAs: [],
  };

  const script = document.createElement("script");
  script.type = "application/ld+json";
  script.setAttribute("data-jsonld", "org");
  script.textContent = JSON.stringify(jsonLd);
  document.head.appendChild(script);
}

function injectFaqSchema(faqs: { question: string; answer: string }[]) {
  const existing = document.querySelector('script[data-jsonld="faq"]');
  if (existing) existing.remove();
  if (!faqs.length) return;

  const faqLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map(f => ({
      "@type": "Question",
      name: f.question,
      acceptedAnswer: {
        "@type": "Answer",
        text: f.answer,
      },
    })),
  };

  const script = document.createElement("script");
  script.type = "application/ld+json";
  script.setAttribute("data-jsonld", "faq");
  script.textContent = JSON.stringify(faqLd);
  document.head.appendChild(script);
}

function injectServicesSchema(services: { name: string; description?: string }[]) {
  const existing = document.querySelector('script[data-jsonld="services"]');
  if (existing) existing.remove();
  if (!services.length) return;

  const servicesLd = {
    "@context": "https://schema.org",
    "@type": "ItemList",
    name: "Szolgáltatásaink",
    itemListElement: services.map((s, i) => ({
      "@type": "ListItem",
      position: i + 1,
      item: {
        "@type": "MedicalProcedure",
        name: s.name,
        description: s.description || "",
      },
    })),
  };

  const script = document.createElement("script");
  script.type = "application/ld+json";
  script.setAttribute("data-jsonld", "services");
  script.textContent = JSON.stringify(servicesLd);
  document.head.appendChild(script);
}

function injectHreflang(pathname: string, languages: string[]) {
  // Remove old hreflang links
  document.querySelectorAll('link[data-hreflang]').forEach(el => el.remove());

  const origin = window.location.origin;

  // x-default -> Hungarian
  const xDefault = document.createElement("link");
  xDefault.rel = "alternate";
  xDefault.setAttribute("hreflang", "x-default");
  xDefault.href = `${origin}${pathname}`;
  xDefault.setAttribute("data-hreflang", "true");
  document.head.appendChild(xDefault);

  // Hungarian
  const hu = document.createElement("link");
  hu.rel = "alternate";
  hu.setAttribute("hreflang", "hu");
  hu.href = `${origin}${pathname}`;
  hu.setAttribute("data-hreflang", "true");
  document.head.appendChild(hu);

  // Other languages
  for (const lang of languages) {
    if (lang === "hu") continue;
    const link = document.createElement("link");
    link.rel = "alternate";
    link.setAttribute("hreflang", lang);
    link.href = `${origin}/${lang}${pathname}`;
    link.setAttribute("data-hreflang", "true");
    document.head.appendChild(link);
  }
}

function trackPageView(pathname: string) {
  try {
    // Debounce: don't track admin pages or rapid navigations
    if (pathname.startsWith("/admin")) return;

    (supabase as any)
      .from("page_views")
      .insert({
        page_path: pathname,
        referrer: document.referrer || null,
        user_agent: navigator.userAgent?.substring(0, 255) || null,
      })
      .then(() => {});
  } catch {
    // silently fail
  }
}

export function useSeo() {
  const { pathname } = useLocation();

  const { data: seo } = useQuery({
    queryKey: ["seo-page", pathname],
    queryFn: async () => {
      const { data } = await (supabase as any)
        .from("seo_pages")
        .select("*")
        .eq("page_path", pathname)
        .maybeSingle();
      return data;
    },
  });

  // Fetch services for Schema.org on landing page
  const { data: services } = useQuery({
    queryKey: ["seo-services-schema"],
    queryFn: async () => {
      const { data } = await supabase
        .from("services")
        .select("name")
        .eq("is_active", true)
        .order("sort_order");
      return data ?? [];
    },
    enabled: pathname === "/",
  });

  // Fetch available translations for hreflang
  const { data: availableLanguages } = useQuery({
    queryKey: ["seo-hreflang", seo?.id],
    queryFn: async () => {
      if (!seo?.id) return ["hu"];
      const { data } = await supabase
        .from("content_translations")
        .select("language")
        .eq("table_name", "seo_pages")
        .eq("record_id", seo.id);
      const langs = new Set(["hu"]);
      data?.forEach((d: any) => {
        if (SUPPORTED_LANGS.includes(d.language)) langs.add(d.language);
      });
      return Array.from(langs);
    },
    enabled: !!seo?.id,
  });

  // Track page view on navigation
  useEffect(() => {
    trackPageView(pathname);
  }, [pathname]);

  useEffect(() => {
    if (pathname === "/") {
      injectJsonLd();

      // Inject services schema
      if (services?.length) {
        injectServicesSchema(
          services.map(s => ({ name: s.name }))
        );
      }

      // Inject FAQ schema with common questions
      injectFaqSchema([
        { question: "Mi az a munkaköri alkalmassági vizsgálat?", answer: "A munkaköri alkalmassági vizsgálat megállapítja, hogy a munkavállaló egészségi állapota alkalmas-e az adott munkakör betöltésére." },
        { question: "Milyen gyakran kell üzemorvosi vizsgálatra menni?", answer: "Az üzemorvosi vizsgálat gyakorisága a munkakör kockázati besorolásától függ, általában évente vagy kétévente szükséges." },
        { question: "Hogyan tudok időpontot foglalni?", answer: "Időpontfoglalás online a weboldalon keresztül, telefonon vagy e-mailben lehetséges." },
        { question: "Milyen dokumentumokat kell vinni a vizsgálatra?", answer: "A vizsgálatra a munkáltató által kiállított beutalót, személyi igazolványt és TAJ kártyát szükséges vinni." },
        { question: "Milyen nyelveken érhető el a szolgáltatás?", answer: "Szolgáltatásaink magyar, angol, német, román, szerb, kínai és filippínó nyelven érhetők el." },
      ]);
    }

    // Inject hreflang tags
    if (availableLanguages && availableLanguages.length > 1) {
      injectHreflang(pathname, availableLanguages);
    }

    if (!seo) return;

    if (seo.title) document.title = seo.title;

    const setMeta = (name: string, content: string | null, property = false) => {
      if (!content) return;
      const attr = property ? "property" : "name";
      let el = document.querySelector(`meta[${attr}="${name}"]`) as HTMLMetaElement | null;
      if (!el) {
        el = document.createElement("meta");
        el.setAttribute(attr, name);
        document.head.appendChild(el);
      }
      el.content = content;
    };

    setMeta("description", seo.description);
    setMeta("keywords", seo.keywords);
    setMeta("og:title", seo.og_title, true);
    setMeta("og:description", seo.og_description, true);
    setMeta("og:image", seo.og_image, true);

    if (seo.canonical_url) {
      let link = document.querySelector('link[rel="canonical"]') as HTMLLinkElement | null;
      if (!link) {
        link = document.createElement("link");
        link.rel = "canonical";
        document.head.appendChild(link);
      }
      link.href = seo.canonical_url;
    }

    if (seo.noindex) {
      setMeta("robots", "noindex, nofollow");
    }
  }, [seo, pathname, services, availableLanguages]);
}
