import { useEffect } from "react";
import { useSiteSettings } from "@/hooks/use-cms";

export function useThemeFromCMS() {
  const { data: s } = useSiteSettings();

  useEffect(() => {
    if (!s) return;
    const root = document.documentElement;

    const ph = s.theme_primary_hue;
    const ps = s.theme_primary_saturation;
    const pl = s.theme_primary_lightness;
    if (ph && ps && pl) {
      // Regenerate full navy scale from primary HSL
      const h = Number(ph), sat = Number(ps), l = Number(pl);
      root.style.setProperty("--navy-950", `${h} ${sat + 5}% ${Math.max(l - 4, 4)}%`);
      root.style.setProperty("--navy-900", `${h} ${sat}% ${l}%`);
      root.style.setProperty("--navy-800", `${h} ${sat - 5}% ${l + 5}%`);
      root.style.setProperty("--navy-700", `${h} ${sat - 10}% ${l + 12}%`);
      root.style.setProperty("--navy-600", `${h} ${sat - 15}% ${l + 20}%`);
      root.style.setProperty("--navy-500", `${h} ${sat - 20}% ${l + 30}%`);
      root.style.setProperty("--navy-400", `${h} ${sat - 25}% ${l + 45}%`);
      root.style.setProperty("--navy-300", `${h} ${sat - 30}% ${l + 60}%`);
      root.style.setProperty("--navy-200", `${h} ${sat - 35}% ${l + 73}%`);
      root.style.setProperty("--navy-100", `${h} ${sat - 37}% ${l + 83}%`);
      root.style.setProperty("--navy-50", `${h} ${sat - 40}% ${l + 87}%`);
    }

    const ah = s.theme_accent_hue;
    const as = s.theme_accent_saturation;
    const al = s.theme_accent_lightness;
    if (ah && as && al) {
      const h = Number(ah), sat = Number(as), l = Number(al);
      root.style.setProperty("--gold-500", `${h} ${sat}% ${l}%`);
      root.style.setProperty("--gold-600", `${h} ${sat - 2}% ${l - 7}%`);
      root.style.setProperty("--gold-700", `${h} ${sat - 0}% ${l - 15}%`);
      root.style.setProperty("--gold-800", `${h} ${sat + 5}% ${l - 23}%`);
      root.style.setProperty("--gold-900", `${h} ${sat + 10}% ${l - 30}%`);
      root.style.setProperty("--gold-400", `${h} ${sat + 2}% ${l + 9}%`);
      root.style.setProperty("--gold-300", `${h} ${sat + 4}% ${l + 19}%`);
      root.style.setProperty("--gold-200", `${h} ${sat}% ${l + 29}%`);
      root.style.setProperty("--gold-100", `${h} ${sat - 10}% ${l + 38}%`);
      root.style.setProperty("--gold-50", `${h} ${sat - 20}% ${l + 42}%`);
    }

    if (s.theme_hero_gradient) {
      root.style.setProperty("--gradient-hero", s.theme_hero_gradient);
    }

    if (s.theme_font_display) {
      root.style.setProperty("--font-display", `'${s.theme_font_display}', Georgia, serif`);
    }
    if (s.theme_font_body) {
      root.style.setProperty("--font-body", `'${s.theme_font_body}', system-ui, sans-serif`);
    }
  }, [s]);
}
