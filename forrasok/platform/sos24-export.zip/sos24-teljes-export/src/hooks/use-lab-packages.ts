import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface LabPackage {
  id: string;
  name: string;
  description: string | null;
  target_audience: string | null;
  icon: string;
  test_ids: string[];
  is_active: boolean;
  display_order: number;
}

export function useLabPackages() {
  return useQuery({
    queryKey: ['lab-packages'],
    queryFn: async () => {
      const { data, error } = await (supabase as any)
        .from('lab_packages')
        .select('*')
        .eq('is_active', true)
        .order('display_order', { ascending: true });
      if (error) throw error;
      return (data ?? []) as LabPackage[];
    },
  });
}
