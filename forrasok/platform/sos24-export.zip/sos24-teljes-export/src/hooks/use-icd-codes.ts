import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type IcdVersion = "icd10" | "icd11";

export interface IcdCode {
  id: string;
  code: string;
  version: IcdVersion;
  label_hu: string;
  label_en: string | null;
  parent_code: string | null;
  level: number;
  synonyms: string[];
  category: string | null;
  is_active: boolean;
}

export function useIcdCodes(query: string, version: IcdVersion = "icd10", limit = 20, enabled = true) {
  return useQuery({
    queryKey: ["icd-codes", query.trim().toLowerCase(), version, limit],
    queryFn: async () => {
      const q = query.trim();
      if (!q) return [];
      const { data, error } = await supabase.rpc("search_icd_codes", {
        _query: q,
        _version: version,
        _limit: limit,
      });
      if (error) throw error;
      return (data ?? []) as IcdCode[];
    },
    enabled: enabled && query.trim().length > 0,
    staleTime: 5 * 60 * 1000,
  });
}

export function useIcdCodeByCode(code: string | null | undefined, version: IcdVersion = "icd10") {
  return useQuery({
    queryKey: ["icd-code-by-code", code, version],
    queryFn: async () => {
      if (!code) return null;
      const { data, error } = await supabase
        .from("icd_codes")
        .select("id, code, version, label_hu, label_en, parent_code, level, synonyms, category, is_active")
        .eq("code", code)
        .eq("version", version)
        .eq("is_active", true)
        .single();
      if (error) return null;
      return data as IcdCode | null;
    },
    enabled: !!code,
    staleTime: 10 * 60 * 1000,
  });
}
