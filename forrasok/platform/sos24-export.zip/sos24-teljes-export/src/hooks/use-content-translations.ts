import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";
import { supabase } from "@/integrations/supabase/client";

interface ContentTranslation {
  record_id: string;
  field_name: string;
  value: string;
}

/**
 * Fetches content translations for a specific table and the current language.
 * Falls back to the original value if no translation is found.
 * Subscribes to realtime changes for instant updates.
 */
export function useContentTranslations(tableName: string) {
  const { i18n } = useTranslation();
  const lang = i18n.language;

  const queryKey = ["content-translations", tableName, lang];

  const { data: translations } = useQuery({
    queryKey,
    queryFn: async () => {
      // Don't fetch for Hungarian (base language)
      if (lang === "hu") return [];
      const { data, error } = await supabase
        .from("content_translations")
        .select("record_id, field_name, value")
        .eq("table_name", tableName)
        .eq("language", lang);
      if (error) throw error;
      return (data ?? []) as ContentTranslation[];
    },
    staleTime: 5 * 60 * 1000,
  });


  // Build a lookup map: `${record_id}::${field_name}` -> value
  const translationMap = useMemo(() => {
    const map = new Map<string, string>();
    translations?.forEach((t) => {
      map.set(`${t.record_id}::${t.field_name}`, t.value);
    });
    return map;
  }, [translations]);

  /**
   * Get translated value for a record field, falling back to original.
   */
  function ct(recordId: string, fieldName: string, originalValue: string | null | undefined): string {
    if (lang === "hu" || !originalValue) return originalValue ?? "";
    return translationMap.get(`${recordId}::${fieldName}`) ?? originalValue;
  }

  return { ct, translationMap };
}

/**
 * Hook for translating site_settings which use `key` as identifier instead of `id`.
 * Stores translations with record_id = MD5-like deterministic UUID from the key string.
 * We use the key directly as record_id field in content_translations for site_settings.
 */
export function useSiteSettingsTranslations() {
  const { i18n } = useTranslation();
  const lang = i18n.language;
  

  const queryKey = ["content-translations", "site_settings", lang];

  const { data: translations } = useQuery({
    queryKey,
    queryFn: async () => {
      if (lang === "hu") return [];
      const { data, error } = await supabase
        .from("content_translations")
        .select("record_id, field_name, value")
        .eq("table_name", "site_settings")
        .eq("language", lang);
      if (error) throw error;
      return (data ?? []) as ContentTranslation[];
    },
    staleTime: 5 * 60 * 1000,
  });


  // For site_settings, record_id stores the setting's DB id, field_name = "value"
  const translationMap = useMemo(() => {
    const map = new Map<string, string>();
    translations?.forEach((t) => {
      map.set(t.record_id, t.value);
    });
    return map;
  }, [translations]);

  /**
   * Get translated setting value. settingId = the UUID of the site_settings row.
   */
  function ctSetting(settingId: string, originalValue: string | null | undefined): string {
    if (lang === "hu" || !originalValue) return originalValue ?? "";
    return translationMap.get(settingId) ?? originalValue;
  }

  return { ctSetting, translationMap };
}
