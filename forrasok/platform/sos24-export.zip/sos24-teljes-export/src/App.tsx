import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/contexts/AuthContext";
import { useThemeFromCMS } from "@/hooks/use-theme-from-cms";
import { useI18nOverrides } from "@/hooks/use-i18n-overrides";
import ProtectedRoute from "@/components/ProtectedRoute";
import MessagesPage from "@/components/MessagesPage";

import Index from "./pages/Index";
import Login from "./pages/Login";
import Register from "./pages/Register";
import ResetPassword from "./pages/ResetPassword";
import NotFound from "./pages/NotFound";
import Unsubscribe from "./pages/Unsubscribe";
import EmailUnsubscribe from "./pages/EmailUnsubscribe";
import CookieBanner from "./components/CookieBanner";
import ChatBot from "./components/ChatBot";
import ActivityPage from "./pages/ActivityPage";
import ActivitiesListPage from "./pages/ActivitiesListPage";

// Admin
import AdminLayout from "./pages/admin/AdminLayout";
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminUsers from "./pages/admin/AdminUsers";
import AdminServices from "./pages/admin/AdminServices";
import AdminLocations from "./pages/admin/AdminLocations";
import AdminCMS from "./pages/admin/AdminCMS";
import AdminNavigation from "./pages/admin/AdminNavigation";
import AdminSEO from "./pages/admin/AdminSEO";
import AdminSettings from "./pages/admin/AdminSettings";
import AdminSlots from "./pages/admin/AdminSlots";
import AdminCompanies from "./pages/admin/AdminCompanies";
import AdminExaminations from "./pages/admin/AdminExaminations";
import AdminAuditLog from "./pages/admin/AdminAuditLog";
import AdminDocumentTags from "./pages/admin/AdminDocumentTags";
import AdminGdpr from "./pages/admin/AdminGdpr";
import AdminEmailTemplates from "./pages/admin/AdminEmailTemplates";
import AdminTranslate from "./pages/admin/AdminTranslate";
import AdminActivities from "./pages/admin/AdminActivities";
import AdminDocumentTemplates from "./pages/admin/AdminDocumentTemplates";
import AdminRiskAssessments from "./pages/admin/AdminRiskAssessments";
import AdminSubstances from "./pages/admin/AdminSubstances";
import AdminMarketing from "./pages/admin/AdminMarketing";
import AdminLabShop from "./pages/admin/AdminLabShop";
import AdminSecurityEvents from "./pages/admin/AdminSecurityEvents";
import AdminIcdCodes from "./pages/admin/AdminIcdCodes";
import LabShop from "./pages/LabShop";

// Háziorvos
import HaziorvosLayout from "./pages/haziorvos/HaziorvosLayout";
import HaziorvosDashboard from "./pages/haziorvos/HaziorvosDashboard";
import HaziorvosPatients from "./pages/haziorvos/HaziorvosPatients";
import HaziorvosAppointments from "./pages/haziorvos/HaziorvosAppointments";
import HaziorvosRequests from "./pages/haziorvos/HaziorvosRequests";
import HaziorvosQuestionnaires from "./pages/haziorvos/HaziorvosQuestionnaires";
import HaziorvosDocuments from "./pages/haziorvos/HaziorvosDocuments";
import DoctorVaccinations from "./components/DoctorVaccinations";
import DoctorCertificates from "./components/DoctorCertificates";

// Üzemorvos
import UzemorvosLayout from "./pages/uzemorvos/UzemorvosLayout";
import UzemorvosDashboard from "./pages/uzemorvos/UzemorvosDashboard";
import UzemorvosExaminations from "./pages/uzemorvos/UzemorvosExaminations";
import UzemorvosAppointments from "./pages/uzemorvos/UzemorvosAppointments";
import UzemorvosEmployees from "./pages/uzemorvos/UzemorvosEmployees";
import UzemorvosCompanies from "./pages/uzemorvos/UzemorvosCompanies";
import UzemorvosReferrals from "./pages/uzemorvos/UzemorvosReferrals";
import UzemorvosOpinions from "./pages/uzemorvos/UzemorvosOpinions";
import UzemorvosQuestionnaires from "./pages/uzemorvos/UzemorvosQuestionnaires";
import UzemorvosDocuments from "./pages/uzemorvos/UzemorvosDocuments";
import UzemorvosStatistics from "./pages/uzemorvos/UzemorvosStatistics";
import UzemorvosRiskAssessments from "./pages/uzemorvos/UzemorvosRiskAssessments";

// Munkáltató
import MunkaltatoLayout from "./pages/munkaltato/MunkaltatoLayout";
import MunkaltatoDashboard from "./pages/munkaltato/MunkaltatoDashboard";
import MunkaltatoEmployees from "./pages/munkaltato/MunkaltatoEmployees";
import MunkaltatoCompany from "./pages/munkaltato/MunkaltatoCompany";
import MunkaltatoReferrals from "./pages/munkaltato/MunkaltatoReferrals";
import MunkaltatoOpinions from "./pages/munkaltato/MunkaltatoOpinions";
import MunkaltatoDocuments from "./pages/munkaltato/MunkaltatoDocuments";
import MunkaltatoReports from "./pages/munkaltato/MunkaltatoReports";
import MunkaltatoRiskAssessments from "./pages/munkaltato/MunkaltatoRiskAssessments";
import MunkaltatoAccidents from "./pages/munkaltato/MunkaltatoAccidents";

// Munkavállaló
import MunkavallaloLayout from "./pages/munkavallalo/MunkavallaloLayout";
import MunkavallatoDashboard from "./pages/munkavallalo/MunkavallatoDashboard";
import MunkavallaloAppointments from "./pages/munkavallalo/MunkavallaloAppointments";
import MunkavallaloHealth from "./pages/munkavallalo/MunkavallaloHealth";
import MunkavallaloJournal from "./pages/munkavallalo/MunkavallaloJournal";
import MunkavallaloVaccinations from "./pages/munkavallalo/MunkavallaloVaccinations";
import MunkavallaloOpinions from "./pages/munkavallalo/MunkavallaloOpinions";
import MunkavallaloQuestionnaires from "./pages/munkavallalo/MunkavallaloQuestionnaires";
import MunkavallaloDocuments from "./pages/munkavallalo/MunkavallaloDocuments";
import MunkavallaloDataAccess from "./pages/munkavallalo/MunkavallaloDataAccess";
import MunkavallaloSettings from "./pages/munkavallalo/MunkavallaloSettings";
import MunkavallaloGdpr from "./pages/munkavallalo/MunkavallaloGdpr";
import MunkavallaloProfile from "./pages/munkavallalo/MunkavallaloProfile";
import MunkavallaloAccidents from "./pages/munkavallalo/MunkavallaloAccidents";

// Praxistag
import PraxistagLayout from "./pages/praxistag/PraxistagLayout";
import PraxistagDashboard from "./pages/praxistag/PraxistagDashboard";
import PraxistagAppointments from "./pages/praxistag/PraxistagAppointments";
import PraxistagHealth from "./pages/praxistag/PraxistagHealth";
import PraxistagDocuments from "./pages/praxistag/PraxistagDocuments";
import PraxistagMedications from "./pages/praxistag/PraxistagMedications";
import PraxistagReferralRequest from "./pages/praxistag/PraxistagReferralRequest";
import PraxistagProfile from "./pages/praxistag/PraxistagProfile";
import HealthPlanPage from "./pages/shared/HealthPlanPage";
import DoctorPatientHealthPlans from "./components/DoctorPatientHealthPlans";

// Háziorvos extra
import HaziorvosMedRequests from "./pages/haziorvos/HaziorvosMedRequests";
import LabRequestBuilder from "./components/LabRequestBuilder";

const queryClient = new QueryClient();

function ThemeProvider({ children }: { children: React.ReactNode }) {
  useThemeFromCMS();
  return <>{children}</>;
}

function I18nLoader({ children }: { children: React.ReactNode }) {
  useI18nOverrides();
  return <>{children}</>;
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <TooltipProvider>
        <ThemeProvider>
        <I18nLoader>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              {/* Public */}
              <Route path="/" element={<Index />} />
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              <Route path="/reset-password" element={<ResetPassword />} />
              <Route path="/unsubscribe" element={<Unsubscribe />} />
              <Route path="/email-unsubscribe" element={<EmailUnsubscribe />} />
              <Route path="/tevekenysegeink" element={<ActivitiesListPage />} />
              <Route path="/tevekenyseg/:slug" element={<ActivityPage />} />
              <Route path="/labor" element={<LabShop />} />

              {/* Admin */}
              <Route path="/admin" element={<ProtectedRoute allowedRoles={["super_admin"]}><AdminLayout /></ProtectedRoute>}>
                <Route index element={<AdminDashboard />} />
                <Route path="users" element={<AdminUsers />} />
                <Route path="companies" element={<AdminCompanies />} />
                <Route path="examinations" element={<AdminExaminations />} />
                <Route path="services" element={<AdminServices />} />
                <Route path="locations" element={<AdminLocations />} />
                <Route path="slots" element={<AdminSlots />} />
                <Route path="cms" element={<AdminCMS />} />
                <Route path="navigation" element={<AdminNavigation />} />
                <Route path="seo" element={<AdminSEO />} />
                <Route path="translate" element={<AdminTranslate />} />
                <Route path="activities" element={<AdminActivities />} />
                <Route path="messages" element={<MessagesPage />} />
                <Route path="document-tags" element={<AdminDocumentTags />} />
                <Route path="email-templates" element={<AdminEmailTemplates />} />
                <Route path="audit-log" element={<AdminAuditLog />} />
                <Route path="security-events" element={<AdminSecurityEvents />} />
                <Route path="settings" element={<AdminSettings />} />
                <Route path="document-templates" element={<AdminDocumentTemplates />} />
                <Route path="risk-assessments" element={<AdminRiskAssessments />} />
                <Route path="substances" element={<AdminSubstances />} />
                <Route path="marketing" element={<AdminMarketing />} />
                <Route path="lab-shop" element={<AdminLabShop />} />
                <Route path="icd-codes" element={<AdminIcdCodes />} />
                <Route path="gdpr" element={<AdminGdpr />} />
              </Route>

              {/* Háziorvos */}
              <Route path="/haziorvos" element={<ProtectedRoute allowedRoles={["haziorvos", "super_admin"]}><HaziorvosLayout /></ProtectedRoute>}>
                <Route index element={<HaziorvosDashboard />} />
                <Route path="patients" element={<HaziorvosPatients />} />
                <Route path="appointments" element={<HaziorvosAppointments />} />
                <Route path="med-requests" element={<HaziorvosMedRequests />} />
                <Route path="requests" element={<HaziorvosRequests />} />
                <Route path="questionnaires" element={<HaziorvosQuestionnaires />} />
                <Route path="documents" element={<HaziorvosDocuments />} />
                <Route path="vaccinations" element={<DoctorVaccinations />} />
                <Route path="certificates" element={<DoctorCertificates />} />
                <Route path="health-plans" element={<DoctorPatientHealthPlans />} />
                <Route path="lab-requests" element={<LabRequestBuilder />} />
                <Route path="messages" element={<MessagesPage />} />
              </Route>

              {/* Üzemorvos */}
              <Route path="/uzemorvos" element={<ProtectedRoute allowedRoles={["uzemorvos", "super_admin"]}><UzemorvosLayout /></ProtectedRoute>}>
                <Route index element={<UzemorvosDashboard />} />
                <Route path="examinations" element={<UzemorvosExaminations />} />
                <Route path="appointments" element={<UzemorvosAppointments />} />
                <Route path="employees" element={<UzemorvosEmployees />} />
                <Route path="companies" element={<UzemorvosCompanies />} />
                <Route path="referrals" element={<UzemorvosReferrals />} />
                <Route path="opinions" element={<UzemorvosOpinions />} />
                <Route path="certificates" element={<DoctorCertificates />} />
                <Route path="questionnaires" element={<UzemorvosQuestionnaires />} />
                <Route path="documents" element={<UzemorvosDocuments />} />
                <Route path="vaccinations" element={<DoctorVaccinations />} />
                <Route path="statistics" element={<UzemorvosStatistics />} />
                <Route path="health-plans" element={<DoctorPatientHealthPlans />} />
                <Route path="risk-assessments" element={<UzemorvosRiskAssessments />} />
                <Route path="lab-requests" element={<LabRequestBuilder />} />
                <Route path="messages" element={<MessagesPage />} />
              </Route>

              {/* Munkáltató */}
              <Route path="/munkaltato" element={<ProtectedRoute allowedRoles={["munkaltato", "super_admin"]}><MunkaltatoLayout /></ProtectedRoute>}>
                <Route index element={<MunkaltatoDashboard />} />
                <Route path="employees" element={<MunkaltatoEmployees />} />
                <Route path="company" element={<MunkaltatoCompany />} />
                <Route path="referrals" element={<MunkaltatoReferrals />} />
                <Route path="opinions" element={<MunkaltatoOpinions />} />
                <Route path="documents" element={<MunkaltatoDocuments />} />
                <Route path="reports" element={<MunkaltatoReports />} />
                <Route path="risk-assessments" element={<MunkaltatoRiskAssessments />} />
                <Route path="accidents" element={<MunkaltatoAccidents />} />
                <Route path="messages" element={<MessagesPage />} />
              </Route>

              {/* Munkavállaló */}
              <Route path="/munkavallalo" element={<ProtectedRoute allowedRoles={["munkavallalo", "super_admin"]}><MunkavallaloLayout /></ProtectedRoute>}>
                <Route index element={<MunkavallatoDashboard />} />
                <Route path="profile" element={<MunkavallaloProfile />} />
                <Route path="appointments" element={<MunkavallaloAppointments />} />
                <Route path="health" element={<MunkavallaloHealth />} />
                <Route path="journal" element={<MunkavallaloJournal />} />
                <Route path="vaccinations" element={<MunkavallaloVaccinations />} />
                <Route path="opinions" element={<MunkavallaloOpinions />} />
                <Route path="questionnaires" element={<MunkavallaloQuestionnaires />} />
                <Route path="health-plan" element={<HealthPlanPage />} />
                <Route path="documents" element={<MunkavallaloDocuments />} />
                <Route path="data-access" element={<MunkavallaloDataAccess />} />
                <Route path="accidents" element={<MunkavallaloAccidents />} />
                <Route path="labor" element={<LabShop />} />
                <Route path="settings" element={<MunkavallaloSettings />} />
                <Route path="gdpr" element={<MunkavallaloGdpr />} />
                <Route path="messages" element={<MessagesPage />} />
              </Route>

              {/* Praxistag */}
              <Route path="/praxistag" element={<ProtectedRoute allowedRoles={["praxistag", "super_admin"]}><PraxistagLayout /></ProtectedRoute>}>
                <Route index element={<PraxistagDashboard />} />
                <Route path="profile" element={<PraxistagProfile />} />
                <Route path="appointments" element={<PraxistagAppointments />} />
                <Route path="health" element={<PraxistagHealth />} />
                <Route path="journal" element={<MunkavallaloJournal />} />
                <Route path="medications" element={<PraxistagMedications />} />
                <Route path="referral-request" element={<PraxistagReferralRequest />} />
                <Route path="documents" element={<PraxistagDocuments />} />
                <Route path="questionnaires" element={<MunkavallaloQuestionnaires />} />
                <Route path="labor" element={<LabShop />} />
                <Route path="health-plan" element={<HealthPlanPage />} />
                <Route path="messages" element={<MessagesPage />} />
              </Route>

              <Route path="*" element={<NotFound />} />
            </Routes>
            <CookieBanner />
            <ChatBot />
          </BrowserRouter>
        </I18nLoader>
        </ThemeProvider>
      </TooltipProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
