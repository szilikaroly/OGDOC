import i18n from "i18next";
import { initReactI18next } from "react-i18next";
import LanguageDetector from "i18next-browser-languagedetector";
import hu from "./hu.json";
import en from "./en.json";
import de from "./de.json";
import ro from "./ro.json";
import sr from "./sr.json";
import zh from "./zh.json";
import fil from "./fil.json";

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources: {
      hu: { translation: hu },
      en: { translation: en },
      de: { translation: de },
      ro: { translation: ro },
      sr: { translation: sr },
      zh: { translation: zh },
      fil: { translation: fil },
    },
    fallbackLng: "hu",
    interpolation: { escapeValue: false },
    detection: {
      order: ["localStorage", "navigator"],
      caches: ["localStorage"],
    },
  });

export default i18n;
