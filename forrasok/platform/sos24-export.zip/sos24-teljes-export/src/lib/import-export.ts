import * as XLSX from "xlsx";

export type ImportRowStatus = "pending" | "success" | "error" | "duplicate";

export interface ImportLogRow {
  full_name?: string;
  email?: string;
  taj_number?: string;
  birth_date?: string;
  birth_place?: string;
  birth_name?: string;
  mother_name?: string;
  phone?: string;
  address?: string;
  gender?: string;
  position?: string;
  feor_code?: string;
  feor_name?: string;
  site_name?: string;
  workplace_name?: string;
  status: ImportRowStatus;
  error?: string;
  /** Mi okozta az érvénytelenítést vagy duplum jelölést. */
  reason_category?: "validation" | "duplicate" | "system" | "ok";
  reason_detail?: string;
}

const statusLabel = (s: ImportRowStatus) =>
  s === "success" ? "Sikeres" : s === "duplicate" ? "Duplum" : s === "error" ? "Hiba" : "Várakozik";

export function exportImportLog(rows: ImportLogRow[], fileName = "import_eredmeny") {
  const wb = XLSX.utils.book_new();
  const data = [
    ["Név", "Email", "TAJ", "Szül. dátum", "Munkakör", "FEOR", "Státusz", "Hiba/Megjegyzés"],
    ...rows.map((r) => [
      r.full_name || "",
      r.email || "",
      r.taj_number || "",
      r.birth_date || "",
      r.position || "",
      r.feor_code || "",
      statusLabel(r.status),
      r.error || "",
    ]),
  ];
  const ws = XLSX.utils.aoa_to_sheet(data);
  XLSX.utils.book_append_sheet(wb, ws, "Eredmény");
  const safe = fileName.replace(/[^\w.-]+/g, "_");
  XLSX.writeFile(wb, `${safe}_${new Date().toISOString().slice(0, 10)}.xlsx`);
}
