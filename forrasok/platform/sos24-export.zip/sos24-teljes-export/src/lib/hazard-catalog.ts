export type HazardCategoryKey =
  | "physical"
  | "chemical"
  | "biological"
  | "ergonomic"
  | "psychosocial"
  | "equipment"
  | "environment"
  | "fire"
  | "other";

export interface HazardItem {
  id: string;
  category: HazardCategoryKey;
  subcategory: string;
  name_hu: string;
  name_en: string;
  default_severity: 1 | 2 | 3 | 4;
  monitoring?: string;
  ppe?: string;
}

export const HAZARD_CATEGORIES: Record<HazardCategoryKey, { hu: string; en: string; icon: string }> = {
  physical: { hu: "Fizikai tényezők", en: "Physical Hazards", icon: "Zap" },
  chemical: { hu: "Kémiai tényezők", en: "Chemical Hazards", icon: "FlaskConical" },
  biological: { hu: "Biológiai tényezők", en: "Biological Hazards", icon: "Bug" },
  ergonomic: { hu: "Ergonómiai tényezők", en: "Ergonomic Hazards", icon: "PersonStanding" },
  psychosocial: { hu: "Pszichoszociális tényezők", en: "Psychosocial Hazards", icon: "Brain" },
  equipment: { hu: "Munkaeszközök veszélyei", en: "Equipment Hazards", icon: "Wrench" },
  environment: { hu: "Munkakörnyezet veszélyei", en: "Work Environment Hazards", icon: "Construction" },
  fire: { hu: "Tűz- és robbanásveszély", en: "Fire & Explosion Hazards", icon: "Flame" },
  other: { hu: "Egyéb veszélyek", en: "Other Hazards", icon: "AlertTriangle" },
};

export const HAZARD_CATALOG: HazardItem[] = [
  // ---- FIZIKAI ----
  { id: "phy-01", category: "physical", subcategory: "noise", name_hu: "Zaj (folyamatos)", name_en: "Continuous noise", default_severity: 3, monitoring: "Zajszintmérés", ppe: "Hallásvédő" },
  { id: "phy-02", category: "physical", subcategory: "noise", name_hu: "Zaj (impulzus jellegű)", name_en: "Impulse noise", default_severity: 3, monitoring: "Zajszintmérés", ppe: "Hallásvédő" },
  { id: "phy-03", category: "physical", subcategory: "vibration", name_hu: "Rezgés (kéz-kar)", name_en: "Hand-arm vibration", default_severity: 3, monitoring: "Rezgésmérés", ppe: "Rezgéscsillapító kesztyű" },
  { id: "phy-04", category: "physical", subcategory: "vibration", name_hu: "Rezgés (egésztest)", name_en: "Whole-body vibration", default_severity: 3, monitoring: "Rezgésmérés", ppe: "Rezgéscsillapító ülés" },
  { id: "phy-05", category: "physical", subcategory: "lighting", name_hu: "Elégtelen megvilágítás", name_en: "Insufficient lighting", default_severity: 2, monitoring: "Fényerősség mérés" },
  { id: "phy-06", category: "physical", subcategory: "lighting", name_hu: "Káprázás / villogás", name_en: "Glare / flickering", default_severity: 2, monitoring: "Fényerősség mérés" },
  { id: "phy-07", category: "physical", subcategory: "electrical", name_hu: "Elektromos áramütés veszélye", name_en: "Electrical shock hazard", default_severity: 4, monitoring: "Érintésvédelmi felülvizsgálat", ppe: "Szigetelő kesztyű" },
  { id: "phy-08", category: "physical", subcategory: "thermal", name_hu: "Hőterhelés (meleg)", name_en: "Heat stress", default_severity: 3, monitoring: "Hőmérséklet / WBGT mérés", ppe: "Hőálló ruházat" },
  { id: "phy-09", category: "physical", subcategory: "thermal", name_hu: "Hideg terhelés", name_en: "Cold stress", default_severity: 2, monitoring: "Hőmérséklet mérés", ppe: "Hőszigetelő ruházat" },
  { id: "phy-10", category: "physical", subcategory: "radiation", name_hu: "Ionizáló sugárzás", name_en: "Ionizing radiation", default_severity: 4, monitoring: "Dozimetria", ppe: "Ólomkötény" },
  { id: "phy-11", category: "physical", subcategory: "radiation", name_hu: "Nem ionizáló sugárzás (UV, IR, lézer)", name_en: "Non-ionizing radiation", default_severity: 3, monitoring: "Sugárzásmérés", ppe: "Védőszemüveg" },
  { id: "phy-12", category: "physical", subcategory: "pressure", name_hu: "Túlnyomás / alulnyomás", name_en: "Pressure hazards", default_severity: 3 },
  { id: "phy-13", category: "physical", subcategory: "humidity", name_hu: "Páratartalom (túl magas/alacsony)", name_en: "Humidity extremes", default_severity: 2, monitoring: "Páratartalom mérés" },

  // ---- KÉMIAI ----
  { id: "che-01", category: "chemical", subcategory: "dust", name_hu: "Porok (szemcsés anyagok)", name_en: "Dusts (particulate matter)", default_severity: 3, monitoring: "Porkoncentráció mérés", ppe: "FFP2/FFP3 maszk" },
  { id: "che-02", category: "chemical", subcategory: "dust", name_hu: "Azbeszt szálak", name_en: "Asbestos fibers", default_severity: 4, monitoring: "Szálszám mérés", ppe: "Teljes testet fedő védőruha + légzésvédő" },
  { id: "che-03", category: "chemical", subcategory: "gas", name_hu: "Mérgező gázok (CO, H₂S, NH₃)", name_en: "Toxic gases", default_severity: 4, monitoring: "Gázkoncentráció mérés", ppe: "Légzésvédő készülék" },
  { id: "che-04", category: "chemical", subcategory: "gas", name_hu: "Oxigénhiányos légkör", name_en: "Oxygen-deficient atmosphere", default_severity: 4, monitoring: "O₂ szintmérés", ppe: "Független légzésvédő" },
  { id: "che-05", category: "chemical", subcategory: "vapor", name_hu: "Szerves oldószer gőzök", name_en: "Organic solvent vapors", default_severity: 3, monitoring: "Légszennyezettség mérés", ppe: "Aktívszenes maszk" },
  { id: "che-06", category: "chemical", subcategory: "liquid", name_hu: "Savas/lúgos oldatok", name_en: "Acidic/alkaline solutions", default_severity: 3, monitoring: "pH mérés", ppe: "Saválló kesztyű, védőszemüveg" },
  { id: "che-07", category: "chemical", subcategory: "liquid", name_hu: "Korrozív anyagok", name_en: "Corrosive substances", default_severity: 3, ppe: "Vegyi védőruha" },
  { id: "che-08", category: "chemical", subcategory: "heavy_metal", name_hu: "Nehézfémek (ólom, higany, kadmium)", name_en: "Heavy metals (Pb, Hg, Cd)", default_severity: 4, monitoring: "Biológiai monitoring" },
  { id: "che-09", category: "chemical", subcategory: "carcinogen", name_hu: "Rákkeltő anyagok (SVHC lista)", name_en: "Carcinogenic substances (SVHC)", default_severity: 4, monitoring: "Expozíció monitoring" },
  { id: "che-10", category: "chemical", subcategory: "sensitizer", name_hu: "Szenzibilizáló / allergén anyagok", name_en: "Sensitizing / allergenic substances", default_severity: 2, monitoring: "Allergia szűrés" },
  { id: "che-11", category: "chemical", subcategory: "pesticide", name_hu: "Növényvédő szerek", name_en: "Pesticides", default_severity: 3, monitoring: "Kolinészteráz szint", ppe: "Teljes védőfelszerelés" },
  { id: "che-12", category: "chemical", subcategory: "isocyanate", name_hu: "Izocianátok", name_en: "Isocyanates", default_severity: 3, monitoring: "Spirometria", ppe: "Légzésvédő" },
  { id: "che-13", category: "chemical", subcategory: "metal_fumes", name_hu: "Hegesztési füstök", name_en: "Welding fumes", default_severity: 3, monitoring: "Légszennyezettség", ppe: "Hegesztő pajzs + légzésvédő" },

  // ---- BIOLÓGIAI ----
  { id: "bio-01", category: "biological", subcategory: "bacteria", name_hu: "Baktérium fertőzés veszélye", name_en: "Bacterial infection risk", default_severity: 3, monitoring: "Immunstátusz vizsgálat" },
  { id: "bio-02", category: "biological", subcategory: "virus", name_hu: "Vírus fertőzés veszélye", name_en: "Viral infection risk", default_severity: 3, monitoring: "Védőoltás ellenőrzés" },
  { id: "bio-03", category: "biological", subcategory: "fungus", name_hu: "Gomba / penész expozíció", name_en: "Fungal / mold exposure", default_severity: 2, monitoring: "Légúti szűrés" },
  { id: "bio-04", category: "biological", subcategory: "parasite", name_hu: "Parazita fertőzés (kullancs, stb.)", name_en: "Parasitic infections (ticks, etc.)", default_severity: 2, monitoring: "Borrelia szűrés" },
  { id: "bio-05", category: "biological", subcategory: "legionella", name_hu: "Legionella veszély", name_en: "Legionella risk", default_severity: 3, monitoring: "Vízminőség vizsgálat" },
  { id: "bio-06", category: "biological", subcategory: "bloodborne", name_hu: "Vérátviteli fertőzések (HIV, HBV, HCV)", name_en: "Bloodborne pathogens", default_severity: 4, monitoring: "Szerológiai vizsgálat", ppe: "Védőkesztyű, védőszemüveg" },
  { id: "bio-07", category: "biological", subcategory: "animal", name_hu: "Állatokkal kapcsolatos kórokozók", name_en: "Zoonotic pathogens", default_severity: 3, monitoring: "Védőoltás" },
  { id: "bio-08", category: "biological", subcategory: "bioaerosol", name_hu: "Bio-aeroszolok (komposztálás, szennyvíz)", name_en: "Bioaerosols", default_severity: 3, ppe: "FFP3 maszk" },

  // ---- ERGONÓMIAI ----
  { id: "erg-01", category: "ergonomic", subcategory: "manual_handling", name_hu: "Kézi tehermozgatás (>5 kg rendszeres)", name_en: "Manual handling (>5 kg regular)", default_severity: 3, monitoring: "Mozgásszervi szűrés" },
  { id: "erg-02", category: "ergonomic", subcategory: "manual_handling", name_hu: "Nehéz tárgyak emelése (>25 kg)", name_en: "Heavy lifting (>25 kg)", default_severity: 4, monitoring: "Gerincvizsgálat" },
  { id: "erg-03", category: "ergonomic", subcategory: "repetitive", name_hu: "Ismétlődő mozdulatok", name_en: "Repetitive movements", default_severity: 2, monitoring: "Mozgásszervi szűrés" },
  { id: "erg-04", category: "ergonomic", subcategory: "posture", name_hu: "Kényszerhelyzet / statikus testtartás", name_en: "Forced posture / static position", default_severity: 2, monitoring: "Ergonómiai felmérés" },
  { id: "erg-05", category: "ergonomic", subcategory: "vdu", name_hu: "Képernyő előtti munka (>4 óra/nap)", name_en: "VDU work (>4 hours/day)", default_severity: 2, monitoring: "Szemészeti vizsgálat" },
  { id: "erg-06", category: "ergonomic", subcategory: "standing", name_hu: "Tartós állómunka", name_en: "Prolonged standing", default_severity: 2, monitoring: "Érbetegség szűrés" },
  { id: "erg-07", category: "ergonomic", subcategory: "seated", name_hu: "Tartós ülőmunka", name_en: "Prolonged sitting", default_severity: 2, monitoring: "Gerincvizsgálat" },
  { id: "erg-08", category: "ergonomic", subcategory: "push_pull", name_hu: "Tolás / húzás", name_en: "Pushing / pulling", default_severity: 2, monitoring: "Erőkifejtés mérés" },

  // ---- PSZICHOSZOCIÁLIS ----
  { id: "psy-01", category: "psychosocial", subcategory: "stress", name_hu: "Munkahelyi stressz", name_en: "Workplace stress", default_severity: 2, monitoring: "Stressz kérdőív" },
  { id: "psy-02", category: "psychosocial", subcategory: "night_work", name_hu: "Éjszakai / műszakos munka", name_en: "Night / shift work", default_severity: 3, monitoring: "Alvásminőség felmérés" },
  { id: "psy-03", category: "psychosocial", subcategory: "lone_work", name_hu: "Egyedül végzett munka", name_en: "Lone working", default_severity: 2, monitoring: "Kockázatértékelés" },
  { id: "psy-04", category: "psychosocial", subcategory: "violence", name_hu: "Erőszak / zaklatás veszélye", name_en: "Violence / harassment risk", default_severity: 3 },
  { id: "psy-05", category: "psychosocial", subcategory: "monotony", name_hu: "Monoton munka", name_en: "Monotonous work", default_severity: 1, monitoring: "Pszichoszociális kérdőív" },
  { id: "psy-06", category: "psychosocial", subcategory: "deadline", name_hu: "Időnyomás / határidős munka", name_en: "Time pressure / deadline work", default_severity: 2 },
  { id: "psy-07", category: "psychosocial", subcategory: "burnout", name_hu: "Kiégés veszélye", name_en: "Burnout risk", default_severity: 2, monitoring: "Maslach kérdőív" },

  // ---- MUNKAESZKÖZÖK ----
  { id: "equ-01", category: "equipment", subcategory: "rotating", name_hu: "Forgó alkatrészek", name_en: "Rotating parts", default_severity: 4, ppe: "Szorosan álló ruházat" },
  { id: "equ-02", category: "equipment", subcategory: "sharp", name_hu: "Éles felületek / vágásveszély", name_en: "Sharp surfaces / cutting hazard", default_severity: 3, ppe: "Vágásbiztos kesztyű" },
  { id: "equ-03", category: "equipment", subcategory: "press", name_hu: "Préselő / zúzó berendezések", name_en: "Pressing / crushing equipment", default_severity: 4, ppe: "Védőkesztyű" },
  { id: "equ-04", category: "equipment", subcategory: "crane", name_hu: "Emelőgépek / daruk", name_en: "Lifting equipment / cranes", default_severity: 4, monitoring: "Időszakos felülvizsgálat" },
  { id: "equ-05", category: "equipment", subcategory: "forklift", name_hu: "Targonca / belső szállítás", name_en: "Forklift / internal transport", default_severity: 3, monitoring: "Jogosultság ellenőrzés" },
  { id: "equ-06", category: "equipment", subcategory: "power_tool", name_hu: "Kézi erőgépek (fúró, csiszoló, flex)", name_en: "Power tools (drill, grinder)", default_severity: 3, ppe: "Védőszemüveg, kesztyű" },
  { id: "equ-07", category: "equipment", subcategory: "conveyor", name_hu: "Szállítószalagok", name_en: "Conveyors", default_severity: 3 },
  { id: "equ-08", category: "equipment", subcategory: "pneumatic", name_hu: "Pneumatikus / hidraulikus rendszerek", name_en: "Pneumatic / hydraulic systems", default_severity: 3 },
  { id: "equ-09", category: "equipment", subcategory: "ladder", name_hu: "Létrák / állványzatok", name_en: "Ladders / scaffolding", default_severity: 3, monitoring: "Állapot ellenőrzés" },

  // ---- MUNKAKÖRNYEZET ----
  { id: "env-01", category: "environment", subcategory: "fall_height", name_hu: "Magasból leesés veszélye", name_en: "Fall from height", default_severity: 4, ppe: "Biztonsági hám" },
  { id: "env-02", category: "environment", subcategory: "fall_level", name_hu: "Megcsúszás / elesés (azonos szint)", name_en: "Slips / trips (same level)", default_severity: 2, ppe: "Csúszásbiztos cipő" },
  { id: "env-03", category: "environment", subcategory: "confined", name_hu: "Zárt tér / tartályok", name_en: "Confined spaces / tanks", default_severity: 4, monitoring: "Gázmérés belépés előtt", ppe: "Független légzésvédő" },
  { id: "env-04", category: "environment", subcategory: "narrow", name_hu: "Szűk hely / korlátozott mozgás", name_en: "Narrow space / restricted movement", default_severity: 2 },
  { id: "env-05", category: "environment", subcategory: "traffic", name_hu: "Járműforgalom a munkaterületen", name_en: "Vehicle traffic in work area", default_severity: 3, ppe: "Láthatósági mellény" },
  { id: "env-06", category: "environment", subcategory: "falling_objects", name_hu: "Tárgyak leesésének veszélye", name_en: "Falling objects risk", default_severity: 3, ppe: "Védősisak" },
  { id: "env-07", category: "environment", subcategory: "drowning", name_hu: "Vízbeesés / fulladás veszélye", name_en: "Drowning hazard", default_severity: 4, ppe: "Mentőmellény" },
  { id: "env-08", category: "environment", subcategory: "outdoor", name_hu: "Szabadban végzett munka (időjárás)", name_en: "Outdoor work (weather)", default_severity: 2, ppe: "Időjárásnak megfelelő ruházat" },
  { id: "env-09", category: "environment", subcategory: "underground", name_hu: "Földalatti / mélyépítési munka", name_en: "Underground / deep construction work", default_severity: 3, ppe: "Védősisak, mentőkötél" },
  { id: "env-10", category: "environment", subcategory: "poor_housekeeping", name_hu: "Rendetlenség / akadályok az úton", name_en: "Poor housekeeping / obstructions", default_severity: 2 },

  // ---- TŰZ ÉS ROBBANÁS ----
  { id: "fir-01", category: "fire", subcategory: "flammable_liquid", name_hu: "Gyúlékony folyadékok tárolása / használata", name_en: "Flammable liquids storage/use", default_severity: 4, monitoring: "Tűzvédelmi felülvizsgálat", ppe: "Tűzálló ruházat" },
  { id: "fir-02", category: "fire", subcategory: "flammable_gas", name_hu: "Gyúlékony gázok", name_en: "Flammable gases", default_severity: 4, monitoring: "Gázszivárgás érzékelő" },
  { id: "fir-03", category: "fire", subcategory: "explosion", name_hu: "Porrobbanás veszélye", name_en: "Dust explosion risk", default_severity: 4, monitoring: "ATEX felülvizsgálat" },
  { id: "fir-04", category: "fire", subcategory: "hot_work", name_hu: "Tűzveszélyes munka (hegesztés, vágás)", name_en: "Hot work (welding, cutting)", default_severity: 3, monitoring: "Tűzmunka engedély" },
  { id: "fir-05", category: "fire", subcategory: "electrical_fire", name_hu: "Elektromos tűz veszélye", name_en: "Electrical fire risk", default_severity: 3, monitoring: "Termográfia" },
  { id: "fir-06", category: "fire", subcategory: "spontaneous", name_hu: "Öngyulladás veszélye", name_en: "Spontaneous combustion risk", default_severity: 3 },

  // ---- EGYÉB ----
  { id: "oth-01", category: "other", subcategory: "driving", name_hu: "Gépjárművezetés munka közben", name_en: "Driving during work", default_severity: 3, monitoring: "Vezetői alkalmasság" },
  { id: "oth-02", category: "other", subcategory: "diving", name_hu: "Búvármunka", name_en: "Diving work", default_severity: 4, monitoring: "Búvárvizsgálat" },
  { id: "oth-03", category: "other", subcategory: "hyperbaric", name_hu: "Túlnyomásos környezet (keszon)", name_en: "Hyperbaric environment", default_severity: 4 },
  { id: "oth-04", category: "other", subcategory: "customer_facing", name_hu: "Ügyfélkapcsolat (agresszió veszélye)", name_en: "Customer-facing (aggression risk)", default_severity: 2 },
  { id: "oth-05", category: "other", subcategory: "remote", name_hu: "Távoli / elszigetelt munkahely", name_en: "Remote / isolated workplace", default_severity: 2 },
];

// Risk level helpers
export const RISK_MATRIX_COLORS: Record<string, string> = {
  trivial: "bg-green-100 text-green-800 border-green-300",
  tolerable: "bg-yellow-100 text-yellow-800 border-yellow-300",
  moderate: "bg-orange-100 text-orange-800 border-orange-300",
  substantial: "bg-red-100 text-red-800 border-red-300",
  intolerable: "bg-red-200 text-red-900 border-red-500",
};

export function getRiskCategory(probability: number, severity: number): string {
  const level = probability * severity;
  if (level <= 2) return "trivial";
  if (level <= 4) return "tolerable";
  if (level <= 6) return "moderate";
  if (level <= 9) return "substantial";
  return "intolerable";
}

export const PROBABILITY_LABELS = {
  1: { hu: "Nagyon valószínűtlen", en: "Very unlikely" },
  2: { hu: "Valószínűtlen", en: "Unlikely" },
  3: { hu: "Valószínű", en: "Likely" },
  4: { hu: "Nagyon valószínű", en: "Very likely" },
};

export const SEVERITY_LABELS = {
  1: { hu: "Elhanyagolható", en: "Negligible" },
  2: { hu: "Kisebb sérülés", en: "Minor injury" },
  3: { hu: "Súlyos sérülés", en: "Major injury" },
  4: { hu: "Halálos / maradandó", en: "Fatal / permanent" },
};

export const RISK_CATEGORY_LABELS = {
  trivial: { hu: "Elenyésző", en: "Trivial" },
  tolerable: { hu: "Elfogadható", en: "Tolerable" },
  moderate: { hu: "Mérsékelt", en: "Moderate" },
  substantial: { hu: "Jelentős", en: "Substantial" },
  intolerable: { hu: "Elviselhetetlen", en: "Intolerable" },
};

export const ACTION_HIERARCHY_LABELS = {
  elimination: { hu: "Kiküszöbölés", en: "Elimination" },
  substitution: { hu: "Helyettesítés", en: "Substitution" },
  engineering: { hu: "Műszaki védelem", en: "Engineering controls" },
  admin: { hu: "Szervezési intézkedés", en: "Administrative controls" },
  ppe: { hu: "Egyéni védőeszköz", en: "PPE" },
};

export const EXPOSURE_FREQUENCY_OPTIONS = [
  { value: "daily", hu: "Naponta", en: "Daily" },
  { value: "weekly", hu: "Hetente", en: "Weekly" },
  { value: "monthly", hu: "Havonta", en: "Monthly" },
  { value: "rarely", hu: "Ritkán", en: "Rarely" },
];

export const EXPOSURE_DURATION_OPTIONS = [
  { value: "<1h", hu: "< 1 óra", en: "< 1 hour" },
  { value: "1-4h", hu: "1-4 óra", en: "1-4 hours" },
  { value: "4-8h", hu: "4-8 óra", en: "4-8 hours" },
  { value: ">8h", hu: "> 8 óra", en: "> 8 hours" },
];
