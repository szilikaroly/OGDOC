import { supabase } from "@/integrations/supabase/client";

const TARGET_LANGUAGES = ["en", "de", "ro", "sr", "zh", "fil"];

/**
 * Auto-translate a pages_content record to all languages and upsert into content_translations.
 * Works for both content (HTML) and content_json fields.
 */
export async function autoTranslatePageContent(
  recordId: string,
  content: string | null,
  contentJson: any,
  onProgress?: (lang: string) => void
): Promise<{ success: number; failed: string[] }> {
  const failed: string[] = [];
  let success = 0;

  // Determine which fields to translate
  const fieldsToTranslate: { field: string; text: string; isHtml: boolean }[] = [];

  if (content) {
    fieldsToTranslate.push({ field: "content", text: content, isHtml: true });
  }

  if (contentJson) {
    // For JSON, translate each string value separately
    const jsonObj = typeof contentJson === "string" ? JSON.parse(contentJson) : contentJson;
    for (const [key, val] of Object.entries(jsonObj)) {
      if (typeof val === "string" && val.trim()) {
        fieldsToTranslate.push({ field: key, text: val, isHtml: false });
      }
    }
  }

  if (fieldsToTranslate.length === 0) return { success: 0, failed: [] };

  for (const lang of TARGET_LANGUAGES) {
    onProgress?.(lang);
    for (const { field, text, isHtml } of fieldsToTranslate) {
      try {
        const { data, error } = await supabase.functions.invoke("ai-translate", {
          body: { text, target_language: lang, is_html: isHtml },
        });
        if (error) throw error;

        const translated = data.translated;
        if (!translated) continue;

        // Upsert into content_translations
        const { error: upsertErr } = await supabase.from("content_translations").upsert(
          {
            table_name: "pages_content",
            record_id: recordId,
            field_name: field,
            language: lang,
            value: translated,
          },
          { onConflict: "table_name,record_id,field_name,language" }
        );
        if (upsertErr) throw upsertErr;
        success++;
      } catch {
        failed.push(`${lang}/${field}`);
      }
    }
    // Small delay between languages to avoid rate limiting
    await new Promise((r) => setTimeout(r, 300));
  }

  return { success, failed };
}

/**
 * Auto-translate a site_settings value to all languages and upsert into content_translations.
 */
export async function autoTranslateSiteSetting(
  settingId: string,
  value: string,
  onProgress?: (lang: string) => void
): Promise<{ success: number; failed: string[] }> {
  const failed: string[] = [];
  let success = 0;

  if (!value.trim()) return { success: 0, failed: [] };

  const isHtml = /<[a-z][\s\S]*>/i.test(value);

  for (const lang of TARGET_LANGUAGES) {
    onProgress?.(lang);
    try {
      const { data, error } = await supabase.functions.invoke("ai-translate", {
        body: { text: value, target_language: lang, is_html: isHtml },
      });
      if (error) throw error;

      const translated = data.translated;
      if (!translated) continue;

      const { error: upsertErr } = await supabase.from("content_translations").upsert(
        {
          table_name: "site_settings",
          record_id: settingId,
          field_name: "value",
          language: lang,
          value: translated,
        },
        { onConflict: "table_name,record_id,field_name,language" }
      );
      if (upsertErr) throw upsertErr;
      success++;
    } catch {
      failed.push(lang);
    }
    await new Promise((r) => setTimeout(r, 300));
  }

  return { success, failed };
}
