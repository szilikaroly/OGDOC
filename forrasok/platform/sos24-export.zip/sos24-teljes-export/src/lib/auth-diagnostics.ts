// Auth health diagnostics — pure function evaluating recovery + auth state
// and returning a prioritized list of findings with suggested fixes.

export type Severity = "error" | "warn" | "info";

export type SuggestedAction =
  | "send_recovery_link"
  | "set_password_direct"
  | "edit_email"
  | "add_role"
  | "none";

export type Finding = {
  key: string;
  severity: Severity;
  title: string;
  description: string;
  action: SuggestedAction;
  actionLabel: string;
};

export type RecoveryRow = {
  user_id: string;
  email: string | null;
  recovery_sent_at: string | null;
  last_sign_in_at: string | null;
  email_confirmed_at: string | null;
  last_recovery_status: string | null;
  last_recovery_error: string | null;
  last_recovery_log_at: string | null;
  user_created_at?: string | null;
  has_password?: boolean | null;
};

const minutesAgo = (iso: string | null | undefined): number => {
  if (!iso) return Number.POSITIVE_INFINITY;
  return Math.max(0, (Date.now() - new Date(iso).getTime()) / 60000);
};

export function evaluateUser(
  rec: RecoveryRow | undefined,
  opts: { hasAnyRole: boolean }
): Finding[] {
  const findings: Finding[] = [];
  if (!rec) return findings;

  const status = rec.last_recovery_status ?? null;
  const confirmed = !!rec.email_confirmed_at;
  const everSignedIn = !!rec.last_sign_in_at;
  const hasPassword = rec.has_password !== false; // unknown → assume yes
  const createdMin = minutesAgo(rec.user_created_at ?? null);
  const recoveryAgeMin = minutesAgo(rec.last_recovery_log_at);

  // Email confirmation
  if (!confirmed && !everSignedIn) {
    findings.push({
      key: "email_unconfirmed_no_login",
      severity: "error",
      title: "Email nincs megerősítve",
      description:
        "A felhasználó még soha nem lépett be és nincs megerősített e-mail címe — így nem tud bejelentkezni.",
      action: "set_password_direct",
      actionLabel: "Új jelszó beállítása (megerősíti az emailt is)",
    });
  } else if (!confirmed && everSignedIn) {
    findings.push({
      key: "email_unconfirmed_with_login",
      severity: "warn",
      title: "Email nincs megerősítve, de van belépés",
      description:
        "A fiók működik, de az e-mail cím nincs megerősítve. A jelszó-link közvetlen beállítás módban megerősíti.",
      action: "set_password_direct",
      actionLabel: "Email megerősítése jelszó-beállítással",
    });
  }

  // Recovery delivery
  if (status === "dlq" || status === "failed" || status === "bounced") {
    findings.push({
      key: `recovery_${status}`,
      severity: "error",
      title: "Jelszó-visszaállító email sikertelen",
      description: rec.last_recovery_error
        ? `Hiba: ${rec.last_recovery_error.slice(0, 200)}`
        : "Az utolsó kiküldés sikertelen volt — ellenőrizd az email címet és próbáld újra.",
      action: "edit_email",
      actionLabel: "Email cím javítása",
    });
  } else if (status === "suppressed" || status === "complained") {
    findings.push({
      key: `recovery_${status}`,
      severity: "error",
      title: "Email cím letiltva (bounce/panasz lista)",
      description:
        "A címzettet a szolgáltató letiltotta. Javítsd az email címet vagy állíts be közvetlenül jelszót.",
      action: "set_password_direct",
      actionLabel: "Új jelszó beállítása közvetlenül",
    });
  } else if (status === "pending" && recoveryAgeMin > 5) {
    findings.push({
      key: "recovery_stuck",
      severity: "warn",
      title: "Recovery email a sorban ragadt",
      description: `Több mint ${Math.round(recoveryAgeMin)} perce vár a kiküldésre. Próbáld újraküldeni.`,
      action: "send_recovery_link",
      actionLabel: "Új link kiküldése",
    });
  } else if (status === "sent" && rec.last_recovery_log_at && !everSignedIn) {
    findings.push({
      key: "recovery_sent_not_used",
      severity: "info",
      title: "Recovery link kiment, de nem használták",
      description:
        "A link kiküldésre került, de a felhasználó azóta nem lépett be. Lehet, hogy a spam mappában van vagy lejárt (1 óra).",
      action: "send_recovery_link",
      actionLabel: "Új link kiküldése",
    });
  }

  // Never logged in
  if (!everSignedIn && createdMin > 60 * 24 * 7 && !status) {
    findings.push({
      key: "never_signed_in",
      severity: "info",
      title: "Soha nem lépett be",
      description: "A felhasználó több mint 7 napja regisztrált, de még nem lépett be.",
      action: "send_recovery_link",
      actionLabel: "Belépési link küldése",
    });
  }

  // No password set
  if (!hasPassword && !everSignedIn) {
    findings.push({
      key: "no_password",
      severity: "warn",
      title: "Nincs jelszó beállítva",
      description: "A fiókhoz nem tartozik jelszó — küldj recovery linket vagy állíts be egyet közvetlenül.",
      action: "send_recovery_link",
      actionLabel: "Jelszó-beállító link küldése",
    });
  }

  // No role
  if (!opts.hasAnyRole) {
    findings.push({
      key: "no_role",
      severity: "warn",
      title: "Nincs szerepkör hozzárendelve",
      description: "A felhasználó belép, de szerepkör hiányában korlátozott a hozzáférése.",
      action: "add_role",
      actionLabel: "Szerepkör hozzáadása",
    });
  }

  return findings;
}

export const severityRank: Record<Severity, number> = { error: 0, warn: 1, info: 2 };
