import { supabase } from "@/integrations/supabase/client";

/**
 * Resolve a signature_url (which may be a storage path or legacy public URL)
 * into a signed URL for display.
 */
export async function resolveSignatureUrl(storedUrl: string | null | undefined): Promise<string | null> {
  if (!storedUrl) return null;

  // If it's a storage path (not a URL), create a signed URL
  if (!storedUrl.startsWith("http")) {
    const { data } = await supabase.storage.from("signatures").createSignedUrl(storedUrl, 3600);
    return data?.signedUrl ?? null;
  }

  // Legacy public URL - extract the path and create signed URL
  const match = storedUrl.match(/\/signatures\/(.+?)(\?|$)/);
  if (match) {
    const { data } = await supabase.storage.from("signatures").createSignedUrl(match[1], 3600);
    return data?.signedUrl ?? null;
  }

  return storedUrl;
}
