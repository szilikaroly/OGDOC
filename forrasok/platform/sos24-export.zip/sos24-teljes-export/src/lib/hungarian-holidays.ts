/**
 * Hungarian public holidays and rest days through 2045.
 * July 1 is always a non-working day (custom rule).
 */

// Fixed holidays (month is 0-indexed)
const FIXED_HOLIDAYS: Array<{ month: number; day: number; name: string }> = [
  { month: 0, day: 1, name: "Újév" },
  { month: 2, day: 15, name: "Nemzeti ünnep" },
  { month: 4, day: 1, name: "Munka ünnepe" },
  { month: 5, day: 1, name: "Munkaszüneti nap (július 1.)" }, // June index=5? No, July=6
  { month: 7, day: 20, name: "Az államalapítás ünnepe" },
  { month: 9, day: 23, name: "1956-os forradalom ünnepe" },
  { month: 10, day: 1, name: "Mindenszentek" },
  { month: 11, day: 25, name: "Karácsony" },
  { month: 11, day: 26, name: "Karácsony 2. napja" },
];

// July 1 custom holiday
const JULY_1_HOLIDAY = { month: 6, day: 1, name: "Munkaszüneti nap (július 1.)" };

// Easter calculation (Anonymous Gregorian algorithm)
function getEasterDate(year: number): Date {
  const a = year % 19;
  const b = Math.floor(year / 100);
  const c = year % 100;
  const d = Math.floor(b / 4);
  const e = b % 4;
  const f = Math.floor((b + 8) / 25);
  const g = Math.floor((b - f + 1) / 3);
  const h = (19 * a + b - d - g + 15) % 30;
  const i = Math.floor(c / 4);
  const k = c % 4;
  const l = (32 + 2 * e + 2 * i - h - k) % 7;
  const m = Math.floor((a + 11 * h + 22 * l) / 451);
  const month = Math.floor((h + l - 7 * m + 114) / 31) - 1;
  const day = ((h + l - 7 * m + 114) % 31) + 1;
  return new Date(year, month, day);
}

function addDays(date: Date, days: number): Date {
  const r = new Date(date);
  r.setDate(r.getDate() + days);
  return r;
}

function dateKey(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

export interface HolidayInfo {
  date: string; // YYYY-MM-DD
  name: string;
}

// Cache
let cachedHolidays: Map<string, HolidayInfo> | null = null;

function buildHolidayMap(): Map<string, HolidayInfo> {
  const map = new Map<string, HolidayInfo>();

  for (let year = 2024; year <= 2045; year++) {
    // Fixed holidays
    for (const h of FIXED_HOLIDAYS) {
      const d = new Date(year, h.month, h.day);
      const key = dateKey(d);
      map.set(key, { date: key, name: h.name });
    }

    // July 1
    const jul1 = new Date(year, 6, 1);
    const jul1Key = dateKey(jul1);
    if (!map.has(jul1Key)) {
      map.set(jul1Key, { date: jul1Key, name: JULY_1_HOLIDAY.name });
    }

    // Easter-based movable holidays
    const easter = getEasterDate(year);
    const easterFriday = addDays(easter, -2); // Nagypéntek
    const easterMonday = addDays(easter, 1); // Húsvéthétfő
    const whitsunMonday = addDays(easter, 50); // Pünkösdhétfő

    for (const [d, name] of [
      [easterFriday, "Nagypéntek"],
      [easterMonday, "Húsvéthétfő"],
      [whitsunMonday, "Pünkösdhétfő"],
    ] as [Date, string][]) {
      const key = dateKey(d);
      map.set(key, { date: key, name });
    }
  }

  return map;
}

export function getHolidayMap(): Map<string, HolidayInfo> {
  if (!cachedHolidays) {
    cachedHolidays = buildHolidayMap();
  }
  return cachedHolidays;
}

export function isHoliday(date: Date): HolidayInfo | null {
  const key = dateKey(date);
  return getHolidayMap().get(key) ?? null;
}

export function isWeekend(date: Date): boolean {
  const day = date.getDay();
  return day === 0 || day === 6;
}

export function isNonWorkingDay(date: Date): { reason: string } | null {
  if (isWeekend(date)) return { reason: date.getDay() === 0 ? "Vasárnap" : "Szombat" };
  const holiday = isHoliday(date);
  if (holiday) return { reason: holiday.name };
  return null;
}
