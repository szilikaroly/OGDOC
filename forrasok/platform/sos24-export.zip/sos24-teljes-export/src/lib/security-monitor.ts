/**
 * Security event monitoring helper.
 *
 * Detects RLS / permission-denied errors coming back from Supabase
 * and forwards a structured event to the `log_security_event` RPC.
 *
 * Usage:
 *   const { data, error } = await supabase.from('foo').select('*');
 *   if (error) reportSupabaseError(error, { table: 'foo', operation: 'select' });
 */
import { supabase } from "@/integrations/supabase/client";

type SupabaseLikeError = {
  message?: string | null;
  code?: string | null;
  details?: string | null;
  hint?: string | null;
  status?: number | null;
};

const RLS_HINT_PATTERNS = [
  /permission denied for/i,
  /row[- ]level security/i,
  /violates row-level security policy/i,
  /not authorized/i,
];

const RLS_ERROR_CODES = new Set([
  "42501", // insufficient_privilege
  "PGRST301", // PostgREST: JWT/role missing
  "PGRST116", // 0 rows after RLS filter (sometimes useful)
]);

export interface SecurityReportContext {
  table?: string;
  operation?: string;
  route?: string;
  metadata?: Record<string, unknown>;
  /** Force severity (defaults to 'warn'). */
  severity?: "info" | "warn" | "error" | "critical";
  /** Custom event_type (defaults to 'rls_denied'). */
  eventType?: string;
}

/** Returns true when the error looks like an RLS/permission denial. */
export function isRlsDenial(err: SupabaseLikeError | null | undefined): boolean {
  if (!err) return false;
  if (err.code && RLS_ERROR_CODES.has(err.code)) return true;
  const msg = `${err.message ?? ""} ${err.details ?? ""} ${err.hint ?? ""}`;
  return RLS_HINT_PATTERNS.some((p) => p.test(msg));
}

/**
 * Reports a Supabase error if (and only if) it looks like an RLS denial.
 * Swallows its own failures so it never breaks the calling code path.
 */
export async function reportSupabaseError(
  err: SupabaseLikeError | null | undefined,
  ctx: SecurityReportContext = {},
): Promise<void> {
  try {
    if (!isRlsDenial(err)) return;
    await reportSecurityEvent({
      ...ctx,
      eventType: ctx.eventType ?? "rls_denied",
      severity: ctx.severity ?? "warn",
      errorCode: err?.code ?? null,
      errorMessage: err?.message ?? null,
    });
  } catch {
    // Never throw from the monitor.
  }
}

/** Lower-level: log any custom security event. */
export async function reportSecurityEvent(args: {
  eventType: string;
  severity?: "info" | "warn" | "error" | "critical";
  table?: string;
  operation?: string;
  errorCode?: string | null;
  errorMessage?: string | null;
  route?: string;
  metadata?: Record<string, unknown>;
}): Promise<void> {
  try {
    const route =
      args.route ??
      (typeof window !== "undefined" ? window.location.pathname : null);
    const userAgent =
      typeof navigator !== "undefined" ? navigator.userAgent : null;

    await (supabase as any).rpc("log_security_event", {
      _event_type: args.eventType,
      _severity: args.severity ?? "warn",
      _table_name: args.table ?? null,
      _operation: args.operation ?? null,
      _error_code: args.errorCode ?? null,
      _error_message: args.errorMessage ?? null,
      _route: route,
      _user_agent: userAgent,
      _metadata: args.metadata ?? {},
    });
  } catch {
    // swallow
  }
}
