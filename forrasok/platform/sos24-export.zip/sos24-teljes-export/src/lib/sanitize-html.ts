// Centralized client-side HTML sanitizer. Mirrors the allow-list used by the
// server (supabase/functions/_shared/sanitize.ts). Use anywhere we render
// untrusted HTML via dangerouslySetInnerHTML to avoid drifting policies.
import DOMPurify from "dompurify";

const ALLOWED_TAGS = [
  "p", "br", "strong", "em", "u", "ul", "ol", "li",
  "h1", "h2", "h3", "h4", "h5", "h6",
  "blockquote", "a", "code", "pre", "hr", "span", "div",
];
const ALLOWED_ATTR = ["href", "title", "target", "rel"];

const MAX_LENGTH = 100_000;

export function sanitizeRichHtml(input: unknown): string {
  if (input == null) return "";
  const raw = String(input);
  const truncated = raw.length > MAX_LENGTH ? raw.slice(0, MAX_LENGTH) : raw;
  const clean = DOMPurify.sanitize(truncated, {
    ALLOWED_TAGS,
    ALLOWED_ATTR,
    FORBID_TAGS: ["script", "style", "iframe", "object", "embed", "form", "input"],
    FORBID_ATTR: ["style", "onerror", "onload", "onclick", "onmouseover", "onfocus", "onblur"],
    ALLOW_DATA_ATTR: false,
  });
  // Force safe rel on any links the editor produced.
  return clean.replace(/<a\s+([^>]*?)>/gi, (_m, attrs) => {
    const hasRel = /\brel=/i.test(attrs);
    const safeAttrs = hasRel ? attrs : `${attrs} rel="noopener noreferrer nofollow"`;
    return `<a ${safeAttrs}>`;
  });
}

// Used for AI-generated text where Markdown-ish formatting is applied before
// sanitization. Stricter allow-list than rich HTML.
export function sanitizeAiHtml(input: unknown): string {
  if (input == null) return "";
  const raw = String(input).slice(0, MAX_LENGTH);
  return DOMPurify.sanitize(raw, {
    ALLOWED_TAGS: ["br", "h3", "strong", "em", "p", "ul", "ol", "li"],
    ALLOWED_ATTR: [],
    FORBID_ATTR: ["style", "onerror", "onload", "onclick"],
    ALLOW_DATA_ATTR: false,
  });
}
