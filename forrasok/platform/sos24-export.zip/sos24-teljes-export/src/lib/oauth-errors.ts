// Maps OAuth (Google/Apple) error codes & messages to friendly Hungarian text.
// Used by Login.tsx and Register.tsx to display readable feedback when the
// social sign-in flow fails (user cancellation, expired session, popup blocked, …).

export type OAuthProvider = "google" | "apple";

export interface FriendlyOAuthError {
  /** Short title (toast title / alert heading). */
  title: string;
  /** Detailed user-facing explanation. */
  description: string;
  /** Optional action hint (what should the user do next). */
  hint?: string;
  /** Severity – `info` for benign cases (e.g. user cancelled). */
  severity: "info" | "warning" | "error";
  /** Internal code for analytics / debugging. */
  code: string;
}

const PROVIDER_NAMES: Record<OAuthProvider, string> = {
  google: "Google",
  apple: "Apple",
};

/**
 * Normalize anything thrown / returned from the OAuth flow into a string blob
 * we can pattern-match against.
 */
function extractText(err: unknown): string {
  if (!err) return "";
  if (typeof err === "string") return err;
  if (err instanceof Error) return `${err.name}: ${err.message}`;
  if (typeof err === "object") {
    try {
      const anyErr = err as Record<string, unknown>;
      return [
        anyErr.code,
        anyErr.error,
        anyErr.error_code,
        anyErr.error_description,
        anyErr.message,
        anyErr.msg,
        anyErr.status,
      ]
        .filter(Boolean)
        .join(" | ");
    } catch {
      return String(err);
    }
  }
  return String(err);
}

export function getFriendlyOAuthError(
  provider: OAuthProvider,
  err: unknown,
): FriendlyOAuthError {
  const providerName = PROVIDER_NAMES[provider];
  const raw = extractText(err).toLowerCase();

  // 1. User-initiated cancellation (popup closed, "back" pressed on provider page)
  if (
    raw.includes("cancel") ||
    raw.includes("user_cancelled") ||
    raw.includes("access_denied") ||
    raw.includes("user denied") ||
    raw.includes("popup_closed") ||
    raw.includes("closed by user") ||
    raw.includes("window closed")
  ) {
    return {
      severity: "info",
      code: "oauth_cancelled",
      title: `${providerName} bejelentkezés megszakítva`,
      description: `A ${providerName} bejelentkezést megszakította vagy bezárta a felugró ablakot.`,
      hint: "Próbálja újra, és engedélyezze a hozzáférést a folytatáshoz.",
    };
  }

  // 2. Popup blocked by the browser
  if (
    raw.includes("popup blocked") ||
    raw.includes("popup_blocked") ||
    raw.includes("blocked by browser") ||
    raw.includes("popup was blocked")
  ) {
    return {
      severity: "warning",
      code: "oauth_popup_blocked",
      title: "Felugró ablak letiltva",
      description:
        "A böngésző letiltotta a bejelentkezési ablakot, ezért nem tudjuk megnyitni a Google/Apple bejelentkezési oldalt.",
      hint: "Engedélyezze a felugró ablakokat ehhez az oldalhoz, majd próbálja újra.",
    };
  }

  // 3. Expired / invalid session (state token, PKCE, replay)
  if (
    raw.includes("expired") ||
    raw.includes("invalid_state") ||
    raw.includes("state mismatch") ||
    raw.includes("pkce") ||
    raw.includes("nonce") ||
    raw.includes("code_verifier") ||
    raw.includes("invalid grant") ||
    raw.includes("invalid_grant") ||
    raw.includes("already used") ||
    raw.includes("replay")
  ) {
    return {
      severity: "warning",
      code: "oauth_expired",
      title: "Lejárt vagy érvénytelen bejelentkezési munkamenet",
      description: `A ${providerName} bejelentkezési munkamenet lejárt, vagy egy újraküldött (cache-ből visszanyitott) linket próbáltunk feldolgozni.`,
      hint: "Frissítse az oldalt, majd indítsa el újra a bejelentkezést.",
    };
  }

  // 4. Network / connectivity
  if (
    raw.includes("network") ||
    raw.includes("failed to fetch") ||
    raw.includes("fetch failed") ||
    raw.includes("timeout") ||
    raw.includes("timed out") ||
    raw.includes("offline")
  ) {
    return {
      severity: "error",
      code: "oauth_network",
      title: "Hálózati hiba",
      description: `Nem sikerült elérni a ${providerName} szolgáltatást. Ellenőrizze az internetkapcsolatot.`,
      hint: "Ha a probléma fennáll, próbálja újra néhány másodperc múlva.",
    };
  }

  // 5. Email already linked to another auth method
  if (
    raw.includes("identity_already_exists") ||
    raw.includes("email_exists") ||
    raw.includes("already registered") ||
    raw.includes("user already") ||
    raw.includes("already in use")
  ) {
    return {
      severity: "warning",
      code: "oauth_account_exists",
      title: "Már létező fiók",
      description: `Ezzel az e-mail címmel már létezik fiók egy másik bejelentkezési módszerrel.`,
      hint: `Lépjen be a másik módszerrel (pl. e-mail/jelszó), majd a Profil → Összekapcsolt fiókok menüben kösse össze a ${providerName} fiókját.`,
    };
  }

  // 6. Provider disabled / not configured
  if (
    raw.includes("provider is not enabled") ||
    raw.includes("unsupported_provider") ||
    raw.includes("provider_disabled") ||
    raw.includes("not configured")
  ) {
    return {
      severity: "error",
      code: "oauth_provider_disabled",
      title: `${providerName} bejelentkezés nem elérhető`,
      description: `A ${providerName} bejelentkezés jelenleg nincs engedélyezve a rendszerben.`,
      hint: "Próbáljon e-mail/jelszó alapú belépést, vagy keresse fel az ügyfélszolgálatot.",
    };
  }

  // 7. Server / 5xx
  if (
    raw.includes("server_error") ||
    raw.includes("internal error") ||
    raw.includes("500") ||
    raw.includes("502") ||
    raw.includes("503") ||
    raw.includes("504")
  ) {
    return {
      severity: "error",
      code: "oauth_server",
      title: `${providerName} szolgáltatás hiba`,
      description: `A ${providerName} szolgáltatás átmenetileg nem érhető el.`,
      hint: "Próbálja újra később. Ha a probléma tartós, jelezze a támogatásnak.",
    };
  }

  // 8. Iframe / preview restrictions
  if (raw.includes("iframe") || raw.includes("framed") || raw.includes("x-frame")) {
    return {
      severity: "warning",
      code: "oauth_iframe",
      title: "Bejelentkezés nem indítható ebben a nézetben",
      description: `A ${providerName} nem engedélyezi a beágyazott (iframe) megjelenítést.`,
      hint: "Nyissa meg az alkalmazást új lapon, és próbálja újra.",
    };
  }

  // 9. Fallback – show raw message in a friendly wrapper
  return {
    severity: "error",
    code: "oauth_unknown",
    title: `${providerName} bejelentkezési hiba`,
    description:
      extractText(err).slice(0, 240) ||
      `Ismeretlen hiba történt a ${providerName} bejelentkezés során.`,
    hint: "Próbálja újra, vagy használjon e-mail/jelszó alapú bejelentkezést.",
  };
}

/**
 * Read OAuth error info from the current URL (query + hash). Supabase/OAuth
 * providers may bounce back with ?error=... or #error=... params.
 */
export function readOAuthErrorFromUrl(): {
  error?: string;
  error_description?: string;
} | null {
  if (typeof window === "undefined") return null;
  const out: Record<string, string> = {};
  try {
    const sp = new URLSearchParams(window.location.search);
    for (const k of ["error", "error_code", "error_description"]) {
      const v = sp.get(k);
      if (v) out[k === "error_code" ? "error" : k] = v;
    }
    const hash = window.location.hash?.startsWith("#")
      ? window.location.hash.slice(1)
      : "";
    if (hash) {
      const hp = new URLSearchParams(hash);
      for (const k of ["error", "error_code", "error_description"]) {
        const v = hp.get(k);
        if (v && !out[k === "error_code" ? "error" : k]) {
          out[k === "error_code" ? "error" : k] = v;
        }
      }
    }
  } catch {
    return null;
  }
  return out.error || out.error_description ? out : null;
}

/** Strip OAuth error params from the URL without reloading the page. */
export function clearOAuthErrorFromUrl(): void {
  if (typeof window === "undefined") return;
  try {
    const url = new URL(window.location.href);
    ["error", "error_code", "error_description", "state"].forEach((k) =>
      url.searchParams.delete(k),
    );
    if (url.hash) {
      const hp = new URLSearchParams(
        url.hash.startsWith("#") ? url.hash.slice(1) : url.hash,
      );
      ["error", "error_code", "error_description", "state"].forEach((k) =>
        hp.delete(k),
      );
      const next = hp.toString();
      url.hash = next ? `#${next}` : "";
    }
    window.history.replaceState({}, "", url.toString());
  } catch {
    /* noop */
  }
}
