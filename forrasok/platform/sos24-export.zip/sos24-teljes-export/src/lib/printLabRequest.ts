import type { LabTest } from './labTestCatalog';

export interface LabRequestPrintData {
  requestNumber: string;
  patientName: string;
  dateOfBirth?: string;
  tajNumber?: string;
  motherName?: string;
  patientAddress?: string;
  patientGender?: string;
  patientPhone?: string;
  physicianName: string;
  scheduledDate?: string;
  costBearer?: 'taj' | 'self' | 'employer';
  priority: 'routine' | 'urgent' | 'stat';
  notes?: string;
  selectedTests: LabTest[];
  createdAt: string;
}

// Escape HTML to prevent XSS in printable view.
function esc(v: unknown): string {
  if (v === null || v === undefined) return '';
  return String(v)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

const priorityLabel: Record<string, string> = {
  routine: 'Rutin',
  urgent: 'Sürgős',
  stat: 'AZONNALI (STAT)',
};

const priorityColor: Record<string, string> = {
  routine: '#1d4ed8',
  urgent: '#b45309',
  stat: '#dc2626',
};

export function printLabRequest(d: LabRequestPrintData): void {
  const now = new Date().toLocaleString('hu-HU');
  const scheduledStr = d.scheduledDate
    ? new Date(d.scheduledDate).toLocaleDateString('hu-HU', { year: 'numeric', month: 'long', day: 'numeric' })
    : '—';

  const grouped: Record<string, LabTest[]> = {};
  d.selectedTests.forEach(t => {
    if (!grouped[t.specialty]) grouped[t.specialty] = [];
    grouped[t.specialty].push(t);
  });

  const testSections = Object.entries(grouped).map(([specialty, tests]) => `
    <div class="test-group">
      <div class="test-group-header">${esc(specialty.toUpperCase())}</div>
      <table class="test-table">
        <thead><tr>
          <th class="col-le">LE kód</th><th class="col-short">Rövid kód</th>
          <th class="col-name">Megnevezés</th><th class="col-unit">Egység</th>
          <th class="col-sample">Mintatípus</th><th class="col-check">✓</th>
        </tr></thead>
        <tbody>${tests.map(t => `
          <tr>
            <td class="col-le mono">${esc(t.leCode || t.id)}</td>
            <td class="col-short mono">${esc(t.shortName)}</td>
            <td class="col-name">${esc(t.name)}</td>
            <td class="col-unit small">${esc(t.unit || '—')}</td>
            <td class="col-sample">${esc(t.sampleType)}</td>
            <td class="col-check check-box">□</td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>`).join('');

  const sampleSummary = [...new Set(d.selectedTests.map(t => t.sampleType))].filter(s => s && s !== 'N/A');

  const html = `<!DOCTYPE html><html lang="hu"><head><meta charset="UTF-8"/>
<title>Labor kérő – ${esc(d.requestNumber)}</title>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Helvetica Neue',Arial,sans-serif;font-size:11px;color:#111;background:#fff;padding:24px 32px}
@media print{body{padding:0;font-size:10px}.no-print{display:none}}
.report-header{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:3px solid #111;padding-bottom:12px;margin-bottom:16px}
.report-title{font-size:18px;font-weight:900;letter-spacing:-0.5px}
.report-subtitle{font-size:10px;color:#666;margin-top:3px}
.report-meta{text-align:right;font-size:10px;color:#555;line-height:1.8}
.report-meta .req-num{font-size:15px;font-weight:800;color:#111;display:block}
.priority-badge{display:inline-block;padding:2px 8px;border-radius:4px;font-size:10px;font-weight:700;border:1.5px solid;margin-top:4px}
.info-grid{display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-bottom:14px}
.info-box{border:1px solid #ddd;border-radius:4px;padding:8px 10px}
.info-label{font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;color:#888;margin-bottom:3px}
.info-value{font-size:12px;font-weight:700;color:#111}
.sample-summary{background:#f0fdf4;border:1px solid #86efac;border-radius:5px;padding:8px 10px;margin-bottom:14px}
.sample-summary-title{font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;color:#15803d;margin-bottom:5px}
.sample-chips{display:flex;flex-wrap:wrap;gap:5px}
.sample-chip{font-size:10px;background:#dcfce7;border:1px solid #86efac;border-radius:3px;padding:2px 7px;font-weight:600}
.test-group{margin-bottom:14px}
.test-group-header{font-size:10px;font-weight:800;background:#f3f3f3;border-left:4px solid #111;padding:4px 8px;margin-bottom:5px}
.test-table{width:100%;border-collapse:collapse}
.test-table th{font-size:9px;font-weight:700;text-transform:uppercase;color:#555;background:#fafafa;border-bottom:1px solid #ddd;padding:4px 5px;text-align:left}
.test-table td{padding:3.5px 5px;border-bottom:1px solid #f0f0f0}
.mono{font-family:monospace;font-size:10px;color:#444}
.small{font-size:10px;color:#666}
.check-box{font-size:13px;color:#999;text-align:center}
.notes-box{border:1px solid #ddd;border-radius:4px;padding:8px 10px;margin-top:14px;min-height:48px}
.notes-label{font-size:9px;font-weight:700;text-transform:uppercase;color:#888;margin-bottom:5px}
.report-footer{display:flex;justify-content:space-between;align-items:flex-end;margin-top:24px;padding-top:10px;border-top:1px solid #ddd;font-size:9px;color:#aaa}
.sig-area{border-top:1px solid #888;width:180px;padding-top:4px;text-align:center;font-size:9px;color:#666}
.total-badge{background:#111;color:#fff;border-radius:4px;padding:4px 10px;font-size:12px;font-weight:800}
</style></head><body>
<div class="report-header">
  <div><div class="report-title">LABOR VIZSGÁLATKÉRŐ LAP</div>
  <div class="report-subtitle">SOS-24 Foglalkozás-egészségügyi Szolgálat · Konfidenciális orvosi dokumentum</div></div>
  <div class="report-meta"><span class="req-num">${esc(d.requestNumber)}</span>
  <div style="color:${priorityColor[d.priority]}"><span class="priority-badge" style="color:${priorityColor[d.priority]};border-color:${priorityColor[d.priority]}">${esc(priorityLabel[d.priority])}</span></div>
  Generálva: ${esc(now)}</div>
</div>
<div class="info-grid">
  <div class="info-box"><div class="info-label">Páciens neve</div><div class="info-value">${esc(d.patientName)}</div>
    ${d.dateOfBirth ? `<div style="font-size:10px;color:#555;margin-top:2px">Születési dátum: ${esc(d.dateOfBirth)}</div>` : ''}
    ${d.tajNumber ? `<div style="font-size:10px;color:#555">TAJ: ${esc(d.tajNumber)}</div>` : ''}
    ${d.motherName ? `<div style="font-size:10px;color:#555">Anyja neve: ${esc(d.motherName)}</div>` : ''}
    ${d.patientGender ? `<div style="font-size:10px;color:#555">Nem: ${esc(d.patientGender === 'male' ? 'Férfi' : d.patientGender === 'female' ? 'Nő' : d.patientGender)}</div>` : ''}
    ${d.patientAddress ? `<div style="font-size:10px;color:#555">Cím: ${esc(d.patientAddress)}</div>` : ''}</div>
  <div class="info-box"><div class="info-label">Kérő orvos</div><div class="info-value">${esc(d.physicianName)}</div>
    <div style="font-size:10px;color:#555;margin-top:2px">Mintavétel: ${esc(scheduledStr)}</div></div>
  <div class="info-box"><div class="info-label">Költségviselő</div><div class="info-value">${
    d.costBearer === 'taj' ? '🏥 TAJ finanszírozott' :
    d.costBearer === 'self' ? '💳 Önfizető' :
    d.costBearer === 'employer' ? '🏢 Munkáltatói' : '—'}</div></div>
</div>
${sampleSummary.length > 0 ? `<div class="sample-summary"><div class="sample-summary-title">🧪 Szükséges mintatípusok (${sampleSummary.length})</div>
<div class="sample-chips">${sampleSummary.map(s => `<span class="sample-chip">${esc(s)}</span>`).join('')}</div></div>` : ''}
<div style="display:flex;justify-content:flex-end;margin-bottom:10px"><span class="total-badge">Összes vizsgálat: ${d.selectedTests.length}</span></div>
${testSections}
<div class="notes-box"><div class="notes-label">Megjegyzés</div><div style="font-size:11px;white-space:pre-wrap">${esc(d.notes || '')}</div></div>
<div class="report-footer"><span>SOS-24 · ${esc(d.requestNumber)} · ${esc(d.patientName)}</span><div class="sig-area">${esc(d.physicianName)} – Orvos aláírása</div><span>${esc(now)}</span></div>
</body></html>`;

  const win = window.open('', '_blank', 'width=1000,height=760');
  if (!win) { alert('Engedélyezd a felugró ablakokat az exportáláshoz.'); return; }
  win.document.write(html);
  win.document.close();
  win.focus();
  setTimeout(() => { win.print(); }, 500);
}
