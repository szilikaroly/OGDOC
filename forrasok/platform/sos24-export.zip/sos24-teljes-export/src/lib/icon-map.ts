import {
  ShieldCheck, Users, Award, Stethoscope, FileCheck, CalendarCheck,
  ClipboardList, HeartPulse, Activity, Syringe, Pill, Thermometer,
  Brain, Eye, Baby, Bone, Heart, Microscope, Scan, Clipboard,
  MapPin, Building2, Phone, Mail, Globe, Search, Settings, Star,
  Clock, AlertCircle, CheckCircle, FileText, Calendar, Home,
  Briefcase, UserCheck, Truck, Shield, Zap, Target, TrendingUp,
  type LucideIcon,
} from "lucide-react";

const ICON_MAP: Record<string, LucideIcon> = {
  ShieldCheck, Users, Award, Stethoscope, FileCheck, CalendarCheck,
  ClipboardList, HeartPulse, Activity, Syringe, Pill, Thermometer,
  Brain, Eye, Baby, Bone, Heart, Microscope, Scan, Clipboard,
  MapPin, Building2, Phone, Mail, Globe, Search, Settings, Star,
  Clock, AlertCircle, CheckCircle, FileText, Calendar, Home,
  Briefcase, UserCheck, Truck, Shield, Zap, Target, TrendingUp,
};

export function getIcon(name: string | null | undefined): LucideIcon {
  if (!name) return ClipboardList;
  return ICON_MAP[name] ?? ClipboardList;
}
