/**
 * Centralized translation of Supabase email/password auth errors.
 * OAuth-specific errors live in `oauth-errors.ts` and are not handled here.
 */

export type AuthErrorKind =
  | "invalid_credentials"
  | "email_not_confirmed"
  | "user_already_exists"
  | "rate_limited"
  | "link_expired"
  | "link_invalid"
  | "password_too_short"
  | "password_too_weak"
  | "password_same_as_old"
  | "password_needs_letter_number"
  | "passwords_no_match"
  | "network"
  | "unknown";

type AnyErr = {
  code?: string;
  status?: number;
  message?: string;
  name?: string;
} | string | null | undefined;

function asObj(err: unknown): { code?: string; status?: number; message?: string; name?: string } {
  if (!err) return {};
  if (typeof err === "string") return { message: err };
  if (typeof err === "object") {
    const e = err as any;
    return {
      code: typeof e.code === "string" ? e.code : undefined,
      status: typeof e.status === "number" ? e.status : undefined,
      message: typeof e.message === "string" ? e.message : undefined,
      name: typeof e.name === "string" ? e.name : undefined,
    };
  }
  return {};
}

export function classifyAuthError(err: unknown): AuthErrorKind {
  const { code, status, message, name } = asObj(err);
  const m = (message || "").toLowerCase();

  // 1) Supabase error codes (preferred)
  switch (code) {
    case "invalid_credentials":
      return "invalid_credentials";
    case "email_not_confirmed":
      return "email_not_confirmed";
    case "user_already_exists":
    case "email_exists":
      return "user_already_exists";
    case "over_email_send_rate_limit":
    case "over_request_rate_limit":
      return "rate_limited";
    case "otp_expired":
      return "link_expired";
    case "weak_password":
      return "password_too_weak";
    case "same_password":
      return "password_same_as_old";
  }

  // 2) HTTP status
  if (status === 429) return "rate_limited";

  // 3) Network failure (fetch)
  if (name === "TypeError" && /fetch|network/i.test(m)) return "network";
  if (/failed to fetch|network ?error/i.test(m)) return "network";

  // 4) Message-based fallbacks
  if (!m) return "unknown";
  if (m.includes("invalid login credentials")) return "invalid_credentials";
  if (m.includes("email not confirmed")) return "email_not_confirmed";
  if (m.includes("user already registered") || m.includes("already registered")) return "user_already_exists";
  if (m.includes("rate limit") || m.includes("too many requests")) return "rate_limited";
  if (m.includes("expired")) return "link_expired";
  if (m.includes("invalid") && m.includes("token")) return "link_invalid";
  if (m.includes("new password should be different")) return "password_same_as_old";
  if (m.includes("pwned") || m.includes("compromised") || m.includes("weak")) return "password_too_weak";
  if (m.includes("should be at least")) return "password_too_short";

  return "unknown";
}

const KIND_TO_KEY: Record<AuthErrorKind, string> = {
  invalid_credentials: "auth.invalidCredentials",
  email_not_confirmed: "auth.emailNotConfirmed",
  user_already_exists: "auth.userAlreadyExists",
  rate_limited: "auth.rateLimited",
  link_expired: "auth.linkExpired",
  link_invalid: "auth.linkInvalid",
  password_too_short: "auth.passwordTooShort",
  password_too_weak: "auth.passwordTooWeak",
  password_same_as_old: "auth.passwordSameAsOld",
  password_needs_letter_number: "auth.passwordNeedsLetterNumber",
  passwords_no_match: "auth.passwordsNoMatch",
  network: "auth.networkError",
  unknown: "auth.errorGeneric",
};

type Translator = (key: string) => string;

/**
 * Translate any Supabase auth-related error into a localized, user-facing message.
 * Falls back to the raw `err.message` when the kind is `unknown`, so developers
 * still see actionable text instead of a generic placeholder.
 */
export function translateAuthError(err: unknown, t: Translator): string {
  const kind = classifyAuthError(err);
  const key = KIND_TO_KEY[kind];
  const translated = t(key);
  if (kind === "unknown") {
    const { message } = asObj(err);
    if (message && message.trim().length > 0 && translated === key) return message;
    if (message && message.trim().length > 0) return message;
  }
  // If a key is missing in the bundle, i18next returns the key itself; fall back.
  return translated && translated !== key ? translated : (asObj(err).message || translated);
}

/**
 * Build a destructive toast payload (sonner / use-toast compatible).
 */
export function getAuthErrorToast(
  err: unknown,
  t: Translator,
  titleKey: string = "common.error"
): { title: string; description: string; variant: "destructive" } {
  return {
    variant: "destructive",
    title: t(titleKey),
    description: translateAuthError(err, t),
  };
}
