import { createContext, useContext, useEffect, useState, useCallback, type ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { User, Session } from "@supabase/supabase-js";

export type AppRole =
  | "super_admin"
  | "haziorvos"
  | "uzemorvos"
  | "munkaltato"
  | "munkavallalo"
  | "praxistag";

interface Profile {
  id: string;
  user_id: string;
  full_name: string;
  taj_number: string | null;
  birth_date: string | null;
  phone: string | null;
  avatar_url: string | null;
}

interface AuthContextType {
  user: User | null;
  session: Session | null;
  profile: Profile | null;
  roles: AppRole[];
  loading: boolean;
  hasRole: (role: AppRole) => boolean;
  hasAnyRole: (roles: AppRole[]) => boolean;
  activeRole: AppRole | null;
  setActiveRole: (role: AppRole) => void;
  signOut: () => Promise<void>;
  refreshRoles: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [roles, setRoles] = useState<AppRole[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeRole, setActiveRole] = useState<AppRole | null>(null);

  const fetchProfile = useCallback(async (userId: string) => {
    const { data } = await supabase
      .from("profiles")
      .select("id, user_id, full_name, taj_number, birth_date, phone, avatar_url")
      .eq("user_id", userId)
      .single();
    setProfile(data as Profile | null);
  }, []);

  const fetchRoles = useCallback(async (userId: string) => {
    const { data } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", userId);

    const userRoles = (data ?? []).map((r) => r.role as AppRole);
    setRoles(userRoles);

    // Auto-select active role
    if (userRoles.length > 0) {
      const savedRole = localStorage.getItem("activeRole") as AppRole | null;
      if (savedRole && userRoles.includes(savedRole)) {
        setActiveRole(savedRole);
      } else {
        setActiveRole(userRoles[0]);
      }
    } else {
      setActiveRole(null);
    }
  }, []);

  const refreshRoles = useCallback(async () => {
    if (user?.id) await fetchRoles(user.id);
  }, [user, fetchRoles]);

  useEffect(() => {
    // Set up auth state listener FIRST
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setSession(session);
        setUser(session?.user ?? null);

        if (session?.user) {
          // Defer data fetching to avoid Supabase deadlock
          setTimeout(async () => {
            await Promise.all([
              fetchProfile(session.user.id),
              fetchRoles(session.user.id),
            ]);
            setLoading(false);

            // OAuth role validation: ha social login (Google/Apple) után nincs
            // szerepkör, jelezzük az adminnak és a felhasználónak.
            if (event === "SIGNED_IN") {
              try {
                const provider =
                  (session.user.app_metadata as any)?.provider ??
                  session.user.identities?.[0]?.provider ??
                  "email";
                if (provider === "google" || provider === "apple") {
                  const { data: roleRows } = await supabase
                    .from("user_roles")
                    .select("role")
                    .eq("user_id", session.user.id);
                  if (!roleRows || roleRows.length === 0) {
                    await supabase.rpc("log_security_event", {
                      _event_type: "oauth_login_no_role",
                      _severity: "warn",
                      _route: typeof window !== "undefined" ? window.location.pathname : null,
                      _user_agent: typeof navigator !== "undefined" ? navigator.userAgent : null,
                      _metadata: {
                        provider,
                        email: session.user.email,
                        user_id: session.user.id,
                      },
                    });
                    if (typeof window !== "undefined") {
                      const { toast } = await import("@/hooks/use-toast");
                      toast({
                        variant: "destructive",
                        title: "Nincs szerepkör hozzárendelve",
                        description:
                          provider === "google"
                            ? "A Google fiókodhoz még nincs jogosultság rendelve. Kérjük, vedd fel a kapcsolatot az adminisztrátorral."
                            : "Az Apple fiókodhoz még nincs jogosultság rendelve. Kérjük, vedd fel a kapcsolatot az adminisztrátorral.",
                      });
                    }
                  }
                }
              } catch {
                /* best-effort */
              }
            }
          }, 0);
        } else {
          setProfile(null);
          setRoles([]);
          setActiveRole(null);
          setLoading(false);
        }
      }
    );

    // THEN check existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);

      if (session?.user) {
        Promise.all([
          fetchProfile(session.user.id),
          fetchRoles(session.user.id),
        ]).finally(() => setLoading(false));
      } else {
        setLoading(false);
      }
    });

    return () => subscription.unsubscribe();
  }, [fetchProfile, fetchRoles]);

  // Persist active role
  useEffect(() => {
    if (activeRole) {
      localStorage.setItem("activeRole", activeRole);
    }
  }, [activeRole]);

  const hasRole = useCallback(
    (role: AppRole) => roles.includes(role),
    [roles]
  );

  const hasAnyRole = useCallback(
    (checkRoles: AppRole[]) => checkRoles.some((r) => roles.includes(r)),
    [roles]
  );

  const signOut = useCallback(async () => {
    // 1. Best-effort revoke Google OAuth tokens so the provider session is also
    //    invalidated (not just the local Supabase session).
    try {
      const providerToken =
        (session as unknown as { provider_token?: string })?.provider_token ??
        null;
      const providerRefreshToken =
        (session as unknown as { provider_refresh_token?: string })
          ?.provider_refresh_token ?? null;
      const tokensToRevoke = [providerToken, providerRefreshToken].filter(
        Boolean,
      ) as string[];
      await Promise.allSettled(
        tokensToRevoke.map((tok) =>
          fetch(
            `https://oauth2.googleapis.com/revoke?token=${encodeURIComponent(tok)}`,
            { method: "POST", mode: "no-cors", keepalive: true },
          ),
        ),
      );
    } catch {
      /* non-fatal */
    }

    // 2. Sign out globally — revokes the refresh token on the server so every
    //    tab / device that shares this session loses access.
    try {
      await supabase.auth.signOut({ scope: "global" });
    } catch {
      // Fallback to local sign-out if the server is unreachable.
      try {
        await supabase.auth.signOut({ scope: "local" });
      } catch {
        /* ignore */
      }
    }

    // 3. Clear any lingering auth artefacts. Defensive against provider state
    //    that survived (e.g. half-finished OAuth flows, stale tokens).
    try {
      const purgeKeys = (storage: Storage) => {
        const toDelete: string[] = [];
        for (let i = 0; i < storage.length; i++) {
          const k = storage.key(i);
          if (!k) continue;
          if (
            k.startsWith("sb-") ||
            k.includes("supabase.auth") ||
            k.startsWith("lovable.auth") ||
            k === "activeRole"
          ) {
            toDelete.push(k);
          }
        }
        toDelete.forEach((k) => storage.removeItem(k));
      };
      purgeKeys(localStorage);
      purgeKeys(sessionStorage);
    } catch {
      /* ignore */
    }

    // 4. Reset in-memory state immediately so the UI is consistent regardless
    //    of provider — don't wait for onAuthStateChange to race in.
    setUser(null);
    setSession(null);
    setProfile(null);
    setRoles([]);
    setActiveRole(null);
  }, [session]);

  return (
    <AuthContext.Provider
      value={{
        user,
        session,
        profile,
        roles,
        loading,
        hasRole,
        hasAnyRole,
        activeRole,
        setActiveRole,
        signOut,
        refreshRoles,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
