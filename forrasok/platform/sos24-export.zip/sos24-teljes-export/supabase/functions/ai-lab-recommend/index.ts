import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { requireUser } from "../_shared/auth.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface CatalogItem {
  id: string;
  name: string;
  shortName: string;
  specialty: string;
  sampleType: string;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const auth = await requireUser(req, corsHeaders);
    if (!auth.ok) return auth.response;

    const { symptoms, mode, catalog } = await req.json();
    if (!symptoms || typeof symptoms !== "string" || symptoms.length < 3) {
      return new Response(JSON.stringify({ error: "Adjon meg legalább 3 karakter hosszú leírást." }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (!Array.isArray(catalog) || catalog.length === 0) {
      return new Response(JSON.stringify({ error: "Hiányzó katalógus." }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    // Compact catalog for the model — id + name + specialty
    const compact = (catalog as CatalogItem[])
      .map((t) => `${t.id}|${t.name}|${t.specialty}`)
      .join("\n");

    const isOrder = mode === "order";

    const systemPrompt = `Te egy magyar nyelvű, tapasztalt laborszakértő asszisztens vagy. Feladatod KIZÁRÓLAG laborvizsgálatok ajánlása a megadott katalógusból a páciens panaszai alapján.

SZIGORÚ SZABÁLYOK:
- Csak és kizárólag a katalógusban szereplő ID-ket használhatod (LK-* formátum).
- SOHA ne találj ki vizsgálat-ID-t. Ha valami nincs a katalógusban, hagyd ki.
- NEM diagnosztizálsz, NEM adsz kezelési javaslatot, NEM javasolsz gyógyszert.
- Mindig hangsúlyozd, hogy a végleges értelmezés és diagnózis ORVOS feladata.
- ${isOrder ? "Adj meg egy LOGIKUS sorrendet a vizsgálatok elvégzéséhez (pl. előbb alapszűrés, aztán célzott vizsgálatok)." : "Csak ajánld a vizsgálatokat, sorrend nélkül."}
- Magyarul válaszolj.

ELÉRHETŐ KATALÓGUS (id|név|szakterület):
${compact}`;

    const tools = [
      {
        type: "function",
        function: {
          name: "recommend_lab_tests",
          description: "Visszaad egy listát a javasolt laborvizsgálatok ID-iről és egy rövid magyarázatot.",
          parameters: {
            type: "object",
            properties: {
              summary: {
                type: "string",
                description: "Rövid (2-3 mondatos) magyar összefoglaló a panaszok alapján, mit érdemes nézni. Hangsúlyozd, hogy orvosi értelmezés szükséges.",
              },
              recommendations: {
                type: "array",
                description: "Javasolt vizsgálatok listája, max 15 elem.",
                items: {
                  type: "object",
                  properties: {
                    test_id: { type: "string", description: "A katalógusban szereplő pontos ID (pl. LK-22)" },
                    reason: { type: "string", description: "Egy mondatos indoklás magyarul, miért javasolt." },
                    priority: { type: "string", enum: ["alap", "kiegészítő", "célzott"], description: "Sorrendiségi prioritás" },
                  },
                  required: ["test_id", "reason", "priority"],
                  additionalProperties: false,
                },
              },
              disclaimer: {
                type: "string",
                description: "Rövid figyelmeztetés magyarul, hogy a leletek értékelése orvosi kompetencia.",
              },
            },
            required: ["summary", "recommendations", "disclaimer"],
            additionalProperties: false,
          },
        },
      },
    ];

    const aiResp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: symptoms },
        ],
        tools,
        tool_choice: { type: "function", function: { name: "recommend_lab_tests" } },
      }),
    });

    if (!aiResp.ok) {
      if (aiResp.status === 429) {
        return new Response(JSON.stringify({ error: "Túl sok kérés érkezett, próbálja újra később." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (aiResp.status === 402) {
        return new Response(JSON.stringify({ error: "AI kredit elfogyott. Egyeztessen az adminisztrátorral." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const t = await aiResp.text();
      console.error("AI gateway error:", aiResp.status, t);
      throw new Error("AI gateway error");
    }

    const aiData = await aiResp.json();
    const toolCall = aiData.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall) throw new Error("Az AI nem adott vissza választ.");

    const args = JSON.parse(toolCall.function.arguments);

    // Validate: only keep IDs that exist in the provided catalog
    const validIds = new Set((catalog as CatalogItem[]).map((c) => c.id));
    args.recommendations = (args.recommendations ?? []).filter((r: any) =>
      typeof r.test_id === "string" && validIds.has(r.test_id)
    );

    return new Response(JSON.stringify(args), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("ai-lab-recommend error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Ismeretlen hiba" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
