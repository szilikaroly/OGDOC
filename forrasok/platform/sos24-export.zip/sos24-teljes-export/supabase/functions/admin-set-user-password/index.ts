import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const anon = createClient(SUPABASE_URL, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: userRes, error: userErr } = await anon.auth.getUser(authHeader.replace("Bearer ", ""));
    if (userErr || !userRes?.user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const callerId = userRes.user.id;

    const admin = createClient(SUPABASE_URL, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const { data: isAdmin } = await admin.rpc("has_role", { _user_id: callerId, _role: "super_admin" });
    if (!isAdmin) {
      return new Response(JSON.stringify({ error: "Forbidden" }), { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const body = await req.json() as {
      user_id: string;
      mode: "link" | "direct";
      new_password?: string;
      redirect_to?: string;
    };

    if (!body.user_id || !body.mode) {
      return new Response(JSON.stringify({ error: "Missing fields" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const { data: target, error: targetErr } = await admin.auth.admin.getUserById(body.user_id);
    if (targetErr || !target?.user) {
      return new Response(JSON.stringify({ error: "User not found" }), { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const email = target.user.email;
    if (!email) {
      return new Response(JSON.stringify({ error: "User has no email" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const logAction = async (kind: "admin_direct" | "admin_link") => {
      try {
        await admin.rpc("log_security_event", {
          _event_type: kind === "admin_direct" ? "admin_password_set" : "admin_password_link_sent",
          _severity: "info",
          _table_name: "auth.users",
          _operation: "update",
          _metadata: { target_user_id: body.user_id, target_email: email, kind },
        });
      } catch (_) { /* logging best-effort */ }
    };

    if (body.mode === "link") {
      const { error } = await admin.auth.resetPasswordForEmail(email, {
        redirectTo: body.redirect_to || undefined,
      });
      if (error) throw error;
      await logAction("admin_link");
      return new Response(JSON.stringify({ ok: true, message: "Reset link sent" }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (body.mode === "direct") {
      const pwd = body.new_password;
      if (!pwd || pwd.length < 8) {
        return new Response(JSON.stringify({ error: "Password must be at least 8 characters" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      // Set the new password AND auto-confirm the email so the user can sign in
      // immediately (covers cases where the account was created but the
      // confirmation email was never opened — e.g. bulk-created users).
      const { error } = await admin.auth.admin.updateUserById(body.user_id, {
        password: pwd,
        email_confirm: true,
      });
      if (error) throw error;
      await logAction("admin_direct");

      // Try to email the new password via transactional email if template exists; silent on failure.
      try {
        await admin.functions.invoke("send-transactional-email", {
          body: {
            templateName: "admin-password-set",
            recipientEmail: email,
            idempotencyKey: `pwd-set-${body.user_id}-${Date.now()}`,
            templateData: { password: pwd },
          },
        });
      } catch (_) { /* template optional */ }

      return new Response(JSON.stringify({ ok: true, message: "Password updated" }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }


    return new Response(JSON.stringify({ error: "Invalid mode" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (err: any) {
    const msg: string = err?.message || "Unknown error";
    const lower = msg.toLowerCase();
    let status = 500;
    let friendly = msg;
    if (lower.includes("weak") || lower.includes("pwned") || lower.includes("known to be") || lower.includes("easy to guess")) {
      status = 400;
      friendly = "A jelszó túl gyenge vagy ismert adatszivárgásban szerepel. Válassz erősebb, egyedi jelszót (legalább 8 karakter, kis- és nagybetű, szám, speciális karakter).";
    } else if (lower.includes("should be at least") || lower.includes("password")) {
      status = 400;
      friendly = msg;
    }
    return new Response(JSON.stringify({ error: friendly, code: status === 400 ? "weak_password" : "internal" }), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
