import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const anon = createClient(SUPABASE_URL, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: userRes, error: userErr } = await anon.auth.getUser(authHeader.replace("Bearer ", ""));
    if (userErr || !userRes?.user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const callerId = userRes.user.id;

    const admin = createClient(SUPABASE_URL, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const { data: isAdmin } = await admin.rpc("has_role", { _user_id: callerId, _role: "super_admin" });
    if (!isAdmin) {
      return new Response(JSON.stringify({ error: "Forbidden" }), { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const body = await req.json() as {
      user_id: string;
      email?: string;
      phone?: string;
      full_name?: string;
    };

    if (!body.user_id) {
      return new Response(JSON.stringify({ error: "Missing user_id" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // Update auth email (if provided)
    if (body.email && body.email.includes("@")) {
      const { error } = await admin.auth.admin.updateUserById(body.user_id, { email: body.email, email_confirm: true });
      if (error) {
        const msg = (error.message || "").toLowerCase();
        if (msg.includes("already") && msg.includes("registered")) {
          return new Response(JSON.stringify({ error: "Ez az email cím már regisztrálva van" }), { status: 409, headers: { ...corsHeaders, "Content-Type": "application/json" } });
        }
        throw new Error(`Email frissítés: ${error.message}`);
      }
    }

    // Update profile (phone, full_name)
    const profileUpdate: Record<string, string> = {};
    if (typeof body.phone === "string") profileUpdate.phone = body.phone;
    if (body.full_name) profileUpdate.full_name = body.full_name;
    if (Object.keys(profileUpdate).length > 0) {
      const { error } = await admin.from("profiles").update(profileUpdate).eq("user_id", body.user_id);
      if (error) {
        if ((error as any).code === "23505" || /duplicate key/i.test(error.message)) {
          return new Response(JSON.stringify({ error: "Ezt a telefonszámot már egy másik felhasználó használja" }), { status: 409, headers: { ...corsHeaders, "Content-Type": "application/json" } });
        }
        throw new Error(`Profil frissítés: ${error.message}`);
      }
    }


    return new Response(JSON.stringify({ ok: true }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
