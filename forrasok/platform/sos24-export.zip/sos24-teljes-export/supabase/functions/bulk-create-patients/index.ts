import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { startAudit } from "../_shared/audit.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};


interface PatientInput {
  email?: string;
  full_name: string;
  taj_number?: string;
  birth_date?: string;
  birth_place?: string;
  birth_name?: string;
  mother_name?: string;
  phone?: string;
  address?: string;
  gender?: string;
  position?: string;
  feor_code?: string;
  feor_name?: string;
  site_name?: string;
  workplace_name?: string;
}

type Result = { email?: string; taj_number?: string; status: "success" | "error" | "duplicate"; error?: string; user_id?: string };

const ALLOWED_ROLES = new Set(["munkavallalo", "praxistag"]);

function normalizeTaj(v?: string) { return v ? v.replace(/[\s-]/g, "").trim() : undefined; }

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  const audit = startAudit("bulk-create-patients", req);
  let callerId: string | null = null;
  let callerEmail: string | null = null;

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      await audit.finish({ action: "bulk_create", statusCode: 401, severity: "warn", errorMessage: "missing bearer" });
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const anonClient = createClient(SUPABASE_URL, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: userRes, error: userErr } = await anonClient.auth.getUser(authHeader.replace("Bearer ", ""));
    if (userErr || !userRes?.user) {
      await audit.finish({ action: "bulk_create", statusCode: 401, severity: "warn", errorMessage: "invalid token" });
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    callerId = userRes.user.id;
    callerEmail = userRes.user.email ?? null;

    const adminClient = createClient(SUPABASE_URL, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

    const body = await req.json() as { patients: PatientInput[]; target_role?: string };
    const targetRole = (body.target_role && ALLOWED_ROLES.has(body.target_role)) ? body.target_role : "munkavallalo";

    if (!Array.isArray(body.patients) || body.patients.length === 0) {
      await audit.finish({ userId: callerId, userEmail: callerEmail, action: "bulk_create", statusCode: 400, severity: "warn", errorMessage: "empty patients" });
      return new Response(JSON.stringify({ error: "No patients provided" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    if (body.patients.length > 500) {
      await audit.finish({ userId: callerId, userEmail: callerEmail, action: "bulk_create", statusCode: 400, severity: "warn", errorMessage: "batch too large", metadata: { count: body.patients.length } });
      return new Response(JSON.stringify({ error: "Max 500 patients per batch" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // Authorization
    const { data: callerRel } = await adminClient
      .from("user_company_relations")
      .select("company_id")
      .eq("user_id", callerId)
      .eq("role", "munkaltato")
      .eq("is_active", true)
      .limit(1)
      .maybeSingle();
    const companyId = callerRel?.company_id;

    const { data: isAdmin } = await adminClient.rpc("has_role", { _user_id: callerId, _role: "super_admin" });
    const { data: isHaziorvos } = await adminClient.rpc("has_role", { _user_id: callerId, _role: "haziorvos" });

    if (!isAdmin && !isHaziorvos && !companyId) {
      await audit.finish({ userId: callerId, userEmail: callerEmail, action: "bulk_create", statusCode: 403, severity: "warn", errorMessage: "no eligible role" });
      return new Response(JSON.stringify({ error: "Forbidden" }), { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }



    // Pre-check duplicates against DB (server-side guard)
    const incomingTajs = Array.from(new Set(body.patients.map((p) => normalizeTaj(p.taj_number)).filter(Boolean) as string[]));
    const existingTajs = new Set<string>();
    if (incomingTajs.length > 0) {
      const { data: existing } = await adminClient
        .from("profiles")
        .select("taj_number")
        .in("taj_number", incomingTajs);
      for (const p of existing ?? []) if (p.taj_number) existingTajs.add(p.taj_number as string);
    }

    const results: Result[] = [];

    for (const raw of body.patients) {
      const p = { ...raw, taj_number: normalizeTaj(raw.taj_number) };
      try {
        if (!p.full_name) {
          results.push({ email: p.email, taj_number: p.taj_number, status: "error", error: "Név hiányzik" });
          continue;
        }
        if (!p.email && !p.taj_number) {
          results.push({ status: "error", error: "Email vagy TAJ kötelező" });
          continue;
        }
        if (p.taj_number && existingTajs.has(p.taj_number)) {
          results.push({ email: p.email, taj_number: p.taj_number, status: "duplicate", error: "TAJ már létezik" });
          continue;
        }

        let userId: string | undefined;
        let emailConflict = false;

        if (p.email) {
          // Create auth user
          const tempPassword = crypto.randomUUID().slice(0, 16) + "Aa1!";
          const { data: userData, error: createError } = await adminClient.auth.admin.createUser({
            email: p.email,
            password: tempPassword,
            email_confirm: true,
            user_metadata: { full_name: p.full_name },
          });
          if (createError) {
            // Email conflict in auth
            if (createError.message?.toLowerCase().includes("registered")) {
              results.push({ email: p.email, taj_number: p.taj_number, status: "duplicate", error: "Email már létezik" });
              continue;
            }
            results.push({ email: p.email, taj_number: p.taj_number, status: "error", error: createError.message });
            continue;
          }
          userId = userData.user.id;
        } else {
          // No-email path: profile-only patient with random UUID (no auth account)
          userId = crypto.randomUUID();
        }

        if (!userId) continue;

        // Upsert profile (handle_new_user may have created one already when email path)
        const profilePayload: Record<string, any> = {
          user_id: userId,
          full_name: p.full_name,
        };
        if (p.taj_number) profilePayload.taj_number = p.taj_number;
        if (p.birth_date) profilePayload.birth_date = p.birth_date;
        if (p.birth_place) profilePayload.birth_place = p.birth_place;
        if (p.mother_name) profilePayload.mother_name = p.mother_name;
        if (p.phone) profilePayload.phone = p.phone;
        if (p.address) profilePayload.address = p.address;
        if (p.gender && ["ferfi", "no", "egyeb"].includes(p.gender)) profilePayload.gender = p.gender;

        const { error: upErr } = await adminClient
          .from("profiles")
          .upsert(profilePayload, { onConflict: "user_id" });
        if (upErr) {
          // Likely TAJ unique conflict raced
          if (upErr.message?.includes("profiles_taj_number_key")) {
            results.push({ email: p.email, taj_number: p.taj_number, status: "duplicate", error: "TAJ már létezik" });
            continue;
          }
          results.push({ email: p.email, taj_number: p.taj_number, status: "error", error: upErr.message });
          continue;
        }

        // Role + relations: only when auth user exists
        if (p.email) {
          await adminClient.from("user_roles").upsert(
            { user_id: userId, role: targetRole },
            { onConflict: "user_id,role" },
          );

          if (companyId && targetRole === "munkavallalo") {
            const relPayload: Record<string, any> = {
              user_id: userId,
              company_id: companyId,
              role: "munkavallalo",
              is_active: true,
            };
            if (p.feor_code) relPayload.feor_code = p.feor_code;
            if (p.feor_name) relPayload.feor_name = p.feor_name;
            await adminClient.from("user_company_relations").insert(relPayload);
          }

          await adminClient.from("notifications").insert({
            user_id: userId,
            type: "welcome",
            title: "Üdvözöljük a rendszerben!",
            body: "Regisztráció megtörtént. Kérjük, állítson be jelszót a bejelentkezéshez.",
            link: "/login",
          });
        }

        results.push({ email: p.email, taj_number: p.taj_number, status: "success", user_id: userId });
      } catch (err: any) {
        results.push({ email: p.email, taj_number: p.taj_number, status: "error", error: err.message });
      }
    }

    const summary = {
      success: results.filter(r => r.status === "success").length,
      duplicate: results.filter(r => r.status === "duplicate").length,
      error: results.filter(r => r.status === "error").length,
    };
    await audit.finish({
      userId: callerId, userEmail: callerEmail, action: "bulk_create",
      resourceType: "patients", statusCode: 200, severity: summary.error > 0 ? "warn" : "info",
      metadata: { target_role: targetRole, company_id: companyId ?? null, total: results.length, ...summary },
    });
    return new Response(JSON.stringify({ results }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err: any) {
    await audit.finish({
      userId: callerId, userEmail: callerEmail, action: "bulk_create",
      statusCode: 500, severity: "error", errorMessage: err.message,
    });
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

