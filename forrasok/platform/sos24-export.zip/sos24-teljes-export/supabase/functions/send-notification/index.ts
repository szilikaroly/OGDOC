import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
import { startAudit } from "../_shared/audit.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
function isUuid(v: unknown): v is string { return typeof v === "string" && UUID_RE.test(v); }


interface NotificationPayload {
  type: "appointment_confirmed" | "referral_received" | "opinion_ready" | "medication_response" | "screening_plan" | "diet_plan";
  recipient_id: string;
  sender_id: string;
  data?: Record<string, string>;
}

const TEMPLATE_MAP: Record<string, string> = {
  appointment_confirmed: "appointment-confirmed",
  referral_received: "referral-received",
  opinion_ready: "opinion-ready",
  medication_response: "medication-response",
};

const TEMPLATES: Record<string, { subject: string; body: (data?: Record<string, string>) => string }> = {
  appointment_confirmed: {
    subject: "Időpont megerősítve",
    body: (d) => `Az Ön időpontja megerősítésre került.${d?.date ? ` Dátum: ${d.date}` : ""}${d?.service ? ` Szolgáltatás: ${d.service}` : ""} Kérjük, jelenjen meg a megadott időpontban.`,
  },
  referral_received: {
    subject: "Új beutaló érkezett",
    body: (d) => `Új beutaló érkezett az Ön részére.${d?.exam_reason ? ` Vizsgálat típusa: ${d.exam_reason}` : ""}${d?.company ? ` Munkáltató: ${d.company}` : ""}`,
  },
  opinion_ready: {
    subject: "Alkalmassági vélemény elkészült",
    body: (d) => `Az Ön alkalmassági véleménye elkészült.${d?.result ? ` Eredmény: ${d.result}` : ""}${d?.valid_until ? ` Érvényes: ${d.valid_until}` : ""}`,
  },
  medication_response: {
    subject: "Receptkérés megválaszolva",
    body: (d) => `A háziorvos megválaszolta a receptkérését.${d?.medication ? ` Gyógyszer: ${d.medication}` : ""}${d?.status ? ` Státusz: ${d.status === "approved" ? "Elfogadva" : "Elutasítva"}` : ""}`,
  },
  screening_plan: {
    subject: "Új szűrési terv érkezett",
    body: (d) => `Kezelőorvosa szűrési és kivizsgálási tervet készített az Ön számára.${d?.title ? ` ${d.title}` : ""} Tekintse meg az egészségterv menüpontban.`,
  },
  diet_plan: {
    subject: "Új diétás terv érkezett",
    body: (d) => `Kezelőorvosa személyre szabott diétás tervet készített az Ön számára.${d?.title ? ` ${d.title}` : ""} Tekintse meg az egészségterv menüpontban.`,
  },
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const audit = startAudit("send-notification", req);
  let callerId: string | null = null;
  let callerEmail: string | null = null;

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    // Require authentication
    const authHeader = req.headers.get("Authorization") ?? req.headers.get("authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      await audit.finish({ action: "send", statusCode: 401, severity: "warn", errorMessage: "missing bearer" });
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const token = authHeader.replace("Bearer ", "");
    const authClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: claimsRes, error: claimsErr } = await authClient.auth.getClaims(token);
    if (claimsErr || !claimsRes?.claims?.sub) {
      await audit.finish({ action: "send", statusCode: 401, severity: "warn", errorMessage: "invalid token" });
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    callerId = claimsRes.claims.sub as string;
    callerEmail = (claimsRes.claims.email as string | undefined) ?? null;
    const supabase = createClient(supabaseUrl, serviceKey);

    const payload = await req.json().catch(() => ({})) as Partial<NotificationPayload>;
    const { type, recipient_id, sender_id, data } = payload;

    if (!isUuid(recipient_id) || !isUuid(sender_id) || typeof type !== "string") {
      await audit.finish({ userId: callerId, userEmail: callerEmail, action: "send", statusCode: 400, severity: "warn", errorMessage: "validation" });
      return new Response(JSON.stringify({ error: "Invalid payload" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Caller may only send notifications under their own identity
    if (sender_id !== callerId) {
      await audit.finish({ userId: callerId, userEmail: callerEmail, action: "send", statusCode: 403, severity: "warn", errorMessage: "sender mismatch", metadata: { claimed_sender: sender_id } });
      return new Response(JSON.stringify({ error: "Forbidden: sender_id must match caller" }), {
        status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const template = TEMPLATES[type];
    if (!template) {
      await audit.finish({ userId: callerId, userEmail: callerEmail, action: "send", statusCode: 400, severity: "warn", errorMessage: `unknown type: ${type}` });
      return new Response(JSON.stringify({ error: "Unknown notification type" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }


    // 1. Insert in-app message
    const { error } = await supabase.from("messages").insert({
      sender_id,
      recipient_id,
      subject: template.subject,
      body: template.body(data),
      is_read: false,
    });
    if (error) throw error;

    // 2. Insert notification for bell UI
    const { error: notifError } = await supabase.from("notifications").insert({
      user_id: recipient_id,
      type,
      title: template.subject,
      body: template.body(data),
      link: data?.link ?? null,
    });
    if (notifError) console.error("Notification insert error:", notifError.message);

    // 3. Send transactional email via send-transactional-email
    const emailTemplateName = TEMPLATE_MAP[type];
    if (emailTemplateName) {
      try {
        const { data: userData } = await supabase.auth.admin.getUserById(recipient_id);
        if (userData?.user?.email) {
          const idempotencyKey = `${type}-${recipient_id}-${Date.now()}`;
          await supabase.functions.invoke("send-transactional-email", {
            body: {
              templateName: emailTemplateName,
              recipientEmail: userData.user.email,
              idempotencyKey,
              templateData: data ?? {},
            },
          });
          console.log(`Email queued: ${emailTemplateName} → ${userData.user.email}`);
        }
      } catch (emailErr: unknown) {
        const msg = emailErr instanceof Error ? emailErr.message : String(emailErr);
        console.error("Email send failed (non-blocking):", msg);
      }
    }

    await audit.finish({
      userId: callerId, userEmail: callerEmail, action: "send",
      resourceType: "notification", resourceId: recipient_id, statusCode: 200, severity: "info",
      metadata: { type },
    });
    return new Response(JSON.stringify({ success: true, type }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    await audit.finish({
      userId: callerId, userEmail: callerEmail, action: "send",
      statusCode: 500, severity: "error", errorMessage: (err as Error).message,
    });
    return new Response(JSON.stringify({ error: (err as Error).message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

