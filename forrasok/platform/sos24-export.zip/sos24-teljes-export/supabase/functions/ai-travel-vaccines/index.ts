import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { requireUser } from "../_shared/auth.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const auth = await requireUser(req, corsHeaders);
    if (!auth.ok) return auth.response;

    const { destination, existingVaccines } = await req.json();
    if (!destination || typeof destination !== "string") {
      return new Response(JSON.stringify({ error: "destination is required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const systemPrompt = `You are a travel medicine expert. The user wants to travel to a destination.
Based on the destination, provide vaccination recommendations.

IMPORTANT RULES:
- Always respond in Hungarian language
- Separate MANDATORY (kötelező) vaccines from RECOMMENDED (ajánlott) ones
- For each vaccine include: name, why it's needed, timing (how many weeks before travel), number of doses
- If the user already has certain vaccines, note which ones they can skip
- Include general health advice for the destination (malaria risk, food/water safety, etc.)
- Be specific to the country/region mentioned
- Use the WHO and CDC guidelines as reference

Return a JSON object with this exact structure:
{
  "destination": "country/region name",
  "mandatory": [
    { "name": "vaccine name", "reason": "why required", "timing": "when to get it", "doses": 1, "notes": "additional info" }
  ],
  "recommended": [
    { "name": "vaccine name", "reason": "why recommended", "timing": "when to get it", "doses": 1, "notes": "additional info" }
  ],
  "skippable": ["vaccine names the user already has"],
  "generalAdvice": "general health advice for the destination",
  "malariaRisk": "none/low/moderate/high",
  "malariaAdvice": "malaria prevention advice if applicable"
}`;

    const userPrompt = `Úti cél: ${destination}
${existingVaccines?.length ? `Meglévő oltások: ${existingVaccines.join(", ")}` : "Nincs korábbi oltási adat."}`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        tools: [
          {
            type: "function",
            function: {
              name: "travel_vaccine_recommendations",
              description: "Return travel vaccination recommendations",
              parameters: {
                type: "object",
                properties: {
                  destination: { type: "string" },
                  mandatory: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        name: { type: "string" },
                        reason: { type: "string" },
                        timing: { type: "string" },
                        doses: { type: "number" },
                        notes: { type: "string" },
                      },
                      required: ["name", "reason", "timing", "doses"],
                    },
                  },
                  recommended: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        name: { type: "string" },
                        reason: { type: "string" },
                        timing: { type: "string" },
                        doses: { type: "number" },
                        notes: { type: "string" },
                      },
                      required: ["name", "reason", "timing", "doses"],
                    },
                  },
                  skippable: { type: "array", items: { type: "string" } },
                  generalAdvice: { type: "string" },
                  malariaRisk: { type: "string", enum: ["none", "low", "moderate", "high"] },
                  malariaAdvice: { type: "string" },
                },
                required: ["destination", "mandatory", "recommended", "generalAdvice", "malariaRisk"],
              },
            },
          },
        ],
        tool_choice: { type: "function", function: { name: "travel_vaccine_recommendations" } },
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded" }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Payment required" }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const t = await response.text();
      console.error("AI error:", response.status, t);
      throw new Error("AI gateway error");
    }

    const result = await response.json();
    const toolCall = result.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall) throw new Error("No tool call in response");

    const recommendations = JSON.parse(toolCall.function.arguments);

    return new Response(JSON.stringify(recommendations), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("travel-vaccines error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
