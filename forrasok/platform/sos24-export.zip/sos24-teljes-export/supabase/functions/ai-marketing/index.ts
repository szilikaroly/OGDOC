import { createClient } from "https://esm.sh/@supabase/supabase-js@2.100.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const AI_URL = "https://ai.gateway.lovable.dev/v1/chat/completions";

async function callAI(system: string, prompt: string, json = false) {
  const key = Deno.env.get("LOVABLE_API_KEY");
  if (!key) throw new Error("LOVABLE_API_KEY not configured");

  const body: any = {
    model: "google/gemini-3-flash-preview",
    messages: [
      { role: "system", content: system },
      { role: "user", content: prompt },
    ],
  };
  if (json) {
    body.response_format = { type: "json_object" };
  }

  const res = await fetch(AI_URL, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${key}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const t = await res.text();
    console.error("AI error:", res.status, t);
    if (res.status === 429) throw new Error("RATE_LIMIT");
    if (res.status === 402) throw new Error("PAYMENT_REQUIRED");
    throw new Error(`AI error: ${res.status}`);
  }

  const data = await res.json();
  return data.choices?.[0]?.message?.content ?? "";
}

async function scrapeUrl(url: string): Promise<{ title: string; description: string; headings: string[]; schemaOrg: string; bodyText: string; fetchError?: string }> {
  try {
    const res = await fetch(url, {
      headers: { "User-Agent": "Mozilla/5.0 (compatible; SEOBot/1.0)" },
      redirect: "follow",
      signal: AbortSignal.timeout(10000),
    });
    const html = await res.text();
    return parseHtml(html);
  } catch (e) {
    console.error("Fetch error:", e);
    // DNS/network errors are common in edge runtime — return empty data with error note
    return {
      title: "",
      description: "",
      headings: [],
      schemaOrg: "",
      bodyText: "",
      fetchError: `Could not fetch ${url}: ${e.message}. The URL was saved but could not be scraped from the server environment. You can try again later or analyze manually.`,
    };
  }
}

function parseHtml(html: string) {
  const titleMatch = html.match(/<title[^>]*>([^<]*)<\/title>/i);
  const descMatch = html.match(/<meta[^>]*name=["']description["'][^>]*content=["']([^"']*)["']/i)
    || html.match(/<meta[^>]*content=["']([^"']*)["'][^>]*name=["']description["']/i);

  const headings: string[] = [];
  const hRe = /<h([1-6])[^>]*>([\s\S]*?)<\/h\1>/gi;
  let m;
  while ((m = hRe.exec(html)) !== null && headings.length < 30) {
    headings.push(`h${m[1]}: ${m[2].replace(/<[^>]+>/g, "").trim()}`);
  }

  const schemaBlocks: string[] = [];
  const ldRe = /<script[^>]*type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi;
  while ((m = ldRe.exec(html)) !== null) {
    schemaBlocks.push(m[1].trim());
  }

  let bodyText = html.replace(/<script[\s\S]*?<\/script>/gi, "")
    .replace(/<style[\s\S]*?<\/style>/gi, "")
    .replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  bodyText = bodyText.slice(0, 3000);

  return {
    title: titleMatch?.[1]?.trim() || "",
    description: descMatch?.[1]?.trim() || "",
    headings,
    schemaOrg: schemaBlocks.join("\n---\n"),
    bodyText,
  };
}

function getSupabase(authHeader: string) {
  return createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_ANON_KEY")!,
    { global: { headers: { Authorization: authHeader } } }
  );
}

async function verifyAdmin(authHeader: string) {
  const sb = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );
  const token = authHeader.replace("Bearer ", "");
  const { data: { user }, error } = await sb.auth.getUser(token);
  if (error || !user) throw new Error("Unauthorized");

  const { data: roles } = await sb.from("user_roles").select("role").eq("user_id", user.id);
  if (!roles?.some((r: any) => r.role === "super_admin")) throw new Error("Forbidden");
  return user.id;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization") || "";
    const userId = await verifyAdmin(authHeader);
    const { action, ...params } = await req.json();
    const sb = getSupabase(authHeader);

    let result: any;

    switch (action) {
      case "scrape_competitor": {
        const { url } = params;
        if (!url) throw new Error("URL is required");
        const scraped = await scrapeUrl(url);

        const { data: existing } = await sb.from("competitor_urls").select("id").eq("url", url).maybeSingle();
        let urlId = existing?.id;
        if (!urlId) {
          const { data: created } = await sb.from("competitor_urls").insert({ url, name: scraped.title || url, created_by: userId }).select("id").single();
          urlId = created?.id;
        }

        await sb.from("competitor_analyses").insert({
          competitor_url_id: urlId,
          analysis_type: "scrape",
          results: scraped,
          created_by: userId,
        });

        result = scraped;
        break;
      }

      case "compare_seo": {
        const { competitor_data, own_seo } = params;
        const aiResult = await callAI(
          `Foglalkozás-egészségügyi weboldalak SEO szakértője vagy. Magyar nyelven válaszolj. 
           Válaszolj JSON formátumban a következő struktúrával:
           { "comparison": [ { "aspect": "...", "own": "...", "competitor": "...", "recommendation": "..." } ], 
             "strengths": ["..."], "weaknesses": ["..."], "gaps": ["..."], "score": { "own": 0-100, "competitor": 0-100 } }`,
          `Hasonlítsd össze a saját oldal és a versenytárs SEO adatait:\n\nSaját oldal:\n${JSON.stringify(own_seo)}\n\nVersenytárs:\n${JSON.stringify(competitor_data)}`,
          true
        );

        const parsed = JSON.parse(aiResult);
        await sb.from("competitor_analyses").insert({
          competitor_url_id: params.competitor_url_id,
          analysis_type: "seo_compare",
          results: parsed,
          created_by: userId,
        });

        result = parsed;
        break;
      }

      case "content_suggestions": {
        const { competitor_data, own_services } = params;
        const aiResult = await callAI(
          `Foglalkozás-egészségügyi tartalom-stratégiai tanácsadó vagy. Magyar nyelven válaszolj.
           JSON formátumban válaszolj: { "suggestions": [ { "service": "...", "gap": "...", "recommendation": "...", "priority": "high|medium|low", "estimated_impact": "..." } ], "missing_topics": ["..."], "content_length_comparison": "..." }`,
          `A versenytárs tartalma:\n${JSON.stringify(competitor_data)}\n\nSaját szolgáltatásaink:\n${JSON.stringify(own_services)}`,
          true
        );

        const parsed = JSON.parse(aiResult);
        await sb.from("competitor_analyses").insert({
          competitor_url_id: params.competitor_url_id,
          analysis_type: "content_gap",
          results: parsed,
          created_by: userId,
        });
        result = parsed;
        break;
      }

      case "analyze_pricing": {
        const { competitor_data, own_prices } = params;
        const aiResult = await callAI(
          `Foglalkozás-egészségügyi piaci ár-elemző vagy. Magyar nyelven válaszolj.
           JSON: { "pricing_comparison": [ { "service": "...", "own_price": "...", "competitor_price": "...", "difference": "...", "recommendation": "..." } ], "promotions_found": ["..."], "market_position": "...", "pricing_strategy": "..." }`,
          `Versenytárs oldal tartalma (keress árakat, akciókat):\n${JSON.stringify(competitor_data)}\n\nSaját áraink:\n${JSON.stringify(own_prices)}`,
          true
        );

        const parsed = JSON.parse(aiResult);
        await sb.from("competitor_analyses").insert({
          competitor_url_id: params.competitor_url_id,
          analysis_type: "pricing",
          results: parsed,
          created_by: userId,
        });
        result = parsed;
        break;
      }

      case "predict_trends": {
        const { analyses_history, market_context } = params;
        const aiResult = await callAI(
          `Foglalkozás-egészségügyi marketing trend-elemző vagy Magyarországon. Magyar nyelven válaszolj.
           JSON: { "trends": [ { "trend": "...", "direction": "rising|stable|declining", "impact": "high|medium|low", "timeframe": "..." } ], "competition_intensity": { "overall": "high|medium|low", "by_keyword": [ { "keyword": "...", "intensity": "...", "recommendation": "..." } ] }, "seasonal_patterns": ["..."], "focus_areas": ["..."], "warnings": ["..."] }`,
          `Korábbi elemzések:\n${JSON.stringify(analyses_history)}\n\nPiaci kontextus:\n${JSON.stringify(market_context)}`,
          true
        );

        const parsed = JSON.parse(aiResult);
        await sb.from("competitor_analyses").insert({
          analysis_type: "trend",
          results: parsed,
          created_by: userId,
        });
        result = parsed;
        break;
      }

      case "generate_report": {
        const { analyses } = params;
        const aiResult = await callAI(
          `Foglalkozás-egészségügyi marketing riport készítő vagy. Magyar nyelven készíts executive summary-t markdown formátumban.
           Tartalmazza: összefoglaló, versenykörnyezet, erősségek/gyengeségek, javaslatok, prioritások, következő lépések.`,
          `Az összes elemzés eredménye:\n${JSON.stringify(analyses)}`
        );

        result = { report_markdown: aiResult };
        await sb.from("competitor_analyses").insert({
          analysis_type: "report",
          results: result,
          created_by: userId,
        });
        break;
      }

      case "search_competitors": {
        const { scope, city } = params;
        if (scope === "local" && !city) throw new Error("City is required for local search");

        const searchPrompt = scope === "local"
          ? `Keress foglalkozás-egészségügyi szolgáltatókat, üzemorvosokat, munkaegészségügyi cégeket a következő városban: ${city}, Magyarország.
             Keresési kifejezések: "üzemorvos ${city}", "foglalkozás-egészségügyi vizsgálat ${city}", "munkaegészségügyi szolgálat ${city}", "üzemorvosi rendelő ${city}".
             Listázz valós, ismert szolgáltatókat URL-lel, ha ismered őket. Ha nem ismersz konkrét URL-t, adj meg valószínű/kereshető neveket.`
          : `Keress országos szinten ismert foglalkozás-egészségügyi szolgáltatókat, üzemorvosi hálózatokat Magyarországon.
             Keresési kifejezések: "foglalkozás-egészségügyi szolgáltató Magyarország", "üzemorvosi hálózat", "munkaegészségügyi központ", "occupational health Hungary".
             Listázz valós, ismert szolgáltatókat URL-lel.`;

        const aiResult = await callAI(
          `Foglalkozás-egészségügyi piackutató vagy Magyarországon. Magyar nyelven válaszolj.
           JSON formátumban válaszolj: { "competitors": [ { "url": "https://...", "name": "...", "description": "...", "relevance": "high|medium|low", "city": "..." } ] }
           Csak valós, létező vagy nagy valószínűséggel létező szolgáltatókat adj meg. Ha nem vagy biztos egy URL-ben, jelezd a description mezőben.`,
          searchPrompt,
          true
        );

        const parsed = JSON.parse(aiResult);

        await sb.from("competitor_analyses").insert({
          analysis_type: "search",
          results: { scope, city: city || null, ...parsed },
          created_by: userId,
        });

        result = parsed;
        break;
      }

      default:
        throw new Error(`Unknown action: ${action}`);
    }

    return new Response(JSON.stringify({ success: true, data: result }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("ai-marketing error:", e);
    const status = e.message === "RATE_LIMIT" ? 429 : e.message === "PAYMENT_REQUIRED" ? 402 : e.message === "Unauthorized" ? 401 : e.message === "Forbidden" ? 403 : 500;
    return new Response(JSON.stringify({ success: false, error: e.message }), {
      status,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
