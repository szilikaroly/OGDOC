import * as React from 'npm:react@18.3.1'
import {
  Body, Container, Head, Heading, Html, Preview, Text, Hr, Section,
} from 'npm:@react-email/components@0.0.22'
import type { TemplateEntry } from './registry.ts'

const SITE_NAME = "SOS-24 Üzemorvos"

interface Props {
  exam_reason?: string
  company?: string
  employee_name?: string
}

const ReferralReceivedEmail = ({ exam_reason, company, employee_name }: Props) => (
  <Html lang="hu" dir="ltr">
    <Head />
    <Preview>Új beutaló érkezett – {SITE_NAME}</Preview>
    <Body style={main}>
      <Container style={container}>
        <Section style={header}>
          <Heading style={h1}>{SITE_NAME}</Heading>
        </Section>
        <Heading style={h2}>Új beutaló érkezett</Heading>
        <Text style={text}>
          Új foglalkozás-egészségügyi beutaló érkezett az Ön részére.
        </Text>
        {employee_name && <Text style={detail}><strong>Munkavállaló:</strong> {employee_name}</Text>}
        {company && <Text style={detail}><strong>Munkáltató:</strong> {company}</Text>}
        {exam_reason && <Text style={detail}><strong>Vizsgálat típusa:</strong> {exam_reason}</Text>}
        <Text style={text}>
          Kérjük, lépjen be a rendszerbe az időpont egyeztetéséhez.
        </Text>
        <Hr style={hr} />
        <Text style={footer}>Üdvözlettel, {SITE_NAME} csapata</Text>
      </Container>
    </Body>
  </Html>
)

export const template = {
  component: ReferralReceivedEmail,
  subject: 'Új beutaló érkezett',
  displayName: 'Beutaló értesítés',
  previewData: { exam_reason: 'Előzetes vizsgálat', company: 'Teszt Kft.', employee_name: 'Kovács János' },
} satisfies TemplateEntry

const main = { backgroundColor: '#ffffff', fontFamily: "'Inter', Arial, sans-serif" }
const container = { padding: '0', maxWidth: '560px', margin: '0 auto' }
const header = { backgroundColor: '#1a2744', padding: '24px 25px', borderRadius: '8px 8px 0 0' }
const h1 = { color: '#c6973f', fontSize: '20px', fontFamily: "'Playfair Display', Georgia, serif", margin: '0', fontWeight: '600' as const }
const h2 = { fontSize: '20px', color: '#1a2744', margin: '24px 25px 8px', fontWeight: '600' as const }
const text = { fontSize: '14px', color: '#55575d', lineHeight: '1.6', margin: '0 25px 16px' }
const detail = { fontSize: '14px', color: '#333', lineHeight: '1.6', margin: '0 25px 6px' }
const hr = { borderColor: '#e5e7eb', margin: '24px 25px' }
const footer = { fontSize: '12px', color: '#999', margin: '0 25px 24px' }
