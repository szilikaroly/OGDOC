import * as React from 'npm:react@18.3.1'
import {
  Body, Container, Head, Heading, Html, Preview, Text, Button, Hr, Section,
} from 'npm:@react-email/components@0.0.22'
import type { TemplateEntry } from './registry.ts'

const SITE_NAME = "SOS-24 Üzemorvos"

interface Props {
  date?: string
  service?: string
  location?: string
}

const AppointmentConfirmedEmail = ({ date, service, location }: Props) => (
  <Html lang="hu" dir="ltr">
    <Head />
    <Preview>Időpontja megerősítve – {SITE_NAME}</Preview>
    <Body style={main}>
      <Container style={container}>
        <Section style={header}>
          <Heading style={h1}>{SITE_NAME}</Heading>
        </Section>
        <Heading style={h2}>Időpont megerősítve</Heading>
        <Text style={text}>
          Az Ön időpontja sikeresen megerősítésre került.
        </Text>
        {date && <Text style={detail}><strong>Dátum:</strong> {date}</Text>}
        {service && <Text style={detail}><strong>Szolgáltatás:</strong> {service}</Text>}
        {location && <Text style={detail}><strong>Helyszín:</strong> {location}</Text>}
        <Text style={text}>
          Kérjük, jelenjen meg a megadott időpontban. Amennyiben lemondaná, kérjük legalább 24 órával előtte jelezze.
        </Text>
        <Hr style={hr} />
        <Text style={footer}>Üdvözlettel, {SITE_NAME} csapata</Text>
      </Container>
    </Body>
  </Html>
)

export const template = {
  component: AppointmentConfirmedEmail,
  subject: 'Időpont megerősítve',
  displayName: 'Időpont megerősítés',
  previewData: { date: '2026-04-15 10:00', service: 'Előzetes alkalmassági vizsgálat', location: 'Budapest, Fő utca 12.' },
} satisfies TemplateEntry

const main = { backgroundColor: '#ffffff', fontFamily: "'Inter', Arial, sans-serif" }
const container = { padding: '0', maxWidth: '560px', margin: '0 auto' }
const header = { backgroundColor: '#1a2744', padding: '24px 25px', borderRadius: '8px 8px 0 0' }
const h1 = { color: '#c6973f', fontSize: '20px', fontFamily: "'Playfair Display', Georgia, serif", margin: '0', fontWeight: '600' as const }
const h2 = { fontSize: '20px', color: '#1a2744', margin: '24px 25px 8px', fontWeight: '600' as const }
const text = { fontSize: '14px', color: '#55575d', lineHeight: '1.6', margin: '0 25px 16px' }
const detail = { fontSize: '14px', color: '#333', lineHeight: '1.6', margin: '0 25px 6px' }
const hr = { borderColor: '#e5e7eb', margin: '24px 25px' }
const footer = { fontSize: '12px', color: '#999', margin: '0 25px 24px' }
