import * as React from 'npm:react@18.3.1'
import {
  Body, Container, Head, Heading, Html, Preview, Text, Button, Hr, Section,
} from 'npm:@react-email/components@0.0.22'
import type { TemplateEntry } from './registry.ts'

const SITE_NAME = "SOS-24 Üzemorvos"

interface Props {
  patientName?: string
  eventTitle?: string
  eventDate?: string
  location?: string
  description?: string
}

const HealthDayInvitationEmail = ({ patientName, eventTitle, eventDate, location, description }: Props) => (
  <Html lang="hu" dir="ltr">
    <Head />
    <Preview>Egészségnap meghívó – {SITE_NAME}</Preview>
    <Body style={main}>
      <Container style={container}>
        <Section style={header}>
          <Heading style={h1}>{SITE_NAME}</Heading>
        </Section>
        <Heading style={h2}>{eventTitle || 'Egészségnap'}</Heading>
        <Text style={text}>
          {patientName ? `Kedves ${patientName}!` : 'Tisztelt Páciensünk!'}
        </Text>
        <Text style={text}>
          Szeretettel meghívjuk Önt közelgő egészségnapunkra!
        </Text>
        {eventDate && <Text style={detail}><strong>Időpont:</strong> {eventDate}</Text>}
        {location && <Text style={detail}><strong>Helyszín:</strong> {location}</Text>}
        {description && <Text style={text}>{description}</Text>}
        <Section style={{ textAlign: 'center' as const, margin: '24px 0' }}>
          <Button style={button} href="{{siteUrl}}/munkavallalo/appointments">
            Jelentkezés
          </Button>
        </Section>
        <Text style={text}>
          A részvétel ingyenes, de regisztráció szükséges. Várjuk szeretettel!
        </Text>
        <Hr style={hr} />
        <Text style={footer}>Üdvözlettel, {SITE_NAME} csapata</Text>
      </Container>
    </Body>
  </Html>
)

export const template = {
  component: HealthDayInvitationEmail,
  subject: (data) => data?.eventTitle ? `Meghívó: ${data.eventTitle}` : 'Egészségnap meghívó',
  displayName: 'Egészségnap meghívó',
  previewData: { patientName: 'Tóth Éva', eventTitle: 'Tavaszi Egészségnap 2026', eventDate: '2026. május 15. 09:00-15:00', location: 'SOS-24 Rendelő, Budapest', description: 'Ingyenes szűrővizsgálatok, vércukormérés, vérnyomásmérés és dietetikus tanácsadás.' },
} satisfies TemplateEntry

const main = { backgroundColor: '#ffffff', fontFamily: "'Inter', Arial, sans-serif" }
const container = { padding: '0', maxWidth: '560px', margin: '0 auto' }
const header = { backgroundColor: '#1a2744', padding: '24px 25px', borderRadius: '8px 8px 0 0' }
const h1 = { color: '#c6973f', fontSize: '20px', fontFamily: "'Playfair Display', Georgia, serif", margin: '0', fontWeight: '600' as const }
const h2 = { fontSize: '20px', color: '#1a2744', margin: '24px 25px 8px', fontWeight: '600' as const }
const text = { fontSize: '14px', color: '#55575d', lineHeight: '1.6', margin: '0 25px 16px' }
const detail = { fontSize: '14px', color: '#333', lineHeight: '1.6', margin: '0 25px 6px' }
const button = { backgroundColor: '#c6973f', color: '#ffffff', padding: '12px 24px', borderRadius: '6px', fontSize: '14px', fontWeight: '600' as const, textDecoration: 'none' }
const hr = { borderColor: '#e5e7eb', margin: '24px 25px' }
const footer = { fontSize: '12px', color: '#999', margin: '0 25px 24px' }
