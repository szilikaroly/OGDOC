import * as React from 'npm:react@18.3.1'
import {
  Body, Container, Head, Heading, Html, Preview, Text, Button, Hr, Section,
} from 'npm:@react-email/components@0.0.22'
import type { TemplateEntry } from './registry.ts'

const SITE_NAME = "SOS-24 Üzemorvos"

interface Props {
  patientName?: string
  title?: string
  message?: string
  ctaLabel?: string
  ctaUrl?: string
}

const GeneralNotificationEmail = ({ patientName, title, message, ctaLabel, ctaUrl }: Props) => (
  <Html lang="hu" dir="ltr">
    <Head />
    <Preview>{title || 'Értesítés'} – {SITE_NAME}</Preview>
    <Body style={main}>
      <Container style={container}>
        <Section style={header}>
          <Heading style={h1}>{SITE_NAME}</Heading>
        </Section>
        <Heading style={h2}>{title || 'Értesítés'}</Heading>
        <Text style={text}>
          {patientName ? `Kedves ${patientName}!` : 'Tisztelt Páciensünk!'}
        </Text>
        {message && <Text style={text}>{message}</Text>}
        {ctaLabel && ctaUrl && (
          <Section style={{ textAlign: 'center' as const, margin: '24px 0' }}>
            <Button style={button} href={ctaUrl}>
              {ctaLabel}
            </Button>
          </Section>
        )}
        <Hr style={hr} />
        <Text style={footer}>Üdvözlettel, {SITE_NAME} csapata</Text>
      </Container>
    </Body>
  </Html>
)

export const template = {
  component: GeneralNotificationEmail,
  subject: (data) => data?.title || 'Értesítés',
  displayName: 'Általános értesítés',
  previewData: { patientName: 'Kiss János', title: 'Fontos tájékoztatás', message: 'Ez egy egyedi értesítés sablon, amelyet tetszőleges tartalommal tölthet ki.', ctaLabel: 'Részletek megtekintése', ctaUrl: 'https://sos24.lovable.app' },
} satisfies TemplateEntry

const main = { backgroundColor: '#ffffff', fontFamily: "'Inter', Arial, sans-serif" }
const container = { padding: '0', maxWidth: '560px', margin: '0 auto' }
const header = { backgroundColor: '#1a2744', padding: '24px 25px', borderRadius: '8px 8px 0 0' }
const h1 = { color: '#c6973f', fontSize: '20px', fontFamily: "'Playfair Display', Georgia, serif", margin: '0', fontWeight: '600' as const }
const h2 = { fontSize: '20px', color: '#1a2744', margin: '24px 25px 8px', fontWeight: '600' as const }
const text = { fontSize: '14px', color: '#55575d', lineHeight: '1.6', margin: '0 25px 16px' }
const button = { backgroundColor: '#c6973f', color: '#ffffff', padding: '12px 24px', borderRadius: '6px', fontSize: '14px', fontWeight: '600' as const, textDecoration: 'none' }
const hr = { borderColor: '#e5e7eb', margin: '24px 25px' }
const footer = { fontSize: '12px', color: '#999', margin: '0 25px 24px' }
