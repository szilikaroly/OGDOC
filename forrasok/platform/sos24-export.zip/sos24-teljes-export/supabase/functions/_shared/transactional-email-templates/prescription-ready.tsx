import * as React from 'npm:react@18.3.1'
import {
  Body, Container, Head, Heading, Html, Preview, Text, Hr, Section,
} from 'npm:@react-email/components@0.0.22'
import type { TemplateEntry } from './registry.ts'

const SITE_NAME = "SOS-24 Üzemorvos"

interface Props {
  patientName?: string
  medication?: string
  doctorName?: string
  pharmacy?: string
}

const PrescriptionReadyEmail = ({ patientName, medication, doctorName, pharmacy }: Props) => (
  <Html lang="hu" dir="ltr">
    <Head />
    <Preview>Recept kiállítva – {SITE_NAME}</Preview>
    <Body style={main}>
      <Container style={container}>
        <Section style={header}>
          <Heading style={h1}>{SITE_NAME}</Heading>
        </Section>
        <Heading style={h2}>Receptje elkészült</Heading>
        <Text style={text}>
          {patientName ? `Kedves ${patientName}!` : 'Tisztelt Páciensünk!'}
        </Text>
        <Text style={text}>
          Tájékoztatjuk, hogy az Ön által kért recept sikeresen kiállításra került.
        </Text>
        {medication && <Text style={detail}><strong>Gyógyszer:</strong> {medication}</Text>}
        {doctorName && <Text style={detail}><strong>Felíró orvos:</strong> {doctorName}</Text>}
        {pharmacy && <Text style={detail}><strong>Patika:</strong> {pharmacy}</Text>}
        <Text style={text}>
          Az e-recept az EESZT rendszerben elérhető, a patikában a TAJ kártyájával kiváltható.
        </Text>
        <Hr style={hr} />
        <Text style={footer}>Üdvözlettel, {SITE_NAME} csapata</Text>
      </Container>
    </Body>
  </Html>
)

export const template = {
  component: PrescriptionReadyEmail,
  subject: 'Receptje elkészült',
  displayName: 'Recept kiállítva',
  previewData: { patientName: 'Szabó Péter', medication: 'Enalapril 10mg', doctorName: 'Dr. Nagy István', pharmacy: 'Gyógyszertár Online' },
} satisfies TemplateEntry

const main = { backgroundColor: '#ffffff', fontFamily: "'Inter', Arial, sans-serif" }
const container = { padding: '0', maxWidth: '560px', margin: '0 auto' }
const header = { backgroundColor: '#1a2744', padding: '24px 25px', borderRadius: '8px 8px 0 0' }
const h1 = { color: '#c6973f', fontSize: '20px', fontFamily: "'Playfair Display', Georgia, serif", margin: '0', fontWeight: '600' as const }
const h2 = { fontSize: '20px', color: '#1a2744', margin: '24px 25px 8px', fontWeight: '600' as const }
const text = { fontSize: '14px', color: '#55575d', lineHeight: '1.6', margin: '0 25px 16px' }
const detail = { fontSize: '14px', color: '#333', lineHeight: '1.6', margin: '0 25px 6px' }
const hr = { borderColor: '#e5e7eb', margin: '24px 25px' }
const footer = { fontSize: '12px', color: '#999', margin: '0 25px 24px' }
