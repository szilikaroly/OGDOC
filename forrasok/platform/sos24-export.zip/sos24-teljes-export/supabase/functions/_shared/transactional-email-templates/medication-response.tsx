import * as React from 'npm:react@18.3.1'
import {
  Body, Container, Head, Heading, Html, Preview, Text, Hr, Section,
} from 'npm:@react-email/components@0.0.22'
import type { TemplateEntry } from './registry.ts'

const SITE_NAME = "SOS-24 Üzemorvos"

interface Props {
  medication?: string
  status?: string
  response?: string
}

const MedicationResponseEmail = ({ medication, status, response }: Props) => {
  const statusText = status === 'approved' ? 'Elfogadva' : status === 'rejected' ? 'Elutasítva' : status
  return (
    <Html lang="hu" dir="ltr">
      <Head />
      <Preview>Receptkérés megválaszolva – {SITE_NAME}</Preview>
      <Body style={main}>
        <Container style={container}>
          <Section style={header}>
            <Heading style={h1}>{SITE_NAME}</Heading>
          </Section>
          <Heading style={h2}>Receptkérés megválaszolva</Heading>
          <Text style={text}>
            A háziorvos megválaszolta az Ön receptkérését.
          </Text>
          {medication && <Text style={detail}><strong>Gyógyszer:</strong> {medication}</Text>}
          {statusText && <Text style={detail}><strong>Státusz:</strong> {statusText}</Text>}
          {response && <Text style={detail}><strong>Orvos válasza:</strong> {response}</Text>}
          <Text style={text}>
            További részletekért lépjen be fiókjába.
          </Text>
          <Hr style={hr} />
          <Text style={footer}>Üdvözlettel, {SITE_NAME} csapata</Text>
        </Container>
      </Body>
    </Html>
  )
}

export const template = {
  component: MedicationResponseEmail,
  subject: 'Receptkérés megválaszolva',
  displayName: 'Receptkérés válasz',
  previewData: { medication: 'Enalapril 10mg', status: 'approved', response: 'Kiállítva, gyógyszertárban átvehető.' },
} satisfies TemplateEntry

const main = { backgroundColor: '#ffffff', fontFamily: "'Inter', Arial, sans-serif" }
const container = { padding: '0', maxWidth: '560px', margin: '0 auto' }
const header = { backgroundColor: '#1a2744', padding: '24px 25px', borderRadius: '8px 8px 0 0' }
const h1 = { color: '#c6973f', fontSize: '20px', fontFamily: "'Playfair Display', Georgia, serif", margin: '0', fontWeight: '600' as const }
const h2 = { fontSize: '20px', color: '#1a2744', margin: '24px 25px 8px', fontWeight: '600' as const }
const text = { fontSize: '14px', color: '#55575d', lineHeight: '1.6', margin: '0 25px 16px' }
const detail = { fontSize: '14px', color: '#333', lineHeight: '1.6', margin: '0 25px 6px' }
const hr = { borderColor: '#e5e7eb', margin: '24px 25px' }
const footer = { fontSize: '12px', color: '#999', margin: '0 25px 24px' }
