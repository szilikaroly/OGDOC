/// <reference types="npm:@types/react@18.3.1" />
import * as React from 'npm:react@18.3.1'

export interface TemplateEntry {
  component: React.ComponentType<any>
  subject: string | ((data: Record<string, any>) => string)
  to?: string
  displayName?: string
  previewData?: Record<string, any>
}

import { template as appointmentConfirmed } from './appointment-confirmed.tsx'
import { template as referralReceived } from './referral-received.tsx'
import { template as opinionReady } from './opinion-ready.tsx'
import { template as medicationResponse } from './medication-response.tsx'
import { template as labControlReminder } from './lab-control-reminder.tsx'
import { template as prescriptionReady } from './prescription-ready.tsx'
import { template as healthDayInvitation } from './health-day-invitation.tsx'
import { template as generalNotification } from './general-notification.tsx'

export const TEMPLATES: Record<string, TemplateEntry> = {
  'appointment-confirmed': appointmentConfirmed,
  'referral-received': referralReceived,
  'opinion-ready': opinionReady,
  'medication-response': medicationResponse,
  'lab-control-reminder': labControlReminder,
  'prescription-ready': prescriptionReady,
  'health-day-invitation': healthDayInvitation,
  'general-notification': generalNotification,
}
