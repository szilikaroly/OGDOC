import * as React from 'npm:react@18.3.1'
import {
  Body, Container, Head, Heading, Html, Preview, Text, Hr, Section,
} from 'npm:@react-email/components@0.0.22'
import type { TemplateEntry } from './registry.ts'

const SITE_NAME = "SOS-24 Üzemorvos"

interface Props {
  result?: string
  valid_until?: string
  patient_name?: string
}

const OpinionReadyEmail = ({ result, valid_until, patient_name }: Props) => (
  <Html lang="hu" dir="ltr">
    <Head />
    <Preview>Alkalmassági vélemény elkészült – {SITE_NAME}</Preview>
    <Body style={main}>
      <Container style={container}>
        <Section style={header}>
          <Heading style={h1}>{SITE_NAME}</Heading>
        </Section>
        <Heading style={h2}>Alkalmassági vélemény elkészült</Heading>
        <Text style={text}>
          {patient_name ? `Kedves ${patient_name}!` : 'Tisztelt Páciensünk!'}
        </Text>
        <Text style={text}>
          Az Ön alkalmassági véleménye elkészült és megtekinthető a rendszerben.
        </Text>
        {result && <Text style={detail}><strong>Eredmény:</strong> {result}</Text>}
        {valid_until && <Text style={detail}><strong>Érvényes:</strong> {valid_until}</Text>}
        <Text style={text}>
          A vélemény letölthető PDF formátumban a fiókjából.
        </Text>
        <Hr style={hr} />
        <Text style={footer}>Üdvözlettel, {SITE_NAME} csapata</Text>
      </Container>
    </Body>
  </Html>
)

export const template = {
  component: OpinionReadyEmail,
  subject: 'Alkalmassági vélemény elkészült',
  displayName: 'Vélemény értesítés',
  previewData: { result: 'Alkalmas', valid_until: '2027-04-15', patient_name: 'Szabó Anna' },
} satisfies TemplateEntry

const main = { backgroundColor: '#ffffff', fontFamily: "'Inter', Arial, sans-serif" }
const container = { padding: '0', maxWidth: '560px', margin: '0 auto' }
const header = { backgroundColor: '#1a2744', padding: '24px 25px', borderRadius: '8px 8px 0 0' }
const h1 = { color: '#c6973f', fontSize: '20px', fontFamily: "'Playfair Display', Georgia, serif", margin: '0', fontWeight: '600' as const }
const h2 = { fontSize: '20px', color: '#1a2744', margin: '24px 25px 8px', fontWeight: '600' as const }
const text = { fontSize: '14px', color: '#55575d', lineHeight: '1.6', margin: '0 25px 16px' }
const detail = { fontSize: '14px', color: '#333', lineHeight: '1.6', margin: '0 25px 6px' }
const hr = { borderColor: '#e5e7eb', margin: '24px 25px' }
const footer = { fontSize: '12px', color: '#999', margin: '0 25px 24px' }
