import * as React from 'npm:react@18.3.1'
import {
  Body, Container, Head, Heading, Html, Preview, Text, Button, Hr, Section,
} from 'npm:@react-email/components@0.0.22'
import type { TemplateEntry } from './registry.ts'

const SITE_NAME = "SOS-24 Üzemorvos"

interface Props {
  patientName?: string
  testType?: string
  dueDate?: string
  doctorName?: string
}

const LabControlReminderEmail = ({ patientName, testType, dueDate, doctorName }: Props) => (
  <Html lang="hu" dir="ltr">
    <Head />
    <Preview>Labor kontroll emlékeztető – {SITE_NAME}</Preview>
    <Body style={main}>
      <Container style={container}>
        <Section style={header}>
          <Heading style={h1}>{SITE_NAME}</Heading>
        </Section>
        <Heading style={h2}>Labor kontroll szükséges</Heading>
        <Text style={text}>
          {patientName ? `Kedves ${patientName}!` : 'Tisztelt Páciensünk!'}
        </Text>
        <Text style={text}>
          Ezúton emlékeztetjük, hogy esedékes a labor kontroll vizsgálata.
        </Text>
        {testType && <Text style={detail}><strong>Vizsgálat típusa:</strong> {testType}</Text>}
        {dueDate && <Text style={detail}><strong>Esedékesség:</strong> {dueDate}</Text>}
        {doctorName && <Text style={detail}><strong>Kezelőorvos:</strong> {doctorName}</Text>}
        <Section style={{ textAlign: 'center' as const, margin: '24px 0' }}>
          <Button style={button} href="{{siteUrl}}/munkavallalo/appointments">
            Időpont foglalás
          </Button>
        </Section>
        <Text style={text}>
          Kérjük, mielőbb foglaljon időpontot a vizsgálatra. Éhgyomorra érkezzék!
        </Text>
        <Hr style={hr} />
        <Text style={footer}>Üdvözlettel, {SITE_NAME} csapata</Text>
      </Container>
    </Body>
  </Html>
)

export const template = {
  component: LabControlReminderEmail,
  subject: 'Labor kontroll emlékeztető',
  displayName: 'Labor kontroll emlékeztető',
  previewData: { patientName: 'Kovács Anna', testType: 'Vérkép + lipidpanel', dueDate: '2026-04-20', doctorName: 'Dr. Nagy István' },
} satisfies TemplateEntry

const main = { backgroundColor: '#ffffff', fontFamily: "'Inter', Arial, sans-serif" }
const container = { padding: '0', maxWidth: '560px', margin: '0 auto' }
const header = { backgroundColor: '#1a2744', padding: '24px 25px', borderRadius: '8px 8px 0 0' }
const h1 = { color: '#c6973f', fontSize: '20px', fontFamily: "'Playfair Display', Georgia, serif", margin: '0', fontWeight: '600' as const }
const h2 = { fontSize: '20px', color: '#1a2744', margin: '24px 25px 8px', fontWeight: '600' as const }
const text = { fontSize: '14px', color: '#55575d', lineHeight: '1.6', margin: '0 25px 16px' }
const detail = { fontSize: '14px', color: '#333', lineHeight: '1.6', margin: '0 25px 6px' }
const button = { backgroundColor: '#c6973f', color: '#ffffff', padding: '12px 24px', borderRadius: '6px', fontSize: '14px', fontWeight: '600' as const, textDecoration: 'none' }
const hr = { borderColor: '#e5e7eb', margin: '24px 25px' }
const footer = { fontSize: '12px', color: '#999', margin: '0 25px 24px' }
