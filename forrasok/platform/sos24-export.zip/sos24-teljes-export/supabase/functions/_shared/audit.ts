// Shared audit helper for edge functions.
// Writes a row to public.security_events with service-role privileges so the
// admin UI can show "who called which function, when, on which resource".
// Never logs raw passwords / tokens — only IDs, emails, status, error_message.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

export interface AuditEntry {
  functionName: string;
  action: string; // e.g. "create_user", "send_notification", "generate_pdf"
  resourceType?: string | null; // e.g. "user", "company", "opinion"
  resourceId?: string | null;
  userId?: string | null;
  userEmail?: string | null;
  statusCode?: number | null;
  durationMs?: number | null;
  severity?: "info" | "warn" | "error" | "critical";
  errorMessage?: string | null;
  metadata?: Record<string, unknown>;
  route?: string | null;
  userAgent?: string | null;
}

const SUPABASE_URL = Deno.env.get("SUPABASE_URL") ?? "";
const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";

let _client: ReturnType<typeof createClient> | null = null;
function getClient() {
  if (!_client) _client = createClient(SUPABASE_URL, SERVICE_ROLE);
  return _client;
}

// Strip obviously secret-looking fields before persisting metadata.
const SECRET_KEYS = /pass(word)?|token|secret|api[_-]?key|authorization/i;
function redact(value: unknown): unknown {
  if (value == null) return value;
  if (Array.isArray(value)) return value.map(redact);
  if (typeof value === "object") {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value)) {
      out[k] = SECRET_KEYS.test(k) ? "[redacted]" : redact(v);
    }
    return out;
  }
  if (typeof value === "string" && value.length > 2000) {
    return value.slice(0, 2000) + "…";
  }
  return value;
}

export async function logAudit(entry: AuditEntry): Promise<void> {
  try {
    const client = getClient();
    const severity =
      entry.severity ??
      (entry.statusCode && entry.statusCode >= 500
        ? "error"
        : entry.statusCode && entry.statusCode >= 400
          ? "warn"
          : "info");

    await client.from("security_events").insert({
      event_type: "edge_function_call",
      severity,
      user_id: entry.userId ?? null,
      user_email: entry.userEmail ?? null,
      function_name: entry.functionName,
      action: entry.action,
      resource_type: entry.resourceType ?? null,
      resource_id: entry.resourceId ?? null,
      status_code: entry.statusCode ?? null,
      duration_ms: entry.durationMs ?? null,
      error_message: entry.errorMessage ? String(entry.errorMessage).slice(0, 2000) : null,
      route: entry.route ?? null,
      user_agent: entry.userAgent ? String(entry.userAgent).slice(0, 500) : null,
      metadata: (redact(entry.metadata ?? {}) as Record<string, unknown>) ?? {},
    });
  } catch (err) {
    // Auditing must never break the calling function.
    console.error("[audit] failed to write audit event:", err);
  }
}

// Convenience wrapper for the most common pattern.
export function startAudit(functionName: string, req: Request) {
  const startedAt = Date.now();
  const route = new URL(req.url).pathname;
  const userAgent = req.headers.get("user-agent") ?? null;
  return {
    finish: (entry: Omit<AuditEntry, "functionName" | "route" | "userAgent" | "durationMs">) =>
      logAudit({
        ...entry,
        functionName,
        route,
        userAgent,
        durationMs: Date.now() - startedAt,
      }),
  };
}
