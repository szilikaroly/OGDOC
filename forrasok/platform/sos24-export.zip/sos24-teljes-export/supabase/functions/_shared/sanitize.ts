// Server-side HTML sanitizer for content that may be embedded in PDFs,
// emails or echoed back to the client. Allow-list based: strips scripts,
// iframes, event handlers, javascript: URLs, style/class attributes.
//
// Uses isomorphic-dompurify via npm: specifier so it works in Deno/Edge.

import createDOMPurify from "npm:isomorphic-dompurify@2.16.0";

const purify = createDOMPurify;

const ALLOWED_TAGS = [
  "p", "br", "strong", "em", "u", "ul", "ol", "li",
  "h1", "h2", "h3", "h4", "h5", "h6",
  "blockquote", "a", "code", "pre", "hr", "span", "div",
];
const ALLOWED_ATTR = ["href", "title", "target", "rel"];

export function sanitizeHtml(input: unknown, maxLength = 50_000): string {
  if (input == null) return "";
  const raw = String(input);
  if (raw.length > maxLength) {
    throw new Error(`HTML input exceeds ${maxLength} bytes`);
  }
  const clean = purify.sanitize(raw, {
    ALLOWED_TAGS,
    ALLOWED_ATTR,
    FORBID_TAGS: ["script", "style", "iframe", "object", "embed", "form", "input"],
    FORBID_ATTR: ["style", "onerror", "onload", "onclick", "onmouseover"],
    ALLOW_DATA_ATTR: false,
  }) as string;
  // Force external links safe
  return clean.replace(
    /<a\s+([^>]*?)>/gi,
    (_m, attrs) => `<a ${attrs} rel="noopener noreferrer nofollow">`,
  );
}

// Plain-text fallback: strip ALL tags. Use when embedding into PDFs.
export function stripHtml(input: unknown, maxLength = 50_000): string {
  if (input == null) return "";
  const raw = String(input).slice(0, maxLength);
  const cleaned = purify.sanitize(raw, { ALLOWED_TAGS: [], ALLOWED_ATTR: [] }) as string;
  return cleaned.replace(/\s+/g, " ").trim();
}
