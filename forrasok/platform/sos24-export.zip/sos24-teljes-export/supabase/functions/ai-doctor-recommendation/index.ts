import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.100.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const anonClient = createClient(supabaseUrl, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: { user }, error: userError } = await anonClient.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const { type, patient_id, duration_days, notes } = await req.json();

    if (!type || !patient_id) {
      return new Response(JSON.stringify({ error: "type and patient_id required" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // Authorization: caller must be the patient OR have a clinician/admin role
    // OR (for munkaltato role) be the employer of that patient.
    let authorized = user.id === patient_id;
    if (!authorized) {
      const { data: roles } = await supabase.from("user_roles").select("role").eq("user_id", user.id);
      const roleSet = new Set((roles ?? []).map((r: { role: string }) => r.role));
      if (roleSet.has("super_admin") || roleSet.has("uzemorvos") || roleSet.has("haziorvos")) {
        authorized = true;
      } else if (roleSet.has("munkaltato")) {
        const { data: ok } = await supabase.rpc("is_employer_of_patient", {
          _employer_id: user.id,
          _patient_id: patient_id,
        });
        authorized = !!ok;
      }
    }
    if (!authorized) {
      return new Response(JSON.stringify({ error: "Forbidden" }), { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // Gather patient data
    const [
      { data: profile },
      { data: patientCard },
      { data: healthJournal },
      { data: foodJournal },
      { data: stoolJournal },
      { data: submissions },
      { data: medications },
      { data: vaccinations },
      { data: healthReports },
    ] = await Promise.all([
      supabase.from("profiles").select("*").eq("user_id", patient_id).single(),
      supabase.from("patient_cards").select("*").eq("user_id", patient_id).single(),
      supabase.from("health_journal").select("*").eq("user_id", patient_id).order("entry_date", { ascending: false }).limit(30),
      supabase.from("food_journal").select("*").eq("user_id", patient_id).order("entry_date", { ascending: false }).limit(30),
      supabase.from("stool_journal").select("*").eq("user_id", patient_id).order("entry_date", { ascending: false }).limit(14),
      supabase.from("questionnaire_submissions").select("id, questionnaire_id, answers, score, risk_category, ai_evaluation, submitted_at").eq("user_id", patient_id).order("submitted_at", { ascending: false }).limit(10),
      supabase.from("medication_requests").select("*").eq("patient_id", patient_id).eq("status", "approved"),
      supabase.from("vaccinations").select("*").eq("user_id", patient_id).order("administered_date", { ascending: false }),
      supabase.from("health_reports").select("*").eq("user_id", patient_id).order("report_date", { ascending: false }).limit(5),
    ]);

    // Get questionnaire titles
    const qIds = [...new Set((submissions ?? []).map((s: any) => s.questionnaire_id))];
    let questionnaires: any[] = [];
    if (qIds.length > 0) {
      const { data } = await supabase.from("questionnaires").select("id, title").in("id", qIds);
      questionnaires = data ?? [];
    }

    const submissionsWithTitles = (submissions ?? []).map((s: any) => ({
      ...s,
      questionnaire_title: questionnaires.find((q: any) => q.id === s.questionnaire_id)?.title ?? "Unknown",
    }));

    // Calculate age
    let age: number | null = null;
    if (profile?.birth_date) {
      const bd = new Date(profile.birth_date);
      const now = new Date();
      age = now.getFullYear() - bd.getFullYear();
      if (now.getMonth() < bd.getMonth() || (now.getMonth() === bd.getMonth() && now.getDate() < bd.getDate())) age--;
    }

    const hjData = healthJournal ?? [];
    const lastWeight = hjData.find((h: any) => h.weight_kg)?.weight_kg;
    const lastHeight = (healthReports ?? []).find((r: any) => r.height_cm)?.height_cm;

    const patientDataBlock = `
## Páciens adatok

**Profil:** ${profile?.full_name ?? 'N/A'}
- Nem: ${profile?.gender === 'ferfi' ? 'Férfi' : profile?.gender === 'no' ? 'Nő' : 'Nem megadott'}
- Kor: ${age ?? 'Nem megadott'}
- Testsúly: ${lastWeight ? `${lastWeight} kg` : 'N/A'}
- Magasság: ${lastHeight ? `${lastHeight} cm` : 'N/A'}
${lastWeight && lastHeight ? `- BMI: ${(lastWeight / ((lastHeight / 100) ** 2)).toFixed(1)}` : ''}

**Törzskarton:**
- Krónikus betegségek: ${patientCard?.chronic_diseases || 'Nincs'}
- Gyógyszerallergiák: ${patientCard?.drug_allergies || 'Nincs'}
- Állandó gyógyszerek: ${patientCard?.regular_medications || 'Nincs'}
- Műtétek: ${patientCard?.surgeries || 'Nincs'}
- Dohányzás: ${JSON.stringify(patientCard?.smoking) || 'N/A'}
- Alkohol: ${patientCard?.alcohol || 'N/A'}
- Foglalkozás: ${patientCard?.occupation || 'N/A'}

**Kérdőív eredmények:**
${submissionsWithTitles.length > 0 ? submissionsWithTitles.map((s: any) => `- ${s.questionnaire_title}: Pontszám ${s.score ?? '?'}, Kategória: ${s.risk_category ?? '?'}`).join('\n') : 'Nincs'}

**Védőoltások:**
${(vaccinations ?? []).length > 0 ? (vaccinations ?? []).slice(0, 10).map((v: any) => `- ${v.vaccine_name} (${v.administered_date})`).join('\n') : 'Nincs'}

**Aktív gyógyszerek:**
${(medications ?? []).length > 0 ? (medications ?? []).map((m: any) => `- ${m.medication_name}`).join('\n') : 'Nincs'}
`;

    let prompt: string;
    let title: string;

    if (type === "screening_plan") {
      title = "Szűrési és kivizsgálási terv";
      prompt = `Te egy tapasztalt magyar üzemorvos vagy. Az alábbi páciens adatai alapján készíts részletes szűrési és kivizsgálási tervet.

${patientDataBlock}

${notes ? `**Orvos megjegyzése:** ${notes}` : ''}

## Kérés

Készíts részletes szűrési és kivizsgálási tervet az alábbi struktúrában (magyar nyelven, markdown formátumban):

### 1. Aktuális állapot összefoglalása
Rövid összegzés a rendelkezésre álló adatok alapján.

### 2. Javasolt szűrővizsgálatok
Részletes lista a szükséges szűrővizsgálatokról, prioritás és sürgősség szerint:
- Vizsgálat neve
- Indoklás
- Javasolt időpont/gyakoriság
- Előkészületek

### 3. Labor vizsgálatok
Szükséges laborvizsgálatok listája indoklással.

### 4. Szakterületi konzultációk
Javasolt szakterületi vizsgálatok (pl. kardiológia, szemészet, stb.)

### 5. Képalkotó vizsgálatok
Szükséges röntgen, ultrahang, CT, MRI vizsgálatok.

### 6. Kontroll ütemterv
Következő kontrollvizsgálatok javasolt időpontja.

### 7. Megelőzési javaslatok
Életmódbeli tanácsok a kockázatok csökkentésére.

FONTOS: Vedd figyelembe az életkort, nemet, foglalkozást, kockázati tényezőket és az utolsó vizsgálatok időpontját. Ha valamelyik területen nincs adat, jelezd.`;
    } else {
      const days = Math.min(Math.max(duration_days || 7, 1), 30);
      title = `${days} napos diétás terv`;
      prompt = `Te egy tapasztalt magyar dietetikus vagy. Az alábbi páciens adatai alapján készíts ${days} napos részletes diétás tervet kalóriával és makrotápanyagokkal.

${patientDataBlock}

**Átlag napi kalóriabevitel (étkezési napló):** ${
  (foodJournal ?? []).length > 0
    ? `${Math.round((foodJournal ?? []).filter((f: any) => f.calories_estimated).reduce((s: number, f: any) => s + f.calories_estimated, 0) / ((foodJournal ?? []).filter((f: any) => f.calories_estimated).length || 1))} kcal`
    : 'Nincs adat'
}

${notes ? `**Orvos megjegyzése / speciális igények:** ${notes}` : ''}

## Kérés

Készíts ${days} napos részletes diétás tervet az alábbi formátumban (magyar nyelven, markdown):

### Összefoglaló
- Javasolt napi kalóriabevitel (indoklással)
- Makrotápanyag-elosztás (fehérje/szénhidrát/zsír g és %)
- Figyelembe vett allergiák, intoleranciák, gyógyszer-interakciók

### Napi étrendek

Minden napra (1. nap – ${days}. nap):

#### N. nap
| Étkezés | Étel | kcal | Fehérje (g) | Szénhidrát (g) | Zsír (g) |
|---------|------|------|-------------|-----------------|----------|
| Reggeli | ... | ... | ... | ... | ... |
| Tízórai | ... | ... | ... | ... | ... |
| Ebéd | ... | ... | ... | ... | ... |
| Uzsonna | ... | ... | ... | ... | ... |
| Vacsora | ... | ... | ... | ... | ... |
| **Összesen** | | **...** | **...** | **...** | **...** |

### Heti bevásárlólista
A diétás terv alapján összeállított bevásárlólista (legalább az első héthez).

### Fontos megjegyzések
- Étel-gyógyszer interakciók (ha releváns)
- Folyadékbevitel javaslat
- Táplálékkiegészítő javaslatok

FONTOS: Minden nap legyen egyedi, változatos. Vedd figyelembe a páciens állapotát, allergiáit, gyógyszereit. A kalóriaértékek legyenek reálisak.`;
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const aiResponse = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: type === "screening_plan"
            ? "Te egy tapasztalt magyar orvos vagy, aki szűrési és kivizsgálási terveket készít. Részletes, személyre szabott javaslatokat adsz magyar nyelven."
            : "Te egy tapasztalt magyar dietetikus vagy. Részletes, kalóriaszámolt diétás terveket készítesz magyar nyelven, figyelembe véve az orvosi állapotot és gyógyszer-interakciókat."
          },
          { role: "user", content: prompt },
        ],
        max_tokens: 8000,
      }),
    });

    if (!aiResponse.ok) {
      const errText = await aiResponse.text();
      console.error("AI gateway error:", aiResponse.status, errText);
      if (aiResponse.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded" }), { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      if (aiResponse.status === 402) {
        return new Response(JSON.stringify({ error: "Payment required" }), { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      return new Response(JSON.stringify({ error: "AI generation failed" }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const aiData = await aiResponse.json();
    const plan = aiData.choices?.[0]?.message?.content ?? "";

    return new Response(JSON.stringify({ plan, title, type }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("ai-doctor-recommendation error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
