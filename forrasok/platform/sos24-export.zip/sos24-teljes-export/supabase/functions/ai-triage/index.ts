import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: userErr } = await supabase.auth.getUser();
    if (userErr || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { symptoms, age, gender } = await req.json();

    if (!symptoms || typeof symptoms !== "string" || symptoms.trim().length < 5) {
      return new Response(JSON.stringify({ error: "Kérjük, írja le a panaszait részletesebben." }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      return new Response(JSON.stringify({ error: "API key not configured" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const systemPrompt = `Te egy magyar háziorvosi rendelő triázs asszisztense vagy. A páciens leírja a panaszait, és neked kell:
1. Röviden összefoglalni a panaszokat (max 2 mondat)
2. Javasolt szakterületet/szakrendelést megnevezni (pl. belgyógyászat, ortopédia, bőrgyógyászat, szemészet, fül-orr-gégészet, neurológia, urológia, nőgyógyászat, kardiológia, gasztroenterológia, reumatológia, pszichiátria, sebészet, stb.)
3. Sürgősségi szintet meghatározni (alacsony/közepes/magas/azonnali)
4. 2-3 kiegészítő kérdést feltenni, amik segíthetik a pontos diagnózist

Válaszolj JSON formátumban:
{
  "summary": "panasz összefoglalás",
  "suggested_specialty": "javasolt szakterület",
  "urgency": "alacsony|közepes|magas|azonnali",
  "followup_questions": ["kérdés1", "kérdés2"],
  "reasoning": "rövid indoklás miért ezt a szakterületet javaslod"
}

FONTOS: Ez NEM diagnózis, csak iránymutatás a háziorvos felé. Mindig hangsúlyozd, hogy a végső döntés az orvosé.`;

    const userPrompt = `Páciens adatai: ${age ? `Kor: ${age} év` : "Kor: ismeretlen"}, ${gender === "ferfi" ? "Férfi" : gender === "no" ? "Nő" : "Nem megadva"}

Panaszok: ${symptoms}`;

    const aiRes = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        response_format: { type: "json_object" },
      }),
    });

    if (!aiRes.ok) {
      const errText = await aiRes.text();
      console.error("AI API error:", errText);
      return new Response(JSON.stringify({ error: "AI szolgáltatás nem elérhető" }), {
        status: 502,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const aiData = await aiRes.json();
    const content = aiData.choices?.[0]?.message?.content;

    let parsed;
    try {
      parsed = JSON.parse(content);
    } catch {
      parsed = { summary: content, suggested_specialty: "Háziorvos", urgency: "közepes", followup_questions: [], reasoning: "" };
    }

    return new Response(JSON.stringify(parsed), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err: any) {
    console.error("ai-triage error:", err);
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
