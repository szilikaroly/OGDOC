import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

// FINDRISK scoring logic
function calculateFindriskScore(answers: Record<string, any>): { score: number; category: string } {
  let score = 0;
  const pointMap: Record<string, Record<string, number>> = {
    age: { "45 évnél fiatalabb": 0, "45–54 év": 2, "55–64 év": 3, "65 év felett": 4 },
    bmi: { "25 alatt": 0, "25–30": 1, "30 felett": 3 },
    waist_male: { "94 cm alatt": 0, "94–102 cm": 3, "102 cm felett": 4 },
    waist_female: { "80 cm alatt": 0, "80–88 cm": 3, "88 cm felett": 4 },
    physical_activity: { "igen": 0, "nem": 2 },
    vegetable_intake: { "Minden nap": 0, "Nem minden nap": 1 },
    blood_pressure_med: { "nem": 0, "igen": 2 },
    high_blood_sugar: { "nem": 0, "igen": 5 },
    family_diabetes: { "Nem": 0, "Igen: nagyszülő, nagybácsi/nagynéni, unokatestvér": 3, "Igen: szülő, testvér, saját gyermek": 5 },
  };

  for (const [key, mapping] of Object.entries(pointMap)) {
    const val = answers[key];
    if (val && mapping[val] !== undefined) {
      score += mapping[val];
    }
  }

  let category: string;
  if (score < 7) category = "Alacsony kockázat";
  else if (score < 12) category = "Enyhén emelkedett kockázat";
  else if (score < 15) category = "Közepes kockázat";
  else if (score < 21) category = "Magas kockázat";
  else category = "Nagyon magas kockázat";

  return { score, category };
}

// BECK BDI-II scoring logic
function calculateBeckScore(answers: Record<string, any>): { score: number; category: string } {
  let score = 0;
  // Beck items are numbered 1-21, each value is 0-3
  for (const [key, val] of Object.entries(answers)) {
    const num = parseInt(String(val));
    if (!isNaN(num)) {
      score += Math.min(num, 3);
    }
  }

  let category: string;
  if (score <= 13) category = "Minimális depresszió";
  else if (score <= 19) category = "Enyhe depresszió";
  else if (score <= 28) category = "Közepes depresszió";
  else category = "Súlyos depresszió";

  return { score, category };
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) throw new Error("Missing authorization");

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) throw new Error("Unauthorized");

    const { submission_id } = await req.json();
    if (!submission_id) throw new Error("Missing submission_id");

    // Fetch submission with questionnaire title
    const serviceClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const { data: submission, error: subError } = await serviceClient
      .from("questionnaire_submissions")
      .select("id, answers, questionnaire_id, user_id")
      .eq("id", submission_id)
      .single();
    if (subError || !submission) throw new Error("Submission not found");

    // Authorization: caller must own the submission OR have a clinician/admin role
    let authorized = submission.user_id === user.id;
    if (!authorized) {
      const { data: roles } = await serviceClient.from("user_roles").select("role").eq("user_id", user.id);
      const roleSet = new Set((roles ?? []).map((r: { role: string }) => r.role));
      authorized = roleSet.has("super_admin") || roleSet.has("uzemorvos") || roleSet.has("haziorvos");
    }
    if (!authorized) {
      return new Response(JSON.stringify({ error: "Forbidden" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: questionnaire } = await serviceClient
      .from("questionnaires")
      .select("title")
      .eq("id", submission.questionnaire_id)
      .single();

    const title = (questionnaire?.title || "").toUpperCase();
    const answers = submission.answers as Record<string, any>;

    let score = 0;
    let riskCategory = "";

    if (title.includes("FINDRISK")) {
      const result = calculateFindriskScore(answers);
      score = result.score;
      riskCategory = result.category;
    } else if (title.includes("BECK")) {
      const result = calculateBeckScore(answers);
      score = result.score;
      riskCategory = result.category;
    } else {
      // For SCORE2 and Hamilton, just sum numeric answers
      for (const val of Object.values(answers)) {
        const num = parseInt(String(val));
        if (!isNaN(num)) score += num;
      }
      if (title.includes("HAMILTON") || title.includes("HAM-A")) {
        if (score <= 7) riskCategory = "Nincs szorongás";
        else if (score <= 14) riskCategory = "Enyhe szorongás";
        else if (score <= 23) riskCategory = "Közepes szorongás";
        else riskCategory = "Súlyos szorongás";
      } else if (title.includes("SCORE2")) {
        if (score <= 3) riskCategory = "Alacsony kardiovaszkuláris kockázat";
        else if (score <= 6) riskCategory = "Közepes kardiovaszkuláris kockázat";
        else riskCategory = "Magas kardiovaszkuláris kockázat";
      } else {
        riskCategory = `Összpontszám: ${score}`;
      }
    }

    // Call AI for clinical evaluation
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    let aiEvaluation = "";

    if (LOVABLE_API_KEY) {
      const aiResponse = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${LOVABLE_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "google/gemini-2.5-flash",
          messages: [
            {
              role: "system",
              content: `Te egy tapasztalt magyar orvos vagy. A páciens kitöltött egy klinikai kérdőívet. Az eredmény alapján adj rövid, strukturált klinikai értékelést magyarul (max 300 szó). Tartalmazd:
1. Az eredmény értelmezése
2. Klinikai jelentőség
3. Javasolt teendők / további vizsgálatok
4. Figyelmeztetések, ha van

Használj markdown formázást. Legyél empatikus de professzionális.`,
            },
            {
              role: "user",
              content: `Kérdőív: ${questionnaire?.title || "Ismeretlen"}
Összpontszám: ${score}
Rizikó kategória: ${riskCategory}
Válaszok: ${JSON.stringify(answers, null, 2)}`,
            },
          ],
        }),
      });

      if (aiResponse.ok) {
        const aiData = await aiResponse.json();
        aiEvaluation = aiData.choices?.[0]?.message?.content || "";
      }
    }

    // Update submission with score, category, and AI evaluation
    const { error: updateError } = await serviceClient
      .from("questionnaire_submissions")
      .update({ score, risk_category: riskCategory, ai_evaluation: aiEvaluation })
      .eq("id", submission_id);

    if (updateError) throw updateError;

    return new Response(JSON.stringify({ score, risk_category: riskCategory, ai_evaluation: aiEvaluation }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("ai-questionnaire-scoring error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
