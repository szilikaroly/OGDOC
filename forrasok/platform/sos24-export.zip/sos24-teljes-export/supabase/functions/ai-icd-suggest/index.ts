import { streamText, Output, jsonSchema } from "npm:ai";
import { requireUser } from "../_shared/auth.ts";
import {
  createLovableAiGatewayProvider,
  getLovableAiGatewayRunId,
  getLovableAiGatewayResponseHeaders,
  withLovableAiGatewayRunIdHeader,
} from "../_shared/ai-gateway.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-lovable-aig-run-id",
};

const SuggestSchema = jsonSchema({
  type: "object",
  additionalProperties: false,
  properties: {
    suggestions: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        properties: {
          code: { type: "string" },
          label_hu: { type: "string" },
          reason: { type: ["string", "null"] },
        },
        required: ["code", "label_hu", "reason"],
      },
    },
  },
  required: ["suggestions"],
});

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const auth = await requireUser(req, corsHeaders);
    if (!auth.ok) return auth.response;

    const body = await req.json();
    const description = typeof body.description === "string" ? body.description.trim() : "";
    const version = body.version === "icd11" ? "icd11" : "icd10";
    const maxResults = Math.min(Math.max(Number(body.max_results) || 5, 1), 10);

    if (description.length < 3) {
      return new Response(
        JSON.stringify({ error: "A leírás legalább 3 karakter legyen." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      return new Response(
        JSON.stringify({ error: "LOVABLE_API_KEY is not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const systemPrompt = `Te egy tapasztalt magyar orvos vagy, aki BNO (ICD) kódolással foglalkozik. A felhasználó leírása alapján javasolj pontos BNO kódokat magyar elnevezéssel.

SZABÁLYOK:
- A javaslatok legyenek szakmailag indokoltak, de hangsúlyozd, hogy a végleges kódolás az orvos felelőssége.
- Csak valóban létező ICD kódokat javasolj; ne találj ki kódot.
- Adj meg maximum ${maxResults} javaslatot.
- A kódokat a ${version.toUpperCase()} szabvány szerint add meg.
- Minden javaslathoz adj rövid magyar indoklást.`;

    const initialRunId = getLovableAiGatewayRunId(req);
    const gateway = createLovableAiGatewayProvider(LOVABLE_API_KEY, initialRunId);

    const result = streamText({
      model: gateway.responses("openai/gpt-5.6-sol"),
      output: Output.object({ schema: SuggestSchema }),
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: description },
      ],
      providerOptions: {
        openai: {
          forceReasoning: false,
          store: false,
        },
      },
    });

    const { output } = await result;
    const rawSuggestions = (output as { suggestions?: Array<{ code: string; label_hu: string; reason: string | null }> }).suggestions ?? [];

    // Validate each suggestion against the database and enrich with DB fields
    const validSuggestions = [];
    for (const s of rawSuggestions.slice(0, maxResults)) {
      const { data } = await auth.client
        .from("icd_codes")
        .select("id, code, version, label_hu, label_en, parent_code, level, synonyms, category, is_active")
        .eq("code", s.code)
        .eq("version", version)
        .eq("is_active", true)
        .single();

      if (data) {
        validSuggestions.push(data);
      }
    }

    const response = Response.json(
      { suggestions: validSuggestions },
      { headers: getLovableAiGatewayResponseHeaders(undefined, corsHeaders) },
    );

    return withLovableAiGatewayRunIdHeader(response, gateway, corsHeaders);
  } catch (e) {
    console.error("ai-icd-suggest error:", e);
    return new Response(
      JSON.stringify({ error: e instanceof Error ? e.message : "Ismeretlen hiba" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
