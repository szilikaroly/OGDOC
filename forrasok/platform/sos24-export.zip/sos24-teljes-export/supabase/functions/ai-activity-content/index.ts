import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { requireUser, hasAnyRole } from "../_shared/auth.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const auth = await requireUser(req, corsHeaders);
    if (!auth.ok) return auth.response;
    // Content authoring tools are admin/marketing only
    const allowed = await hasAnyRole(auth.user.id, ["super_admin", "uzemorvos", "haziorvos"]);
    if (!allowed) {
      return new Response(JSON.stringify({ error: "Forbidden" }), {
        status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY not configured");

    const { name, mode, existing_content, language, existing_services } = await req.json();

    const lang = language || "hu";
    let systemPrompt: string;
    let userPrompt: string;
    let toolDef: any;

    if (mode === "suggest_premium_services") {
      systemPrompt = `You are an expert in occupational health services (üzemorvosi szolgáltatások) and corporate wellness in Hungary. Suggest premium services and bundled packages that a modern occupational health provider can offer. Output in ${lang === "hu" ? "Hungarian" : lang} language. Be specific with medical service names, include realistic Hungarian price ranges in HUF, and suggest appropriate durations.`;

      const existingList = (existing_services || []).join(", ");
      userPrompt = `Suggest 8-12 premium occupational health services AND 3-5 bundled packages for a Hungarian occupational health provider website.

Already existing services (DO NOT suggest these): ${existingList || "none"}

Include services like:
- Executive/VIP health screenings
- Specialized driver fitness exams
- Ergonomic workplace assessments
- Mental health & burnout prevention programs
- Corporate wellness packages
- Travel medicine consultations
- Occupational disease screening panels
- Hearing/vision conservation programs
- Respiratory function testing
- Drug & alcohol testing programs
- Return-to-work assessments
- Vaccination programs for companies

For packages, combine multiple services into value bundles.

Return all suggestions as a single list.`;

      toolDef = {
        type: "function",
        function: {
          name: "return_suggestions",
          description: "Return premium service and package suggestions",
          parameters: {
            type: "object",
            properties: {
              suggestions: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    name: { type: "string", description: "Service name in Hungarian" },
                    description: { type: "string", description: "Detailed 2-4 sentence description in Hungarian" },
                    category: { type: "string", description: "Service category in Hungarian" },
                    price_range: { type: "string", description: "Price range in HUF, e.g. '15 000 - 25 000 Ft'" },
                    duration_min: { type: "number", description: "Duration in minutes" },
                    icon_suggestion: {
                      type: "string",
                      enum: ["Stethoscope", "HeartPulse", "Syringe", "Pill", "Microscope", "Scan", "Brain", "Eye", "Baby", "Bone", "Heart", "Thermometer", "Activity", "ShieldCheck", "UserCheck", "Home", "Briefcase", "Truck", "ClipboardList", "Shield", "Ear", "Wind", "Dumbbell", "Coffee", "Package"],
                    },
                    is_package: { type: "boolean", description: "True if this is a bundled package" },
                    package_includes: {
                      type: "array",
                      items: { type: "string" },
                      description: "List of included services if is_package is true",
                    },
                  },
                  required: ["name", "description", "category", "price_range", "duration_min", "icon_suggestion", "is_package"],
                },
              },
            },
            required: ["suggestions"],
          },
        },
      };

      const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${LOVABLE_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "google/gemini-3-flash-preview",
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: userPrompt },
          ],
          tools: [toolDef],
          tool_choice: { type: "function", function: { name: "return_suggestions" } },
        }),
      });

      if (!response.ok) {
        const errText = await response.text();
        console.error("AI gateway error:", response.status, errText);
        if (response.status === 429) {
          return new Response(JSON.stringify({ error: "Rate limit exceeded, try again later" }), {
            status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        if (response.status === 402) {
          return new Response(JSON.stringify({ error: "Credits exhausted" }), {
            status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        throw new Error(`AI error: ${response.status}`);
      }

      const data = await response.json();
      const toolCall = data.choices?.[0]?.message?.tool_calls?.[0];
      let result: any = { suggestions: [] };

      if (toolCall?.function?.arguments) {
        result = typeof toolCall.function.arguments === "string"
          ? JSON.parse(toolCall.function.arguments)
          : toolCall.function.arguments;
      }

      return new Response(JSON.stringify(result), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // --- Existing modes below ---

    if (mode === "service_description") {
      systemPrompt = `You are a medical copywriter. Write professional service descriptions for a healthcare provider website. Output in ${lang === "hu" ? "Hungarian" : lang} language. Return JSON with: { "description": "2-3 sentence description" }`;
      userPrompt = `Write a professional description for this medical service: "${name}"${existing_content ? `\n\nCurrent description to improve: ${existing_content}` : ""}`;
    } else if (mode === "seo") {
      systemPrompt = `You are an SEO expert for healthcare websites. Generate SEO metadata in ${lang === "hu" ? "Hungarian" : lang} language. Return JSON with: { "seo_title": "max 60 chars", "seo_description": "max 160 chars", "seo_keywords": "comma separated", "og_title": "max 60 chars", "og_description": "max 160 chars" }`;
      userPrompt = `Generate SEO metadata for a healthcare activity page about: "${name}"${existing_content ? `\n\nPage content context: ${existing_content}` : ""}`;
    } else if (mode === "refine") {
      systemPrompt = `You are a medical content editor. Improve and refine the given content while keeping it professional and accurate. Output in ${lang === "hu" ? "Hungarian" : lang} language. Return JSON with: { "short_description": "1-2 sentences", "long_description": "3-5 sentences", "page_content": "full markdown page content, 300-500 words" }`;
      userPrompt = `Refine and improve this healthcare activity content for: "${name}"\n\nCurrent content:\nShort: ${existing_content?.short || ""}\nLong: ${existing_content?.long || ""}\nPage: ${existing_content?.page || ""}`;
    } else {
      // generate
      systemPrompt = `You are a medical content writer for a healthcare provider website. Generate comprehensive content in ${lang === "hu" ? "Hungarian" : lang} language. Return JSON with: { "short_description": "1-2 sentences for card display", "long_description": "3-5 sentences detailed description", "page_content": "full markdown page content, 300-500 words, include headings, bullet points", "seo_title": "max 60 chars", "seo_description": "max 160 chars", "seo_keywords": "comma separated keywords", "og_title": "max 60 chars", "og_description": "max 160 chars", "suggested_icon": "one of: Stethoscope, HeartPulse, Syringe, Pill, Microscope, Scan, Brain, Eye, Baby, Bone, Heart, Thermometer, Activity, ShieldCheck, UserCheck, Home, Briefcase, Truck, ClipboardList" }`;
      userPrompt = `Generate full website content for this healthcare activity: "${name}"`;
    }

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        tools: [{
          type: "function",
          function: {
            name: "return_content",
            description: "Return the generated content",
            parameters: {
              type: "object",
              properties: mode === "service_description"
                ? { description: { type: "string" } }
                : mode === "seo"
                ? {
                    seo_title: { type: "string" },
                    seo_description: { type: "string" },
                    seo_keywords: { type: "string" },
                    og_title: { type: "string" },
                    og_description: { type: "string" },
                  }
                : {
                    short_description: { type: "string" },
                    long_description: { type: "string" },
                    page_content: { type: "string" },
                    seo_title: { type: "string" },
                    seo_description: { type: "string" },
                    seo_keywords: { type: "string" },
                    og_title: { type: "string" },
                    og_description: { type: "string" },
                    suggested_icon: { type: "string" },
                  },
              required: mode === "service_description"
                ? ["description"]
                : mode === "seo"
                ? ["seo_title", "seo_description"]
                : ["short_description", "long_description", "page_content"],
            },
          },
        }],
        tool_choice: { type: "function", function: { name: "return_content" } },
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error("AI gateway error:", response.status, errText);
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded, try again later" }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Credits exhausted" }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      throw new Error(`AI error: ${response.status}`);
    }

    const data = await response.json();
    const toolCall = data.choices?.[0]?.message?.tool_calls?.[0];
    let result: Record<string, string> = {};

    if (toolCall?.function?.arguments) {
      result = typeof toolCall.function.arguments === "string"
        ? JSON.parse(toolCall.function.arguments)
        : toolCall.function.arguments;
    }

    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err: any) {
    console.error("ai-activity-content error:", err);
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
