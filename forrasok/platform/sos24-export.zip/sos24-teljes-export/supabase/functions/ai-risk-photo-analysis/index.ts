import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { requireUser } from "../_shared/auth.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const auth = await requireUser(req, corsHeaders);
    if (!auth.ok) return auth.response;

    const { image_base64, mime_type = "image/jpeg" } = await req.json();
    if (!image_base64) {
      return new Response(JSON.stringify({ error: "image_base64 is required" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const systemPrompt = `Te egy tapasztalt munkavédelmi szakértő vagy, aki ISO 45001 szerinti kockázatértékeléseket végez. A kapott fénykép alapján adj átfogó munkavédelmi helyszínelemzést.

Válaszolj JSON formátumban az alábbi struktúrával:
{
  "workplace_description": {
    "type": "A munkaterület típusa (pl. gyártócsarnok, irodai munkahely, raktár, laboratórium, építkezés stb.)",
    "layout": "Elrendezés, méret, tér leírása",
    "lighting": "Megvilágítás értékelése (természetes/mesterséges, elegendő/elégtelen)",
    "ventilation": "Szellőzés értékelése (természetes/gépi, megfelelő/nem megfelelő)",
    "temperature": "Becsült hőmérsékleti viszonyok, ha megállapítható"
  },
  "atmosphere": {
    "organization": "Szervezettség értékelése (rendezett/rendezetlen/kaotikus)",
    "cleanliness": "Tisztaság értékelése",
    "general_impression": "Általános hangulat és benyomás a munkakörnyezetről",
    "housekeeping_score": 1-5
  },
  "worker_clothing": {
    "observed_ppe": ["Felsorolt, ténylegesen viselt védőeszközök"],
    "required_ppe": ["A munkaterület alapján szükséges védőeszközök"],
    "missing_ppe": ["Hiányzó védőeszközök, amiket viselniük kellene"],
    "clothing_appropriate": true/false,
    "notes": "Észrevételek a ruházattal kapcsolatban"
  },
  "slip_trip_fall": {
    "floor_condition": "Padlóburkolat állapota, minősége",
    "obstacles": ["Azonosított akadályok, botlásveszélyes tárgyak"],
    "height_risks": "Magasból esés kockázata (lépcső, emelvény, létra, állvány stb.)",
    "guardrails": "Korlátok, védőrácsok megléte/hiánya",
    "risk_level": "low|medium|high|critical",
    "notes": "Egyéb csúszás/botlás/esés megjegyzések"
  },
  "dust_fumes": {
    "visible_dust": true/false,
    "dust_description": "Látható por típusa és mennyisége",
    "fumes_vapors": true/false,
    "fumes_description": "Gőz, kipárolgás, köd leírása, ha van",
    "extraction_present": true/false,
    "risk_level": "low|medium|high|critical"
  },
  "work_phase": {
    "identified_phase": "A vélt munkafázis (előkészítés, gyártás, összeszerelés, karbantartás, takarítás, szállítás, raktározás stb.)",
    "activities_observed": ["Megfigyelt munkatevékenységek"],
    "equipment_visible": ["Látható gépek, eszközök, szerszámok"],
    "materials_visible": ["Látható anyagok, alapanyagok"]
  },
  "ppe_compliance": {
    "overall_score": 1-5,
    "compliant_items": ["Megfelelő PPE elemek"],
    "non_compliant_items": ["Nem megfelelő / hiányzó PPE elemek"],
    "recommendation": "Összefoglaló PPE javaslat"
  },
  "hazards": [
    {
      "category": "physical|chemical|biological|ergonomic|psychosocial|equipment|environment|fire|electrical|other",
      "name": "A veszélyforrás neve (magyarul)",
      "description": "Rövid leírás a képen látható problémáról",
      "severity": 1-4,
      "probability": 1-4,
      "recommendation": "Javasolt intézkedés",
      "catalog_match": "A legközelebb álló hazard-catalog id, ha releváns (pl. physical_noise, chemical_dust stb.)"
    }
  ],
  "positive_aspects": ["Pozitív biztonsági elemek listája"]
}

FONTOS szabályok:
- Legyél alapos de tömör. Minden szekciót töltsd ki.
- Ha valamit nem tudsz megállapítani a képről, írd be: "Nem megállapítható a képről"
- A severity és probability 1-4 skálán (1=elhanyagolható, 4=nagyon súlyos/nagyon valószínű)
- A hazards tömbben minden észlelt veszélyforrást listázz. Ha nem látsz veszélyt, üres tömböt adj.
- A catalog_match mezőben próbáld az ismert kategóriákat használni: physical_, chemical_, biological_, ergonomic_, psychosocial_, equipment_, environment_, fire_, electrical_
- Különösen figyelj: esés/zuhanás/csúszás, por/gőz, égés/robbanás, elektromos veszély, zaj, vibráció, rossz ergonómia`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          {
            role: "user",
            content: [
              { type: "text", text: "Kérlek elemezd ezt a munkaterületi fényképet és adj átfogó munkavédelmi helyszínleírást, beleértve a munkaterület leírását, a dolgozók ruházatát és védőfelszerelését, az esés/csúszás/zuhanás kockázatokat, a látható port vagy gőzöket, és a vélt munkafázist." },
              { type: "image_url", image_url: { url: `data:${mime_type};base64,${image_base64}` } },
            ],
          },
        ],
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Túl sok kérés, próbálja újra később." }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Fizetés szükséges." }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const t = await response.text();
      console.error("AI gateway error:", response.status, t);
      return new Response(JSON.stringify({ error: "AI elemzési hiba" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const result = await response.json();
    const content = result.choices?.[0]?.message?.content ?? "";

    let analysis;
    try {
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      analysis = jsonMatch ? JSON.parse(jsonMatch[0]) : { raw: content };
    } catch {
      analysis = { raw: content };
    }

    return new Response(JSON.stringify({ analysis }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("ai-risk-photo-analysis error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Ismeretlen hiba" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
