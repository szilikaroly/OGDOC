import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const baseUrl = "https://sos24.lovable.app";
    const languages = ["hu", "en", "de", "ro", "sr", "zh", "fil"];
    const defaultLang = "hu";

    interface SitemapUrl {
      loc: string;
      lastmod?: string;
      priority: string;
      changefreq: string;
      alternates?: { lang: string; href: string }[];
    }

    const urls: SitemapUrl[] = [];

    // Helper: build hreflang alternates for a path
    const buildAlternates = (path: string) =>
      languages.map((lang) => ({
        lang,
        href: `${baseUrl}${path}${path.includes("?") ? "&" : "?"}lang=${lang}`,
      }));

    // 1. SEO pages from CMS
    const { data: seoPages } = await supabase
      .from("seo_pages")
      .select("page_path, updated_at, noindex")
      .eq("noindex", false);

    if (seoPages) {
      for (const p of seoPages) {
        urls.push({
          loc: `${baseUrl}${p.page_path}`,
          lastmod: p.updated_at?.split("T")[0],
          priority: p.page_path === "/" ? "1.0" : "0.7",
          changefreq: p.page_path === "/" ? "weekly" : "monthly",
          alternates: buildAlternates(p.page_path),
        });
      }
    }

    // 2. Activities (dynamic CMS content)
    const { data: activities } = await supabase
      .from("activities")
      .select("slug, updated_at, name")
      .eq("is_active", true)
      .order("sort_order", { ascending: true });

    if (activities) {
      for (const a of activities) {
        const path = `/tevekenysegeink/${a.slug}`;
        if (!urls.find((u) => u.loc.endsWith(path))) {
          urls.push({
            loc: `${baseUrl}${path}`,
            lastmod: a.updated_at?.split("T")[0],
            priority: "0.8",
            changefreq: "weekly",
            alternates: buildAlternates(path),
          });
        }
      }
      // Activities list page
      const listPath = "/tevekenysegeink";
      if (!urls.find((u) => u.loc.endsWith(listPath))) {
        urls.push({
          loc: `${baseUrl}${listPath}`,
          lastmod: activities[0]?.updated_at?.split("T")[0],
          priority: "0.8",
          changefreq: "weekly",
          alternates: buildAlternates(listPath),
        });
      }
    }

    // 3. Services
    const { data: services } = await supabase
      .from("services")
      .select("id, updated_at, slug")
      .eq("is_active", true);

    if (services) {
      for (const s of services) {
        const path = `/szolgaltatasok/${s.slug || s.id}`;
        if (!urls.find((u) => u.loc.endsWith(path))) {
          urls.push({
            loc: `${baseUrl}${path}`,
            lastmod: s.updated_at?.split("T")[0],
            priority: "0.7",
            changefreq: "monthly",
            alternates: buildAlternates(path),
          });
        }
      }
    }

    // 4. Locations
    const { data: locations } = await supabase
      .from("locations")
      .select("id, name, updated_at, city")
      .eq("is_active", true);

    if (locations) {
      for (const l of locations) {
        const slug = l.city?.toLowerCase().replace(/\s+/g, "-") || l.id;
        const path = `/helyszinek/${slug}`;
        if (!urls.find((u) => u.loc.endsWith(path))) {
          urls.push({
            loc: `${baseUrl}${path}`,
            lastmod: l.updated_at?.split("T")[0],
            priority: "0.6",
            changefreq: "monthly",
            alternates: buildAlternates(path),
          });
        }
      }
    }

    // 5. CMS pages (pages_content)
    const { data: cmsPages } = await supabase
      .from("pages_content")
      .select("page_key, updated_at")
      .eq("is_active", true);

    if (cmsPages) {
      const uniquePageKeys = [...new Set(cmsPages.map((p) => p.page_key))];
      for (const key of uniquePageKeys) {
        const page = cmsPages.find((p) => p.page_key === key);
        // Skip pages already covered
        const path = `/${key}`;
        if (!urls.find((u) => u.loc === `${baseUrl}${path}` || u.loc === `${baseUrl}/`)) {
          urls.push({
            loc: `${baseUrl}${path}`,
            lastmod: page?.updated_at?.split("T")[0],
            priority: "0.6",
            changefreq: "monthly",
            alternates: buildAlternates(path),
          });
        }
      }
    }

    // 6. Lab shop (public page)
    const labPath = "/labor";
    if (!urls.find((u) => u.loc.endsWith(labPath))) {
      urls.push({
        loc: `${baseUrl}${labPath}`,
        priority: "0.7",
        changefreq: "weekly",
        alternates: buildAlternates(labPath),
      });
    }

    // 7. Ensure root page exists
    if (!urls.find((u) => u.loc === `${baseUrl}/`)) {
      urls.push({
        loc: `${baseUrl}/`,
        priority: "1.0",
        changefreq: "weekly",
        alternates: buildAlternates("/"),
      });
    }

    // 8. Static public pages
    for (const path of ["/login", "/register"]) {
      if (!urls.find((u) => u.loc === baseUrl + path)) {
        urls.push({
          loc: `${baseUrl}${path}`,
          priority: "0.5",
          changefreq: "monthly",
        });
      }
    }

    // Generate XML with xhtml:link hreflang support
    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:xhtml="http://www.w3.org/1999/xhtml">
${urls
  .map(
    (u) => `  <url>
    <loc>${escapeXml(u.loc)}</loc>
${u.lastmod ? `    <lastmod>${u.lastmod}</lastmod>\n` : ""}    <changefreq>${u.changefreq}</changefreq>
    <priority>${u.priority}</priority>
${
  u.alternates
    ? u.alternates
        .map(
          (a) =>
            `    <xhtml:link rel="alternate" hreflang="${a.lang}" href="${escapeXml(a.href)}" />`
        )
        .join("\n") + "\n"
    : ""
}  </url>`
  )
  .join("\n")}
</urlset>`;

    return new Response(xml, {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/xml; charset=utf-8",
        "Cache-Control": "public, max-age=3600, s-maxage=3600",
      },
    });
  } catch (e) {
    console.error("Sitemap generation error:", e);
    return new Response("Error generating sitemap", {
      status: 500,
      headers: corsHeaders,
    });
  }
});

function escapeXml(str: string): string {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}
