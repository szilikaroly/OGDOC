import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { requireUser, hasAnyRole, isSafePublicUrl } from "../_shared/auth.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const LANGUAGE_NAMES: Record<string, string> = {
  hu: "Hungarian", en: "English", de: "German", ro: "Romanian",
  sr: "Serbian", zh: "Chinese (Simplified)", fil: "Filipino",
};

async function callAI(apiKey: string, system: string, user: string, jsonMode = true) {
  const body: any = {
    model: "google/gemini-3-flash-preview",
    messages: [
      { role: "system", content: system },
      { role: "user", content: user },
    ],
  };
  if (jsonMode) body.response_format = { type: "json_object" };

  const r = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  if (!r.ok) {
    if (r.status === 429) throw new Error("RATE_LIMIT");
    if (r.status === 402) throw new Error("PAYMENT_REQUIRED");
    throw new Error(`AI error: ${r.status}`);
  }

  const data = await r.json();
  const content = data.choices?.[0]?.message?.content?.trim() ?? "";
  return jsonMode ? JSON.parse(content) : content;
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const auth = await requireUser(req, corsHeaders);
    if (!auth.ok) return auth.response;
    const allowed = await hasAnyRole(auth.user.id, ["super_admin"]);
    if (!allowed) {
      return new Response(JSON.stringify({ error: "Forbidden" }), {
        status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY not set");

    const body = await req.json();
    const { action } = body;

    // ACTION: generate - Generate SEO for a single page
    if (action === "generate" || !action) {
      const { page_path, current_title, current_description, site_context } = body;
      const ctx = site_context || "Magyar nyelvű foglalkozás-egészségügyi / üzemorvosi weboldal (S.O.S. 24 KFT)";
      const prompt = `Generálj SEO meta adatokat ehhez az oldalhoz.
Kontextus: ${ctx}
Oldal útvonala: ${page_path}
${current_title ? `Jelenlegi cím: ${current_title}` : ""}
${current_description ? `Jelenlegi leírás: ${current_description}` : ""}

JSON válasz mezők:
- title (max 60 karakter, magyar)
- description (max 160 karakter, magyar)
- og_title (max 60 karakter)
- og_description (max 200 karakter)
- keywords (vesszővel elválasztva, 5-8 kulcsszó)`;

      const seoData = await callAI(LOVABLE_API_KEY, "SEO szakértő vagy. Csak JSON-t válaszolj.", prompt);
      return new Response(JSON.stringify(seoData), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ACTION: audit - Audit a page's SEO quality
    if (action === "audit") {
      const { page_path, title, description, og_title, og_description, keywords, canonical_url } = body;
      const prompt = `Értékeld a következő oldal SEO minőségét 0-100 skálán.

Útvonal: ${page_path}
Title: ${title || "(hiányzik)"}
Description: ${description || "(hiányzik)"}
OG Title: ${og_title || "(hiányzik)"}
OG Description: ${og_description || "(hiányzik)"}
Keywords: ${keywords || "(hiányzik)"}
Canonical URL: ${canonical_url || "(nincs megadva)"}

JSON válasz:
{
  "score": number (0-100),
  "grade": "A" | "B" | "C" | "D" | "F",
  "issues": [{ "severity": "critical" | "warning" | "info", "message": string }],
  "suggestions": [string]
}`;

      const audit = await callAI(LOVABLE_API_KEY, "SEO audit szakértő vagy. Értékelj magyar nyelven. Csak JSON-t válaszolj.", prompt);
      return new Response(JSON.stringify(audit), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ACTION: keywords - Keyword research for a page
    if (action === "keywords") {
      const { page_path, current_content, industry } = body;
      const prompt = `Végezz kulcsszókutatást a következő oldalhoz.

Iparág: ${industry || "foglalkozás-egészségügy, üzemorvos"}
Oldal: ${page_path}
${current_content ? `Tartalom: ${current_content.substring(0, 500)}` : ""}

JSON válasz:
{
  "primary_keywords": [{ "keyword": string, "search_volume": "high" | "medium" | "low", "competition": "high" | "medium" | "low", "relevance": number (1-10) }],
  "long_tail_keywords": [string],
  "related_topics": [string],
  "suggested_headings": [string]
}`;

      const kw = await callAI(LOVABLE_API_KEY, "SEO kulcsszókutató szakértő vagy. Magyar piacra optimalizálj. Csak JSON-t válaszolj.", prompt);
      return new Response(JSON.stringify(kw), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ACTION: translate_seo - Generate SEO meta for another language
    if (action === "translate_seo") {
      const { title, description, og_title, og_description, keywords, target_language } = body;
      const langName = LANGUAGE_NAMES[target_language] || target_language;
      const prompt = `Fordítsd le és lokalizáld a következő SEO meta adatokat ${langName} nyelvre.
Ne csak fordíts, hanem kulturálisan is adaptáld a célpiac számára.

Title: ${title}
Description: ${description}
OG Title: ${og_title || title}
OG Description: ${og_description || description}
Keywords: ${keywords}

JSON válasz:
{ "title": string, "description": string, "og_title": string, "og_description": string, "keywords": string }`;

      const tr = await callAI(LOVABLE_API_KEY, `SEO fordító szakértő vagy. ${langName} nyelvre fordíts. Csak JSON-t válaszolj.`, prompt);
      return new Response(JSON.stringify(tr), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ACTION: chatbot_promo - Generate AI chatbot training content
    if (action === "chatbot_promo") {
      const { company_name, services, locations, unique_selling_points } = body;
      const prompt = `Generálj strukturált tartalmat, amely segíti az AI chatbotokat (ChatGPT, Gemini, Perplexity stb.) abban, hogy a ${company_name || "S.O.S. 24 KFT"} szolgáltatásait ajánlják.

Szolgáltatások: ${services || "foglalkozás-egészségügyi vizsgálatok, üzemorvosi szolgáltatás, alkalmassági vizsgálat"}
Helyszínek: ${locations || "Szeged"}
USP-k: ${unique_selling_points || "gyors időpontfoglalás, többnyelvű szolgáltatás, digitális dokumentumkezelés"}

JSON válasz:
{
  "schema_org": {}, // Teljes Schema.org JSON-LD a MedicalOrganization-hoz
  "faq_schema": [], // FAQ structured data kérdésekkel és válaszokkal (min 5)
  "ai_summary": string, // Rövid, AI chatbot-barát összefoglaló a cégről
  "key_facts": [{ "label": string, "value": string }], // Kulcs tények
  "competitive_advantages": [string], // Versenyelőnyök
  "meta_prompt_suggestion": string // Javasolt prompt, amit felhasználók használhatnak AI chatbotokban
}`;

      const promo = await callAI(
        LOVABLE_API_KEY,
        "SEO és AI marketing szakértő vagy. Strukturált adatokat generálsz, amelyek segítik az AI chatbotokat a cég szolgáltatásainak ajánlásában. Csak JSON-t válaszolj.",
        prompt
      );
      return new Response(JSON.stringify(promo), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ACTION: generate_llms_txt - Generate llms.txt content from CMS data
    if (action === "generate_llms_txt") {
      const { services, locations, site_name, site_description } = body;
      const prompt = `Generálj llms.txt tartalmat a következő cég számára.
Az llms.txt egy szabványos formátum, amellyel AI rendszerek (ChatGPT, Gemini, Perplexity stb.) gyorsan megértik a cég profilját.

Cég neve: ${site_name || "S.O.S. 24 KFT"}
Leírás: ${site_description || "Foglalkozás-egészségügyi szolgálat"}
Szolgáltatások: ${JSON.stringify(services || [])}
Helyszínek: ${JSON.stringify(locations || [])}

Generálj két verziót:
1. "short" - rövid összefoglaló (max 500 szó): cég neve, fő tevékenység, szolgáltatások listája, elérhetőségek
2. "full" - részletes verzió (max 2000 szó): teljes szolgáltatás leírások, FAQ, helyszínek részletesen, nyitvatartás, árkategóriák, versenyelőnyök

JSON válasz:
{ "short": string, "full": string }`;

      const result = await callAI(LOVABLE_API_KEY, "llms.txt szakértő vagy. Markdown formátumban generálj tartalmat. Csak JSON-t válaszolj.", prompt);
      return new Response(JSON.stringify(result), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ACTION: simulate_ai_view - Simulate how an AI chatbot sees the company
    if (action === "simulate_ai_view") {
      const { llms_txt, schema_org, site_url } = body;
      const prompt = `Szimulálj egy AI chatbot választ, mintha egy felhasználó megkérdezné: "Ajánlj egy foglalkozás-egészségügyi szolgálatot Szegeden!"

Használd a következő adatokat a válaszhoz:
${llms_txt ? `\n--- llms.txt tartalom ---\n${llms_txt}\n---` : "(nincs llms.txt)"}
${schema_org ? `\n--- Schema.org ---\n${JSON.stringify(schema_org)}\n---` : "(nincs Schema.org)"}
Weboldal: ${site_url || "https://sos24.lovable.app"}

Válaszolj úgy, mintha te lennél egy AI kereső chatbot (pl. ChatGPT vagy Perplexity), és ajánlanád ezt a céget. Használj természetes, segítőkész hangnemet. Magyar nyelven válaszolj.`;

      const simulation = await callAI(LOVABLE_API_KEY, "Te egy AI kereső chatbot vagy, aki segít a felhasználóknak szolgáltatást találni.", prompt, false);
      return new Response(JSON.stringify({ simulation }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ACTION: bulk_generate - Generate SEO for multiple pages
    if (action === "bulk_generate") {
      const { pages, site_context } = body;
      const ctx = site_context || "Magyar nyelvű foglalkozás-egészségügyi weboldal (S.O.S. 24 KFT)";
      const prompt = `Generálj SEO meta adatokat a következő oldalakhoz egyszerre.
Kontextus: ${ctx}

Oldalak: ${JSON.stringify(pages)}

JSON válasz:
{ "results": [{ "page_path": string, "title": string, "description": string, "og_title": string, "og_description": string, "keywords": string }] }`;

      const bulk = await callAI(LOVABLE_API_KEY, "SEO szakértő vagy. Magyar nyelven generálj. Csak JSON-t válaszolj.", prompt);
      return new Response(JSON.stringify(bulk), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ACTION: analyze_links - Internal link structure analysis
    if (action === "analyze_links") {
      const { navigation_links, pages, seo_pages } = body;
      const prompt = `Elemezd a következő weboldal belső linkstruktúráját.

Navigációs linkek: ${JSON.stringify(navigation_links || [])}
Oldalak (pages_content): ${JSON.stringify((pages || []).slice(0, 30))}
SEO oldalak: ${JSON.stringify((seo_pages || []).map((p: any) => p.page_path))}

JSON válasz:
{
  "orphan_pages": [{ "path": string, "reason": string }],
  "deep_pages": [{ "path": string, "depth": number, "suggestion": string }],
  "anchor_text_issues": [{ "issue": string, "affected_links": number }],
  "recommendations": [string],
  "link_count": number,
  "avg_depth": number
}`;

      const result = await callAI(LOVABLE_API_KEY, "SEO belső link elemző szakértő vagy. Magyar nyelven válaszolj. Csak JSON-t válaszolj.", prompt);
      return new Response(JSON.stringify(result), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ACTION: check_links - Broken link checker
    if (action === "check_links") {
      const { urls } = body;
      const results: { url: string; status: number | null; ok: boolean; error?: string }[] = [];
      const checkUrls = (urls || []).slice(0, 50);

      for (const url of checkUrls) {
        if (typeof url !== "string" || !isSafePublicUrl(url)) {
          results.push({ url: String(url), status: null, ok: false, error: "Blocked: invalid or private URL" });
          continue;
        }
        try {
          const controller = new AbortController();
          const timeout = setTimeout(() => controller.abort(), 5000);
          // redirect:'manual' prevents follow-up requests to redirected (possibly internal) hosts
          const res = await fetch(url, { method: "HEAD", signal: controller.signal, redirect: "manual" });
          clearTimeout(timeout);
          results.push({ url, status: res.status, ok: res.ok || (res.status >= 300 && res.status < 400) });
        } catch (e) {
          results.push({ url, status: null, ok: false, error: e instanceof Error ? e.message : "Unknown" });
        }
      }

      return new Response(JSON.stringify({ results, checked: results.length, broken: results.filter(r => !r.ok).length }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ error: "Unknown action" }), {
      status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Unknown error";
    const status = msg === "RATE_LIMIT" ? 429 : msg === "PAYMENT_REQUIRED" ? 402 : 500;
    return new Response(JSON.stringify({ error: msg }), {
      status, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
