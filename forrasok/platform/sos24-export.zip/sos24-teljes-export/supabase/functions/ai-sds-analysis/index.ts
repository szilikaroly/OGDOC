import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: { user }, error: authErr } = await supabase.auth.getUser();
    if (authErr || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      return new Response(JSON.stringify({ error: "API key not configured" }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const adminClient = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const body = await req.json();
    const { sds_text, sds_pdf_base64, work_area_id, cumulative_only, file_name, file_path } = body;

    // Determine text content for analysis
    let textContent = sds_text || "";

    // If PDF base64 provided, use Gemini vision to extract content
    if (sds_pdf_base64 && !textContent) {
      const extractRes = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${LOVABLE_API_KEY}` },
        body: JSON.stringify({
          model: "google/gemini-2.5-flash",
          messages: [
            {
              role: "user",
              content: [
                {
                  type: "text",
                  text: "Extract ALL text content from this Safety Data Sheet (SDS) PDF. Include every section, every table, every hazard statement, composition/ingredients, mixture components with their CAS numbers and percentages. Return the complete extracted text."
                },
                {
                  type: "image_url",
                  image_url: { url: `data:application/pdf;base64,${sds_pdf_base64}` }
                }
              ]
            }
          ],
        }),
      });

      if (extractRes.ok) {
        const extractData = await extractRes.json();
        textContent = extractData.choices?.[0]?.message?.content || "";
      } else {
        console.error("PDF extraction failed:", extractRes.status);
        throw new Error("Failed to extract PDF content");
      }
    }

    // Fetch existing substances in this work area (for cumulative risk)
    let workAreaSubstances: any[] = [];
    let workAreaName = "";
    if (work_area_id) {
      const { data: wa } = await adminClient.from("work_areas").select("name, site_id").eq("id", work_area_id).single();
      workAreaName = wa?.name || "";
      
      const { data: assessments } = await adminClient
        .from("risk_assessments")
        .select("id")
        .eq("work_area_id", work_area_id)
        .order("created_at", { ascending: false })
        .limit(1);

      if (assessments?.length) {
        const { data: hazards } = await adminClient
          .from("risk_assessment_hazards")
          .select("hazard_name, hazard_category, substance_ids, severity, probability, risk_level, current_controls")
          .eq("risk_assessment_id", assessments[0].id);
        workAreaSubstances = hazards || [];
      }

      if (wa?.site_id) {
        const { data: site } = await adminClient.from("company_sites").select("company_id").eq("id", wa.site_id).single();
        if (site?.company_id) {
          const { data: compSubs } = await adminClient
            .from("company_hazardous_substances")
            .select("substance_id, usage_description, annual_quantity, exposure_type, ppe_required")
            .eq("company_id", site.company_id);
          
          if (compSubs?.length) {
            const subIds = compSubs.map((cs: any) => cs.substance_id);
            const { data: subs } = await adminClient
              .from("hazardous_substances")
              .select("id, name, cas_number, ec_number, reason_for_inclusion")
              .in("id", subIds);
            
            workAreaSubstances = [
              ...workAreaSubstances,
              ...(compSubs || []).map((cs: any) => ({
                ...cs,
                substance: (subs || []).find((s: any) => s.id === cs.substance_id),
              })),
            ];
          }
        }
      }

      // Also include existing SDS documents for this work area
      const { data: existingSds } = await adminClient
        .from("work_area_sds_documents")
        .select("substance_name, cas_number, is_mixture, mixture_components, risk_level, analysis_data")
        .eq("work_area_id", work_area_id);
      
      if (existingSds?.length) {
        for (const sds of existingSds) {
          workAreaSubstances.push({
            hazard_name: sds.substance_name || "Unknown SDS substance",
            hazard_category: "chemical",
            is_mixture: sds.is_mixture,
            mixture_components: sds.mixture_components,
            risk_level: sds.risk_level,
            from_sds: true,
          });
        }
      }
    }

    let resultPayload: any = {};

    if (!cumulative_only && textContent) {
      // Analyze individual SDS - enhanced prompt with mixture support
      const sdsPrompt = `Te egy vegyész és munkavédelmi szakértő vagy. Elemezd az alábbi biztonsági adatlapot (Safety Data Sheet / SDS) és add vissza strukturált JSON formátumban az eredményt.

FONTOS: Ha az anyag keverék (mixture/blend/preparation), akkor a mixture_components mezőben add meg az összes összetevőt a koncentrációjukkal együtt!

Válasz JSON struktúra:
{
  "analysis": {
    "substance_name": "anyag/keverék neve",
    "cas_number": "CAS szám (fő anyag vagy keverék azonosító)",
    "ec_number": "EC szám",
    "is_mixture": true/false,
    "mixture_components": [
      {
        "name": "összetevő neve",
        "cas_number": "CAS szám",
        "ec_number": "EC szám",
        "concentration_min": 0,
        "concentration_max": 100,
        "concentration_unit": "% w/w",
        "classification": "GHS besorolás (pl. Acute Tox. 4, H302)",
        "hazard_statements": ["H-kódok"]
      }
    ],
    "hazard_statements": [{"code": "H3xx", "text": "leírás", "category": "fizikai/egészségügyi/környezeti"}],
    "precautionary_statements": [{"code": "P2xx", "text": "leírás"}],
    "ghs_classification": ["GHS piktogram nevek"],
    "exposure_limits": [{"type": "OEL/DNEL/PNEC", "value": "érték", "unit": "mg/m³", "component": "összetevő neve ha keverék"}],
    "ppe_required": ["szükséges egyéni védőeszközök"],
    "first_aid": ["elsősegély intézkedések"],
    "fire_fighting": ["tűzoltási utasítások"],
    "physical_properties": {"halmazállapot": "...", "szín": "...", "lobbanáspont": "..."},
    "risk_level": "low/medium/high/very_high",
    "matched_svhc": true/false,
    "svhc_reason": "ha SVHC, az oka",
    "mixture_synergy_risks": ["keverékben fellépő szinergikus kockázatok, pl. felszabaduló gázok, reakciók"],
    "incompatible_materials": ["összeférhetetlen anyagok"]
  }
}

Ha a szöveg nem tartalmaz elegendő információt egy mezőhöz, hagyd üresen vagy null-ra.
Keresd meg az ECHA SVHC jelöltlista szerinti besorolást is (CMR, PBT, vPvB, endokrin károsító stb).
Ha keverék, vizsgáld meg a komponensek közötti szinergikus hatásokat is.`;

      const aiRes = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${LOVABLE_API_KEY}` },
        body: JSON.stringify({
          model: "google/gemini-2.5-flash",
          messages: [
            { role: "system", content: sdsPrompt },
            { role: "user", content: `Biztonsági adatlap szövege:\n\n${textContent.substring(0, 20000)}` },
          ],
          response_format: { type: "json_object" },
        }),
      });

      if (!aiRes.ok) {
        if (aiRes.status === 429) {
          return new Response(JSON.stringify({ error: "Rate limit exceeded" }), { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } });
        }
        if (aiRes.status === 402) {
          return new Response(JSON.stringify({ error: "Payment required" }), { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } });
        }
        throw new Error("AI service unavailable");
      }
      const aiData = await aiRes.json();
      const content = aiData.choices?.[0]?.message?.content;
      try {
        const parsed = JSON.parse(content);
        resultPayload.analysis = parsed.analysis || parsed;
      } catch {
        resultPayload.analysis = { substance_name: "Parse error", risk_level: "medium" };
      }

      // Save to work_area_sds_documents if work_area_id and file_path provided
      if (work_area_id && file_path && resultPayload.analysis) {
        const a = resultPayload.analysis;
        const { error: insertErr } = await adminClient.from("work_area_sds_documents").insert({
          work_area_id,
          file_name: file_name || "sds.pdf",
          file_path,
          substance_name: a.substance_name || null,
          cas_number: a.cas_number || null,
          ec_number: a.ec_number || null,
          is_mixture: a.is_mixture || false,
          mixture_components: a.mixture_components || [],
          analysis_data: a,
          risk_level: a.risk_level || null,
          uploaded_by: user.id,
        });
        if (insertErr) console.error("Failed to save SDS document:", insertErr);
        else resultPayload.saved = true;
      }
    }

    // Calculate cumulative risk if work area selected
    if (work_area_id && (workAreaSubstances.length > 0 || resultPayload.analysis)) {
      const substanceList = workAreaSubstances.map((s: any) => {
        if (s.from_sds) {
          let desc = `- [SDS] ${s.hazard_name} (kockázat: ${s.risk_level || '?'})`;
          if (s.is_mixture && s.mixture_components?.length) {
            desc += ` - KEVERÉK összetevők: ${s.mixture_components.map((c: any) => `${c.name} ${c.concentration_min ?? '?'}-${c.concentration_max ?? '?'}${c.concentration_unit || '%'}`).join(', ')}`;
          }
          return desc;
        }
        if (s.substance) return `- ${s.substance.name} (CAS: ${s.substance.cas_number || '?'}, ${s.substance.reason_for_inclusion || 'N/A'})`;
        return `- ${s.hazard_name} (${s.hazard_category}, kockázat: ${s.risk_level || '?'}, súlyosság: ${s.severity || '?'})`;
      }).join("\n");

      const newSubstance = resultPayload.analysis
        ? `\nÚj anyag: ${resultPayload.analysis.substance_name} (kockázat: ${resultPayload.analysis.risk_level})${resultPayload.analysis.is_mixture ? ' - KEVERÉK' : ''}`
        : "";

      const cumulativePrompt = `Te egy munkavédelmi és toxikológiai szakértő vagy. Számold ki a halmozott kockázatot az adott munkaterületen lévő összes veszélyes anyag és veszélyforrás alapján.

Munkaterület: ${workAreaName}

Jelenlegi veszélyforrások és anyagok:
${substanceList}
${newSubstance}

Válaszolj JSON formátumban:
{
  "cumulative_risk": {
    "total_risk_score": 1-100 közötti szám,
    "category": "low/medium/high/very_high",
    "dominant_hazards": ["legfontosabb veszélyforrások"],
    "combined_exposure_concerns": ["halmozott expozíciós aggályok, pl. szinergikus hatások, azonos célszervek"],
    "mixture_interaction_risks": ["keverékek közötti kölcsönhatási kockázatok"],
    "recommended_controls": ["javasolt intézkedések a halmozott kockázat csökkentésére"],
    "monitoring_requirements": ["szükséges monitoring és mérési követelmények"]
  }
}

Vedd figyelembe:
- Azonos célszerveket támadó anyagok additív hatása
- CMR anyagok jelenléte fokozza a kockázatot
- Szinergikus hatások lehetősége
- Expozíciós utak kombinációja (belégzés + bőr)
- Keverékekben lévő összetevők közötti reakciók
- Összeférhetetlen anyagok egy munkaterületen belül`;

      const cumRes = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${LOVABLE_API_KEY}` },
        body: JSON.stringify({
          model: "google/gemini-2.5-flash",
          messages: [
            { role: "system", content: cumulativePrompt },
            { role: "user", content: "Számold ki a halmozott kockázatot." },
          ],
          response_format: { type: "json_object" },
        }),
      });

      if (cumRes.ok) {
        const cumData = await cumRes.json();
        try {
          const parsed = JSON.parse(cumData.choices?.[0]?.message?.content);
          resultPayload.cumulative_risk = parsed.cumulative_risk || parsed;
        } catch {
          // skip
        }
      }
    }

    return new Response(JSON.stringify(resultPayload), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err: any) {
    console.error("ai-sds-analysis error:", err);
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
