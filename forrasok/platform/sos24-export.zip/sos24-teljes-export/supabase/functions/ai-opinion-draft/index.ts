import { requireUser, hasAnyRole } from "../_shared/auth.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const auth = await requireUser(req, corsHeaders);
    if (!auth.ok) return auth.response;
    const allowed = await hasAnyRole(auth.user.id, ["super_admin", "uzemorvos", "haziorvos"]);
    if (!allowed) {
      return new Response(JSON.stringify({ error: "Forbidden" }), {
        status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { patient_data, clinical_findings, exam_type, restrictions } = await req.json();

    const apiKey = Deno.env.get("LOVABLE_API_KEY");
    if (!apiKey) throw new Error("LOVABLE_API_KEY not configured");

    const prompt = `Te egy magyar üzemorvosi rendszer AI asszisztense vagy. A vizsgálati adatok alapján készíts alkalmassági vélemény tervezetet magyarul.

Vizsgálat típusa: ${exam_type || "Nem megadott"}

Anamnézis:
${JSON.stringify(patient_data || {}, null, 2)}

Klinikai leletek:
${JSON.stringify(clinical_findings || {}, null, 2)}

${restrictions ? `Korlátozások: ${restrictions}` : ""}

Kérlek, adj strukturált vélemény-javaslatot az alábbi formátumban:
1. Összefoglaló értékelés (2-3 mondat)
2. Javasolt eredmény: alkalmas / nem alkalmas / feltételesen alkalmas / ideiglenes
3. Javasolt korlátozások (ha vannak)
4. Javasolt érvényességi idő
5. Megjegyzések az orvos számára

FONTOS: Ez csak javaslat, az orvos dönt a végső véleményről.`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [{ role: "user", content: prompt }],
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Túl sok kérés, kérjük próbálja újra később." }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Fizetés szükséges." }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const errText = await response.text();
      console.error("AI gateway error:", response.status, errText);
      throw new Error(`AI API error: ${response.status}`);
    }

    const result = await response.json();
    const draft = result.choices?.[0]?.message?.content || "Nem sikerült véleményt generálni.";

    return new Response(JSON.stringify({ draft }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("ai-opinion-draft error:", err);
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
