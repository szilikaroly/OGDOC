import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { requireUser } from "../_shared/auth.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

type AnalysisType = "risk_analysis" | "employer_summary" | "questionnaire_recommend" | "anomaly_detection" | "appointment_suggestion" | "risk_assessment_hazards" | "risk_assessment_actions" | "risk_assessment_summary";

const SYSTEM_PROMPTS: Record<AnalysisType, string> = {
  risk_analysis: `Te egy tapasztalt magyar üzemorvos vagy, aki a munkakörök kockázati tényezőit elemzi.

A kapott beutaló adatok alapján:
1. Értékeld a kockázati tényezők súlyosságát (alacsony / közepes / magas)
2. Határozd meg a szükséges vizsgálatokat prioritás szerint
3. Jelölj meg speciális figyelmeztető jelzéseket
4. Adj javaslatot a vizsgálat fókuszpontjaira

Használj magyar orvosi terminológiát, legyél tömör és strukturált. Használj markdown formázást.`,

  employer_summary: `Te egy foglalkozás-egészségügyi tanácsadó vagy, aki munkáltatók számára készít összefoglalókat.

A kapott munkavállalói egészségügyi adatok alapján:
1. Készíts statisztikai összefoglalót (alkalmasság, lejáró vizsgálatok)
2. Azonosítsd a kockázati mintázatokat
3. Adj javaslatot megelőző intézkedésekre
4. Jelezd a sürgős teendőket

Legyél professzionális, ne közölj egyedi betegadatokat, csak aggregált trendeket. Használj markdown formázást.`,

  questionnaire_recommend: `Te egy üzemorvosi asszisztens AI vagy.

A kapott páciens adatok (törzskarton, korábbi vizsgálatok, munkakör) alapján:
1. Javasolj releváns kérdőíveket a rendelkezésre álló listából
2. Indokold a javaslatokat
3. Határozd meg a prioritást (kötelező / ajánlott / opcionális)

Legyél tömör, használj magyar nyelvet és markdown formázást.`,

  anomaly_detection: `Te egy egészségügyi adat-elemző AI vagy.

A kapott egészségügyi mérési sorozat (vérnyomás, pulzus, vércukor, testsúly) alapján:
1. Azonosítsd a szokatlan értékeket vagy trendeket
2. Jelezd a normál tartománytól való eltéréseket
3. Adj javaslatot további vizsgálatokra ha szükséges
4. Értékeld az összesített egészségügyi trendet

Referencia értékek:
- Vérnyomás: 120/80 normál, >140/90 magas, <90/60 alacsony
- Pulzus: 60-100/perc normál
- Vércukor (éhomi): 3.9-5.6 mmol/L normál, >7.0 diabétesz
- BMI: 18.5-24.9 normál

Használj magyar nyelvet és markdown formázást. Figyelmeztető jelekre használj ⚠️ emojit.`,

  appointment_suggestion: `Te egy foglalkozás-egészségügyi ütemező asszisztens vagy.

A páciens panasza/kérése és a szabad időpontok alapján:
1. Határozd meg milyen típusú vizsgálat szükséges (előzetes, időszakos, soron kívüli)
2. Becsüld meg a szükséges időtartamot
3. Javasolj konkrét időponto(ka)t a szabad slotok közül
4. Ha releváns, javasolj helyszínt és szolgáltatást
5. Jelezd ha sürgős ellátás szükséges

Legyél tömör és praktikus. Használj magyar nyelvet és markdown formázást.`,

  risk_assessment_hazards: `Te egy tapasztalt munkavédelmi szakértő vagy (ISO 45001, MSZ 28001).

A kapott munkaterület, iparág és meglévő veszélyforrások alapján:
1. **Javasolj további releváns veszélyforrásokat**, amiket az értékelő esetleg nem vett figyelembe
2. Minden javasolt veszélyforráshoz add meg:
   - Kategória (fizikai, kémiai, biológiai, ergonómiai, pszichoszociális, gép/berendezés, környezeti, tűz, egyéb)
   - Miért releváns az adott munkaterületen
   - Javasolt súlyosság (1-4) és valószínűség (1-4)
3. Jelezd ha **halmozott kockázat** áll fenn (több veszélyforrás együttes hatása)
4. Adj **jogszabályi hivatkozásokat** ahol releváns (pl. munkavédelmi törvény, OSHA, EU irányelvek)

Használj magyar nyelvet és markdown formázást. Legyél alapos de tömör.`,

  risk_assessment_actions: `Te egy munkavédelmi intézkedési terv szakértő vagy (ISO 45001 kontroll hierarchia).

A kapott veszélyforrások és kockázati értékelések alapján:
1. Minden magas kockázatú tételhez javasolj **konkrét intézkedéseket** a kontroll hierarchia szerint:
   - Kiküszöbölés (elimination)
   - Helyettesítés (substitution)
   - Mérnöki kontrollok (engineering controls)
   - Adminisztratív kontrollok (administrative controls)
   - Egyéni védőeszközök (PPE)
2. Adj **határidő javaslatokat** a sürgősség alapján
3. Jelöld meg a **felelős szervezeti egységet/pozíciót**
4. Becsüld meg a **maradék kockázatot** az intézkedések után
5. Adj **költség-hatékonyság** becslést ahol lehetséges

Használj magyar nyelvet és markdown formázást. Legyél konkrét és megvalósítható.`,

  risk_assessment_summary: `Te egy munkavédelmi dokumentáció szakértő vagy.

A kapott kockázatértékelési adatok alapján készíts **átfogó összefoglaló jelentést**:

1. **Vezetői összefoglaló** — a legfontosabb megállapítások 3-5 mondatban
2. **Kockázati profil** — a munkaterület általános kockázati szintje, főbb veszélyforrások
3. **Kritikus megállapítások** — azonnali beavatkozást igénylő tételek ⚠️
4. **Intézkedési prioritások** — TOP 5 legfontosabb teendő határidővel
5. **Pozitív megállapítások** — meglévő megfelelő kontrollok ✅
6. **Következő lépések** — felülvizsgálati javaslat, további vizsgálatok
7. **Jogszabályi megfelelés** — releváns előírásoknak való megfelelés értékelése

Használj magyar nyelvet és professzionális markdown formázást. A jelentés legyen alkalmas vezetői prezentációra.`,
};

function buildUserPrompt(type: AnalysisType, data: any): string {
  switch (type) {
    case "risk_analysis":
      return `Beutaló adatok:
- Munkakör: ${data.position ?? "Nem megadott"}
- FEOR kód: ${data.feor ?? "Nem megadott"}
- Vizsgálat oka: ${data.exam_reason ?? "Nem megadott"}
- Egység: ${data.unit_name ?? "Nem megadott"}
- Kockázati tényezők: ${JSON.stringify(data.risk_factors ?? {}, null, 2)}

${data.patient_card ? `Páciens törzskarton:
- Krónikus betegségek: ${data.patient_card.chronic_diseases ?? "Nincs"}
- Gyógyszerallergia: ${data.patient_card.drug_allergies ?? "Nincs"}
- Állandó gyógyszerek: ${data.patient_card.regular_medications ?? "Nincs"}
- Dohányzás: ${JSON.stringify(data.patient_card.smoking ?? {})}
- Alkohol: ${data.patient_card.alcohol ?? "Nem megadott"}
- Műtétek: ${data.patient_card.surgeries ?? "Nincs"}` : ""}

Kérlek elemezd a kockázati tényezőket és adj javaslatot.`;

    case "employer_summary":
      return `Munkáltatói egészségügyi adatok:

Munkavállalók száma: ${data.employee_count ?? 0}
Vizsgálati eredmények: ${JSON.stringify(data.exam_results ?? {})}
Lejáró vizsgálatok (30 napon belül): ${data.expiring_count ?? 0}
Lejárt vizsgálatok: ${data.expired_count ?? 0}
Beutaló státuszok: ${JSON.stringify(data.referral_stats ?? {})}
Leggyakoribb kockázati tényezők: ${JSON.stringify(data.top_risks ?? [])}

Kérlek készíts összefoglaló elemzést a munkáltatónak.`;

    case "questionnaire_recommend":
      return `Páciens adatok:
- Foglalkozás: ${data.occupation ?? "Nem megadott"}
- Munkahely: ${data.employer ?? "Nem megadott"}
- Krónikus betegségek: ${data.chronic_diseases ?? "Nincs"}
- Dohányzás: ${data.smoking_status ?? "Nem megadott"}
- Alkohol: ${data.alcohol ?? "Nem megadott"}
- Korábbi vizsgálat típusa: ${data.last_exam_type ?? "Nincs korábbi"}
- Kockázati tényezők: ${JSON.stringify(data.risk_factors ?? [])}

Elérhető kérdőívek:
${(data.available_questionnaires ?? []).map((q: any) => `- ${q.title}: ${q.description ?? "Leírás nélkül"}`).join("\n")}

Kérlek javasolj kérdőíveket a páciens számára.`;

    case "anomaly_detection":
      return `Egészségügyi mérések idősorban (legrégebbitől a legújabbig):

${(data.reports ?? []).map((r: any) => `${r.report_date}: Súly=${r.weight_kg ?? "—"}kg, Magasság=${r.height_cm ?? "—"}cm, RR=${r.blood_pressure_systolic ?? "—"}/${r.blood_pressure_diastolic ?? "—"}, Pulzus=${r.heart_rate ?? "—"}/perc, Vércukor=${r.blood_sugar ?? "—"} mmol/L`).join("\n")}

Megjegyzések: ${(data.reports ?? []).filter((r: any) => r.notes).map((r: any) => `${r.report_date}: ${r.notes}`).join("; ") || "Nincs"}

Kérlek elemezd a trendeket és jelezd az anomáliákat.`;

    case "appointment_suggestion":
      return `Páciens panasza/kérése: ${data.complaint ?? "Nem megadott"}

Szabad időpontok:
${(data.available_slots ?? []).map((s: any) => `- ${new Date(s.start).toLocaleString("hu-HU")} – ${new Date(s.end).toLocaleTimeString("hu-HU")}${s.service_id ? ` (szolg: ${s.service_id})` : ""}${s.location_id ? ` (hely: ${s.location_id})` : ""}`).join("\n")}

Szolgáltatások:
${(data.services ?? []).map((s: any) => `- ${s.name} (${s.duration} perc)`).join("\n")}

Helyszínek:
${(data.locations ?? []).map((l: any) => `- ${l.name}`).join("\n")}

Kérlek javasolj optimális időpontot a panasz alapján.`;

    case "risk_assessment_hazards":
      return `Munkaterület: ${data.workAreaName ?? "Nem megadott"}
Telephely: ${data.siteName ?? "Nem megadott"}
Cég: ${data.companyName ?? "Nem megadott"}
Iparág: ${data.industry ?? "Nem megadott"}

Jelenleg kiválasztott veszélyforrások (${data.selectedHazards?.length ?? 0} db):
${(data.selectedHazards ?? []).map((h: any) => `- ${h.name} (kategória: ${h.category}, súlyosság: ${h.severity})`).join("\n") || "Még nincs kiválasztva"}

Veszélyes anyagok a cégnél:
${(data.substances ?? []).map((s: any) => `- ${s.name} (CAS: ${s.cas_number ?? "N/A"})`).join("\n") || "Nincs nyilvántartva"}

Zajmérési eredmények: ${data.noiseMeasurements ? JSON.stringify(data.noiseMeasurements) : "Nincs adat"}
Vibrációs mérések: ${data.vibrationMeasurements ? JSON.stringify(data.vibrationMeasurements) : "Nincs adat"}

Kérlek javasolj további releváns veszélyforrásokat és értékeld a halmozott kockázatokat.`;

    case "risk_assessment_actions":
      return `Munkaterület: ${data.workAreaName ?? "Nem megadott"}
Cég: ${data.companyName ?? "Nem megadott"}

Azonosított veszélyforrások és kockázati szintek:
${(data.hazards ?? []).map((h: any) => `- ${h.name} | Valószínűség: ${h.probability}/4 | Súlyosság: ${h.severity}/4 | Kockázat: ${h.probability * h.severity} | Jelenlegi kontrollok: ${h.currentControls || "Nincs megadva"} | Tervezett intézkedés: ${h.requiredActions || "Nincs megadva"}`).join("\n") || "Nincs adat"}

Kérlek javasolj konkrét intézkedési tervet a kontroll hierarchia szerint.`;

    case "risk_assessment_summary":
      return `Kockázatértékelés összefoglaló adatok:

Cég: ${data.companyName ?? "Nem megadott"}
Telephely: ${data.siteName ?? "Nem megadott"}
Munkaterület: ${data.workAreaName ?? "Nem megadott"}
Értékelő: ${data.assessorName ?? "Nem megadott"}
Dátum: ${data.assessmentDate ?? "Nem megadott"}

Azonosított veszélyforrások összesen: ${data.totalHazards ?? 0}
Magas kockázatú (intézkedést igénylő): ${data.highRiskCount ?? 0}
Elfogadható kockázatú: ${data.tolerableCount ?? 0}

Részletes veszélylista:
${(data.hazards ?? []).map((h: any) => `- ${h.name} | Kat: ${h.category} | P:${h.probability} × S:${h.severity} = ${h.probability * h.severity} | Kontroll: ${h.currentControls || "—"} | Intézkedés: ${h.requiredActions || "—"} | Maradék: P:${h.residualProbability} × S:${h.residualSeverity} = ${(h.residualProbability ?? 1) * (h.residualSeverity ?? 1)}`).join("\n") || "Nincs adat"}

Zajmérések: ${data.noiseMeasurements ? `${data.noiseMeasurements.length} db mérés` : "Nincs"}
Vibrációs mérések: ${data.vibrationMeasurements ? `${data.vibrationMeasurements.length} db mérés` : "Nincs"}

Megjegyzések: ${data.summaryNotes || "Nincs"}

Kérlek készíts átfogó összefoglaló jelentést.`;

    default:
      return JSON.stringify(data);
  }
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const auth = await requireUser(req, corsHeaders);
    if (!auth.ok) return auth.response;

    const body = await req.json();
    const type = body.type as AnalysisType;
    const data = body.data || body.context;
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    if (!type || !SYSTEM_PROMPTS[type]) {
      return new Response(JSON.stringify({ error: "Invalid analysis type" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: SYSTEM_PROMPTS[type] },
          { role: "user", content: buildUserPrompt(type, data) },
        ],
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Túl sok kérés, kérjük próbálja újra később." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Fizetés szükséges, kérjük töltse fel az egyenlegét." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const t = await response.text();
      console.error("AI gateway error:", response.status, t);
      return new Response(JSON.stringify({ error: "AI hiba" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const result = await response.json();
    const analysis = result.choices?.[0]?.message?.content ?? "";

    return new Response(JSON.stringify({ analysis }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("ai-analysis error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Ismeretlen hiba" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
