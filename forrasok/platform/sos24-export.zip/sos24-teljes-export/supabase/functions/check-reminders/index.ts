import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
import { requireCronSecret } from "../_shared/auth.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-cron-secret",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const unauthorized = requireCronSecret(req, corsHeaders);
  if (unauthorized) return unauthorized;

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, serviceKey);

    const now = new Date();
    const results = {
      expiring_exams: 0,
      appointment_reminders: 0,
      expired_exams: 0,
      expiring_vaccinations: 0,
      lab_control_reminders: 0,
      haziorvos_lab_reminders: 0,
    };

    const in30Days = new Date(now);
    in30Days.setDate(in30Days.getDate() + 30);
    const in7Days = new Date(now);
    in7Days.setDate(in7Days.getDate() + 7);
    const today = now.toISOString().split("T")[0];

    // ── 1. Lejáró vizsgálatok (30 napon belül) ──
    const { data: expiringExams } = await supabase
      .from("examinations")
      .select("id, patient_id, doctor_id, exam_type, valid_until, result, restrictions")
      .gte("valid_until", today)
      .lte("valid_until", in30Days.toISOString().split("T")[0])
      .eq("result", "alkalmas");

    if (expiringExams && expiringExams.length > 0) {
      for (const exam of expiringExams) {
        const daysLeft = Math.ceil(
          (new Date(exam.valid_until!).getTime() - now.getTime()) / (1000 * 60 * 60 * 24)
        );

        let urgency = "info";
        let prefix = "";
        if (daysLeft <= 7) {
          urgency = "urgent";
          prefix = "⚠️ SÜRGŐS: ";
        } else if (daysLeft <= 14) {
          urgency = "warning";
          prefix = "⚡ ";
        }

        const { data: existingNotif } = await supabase
          .from("notifications")
          .select("id")
          .eq("user_id", exam.patient_id)
          .eq("type", `exam_expiring_${daysLeft <= 7 ? "7d" : "30d"}`)
          .eq("link", `/munkavallalo/opinions`)
          .gte("created_at", today + "T00:00:00Z")
          .limit(1);

        if (existingNotif && existingNotif.length > 0) continue;

        await supabase.from("notifications").insert({
          user_id: exam.patient_id,
          type: daysLeft <= 7 ? "exam_expiring_7d" : "exam_expiring_30d",
          title: `${prefix}Alkalmassági vélemény hamarosan lejár`,
          body: `Az Ön "${exam.exam_type}" vizsgálata ${daysLeft} nap múlva lejár (${exam.valid_until}). Kérjük, egyeztessen új vizsgálati időpontot.`,
          link: "/munkavallalo/opinions",
        });

        await supabase.from("notifications").insert({
          user_id: exam.doctor_id,
          type: daysLeft <= 7 ? "exam_expiring_7d" : "exam_expiring_30d",
          title: `${prefix}Páciens vizsgálata hamarosan lejár`,
          body: `Egy páciens "${exam.exam_type}" vizsgálata ${daysLeft} nap múlva lejár (${exam.valid_until}).`,
          link: "/uzemorvos/examinations",
        });

        results.expiring_exams++;
      }
    }

    // ── 2. Már lejárt vizsgálatok (ma lejárt) ──
    const { data: expiredExams } = await supabase
      .from("examinations")
      .select("id, patient_id, doctor_id, exam_type, valid_until")
      .eq("valid_until", today)
      .eq("result", "alkalmas");

    if (expiredExams && expiredExams.length > 0) {
      for (const exam of expiredExams) {
        const { data: existingNotif } = await supabase
          .from("notifications")
          .select("id")
          .eq("user_id", exam.patient_id)
          .eq("type", "exam_expired")
          .gte("created_at", today + "T00:00:00Z")
          .limit(1);

        if (existingNotif && existingNotif.length > 0) continue;

        await supabase.from("notifications").insert({
          user_id: exam.patient_id,
          type: "exam_expired",
          title: "🔴 Alkalmassági vélemény lejárt",
          body: `Az Ön "${exam.exam_type}" vizsgálatának érvényessége ma lejárt. Kérjük, sürgősen egyeztessen új vizsgálatot.`,
          link: "/munkavallalo/opinions",
        });

        const { data: relations } = await supabase
          .from("user_company_relations")
          .select("company_id")
          .eq("user_id", exam.patient_id)
          .eq("role", "munkavallalo")
          .eq("is_active", true);

        if (relations) {
          for (const rel of relations) {
            const { data: employers } = await supabase
              .from("user_company_relations")
              .select("user_id")
              .eq("company_id", rel.company_id)
              .eq("role", "munkaltato")
              .eq("is_active", true);

            if (employers) {
              for (const emp of employers) {
                await supabase.from("notifications").insert({
                  user_id: emp.user_id,
                  type: "employee_exam_expired",
                  title: "🔴 Munkavállaló vizsgálata lejárt",
                  body: `Egy munkavállaló "${exam.exam_type}" vizsgálatának érvényessége ma lejárt.`,
                  link: "/munkaltato/employees",
                });
              }
            }
          }
        }

        results.expired_exams++;
      }
    }

    // ── 3. Időpont-emlékeztetők (holnapi időpontok) ──
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    const tomorrowStr = tomorrow.toISOString().split("T")[0];

    const { data: tomorrowSlots } = await supabase
      .from("appointment_slots")
      .select("id, slot_start, slot_end, service_id")
      .gte("slot_start", tomorrowStr + "T00:00:00Z")
      .lt("slot_start", tomorrowStr + "T23:59:59Z")
      .eq("is_active", true);

    if (tomorrowSlots && tomorrowSlots.length > 0) {
      const slotIds = tomorrowSlots.map((s) => s.id);

      const { data: tomorrowAppts } = await supabase
        .from("appointments")
        .select("id, patient_id, doctor_id, slot_id, service_id, status")
        .in("slot_id", slotIds)
        .in("status", ["pending", "confirmed"]);

      if (tomorrowAppts && tomorrowAppts.length > 0) {
        for (const appt of tomorrowAppts) {
          const slot = tomorrowSlots.find((s) => s.id === appt.slot_id);
          if (!slot) continue;

          const slotTime = new Date(slot.slot_start);
          const timeStr = slotTime.toLocaleTimeString("hu-HU", {
            hour: "2-digit",
            minute: "2-digit",
            timeZone: "Europe/Budapest",
          });

          const { data: existingNotif } = await supabase
            .from("notifications")
            .select("id")
            .eq("user_id", appt.patient_id)
            .eq("type", "appointment_reminder")
            .gte("created_at", today + "T00:00:00Z")
            .limit(1);

          if (existingNotif && existingNotif.length > 0) continue;

          await supabase.from("notifications").insert({
            user_id: appt.patient_id,
            type: "appointment_reminder",
            title: "📅 Időpont-emlékeztető",
            body: `Holnap ${timeStr}-kor időpontja van. Kérjük, jelenjen meg a megadott időpontban.`,
            link: "/munkavallalo/appointments",
          });

          if (appt.doctor_id) {
            await supabase.from("notifications").insert({
              user_id: appt.doctor_id,
              type: "appointment_reminder_doctor",
              title: "📅 Holnapi időpont",
              body: `Holnap ${timeStr}-kor páciense van.`,
              link: "/uzemorvos/appointments",
            });
          }

          results.appointment_reminders++;
        }
      }
    }

    // ── 4. Lejáró alkalmassági vélemények (medical_opinions) ──
    const { data: expiringOpinions } = await supabase
      .from("medical_opinions")
      .select("id, patient_id, doctor_id, company_id, valid_until, status, notes")
      .gte("valid_until", today)
      .lte("valid_until", in30Days.toISOString().split("T")[0])
      .eq("status", "alkalmas");

    if (expiringOpinions && expiringOpinions.length > 0) {
      for (const op of expiringOpinions) {
        if (!op.valid_until) continue;
        const daysLeft = Math.ceil(
          (new Date(op.valid_until).getTime() - now.getTime()) / (1000 * 60 * 60 * 24)
        );

        const { data: existingNotif } = await supabase
          .from("notifications")
          .select("id")
          .eq("user_id", op.patient_id)
          .eq("type", "opinion_expiring")
          .gte("created_at", today + "T00:00:00Z")
          .limit(1);

        if (existingNotif && existingNotif.length > 0) continue;

        const prefix = daysLeft <= 7 ? "⚠️ " : "";

        await supabase.from("notifications").insert({
          user_id: op.patient_id,
          type: "opinion_expiring",
          title: `${prefix}Alkalmassági vélemény ${daysLeft} nap múlva lejár`,
          body: `Az Ön alkalmassági véleménye ${op.valid_until} napon lejár. Kérjük, kezdeményezzen új vizsgálatot.`,
          link: "/munkavallalo/opinions",
        });

        if (op.company_id) {
          const { data: employers } = await supabase
            .from("user_company_relations")
            .select("user_id")
            .eq("company_id", op.company_id)
            .eq("role", "munkaltato")
            .eq("is_active", true);

          if (employers) {
            for (const emp of employers) {
              await supabase.from("notifications").insert({
                user_id: emp.user_id,
                type: "employee_opinion_expiring",
                title: `${prefix}Munkavállaló véleménye ${daysLeft} nap múlva lejár`,
                body: `Egy munkavállaló alkalmassági véleménye ${op.valid_until} napon lejár.`,
                link: "/munkaltato/opinions",
              });
            }
          }
        }
      }
    }

    // ── 5. Lejáró oltások (30 napon belül) ──
    const { data: expiringVaccs } = await supabase
      .from("vaccinations")
      .select("id, user_id, vaccine_name, expiry_date")
      .gte("expiry_date", today)
      .lte("expiry_date", in30Days.toISOString().split("T")[0]);

    if (expiringVaccs && expiringVaccs.length > 0) {
      for (const vacc of expiringVaccs) {
        if (!vacc.expiry_date) continue;
        const daysLeft = Math.ceil(
          (new Date(vacc.expiry_date).getTime() - now.getTime()) / (1000 * 60 * 60 * 24)
        );

        const { data: existingNotif } = await supabase
          .from("notifications")
          .select("id")
          .eq("user_id", vacc.user_id)
          .eq("type", "vaccination_expiring")
          .gte("created_at", today + "T00:00:00Z")
          .limit(1);

        if (existingNotif && existingNotif.length > 0) continue;

        const prefix = daysLeft <= 7 ? "⚠️ " : "";

        await supabase.from("notifications").insert({
          user_id: vacc.user_id,
          type: "vaccination_expiring",
          title: `${prefix}${vacc.vaccine_name} oltás ${daysLeft} nap múlva lejár`,
          body: `Az Ön "${vacc.vaccine_name}" oltásának érvényessége ${vacc.expiry_date} napon lejár. Kérjük, egyeztessen emlékeztető oltást.`,
          link: "/munkavallalo/vaccinations",
        });

        results.expiring_vaccinations++;
      }
    }

    // ── 6. Üzemorvos labor kontroll emlékeztetők (next_lab_control mező alapján) ──
    const in14Days = new Date(now);
    in14Days.setDate(in14Days.getDate() + 14);

    const { data: labControlExams } = await supabase
      .from("examinations")
      .select("id, patient_id, doctor_id, exam_type, next_lab_control")
      .not("next_lab_control", "is", null)
      .gte("next_lab_control", today)
      .lte("next_lab_control", in14Days.toISOString().split("T")[0]);

    if (labControlExams && labControlExams.length > 0) {
      for (const exam of labControlExams) {
        const labDate = exam.next_lab_control as string;
        const daysLeft = Math.ceil(
          (new Date(labDate).getTime() - now.getTime()) / (1000 * 60 * 60 * 24)
        );

        // Dedup
        const { data: existingNotif } = await supabase
          .from("notifications")
          .select("id")
          .eq("user_id", exam.patient_id)
          .eq("type", "lab_control_reminder")
          .gte("created_at", today + "T00:00:00Z")
          .limit(1);

        if (existingNotif && existingNotif.length > 0) continue;

        // Get patient profile for email
        const { data: profile } = await supabase
          .from("profiles")
          .select("full_name, user_id")
          .eq("user_id", exam.patient_id)
          .single();

        const patientName = profile?.full_name || "Páciens";

        // In-app notification
        await supabase.from("notifications").insert({
          user_id: exam.patient_id,
          type: "lab_control_reminder",
          title: `🔬 Labor kontroll esedékes`,
          body: `Az Ön labor kontrollja ${daysLeft} nap múlva esedékes (${labDate}). Kérjük, egyeztessen időpontot.`,
          link: "/munkavallalo/appointments",
        });

        // Notify doctor
        await supabase.from("notifications").insert({
          user_id: exam.doctor_id,
          type: "lab_control_reminder_doctor",
          title: `🔬 Páciens labor kontrollja esedékes`,
          body: `${patientName} labor kontrollja ${daysLeft} nap múlva esedékes (${labDate}).`,
          link: "/uzemorvos/examinations",
        });

        // Send email via transactional email
        try {
          await supabase.functions.invoke("send-transactional-email", {
            body: {
              templateName: "lab-control-reminder",
              to: exam.patient_id,
              data: {
                patientName,
                dueDate: labDate,
                testTypes: exam.exam_type,
                doctorName: "Üzemorvos",
              },
            },
          });
        } catch (emailErr) {
          console.error("Lab control email error:", emailErr);
        }

        results.lab_control_reminders++;
      }
    }

    // ── 7. Háziorvos automatikus labor kontroll (krónikus betegség: 3 hó, nincs: 6 hó) ──
    // Check patient_cards for chronic_diseases and calculate due dates
    const { data: patientCards } = await supabase
      .from("patient_cards")
      .select("user_id, chronic_diseases");

    if (patientCards && patientCards.length > 0) {
      for (const card of patientCards) {
        const hasChronic = !!(card.chronic_diseases && card.chronic_diseases.trim().length > 0);
        const monthsInterval = hasChronic ? 3 : 6;

        // Find last lab control notification or last health report
        const { data: lastLabNotif } = await supabase
          .from("notifications")
          .select("created_at")
          .eq("user_id", card.user_id)
          .eq("type", "haziorvos_lab_control")
          .order("created_at", { ascending: false })
          .limit(1);

        // Also check last health report as a reference point
        const { data: lastReport } = await supabase
          .from("health_reports")
          .select("report_date")
          .eq("user_id", card.user_id)
          .order("report_date", { ascending: false })
          .limit(1);

        // Determine the last lab activity date
        let lastLabDate: Date | null = null;
        if (lastReport && lastReport.length > 0) {
          lastLabDate = new Date(lastReport[0].report_date);
        }
        if (lastLabNotif && lastLabNotif.length > 0) {
          const notifDate = new Date(lastLabNotif[0].created_at);
          if (!lastLabDate || notifDate > lastLabDate) {
            lastLabDate = notifDate;
          }
        }

        // If no previous lab activity, use 6 months ago as baseline so first reminder triggers
        if (!lastLabDate) {
          lastLabDate = new Date(now);
          lastLabDate.setMonth(lastLabDate.getMonth() - monthsInterval);
        }

        // Check if it's time for a reminder (2 weeks before due)
        const dueDate = new Date(lastLabDate);
        dueDate.setMonth(dueDate.getMonth() + monthsInterval);
        const reminderDate = new Date(dueDate);
        reminderDate.setDate(reminderDate.getDate() - 14);

        if (now >= reminderDate && now <= dueDate) {
          // Dedup - check if already sent this month
          const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
          const { data: existingNotif } = await supabase
            .from("notifications")
            .select("id")
            .eq("user_id", card.user_id)
            .eq("type", "haziorvos_lab_control")
            .gte("created_at", monthStart)
            .limit(1);

          if (existingNotif && existingNotif.length > 0) continue;

          const daysLeft = Math.ceil((dueDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
          const dueDateStr = dueDate.toISOString().split("T")[0];

          const { data: profile } = await supabase
            .from("profiles")
            .select("full_name")
            .eq("user_id", card.user_id)
            .single();

          const patientName = profile?.full_name || "Páciens";
          const reason = hasChronic
            ? `Krónikus betegség miatt ${monthsInterval} havonta szükséges labor kontroll.`
            : `Általános szűrés – ${monthsInterval} havonta ajánlott labor kontroll.`;

          // Notify patient
          await supabase.from("notifications").insert({
            user_id: card.user_id,
            type: "haziorvos_lab_control",
            title: `🔬 Labor kontroll esedékes`,
            body: `${reason} Esedékesség: ${dueDateStr} (${daysLeft} nap múlva).`,
            link: "/praxistag/appointments",
          });

          // Notify all háziorvos users
          const { data: haziorvosRoles } = await supabase
            .from("user_roles")
            .select("user_id")
            .eq("role", "haziorvos");

          if (haziorvosRoles) {
            for (const doc of haziorvosRoles) {
              await supabase.from("notifications").insert({
                user_id: doc.user_id,
                type: "haziorvos_lab_control_doctor",
                title: `🔬 ${patientName} – Labor kontroll esedékes`,
                body: `${reason} Esedékesség: ${dueDateStr}.`,
                link: "/haziorvos/patients",
              });
            }
          }

          // Send email
          try {
            await supabase.functions.invoke("send-transactional-email", {
              body: {
                templateName: "lab-control-reminder",
                to: card.user_id,
                data: {
                  patientName,
                  dueDate: dueDateStr,
                  testTypes: hasChronic ? "Krónikus betegség kontroll" : "Általános labor szűrés",
                  doctorName: "Háziorvos",
                },
              },
            });
          } catch (emailErr) {
            console.error("Haziorvos lab control email error:", emailErr);
          }

          results.haziorvos_lab_reminders++;
        }
      }
    }

    return new Response(
      JSON.stringify({ success: true, results, timestamp: now.toISOString() }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    console.error("check-reminders error:", err);
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
