import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.100.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Verify user
    const anonClient = createClient(supabaseUrl, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: { user }, error: userError } = await anonClient.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const { preferences } = await req.json();

    // Gather all patient data in parallel
    const [
      { data: profile },
      { data: patientCard },
      { data: healthJournal },
      { data: foodJournal },
      { data: stoolJournal },
      { data: submissions },
      { data: medications },
      { data: vaccinations },
    ] = await Promise.all([
      supabase.from("profiles").select("*").eq("user_id", user.id).single(),
      supabase.from("patient_cards").select("*").eq("user_id", user.id).single(),
      supabase.from("health_journal").select("*").eq("user_id", user.id).order("entry_date", { ascending: false }).limit(30),
      supabase.from("food_journal").select("*").eq("user_id", user.id).order("entry_date", { ascending: false }).limit(30),
      supabase.from("stool_journal").select("*").eq("user_id", user.id).order("entry_date", { ascending: false }).limit(14),
      supabase.from("questionnaire_submissions").select("id, questionnaire_id, answers, score, risk_category, ai_evaluation, submitted_at").eq("user_id", user.id).order("submitted_at", { ascending: false }).limit(10),
      supabase.from("medication_requests").select("*").eq("patient_id", user.id).eq("status", "approved"),
      supabase.from("vaccinations").select("*").eq("user_id", user.id).order("administered_date", { ascending: false }),
    ]);

    // Get questionnaire titles for context
    const qIds = [...new Set((submissions ?? []).map((s: any) => s.questionnaire_id))];
    let questionnaires: any[] = [];
    if (qIds.length > 0) {
      const { data } = await supabase.from("questionnaires").select("id, title, description").in("id", qIds);
      questionnaires = data ?? [];
    }

    const submissionsWithTitles = (submissions ?? []).map((s: any) => ({
      ...s,
      questionnaire_title: questionnaires.find((q: any) => q.id === s.questionnaire_id)?.title ?? "Unknown",
    }));

    // Calculate age
    let age: number | null = null;
    if (profile?.birth_date) {
      const bd = new Date(profile.birth_date);
      const now = new Date();
      age = now.getFullYear() - bd.getFullYear();
      if (now.getMonth() < bd.getMonth() || (now.getMonth() === bd.getMonth() && now.getDate() < bd.getDate())) age--;
    }

    // Compute averages from health journal
    const hjData = healthJournal ?? [];
    const avgBP = hjData.length > 0 ? {
      systolic: Math.round(hjData.filter((h: any) => h.blood_pressure_systolic).reduce((s: number, h: any) => s + h.blood_pressure_systolic, 0) / (hjData.filter((h: any) => h.blood_pressure_systolic).length || 1)),
      diastolic: Math.round(hjData.filter((h: any) => h.blood_pressure_diastolic).reduce((s: number, h: any) => s + h.blood_pressure_diastolic, 0) / (hjData.filter((h: any) => h.blood_pressure_diastolic).length || 1)),
    } : null;

    const avgCalories = (foodJournal ?? []).length > 0
      ? Math.round((foodJournal ?? []).filter((f: any) => f.calories_estimated).reduce((s: number, f: any) => s + f.calories_estimated, 0) / ((foodJournal ?? []).filter((f: any) => f.calories_estimated).length || 1))
      : null;

    const prompt = `Te egy magyar nyelvű, tapasztalt orvos és életmód tanácsadó vagy. A páciens adatai alapján készíts egy személyre szabott, részletes egészségtervet.

## Páciens adatok

**Profil:**
- Nem: ${profile?.gender === 'ferfi' ? 'Férfi' : profile?.gender === 'no' ? 'Nő' : 'Nem megadott'}
- Kor: ${age ?? 'Nem megadott'}
- Vércsoport: ${profile?.blood_type ?? 'Nem megadott'}

**Törzskarton:**
- Krónikus betegségek: ${patientCard?.chronic_diseases || 'Nincs megadva'}
- Gyógyszerallergiák: ${patientCard?.drug_allergies || 'Nincs megadva'}
- Állandó gyógyszerek: ${patientCard?.regular_medications || 'Nincs megadva'}
- Műtétek: ${patientCard?.surgeries || 'Nincs megadva'}
- Dohányzás: ${JSON.stringify(patientCard?.smoking) || 'Nincs megadva'}
- Alkohol: ${patientCard?.alcohol || 'Nincs megadva'}
- Foglalkozás: ${patientCard?.occupation || 'Nincs megadva'}

**Egészségügyi napló (utolsó 30 nap átlagai):**
- Átlag vérnyomás: ${avgBP ? `${avgBP.systolic}/${avgBP.diastolic} Hgmm` : 'Nincs adat'}
- Átlag napi kalóriabevitel: ${avgCalories ? `${avgCalories} kcal` : 'Nincs adat'}
- Utolsó testsúly: ${hjData.find((h: any) => h.weight_kg)?.weight_kg ? `${hjData.find((h: any) => h.weight_kg).weight_kg} kg` : 'Nincs adat'}

**Széklet napló (utolsó 2 hét):**
${(stoolJournal ?? []).length > 0 ? `Átlag Bristol típus: ${Math.round((stoolJournal ?? []).reduce((s: number, e: any) => s + (e.bristol_type || 4), 0) / (stoolJournal ?? []).length)}, Véres: ${(stoolJournal ?? []).some((e: any) => e.blood_present) ? 'Igen' : 'Nem'}` : 'Nincs adat'}

**Kérdőív eredmények:**
${submissionsWithTitles.length > 0 ? submissionsWithTitles.map((s: any) => `- ${s.questionnaire_title}: Pontszám ${s.score ?? '?'}, Kategória: ${s.risk_category ?? '?'}\n  AI értékelés: ${(s.ai_evaluation ?? '').substring(0, 300)}`).join('\n') : 'Nincs kitöltött kérdőív'}

**Védőoltások:**
${(vaccinations ?? []).length > 0 ? (vaccinations ?? []).map((v: any) => `- ${v.vaccine_name} (${v.administered_date})`).join('\n') : 'Nincs rögzített oltás'}

**Aktív gyógyszerek:**
${(medications ?? []).length > 0 ? (medications ?? []).map((m: any) => `- ${m.medication_name}`).join('\n') : 'Nincs aktív gyógyszerkérés'}

## Páciens preferenciái
${preferences ? `
- Diétás preferencia: ${preferences.diet_preference || 'Nincs megadva'}
- Ételallergiák/intoleranciák: ${preferences.food_allergies || 'Nincs'}
- Mozgás preferencia: ${preferences.exercise_preference || 'Nincs megadva'}
- Fizikai korlátozások: ${preferences.physical_limitations || 'Nincs'}
- Heti edzésre szánt idő: ${preferences.exercise_time || 'Nincs megadva'}
- Célok: ${preferences.goals || 'Nincs megadva'}
` : 'Nincsenek preferenciák megadva'}

## Kérés

Készíts egy átfogó, személyre szabott egészségtervet a következő struktúrában (markdown formátumban):

### 1. Összefoglaló értékelés
Rövid összefoglalás az aktuális egészségi állapotról a rendelkezésre álló adatok alapján.

### 2. Kockázati tényezők
Azonosított kockázati tényezők és figyelmeztető jelek.

### 3. Személyre szabott diétás terv
Napi étkezési javaslatok (reggeli, tízórai, ebéd, uzsonna, vacsora) a preferenciák figyelembevételével. Becsült kalória és makrotápanyag-elosztás.

### 4. Mozgásterv
Heti edzésterv a fizikai állapot és preferenciák alapján. Konkrét gyakorlatok, időtartam, intenzitás.

### 5. Életmód javaslatok
Alvás, stresszkezelés, szokások (dohányzás, alkohol) terén javaslatok.

### 6. Orvosi javaslatok
Szükséges szűrővizsgálatok, kontrollok, hiányzó oltások.

### 7. 30 napos akcióterv
Konkrét, mérhető célok 30 napra lebontva.

FONTOS: A terv legyen gyakorlatias, magyar nyelven írt, és vegye figyelembe a páciens egyéni állapotát. Jelezd, ha valamelyik területen nincs elég adat a megalapozott javaslathoz.`;

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const aiResponse = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: "Te egy tapasztalt orvos és életmód tanácsadó vagy. Részletes, személyre szabott egészségtervet készítesz magyar nyelven." },
          { role: "user", content: prompt },
        ],
        max_tokens: 4000,
      }),
    });

    if (!aiResponse.ok) {
      const errText = await aiResponse.text();
      console.error("AI gateway error:", aiResponse.status, errText);
      if (aiResponse.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded" }), { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      return new Response(JSON.stringify({ error: "AI generation failed" }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const aiData = await aiResponse.json();
    const plan = aiData.choices?.[0]?.message?.content ?? "";

    return new Response(JSON.stringify({ plan, generated_at: new Date().toISOString() }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("ai-health-plan error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
