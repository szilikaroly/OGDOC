import { createClient } from "https://esm.sh/@supabase/supabase-js@2.100.0";
import { startAudit } from "../_shared/audit.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

function isEmail(v: unknown): v is string {
  return typeof v === "string" && /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v) && v.length <= 254;
}
function bounded(v: unknown, max: number): string | null {
  if (v == null) return null;
  if (typeof v !== "string") return null;
  return v.trim().slice(0, max) || null;
}


Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  const audit = startAudit("invite-employer", req);
  let callerId: string | null = null;
  let callerEmail: string | null = null;

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    // Require authenticated super_admin caller
    const authHeader = req.headers.get("Authorization") ?? req.headers.get("authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      await audit.finish({ action: "invite", statusCode: 401, severity: "warn", errorMessage: "missing bearer" });
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const token = authHeader.replace("Bearer ", "");
    const authClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: claimsRes, error: claimsErr } = await authClient.auth.getClaims(token);
    if (claimsErr || !claimsRes?.claims?.sub) {
      await audit.finish({ action: "invite", statusCode: 401, severity: "warn", errorMessage: "invalid token" });
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const admin = createClient(supabaseUrl, serviceKey);
    callerId = claimsRes.claims.sub as string;
    callerEmail = (claimsRes.claims.email as string | undefined) ?? null;
    const { data: isAdmin } = await admin.rpc("has_role", { _user_id: callerId, _role: "super_admin" });
    if (!isAdmin) {
      await audit.finish({ userId: callerId, userEmail: callerEmail, action: "invite", statusCode: 403, severity: "warn", errorMessage: "not super_admin" });
      return new Response(JSON.stringify({ error: "Forbidden: super_admin role required" }), {
        status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const raw = await req.json().catch(() => ({}));
    const email = isEmail(raw?.email) ? (raw.email as string).toLowerCase() : null;
    const full_name = bounded(raw?.full_name, 200);
    const company_name = bounded(raw?.company_name, 200);
    const company_id = bounded(raw?.company_id, 64);
    const tax_number = bounded(raw?.tax_number, 32);
    const address = bounded(raw?.address, 300);
    const contact_phone = bounded(raw?.contact_phone, 32);

    if (!email || !full_name) {
      await audit.finish({ userId: callerId, userEmail: callerEmail, action: "invite", statusCode: 400, severity: "warn", errorMessage: "validation: email/full_name" });
      return new Response(JSON.stringify({ error: "Email és név megadása kötelező" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }



    // 1. Create user with a temporary password, then send password reset
    const tempPassword = crypto.randomUUID() + "Aa1!";
    const { data: userData, error: userError } = await admin.auth.admin.createUser({
      email,
      password: tempPassword,
      email_confirm: true,
      user_metadata: { full_name },
    });

    if (userError) {
      // If user already exists, just get their id
      if (userError.message?.includes("already been registered")) {
        const { data: { users } } = await admin.auth.admin.listUsers();
        const existing = users?.find(u => u.email === email);
        if (!existing) throw userError;

        // Assign role and company even if user exists
        await assignRoleAndCompany(admin, existing.id, company_name, company_id, tax_number, address, contact_phone, full_name);

        await audit.finish({
          userId: callerId, userEmail: callerEmail, action: "invite_existing",
          resourceType: "user", resourceId: existing.id, statusCode: 200, severity: "info",
          metadata: { invited_email: email, company_id: company_id ?? null },
        });
        return new Response(JSON.stringify({
          success: true,
          user_id: existing.id,
          message: "Felhasználó már létezik, cég hozzárendelve"
        }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      throw userError;
    }

    const userId = userData.user!.id;

    // 2. Assign munkaltato role and create/link company
    await assignRoleAndCompany(admin, userId, company_name, company_id, tax_number, address, contact_phone, full_name);

    // 3. Send password reset email so user can set their own password
    const { error: resetError } = await admin.auth.admin.generateLink({
      type: "recovery",
      email,
      options: {
        redirectTo: `${req.headers.get("origin") || supabaseUrl}/reset-password`,
      },
    });

    if (resetError) console.error("Reset email error:", resetError);

    await audit.finish({
      userId: callerId, userEmail: callerEmail, action: "invite_create",
      resourceType: "user", resourceId: userId, statusCode: 200, severity: "info",
      metadata: { invited_email: email, company_id: company_id ?? null, reset_link_error: resetError?.message ?? null },
    });

    return new Response(JSON.stringify({
      success: true,
      user_id: userId,
      message: "Munkáltató létrehozva, jelszóbeállító email elküldve"
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (err) {
    console.error("invite-employer error:", err);
    await audit.finish({
      userId: callerId, userEmail: callerEmail, action: "invite",
      statusCode: 500, severity: "error", errorMessage: (err as Error).message,
    });
    return new Response(JSON.stringify({ error: (err as Error).message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});


async function assignRoleAndCompany(
  admin: any, userId: string, 
  companyName?: string, companyId?: string,
  taxNumber?: string, address?: string, contactPhone?: string,
  fullName?: string
) {
  // Assign munkaltato role (ignore if exists)
  await admin.from("user_roles").upsert(
    { user_id: userId, role: "munkaltato" },
    { onConflict: "user_id,role" }
  );

  let finalCompanyId = companyId;

  // Create company if no existing company selected
  if (!companyId && companyName) {
    const { data: company, error } = await admin.from("companies").insert({
      name: companyName,
      created_by: userId,
      tax_number: taxNumber || null,
      address: address || null,
      contact_phone: contactPhone || null,
      contact_email: null,
    }).select("id").single();
    if (error) throw error;
    finalCompanyId = company.id;
  }

  // Link user to company
  if (finalCompanyId) {
    await admin.from("user_company_relations").upsert(
      { user_id: userId, company_id: finalCompanyId, role: "munkaltato", is_active: true },
      { onConflict: "user_id,company_id" }
    );
  }
}
