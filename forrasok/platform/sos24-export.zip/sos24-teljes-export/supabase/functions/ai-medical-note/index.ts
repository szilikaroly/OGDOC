import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { requireUser, hasAnyRole } from "../_shared/auth.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const auth = await requireUser(req, corsHeaders);
    if (!auth.ok) return auth.response;
    const allowed = await hasAnyRole(auth.user.id, ["super_admin", "uzemorvos", "haziorvos"]);
    if (!allowed) {
      return new Response(JSON.stringify({ error: "Forbidden" }), {
        status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { patient_data, clinical_findings, exam_type } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const systemPrompt = `Te egy tapasztalt magyar üzemorvos vagy. A kapott vizsgálati adatok alapján készíts rövid, strukturált orvosi összefoglalót magyarul.

Az összefoglaló tartalmazza:
1. Vizsgálat típusa és indoka
2. Főbb anamnesztikus adatok
3. Klinikai vizsgálat lényeges leletei
4. Összefoglalás és javaslat

Legyél tömör, szakszerű és pontos. Használj magyar orvosi terminológiát.`;

    const userPrompt = `Vizsgálat típusa: ${exam_type || "Nem megadott"}

Páciens adatok (anamnézis):
${JSON.stringify(patient_data, null, 2)}

Klinikai vizsgálat eredményei:
${JSON.stringify(clinical_findings, null, 2)}

Kérlek készíts strukturált orvosi összefoglalót a fenti adatok alapján.`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Túl sok kérés, kérjük próbálja újra később." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Fizetés szükséges, kérjük töltse fel az egyenlegét." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const t = await response.text();
      console.error("AI gateway error:", response.status, t);
      return new Response(JSON.stringify({ error: "AI hiba történt" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const data = await response.json();
    const note = data.choices?.[0]?.message?.content ?? "";

    return new Response(JSON.stringify({ note }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("ai-medical-note error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Ismeretlen hiba" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
