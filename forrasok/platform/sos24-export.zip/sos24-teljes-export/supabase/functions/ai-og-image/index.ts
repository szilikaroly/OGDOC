import { createClient } from "https://esm.sh/@supabase/supabase-js@2.100.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const AI_URL = "https://ai.gateway.lovable.dev/v1/chat/completions";

async function verifyAdmin(authHeader: string) {
  const sb = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );
  const token = authHeader.replace("Bearer ", "");
  const { data: { user }, error } = await sb.auth.getUser(token);
  if (error || !user) throw new Error("Unauthorized");

  const { data: roles } = await sb.from("user_roles").select("role").eq("user_id", user.id);
  if (!roles?.some((r: any) => r.role === "super_admin")) throw new Error("Forbidden");
  return user.id;
}

function base64ToUint8Array(base64: string): Uint8Array {
  const raw = atob(base64);
  const arr = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) arr[i] = raw.charCodeAt(i);
  return arr;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization") || "";
    await verifyAdmin(authHeader);

    const { title, subtitle, slug, regenerate } = await req.json();
    if (!title || !slug) throw new Error("title and slug are required");

    const sb = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const filePath = `${slug}.png`;

    // Check if image already exists (skip if regenerate)
    if (!regenerate) {
      const { data: existing } = await sb.storage.from("og-images").list("", {
        search: filePath,
      });
      if (existing?.some((f) => f.name === filePath)) {
        const { data: urlData } = sb.storage.from("og-images").getPublicUrl(filePath);
        return new Response(
          JSON.stringify({ success: true, url: urlData.publicUrl, cached: true }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
    }

    // Generate OG image via AI
    const key = Deno.env.get("LOVABLE_API_KEY");
    if (!key) throw new Error("LOVABLE_API_KEY not configured");

    const subtitlePart = subtitle ? `, subtitle text: "${subtitle}"` : "";
    const prompt = `Create a professional Open Graph social media sharing image (1200x630 pixels landscape). 
The image should have:
- A clean, modern gradient background using medical/health industry colors (teal, blue, white tones)
- The title text "${title}" prominently displayed in large, bold white font in the center${subtitlePart}
- A subtle medical cross or stethoscope icon watermark in the corner
- Professional typography with good contrast
- The text "SOS24.hu" small in the bottom right corner as branding
- No photo-realistic elements, keep it graphic/illustrative style
- Make sure the text is clearly readable and properly centered
The overall feel should be professional, trustworthy, and medical/healthcare themed.`;

    const aiRes = await fetch(AI_URL, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${key}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3.1-flash-image-preview",
        messages: [{ role: "user", content: prompt }],
        modalities: ["image", "text"],
      }),
    });

    if (!aiRes.ok) {
      const t = await aiRes.text();
      console.error("AI image error:", aiRes.status, t);
      if (aiRes.status === 429) throw new Error("RATE_LIMIT");
      if (aiRes.status === 402) throw new Error("PAYMENT_REQUIRED");
      throw new Error(`AI image generation failed: ${aiRes.status}`);
    }

    const aiData = await aiRes.json();
    const imageUrl = aiData.choices?.[0]?.message?.images?.[0]?.image_url?.url;
    if (!imageUrl) throw new Error("No image returned from AI");

    // Extract base64 data
    const base64Match = imageUrl.match(/^data:image\/\w+;base64,(.+)$/);
    if (!base64Match) throw new Error("Invalid image data format");

    const imageBytes = base64ToUint8Array(base64Match[1]);

    // Upload to storage
    const { error: uploadError } = await sb.storage
      .from("og-images")
      .upload(filePath, imageBytes, {
        contentType: "image/png",
        upsert: true,
      });

    if (uploadError) {
      console.error("Upload error:", uploadError);
      throw new Error(`Upload failed: ${uploadError.message}`);
    }

    const { data: urlData } = sb.storage.from("og-images").getPublicUrl(filePath);

    return new Response(
      JSON.stringify({ success: true, url: urlData.publicUrl, cached: false }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (e) {
    console.error("ai-og-image error:", e);
    const status =
      e.message === "RATE_LIMIT" ? 429
      : e.message === "PAYMENT_REQUIRED" ? 402
      : e.message === "Unauthorized" ? 401
      : e.message === "Forbidden" ? 403
      : 500;
    return new Response(
      JSON.stringify({ success: false, error: e.message }),
      { status, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
