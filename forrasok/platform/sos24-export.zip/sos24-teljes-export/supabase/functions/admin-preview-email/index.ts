import * as React from 'npm:react@18.3.1'
import { renderAsync } from 'npm:@react-email/components@0.0.22'
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1"
import { TEMPLATES } from '../_shared/transactional-email-templates/registry.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  // Verify JWT + super_admin role
  const authHeader = req.headers.get('Authorization')
  if (!authHeader?.startsWith('Bearer ')) {
    return new Response(JSON.stringify({ error: 'Unauthorized' }), {
      status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }

  const supabaseUrl = Deno.env.get('SUPABASE_URL')!
  const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY')!
  const supabase = createClient(supabaseUrl, supabaseAnonKey, {
    global: { headers: { Authorization: authHeader } },
  })

  const { data: { user }, error: userError } = await supabase.auth.getUser()
  if (userError || !user) {
    return new Response(JSON.stringify({ error: 'Unauthorized' }), {
      status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }

  const userId = user.id

  // Check super_admin role
  const serviceClient = createClient(supabaseUrl, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!)
  const { data: hasRole } = await serviceClient.rpc('has_role', {
    _user_id: userId,
    _role: 'super_admin',
  })
  if (!hasRole) {
    return new Response(JSON.stringify({ error: 'Forbidden' }), {
      status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }

  try {
    const body = await req.json().catch(() => ({}))
    const { templateName, templateData } = body as {
      templateName?: string
      templateData?: Record<string, string>
    }

    // If a specific template is requested, render just that one
    if (templateName) {
      const entry = TEMPLATES[templateName]
      if (!entry) {
        return new Response(JSON.stringify({ error: 'Template not found' }), {
          status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        })
      }

      const props = templateData || entry.previewData || {}
      const html = await renderAsync(React.createElement(entry.component, props))
      const subject = typeof entry.subject === 'function'
        ? entry.subject(props)
        : entry.subject

      return new Response(JSON.stringify({
        templateName,
        displayName: entry.displayName || templateName,
        subject,
        html,
        previewData: entry.previewData || {},
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    // List all templates with rendered previews
    const results = []
    for (const [name, entry] of Object.entries(TEMPLATES)) {
      try {
        const props = entry.previewData || {}
        const html = await renderAsync(React.createElement(entry.component, props))
        const subject = typeof entry.subject === 'function'
          ? entry.subject(props)
          : entry.subject

        results.push({
          templateName: name,
          displayName: entry.displayName || name,
          subject,
          html,
          previewData: entry.previewData || {},
        })
      } catch (err) {
        results.push({
          templateName: name,
          displayName: entry.displayName || name,
          subject: '',
          html: '',
          previewData: {},
          error: err instanceof Error ? err.message : String(err),
        })
      }
    }

    return new Response(JSON.stringify({ templates: results }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  } catch (err) {
    return new Response(JSON.stringify({ error: err instanceof Error ? err.message : String(err) }), {
      status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }
})
