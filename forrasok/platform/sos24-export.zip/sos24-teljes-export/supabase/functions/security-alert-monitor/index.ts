// Cron-invoked function. Aggregates the last 5 minutes of `security_events`
// rows with event_type='rls_denied' grouped by user; if any user exceeds
// ALERT_THRESHOLD, inserts a critical alert event and emails super admins.

import { createClient } from "npm:@supabase/supabase-js@2";
import { requireCronSecret } from "../_shared/auth.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-cron-secret",
};

// Tunable thresholds (no UI for these yet — edit here to adjust).
const WINDOW_MINUTES = 5;
const ALERT_THRESHOLD = 10; // denials per user inside the window
const ALERT_COOLDOWN_MINUTES = 30; // don't re-alert for the same user inside this window

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const unauthorized = requireCronSecret(req, corsHeaders);
  if (unauthorized) return unauthorized;

  const url = Deno.env.get("SUPABASE_URL");
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !serviceKey) {
    return new Response(
      JSON.stringify({ error: "Server configuration error" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  const supabase = createClient(url, serviceKey);
  const since = new Date(
    Date.now() - WINDOW_MINUTES * 60 * 1000,
  ).toISOString();
  const cooldownSince = new Date(
    Date.now() - ALERT_COOLDOWN_MINUTES * 60 * 1000,
  ).toISOString();

  // 1) Aggregate denials
  const { data: summary, error: aggErr } = await supabase.rpc(
    "security_denials_summary",
    { _since: since },
  );
  if (aggErr) {
    console.error("aggregation failed", aggErr);
    return new Response(JSON.stringify({ error: aggErr.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const offenders = (summary ?? []).filter(
    (r: any) => Number(r.denial_count) >= ALERT_THRESHOLD,
  );

  if (offenders.length === 0) {
    return new Response(
      JSON.stringify({ ok: true, checked: (summary ?? []).length, alerted: 0 }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }

  // 2) Fetch super_admin recipients once
  const { data: admins } = await supabase
    .from("user_roles")
    .select("user_id")
    .eq("role", "super_admin");
  const adminIds = (admins ?? []).map((r: any) => r.user_id);
  const { data: adminProfiles } =
    adminIds.length > 0
      ? await supabase.auth.admin
          .listUsers({ page: 1, perPage: 200 })
          .then((res: any) => ({
            data: (res.data?.users ?? []).filter((u: any) =>
              adminIds.includes(u.id),
            ),
          }))
      : { data: [] as any[] };
  const adminEmails: string[] = (adminProfiles ?? [])
    .map((u: any) => u.email)
    .filter(Boolean);

  let alerted = 0;
  for (const o of offenders) {
    const userId: string | null = o.user_id;
    const userEmail: string | null = o.user_email;
    const count: number = Number(o.denial_count);

    // 3) Cooldown check
    const cooldownQ = supabase
      .from("security_events")
      .select("id")
      .eq("event_type", "rls_alert")
      .gte("created_at", cooldownSince)
      .limit(1);
    const { data: recent } = userId
      ? await cooldownQ.eq("user_id", userId)
      : await cooldownQ.is("user_id", null);
    if (recent && recent.length > 0) continue;

    // 4) Insert critical alert row
    await supabase.from("security_events").insert({
      event_type: "rls_alert",
      severity: "critical",
      user_id: userId,
      user_email: userEmail,
      error_message: `${count} RLS denials in the last ${WINDOW_MINUTES} minutes`,
      metadata: {
        threshold: ALERT_THRESHOLD,
        window_minutes: WINDOW_MINUTES,
        sample_messages: o.sample_messages ?? [],
        last_seen: o.last_seen,
      },
    });
    alerted++;

    // 5) Email super admins (best-effort, fan-out through send-transactional-email)
    for (const to of adminEmails) {
      try {
        await fetch(`${url}/functions/v1/send-transactional-email`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${serviceKey}`,
            apikey: serviceKey,
          },
          body: JSON.stringify({
            templateName: "general-notification",
            recipientEmail: to,
            idempotencyKey: `rls-alert-${userId ?? "anon"}-${Math.floor(
              Date.now() / (ALERT_COOLDOWN_MINUTES * 60 * 1000),
            )}`,
            templateData: {
              title: "Biztonsági riasztás – RLS megtagadások",
              message: `${userEmail ?? "Névtelen felhasználó"} az utolsó ${WINDOW_MINUTES} percben ${count} adatbázis-hozzáférést kísérelt meg jogosultság nélkül. Kérjük, ellenőrizd az admin felületen.`,
              ctaLabel: "Biztonsági események megnyitása",
              ctaUrl: `${url.replace(".supabase.co", "")}/admin/security-events`,
            },
          }),
        });
      } catch (e) {
        console.error("email send failed", e);
      }
    }
  }

  return new Response(
    JSON.stringify({
      ok: true,
      checked: (summary ?? []).length,
      alerted,
      threshold: ALERT_THRESHOLD,
      window_minutes: WINDOW_MINUTES,
    }),
    { headers: { ...corsHeaders, "Content-Type": "application/json" } },
  );
});
