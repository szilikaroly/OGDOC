// Role-based integration tests for security-critical Edge Functions.
//
// These tests verify that each function correctly rejects:
//   - anonymous (no Authorization header)
//   - authenticated but unauthorized (regular user without required role)
//
// They do NOT call the live Supabase backend; they exercise the request handlers
// in isolation and assert on the response status / JSON body.
//
// Run with:
//   deno test -A supabase/functions/_tests/integration.test.ts

import { assertEquals } from "https://deno.land/std@0.224.0/assert/mod.ts";

// Minimal env setup so the handlers can import.
Deno.env.set("SUPABASE_URL", "https://example.supabase.co");
Deno.env.set("SUPABASE_ANON_KEY", "anon-test-key");
Deno.env.set("SUPABASE_SERVICE_ROLE_KEY", "service-test-key");
Deno.env.set("RESEND_API_KEY", "test");

// We intercept fetch to avoid real network calls and return canned auth responses.
const realFetch = globalThis.fetch;
type FetchHandler = (req: Request) => Response | Promise<Response>;
let fetchHandler: FetchHandler = () =>
  new Response(JSON.stringify({}), { status: 200 });
globalThis.fetch = ((input: RequestInfo | URL, init?: RequestInit) => {
  const req = input instanceof Request ? input : new Request(input.toString(), init);
  return Promise.resolve(fetchHandler(req));
}) as typeof fetch;

async function callHandler(
  path: string,
  req: Request,
): Promise<Response> {
  // Import the function dynamically so each test gets a fresh module instance.
  const mod = await import(path + `?t=${crypto.randomUUID()}`);
  // Most Edge Functions register via Deno.serve; we capture the handler.
  // To keep tests simple, the functions are written so their default export is the handler.
  // Here we just rely on Deno.serve being shimmed below.
  return await (mod.default ?? handlerHolder.current!)(req);
}

const handlerHolder: { current: ((r: Request) => Promise<Response>) | null } = {
  current: null,
};
// Shim Deno.serve so imported functions register their handler instead of starting a server.
(Deno as unknown as { serve: typeof Deno.serve }).serve = ((
  handler: (r: Request) => Promise<Response>,
) => {
  handlerHolder.current = handler;
  return { finished: Promise.resolve() } as unknown as ReturnType<typeof Deno.serve>;
}) as typeof Deno.serve;

// ---------------- send-notification ----------------

Deno.test("send-notification: anon → 401", async () => {
  fetchHandler = () => new Response("{}", { status: 200 });
  const res = await callHandler(
    "../send-notification/index.ts",
    new Request("http://localhost/send-notification", {
      method: "POST",
      body: JSON.stringify({ recipient_id: crypto.randomUUID(), type: "appointment_reminder" }),
    }),
  );
  assertEquals(res.status, 401);
});

Deno.test("send-notification: bad recipient_id → 400", async () => {
  fetchHandler = (req) => {
    if (req.url.endsWith("/auth/v1/user")) {
      return new Response(
        JSON.stringify({ id: crypto.randomUUID(), email: "u@example.com" }),
        { status: 200, headers: { "content-type": "application/json" } },
      );
    }
    return new Response("{}", { status: 200 });
  };
  const res = await callHandler(
    "../send-notification/index.ts",
    new Request("http://localhost/send-notification", {
      method: "POST",
      headers: { Authorization: "Bearer fake.jwt.token" },
      body: JSON.stringify({ recipient_id: "not-a-uuid", type: "appointment_reminder" }),
    }),
  );
  assertEquals(res.status, 400);
});

// ---------------- invite-employer ----------------

Deno.test("invite-employer: anon → 401", async () => {
  const res = await callHandler(
    "../invite-employer/index.ts",
    new Request("http://localhost/invite-employer", {
      method: "POST",
      body: JSON.stringify({ email: "x@example.com" }),
    }),
  );
  assertEquals(res.status, 401);
});

Deno.test("invite-employer: malformed email → 400", async () => {
  fetchHandler = (req) => {
    if (req.url.endsWith("/auth/v1/user")) {
      return new Response(
        JSON.stringify({ id: crypto.randomUUID(), email: "admin@example.com" }),
        { status: 200, headers: { "content-type": "application/json" } },
      );
    }
    // has_role rpc
    return new Response(JSON.stringify(true), { status: 200 });
  };
  const res = await callHandler(
    "../invite-employer/index.ts",
    new Request("http://localhost/invite-employer", {
      method: "POST",
      headers: { Authorization: "Bearer fake.jwt.token" },
      body: JSON.stringify({ email: "not-an-email", name: "x" }),
    }),
  );
  assertEquals(res.status, 400);
});

// ---------------- generate-pdf ----------------

Deno.test("generate-pdf: anon → 401", async () => {
  const res = await callHandler(
    "../generate-pdf/index.ts",
    new Request("http://localhost/generate-pdf", {
      method: "POST",
      body: JSON.stringify({ type: "opinion", record_id: crypto.randomUUID() }),
    }),
  );
  assertEquals(res.status, 401);
});

Deno.test("generate-pdf: bad type → 400", async () => {
  fetchHandler = (req) => {
    if (req.url.includes("/auth/v1")) {
      return new Response(
        JSON.stringify({ claims: { sub: crypto.randomUUID(), email: "u@example.com" } }),
        { status: 200, headers: { "content-type": "application/json" } },
      );
    }
    return new Response("{}", { status: 200 });
  };
  const res = await callHandler(
    "../generate-pdf/index.ts",
    new Request("http://localhost/generate-pdf", {
      method: "POST",
      headers: { Authorization: "Bearer fake.jwt.token" },
      body: JSON.stringify({ type: "evil", record_id: "x" }),
    }),
  );
  assertEquals(res.status, 400);
});

// ---------------- bulk-create-patients ----------------

Deno.test("bulk-create-patients: anon → 401", async () => {
  const res = await callHandler(
    "../bulk-create-patients/index.ts",
    new Request("http://localhost/bulk-create-patients", {
      method: "POST",
      body: JSON.stringify({ patients: [] }),
    }),
  );
  assertEquals(res.status, 401);
});

Deno.test("bulk-create-patients: empty list → 400", async () => {
  fetchHandler = (req) => {
    if (req.url.endsWith("/auth/v1/user")) {
      return new Response(
        JSON.stringify({ user: { id: crypto.randomUUID(), email: "admin@example.com" } }),
        { status: 200, headers: { "content-type": "application/json" } },
      );
    }
    return new Response(JSON.stringify(true), { status: 200 });
  };
  const res = await callHandler(
    "../bulk-create-patients/index.ts",
    new Request("http://localhost/bulk-create-patients", {
      method: "POST",
      headers: { Authorization: "Bearer fake.jwt.token" },
      body: JSON.stringify({ patients: [] }),
    }),
  );
  assertEquals(res.status, 400);
});

// Restore real fetch after suite.
globalThis.addEventListener("unload", () => {
  globalThis.fetch = realFetch;
});
