import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: authErr } = await supabase.auth.getUser();
    if (authErr || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const userId = user.id;
    const { document_id, file_name, tags, document_type } = await req.json();

    if (!document_id) {
      return new Response(JSON.stringify({ error: "document_id required" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      return new Response(JSON.stringify({ error: "API key not configured" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const adminClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const { data: patientCard } = await adminClient
      .from("patient_cards")
      .select("*")
      .eq("user_id", userId)
      .maybeSingle();

    const { data: profile } = await adminClient
      .from("profiles")
      .select("full_name, birth_date, gender, blood_type")
      .eq("user_id", userId)
      .single();

    const systemPrompt = `Te egy magyar egészségügyi rendszer AI asszisztense vagy. Feladatod kettős:

1. DOKUMENTUM ELEMZÉS: Elemezd a feltöltött dokumentum nevét és típusát, és adj rövid összefoglalót arról, milyen információk lehetnek benne.

2. TÖRZSKARTON FRISSÍTÉS: A dokumentum típusa alapján javasolj törzskarton-frissítéseket. A törzskarton mezői:
   - drug_allergies (gyógyszerallergia)
   - chronic_diseases (krónikus betegségek)
   - regular_medications (állandó gyógyszerek)
   - surgeries (műtétek)
   - occupation (foglalkozás)
   - other_notes (egyéb megjegyzések)

3. ELTÉRÉS DETEKCIÓ: Ha a dokumentum típusa labor, lelet, vagy hasonló, jelezd ha a dokumentum neve/típusa alapján valószínűsíthető, hogy beavatkozást igénylő eredmény lehet (pl. magas vércukor, alacsony hemoglobin, stb). Ilyenkor adj javaslatot:
   - Melyik szakterületre kellene időpontot kérni
   - Milyen további vizsgálat szükséges

Válaszolj JSON formátumban:
{
  "summary": "dokumentum rövid összefoglalója",
  "patient_card_updates": {
    "field_name": "javasolt érték (hozzáfűzés a meglévőhöz)"
  },
  "has_abnormality": false,
  "abnormality_details": "ha van eltérés, részletezés",
  "recommended_specialty": "javasolt szakterület ha eltérés van",
  "recommended_action": "javasolt teendő",
  "urgency": "alacsony|közepes|magas"
}

Ha nincs elég információ az elemzéshez (csak fájlnév alapján dolgozol), add meg amit tudsz és jelezd a korlátokat.`;

    const userPrompt = `Feltöltött dokumentum:
- Fájlnév: ${file_name}
- Dokumentum típus/tag: ${tags?.join(", ") || document_type || "nem megadva"}
- Páciens: ${profile?.full_name || "ismeretlen"}, ${profile?.birth_date ? `szül: ${profile.birth_date}` : ""}, ${profile?.gender === "ferfi" ? "férfi" : profile?.gender === "no" ? "nő" : ""}, vércsoport: ${profile?.blood_type || "ismeretlen"}

Jelenlegi törzskarton:
- Gyógyszerallergia: ${patientCard?.drug_allergies || "nincs adat"}
- Krónikus betegségek: ${patientCard?.chronic_diseases || "nincs adat"}
- Állandó gyógyszerek: ${patientCard?.regular_medications || "nincs adat"}
- Műtétek: ${patientCard?.surgeries || "nincs adat"}
- Foglalkozás: ${patientCard?.occupation || "nincs adat"}
- Egyéb: ${patientCard?.other_notes || "nincs adat"}`;

    const aiRes = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        response_format: { type: "json_object" },
      }),
    });

    if (!aiRes.ok) {
      const errText = await aiRes.text();
      console.error("AI error:", errText);
      return new Response(JSON.stringify({ error: "AI szolgáltatás nem elérhető" }), {
        status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const aiData = await aiRes.json();
    const content = aiData.choices?.[0]?.message?.content;

    let analysis;
    try {
      analysis = JSON.parse(content);
    } catch {
      analysis = { summary: content, patient_card_updates: {}, has_abnormality: false };
    }

    // Save AI analysis to document
    await adminClient.from("documents").update({ ai_analysis: analysis }).eq("id", document_id);

    // Apply patient card updates if any
    const updates = analysis.patient_card_updates || {};
    if (Object.keys(updates).length > 0 && patientCard) {
      const merged: Record<string, string> = {};
      for (const [key, val] of Object.entries(updates)) {
        if (!val || typeof val !== "string") continue;
        const existing = (patientCard as any)[key] || "";
        if (existing && !existing.includes(val as string)) {
          merged[key] = `${existing}, ${val}`;
        } else if (!existing) {
          merged[key] = val as string;
        }
      }
      if (Object.keys(merged).length > 0) {
        await adminClient.from("patient_cards").update(merged).eq("user_id", userId);
      }
    } else if (Object.keys(updates).length > 0 && !patientCard) {
      await adminClient.from("patient_cards").insert({
        user_id: userId,
        ...updates,
      });
    }

    // If abnormality detected, send notification
    if (analysis.has_abnormality) {
      await adminClient.from("notifications").insert({
        user_id: userId,
        type: "document_alert",
        title: "⚠️ Dokumentum elemzés: eltérés észlelve",
        body: `${analysis.abnormality_details || "Eltérés észlelve a feltöltött dokumentumban."} Javasolt: ${analysis.recommended_specialty || "háziorvosi konzultáció"}.`,
        link: "/praxistag/documents",
      });
    }

    return new Response(JSON.stringify(analysis), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err: any) {
    console.error("ai-document-analysis error:", err);
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
