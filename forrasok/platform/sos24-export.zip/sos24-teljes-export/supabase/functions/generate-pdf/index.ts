import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
import { PDFDocument, rgb, StandardFonts } from "https://esm.sh/pdf-lib@1.17.1";
import { startAudit } from "../_shared/audit.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const ALLOWED_TYPES = new Set(["opinion", "examination", "referral"]);

interface GeneratePdfRequest {
  type: "opinion" | "examination" | "referral";
  record_id: string;
}


function sanitizeFileName(str: string): string {
  const charMap: Record<string, string> = {
    á: "a", é: "e", í: "i", ó: "o", ö: "o", ő: "o", ú: "u", ü: "u", ű: "u",
    Á: "A", É: "E", Í: "I", Ó: "O", Ö: "O", Ő: "O", Ú: "U", Ü: "U", Ű: "U",
  };
  return str.replace(/[^\x00-\x7F]/g, (ch) => charMap[ch] ?? "_");
}

const STATUS_LABELS: Record<string, string> = {
  alkalmas: "ALKALMAS",
  nem_alkalmas: "NEM ALKALMAS",
  feltetelesen_alkalmas: "FELTÉTELESEN ALKALMAS",
  ideiglenes: "IDEIGLENESEN NEM ALKALMAS",
};

const REFERRAL_STATUS: Record<string, string> = {
  draft: "Piszkozat",
  sent: "Elküldve",
  completed: "Teljesítve",
};

function formatDate(d: string | null): string {
  if (!d) return "—";
  return new Date(d).toLocaleDateString("hu-HU");
}

// ---- PDF Builder helper ----
const A4_W = 595.28;
const A4_H = 841.89;
const M = 50; // margin
const CW = A4_W - 2 * M; // content width

type PDFFont = Awaited<ReturnType<PDFDocument["embedFont"]>>;
type PDFPage = ReturnType<PDFDocument["addPage"]>;

interface FontSet { regular: PDFFont; bold: PDFFont }

// WinAnsi supports most Hungarian chars (á,é,í,ó,ö,ú,ü) but NOT ő,ű
function safeText(str: string): string {
  return str.replace(/[\r\n]+/g, " ").replace(/ő/g, "ö").replace(/ű/g, "ü").replace(/Ő/g, "Ö").replace(/Ű/g, "Ü");
}

async function loadFonts(doc: PDFDocument): Promise<FontSet> {
  const regular = await doc.embedFont(StandardFonts.Helvetica);
  const bold = await doc.embedFont(StandardFonts.HelveticaBold);
  return { regular, bold };
}

class PdfBuilder {
  doc: PDFDocument;
  page: PDFPage;
  fonts: FontSet;
  y: number;
  lineHeight = 16;

  constructor(doc: PDFDocument, fonts: FontSet) {
    this.doc = doc;
    this.fonts = fonts;
    this.page = doc.addPage([A4_W, A4_H]);
    this.y = A4_H - M;
  }

  safe(str: string): string { return safeText(str); }

  ensureSpace(needed: number) {
    if (this.y - needed < M) {
      this.page = this.doc.addPage([A4_W, A4_H]);
      this.y = A4_H - M;
    }
  }

  text(str: string, opts?: { size?: number; bold?: boolean; center?: boolean; x?: number; maxWidth?: number; color?: [number, number, number] }) {
    const s = this.safe(str);
    const size = opts?.size ?? 10;
    const font = opts?.bold ? this.fonts.bold : this.fonts.regular;
    const color = opts?.color ? rgb(...opts.color) : rgb(0, 0, 0);
    const maxW = opts?.maxWidth ?? CW;

    const words = s.split(" ");
    const lines: string[] = [];
    let currentLine = "";
    for (const word of words) {
      const test = currentLine ? currentLine + " " + word : word;
      if (font.widthOfTextAtSize(test, size) > maxW && currentLine) {
        lines.push(currentLine);
        currentLine = word;
      } else {
        currentLine = test;
      }
    }
    if (currentLine) lines.push(currentLine);

    for (const line of lines) {
      this.ensureSpace(size + 4);
      let x = opts?.x ?? M;
      if (opts?.center) {
        const tw = font.widthOfTextAtSize(line, size);
        x = (A4_W - tw) / 2;
      }
      this.page.drawText(line, { x, y: this.y, size, font, color });
      this.y -= size + 4;
    }
  }

  space(h = 10) { this.y -= h; }

  line(x1?: number, x2?: number) {
    this.ensureSpace(6);
    this.page.drawLine({
      start: { x: x1 ?? M, y: this.y },
      end: { x: x2 ?? (A4_W - M), y: this.y },
      thickness: 0.5,
      color: rgb(0, 0, 0),
    });
    this.y -= 6;
  }

  sectionTitle(title: string) {
    this.space(12);
    this.text(title, { size: 11, bold: true });
    this.line();
    this.space(4);
  }

  field(label: string, value: string, opts?: { x?: number; labelWidth?: number }) {
    const x = opts?.x ?? M;
    const lw = opts?.labelWidth ?? 130;
    this.ensureSpace(14);
    this.page.drawText(this.safe(label), { x, y: this.y, size: 9, font: this.fonts.bold, color: rgb(0, 0, 0) });
    this.page.drawText(this.safe(value || "—"), { x: x + lw, y: this.y, size: 10, font: this.fonts.regular, color: rgb(0, 0, 0) });
    this.y -= 16;
  }

  fieldRow(fields: { label: string; value: string }[]) {
    const colW = CW / fields.length;
    this.ensureSpace(14);
    for (let i = 0; i < fields.length; i++) {
      const x = M + i * colW;
      this.page.drawText(this.safe(fields[i].label), { x, y: this.y, size: 9, font: this.fonts.bold, color: rgb(0, 0, 0) });
      this.page.drawText(this.safe(fields[i].value || "—"), { x: x + 100, y: this.y, size: 10, font: this.fonts.regular, color: rgb(0, 0, 0) });
    }
    this.y -= 16;
  }

  statusBox(label: string, active: boolean, x: number, w: number) {
    const h = 30;
    this.page.drawRectangle({
      x, y: this.y - h, width: w, height: h,
      borderColor: rgb(0, 0, 0), borderWidth: 1.5,
      color: active ? rgb(0, 0, 0) : rgb(1, 1, 1),
    });
    const font = this.fonts.bold;
    const size = 9;
    const safeLabel = this.safe(label);
    const tw = font.widthOfTextAtSize(safeLabel, size);
    this.page.drawText(safeLabel, {
      x: x + (w - tw) / 2, y: this.y - h / 2 - size / 3,
      size, font, color: active ? rgb(1, 1, 1) : rgb(0, 0, 0),
    });
  }

  resultBox(status: string) {
    const label = this.safe(STATUS_LABELS[status] ?? status.toUpperCase());
    this.ensureSpace(50);
    const boxW = CW;
    this.page.drawRectangle({
      x: M, y: this.y - 40, width: boxW, height: 40,
      borderColor: rgb(0, 0, 0), borderWidth: 2,
    });
    const font = this.fonts.bold;
    const size = 16;
    const tw = font.widthOfTextAtSize(label, size);
    this.page.drawText(label, {
      x: M + (boxW - tw) / 2, y: this.y - 25,
      size, font, color: rgb(0, 0, 0),
    });
    this.y -= 50;
  }

  async signatureBlock(doctorName: string, signatureImageBytes?: Uint8Array) {
    this.space(40);
    this.ensureSpace(80);
    const sigX = A4_W - M - 200;

    // Embed signature image if available
    if (signatureImageBytes) {
      try {
        let sigImage;
        try {
          sigImage = await this.doc.embedPng(signatureImageBytes);
        } catch {
          sigImage = await this.doc.embedJpg(signatureImageBytes);
        }
        const sigW = 150;
        const sigH = (sigImage.height / sigImage.width) * sigW;
        this.page.drawImage(sigImage, {
          x: sigX + (180 - sigW) / 2,
          y: this.y - sigH,
          width: sigW,
          height: sigH,
        });
        this.y -= sigH + 4;
      } catch {
        // Fallback to line if image embedding fails
      }
    }

    this.page.drawLine({ start: { x: sigX, y: this.y }, end: { x: sigX + 180, y: this.y }, thickness: 0.5, color: rgb(0, 0, 0) });
    this.y -= 14;
    const lbl = this.safe("Vizsgáló orvos");
    const tw = this.fonts.regular.widthOfTextAtSize(lbl, 8);
    this.page.drawText(lbl, { x: sigX + (180 - tw) / 2, y: this.y, size: 8, font: this.fonts.regular, color: rgb(0.4, 0.4, 0.4) });
    this.y -= 14;
    const name = this.safe(`Dr. ${doctorName}`);
    const nw = this.fonts.bold.widthOfTextAtSize(name, 10);
    this.page.drawText(name, { x: sigX + (180 - nw) / 2, y: this.y, size: 10, font: this.fonts.bold, color: rgb(0, 0, 0) });
    this.y -= 20;
  }

  footer() {
    const txt = this.safe("Ez a dokumentum elektronikusan generált");
    const tw = this.fonts.regular.widthOfTextAtSize(txt, 7);
    this.page.drawText(txt, { x: (A4_W - tw) / 2, y: M - 20, size: 7, font: this.fonts.regular, color: rgb(0.5, 0.5, 0.5) });
  }

  tableRow(cells: string[], widths: number[], opts?: { bold?: boolean; header?: boolean }) {
    const rowH = 18;
    this.ensureSpace(rowH + 2);
    const font = opts?.bold || opts?.header ? this.fonts.bold : this.fonts.regular;
    const size = 9;
    let x = M;
    for (let i = 0; i < cells.length; i++) {
      const w = widths[i];
      if (opts?.header) {
        this.page.drawRectangle({ x, y: this.y - rowH, width: w, height: rowH, color: rgb(0.94, 0.94, 0.94), borderColor: rgb(0.2, 0.2, 0.2), borderWidth: 0.5 });
      } else {
        this.page.drawRectangle({ x, y: this.y - rowH, width: w, height: rowH, borderColor: rgb(0.2, 0.2, 0.2), borderWidth: 0.5 });
      }
      const text = this.safe((cells[i] ?? "").substring(0, 60));
      this.page.drawText(text, { x: x + 4, y: this.y - rowH + 5, size, font, color: rgb(0, 0, 0) });
      x += w;
    }
    this.y -= rowH;
  }
}

// ---- Document generators ----

async function generateOpinionPdf(supabase: any, recordId: string): Promise<{ bytes: Uint8Array; fileName: string; patientId: string }> {
  let opinion: any;
  const { data: directOpinion } = await supabase.from("medical_opinions").select("*").eq("id", recordId).maybeSingle();
  if (directOpinion) {
    opinion = directOpinion;
  } else {
    const { data: exam } = await supabase.from("examinations").select("patient_id, doctor_id").eq("id", recordId).maybeSingle();
    if (exam) {
      const { data: linkedOpinion } = await supabase.from("medical_opinions")
        .select("*").eq("patient_id", exam.patient_id).eq("doctor_id", exam.doctor_id)
        .order("created_at", { ascending: false }).limit(1).maybeSingle();
      opinion = linkedOpinion;
    }
  }
  if (!opinion) throw new Error("Vélemény nem található");

  const { data: patient } = await supabase.from("profiles").select("full_name, taj_number, birth_date, address, mother_name").eq("user_id", opinion.patient_id).single();
  const { data: doctor } = await supabase.from("profiles").select("full_name, signature_url").eq("user_id", opinion.doctor_id).single();

  // Load doctor signature image
  let signatureBytes: Uint8Array | undefined;
  if (doctor?.signature_url) {
    try {
      const sigResp = await fetch(doctor.signature_url);
      if (sigResp.ok) {
        signatureBytes = new Uint8Array(await sigResp.arrayBuffer());
      }
    } catch { /* ignore */ }
  }

  let position = "";
  const { data: linkedExam } = await supabase.from("examinations")
    .select("referral_id").eq("patient_id", opinion.patient_id).eq("doctor_id", opinion.doctor_id)
    .order("created_at", { ascending: false }).limit(1).maybeSingle();
  if (linkedExam?.referral_id) {
    const { data: ref } = await supabase.from("referrals").select("position").eq("id", linkedExam.referral_id).maybeSingle();
    position = ref?.position ?? "";
  }

  let serviceName = "";
  const { data: setting } = await supabase.from("site_settings").select("value").eq("key", "site_name").maybeSingle();
  serviceName = setting?.value ?? "";

  const doc = await PDFDocument.create();
  const fonts = await loadFonts(doc);
  const b = new PdfBuilder(doc, fonts);

  // Header
  b.text("Munkavédelmi szabályzat", { size: 8, color: [0.4, 0.4, 0.4] });
  const headerRight = b.safe("5. sz. melléklet");
  b.page.drawText(headerRight, {
    x: A4_W - M - fonts.regular.widthOfTextAtSize(headerRight, 8),
    y: b.y + 12, size: 8, font: fonts.regular, color: rgb(0.4, 0.4, 0.4),
  });
  b.space(20);
  b.text("Elsőfokú munkaköri/szakmai orvosi", { size: 14, bold: true, center: true });
  b.text("alkalmassági vélemény", { size: 14, bold: true, center: true });
  b.space(20);

  // Service name
  b.field("Foglalkozás-egészségügyi szolgálat:", serviceName, { labelWidth: 230 });
  b.space(10);
  b.text("A vizsgálat eredménye alapján", { size: 10 });
  b.space(6);

  // Patient + position
  b.field("Munkavállaló neve:", patient?.full_name ?? "—", { labelWidth: 140 });
  b.field("Munkakör:", position || "—", { labelWidth: 140 });
  b.space(16);

  // Status boxes
  const isAlkalmas = opinion.status === "alkalmas";
  const isIdeiglenes = opinion.status === "ideiglenes" || opinion.status === "feltetelesen_alkalmas";
  const isNemAlkalmas = opinion.status === "nem_alkalmas";

  b.ensureSpace(50);
  const boxW = 150;
  const gap = (CW - 3 * boxW) / 2;
  b.statusBox("ALKALMAS", isAlkalmas, M, boxW);
  b.statusBox("IDEIGLENESEN NEM ALKALMAS", isIdeiglenes, M + boxW + gap, boxW);
  b.statusBox("NEM ALKALMAS", isNemAlkalmas, M + 2 * (boxW + gap), boxW);
  b.y -= 40;
  b.space(16);

  // Restrictions
  b.text("Nevezett munkaköri/szakmai alkalmasságát érintő korlátozás:", { size: 10, bold: true });
  b.space(4);
  b.text(opinion.notes || "Nincs", { size: 10 });
  b.space(8);

  if (isIdeiglenes && opinion.valid_until) {
    b.text(`Ideiglenesen nem alkalmas minősítés esetén a legközelebbi vizsgálat: ${formatDate(opinion.valid_until)}`, { size: 10 });
    b.space(8);
  }

  // Date
  b.space(20);
  b.field("Kelt:", formatDate(opinion.opinion_date), { labelWidth: 40 });
  b.space(10);
  b.text("P. H.", { size: 10, center: true });

  // Signature
  b.signatureBlock(doctor?.full_name ?? "—", signatureBytes);
  b.footer();

  const pdfBytes = await doc.save();
  const fileName = `velemeny_${opinion.opinion_date}_${sanitizeFileName((patient?.full_name ?? "").replace(/\s/g, "_"))}.pdf`;
  return { bytes: pdfBytes, fileName, patientId: opinion.patient_id };
}

async function generateExaminationPdf(supabase: any, recordId: string): Promise<{ bytes: Uint8Array; fileName: string; patientId: string }> {
  const { data: exam, error } = await supabase.from("examinations").select("*").eq("id", recordId).single();
  if (error || !exam) throw new Error("Vizsgálat nem található");

  const { data: patient } = await supabase.from("profiles").select("full_name, taj_number, birth_date, address, mother_name").eq("user_id", exam.patient_id).single();
  const { data: doctor } = await supabase.from("profiles").select("full_name, signature_url").eq("user_id", exam.doctor_id).single();

  // Load doctor signature image
  let signatureBytes: Uint8Array | undefined;
  if (doctor?.signature_url) {
    try {
      const sigResp = await fetch(doctor.signature_url);
      if (sigResp.ok) {
        signatureBytes = new Uint8Array(await sigResp.arrayBuffer());
      }
    } catch { /* ignore */ }
  }

  // Fetch referral position
  let position = "";
  if (exam.referral_id) {
    const { data: ref } = await supabase.from("referrals").select("position").eq("id", exam.referral_id).maybeSingle();
    position = ref?.position ?? "";
  }

  // Fetch latest questionnaire submission
  let questionnaireRows: { label: string; value: string }[] = [];
  const { data: submissions } = await supabase.from("questionnaire_submissions")
    .select("answers, questionnaire_id")
    .eq("user_id", exam.patient_id)
    .order("submitted_at", { ascending: false })
    .limit(1);
  if (submissions?.length) {
    const sub = submissions[0];
    const answers = sub.answers as Record<string, any>;
    const { data: questionnaire } = await supabase.from("questionnaires")
      .select("fields").eq("id", sub.questionnaire_id).maybeSingle();
    const fields = (questionnaire?.fields ?? []) as Array<{ id: string; label: string }>;
    const fieldMap: Record<string, string> = {};
    for (const f of fields) { fieldMap[f.id] = f.label; }
    for (const [key, val] of Object.entries(answers)) {
      const label = fieldMap[key] ?? key;
      const strVal = typeof val === "boolean" ? (val ? "Igen" : "Nem") : String(val ?? "—");
      questionnaireRows.push({ label, value: strVal });
    }
  }

  const pd = exam.patient_data ?? {};
  const cf = exam.clinical_findings ?? {};

  const doc = await PDFDocument.create();
  const fonts = await loadFonts(doc);
  const b = new PdfBuilder(doc, fonts);

  // Header
  b.text("Vizsgálati Jegyzőkönyv", { size: 16, bold: true, center: true });
  b.text("Foglalkozás-egészségügyi vizsgálat", { size: 10, center: true, color: [0.4, 0.4, 0.4] });
  b.space(16);

  // Patient
  b.sectionTitle("Páciens adatai");
  b.fieldRow([
    { label: "Név:", value: patient?.full_name ?? "—" },
    { label: "TAJ szám:", value: patient?.taj_number ?? "—" },
  ]);
  b.fieldRow([
    { label: "Születési dátum:", value: formatDate(patient?.birth_date) },
    { label: "Anyja neve:", value: patient?.mother_name ?? "—" },
  ]);
  b.field("Lakcím:", patient?.address ?? "—");
  b.field("Munkakör:", position || "—");

  // Exam info
  b.sectionTitle("Vizsgálat");
  b.fieldRow([
    { label: "Típus:", value: exam.exam_type },
    { label: "Dátum:", value: formatDate(exam.created_at) },
  ]);

  // Anamnesis
  b.sectionTitle("Anamnézis");
  b.field("Panaszok:", pd.complaints ?? "—");
  b.field("Kórelőzmény:", pd.anamnesis ?? "—");
  b.field("Korábbi betegségek:", pd.diseases ?? "—");
  b.field("Kórházi kezelés:", pd.hospital ?? "—");
  b.field("Műtétek:", pd.surgeries ?? "—");
  b.field("Gyógyszerek:", pd.medications ?? "—");
  b.field("Allergiák:", pd.allergies ?? "—");
  b.field("Életmód:", pd.lifestyle ?? "—");

  // Questionnaire
  if (questionnaireRows.length) {
    b.sectionTitle("Kérdőív válaszok");
    const colW = [CW * 0.45, CW * 0.55];
    b.tableRow(["Kérdés", "Válasz"], colW, { header: true });
    for (const row of questionnaireRows) {
      b.tableRow([row.label, row.value], colW);
    }
  }

  // Clinical findings table — all fields
  const clinicalLabels: Record<string, string> = {
    blood_pressure: "Vérnyomás", pulse: "Pulzus", heart_rate: "Pulzus", bmi: "BMI",
    weight: "Testsúly (kg)", height: "Testmagasság (cm)",
    ekg: "EKG", lungs: "Tüdő", abdomen: "Has",
    skin: "Bőr", tattoo: "Tetoválás", body_status: "Általános állapot",
    oral_pharynx: "Szájüreg/Garat", teeth: "Fogak", tongue: "Nyelv",
    pharynx: "Garat", lymph_nodes: "Nyirokcsomók", thyroid: "Pajzsmirigy",
    cardiovascular: "Szív-érrendszer", vessels: "Erek", varicosity: "Visszér",
    lung_xray_date: "Mellkas rtg. dátuma", spirometry: "Spirometria",
    fvc: "FVC", fev1: "FEV1", pef: "PEF", fev1_fvc: "FEV1/FVC", vc: "VC",
    abdomen_palpation: "Has tapintás", bowel_sounds: "Bélhangok",
    musculoskeletal: "Mozgásszervi",
    vision_right: "Visus jobb", vision_left: "Visus bal",
    vision_right_corr: "Visus jobb (korr.)", vision_left_corr: "Visus bal (korr.)",
    color_vision: "Színlátás",
    hearing: "Hallás",
    hearing_right_speech: "Hallás jobb (beszéd)", hearing_right_whisper: "Hallás jobb (suttogás)",
    hearing_left_speech: "Hallás bal (beszéd)", hearing_left_whisper: "Hallás bal (suttogás)",
    audiometry: "Audiometria",
    neurology: "Neurológia",
    neuro_consciousness: "Tudatállapot", neuro_orientation: "Orientáció",
    neuro_focal: "Góctünet", neuro_reflexes: "Reflexek",
    neuro_romberg: "Romberg", neuro_tremor: "Tremor", neuro_blind_walk: "Vakon járás",
    other: "Egyéb",
  };
  const clinicalEntries = Object.entries(cf as Record<string, string>).filter(([, v]) => v);
  if (clinicalEntries.length) {
    b.sectionTitle("Klinikai vizsgálat");
    const colW = [CW * 0.35, CW * 0.65];
    b.tableRow(["Vizsgálat", "Eredmény"], colW, { header: true });
    for (const [k, v] of clinicalEntries) {
      b.tableRow([clinicalLabels[k] ?? k, String(v)], colW);
    }
  }

  b.space(12);
  b.resultBox(exam.result);

  if (exam.restrictions) {
    b.sectionTitle("Korlátozások");
    b.text(exam.restrictions, { size: 10 });
  }
  if (exam.valid_until) {
    b.field("Érvényesség:", formatDate(exam.valid_until));
  }
  if (exam.ai_notes) {
    b.sectionTitle("Orvosi jegyzet");
    b.text(exam.ai_notes, { size: 10 });
  }

  b.signatureBlock(doctor?.full_name ?? "—", signatureBytes);
  b.footer();

  const pdfBytes = await doc.save();
  const fileName = `vizsgalat_${exam.created_at.substring(0, 10)}_${sanitizeFileName((patient?.full_name ?? "").replace(/\s/g, "_"))}.pdf`;
  return { bytes: pdfBytes, fileName, patientId: exam.patient_id };
}

async function generateReferralPdf(supabase: any, recordId: string): Promise<{ bytes: Uint8Array; fileName: string; patientId: string }> {
  const { data: ref, error } = await supabase.from("referrals").select("*").eq("id", recordId).single();
  if (error || !ref) throw new Error("Beutaló nem található");

  const { data: employee } = await supabase.from("profiles").select("full_name, taj_number, birth_date, address, mother_name").eq("user_id", ref.employee_id).single();
  const { data: company } = await supabase.from("companies").select("name, address, tax_number, contact_phone").eq("id", ref.company_id).single();
  const { data: creator } = await supabase.from("profiles").select("full_name").eq("user_id", ref.created_by).single();

  const doc = await PDFDocument.create();
  const fonts = await loadFonts(doc);
  const b = new PdfBuilder(doc, fonts);

  b.text("Beutaló", { size: 16, bold: true, center: true });
  b.text("Foglalkozás-egészségügyi alkalmassági vizsgálatra", { size: 10, center: true, color: [0.4, 0.4, 0.4] });
  b.space(16);

  b.sectionTitle("Munkáltató adatai");
  b.fieldRow([
    { label: "Cégnév:", value: company?.name ?? "—" },
    { label: "Adószám:", value: company?.tax_number ?? "—" },
  ]);
  b.fieldRow([
    { label: "Cím:", value: company?.address ?? "—" },
    { label: "Telefon:", value: company?.contact_phone ?? "—" },
  ]);

  b.sectionTitle("Munkavállaló adatai");
  b.fieldRow([
    { label: "Név:", value: employee?.full_name ?? "—" },
    { label: "TAJ szám:", value: employee?.taj_number ?? "—" },
  ]);
  b.fieldRow([
    { label: "Születési dátum:", value: formatDate(employee?.birth_date) },
    { label: "Anyja neve:", value: employee?.mother_name ?? "—" },
  ]);
  b.field("Lakcím:", employee?.address ?? "—");

  b.sectionTitle("Munkakör");
  b.fieldRow([
    { label: "Munkakör:", value: ref.position ?? "—" },
    { label: "FEOR:", value: ref.feor ?? "—" },
  ]);
  b.fieldRow([
    { label: "Egység:", value: ref.unit_name ?? "—" },
    { label: "Vizsgálat oka:", value: ref.exam_reason },
  ]);

  // Risk factors — resolve i18n keys to Hungarian labels for PDF
  const I18N_RISK_LABELS: Record<string, string> = {
    "referralRiskFactors.manualHandling": "Kézi anyagmozgatás",
    "referralRiskFactors.heavyPhysical": "Fokozott fizikai igénybevétel",
    "referralRiskFactors.forcedPosition": "Kényszerhelyzet",
    "referralRiskFactors.screenWork": "Képernyős munkavégzés",
    "referralRiskFactors.noise": "Zaj",
    "referralRiskFactors.vibrationHand": "Rezgés (kéz-kar)",
    "referralRiskFactors.vibrationBody": "Rezgés (egésztest)",
    "referralRiskFactors.ionizingRadiation": "Ionizáló sugárzás",
    "referralRiskFactors.nonIonizingRadiation": "Nem ionizáló sugárzás",
    "referralRiskFactors.chemicalAirway": "Vegyi anyag (légúti)",
    "referralRiskFactors.chemicalSkin": "Vegyi anyag (bőr)",
    "referralRiskFactors.biologicalAgent": "Biológiai kóroki tényező",
    "referralRiskFactors.dustFibrogenic": "Por (fibrogenizáló)",
    "referralRiskFactors.dustNonFibrogenic": "Por (nem fibrogenizáló)",
    "referralRiskFactors.nightShift": "Éjszakai műszak",
    "referralRiskFactors.highTemperature": "Magas hőmérséklet",
    "referralRiskFactors.lowTemperature": "Alacsony hőmérséklet",
    "referralRiskFactors.heightWork": "Magasban végzett munka",
    "referralRiskFactors.depthWork": "Mélységben végzett munka",
    "referralRiskFactors.driving": "Gépjárművezetés",
    "referralRiskFactors.aloneWork": "Egyedül végzett munka",
    "referralRiskFactors.psychosocial": "Fokozott pszichés terhelés",
    "referralRiskFactors.other": "Egyéb",
    "riskFactors.chemicals": "Vegyi anyagok",
    "riskFactors.noise": "Zaj",
    "riskFactors.vibration": "Rezgés",
    "riskFactors.dust": "Por",
    "riskFactors.screenWork": "Képernyő előtti munkavégzés",
    "riskFactors.heavyPhysical": "Nehéz fizikai munka",
    "riskFactors.nightShift": "Éjszakai műszak",
    "riskFactors.heightWork": "Magasban végzett munka",
    "riskFactors.heatStress": "Hőterhelés",
    "riskFactors.biologicalRisk": "Biológiai kockázat",
    "riskFactors.radiation": "Sugárzás",
    "riskFactors.forcedPosition": "Kényszerhelyzet",
    "riskFactors.psychosocial": "Pszichoszociális terhelés",
    "riskFactors.drivingOperating": "Vezetés / gépkezelés",
  };

  const riskFactors = ref.risk_factors ?? {};
  const riskEntries = Object.entries(riskFactors as Record<string, boolean>);
  if (riskEntries.length) {
    b.sectionTitle("Kockázati tényezők");
    for (const [name, active] of riskEntries) {
      const label = I18N_RISK_LABELS[name] || name;
      const prefix = active ? "✓ " : "☐ ";
      b.text(`${prefix}${label}`, { size: 9, bold: active as boolean });
    }
  }

  b.space(8);
  b.fieldRow([
    { label: "Státusz:", value: REFERRAL_STATUS[ref.status] ?? ref.status },
    { label: "Létrehozva:", value: formatDate(ref.created_at) },
  ]);

  // Signature
  b.space(40);
  b.ensureSpace(50);
  const sigX = A4_W - M - 200;
  b.page.drawLine({ start: { x: sigX, y: b.y }, end: { x: sigX + 180, y: b.y }, thickness: 0.5, color: rgb(0, 0, 0) });
  b.y -= 14;
  const lbl = b.safe("Munkáltató képviselője");
  const tw = fonts.regular.widthOfTextAtSize(lbl, 8);
  b.page.drawText(lbl, { x: sigX + (180 - tw) / 2, y: b.y, size: 8, font: fonts.regular, color: rgb(0.4, 0.4, 0.4) });
  b.y -= 14;
  const nm = b.safe(creator?.full_name ?? "—");
  const nw = fonts.bold.widthOfTextAtSize(nm, 10);
  b.page.drawText(nm, { x: sigX + (180 - nw) / 2, y: b.y, size: 10, font: fonts.bold, color: rgb(0, 0, 0) });

  b.footer();

  const pdfBytes = await doc.save();
  const fileName = `beutalo_${ref.created_at.substring(0, 10)}_${sanitizeFileName((employee?.full_name ?? "").replace(/\s/g, "_"))}.pdf`;
  return { bytes: pdfBytes, fileName, patientId: ref.employee_id };
}

// ---- Main handler ----

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const audit = startAudit("generate-pdf", req);
  let callerId: string | null = null;
  let callerEmail: string | null = null;
  let auditType: string | null = null;
  let auditRecordId: string | null = null;

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    // Reject obviously oversized payloads early.
    const contentLength = Number(req.headers.get("content-length") ?? 0);
    if (contentLength > 500_000) {
      await audit.finish({ action: "generate", statusCode: 413, severity: "warn", errorMessage: `payload too large: ${contentLength}` });
      return new Response(JSON.stringify({ error: "Payload too large" }), {
        status: 413, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Require authentication
    const authHeader = req.headers.get("Authorization") ?? req.headers.get("authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      await audit.finish({ action: "generate", statusCode: 401, severity: "warn", errorMessage: "missing bearer" });
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const token = authHeader.replace("Bearer ", "");
    const authClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: claimsRes, error: claimsErr } = await authClient.auth.getClaims(token);
    if (claimsErr || !claimsRes?.claims?.sub) {
      await audit.finish({ action: "generate", statusCode: 401, severity: "warn", errorMessage: "invalid token" });
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    callerId = claimsRes.claims.sub as string;
    callerEmail = (claimsRes.claims.email as string | undefined) ?? null;

    const supabase = createClient(supabaseUrl, serviceKey);

    const raw = await req.json().catch(() => ({})) as Partial<GeneratePdfRequest>;
    const type = raw?.type;
    const record_id = raw?.record_id;

    if (!type || !ALLOWED_TYPES.has(type) || !record_id || !UUID_RE.test(record_id)) {
      await audit.finish({
        userId: callerId, userEmail: callerEmail, action: "generate",
        statusCode: 400, severity: "warn", errorMessage: "invalid type or record_id",
        metadata: { type: type ?? null },
      });
      return new Response(JSON.stringify({ error: "Invalid type or record_id" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    auditType = type;
    auditRecordId = record_id;

    let result: { bytes: Uint8Array; fileName: string; patientId: string };
    const docLabels: Record<string, string> = { opinion: "Alkalmassági vélemény", examination: "Vizsgálati jegyzőkönyv", referral: "Beutaló" };

    switch (type) {
      case "opinion":
        result = await generateOpinionPdf(supabase, record_id);
        break;
      case "examination":
        result = await generateExaminationPdf(supabase, record_id);
        break;
      case "referral":
        result = await generateReferralPdf(supabase, record_id);
        break;
      default:
        return new Response(JSON.stringify({ error: "Invalid type" }), {
          status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
    }

    // Authorization: caller must be the patient, a doctor (uzemorvos/haziorvos),
    // super_admin, or an active employer of the patient.
    const [{ data: rolesRows }, { data: empRel }] = await Promise.all([
      supabase.from("user_roles").select("role").eq("user_id", callerId),
      supabase.rpc("is_employer_of_patient", { _employer_id: callerId, _patient_id: result.patientId }),
    ]);
    const roles = (rolesRows ?? []).map((r: { role: string }) => r.role);
    const allowed =
      callerId === result.patientId ||
      roles.includes("super_admin") ||
      roles.includes("uzemorvos") ||
      roles.includes("haziorvos") ||
      empRel === true;
    if (!allowed) {
      await audit.finish({
        userId: callerId, userEmail: callerEmail, action: "generate",
        resourceType: type, resourceId: record_id,
        statusCode: 403, severity: "warn", errorMessage: "not allowed for patient",
        metadata: { patient_id: result.patientId },
      });
      return new Response(JSON.stringify({ error: "Forbidden" }), {
        status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Upload PDF to storage
    const storagePath = `${result.patientId}/${type}/${result.fileName}`;

    const { error: uploadError } = await supabase.storage
      .from("medical-documents")
      .upload(storagePath, result.bytes, {
        contentType: "application/pdf",
        upsert: true,
      });

    if (uploadError) throw new Error(`Upload failed: ${uploadError.message}`);

    // Track in documents table
    await supabase.from("documents").insert({
      user_id: result.patientId,
      document_type: type,
      related_id: record_id,
      file_name: result.fileName,
      file_path: storagePath,
      file_size: result.bytes.length,
      mime_type: "application/pdf",
      created_by: callerId,
    });

    await audit.finish({
      userId: callerId, userEmail: callerEmail, action: "generate",
      resourceType: type, resourceId: record_id,
      statusCode: 200, severity: "info",
      metadata: { patient_id: result.patientId, file_size: result.bytes.length },
    });

    return new Response(
      JSON.stringify({
        success: true,
        file_path: storagePath,
        file_name: result.fileName,
        document_type: docLabels[type],
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    await audit.finish({
      userId: callerId, userEmail: callerEmail, action: "generate",
      resourceType: auditType, resourceId: auditRecordId,
      statusCode: 500, severity: "error", errorMessage: (err as Error).message,
    });
    return new Response(JSON.stringify({ error: (err as Error).message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

