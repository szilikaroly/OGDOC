import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { messages, context } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    // Build dynamic context from DB
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const sb = createClient(supabaseUrl, supabaseKey);

    // Fetch services, locations, navigation, activities for context
    const [servicesRes, locationsRes, navRes, activitiesRes, settingsRes] = await Promise.all([
      sb.from("services").select("name, description, duration_min, price").eq("is_active", true),
      sb.from("locations").select("name, address, city, phone, email, google_maps_url").eq("is_active", true),
      sb.from("navigation_links").select("label, href").eq("is_active", true).order("sort_order"),
      sb.from("activities").select("name, short_description, slug").eq("is_active", true).order("sort_order"),
      sb.from("site_settings").select("key, value"),
    ]);

    const services = servicesRes.data ?? [];
    const locations = locationsRes.data ?? [];
    const navLinks = navRes.data ?? [];
    const activities = activitiesRes.data ?? [];
    const settings: Record<string, string> = {};
    (settingsRes.data ?? []).forEach((s: any) => { settings[s.key] = s.value ?? ""; });

    const siteName = settings["site_name"] || "SOS 24 KFT";

    // Role-specific workflow guidance
    const roleWorkflows: Record<string, string> = {
      munkavallalo: `
MUNKAVÁLLALÓ (Employee) workflow:
1. Profil kitöltése (személyes adatok, TAJ szám, születési dátum)
2. Egészségügyi napló vezetése (vérnyomás, súly, pulzus)
3. Időpontfoglalás vizsgálatra
4. Kérdőívek kitöltése (ha kapott)
5. Dokumentumok megtekintése (vélemények, leletek)
6. Oltási napló
7. GDPR beállítások kezelése
Útvonalak: /munkavallalo, /munkavallalo/profile, /munkavallalo/appointments, /munkavallalo/health, /munkavallalo/journal, /munkavallalo/vaccinations, /munkavallalo/opinions, /munkavallalo/questionnaires, /munkavallalo/documents, /munkavallalo/settings`,
      munkaltato: `
MUNKÁLTATÓ (Employer) workflow:
1. Cég adatok kezelése
2. Munkavállalók kezelése, hozzáadása
3. Beutalók létrehozása és követése
4. Alkalmassági vélemények megtekintése
5. Dokumentumok kezelése
6. Riportok generálása
Útvonalak: /munkaltato, /munkaltato/company, /munkaltato/employees, /munkaltato/referrals, /munkaltato/opinions, /munkaltato/documents, /munkaltato/reports`,
      uzemorvos: `
ÜZEMORVOS (Occupational Doctor) workflow:
1. Beutalók áttekintése
2. Vizsgálatok elvégzése
3. Alkalmassági vélemények kiadása
4. Időpontok kezelése
5. Cégek és munkavállalók kezelése
6. Statisztikák
Útvonalak: /uzemorvos, /uzemorvos/examinations, /uzemorvos/appointments, /uzemorvos/referrals, /uzemorvos/opinions, /uzemorvos/companies, /uzemorvos/employees, /uzemorvos/statistics`,
      haziorvos: `
HÁZIORVOS (GP Doctor) workflow:
1. Páciensek kezelése
2. Időpontok kezelése
3. Kérések feldolgozása
4. Recept kérések kezelése
5. Dokumentumok, oltások, igazolások
Útvonalak: /haziorvos, /haziorvos/patients, /haziorvos/appointments, /haziorvos/requests, /haziorvos/med-requests, /haziorvos/documents, /haziorvos/vaccinations, /haziorvos/certificates`,
      praxistag: `
PRAXISTAG (Practice Day Patient) workflow:
1. Profil kitöltése
2. Időpontfoglalás
3. Egészségügyi adatok megtekintése
4. Gyógyszerek
5. Beutaló kérés
6. Dokumentumok
Útvonalak: /praxistag, /praxistag/profile, /praxistag/appointments, /praxistag/health, /praxistag/medications, /praxistag/referral-request, /praxistag/documents`,
    };

    const activeRole = context?.activeRole || null;
    const isLoggedIn = context?.isLoggedIn || false;
    const currentPath = context?.currentPath || "/";

    const roleGuidance = activeRole && roleWorkflows[activeRole]
      ? roleWorkflows[activeRole]
      : Object.values(roleWorkflows).join("\n");

    const systemPrompt = `Te vagy ${siteName} AI asszisztense. Segítesz a felhasználóknak eligazodni az oldalon, megérteni a szolgáltatásokat, és végigvezetni őket a munkafolyamatokon.

VISELKEDÉS:
- Mindig magyarul válaszolj (kivéve ha más nyelven kérdeznek)
- Legyél barátságos, segítőkész és tömör
- Ha navigációs kérdés, add meg a pontos útvonalat
- Ha workflow kérdés, lépésről lépésre vezesd végig
- Ha nem tudsz válaszolni, irányítsd az ügyfélszolgálathoz

JELENLEGI KONTEXTUS:
- Aktuális oldal: ${currentPath}
- Bejelentkezve: ${isLoggedIn ? "Igen" : "Nem"}
- Szerepkör: ${activeRole || "Vendég (nincs bejelentkezve)"}

OLDAL NAVIGÁCIÓ:
${navLinks.map((l) => `- ${l.label}: ${l.href}`).join("\n")}

SZOLGÁLTATÁSOK:
${services.map((s) => `- ${s.name}: ${s.description || ""} (${s.duration_min} perc${s.price ? `, ${s.price} Ft` : ""})`).join("\n")}

HELYSZÍNEK:
${locations.map((l) => `- ${l.name}: ${l.address || ""}, ${l.city || ""} | Tel: ${l.phone || "-"} | Email: ${l.email || "-"}${l.google_maps_url ? ` | Térkép: ${l.google_maps_url}` : ""}`).join("\n")}

TEVÉKENYSÉGEK:
${activities.map((a) => `- ${a.name}: ${a.short_description || ""} (oldal: /tevekenyseg/${a.slug})`).join("\n")}

SZEREPKÖR WORKFLOW-K:
${roleGuidance}

PUBLIKUS OLDALAK:
- Főoldal: /
- Bejelentkezés: /login
- Regisztráció: /register
- Jelszó visszaállítás: /reset-password

Ha a felhasználó nem bejelentkezett, segíts neki megérteni a szolgáltatásokat, és irányítsd a regisztrációhoz vagy bejelentkezéshez.
Ha bejelentkezett, vezesd végig az aktuális szerepkörének megfelelő workflow-n.`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          ...messages,
        ],
        stream: true,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Túl sok kérés, kérjük próbáld később." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "A szolgáltatás jelenleg nem elérhető." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const t = await response.text();
      console.error("AI gateway error:", response.status, t);
      return new Response(JSON.stringify({ error: "AI hiba történt." }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(response.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (e) {
    console.error("chatbot error:", e);
    return new Response(
      JSON.stringify({ error: e instanceof Error ? e.message : "Ismeretlen hiba" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
