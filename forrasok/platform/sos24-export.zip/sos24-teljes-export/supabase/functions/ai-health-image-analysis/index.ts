import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { requireUser } from "../_shared/auth.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const PROMPTS: Record<string, string> = {
  blood_pressure: `You are a medical device reader. Analyze the photo of a blood pressure monitor display.
Extract the systolic (top number), diastolic (bottom number), and heart rate/pulse if visible.
Return structured data using the provided tool.`,

  food: `You are a nutritionist AI. Analyze the food photo.
Identify all visible foods and estimate:
- Total calories
- Protein (g), Carbs (g), Fat (g), Fiber (g)
- A brief food description in Hungarian
Be realistic with portion sizes. Indicate these are estimates.`,

  stool: `You are a gastroenterology assistant. Analyze the image to classify using the Bristol Stool Scale (1-7):
1 = Separate hard lumps (hard to pass)
2 = Sausage-shaped but lumpy
3 = Sausage with cracks on surface
4 = Smooth soft sausage or snake
5 = Soft blobs with clear-cut edges
6 = Fluffy pieces with ragged edges
7 = Watery, no solid pieces
Also identify color and any notable characteristics.`,
};

const TOOLS: Record<string, any> = {
  blood_pressure: {
    type: "function",
    function: {
      name: "blood_pressure_result",
      description: "Return blood pressure reading from the monitor photo",
      parameters: {
        type: "object",
        properties: {
          systolic: { type: "number", description: "Systolic value (top number)" },
          diastolic: { type: "number", description: "Diastolic value (bottom number)" },
          heart_rate: { type: "number", description: "Heart rate/pulse if visible, null otherwise" },
          confidence: { type: "string", enum: ["high", "medium", "low"] },
        },
        required: ["systolic", "diastolic", "confidence"],
      },
    },
  },
  food: {
    type: "function",
    function: {
      name: "food_analysis_result",
      description: "Return nutritional analysis of the food photo",
      parameters: {
        type: "object",
        properties: {
          food_description: { type: "string", description: "Brief description of identified foods in Hungarian" },
          calories_estimated: { type: "number", description: "Estimated total calories" },
          protein_g: { type: "number", description: "Estimated protein in grams" },
          carbs_g: { type: "number", description: "Estimated carbohydrates in grams" },
          fat_g: { type: "number", description: "Estimated fat in grams" },
          fiber_g: { type: "number", description: "Estimated fiber in grams" },
          confidence: { type: "string", enum: ["high", "medium", "low"] },
        },
        required: ["food_description", "calories_estimated", "protein_g", "carbs_g", "fat_g", "fiber_g", "confidence"],
      },
    },
  },
  stool: {
    type: "function",
    function: {
      name: "stool_analysis_result",
      description: "Return Bristol scale classification from the image",
      parameters: {
        type: "object",
        properties: {
          bristol_type: { type: "number", description: "Bristol scale type 1-7" },
          color: { type: "string", description: "Color description in Hungarian" },
          blood_present: { type: "boolean", description: "Whether blood appears present" },
          mucus_present: { type: "boolean", description: "Whether mucus appears present" },
          confidence: { type: "string", enum: ["high", "medium", "low"] },
        },
        required: ["bristol_type", "color", "confidence"],
      },
    },
  },
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const auth = await requireUser(req, corsHeaders);
    if (!auth.ok) return auth.response;

    const { mode, image_base64, mime_type } = await req.json();

    if (!mode || !PROMPTS[mode]) {
      return new Response(JSON.stringify({ error: "Invalid mode. Use: blood_pressure, food, stool" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (!image_base64) {
      return new Response(JSON.stringify({ error: "image_base64 is required" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: PROMPTS[mode] },
          {
            role: "user",
            content: [
              { type: "text", text: "Please analyze this image." },
              { type: "image_url", image_url: { url: `data:${mime_type || "image/jpeg"};base64,${image_base64}` } },
            ],
          },
        ],
        tools: [TOOLS[mode]],
        tool_choice: { type: "function", function: { name: TOOLS[mode].function.name } },
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded, please try again later." }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Payment required, please add credits." }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const t = await response.text();
      console.error("AI gateway error:", response.status, t);
      return new Response(JSON.stringify({ error: "AI analysis failed" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const data = await response.json();
    const toolCall = data.choices?.[0]?.message?.tool_calls?.[0];
    
    if (!toolCall?.function?.arguments) {
      return new Response(JSON.stringify({ error: "AI could not analyze the image" }), {
        status: 422, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const result = JSON.parse(toolCall.function.arguments);

    return new Response(JSON.stringify({ result, mode }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("ai-health-image-analysis error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
