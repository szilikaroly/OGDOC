import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

serve(async (req) => {
  const url = new URL(req.url);
  const isFull = url.searchParams.get("full") === "true";
  const settingKey = isFull ? "llms_full_txt" : "llms_txt";

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const { data } = await supabase
      .from("site_settings")
      .select("value")
      .eq("key", settingKey)
      .maybeSingle();

    const content = data?.value || `# S.O.S. 24 KFT\n\n> Foglalkozás-egészségügyi szolgálat\n\nNo detailed content configured yet. Please generate llms.txt from the admin panel.`;

    return new Response(content, {
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
        "Access-Control-Allow-Origin": "*",
        "Cache-Control": "public, max-age=3600",
      },
    });
  } catch (e) {
    return new Response("Error loading llms.txt", { status: 500 });
  }
});
