/**
 * Publikus tracking végpont az A/B kísérletek megjelenés- és konverzió-eseményeihez.
 * Auth nélkül hívható (anon role); a security definer fn elvégzi a futás-ellenőrzést,
 * a rate-limitet és a view dedupe-ot.
 *
 * Ha az esemény `goal` típusú és `event_name` szerepel, akkor a kísérleten
 * eltárolt `conversion_events` definíció alapján SZIGORÚAN validáljuk a `params`-t.
 */
import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { createClient } from "@supabase/supabase-js";
import {
  ConversionEventsSchema,
  buildParamsSchema,
  type ConversionEventDef,
} from "@/lib/cms/conversion-events";

const Body = z.object({
  experiment_id: z.string().uuid(),
  variant_id: z.string().uuid(),
  event_type: z.enum(["view", "goal"]),
  session_id: z.string().min(1).max(120),
  path: z.string().max(500).optional(),
  referrer: z.string().max(500).optional(),
  event_name: z.string().min(1).max(80).regex(/^[a-zA-Z0-9_.-]+$/).optional(),
  params: z.record(z.unknown()).optional(),
});

export const Route = createFileRoute("/api/public/experiments/track")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let parsed;
        try {
          const json = await request.json();
          parsed = Body.parse(json);
        } catch (e: any) {
          return new Response(JSON.stringify({ error: "invalid_input", detail: e?.message }), {
            status: 400, headers: { "content-type": "application/json" },
          });
        }
        const url = process.env.SUPABASE_URL;
        const key = process.env.SUPABASE_PUBLISHABLE_KEY;
        if (!url || !key) {
          return new Response(JSON.stringify({ error: "config" }), { status: 500 });
        }
        const sb = createClient(url, key, {
          auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
        });

        // Séma alapú params validálás névvel érkező goal eseményre
        if (parsed.event_type === "goal" && parsed.event_name) {
          const { data: exp, error: expErr } = await sb
            .from("cms_experiments")
            .select("conversion_events,status")
            .eq("id", parsed.experiment_id)
            .maybeSingle();
          if (expErr || !exp || exp.status !== "running") {
            return new Response(JSON.stringify({ ok: false }), { status: 202 });
          }
          const defsParsed = ConversionEventsSchema.safeParse(exp.conversion_events ?? []);
          const defs: ConversionEventDef[] = defsParsed.success ? defsParsed.data : [];
          const def = defs.find((d) => d.name === parsed.event_name);
          if (!def) {
            return new Response(JSON.stringify({ error: "unknown_event", event: parsed.event_name }), {
              status: 422, headers: { "content-type": "application/json" },
            });
          }
          const schema = buildParamsSchema(def);
          const check = schema.safeParse(parsed.params ?? {});
          if (!check.success) {
            return new Response(JSON.stringify({ error: "invalid_params", detail: check.error.issues }), {
              status: 422, headers: { "content-type": "application/json" },
            });
          }
        }

        const ua = request.headers.get("user-agent") ?? null;
        const { error } = await sb.rpc("cms_exp_event_record", {
          _experiment_id: parsed.experiment_id,
          _variant_id: parsed.variant_id,
          _event_type: parsed.event_type,
          _session_id: parsed.session_id,
          _path: parsed.path ?? null,
          _referrer: parsed.referrer ?? null,
          _user_agent: ua ? ua.slice(0, 500) : null,
          _event_name: parsed.event_name ?? null,
          _params: parsed.params ?? null,
        });
        if (error) {
          return new Response(JSON.stringify({ ok: false }), { status: 202, headers: { "content-type": "application/json" } });
        }
        return new Response(JSON.stringify({ ok: true }), { status: 200, headers: { "content-type": "application/json" } });
      },
    },
  },
});
