/**
 * Lemondás kóddal — publikus.
 */
import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";

const Input = z.object({
  foglalas_kod: z.string().min(6).max(12),
  vendeg_email: z.string().email().max(200),
  reason: z.string().max(500).optional(),
});

export const Route = createFileRoute("/api/public/booking/cancel")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let body: unknown;
        try { body = await request.json(); } catch { return Response.json({ error: "invalid_json" }, { status: 400 }); }
        const parsed = Input.safeParse(body);
        if (!parsed.success) return Response.json({ error: parsed.error.flatten() }, { status: 400 });
        const { foglalas_kod, vendeg_email, reason } = parsed.data;
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        const { data: appt, error } = await supabaseAdmin
          .from("appointments")
          .select("id, slot_id, status, tenant_id")
          .eq("foglalas_kod", foglalas_kod.toUpperCase())
          .eq("vendeg_email", vendeg_email.toLowerCase())
          .maybeSingle();
        if (error) return Response.json({ error: error.message }, { status: 500 });
        if (!appt) return Response.json({ error: "not_found" }, { status: 404 });
        if (appt.status === "lemondva") return Response.json({ ok: true, already: true });
        if (appt.status === "befejezett" || appt.status === "megerkezett") {
          return Response.json({ error: "cannot_cancel" }, { status: 409 });
        }

        const { error: uerr } = await supabaseAdmin
          .from("appointments").update({ status: "lemondva", ok: reason ?? "guest_cancel" }).eq("id", appt.id);
        if (uerr) return Response.json({ error: uerr.message }, { status: 500 });

        await supabaseAdmin.from("appointment_status_events").insert({
          appointment_id: appt.id,
          from_status: appt.status,
          to_status: "lemondva",
          tenant_id: appt.tenant_id,
          reason: reason ?? "guest_cancel",
        });
        await supabaseAdmin
          .from("appointment_slots")
          .update({ status: "szabad" })
          .eq("id", appt.slot_id);
        return Response.json({ ok: true });
      },
    },
  },
});
