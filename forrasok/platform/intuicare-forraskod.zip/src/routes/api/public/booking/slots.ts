/**
 * Publikus vendég-foglaló végpontok (`/api/public/booking/*`).
 *
 * Auth nincs (vendég is foglalhat); a védelem a SUPABASE_PUBLISHABLE_KEY-en
 * keresztül érvényesülő RLS + szigorúan szűkített INSERT a service kliensen,
 * miután minden bemenetet validáltunk.
 */
import { createFileRoute } from "@tanstack/react-router";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";

const Query = z.object({
  resource_id: z.string().uuid().optional(),
  from: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  to: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  szakma_id: z.string().uuid().optional(),
  orvos_id: z.string().uuid().optional(),
  org_unit_id: z.string().uuid().optional(),
});

export const Route = createFileRoute("/api/public/booking/slots")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const parsed = Query.safeParse(Object.fromEntries(url.searchParams.entries()));
        if (!parsed.success) {
          return Response.json({ error: parsed.error.flatten() }, { status: 400 });
        }
        const { resource_id, from, to, szakma_id, orvos_id, org_unit_id } = parsed.data;
        const supabase = createClient(
          process.env.SUPABASE_URL!,
          process.env.SUPABASE_PUBLISHABLE_KEY!,
          { auth: { persistSession: false, autoRefreshToken: false } },
        );

        let q = supabase
          .from("appointment_slots")
          .select("id, resource_id, org_unit_id, kezdo_ts, veg_ts, kapacitas, status, appointment_resources!inner(id, nev, tipus, szakma_id, orvos_id, org_unit_id, aktiv)")
          .eq("status", "szabad")
          .eq("appointment_resources.aktiv", true)
          .gte("kezdo_ts", `${from}T00:00:00Z`)
          .lte("kezdo_ts", `${to}T23:59:59Z`)
          .order("kezdo_ts", { ascending: true })
          .limit(500);
        if (resource_id) q = q.eq("resource_id", resource_id);
        if (szakma_id) q = q.eq("appointment_resources.szakma_id", szakma_id);
        if (orvos_id) q = q.eq("appointment_resources.orvos_id", orvos_id);
        if (org_unit_id) q = q.eq("appointment_resources.org_unit_id", org_unit_id);

        const { data, error } = await q;
        if (error) return Response.json({ error: error.message }, { status: 500 });
        return Response.json({ slots: data ?? [] });
      },
    },
  },
});
