/**
 * Publikus check-in endpoint — foglalási kód + születési dátum alapján.
 * Privacy: csak sorszámot ad vissza, nincs PII a válaszban.
 */
import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";

const Input = z.object({
  foglalas_kod: z.string().min(6).max(12),
  vendeg_szuletesi_datum: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  method: z.enum(["qr", "kiosk", "mobile"]).default("kiosk"),
});

export const Route = createFileRoute("/api/public/booking/checkin")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let body: unknown;
        try { body = await request.json(); } catch { return Response.json({ error: "invalid_json" }, { status: 400 }); }
        const parsed = Input.safeParse(body);
        if (!parsed.success) return Response.json({ error: parsed.error.flatten() }, { status: 400 });
        const { foglalas_kod, vendeg_szuletesi_datum, method } = parsed.data;

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        const { data: appt, error } = await supabaseAdmin
          .from("appointments")
          .select("id, status, tenant_id, resource_id, vendeg_szuletesi_datum, appointment_slots!inner(kezdo_ts)")
          .eq("foglalas_kod", foglalas_kod.toUpperCase())
          .eq("vendeg_szuletesi_datum", vendeg_szuletesi_datum)
          .maybeSingle();
        if (error) return Response.json({ error: error.message }, { status: 500 });
        if (!appt) return Response.json({ error: "not_found" }, { status: 404 });
        if (appt.status === "lemondva" || appt.status === "befejezett") {
          return Response.json({ error: "invalid_state" }, { status: 409 });
        }

        // Megérkezett-e már?
        const { data: existing } = await supabaseAdmin
          .from("patient_checkin")
          .select("id, queue_position, status")
          .eq("appointment_id", appt.id)
          .maybeSingle();
        if (existing) {
          return Response.json({ queue_position: existing.queue_position, status: existing.status, already: true });
        }

        // Aznapi sor: hány már bejelentkezett az erőforráshoz
        const startOfDay = new Date(); startOfDay.setHours(0, 0, 0, 0);
        const { count } = await supabaseAdmin
          .from("patient_checkin")
          .select("id", { count: "exact", head: true })
          .gte("checkin_ts", startOfDay.toISOString());

        const queue_position = (count ?? 0) + 1;

        const nowIso = new Date().toISOString();
        const { error: cerr } = await supabaseAdmin.from("patient_checkin").insert({
          appointment_id: appt.id,
          tenant_id: appt.tenant_id,
          method,
          status: "arrived",
          queue_position,
          checkin_ts: nowIso,
        });
        if (cerr) return Response.json({ error: cerr.message }, { status: 500 });

        await supabaseAdmin.from("appointments").update({ status: "megerkezett" }).eq("id", appt.id);
        await supabaseAdmin.from("appointment_status_events").insert({
          appointment_id: appt.id,
          from_status: appt.status,
          to_status: "megerkezett",
          tenant_id: appt.tenant_id,
          reason: `checkin_${method}`,
        });

        return Response.json({ queue_position, status: "arrived" });
      },
    },
  },
});
