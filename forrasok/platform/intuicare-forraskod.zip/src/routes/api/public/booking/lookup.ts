/**
 * Foglalás visszakeresés (kód + email) — publikus.
 * Nem ad ki PII-t, csak a foglalás állapotát és időpontját.
 */
import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";

const Input = z.object({
  foglalas_kod: z.string().min(6).max(12),
  vendeg_email: z.string().email().max(200),
});

export const Route = createFileRoute("/api/public/booking/lookup")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let body: unknown;
        try { body = await request.json(); } catch { return Response.json({ error: "invalid_json" }, { status: 400 }); }
        const parsed = Input.safeParse(body);
        if (!parsed.success) return Response.json({ error: parsed.error.flatten() }, { status: 400 });
        const { foglalas_kod, vendeg_email } = parsed.data;

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const { data, error } = await supabaseAdmin
          .from("appointments")
          .select("id, status, foglalas_kod, vendeg_nev, megjegyzes, appointment_slots!inner(kezdo_ts, veg_ts), appointment_resources!inner(nev)")
          .eq("foglalas_kod", foglalas_kod.toUpperCase())
          .eq("vendeg_email", vendeg_email.toLowerCase())
          .maybeSingle();
        if (error) return Response.json({ error: error.message }, { status: 500 });
        if (!data) return Response.json({ error: "not_found" }, { status: 404 });
        return Response.json({ appointment: data });
      },
    },
  },
});
