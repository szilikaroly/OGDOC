/**
 * Publikus vendég-foglalás létrehozása.
 *
 * Folyamat:
 *   1) Slot ellenőrzés (létezik, szabad, jövőbeli).
 *   2) Optimista slot-update szabad → foglalt.
 *   3) appointments insert (visszaigazoló kód + idempotency_key).
 *   4) status_event + (későbbi fázis) e-mail visszaigazolás.
 *
 * Az EESZT-szinkron a feature flag (`eeszt_sync_enabled`) alapján fut;
 * jelenleg NoopAdapter — csak naplóz.
 */
import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { generateBookingCode } from "@/lib/booking/slots";

const BookInput = z.object({
  slot_id: z.string().uuid(),
  vendeg_nev: z.string().min(2).max(120),
  vendeg_email: z.string().email().max(200),
  vendeg_telefon: z.string().min(5).max(30),
  vendeg_szuletesi_datum: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  megjegyzes: z.string().max(500).optional(),
  gdpr_consent: z.literal(true),
  idempotency_key: z.string().min(8).max(80),
});

export const Route = createFileRoute("/api/public/booking/book")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let body: unknown;
        try { body = await request.json(); } catch { return Response.json({ error: "invalid_json" }, { status: 400 }); }
        const parsed = BookInput.safeParse(body);
        if (!parsed.success) {
          return Response.json({ error: parsed.error.flatten() }, { status: 400 });
        }
        const d = parsed.data;
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        // idempotencia
        const { data: existing } = await supabaseAdmin
          .from("appointments")
          .select("id, foglalas_kod, status")
          .eq("idempotency_key", d.idempotency_key)
          .maybeSingle();
        if (existing) {
          return Response.json({ appointment_id: existing.id, foglalas_kod: existing.foglalas_kod, status: existing.status, idempotent: true });
        }

        const { data: slot, error: serr } = await supabaseAdmin
          .from("appointment_slots")
          .select("id, resource_id, tenant_id, kezdo_ts, status, version")
          .eq("id", d.slot_id)
          .maybeSingle();
        if (serr) return Response.json({ error: serr.message }, { status: 500 });
        if (!slot) return Response.json({ error: "slot_not_found" }, { status: 404 });
        if (slot.status !== "szabad") return Response.json({ error: "slot_taken" }, { status: 409 });
        if (new Date(slot.kezdo_ts).getTime() < Date.now()) {
          return Response.json({ error: "slot_in_past" }, { status: 409 });
        }

        // optimista zárolás
        const { data: locked, error: lerr } = await supabaseAdmin
          .from("appointment_slots")
          .update({ status: "foglalt", version: slot.version + 1 })
          .eq("id", slot.id)
          .eq("version", slot.version)
          .eq("status", "szabad")
          .select("id")
          .maybeSingle();
        if (lerr) return Response.json({ error: lerr.message }, { status: 500 });
        if (!locked) return Response.json({ error: "slot_taken" }, { status: 409 });

        const foglalas_kod = generateBookingCode();
        const { data: appt, error: ierr } = await supabaseAdmin
          .from("appointments")
          .insert({
            slot_id: slot.id,
            resource_id: slot.resource_id,
            tenant_id: slot.tenant_id,
            vendeg_nev: d.vendeg_nev,
            vendeg_email: d.vendeg_email,
            vendeg_telefon: d.vendeg_telefon,
            vendeg_szuletesi_datum: d.vendeg_szuletesi_datum,
            megjegyzes: d.megjegyzes ?? null,
            gdpr_consent_at: new Date().toISOString(),
            foglalas_kod,
            idempotency_key: d.idempotency_key,
            status: "megerositendo",
          })
          .select("id, foglalas_kod, status")
          .single();
        if (ierr || !appt) {
          // rollback slot
          await supabaseAdmin.from("appointment_slots").update({ status: "szabad" }).eq("id", slot.id);
          return Response.json({ error: ierr?.message ?? "insert_failed" }, { status: 500 });
        }

        await supabaseAdmin.from("appointment_status_events").insert({
          appointment_id: appt.id,
          to_status: "megerositendo",
          tenant_id: slot.tenant_id,
          reason: "guest_booking",
        });

        return Response.json({ appointment_id: appt.id, foglalas_kod: appt.foglalas_kod, status: appt.status });
      },
    },
  },
});
