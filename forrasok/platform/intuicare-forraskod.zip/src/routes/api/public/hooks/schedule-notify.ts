import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";

const BodySchema = z.object({
  event: z.enum(["new", "change", "cancel"]),
  assignment: z.object({
    id: z.string().uuid(),
    user_id: z.string().uuid().nullable(),
    tenant_id: z.string().uuid().nullable().optional(),
    kezdo_idopont: z.string(),
    zaro_idopont: z.string().optional().nullable(),
    kategoria: z.string().nullable().optional(),
    status: z.string().nullable().optional(),
  }),
  changes: z.array(z.string()).nullable().optional(),
});

function fmt(iso: string): string {
  return new Date(iso).toLocaleString("hu-HU", {
    timeZone: "Europe/Budapest",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export const Route = createFileRoute("/api/public/hooks/schedule-notify")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { verifyCronRequest, cronAuthErrorResponse } = await import("@/lib/cron/auth.server");
        const auth = verifyCronRequest(request);
        if (!auth.ok) return cronAuthErrorResponse(auth);

        let payload: z.infer<typeof BodySchema>;
        try {
          payload = BodySchema.parse(await request.json());
        } catch (e) {
          return new Response(JSON.stringify({ error: "invalid_body", detail: String(e) }), {
            status: 400,
            headers: { "content-type": "application/json" },
          });
        }

        const { event, assignment, changes } = payload;
        if (!assignment.user_id) {
          return Response.json({ ok: true, skipped: "no_user" });
        }

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const supabase = supabaseAdmin;

        // Idempotency
        const kind = event === "new" ? "new" : event === "cancel" ? "cancel" : "change";
        const { data: existingRow } = await supabase
          .from("shift_notifications_sent")
          .select("id")
          .eq("assignment_id", assignment.id)
          .eq("kind", kind)
          .eq("channel", "push")
          .maybeSingle();
        if (existingRow) {
          return Response.json({ ok: true, skipped: "duplicate" });
        }

        const { data: profile } = await supabase
          .from("profiles")
          .select("id, reminder_push_enabled")
          .eq("id", assignment.user_id)
          .maybeSingle();
        if (!profile) return Response.json({ ok: true, skipped: "no_profile" });

        // Build message
        const when = fmt(assignment.kezdo_idopont);
        const kategoria = assignment.kategoria ?? "műszak";
        let title: string;
        let body: string;
        if (event === "new") {
          title = "Új műszakot kaptál";
          body = `${when} (${kategoria})`;
        } else if (event === "cancel") {
          title = "Törölt műszak";
          body = `${when} (${kategoria})`;
        } else {
          title = "Beosztásod változott";
          body = (changes ?? []).join(" • ") || `${when} (${kategoria})`;
        }

        // Insert idempotency row (pending)
        const { data: insertRes } = await supabase
          .from("shift_notifications_sent")
          .insert({
            assignment_id: assignment.id,
            user_id: assignment.user_id,
            kind,
            channel: "push",
            success: false,
          } as never)
          .select("id")
          .maybeSingle();

        // Respect the user's push preference
        if (profile.reminder_push_enabled === false) {
          if (insertRes) {
            await supabase
              .from("shift_notifications_sent")
              .update({ success: false, error: "user_push_disabled" } as never)
              .eq("id", (insertRes as { id: string }).id);
          }
          return Response.json({ ok: true, skipped: "push_disabled" });
        }

        const { data: subs } = await supabase
          .from("push_subscriptions")
          .select("id, endpoint, p256dh, auth")
          .eq("user_id", assignment.user_id);

        if (!subs || subs.length === 0) {
          if (insertRes) {
            await supabase
              .from("shift_notifications_sent")
              .update({ success: false, error: "no_subscriptions" } as never)
              .eq("id", (insertRes as { id: string }).id);
          }
          return Response.json({ ok: true, skipped: "no_subscriptions" });
        }

        try {
          const { sendPushToSubscriptions } = await import("@/lib/push/send.server");
          const res = await sendPushToSubscriptions(
            subs as Array<{ id: string; endpoint: string; p256dh: string; auth: string }>,
            { title, body, url: "/beosztas", tag: `shift-${assignment.id}-${kind}` },
          );
          if (res.gone.length > 0) {
            await supabase.from("push_subscriptions").delete().in("endpoint", res.gone);
          }
          if (insertRes) {
            await supabase
              .from("shift_notifications_sent")
              .update({
                success: res.sent > 0,
                error: res.sent === 0 ? `failed:${res.failed}` : null,
              } as never)
              .eq("id", (insertRes as { id: string }).id);
          }
          return Response.json({ ok: true, sent: res.sent, gone: res.gone.length, failed: res.failed });
        } catch (e) {
          if (insertRes) {
            await supabase
              .from("shift_notifications_sent")
              .update({ success: false, error: String(e).slice(0, 500) } as never)
              .eq("id", (insertRes as { id: string }).id);
          }
          return new Response(JSON.stringify({ error: String(e) }), {
            status: 500,
            headers: { "content-type": "application/json" },
          });
        }
      },
    },
  },
});
