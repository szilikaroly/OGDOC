import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/public/hooks/weekly-digest")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { verifyCronRequest, cronAuthErrorResponse } = await import("@/lib/cron/auth.server");
        const auth = verifyCronRequest(request);
        if (!auth.ok) return cronAuthErrorResponse(auth);
        try {
          const { runWeeklyDigestForAllTenants } = await import("@/lib/weekly-digest.server");
          const result = await runWeeklyDigestForAllTenants();
          return Response.json({ ok: true, ...result, at: new Date().toISOString() });
        } catch (e) {
          return new Response(
            JSON.stringify({ ok: false, error: (e as Error).message }),
            { status: 500, headers: { "content-type": "application/json" } },
          );
        }
      },
    },
  },
});
