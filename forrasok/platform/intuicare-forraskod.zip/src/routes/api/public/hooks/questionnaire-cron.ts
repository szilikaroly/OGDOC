/**
 * Naponta futó cron-végpont: periodikus kérdőív-ütemezések feldolgozása,
 * lejárt assignmentek expirálása, emlékeztetők küldése.
 *
 * pg_cron-ból hívva a Supabase anon kulccsal (apikey header).
 */
import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/public/hooks/questionnaire-cron")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { verifyCronRequest, cronAuthErrorResponse } = await import("@/lib/cron/auth.server");
        const auth = verifyCronRequest(request);
        if (!auth.ok) return cronAuthErrorResponse(auth);


        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        const results: Record<string, unknown> = {};
        try {
          const { data: scheduled, error: e1 } = await supabaseAdmin
            .rpc("process_questionnaire_schedules");
          if (e1) throw e1;
          results.schedules = scheduled ?? [];

          const { data: expired, error: e2 } = await supabaseAdmin
            .rpc("expire_overdue_questionnaire_assignments");
          if (e2) throw e2;
          results.expired_count = expired ?? 0;

          const { data: reminded, error: e3 } = await supabaseAdmin
            .rpc("send_questionnaire_reminders");
          if (e3) throw e3;
          results.reminder_count = reminded ?? 0;

          // Visszajelentő (follow-up) protokollok feldolgozása
          const { data: fu, error: e4 } = await supabaseAdmin
            .rpc("process_followup_schedules");
          if (e4) throw e4;
          results.followup_generated = fu ?? 0;

          return Response.json({ ok: true, ...results });
        } catch (err: unknown) {
          const msg = err instanceof Error ? err.message : String(err);
          return Response.json({ ok: false, error: msg, results }, { status: 500 });
        }
      },
    },
  },
});
