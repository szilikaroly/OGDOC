import { createFileRoute } from "@tanstack/react-router";


const REMINDER_KINDS = [
  { kind: "24h" as const, minutesBefore: 24 * 60, windowMin: 5 },
  { kind: "2h" as const, minutesBefore: 2 * 60, windowMin: 5 },
];

function fmtTime(iso: string) {
  return new Date(iso).toLocaleString("hu-HU", {
    timeZone: "Europe/Budapest",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export const Route = createFileRoute("/api/public/hooks/shift-reminders")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { verifyCronRequest, cronAuthErrorResponse } = await import("@/lib/cron/auth.server");
        const auth = verifyCronRequest(request);
        if (!auth.ok) return cronAuthErrorResponse(auth);

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const supabase = supabaseAdmin;

        const now = Date.now();
        const summary: Array<Record<string, unknown>> = [];

        for (const { kind, minutesBefore, windowMin } of REMINDER_KINDS) {
          const targetMs = now + minutesBefore * 60_000;
          const fromIso = new Date(targetMs - windowMin * 60_000).toISOString();
          const toIso = new Date(targetMs + windowMin * 60_000).toISOString();

          const { data: assignments, error: aErr } = await supabase
            .from("schedule_assignments")
            .select("id, user_id, kezdo_idopont, zaro_idopont, kategoria, org_unit_id, site_id, status")
            .gte("kezdo_idopont", fromIso)
            .lte("kezdo_idopont", toIso)
            .not("user_id", "is", null);
          if (aErr) {
            summary.push({ kind, error: aErr.message });
            continue;
          }
          if (!assignments || assignments.length === 0) {
            summary.push({ kind, count: 0 });
            continue;
          }

          const userIds = Array.from(new Set((assignments ?? []).map((a: { user_id: string | null }) => a.user_id!).filter(Boolean)));
          const [{ data: profiles }, { data: existing }] = await Promise.all([
            supabase
              .from("profiles")
              .select("id, email, teljes_nev, reminder_email_enabled, reminder_push_enabled, tenant_id")
              .in("id", userIds),
            supabase
              .from("shift_notifications_sent")
              .select("assignment_id, channel")
              .in("assignment_id", (assignments ?? []).map((a: { id: string }) => a.id))
              .eq("kind", kind),
          ]);
          const profileMap = new Map(
            ((profiles ?? []) as Array<{ id: string }>).map((p) => [p.id, p as unknown as ProfileRow]),
          );
          const existingSet = new Set(
            ((existing ?? []) as Array<{ assignment_id: string; channel: string }>).map(
              (e) => `${e.assignment_id}:${e.channel}`,
            ),
          );

          let pushSent = 0;
          let emailQueued = 0;
          let notifInserted = 0;

          for (const aRaw of assignments) {
            const a = aRaw as unknown as {
              id: string;
              user_id: string;
              kezdo_idopont: string;
              zaro_idopont: string;
              kategoria: string;
              tenant_id?: string;
            };
            const profile = profileMap.get(a.user_id);
            if (!profile) continue;
            const when = fmtTime(a.kezdo_idopont);
            const endLabel = new Date(a.zaro_idopont).toLocaleTimeString("hu-HU", {
              timeZone: "Europe/Budapest",
              hour: "2-digit",
              minute: "2-digit",
            });
            const hLabel = kind === "24h" ? "24 óra múlva" : "2 óra múlva";
            const title = `Műszak ${hLabel}`;
            const body = `${when} – ${endLabel} (${a.kategoria})`;

            // PUSH
            if (profile.reminder_push_enabled !== false && !existingSet.has(`${a.id}:push`)) {
              const { data: insertRes } = await supabase
                .from("shift_notifications_sent")
                .insert({
                  assignment_id: a.id,
                  user_id: a.user_id,
                  kind,
                  channel: "push",
                  success: false,
                } as never)
                .select("id")
                .maybeSingle();
              if (insertRes) {
                const { data: subs } = await supabase
                  .from("push_subscriptions")
                  .select("id, endpoint, p256dh, auth")
                  .eq("user_id", a.user_id);
                if (subs && subs.length > 0) {
                  try {
                    const { sendPushToSubscriptions } = await import("@/lib/push/send.server");
                    const res = await sendPushToSubscriptions(
                      subs as Array<{ id: string; endpoint: string; p256dh: string; auth: string }>,
                      { title, body, url: "/munkaido", tag: `shift-${a.id}-${kind}` },
                    );
                    if (res.gone.length > 0) {
                      await supabase.from("push_subscriptions").delete().in("endpoint", res.gone);
                    }
                    await supabase
                      .from("shift_notifications_sent")
                      .update({ success: res.sent > 0 } as never)
                      .eq("id", (insertRes as { id: string }).id);
                    if (res.sent > 0) pushSent++;
                  } catch (e) {
                    await supabase
                      .from("shift_notifications_sent")
                      .update({ success: false, error: String(e).slice(0, 500) } as never)
                      .eq("id", (insertRes as { id: string }).id);
                  }
                }
              }
            }

            // EMAIL (via Lovable transactional template, if scaffolded)
            if (profile.reminder_email_enabled !== false && profile.email && !existingSet.has(`${a.id}:email`)) {
              const { data: insertRes } = await supabase
                .from("shift_notifications_sent")
                .insert({
                  assignment_id: a.id,
                  user_id: a.user_id,
                  kind,
                  channel: "email",
                  success: false,
                } as never)
                .select("id")
                .maybeSingle();
              if (insertRes) {
                try {
                  const url = new URL("/lovable/email/transactional/send", request.url);
                  const r = await fetch(url, {
                    method: "POST",
                    headers: {
                      "Content-Type": "application/json",
                      Authorization: `Bearer ${process.env.LOVABLE_API_KEY ?? ""}`,
                    },
                    body: JSON.stringify({
                      templateName: "shift-reminder",
                      recipientEmail: profile.email,
                      idempotencyKey: `shift-${a.id}-${kind}`,
                      templateData: {
                        name: profile.teljes_nev ?? "",
                        when,
                        endLabel,
                        kategoria: a.kategoria,
                        kind,
                      },
                    }),
                  });
                  const ok = r.ok;
                  await supabase
                    .from("shift_notifications_sent")
                    .update({ success: ok, error: ok ? null : `HTTP ${r.status}` } as never)
                    .eq("id", (insertRes as { id: string }).id);
                  if (ok) emailQueued++;
                } catch (e) {
                  await supabase
                    .from("shift_notifications_sent")
                    .update({ success: false, error: String(e).slice(0, 500) } as never)
                    .eq("id", (insertRes as { id: string }).id);
                }
              }
            }

            // In-app notification (always)
            await supabase.from("notifications").insert({
              tenant_id: profile.tenant_id,
              user_id: a.user_id,
              tipus: "beosztas",
              cim: title,
              uzenet: body,
              link: "/munkaido",
            } as never);
            notifInserted++;
          }

          summary.push({ kind, count: assignments.length, pushSent, emailQueued, notifInserted });
        }

        return Response.json({ ok: true, summary, at: new Date().toISOString() });
      },
    },
  },
});

type ProfileRow = {
  id: string;
  email: string | null;
  teljes_nev: string | null;
  reminder_email_enabled: boolean | null;
  reminder_push_enabled: boolean | null;
  tenant_id: string | null;
};
