import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/public/hooks/escalate-alerts")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { verifyCronRequest, cronAuthErrorResponse } = await import("@/lib/cron/auth.server");
        const auth = verifyCronRequest(request);
        if (!auth.ok) return cronAuthErrorResponse(auth);
        const { runEscalationOnce } = await import("@/lib/paciens-360/escalation.server");
        const result = await runEscalationOnce();
        return Response.json({ ok: true, ...result });
      },
    },
  },
});
