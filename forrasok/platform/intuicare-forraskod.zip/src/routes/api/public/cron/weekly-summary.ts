import { createFileRoute } from "@tanstack/react-router";

/**
 * Heti összefoglaló cron végpont.
 *
 * Hívás: pg_cron net.http_post hetente egyszer.
 * Authentikáció: `apikey` header == Supabase anon kulcs (a /api/public/* route
 * már az edge szintjén bypass-olja az auth-ot, az anon kulcs csak alap-védelem
 * a véletlen külső kérések ellen).
 *
 * Mit csinál:
 *  - végigmegy minden user-en, akinek `notification_preferences.email_weekly_summary = true`
 *  - összegyűjti az utolsó 7 nap mérés / lelet / új időpont / kérdőív aktivitását
 *  - notification rekordot ír `notifications` táblába
 *  - push értesítést küld a regisztrált eszközökre (ha van VAPID)
 *  - e-mailt küld (Lovable Emails ha be van állítva, különben Resend-fallback)
 */
export const Route = createFileRoute("/api/public/cron/weekly-summary")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const apiKey = request.headers.get("apikey") ?? request.headers.get("x-cron-secret");
        const expected = process.env.SUPABASE_PUBLISHABLE_KEY ?? process.env.SUPABASE_ANON_KEY ?? process.env.CRON_SECRET;
        if (!apiKey || !expected || apiKey !== expected) {
          return new Response("Unauthorized", { status: 401 });
        }
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        const since = new Date(Date.now() - 7 * 24 * 3600_000).toISOString();

        const { data: optIns } = await supabaseAdmin
          .from("notification_preferences" as never)
          .select("user_id")
          .eq("email_weekly_summary", true);

        const userIds = ((optIns ?? []) as any[]).map((r) => r.user_id);
        if (userIds.length === 0) {
          return Response.json({ ok: true, processed: 0 });
        }

        // E-mail címek lekérése (Auth Admin API-n keresztül, best-effort)
        const emailByUser: Record<string, string> = {};
        for (const uid of userIds) {
          try {
            const { data } = await supabaseAdmin.auth.admin.getUserById(uid);
            if (data?.user?.email) emailByUser[uid] = data.user.email;
          } catch { /* ignore */ }
        }

        const { data: links } = await supabaseAdmin
          .from("patient_users")
          .select("user_id, patient_id")
          .in("user_id", userIds);

        const byUser: Record<string, string[]> = {};
        for (const l of (links ?? []) as any[]) {
          (byUser[l.user_id] ??= []).push(l.patient_id);
        }

        let processed = 0;
        let pushed = 0;
        let emailed = 0;
        let emailSkipped = 0;
        for (const userId of userIds) {
          const pids = byUser[userId] ?? [];
          let measCount = 0, labCount = 0, apptCount = 0, alertCount = 0;
          if (pids.length > 0) {
            const [m, l, a, c] = await Promise.all([
              supabaseAdmin.from("measurements").select("id", { count: "exact", head: true }).in("patient_id", pids).gte("created_at", since),
              supabaseAdmin.from("clinical_observations").select("id", { count: "exact", head: true }).in("patient_id", pids).gte("effective_ts", since),
              supabaseAdmin.from("appointments").select("id", { count: "exact", head: true }).in("patient_id", pids).gte("created_at", since),
              supabaseAdmin.from("clinical_critical_alerts").select("id", { count: "exact", head: true }).in("patient_id", pids).gte("triggered_at", since),
            ]);
            measCount = m.count ?? 0;
            labCount = l.count ?? 0;
            apptCount = a.count ?? 0;
            alertCount = c.count ?? 0;
          }

          const cim = "Heti egészség-összefoglaló";
          const uzenet = `Az elmúlt 7 napban: ${labCount} új lelet, ${measCount} otthoni mérés, ${apptCount} időpont, ${alertCount} riasztás.`;

          await supabaseAdmin.from("notifications").insert({
            user_id: userId,
            tipus: "weekly_summary",
            cim,
            uzenet,
            link: "/portal",
          } as never);

          // Push (best-effort)
          try {
            const { data: subs } = await supabaseAdmin
              .from("push_subscriptions")
              .select("id, endpoint, p256dh, auth")
              .eq("user_id", userId);
            if (subs && subs.length > 0) {
              const { sendPushToSubscriptions } = await import("@/lib/push/send.server");
              const res = await sendPushToSubscriptions(subs, {
                title: cim,
                body: uzenet,
                url: "/portal",
                tag: "weekly-summary",
              });
              pushed += subs.length - res.gone.length;
              if (res.gone.length > 0) {
                await supabaseAdmin.from("push_subscriptions").delete().in("endpoint", res.gone);
              }
            }
          } catch (e) {
            console.warn("weekly push failed for", userId, e);
          }

          // E-mail (best-effort, csak ha Resend konfigurálva)
          const email = emailByUser[userId];
          if (email) {
            try {
              const { sendEmail } = await import("@/lib/email/send.server");
              const html = `<div style="font-family:system-ui,sans-serif;max-width:560px;margin:0 auto;padding:24px;color:#0f172a">
                <h2 style="margin:0 0 12px">${cim}</h2>
                <p style="margin:0 0 16px;color:#475569">Az elmúlt 7 nap egészségügyi aktivitása:</p>
                <ul style="line-height:1.7;padding-left:18px">
                  <li><b>${labCount}</b> új lelet</li>
                  <li><b>${measCount}</b> otthoni mérés</li>
                  <li><b>${apptCount}</b> új időpont</li>
                  <li><b>${alertCount}</b> riasztás</li>
                </ul>
                <p style="margin-top:24px"><a href="https://intuicare-planner.lovable.app/portal" style="background:#0f172a;color:#fff;padding:10px 16px;border-radius:8px;text-decoration:none">Megnyitás a portálon</a></p>
                <p style="margin-top:24px;font-size:12px;color:#94a3b8">A leiratkozáshoz módosítsa az értesítési beállításait a portál Profil oldalán.</p>
              </div>`;
              const r = await sendEmail({ to: email, subject: cim, html, text: uzenet });
              if (r.ok) emailed++;
              else if (r.skipped) emailSkipped++;
            } catch (e) {
              console.warn("weekly email failed for", userId, e);
            }
          }
          processed++;
        }

        return Response.json({ ok: true, processed, pushed, emailed, emailSkipped });
      },
    },
  },
});
