import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/public/schedule/$token")({
  server: {
    handlers: {
      GET: async ({ params, request }) => {
        const token = params.token;
        if (!token || token.length < 16) {
          return Response.json({ error: "invalid_token" }, { status: 400 });
        }
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        const { data: tok, error } = await supabaseAdmin
          .from("schedule_share_tokens")
          .select("id,tenant_id,scope_month,expires_at,revoked_at")
          .eq("token", token)
          .maybeSingle();

        // GDPR audit – minden publikus hozzáférési kísérletet naplózunk
        const ip =
          request.headers.get("cf-connecting-ip") ||
          request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
          null;
        const ua = request.headers.get("user-agent") || null;
        const audit = (action: string, after: Record<string, unknown>) =>
          supabaseAdmin.from("admin_audit_log").insert({
            tenant_id: tok?.tenant_id ?? null,
            user_id: null,
            action,
            table_name: "schedule_share_tokens",
            record_id: tok?.id ?? token.slice(0, 8),
            before_data: null,
            after_data: { ip, ua, ...after },
          });

        if (error) {
          await audit("PUBLIC_SHARE_ERROR", { reason: "lookup_failed" });
          return Response.json({ error: "lookup_failed" }, { status: 500 });
        }
        if (!tok) {
          await audit("PUBLIC_SHARE_NOT_FOUND", { token_prefix: token.slice(0, 8) });
          return Response.json({ error: "not_found" }, { status: 404 });
        }
        if (tok.revoked_at) {
          await audit("PUBLIC_SHARE_REVOKED_HIT", {});
          return Response.json({ error: "revoked" }, { status: 410 });
        }
        if (new Date(tok.expires_at).getTime() < Date.now()) {
          await audit("PUBLIC_SHARE_EXPIRED_HIT", {});
          return Response.json({ error: "expired" }, { status: 410 });
        }
        await audit("PUBLIC_SHARE_ACCESS", { scope_month: tok.scope_month });

        // Hónap intervallum
        const start = new Date(tok.scope_month);
        const end = new Date(start.getFullYear(), start.getMonth() + 1, 1);
        const iso = (d: Date) => d.toISOString().slice(0, 10);

        const [aRes, pRes] = await Promise.all([
          supabaseAdmin
            .from("schedule_assignments")
            .select("user_id,kezdo_idopont,zaro_idopont,ora,kategoria")
            .eq("tenant_id", tok.tenant_id)
            .gte("kezdo_idopont", `${iso(start)}T00:00:00`)
            .lt("kezdo_idopont", `${iso(end)}T00:00:00`),
          supabaseAdmin
            .from("profiles")
            .select("id,teljes_nev")
            .eq("tenant_id", tok.tenant_id),
        ]);

        // CSAK biztonságos mezőket adunk vissza — nincs TAJ/email/jogosultság.
        return Response.json(
          {
            month: iso(start),
            assignments: aRes.data ?? [],
            people: pRes.data ?? [],
            expires_at: tok.expires_at,
          },
          { headers: { "Cache-Control": "no-store" } },
        );
      },
    },
  },
});
