import { createFileRoute } from "@tanstack/react-router";

// Mock EESZT sync endpoint — called by pg_cron.
// Marks patient links as "synced" by bumping utolso_szinkron_at.
// In production, this would call the real EESZT API per tenant.
export const Route = createFileRoute("/api/public/eeszt-sync")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const apiKey =
          request.headers.get("apikey") ??
          request.headers.get("authorization")?.replace(/^Bearer\s+/i, "");
        // Prefer dedicated CRON_SECRET; fall back to the anon key for legacy pg_cron jobs.
        const expected = process.env.CRON_SECRET ?? process.env.SUPABASE_PUBLISHABLE_KEY;
        if (!apiKey || !expected || apiKey !== expected) {
          return new Response(
            JSON.stringify({ error: "Unauthorized" }),
            { status: 401, headers: { "Content-Type": "application/json" } },
          );
        }

        const { supabaseAdmin } = await import(
          "@/integrations/supabase/client.server"
        );

        // Pick links not synced in the last 6 hours (or never).
        const cutoff = new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString();
        const { data: stale, error: selErr } = await supabaseAdmin
          .from("eeszt_patient_links")
          .select("id, hozzajarulas_status, utolso_szinkron_at")
          .or(`utolso_szinkron_at.is.null,utolso_szinkron_at.lt.${cutoff}`)
          .limit(200);

        if (selErr) {
          return new Response(
            JSON.stringify({ error: selErr.message }),
            { status: 500, headers: { "Content-Type": "application/json" } },
          );
        }

        const now = new Date().toISOString();
        const ids = (stale ?? []).map((r) => r.id);
        let updated = 0;
        if (ids.length > 0) {
          const { error: updErr, count } = await supabaseAdmin
            .from("eeszt_patient_links")
            .update({ utolso_szinkron_at: now }, { count: "exact" })
            .in("id", ids);
          if (updErr) {
            return new Response(
              JSON.stringify({ error: updErr.message }),
              { status: 500, headers: { "Content-Type": "application/json" } },
            );
          }
          updated = count ?? ids.length;
        }

        return new Response(
          JSON.stringify({
            ok: true,
            mock: true,
            checked: stale?.length ?? 0,
            updated,
            timestamp: now,
          }),
          { headers: { "Content-Type": "application/json" } },
        );
      },
    },
  },
});

