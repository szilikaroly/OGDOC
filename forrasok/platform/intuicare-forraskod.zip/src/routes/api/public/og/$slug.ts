/**
 * Dinamikus OG-image endpoint (Satori + resvg-wasm).
 *
 * URL: /api/public/og/:slug  → 1200×630 PNG
 * A tartalmat a publikált CMS oldalból építi (title, description, site name).
 * Font és wasm modult CDN-ről tölti be egyszer, memóriában cache-eli.
 */
import { createFileRoute } from "@tanstack/react-router";
import satori from "satori";
import { Resvg, initWasm } from "@resvg/resvg-wasm";
import { createClient } from "@supabase/supabase-js";

const FONT_REGULAR_URL =
  "https://cdn.jsdelivr.net/fontsource/fonts/inter@latest/latin-400-normal.ttf";
const FONT_BOLD_URL =
  "https://cdn.jsdelivr.net/fontsource/fonts/inter@latest/latin-700-normal.ttf";
const RESVG_WASM_URL =
  "https://cdn.jsdelivr.net/npm/@resvg/resvg-wasm@2.6.2/index_bg.wasm";

let fontRegular: ArrayBuffer | null = null;
let fontBold: ArrayBuffer | null = null;
let wasmReady: Promise<void> | null = null;

async function loadAssets() {
  if (!fontRegular) {
    const r = await fetch(FONT_REGULAR_URL);
    fontRegular = await r.arrayBuffer();
  }
  if (!fontBold) {
    const r = await fetch(FONT_BOLD_URL);
    fontBold = await r.arrayBuffer();
  }
  if (!wasmReady) {
    wasmReady = (async () => {
      const r = await fetch(RESVG_WASM_URL);
      const buf = await r.arrayBuffer();
      await initWasm(buf);
    })();
  }
  await wasmReady;
}

function publicClient() {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_PUBLISHABLE_KEY;
  if (!url || !key) throw new Error("Missing Supabase env");
  return createClient(url, key, {
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
  });
}

async function loadPage(slug: string) {
  const sb = publicClient();
  const { data: page } = await sb
    .from("cms_pages")
    .select("title, description, seo_title, seo_description, og_image_url, featured_image_url")
    .eq("slug", slug)
    .eq("locale", "hu")
    .eq("status", "published")
    .maybeSingle();
  return page as
    | {
        title: string;
        description: string | null;
        seo_title: string | null;
        seo_description: string | null;
        og_image_url: string | null;
        featured_image_url: string | null;
      }
    | null;
}

function trim(text: string, max: number) {
  const t = text.trim();
  if (t.length <= max) return t;
  return t.slice(0, max - 1).trimEnd() + "…";
}

function buildTree(title: string, description: string, siteName: string) {
  // Satori JSX-mentes: kézzel épített element-fa.
  return {
    type: "div",
    props: {
      style: {
        width: "1200px",
        height: "630px",
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
        padding: "72px",
        background: "linear-gradient(135deg, #0f1b3d 0%, #1e3a5f 100%)",
        color: "#ffffff",
        fontFamily: "Inter",
      },
      children: [
        {
          type: "div",
          props: {
            style: { display: "flex", alignItems: "center", gap: "16px", fontSize: "24px", color: "#c9a84c" },
            children: [
              { type: "div", props: { style: { width: "10px", height: "40px", background: "#c9a84c" } } },
              { type: "div", props: { children: siteName } },
            ],
          },
        },
        {
          type: "div",
          props: {
            style: { display: "flex", flexDirection: "column", gap: "20px" },
            children: [
              {
                type: "div",
                props: {
                  style: {
                    fontSize: "64px",
                    fontWeight: 700,
                    lineHeight: 1.15,
                    letterSpacing: "-0.02em",
                  },
                  children: trim(title, 100),
                },
              },
              description
                ? {
                    type: "div",
                    props: {
                      style: { fontSize: "28px", color: "#cbd5e1", lineHeight: 1.35 },
                      children: trim(description, 160),
                    },
                  }
                : null,
            ].filter(Boolean),
          },
        },
        {
          type: "div",
          props: {
            style: { fontSize: "20px", color: "#94a3b8" },
            children: "intuicare-planner.lovable.app",
          },
        },
      ],
    },
  } as any;
}

async function renderOg(slug: string): Promise<Uint8Array> {
  await loadAssets();
  const page = await loadPage(slug);
  const title = page?.seo_title || page?.title || slug;
  const description = page?.seo_description || page?.description || "";
  const svg = await satori(buildTree(title, description, "Szülészeti és Nőgyógyászati Klinika"), {
    width: 1200,
    height: 630,
    fonts: [
      { name: "Inter", data: fontRegular!, weight: 400, style: "normal" },
      { name: "Inter", data: fontBold!, weight: 700, style: "normal" },
    ],
  });
  const resvg = new Resvg(svg, { fitTo: { mode: "width", value: 1200 } });
  return resvg.render().asPng();
}

export const Route = createFileRoute("/api/public/og/$slug")({
  server: {
    handlers: {
      GET: async ({ params }) => {
        try {
          const png = await renderOg(params.slug);
          return new Response(png as unknown as BodyInit, {
            status: 200,
            headers: {
              "Content-Type": "image/png",
              "Cache-Control": "public, max-age=300, s-maxage=3600, stale-while-revalidate=86400",
            },
          });
        } catch (e) {
          const msg = e instanceof Error ? e.message : String(e);
          return new Response(`OG render failed: ${msg}`, { status: 500 });
        }
      },
    },
  },
});
