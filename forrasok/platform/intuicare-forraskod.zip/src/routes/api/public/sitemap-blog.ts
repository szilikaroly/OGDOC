import { createFileRoute } from "@tanstack/react-router";
import { createClient } from "@supabase/supabase-js";

function pub() {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_PUBLISHABLE_KEY;
  if (!url || !key) throw new Error("Missing Supabase env");
  return createClient(url, key, {
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
  });
}

function escapeXml(s: string) {
  return s.replace(/[<>&'"]/g, (c) =>
    c === "<" ? "&lt;" : c === ">" ? "&gt;" : c === "&" ? "&amp;" : c === "'" ? "&apos;" : "&quot;",
  );
}

export const Route = createFileRoute("/api/public/sitemap-blog")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const origin = new URL(request.url).origin;
        const sb = pub();
        const { data: posts } = await sb.from("cms_news_posts")
          .select("slug,title,excerpt,updated_at,published_at,featured_image_url,featured_image_alt,locale")
          .eq("status", "published")
          .eq("post_type", "blog")
          .lte("published_at", new Date().toISOString())
          .order("updated_at", { ascending: false });

        const now = Date.now();
        const items = (posts ?? []).map((p: any) => {
          const updated = p.updated_at ? new Date(p.updated_at) : null;
          const published = p.published_at ? new Date(p.published_at) : null;
          const lastmod = (updated ?? published ?? new Date()).toISOString();
          const ageDays = updated ? (now - updated.getTime()) / 86_400_000 : 999;
          const changefreq = ageDays < 7 ? "daily" : ageDays < 30 ? "weekly" : ageDays < 180 ? "monthly" : "yearly";
          const priority = ageDays < 30 ? "0.8" : ageDays < 180 ? "0.6" : "0.4";
          const image = p.featured_image_url
            ? `<image:image><image:loc>${escapeXml(p.featured_image_url)}</image:loc>${p.featured_image_alt ? `<image:caption>${escapeXml(p.featured_image_alt)}</image:caption>` : ""}${p.title ? `<image:title>${escapeXml(p.title)}</image:title>` : ""}</image:image>`
            : "";
          return `<url><loc>${origin}/blog/${encodeURIComponent(p.slug)}</loc><lastmod>${lastmod}</lastmod><changefreq>${changefreq}</changefreq><priority>${priority}</priority>${image}</url>`;
        });

        const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">\n${items.join("\n")}\n</urlset>`;
        return new Response(xml, {
          headers: {
            "Content-Type": "application/xml; charset=utf-8",
            "Cache-Control": "public, max-age=1800",
          },
        });
      },
    },
  },
});
