/**
 * Publikus elégedettségi felmérés beküldés.
 * Auth nélkül — RLS anon-INSERT policy fedezi (ss_insert_anon).
 *
 * A foglalási kód + e-mail validálja, hogy a beküldő tényleg a páciens.
 */
import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";

const Input = z.object({
  foglalas_kod: z.string().min(6).max(12),
  vendeg_email: z.string().email().max(200),
  instrument_code: z.enum(["NPS", "CGCAHPS"]),
  nps_score: z.number().int().min(0).max(10).optional(),
  answers: z.record(z.string(), z.union([z.string(), z.number(), z.boolean()])).default({}),
  is_anonymous: z.boolean().default(true),
});

export const Route = createFileRoute("/api/public/elegedettseg")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let body: unknown;
        try { body = await request.json(); } catch { return Response.json({ error: "invalid_json" }, { status: 400 }); }
        const parsed = Input.safeParse(body);
        if (!parsed.success) return Response.json({ error: parsed.error.flatten() }, { status: 400 });
        const d = parsed.data;

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const { data: appt, error } = await supabaseAdmin
          .from("appointments")
          .select("id, tenant_id, resource_id, status")
          .eq("foglalas_kod", d.foglalas_kod.toUpperCase())
          .eq("vendeg_email", d.vendeg_email.toLowerCase())
          .maybeSingle();
        if (error) return Response.json({ error: error.message }, { status: 500 });
        if (!appt) return Response.json({ error: "not_found" }, { status: 404 });
        if (appt.status !== "befejezett" && appt.status !== "megerkezett") {
          return Response.json({ error: "appointment_not_completed" }, { status: 409 });
        }

        const { error: ierr } = await supabaseAdmin.from("satisfaction_surveys").insert({
          tenant_id: appt.tenant_id,
          appointment_id: appt.id,
          resource_id: appt.resource_id,
          instrument_code: d.instrument_code,
          answers: d.answers,
          nps_score: d.nps_score ?? null,
          is_anonymous: d.is_anonymous,
          submitted_at: new Date().toISOString(),
        });
        if (ierr) return Response.json({ error: ierr.message }, { status: 500 });
        return Response.json({ ok: true });
      },
    },
  },
});
