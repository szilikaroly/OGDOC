import { createFileRoute } from "@tanstack/react-router";
import { createClient } from "@supabase/supabase-js";

/**
 * Élő diktálás (batch-streaming): a kliens egy hang-blobot küld multipart/form-data POST-tal,
 * a szerver továbbítja a Lovable AI transcription endpointra `stream=true`-val, és az SSE-t
 * pass-through visszaküldi a böngészőnek.
 */
export const Route = createFileRoute("/api/dictate")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const key = process.env.LOVABLE_API_KEY;
        if (!key) return new Response("Missing LOVABLE_API_KEY", { status: 500 });

        // Require an authenticated Supabase user before consuming AI credit.
        const url = process.env.SUPABASE_URL;
        const pubKey = process.env.SUPABASE_PUBLISHABLE_KEY;
        if (!url || !pubKey) return new Response("Server misconfigured", { status: 500 });
        const token = request.headers.get("authorization")?.replace(/^Bearer\s+/i, "") ?? "";
        if (!token) return new Response("Unauthorized", { status: 401 });
        const sb = createClient(url, pubKey, {
          global: { headers: { Authorization: `Bearer ${token}` } },
          auth: { persistSession: false, autoRefreshToken: false, storage: undefined },
        });
        const { data: u, error: uErr } = await sb.auth.getUser();
        if (uErr || !u.user) return new Response("Unauthorized", { status: 401 });

        const inForm = await request.formData();
        const file = inForm.get("file");
        if (!(file instanceof File)) return new Response("file kötelező", { status: 400 });
        if (file.size > 20 * 1024 * 1024) return new Response("Túl nagy fájl (max 20MB)", { status: 413 });

        const ext = ({
          "audio/webm": "webm", "audio/mp4": "m4a", "audio/mpeg": "mp3", "audio/mp3": "mp3",
          "audio/wav": "wav", "audio/ogg": "ogg", "audio/m4a": "m4a",
        } as Record<string, string>)[file.type.split(";")[0]] ?? "webm";

        const upstream = new FormData();
        upstream.append("model", "openai/gpt-4o-mini-transcribe");
        upstream.append("file", file, `dictation.${ext}`);
        upstream.append("stream", "true");

        const r = await fetch("https://ai.gateway.lovable.dev/v1/audio/transcriptions", {
          method: "POST",
          headers: { Authorization: `Bearer ${key}` },
          body: upstream,
        });
        if (!r.ok || !r.body) {
          const t = await r.text().catch(() => "");
          return new Response(`Transcription failed: ${r.status} ${t}`, { status: 502 });
        }
        return new Response(r.body, {
          headers: {
            "Content-Type": "text/event-stream",
            "Cache-Control": "no-cache",
          },
        });
      },
    },
  },
});
