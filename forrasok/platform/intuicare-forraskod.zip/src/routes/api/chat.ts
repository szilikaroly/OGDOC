import { createFileRoute } from "@tanstack/react-router";
import { createLovableAiGatewayProvider } from "@/lib/ai-gateway.server";
import { convertToModelMessages, streamText, type UIMessage } from "ai";
import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

type ChatBody = { messages?: UIMessage[] };

async function buildSystemPrompt(token: string): Promise<{ system: string; userId: string | null }> {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_PUBLISHABLE_KEY;
  if (!url || !key) return { system: BASE_PROMPT, userId: null };

  const supabase = createClient<Database>(url, key, {
    global: { headers: { Authorization: `Bearer ${token}` } },
    auth: { persistSession: false, autoRefreshToken: false, storage: undefined },
  });

  const { data: userData } = await supabase.auth.getUser();
  const userId = userData.user?.id ?? null;
  if (!userId) return { system: BASE_PROMPT, userId: null };

  // Lekérjük a felhasználó szerepköreit (kulcs) a rolesból
  const { data: roleRows } = await supabase
    .from("user_roles")
    .select("role_id, roles!inner(kulcs, megnevezes, kategoria)")
    .eq("user_id", userId);

  const roles = (roleRows ?? [])
    .map((r) => {
      const role = (r as { roles?: { kulcs: string; megnevezes: string; kategoria: string } }).roles;
      return role ? `${role.megnevezes} (${role.kulcs}, ${role.kategoria})` : null;
    })
    .filter(Boolean) as string[];

  const { data: profile } = await supabase
    .from("profiles")
    .select("teljes_nev, becenev")
    .eq("id", userId)
    .maybeSingle();

  const isAdminLike = roles.some((r) =>
    /admin|fonok|vezeto|koordinator|igazgato/i.test(r),
  );

  const roleContext = roles.length
    ? `A felhasználó szerepkörei: ${roles.join("; ")}.`
    : "A felhasználónak még nincs szerepköre.";

  const adminAddon = isAdminLike
    ? "\nA felhasználó vezetői/koordinátori jogkörrel rendelkezik – válaszolhatsz beosztás-tervezési, lefedettség-elemzési, túlóra-elrendelési és pótlási kérdésekre is."
    : "\nA felhasználó nem rendelkezik admin jogkörrel – ne adj ki más kollégákra vonatkozó személyes adatokat; a vezetői funkciókat csak általánosan, súgó-szinten ismertesd.";

  return {
    userId,
    system: `${BASE_PROMPT}\n\nFelhasználó: ${profile?.teljes_nev ?? profile?.becenev ?? "ismeretlen"}.\n${roleContext}${adminAddon}`,
  };
}

const BASE_PROMPT = `Te a Kórházi Műszak- és Karakterlap-rendszer beépített AI asszisztense vagy. Magyarul válaszolj, tömören, gyakorlatiasan.

Feladataid:
1. KARAKTERLAP KITÖLTÉS – segítsd a dolgozót a /karakterlap oldalon: magyarázd a mezőket (személyes adatok, szakképesítések, beavatkozások, kompetencia-szintek, elérhetőségi preferenciák, ügyelet-vállalás, pár-műszakok). Mondd meg mit kötelező kitölteni és miért.
2. RENDSZERHASZNÁLAT – navigációs súgó: hol találja a beosztást, jelenlétet, munkaidőt, képzéseket, pótlást, túlóra-pool-t. Hibák értelmezése.
3. JOGI HÁTTÉR – általános magyarázat a 528/2020 Korm. rendeletről (heti pihenőidő, ügyelet-időkeret), Mt. munkaidő-szabályairól, opt-out megállapodásokról. NEM jogi tanácsadás – javasold a HR/jogi osztály bevonását fontos döntéseknél.
4. ADATVÉDELEM – soha nem adsz ki más felhasználók személyes adatait, betegadatokat. Saját adatait kérdezheted tőle vagy az alkalmazás megfelelő oldalára irányíthatod.

Stílus: rövid bekezdések, listák, ha lehetséges navigációs hivatkozás (pl. "/karakterlap > Beavatkozások fül"). Ha nem tudsz biztosan válaszolni: jelezd és javasold a Szervezet kézikönyv (/admin/szervezet-sugo) vagy a vezető megkérdezését.`;

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const apiKey = process.env.LOVABLE_API_KEY;
        if (!apiKey) {
          return new Response("Missing LOVABLE_API_KEY", { status: 500 });
        }
        const authHeader = request.headers.get("authorization") ?? "";
        const token = authHeader.replace(/^Bearer\s+/, "");
        if (!token) return new Response("Unauthorized", { status: 401 });

        // Validate the token against Supabase before consuming AI credit.
        const url = process.env.SUPABASE_URL;
        const pubKey = process.env.SUPABASE_PUBLISHABLE_KEY;
        if (!url || !pubKey) return new Response("Server misconfigured", { status: 500 });
        const authClient = createClient<Database>(url, pubKey, {
          global: { headers: { Authorization: `Bearer ${token}` } },
          auth: { persistSession: false, autoRefreshToken: false, storage: undefined },
        });
        const { data: authData, error: authErr } = await authClient.auth.getUser();
        if (authErr || !authData.user) return new Response("Unauthorized", { status: 401 });

        const { messages } = (await request.json()) as ChatBody;
        if (!Array.isArray(messages)) {
          return new Response("Missing messages", { status: 400 });
        }

        const { system } = await buildSystemPrompt(token);

        const gateway = createLovableAiGatewayProvider(apiKey);
        const result = streamText({
          model: gateway("google/gemini-3-flash-preview"),
          system,
          messages: await convertToModelMessages(messages),
        });

        return result.toUIMessageStreamResponse({
          onError: (err) => {
            console.error("[chat] stream error", err);
            const msg = err instanceof Error ? err.message : "AI hiba";
            if (/429/.test(msg)) return "Túl sok kérés – próbáld újra pár másodperc múlva.";
            if (/402/.test(msg)) return "Az AI keret elfogyott – jelezd a rendszergazdának.";
            return "AI hiba történt. Próbáld újra később.";
          },
        });
      },
    },
  },
});
