import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Loader2, Link2, Link2Off, ShieldCheck, ArrowLeft } from "lucide-react";

export const Route = createFileRoute("/_authenticated/fiok")({
  component: FiokPage,
  errorComponent: ({ error, reset }) => (
    <div className="p-6">
      <Card className="p-4 text-sm text-destructive">
        Hiba a fiók-oldal betöltésekor: {error.message}
        <Button size="sm" variant="outline" className="ml-3" onClick={reset}>
          Újra
        </Button>
      </Card>
    </div>
  ),
  notFoundComponent: () => <div className="p-6 text-sm">Az oldal nem található.</div>,
});

type Identity = {
  id: string;
  identity_id?: string;
  provider: string;
  email?: string;
  created_at?: string;
  last_sign_in_at?: string;
  identity_data?: Record<string, any>;
};

const PROVIDER_LABEL: Record<string, string> = {
  email: "E-mail / jelszó",
  google: "Google",
  apple: "Apple",
  microsoft: "Microsoft",
};

const LINKABLE: Array<{ provider: "google" | "apple"; label: string }> = [
  { provider: "google", label: "Google" },
  { provider: "apple", label: "Apple" },
];

function FiokPage() {
  const [identities, setIdentities] = useState<Identity[] | null>(null);
  const [email, setEmail] = useState<string | null>(null);
  const [loadingProvider, setLoadingProvider] = useState<string | null>(null);

  const refresh = async () => {
    const { data: userData } = await supabase.auth.getUser();
    setEmail(userData.user?.email ?? null);
    const { data, error } = await supabase.auth.getUserIdentities();
    if (error) {
      toast.error("Nem sikerült betölteni a fiók-adatokat", { description: error.message });
      setIdentities([]);
      return;
    }
    setIdentities((data?.identities ?? []) as Identity[]);
  };

  useEffect(() => {
    refresh();
  }, []);

  const hasProvider = (p: string) => identities?.some((i) => i.provider === p) ?? false;

  const handleLink = async (provider: "google" | "apple") => {
    setLoadingProvider(provider);
    try {
      const { error } = await supabase.auth.linkIdentity({
        provider,
        options: { redirectTo: `${window.location.origin}/fiok` },
      });
      if (error) {
        // Ha nincs engedélyezve a Manual Linking a backenden
        const msg = error.message ?? "";
        if (/manual linking|not enabled|disabled/i.test(msg)) {
          toast.error("A fiók-összekapcsolás jelenleg nincs engedélyezve a backenden.", {
            description:
              "Kérjük, engedélyezze a Manual Linking opciót a Lovable Cloud → Users → Auth Settings menüben.",
          });
        } else {
          toast.error("Összekapcsolás sikertelen", { description: msg });
        }
      }
      // sikeres esetben redirect történik
    } catch (e: any) {
      toast.error("Összekapcsolás hiba", { description: e?.message });
    } finally {
      setLoadingProvider(null);
    }
  };

  const handleUnlink = async (identity: Identity) => {
    if (!identities || identities.length <= 1) {
      toast.error("Legalább egy bejelentkezési módot meg kell hagyni.");
      return;
    }
    if (!confirm(`Biztosan leválasztod a(z) ${PROVIDER_LABEL[identity.provider] ?? identity.provider} fiókot?`))
      return;
    setLoadingProvider(identity.provider);
    try {
      const { error } = await supabase.auth.unlinkIdentity(identity as any);
      if (error) {
        toast.error("Leválasztás sikertelen", { description: error.message });
      } else {
        toast.success(`${PROVIDER_LABEL[identity.provider] ?? identity.provider} leválasztva.`);
        await refresh();
      }
    } catch (e: any) {
      toast.error("Leválasztás hiba", { description: e?.message });
    } finally {
      setLoadingProvider(null);
    }
  };

  return (
    <div className="max-w-3xl mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
      <div className="flex items-center gap-2">
        <Button asChild variant="ghost" size="sm">
          <Link to="/dashboard">
            <ArrowLeft className="h-4 w-4 mr-1" /> Vissza
          </Link>
        </Button>
      </div>

      <div>
        <h1 className="text-2xl font-bold tracking-tight">Fiók-összekapcsolás</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Kapcsold össze a Google és Apple fiókodat ugyanazzal a MedRoster-fiókkal, hogy bármelyikkel be tudj lépni.
        </p>
        {email && (
          <p className="text-xs text-muted-foreground mt-2 font-mono">Bejelentkezve: {email}</p>
        )}
      </div>

      <Card className="p-4 sm:p-6 space-y-4">
        <div className="flex items-center gap-2">
          <ShieldCheck className="h-4 w-4 text-primary" />
          <h2 className="font-semibold">Összekapcsolt bejelentkezési módok</h2>
        </div>
        <Separator />
        {identities === null ? (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" /> Betöltés…
          </div>
        ) : identities.length === 0 ? (
          <div className="text-sm text-muted-foreground">Nincs regisztrált bejelentkezési mód.</div>
        ) : (
          <ul className="space-y-2">
            {identities.map((i) => (
              <li
                key={i.identity_id ?? `${i.provider}-${i.id}`}
                className="flex items-center justify-between gap-3 rounded-lg border bg-card px-3 py-2"
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-sm">
                      {PROVIDER_LABEL[i.provider] ?? i.provider}
                    </span>
                    <Badge variant="secondary" className="text-[10px]">aktív</Badge>
                  </div>
                  <div className="text-xs text-muted-foreground truncate">
                    {i.email ?? i.identity_data?.email ?? "—"}
                  </div>
                </div>
                {i.provider !== "email" && identities.length > 1 && (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleUnlink(i)}
                    disabled={loadingProvider === i.provider}
                  >
                    <Link2Off className="h-3.5 w-3.5 mr-1" /> Leválasztás
                  </Button>
                )}
              </li>
            ))}
          </ul>
        )}
      </Card>

      <Card className="p-4 sm:p-6 space-y-4">
        <div className="flex items-center gap-2">
          <Link2 className="h-4 w-4 text-primary" />
          <h2 className="font-semibold">Új szolgáltatás összekapcsolása</h2>
        </div>
        <Separator />
        <div className="grid gap-2 sm:grid-cols-2">
          {LINKABLE.map(({ provider, label }) => {
            const already = hasProvider(provider);
            return (
              <Button
                key={provider}
                variant={already ? "secondary" : "outline"}
                disabled={already || loadingProvider === provider}
                onClick={() => handleLink(provider)}
                className="justify-start min-h-11"
              >
                {loadingProvider === provider ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Link2 className="h-4 w-4 mr-2" />
                )}
                {already ? `${label} — összekapcsolva` : `${label} összekapcsolása`}
              </Button>
            );
          })}
        </div>
        <p className="text-xs text-muted-foreground">
          A gombra kattintva átirányítunk a szolgáltatóhoz jóváhagyásra. Sikeres bejelentkezés után visszatérsz ide, és
          a fiók az aktuális MedRoster-fiókodhoz lesz kötve.
        </p>
      </Card>
    </div>
  );
}
