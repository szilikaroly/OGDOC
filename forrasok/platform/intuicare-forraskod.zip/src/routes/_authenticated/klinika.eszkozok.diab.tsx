import { createFileRoute, Link, useSearch } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Activity, ArrowLeft, Save, Loader2, RotateCcw, AlertTriangle, FileText, BarChart3, Pill, Calculator, Bell } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { toast } from "sonner";
import {
  calculateInsulin, DEFAULT_MODIFIERS, INSULIN_PREPS,
  type InsulinInputs, type Modifiers, type MealRatio, type InsulinMode, type DiabetesType, type BolusType,
} from "@/lib/clinical/ada2025";
import {
  DIAB_DRUGS, analyzeDrugCombo, parseWeeklyPaste, analyzeWeek,
  type DrugId, type DrugStatus, type ParsedVcRow,
} from "@/lib/clinical/diab-drugs";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ReferenceArea, ResponsiveContainer, Legend } from "recharts";

export const Route = createFileRoute("/_authenticated/klinika/eszkozok/diab")({
  validateSearch: (s: Record<string, unknown>): { encounterId?: string; patientId?: string; tab?: string } => ({
    encounterId: typeof s.encounterId === "string" ? s.encounterId : undefined,
    patientId: typeof s.patientId === "string" ? s.patientId : undefined,
    tab: typeof s.tab === "string" ? s.tab : undefined,
  }),
  component: DiabPage,
});

type Tab = "insulin" | "drugs" | "weekly" | "protocols";

function DiabPage() {
  const { user } = useAuth();
  const { encounterId, patientId, tab: initialTab } = useSearch({ from: "/_authenticated/klinika/eszkozok/diab" });
  const [tab, setTab] = useState<Tab>((initialTab as Tab) ?? "insulin");
  const [activeEncounter, setActiveEncounter] = useState<{ id: string; patient_id: string; label: string } | null>(null);
  const [alerts, setAlerts] = useState<Array<{ id: string; severity: string; code: string; message: string; triggered_at: string }>>([]);

  useEffect(() => {
    void (async () => {
      let enc: { id: string; patient_id: string; encounter_type: string } | null = null;
      let p: { vezeteknev: string | null; keresztnev: string | null } | null = null;
      if (encounterId && patientId) {
        const er = await supabase.from("clinical_encounters").select("id, patient_id, encounter_type").eq("id", encounterId).maybeSingle();
        const pr = await supabase.from("patients").select("vezeteknev, keresztnev").eq("id", patientId).maybeSingle();
        enc = er.data as any; p = pr.data as any;
      } else if (user) {
        const r = await supabase
          .from("clinical_encounters")
          .select("id, patient_id, encounter_type, patients!inner(vezeteknev, keresztnev)")
          .eq("status", "in-progress").eq("created_by", user.id)
          .order("start_ts", { ascending: false }).limit(1).maybeSingle();
        if (r.data) { enc = r.data as any; p = (r.data as any).patients; }
      }
      if (enc && p) setActiveEncounter({ id: enc.id, patient_id: enc.patient_id, label: `${p.vezeteknev ?? ""} ${p.keresztnev ?? ""} · ${enc.encounter_type}` });
    })();
  }, [encounterId, patientId, user]);

  useEffect(() => {
    if (!activeEncounter) return;
    void (async () => {
      const { data } = await supabase
        .from("clinical_critical_alerts")
        .select("id, severity, code, message, triggered_at")
        .eq("patient_id", activeEncounter.patient_id)
        .is("acknowledged_at", null)
        .order("triggered_at", { ascending: false }).limit(8);
      setAlerts((data ?? []) as any);
    })();
  }, [activeEncounter, tab]);

  async function ackAlert(id: string) {
    if (!user) return;
    await supabase.from("clinical_critical_alerts").update({ acknowledged_at: new Date().toISOString(), acknowledged_by: user.id }).eq("id", id);
    setAlerts((a) => a.filter((x) => x.id !== id));
  }

  return (
    <div className="container max-w-7xl py-6 space-y-4">
      <header>
        <Link to="/klinika/eszkozok" className="text-xs text-muted-foreground hover:underline flex items-center gap-1">
          <ArrowLeft className="h-3 w-3" /> Eszközök
        </Link>
        <div className="flex items-start justify-between mt-1 gap-4 flex-wrap">
          <div>
            <h1 className="text-2xl font-semibold flex items-center gap-2">
              <Activity className="h-6 w-6 text-primary" /> Diabétesz Terápia (ADA 2025)
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              Inzulin kalkulátor · kiegészítő terápia · heti VC monitorozás · klinikai protokollok. Integrált rendszerszintű riasztásokkal.
            </p>
          </div>
          {activeEncounter && (
            <div className="text-xs text-muted-foreground bg-muted/40 px-3 py-1.5 rounded-md border border-border">
              Aktív epizód: <span className="font-mono">{activeEncounter.label}</span>
            </div>
          )}
        </div>
      </header>

      {alerts.length > 0 && (
        <div className="rounded-xl border border-destructive/40 bg-destructive/5 p-3 space-y-1.5">
          <div className="flex items-center gap-1.5 text-sm font-semibold text-destructive">
            <Bell className="h-4 w-4 animate-pulse" /> Aktív riasztások ({alerts.length})
          </div>
          <ul className="space-y-1">
            {alerts.map((a) => (
              <li key={a.id} className="flex items-center gap-2 text-xs">
                <span className={`px-1.5 py-0.5 rounded font-mono text-[10px] uppercase ${
                  a.severity === "critical" ? "bg-destructive text-destructive-foreground" :
                  a.severity === "warn" ? "bg-amber-500/20 text-amber-700" : "bg-muted text-muted-foreground"
                }`}>{a.severity}</span>
                <span className="font-mono text-muted-foreground">{a.code}</span>
                <span className="flex-1">{a.message}</span>
                <button onClick={() => ackAlert(a.id)} className="text-xs underline text-muted-foreground hover:text-foreground">Nyugtáz</button>
              </li>
            ))}
          </ul>
        </div>
      )}

      <nav className="flex gap-1 border-b border-border">
        {[
          { k: "insulin", l: "💉 Inzulin", I: Calculator },
          { k: "drugs", l: "💊 Kiegészítő terápia", I: Pill },
          { k: "weekly", l: "📋 Heti VC + grafikon", I: BarChart3 },
          { k: "protocols", l: "🚨 Protokollok", I: FileText },
        ].map((t) => (
          <button key={t.k} onClick={() => setTab(t.k as Tab)}
            className={`px-3 py-2 text-sm border-b-2 transition-colors ${tab === t.k ? "border-primary text-primary font-medium" : "border-transparent text-muted-foreground hover:text-foreground"}`}>
            {t.l}
          </button>
        ))}
      </nav>

      {tab === "insulin" && <InsulinTab encounter={activeEncounter} userId={user?.id} />}
      {tab === "drugs" && <DrugsTab encounter={activeEncounter} userId={user?.id} />}
      {tab === "weekly" && <WeeklyTab encounter={activeEncounter} userId={user?.id} />}
      {tab === "protocols" && <ProtocolsTab />}
    </div>
  );
}

// ============== INSULIN TAB ==============

const DEFAULT_INSULIN: InsulinInputs = {
  mode: "bb",
  diabetesType: "t2r",
  weightKg: 80,
  bolusType: "analog",
  mealRatio: "333",
  modifiers: DEFAULT_MODIFIERS,
  currentVc: null,
  targetVc: 6.0,
};

function InsulinTab({ encounter, userId }: { encounter: { id: string; patient_id: string; label: string } | null; userId?: string }) {
  const [input, setInput] = useState<InsulinInputs>(DEFAULT_INSULIN);
  const [bolusPrep, setBolusPrep] = useState("novorapid");
  const [basalPrep, setBasalPrep] = useState("tresiba");
  const [premixPrep, setPremixPrep] = useState("novomix30");
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);

  const result = useMemo(() => calculateInsulin(input), [input]);

  function setMod<K extends keyof Modifiers>(k: K, v: boolean) {
    setInput((x) => ({ ...x, modifiers: { ...x.modifiers, [k]: v } }));
  }

  async function save() {
    if (!encounter || !userId) { toast.error("Nincs aktív epizód"); return; }
    setSaving(true);
    try {
      const { error } = await supabase.from("clinical_insulin_sessions").insert({
        encounter_id: encounter.id,
        patient_id: encounter.patient_id,
        mode: input.mode,
        diabetes_type: input.diabetesType,
        weight_kg: input.weightKg,
        bolus_type: input.bolusType,
        meal_ratio: input.mealRatio,
        bolus_prep_id: bolusPrep,
        basal_prep_id: basalPrep,
        premix_prep_id: premixPrep,
        tdd: result.tdd,
        basal: result.basal,
        bolus_r: result.doses.r,
        bolus_d: result.doses.d,
        bolus_e: result.doses.e,
        icr: result.icr,
        isf: result.isf,
        target_vc: input.targetVc,
        current_vc: input.currentVc,
        correction_bolus: result.correctionBolus,
        modifiers_json: input.modifiers as any,
        notes,
        created_by: userId,
      });
      if (error) throw error;
      toast.success("Inzulin session mentve");
    } catch (e: any) { toast.error(e?.message ?? "Hiba"); }
    finally { setSaving(false); }
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mt-4">
      <div className="rounded-xl border border-border bg-card p-4 space-y-3 lg:col-span-2">
        <h3 className="text-sm font-semibold">Beteg-paraméterek</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          <Sel label="Mód" value={input.mode} onChange={(v) => setInput({ ...input, mode: v as InsulinMode })}
            options={[["bb", "Basal-Bolus"], ["premix2", "Premix 2×"], ["premix3", "Premix 3×"]]} />
          <Sel label="DM típus" value={input.diabetesType} onChange={(v) => setInput({ ...input, diabetesType: v as DiabetesType })}
            options={[["t1", "T1DM"], ["t2", "T2DM (naiv)"], ["t2r", "T2DM (alapozott)"], ["gest", "Gesztációs"]]} />
          <Num label="Testsúly (kg)" value={input.weightKg} onChange={(v) => setInput({ ...input, weightKg: v })} step={0.5} />
          {input.mode === "bb" && (
            <>
              <Sel label="Bólusz típus" value={input.bolusType} onChange={(v) => setInput({ ...input, bolusType: v as BolusType })}
                options={[["analog", "Analóg"], ["regular", "Regular"]]} />
              <Sel label="Étrendi arány" value={input.mealRatio} onChange={(v) => setInput({ ...input, mealRatio: v as MealRatio })}
                options={[["333", "33/33/33"], ["402040", "40/20/40"], ["204040", "20/40/40"], ["403030", "40/30/30"]]} />
            </>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-2 border-t border-border">
          {input.mode === "bb" && (
            <>
              <Sel label="Bólusz készítmény" value={bolusPrep} onChange={setBolusPrep}
                options={INSULIN_PREPS.bolus.map((p) => [p.id, p.name])} />
              <Sel label="Bázis készítmény" value={basalPrep} onChange={setBasalPrep}
                options={INSULIN_PREPS.basal.map((p) => [p.id, p.name])} />
            </>
          )}
          {input.mode !== "bb" && (
            <Sel label="Premix készítmény" value={premixPrep} onChange={setPremixPrep}
              options={INSULIN_PREPS.premix.map((p) => [p.id, p.name])} />
          )}
        </div>

        <div className="pt-2 border-t border-border">
          <div className="text-xs uppercase font-mono text-muted-foreground mb-2">Hatásmódosítók</div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {([
              ["steroid", "Szteroid (+25%)"], ["ckd", "CKD (−20%)"], ["surgery", "Műtét (+10%)"], ["infection", "Infekció (+15%)"],
              ["pregnancy", "Terhesség (+10%)"], ["elderly", "Idős (−15%)"], ["obese", "Obesitas (+10%)"], ["enteral", "Enterális (−20%)"],
            ] as Array<[keyof Modifiers, string]>).map(([k, l]) => (
              <Chk key={k} label={l} value={input.modifiers[k]} onChange={(v) => setMod(k, v)} />
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2 border-t border-border">
          <Num label="Cél VC (mmol/L)" value={input.targetVc} onChange={(v) => setInput({ ...input, targetVc: v })} step={0.1} />
          <Num label="Aktuális VC (mmol/L)" value={input.currentVc ?? 0} onChange={(v) => setInput({ ...input, currentVc: v || null })} step={0.1} />
        </div>

        <label className="block pt-2 border-t border-border">
          <span className="text-xs text-muted-foreground">Megjegyzés</span>
          <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2}
            className="mt-1 w-full px-2 py-1.5 text-sm rounded-md border border-border bg-background" />
        </label>

        <div className="flex items-center gap-2 pt-2">
          <button onClick={() => setInput(DEFAULT_INSULIN)} className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-md border border-border hover:bg-accent">
            <RotateCcw className="h-3.5 w-3.5" /> Reset
          </button>
          <button onClick={save} disabled={saving || !encounter || result.hypoBlock}
            className="ml-auto inline-flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-md bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50">
            {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
            Mentés {encounter ? "az epizódhoz" : "(nincs aktív epizód)"}
          </button>
        </div>
      </div>

      <div className="rounded-xl border border-border bg-card p-4 space-y-3">
        {result.hypoBlock && (
          <div className="rounded-md border-2 border-destructive bg-destructive/10 p-3">
            <div className="flex items-center gap-2 text-destructive font-semibold">
              <AlertTriangle className="h-4 w-4" /> HYPOGLIKÉMIA — Bólusz tiltva
            </div>
            <p className="text-xs mt-1">VC &lt; 3.9 mmol/L. 15-15 szabály: 15 g gyors CH, 15 perc múlva újra mérés. Lásd Protokollok fül.</p>
          </div>
        )}

        <div className="grid grid-cols-2 gap-2">
          <Metric label="TDD" value={`${result.tdd} NE`} hint={`alap: ${result.baseTdd} × ${result.modifierFactor}`} />
          <Metric label={input.mode === "bb" ? "Bázis" : "Premix"} value={`${result.basal || result.bolusTotal} NE`} />
          <Metric label="Bólusz össz." value={`${result.bolusTotal} NE`} />
          <Metric label="Korrekció" value={result.correctionBolus !== null ? `+${result.correctionBolus} NE` : "—"} hint={input.currentVc ? `cél ${input.targetVc}` : "VC nem megadva"} />
          <Metric label="ICR" value={`1 NE / ${result.icr} g`} hint="szénhidrát-arány" />
          <Metric label="ISF" value={`1 NE / ${result.isf} mmol/L`} hint="korrekciós faktor" />
        </div>

        <div className="rounded-md bg-muted/40 p-3 space-y-1">
          <div className="text-xs uppercase font-mono text-muted-foreground">Dózizkártya</div>
          <div className="grid grid-cols-4 gap-2 text-center">
            {(["r", "d", "e", "b"] as const).map((k) => (
              <div key={k} className="rounded border border-border bg-background p-2">
                <div className="text-[10px] uppercase font-mono text-muted-foreground">{k === "r" ? "Reggel" : k === "d" ? "Dél" : k === "e" ? "Este" : "Lefekvés"}</div>
                <div className="font-mono font-semibold">{result.doses[k]} NE</div>
              </div>
            ))}
          </div>
        </div>

        {result.modifierNotes.length > 0 && (
          <div className="text-xs text-muted-foreground">
            <b>Módosítók:</b> {result.modifierNotes.join(", ")}
          </div>
        )}
      </div>
    </div>
  );
}

// ============== DRUGS TAB ==============

function DrugsTab({ encounter, userId }: { encounter: { id: string; patient_id: string; label: string } | null; userId?: string }) {
  const [statuses, setStatuses] = useState<Partial<Record<DrugId, DrugStatus>>>({});
  const [selected, setSelected] = useState<DrugId>("metformin");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!encounter) return;
    void (async () => {
      const { data } = await supabase.from("clinical_drug_statuses").select("drug_id, status").eq("patient_id", encounter.patient_id);
      const map: Partial<Record<DrugId, DrugStatus>> = {};
      (data ?? []).forEach((r: any) => { map[r.drug_id as DrugId] = r.status; });
      setStatuses(map);
    })();
  }, [encounter]);

  const analysis = useMemo(() => analyzeDrugCombo(statuses), [statuses]);

  async function updateStatus(drug: DrugId, status: DrugStatus) {
    setStatuses((s) => ({ ...s, [drug]: status }));
    if (!encounter || !userId) return;
    setSaving(true);
    try {
      const { error } = await supabase.from("clinical_drug_statuses").upsert({
        patient_id: encounter.patient_id, encounter_id: encounter.id,
        drug_id: drug, status, created_by: userId,
      }, { onConflict: "patient_id,drug_id" });
      if (error) throw error;
    } catch (e: any) { toast.error(e?.message ?? "Mentés hiba"); }
    finally { setSaving(false); }
  }

  const drug = DIAB_DRUGS.find((d) => d.id === selected)!;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mt-4">
      <div className="space-y-3">
        {DIAB_DRUGS.map((d) => {
          const st = statuses[d.id] ?? "none";
          return (
            <div key={d.id} onClick={() => setSelected(d.id)}
              className={`rounded-lg border p-3 cursor-pointer transition-colors ${selected === d.id ? "border-primary bg-primary/5" : "border-border bg-card hover:bg-accent/40"}`}>
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-semibold text-sm" style={{ color: d.color }}>{d.hu}</div>
                  <div className="text-xs text-muted-foreground">{d.cls}</div>
                </div>
                <span className={`text-[10px] uppercase font-mono px-1.5 py-0.5 rounded ${
                  st === "current" ? "bg-emerald-500/20 text-emerald-700" :
                  st === "planned" ? "bg-sky-500/20 text-sky-700" :
                  st === "stop" ? "bg-destructive/20 text-destructive" : "bg-muted text-muted-foreground"
                }`}>{st}</span>
              </div>
              <div className="grid grid-cols-4 gap-1 mt-2">
                {(["none", "current", "planned", "stop"] as DrugStatus[]).map((s) => (
                  <button key={s} onClick={(e) => { e.stopPropagation(); updateStatus(d.id, s); }} disabled={saving || !encounter}
                    className={`text-[10px] py-1 rounded border ${st === s ? "bg-primary text-primary-foreground border-primary" : "border-border hover:bg-accent"} disabled:opacity-50`}>
                    {s === "none" ? "nincs" : s === "current" ? "jelenlegi" : s === "planned" ? "tervezett" : "elhagy."}
                  </button>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      <div className="lg:col-span-2 space-y-3">
        <div className="rounded-xl border border-border bg-card p-4 space-y-3">
          <div className="flex items-start justify-between">
            <div>
              <h3 className="text-base font-semibold" style={{ color: drug.color }}>{drug.hu} — {drug.cls}</h3>
              <p className="text-xs text-muted-foreground mt-0.5">{drug.mech}</p>
            </div>
            <div className="text-right text-xs text-muted-foreground">
              <div>HbA1c: <b className="text-foreground">{drug.hba1c}</b></div>
              <div>Súly: <b className="text-foreground">{drug.weight}</b></div>
              <div>CV: <b className="text-foreground">{drug.cv}</b></div>
              <div>Hypo: <b className="text-foreground">{drug.hypoRisk}</b></div>
            </div>
          </div>

          <div>
            <div className="text-xs uppercase font-mono text-muted-foreground mb-1">Készítmények</div>
            <div className="flex flex-wrap gap-1">
              {drug.drugs.map((dn) => <span key={dn} className="text-xs bg-muted px-2 py-0.5 rounded">{dn}</span>)}
            </div>
          </div>

          <div>
            <div className="text-xs uppercase font-mono text-muted-foreground mb-1">CKD biztonsági táblázat (eGFR ml/min/1,73 m²)</div>
            <table className="w-full text-xs">
              <tbody>
                {drug.ckd.map((c) => (
                  <tr key={c.gfr} className="border-t border-border">
                    <td className="py-1.5 font-mono w-20">{c.gfr}</td>
                    <td className="py-1.5">
                      <span className={`inline-block px-1.5 py-0.5 rounded text-[10px] uppercase mr-2 ${
                        c.safety === "ok" ? "bg-emerald-500/20 text-emerald-700" :
                        c.safety === "cau" ? "bg-amber-500/20 text-amber-700" :
                        c.safety === "con" ? "bg-destructive/20 text-destructive" : "bg-muted"
                      }`}>{c.safety}</span>
                      {c.text}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="rounded-md bg-muted/40 p-2">
              <div className="text-[10px] uppercase font-mono text-muted-foreground">Terhesség</div>
              <div className={drug.pregnancy.safety === "con" ? "text-destructive" : ""}>{drug.pregnancy.note}</div>
            </div>
            <div className="rounded-md bg-muted/40 p-2">
              <div className="text-[10px] uppercase font-mono text-muted-foreground">Kombináció</div>
              <div>{drug.combo}</div>
            </div>
          </div>

          <div className="rounded-md border border-border bg-primary/5 p-3 text-xs space-y-1">
            <div className="font-semibold mb-1">Beteg-tájékoztató</div>
            <div><b>Hogyan:</b> {drug.patient.how}</div>
            <div><b>Mit csinál:</b> {drug.patient.what}</div>
            <div><b>Figyelni:</b> {drug.patient.watch}</div>
            <div><b>Előny:</b> {drug.patient.good}</div>
            <div><b>Elhagyás:</b> {drug.patient.stopNote}</div>
          </div>
        </div>

        <div className="rounded-xl border border-border bg-card p-4 space-y-2">
          <h4 className="text-sm font-semibold">Klinikai kombináció elemzés</h4>
          <div className="text-xs">Aktív vagy tervezett: <b>{analysis.active.length}</b> ({analysis.active.join(", ") || "—"})</div>
          {analysis.totalInsulinReduction > 0 && (
            <div className="text-xs">Becsült inzulin-megtakarítás: <b className="text-primary">~{analysis.totalInsulinReduction} NE/nap</b></div>
          )}
          {analysis.warnings.length > 0 && (
            <ul className="space-y-1 mt-2">
              {analysis.warnings.map((w, i) => (
                <li key={i} className="text-xs text-amber-700 flex items-start gap-1.5"><AlertTriangle className="h-3 w-3 mt-0.5 flex-shrink-0" />{w}</li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}

// ============== WEEKLY TAB ==============

const DEMO_DATA = `2026-06-14\t6\t4\t8\t18\t8.2\t6.5\t9.1\t7.2\t10.4\t6.8\t9.8
2026-06-15\t6\t4\t8\t18\t7.8\t6.2\t8.5\t6.9\t9.8\t6.5\t9.2
2026-06-16\t6\t4\t8\t20\t9.1\t7.0\t10.2\t7.5\t11.0\t7.2\t10.5
2026-06-17\t6\t4\t8\t20\t7.5\t6.0\t8.8\t6.5\t9.5\t6.2\t9.0
2026-06-18\t8\t4\t8\t20\t6.8\t5.5\t8.2\t6.0\t8.8\t5.8\t8.5
2026-06-19\t8\t4\t10\t22\t6.5\t5.2\t7.8\t5.8\t8.5\t5.5\t8.2
2026-06-20\t8\t4\t10\t22\t6.2\t5.0\t7.5\t5.5\t8.0\t5.2\t7.8`;

function WeeklyTab({ encounter, userId }: { encounter: { id: string; patient_id: string; label: string } | null; userId?: string }) {
  const [raw, setRaw] = useState("");
  const [rows, setRows] = useState<ParsedVcRow[]>([]);
  const [saving, setSaving] = useState(false);

  function loadDemo() { setRaw(DEMO_DATA); setRows(parseWeeklyPaste(DEMO_DATA)); }
  function parseNow() { setRows(parseWeeklyPaste(raw)); }

  const analysis = useMemo(() => analyzeWeek(rows), [rows]);

  // Chart data
  const vcSeries = rows.flatMap((r) =>
    Object.entries(r.measurements).map(([k, v]) => ({ day: r.date.slice(5), point: k, vc: v }))
  );
  const profileData = (["night", "fasting", "regPP", "lunchPre", "lunchPP", "dinnerPre", "dinnerPP"] as const).map((pt) => {
    const obj: any = { time: pt };
    rows.forEach((r) => { obj[r.date.slice(5)] = r.measurements[pt] ?? null; });
    return obj;
  });
  const doseData = rows.map((r) => ({
    day: r.date.slice(5), bolus: (r.bolus_r ?? 0) + (r.bolus_d ?? 0) + (r.bolus_e ?? 0), basal: r.basal ?? 0,
  }));

  async function saveAllToPatient() {
    if (!encounter || !userId) { toast.error("Nincs aktív epizód"); return; }
    setSaving(true);
    try {
      const inserts: any[] = [];
      for (const r of rows) {
        for (const [type, value] of Object.entries(r.measurements)) {
          if (typeof value === "number") {
            inserts.push({
              patient_id: encounter.patient_id,
              encounter_id: encounter.id,
              measured_at: `${r.date}T${typeForTime(type)}:00.000Z`,
              value_mmol_l: value,
              measurement_type: type,
              created_by: userId,
            });
          }
        }
      }
      if (inserts.length === 0) { toast.error("Nincs adat"); return; }
      const { error } = await supabase.from("clinical_weekly_vc").insert(inserts);
      if (error) throw error;
      toast.success(`${inserts.length} mérés mentve — riasztások automatikusan generálva`);
    } catch (e: any) { toast.error(e?.message ?? "Hiba"); }
    finally { setSaving(false); }
  }

  function typeForTime(t: string): string {
    return ({ night: "23:00", fasting: "06:00", regPP: "08:00", lunchPre: "12:00", lunchPP: "14:00", dinnerPre: "18:00", dinnerPP: "20:00" } as Record<string, string>)[t] ?? "12:00";
  }

  return (
    <div className="space-y-4 mt-4">
      <div className="rounded-xl border border-border bg-card p-4 space-y-2">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold">Heti VC adat (Excel paste, tab/vessző elválasztva)</h3>
          <div className="flex gap-2">
            <button onClick={loadDemo} className="text-xs px-2 py-1 rounded border border-border hover:bg-accent">Demó betöltés</button>
            <button onClick={parseNow} className="text-xs px-2 py-1 rounded bg-primary text-primary-foreground">Feldolgozás</button>
            <button onClick={saveAllToPatient} disabled={saving || rows.length === 0 || !encounter}
              className="text-xs px-2 py-1 rounded bg-primary text-primary-foreground inline-flex items-center gap-1 disabled:opacity-50">
              {saving ? <Loader2 className="h-3 w-3 animate-spin" /> : <Save className="h-3 w-3" />}Mentés páciensbe
            </button>
          </div>
        </div>
        <p className="text-xs text-muted-foreground">Oszlopok: dátum, bolus_r, bolus_d, bolus_e, basal, éjjeli, éhomi, reggeli_pp, déli_pre, déli_pp, esti_pre, esti_pp</p>
        <textarea value={raw} onChange={(e) => setRaw(e.target.value)} rows={6} placeholder="2026-06-20	6	4	8	18	8.2	6.5	..."
          className="w-full px-2 py-1.5 text-xs font-mono rounded-md border border-border bg-background" />
      </div>

      {rows.length > 0 && (
        <>
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
            <Metric label="Átl. éhomi" value={analysis.avgFasting !== null ? `${analysis.avgFasting} mmol/L` : "—"} />
            <Metric label="TIR (4.4–10)" value={analysis.tir !== null ? `${analysis.tir}%` : "—"} hint="cél > 70%" />
            <Metric label="Hypo" value={`${analysis.hypoCount}`} hint="< 3.9 mmol/L" />
            <Metric label="Hyper" value={`${analysis.hyperCount}`} hint="> 10 mmol/L" />
            <Metric label="Dawn" value={`${analysis.dawnDays} nap`} hint="éjj→éh > 2" />
          </div>

          {(analysis.highStreak >= 3 || analysis.lowStreak >= 3) && (
            <div className="rounded-md border border-amber-500/40 bg-amber-50/40 p-3 text-xs space-y-1">
              <div className="font-semibold flex items-center gap-1.5"><AlertTriangle className="h-3.5 w-3.5 text-amber-700" /> 3-3 szabály</div>
              {analysis.highStreak >= 3 && <div>{analysis.highStreak} egymást követő nap éhomi &gt; 7,2 → <b>bázis inzulin emelése</b> mérlegelendő (+10–20%)</div>}
              {analysis.lowStreak >= 3 && <div>{analysis.lowStreak} egymást követő nap éhomi &lt; 4,4 → <b>bázis inzulin csökkentése</b> mérlegelendő (−10–20%)</div>}
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="rounded-xl border border-border bg-card p-4">
              <h4 className="text-sm font-semibold mb-2">Napi VC profil (7-pontos)</h4>
              <ResponsiveContainer width="100%" height={260}>
                <LineChart data={profileData}>
                  <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                  <XAxis dataKey="time" style={{ fontSize: 10 }} />
                  <YAxis domain={[2, 18]} style={{ fontSize: 10 }} />
                  <ReferenceArea y1={4.4} y2={10} fill="#10b981" fillOpacity={0.08} />
                  <Tooltip />
                  <Legend wrapperStyle={{ fontSize: 10 }} />
                  {rows.map((r, i) => (
                    <Line key={r.date} type="monotone" dataKey={r.date.slice(5)} stroke={`hsl(${i * 50}, 70%, 50%)`} strokeWidth={1.5} dot={{ r: 2 }} connectNulls />
                  ))}
                </LineChart>
              </ResponsiveContainer>
            </div>

            <div className="rounded-xl border border-border bg-card p-4">
              <h4 className="text-sm font-semibold mb-2">Inzulin dózisok (NE)</h4>
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={doseData}>
                  <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                  <XAxis dataKey="day" style={{ fontSize: 10 }} />
                  <YAxis style={{ fontSize: 10 }} />
                  <Tooltip />
                  <Legend wrapperStyle={{ fontSize: 10 }} />
                  <Bar dataKey="bolus" fill="#0ea5e9" name="Bólusz" />
                  <Bar dataKey="basal" fill="#8b5cf6" name="Bázis" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="rounded-xl border border-border bg-card p-4 overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="text-left text-muted-foreground border-b border-border">
                  <th className="py-1.5">Dátum</th><th>Éjjeli</th><th>Éhomi</th><th>Reg PP</th>
                  <th>Déli pre</th><th>Déli PP</th><th>Esti pre</th><th>Esti PP</th>
                  <th>Bólusz</th><th>Bázis</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.date} className="border-t border-border font-mono">
                    <td className="py-1">{r.date}</td>
                    {(["night","fasting","regPP","lunchPre","lunchPP","dinnerPre","dinnerPP"] as const).map((k) => {
                      const v = r.measurements[k];
                      return <td key={k} className={v !== undefined && v < 3.9 ? "text-destructive" : v !== undefined && v > 10 ? "text-amber-600" : ""}>{v ?? "—"}</td>;
                    })}
                    <td>{((r.bolus_r ?? 0) + (r.bolus_d ?? 0) + (r.bolus_e ?? 0)) || "—"}</td>
                    <td>{r.basal ?? "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}

// ============== PROTOCOLS TAB ==============

function ProtocolsTab() {
  const [open, setOpen] = useState<string>("hypo");
  const items = [
    { id: "hypo", title: "🍬 Hypoglikémia (15-15 szabály)", body: HYPO_PROTOCOL },
    { id: "red", title: "🚩 Red Flagek — sürgős átirányítás", body: RED_FLAGS },
    { id: "dka", title: "💧 DKA — Ketoacidózis ellátás", body: DKA_PROTOCOL },
    { id: "hhs", title: "🧂 HHS — Hyperozmoláris állapot", body: HHS_PROTOCOL },
    { id: "preg", title: "🤰 Gesztációs DM — protokoll", body: PREG_PROTOCOL },
  ];

  return (
    <div className="space-y-2 mt-4">
      {items.map((it) => (
        <div key={it.id} className="rounded-xl border border-border bg-card overflow-hidden">
          <button onClick={() => setOpen((o) => o === it.id ? "" : it.id)}
            className={`w-full px-4 py-3 text-left text-sm font-semibold flex items-center justify-between ${open === it.id ? "bg-primary/5" : "hover:bg-accent/40"}`}>
            {it.title}
            <span className="text-xs text-muted-foreground">{open === it.id ? "▼" : "▶"}</span>
          </button>
          {open === it.id && <div className="px-4 py-3 border-t border-border text-sm whitespace-pre-wrap leading-relaxed">{it.body}</div>}
        </div>
      ))}
    </div>
  );
}

const HYPO_PROTOCOL = `1. ENYHE (VC 3.0–3.8 mmol/L, beteg eszméleten):
   • 15 g gyors CH (3–4 db kockacukor, 1,5 dl gyümölcslé, 1 dl Coca-Cola)
   • 15 perc múlva újra VC mérés
   • Ha még < 3.9 → újabb 15 g CH, ismétlés
   • Ha helyreállt → komplex CH (kenyér, keksz) a következő étkezésig

2. SÚLYOS (VC < 3.0 vagy eszméletlen):
   • i.v. 40% glükóz 40–60 ml bólusban
   • Vagy glukagon 1 mg i.m./s.c. (ha nincs vénás bemenet)
   • Eszmélet visszatérése után 15 g CH p.o.
   • Mentő hívása, kórházi obszerváció szükséges

3. KRITIKUS — bólusz előtt VC < 3.9:
   • Bólusz NEM adható le
   • Étkezés halasztása, korrekciós CH
   • 30 perc múlva újra VC, esetén csökkentett bólusz`;

const RED_FLAGS = `Azonnali kórházi átirányítás javasolt, ha:

🚩 VC > 22 mmol/L vagy < 2.5 mmol/L
🚩 Pozitív vér- vagy vizelet-keton + magas VC → DKA gyanú
🚩 Sepsis jelei (qSOFA ≥ 2, láz, hypotensio)
🚩 Eszméletzavar, görcs
🚩 Súlyos dehydratáció + magas VC + ozmolaritás > 320 mOsm/kg → HHS gyanú
🚩 Frissen diagnosztizált T1DM gyanú (fogyás, polyuria, ketonuria)`;

const DKA_PROTOCOL = `DIAGNÓZIS:
  pH < 7.30, HCO₃⁻ < 18, anion gap > 10, VC > 14, keton+

1. FOLYADÉK (első 1 óra):
   0.9% NaCl 15–20 ml/kg/h (1–1,5 L) → korrigál hipovolémia

2. KÁLIUM:
   • K+ < 3.3 → kálium pótlás MIELŐTT inzulin
   • K+ 3.3–5.3 → 20–30 mmol K+/L oldatban
   • K+ > 5.3 → várni, monitorozni

3. INZULIN:
   • Regular inzulin 0.1 NE/kg i.v. bólus, majd 0.1 NE/kg/h infúzió
   • VC csökkenése 3–4 mmol/L/h legyen — túl gyors NEM jó
   • VC < 14 → infúzióhoz 5% glükóz, inzulin fenntartása

4. MONITOR:
   • VC, K+, vérgáz óránként az első 4–6 óra
   • Anion gap zárul → metabolikus rendezés OK

5. ÁTÁLLÁS:
   • pH > 7.3, HCO₃ > 18, AG normalizált
   • S.c. inzulin elindítása, i.v. infúzió folytatása még 1–2 óra (átfedés)`;

const HHS_PROTOCOL = `DIAGNÓZIS:
  VC > 33 mmol/L, ozmolaritás > 320 mOsm/kg, kis vagy nincs ketonuria, pH > 7.30

1. FOLYADÉK (lassúbb mint DKA):
   0.9% NaCl 1 L első órában
   Majd 0.45% NaCl 250–500 ml/h Na-szint alapján
   Cél: 50% deficit első 12 órában

2. KÁLIUM:
   K+ < 3.3 → 40 mmol/h
   K+ 3.3–5.3 → 20–30 mmol/L
   K+ > 5.3 → várj

3. INZULIN:
   • CSAK miután folyadékot kezdtél (különben sokk)
   • 0.05–0.1 NE/kg/h i.v. infúzió
   • VC csökkenése MAX 5 mmol/L/h (gyors → agyödéma!)

4. MONITOR:
   • VC, Na+, K+, ozmolaritás 2 óránként
   • Mentális állapot, vizeletürítés`;

const PREG_PROTOCOL = `GESZTÁCIÓS DM:

CÉLOK:
  • Éhomi: < 5.3 mmol/L
  • 1 órás postprandiális: < 7.8 mmol/L
  • 2 órás postprandiális: < 6.7 mmol/L
  • HbA1c: < 6.0% (ideálisan < 5.5%)

INZULIN-SÉMA:
  • Csak humán inzulin / aspart / lispro / detemir adható
  • Glargine U100 elfogadott, U300 (Toujeo) NEM
  • Degludec (Tresiba) NEM ajánlott
  • Kezdő dózis: súly × 0.7 NE/kg (2. trim) / × 1.0 NE/kg (3. trim)

SÜRGŐSSÉG:
  • DKA terhességben → fenyegetett magzati halál — azonnali kórház
  • Hypo súlyosabb mint nem-terhesnél — 15-15 szigorúan

POSZTPARTUM:
  • Inzulin igény hirtelen csökken (50–75%)
  • 6 héttel szülés után OGTT — perzisztáló DM kizárására
  • Szoptatás bátorítva — javítja a glükóztoleranciát

KERÜLENDŐ GYÓGYSZEREK:
  • Minden orális antidiabetikum (SGLT2, GLP1, DPP4, SU) → ellenjavallt
  • Metformin: kontrolverz, eset-specifikus mérlegelés`;

// ============== SMALL COMPONENTS ==============

function Num({ label, value, onChange, step }: { label: string; value: number; onChange: (v: number) => void; step: number }) {
  return (
    <label className="block">
      <span className="text-xs text-muted-foreground">{label}</span>
      <input type="number" step={step} value={value} onChange={(e) => onChange(Number(e.target.value))}
        className="mt-1 w-full px-2 py-1.5 text-sm rounded-md border border-border bg-background font-mono" />
    </label>
  );
}
function Sel({ label, value, onChange, options }: { label: string; value: string; onChange: (v: string) => void; options: Array<[string, string]> }) {
  return (
    <label className="block">
      <span className="text-xs text-muted-foreground">{label}</span>
      <select value={value} onChange={(e) => onChange(e.target.value)}
        className="mt-1 w-full px-2 py-1.5 text-sm rounded-md border border-border bg-background">
        {options.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
      </select>
    </label>
  );
}
function Chk({ label, value, onChange }: { label: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <label className="flex items-center gap-2 text-xs">
      <input type="checkbox" checked={value} onChange={(e) => onChange(e.target.checked)} />
      {label}
    </label>
  );
}
function Metric({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <div className="rounded-md border border-border bg-background p-2">
      <div className="text-[10px] uppercase font-mono text-muted-foreground">{label}</div>
      <div className="font-mono font-semibold text-sm">{value}</div>
      {hint && <div className="text-[10px] text-muted-foreground">{hint}</div>}
    </div>
  );
}
