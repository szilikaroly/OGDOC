import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import {
  Stethoscope, ArrowLeft, Loader2, Save, Plus, X, FileSignature, Activity,
  ClipboardList, Microscope, Pill, BadgeCheck, FileText, LineChart, Sparkles, Baby,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { useServerFn } from "@tanstack/react-start";
import { generateAiClinicalNote } from "@/lib/clinical/ai-notes.functions";
import { toast } from "sonner";
import { LOINC, VITAL_KEYS, COMMON_LAB_KEYS, type LoincKey, formatRef, interpretValue } from "@/lib/clinical/fhir-codes";
import { AnomalyTrendChart } from "@/components/clinical/anomaly-trend-chart";
import { StatusBadge } from "@/components/ui/status-badge";
import { VoiceRecorderButton } from "@/components/clinical/voice-recorder-button";

export const Route = createFileRoute("/_authenticated/klinika/beteg/$patientId")({
  validateSearch: (s: Record<string, unknown>): { encounterId?: string; tab?: string } => ({
    encounterId: typeof s.encounterId === "string" ? s.encounterId : undefined,
    tab: typeof s.tab === "string" ? s.tab : undefined,
  }),
  component: BetegKarton,
});

type Patient = {
  id: string;
  taj: string | null;
  vezeteknev: string;
  keresztnev: string;
  szuletesi_datum: string | null;
  nem: string | null;
  fo_diagnozis_bno: string | null;
};
type Encounter = {
  id: string;
  encounter_type: string;
  status: string;
  start_ts: string;
  end_ts: string | null;
  chief_complaint: string | null;
};

const TABS = [
  { id: "overview", label: "Áttekintés", Icon: ClipboardList },
  { id: "vitals", label: "Mérések", Icon: Activity },
  { id: "labs", label: "Labor", Icon: Microscope },
  { id: "notes", label: "Jegyzetek", Icon: FileText },
  { id: "ai", label: "AI dokumentáció", Icon: Sparkles },
  { id: "diagnoses", label: "Diagnózis", Icon: BadgeCheck },
  { id: "therapy", label: "Terápia", Icon: Pill },
  { id: "lazlap", label: "Lázlap", Icon: LineChart },
];

function BetegKarton() {
  const { user } = useAuth();
  const { patientId } = Route.useParams();
  const { encounterId, tab } = Route.useSearch();
  const navigate = useNavigate();

  const [patient, setPatient] = useState<Patient | null>(null);
  const [encounter, setEncounter] = useState<Encounter | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState(tab ?? "overview");

  useEffect(() => {
    if (!user) return;
    void (async () => {
      setLoading(true);
      const [{ data: p }, { data: e }] = await Promise.all([
        supabase.from("patients").select("*").eq("id", patientId).maybeSingle(),
        encounterId
          ? supabase.from("clinical_encounters").select("*").eq("id", encounterId).maybeSingle()
          : Promise.resolve({ data: null }),
      ]);
      setPatient(p as Patient | null);
      setEncounter(e as Encounter | null);
      setLoading(false);
    })();
  }, [user, patientId, encounterId]);

  async function closeEncounter() {
    if (!encounter || !user) return;
    const { error } = await supabase
      .from("clinical_encounters")
      .update({ status: "finished", end_ts: new Date().toISOString(), closed_by: user.id })
      .eq("id", encounter.id);
    if (error) toast.error(error.message); else {
      toast.success("Epizód lezárva");
      navigate({ to: "/klinika" });
    }
  }

  if (loading) return <div className="container py-8 flex items-center gap-2 text-sm"><Loader2 className="h-4 w-4 animate-spin" /> Betöltés…</div>;
  if (!patient) return <div className="container py-8">Beteg nem található.</div>;

  return (
    <div className="container max-w-7xl py-6 space-y-4">
      <header className="rounded-xl border border-border bg-card p-4">
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div>
            <Link to="/klinika" className="text-xs text-muted-foreground hover:underline flex items-center gap-1">
              <ArrowLeft className="h-3 w-3" /> Klinika
            </Link>
            <h1 className="text-2xl font-semibold mt-1 flex items-center gap-2">
              <Stethoscope className="h-6 w-6 text-primary" />
              {patient.vezeteknev} {patient.keresztnev}
            </h1>
            <p className="text-sm text-muted-foreground">
              TAJ: {patient.taj ?? "—"} · Szül.: {patient.szuletesi_datum ?? "—"} · {patient.nem ?? "—"}
            </p>
          </div>
          {encounter && (
            <div className="text-right">
              <div className="text-xs text-muted-foreground">Aktív epizód</div>
              <div className="font-mono text-xs">{encounter.encounter_type} · {new Date(encounter.start_ts).toLocaleString("hu-HU")}</div>
              {encounter.status === "in-progress" && (
                <button onClick={closeEncounter} className="mt-2 text-xs px-3 py-1 rounded-md border border-border hover:bg-accent">
                  Epizód lezárása
                </button>
              )}
            </div>
          )}
        </div>
      </header>

      {encounter ? (
        <>
          <nav className="flex gap-1 border-b border-border overflow-x-auto">
            {TABS.map(({ id, label, Icon }) => (
              <button
                key={id}
                onClick={() => {
                  setActiveTab(id);
                  navigate({ to: ".", params: { patientId }, search: { encounterId, tab: id } });
                }}
                className={`flex items-center gap-1.5 px-3 py-2 text-sm border-b-2 -mb-px transition-colors ${
                  activeTab === id
                    ? "border-primary text-primary font-semibold"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                }`}
              >
                <Icon className="h-4 w-4" /> {label}
              </button>
            ))}
            <Link
              to="/klinika/partogram/$encounterId"
              params={{ encounterId: encounter.id }}
              className="ml-auto inline-flex items-center gap-1.5 px-3 py-2 text-xs text-primary hover:underline"
            >
              <Baby className="h-3.5 w-3.5" /> Partogram
            </Link>
            <Link
              to="/klinika/lazlap/$encounterId"
              params={{ encounterId: encounter.id }}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs text-primary hover:underline"
            >
              <LineChart className="h-3.5 w-3.5" /> Lázlap →
            </Link>
          </nav>

          <div className="pt-2">
            {activeTab === "overview" && <OverviewTab encounterId={encounter.id} patientId={patient.id} />}
            {activeTab === "vitals" && <VitalsTab encounterId={encounter.id} patientId={patient.id} userId={user!.id} />}
            {activeTab === "labs" && <LabsTab encounterId={encounter.id} patientId={patient.id} userId={user!.id} />}
            {activeTab === "notes" && <NotesTab encounterId={encounter.id} patientId={patient.id} userId={user!.id} />}
            {activeTab === "ai" && <AiNotesTab encounterId={encounter.id} patientId={patient.id} userId={user!.id} />}
            {activeTab === "diagnoses" && <DiagnosesTab encounterId={encounter.id} patientId={patient.id} userId={user!.id} />}
            {activeTab === "therapy" && <TherapyTab encounterId={encounter.id} patientId={patient.id} userId={user!.id} />}
            {activeTab === "lazlap" && <LazlapPreview encounterId={encounter.id} />}
          </div>
        </>
      ) : (
        <div className="rounded-xl border border-border bg-card p-8 text-center">
          <p className="text-sm text-muted-foreground">Nincs aktív ellátási epizód.</p>
          <Link to="/klinika" className="inline-block mt-4 text-sm text-primary hover:underline">
            Vissza a beteglistához
          </Link>
        </div>
      )}
    </div>
  );
}

// ---------- OVERVIEW ----------

function OverviewTab({ encounterId, patientId }: { encounterId: string; patientId: string }) {
  const [counts, setCounts] = useState({ obs: 0, notes: 0, dx: 0, tx: 0 });
  const [lastVitals, setLastVitals] = useState<Array<{ loinc_code: string | null; code_display: string; value_quantity: number | null; value_unit: string | null; effective_ts: string }>>([]);

  useEffect(() => {
    void (async () => {
      const [obs, notes, dx, tx, vitals] = await Promise.all([
        supabase.from("clinical_observations").select("*", { count: "exact", head: true }).eq("encounter_id", encounterId),
        supabase.from("clinical_notes").select("*", { count: "exact", head: true }).eq("encounter_id", encounterId),
        supabase.from("clinical_diagnoses").select("*", { count: "exact", head: true }).eq("encounter_id", encounterId),
        supabase.from("clinical_therapy_orders").select("*", { count: "exact", head: true }).eq("encounter_id", encounterId),
        supabase
          .from("clinical_observations")
          .select("loinc_code, code_display, value_quantity, value_unit, effective_ts")
          .eq("patient_id", patientId)
          .eq("category", "vital-signs")
          .order("effective_ts", { ascending: false })
          .limit(7),
      ]);
      setCounts({ obs: obs.count ?? 0, notes: notes.count ?? 0, dx: dx.count ?? 0, tx: tx.count ?? 0 });
      setLastVitals((vitals.data ?? []) as any);
    })();
  }, [encounterId, patientId]);

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
      <Stat label="Mérések" value={counts.obs} />
      <Stat label="Jegyzetek" value={counts.notes} />
      <Stat label="Diagnózisok" value={counts.dx} />
      <Stat label="Terápia rendelvény" value={counts.tx} />
      <div className="md:col-span-4 rounded-xl border border-border bg-card p-4">
        <h3 className="text-sm font-semibold mb-3">Utolsó vitálisok</h3>
        {lastVitals.length === 0 ? (
          <p className="text-sm text-muted-foreground">Még nincs rögzített vitális.</p>
        ) : (
          <ul className="space-y-1 text-sm font-mono">
            {lastVitals.map((v, i) => (
              <li key={i} className="flex items-center justify-between">
                <span>{v.code_display}</span>
                <span>{v.value_quantity} {v.value_unit} <span className="text-xs text-muted-foreground ml-2">{new Date(v.effective_ts).toLocaleString("hu-HU")}</span></span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: number | string }) {
  return (
    <div className="rounded-xl border border-border bg-card p-4">
      <div className="text-[10px] uppercase tracking-wider font-mono text-muted-foreground">{label}</div>
      <div className="text-2xl font-semibold mt-1">{value}</div>
    </div>
  );
}

// ---------- VITALS ----------

function VitalsTab({ encounterId, patientId, userId }: { encounterId: string; patientId: string; userId: string }) {
  const [values, setValues] = useState<Partial<Record<LoincKey, number>>>({});
  const [saving, setSaving] = useState(false);
  const [recent, setRecent] = useState<any[]>([]);
  const [history, setHistory] = useState<any[]>([]);

  async function refresh() {
    const sinceHistory = new Date(Date.now() - 90 * 24 * 3600_000).toISOString();
    const [{ data: recentData }, { data: histData }] = await Promise.all([
      supabase
        .from("clinical_observations")
        .select("*")
        .eq("encounter_id", encounterId)
        .eq("category", "vital-signs")
        .order("effective_ts", { ascending: false })
        .limit(20),
      supabase
        .from("clinical_observations")
        .select("loinc_code, code_display, value_quantity, value_unit, effective_ts")
        .eq("patient_id", patientId)
        .eq("category", "vital-signs")
        .gte("effective_ts", sinceHistory)
        .order("effective_ts", { ascending: true })
        .limit(500),
    ]);
    setRecent(recentData ?? []);
    setHistory(histData ?? []);
  }
  useEffect(() => { void refresh(); }, [encounterId, patientId]);

  // 90 napos sorozatok LOINC szerint, anomália-detektorhoz
  const trendByLoinc = useMemo(() => {
    const out: Record<string, { label: string; unit: string; series: { ts: string; value: number }[] }> = {};
    for (const r of history) {
      if (typeof r.value_quantity !== "number" || !r.loinc_code) continue;
      const key = r.loinc_code as string;
      out[key] ??= { label: r.code_display ?? key, unit: r.value_unit ?? "", series: [] };
      out[key].series.push({ ts: r.effective_ts, value: r.value_quantity });
    }
    return out;
  }, [history]);

  async function save() {
    const entries = Object.entries(values).filter(([, v]) => v !== undefined && Number.isFinite(v));
    if (entries.length === 0) return;
    setSaving(true);
    const ts = new Date().toISOString();
    const rows = entries.map(([k, v]) => {
      const meta = LOINC[k as LoincKey];
      return {
        encounter_id: encounterId,
        patient_id: patientId,
        category: meta.category,
        loinc_code: meta.loinc,
        code_display: meta.hu,
        value_quantity: v,
        value_unit: meta.unit,
        interpretation: interpretValue(k as LoincKey, v as number),
        effective_ts: ts,
        performer_id: userId,
        source: "manual",
      };
    });
    const { error } = await supabase.from("clinical_observations").insert(rows);
    setSaving(false);
    if (error) toast.error(error.message);
    else {
      toast.success(`${rows.length} mérés rögzítve`);
      setValues({});
      void refresh();
    }
  }

  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-border bg-card p-4">
        <h3 className="text-sm font-semibold mb-3">Gyors-rögzítés</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {VITAL_KEYS.map((k) => (
            <label key={k} className="block">
              <span className="text-xs text-muted-foreground flex items-center justify-between">
                <span>{LOINC[k].hu}</span>
                <span className="text-[10px] opacity-70">{formatRef(k)}</span>
              </span>
              <div className="mt-1 flex items-center gap-1">
                <input
                  type="number"
                  step={LOINC[k].step}
                  min={LOINC[k].min}
                  max={LOINC[k].max}
                  value={values[k] ?? ""}
                  onChange={(e) => setValues({ ...values, [k]: e.target.value === "" ? undefined : Number(e.target.value) })}
                  className="w-full px-2 py-1.5 text-sm rounded-md border border-border bg-background font-mono"
                />
                <span className="text-xs text-muted-foreground w-12">{LOINC[k].unit}</span>
              </div>
            </label>
          ))}
        </div>
        <div className="mt-4 flex items-center gap-2">
          <button
            onClick={save}
            disabled={saving || Object.keys(values).length === 0}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-md bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
          >
            {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />} Rögzítés
          </button>
          {Object.keys(values).length > 0 && (
            <button onClick={() => setValues({})} className="text-xs text-muted-foreground hover:underline">
              törlés
            </button>
          )}
        </div>
      </div>

      <div className="rounded-xl border border-border bg-card">
        <div className="px-4 py-3 border-b border-border text-sm font-semibold">Korábbi mérések (az epizódban)</div>
        {recent.length === 0 ? (
          <p className="p-4 text-sm text-muted-foreground">Még nincs.</p>
        ) : (
          <div className="overflow-auto max-h-96">
            <table className="w-full text-sm">
              <thead className="bg-muted/40 text-xs">
                <tr><th className="px-3 py-2 text-left">Idő</th><th className="px-3 py-2 text-left">Paraméter</th><th className="px-3 py-2 text-left">Érték</th><th className="px-3 py-2 text-left">Értékelés</th></tr>
              </thead>
              <tbody>
                {recent.map((r) => (
                  <tr key={r.id} className="border-t border-border">
                    <td className="px-3 py-2 font-mono text-xs">{new Date(r.effective_ts).toLocaleString("hu-HU")}</td>
                    <td className="px-3 py-2">{r.code_display}</td>
                    <td className="px-3 py-2 font-mono">{r.value_quantity} {r.value_unit}</td>
                    <td className="px-3 py-2">
                      <InterpBadge value={r.interpretation} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {Object.keys(trendByLoinc).length > 0 && (
        <div className="rounded-xl border border-border bg-card">
          <div className="px-4 py-3 border-b border-border text-sm font-semibold flex items-center gap-2">
            <LineChart className="h-4 w-4" /> 90 napos trendek (anomália-jelöléssel)
          </div>
          <div className="p-4 grid gap-6 md:grid-cols-2">
            {Object.entries(trendByLoinc)
              .filter(([, v]) => v.series.length >= 3)
              .map(([loinc, v]) => (
                <AnomalyTrendChart
                  key={loinc}
                  series={v.series}
                  label={v.label}
                  unit={v.unit}
                  height={180}
                />
              ))}
          </div>
        </div>
      )}
    </div>
  );
}

function InterpBadge({ value }: { value: string | null }) {
  if (!value || value === "normal") return <StatusBadge tone="ok">normál</StatusBadge>;
  const tone: "bad" | "warn" | "neutral" =
    value === "critical-low" || value === "critical-high" ? "bad" :
    value === "low" || value === "high" ? "warn" : "neutral";
  const label =
    value === "low" ? "alacsony" :
    value === "high" ? "magas" :
    value === "critical-low" ? "krit. alacsony" :
    value === "critical-high" ? "krit. magas" : value;
  return <StatusBadge tone={tone}>{label}</StatusBadge>;
}

// ---------- LABS ----------

function LabsTab({ encounterId, patientId, userId }: { encounterId: string; patientId: string; userId: string }) {
  const [values, setValues] = useState<Partial<Record<LoincKey, number>>>({});
  const [recent, setRecent] = useState<any[]>([]);

  async function refresh() {
    const { data } = await supabase
      .from("clinical_observations").select("*")
      .eq("encounter_id", encounterId).eq("category", "laboratory")
      .order("effective_ts", { ascending: false }).limit(50);
    setRecent(data ?? []);
  }
  useEffect(() => { void refresh(); }, [encounterId]);

  async function save() {
    const entries = Object.entries(values).filter(([, v]) => v !== undefined && Number.isFinite(v));
    if (entries.length === 0) return;
    const ts = new Date().toISOString();
    const rows = entries.map(([k, v]) => {
      const meta = LOINC[k as LoincKey];
      return {
        encounter_id: encounterId, patient_id: patientId,
        category: meta.category, loinc_code: meta.loinc, code_display: meta.hu,
        value_quantity: v, value_unit: meta.unit,
        interpretation: interpretValue(k as LoincKey, v as number),
        effective_ts: ts, performer_id: userId, source: "manual",
      };
    });
    const { error } = await supabase.from("clinical_observations").insert(rows);
    if (error) toast.error(error.message);
    else { toast.success(`${rows.length} laborérték rögzítve`); setValues({}); void refresh(); }
  }

  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-border bg-card p-4">
        <h3 className="text-sm font-semibold mb-3">Laborértékek rögzítése</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {COMMON_LAB_KEYS.map((k) => (
            <label key={k} className="block">
              <span className="text-xs text-muted-foreground flex items-center justify-between">
                <span>{LOINC[k].hu}</span><span className="text-[10px] opacity-70">{formatRef(k)}</span>
              </span>
              <div className="mt-1 flex items-center gap-1">
                <input type="number" step={LOINC[k].step}
                  value={values[k] ?? ""}
                  onChange={(e) => setValues({ ...values, [k]: e.target.value === "" ? undefined : Number(e.target.value) })}
                  className="w-full px-2 py-1.5 text-sm rounded-md border border-border bg-background font-mono" />
                <span className="text-xs text-muted-foreground w-14">{LOINC[k].unit}</span>
              </div>
            </label>
          ))}
        </div>
        <button onClick={save} disabled={Object.keys(values).length === 0}
          className="mt-4 inline-flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-md bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50">
          <Save className="h-3.5 w-3.5" /> Rögzítés
        </button>
      </div>

      <div className="rounded-xl border border-border bg-card">
        <div className="px-4 py-3 border-b border-border text-sm font-semibold">Korábbi labor</div>
        {recent.length === 0 ? <p className="p-4 text-sm text-muted-foreground">Még nincs.</p> : (
          <div className="overflow-auto max-h-96">
            <table className="w-full text-sm">
              <thead className="bg-muted/40 text-xs"><tr>
                <th className="px-3 py-2 text-left">Idő</th><th className="px-3 py-2 text-left">Paraméter</th>
                <th className="px-3 py-2 text-left">Érték</th><th className="px-3 py-2 text-left">LOINC</th>
                <th className="px-3 py-2 text-left">Értékelés</th>
              </tr></thead>
              <tbody>
                {recent.map((r) => (
                  <tr key={r.id} className="border-t border-border">
                    <td className="px-3 py-2 font-mono text-xs">{new Date(r.effective_ts).toLocaleString("hu-HU")}</td>
                    <td className="px-3 py-2">{r.code_display}</td>
                    <td className="px-3 py-2 font-mono">{r.value_quantity} {r.value_unit}</td>
                    <td className="px-3 py-2 font-mono text-xs text-muted-foreground">{r.loinc_code ?? "—"}</td>
                    <td className="px-3 py-2"><InterpBadge value={r.interpretation} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

// ---------- NOTES ----------

const NOTE_KINDS = [
  { value: "anamnesis", label: "Anamnézis" },
  { value: "complaint", label: "Panasz / HPI" },
  { value: "status", label: "Státusz" },
  { value: "ultrasound", label: "Ultrahang" },
  { value: "imaging", label: "Képalkotás" },
  { value: "progress", label: "Folyamat (progress note)" },
  { value: "epicrisis", label: "Epikrízis" },
  { value: "recommendation", label: "Javaslat" },
  { value: "lifestyle", label: "Életmód" },
  { value: "diet", label: "Diéta" },
  { value: "results_summary", label: "Lelet-összefoglaló" },
];

function NotesTab({ encounterId, patientId, userId }: { encounterId: string; patientId: string; userId: string }) {
  const [notes, setNotes] = useState<any[]>([]);
  const [kind, setKind] = useState("status");
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [saving, setSaving] = useState(false);

  async function refresh() {
    const { data } = await supabase.from("clinical_notes").select("*").eq("encounter_id", encounterId).order("created_at", { ascending: false });
    setNotes(data ?? []);
  }
  useEffect(() => { void refresh(); }, [encounterId]);

  async function save() {
    if (!body.trim()) return;
    setSaving(true);
    const { error } = await supabase.from("clinical_notes").insert({
      encounter_id: encounterId, patient_id: patientId, author_id: userId,
      kind, title: title || null, body_md: body,
    });
    setSaving(false);
    if (error) toast.error(error.message);
    else { toast.success("Jegyzet mentve"); setBody(""); setTitle(""); void refresh(); }
  }

  async function sign(id: string) {
    const { error } = await supabase.from("clinical_notes").update({ signed_at: new Date().toISOString(), signed_by: userId }).eq("id", id);
    if (error) toast.error(error.message);
    else { toast.success("Aláírva"); void refresh(); }
  }

  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-border bg-card p-4 space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <label className="block">
            <span className="text-xs text-muted-foreground">Típus</span>
            <select value={kind} onChange={(e) => setKind(e.target.value)} className="mt-1 w-full px-2 py-1.5 text-sm rounded-md border border-border bg-background">
              {NOTE_KINDS.map((k) => <option key={k.value} value={k.value}>{k.label}</option>)}
            </select>
          </label>
          <label className="block md:col-span-2">
            <span className="text-xs text-muted-foreground">Cím (opcionális)</span>
            <input value={title} onChange={(e) => setTitle(e.target.value)}
              className="mt-1 w-full px-2 py-1.5 text-sm rounded-md border border-border bg-background" />
          </label>
        </div>
        <label className="block">
          <span className="text-xs text-muted-foreground flex items-center justify-between gap-2">
            <span>Tartalom (Markdown)</span>
            <VoiceRecorderButton
              className="!min-h-9 !min-w-9 !p-1.5"
              title="Hang-alapú diktálás — a szöveg a mezőhöz fűződik"
              onResult={(txt) => setBody((b) => (b ? `${b} ${txt}` : txt))}
            />
          </span>
          <textarea value={body} onChange={(e) => setBody(e.target.value)} rows={6}
            className="mt-1 w-full px-3 py-2 text-sm rounded-md border border-border bg-background font-mono" />
        </label>
        <button onClick={save} disabled={saving || !body.trim()}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-md bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50">
          {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />} Mentés
        </button>
      </div>

      {notes.map((n) => (
        <div key={n.id} className="rounded-xl border border-border bg-card p-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="text-xs uppercase font-mono text-muted-foreground">
                {NOTE_KINDS.find((k) => k.value === n.kind)?.label ?? n.kind} · {new Date(n.created_at).toLocaleString("hu-HU")}
              </div>
              {n.title && <div className="font-semibold mt-1">{n.title}</div>}
            </div>
            {n.signed_at ? (
              <StatusBadge tone="ok" pill size="sm" icon={<FileSignature className="h-3 w-3" />}>
                aláírva
              </StatusBadge>
            ) : (
              <button onClick={() => sign(n.id)} className="text-xs px-2 py-1 rounded-md border border-border hover:bg-accent">Aláírás</button>
            )}
          </div>
          <p className="mt-2 text-sm whitespace-pre-wrap">{n.body_md}</p>
        </div>
      ))}
    </div>
  );
}

// ---------- DIAGNOSES ----------

function DiagnosesTab({ encounterId, patientId, userId }: { encounterId: string; patientId: string; userId: string }) {
  const [rows, setRows] = useState<any[]>([]);
  const [icd, setIcd] = useState("");
  const [display, setDisplay] = useState("");
  const [certainty, setCertainty] = useState("confirmed");
  const [isPrimary, setIsPrimary] = useState(false);

  async function refresh() {
    const { data } = await supabase.from("clinical_diagnoses").select("*").eq("encounter_id", encounterId).order("is_primary", { ascending: false });
    setRows(data ?? []);
  }
  useEffect(() => { void refresh(); }, [encounterId]);

  async function add() {
    if (!display.trim()) return;
    const { error } = await supabase.from("clinical_diagnoses").insert({
      encounter_id: encounterId, patient_id: patientId, created_by: userId,
      icd10_code: icd || null, display, certainty, is_primary: isPrimary,
    });
    if (error) toast.error(error.message);
    else { setIcd(""); setDisplay(""); setIsPrimary(false); void refresh(); }
  }

  async function remove(id: string) {
    const { error } = await supabase.from("clinical_diagnoses").delete().eq("id", id);
    if (error) toast.error(error.message); else void refresh();
  }

  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-border bg-card p-4">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-2 items-end">
          <label className="block md:col-span-2">
            <span className="text-xs text-muted-foreground">BNO-10 / ICD-10</span>
            <input value={icd} onChange={(e) => setIcd(e.target.value.toUpperCase())} placeholder="pl. I10"
              className="mt-1 w-full px-2 py-1.5 text-sm rounded-md border border-border bg-background font-mono" />
          </label>
          <label className="block md:col-span-5">
            <span className="text-xs text-muted-foreground">Megnevezés</span>
            <input value={display} onChange={(e) => setDisplay(e.target.value)}
              className="mt-1 w-full px-2 py-1.5 text-sm rounded-md border border-border bg-background" />
          </label>
          <label className="block md:col-span-2">
            <span className="text-xs text-muted-foreground">Bizonyosság</span>
            <select value={certainty} onChange={(e) => setCertainty(e.target.value)}
              className="mt-1 w-full px-2 py-1.5 text-sm rounded-md border border-border bg-background">
              <option value="suspected">Gyanú</option>
              <option value="confirmed">Megerősített</option>
              <option value="differential">Differenciál</option>
              <option value="ruled-out">Kizárva</option>
            </select>
          </label>
          <label className="flex items-center gap-2 md:col-span-2 text-sm pb-1.5">
            <input type="checkbox" checked={isPrimary} onChange={(e) => setIsPrimary(e.target.checked)} />
            Primer
          </label>
          <button onClick={add} disabled={!display.trim()}
            className="md:col-span-1 inline-flex items-center justify-center gap-1 px-3 py-1.5 text-sm rounded-md bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50">
            <Plus className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {rows.length === 0 ? (
        <p className="text-sm text-muted-foreground p-4">Nincs rögzített diagnózis.</p>
      ) : (
        <div className="rounded-xl border border-border bg-card overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted/40 text-xs"><tr>
              <th className="px-3 py-2 text-left w-20">BNO</th>
              <th className="px-3 py-2 text-left">Diagnózis</th>
              <th className="px-3 py-2 text-left w-32">Bizonyosság</th>
              <th className="px-3 py-2 text-left w-20">Primer</th>
              <th className="px-3 py-2 w-10"></th>
            </tr></thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.id} className="border-t border-border">
                  <td className="px-3 py-2 font-mono">{r.icd10_code ?? "—"}</td>
                  <td className="px-3 py-2">{r.display}</td>
                  <td className="px-3 py-2 text-xs">{r.certainty}</td>
                  <td className="px-3 py-2">{r.is_primary && <BadgeCheck className="h-4 w-4 text-primary" />}</td>
                  <td className="px-3 py-2"><button onClick={() => remove(r.id)} className="text-muted-foreground hover:text-red-600"><X className="h-4 w-4" /></button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ---------- THERAPY ----------

function TherapyTab({ encounterId, patientId, userId }: { encounterId: string; patientId: string; userId: string }) {
  const [rows, setRows] = useState<any[]>([]);
  const [kind, setKind] = useState("medication");
  const [display, setDisplay] = useState("");
  const [dose, setDose] = useState("");
  const [freq, setFreq] = useState("");
  const [dur, setDur] = useState("");

  async function refresh() {
    const { data } = await supabase.from("clinical_therapy_orders").select("*").eq("encounter_id", encounterId).order("created_at", { ascending: false });
    setRows(data ?? []);
  }
  useEffect(() => { void refresh(); }, [encounterId]);

  async function add() {
    if (!display.trim()) return;
    const { error } = await supabase.from("clinical_therapy_orders").insert({
      encounter_id: encounterId, patient_id: patientId, created_by: userId,
      kind, display, dose: dose || null, frequency: freq || null, duration: dur || null,
    });
    if (error) toast.error(error.message);
    else { setDisplay(""); setDose(""); setFreq(""); setDur(""); void refresh(); }
  }

  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-border bg-card p-4">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-2 items-end">
          <label className="block md:col-span-2">
            <span className="text-xs text-muted-foreground">Típus</span>
            <select value={kind} onChange={(e) => setKind(e.target.value)} className="mt-1 w-full px-2 py-1.5 text-sm rounded-md border border-border bg-background">
              <option value="medication">Gyógyszer</option>
              <option value="procedure">Beavatkozás</option>
              <option value="lifestyle">Életmód</option>
              <option value="diet">Diéta</option>
              <option value="lab-request">Laborkérés</option>
              <option value="imaging">Képalkotás</option>
              <option value="referral">Beutaló</option>
            </select>
          </label>
          <label className="block md:col-span-4">
            <span className="text-xs text-muted-foreground">Megnevezés</span>
            <input value={display} onChange={(e) => setDisplay(e.target.value)}
              className="mt-1 w-full px-2 py-1.5 text-sm rounded-md border border-border bg-background" />
          </label>
          <label className="block md:col-span-2">
            <span className="text-xs text-muted-foreground">Dózis</span>
            <input value={dose} onChange={(e) => setDose(e.target.value)} placeholder="pl. 5 mg"
              className="mt-1 w-full px-2 py-1.5 text-sm rounded-md border border-border bg-background" />
          </label>
          <label className="block md:col-span-2">
            <span className="text-xs text-muted-foreground">Gyakoriság</span>
            <input value={freq} onChange={(e) => setFreq(e.target.value)} placeholder="pl. 1×1"
              className="mt-1 w-full px-2 py-1.5 text-sm rounded-md border border-border bg-background" />
          </label>
          <label className="block md:col-span-1">
            <span className="text-xs text-muted-foreground">Időtartam</span>
            <input value={dur} onChange={(e) => setDur(e.target.value)} placeholder="pl. 7 nap"
              className="mt-1 w-full px-2 py-1.5 text-sm rounded-md border border-border bg-background" />
          </label>
          <button onClick={add} disabled={!display.trim()}
            className="md:col-span-1 inline-flex items-center justify-center gap-1 px-3 py-1.5 text-sm rounded-md bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50">
            <Plus className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {rows.length === 0 ? (
        <p className="text-sm text-muted-foreground p-4">Nincs rögzített terápia.</p>
      ) : (
        <div className="rounded-xl border border-border bg-card overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted/40 text-xs"><tr>
              <th className="px-3 py-2 text-left w-28">Típus</th>
              <th className="px-3 py-2 text-left">Megnevezés</th>
              <th className="px-3 py-2 text-left w-24">Dózis</th>
              <th className="px-3 py-2 text-left w-24">Gyakoriság</th>
              <th className="px-3 py-2 text-left w-24">Időtartam</th>
            </tr></thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.id} className="border-t border-border">
                  <td className="px-3 py-2 text-xs">{r.kind}</td>
                  <td className="px-3 py-2">{r.display}</td>
                  <td className="px-3 py-2 font-mono text-xs">{r.dose ?? "—"}</td>
                  <td className="px-3 py-2 font-mono text-xs">{r.frequency ?? "—"}</td>
                  <td className="px-3 py-2 font-mono text-xs">{r.duration ?? "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ---------- LAZLAP PREVIEW ----------

function LazlapPreview({ encounterId }: { encounterId: string }) {
  return (
    <div className="rounded-xl border border-border bg-card p-8 text-center">
      <LineChart className="h-12 w-12 mx-auto text-muted-foreground" />
      <h3 className="mt-3 text-lg font-semibold">Digitális lázlap</h3>
      <p className="mt-1 text-sm text-muted-foreground">A teljes idősoros lázlap külön nézetben tekinthető meg.</p>
      <Link to="/klinika/lazlap/$encounterId" params={{ encounterId }} className="inline-block mt-4 px-4 py-2 text-sm rounded-md bg-primary text-primary-foreground hover:bg-primary/90">
        Lázlap megnyitása
      </Link>
    </div>
  );
}

// ---------- AI NOTES ----------

type AiKind = "anamnesis" | "epicrisis" | "diet" | "results_summary";
const AI_KINDS: Array<{ value: AiKind; label: string }> = [
  { value: "anamnesis", label: "Anamnézis" },
  { value: "results_summary", label: "Lelet-összefoglaló" },
  { value: "epicrisis", label: "Epikrízis" },
  { value: "diet", label: "Diétás terv" },
];

function AiNotesTab({ encounterId, patientId, userId }: { encounterId: string; patientId: string; userId: string }) {
  const generate = useServerFn(generateAiClinicalNote);
  const [notes, setNotes] = useState<any[]>([]);
  const [generating, setGenerating] = useState<string | null>(null);
  const [editing, setEditing] = useState<Record<string, string>>({});
  const [extraCtx, setExtraCtx] = useState("");

  async function refresh() {
    const { data } = await supabase
      .from("clinical_notes")
      .select("*")
      .eq("encounter_id", encounterId)
      .eq("ai_generated", true)
      .order("created_at", { ascending: false });
    setNotes(data ?? []);
  }
  useEffect(() => { void refresh(); }, [encounterId]);

  async function gen(kind: AiKind) {
    setGenerating(kind);
    try {
      await generate({ data: { patientId, encounterId, kind, extraContext: extraCtx || undefined } });
      toast.success("AI vázlat elkészült");
      setExtraCtx("");
      void refresh();
    } catch (e: any) {
      toast.error(e?.message ?? "AI generálás sikertelen");
    } finally {
      setGenerating(null);
    }
  }

  async function saveEdit(id: string) {
    const body = editing[id];
    if (body == null) return;
    const { error } = await supabase.from("clinical_notes").update({ body_md: body }).eq("id", id);
    if (error) toast.error(error.message);
    else { toast.success("Módosítás mentve"); setEditing((e) => { const c = { ...e }; delete c[id]; return c; }); void refresh(); }
  }

  async function sign(id: string) {
    const body = editing[id];
    const patch: any = { signed_at: new Date().toISOString(), signed_by: userId };
    if (body != null) patch.body_md = body;
    const { error } = await supabase.from("clinical_notes").update(patch).eq("id", id);
    if (error) toast.error(error.message);
    else { toast.success("Aláírva"); setEditing((e) => { const c = { ...e }; delete c[id]; return c; }); void refresh(); }
  }

  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-border bg-card p-4 space-y-3">
        <div className="flex items-center gap-2 text-sm font-semibold">
          <Sparkles className="h-4 w-4 text-primary" /> AI-asszisztált dokumentáció
        </div>
        <p className="text-xs text-muted-foreground">
          A modell a beteg aktuális mérései, diagnózisai, terápiái és kalkulátor-eredményei alapján készít magyar nyelvű, szerkeszthető Markdown vázlatot. Az orvos felülvizsgálja, módosítja, majd aláírja.
        </p>
        <label className="block">
          <span className="text-xs text-muted-foreground flex items-center justify-between gap-2">
            <span>Egyéb kontextus a modell számára (opcionális)</span>
            <VoiceRecorderButton
              className="!min-h-9 !min-w-9 !p-1.5"
              title="Hang-alapú diktálás — a szöveg a kontextushoz fűződik"
              onResult={(txt) => setExtraCtx((c) => (c ? `${c} ${txt}` : txt))}
            />
          </span>
          <textarea value={extraCtx} onChange={(e) => setExtraCtx(e.target.value)} rows={2}
            placeholder="pl. terhesség 24. hét, laktóz-intolerancia, allergiák, aktuális panasz felvétele hangfelvételről…"
            className="mt-1 w-full px-2 py-1.5 text-sm rounded-md border border-border bg-background" />
        </label>
        <div className="flex flex-wrap gap-2">
          {AI_KINDS.map((k) => (
            <button key={k.value} onClick={() => gen(k.value)} disabled={generating !== null}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-md bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50">
              {generating === k.value ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Sparkles className="h-3.5 w-3.5" />}
              {k.label} generálása
            </button>
          ))}
        </div>
      </div>

      {notes.length === 0 ? (
        <p className="text-sm text-muted-foreground p-4">Még nincs AI-vázlat ehhez az epizódhoz.</p>
      ) : notes.map((n) => {
        const isSigned = !!n.signed_at;
        const value = editing[n.id] ?? n.body_md;
        return (
          <div key={n.id} className="rounded-xl border border-border bg-card p-4">
            <div className="flex items-start justify-between gap-3 mb-3">
              <div>
                <div className="text-xs uppercase font-mono text-muted-foreground flex items-center gap-2">
                  <Sparkles className="h-3 w-3" /> {AI_KINDS.find((k) => k.value === n.kind)?.label ?? n.kind} · {new Date(n.created_at).toLocaleString("hu-HU")}
                </div>
                {n.title && <div className="font-semibold mt-1">{n.title}</div>}
              </div>
              {isSigned ? (
                <StatusBadge tone="ok" pill size="sm" icon={<FileSignature className="h-3 w-3" />}>
                  aláírva {new Date(n.signed_at).toLocaleString("hu-HU")}
                </StatusBadge>
              ) : (
                <StatusBadge tone="warn" pill>vázlat</StatusBadge>
              )}
            </div>
            {isSigned ? (
              <pre className="whitespace-pre-wrap text-sm font-sans">{n.body_md}</pre>
            ) : (
              <>
                <textarea value={value} onChange={(e) => setEditing((s) => ({ ...s, [n.id]: e.target.value }))} rows={14}
                  className="w-full px-3 py-2 text-sm rounded-md border border-border bg-background font-mono" />
                <div className="mt-2 flex items-center gap-2">
                  <button onClick={() => saveEdit(n.id)} disabled={editing[n.id] == null}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-md border border-border hover:bg-accent disabled:opacity-50">
                    <Save className="h-3.5 w-3.5" /> Módosítás mentése
                  </button>
                  <button onClick={() => sign(n.id)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-md bg-primary text-primary-foreground hover:bg-primary/90">
                    <FileSignature className="h-3.5 w-3.5" /> Aláírás
                  </button>
                </div>
              </>
            )}
          </div>
        );
      })}
    </div>
  );
}
