/**
 * Admin elégedettségi dashboard — NPS aggregálás + utolsó visszajelzések.
 *
 * NPS = %promoter (9–10) − %detractor (0–6). Adams et al. (2022) szerint
 * másodlagos trend-metrika, nem önálló minőségmérce — UI-ban jelzem.
 */
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

type Row = {
  id: string;
  instrument_code: string;
  nps_score: number | null;
  answers: Record<string, unknown> | null;
  submitted_at: string;
};

function calcNps(rows: Row[]) {
  const nps = rows.filter((r) => r.nps_score !== null).map((r) => r.nps_score as number);
  if (nps.length === 0) return { score: null, promoters: 0, passives: 0, detractors: 0, n: 0 };
  const promoters = nps.filter((s) => s >= 9).length;
  const detractors = nps.filter((s) => s <= 6).length;
  const passives = nps.length - promoters - detractors;
  const score = Math.round(((promoters - detractors) / nps.length) * 100);
  return { score, promoters, passives, detractors, n: nps.length };
}

function ElegedettsegPage() {
  const q = useQuery({
    queryKey: ["satisfaction"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("satisfaction_surveys")
        .select("id, instrument_code, nps_score, answers, submitted_at")
        .order("submitted_at", { ascending: false })
        .limit(500);
      if (error) throw new Error(error.message);
      return (data ?? []) as unknown as Row[];
    },
  });

  const stats = calcNps(q.data ?? []);

  return (
    <main className="container mx-auto px-4 py-8">
      <h1 className="mb-6 text-2xl font-bold">Elégedettség</h1>
      <p className="-mt-4 mb-6 text-xs text-muted-foreground">
        Az NPS másodlagos trend-metrika, nem önálló minőségmérce (Adams et al., 2022).
      </p>

      {q.isLoading && <Skeleton className="h-40 w-full" />}
      {q.isError && <p className="text-sm text-destructive">{(q.error as Error).message}</p>}

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">NPS</CardTitle></CardHeader>
          <CardContent>
            <p className="text-4xl font-bold">{stats.score ?? "—"}</p>
            <p className="text-xs text-muted-foreground">n = {stats.n}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Promóter (9–10)</CardTitle></CardHeader>
          <CardContent><p className="text-3xl font-bold text-green-600">{stats.promoters}</p></CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Passzív (7–8)</CardTitle></CardHeader>
          <CardContent><p className="text-3xl font-bold text-amber-600">{stats.passives}</p></CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Kritikus (0–6)</CardTitle></CardHeader>
          <CardContent><p className="text-3xl font-bold text-red-600">{stats.detractors}</p></CardContent>
        </Card>
      </div>

      <h2 className="mb-3 mt-8 text-lg font-semibold">Legutóbbi visszajelzések</h2>
      <div className="space-y-2">
        {q.data?.slice(0, 30).map((r) => {
          const comment = (r.answers as { comment?: string } | null)?.comment;
          return (
            <Card key={r.id}>
              <CardContent className="flex items-start justify-between gap-3 py-3">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">{r.instrument_code}</Badge>
                    {r.nps_score !== null && (
                      <Badge variant={r.nps_score >= 9 ? "default" : r.nps_score <= 6 ? "destructive" : "secondary"}>
                        NPS {r.nps_score}
                      </Badge>
                    )}
                    <span className="text-xs text-muted-foreground">
                      {new Date(r.submitted_at).toLocaleString("hu-HU")}
                    </span>
                  </div>
                  {comment && <p className="mt-1 text-sm italic">„{comment}”</p>}
                </div>
              </CardContent>
            </Card>
          );
        })}
        {q.data && q.data.length === 0 && (
          <p className="text-sm text-muted-foreground">Még nincs visszajelzés.</p>
        )}
      </div>
    </main>
  );
}

export const Route = createFileRoute("/_authenticated/elegedettseg")({
  component: ElegedettsegPage,
  head: () => ({ meta: [{ title: "Elégedettség" }] }),
  errorComponent: ({ error, reset }) => (
    <div className="p-6"><p className="text-destructive">{error.message}</p><Button onClick={reset}>Újra</Button></div>
  ),
  notFoundComponent: () => <div className="p-6">Nem található</div>,
});
