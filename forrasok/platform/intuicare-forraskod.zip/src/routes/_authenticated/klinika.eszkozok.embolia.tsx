import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Wind } from "lucide-react";
import { CalculatorShell, Card, ScoreBadge, Toggle } from "@/components/clinical/calc-shell";
import {
  scoreWellsPE, scoreGenevaPE,
  type WellsPeInput, type GenevaInput,
} from "@/lib/clinical/scores";

export const Route = createFileRoute("/_authenticated/klinika/eszkozok/embolia")({
  validateSearch: (s: Record<string, unknown>): { encounterId?: string; patientId?: string } => ({
    encounterId: typeof s.encounterId === "string" ? s.encounterId : undefined,
    patientId: typeof s.patientId === "string" ? s.patientId : undefined,
  }),
  component: EmboliaPage,
});

const W0: WellsPeInput = { clinical_signs_dvt: false, pe_most_likely_dx: false, hr_over_100: false, immobilization_or_surgery_4w: false, prev_dvt_pe: false, hemoptysis: false, malignancy_active: false };
const G0: GenevaInput = { age_over_65: false, prev_dvt_pe: false, surgery_or_fracture_1m: false, malignancy_active: false, unilateral_leg_pain: false, hemoptysis: false, hr_75_94: false, hr_95_plus: false, pain_on_palpation_unilateral_edema: false };

function EmboliaPage() {
  const [tab, setTab] = useState<"wells" | "geneva">("wells");
  const [w, setW] = useState<WellsPeInput>(W0);
  const [g, setG] = useState<GenevaInput>(G0);
  const wR = useMemo(() => scoreWellsPE(w), [w]);
  const gR = useMemo(() => scoreGenevaPE(g), [g]);

  return (
    <CalculatorShell
      title="Pulmonális embólia — Wells & Geneva (rev.)"
      subtitle="PE klinikai valószínűségi pontszámok és diagnosztikus algoritmus."
      Icon={Wind}
      fromRoute="/_authenticated/klinika/eszkozok/embolia"
      onReset={() => { setW(W0); setG(G0); }}
      getSaveBundle={() => tab === "wells"
        ? { calculator: "wells_pe", inputs: w, outputs: wR,
            interpretation_md: `**Wells PE:** ${wR.score} pont · ${wR.twoTier} (${wR.threeTier})\n\n${wR.next}` }
        : { calculator: "geneva_pe", inputs: g, outputs: gR,
            interpretation_md: `**Geneva (rev.):** ${gR.score} pont · ${gR.threeTier} valószínűség\n\n${gR.next}` }}
    >
      <div className="flex gap-2 border-b border-border">
        <Tab active={tab === "wells"} onClick={() => setTab("wells")}>Wells (PE)</Tab>
        <Tab active={tab === "geneva"} onClick={() => setTab("geneva")}>Geneva (rev.)</Tab>
      </div>

      {tab === "wells" ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Card title="Kritériumok">
            <Toggle checked={w.clinical_signs_dvt} onChange={(v) => setW({ ...w, clinical_signs_dvt: v })} label="DVT klinikai jelei (3)" />
            <Toggle checked={w.pe_most_likely_dx} onChange={(v) => setW({ ...w, pe_most_likely_dx: v })} label="PE a legvalószínűbb dg. (3)" />
            <Toggle checked={w.hr_over_100} onChange={(v) => setW({ ...w, hr_over_100: v })} label="HR > 100/perc (1,5)" />
            <Toggle checked={w.immobilization_or_surgery_4w} onChange={(v) => setW({ ...w, immobilization_or_surgery_4w: v })} label="Immobilizáció / műtét 4 héten belül (1,5)" />
            <Toggle checked={w.prev_dvt_pe} onChange={(v) => setW({ ...w, prev_dvt_pe: v })} label="Korábbi DVT/PE (1,5)" />
            <Toggle checked={w.hemoptysis} onChange={(v) => setW({ ...w, hemoptysis: v })} label="Vérköpés (1)" />
            <Toggle checked={w.malignancy_active} onChange={(v) => setW({ ...w, malignancy_active: v })} label="Aktív malignitás (1)" />
          </Card>
          <Card title="Eredmény" footer={wR.next}>
            <ScoreBadge score={wR.score} label={`pont · ${wR.twoTier}`} tone={wR.twoTier === "valószínű" ? "danger" : "warn"} />
            <div className="text-sm">3-tier: <span className="font-mono font-semibold">{wR.threeTier}</span></div>
          </Card>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Card title="Kritériumok">
            <Toggle checked={g.age_over_65} onChange={(v) => setG({ ...g, age_over_65: v })} label="Életkor > 65 (1)" />
            <Toggle checked={g.prev_dvt_pe} onChange={(v) => setG({ ...g, prev_dvt_pe: v })} label="Korábbi DVT/PE (3)" />
            <Toggle checked={g.surgery_or_fracture_1m} onChange={(v) => setG({ ...g, surgery_or_fracture_1m: v })} label="Műtét / törés 1 hónapon belül (2)" />
            <Toggle checked={g.malignancy_active} onChange={(v) => setG({ ...g, malignancy_active: v })} label="Aktív malignitás (2)" />
            <Toggle checked={g.unilateral_leg_pain} onChange={(v) => setG({ ...g, unilateral_leg_pain: v })} label="Egyoldali végtagfájdalom (3)" />
            <Toggle checked={g.hemoptysis} onChange={(v) => setG({ ...g, hemoptysis: v })} label="Vérköpés (2)" />
            <Toggle checked={g.hr_75_94} onChange={(v) => setG({ ...g, hr_75_94: v, hr_95_plus: v ? false : g.hr_95_plus })} label="Pulzus 75–94 (3)" />
            <Toggle checked={g.hr_95_plus} onChange={(v) => setG({ ...g, hr_95_plus: v, hr_75_94: v ? false : g.hr_75_94 })} label="Pulzus ≥ 95 (5)" />
            <Toggle checked={g.pain_on_palpation_unilateral_edema} onChange={(v) => setG({ ...g, pain_on_palpation_unilateral_edema: v })} label="Palpációs érzékenység + egyoldali ödéma (4)" />
          </Card>
          <Card title="Eredmény" footer={gR.next}>
            <ScoreBadge score={gR.score} label={`pont · ${gR.threeTier}`} tone={gR.threeTier === "magas" ? "danger" : gR.threeTier === "közepes" ? "warn" : "ok"} />
          </Card>
        </div>
      )}
    </CalculatorShell>
  );
}

function Tab({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button onClick={onClick} className={`px-4 py-2 text-sm font-medium border-b-2 -mb-px ${active ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"}`}>
      {children}
    </button>
  );
}
