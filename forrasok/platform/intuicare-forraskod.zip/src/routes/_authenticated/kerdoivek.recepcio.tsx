/**
 * Recepciós nézet — QR-kódok nyomtatása a kioszk-engedélyezett, aktív
 * kérdőív hozzárendelésekhez. Nyomtatási státusz (nyomtatva/lemondva)
 * tárolva, kártyán megjelenítve. Kereső + dátumszűrés + rendezés.
 */
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { QRCodeSVG } from "qrcode.react";
import { toast } from "sonner";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { StatusBadge } from "@/components/ui/status-badge";
import { dueTone } from "@/lib/ui/status-tone";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Printer, RefreshCw, Search, ChevronLeft, Clock, AlertTriangle,
  CheckCircle2, XCircle, Inbox, RotateCcw,
} from "lucide-react";
import {
  listKioskEligibleAssignments,
  setKioskPrintStatus,
} from "@/lib/questionnaires/questionnaires.functions";

type PrintStatus = "not_printed" | "printed" | "cancelled";
type SortKey = "due_asc" | "due_desc" | "assigned_desc" | "patient_asc" | "print_pending_first";
type StatusFilter = "all" | PrintStatus | "pending";

function fmt(iso: string | null): string {
  if (!iso) return "—";
  return new Date(iso).toLocaleString("hu-HU", {
    year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit",
  });
}
function fmtDOB(iso: string | null): string {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString("hu-HU");
}
function dueBadge(due: string | null): { label: string; tone: "neutral" | "warn" | "bad" } {
  const r = dueTone(due);
  return { label: r.label, tone: r.tone === "neutral" ? "neutral" : r.tone === "warn" ? "warn" : "bad" };
}
function kioskUrl(token: string): string {
  if (typeof window === "undefined") return `/kiosk/${token}`;
  return `${window.location.origin}/kiosk/${token}`;
}

function PrintStatusBadge({ status, ts }: { status: PrintStatus; ts: string | null }) {
  if (status === "printed") {
    return (
      <StatusBadge tone="ok" pill icon={<CheckCircle2 className="h-3 w-3" />}>
        Nyomtatva {ts ? `· ${fmt(ts)}` : ""}
      </StatusBadge>
    );
  }
  if (status === "cancelled") {
    return (
      <StatusBadge tone="bad" pill icon={<XCircle className="h-3 w-3" />}>
        Lemondva {ts ? `· ${fmt(ts)}` : ""}
      </StatusBadge>
    );
  }
  return <StatusBadge tone="neutral" pill>Még nem nyomtatva</StatusBadge>;
}

function QRCard({
  row,
  onSetStatus,
  busy,
}: {
  row: any;
  onSetStatus: (assignment_id: string, s: PrintStatus) => void;
  busy: boolean;
}) {
  const p = row.patients;
  const q = row.questionnaires;
  const name = p ? `${p.vezeteknev ?? ""} ${p.keresztnev ?? ""}`.trim() : "Anonim";
  const url = kioskUrl(row.token);
  const due = dueBadge(row.due_at);
  const status: PrintStatus = (row.print_status as PrintStatus) ?? "not_printed";
  const ts = status === "printed" ? row.printed_at : status === "cancelled" ? row.print_cancelled_at : null;

  return (
    <Card
      className={`qr-card break-inside-avoid border-2 print:shadow-none ${
        status === "cancelled" ? "opacity-60" : ""
      }`}
    >
      <CardContent className="flex flex-col items-center gap-3 p-4 text-center">
        <div className="w-full text-left">
          <div className="text-xs uppercase tracking-wide text-muted-foreground">{q?.code ?? "—"}</div>
          <div className="text-sm font-semibold leading-tight">{q?.title ?? "Kérdőív"}</div>
        </div>

        <div className="rounded-md border bg-white p-3">
          <QRCodeSVG value={url} size={168} level="M" includeMargin={false} />
        </div>

        <div className="w-full text-left">
          <div className="text-base font-semibold">{name}</div>
          {p?.szuletesi_datum && (
            <div className="text-xs text-muted-foreground">
              Szül.: {fmtDOB(p.szuletesi_datum)}
              {p.taj ? ` · TAJ: ${p.taj}` : ""}
            </div>
          )}
          <div className="mt-2 flex flex-wrap items-center gap-1">
            <StatusBadge tone={due.tone} pill>{due.label}</StatusBadge>
            {q?.becsult_perc != null && (
              <StatusBadge tone="neutral" pill icon={<Clock className="h-3 w-3" />}>
                {q.becsult_perc} perc
              </StatusBadge>
            )}
            <PrintStatusBadge status={status} ts={ts} />
          </div>
          <div className="mt-2 break-all rounded bg-muted/60 px-1.5 py-1 font-mono text-[10px] text-muted-foreground">
            {url}
          </div>

          <div className="mt-3 flex flex-wrap gap-2 print:hidden">
            {status !== "printed" && (
              <Button
                size="sm"
                variant="default"
                disabled={busy}
                onClick={() => onSetStatus(row.id, "printed")}
              >
                <CheckCircle2 className="mr-1 h-3 w-3" /> Nyomtatva
              </Button>
            )}
            {status !== "cancelled" && (
              <Button
                size="sm"
                variant="outline"
                disabled={busy}
                onClick={() => onSetStatus(row.id, "cancelled")}
              >
                <XCircle className="mr-1 h-3 w-3" /> Lemondás
              </Button>
            )}
            {status !== "not_printed" && (
              <Button
                size="sm"
                variant="ghost"
                disabled={busy}
                onClick={() => onSetStatus(row.id, "not_printed")}
              >
                <RotateCcw className="mr-1 h-3 w-3" /> Visszaállít
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function RecepcioPage() {
  const fn = useServerFn(listKioskEligibleAssignments);
  const setFn = useServerFn(setKioskPrintStatus);
  const qc = useQueryClient();

  const q = useQuery({
    queryKey: ["kiosk-eligible-assignments"],
    queryFn: () => fn(),
    refetchInterval: 60_000,
    retry: 2,
  });

  const mutate = useMutation({
    mutationFn: (v: { id: string; s: PrintStatus }) =>
      setFn({ data: { assignment_id: v.id, print_status: v.s } }),
    onSuccess: (_d, v) => {
      toast.success(
        v.s === "printed" ? "Nyomtatva megjelölve" :
        v.s === "cancelled" ? "Lemondva" : "Visszaállítva",
      );
      qc.invalidateQueries({ queryKey: ["kiosk-eligible-assignments"] });
    },
    onError: (e: any) => toast.error(`Mentés sikertelen: ${e?.message ?? "ismeretlen hiba"}`),
  });

  const [search, setSearch] = useState("");
  const [dueFrom, setDueFrom] = useState("");
  const [dueTo, setDueTo] = useState("");
  const [sortKey, setSortKey] = useState<SortKey>("due_asc");
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");

  const rows = useMemo(() => {
    let list = (q.data ?? []) as any[];

    const s = search.trim().toLowerCase();
    if (s) {
      list = list.filter((r) => {
        const p = r.patients;
        const name = p ? `${p.vezeteknev ?? ""} ${p.keresztnev ?? ""}`.toLowerCase() : "";
        const taj = (p?.taj ?? "").toString().toLowerCase();
        const qcode = (r.questionnaires?.code ?? "").toLowerCase();
        const qtitle = (r.questionnaires?.title ?? "").toLowerCase();
        return name.includes(s) || taj.includes(s) || qcode.includes(s) || qtitle.includes(s);
      });
    }

    const fromT = dueFrom ? new Date(dueFrom).getTime() : null;
    const toT = dueTo ? new Date(dueTo).getTime() + 24 * 3600 * 1000 - 1 : null;
    if (fromT !== null || toT !== null) {
      list = list.filter((r) => {
        if (!r.due_at) return false;
        const t = new Date(r.due_at).getTime();
        if (fromT !== null && t < fromT) return false;
        if (toT !== null && t > toT) return false;
        return true;
      });
    }

    if (statusFilter !== "all") {
      list = list.filter((r) => {
        const ps = (r.print_status as PrintStatus) ?? "not_printed";
        if (statusFilter === "pending") return ps !== "printed";
        return ps === statusFilter;
      });
    }

    const cmpDue = (a: any, b: any, asc: boolean) => {
      const av = a.due_at ? new Date(a.due_at).getTime() : Number.POSITIVE_INFINITY;
      const bv = b.due_at ? new Date(b.due_at).getTime() : Number.POSITIVE_INFINITY;
      return asc ? av - bv : bv - av;
    };
    const sorters: Record<SortKey, (a: any, b: any) => number> = {
      due_asc: (a, b) => cmpDue(a, b, true),
      due_desc: (a, b) => cmpDue(a, b, false),
      assigned_desc: (a, b) =>
        new Date(b.assigned_at ?? 0).getTime() - new Date(a.assigned_at ?? 0).getTime(),
      patient_asc: (a, b) => {
        const an = `${a.patients?.vezeteknev ?? ""} ${a.patients?.keresztnev ?? ""}`.trim().toLowerCase();
        const bn = `${b.patients?.vezeteknev ?? ""} ${b.patients?.keresztnev ?? ""}`.trim().toLowerCase();
        return an.localeCompare(bn, "hu");
      },
      print_pending_first: (a, b) => {
        const rank = (r: any) => ((r.print_status ?? "not_printed") === "not_printed" ? 0 : 1);
        const d = rank(a) - rank(b);
        return d !== 0 ? d : cmpDue(a, b, true);
      },
    };
    return [...list].sort(sorters[sortKey]);
  }, [q.data, search, dueFrom, dueTo, sortKey, statusFilter]);

  const stats = useMemo(() => {
    const all = (q.data ?? []) as any[];
    const printed = all.filter((r) => r.print_status === "printed").length;
    const cancelled = all.filter((r) => r.print_status === "cancelled").length;
    const pending = all.length - printed - cancelled;
    return { total: all.length, printed, cancelled, pending };
  }, [q.data]);

  const resetFilters = () => {
    setSearch(""); setDueFrom(""); setDueTo(""); setSortKey("due_asc"); setStatusFilter("all");
  };

  return (
    <main className="container mx-auto px-4 py-8 print:px-0 print:py-0">
      <header className="mb-6 flex flex-wrap items-center justify-between gap-3 print:hidden">
        <div className="flex items-center gap-3">
          <Link to="/kerdoivek" className="text-sm text-primary hover:underline">
            <ChevronLeft className="inline h-4 w-4" /> Vissza
          </Link>
          <div>
            <h1 className="text-2xl font-bold">Recepció — QR-nyomtatás</h1>
            <p className="text-sm text-muted-foreground">
              Aktív, kioszk-engedélyezett kérdőívek. Jelöld a nyomtatást vagy a lemondást — az állapot megőrződik.
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => q.refetch()} disabled={q.isFetching}>
            <RefreshCw className={`mr-2 h-4 w-4 ${q.isFetching ? "animate-spin" : ""}`} />
            Frissítés
          </Button>
          <Button size="sm" onClick={() => window.print()}>
            <Printer className="mr-2 h-4 w-4" /> Nyomtatás
          </Button>
        </div>
      </header>

      {/* Szűrők */}
      <section className="mb-4 grid grid-cols-1 gap-3 md:grid-cols-5 print:hidden">
        <div className="relative md:col-span-2">
          <Label className="mb-1 block text-xs">Keresés</Label>
          <Search className="pointer-events-none absolute left-2 top-[34px] h-4 w-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Páciens, TAJ, kérdőív kód…"
            className="pl-8"
          />
        </div>
        <div>
          <Label className="mb-1 block text-xs">Esedékesség-tól</Label>
          <Input type="date" value={dueFrom} onChange={(e) => setDueFrom(e.target.value)} />
        </div>
        <div>
          <Label className="mb-1 block text-xs">Esedékesség-ig</Label>
          <Input type="date" value={dueTo} onChange={(e) => setDueTo(e.target.value)} />
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div>
            <Label className="mb-1 block text-xs">Státusz</Label>
            <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as StatusFilter)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Mind</SelectItem>
                <SelectItem value="pending">Nyitott (nem nyomtatva)</SelectItem>
                <SelectItem value="not_printed">Még nem nyomtatva</SelectItem>
                <SelectItem value="printed">Nyomtatva</SelectItem>
                <SelectItem value="cancelled">Lemondva</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="mb-1 block text-xs">Rendezés</Label>
            <Select value={sortKey} onValueChange={(v) => setSortKey(v as SortKey)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="due_asc">Esedékesség ↑</SelectItem>
                <SelectItem value="due_desc">Esedékesség ↓</SelectItem>
                <SelectItem value="assigned_desc">Legújabb kiosztás</SelectItem>
                <SelectItem value="patient_asc">Páciens (A→Z)</SelectItem>
                <SelectItem value="print_pending_first">Nyomtatandó elöl</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </section>

      <div className="mb-4 flex flex-wrap items-center gap-3 text-xs text-muted-foreground print:hidden">
        <span>Összes: <strong>{stats.total}</strong></span>
        <span>Nyitott: <strong>{stats.pending}</strong></span>
        <span>Nyomtatva: <strong className="text-emerald-600">{stats.printed}</strong></span>
        <span>Lemondva: <strong className="text-destructive">{stats.cancelled}</strong></span>
        <Button size="sm" variant="ghost" className="h-7 px-2" onClick={resetFilters}>Szűrők törlése</Button>
      </div>

      {/* Loading */}
      {q.isLoading && (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-80 w-full" />)}
        </div>
      )}

      {/* Hiba */}
      {q.isError && (
        <Card className="border-destructive/40">
          <CardContent className="flex flex-col items-start gap-3 p-6">
            <div className="flex items-center gap-2 text-destructive">
              <AlertTriangle className="h-5 w-5" />
              <h2 className="text-base font-semibold">Nem sikerült betölteni a kioszk hozzárendeléseket</h2>
            </div>
            <p className="text-sm text-muted-foreground">
              {(q.error as Error)?.message ?? "Ismeretlen hiba történt."} Ellenőrizd a hálózati kapcsolatot, majd próbáld újra.
            </p>
            <Button size="sm" onClick={() => q.refetch()} disabled={q.isFetching}>
              <RefreshCw className={`mr-2 h-4 w-4 ${q.isFetching ? "animate-spin" : ""}`} />
              Újrapróbálás
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Üres állapot */}
      {!q.isLoading && !q.isError && rows.length === 0 && (
        <Card>
          <CardContent className="flex flex-col items-center gap-3 p-10 text-center">
            <Inbox className="h-10 w-10 text-muted-foreground" />
            <h2 className="text-base font-semibold">
              {stats.total === 0 ? "Nincs aktív, kioszk-engedélyezett kérdőív" : "Nincs a szűrésnek megfelelő találat"}
            </h2>
            <p className="max-w-md text-sm text-muted-foreground">
              {stats.total === 0
                ? "Új hozzárendelés esetén itt jelennek meg a páciensek QR-kódjai. A kérdőív kioszk-engedélyezettségét a kérdőív szerkesztőben állíthatod be."
                : "Lazíts a szűrőkön (dátum, státusz, keresés) vagy állítsd vissza az alapértelmezést."}
            </p>
            {stats.total > 0 && (
              <Button size="sm" variant="outline" onClick={resetFilters}>Szűrők törlése</Button>
            )}
          </CardContent>
        </Card>
      )}

      {/* Rács */}
      {!q.isLoading && !q.isError && rows.length > 0 && (
        <section className="qr-grid grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3 print:grid-cols-2 print:gap-3">
          {rows.map((r: any) => (
            <QRCard
              key={r.id}
              row={r}
              busy={mutate.isPending && mutate.variables?.id === r.id}
              onSetStatus={(id, s) => mutate.mutate({ id, s })}
            />
          ))}
        </section>
      )}

      <p className="mt-6 text-xs text-muted-foreground print:hidden">
        Megjelenítve {rows.length} / {stats.total} QR-kód. A nyomtatás csak a kártyákat tartalmazza (A4-re optimalizálva).
      </p>

      <style>{`
        @media print {
          @page { size: A4; margin: 10mm; }
          body { background: white !important; }
          .qr-card { page-break-inside: avoid; }
        }
      `}</style>
    </main>
  );
}

export const Route = createFileRoute("/_authenticated/kerdoivek/recepcio")({
  component: RecepcioPage,
});
