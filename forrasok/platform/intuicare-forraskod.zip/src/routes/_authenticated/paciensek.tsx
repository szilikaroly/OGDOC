import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Loader2, Stethoscope, Plus, Search, X, FileSignature } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { useTranslation } from "react-i18next";
import { humanizeError } from "@/lib/humanize-error";
import { toast } from "sonner";
import { EncounterEditor, type EncounterRow } from "@/components/paciensek/encounter-editor";
import { EesztPanel } from "@/components/paciensek/eeszt-panel";
import { exportPatientGdpr, downloadJson } from "@/lib/patient-gdpr-export";
import { openPatientGdprPrint } from "@/lib/patient-gdpr-print";
import { Download, Printer } from "lucide-react";

export const Route = createFileRoute("/_authenticated/paciensek")({
  validateSearch: (search: Record<string, unknown>): { id?: string } => ({
    id: typeof search.id === "string" ? search.id : undefined,
  }),
  component: PaciensekPage,
});


type Patient = {
  id: string;
  taj: string | null;
  vezeteknev: string;
  keresztnev: string;
  szuletesi_datum: string | null;
  nem: string | null;
  fo_diagnozis_bno: string | null;
};

type Encounter = EncounterRow;

function PaciensekPage() {
  const { user } = useAuth();
  const { t } = useTranslation();
  const { id: deepLinkId } = Route.useSearch();

  const [tenantId, setTenantId] = useState<string | null>(null);
  const [patients, setPatients] = useState<Patient[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<Patient | null>(null);
  const [encounters, setEncounters] = useState<Encounter[]>([]);
  const [showNew, setShowNew] = useState(false);
  const [form, setForm] = useState({ vezeteknev: "", keresztnev: "", taj: "", szuletesi_datum: "", nem: "" });
  const [editEnc, setEditEnc] = useState<{ row: Encounter | null } | null>(null);

  useEffect(() => {
    if (!user) return;
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  // Deep-link: ?id=<patient_id> automatikus megnyitás
  useEffect(() => {
    if (!user || !deepLinkId) return;
    if (selected?.id === deepLinkId) return;
    (async () => {
      const { data, error } = await supabase
        .from("patients")
        .select("id,taj,vezeteknev,keresztnev,szuletesi_datum,nem,fo_diagnozis_bno")
        .eq("id", deepLinkId)
        .maybeSingle();
      if (error) { toast.error(humanizeError(error, t)); return; }
      if (data) {
        setSelected(data as Patient);
        await reloadEncounters((data as Patient).id);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, deepLinkId]);


  useEffect(() => {
    if (!user) return;
    const q = search.trim();
    if (q.length < 2) return;
    const t = setTimeout(() => { void runSearch(q); }, 250);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search, user]);

  async function runSearch(q: string) {
    const { data, error } = await (supabase as any).rpc("search_patients", { _q: q, _limit: 50 });
    if (error) { toast.error(humanizeError(error, t)); return; }
    setPatients((data ?? []) as Patient[]);
  }

  async function load() {
    if (!user) return;
    setLoading(true);
    const { data: prof } = await supabase.from("profiles").select("tenant_id").eq("id", user.id).maybeSingle();
    setTenantId((prof as any)?.tenant_id ?? null);
    const { data, error } = await supabase
      .from("patients")
      .select("id,taj,vezeteknev,keresztnev,szuletesi_datum,nem,fo_diagnozis_bno")
      .order("vezeteknev")
      .limit(100);
    if (error) toast.error(humanizeError(error, t));
    else setPatients((data ?? []) as Patient[]);
    setLoading(false);
  }

  async function openPatient(p: Patient) {
    setSelected(p);
    await reloadEncounters(p.id);
  }

  async function reloadEncounters(pid: string) {
    const { data, error } = await supabase
      .from("patient_encounters")
      .select("id,patient_id,ellatas_kezdete,ellatas_vege,tipus,status,bno_kodok,oeno_kodok,beavatkozas_ids,osszefoglalo,intezmenyi_azonosito,szerzo_id,szerzo_alairas_at,ellenjegyzo_id,ellenjegyzo_alairas_at")
      .eq("patient_id", pid)
      .order("ellatas_kezdete", { ascending: false })
      .limit(20);
    if (error) toast.error(humanizeError(error, t));
    else setEncounters((data ?? []) as Encounter[]);
  }

  async function createPatient() {
    if (!tenantId || !form.vezeteknev.trim() || !form.keresztnev.trim()) {
      toast.error("Vezetéknév és keresztnév kötelező");
      return;
    }
    const { data, error } = await (supabase.from("patients") as any)
      .insert({
        tenant_id: tenantId,
        vezeteknev: form.vezeteknev.trim(),
        keresztnev: form.keresztnev.trim(),
        taj: form.taj.trim() || null,
        szuletesi_datum: form.szuletesi_datum || null,
        nem: form.nem || null,
      })
      .select()
      .single();
    if (error) return toast.error(humanizeError(error, t));
    setPatients([data as Patient, ...patients]);
    setForm({ vezeteknev: "", keresztnev: "", taj: "", szuletesi_datum: "", nem: "" });
    setShowNew(false);
    toast.success("Páciens létrehozva");
  }

  const filtered = patients.filter(
    (p) =>
      !search ||
      `${p.vezeteknev} ${p.keresztnev}`.toLowerCase().includes(search.toLowerCase()) ||
      (p.taj ?? "").includes(search),
  );

  if (loading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Stethoscope className="h-6 w-6 text-primary" />
          <div>
            <h1 className="text-2xl font-semibold">Páciensek</h1>
            <p className="text-sm text-muted-foreground">EMR mag — páciens-törzs és ellátási epizódok</p>
          </div>
        </div>
        <button onClick={() => setShowNew(!showNew)} className="flex items-center gap-1 rounded bg-primary px-3 py-1.5 text-sm text-primary-foreground hover:opacity-90">
          <Plus className="h-4 w-4" /> Új páciens
        </button>
      </div>

      {showNew && (
        <div className="rounded-lg border bg-card p-4 grid grid-cols-1 sm:grid-cols-5 gap-2">
          <input placeholder="Vezetéknév" value={form.vezeteknev} onChange={(e) => setForm({ ...form, vezeteknev: e.target.value })} className="rounded border bg-background px-2 py-1.5 text-sm" />
          <input placeholder="Keresztnév" value={form.keresztnev} onChange={(e) => setForm({ ...form, keresztnev: e.target.value })} className="rounded border bg-background px-2 py-1.5 text-sm" />
          <input placeholder="TAJ" value={form.taj} onChange={(e) => setForm({ ...form, taj: e.target.value })} className="rounded border bg-background px-2 py-1.5 text-sm" />
          <input type="date" value={form.szuletesi_datum} onChange={(e) => setForm({ ...form, szuletesi_datum: e.target.value })} className="rounded border bg-background px-2 py-1.5 text-sm" />
          <select value={form.nem} onChange={(e) => setForm({ ...form, nem: e.target.value })} className="rounded border bg-background px-2 py-1.5 text-sm">
            <option value="">nem</option>
            <option value="ferfi">férfi</option>
            <option value="no">nő</option>
            <option value="egyeb">egyéb</option>
          </select>
          <div className="sm:col-span-5 flex gap-2">
            <button onClick={createPatient} className="rounded bg-primary px-3 py-1.5 text-sm text-primary-foreground hover:opacity-90">Mentés</button>
            <button onClick={() => setShowNew(false)} className="rounded border px-3 py-1.5 text-sm hover:bg-accent">Mégse</button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_2fr] gap-4">
        <div className="space-y-2">
          <div className="relative">
            <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Keresés név vagy TAJ szerint" className="w-full pl-8 pr-2 py-1.5 rounded border bg-background text-sm" />
          </div>
          <div className="rounded-lg border bg-card divide-y max-h-[60vh] overflow-y-auto">
            {filtered.length === 0 && <div className="p-4 text-sm text-muted-foreground italic">Nincs találat</div>}
            {filtered.map((p) => (
              <button key={p.id} onClick={() => openPatient(p)} className={"w-full text-left p-3 hover:bg-accent " + (selected?.id === p.id ? "bg-accent" : "")}>
                <div className="text-sm font-medium">{p.vezeteknev} {p.keresztnev}</div>
                <div className="text-xs text-muted-foreground font-mono">{p.taj ?? "—"} · {p.szuletesi_datum ?? "?"} · {p.nem ?? "?"}</div>
              </button>
            ))}
          </div>
        </div>

        <div className="rounded-lg border bg-card">
          {!selected ? (
            <div className="p-6 text-sm text-muted-foreground italic">Válasszon pácienst a részletekhez</div>
          ) : (
            <div className="p-4 space-y-3">
              <div className="flex items-start justify-between">
                <div>
                  <h2 className="text-lg font-semibold">{selected.vezeteknev} {selected.keresztnev}</h2>
                  <div className="text-xs font-mono text-muted-foreground">
                    TAJ: {selected.taj ?? "—"} · szül: {selected.szuletesi_datum ?? "?"} · nem: {selected.nem ?? "?"}
                  </div>
                  {selected.fo_diagnozis_bno && <div className="text-xs">Fő BNO: <span className="font-mono">{selected.fo_diagnozis_bno}</span></div>}
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={async () => {
                      try {
                        const { filename, payload } = await exportPatientGdpr(selected.id);
                        downloadJson(filename, payload);
                        toast.success("GDPR export letöltve");
                      } catch (e: any) {
                        toast.error(e?.message ?? "Export hiba");
                      }
                    }}
                    title="GDPR Art. 15 — teljes adatcsomag JSON-ban"
                    className="flex items-center gap-1 rounded border px-2 py-1 text-xs hover:bg-accent"
                  >
                    <Download className="h-3 w-3" /> GDPR
                  </button>
                  <button
                    onClick={async () => {
                      try {
                        await openPatientGdprPrint(selected.id);
                      } catch (e: any) {
                        toast.error(e?.message ?? "PDF hiba");
                      }
                    }}
                    title="GDPR adatkivonat nyomtatható PDF-ben"
                    className="flex items-center gap-1 rounded border px-2 py-1 text-xs hover:bg-accent"
                  >
                    <Printer className="h-3 w-3" /> GDPR PDF
                  </button>
                  <a
                    href={`/paciens-360/${selected.id}`}
                    className="flex items-center gap-1 rounded border px-2 py-1 text-xs hover:bg-accent"
                    title="Páciens 360 panel – összefoglaló nézet"
                  >
                    <Stethoscope className="h-3 w-3" /> 360
                  </a>
                  <button onClick={() => setSelected(null)} className="text-muted-foreground hover:text-foreground">
                    <X className="h-4 w-4" />
                  </button>
                </div>
              </div>
              {tenantId && <EesztPanel tenantId={tenantId} patientId={selected.id} />}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-medium">Ellátási epizódok</h3>
                  <button onClick={() => setEditEnc({ row: null })}
                    className="flex items-center gap-1 rounded border border-primary text-primary px-2 py-1 text-xs hover:bg-primary/10">
                    <Plus className="h-3 w-3" /> Új ellátás
                  </button>
                </div>
                <div className="divide-y border rounded">
                  {encounters.length === 0 && <div className="p-3 text-xs text-muted-foreground italic">Nincs epizód</div>}
                  {encounters.map((e) => (
                    <button key={e.id} onClick={() => setEditEnc({ row: e })}
                      className="w-full text-left p-2 text-xs hover:bg-accent/30">
                      <div className="flex items-center gap-2">
                        <span className="px-1.5 py-0.5 rounded bg-muted font-mono">{e.tipus}</span>
                        <span className="font-mono">{new Date(e.ellatas_kezdete).toLocaleString("hu-HU")}</span>
                        <span className="text-muted-foreground">→ {e.ellatas_vege ? new Date(e.ellatas_vege).toLocaleString("hu-HU") : "folyamatban"}</span>
                        <span className={
                          "ml-auto px-1.5 py-0.5 rounded font-mono text-[10px] " +
                          (e.status === "ellenjegyezve" ? "bg-emerald-500/15 text-emerald-700" :
                           e.status === "alairva" ? "bg-amber-500/15 text-amber-700" : "bg-muted text-muted-foreground")
                        }>{e.status}</span>
                        {e.ellenjegyzo_alairas_at && <FileSignature className="h-3 w-3 text-emerald-600" />}
                      </div>
                      {e.bno_kodok && e.bno_kodok.length > 0 && (
                        <div className="mt-1 font-mono text-muted-foreground">BNO: {e.bno_kodok.join(", ")}</div>
                      )}
                      {e.osszefoglalo && <div className="mt-1 line-clamp-2">{e.osszefoglalo}</div>}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {editEnc && selected && tenantId && user && (
        <EncounterEditor
          tenantId={tenantId}
          userId={user.id}
          patientId={selected.id}
          encounter={editEnc.row}
          onClose={() => setEditEnc(null)}
          onSaved={() => void reloadEncounters(selected.id)}
        />
      )}
    </div>
  );
}
