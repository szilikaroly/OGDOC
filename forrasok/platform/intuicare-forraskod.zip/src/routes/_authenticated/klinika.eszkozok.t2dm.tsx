import { createFileRoute, Link, useSearch } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Heart, Save, Loader2, ArrowLeft, RotateCcw } from "lucide-react";
import { evaluateT2dm, type T2dmInputs } from "@/lib/clinical/t2dm";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { toast } from "sonner";
import { LOINC } from "@/lib/clinical/fhir-codes";

export const Route = createFileRoute("/_authenticated/klinika/eszkozok/t2dm")({
  validateSearch: (s: Record<string, unknown>): { encounterId?: string; patientId?: string } => ({
    encounterId: typeof s.encounterId === "string" ? s.encounterId : undefined,
    patientId: typeof s.patientId === "string" ? s.patientId : undefined,
  }),
  component: T2dmPage,
});

const DEFAULTS: T2dmInputs = {
  age: 60,
  weightKg: 85,
  heightCm: 172,
  hba1c_pct: 8.2,
  egfr_ml_min_173: 75,
  ascvd: false,
  heart_failure: false,
  ckd: false,
  hypo_risk_high: false,
  cost_sensitive: false,
  pregnancy: false,
  current_meds: "",
};

function T2dmPage() {
  const { user } = useAuth();
  const { encounterId, patientId } = useSearch({ from: "/_authenticated/klinika/eszkozok/t2dm" });
  const [input, setInput] = useState<T2dmInputs>(DEFAULTS);
  const [saving, setSaving] = useState(false);
  const [activeEncounter, setActiveEncounter] = useState<{ id: string; patient_id: string; label: string } | null>(null);

  useEffect(() => {
    if (encounterId && patientId) {
      void (async () => {
        const { data: e } = await supabase.from("clinical_encounters").select("id, patient_id, encounter_type, start_ts").eq("id", encounterId).maybeSingle();
        const { data: p } = await supabase.from("patients").select("vezeteknev, keresztnev").eq("id", patientId).maybeSingle();
        if (e && p) {
          setActiveEncounter({ id: e.id, patient_id: e.patient_id, label: `${(p as any).vezeteknev} ${(p as any).keresztnev} · ${(e as any).encounter_type}` });
        }
      })();
    } else if (user) {
      void (async () => {
        const { data } = await supabase
          .from("clinical_encounters")
          .select("id, patient_id, encounter_type, start_ts, patients!inner(vezeteknev, keresztnev)")
          .eq("status", "in-progress")
          .eq("created_by", user.id)
          .order("start_ts", { ascending: false })
          .limit(1)
          .maybeSingle();
        if (data) {
          const p: any = (data as any).patients;
          setActiveEncounter({ id: (data as any).id, patient_id: (data as any).patient_id, label: `${p.vezeteknev} ${p.keresztnev} · ${(data as any).encounter_type}` });
        }
      })();
    }
  }, [encounterId, patientId, user]);

  const result = useMemo(() => evaluateT2dm(input), [input]);

  function set<K extends keyof T2dmInputs>(k: K, v: T2dmInputs[K]) {
    setInput((x) => ({ ...x, [k]: v }));
  }

  async function saveToEncounter() {
    if (!user || !activeEncounter) {
      toast.error("Nincs aktív ellátási epizód a mentéshez");
      return;
    }
    setSaving(true);
    try {
      const { error } = await supabase.from("clinical_calculator_results").insert({
        encounter_id: activeEncounter.id,
        patient_id: activeEncounter.patient_id,
        calculator: "t2dm",
        inputs_json: input as any,
        outputs_json: result as any,
        interpretation_md: result.interpretation_md,
        created_by: user.id,
      });
      if (error) throw error;

      const ts = new Date().toISOString();
      const bmi = input.weightKg / Math.pow(input.heightCm / 100, 2);
      const obs: any[] = [];
      const push = (loinc: string, display: string, value: number, unit: string, category: "vital-signs" | "laboratory") => {
        obs.push({
          encounter_id: activeEncounter.id,
          patient_id: activeEncounter.patient_id,
          category,
          loinc_code: loinc,
          code_display: display,
          value_quantity: value,
          value_unit: unit,
          effective_ts: ts,
          performer_id: user.id,
          source: "calculator-t2dm",
        });
      };
      push(LOINC.HBA1C.loinc, LOINC.HBA1C.hu, input.hba1c_pct, LOINC.HBA1C.unit, "laboratory");
      push("33914-3", "eGFR", input.egfr_ml_min_173, "mL/min/1.73m²", "laboratory");
      push(LOINC.BMI.loinc, LOINC.BMI.hu, Math.round(bmi * 10) / 10, LOINC.BMI.unit, "vital-signs");
      push(LOINC.WEIGHT.loinc, LOINC.WEIGHT.hu, input.weightKg, LOINC.WEIGHT.unit, "vital-signs");
      push(LOINC.HEIGHT.loinc, LOINC.HEIGHT.hu, input.heightCm, LOINC.HEIGHT.unit, "vital-signs");
      await supabase.from("clinical_observations").insert(obs);

      toast.success("Eredmény elmentve az epizódhoz");
    } catch (e: any) {
      toast.error(e?.message ?? "Mentés sikertelen");
    } finally {
      setSaving(false);
    }
  }

  const bmi = input.weightKg / Math.pow(input.heightCm / 100, 2);

  return (
    <div className="container max-w-6xl py-6 space-y-4">
      <header>
        <Link to="/klinika/eszkozok" className="text-xs text-muted-foreground hover:underline flex items-center gap-1">
          <ArrowLeft className="h-3 w-3" /> Eszközök
        </Link>
        <h1 className="text-2xl font-semibold mt-1 flex items-center gap-2">
          <Heart className="h-6 w-6 text-primary" /> T2DM Terápiatervező
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          ADA/EASD 2024-szerű egyszerűsített ajánlás. Az eredmény mentéskor a beteg epizódjához kerül LOINC-kódolt megfigyelésekkel.
        </p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="rounded-xl border border-border bg-card p-4 space-y-4">
          <h3 className="text-sm font-semibold">Beteg-paraméterek</h3>
          <div className="grid grid-cols-2 gap-3">
            <Num label="Életkor (év)" value={input.age} onChange={(v) => set("age", v)} step={1} />
            <Num label="Testsúly (kg)" value={input.weightKg} onChange={(v) => set("weightKg", v)} step={0.5} />
            <Num label="Magasság (cm)" value={input.heightCm} onChange={(v) => set("heightCm", v)} step={1} />
            <Num label="HbA1c (%)" value={input.hba1c_pct} onChange={(v) => set("hba1c_pct", v)} step={0.1} />
            <Num label="eGFR (ml/min/1,73 m²)" value={input.egfr_ml_min_173} onChange={(v) => set("egfr_ml_min_173", v)} step={1} />
            <div className="rounded-md border border-border px-2 py-1.5 text-sm bg-muted/30">
              <span className="text-xs text-muted-foreground">BMI</span>
              <div className="font-mono">{bmi.toFixed(1)} kg/m²</div>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2 pt-2 border-t border-border">
            <Chk label="ASCVD (CV-betegség)" value={input.ascvd} onChange={(v) => set("ascvd", v)} />
            <Chk label="Szívelégtelenség" value={input.heart_failure} onChange={(v) => set("heart_failure", v)} />
            <Chk label="CKD / albuminuria" value={input.ckd} onChange={(v) => set("ckd", v)} />
            <Chk label="Magas hipo-rizikó" value={input.hypo_risk_high} onChange={(v) => set("hypo_risk_high", v)} />
            <Chk label="Költségérzékeny" value={input.cost_sensitive} onChange={(v) => set("cost_sensitive", v)} />
            <Chk label="Terhesség" value={input.pregnancy} onChange={(v) => set("pregnancy", v)} />
          </div>
          <label className="block">
            <span className="text-xs text-muted-foreground">Jelenlegi gyógyszerelés</span>
            <textarea value={input.current_meds} onChange={(e) => set("current_meds", e.target.value)} rows={2}
              className="mt-1 w-full px-2 py-1.5 text-sm rounded-md border border-border bg-background font-mono" />
          </label>
          <div className="flex items-center gap-2 pt-2">
            <button onClick={() => setInput(DEFAULTS)} className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-md border border-border hover:bg-accent">
              <RotateCcw className="h-3.5 w-3.5" /> Reset
            </button>
            <button
              onClick={saveToEncounter}
              disabled={saving || !activeEncounter}
              className="ml-auto inline-flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-md bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
            >
              {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
              Mentés {activeEncounter ? "az epizódhoz" : "(nincs aktív epizód)"}
            </button>
          </div>
          {activeEncounter && (
            <p className="text-xs text-muted-foreground">Aktív epizód: <span className="font-mono">{activeEncounter.label}</span></p>
          )}
        </div>

        <div className="rounded-xl border border-border bg-card p-4 space-y-3">
          <h3 className="text-sm font-semibold">Javaslat</h3>
          <div className="rounded-md bg-muted/40 p-3 text-xs space-y-1">
            <div><b>HbA1c cél:</b> {result.hba1c_target}</div>
            <div><b>BMI:</b> {result.bmi.toFixed(1)} ({result.bmi_class})</div>
          </div>
          <Section title="Elsővonalbeli" items={result.first_line} tone="primary" />
          <Section title="Hozzáadandó / preferált" items={result.add_on} tone="accent" />
          <Section title="Kerülendő" items={result.avoid} tone="warn" />
        </div>
      </div>

      <div className="rounded-xl border border-border bg-card p-4">
        <h3 className="text-sm font-semibold mb-2">Részletes értelmezés (Markdown)</h3>
        <pre className="whitespace-pre-wrap text-xs font-mono bg-muted/30 p-3 rounded-md max-h-96 overflow-auto">{result.interpretation_md}</pre>
      </div>
    </div>
  );
}

function Num({ label, value, onChange, step }: { label: string; value: number; onChange: (v: number) => void; step: number }) {
  return (
    <label className="block">
      <span className="text-xs text-muted-foreground">{label}</span>
      <input type="number" step={step} value={value} onChange={(e) => onChange(Number(e.target.value))}
        className="mt-1 w-full px-2 py-1.5 text-sm rounded-md border border-border bg-background font-mono" />
    </label>
  );
}

function Chk({ label, value, onChange }: { label: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <label className="flex items-center gap-2 text-sm">
      <input type="checkbox" checked={value} onChange={(e) => onChange(e.target.checked)} />
      {label}
    </label>
  );
}

function Section({ title, items, tone }: { title: string; items: { drug: string; rationale: string; caution?: string }[]; tone: "primary" | "accent" | "warn" }) {
  const cls = tone === "warn" ? "border-amber-500/40 bg-amber-50/40" : tone === "accent" ? "border-primary/30 bg-primary/5" : "border-border bg-background";
  return (
    <div className={`rounded-md border ${cls} p-3`}>
      <div className="text-xs uppercase font-mono text-muted-foreground mb-1">{title}</div>
      {items.length === 0 ? <p className="text-xs text-muted-foreground">—</p> : (
        <ul className="space-y-1.5 text-sm">
          {items.map((it, i) => (
            <li key={i}>
              <div className="font-medium">{it.drug}</div>
              <div className="text-xs text-muted-foreground">{it.rationale}</div>
              {it.caution && <div className="text-xs text-amber-700 mt-0.5">⚠️ {it.caution}</div>}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
