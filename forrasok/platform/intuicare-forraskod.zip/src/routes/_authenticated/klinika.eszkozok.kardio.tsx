import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Heart } from "lucide-react";
import { CalculatorShell, Card, Field, NumberInput, ScoreBadge, Toggle } from "@/components/clinical/calc-shell";
import {
  scoreCHA2DS2VASc, scoreHasBled,
  type ChaInput, type HasBledInput, type Sex,
} from "@/lib/clinical/scores";

export const Route = createFileRoute("/_authenticated/klinika/eszkozok/kardio")({
  validateSearch: (s: Record<string, unknown>): { encounterId?: string; patientId?: string } => ({
    encounterId: typeof s.encounterId === "string" ? s.encounterId : undefined,
    patientId: typeof s.patientId === "string" ? s.patientId : undefined,
  }),
  component: KardioPage,
});

function KardioPage() {
  const [tab, setTab] = useState<"cha" | "hasbled">("cha");
  const [cha, setCha] = useState<ChaInput>({ age: 70, sex: "M", chf: false, hypertension: false, diabetes: false, stroke_tia_te: false, vascular: false });
  const [hb, setHb] = useState<HasBledInput>({
    hypertension_uncontrolled: false, renal_abnormal: false, liver_abnormal: false, stroke_history: false,
    bleeding_history: false, labile_inr: false, age65_plus: false, drugs_antiplatelet_nsaid: false, alcohol_8plus_per_week: false,
  });

  const chaR = useMemo(() => scoreCHA2DS2VASc(cha), [cha]);
  const hbR = useMemo(() => scoreHasBled(hb), [hb]);

  return (
    <CalculatorShell
      title="Pitvarfibrilláció — CHA₂DS₂-VASc & HAS-BLED"
      subtitle="Stroke- és vérzéskockázat NVAF-ben (ESC 2024)."
      Icon={Heart}
      fromRoute="/_authenticated/klinika/eszkozok/kardio"
      onReset={() => {
        setCha({ age: 70, sex: "M", chf: false, hypertension: false, diabetes: false, stroke_tia_te: false, vascular: false });
        setHb({ hypertension_uncontrolled: false, renal_abnormal: false, liver_abnormal: false, stroke_history: false, bleeding_history: false, labile_inr: false, age65_plus: false, drugs_antiplatelet_nsaid: false, alcohol_8plus_per_week: false });
      }}
      getSaveBundle={() => tab === "cha"
        ? { calculator: "cha2ds2_vasc", inputs: cha, outputs: chaR,
            interpretation_md: `**CHA₂DS₂-VASc:** ${chaR.score} pont · becsült éves stroke-rizikó ${chaR.annualStrokePct}%\n\n${chaR.recommendation}` }
        : { calculator: "has_bled", inputs: hb, outputs: hbR,
            interpretation_md: `**HAS-BLED:** ${hbR.score} pont (${hbR.riskLabel}) · éves vérzés ≈ ${hbR.annualBleedPct}%\n\n${hbR.note}` }}
    >
      <div className="flex gap-2 border-b border-border">
        <TabBtn active={tab === "cha"} onClick={() => setTab("cha")}>CHA₂DS₂-VASc</TabBtn>
        <TabBtn active={tab === "hasbled"} onClick={() => setTab("hasbled")}>HAS-BLED</TabBtn>
      </div>

      {tab === "cha" ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Card title="Bemenetek">
            <div className="grid grid-cols-2 gap-3">
              <Field label="Életkor (év)"><NumberInput value={cha.age} onChange={(v) => setCha({ ...cha, age: v ?? 0 })} /></Field>
              <Field label="Nem">
                <select value={cha.sex} onChange={(e) => setCha({ ...cha, sex: e.target.value as Sex })} className="w-full px-2 py-1.5 text-sm rounded-md border border-border bg-background">
                  <option value="M">Férfi</option><option value="F">Nő</option>
                </select>
              </Field>
            </div>
            <Toggle checked={cha.chf} onChange={(v) => setCha({ ...cha, chf: v })} label="Pangásos szívelégtelenség / LVEF ≤ 40%" />
            <Toggle checked={cha.hypertension} onChange={(v) => setCha({ ...cha, hypertension: v })} label="Hipertónia" />
            <Toggle checked={cha.diabetes} onChange={(v) => setCha({ ...cha, diabetes: v })} label="Diabétesz" />
            <Toggle checked={cha.stroke_tia_te} onChange={(v) => setCha({ ...cha, stroke_tia_te: v })} label="Korábbi stroke / TIA / thromboembolia (2 pont)" />
            <Toggle checked={cha.vascular} onChange={(v) => setCha({ ...cha, vascular: v })} label="Érbetegség (MI, PAD, aorta plakk)" />
          </Card>
          <Card title="Eredmény" footer={chaR.recommendation}>
            <ScoreBadge score={chaR.score} label="pont" tone={chaR.score >= 2 ? "warn" : "ok"} />
            <div className="text-sm">Becsült éves stroke-rizikó: <span className="font-mono font-semibold">{chaR.annualStrokePct}%</span></div>
            <ul className="text-sm space-y-1 mt-2">
              {chaR.parts.map((p) => (
                <li key={p.label} className="flex items-center justify-between border-b border-border/50 py-1">
                  <span>{p.label}</span><span className="font-mono">{p.pts}</span>
                </li>
              ))}
              {chaR.parts.length === 0 && <li className="text-muted-foreground italic">0 pont</li>}
            </ul>
          </Card>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Card title="Rizikófaktorok">
            {[
              ["hypertension_uncontrolled", "Kontrollálatlan hipertónia (SBP > 160)"],
              ["renal_abnormal", "Vesefunkció zavar (dialízis / transzplant / kreat > 200 µmol/L)"],
              ["liver_abnormal", "Májfunkció zavar (krón. hepatopathia / kóros enzimek)"],
              ["stroke_history", "Korábbi stroke"],
              ["bleeding_history", "Korábbi vérzés vagy hajlam"],
              ["labile_inr", "Labilis INR (VKA mellett, TTR < 60%)"],
              ["age65_plus", "Életkor > 65 év"],
              ["drugs_antiplatelet_nsaid", "TAG vagy NSAID gyógyszerelés"],
              ["alcohol_8plus_per_week", "Alkohol ≥ 8 ital/hét"],
            ].map(([k, label]) => (
              <Toggle key={k} checked={(hb as any)[k]} onChange={(v) => setHb({ ...hb, [k]: v } as HasBledInput)} label={label} />
            ))}
          </Card>
          <Card title="Eredmény" footer={hbR.note}>
            <ScoreBadge score={hbR.score} label={`pont · ${hbR.riskLabel}`} tone={hbR.score >= 3 ? "danger" : hbR.score >= 2 ? "warn" : "ok"} />
            <div className="text-sm">Becsült éves súlyos vérzés: <span className="font-mono font-semibold">≈ {hbR.annualBleedPct}%</span></div>
          </Card>
        </div>
      )}
    </CalculatorShell>
  );
}

function TabBtn({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button onClick={onClick} className={`px-4 py-2 text-sm font-medium border-b-2 -mb-px ${active ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"}`}>
      {children}
    </button>
  );
}
