import { createFileRoute, useNavigate, redirect } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { useAuth } from "@/hooks/use-auth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import {
  AlertTriangle,
  CalendarClock,
  Clock,
  Stethoscope,
  Users,
  CalendarRange,
  Building2,
} from "lucide-react";
import { Link } from "@tanstack/react-router";

export const Route = createFileRoute("/_authenticated/dashboard")({
  beforeLoad: () => {
    throw redirect({ to: "/iranyitopult" });
  },
  component: Dashboard,
});

function Dashboard() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [profile, setProfile] = useState<{
    teljes_nev: string;
    tenant_id: string | null;
  } | null>(null);
  const [tenantName, setTenantName] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);
  const [newTenant, setNewTenant] = useState("");

  useEffect(() => {
    if (!user) return;
    void (async () => {
      const { data } = await supabase
        .from("profiles")
        .select("teljes_nev, tenant_id")
        .eq("id", user.id)
        .maybeSingle();
      setProfile(data);
      if (data?.tenant_id) {
        const { data: tenant } = await supabase
          .from("tenants")
          .select("nev")
          .eq("id", data.tenant_id)
          .maybeSingle();
        setTenantName(tenant?.nev ?? null);
      }
    })();
  }, [user]);

  async function createTenant(e: React.FormEvent) {
    e.preventDefault();
    if (!user || !newTenant.trim()) return;
    setCreating(true);
    try {
      // 1) Tenant létrehozása (anon tud, RLS-en ez nyitva van — service role nélkül,
      //    mert még nem tartozik tenanthoz a user). A multi-tenant onboarding-hoz
      //    a tenants INSERT-re nincs WITH CHECK megkötés, így megengedett a saját tenant.
      const { data: tenant, error: tenantErr } = await supabase
        .from("tenants")
        .insert({ nev: newTenant.trim() })
        .select("id")
        .single();
      if (tenantErr) throw tenantErr;

      // 2) Profile frissítése a tenant_id-vel
      const { error: profErr } = await supabase
        .from("profiles")
        .update({ tenant_id: tenant.id })
        .eq("id", user.id);
      if (profErr) throw profErr;

      // 3) tenant_admin szerepkör megadása az alapítónak
      const { data: adminRole } = await supabase
        .from("roles")
        .select("id")
        .eq("kulcs", "tenant_admin")
        .single();
      if (adminRole) {
        await supabase
          .from("user_roles")
          .insert({ tenant_id: tenant.id, user_id: user.id, role_id: adminRole.id });
      }

      toast.success("Bérlő létrehozva.");
      window.location.reload();
    } catch (err) {
      toast.error(
        `Sikertelen létrehozás: ${err instanceof Error ? err.message : String(err)}`,
      );
    } finally {
      setCreating(false);
    }
  }

  // ONBOARDING: nincs tenant_id
  if (profile && !profile.tenant_id) {
    return (
      <div className="p-8 max-w-2xl">
        <h1 className="text-2xl font-bold tracking-tight mb-2">
          {t("onboarding.title")}
        </h1>
        <p className="text-sm text-muted-foreground mb-6">{t("onboarding.subtitle")}</p>

        <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
          <h2 className="text-sm font-mono uppercase text-muted-foreground mb-4">
            {t("onboarding.create_tenant")}
          </h2>
          <form onSubmit={createTenant} className="space-y-3">
            <div>
              <label className="text-xs font-mono font-semibold uppercase text-muted-foreground block mb-1">
                {t("onboarding.tenant_name")}
              </label>
              <input
                type="text"
                value={newTenant}
                onChange={(e) => setNewTenant(e.target.value)}
                placeholder="Pl. Szent Margit Klinika-csoport"
                required
                className="w-full px-3 py-2 bg-background border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>
            <button
              type="submit"
              disabled={creating}
              className="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-semibold hover:bg-primary/90 transition-colors disabled:opacity-50"
            >
              {t("onboarding.create")}
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">
          {t("dashboard.welcome")}, {profile?.teljes_nev ?? user?.email}
        </h1>
        {tenantName && (
          <p className="text-sm text-muted-foreground font-mono mt-1 uppercase tracking-wider">
            {tenantName}
          </p>
        )}
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-card p-5 rounded-xl border border-border flex flex-col justify-between">
          <p className="text-xs font-mono text-muted-foreground uppercase flex items-center gap-2">
            <Clock className="size-3.5" />
            {t("dashboard.heti_oraketet")}
          </p>
          <div className="mt-4 flex items-baseline gap-2">
            <span className="text-3xl font-bold tracking-tight">0</span>
            <span className="text-muted-foreground text-sm">
              {t("dashboard.heti_oraketet_sub", { limit: 60 })}
            </span>
          </div>
          <div className="w-full h-1.5 bg-secondary rounded-full mt-4 overflow-hidden">
            <div className="w-0 h-full bg-primary transition-all" />
          </div>
        </div>

        <div className="bg-card p-5 rounded-xl border border-border">
          <p className="text-xs font-mono text-muted-foreground uppercase flex items-center gap-2">
            <CalendarClock className="size-3.5" />
            {t("dashboard.kovetkezo_ugyelet")}
          </p>
          <p className="mt-4 text-sm text-muted-foreground italic">
            {t("dashboard.nincs_ugyelet")}
          </p>
        </div>

        <div className="bg-card p-5 rounded-xl border border-border ring-1 ring-success/20">
          <p className="text-xs font-mono text-success uppercase font-bold flex items-center gap-2">
            <AlertTriangle className="size-3.5" />
            {t("dashboard.figyelmeztetes")}
          </p>
          <p className="mt-3 text-sm font-medium">{t("dashboard.minden_rendben")}</p>
        </div>
      </div>

      {/* Quick actions */}
      <div>
        <h2 className="text-sm font-mono text-muted-foreground uppercase mb-4 flex items-center gap-2">
          {t("dashboard.quick_actions")}
          <span className="h-px flex-1 bg-border" />
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <QuickLink to="/admin/szervezet" icon={Building2} label={t("nav.admin_szervezet")} />
          <QuickLink to="/csapat" icon={Users} label={t("nav.csapat")} />
          <QuickLink to="/beosztas" icon={CalendarRange} label={t("nav.beosztas")} />
          <QuickLink to="/paciensek" icon={Stethoscope} label={t("nav.paciensek")} />
        </div>
      </div>
    </div>
  );
}

function QuickLink({
  to,
  icon: Icon,
  label,
}: {
  to: string;
  icon: typeof Building2;
  label: string;
}) {
  return (
    <Link
      to={to}
      className="bg-card border border-border rounded-xl p-5 hover:border-primary/40 hover:shadow-sm transition-all flex items-center gap-3 group"
    >
      <div className="size-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
        <Icon className="size-5" />
      </div>
      <span className="font-semibold text-sm">{label}</span>
    </Link>
  );
}
