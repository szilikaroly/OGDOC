/**
 * Heti foglalási sablon szerkesztő + slot-generálás.
 */
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { listResources, upsertTemplate, generateSlots } from "@/lib/booking/booking.functions";

const NAPOK = [
  { iso: 1, nev: "H" }, { iso: 2, nev: "K" }, { iso: 3, nev: "Sze" },
  { iso: 4, nev: "Cs" }, { iso: 5, nev: "P" }, { iso: 6, nev: "Szo" }, { iso: 7, nev: "V" },
];

function todayISO(off = 0) { const d = new Date(); d.setDate(d.getDate() + off); return d.toISOString().slice(0, 10); }

function SablonokPage() {
  const fetchRes = useServerFn(listResources);
  const upsertFn = useServerFn(upsertTemplate);
  const genFn = useServerFn(generateSlots);
  const resQ = useQuery({ queryKey: ["appt-resources"], queryFn: () => fetchRes() });

  const [form, setForm] = useState({
    resource_id: "",
    nev: "Heti rendelés",
    napok: [1, 2, 3, 4, 5] as number[],
    kezd_ido: "08:00",
    veg_ido: "16:00",
    slot_perc: 20,
    kapacitas: 1,
    ervenyes_tol: todayISO(),
    ervenyes_ig: todayISO(90),
    unnepnap_uzemel: false,
    aktiv: true,
  });
  const [lastTemplateId, setLastTemplateId] = useState<string | null>(null);
  const [genFrom, setGenFrom] = useState(todayISO());
  const [genTo, setGenTo] = useState(todayISO(30));

  const saveM = useMutation({
    mutationFn: () => upsertFn({ data: form }),
    onSuccess: (row: any) => { setLastTemplateId(row.id); toast.success("Sablon mentve."); },
    onError: (e: Error) => toast.error(e.message),
  });

  const genM = useMutation({
    mutationFn: () => genFn({ data: { template_id: lastTemplateId!, from: genFrom, to: genTo } }),
    onSuccess: (r: any) => toast.success(`${r.inserted} slot létrehozva.`),
    onError: (e: Error) => toast.error(e.message),
  });

  function toggleNap(iso: number) {
    setForm((f) => ({
      ...f,
      napok: f.napok.includes(iso) ? f.napok.filter((n) => n !== iso) : [...f.napok, iso].sort(),
    }));
  }

  return (
    <main className="container mx-auto px-4 py-8">
      <Link to="/idopontok" className="text-sm text-primary hover:underline">← Vissza az időpontokhoz</Link>
      <h1 className="mb-6 mt-2 text-2xl font-bold">Sablonok és slot-generálás</h1>

      <Card>
        <CardHeader><CardTitle className="text-base">1. Heti sablon</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>Erőforrás</Label>
            <select className="h-9 w-full rounded-md border bg-background px-2 text-sm"
              value={form.resource_id} onChange={(e) => setForm({ ...form, resource_id: e.target.value })}>
              <option value="">— Válasszon —</option>
              {resQ.data?.map((r) => <option key={r.id} value={r.id}>{r.nev} ({r.tipus})</option>)}
            </select>
          </div>
          <div><Label>Sablon neve</Label><Input value={form.nev} onChange={(e) => setForm({ ...form, nev: e.target.value })} /></div>
          <div>
            <Label>Napok</Label>
            <div className="flex gap-1">
              {NAPOK.map((n) => (
                <Button key={n.iso} type="button" size="sm"
                  variant={form.napok.includes(n.iso) ? "default" : "outline"}
                  onClick={() => toggleNap(n.iso)}>{n.nev}</Button>
              ))}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Kezdő idő</Label><Input type="time" value={form.kezd_ido} onChange={(e) => setForm({ ...form, kezd_ido: e.target.value })} /></div>
            <div><Label>Záró idő</Label><Input type="time" value={form.veg_ido} onChange={(e) => setForm({ ...form, veg_ido: e.target.value })} /></div>
            <div><Label>Slot hossza (perc)</Label><Input type="number" min={5} max={240} value={form.slot_perc} onChange={(e) => setForm({ ...form, slot_perc: Number(e.target.value) })} /></div>
            <div><Label>Kapacitás</Label><Input type="number" min={1} value={form.kapacitas} onChange={(e) => setForm({ ...form, kapacitas: Number(e.target.value) })} /></div>
            <div><Label>Érvényes -tól</Label><Input type="date" value={form.ervenyes_tol} onChange={(e) => setForm({ ...form, ervenyes_tol: e.target.value })} /></div>
            <div><Label>Érvényes -ig</Label><Input type="date" value={form.ervenyes_ig} onChange={(e) => setForm({ ...form, ervenyes_ig: e.target.value })} /></div>
          </div>
          <Button onClick={() => saveM.mutate()} disabled={!form.resource_id || saveM.isPending}>
            {saveM.isPending ? "Mentés…" : "Sablon mentése"}
          </Button>
        </CardContent>
      </Card>

      <Card className="mt-4">
        <CardHeader><CardTitle className="text-base">2. Slot-generálás (mentett sablonra)</CardTitle></CardHeader>
        <CardContent className="flex flex-wrap items-end gap-3">
          <div><Label>Ettől</Label><Input type="date" value={genFrom} onChange={(e) => setGenFrom(e.target.value)} /></div>
          <div><Label>Eddig</Label><Input type="date" value={genTo} onChange={(e) => setGenTo(e.target.value)} /></div>
          <Button disabled={!lastTemplateId || genM.isPending} onClick={() => genM.mutate()}>
            {genM.isPending ? "Generálás…" : "Slotok generálása"}
          </Button>
          {!lastTemplateId && <p className="text-xs text-muted-foreground">Először mentsen sablont.</p>}
        </CardContent>
      </Card>
    </main>
  );
}

export const Route = createFileRoute("/_authenticated/idopontok/sablonok")({
  component: SablonokPage,
  head: () => ({ meta: [{ title: "Foglalási sablonok" }] }),
  errorComponent: ({ error, reset }) => (
    <div className="p-6"><p className="text-destructive">{error.message}</p><Button onClick={reset}>Újra</Button></div>
  ),
  notFoundComponent: () => <div className="p-6">Nem található</div>,
});
