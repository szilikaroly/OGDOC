import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useMemo, useState } from "react";
import {
  DndContext,
  DragOverlay,
  PointerSensor,
  useDraggable,
  useDroppable,
  useSensor,
  useSensors,
  type DragEndEvent,
} from "@dnd-kit/core";
import {
  SortableContext,
  useSortable,
  arrayMove,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { AlertTriangle, Calendar, Clock, GripVertical, Lock, Siren, Sparkles, Loader2, Users } from "lucide-react";
import { listBoard, bookCaseToBlock, triggerEmergency, releaseBlock } from "@/lib/or/board.functions";
import { previewEligibility, type EligibilityMap } from "@/lib/or/ai-suggest.functions";
import { reorderBlockCases, aiOrderBlockCases, aiAutoSchedule } from "@/lib/or/sequence.functions";
import { AiOrderPreviewDialog } from "@/components/or/AiOrderPreviewDialog";
import { CreateBlockDialog } from "@/components/or/CreateBlockDialog";
import { TeamPlannerDialog } from "@/components/or/TeamPlannerDialog";
import { AiSuggestionsPanel } from "@/components/or/AiSuggestionsPanel";
import { CascadeReplanPanel } from "@/components/or/CascadeReplanPanel";
import { OrConflictsPanel } from "@/components/or/OrConflictsPanel";
import { usePermissions } from "@/hooks/use-permissions";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { RouteErrorBoundary } from "@/lib/errors/route-boundaries";

export const Route = createFileRoute("/_authenticated/muteti-terv/blokkok")({
  component: OrBoardPage,
  errorComponent: RouteErrorBoundary,
  head: () => ({ meta: [{ title: "Műtéti blokk-naptár" }] }),
});

type Block = Awaited<ReturnType<typeof listBoard>>["blocks"][number];
type Room = Awaited<ReturnType<typeof listBoard>>["rooms"][number];
type SurgeryCase = {
  id: string;
  patient_id: string | null;
  surgery_type_id: string | null;
  becsult_idotartam_perc: number | null;
  prioritas: string | null;
  statusz?: string | null;
  or_block_id?: string | null;
};

const TYPE_COLOR: Record<string, string> = {
  altalanos: "bg-secondary",
  szuloszoba: "bg-pink-500/20",
  egynapos_kismuteti: "bg-blue-500/20",
  onkosebeszet: "bg-orange-500/20",
  reproduktiv: "bg-emerald-500/20",
  hibrid: "bg-purple-500/20",
  lezer: "bg-red-500/20",
  robot: "bg-indigo-500/20",
};

function todayIso() {
  return new Date().toISOString().slice(0, 10);
}

function OrBoardPage() {
  const { can, canReal, loading: permLoading } = usePermissions();
  const [date, setDate] = useState<string>(todayIso());
  const [createBlockOpen, setCreateBlockOpen] = useState(false);
  const [teamPlannerOpen, setTeamPlannerOpen] = useState(false);
  const qc = useQueryClient();
  const list = useServerFn(listBoard);
  const book = useServerFn(bookCaseToBlock);
  const emerg = useServerFn(triggerEmergency);
  const release = useServerFn(releaseBlock);

  const { data, isLoading } = useQuery({
    queryKey: ["or-board", date],
    queryFn: () => list({ data: { date, suiteId: null } }),
  });

  // realtime invalidation
  useEffect(() => {
    const channel = supabase
      .channel(`or-board-${date}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "surgery_cases" }, () =>
        qc.invalidateQueries({ queryKey: ["or-board", date] }),
      )
      .on("postgres_changes", { event: "*", schema: "public", table: "or_blocks" }, () =>
        qc.invalidateQueries({ queryKey: ["or-board", date] }),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [date, qc]);

  const bookMut = useMutation({
    mutationFn: (input: { caseId: string; blockId: string }) =>
      book({ data: { caseId: input.caseId, blockId: input.blockId } }),
    onSuccess: () => {
      toast.success("Eset blokkba helyezve");
      qc.invalidateQueries({ queryKey: ["or-board", date] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const emergMut = useMutation({
    mutationFn: (caseId: string) => emerg({ data: { caseId } }),
    onSuccess: () => toast.success("Sürgősségi push elindítva"),
    onError: (e: Error) => toast.error(e.message),
  });

  const releaseMut = useMutation({
    mutationFn: (blockId: string) => release({ data: { blockId } }),
    onSuccess: () => {
      toast.success("Blokk felszabadítva");
      qc.invalidateQueries({ queryKey: ["or-board", date] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const reorder = useServerFn(reorderBlockCases);
  const aiOrder = useServerFn(aiOrderBlockCases);
  const reorderMut = useMutation({
    mutationFn: (input: { blockId: string; orderedCaseIds: string[] }) =>
      reorder({ data: input }),
    onSuccess: () => {
      toast.success("Sorrend mentve");
      qc.invalidateQueries({ queryKey: ["or-board", date] });
    },
    onError: (e: Error) => toast.error(e.message),
  });
  const [aiPendingBlockId, setAiPendingBlockId] = useState<string | null>(null);
  const [previewBlockId, setPreviewBlockId] = useState<string | null>(null);
  const [previewOrder, setPreviewOrder] = useState<string[]>([]);
  const [previewRationale, setPreviewRationale] = useState<string>("");

  const aiPreviewMut = useMutation({
    mutationFn: async (blockId: string) => {
      setAiPendingBlockId(blockId);
      setPreviewBlockId(blockId);
      setPreviewOrder([]);
      setPreviewRationale("");
      const res = await aiOrder({ data: { blockId } });
      return res;
    },
    onSuccess: (res) => {
      setAiPendingBlockId(null);
      setPreviewOrder(res.orderedCaseIds);
      setPreviewRationale(res.rationale);
    },
    onError: (e: Error) => {
      setAiPendingBlockId(null);
      setPreviewBlockId(null);
      toast.error(e.message);
    },
  });

  const autoSchedule = useServerFn(aiAutoSchedule);
  const autoMut = useMutation({
    mutationFn: (d: string) => autoSchedule({ data: { date: d } }),
    onSuccess: (res) => {
      qc.invalidateQueries({ queryKey: ["or-board", date] });
      if (res.applied === 0) {
        toast.info("Nincs új beosztás", { description: res.rationale || "Nem található alkalmas párosítás." });
      } else {
        toast.success(`${res.applied} eset beosztva`, {
          description: res.skipped.length > 0 ? `${res.skipped.length} kihagyva. ${res.rationale}` : res.rationale,
        });
      }
    },
    onError: (e: Error) => toast.error(e.message),
  });


  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 4 } }));
  const [draggingCase, setDraggingCase] = useState<SurgeryCase | null>(null);
  const [eligibility, setEligibility] = useState<EligibilityMap>({});
  const preview = useServerFn(previewEligibility);

  const blocksByRoom = useMemo(() => {
    const map = new Map<string, Block[]>();
    for (const b of data?.blocks ?? []) {
      const arr = map.get(b.org_unit_id) ?? [];
      arr.push(b);
      map.set(b.org_unit_id, arr);
    }
    return map;
  }, [data?.blocks]);

  const casesByBlock = useMemo(() => {
    const map = new Map<string, SurgeryCase[]>();
    for (const c of data?.cases ?? []) {
      if (!c.or_block_id) continue;
      const arr = map.get(c.or_block_id) ?? [];
      arr.push(c);
      map.set(c.or_block_id, arr);
    }
    return map;
  }, [data?.cases]);

  if (permLoading) return <div className="p-8 text-sm text-muted-foreground">Jogosultságok betöltése…</div>;
  if (!canReal("view_or_board")) {
    return (
      <div className="p-8">
        <div className="inline-flex items-center gap-2 rounded-md border border-border bg-card px-4 py-3 text-sm">
          <Lock className="size-4" />
          Nincs jogosultsága a műtéti naptár megtekintéséhez.
        </div>
      </div>
    );
  }

  function onDragEnd(e: DragEndEvent) {
    setDraggingCase(null);
    const activeId = String(e.active.id);
    const overId = e.over?.id ? String(e.over.id) : null;
    if (!overId) return;

    const activeData = e.active.data?.current as { type?: string; blockId?: string } | undefined;
    const overData = e.over?.data?.current as { type?: string; blockId?: string } | undefined;

    // Reorder within the same block
    if (activeData?.type === "block-case") {
      const blockId = activeData.blockId!;
      const current = (data?.cases ?? [])
        .filter((c) => c.or_block_id === blockId)
        .map((c) => c.id);
      const fromIdx = current.indexOf(activeId);
      if (fromIdx < 0) return;

      let toIdx = -1;
      if (overData?.type === "block-case" && overData.blockId === blockId) {
        toIdx = current.indexOf(overId);
      } else if (overId === blockId) {
        // dropped on the block container (not on another case) → move to end
        toIdx = current.length - 1;
      } else {
        return; // dropped elsewhere — ignore (no cross-block reorder yet)
      }
      if (toIdx < 0 || toIdx === fromIdx) return;
      const ordered = arrayMove(current, fromIdx, toIdx);
      reorderMut.mutate({ blockId, orderedCaseIds: ordered });
      return;
    }

    // Waitlist → block
    bookMut.mutate({ caseId: activeId, blockId: overId });
  }

  return (
    <div className="p-6 space-y-6">
      <header className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <Calendar className="size-5" /> Műtéti blokk-naptár
          </h1>
          <p className="mt-1 text-xs font-mono text-muted-foreground uppercase tracking-wider">
            Drag &amp; drop a várólistából egy blokkra · jogosultság-ellenőrzés szerver-oldalon
          </p>
        </div>
        <div className="flex items-center gap-3">
          {can("book_or_case") && (() => {
            const hasBlocks = (data?.blocks ?? []).length > 0;
            const disabled = autoMut.isPending || !hasBlocks;
            return (
              <button
                type="button"
                onClick={() => {
                  if (!hasBlocks) {
                    toast.warning("Nincs aktív blokk erre a napra", {
                      description: "Hozzon létre egy műtéti blokkot, mielőtt az automata beosztást futtatja.",
                    });
                    return;
                  }
                  autoMut.mutate(date);
                }}
                disabled={disabled}
                title={!hasBlocks ? "Nincs aktív blokk erre a napra" : undefined}
                className="h-9 inline-flex items-center gap-2 rounded-md bg-primary px-3 text-sm font-semibold text-primary-foreground hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {autoMut.isPending ? <Loader2 className="size-4 animate-spin" /> : <Sparkles className="size-4" />}
                Automata beosztás
              </button>
            );
          })()}
          {can("book_or_case") && (
            <button
              type="button"
              onClick={() => setTeamPlannerOpen(true)}
              className="h-9 inline-flex items-center gap-2 rounded-md border border-border bg-card px-3 text-sm font-semibold hover:bg-secondary"
              title="Csapat-beosztás generálása az adott napra"
            >
              <Users className="size-4" /> Csapat beosztás
            </button>
          )}
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="h-9 rounded-md border border-border bg-card px-3 text-sm"
          />
        </div>
      </header>

      {can("book_or_case") && (data?.blocks ?? []).length === 0 && !isLoading && (
        <div className="rounded-md border border-warning/40 bg-warning/10 px-3 py-2 text-xs flex items-center gap-2 flex-wrap">
          <AlertTriangle className="size-3.5 text-warning" />
          <span className="flex-1 min-w-[200px]">
            Nincs aktív műtéti blokk erre a napra — az automata beosztás csak meglévő blokkokba tud esetet sorolni.
          </span>
          <button
            type="button"
            onClick={() => setCreateBlockOpen(true)}
            className="h-7 inline-flex items-center gap-1.5 rounded-md bg-warning px-2.5 text-xs font-semibold text-warning-foreground hover:opacity-90"
          >
            Blokk létrehozása
          </button>
        </div>
      )}



      {!can("book_or_case") && (
        <div className="rounded-md border border-warning/40 bg-warning/10 px-3 py-2 text-xs flex items-center gap-2">
          <AlertTriangle className="size-3.5 text-warning" />
          Csak megtekintési joga van. Az áthelyezés és előjegyzés tiltva.
        </div>
      )}

      <DndContext
        sensors={sensors}
        onDragStart={(e) => {
          const c = (data?.waitlist ?? []).find((w) => w.id === String(e.active.id))
            ?? (data?.cases ?? []).find((w) => w.id === String(e.active.id));
          setDraggingCase(c ?? null);
          if (c) {
            preview({ data: { caseId: c.id, date } })
              .then(setEligibility)
              .catch(() => setEligibility({}));
          }
        }}
        onDragEnd={(e) => {
          setEligibility({});
          onDragEnd(e);
        }}
        onDragCancel={() => setEligibility({})}
      >
        <OrConflictsPanel date={date} />
        <div className="grid grid-cols-[260px_1fr_320px] gap-4 mt-4">
          {/* Waitlist */}
          <aside className="space-y-2">
            <h2 className="text-xs font-mono uppercase tracking-wider text-muted-foreground">
              Várólista ({data?.waitlist.length ?? 0})
            </h2>
            <div className="space-y-2 max-h-[70vh] overflow-y-auto pr-1">
              {(data?.waitlist ?? []).map((c) => (
                <CaseCard
                  key={c.id}
                  c={c}
                  draggable={can("book_or_case")}
                  onEmergency={can("trigger_or_emergency") ? () => emergMut.mutate(c.id) : undefined}
                />
              ))}
              {(data?.waitlist?.length ?? 0) === 0 && (
                <div className="text-xs text-muted-foreground italic">Üres várólista.</div>
              )}
            </div>
          </aside>

          {/* Rooms */}
          <div className="overflow-x-auto">
            {isLoading ? (
              <div className="text-sm text-muted-foreground">Betöltés…</div>
            ) : (
              <div className="flex gap-3 min-w-max">
                {(data?.rooms ?? []).map((room) => (
                  <RoomColumn
                    key={room.id}
                    room={room}
                    blocks={blocksByRoom.get(room.org_unit_id ?? "") ?? []}
                    casesByBlock={casesByBlock}
                    canManage={can("manage_or_blocks")}
                    canBook={can("book_or_case")}
                    onRelease={(blockId) => releaseMut.mutate(blockId)}
                    onAiOrder={(blockId) => aiPreviewMut.mutate(blockId)}
                    aiPendingBlockId={aiPendingBlockId}
                    eligibility={eligibility}
                    isDragging={!!draggingCase}
                  />
                ))}
                {(data?.rooms?.length ?? 0) === 0 && (
                  <div className="text-sm text-muted-foreground italic px-4 py-8">
                    Nincs még műtő-profil felvéve. (Admin → Szervezet)
                  </div>
                )}
              </div>
            )}
          </div>

          <AiSuggestionsPanel
            date={date}
            canBook={can("book_or_case")}
            canManage={can("manage_or_blocks")}
            onApplied={() => qc.invalidateQueries({ queryKey: ["or-board", date] })}
          />

          <CascadeReplanPanel
            date={date}
            canApply={can("manage_or_blocks") || can("book_or_case")}
            onApplied={() => qc.invalidateQueries({ queryKey: ["or-board", date] })}
          />

        </div>

        <DragOverlay>{draggingCase ? <CaseCard c={draggingCase} draggable={false} /> : null}</DragOverlay>
      </DndContext>

      {previewBlockId && (() => {
        const block = (data?.blocks ?? []).find((b) => b.id === previewBlockId);
        const blockCases = (data?.cases ?? []).filter((c) => c.or_block_id === previewBlockId);
        const room = (data?.rooms ?? []).find((r) => r.org_unit_id === block?.org_unit_id);
        return (
          <AiOrderPreviewDialog
            open={!!previewBlockId}
            loading={aiPendingBlockId === previewBlockId}
            applying={reorderMut.isPending}
            blockStart={block?.kezdo_ido ?? null}
            blockEnd={block?.veg_ido ?? null}
            turnoverMin={room?.fordulo_ido_perc ?? 15}
            currentCases={blockCases}
            proposedOrder={previewOrder}
            rationale={previewRationale}
            onCancel={() => setPreviewBlockId(null)}
            onApply={() => {
              reorderMut.mutate(
                { blockId: previewBlockId, orderedCaseIds: previewOrder },
                { onSuccess: () => setPreviewBlockId(null) },
              );
            }}
          />
        );
      })()}

      <CreateBlockDialog
        open={createBlockOpen}
        onOpenChange={setCreateBlockOpen}
        date={date}
      />

      <TeamPlannerDialog
        open={teamPlannerOpen}
        onOpenChange={setTeamPlannerOpen}
        date={date}
      />
    </div>

  );
}

function CaseCard({
  c,
  draggable,
  onEmergency,
}: {
  c: SurgeryCase;
  draggable: boolean;
  onEmergency?: () => void;
}) {
  const { attributes, listeners, setNodeRef, isDragging } = useDraggable({
    id: c.id,
    disabled: !draggable,
  });

  return (
    <div
      ref={setNodeRef}
      {...(draggable ? attributes : {})}
      {...(draggable ? listeners : {})}
      className={cn(
        "rounded-md border border-border bg-card p-2.5 text-xs space-y-1 transition-shadow touch-none select-none",
        draggable && "cursor-grab active:cursor-grabbing hover:shadow-sm",
        isDragging && "opacity-40",
        c.prioritas === "azonnali" && "border-destructive ring-1 ring-destructive/30",
        c.prioritas === "sürgos" && "border-warning",
      )}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-1.5 min-w-0">
          {draggable && (
            <span className="text-muted-foreground/60 shrink-0">
              <GripVertical className="size-3" />
            </span>
          )}
          <span className="font-semibold truncate">#{c.id.slice(0, 6)}</span>
        </div>
        <span
          className={cn(
            "text-[10px] font-mono uppercase shrink-0 px-1.5 py-0.5 rounded",
            c.prioritas === "azonnali" && "bg-destructive text-destructive-foreground",
            c.prioritas === "sürgos" && "bg-warning/20 text-warning-foreground",
            (!c.prioritas || c.prioritas === "elektiv") && "bg-secondary text-muted-foreground",
          )}
        >
          {c.prioritas ?? "elektiv"}
        </span>
      </div>
      <div className="flex items-center gap-1 text-[10px] font-mono text-muted-foreground">
        <Clock className="size-3" /> {c.becsult_idotartam_perc} perc
      </div>
      {onEmergency && c.prioritas !== "azonnali" && (
        <button
          type="button"
          onClick={onEmergency}
          className="mt-1 w-full inline-flex items-center justify-center gap-1 text-[10px] font-bold uppercase tracking-wider bg-destructive/10 text-destructive hover:bg-destructive hover:text-destructive-foreground rounded px-2 py-1 transition-colors"
        >
          <Siren className="size-3" /> Sürgős → push
        </button>
      )}
    </div>
  );
}

function RoomColumn({
  room,
  blocks,
  casesByBlock,
  canManage,
  canBook,
  onRelease,
  onAiOrder,
  aiPendingBlockId,
  eligibility,
  isDragging,
}: {
  room: Room;
  blocks: Block[];
  casesByBlock: Map<string, SurgeryCase[]>;
  canManage: boolean;
  canBook: boolean;
  onRelease: (blockId: string) => void;
  onAiOrder: (blockId: string) => void;
  aiPendingBlockId: string | null;
  eligibility: EligibilityMap;
  isDragging: boolean;
}) {
  return (
    <div className="w-64 shrink-0 border border-border rounded-lg bg-background">
      <div className={cn("p-2.5 border-b border-border rounded-t-lg", TYPE_COLOR[room.tipus] ?? "bg-secondary")}>
        <div className="text-xs font-bold uppercase tracking-wider truncate">
          {room.tipus.replace(/_/g, " ")}
          {room.tartalek && <span className="ml-1 text-[10px] font-mono">(tartalék)</span>}
        </div>
        <div className="text-[10px] font-mono text-muted-foreground">
          {room.napi_kezdo_ido?.slice(0, 5)}–{room.napi_veg_ido?.slice(0, 5)} · turnover {room.fordulo_ido_perc}p
        </div>
      </div>
      <div className="p-2 space-y-2 min-h-[200px]">
        {blocks.length === 0 && (
          <div className="text-[11px] italic text-muted-foreground px-2 py-3">Nincs blokk erre a napra.</div>
        )}
        {blocks.map((b) => (
          <BlockDropZone
            key={b.id}
            block={b}
            cases={casesByBlock.get(b.id) ?? []}
            canManage={canManage}
            canBook={canBook}
            onRelease={() => onRelease(b.id)}
            onAiOrder={() => onAiOrder(b.id)}
            aiPending={aiPendingBlockId === b.id}
            eligibility={eligibility[b.id]}
            isDragging={isDragging}
          />
        ))}
      </div>
    </div>
  );
}

function BlockDropZone({
  block,
  cases,
  canManage,
  canBook,
  onRelease,
  onAiOrder,
  aiPending,
  eligibility,
  isDragging,
}: {
  block: Block;
  cases: SurgeryCase[];
  canManage: boolean;
  canBook: boolean;
  onRelease: () => void;
  onAiOrder: () => void;
  aiPending: boolean;
  eligibility?: { allowed: boolean; reason: string };
  isDragging: boolean;
}) {
  const { isOver, setNodeRef } = useDroppable({ id: block.id });
  const usedMin = cases.reduce((s, c) => s + (c.becsult_idotartam_perc ?? 0), 0);
  const start = block.kezdo_ido?.slice(0, 5);
  const end = block.veg_ido?.slice(0, 5);
  const totalMin =
    block.kezdo_ido && block.veg_ido
      ? (parseInt(block.veg_ido.slice(0, 2)) * 60 + parseInt(block.veg_ido.slice(3, 5))) -
        (parseInt(block.kezdo_ido.slice(0, 2)) * 60 + parseInt(block.kezdo_ido.slice(3, 5)))
      : 0;

  const blocked = isDragging && eligibility && !eligibility.allowed;
  const ok = isDragging && eligibility?.allowed;
  const caseIds = useMemo(() => cases.map((c) => c.id), [cases]);
  const canReorder = canBook && block.statusz !== "felszabaditott";

  return (
    <div
      ref={setNodeRef}
      title={isDragging && eligibility ? eligibility.reason : undefined}
      className={cn(
        "rounded-md border border-dashed border-border p-2 transition-colors",
        isOver && ok && "border-primary bg-primary/10",
        isOver && blocked && "border-destructive bg-destructive/10",
        !isOver && ok && "border-emerald-500/40 bg-emerald-500/5",
        !isOver && blocked && "border-destructive/40 bg-destructive/5 opacity-60",
        block.statusz === "felszabaditott" && "opacity-50",
        block.surgossegi_keret && !isDragging && "border-destructive/40 bg-destructive/5",
      )}
    >
      <div className="flex items-center justify-between text-[10px] font-mono">
        <span className="font-semibold">{start}–{end}</span>
        <span className="text-muted-foreground">
          {usedMin}/{totalMin}p
        </span>
      </div>
      {blocked && (
        <div className="text-[10px] text-destructive font-semibold mt-0.5 truncate">
          ⛔ {eligibility?.reason}
        </div>
      )}
      {block.surgossegi_keret && (
        <div className="text-[10px] font-bold text-destructive uppercase mt-0.5">SÜRGŐSSÉGI KERET</div>
      )}
      <SortableContext items={caseIds} strategy={verticalListSortingStrategy}>
        <div className="space-y-1 mt-1.5">
          {cases.map((c, idx) => (
            <SortableCaseCard
              key={c.id}
              c={c}
              index={idx + 1}
              blockId={block.id}
              draggable={canReorder}
            />
          ))}
        </div>
      </SortableContext>
      <div className="mt-2 flex items-center justify-between gap-2">
        {canReorder && cases.length >= 2 ? (
          <button
            type="button"
            onClick={onAiOrder}
            disabled={aiPending}
            className="inline-flex items-center gap-1 text-[10px] uppercase font-semibold text-primary hover:underline disabled:opacity-50"
          >
            {aiPending ? <Loader2 className="size-3 animate-spin" /> : <Sparkles className="size-3" />}
            AI rendezés
          </button>
        ) : <span />}
        {canManage && block.statusz !== "felszabaditott" && (
          <button
            type="button"
            onClick={onRelease}
            className="text-[10px] uppercase font-semibold text-muted-foreground hover:text-foreground underline"
          >
            Felszabadít
          </button>
        )}
      </div>
    </div>
  );
}

function SortableCaseCard({
  c,
  index,
  blockId,
  draggable,
}: {
  c: SurgeryCase;
  index: number;
  blockId: string;
  draggable: boolean;
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id: c.id,
    data: { type: "block-case", blockId },
    disabled: !draggable,
  });
  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };
  return (
    <div
      ref={setNodeRef}
      style={style}
      {...(draggable ? attributes : {})}
      {...(draggable ? listeners : {})}
      className={cn(
        "rounded-md border border-border bg-card p-2 text-xs space-y-1 transition-shadow touch-none select-none",
        draggable && "cursor-grab active:cursor-grabbing hover:shadow-sm",
        isDragging && "opacity-40",
        c.prioritas === "azonnali" && "border-destructive ring-1 ring-destructive/30",
        c.prioritas === "sürgos" && "border-warning",
      )}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-1.5 min-w-0">
          {draggable && (
            <span className="text-muted-foreground/60 shrink-0">
              <GripVertical className="size-3" />
            </span>
          )}
          <span className="text-[10px] font-mono text-muted-foreground shrink-0">#{index}</span>
          <span className="font-semibold truncate">#{c.id.slice(0, 6)}</span>
        </div>
        <span
          className={cn(
            "text-[10px] font-mono uppercase shrink-0 px-1.5 py-0.5 rounded",
            c.prioritas === "azonnali" && "bg-destructive text-destructive-foreground",
            c.prioritas === "sürgos" && "bg-warning/20 text-warning-foreground",
            (!c.prioritas || c.prioritas === "elektiv") && "bg-secondary text-muted-foreground",
          )}
        >
          {c.prioritas ?? "elektiv"}
        </span>
      </div>
      <div className="flex items-center gap-1 text-[10px] font-mono text-muted-foreground">
        <Clock className="size-3" /> {c.becsult_idotartam_perc} perc
      </div>
    </div>
  );
}
