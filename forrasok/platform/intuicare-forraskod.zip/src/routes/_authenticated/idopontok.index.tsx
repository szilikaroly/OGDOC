/**
 * Admin időpontok — naptár-szerű napi nézet + lemondás.
 */
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { StatusBadge, type StatusTone } from "@/components/ui/status-badge";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { listAppointments, adminCancelAppointment, listResources } from "@/lib/booking/booking.functions";
import { markArrived, markCompleted, markNoShow, issueSatisfactionInvite } from "@/lib/booking/lifecycle.functions";

function todayISO(off = 0) { const d = new Date(); d.setDate(d.getDate() + off); return d.toISOString().slice(0, 10); }

function statusTone(s: string): StatusTone {
  if (s === "lemondva") return "bad";
  if (s === "befejezett") return "ok";
  if (s === "megerkezett") return "info";
  if (s === "megerositendo") return "warn";
  if (s === "nem_jelent_meg") return "bad";
  return "neutral";
}

function syncTone(s: string): StatusTone {
  if (s === "sikeres" || s === "ok") return "ok";
  if (s === "hiba" || s === "failed") return "bad";
  return "warn";
}

function IdopontokIndex() {
  const qc = useQueryClient();
  const [from, setFrom] = useState(todayISO());
  const [to, setTo] = useState(todayISO(7));
  const [resourceId, setResourceId] = useState<string>("");

  const fetchList = useServerFn(listAppointments);
  const fetchRes = useServerFn(listResources);
  const cancelFn = useServerFn(adminCancelAppointment);
  const arrivedFn = useServerFn(markArrived);
  const completedFn = useServerFn(markCompleted);
  const noShowFn = useServerFn(markNoShow);
  const inviteFn = useServerFn(issueSatisfactionInvite);

  const resourcesQ = useQuery({ queryKey: ["appt-resources"], queryFn: () => fetchRes() });
  const apptQ = useQuery({
    queryKey: ["appts", from, to, resourceId],
    queryFn: () => fetchList({ data: { from, to, resource_id: resourceId || undefined } }),
  });

  const refresh = () => qc.invalidateQueries({ queryKey: ["appts"] });
  const cancelM = useMutation({
    mutationFn: (vars: { id: string; reason: string }) =>
      cancelFn({ data: { appointment_id: vars.id, reason: vars.reason } }),
    onSuccess: () => { toast.success("Lemondva."); refresh(); },
    onError: (e: Error) => toast.error(e.message),
  });
  const arrivedM = useMutation({
    mutationFn: (id: string) => arrivedFn({ data: { appointment_id: id } }),
    onSuccess: () => { toast.success("Megérkezett."); refresh(); },
    onError: (e: Error) => toast.error(e.message),
  });
  const completedM = useMutation({
    mutationFn: (id: string) => completedFn({ data: { appointment_id: id, send_invite: true } }),
    onSuccess: (r) => {
      toast.success(r.invite_url ? "Befejezve + felmérés link generálva." : "Befejezve.");
      refresh();
    },
    onError: (e: Error) => toast.error(e.message),
  });
  const noShowM = useMutation({
    mutationFn: (vars: { id: string; reason?: string }) =>
      noShowFn({ data: { appointment_id: vars.id, reason: vars.reason } }),
    onSuccess: () => { toast.success("Nem jelent meg."); refresh(); },
    onError: (e: Error) => toast.error(e.message),
  });
  const inviteM = useMutation({
    mutationFn: (id: string) => inviteFn({ data: { appointment_id: id } }),
    onSuccess: (r) => { toast.success("Felmérés link: " + r.url); refresh(); },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <main className="container mx-auto px-4 py-8">
      <header className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Időpontok</h1>
          <p className="text-sm text-muted-foreground">Foglalások kezelése, lemondás, sync státusz.</p>
        </div>
        <Link to="/idopontok/sablonok" className="text-sm text-primary hover:underline">
          Sablonok és slot-generálás →
        </Link>
      </header>

      <Card className="mb-4">
        <CardContent className="flex flex-wrap items-end gap-3 pt-6">
          <div><Label htmlFor="f">Ettől</Label><Input id="f" type="date" value={from} onChange={(e) => setFrom(e.target.value)} /></div>
          <div><Label htmlFor="t">Eddig</Label><Input id="t" type="date" value={to} onChange={(e) => setTo(e.target.value)} /></div>
          <div>
            <Label htmlFor="r">Erőforrás</Label>
            <select id="r" className="h-9 rounded-md border bg-background px-2 text-sm"
              value={resourceId} onChange={(e) => setResourceId(e.target.value)}>
              <option value="">— Mind —</option>
              {resourcesQ.data?.map((r) => <option key={r.id} value={r.id}>{r.nev}</option>)}
            </select>
          </div>
        </CardContent>
      </Card>

      {apptQ.isLoading && <Skeleton className="h-40 w-full" />}
      {apptQ.isError && <p className="text-sm text-destructive">Hiba: {(apptQ.error as Error).message}</p>}

      <div className="space-y-2">
        {apptQ.data?.map((a: any) => (
          <Card key={a.id}>
            <CardContent className="flex flex-wrap items-center justify-between gap-3 py-3">
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-sm">{a.foglalas_kod}</span>
                  <StatusBadge tone={statusTone(a.status)}>{a.status}</StatusBadge>
                  {a.sync_statusz && <StatusBadge tone={syncTone(a.sync_statusz)}>EESZT: {a.sync_statusz}</StatusBadge>}
                </div>
                <p className="mt-1 text-sm">
                  {new Date(a.appointment_slots.kezdo_ts).toLocaleString("hu-HU")} · {a.vendeg_nev}
                </p>
                <p className="text-xs text-muted-foreground">{a.vendeg_email} · {a.vendeg_telefon}</p>
                {a.megjegyzes && <p className="mt-1 text-xs italic">{a.megjegyzes}</p>}
              </div>
              <div className="flex flex-wrap gap-2">
                {(a.status === "foglalt" || a.status === "megerositendo") && (
                  <Button size="sm" variant="secondary"
                    onClick={() => arrivedM.mutate(a.id)} disabled={arrivedM.isPending}>
                    Megérkezett
                  </Button>
                )}
                {(a.status === "megerkezett" || a.status === "foglalt") && (
                  <Button size="sm"
                    onClick={() => completedM.mutate(a.id)} disabled={completedM.isPending}>
                    Befejezés + felmérés
                  </Button>
                )}
                {a.status === "befejezett" && (
                  <Button size="sm" variant="outline"
                    onClick={() => inviteM.mutate(a.id)} disabled={inviteM.isPending}>
                    Felmérés link
                  </Button>
                )}
                {(a.status === "foglalt" || a.status === "megerositendo") && (
                  <Button size="sm" variant="outline"
                    onClick={() => {
                      const reason = prompt("Megjegyzés (opcionális)?") ?? undefined;
                      noShowM.mutate({ id: a.id, reason });
                    }}
                    disabled={noShowM.isPending}>
                    Nem jelent meg
                  </Button>
                )}
                {a.status !== "lemondva" && a.status !== "befejezett" && (
                  <Button size="sm" variant="destructive"
                    onClick={() => {
                      const reason = prompt("Lemondás oka?");
                      if (reason) cancelM.mutate({ id: a.id, reason });
                    }}
                    disabled={cancelM.isPending}>
                    Lemondás
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
        {apptQ.data && apptQ.data.length === 0 && (
          <p className="text-sm text-muted-foreground">Nincs foglalás az időszakban.</p>
        )}
      </div>
    </main>
  );
}

export const Route = createFileRoute("/_authenticated/idopontok/")({
  component: IdopontokIndex,
  head: () => ({ meta: [{ title: "Időpontok" }] }),
  errorComponent: ({ error, reset }) => (
    <div className="p-6"><p className="text-destructive">{error.message}</p><Button onClick={reset}>Újra</Button></div>
  ),
  notFoundComponent: () => <div className="p-6">Nem található</div>,
});
