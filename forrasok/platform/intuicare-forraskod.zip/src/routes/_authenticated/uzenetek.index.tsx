import { createFileRoute } from "@tanstack/react-router";
import { MessageSquare } from "lucide-react";

export const Route = createFileRoute("/_authenticated/uzenetek/")({
  component: () => (
    <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground gap-3">
      <MessageSquare className="size-10 opacity-40" />
      <div className="text-sm">Válassz beszélgetést, vagy indíts újat.</div>
    </div>
  ),
});
