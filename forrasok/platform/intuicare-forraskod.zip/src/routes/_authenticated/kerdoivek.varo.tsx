/**
 * Kérdőív váró — kioszk mód.
 * Bal: ma bejelentkezett, váróban lévő páciensek.
 * Jobb: a kiválasztott páciens kiosztott, kioszk-engedélyezett kérdőívei,
 *       kattintásra a kérdőív kitölthető és beküldhető.
 */
import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { ChevronLeft, Clock, User, CheckCircle2, AlertCircle } from "lucide-react";
import {
  listWaitingPatients,
  listQuestionnaireAssignments,
  getQuestionnaireForFill,
  submitQuestionnaireResponse,
} from "@/lib/questionnaires/questionnaires.functions";

type QItem = { index: number; text: string; type: string; options?: { value: number; label: string }[] };

function fmtTime(iso: string | null): string {
  if (!iso) return "—";
  const d = new Date(iso);
  return d.toLocaleTimeString("hu-HU", { hour: "2-digit", minute: "2-digit" });
}

function PatientList({ selectedId, onSelect }: { selectedId: string | null; onSelect: (id: string, name: string) => void }) {
  const fn = useServerFn(listWaitingPatients);
  const q = useQuery({ queryKey: ["waiting-patients"], queryFn: () => fn(), refetchInterval: 30_000 });

  if (q.isLoading) return <Skeleton className="h-64 w-full" />;
  if (q.isError) return <p className="text-sm text-destructive">{(q.error as Error).message}</p>;
  if (!q.data?.length) return <p className="text-sm text-muted-foreground">Nincs várakozó páciens.</p>;

  return (
    <div className="space-y-2">
      {q.data.map((row: any) => {
        const p = row.patients;
        const name = p ? `${p.vezeteknev} ${p.keresztnev}` : "Ismeretlen páciens";
        const active = row.patient_id === selectedId;
        return (
          <button
            key={row.id}
            onClick={() => row.patient_id && onSelect(row.patient_id, name)}
            disabled={!row.patient_id}
            className={`w-full rounded-lg border p-3 text-left transition hover:bg-accent ${active ? "border-primary bg-accent" : ""}`}
          >
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <User className="h-4 w-4 text-muted-foreground" />
                <span className="font-medium">{name}</span>
              </div>
              <Badge variant={row.status === "in_room" ? "default" : "secondary"}>
                {row.status === "in_room" ? "rendelőben" : "vár"}
              </Badge>
            </div>
            <div className="mt-1 flex items-center gap-3 text-xs text-muted-foreground">
              {row.queue_position != null && <span>#{row.queue_position}</span>}
              <span className="inline-flex items-center gap-1"><Clock className="h-3 w-3" />{fmtTime(row.checkin_ts)}</span>
            </div>
          </button>
        );
      })}
    </div>
  );
}

function AssignmentList({
  patientId,
  patientName,
  onStart,
}: {
  patientId: string;
  patientName: string;
  onStart: (assignmentId: string | null, questionnaireId: string) => void;
}) {
  const fn = useServerFn(listQuestionnaireAssignments);
  const q = useQuery({
    queryKey: ["assignments", patientId],
    queryFn: () => fn({ data: { patient_id: patientId, only_open: true } }),
  });

  const kiosk = useMemo(
    () => (q.data ?? []).filter((a: any) => a.questionnaires?.kioszk_eligible),
    [q.data],
  );

  return (
    <div>
      <header className="mb-4">
        <h2 className="text-lg font-semibold">{patientName}</h2>
        <p className="text-sm text-muted-foreground">Kiosztott kérdőívek (kioszkban kitölthető)</p>
      </header>

      {q.isLoading && <Skeleton className="h-32 w-full" />}
      {q.isError && <p className="text-sm text-destructive">{(q.error as Error).message}</p>}
      {q.data && kiosk.length === 0 && (
        <Card>
          <CardContent className="py-6 text-center text-sm text-muted-foreground">
            <CheckCircle2 className="mx-auto mb-2 h-8 w-8 text-muted-foreground" />
            Nincs kitöltendő kérdőív.
          </CardContent>
        </Card>
      )}

      <div className="grid gap-3 md:grid-cols-2">
        {kiosk.map((a: any) => {
          const overdue = a.derived_status === "esedekes";
          return (
            <Card key={a.id} className={overdue ? "border-amber-500/60" : ""}>
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center justify-between text-base">
                  <span>{a.questionnaires?.code}</span>
                  {overdue && <Badge variant="outline" className="border-amber-500/60 text-amber-700"><AlertCircle className="mr-1 h-3 w-3" />esedékes</Badge>}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm">{a.questionnaires?.title}</p>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>~{a.questionnaires?.becsult_perc ?? "?"} perc</span>
                  {a.due_at && <span>határidő: {new Date(a.due_at).toLocaleDateString("hu-HU")}</span>}
                </div>
                <Button size="sm" className="w-full" onClick={() => onStart(a.id, a.questionnaire_id)}>
                  Kitöltés indítása
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}

function QuestionnaireForm({
  patientId,
  assignmentId,
  questionnaireId,
  onDone,
  onCancel,
}: {
  patientId: string;
  assignmentId: string | null;
  questionnaireId: string;
  onDone: (result: { critical_triggered: boolean }) => void;
  onCancel: () => void;
}) {
  const getFn = useServerFn(getQuestionnaireForFill);
  const submitFn = useServerFn(submitQuestionnaireResponse);
  const qc = useQueryClient();
  const [answers, setAnswers] = useState<Record<number, number>>({});

  const q = useQuery({
    queryKey: ["q-fill", questionnaireId],
    queryFn: () => getFn({ data: { questionnaire_id: questionnaireId } }),
  });

  const mut = useMutation({
    mutationFn: () =>
      submitFn({
        data: {
          questionnaire_id: questionnaireId,
          assignment_id: assignmentId,
          patient_id: patientId,
          answers,
          is_anonymous: false,
          consent_to_record: true,
        },
      }),
    onSuccess: (r) => {
      qc.invalidateQueries({ queryKey: ["assignments", patientId] });
      onDone({ critical_triggered: r.critical_triggered });
    },
  });

  if (q.isLoading) return <Skeleton className="h-96 w-full" />;
  if (q.isError) return <p className="text-sm text-destructive">{(q.error as Error).message}</p>;
  if (!q.data) return null;

  const items = (q.data.items as unknown as QItem[]) ?? [];
  const allAnswered = items.every((it) => typeof answers[it.index] === "number");

  return (
    <div>
      <header className="mb-4 flex items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold">{q.data.title}</h2>
          <p className="text-xs text-muted-foreground">{q.data.code} · ~{q.data.becsult_perc ?? "?"} perc</p>
        </div>
        <Button variant="ghost" size="sm" onClick={onCancel}>
          <ChevronLeft className="mr-1 h-4 w-4" /> Mégse
        </Button>
      </header>

      {q.data.leiras && <p className="mb-4 text-sm text-muted-foreground">{q.data.leiras}</p>}

      <div className="space-y-4">
        {items.map((it) => (
          <Card key={it.index}>
            <CardContent className="pt-4">
              <Label className="block text-sm font-medium">
                {it.index}. {it.text}
              </Label>
              <div className="mt-3 flex flex-wrap gap-2">
                {(it.options ?? []).map((opt) => {
                  const selected = answers[it.index] === opt.value;
                  return (
                    <button
                      key={opt.value}
                      type="button"
                      onClick={() => setAnswers((a) => ({ ...a, [it.index]: opt.value }))}
                      className={`rounded-md border px-3 py-2 text-sm transition ${
                        selected ? "border-primary bg-primary text-primary-foreground" : "hover:bg-accent"
                      }`}
                    >
                      {opt.label}
                    </button>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Separator className="my-6" />

      {mut.isError && <p className="mb-3 text-sm text-destructive">{(mut.error as Error).message}</p>}

      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={onCancel} disabled={mut.isPending}>Mégse</Button>
        <Button onClick={() => mut.mutate()} disabled={!allAnswered || mut.isPending}>
          {mut.isPending ? "Beküldés…" : "Beküldés"}
        </Button>
      </div>
    </div>
  );
}

function VaroPage() {
  const [selected, setSelected] = useState<{ id: string; name: string } | null>(null);
  const [fill, setFill] = useState<{ assignmentId: string | null; questionnaireId: string } | null>(null);
  const [doneMsg, setDoneMsg] = useState<string | null>(null);

  return (
    <main className="container mx-auto px-4 py-6">
      <header className="mb-6">
        <h1 className="text-2xl font-bold">Kérdőív váró</h1>
        <p className="text-sm text-muted-foreground">Kioszk mód — bejelentkezett pácienseknek kitölthető kérdőívek.</p>
      </header>

      <div className="grid gap-6 lg:grid-cols-[320px,1fr]">
        <aside>
          <Card>
            <CardHeader className="pb-3"><CardTitle className="text-base">Várakozók</CardTitle></CardHeader>
            <CardContent>
              <PatientList
                selectedId={selected?.id ?? null}
                onSelect={(id, name) => { setSelected({ id, name }); setFill(null); setDoneMsg(null); }}
              />
            </CardContent>
          </Card>
        </aside>

        <section>
          {!selected && (
            <Card>
              <CardContent className="py-16 text-center text-sm text-muted-foreground">
                Válasszon pácienst a bal oldali listából.
              </CardContent>
            </Card>
          )}

          {selected && !fill && (
            <>
              {doneMsg && (
                <div className="mb-4 rounded-md border border-emerald-500/40 bg-emerald-500/10 p-3 text-sm">
                  {doneMsg}
                </div>
              )}
              <AssignmentList
                patientId={selected.id}
                patientName={selected.name}
                onStart={(assignmentId, questionnaireId) => { setFill({ assignmentId, questionnaireId }); setDoneMsg(null); }}
              />
            </>
          )}

          {selected && fill && (
            <QuestionnaireForm
              patientId={selected.id}
              assignmentId={fill.assignmentId}
              questionnaireId={fill.questionnaireId}
              onCancel={() => setFill(null)}
              onDone={({ critical_triggered }) => {
                setFill(null);
                setDoneMsg(critical_triggered
                  ? "Kérdőív beküldve. Kritikus eredmény miatt riasztás generálódott."
                  : "Kérdőív sikeresen beküldve.");
              }}
            />
          )}
        </section>
      </div>
    </main>
  );
}

export const Route = createFileRoute("/_authenticated/kerdoivek/varo")({
  component: VaroPage,
  head: () => ({ meta: [{ title: "Kérdőív váró" }] }),
  errorComponent: ({ error, reset }) => (
    <div className="p-6">
      <p className="text-destructive">{error.message}</p>
      <Button onClick={reset} className="mt-3">Újra</Button>
    </div>
  ),
  notFoundComponent: () => <div className="p-6">Nem található</div>,
});
