import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { toast } from "sonner";
import {
  Users,
  Search,
  RefreshCcw,
  Download,
  AlertCircle,
  Moon,
  Radiation,
  Clock,
  Phone,
  PhoneOff,
  Heart,
  Ban,
  GraduationCap,
  UserCheck,
  CalendarClock,
  Loader2,
  Filter,
  HeartPulse,
  ChevronDown,
  ChevronRight,
  Award,
  CheckCircle2,
  XCircle,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { usePermissions } from "@/hooks/use-permissions";
import { humanizeError } from "@/lib/humanize-error";
import { cn } from "@/lib/utils";
import { TeamManagementToolbar, RowArchiveAction } from "@/components/csapat/team-management";
import { BulkActionsBar } from "@/components/csapat/team-admin-dialogs";

export const Route = createFileRoute("/_authenticated/csapat")({
  component: CsapatPage,
});

type SchedulingFact = {
  user_id: string;
  tenant_id: string | null;
  teljes_nev: string;
  becenev: string | null;
  foglalkozas_tipus: "orvos" | "szakdolgozo" | "egyeb";
  email: string;
  heti_max_ora: number | null;
  havi_max_ugyelet: number | null;
  ugyelet_utan_pihenonap: boolean;
  ugyelet_utan_min_ora: number;
  egymas_utani_max_ugyelet: number;
  last_minute_elerheto: boolean;
  last_minute_orahatar: number | null;
  utazasi_perc_max: number | null;
  preferalt_musakok: string[];
  tiltott_napok: number[];
  nyelvek: string[];
  terhes: boolean;
  szoptat: boolean;
  kisgyermek_otthon: boolean;
  egyedulnevelo: boolean;
  tartos_betegseg: boolean;
  mozgaskorlatozas: boolean;
  vedendokoru: boolean;
  aktiv_constraint_count: number;
  tiltott_ejszaka: boolean;
  tiltott_sugar_zona: boolean;
  min_pihenoido_ora: number;
  tavollet_nap_30: number;
  tavollet_nap_90: number;
  fuggo_tavollet_count: number;
  jovahagyott_tavollet_count: number;
  pozitiv_kapcsolat: number;
  negativ_kapcsolat: number;
  mentor_count: number;
  mentee_count: number;
  contact_count: number;
  van_aktiv_ertesites: boolean;
};

const CONSTRAINT_FIELDS: Array<keyof SchedulingFact> = [
  "terhes",
  "szoptat",
  "kisgyermek_otthon",
  "egyedulnevelo",
  "tartos_betegseg",
  "mozgaskorlatozas",
  "vedendokoru",
];

function CsapatPage() {
  const { t } = useTranslation();
  const { can, loading: permLoading } = usePermissions();
  const [rows, setRows] = useState<SchedulingFact[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState<"all" | SchedulingFact["foglalkozas_tipus"]>("all");
  const [constraintFilter, setConstraintFilter] = useState<"all" | "any" | "none">("all");
  const [pendingOnly, setPendingOnly] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());

  const allowed = !permLoading && (can("view_team") || can("manage_schedule") || can("manage_tenant"));
  const canManage = can("manage_tenant");

  const toggleSelect = (id: string) => setSelected((s) => {
    const n = new Set(s); if (n.has(id)) n.delete(id); else n.add(id); return n;
  });
  const clearSelection = () => setSelected(new Set());

  async function load() {
    setLoading(true);
    const { data, error } = await (supabase as unknown as {
      from: (t: string) => {
        select: (q: string) => {
          order: (c: string, o: { ascending: boolean }) => Promise<{ data: unknown; error: { message?: string } | null }>;
        };
      };
    })
      .from("profile_scheduling_facts")
      .select("*")
      .order("teljes_nev", { ascending: true });
    if (error) {
      toast.error(humanizeError(error as Parameters<typeof humanizeError>[0], t));
      setRows([]);
    } else {
      setRows((data ?? []) as SchedulingFact[]);
    }
    setLoading(false);
  }

  useEffect(() => {
    if (allowed) void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [allowed]);

  const filtered = useMemo(() => {
    return rows.filter((r) => {
      if (roleFilter !== "all" && r.foglalkozas_tipus !== roleFilter) return false;
      if (constraintFilter === "any" && r.aktiv_constraint_count === 0) return false;
      if (constraintFilter === "none" && r.aktiv_constraint_count > 0) return false;
      if (pendingOnly && r.fuggo_tavollet_count === 0) return false;
      if (search.trim()) {
        const q = search.trim().toLowerCase();
        if (
          !r.teljes_nev.toLowerCase().includes(q) &&
          !r.email.toLowerCase().includes(q) &&
          !(r.becenev ?? "").toLowerCase().includes(q)
        ) {
          return false;
        }
      }
      return true;
    });
  }, [rows, roleFilter, constraintFilter, pendingOnly, search]);

  const summary = useMemo(() => {
    return {
      total: rows.length,
      withConstraints: rows.filter((r) => r.aktiv_constraint_count > 0).length,
      pending: rows.reduce((s, r) => s + r.fuggo_tavollet_count, 0),
      noNight: rows.filter((r) => r.tiltott_ejszaka).length,
    };
  }, [rows]);

  function exportCsv() {
    const cols: Array<keyof SchedulingFact> = [
      "teljes_nev",
      "email",
      "foglalkozas_tipus",
      "aktiv_constraint_count",
      "tiltott_ejszaka",
      "tiltott_sugar_zona",
      "min_pihenoido_ora",
      "heti_max_ora",
      "havi_max_ugyelet",
      "egymas_utani_max_ugyelet",
      "last_minute_elerheto",
      "tavollet_nap_30",
      "tavollet_nap_90",
      "fuggo_tavollet_count",
      "pozitiv_kapcsolat",
      "negativ_kapcsolat",
      "mentor_count",
      "mentee_count",
      "contact_count",
    ];
    const esc = (v: unknown) => {
      const s = v == null ? "" : Array.isArray(v) ? v.join("|") : String(v);
      return /[",\n;]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    };
    const csv = [cols.join(";"), ...filtered.map((r) => cols.map((c) => esc(r[c])).join(";"))].join("\n");
    const blob = new Blob([`\ufeff${csv}`], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `csapat-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success(t("csapat.exported"));
  }

  if (permLoading) {
    return (
      <div className="p-8 flex items-center gap-2 text-muted-foreground">
        <Loader2 className="h-4 w-4 animate-spin" /> {t("common.loading")}
      </div>
    );
  }

  if (!allowed) {
    return (
      <div className="p-8 max-w-xl">
        <div className="rounded-lg border border-border bg-card p-6 flex items-start gap-3">
          <AlertCircle className="h-5 w-5 text-destructive shrink-0 mt-0.5" />
          <div>
            <h1 className="font-semibold text-lg">{t("csapat.title")}</h1>
            <p className="mt-1 text-sm text-muted-foreground">{t("csapat.no_access")}</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 md:p-8 space-y-6">
      <header className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <Users className="h-6 w-6" /> {t("csapat.title")}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">{t("csapat.subtitle")}</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => void load()}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-md border border-border bg-card hover:bg-accent transition-colors"
          >
            <RefreshCcw className={cn("h-3.5 w-3.5", loading && "animate-spin")} />
            {t("csapat.refresh")}
          </button>
          <button
            type="button"
            onClick={exportCsv}
            disabled={filtered.length === 0}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-md border border-border bg-card hover:bg-accent transition-colors disabled:opacity-50"
          >
            <Download className="h-3.5 w-3.5" />
            {t("csapat.export_csv")}
          </button>
          {can("manage_tenant") && (
            <TeamManagementToolbar isAdmin={can("manage_tenant")} onChanged={() => void load()} />
          )}
        </div>
      </header>

      {/* Summary cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <SummaryCard label={t("csapat.summary_total")} value={summary.total} icon={Users} />
        <SummaryCard
          label={t("csapat.summary_with_constraints")}
          value={summary.withConstraints}
          icon={Heart}
          tone="warning"
        />
        <SummaryCard
          label={t("csapat.summary_pending")}
          value={summary.pending}
          icon={CalendarClock}
          tone="info"
        />
        <SummaryCard
          label={t("csapat.summary_no_night")}
          value={summary.noNight}
          icon={Moon}
          tone="muted"
        />
      </div>

      <AcuteIllnessAdminPanel canApprove={can("manage_schedule") || can("manage_tenant")} />

      {/* Filters */}
      <div className="bg-card border border-border rounded-lg p-4 flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[220px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t("csapat.search_ph")}
            className="w-full pl-9 pr-3 py-2 text-sm rounded-md border border-border bg-background"
          />
        </div>
        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4 text-muted-foreground" />
          <select
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value as typeof roleFilter)}
            className="px-2 py-2 text-sm rounded-md border border-border bg-background"
          >
            <option value="all">{t("csapat.filter_role_all")}</option>
            <option value="orvos">{t("csapat.role_orvos")}</option>
            <option value="szakdolgozo">{t("csapat.role_szakdolgozo")}</option>
            <option value="egyeb">{t("csapat.role_egyeb")}</option>
          </select>
          <select
            value={constraintFilter}
            onChange={(e) => setConstraintFilter(e.target.value as typeof constraintFilter)}
            className="px-2 py-2 text-sm rounded-md border border-border bg-background"
          >
            <option value="all">{t("csapat.filter_constraint_all")}</option>
            <option value="any">{t("csapat.filter_constraint_any")}</option>
            <option value="none">{t("csapat.filter_constraint_none")}</option>
          </select>
          <label className="flex items-center gap-1.5 text-sm cursor-pointer select-none">
            <input
              type="checkbox"
              checked={pendingOnly}
              onChange={(e) => setPendingOnly(e.target.checked)}
              className="h-4 w-4 rounded border-border"
            />
            {t("csapat.filter_pending")}
          </label>
        </div>
        <div className="text-xs text-muted-foreground font-mono ml-auto">
          {t("csapat.showing")} {filtered.length} {t("csapat.of")} {rows.length}{" "}
          {filtered.length === 1 ? t("csapat.member") : t("csapat.members")}
        </div>
      </div>

      {/* Table */}
      <div className="bg-card border border-border rounded-lg overflow-hidden">
        {loading ? (
          <div className="p-12 flex items-center justify-center text-muted-foreground gap-2">
            <Loader2 className="h-4 w-4 animate-spin" /> {t("common.loading")}
          </div>
        ) : filtered.length === 0 ? (
          <div className="p-12 text-center text-sm text-muted-foreground">{t("csapat.empty")}</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50 text-xs uppercase tracking-wider text-muted-foreground">
                <tr>
                  {canManage && (
                    <th className="px-3 py-3 w-8">
                      <input
                        type="checkbox"
                        aria-label="Összes kijelölése"
                        checked={filtered.length > 0 && filtered.every((r) => selected.has(r.user_id))}
                        onChange={(e) => {
                          if (e.target.checked) setSelected(new Set(filtered.map((r) => r.user_id)));
                          else clearSelection();
                        }}
                        className="h-4 w-4"
                      />
                    </th>
                  )}
                  <th className="text-left px-4 py-3 font-medium">{t("csapat.th_name")}</th>
                  <th className="text-left px-4 py-3 font-medium">{t("csapat.th_role")}</th>
                  <th className="text-left px-4 py-3 font-medium">{t("csapat.th_constraints")}</th>
                  <th className="text-left px-4 py-3 font-medium">{t("csapat.th_shift_rules")}</th>
                  <th className="text-left px-4 py-3 font-medium">{t("csapat.th_absence")}</th>
                  <th className="text-left px-4 py-3 font-medium">{t("csapat.th_peers")}</th>
                  <th className="text-left px-4 py-3 font-medium">{t("csapat.th_contacts")}</th>
                  {canManage && (
                    <th className="text-left px-4 py-3 font-medium">Művelet</th>
                  )}
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filtered.map((r) => (
                  <Row
                    key={r.user_id}
                    r={r}
                    canManage={canManage}
                    selected={selected.has(r.user_id)}
                    onToggleSelect={canManage ? () => toggleSelect(r.user_id) : undefined}
                    onChanged={() => void load()}
                  />
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {canManage && (
        <BulkActionsBar
          selectedIds={Array.from(selected)}
          onClear={clearSelection}
          onChanged={() => { clearSelection(); void load(); }}
        />
      )}
    </div>
  );
}

function Row({ r, canManage = false, selected = false, onToggleSelect, onChanged }: {
  r: SchedulingFact; canManage?: boolean; selected?: boolean; onToggleSelect?: () => void; onChanged?: () => void;
}) {
  const { t } = useTranslation();
  const activeConstraints = CONSTRAINT_FIELDS.filter((f) => r[f] === true);

  return (
    <tr className={cn("hover:bg-accent/30 transition-colors", selected && "bg-primary/5")}>
      {canManage && (
        <td className="px-3 py-3 align-top">
          <input
            type="checkbox"
            checked={selected}
            onChange={() => onToggleSelect?.()}
            aria-label={`${r.teljes_nev} kijelölése`}
            className="h-4 w-4"
          />
        </td>
      )}
      <td className="px-4 py-3 align-top">
        <Link
          to="/karakterlap"
          search={canManage ? { user: r.user_id } : {}}
          className="font-medium hover:underline"
          aria-label={canManage ? `${r.teljes_nev} karakterlap szerkesztése` : r.teljes_nev}
        >
          {r.teljes_nev}
        </Link>
        {r.becenev && (
          <span className="ml-1.5 text-xs text-muted-foreground">({r.becenev})</span>
        )}
        <div className="text-xs text-muted-foreground mt-0.5">{r.email}</div>
      </td>
      <td className="px-4 py-3 align-top">
        <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-secondary text-xs font-medium">
          {t(`csapat.role_${r.foglalkozas_tipus}`)}
        </span>
      </td>
      <td className="px-4 py-3 align-top">
        {activeConstraints.length === 0 ? (
          <span className="text-muted-foreground">{t("csapat.no_constraints")}</span>
        ) : (
          <div className="flex flex-wrap gap-1 max-w-[220px]">
            {activeConstraints.map((c) => (
              <span
                key={c}
                className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium bg-amber-500/15 text-amber-700 dark:text-amber-300 border border-amber-500/30"
              >
                {t(`csapat.constraint_${c}`)}
              </span>
            ))}
          </div>
        )}
      </td>
      <td className="px-4 py-3 align-top">
        <div className="flex flex-col gap-1 text-xs">
          {r.tiltott_ejszaka && (
            <span className="inline-flex items-center gap-1 text-purple-700 dark:text-purple-300">
              <Moon className="h-3 w-3" /> {t("csapat.no_night")}
            </span>
          )}
          {r.tiltott_sugar_zona && (
            <span className="inline-flex items-center gap-1 text-red-700 dark:text-red-300">
              <Radiation className="h-3 w-3" /> {t("csapat.no_radiation")}
            </span>
          )}
          {r.min_pihenoido_ora > 0 && (
            <span className="inline-flex items-center gap-1 text-muted-foreground">
              <Clock className="h-3 w-3" />
              {t("csapat.min_rest")}: {r.min_pihenoido_ora}
              {t("csapat.hours_short")}
            </span>
          )}
          {r.heti_max_ora != null && (
            <span className="text-muted-foreground">
              {t("csapat.max_weekly")}: {r.heti_max_ora}
              {t("csapat.hours_short")}
            </span>
          )}
          {r.havi_max_ugyelet != null && (
            <span className="text-muted-foreground">
              {t("csapat.max_monthly_duty")}: {r.havi_max_ugyelet}
            </span>
          )}
          {r.egymas_utani_max_ugyelet > 0 && (
            <span className="text-muted-foreground">
              {t("csapat.consec_max")}: {r.egymas_utani_max_ugyelet}
            </span>
          )}
          {r.last_minute_elerheto && (
            <span className="inline-flex items-center gap-1 text-emerald-700 dark:text-emerald-300">
              <Clock className="h-3 w-3" /> {t("csapat.last_minute")}
            </span>
          )}
          {r.nyelvek.length > 0 && (
            <span className="text-muted-foreground">
              {t("csapat.languages")}: {r.nyelvek.join(", ")}
            </span>
          )}
        </div>
      </td>
      <td className="px-4 py-3 align-top">
        <div className="flex flex-col gap-1 text-xs">
          <span className="font-mono font-medium">
            {r.tavollet_nap_30} / {r.tavollet_nap_90} nap
          </span>
          {r.fuggo_tavollet_count > 0 && (
            <span className="inline-flex items-center gap-1 text-amber-700 dark:text-amber-300">
              <CalendarClock className="h-3 w-3" />
              {r.fuggo_tavollet_count} {t("csapat.pending")}
            </span>
          )}
          {r.jovahagyott_tavollet_count > 0 && (
            <span className="text-muted-foreground">
              {r.jovahagyott_tavollet_count} {t("csapat.approved")}
            </span>
          )}
        </div>
      </td>
      <td className="px-4 py-3 align-top">
        <div className="flex flex-col gap-1 text-xs">
          {r.pozitiv_kapcsolat > 0 && (
            <span className="inline-flex items-center gap-1 text-emerald-700 dark:text-emerald-300">
              <Heart className="h-3 w-3" /> {r.pozitiv_kapcsolat} {t("csapat.positive")}
            </span>
          )}
          {r.negativ_kapcsolat > 0 && (
            <span className="inline-flex items-center gap-1 text-red-700 dark:text-red-300">
              <Ban className="h-3 w-3" /> {r.negativ_kapcsolat} {t("csapat.negative")}
            </span>
          )}
          {r.mentor_count > 0 && (
            <span className="inline-flex items-center gap-1 text-muted-foreground">
              <UserCheck className="h-3 w-3" /> {r.mentor_count} {t("csapat.mentor")}
            </span>
          )}
          {r.mentee_count > 0 && (
            <span className="inline-flex items-center gap-1 text-muted-foreground">
              <GraduationCap className="h-3 w-3" /> {r.mentee_count} {t("csapat.mentee")}
            </span>
          )}
          {r.pozitiv_kapcsolat + r.negativ_kapcsolat + r.mentor_count + r.mentee_count === 0 && (
            <span className="text-muted-foreground">{t("csapat.no_constraints")}</span>
          )}
        </div>
      </td>
      <td className="px-4 py-3 align-top">
        <div className="flex flex-col gap-1 text-xs">
          <span className="font-medium">
            {r.contact_count} {t("csapat.contacts_n")}
          </span>
          {r.van_aktiv_ertesites ? (
            <span className="inline-flex items-center gap-1 text-emerald-700 dark:text-emerald-300">
              <Phone className="h-3 w-3" /> {t("csapat.notif_on")}
            </span>
          ) : (
            <span className="inline-flex items-center gap-1 text-muted-foreground">
              <PhoneOff className="h-3 w-3" /> {t("csapat.notif_off")}
            </span>
          )}
        </div>
      </td>
      {canManage && (
        <td className="px-4 py-3 align-top">
          <RowArchiveAction userId={r.user_id} name={r.teljes_nev} onChanged={() => onChanged?.()} />
        </td>
      )}
    </tr>
  );
}

function SummaryCard({
  label,
  value,
  icon: Icon,
  tone = "default",
}: {
  label: string;
  value: number;
  icon: typeof Users;
  tone?: "default" | "warning" | "info" | "muted";
}) {
  const toneCls = {
    default: "text-foreground",
    warning: "text-amber-700 dark:text-amber-300",
    info: "text-blue-700 dark:text-blue-300",
    muted: "text-muted-foreground",
  }[tone];
  return (
    <div className="bg-card border border-border rounded-lg p-4">
      <div className="flex items-center justify-between">
        <div className="text-xs uppercase tracking-wider font-mono text-muted-foreground">{label}</div>
        <Icon className={cn("h-4 w-4", toneCls)} />
      </div>
      <div className={cn("mt-2 text-2xl font-bold tabular-nums", toneCls)}>{value}</div>
    </div>
  );
}

// ============================================================
// Mai akut betegjelentések + helyettesítési javaslatok
// ============================================================
type AcuteRow = {
  id: string;
  user_id: string;
  kezdo_datum: string;
  zaro_datum: string;
  leiras: string | null;
  created_at: string;
  profiles: { teljes_nev: string; email: string; foglalkozas_tipus: string } | null;
};

type Replacement = {
  user_id: string;
  teljes_nev: string;
  email: string;
  foglalkozas_tipus: string;
  egyezo_skillek: string[];
  egyezo_kepzettsegek: string[];
  egyezo_skill_szam: number;
  egyezo_kepz_szam: number;
  pozitiv_kapcsolat: boolean;
  match_score: number;
  szabad: boolean;
  aktiv_korlatozok: string[];
};

function AcuteIllnessAdminPanel({ canApprove: _canApprove }: { canApprove: boolean }) {
  const { t } = useTranslation();
  const [rows, setRows] = useState<AcuteRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [openId, setOpenId] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    const today = new Date().toISOString().slice(0, 10);
    const { data, error } = await (supabase as unknown as {
      from: (t: string) => {
        select: (q: string) => {
          eq: (c: string, v: unknown) => {
            lte: (c: string, v: unknown) => {
              gte: (c: string, v: unknown) => {
                order: (c: string, o: { ascending: boolean }) => Promise<{ data: unknown; error: { message?: string } | null }>;
              };
            };
          };
        };
      };
    })
      .from("profile_unavailability")
      .select("id,user_id,kezdo_datum,zaro_datum,leiras,created_at,profiles:profiles!profile_unavailability_user_id_fkey(teljes_nev,email,foglalkozas_tipus)")
      .eq("akut", true)
      .lte("kezdo_datum", today)
      .gte("zaro_datum", today)
      .order("created_at", { ascending: false });
    if (error) {
      toast.error(humanizeError(error as Parameters<typeof humanizeError>[0], t));
      setRows([]);
    } else {
      setRows((data ?? []) as AcuteRow[]);
    }
    setLoading(false);
  }

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (loading) {
    return (
      <div className="rounded-lg border border-border bg-card p-4 text-sm text-muted-foreground flex items-center gap-2">
        <Loader2 className="h-4 w-4 animate-spin" />
        Mai akut betegjelentések betöltése…
      </div>
    );
  }

  if (rows.length === 0) {
    return (
      <div className="rounded-lg border border-emerald-500/30 bg-emerald-500/5 p-4 text-sm flex items-start gap-3">
        <CheckCircle2 className="h-5 w-5 text-emerald-600 shrink-0 mt-0.5" />
        <div>
          <div className="font-semibold text-emerald-700 dark:text-emerald-300">
            Ma nincs akut betegjelentés
          </div>
          <div className="text-xs text-muted-foreground mt-0.5">
            A kollégák a karakterlap Távollétek fülén tudnak akut betegséget jelenteni.
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-lg border-2 border-destructive/40 bg-destructive/5 overflow-hidden">
      <div className="p-4 flex items-center gap-3 border-b border-destructive/20">
        <div className="rounded-full bg-destructive/15 p-2">
          <HeartPulse className="h-5 w-5 text-destructive" />
        </div>
        <div className="flex-1">
          <div className="text-sm font-semibold text-destructive">
            Mai akut betegjelentések ({rows.length})
          </div>
          <div className="text-xs text-muted-foreground mt-0.5">
            Kattintson egy soron a hasonló skill-ű és képzettségű, ma munkára vehető kollégák megjelenítéséhez.
          </div>
        </div>
        <button
          type="button"
          onClick={() => void load()}
          className="inline-flex items-center gap-1.5 px-2 py-1.5 text-xs rounded-md border border-border bg-card hover:bg-accent"
        >
          <RefreshCcw className="h-3 w-3" />
          Frissítés
        </button>
      </div>
      <div className="divide-y divide-destructive/15">
        {rows.map((r) => (
          <AcuteRowItem
            key={r.id}
            row={r}
            open={openId === r.id}
            onToggle={() => setOpenId(openId === r.id ? null : r.id)}
          />
        ))}
      </div>
    </div>
  );
}

function AcuteRowItem({
  row,
  open,
  onToggle,
}: {
  row: AcuteRow;
  open: boolean;
  onToggle: () => void;
}) {
  const { t } = useTranslation();
  const [reps, setReps] = useState<Replacement[] | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!open || reps !== null) return;
    let cancelled = false;
    (async () => {
      setLoading(true);
      const today = new Date().toISOString().slice(0, 10);
      const { data, error } = await (supabase as unknown as {
        rpc: (n: string, p: Record<string, unknown>) => Promise<{ data: unknown; error: { message?: string } | null }>;
      }).rpc("find_acute_replacements", { p_user_id: row.user_id, p_datum: today });
      if (cancelled) return;
      if (error) {
        toast.error(humanizeError(error as Parameters<typeof humanizeError>[0], t));
        setReps([]);
      } else {
        setReps((data ?? []) as Replacement[]);
      }
      setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [open, reps, row.user_id, t]);

  const days = useMemo(() => {
    const d1 = new Date(row.kezdo_datum);
    const d2 = new Date(row.zaro_datum);
    return Math.round((d2.getTime() - d1.getTime()) / 86400000) + 1;
  }, [row]);

  return (
    <div>
      <button
        type="button"
        onClick={onToggle}
        className="w-full text-left p-4 hover:bg-destructive/5 flex items-start gap-3"
      >
        {open ? (
          <ChevronDown className="h-4 w-4 mt-1 text-muted-foreground shrink-0" />
        ) : (
          <ChevronRight className="h-4 w-4 mt-1 text-muted-foreground shrink-0" />
        )}
        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-baseline gap-2">
            <span className="font-semibold">{row.profiles?.teljes_nev ?? "—"}</span>
            <span className="text-xs text-muted-foreground">{row.profiles?.email}</span>
            <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium bg-secondary">
              {row.profiles?.foglalkozas_tipus}
            </span>
          </div>
          <div className="text-xs text-muted-foreground mt-1">
            {row.kezdo_datum} → {row.zaro_datum} ({days} nap)
            {row.leiras && <span className="ml-2 italic">— „{row.leiras}"</span>}
          </div>
        </div>
      </button>
      {open && (
        <div className="px-4 pb-4 pl-11">
          <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">
            Helyettesítési javaslatok mára
          </div>
          {loading && (
            <div className="text-sm text-muted-foreground flex items-center gap-2 py-3">
              <Loader2 className="h-4 w-4 animate-spin" /> Keresés…
            </div>
          )}
          {!loading && reps && reps.length === 0 && (
            <div className="text-sm text-muted-foreground py-3">
              Nincs egyező skill-ű vagy képzettségű kolléga a csapatban.
            </div>
          )}
          {!loading && reps && reps.length > 0 && (
            <div className="rounded-md border border-border bg-card overflow-hidden">
              <table className="w-full text-sm">
                <thead className="bg-muted/50 text-xs uppercase tracking-wider text-muted-foreground">
                  <tr>
                    <th className="text-left px-3 py-2 font-medium">Kolléga</th>
                    <th className="text-left px-3 py-2 font-medium">Egyezések</th>
                    <th className="text-left px-3 py-2 font-medium">Pontszám</th>
                    <th className="text-left px-3 py-2 font-medium">Ma munkára vehető</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {reps.map((p) => (
                    <tr key={p.user_id} className={cn(!p.szabad && "opacity-60")}>
                      <td className="px-3 py-2 align-top">
                        <div className="font-medium">{p.teljes_nev}</div>
                        <div className="text-xs text-muted-foreground">{p.email}</div>
                        {p.pozitiv_kapcsolat && (
                          <span className="inline-flex items-center gap-1 mt-1 text-[10px] text-emerald-700 dark:text-emerald-300">
                            <Heart className="h-3 w-3" /> pozitív kapcsolat
                          </span>
                        )}
                        {p.aktiv_korlatozok.length > 0 && (
                          <div className="flex flex-wrap gap-1 mt-1">
                            {p.aktiv_korlatozok.map((c) => (
                              <span
                                key={c}
                                className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] bg-amber-500/15 text-amber-700 dark:text-amber-300"
                              >
                                {c}
                              </span>
                            ))}
                          </div>
                        )}
                      </td>
                      <td className="px-3 py-2 align-top">
                        <div className="space-y-1 max-w-[260px]">
                          {p.egyezo_skillek.length > 0 && (
                            <div className="flex items-start gap-1 text-xs">
                              <UserCheck className="h-3 w-3 mt-0.5 text-blue-600 shrink-0" />
                              <span className="text-muted-foreground">
                                Skill ({p.egyezo_skill_szam}):{" "}
                                <span className="text-foreground">{p.egyezo_skillek.join(", ")}</span>
                              </span>
                            </div>
                          )}
                          {p.egyezo_kepzettsegek.length > 0 && (
                            <div className="flex items-start gap-1 text-xs">
                              <Award className="h-3 w-3 mt-0.5 text-purple-600 shrink-0" />
                              <span className="text-muted-foreground">
                                Képz. ({p.egyezo_kepz_szam}):{" "}
                                <span className="text-foreground">{p.egyezo_kepzettsegek.join(", ")}</span>
                              </span>
                            </div>
                          )}
                        </div>
                      </td>
                      <td className="px-3 py-2 align-top tabular-nums font-mono font-semibold">
                        {p.match_score}
                      </td>
                      <td className="px-3 py-2 align-top">
                        {p.szabad ? (
                          <span className="inline-flex items-center gap-1 text-emerald-700 dark:text-emerald-300 text-xs font-medium">
                            <CheckCircle2 className="h-3.5 w-3.5" /> Igen
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-red-700 dark:text-red-300 text-xs">
                            <XCircle className="h-3.5 w-3.5" /> Foglalt / kizárt
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
