import { createFileRoute, Link } from "@tanstack/react-router";
import { Wrench, Activity, Heart, Calculator, ChevronRight, Pill, Droplet, Wind, ShieldAlert, Baby } from "lucide-react";

export const Route = createFileRoute("/_authenticated/klinika/eszkozok/")({
  component: ToolkitIndex,
});

type Tool = {
  to: string;
  label: string;
  desc: string;
  Icon: typeof Wrench;
  status: "ready" | "coming";
  group?: string;
};

const TOOLS: Tool[] = [
  {
    to: "/klinika/eszkozok/vergaz",
    label: "Vérgáz Elemző",
    desc: "Sav-bázis · oxigenizáció · anion gap · delta-delta · DDx és folyadékterápiás javaslat.",
    Icon: Activity, status: "ready", group: "Intenzív / Belgyógyászat",
  },
  {
    to: "/klinika/eszkozok/t2dm",
    label: "T2DM Terápiatervező",
    desc: "Komplex 2-es típusú DM terápiaválasztás — HbA1c, GFR, CV-rizikó, endokrin / reprodukciós ág.",
    Icon: Heart, status: "ready", group: "Endokrinológia",
  },
  {
    to: "/klinika/eszkozok/diab",
    label: "Diabétesz Inzulin (ADA 2025)",
    desc: "Inzulin kalkulátor · OAD kombináció · heti VC + grafikon · klinikai protokollok · riasztások.",
    Icon: Pill, status: "ready", group: "Endokrinológia",
  },
  {
    to: "/klinika/eszkozok/kardio",
    label: "CHA₂DS₂-VASc & HAS-BLED",
    desc: "Pitvarfibrilláció — stroke- és vérzéskockázat, antikoaguláns döntéstámogatás (ESC 2024).",
    Icon: Heart, status: "ready", group: "Kardiológia",
  },
  {
    to: "/klinika/eszkozok/vese",
    label: "CKD-EPI 2021 · eGFR",
    desc: "Faj-mentes egyenlet · KDIGO stádium · gyógyszer-dóziskorrekciós javaslat.",
    Icon: Droplet, status: "ready", group: "Nefrológia",
  },
  {
    to: "/klinika/eszkozok/embolia",
    label: "Wells & Geneva (rev.) — PE",
    desc: "Pulmonális embólia klinikai valószínűsége + következő diagnosztikai lépés.",
    Icon: Wind, status: "ready", group: "Sürgősség",
  },
  {
    to: "/klinika/eszkozok/szepszis",
    label: "qSOFA · SOFA · NEWS2",
    desc: "Szepszis-felismerés és korai romlás detektálása (Sepsis-3, NICE NEWS2).",
    Icon: ShieldAlert, status: "ready", group: "Sürgősség",
  },
  {
    to: "/klinika/eszkozok/szules",
    label: "APGAR & Bishop",
    desc: "Újszülött adaptáció + cervix érettség indukció előtt.",
    Icon: Baby, status: "ready", group: "Szülészet",
  },
  {
    to: "/klinika/eszkozok",
    label: "GCS / Glasgow Coma",
    desc: "Tudatállapot pontszám — neurológiai monitorozás. (Fázis 3)",
    Icon: Calculator, status: "coming",
  },
];


function ToolkitIndex() {
  return (
    <div className="container max-w-6xl py-6 space-y-6">
      <header>
        <Link to="/klinika" className="text-xs text-muted-foreground hover:underline">← Klinika</Link>
        <h1 className="text-2xl font-semibold mt-1 flex items-center gap-2">
          <Wrench className="h-6 w-6 text-primary" /> Klinikai eszközök
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Önállóan használható kalkulátorok. Aktív ellátási epizód esetén az eredmény menthető a betegkartonhoz.
        </p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {TOOLS.map((tool) => {
          const isReady = tool.status === "ready";
          const Cmp = isReady ? Link : "div";
          const props = isReady ? { to: tool.to as any } : {};
          return (
            <Cmp
              key={tool.label}
              {...(props as any)}
              className={`block p-5 rounded-xl border border-border bg-card transition-colors ${
                isReady ? "hover:border-primary hover:shadow-sm" : "opacity-60 cursor-not-allowed"
              }`}
            >
              <div className="flex items-start gap-3">
                <div className={`p-2 rounded-lg ${isReady ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"}`}>
                  <tool.Icon className="h-5 w-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-semibold flex items-center gap-2">
                    {tool.label}
                    {!isReady && <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded-full bg-muted text-muted-foreground">hamarosan</span>}
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">{tool.desc}</p>
                </div>
                {isReady && <ChevronRight className="h-4 w-4 text-muted-foreground flex-shrink-0" />}
              </div>
            </Cmp>
          );
        })}
      </div>
    </div>
  );
}
