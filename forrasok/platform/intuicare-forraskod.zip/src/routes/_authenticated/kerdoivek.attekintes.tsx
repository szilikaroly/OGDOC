/**
 * Klinikus / admin áttekintő nézet — Riasztások + Elmaradtak,
 * scoring és subscale szűrőkkel, drill-down dialógussal.
 */
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { StatusBadge } from "@/components/ui/status-badge";
import { severityTone, statusTone } from "@/lib/ui/status-tone";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  ChevronLeft, AlertTriangle, Clock, RefreshCw, Search, Inbox, X,
} from "lucide-react";
import {
  listAlertOverview,
  listOverdueAssignments,
  getResponseDetail,
} from "@/lib/questionnaires/questionnaires.functions";
import { supabase } from "@/integrations/supabase/client";

type Severity = "minimal" | "mild" | "moderate" | "severe" | "critical";
type AlertStatus = "open" | "acknowledged" | "resolved" | "all";

function fmt(iso: string | null | undefined): string {
  if (!iso) return "—";
  return new Date(iso).toLocaleString("hu-HU", {
    year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit",
  });
}
function fmtDate(iso: string | null | undefined): string {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString("hu-HU");
}
function patientName(p: any): string {
  if (!p) return "Anonim";
  return `${p.vezeteknev ?? ""} ${p.keresztnev ?? ""}`.trim() || "Anonim";
}
function sevColor(s: string | null | undefined): "secondary" | "default" | "destructive" {
  if (s === "critical" || s === "severe") return "destructive";
  if (s === "moderate") return "default";
  return "secondary";
}

function ResponseDialog({ responseId, onClose }: { responseId: string | null; onClose: () => void }) {
  const fn = useServerFn(getResponseDetail);
  const q = useQuery({
    queryKey: ["response-detail", responseId],
    queryFn: () => fn({ data: { response_id: responseId! } }),
    enabled: !!responseId,
  });

  return (
    <Dialog open={!!responseId} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Válasz részletei</DialogTitle>
        </DialogHeader>
        {q.isLoading && <Skeleton className="h-40 w-full" />}
        {q.isError && (
          <p className="text-sm text-destructive">{(q.error as Error).message}</p>
        )}
        {q.data && (() => { const d: any = q.data; return (
          <div className="space-y-4 text-sm">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <div className="text-xs text-muted-foreground">Páciens</div>
                <div className="font-medium">{patientName(d.patients)}</div>
                {d.patients?.taj && (
                  <div className="text-xs text-muted-foreground">TAJ: {d.patients.taj}</div>
                )}
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Kérdőív</div>
                <div className="font-medium">
                  {d.questionnaires?.code} — {d.questionnaires?.title}
                </div>
                <div className="text-xs text-muted-foreground">{fmt(d.completed_at)}</div>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <StatusBadge tone={severityTone(d.severity)} pill>Severity: {d.severity ?? "—"}</StatusBadge>
              <StatusBadge tone="neutral" pill>Total: {d.total_score ?? "—"}</StatusBadge>
              {d.critical_triggered && (
                <StatusBadge tone="bad" pill icon={<AlertTriangle className="h-3 w-3" />}>
                  Kritikus
                </StatusBadge>
              )}
            </div>

            {d.subscale_scores && Object.keys(d.subscale_scores).length > 0 && (
              <section>
                <h3 className="mb-1 text-xs font-semibold uppercase text-muted-foreground">Subscale</h3>
                <Table>
                  <TableHeader>
                    <TableRow><TableHead>Kulcs</TableHead><TableHead>Érték</TableHead></TableRow>
                  </TableHeader>
                  <TableBody>
                    {Object.entries(d.subscale_scores).map(([k, v]) => (
                      <TableRow key={k}>
                        <TableCell className="font-mono text-xs">{k}</TableCell>
                        <TableCell>{String(v)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </section>
            )}

            <section>
              <h3 className="mb-1 text-xs font-semibold uppercase text-muted-foreground">Válaszok</h3>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12">#</TableHead>
                    <TableHead>Kérdés</TableHead>
                    <TableHead className="w-20">Érték</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {Object.entries((d.answers ?? {}) as Record<string, number>)
                    .sort((a, b) => Number(a[0]) - Number(b[0]))
                    .map(([idx, val]) => {
                      const items = d.questionnaires?.items as any[] | undefined;
                      const item = items?.[Number(idx)];
                      return (
                        <TableRow key={idx}>
                          <TableCell>{Number(idx) + 1}</TableCell>
                          <TableCell className="text-xs">{item?.text ?? "—"}</TableCell>
                          <TableCell className="font-mono">{val}</TableCell>
                        </TableRow>
                      );
                    })}
                </TableBody>
              </Table>
            </section>
          </div>
        ); })()}
      </DialogContent>
    </Dialog>
  );
}

function AttekintesPage() {
  // Kérdőív lista a szűrőhöz
  const questionnaires = useQuery({
    queryKey: ["questionnaires-min"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("questionnaires")
        .select("id, code, title")
        .eq("aktiv", true)
        .order("code");
      if (error) throw new Error(error.message);
      return data ?? [];
    },
  });

  // Szűrők
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [questionnaireId, setQuestionnaireId] = useState<string>("");
  const [severity, setSeverity] = useState<Severity | "">("");
  const [minTotal, setMinTotal] = useState("");
  const [maxTotal, setMaxTotal] = useState("");
  const [subscaleKey, setSubscaleKey] = useState("");
  const [subscaleMin, setSubscaleMin] = useState("");
  const [alertStatus, setAlertStatus] = useState<AlertStatus>("open");
  const [overdueScope, setOverdueScope] = useState<"expired" | "overdue_open" | "all">("all");
  const [search, setSearch] = useState("");
  const [tab, setTab] = useState<"alerts" | "overdue">("alerts");
  const [openResponse, setOpenResponse] = useState<string | null>(null);

  const alertParams = useMemo(() => ({
    from: from || undefined,
    to: to || undefined,
    questionnaire_id: questionnaireId || undefined,
    severity: (severity || undefined) as Severity | undefined,
    min_total: minTotal !== "" ? Number(minTotal) : undefined,
    max_total: maxTotal !== "" ? Number(maxTotal) : undefined,
    subscale_key: subscaleKey || undefined,
    subscale_min: subscaleMin !== "" ? Number(subscaleMin) : undefined,
    alert_status: alertStatus,
  }), [from, to, questionnaireId, severity, minTotal, maxTotal, subscaleKey, subscaleMin, alertStatus]);

  const overdueParams = useMemo(() => ({
    from: from || undefined,
    to: to || undefined,
    questionnaire_id: questionnaireId || undefined,
    scope: overdueScope,
  }), [from, to, questionnaireId, overdueScope]);

  const alertsFn = useServerFn(listAlertOverview);
  const overdueFn = useServerFn(listOverdueAssignments);

  const alerts = useQuery({
    queryKey: ["overview-alerts", alertParams],
    queryFn: () => alertsFn({ data: alertParams }),
    enabled: tab === "alerts",
    retry: 2,
  });
  const overdue = useQuery({
    queryKey: ["overview-overdue", overdueParams],
    queryFn: () => overdueFn({ data: overdueParams }),
    enabled: tab === "overdue",
    retry: 2,
  });

  const filterByText = <T extends any[]>(rows: T, pick: (r: any) => string): T => {
    const s = search.trim().toLowerCase();
    if (!s) return rows;
    return rows.filter((r: any) => pick(r).toLowerCase().includes(s)) as T;
  };

  const alertRows = useMemo(() => filterByText(alerts.data ?? [], (r) => {
    const p = patientName(r.patients);
    const q = `${r.questionnaire_responses?.questionnaires?.code ?? ""} ${r.questionnaire_responses?.questionnaires?.title ?? ""}`;
    return `${p} ${q} ${r.alert_type} ${r.patients?.taj ?? ""}`;
  }), [alerts.data, search]);

  const overdueRows = useMemo(() => filterByText(overdue.data ?? [], (r) => {
    const p = patientName(r.patients);
    return `${p} ${r.questionnaires?.code ?? ""} ${r.questionnaires?.title ?? ""} ${r.patients?.taj ?? ""}`;
  }), [overdue.data, search]);

  const resetFilters = () => {
    setFrom(""); setTo(""); setQuestionnaireId(""); setSeverity(""); setMinTotal("");
    setMaxTotal(""); setSubscaleKey(""); setSubscaleMin(""); setAlertStatus("open");
    setOverdueScope("all"); setSearch("");
  };

  return (
    <main className="container mx-auto px-4 py-8">
      <header className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Link to="/kerdoivek" className="text-sm text-primary hover:underline">
            <ChevronLeft className="inline h-4 w-4" /> Vissza
          </Link>
          <div>
            <h1 className="text-2xl font-bold">Klinikai áttekintés</h1>
            <p className="text-sm text-muted-foreground">
              Kritikus riasztások és elmaradt kérdőívek áttekintése scoring + subscale szűrőkkel.
            </p>
          </div>
        </div>
        <Button
          variant="outline" size="sm"
          onClick={() => (tab === "alerts" ? alerts.refetch() : overdue.refetch())}
          disabled={tab === "alerts" ? alerts.isFetching : overdue.isFetching}
        >
          <RefreshCw className={`mr-2 h-4 w-4 ${(tab === "alerts" ? alerts.isFetching : overdue.isFetching) ? "animate-spin" : ""}`} />
          Frissítés
        </Button>
      </header>

      {/* Szűrők */}
      <section className="mb-4 grid grid-cols-2 gap-3 md:grid-cols-6">
        <div className="md:col-span-2 relative">
          <Label className="mb-1 block text-xs">Keresés</Label>
          <Search className="pointer-events-none absolute left-2 top-[34px] h-4 w-4 text-muted-foreground" />
          <Input className="pl-8" value={search} onChange={(e) => setSearch(e.target.value)}
            placeholder="Páciens, TAJ, kérdőív…" />
        </div>
        <div>
          <Label className="mb-1 block text-xs">Dátum-tól</Label>
          <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
        </div>
        <div>
          <Label className="mb-1 block text-xs">Dátum-ig</Label>
          <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
        </div>
        <div className="md:col-span-2">
          <Label className="mb-1 block text-xs">Kérdőív</Label>
          <Select value={questionnaireId || "__all"} onValueChange={(v) => setQuestionnaireId(v === "__all" ? "" : v)}>
            <SelectTrigger><SelectValue placeholder="Mind" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="__all">Mind</SelectItem>
              {(questionnaires.data ?? []).map((q: any) => (
                <SelectItem key={q.id} value={q.id}>{q.code} — {q.title}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {tab === "alerts" && (
          <>
            <div>
              <Label className="mb-1 block text-xs">Severity</Label>
              <Select value={severity || "__all"} onValueChange={(v) => setSeverity(v === "__all" ? "" : (v as Severity))}>
                <SelectTrigger><SelectValue placeholder="Mind" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="__all">Mind</SelectItem>
                  <SelectItem value="minimal">minimal</SelectItem>
                  <SelectItem value="mild">mild</SelectItem>
                  <SelectItem value="moderate">moderate</SelectItem>
                  <SelectItem value="severe">severe</SelectItem>
                  <SelectItem value="critical">critical</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="mb-1 block text-xs">Riasztás státusza</Label>
              <Select value={alertStatus} onValueChange={(v) => setAlertStatus(v as AlertStatus)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="open">Nyitott</SelectItem>
                  <SelectItem value="acknowledged">Tudomásul véve</SelectItem>
                  <SelectItem value="resolved">Lezárt</SelectItem>
                  <SelectItem value="all">Mind</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="mb-1 block text-xs">Total ≥</Label>
              <Input type="number" inputMode="numeric" value={minTotal} onChange={(e) => setMinTotal(e.target.value)} />
            </div>
            <div>
              <Label className="mb-1 block text-xs">Total ≤</Label>
              <Input type="number" inputMode="numeric" value={maxTotal} onChange={(e) => setMaxTotal(e.target.value)} />
            </div>
            <div>
              <Label className="mb-1 block text-xs">Subscale kulcs</Label>
              <Input value={subscaleKey} onChange={(e) => setSubscaleKey(e.target.value)} placeholder="pl. anxiety" />
            </div>
            <div>
              <Label className="mb-1 block text-xs">Subscale ≥</Label>
              <Input type="number" inputMode="numeric" value={subscaleMin} onChange={(e) => setSubscaleMin(e.target.value)} />
            </div>
          </>
        )}

        {tab === "overdue" && (
          <div className="md:col-span-2">
            <Label className="mb-1 block text-xs">Kör</Label>
            <Select value={overdueScope} onValueChange={(v) => setOverdueScope(v as any)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Mind (lejárt nyitott + expired)</SelectItem>
                <SelectItem value="overdue_open">Lejárt, még nyitott</SelectItem>
                <SelectItem value="expired">Lezárult (expired)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        )}
      </section>

      <div className="mb-4 flex items-center justify-between">
        <Button variant="ghost" size="sm" className="h-8 px-2 text-xs" onClick={resetFilters}>
          <X className="mr-1 h-3 w-3" /> Szűrők törlése
        </Button>
      </div>

      <Tabs value={tab} onValueChange={(v) => setTab(v as any)}>
        <TabsList>
          <TabsTrigger value="alerts">
            Riasztások {alerts.data ? `(${alertRows.length})` : ""}
          </TabsTrigger>
          <TabsTrigger value="overdue">
            Elmaradtak {overdue.data ? `(${overdueRows.length})` : ""}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="alerts" className="mt-4">
          {alerts.isLoading && <Skeleton className="h-64 w-full" />}
          {alerts.isError && (
            <Card className="border-destructive/40">
              <CardContent className="flex flex-col items-start gap-3 p-6">
                <div className="flex items-center gap-2 text-destructive">
                  <AlertTriangle className="h-5 w-5" />
                  <h2 className="text-base font-semibold">Nem sikerült betölteni a riasztásokat</h2>
                </div>
                <p className="text-sm text-muted-foreground">{(alerts.error as Error).message}</p>
                <Button size="sm" onClick={() => alerts.refetch()}>Újrapróbálás</Button>
              </CardContent>
            </Card>
          )}
          {!alerts.isLoading && !alerts.isError && alertRows.length === 0 && (
            <Card><CardContent className="flex flex-col items-center gap-3 p-10 text-center">
              <Inbox className="h-10 w-10 text-muted-foreground" />
              <p className="text-sm text-muted-foreground">Nincs a szűrésnek megfelelő riasztás.</p>
            </CardContent></Card>
          )}
          {alertRows.length > 0 && (
            <Card><CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Idő</TableHead>
                    <TableHead>Páciens</TableHead>
                    <TableHead>Kérdőív</TableHead>
                    <TableHead>Típus</TableHead>
                    <TableHead>Severity</TableHead>
                    <TableHead>Total</TableHead>
                    <TableHead>Állapot</TableHead>
                    <TableHead></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {alertRows.map((r: any) => {
                    const qr = r.questionnaire_responses;
                    return (
                      <TableRow key={r.id}>
                        <TableCell className="text-xs">{fmt(r.created_at)}</TableCell>
                        <TableCell>
                          <div className="font-medium">{patientName(r.patients)}</div>
                          {r.patients?.taj && (
                            <div className="text-xs text-muted-foreground">TAJ: {r.patients.taj}</div>
                          )}
                        </TableCell>
                        <TableCell className="text-xs">
                          {qr?.questionnaires?.code} — {qr?.questionnaires?.title}
                        </TableCell>
                        <TableCell><StatusBadge tone="neutral" pill>{r.alert_type}</StatusBadge></TableCell>
                        <TableCell><StatusBadge tone={severityTone(qr?.severity)} pill>{qr?.severity ?? "—"}</StatusBadge></TableCell>
                        <TableCell className="font-mono">{qr?.total_score ?? "—"}</TableCell>
                        <TableCell>
                          <StatusBadge tone={statusTone(r.status)} pill>{r.status}</StatusBadge>
                        </TableCell>
                        <TableCell>
                          <Button size="sm" variant="outline" onClick={() => setOpenResponse(r.response_id)}>
                            Részletek
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent></Card>
          )}
        </TabsContent>

        <TabsContent value="overdue" className="mt-4">
          {overdue.isLoading && <Skeleton className="h-64 w-full" />}
          {overdue.isError && (
            <Card className="border-destructive/40">
              <CardContent className="flex flex-col items-start gap-3 p-6">
                <div className="flex items-center gap-2 text-destructive">
                  <AlertTriangle className="h-5 w-5" />
                  <h2 className="text-base font-semibold">Nem sikerült betölteni az elmaradtakat</h2>
                </div>
                <p className="text-sm text-muted-foreground">{(overdue.error as Error).message}</p>
                <Button size="sm" onClick={() => overdue.refetch()}>Újrapróbálás</Button>
              </CardContent>
            </Card>
          )}
          {!overdue.isLoading && !overdue.isError && overdueRows.length === 0 && (
            <Card><CardContent className="flex flex-col items-center gap-3 p-10 text-center">
              <Inbox className="h-10 w-10 text-muted-foreground" />
              <p className="text-sm text-muted-foreground">Nincs a szűrésnek megfelelő elmaradt kérdőív.</p>
            </CardContent></Card>
          )}
          {overdueRows.length > 0 && (
            <Card><CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Esedékesség</TableHead>
                    <TableHead>Páciens</TableHead>
                    <TableHead>Kérdőív</TableHead>
                    <TableHead>Kiosztva</TableHead>
                    <TableHead>Állapot</TableHead>
                    <TableHead>Emlékeztetők</TableHead>
                    <TableHead>Becsült</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {overdueRows.map((r: any) => (
                    <TableRow key={r.id}>
                      <TableCell className="text-xs">{fmtDate(r.due_at)}</TableCell>
                      <TableCell>
                        <div className="font-medium">{patientName(r.patients)}</div>
                        {r.patients?.taj && (
                          <div className="text-xs text-muted-foreground">TAJ: {r.patients.taj}</div>
                        )}
                      </TableCell>
                      <TableCell className="text-xs">
                        {r.questionnaires?.code} — {r.questionnaires?.title}
                      </TableCell>
                      <TableCell className="text-xs">{fmtDate(r.assigned_at)}</TableCell>
                      <TableCell>
                        <StatusBadge tone={r.status === "expired" ? "bad" : "warn"} pill>
                          {r.status === "expired" ? "lezárult" : "lejárt, nyitott"}
                        </StatusBadge>
                      </TableCell>
                      <TableCell className="font-mono">{r.reminder_count ?? 0}</TableCell>
                      <TableCell className="text-xs">
                        {r.questionnaires?.becsult_perc != null ? (
                          <span className="inline-flex items-center gap-1">
                            <Clock className="h-3 w-3" /> {r.questionnaires.becsult_perc} p
                          </span>
                        ) : "—"}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent></Card>
          )}
        </TabsContent>
      </Tabs>

      <ResponseDialog responseId={openResponse} onClose={() => setOpenResponse(null)} />
    </main>
  );
}

export const Route = createFileRoute("/_authenticated/kerdoivek/attekintes")({
  component: AttekintesPage,
});
