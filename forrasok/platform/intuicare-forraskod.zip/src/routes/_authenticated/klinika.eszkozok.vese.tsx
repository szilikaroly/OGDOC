import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Droplet } from "lucide-react";
import { CalculatorShell, Card, Field, NumberInput, ScoreBadge } from "@/components/clinical/calc-shell";
import { ckdEpi2021, type CkdEpiInput, type Sex } from "@/lib/clinical/scores";

export const Route = createFileRoute("/_authenticated/klinika/eszkozok/vese")({
  validateSearch: (s: Record<string, unknown>): { encounterId?: string; patientId?: string } => ({
    encounterId: typeof s.encounterId === "string" ? s.encounterId : undefined,
    patientId: typeof s.patientId === "string" ? s.patientId : undefined,
  }),
  component: VesePage,
});

function VesePage() {
  const [i, setI] = useState<CkdEpiInput>({ age: 60, sex: "M", creatinine_umol_l: 80 });
  const r = useMemo(() => ckdEpi2021(i), [i]);
  const tone = r.stage === "G5" || r.stage === "G4" ? "danger" : r.stage === "G3a" || r.stage === "G3b" ? "warn" : "ok";

  return (
    <CalculatorShell
      title="Vesefunkció — CKD-EPI 2021"
      subtitle="Faj-mentes egyenlet · KDIGO stádium · gyógyszer-dóziskorrekció."
      Icon={Droplet}
      fromRoute="/_authenticated/klinika/eszkozok/vese"
      onReset={() => setI({ age: 60, sex: "M", creatinine_umol_l: 80 })}
      getSaveBundle={() => ({
        calculator: "ckd_epi_2021", inputs: i, outputs: r,
        interpretation_md: `**eGFR:** ${r.egfr.toFixed(1)} ml/min/1,73 m² · **${r.stage}** — ${r.description}\n\n${r.recommendation}`,
      })}
    >
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card title="Bemenetek">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Életkor (év)"><NumberInput value={i.age} onChange={(v) => setI({ ...i, age: v ?? 0 })} /></Field>
            <Field label="Nem">
              <select value={i.sex} onChange={(e) => setI({ ...i, sex: e.target.value as Sex })} className="w-full px-2 py-1.5 text-sm rounded-md border border-border bg-background">
                <option value="M">Férfi</option><option value="F">Nő</option>
              </select>
            </Field>
            <Field label="Szérum kreatinin (µmol/L)" hint="44–115"><NumberInput value={i.creatinine_umol_l} onChange={(v) => setI({ ...i, creatinine_umol_l: v ?? 0 })} /></Field>
          </div>
        </Card>
        <Card title="Eredmény" footer={r.recommendation}>
          <ScoreBadge score={r.egfr.toFixed(1)} label="ml/min/1,73 m²" tone={tone} />
          <div className="text-sm">Stádium: <span className="font-mono font-semibold">{r.stage}</span> — {r.description}</div>
          <div className="text-xs text-muted-foreground mt-2">
            CKD-EPI 2021 (NEJM 2021) — etnikum-faktor eltávolítva. KDIGO 2024 szerint az albumin/kreatinin arány (ACR) együtt értelmezendő a stádiummal.
          </div>
        </Card>
      </div>
    </CalculatorShell>
  );
}
