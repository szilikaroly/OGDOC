import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Loader2, CalendarRange, ChevronLeft, ChevronRight, Pin, Trash2, X, AlertTriangle, Wand2, Printer, Link2 } from "lucide-react";
import { ShareLinkModal } from "@/components/beosztas/share-link-modal";
import { openSchedulePrint } from "@/lib/schedule-print";
import { summarizeSchedule } from "@/lib/ai-schedule.functions";
import { useServerFn } from "@tanstack/react-start";
import { generateSchedule, type DailyDemand } from "@/lib/scheduling/generate";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { usePermissions } from "@/hooks/use-permissions";
import { useTranslation } from "react-i18next";
import { humanizeError } from "@/lib/humanize-error";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { RunsPanel, CellExplanations } from "@/components/beosztas/runs-panel";
import { DemandEditor } from "@/components/beosztas/demand-editor";

export const Route = createFileRoute("/_authenticated/beosztas")({
  component: BeosztasPage,
});

type Assignment = {
  id: string;
  user_id: string;
  kezdo_idopont: string;
  zaro_idopont: string;
  ora: number;
  kategoria: string;
  status: string;
  pin: boolean;
  megjegyzes: string | null;
};

type Person = { id: string; teljes_nev: string; foglalkozas_tipus: string };

type Rule = {
  napi_max_ora: number;
  heti_max_ora: number;
  napi_pihenes_min_ora: number;
};

const KAT_COLOR: Record<string, string> = {
  rendes: "bg-sky-500/20 text-sky-700 dark:text-sky-300 border-sky-500/40",
  ugyelet: "bg-violet-500/20 text-violet-700 dark:text-violet-300 border-violet-500/40",
  keszenlet: "bg-amber-500/20 text-amber-700 dark:text-amber-300 border-amber-500/40",
  rendkivuli: "bg-rose-500/20 text-rose-700 dark:text-rose-300 border-rose-500/40",
  ovt: "bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border-emerald-500/40",
  szabadnap: "bg-muted text-muted-foreground border-muted",
};
const KATEGORIAK = ["rendes", "ugyelet", "keszenlet", "rendkivuli", "ovt", "szabadnap"];

function daysInMonth(monthStart: Date): Date[] {
  const days: Date[] = [];
  const y = monthStart.getFullYear();
  const m = monthStart.getMonth();
  for (let d = 1; d <= new Date(y, m + 1, 0).getDate(); d++) {
    days.push(new Date(y, m, d));
  }
  return days;
}

function isoDate(d: Date): string {
  return d.toISOString().slice(0, 10);
}

function hoursBetween(a: string, b: string): number {
  return (new Date(b).getTime() - new Date(a).getTime()) / 3_600_000;
}

function BeosztasPage() {
  const { user } = useAuth();
  const { t } = useTranslation();
  const { can } = usePermissions();
  const canEdit = can("manage_schedule") || can("manage_tenant");
  const aiSummaryFn = useServerFn(summarizeSchedule);
  const [tenantId, setTenantId] = useState<string | null>(null);
  const [people, setPeople] = useState<Person[]>([]);
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [rule, setRule] = useState<Rule | null>(null);
  const [month, setMonth] = useState(() => {
    const n = new Date();
    return new Date(n.getFullYear(), n.getMonth(), 1);
  });
  const [loading, setLoading] = useState(true);
  const [editCell, setEditCell] = useState<{ userId: string; date: Date } | null>(null);
  const [demandOpen, setDemandOpen] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [prefOverlay, setPrefOverlay] = useState(false);
  const [prefMap, setPrefMap] = useState<Map<string, "pref" | "avoid">>(new Map());
  // Csak saját nézet — alapból be, ha a felhasználó nem szerkesztheti a beosztást
  const [onlyMine, setOnlyMine] = useState(true);
  useEffect(() => { if (canEdit) setOnlyMine(false); }, [canEdit]);

  const visiblePeople = useMemo(
    () => (onlyMine && user ? people.filter((p) => p.id === user.id) : people),
    [people, onlyMine, user],
  );

  useEffect(() => {
    if (!user) return;
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, month]);

  async function load() {
    if (!user) return;
    setLoading(true);
    try {
      const { data: prof } = await supabase.from("profiles").select("tenant_id").eq("id", user.id).maybeSingle();
      const tid = (prof as any)?.tenant_id ?? null;
      setTenantId(tid);

      const start = isoDate(month);
      const endDate = new Date(month.getFullYear(), month.getMonth() + 1, 1);
      const end = isoDate(endDate);

      const [{ data: pp }, { data: aa }, { data: rr }, { data: dp }] = await Promise.all([
        supabase
          .from("profiles")
          .select("id,teljes_nev,foglalkozas_tipus")
          .eq("aktiv", true)
          .order("teljes_nev"),
        supabase
          .from("schedule_assignments")
          .select("id,user_id,kezdo_idopont,zaro_idopont,ora,kategoria,status,pin,megjegyzes")
          .gte("kezdo_idopont", `${start}T00:00:00`)
          .lt("kezdo_idopont", `${end}T00:00:00`),
        supabase
          .from("work_time_rules")
          .select("napi_max_ora,heti_max_ora,napi_pihenes_min_ora")
          .limit(1)
          .maybeSingle(),
        supabase
          .from("profile_daily_preferences")
          .select("user_id,nap_iso,preferalt_kezd,preferalt_veg,kerult_kezd,kerult_veg")
          .is("ervenyes_ig", null),
      ]);
      setPeople((pp ?? []) as Person[]);
      setAssignments((aa ?? []) as Assignment[]);
      setRule((rr ?? null) as Rule | null);
      const pm = new Map<string, "pref" | "avoid">();
      for (const p of (dp ?? []) as Array<{ user_id: string; nap_iso: number; preferalt_kezd: string | null; kerult_kezd: string | null }>) {
        const key = `${p.user_id}|${p.nap_iso}`;
        if (p.kerult_kezd) pm.set(key, "avoid");
        else if (p.preferalt_kezd) pm.set(key, "pref");
      }
      setPrefMap(pm);
    } catch (e) {
      toast.error(humanizeError(e as Error, t));
    } finally {
      setLoading(false);
    }
  }

  const days = useMemo(() => daysInMonth(month), [month]);

  const byCell = useMemo(() => {
    const m = new Map<string, Assignment[]>();
    for (const a of assignments) {
      const key = `${a.user_id}|${a.kezdo_idopont.slice(0, 10)}`;
      const arr = m.get(key) ?? [];
      arr.push(a);
      m.set(key, arr);
    }
    return m;
  }, [assignments]);

  // Hard-rule violations per assignment id
  const violations = useMemo(() => {
    const v = new Map<string, string[]>();
    if (!rule) return v;
    // sort by user + start
    const byUser = new Map<string, Assignment[]>();
    for (const a of assignments) {
      const arr = byUser.get(a.user_id) ?? [];
      arr.push(a);
      byUser.set(a.user_id, arr);
    }
    for (const list of byUser.values()) {
      list.sort((a, b) => a.kezdo_idopont.localeCompare(b.kezdo_idopont));
      // Daily max
      const byDay = new Map<string, Assignment[]>();
      for (const a of list) {
        const d = a.kezdo_idopont.slice(0, 10);
        (byDay.get(d) ?? byDay.set(d, []).get(d)!).push(a);
      }
      for (const [, dayList] of byDay) {
        const sum = dayList.reduce((s, x) => s + Number(x.ora), 0);
        if (sum > rule.napi_max_ora) {
          for (const a of dayList) {
            const cur = v.get(a.id) ?? [];
            cur.push(`Napi max túllépés (${sum.toFixed(1)} > ${rule.napi_max_ora}h)`);
            v.set(a.id, cur);
          }
        }
      }
      // Daily rest
      for (let i = 1; i < list.length; i++) {
        const rest = hoursBetween(list[i - 1].zaro_idopont, list[i].kezdo_idopont);
        if (rest >= 0 && rest < rule.napi_pihenes_min_ora) {
          const cur = v.get(list[i].id) ?? [];
          cur.push(`Pihenőidő ${rest.toFixed(1)}h < ${rule.napi_pihenes_min_ora}h`);
          v.set(list[i].id, cur);
        }
      }
    }
    return v;
  }, [assignments, rule]);

  function shiftMonth(delta: number) {
    setMonth(new Date(month.getFullYear(), month.getMonth() + delta, 1));
  }

  async function moveAssignment(assignmentId: string, toUserId: string, toDate: Date) {
    const a = assignments.find((x) => x.id === assignmentId);
    if (!a) return;
    if (a.pin) return toast.error("Rögzített (pin) műszak nem mozgatható.");
    const oldStart = new Date(a.kezdo_idopont);
    const oldEnd = new Date(a.zaro_idopont);
    const dayMs = (oldEnd.getTime() - oldStart.getTime());
    const newStart = new Date(toDate);
    newStart.setHours(oldStart.getHours(), oldStart.getMinutes(), 0, 0);
    const newEnd = new Date(newStart.getTime() + dayMs);
    const prev = assignments;
    setAssignments(assignments.map((x) => x.id === assignmentId
      ? { ...x, user_id: toUserId, kezdo_idopont: newStart.toISOString(), zaro_idopont: newEnd.toISOString() }
      : x));
    const { error } = await (supabase.from("schedule_assignments") as any)
      .update({ user_id: toUserId, kezdo_idopont: newStart.toISOString(), zaro_idopont: newEnd.toISOString() })
      .eq("id", assignmentId);
    if (error) {
      setAssignments(prev);
      toast.error(humanizeError(error, t));
    } else {
      toast.success("Műszak áthelyezve");
    }
  }

  if (loading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="p-4 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <CalendarRange className="h-6 w-6 text-primary" />
          <div>
            <h1 className="text-2xl font-semibold">Beosztás</h1>
            <p className="text-xs text-muted-foreground">
              Havi grid · kemény-szabály ellenőrzés · {canEdit ? "kézi szerkesztés" : "olvasás"}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => shiftMonth(-1)} className="rounded border p-1.5 hover:bg-accent">
            <ChevronLeft className="h-4 w-4" />
          </button>
          <span className="font-mono text-sm w-28 text-center">
            {month.toLocaleString("hu-HU", { year: "numeric", month: "long" })}
          </span>
          <button onClick={() => shiftMonth(1)} className="rounded border p-1.5 hover:bg-accent">
            <ChevronRight className="h-4 w-4" />
          </button>
          <button
            onClick={() => setPrefOverlay((v) => !v)}
            className={cn("ml-2 rounded border px-2 py-1 text-xs", prefOverlay && "bg-primary/15 border-primary text-primary")}
            title="Preferencia overlay: zöld = preferált nap, piros = került nap"
          >
            Preferencia overlay {prefOverlay ? "be" : "ki"}
          </button>
          <button
            onClick={() => setOnlyMine((v) => !v)}
            className={cn("ml-1 rounded border px-2 py-1 text-xs", onlyMine && "bg-primary/15 border-primary text-primary")}
            title={onlyMine ? "Csak a saját műszakaim láthatók" : "Teljes csapat látható"}
          >
            {onlyMine ? "Csak saját" : "Csapat"}
          </button>

          <button
            onClick={async (e) => {
              const cells = new Map<string, Array<{ kategoria: string; ora: number; start: string }>>();
              byCell.forEach((arr, k) => cells.set(k, arr.map((a) => ({ kategoria: a.kategoria, ora: a.ora, start: a.kezdo_idopont }))));
              const monthLabel = month.toLocaleString("hu-HU", { year: "numeric", month: "long" });
              let aiSummary: string | undefined;
              if (e.shiftKey) {
                try {
                  const perPerson = people.map((p) => {
                    const ass = assignments.filter((a) => a.user_id === p.id);
                    const sum = (k: string) => ass.filter((a) => a.kategoria === k).reduce((s, a) => s + Number(a.ora), 0);
                    return { nev: p.teljes_nev, rendes: sum("rendes"), ugyelet: sum("ugyelet"), keszenlet: sum("keszenlet") };
                  });
                  const r = await aiSummaryFn({ data: { monthLabel, perPerson } });
                  aiSummary = r.summary;
                } catch (err: any) {
                  toast.error(err?.message ?? "AI összefoglaló hiba");
                }
              }
              openSchedulePrint({ monthLabel, days, people, cells, aiSummary });
            }}
            className="ml-2 flex items-center gap-1 rounded border px-2 py-1 text-xs hover:bg-accent"
            title="Nyomtatható havi beosztás (A3). Shift+kattintás: AI összefoglalóval."
          >
            <Printer className="h-3 w-3" /> PDF
          </button>
          {canEdit && tenantId && (
            <button
              onClick={() => setShareOpen(true)}
              className="ml-2 flex items-center gap-1 rounded border px-2 py-1 text-xs hover:bg-accent"
              title="Csak olvasható megosztó link létrehozása"
            >
              <Link2 className="h-3 w-3" /> Megosztás
            </button>
          )}
          {canEdit && tenantId && user && (
            <button
              onClick={() => setDemandOpen(true)}
              className="ml-2 flex items-center gap-1 rounded bg-primary px-3 py-1.5 text-sm text-primary-foreground hover:opacity-90"
            >
              <Wand2 className="h-4 w-4" /> Generálás…
            </button>
          )}
        </div>
      </div>

      <div className="flex flex-wrap gap-2 text-xs">
        {KATEGORIAK.map((k) => (
          <span key={k} className={cn("px-2 py-0.5 rounded border font-mono", KAT_COLOR[k])}>{k}</span>
        ))}
      </div>

      <div className="rounded-lg border bg-card overflow-auto">
        <table className="text-[10px] border-collapse">
          <thead className="sticky top-0 bg-card z-10">
            <tr>
              <th className="sticky left-0 bg-card border-r border-b px-2 py-1 text-left min-w-[160px] z-20">Munkatárs</th>
              {days.map((d) => {
                const dow = d.getDay();
                return (
                  <th key={isoDate(d)} className={cn("border-b border-r px-1 py-1 text-center min-w-[44px]", (dow === 0 || dow === 6) && "bg-muted/40")}>
                    <div className="font-mono">{d.getDate()}</div>
                    <div className="text-[9px] text-muted-foreground">{["V","H","K","Sz","Cs","P","Szo"][dow]}</div>
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {visiblePeople.map((p) => (
              <tr key={p.id}>
                <td className="sticky left-0 bg-card border-r border-b px-2 py-1 z-10">
                  <div className="font-medium text-xs">{p.teljes_nev}</div>
                  <div className="text-[9px] text-muted-foreground font-mono">{p.foglalkozas_tipus}</div>
                </td>
                {days.map((d) => {
                  const key = `${p.id}|${isoDate(d)}`;
                  const cell = byCell.get(key) ?? [];
                  const hasViolation = cell.some((a) => violations.has(a.id));
                  const napIso = ((d.getDay() + 6) % 7) + 1;
                  const pref = prefOverlay ? prefMap.get(`${p.id}|${napIso}`) : undefined;
                  return (
                    <td
                      key={key}
                      className={cn(
                        "border-b border-r p-0.5 align-top cursor-pointer hover:bg-accent/30",
                        (d.getDay() === 0 || d.getDay() === 6) && "bg-muted/20",
                        pref === "pref" && "bg-emerald-500/10",
                        pref === "avoid" && "bg-rose-500/10",
                      )}
                      onClick={() => canEdit && setEditCell({ userId: p.id, date: d })}
                      onDragOver={(e) => { if (canEdit) e.preventDefault(); }}
                      onDrop={(e) => {
                        if (!canEdit) return;
                        e.preventDefault();
                        const id = e.dataTransfer.getData("text/assignment-id");
                        if (id) void moveAssignment(id, p.id, d);
                      }}
                      title={pref === "pref" ? "Preferált nap" : pref === "avoid" ? "Került nap" : canEdit ? "Kattintson szerkesztéshez vagy húzza át a műszakot" : ""}
                    >
                      <div className="flex flex-col gap-0.5">
                        {cell.map((a) => (
                          <div
                            key={a.id}
                            draggable={canEdit && !a.pin}
                            onDragStart={(e) => {
                              e.stopPropagation();
                              e.dataTransfer.setData("text/assignment-id", a.id);
                              e.dataTransfer.effectAllowed = "move";
                            }}
                            onClick={(e) => e.stopPropagation()}
                            className={cn("rounded border px-1 py-0.5 leading-tight", KAT_COLOR[a.kategoria] ?? KAT_COLOR.rendes, violations.has(a.id) && "ring-1 ring-rose-500", canEdit && !a.pin && "cursor-grab active:cursor-grabbing")}
                            title={(violations.get(a.id) ?? []).join(" · ")}
                          >
                            <div className="flex items-center gap-0.5">
                              {a.pin && <Pin className="h-2 w-2" />}
                              {violations.has(a.id) && <AlertTriangle className="h-2 w-2 text-rose-600" />}
                              <span className="font-mono">{a.kezdo_idopont.slice(11, 16)}</span>
                            </div>
                            <div className="font-mono">{Number(a.ora).toFixed(0)}h</div>
                          </div>
                        ))}
                        {hasViolation && cell.length === 0 && (
                          <AlertTriangle className="h-3 w-3 text-rose-600 mx-auto" />
                        )}
                      </div>
                    </td>
                  );
                })}
              </tr>
            ))}
            {visiblePeople.length === 0 && (
              <tr>
                <td colSpan={days.length + 1} className="p-6 text-center text-muted-foreground italic text-xs">
                  {onlyMine ? "Nincs a hónapra eső saját műszakod." : "Nincs aktív munkatárs"}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Stats footer */}
      {rule && (
        <div className="text-xs text-muted-foreground">
          Kemény szabály: napi max <strong>{rule.napi_max_ora}h</strong> · heti max <strong>{rule.heti_max_ora}h</strong> · napi pihenő ≥ <strong>{rule.napi_pihenes_min_ora}h</strong> ·
          {" "}<span className="text-rose-600">{violations.size} sértés</span>
        </div>
      )}

      {tenantId && <RunsPanel tenantId={tenantId} canEdit={canEdit} onChanged={() => void load()} />}

      {editCell && tenantId && (
        <CellEditor
          tenantId={tenantId}
          userId={editCell.userId}
          date={editCell.date}
          existing={byCell.get(`${editCell.userId}|${isoDate(editCell.date)}`) ?? []}
          onClose={() => setEditCell(null)}
          onSaved={() => {
            setEditCell(null);
            void load();
          }}
        />
      )}

      {demandOpen && tenantId && user && (
        <DemandEditor
          weekStart={(() => {
            const ws = new Date(month);
            const dow = (ws.getDay() + 6) % 7;
            ws.setDate(ws.getDate() - dow);
            return ws.toISOString().slice(0, 10);
          })()}
          onClose={() => setDemandOpen(false)}
          generating={generating}
          tenantId={tenantId}
          totalPeople={people.length}
          onDryRun={async (demand) => {
            const ws = new Date(demand[0].date);
            const weekStart = ws.toISOString().slice(0, 10);
            const r = await generateSchedule({
              tenantId, initiatorId: user.id, orgUnitId: null, weekStart, demand, dryRun: true,
            });
            return { inserted: r.inserted, hardViolations: r.hardViolations };
          }}
          onGenerate={async (demand) => {
            setGenerating(true);
            try {
              const ws = new Date(demand[0].date);
              const weekStart = ws.toISOString().slice(0, 10);
              const r = await generateSchedule({
                tenantId, initiatorId: user.id, orgUnitId: null, weekStart, demand,
              });
              toast.success(`Beosztás generálva: ${r.inserted} műszak · ${r.hardViolations} sértés`);
              setDemandOpen(false);
              void load();
            } catch (e) {
              toast.error(humanizeError(e as Error, t));
            } finally {
              setGenerating(false);
            }
          }}
        />
      )}

      {shareOpen && tenantId && user && (
        <ShareLinkModal
          tenantId={tenantId}
          userId={user.id}
          monthStart={month}
          onClose={() => setShareOpen(false)}
        />
      )}
    </div>
  );
}

function CellEditor({
  tenantId,
  userId,
  date,
  existing,
  onClose,
  onSaved,
}: {
  tenantId: string;
  userId: string;
  date: Date;
  existing: Assignment[];
  onClose: () => void;
  onSaved: () => void;
}) {
  const { t } = useTranslation();
  const { user } = useAuth();
  const [kezd, setKezd] = useState("08:00");
  const [veg, setVeg] = useState("16:00");
  const [kat, setKat] = useState("rendes");
  const [pin, setPin] = useState(false);
  const [megjegyzes, setMegjegyzes] = useState("");
  const [saving, setSaving] = useState(false);

  async function add() {
    setSaving(true);
    const dateStr = isoDate(date);
    const kezdo = `${dateStr}T${kezd}:00`;
    let zaroDate = dateStr;
    if (veg <= kezd) {
      // crosses midnight
      const next = new Date(date);
      next.setDate(next.getDate() + 1);
      zaroDate = isoDate(next);
    }
    const zaro = `${zaroDate}T${veg}:00`;
    const ora = Math.max(0, hoursBetween(kezdo, zaro));
    const { error } = await (supabase.from("schedule_assignments") as any).insert({
      tenant_id: tenantId,
      user_id: userId,
      kezdo_idopont: kezdo,
      zaro_idopont: zaro,
      ora,
      kategoria: kat,
      pin,
      megjegyzes: megjegyzes || null,
      forras: "manual",
      created_by: user?.id ?? null,
    });
    setSaving(false);
    if (error) return toast.error(humanizeError(error, t));
    toast.success("Beosztás mentve");
    onSaved();
  }

  async function remove(id: string) {
    if (!confirm("Törli?")) return;
    const { error } = await supabase.from("schedule_assignments").delete().eq("id", id);
    if (error) return toast.error(humanizeError(error, t));
    onSaved();
  }

  async function togglePin(id: string, val: boolean) {
    const { error } = await (supabase.from("schedule_assignments") as any).update({ pin: val }).eq("id", id);
    if (error) return toast.error(humanizeError(error, t));
    onSaved();
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-card border rounded-lg p-4 w-full max-w-md space-y-3" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between">
          <h3 className="font-semibold">{date.toLocaleDateString("hu-HU")} · beosztás</h3>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X className="h-4 w-4" /></button>
        </div>

        {existing.length > 0 && (
          <div className="space-y-1">
            <div className="text-xs font-medium text-muted-foreground">Meglévő tételek:</div>
            {existing.map((a) => (
              <div key={a.id} className={cn("flex items-center gap-2 rounded border px-2 py-1 text-xs", KAT_COLOR[a.kategoria])}>
                <span className="font-mono">{a.kezdo_idopont.slice(11, 16)}–{a.zaro_idopont.slice(11, 16)}</span>
                <span className="font-mono">{Number(a.ora).toFixed(1)}h</span>
                <span className="ml-auto flex gap-1">
                  <button onClick={() => togglePin(a.id, !a.pin)} className={cn("p-1 rounded hover:bg-background", a.pin && "text-primary")} title="Pin">
                    <Pin className="h-3 w-3" />
                  </button>
                  <button onClick={() => remove(a.id)} className="p-1 rounded hover:bg-background text-rose-600">
                    <Trash2 className="h-3 w-3" />
                  </button>
                </span>
              </div>
            ))}
          </div>
        )}

        <div className="border-t pt-3 space-y-2">
          <div className="border-t pt-2">
            <div className="text-xs font-medium text-muted-foreground mb-1">Solver-magyarázat</div>
            <CellExplanations userId={userId} date={isoDate(date)} />
          </div>
          <div className="text-xs font-medium">Új tétel</div>
          <div className="grid grid-cols-2 gap-2">
            <label className="text-xs">Kezdés
              <input type="time" value={kezd} onChange={(e) => setKezd(e.target.value)} className="w-full mt-0.5 rounded border bg-background px-2 py-1 text-sm" />
            </label>
            <label className="text-xs">Vég
              <input type="time" value={veg} onChange={(e) => setVeg(e.target.value)} className="w-full mt-0.5 rounded border bg-background px-2 py-1 text-sm" />
            </label>
          </div>
          <label className="text-xs block">Kategória
            <select value={kat} onChange={(e) => setKat(e.target.value)} className="w-full mt-0.5 rounded border bg-background px-2 py-1 text-sm">
              {KATEGORIAK.map((k) => <option key={k} value={k}>{k}</option>)}
            </select>
          </label>
          <label className="text-xs block">Megjegyzés
            <input value={megjegyzes} onChange={(e) => setMegjegyzes(e.target.value)} className="w-full mt-0.5 rounded border bg-background px-2 py-1 text-sm" />
          </label>
          <label className="flex items-center gap-2 text-xs">
            <input type="checkbox" checked={pin} onChange={(e) => setPin(e.target.checked)} />
            Pin (rögzített, solver nem írja felül)
          </label>
          <button onClick={add} disabled={saving} className="w-full rounded bg-primary text-primary-foreground py-1.5 text-sm hover:opacity-90 disabled:opacity-50">
            {saving ? <Loader2 className="h-4 w-4 animate-spin mx-auto" /> : "Hozzáadás"}
          </button>
        </div>
      </div>
    </div>
  );
}
