import { createFileRoute, Link } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import {
  Activity,
  AlertTriangle,
  ArrowLeft,
  BadgeCheck,
  Baby,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ClipboardList,
  FileText,
  LineChart,
  Loader2,
  MessageSquare,
  Microscope,
  Pill,
  Plus,
  Save,
  Star,
  Stethoscope,
  Sparkles,
  CalendarPlus,
  ExternalLink,
  Download,
  History,
  Search,
  Trash2,
  X,
  Check,
  Zap,
  PlayCircle,
  Target,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { StaffSosPanel } from "@/components/paciensek/staff-sos-panel";
import { PatientAiExplanationsPanel } from "@/components/paciensek/patient-ai-explanations-panel";
import {
  generatePaciens360Pdf,
  acknowledgeCriticalAlert,
  updateAlertWorkflowStatus,
  listAlertStatusLog,
  listSavedViews,
  saveSavedView,
  deleteSavedView,
  listEscalationRules,
  upsertEscalationRule,
  deleteEscalationRule,
  listOpenAlertsForTest,
  testEscalationRuleOnAlert,
  ALERT_STATUSES,
  type Section360Key,
  type SavedView,
  type AlertStatus,
  type EscalationRule,
} from "@/lib/paciens-360/paciens-360.functions";

export const Route = createFileRoute("/_authenticated/paciens-360/$patientId")({
  component: Paciens360,
});

type Patient = {
  id: string; taj: string | null; vezeteknev: string; keresztnev: string;
  szuletesi_datum: string | null; nem: string | null; anyja_neve: string | null;
  fo_diagnozis_bno: string | null; gondozo_orvos_id: string | null; megjegyzes: string | null;
};
type Encounter = { id: string; encounter_type: string; status: string; start_ts: string; end_ts: string | null; chief_complaint: string | null; location: string | null };
type Diagnosis = { id: string; icd10_code: string | null; display: string | null; is_primary: boolean | null; certainty: string | null; onset_date: string | null };
type Therapy = { id: string; display: string | null; dose: string | null; route: string | null; frequency: string | null; status: string | null; starts_on: string | null; ends_on: string | null };
type Observation = { id: string; category: string | null; code_display: string | null; loinc_code: string | null; value_quantity: number | null; value_unit: string | null; value_string: string | null; interpretation: string | null; effective_ts: string };
type CriticalAlert = { id: string; severity: string; source: string; code: string | null; message: string | null; triggered_at: string; acknowledged_at: string | null; workflow_status: string | null };
type Measurement = { id: string; kind: string; ts: string; value: number | null; value2: number | null; unit: string | null };
type Partogram = { id: string; encounter_id: string; labor_start_ts: string | null; created_at: string };
type ReferralReq = { id: string; status: string | null; request_type: string | null; specialty: string | null; reason: string | null; created_at: string };
type Note = { id: string; title: string | null; kind: string | null; ai_generated: boolean | null; signed_at: string | null; created_at: string };
type QAssign = { id: string; status: string | null; due_at: string | null; created_at: string };

type CategoryKey = "encounters" | "diagnoses" | "therapies" | "vitals" | "labs" | "measurements" | "alerts" | "referrals" | "notes" | "questionnaires" | "partograms";

const CATEGORY_LABELS: Record<CategoryKey, string> = {
  encounters: "Epizódok", diagnoses: "Diagnózisok", therapies: "Terápia",
  vitals: "Vitálok", labs: "Labor", measurements: "Mérések", alerts: "Riasztások",
  referrals: "Beutalók", notes: "Jegyzetek", questionnaires: "Kérdőívek", partograms: "Partogramok",
};

function Paciens360() {
  const { user } = useAuth();
  const { patientId } = Route.useParams();
  const [loading, setLoading] = useState(true);
  const [patient, setPatient] = useState<Patient | null>(null);
  const [encounters, setEncounters] = useState<Encounter[]>([]);
  const [diagnoses, setDiagnoses] = useState<Diagnosis[]>([]);
  const [therapies, setTherapies] = useState<Therapy[]>([]);
  const [vitals, setVitals] = useState<Observation[]>([]);
  const [labs, setLabs] = useState<Observation[]>([]);
  const [alerts, setAlerts] = useState<CriticalAlert[]>([]);
  const [measurements, setMeasurements] = useState<Measurement[]>([]);
  const [partograms, setPartograms] = useState<Partogram[]>([]);
  const [referrals, setReferrals] = useState<ReferralReq[]>([]);
  const [notes, setNotes] = useState<Note[]>([]);
  const [questionnaires, setQuestionnaires] = useState<QAssign[]>([]);

  // search & filter
  const [q, setQ] = useState("");
  const [from, setFrom] = useState<string>("");
  const [to, setTo] = useState<string>("");
  const [enabled, setEnabled] = useState<Record<CategoryKey, boolean>>(() =>
    Object.fromEntries(Object.keys(CATEGORY_LABELS).map((k) => [k, true])) as Record<CategoryKey, boolean>,
  );

  // dialogs
  const [alertOpen, setAlertOpen] = useState(false);
  const [pdfOpen, setPdfOpen] = useState(false);
  const [aiOpen, setAiOpen] = useState(false);
  const [saveOpen, setSaveOpen] = useState(false);

  // saved views (favorites)
  const [savedViews, setSavedViews] = useState<SavedView[]>([]);
  const listViews = useServerFn(listSavedViews);
  const delView = useServerFn(deleteSavedView);

  // timeline grouping
  const [groupBy, setGroupBy] = useState<"none" | "day" | "encounter">("day");
  const [collapsedGroups, setCollapsedGroups] = useState<Record<string, boolean>>({});
  const [highlightId, setHighlightId] = useState<string | null>(null);
  const [matchIdx, setMatchIdx] = useState<number>(0);

  const fetchAll = useMemo(
    () => async () => {
      setLoading(true);
      const [pRes, eRes, dRes, tRes, vRes, lRes, aRes, mRes, ptRes, rRes, nRes, qRes] = await Promise.all([
        supabase.from("patients").select("*").eq("id", patientId).maybeSingle(),
        supabase.from("clinical_encounters").select("id,encounter_type,status,start_ts,end_ts,chief_complaint,location").eq("patient_id", patientId).order("start_ts", { ascending: false }).limit(50),
        supabase.from("clinical_diagnoses").select("id,icd10_code,display,is_primary,certainty,onset_date").eq("patient_id", patientId).order("is_primary", { ascending: false }).limit(50),
        supabase.from("clinical_therapy_orders").select("id,display,dose,route,frequency,status,starts_on,ends_on").eq("patient_id", patientId).order("created_at", { ascending: false }).limit(50),
        supabase.from("clinical_observations").select("id,category,code_display,loinc_code,value_quantity,value_unit,value_string,interpretation,effective_ts").eq("patient_id", patientId).eq("category", "vital-signs").order("effective_ts", { ascending: false }).limit(50),
        supabase.from("clinical_observations").select("id,category,code_display,loinc_code,value_quantity,value_unit,value_string,interpretation,effective_ts").eq("patient_id", patientId).eq("category", "laboratory").order("effective_ts", { ascending: false }).limit(50),
        supabase.from("clinical_critical_alerts").select("id,severity,source,code,message,triggered_at,acknowledged_at,workflow_status").eq("patient_id", patientId).order("triggered_at", { ascending: false }).limit(100),
        supabase.from("measurements").select("id,kind,ts,value,value2,unit").eq("patient_id", patientId).order("ts", { ascending: false }).limit(50),
        supabase.from("obstetric_partograms").select("id,encounter_id,labor_start_ts,created_at").eq("patient_id", patientId).order("created_at", { ascending: false }).limit(10),
        supabase.from("patient_referral_requests").select("id,status,request_type,specialty,reason,created_at").eq("patient_id", patientId).order("created_at", { ascending: false }).limit(30),
        supabase.from("clinical_notes").select("id,title,kind,ai_generated,signed_at,created_at").eq("patient_id", patientId).order("created_at", { ascending: false }).limit(30),
        supabase.from("questionnaire_assignments").select("id,status,due_at,created_at").eq("patient_id", patientId).order("created_at", { ascending: false }).limit(30),
      ]);
      setPatient((pRes.data as Patient | null) ?? null);
      setEncounters((eRes.data as Encounter[]) ?? []);
      setDiagnoses((dRes.data as Diagnosis[]) ?? []);
      setTherapies((tRes.data as Therapy[]) ?? []);
      setVitals((vRes.data as Observation[]) ?? []);
      setLabs((lRes.data as Observation[]) ?? []);
      setAlerts((aRes.data as CriticalAlert[]) ?? []);
      setMeasurements((mRes.data as Measurement[]) ?? []);
      setPartograms((ptRes.data as Partogram[]) ?? []);
      setReferrals((rRes.data as ReferralReq[]) ?? []);
      setNotes((nRes.data as Note[]) ?? []);
      setQuestionnaires((qRes.data as QAssign[]) ?? []);
      setLoading(false);
    },
    [patientId],
  );

  useEffect(() => {
    if (!user) return;
    void fetchAll();
  }, [user, fetchAll]);

  const refreshViews = useCallback(async () => {
    try {
      const v = await listViews({ data: { patientId } });
      setSavedViews(v);
      const def = v.find((x) => x.is_default);
      if (def) applyView(def);
    } catch {
      /* ignore */
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [listViews, patientId]);

  useEffect(() => {
    if (!user) return;
    void refreshViews();
  }, [user, refreshViews]);

  const applyView = (v: SavedView) => {
    const f = v.filters as {
      q?: string;
      from?: string;
      to?: string;
      enabled?: Record<CategoryKey, boolean>;
      groupBy?: "none" | "day" | "encounter";
    };
    if (typeof f.q === "string") setQ(f.q);
    if (typeof f.from === "string") setFrom(f.from);
    if (typeof f.to === "string") setTo(f.to);
    if (f.enabled) setEnabled((s) => ({ ...s, ...f.enabled }));
    if (f.groupBy) setGroupBy(f.groupBy);
  };

  const handleDeleteView = async (id: string) => {
    await delView({ data: { id } });
    setSavedViews((s) => s.filter((v) => v.id !== id));
  };

  // ---- filter helpers
  const inRange = (iso?: string | null) => {
    if (!iso) return true;
    const t = new Date(iso).getTime();
    if (from && t < new Date(from).getTime()) return false;
    if (to && t > new Date(to).getTime() + 86_400_000) return false;
    return true;
  };
  const ql = q.trim().toLowerCase();
  const matchesQ = (...vals: Array<string | null | undefined>) =>
    !ql || vals.some((v) => v && v.toLowerCase().includes(ql));

  const fEncounters = encounters.filter((e) => inRange(e.start_ts) && matchesQ(e.encounter_type, e.status, e.chief_complaint, e.location));
  const fDiagnoses = diagnoses.filter((d) => inRange(d.onset_date) && matchesQ(d.icd10_code, d.display, d.certainty));
  const fTherapies = therapies.filter((t) => inRange(t.starts_on) && matchesQ(t.display, t.dose, t.frequency, t.status));
  const fVitals = vitals.filter((o) => inRange(o.effective_ts) && matchesQ(o.code_display, o.loinc_code, o.interpretation));
  const fLabs = labs.filter((o) => inRange(o.effective_ts) && matchesQ(o.code_display, o.loinc_code, o.interpretation));
  const fMeasurements = measurements.filter((m) => inRange(m.ts) && matchesQ(m.kind, m.unit));
  const fAlerts = alerts.filter((a) => inRange(a.triggered_at) && matchesQ(a.severity, a.source, a.code, a.message));
  const fReferrals = referrals.filter((r) => inRange(r.created_at) && matchesQ(r.request_type, r.specialty, r.reason, r.status));
  const fNotes = notes.filter((n) => inRange(n.created_at) && matchesQ(n.title, n.kind));
  const fQuestionnaires = questionnaires.filter((qa) => inRange(qa.created_at) && matchesQ(qa.status));

  if (loading) {
    return (
      <div className="container py-8 flex items-center gap-2 text-sm">
        <Loader2 className="h-4 w-4 animate-spin" /> Páciens 360 betöltése…
      </div>
    );
  }
  if (!patient) return <div className="container py-8">Beteg nem található.</div>;

  const activeEncounter = encounters.find((e) => e.status === "in-progress") ?? encounters[0];
  const age = patient.szuletesi_datum
    ? Math.floor((Date.now() - new Date(patient.szuletesi_datum).getTime()) / (365.25 * 24 * 3600 * 1000))
    : null;
  const unackAlerts = alerts.filter((a) => !a.acknowledged_at).length;

  // ---- timeline aggregation
  type TimelineItem = { id: string; ts: string; cat: CategoryKey; title: string; sub?: string; severity?: string };
  const timeline: TimelineItem[] = [];
  if (enabled.encounters) fEncounters.forEach((e) => timeline.push({ id: `e-${e.id}`, ts: e.start_ts, cat: "encounters", title: `Epizód · ${e.encounter_type}`, sub: e.chief_complaint ?? e.location ?? e.status }));
  if (enabled.diagnoses) fDiagnoses.forEach((d) => d.onset_date && timeline.push({ id: `d-${d.id}`, ts: d.onset_date, cat: "diagnoses", title: `Diagnózis · ${d.icd10_code ?? ""}`, sub: d.display ?? "" }));
  if (enabled.therapies) fTherapies.forEach((t) => t.starts_on && timeline.push({ id: `t-${t.id}`, ts: t.starts_on, cat: "therapies", title: `Terápia · ${t.display ?? ""}`, sub: t.dose ?? "" }));
  if (enabled.vitals) fVitals.forEach((o) => timeline.push({ id: `v-${o.id}`, ts: o.effective_ts, cat: "vitals", title: `Vitál · ${o.code_display ?? o.loinc_code ?? ""}`, sub: `${o.value_quantity ?? o.value_string ?? ""} ${o.value_unit ?? ""}` }));
  if (enabled.labs) fLabs.forEach((o) => timeline.push({ id: `l-${o.id}`, ts: o.effective_ts, cat: "labs", title: `Labor · ${o.code_display ?? o.loinc_code ?? ""}`, sub: `${o.value_quantity ?? o.value_string ?? ""} ${o.value_unit ?? ""}` }));
  if (enabled.measurements) fMeasurements.forEach((m) => timeline.push({ id: `m-${m.id}`, ts: m.ts, cat: "measurements", title: `Mérés · ${m.kind}`, sub: `${m.value ?? ""}${m.value2 != null ? "/" + m.value2 : ""} ${m.unit ?? ""}` }));
  if (enabled.alerts) fAlerts.forEach((a) => timeline.push({ id: `a-${a.id}`, ts: a.triggered_at, cat: "alerts", title: `Riasztás · ${a.severity}`, sub: a.message ?? a.code ?? a.source, severity: a.severity }));
  if (enabled.referrals) fReferrals.forEach((r) => timeline.push({ id: `r-${r.id}`, ts: r.created_at, cat: "referrals", title: `Beutaló · ${r.request_type ?? ""}`, sub: r.reason ?? "" }));
  if (enabled.notes) fNotes.forEach((n) => timeline.push({ id: `n-${n.id}`, ts: n.created_at, cat: "notes", title: `Jegyzet · ${n.kind ?? ""}`, sub: n.title ?? "" }));
  timeline.sort((a, b) => new Date(b.ts).getTime() - new Date(a.ts).getTime());

  // Matches = items that hit the text query (or all visible if no query)
  const matches: TimelineItem[] = ql
    ? timeline.filter((it) =>
        (it.title?.toLowerCase().includes(ql) ?? false) ||
        (it.sub?.toLowerCase().includes(ql) ?? false),
      )
    : timeline;
  const matchIds = new Set(matches.map((m) => m.id));

  const itemGroupKey = (it: TimelineItem): string => {
    if (groupBy === "none") return "all";
    if (groupBy === "day") return `d-${new Date(it.ts).toISOString().slice(0, 10)}`;
    const sorted = [...fEncounters].sort((a, b) => new Date(b.start_ts).getTime() - new Date(a.start_ts).getTime());
    const t = new Date(it.ts).getTime();
    const enc = sorted.find((e) => {
      const s = new Date(e.start_ts).getTime();
      const en = e.end_ts ? new Date(e.end_ts).getTime() : Date.now();
      return t >= s && t <= en;
    });
    return enc ? `e-${enc.id}` : "__other";
  };

  const scrollToItemId = (id: string) => {
    const el = document.querySelector(`[data-tl-id="${id}"]`) as HTMLElement | null;
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "center" });
      try { el.focus({ preventScroll: true }); } catch { /* noop */ }
    }
  };

  const jumpToTimelineItem = (it: TimelineItem, opts?: { highlight?: boolean }) => {
    const gk = itemGroupKey(it);
    setCollapsedGroups((s) => ({ ...s, [gk]: false }));
    setHighlightId(it.id);
    setTimeout(() => scrollToItemId(it.id), 60);
    if (opts?.highlight !== false) {
      setTimeout(() => setHighlightId((cur) => (cur === it.id ? null : cur)), 2200);
    }
  };

  const jumpByIdx = (i: number) => {
    if (matches.length === 0) return;
    const safe = ((i % matches.length) + matches.length) % matches.length;
    setMatchIdx(safe);
    jumpToTimelineItem(matches[safe]);
  };

  // Persist matchIdx + highlightId per patient so returning to the view restores position
  const persistKey = `p360:nav:${patientId}`;
  const restoredRef = useRef(false);
  useEffect(() => {
    if (restoredRef.current) return;
    if (loading || timeline.length === 0) return;
    try {
      const raw = localStorage.getItem(persistKey);
      if (raw) {
        const saved = JSON.parse(raw) as { matchIdx?: number; highlightId?: string | null };
        const target = saved.highlightId && timeline.find((t) => t.id === saved.highlightId);
        if (target) {
          const idxInMatches = matches.findIndex((m) => m.id === target.id);
          if (idxInMatches >= 0) setMatchIdx(idxInMatches);
          setHighlightId(target.id);
          setTimeout(() => {
            const gk = itemGroupKey(target);
            setCollapsedGroups((s) => ({ ...s, [gk]: false }));
            setTimeout(() => scrollToItemId(target.id), 80);
          }, 0);
        } else if (typeof saved.matchIdx === "number") {
          const safe = Math.min(Math.max(saved.matchIdx, 0), Math.max(matches.length - 1, 0));
          setMatchIdx(safe);
        }
      }
    } catch { /* ignore */ }
    restoredRef.current = true;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loading, timeline.length]);

  useEffect(() => {
    if (!restoredRef.current) return;
    try {
      localStorage.setItem(persistKey, JSON.stringify({ matchIdx, highlightId }));
    } catch { /* ignore */ }
  }, [matchIdx, highlightId, persistKey]);

  // After a re-render (e.g. tab/filter change), if a highlight is still active and the
  // element exists in the DOM, re-scroll it into view so focus is restored.
  useEffect(() => {
    if (!highlightId) return;
    const id = requestAnimationFrame(() => scrollToItemId(highlightId));
    return () => cancelAnimationFrame(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [highlightId, collapsedGroups, groupBy, enabled, q, from, to]);

  // Keyboard shortcuts: J/↓ next, K/↑ prev — only when quick-nav is active
  const quickNavActive = (!!ql || !!from || !!to) && matches.length > 0;
  useEffect(() => {
    if (!quickNavActive) return;
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      const tag = t?.tagName;
      if (t?.isContentEditable || tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      const k = e.key;
      if (k === "j" || k === "J" || k === "ArrowDown") {
        e.preventDefault();
        jumpByIdx(matchIdx + 1);
      } else if (k === "k" || k === "K" || k === "ArrowUp") {
        e.preventDefault();
        jumpByIdx(matchIdx - 1);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [quickNavActive, matchIdx, matches]);


  return (
    <div className="container max-w-7xl py-6 space-y-4">
      {/* Header */}
      <header className="rounded-2xl border border-border bg-gradient-to-br from-card to-card/60 p-5">
        <Link to="/paciensek" className="text-xs text-muted-foreground hover:underline flex items-center gap-1">
          <ArrowLeft className="h-3 w-3" /> Páciensek
        </Link>
        <div className="mt-2 flex items-start justify-between gap-4 flex-wrap">
          <div>
            <h1 className="text-2xl font-semibold flex items-center gap-2">
              <Stethoscope className="h-6 w-6 text-primary" />
              {patient.vezeteknev} {patient.keresztnev}
              {unackAlerts > 0 && (
                <button
                  type="button"
                  onClick={() => setAlertOpen(true)}
                  className="inline-flex items-center gap-1 text-xs font-mono px-2 py-0.5 rounded-full bg-rose-500/15 text-rose-600 border border-rose-500/30 hover:bg-rose-500/25"
                >
                  <AlertTriangle className="h-3 w-3" /> {unackAlerts} aktív riasztás
                </button>
              )}
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              TAJ: <span className="font-mono">{patient.taj ?? "—"}</span> · Szül.:{" "}
              {patient.szuletesi_datum ?? "—"} {age != null && `(${age} é)`} · Nem: {patient.nem ?? "—"} · Anyja neve: {patient.anyja_neve ?? "—"}
            </p>
            {patient.fo_diagnozis_bno && (
              <p className="text-xs mt-1">
                Fő BNO: <span className="font-mono">{patient.fo_diagnozis_bno}</span>
              </p>
            )}
          </div>
          <ActionBar patientId={patient.id} encounterId={activeEncounter?.id} onExport={() => setPdfOpen(true)} onAlerts={() => setAlertOpen(true)} onAiExplanations={() => setAiOpen(true)} />
        </div>
      </header>

      {/* Saved views bar */}
      <SavedViewsBar
        views={savedViews}
        onApply={applyView}
        onSave={() => setSaveOpen(true)}
        onDelete={handleDeleteView}
      />

      {/* Search + filter bar */}
      <section className="rounded-xl border border-border bg-card p-3 space-y-3">
        <div className="flex flex-wrap items-end gap-2">
          <label className="flex-1 min-w-[200px]">
            <span className="text-[10px] uppercase text-muted-foreground">Keresés</span>
            <div className="relative">
              <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Szöveg, kód, név…"
                className="w-full pl-7 pr-2 py-1.5 text-sm rounded-md bg-background border border-input"
              />
            </div>
          </label>
          <label>
            <span className="text-[10px] uppercase text-muted-foreground block">Dátumtól</span>
            <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} className="text-sm rounded-md bg-background border border-input px-2 py-1.5" />
          </label>
          <label>
            <span className="text-[10px] uppercase text-muted-foreground block">Dátumig</span>
            <input type="date" value={to} onChange={(e) => setTo(e.target.value)} className="text-sm rounded-md bg-background border border-input px-2 py-1.5" />
          </label>
          {(q || from || to) && (
            <button type="button" onClick={() => { setQ(""); setFrom(""); setTo(""); }} className="text-xs px-2 py-1.5 rounded-md border border-border hover:bg-accent inline-flex items-center gap-1">
              <X className="h-3 w-3" /> Szűrők törlése
            </button>
          )}
        </div>
        <div className="flex flex-wrap gap-1.5">
          {(Object.keys(CATEGORY_LABELS) as CategoryKey[]).map((k) => (
            <button
              key={k}
              type="button"
              onClick={() => setEnabled((s) => ({ ...s, [k]: !s[k] }))}
              className={
                "text-xs px-2 py-1 rounded-full border transition-colors " +
                (enabled[k] ? "bg-primary/10 border-primary/30 text-primary" : "bg-secondary border-border text-muted-foreground")
              }
            >
              {enabled[k] ? <Check className="inline h-3 w-3 mr-1" /> : null}
              {CATEGORY_LABELS[k]}
            </button>
          ))}
        </div>
      </section>

      {/* Critical alerts banner */}
      {unackAlerts > 0 && (
        <section className="rounded-xl border border-rose-500/40 bg-rose-500/5 p-3">
          <div className="text-xs font-semibold text-rose-600 mb-2 flex items-center justify-between">
            <span className="flex items-center gap-1"><AlertTriangle className="h-3 w-3" /> Aktív kritikus riasztások</span>
            <button type="button" onClick={() => setAlertOpen(true)} className="text-xs px-2 py-0.5 rounded border border-rose-500/40 hover:bg-rose-500/15 inline-flex items-center gap-1">
              <History className="h-3 w-3" /> Kezelés / előzmények
            </button>
          </div>
          <ul className="space-y-1 text-xs">
            {alerts.filter((a) => !a.acknowledged_at).slice(0, 5).map((a) => (
              <li key={a.id} className="flex items-center justify-between gap-2">
                <span><span className="font-mono uppercase mr-2">{a.severity}</span>{a.message ?? a.code ?? a.source}</span>
                <span className="text-muted-foreground">{new Date(a.triggered_at).toLocaleString("hu-HU")}</span>
              </li>
            ))}
          </ul>
        </section>
      )}

      {/* Search results quick-nav */}
      {(ql || from || to) && matches.length > 0 && (
        <section className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-3">
          <div className="text-xs font-semibold text-amber-700 dark:text-amber-400 mb-2 flex items-center gap-2 flex-wrap">
            <Target className="h-3 w-3" /> Találatok az idővonalon ({matches.length}{ql ? ` · "${q}"` : ""})
            <span className="text-muted-foreground font-normal">— ugrás chippel, léptetőkkel vagy <kbd className="px-1 rounded border bg-background font-mono text-[10px]">J</kbd>/<kbd className="px-1 rounded border bg-background font-mono text-[10px]">K</kbd> · <kbd className="px-1 rounded border bg-background font-mono text-[10px]">↑</kbd>/<kbd className="px-1 rounded border bg-background font-mono text-[10px]">↓</kbd></span>
            <div className="ml-auto inline-flex items-center gap-1">
              <button
                type="button"
                onClick={() => jumpByIdx(matchIdx - 1)}
                className="h-6 w-6 inline-flex items-center justify-center rounded border border-amber-500/40 bg-background hover:bg-amber-500/15"
                aria-label="Előző találat"
                title="Előző találat (K / ↑)"
              >
                <ChevronLeft className="h-3 w-3" />
              </button>
              <span className="font-mono text-[11px] text-foreground/80 min-w-[52px] text-center">
                {Math.min(matchIdx + 1, matches.length)} / {matches.length}
              </span>
              <button
                type="button"
                onClick={() => jumpByIdx(matchIdx + 1)}
                className="h-6 w-6 inline-flex items-center justify-center rounded border border-amber-500/40 bg-background hover:bg-amber-500/15"
                aria-label="Következő találat"
                title="Következő találat (J / ↓)"
              >
                <ChevronRight className="h-3 w-3" />
              </button>
            </div>
          </div>
          <ul className="flex flex-wrap gap-1.5 max-h-32 overflow-auto">
            {matches.slice(0, 30).map((it, i) => {
              const active = i === matchIdx;
              return (
                <li key={it.id}>
                  <button
                    type="button"
                    onClick={() => { setMatchIdx(i); jumpToTimelineItem(it); }}
                    className={
                      "text-[11px] px-2 py-1 rounded-full border inline-flex items-center gap-1 " +
                      (active
                        ? "border-amber-500 bg-amber-400/25 text-foreground"
                        : "border-amber-500/40 bg-background hover:bg-amber-500/15")
                    }
                    title={it.sub ?? ""}
                  >
                    <span className="font-mono text-muted-foreground">{new Date(it.ts).toLocaleDateString("hu-HU")}</span>
                    <span className="truncate max-w-[220px]">{it.title}</span>
                  </button>
                </li>
              );
            })}
            {matches.length > 30 && (
              <li className="text-[11px] text-muted-foreground self-center">+{matches.length - 30} további…</li>
            )}
          </ul>
        </section>
      )}

      {/* Timeline */}
      <TimelineBlock
        items={timeline}
        encounters={fEncounters}
        groupBy={groupBy}
        setGroupBy={setGroupBy}
        collapsed={collapsedGroups}
        setCollapsed={setCollapsedGroups}
        highlightId={highlightId}
        matchIds={matchIds}
        hasQuery={!!ql}
      />



      {/* SOS panel */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-1"><StaffSosPanel patientId={patientId} /></div>
      </div>

      {/* Sections grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
        {enabled.encounters && (
          <Section title={`Epizódok (${fEncounters.length})`} icon={ClipboardList}>
            {fEncounters.length === 0 ? <Empty text="Nincs találat." /> : (
              <ul className="space-y-1.5 text-sm">
                {fEncounters.map((e) => (
                  <li key={e.id} className="flex items-center justify-between gap-2">
                    <Link to="/klinika/beteg/$patientId" params={{ patientId }} search={{ encounterId: e.id, tab: "overview" }} className="truncate hover:underline">
                      <span className="font-mono text-xs mr-2 uppercase">{e.encounter_type}</span>
                      {e.chief_complaint ?? e.location ?? "—"}
                    </Link>
                    <StatusPill status={e.status} />
                  </li>
                ))}
              </ul>
            )}
          </Section>
        )}

        {enabled.diagnoses && (
          <Section title={`Diagnózisok (${fDiagnoses.length})`} icon={BadgeCheck}>
            {fDiagnoses.length === 0 ? <Empty text="Nincs találat." /> : (
              <ul className="space-y-1 text-sm">
                {fDiagnoses.map((d) => (
                  <li key={d.id} className="flex items-start justify-between gap-2">
                    <span className="truncate">
                      {d.is_primary && <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-primary/15 text-primary mr-2">FŐ</span>}
                      <span className="font-mono text-xs mr-1">{d.icd10_code ?? "—"}</span>{d.display ?? "—"}
                    </span>
                    {d.certainty && <span className="text-xs text-muted-foreground">{d.certainty}</span>}
                  </li>
                ))}
              </ul>
            )}
          </Section>
        )}

        {enabled.therapies && (
          <Section title={`Terápia (${fTherapies.length})`} icon={Pill}>
            {fTherapies.length === 0 ? <Empty text="Nincs találat." /> : (
              <ul className="space-y-1 text-sm">
                {fTherapies.map((t) => (
                  <li key={t.id} className="flex items-start justify-between gap-2">
                    <span className="truncate">
                      {t.display ?? "—"}
                      {t.dose && <span className="text-xs text-muted-foreground"> · {t.dose}</span>}
                      {t.frequency && <span className="text-xs text-muted-foreground"> · {t.frequency}</span>}
                    </span>
                    <StatusPill status={t.status ?? ""} />
                  </li>
                ))}
              </ul>
            )}
          </Section>
        )}

        {enabled.vitals && (
          <Section title={`Vitálok (${fVitals.length})`} icon={Activity}>
            {fVitals.length === 0 ? <Empty text="Nincs találat." /> : (
              <ul className="space-y-1 text-sm">
                {fVitals.map((o) => (
                  <li key={o.id} className="flex items-center justify-between gap-2">
                    <span className="truncate">{o.code_display ?? o.loinc_code ?? "—"}</span>
                    <span className="font-mono text-xs">
                      {o.value_quantity ?? o.value_string ?? "—"} {o.value_unit ?? ""}
                      {o.interpretation && (
                        <span className={"ml-2 px-1.5 py-0.5 rounded text-[10px] " + (o.interpretation === "H" || o.interpretation === "HH" ? "bg-rose-500/15 text-rose-600" : o.interpretation === "L" || o.interpretation === "LL" ? "bg-amber-500/15 text-amber-600" : "bg-emerald-500/15 text-emerald-600")}>{o.interpretation}</span>
                      )}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </Section>
        )}

        {enabled.labs && (
          <Section title={`Labor (${fLabs.length})`} icon={Microscope}>
            {fLabs.length === 0 ? <Empty text="Nincs találat." /> : (
              <ul className="space-y-1 text-sm">
                {fLabs.map((o) => (
                  <li key={o.id} className="flex items-center justify-between gap-2">
                    <span className="truncate">{o.code_display ?? o.loinc_code ?? "—"}</span>
                    <span className="font-mono text-xs">{o.value_quantity ?? o.value_string ?? "—"} {o.value_unit ?? ""}</span>
                  </li>
                ))}
              </ul>
            )}
          </Section>
        )}

        {enabled.measurements && (
          <Section title={`Mérések (${fMeasurements.length})`} icon={LineChart}>
            {fMeasurements.length === 0 ? <Empty text="Nincs találat." /> : (
              <ul className="space-y-1 text-sm">
                {fMeasurements.map((m) => (
                  <li key={m.id} className="flex items-center justify-between gap-2">
                    <span className="font-mono text-xs uppercase">{m.kind}</span>
                    <span className="font-mono text-xs">
                      {m.value ?? "—"}{m.value2 != null ? `/${m.value2}` : ""} {m.unit ?? ""}
                      <span className="text-muted-foreground ml-2">{new Date(m.ts).toLocaleDateString("hu-HU")}</span>
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </Section>
        )}

        {enabled.questionnaires && (
          <Section title={`Kérdőívek (${fQuestionnaires.length})`} icon={FileText}>
            {fQuestionnaires.length === 0 ? <Empty text="Nincs találat." /> : (
              <ul className="space-y-1 text-sm">
                {fQuestionnaires.map((qa) => (
                  <li key={qa.id} className="flex items-center justify-between gap-2">
                    <span className="text-xs">{qa.due_at ? `Határidő: ${new Date(qa.due_at).toLocaleDateString("hu-HU")}` : new Date(qa.created_at).toLocaleDateString("hu-HU")}</span>
                    <StatusPill status={qa.status ?? ""} />
                  </li>
                ))}
              </ul>
            )}
          </Section>
        )}

        {enabled.referrals && (
          <Section title={`Beutalók (${fReferrals.length})`} icon={FileText}>
            {fReferrals.length === 0 ? <Empty text="Nincs találat." /> : (
              <ul className="space-y-1 text-sm">
                {fReferrals.map((r) => (
                  <li key={r.id} className="flex items-start justify-between gap-2">
                    <span className="truncate">
                      <span className="font-mono text-xs mr-2 uppercase">{r.request_type ?? "—"}</span>
                      {r.specialty && <span className="text-xs text-muted-foreground mr-2">{r.specialty}</span>}
                      {r.reason ?? "—"}
                    </span>
                    <StatusPill status={r.status ?? ""} />
                  </li>
                ))}
              </ul>
            )}
          </Section>
        )}

        {enabled.notes && (
          <Section title={`Jegyzetek (${fNotes.length})`} icon={FileText}>
            {fNotes.length === 0 ? <Empty text="Nincs találat." /> : (
              <ul className="space-y-1 text-sm">
                {fNotes.map((n) => (
                  <li key={n.id} className="flex items-start justify-between gap-2">
                    <span className="truncate">
                      {n.ai_generated && <Sparkles className="inline h-3 w-3 mr-1 text-violet-500" />}
                      {n.title ?? n.kind ?? "—"}
                    </span>
                    <span className="text-[10px] text-muted-foreground">{n.signed_at ? "aláírva" : "vázlat"}</span>
                  </li>
                ))}
              </ul>
            )}
          </Section>
        )}

        {enabled.partograms && partograms.length > 0 && (
          <Section title="Partogramok" icon={Baby}>
            <ul className="space-y-1 text-sm">
              {partograms.map((p) => (
                <li key={p.id} className="flex items-center justify-between gap-2">
                  <span className="text-xs">Vajúdás kezdete: {p.labor_start_ts ? new Date(p.labor_start_ts).toLocaleString("hu-HU") : "—"}</span>
                  <Link to="/klinika/partogram/$encounterId" params={{ encounterId: p.encounter_id }} className="text-xs text-primary hover:underline inline-flex items-center gap-1">
                    Megnyit <ExternalLink className="h-3 w-3" />
                  </Link>
                </li>
              ))}
            </ul>
          </Section>
        )}
      </div>

      {alertOpen && (
        <AlertManagerDialog
          alerts={alerts}
          onClose={() => setAlertOpen(false)}
          onAcked={() => void fetchAll()}
        />
      )}
      {pdfOpen && (
        <PdfExportDialog
          patientId={patientId}
          defaultFrom={from}
          defaultTo={to}
          onClose={() => setPdfOpen(false)}
        />
      )}
      {aiOpen && (
        <PatientAiExplanationsPanel patientId={patientId} onClose={() => setAiOpen(false)} />
      )}
      {saveOpen && (
        <SaveViewDialog
          patientId={patientId}
          existing={savedViews}
          currentFilters={{ q, from, to, enabled, groupBy }}
          onClose={() => setSaveOpen(false)}
          onSaved={() => void refreshViews()}
        />
      )}
    </div>
  );
}

const STATUS_LABEL: Record<AlertStatus, string> = {
  open: "Nyitott",
  acknowledged: "Nyugtázva",
  escalated: "Eszkalálva",
  documented: "Dokumentálva",
  resolved: "Megoldva",
};
const STATUS_CLS: Record<AlertStatus, string> = {
  open: "bg-rose-500/15 text-rose-600 border-rose-500/30",
  acknowledged: "bg-amber-500/15 text-amber-600 border-amber-500/30",
  escalated: "bg-violet-500/15 text-violet-600 border-violet-500/30",
  documented: "bg-sky-500/15 text-sky-600 border-sky-500/30",
  resolved: "bg-emerald-500/15 text-emerald-600 border-emerald-500/30",
};

type AlertWithStatus = CriticalAlert & { workflow_status?: string | null };

function AlertManagerDialog({ alerts, onClose, onAcked }: { alerts: AlertWithStatus[]; onClose: () => void; onAcked: () => void }) {
  const [tab, setTab] = useState<"active" | "history" | "rules">("active");
  const [err, setErr] = useState<string | null>(null);
  const active = alerts.filter((a) => !["resolved", "documented"].includes((a.workflow_status as string) ?? "open"));
  const history = alerts.filter((a) => ["resolved", "documented"].includes((a.workflow_status as string) ?? "open"));

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-card rounded-2xl border border-border w-full max-w-3xl max-h-[85vh] overflow-hidden flex flex-col" onClick={(e) => e.stopPropagation()}>
        <header className="p-4 border-b border-border flex items-center justify-between">
          <h2 className="font-semibold flex items-center gap-2"><AlertTriangle className="h-4 w-4 text-rose-500" /> Riasztás-kezelő</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X className="h-4 w-4" /></button>
        </header>
        <div className="border-b border-border px-3 flex gap-1">
          {([
            ["active", `Aktív (${active.length})`],
            ["history", `Lezárt (${history.length})`],
            ["rules", "Eszkalációs szabályok"],
          ] as Array<[typeof tab, string]>).map(([k, l]) => (
            <button
              key={k}
              onClick={() => setTab(k)}
              className={"text-xs px-3 py-2 border-b-2 -mb-px " + (tab === k ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground")}
            >
              {l}
            </button>
          ))}
        </div>
        <div className="overflow-auto p-4 space-y-3">
          {err && <div className="text-xs text-rose-600 bg-rose-500/10 border border-rose-500/30 rounded p-2">{err}</div>}
          {tab === "active" && (
            active.length === 0 ? <Empty text="Nincs aktív riasztás." /> : (
              <ul className="space-y-2">
                {active.map((a) => (
                  <AlertCard key={a.id} alert={a} onChanged={onAcked} onError={setErr} />
                ))}
              </ul>
            )
          )}
          {tab === "history" && (
            history.length === 0 ? <Empty text="Nincs lezárt riasztás." /> : (
              <ul className="space-y-2">
                {history.map((a) => (
                  <AlertCard key={a.id} alert={a} onChanged={onAcked} onError={setErr} />
                ))}
              </ul>
            )
          )}
          {tab === "rules" && <EscalationRulesPanel onError={setErr} />}
        </div>
      </div>
    </div>
  );
}

function AlertCard({ alert, onChanged, onError }: { alert: AlertWithStatus; onChanged: () => void; onError: (m: string) => void }) {
  const upd = useServerFn(updateAlertWorkflowStatus);
  const listLog = useServerFn(listAlertStatusLog);
  const [busy, setBusy] = useState(false);
  const [open, setOpen] = useState(false);
  const [log, setLog] = useState<Awaited<ReturnType<typeof listLog>> | null>(null);
  const [note, setNote] = useState("");
  const status = (alert.workflow_status as AlertStatus | undefined) ?? "open";

  const change = async (to: AlertStatus) => {
    setBusy(true);
    try {
      await upd({ data: { alertId: alert.id, toStatus: to, note: note || null } });
      setNote("");
      onChanged();
      if (open) setLog(await listLog({ data: { alertId: alert.id } }));
    } catch (e) {
      onError(e instanceof Error ? e.message : "Hiba.");
    } finally {
      setBusy(false);
    }
  };

  const toggleHistory = async () => {
    setOpen((o) => !o);
    if (!open && log === null) {
      try {
        setLog(await listLog({ data: { alertId: alert.id } }));
      } catch {
        setLog([]);
      }
    }
  };

  return (
    <li className={"rounded-lg border p-3 " + STATUS_CLS[status]}>
      <div className="flex items-start justify-between gap-2">
        <div className="text-sm min-w-0">
          <span className="font-mono uppercase mr-2 text-[10px]">{alert.severity}</span>
          <span className={"text-[10px] font-mono uppercase px-1.5 py-0.5 rounded border " + STATUS_CLS[status]}>{STATUS_LABEL[status]}</span>
          <div className="mt-1">{alert.message ?? alert.code ?? alert.source}</div>
          <div className="text-[10px] text-muted-foreground mt-1">
            {alert.source} · {alert.code ?? "—"} · {new Date(alert.triggered_at).toLocaleString("hu-HU")}
          </div>
        </div>
      </div>
      <div className="mt-2 flex flex-wrap items-center gap-1.5">
        {ALERT_STATUSES.filter((s) => s !== status).map((s) => (
          <button
            key={s}
            onClick={() => change(s)}
            disabled={busy}
            className="text-[11px] px-2 py-0.5 rounded border border-border hover:bg-accent disabled:opacity-50"
          >
            → {STATUS_LABEL[s]}
          </button>
        ))}
        <button onClick={toggleHistory} className="ml-auto text-[11px] px-2 py-0.5 rounded border border-border hover:bg-accent inline-flex items-center gap-1">
          <History className="h-3 w-3" /> {open ? "Elrejt" : "Napló"}
        </button>
      </div>
      <input
        type="text"
        value={note}
        onChange={(e) => setNote(e.target.value)}
        placeholder="Megjegyzés a státuszváltáshoz (opcionális)…"
        className="mt-2 w-full text-xs rounded border border-input bg-background px-2 py-1"
      />
      {open && (
        <div className="mt-2 border-t border-border/60 pt-2">
          {log === null ? <div className="text-xs text-muted-foreground"><Loader2 className="h-3 w-3 animate-spin inline" /> Napló betöltése…</div> : log.length === 0 ? (
            <div className="text-xs text-muted-foreground italic">Nincs naplóbejegyzés.</div>
          ) : (
            <ul className="text-[11px] space-y-1">
              {log.map((l) => (
                <li key={l.id} className="flex items-start justify-between gap-2">
                  <span>
                    <span className="font-mono">{l.from_status ?? "—"} → {l.to_status}</span>
                    {l.note && <span className="text-muted-foreground ml-2">„{l.note}"</span>}
                  </span>
                  <span className="text-muted-foreground whitespace-nowrap">{new Date(l.created_at).toLocaleString("hu-HU")}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </li>
  );
}

function EscalationRulesPanel({ onError }: { onError: (m: string) => void }) {
  const list = useServerFn(listEscalationRules);
  const upsert = useServerFn(upsertEscalationRule);
  const del = useServerFn(deleteEscalationRule);
  const [rules, setRules] = useState<EscalationRule[]>([]);
  const [loading, setLoading] = useState(true);
  const [testRule, setTestRule] = useState<EscalationRule | null>(null);
  const [draft, setDraft] = useState<{ id?: string; name: string; severity: string; source: string; minutes: number; targetRole: string; active: boolean }>({
    name: "", severity: "", source: "", minutes: 30, targetRole: "", active: true,
  });

  const refresh = useCallback(async () => {
    setLoading(true);
    try { setRules(await list()); } catch (e) { onError(e instanceof Error ? e.message : "Hiba."); } finally { setLoading(false); }
  }, [list, onError]);

  useEffect(() => { void refresh(); }, [refresh]);

  const save = async () => {
    try {
      await upsert({ data: { id: draft.id, name: draft.name, severity: draft.severity || null, source: draft.source || null, escalateAfterMinutes: draft.minutes, targetRole: draft.targetRole || null, active: draft.active } });
      setDraft({ name: "", severity: "", source: "", minutes: 30, targetRole: "", active: true });
      void refresh();
    } catch (e) {
      onError(e instanceof Error ? e.message : "Hiba.");
    }
  };
  const remove = async (id: string) => {
    try { await del({ data: { id } }); void refresh(); } catch (e) { onError(e instanceof Error ? e.message : "Hiba."); }
  };

  return (
    <div className="space-y-3">
      <div className="rounded-lg border border-border bg-background p-3 space-y-2">
        <div className="text-xs font-semibold flex items-center gap-1"><Zap className="h-3 w-3 text-violet-500" /> {draft.id ? "Szabály szerkesztése" : "Új eszkalációs szabály"}</div>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
          <input value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} placeholder="Név" className="text-xs rounded border border-input bg-background px-2 py-1" />
          <input value={draft.severity} onChange={(e) => setDraft({ ...draft, severity: e.target.value })} placeholder="Súlyosság (pl. critical)" className="text-xs rounded border border-input bg-background px-2 py-1" />
          <input value={draft.source} onChange={(e) => setDraft({ ...draft, source: e.target.value })} placeholder="Forrás (pl. CGM)" className="text-xs rounded border border-input bg-background px-2 py-1" />
          <input type="number" min={1} value={draft.minutes} onChange={(e) => setDraft({ ...draft, minutes: Number(e.target.value) })} placeholder="Eszkaláció utáni perc" className="text-xs rounded border border-input bg-background px-2 py-1" />
          <input value={draft.targetRole} onChange={(e) => setDraft({ ...draft, targetRole: e.target.value })} placeholder="Cél szerepkör (pl. orvos)" className="text-xs rounded border border-input bg-background px-2 py-1" />
          <label className="text-xs inline-flex items-center gap-1"><input type="checkbox" checked={draft.active} onChange={(e) => setDraft({ ...draft, active: e.target.checked })} /> Aktív</label>
        </div>
        <div className="flex justify-end gap-2">
          {draft.id && <button onClick={() => setDraft({ name: "", severity: "", source: "", minutes: 30, targetRole: "", active: true })} className="text-xs px-2 py-1 rounded border border-border">Mégse</button>}
          <button onClick={save} className="text-xs px-2 py-1 rounded bg-primary text-primary-foreground inline-flex items-center gap-1"><Save className="h-3 w-3" /> Mentés</button>
        </div>
      </div>
      {loading ? <div className="text-xs text-muted-foreground"><Loader2 className="h-3 w-3 animate-spin inline" /> Betöltés…</div> : rules.length === 0 ? <Empty text="Még nincs eszkalációs szabály." /> : (
        <ul className="space-y-1">
          {rules.map((r) => (
            <li key={r.id} className="rounded border border-border p-2 flex items-center justify-between gap-2 text-xs">
              <div className="min-w-0">
                <div className="font-semibold">{r.name} {!r.active && <span className="text-muted-foreground">(inaktív)</span>}</div>
                <div className="text-muted-foreground">
                  {r.severity ?? "*"} / {r.source ?? "*"} · {r.escalate_after_minutes} perc után → {r.target_role ?? "—"}
                </div>
              </div>
              <div className="flex gap-1">
                <button onClick={() => setTestRule(r)} className="px-1.5 py-0.5 rounded border border-violet-500/30 text-violet-600 hover:bg-violet-500/10 inline-flex items-center gap-1"><PlayCircle className="h-3 w-3" /> Teszt</button>
                <button onClick={() => setDraft({ id: r.id, name: r.name, severity: r.severity ?? "", source: r.source ?? "", minutes: r.escalate_after_minutes, targetRole: r.target_role ?? "", active: r.active })} className="px-1.5 py-0.5 rounded border border-border hover:bg-accent">Szerkeszt</button>
                <button onClick={() => remove(r.id)} className="px-1.5 py-0.5 rounded border border-rose-500/30 text-rose-600 hover:bg-rose-500/10"><Trash2 className="h-3 w-3" /></button>
              </div>
            </li>
          ))}
        </ul>
      )}
      {testRule && (
        <TestRunDialog rule={testRule} onClose={() => setTestRule(null)} onDone={() => { setTestRule(null); void refresh(); }} onError={onError} />
      )}
    </div>
  );
}

function TestRunDialog({ rule, onClose, onDone, onError }: { rule: EscalationRule; onClose: () => void; onDone: () => void; onError: (m: string) => void }) {
  const listAlerts = useServerFn(listOpenAlertsForTest);
  const testRun = useServerFn(testEscalationRuleOnAlert);
  const [alerts, setAlerts] = useState<Awaited<ReturnType<typeof listOpenAlertsForTest>>>([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [result, setResult] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      setLoading(true);
      try {
        setAlerts(await listAlerts({ data: { severity: rule.severity ?? null, source: rule.source ?? null, limit: 50 } }));
      } catch (e) { onError(e instanceof Error ? e.message : "Hiba."); }
      finally { setLoading(false); }
    })();
  }, [listAlerts, rule.severity, rule.source, onError]);

  const fire = async (alertId: string) => {
    setBusyId(alertId); setResult(null);
    try {
      const r = await testRun({ data: { ruleId: rule.id, alertId } });
      setResult(`OK — eszkalált: ${r.escalated}${r.errors.length ? `, hiba: ${r.errors.length}` : ""}`);
      if (r.escalated > 0) setTimeout(onDone, 800);
    } catch (e) {
      onError(e instanceof Error ? e.message : "Hiba.");
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-card border border-border rounded-xl w-full max-w-2xl max-h-[80vh] flex flex-col" onClick={(e) => e.stopPropagation()}>
        <header className="p-4 border-b border-border flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold flex items-center gap-2"><PlayCircle className="h-4 w-4 text-violet-500" /> Szabály tesztelése: {rule.name}</h3>
            <p className="text-xs text-muted-foreground mt-1">
              Szűrés: {rule.severity ?? "*"} / {rule.source ?? "*"}. A „Futtatás” az időkorlát figyelmen kívül hagyásával eszkalálja a kiválasztott riasztást, és „TESZT futtatás”-ként rögzíti a naplóba.
            </p>
          </div>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X className="h-4 w-4" /></button>
        </header>
        <div className="p-4 overflow-auto flex-1">
          {loading ? (
            <div className="text-xs text-muted-foreground inline-flex items-center gap-1"><Loader2 className="h-3 w-3 animate-spin" /> Riasztások betöltése…</div>
          ) : alerts.length === 0 ? (
            <Empty text="Nincs olyan nyitott riasztás, amire ez a szabály illik." />
          ) : (
            <ul className="space-y-1">
              {alerts.map((a) => (
                <li key={a.id} className="rounded border border-border p-2 flex items-center justify-between gap-2 text-xs">
                  <div className="min-w-0">
                    <div className="font-semibold truncate">
                      <span className="font-mono uppercase mr-2">{a.severity}</span>{a.message ?? a.code ?? a.source}
                    </div>
                    <div className="text-muted-foreground truncate">
                      {a.patients.vezeteknev ?? ""} {a.patients.keresztnev ?? ""} · TAJ {a.patients.taj ?? "—"} · {new Date(a.triggered_at).toLocaleString("hu-HU")} · státusz: {a.workflow_status ?? "open"}
                    </div>
                  </div>
                  <button
                    onClick={() => fire(a.id)}
                    disabled={busyId === a.id}
                    className="px-2 py-1 rounded bg-violet-500 text-white hover:bg-violet-600 inline-flex items-center gap-1 disabled:opacity-50"
                  >
                    {busyId === a.id ? <Loader2 className="h-3 w-3 animate-spin" /> : <PlayCircle className="h-3 w-3" />} Futtatás
                  </button>
                </li>
              ))}
            </ul>
          )}
          {result && <div className="mt-3 text-xs text-emerald-600">{result}</div>}
        </div>
      </div>
    </div>
  );
}

function SavedViewsBar({ views, onApply, onSave, onDelete }: { views: SavedView[]; onApply: (v: SavedView) => void; onSave: () => void; onDelete: (id: string) => void }) {
  return (
    <section className="rounded-xl border border-border bg-card p-2 flex items-center gap-2 flex-wrap">
      <span className="text-[10px] uppercase text-muted-foreground px-1 inline-flex items-center gap-1"><Star className="h-3 w-3" /> Kedvenc nézetek</span>
      {views.length === 0 && <span className="text-xs text-muted-foreground italic">Nincs mentett nézet.</span>}
      {views.map((v) => (
        <span key={v.id} className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full border border-border bg-background">
          {v.is_default && <Star className="h-3 w-3 text-amber-500 fill-amber-500" />}
          <button onClick={() => onApply(v)} className="hover:underline">{v.name}</button>
          <button onClick={() => onDelete(v.id)} className="text-muted-foreground hover:text-rose-600"><X className="h-3 w-3" /></button>
        </span>
      ))}
      <button onClick={onSave} className="ml-auto text-xs px-2 py-1 rounded-md border border-border hover:bg-accent inline-flex items-center gap-1">
        <Plus className="h-3 w-3" /> Aktuális mentése
      </button>
    </section>
  );
}

function SaveViewDialog({ patientId, existing, currentFilters, onClose, onSaved }: { patientId: string; existing: SavedView[]; currentFilters: Record<string, unknown>; onClose: () => void; onSaved: () => void }) {
  const save = useServerFn(saveSavedView);
  const [name, setName] = useState("");
  const [isDefault, setIsDefault] = useState(false);
  const [scope, setScope] = useState<"patient" | "global">("patient");
  const [overwriteId, setOverwriteId] = useState<string>("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const submit = async () => {
    setBusy(true); setErr(null);
    try {
      await save({
        data: {
          id: overwriteId || undefined,
          patientId: scope === "patient" ? patientId : null,
          name: name || (overwriteId ? existing.find((e) => e.id === overwriteId)?.name ?? "Új nézet" : "Új nézet"),
          filters: currentFilters as Record<string, any>,
          isDefault,
        },
      });
      onSaved();
      onClose();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Hiba a mentéskor.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-card rounded-2xl border border-border w-full max-w-md" onClick={(e) => e.stopPropagation()}>
        <header className="p-4 border-b border-border flex items-center justify-between">
          <h2 className="font-semibold flex items-center gap-2"><Save className="h-4 w-4 text-primary" /> Nézet mentése</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X className="h-4 w-4" /></button>
        </header>
        <div className="p-4 space-y-3">
          {existing.length > 0 && (
            <label className="block text-xs">
              <span className="text-muted-foreground block mb-1">Felülírás (opcionális)</span>
              <select value={overwriteId} onChange={(e) => setOverwriteId(e.target.value)} className="w-full text-sm rounded-md bg-background border border-input px-2 py-1.5">
                <option value="">— Új nézet —</option>
                {existing.map((e) => <option key={e.id} value={e.id}>{e.name}</option>)}
              </select>
            </label>
          )}
          {!overwriteId && (
            <label className="block text-xs">
              <span className="text-muted-foreground block mb-1">Név</span>
              <input value={name} onChange={(e) => setName(e.target.value)} placeholder="pl. Aktív kórház, kritikus" className="w-full text-sm rounded-md bg-background border border-input px-2 py-1.5" />
            </label>
          )}
          <div className="flex flex-wrap gap-3 text-xs">
            <label className="inline-flex items-center gap-1">
              <input type="radio" checked={scope === "patient"} onChange={() => setScope("patient")} /> Csak ehhez a beteghez
            </label>
            <label className="inline-flex items-center gap-1">
              <input type="radio" checked={scope === "global"} onChange={() => setScope("global")} /> Minden betegnél
            </label>
          </div>
          <label className="inline-flex items-center gap-1 text-xs">
            <input type="checkbox" checked={isDefault} onChange={(e) => setIsDefault(e.target.checked)} /> Beállítás alapértelmezettnek
          </label>
          {err && <div className="text-xs text-rose-600 bg-rose-500/10 border border-rose-500/30 rounded p-2">{err}</div>}
        </div>
        <footer className="p-3 border-t border-border flex justify-end gap-2">
          <button onClick={onClose} className="text-xs px-3 py-1.5 rounded-md border border-border hover:bg-accent">Mégse</button>
          <button onClick={submit} disabled={busy} className="text-xs px-3 py-1.5 rounded-md bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50 inline-flex items-center gap-1">
            {busy ? <Loader2 className="h-3 w-3 animate-spin" /> : <Save className="h-3 w-3" />} Mentés
          </button>
        </footer>
      </div>
    </div>
  );
}

function TimelineBlock({ items, encounters, groupBy, setGroupBy, collapsed, setCollapsed, highlightId, matchIds, hasQuery }: {
  items: Array<{ id: string; ts: string; cat: CategoryKey; title: string; sub?: string; severity?: string }>;
  encounters: Encounter[];
  groupBy: "none" | "day" | "encounter";
  setGroupBy: (g: "none" | "day" | "encounter") => void;
  collapsed: Record<string, boolean>;
  setCollapsed: (fn: (s: Record<string, boolean>) => Record<string, boolean>) => void;
  highlightId?: string | null;
  matchIds?: Set<string>;
  hasQuery?: boolean;
}) {
  const groups = useMemo(() => {
    if (groupBy === "none") {
      return [{ key: "all", label: `Összes esemény (${items.length})`, items }];
    }
    if (groupBy === "day") {
      const m = new Map<string, typeof items>();
      items.forEach((it) => {
        const k = new Date(it.ts).toISOString().slice(0, 10);
        if (!m.has(k)) m.set(k, []);
        m.get(k)!.push(it);
      });
      return Array.from(m.entries())
        .sort((a, b) => (a[0] < b[0] ? 1 : -1))
        .map(([k, v]) => ({ key: `d-${k}`, label: `${new Date(k).toLocaleDateString("hu-HU", { weekday: "short", year: "numeric", month: "long", day: "numeric" })} · ${v.length} esemény`, items: v }));
    }
    // encounter
    const sortedEnc = [...encounters].sort((a, b) => new Date(b.start_ts).getTime() - new Date(a.start_ts).getTime());
    const buckets: Record<string, typeof items> = { __other: [] };
    sortedEnc.forEach((e) => { buckets[e.id] = []; });
    items.forEach((it) => {
      const t = new Date(it.ts).getTime();
      const enc = sortedEnc.find((e) => {
        const s = new Date(e.start_ts).getTime();
        const en = e.end_ts ? new Date(e.end_ts).getTime() : Date.now();
        return t >= s && t <= en;
      });
      (enc ? buckets[enc.id] : buckets.__other).push(it);
    });
    const res: Array<{ key: string; label: string; items: typeof items }> = [];
    sortedEnc.forEach((e) => {
      if (buckets[e.id].length > 0) {
        res.push({ key: `e-${e.id}`, label: `Epizód · ${e.encounter_type} · ${new Date(e.start_ts).toLocaleDateString("hu-HU")} · ${buckets[e.id].length} esemény`, items: buckets[e.id] });
      }
    });
    if (buckets.__other.length > 0) {
      res.push({ key: "__other", label: `Epizódon kívül · ${buckets.__other.length} esemény`, items: buckets.__other });
    }
    return res;
  }, [items, encounters, groupBy]);

  const toggle = (k: string) => setCollapsed((s) => ({ ...s, [k]: !s[k] }));
  const allCollapsed = groups.every((g) => collapsed[g.key]);
  const toggleAll = () => setCollapsed(() => Object.fromEntries(groups.map((g) => [g.key, !allCollapsed])));

  return (
    <section className="rounded-xl border border-border bg-card p-4">
      <div className="flex items-center gap-2 mb-3 flex-wrap">
        <History className="h-4 w-4 text-primary" />
        <h2 className="text-sm font-semibold">Idővonal ({items.length})</h2>
        <div className="ml-auto flex items-center gap-1 text-xs">
          <span className="text-muted-foreground">Csoportosítás:</span>
          {(["day", "encounter", "none"] as const).map((g) => (
            <button key={g} onClick={() => setGroupBy(g)} className={"px-2 py-0.5 rounded border " + (groupBy === g ? "bg-primary/10 border-primary/30 text-primary" : "border-border text-muted-foreground")}>
              {g === "day" ? "Nap" : g === "encounter" ? "Epizód" : "Nincs"}
            </button>
          ))}
          <button onClick={toggleAll} className="ml-1 px-2 py-0.5 rounded border border-border hover:bg-accent">
            {allCollapsed ? "Mind kinyit" : "Mind becsuk"}
          </button>
        </div>
      </div>
      {items.length === 0 ? <Empty text="Nincs esemény a megadott szűréssel." /> : (
        <div className="max-h-[480px] overflow-auto pr-2 space-y-2">
          {groups.map((g) => {
            const isCol = !!collapsed[g.key];
            return (
              <div key={g.key} className="border border-border/60 rounded-lg">
                <button onClick={() => toggle(g.key)} className="w-full flex items-center gap-2 px-3 py-2 text-left text-xs font-semibold hover:bg-accent/50">
                  {isCol ? <ChevronRight className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
                  {g.label}
                </button>
                {!isCol && (
                  <ol className="relative border-l border-border ml-5 mr-3 mb-3 space-y-2">
                    {g.items.slice(0, 100).map((it) => {
                      const isHi = highlightId === it.id;
                      const isMatch = !!hasQuery && !!matchIds?.has(it.id);
                      return (
                        <li
                          key={it.id}
                          data-tl-id={it.id}
                          tabIndex={-1}
                          className={
                            "ml-3 rounded-md px-2 py-1 transition-colors outline-none focus-visible:ring-2 focus-visible:ring-primary " +
                            (isHi
                              ? "ring-2 ring-amber-400 bg-amber-400/15 animate-pulse"
                              : isMatch
                                ? "bg-amber-400/10 ring-1 ring-amber-400/40"
                                : "")
                          }
                        >
                          <span className={
                            "absolute -left-1.5 w-3 h-3 rounded-full border-2 border-background " +
                            (isMatch
                              ? "bg-amber-500 ring-2 ring-amber-300/60"
                              : it.cat === "alerts" ? "bg-rose-500" : it.cat === "encounters" ? "bg-primary" : it.cat === "diagnoses" ? "bg-amber-500" : it.cat === "labs" ? "bg-sky-500" : it.cat === "vitals" ? "bg-emerald-500" : "bg-muted-foreground")
                          } />
                          <div className="text-[10px] font-mono text-muted-foreground flex items-center gap-1">
                            {isMatch && <Target className="h-2.5 w-2.5 text-amber-600" aria-label="Találat" />}
                            {new Date(it.ts).toLocaleString("hu-HU")}
                          </div>
                          <div className="text-sm">{it.title}</div>
                          {it.sub && <div className="text-xs text-muted-foreground truncate">{it.sub}</div>}
                        </li>
                      );
                    })}
                  </ol>
                )}
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
}

const PDF_SECTIONS: Array<{ key: Section360Key; label: string }> = [
  { key: "patient", label: "Alapadatok" },
  { key: "encounters", label: "Epizódok" },
  { key: "diagnoses", label: "Diagnózisok" },
  { key: "therapies", label: "Terápia" },
  { key: "vitals", label: "Vitálok" },
  { key: "labs", label: "Labor" },
  { key: "measurements", label: "Otthoni mérések" },
  { key: "alerts", label: "Kritikus riasztások" },
  { key: "referrals", label: "Beutalók / receptek" },
  { key: "notes", label: "Jegyzetek" },
  { key: "questionnaires", label: "Kérdőívek" },
];

function PdfExportDialog({ patientId, defaultFrom, defaultTo, onClose }: { patientId: string; defaultFrom: string; defaultTo: string; onClose: () => void }) {
  const gen = useServerFn(generatePaciens360Pdf);
  const [sel, setSel] = useState<Record<Section360Key, boolean>>(() =>
    Object.fromEntries(PDF_SECTIONS.map((s) => [s.key, true])) as Record<Section360Key, boolean>,
  );
  const [from, setFrom] = useState(defaultFrom);
  const [to, setTo] = useState(defaultTo);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [result, setResult] = useState<{ generatedAt: string; dataVersion: string; partialReasons: string[] } | null>(null);

  const toggle = (k: Section360Key) => setSel((s) => ({ ...s, [k]: !s[k] }));

  const handleGenerate = async () => {
    setBusy(true); setErr(null); setResult(null);
    try {
      const sections = PDF_SECTIONS.filter((s) => sel[s.key]).map((s) => s.key);
      if (sections.length === 0) throw new Error("Válassz legalább egy szakaszt.");
      const res = await gen({ data: { patientId, sections, from: from || null, to: to || null } });
      const bin = atob(res.pdf);
      const arr = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
      const blob = new Blob([arr], { type: "application/pdf" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url; a.download = res.filename;
      document.body.appendChild(a); a.click(); a.remove();
      URL.revokeObjectURL(url);
      setResult(res.meta);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Hiba a PDF generálásakor.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-card rounded-2xl border border-border w-full max-w-md" onClick={(e) => e.stopPropagation()}>
        <header className="p-4 border-b border-border flex items-center justify-between">
          <h2 className="font-semibold flex items-center gap-2"><Download className="h-4 w-4 text-primary" /> PDF jelentés</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X className="h-4 w-4" /></button>
        </header>
        <div className="p-4 space-y-3">
          <div>
            <div className="text-xs font-semibold mb-2">Szakaszok</div>
            <div className="grid grid-cols-2 gap-1.5">
              {PDF_SECTIONS.map((s) => (
                <label key={s.key} className="flex items-center gap-2 text-sm cursor-pointer">
                  <input type="checkbox" checked={sel[s.key]} onChange={() => toggle(s.key)} />
                  {s.label}
                </label>
              ))}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <label className="text-xs">
              <span className="text-muted-foreground block">Dátumtól</span>
              <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} className="w-full text-sm rounded-md bg-background border border-input px-2 py-1.5" />
            </label>
            <label className="text-xs">
              <span className="text-muted-foreground block">Dátumig</span>
              <input type="date" value={to} onChange={(e) => setTo(e.target.value)} className="w-full text-sm rounded-md bg-background border border-input px-2 py-1.5" />
            </label>
          </div>
          {err && <div className="text-xs text-rose-600 bg-rose-500/10 border border-rose-500/30 rounded p-2">{err}</div>}
          {result && (
            <div className="text-xs space-y-1 rounded-md border border-emerald-500/30 bg-emerald-500/5 p-2">
              <div className="font-semibold text-emerald-600">PDF letöltve.</div>
              <div className="text-muted-foreground">Generálva: {new Date(result.generatedAt).toLocaleString("hu-HU")}</div>
              <div className="text-muted-foreground">Adatverzió: <span className="font-mono">{result.dataVersion}</span></div>
              {result.partialReasons.length > 0 && (
                <div className="mt-1 pt-1 border-t border-amber-500/30">
                  <div className="font-semibold text-amber-600">⚠ Részleges adat</div>
                  <ul className="list-disc list-inside text-[11px] text-amber-700">
                    {result.partialReasons.map((r, i) => <li key={i}>{r}</li>)}
                  </ul>
                </div>
              )}
            </div>
          )}
        </div>
        <footer className="p-3 border-t border-border flex items-center justify-end gap-2">
          <button onClick={onClose} className="text-xs px-3 py-1.5 rounded-md border border-border hover:bg-accent">Bezárás</button>
          <button onClick={handleGenerate} disabled={busy} className="text-xs px-3 py-1.5 rounded-md bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50 inline-flex items-center gap-1">
            {busy ? <Loader2 className="h-3 w-3 animate-spin" /> : <Download className="h-3 w-3" />} Generálás
          </button>
        </footer>
      </div>
    </div>
  );
}

function ActionBar({ patientId, encounterId, onExport, onAlerts, onAiExplanations }: { patientId: string; encounterId?: string; onExport: () => void; onAlerts: () => void; onAiExplanations: () => void }) {
  const actions: Array<{ label: string; Icon: typeof Activity; to: string; params?: Record<string, string>; search?: Record<string, string>; disabled?: boolean }> = [
    { label: "Beteg-karton", Icon: ClipboardList, to: "/klinika/beteg/$patientId", params: { patientId }, search: encounterId ? { encounterId, tab: "overview" } : undefined },
    { label: "Lázlap", Icon: LineChart, to: "/klinika/lazlap/$encounterId", params: encounterId ? { encounterId } : undefined, disabled: !encounterId },
    { label: "Partogram", Icon: Baby, to: "/klinika/partogram/$encounterId", params: encounterId ? { encounterId } : undefined, disabled: !encounterId },
    { label: "Klinikai eszközök", Icon: Stethoscope, to: "/klinika/eszkozok" },
    { label: "Üzenetek", Icon: MessageSquare, to: "/uzenetek" },
    { label: "Új epizód", Icon: CalendarPlus, to: "/paciensek", search: { id: patientId } },
  ];

  return (
    <div className="flex flex-wrap gap-1.5">
      <button onClick={onExport} className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-primary/40 bg-primary/10 text-primary text-xs hover:bg-primary/20">
        <Download className="h-3.5 w-3.5" /> PDF jelentés
      </button>
      <button onClick={onAlerts} className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-border text-xs hover:bg-accent">
        <AlertTriangle className="h-3.5 w-3.5" /> Riasztások
      </button>
      <button onClick={onAiExplanations} className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-border text-xs hover:bg-accent">
        <Sparkles className="h-3.5 w-3.5" /> AI lelet-magyarázatok
      </button>
      {actions.map((a) =>
        a.disabled ? (
          <span key={a.label} title="Nincs aktív epizód" className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-border text-xs text-muted-foreground/60 cursor-not-allowed">
            <a.Icon className="h-3.5 w-3.5" />{a.label}
          </span>
        ) : (
          <Link
            /* eslint-disable @typescript-eslint/no-explicit-any */
            to={a.to as any}
            params={a.params as any}
            search={a.search as any}
            /* eslint-enable @typescript-eslint/no-explicit-any */
            key={a.label}
            className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-border text-xs hover:bg-accent transition-colors"
          >
            <a.Icon className="h-3.5 w-3.5" />{a.label}
          </Link>
        ),
      )}
    </div>
  );
}

function Section({ title, icon: Icon, children }: { title: string; icon: typeof Activity; children: React.ReactNode }) {
  return (
    <section className="rounded-xl border border-border bg-card p-4">
      <div className="flex items-center gap-2 mb-3">
        <Icon className="h-4 w-4 text-primary" />
        <h2 className="text-sm font-semibold">{title}</h2>
      </div>
      {children}
    </section>
  );
}

function Empty({ text }: { text: string }) {
  return <p className="text-xs text-muted-foreground italic">{text}</p>;
}

function StatusPill({ status }: { status: string }) {
  const cls =
    status === "in-progress" || status === "active"
      ? "bg-emerald-500/15 text-emerald-600"
      : status === "finished" || status === "completed" || status === "signed"
        ? "bg-sky-500/15 text-sky-600"
        : status === "cancelled" || status === "rejected"
          ? "bg-rose-500/15 text-rose-600"
          : "bg-secondary text-muted-foreground";
  return <span className={`text-[10px] font-mono uppercase px-1.5 py-0.5 rounded ${cls}`}>{status || "—"}</span>;
}
