import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { toast } from "sonner";
import {
  User as UserIcon,
  ShieldCheck,
  GraduationCap,
  Award,
  BookOpen,
  Plus,
  Trash2,
  Loader2,
  Save,
  Phone,
  Sliders,
  Star,
  StarOff,
  CalendarOff,
  HeartPulse,
  Check,
  X,
  Clock,
  History,
  ChevronDown,
  ChevronRight,
} from "lucide-react";
import { ReasonInput } from "@/components/reason-input";
import { applyReason } from "@/lib/audit-reason";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { usePermissions } from "@/hooks/use-permissions";
import { humanizeError } from "@/lib/humanize-error";
import { cn } from "@/lib/utils";
import { RecordHistory, SchedulingActivityFeed } from "@/components/audit-history";
import { Calendar } from "@/components/ui/calendar";
import type { DateRange } from "react-day-picker";

import { BeavatkozasokTab } from "@/components/karakterlap/beavatkozasok-tab";
import { PeerLinksTab } from "@/components/karakterlap/peer-links-tab";
import { EmploymentTab } from "@/components/karakterlap/employment-tab";
import { MunkaidoMerlegWidget } from "@/components/karakterlap/munkaido-merleg-widget";
import { EusztvWidget } from "@/components/karakterlap/eusztv-widget";
import { IlletmenyReport } from "@/components/karakterlap/illetmeny-report";
import { WorkTimeFrameEditor } from "@/components/karakterlap/work-time-frame-editor";
import { IlletmenySnapshots } from "@/components/karakterlap/illetmeny-snapshots";
import { AkkreditaciokTab } from "@/components/karakterlap/akkreditaciok-tab";
import { OvertimeTab } from "@/components/karakterlap/overtime-tab";
import { DailyPreferencesTab } from "@/components/karakterlap/daily-preferences-tab";
import { PairedShiftsTab } from "@/components/karakterlap/paired-shifts-tab";
import { DutyAvailabilityTab } from "@/components/karakterlap/duty-availability-tab";
import { ExternalHoursTab } from "@/components/karakterlap/external-hours-tab";
import { Stethoscope, Network, Briefcase, BadgeCheck, Zap, CalendarDays, Users2, HandHeart, Building2, Bell } from "lucide-react";
import { NotificationSettings } from "@/components/karakterlap/notification-settings";

export const Route = createFileRoute("/_authenticated/karakterlap")({
  validateSearch: (s: Record<string, unknown>): { user?: string } => ({
    user: typeof s.user === "string" ? s.user : undefined,
  }),
  component: KarakterlapPage,
});

type Profile = {
  id: string;
  tenant_id: string | null;
  email: string;
  teljes_nev: string;
  foglalkozas_tipus: "orvos" | "szakdolgozo" | "egyeb";
  becenev: string | null;
  szuletesi_datum: string | null;
  nem: "ferfi" | "no" | "egyeb" | "nem_nyilatkozik" | null;
  bemutatkozas: string | null;
  bemutatkozas_publikus: boolean;
  gyermek_szamok?: Array<{ nev?: string; szuletes: string; fogyatekos?: boolean }> | null;
  vezetoi_szint?: "nincs" | "vezeto" | "magasabb_vezeto" | null;
  sugarterheles_kategoria?: string | null;
  oktatoi_munkakor?: boolean | null;
  klinikai_kombinalt?: boolean | null;
  kjt_fizetesi_osztaly?: string | null;
  belepes_datum?: string | null;
};

type Contact = {
  id: string;
  user_id: string;
  tipus: "telefon" | "mobil" | "email" | "signal" | "whatsapp" | "telegram" | "veszhelyzeti_hozzatartozo" | "egyeb";
  cimke: string | null;
  ertek: string;
  is_primary: boolean;
  sorrend: number;
  csak_vesz_eseten: boolean;
  ertesites_engedelyezve: boolean;
  megjegyzes: string | null;
};

type PrefStatus = "tervezett" | "jovahagyasra_var" | "jovahagyott" | "elutasitott";
type Preferences = {
  user_id: string;
  tenant_id: string | null;
  heti_max_ora: number | null;
  havi_max_ugyelet: number | null;
  preferalt_musakok: Array<"nappal" | "delutan" | "ejszaka" | "huszonnegy">;
  tiltott_napok: number[];
  kozossegi_napok: string[];
  preferalt_feladat_korok: string[];
  ugyelet_utan_pihenonap: boolean;
  ugyelet_utan_min_ora: number;
  egymas_utani_max_ugyelet: number;
  last_minute_elerheto: boolean;
  last_minute_orahatar: number | null;
  utazasi_perc_max: number | null;
  nyelvek: string[];
  megjegyzes: string | null;
  status: PrefStatus;
  submitted_at: string | null;
  jovahagyo_id: string | null;
  jovahagyas_at: string | null;
  jovahagyas_indok: string | null;
  jovahagyas_feltetel: string | null;
};
type FeladatKor = {
  id: string;
  kulcs: string;
  nev: string;
  sorrend: number;
  rendszerszintu: boolean;
  aktiv: boolean;
};

type Skill = { id: string; nev: string; kulcs: string; kategoria: string | null };
type ProfileSkill = {
  id: string;
  skill_id: string;
  szint: number;
  igazolva_at: string | null;
  lejarat: string | null;
  megjegyzes: string | null;
};
type Cert = {
  id: string;
  nev: string;
  tipus: string;
  kibocsato: string | null;
  szam: string | null;
  kibocsatva: string | null;
  lejarat: string | null;
};
type Training = {
  id: string;
  nev: string;
  program_id: string | null;
  kezdes: string | null;
  varhato_veg: string | null;
  elorehaladas_pct: number;
  statusz: string;
};
type UserRoleRow = {
  id: string;
  role_id: string;
  site_id: string | null;
  org_unit_id: string | null;
  roles: { kulcs: string; megnevezes: string; kategoria: string } | null;
  sites: { nev: string } | null;
  org_units: { nev: string } | null;
};

const TABS = [
  { key: "basics", icon: UserIcon, label: "Alapadatok", group: "profil" },
  { key: "szabadsag_adatok", icon: UserIcon, label: "Szabadság-adatok", group: "profil" },
  { key: "contacts", icon: Phone, label: "Kapcsolat", group: "profil" },
  { key: "employment", icon: Briefcase, label: "Jogviszony", group: "profil" },
  { key: "preferences", icon: Sliders, label: "Preferenciák", group: "profil" },
  { key: "skills", icon: GraduationCap, label: "Skill-ek", group: "keszsegek" },
  { key: "certs", icon: Award, label: "Képzettségek", group: "keszsegek" },
  { key: "trainings", icon: BookOpen, label: "Képzések", group: "keszsegek" },
  { key: "beavatkozasok", icon: Stethoscope, label: "Beavatkozások", group: "keszsegek" },
  { key: "akkreditaciok", icon: BadgeCheck, label: "Akkreditációk", group: "keszsegek" },
  { key: "unavailability", icon: CalendarOff, label: "Távollétek", group: "beosztas" },
  { key: "constraints", icon: HeartPulse, label: "Korlátozó tényezők", group: "beosztas" },
  { key: "munkaido", icon: Clock, label: "Munkaidő-mérleg", group: "beosztas" },
  { key: "overtime", icon: Zap, label: "Túlóra", group: "beosztas" },
  { key: "external_hours", icon: Building2, label: "Máshol töltött órák", group: "beosztas" },
  { key: "napi_pref", icon: CalendarDays, label: "Napi preferenciák", group: "beosztas" },
  { key: "paros", icon: Users2, label: "Páros műszakok", group: "beosztas" },
  { key: "duty_avail", icon: HandHeart, label: "Rendelkezésre állás", group: "beosztas" },
  { key: "network", icon: Network, label: "Kapcsolati háló", group: "beosztas" },
  { key: "elozmenyek", icon: History, label: "Előzmények", group: "beosztas" },
  { key: "notifications", icon: Bell, label: "Értesítések", group: "profil" },
  { key: "roles", icon: ShieldCheck, label: "Szerepkörök", group: "szerepkorok" },
] as const;

const TAB_GROUPS = [
  { key: "profil", label: "Profil" },
  { key: "keszsegek", label: "Készségek" },
  { key: "beosztas", label: "Beosztás" },
  { key: "szerepkorok", label: "Szerepkörök" },
] as const;

function KarakterlapPage() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const { can } = usePermissions();
  const search = Route.useSearch();
  // Admins / HR may view any team member's profile via ?user=<userId>.
  // Falls back to the signed-in user's own profile.
  const targetUserId = (search.user && can("manage_tenant")) ? search.user : user?.id ?? null;
  const isViewingOther = !!targetUserId && !!user && targetUserId !== user.id;
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<(typeof TABS)[number]["key"]>("basics");

  useEffect(() => {
    if (!targetUserId) return;
    setLoading(true);
    (async () => {
      const { data } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", targetUserId)
        .maybeSingle();
      setProfile(data as Profile | null);
      setLoading(false);
    })();
  }, [targetUserId]);

  // Notification poll: toast recent status decisions on this user's records since last visit.
  useEffect(() => {
    if (!user) return;
    const storageKey = `karakterlap.lastSeenAudit.${user.id}`;
    const since = localStorage.getItem(storageKey) ?? new Date(Date.now() - 7 * 24 * 3600 * 1000).toISOString();
    let cancelled = false;
    (async () => {
      const { data } = await supabase
        .from("admin_audit_log")
        .select("id, created_at, action, table_name, before_data, after_data, user_id")
        .in("table_name", ["profile_unavailability", "profile_constraints"])
        .gt("created_at", since)
        .order("created_at", { ascending: false })
        .limit(50);
      if (cancelled || !data) return;
      let newestTs = since;
      for (const row of data) {
        if (row.created_at > newestTs) newestTs = row.created_at;
        const before = row.before_data as Record<string, unknown> | null;
        const after = row.after_data as Record<string, unknown> | null;
        const ownerId = (after?.["user_id"] ?? before?.["user_id"]) as string | undefined;
        if (ownerId !== user.id) continue;
        if (row.user_id === user.id) continue;
        const beforeStatus = before?.["status"] as string | undefined;
        const afterStatus = after?.["status"] as string | undefined;
        const isUnav = row.table_name === "profile_unavailability";
        if (isUnav && beforeStatus !== afterStatus) {
          if (afterStatus === "jovahagyott") toast.success("Egy távolléti kérelmét jóváhagyták.");
          else if (afterStatus === "elutasitott") toast.error("Egy távolléti kérelmét elutasították.");
          else if (afterStatus === "jovahagyasra_var") toast("Távolléti kérelem beküldve jóváhagyásra.");
        }
      }
      localStorage.setItem(storageKey, newestTs);
    })();
    return () => {
      cancelled = true;
    };
  }, [user]);

  if (loading) {
    return (
      <div className="p-8 flex items-center gap-2 text-muted-foreground text-sm">
        <Loader2 className="size-4 animate-spin" /> {t("common.loading")}
      </div>
    );
  }
  if (!profile) {
    return <div className="p-8 text-sm text-muted-foreground">Nincs profil-adat.</div>;
  }

  return (
    <div className="p-8 max-w-5xl mx-auto space-y-6">
      {isViewingOther && (
        <div className="rounded-lg border border-amber-500/40 bg-amber-500/10 text-amber-800 dark:text-amber-200 px-3 py-2 text-sm flex items-center justify-between gap-3">
          <span>
            HR-admin nézet: <strong>{profile.teljes_nev}</strong> karakterlapját szerkeszti.
          </span>
          <a href="/csapat" className="underline text-xs">← Vissza a csapatra</a>
        </div>
      )}
      <header>
        <h1 className="text-2xl font-bold tracking-tight">{profile.teljes_nev}</h1>
        <p className="text-sm text-muted-foreground font-mono">{profile.email}</p>
      </header>

      <div className="space-y-2">
        <div className="flex gap-1 border-b border-border overflow-x-auto">
          {TAB_GROUPS.map((g) => {
            const tabsInGroup = TABS.filter((tb) => tb.group === g.key);
            const active = tabsInGroup.some((tb) => tb.key === tab);
            return (
              <button
                key={g.key}
                type="button"
                onClick={() => setTab(tabsInGroup[0].key)}
                className={cn(
                  "px-4 py-2 text-sm font-semibold border-b-2 -mb-px transition-colors whitespace-nowrap",
                  active
                    ? "border-primary text-foreground"
                    : "border-transparent text-muted-foreground hover:text-foreground",
                )}
              >
                {g.label}
              </button>
            );
          })}
        </div>
        <div className="flex gap-1 flex-wrap">
          {TABS.filter((tb) => tb.group === (TABS.find((x) => x.key === tab)?.group ?? "profil")).map((tb) => {
            const Icon = tb.icon;
            const active = tab === tb.key;
            return (
              <button
                key={tb.key}
                type="button"
                onClick={() => setTab(tb.key)}
                className={cn(
                  "inline-flex items-center gap-1.5 px-3 py-1 text-xs font-semibold rounded-full transition-colors",
                  active
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-muted-foreground hover:text-foreground",
                )}
              >
                <Icon className="size-3" />
                {tb.label}
              </button>
            );
          })}
        </div>
      </div>

      {tab === "basics" && <BasicsTab profile={profile} onChange={setProfile} />}
      {tab === "szabadsag_adatok" && <SzabadsagAdatokTab profile={profile} onChange={setProfile} isHr={can("manage_tenant")} />}
      {tab === "contacts" && <ContactsTab userId={profile.id} tenantId={profile.tenant_id} />}
      {tab === "employment" && <EmploymentTab userId={profile.id} tenantId={profile.tenant_id} isHr={can("manage_tenant")} />}
      {tab === "munkaido" && (
        <MunkaidoCsoport
          userId={profile.id}
          tenantId={profile.tenant_id ?? ""}
          name={profile.teljes_nev}
        />
      )}
      {tab === "overtime" && (
        <OvertimeTab userId={profile.id} tenantId={profile.tenant_id} isHr={can("manage_tenant")} />
      )}
      {tab === "external_hours" && <ExternalHoursTab userId={profile.id} tenantId={profile.tenant_id} />}
      {tab === "napi_pref" && <DailyPreferencesTab userId={profile.id} tenantId={profile.tenant_id} />}
      {tab === "paros" && <PairedShiftsTab userId={profile.id} tenantId={profile.tenant_id} />}
      {tab === "duty_avail" && <DutyAvailabilityTab userId={profile.id} tenantId={profile.tenant_id} />}
      {tab === "preferences" && <PreferencesTab userId={profile.id} tenantId={profile.tenant_id} />}
      {tab === "notifications" && <NotificationSettings userId={profile.id} />}
      {tab === "roles" && <RolesTab userId={profile.id} tenantId={profile.tenant_id} canEdit={can("manage_roles")} />}
      {tab === "skills" && (
        <SkillsTab userId={profile.id} tenantId={profile.tenant_id} canEditOthers={can("manage_training")} />
      )}
      {tab === "certs" && <CertsTab userId={profile.id} tenantId={profile.tenant_id} />}
      {tab === "trainings" && <TrainingsTab userId={profile.id} tenantId={profile.tenant_id} />}
      {tab === "beavatkozasok" && (
        <BeavatkozasokTab userId={profile.id} tenantId={profile.tenant_id} />
      )}
      {tab === "akkreditaciok" && (
        <AkkreditaciokTab userId={profile.id} tenantId={profile.tenant_id} isHr={can("manage_tenant")} />
      )}
      {tab === "unavailability" && (
        <UnavailabilityTab userId={profile.id} tenantId={profile.tenant_id} canApprove={can("manage_schedule") || can("manage_tenant")} />
      )}
      {tab === "constraints" && (
        <ConstraintsTab userId={profile.id} tenantId={profile.tenant_id} isHr={can("manage_tenant")} />
      )}
      {tab === "network" && (
        <PeerLinksTab userId={profile.id} tenantId={profile.tenant_id} isHr={can("manage_tenant")} />
      )}
      {tab === "elozmenyek" && (
        <SchedulingActivityFeed
          userId={profile.id}
          tableNames={["profile_unavailability", "profile_constraints", "profile_peer_links"]}
        />
      )}
    </div>
  );
}

// ============================================================
// Munkaidő-csoport: keret + illetmény + snapshotok + mérleg
// ============================================================
function MunkaidoCsoport({ userId, tenantId, name }: { userId: string; tenantId: string; name: string }) {
  const [activeOrakeret, setActiveOrakeret] = useState<number | null>(null);
  const [preloadInput, setPreloadInput] = useState<Record<string, unknown> | null>(null);
  return (
    <div className="space-y-6">
      <EusztvWidget userId={userId} />
      <WorkTimeFrameEditor userId={userId} tenantId={tenantId} onActiveFrameChange={setActiveOrakeret} />
      <IlletmenyReport
        userId={userId}
        tenantId={tenantId}
        name={name}
        externalOrakeret={activeOrakeret}
        preloadInput={preloadInput}
      />
      <IlletmenySnapshots userId={userId} name={name} onLoad={setPreloadInput} />
      <MunkaidoMerlegWidget />
    </div>
  );
}

// ============================================================
// Basics
// ============================================================
function BasicsTab({
  profile,
  onChange,
}: {
  profile: Profile;
  onChange: (p: Profile) => void;
}) {
  const { t } = useTranslation();
  const [nev, setNev] = useState(profile.teljes_nev);
  const [becenev, setBecenev] = useState(profile.becenev ?? "");
  const [tipus, setTipus] = useState(profile.foglalkozas_tipus);
  const [szuletesi, setSzuletesi] = useState(profile.szuletesi_datum ?? "");
  const [nem, setNem] = useState<Profile["nem"]>(profile.nem ?? null);
  const [bemutatkozas, setBemutatkozas] = useState(profile.bemutatkozas ?? "");
  const [publikus, setPublikus] = useState(profile.bemutatkozas_publikus);
  const [saving, setSaving] = useState(false);

  const eletkor = useMemo(() => {
    if (!szuletesi) return null;
    const d = new Date(szuletesi);
    if (Number.isNaN(d.getTime())) return null;
    const now = new Date();
    let age = now.getFullYear() - d.getFullYear();
    const m = now.getMonth() - d.getMonth();
    if (m < 0 || (m === 0 && now.getDate() < d.getDate())) age--;
    return age;
  }, [szuletesi]);

  async function save() {
    if (nev.trim().length === 0) {
      toast.error("A teljes név nem lehet üres.");
      return;
    }
    if (bemutatkozas.length > 2000) {
      toast.error("A bemutatkozás max 2000 karakter.");
      return;
    }
    setSaving(true);
    const patch = {
      teljes_nev: nev.trim(),
      becenev: becenev.trim() || null,
      foglalkozas_tipus: tipus,
      szuletesi_datum: szuletesi || null,
      nem,
      bemutatkozas: bemutatkozas.trim() || null,
      bemutatkozas_publikus: publikus,
    };
    const { error } = await supabase.from("profiles").update(patch).eq("id", profile.id);
    setSaving(false);
    if (error) {
      toast.error(humanizeError(error, t));
      return;
    }
    onChange({ ...profile, ...patch });
    toast.success("Mentve");
  }

  return (
    <div className="rounded-lg border border-border bg-card p-6 space-y-4 max-w-2xl">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Field label="Teljes név *">
          <input
            value={nev}
            onChange={(e) => setNev(e.target.value.slice(0, 200))}
            className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
          />
        </Field>
        <Field label="Becenév / hívónév">
          <input
            value={becenev}
            onChange={(e) => setBecenev(e.target.value.slice(0, 60))}
            placeholder="Rövid név a beosztási rácsra"
            className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
          />
        </Field>
        <Field label="Foglalkozás">
          <select
            value={tipus}
            onChange={(e) => setTipus(e.target.value as Profile["foglalkozas_tipus"])}
            className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
          >
            <option value="orvos">Orvos</option>
            <option value="szakdolgozo">Szakdolgozó / szülésznő / ápoló</option>
            <option value="egyeb">Egyéb</option>
          </select>
        </Field>
        <Field label={`Születési dátum${eletkor !== null ? ` · ${eletkor} év` : ""}`}>
          <input
            type="date"
            value={szuletesi}
            onChange={(e) => setSzuletesi(e.target.value)}
            className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
          />
        </Field>
        <Field label="Nem">
          <select
            value={nem ?? ""}
            onChange={(e) => setNem((e.target.value || null) as Profile["nem"])}
            className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
          >
            <option value="">—</option>
            <option value="ferfi">Férfi</option>
            <option value="no">Nő</option>
            <option value="egyeb">Egyéb</option>
            <option value="nem_nyilatkozik">Nem nyilatkozik</option>
          </select>
        </Field>
      </div>

      <div>
        <Field label={`Bemutatkozás (${bemutatkozas.length}/2000)`}>
          <textarea
            value={bemutatkozas}
            onChange={(e) => setBemutatkozas(e.target.value.slice(0, 2000))}
            rows={5}
            placeholder="Pár mondat a szakmai irányról, érdeklődésről…"
            className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm font-mono"
          />
        </Field>
        <label className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
          <input
            type="checkbox"
            checked={publikus}
            onChange={(e) => setPublikus(e.target.checked)}
            className="size-3.5"
          />
          Megjelenhet a páciens-felületen
        </label>
      </div>

      <button
        type="button"
        onClick={save}
        disabled={saving}
        className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90 disabled:opacity-50"
      >
        {saving ? <Loader2 className="size-3.5 animate-spin" /> : <Save className="size-3.5" />}
        Mentés
      </button>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="text-[10px] font-mono uppercase text-muted-foreground tracking-wider">
        {label}
      </label>
      <div className="mt-1">{children}</div>
    </div>
  );
}

// ============================================================
// Contacts
// ============================================================
const CONTACT_TIPUSOK: Array<{ value: Contact["tipus"]; label: string }> = [
  { value: "telefon", label: "Telefon" },
  { value: "mobil", label: "Mobil" },
  { value: "email", label: "E-mail" },
  { value: "signal", label: "Signal" },
  { value: "whatsapp", label: "WhatsApp" },
  { value: "telegram", label: "Telegram" },
  { value: "veszhelyzeti_hozzatartozo", label: "Vészhelyzeti hozzátartozó" },
  { value: "egyeb", label: "Egyéb" },
];

function ContactsTab({ userId, tenantId }: { userId: string; tenantId: string | null }) {
  const { t } = useTranslation();
  const [rows, setRows] = useState<Contact[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const [draft, setDraft] = useState<{
    tipus: Contact["tipus"];
    cimke: string;
    ertek: string;
  }>({ tipus: "mobil", cimke: "", ertek: "" });

  async function load() {
    setLoading(true);
    const { data } = await supabase
      .from("profile_contacts")
      .select("*")
      .eq("user_id", userId)
      .order("sorrend")
      .order("created_at");
    setRows((data ?? []) as Contact[]);
    setLoading(false);
  }
  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId]);

  async function add() {
    if (draft.ertek.trim().length < 1) {
      toast.error("Adjon meg értéket.");
      return;
    }
    if (draft.ertek.length > 255) {
      toast.error("Max 255 karakter.");
      return;
    }
    if (draft.tipus === "email" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(draft.ertek.trim())) {
      toast.error("Érvénytelen e-mail formátum.");
      return;
    }
    setBusy("add");
    const { data, error } = await supabase
      .from("profile_contacts")
      .insert({
        user_id: userId,
        tenant_id: tenantId,
        tipus: draft.tipus,
        cimke: draft.cimke.trim() || null,
        ertek: draft.ertek.trim(),
        sorrend: rows.length,
      })
      .select("*")
      .maybeSingle();
    setBusy(null);
    if (error) {
      toast.error(humanizeError(error, t));
      return;
    }
    if (data) {
      setRows((p) => [...p, data as Contact]);
      setDraft({ tipus: "mobil", cimke: "", ertek: "" });
      toast.success("Kapcsolat hozzáadva");
    }
  }

  async function patch(id: string, fields: Partial<Contact>) {
    setBusy(id);
    const { error } = await supabase.from("profile_contacts").update(fields).eq("id", id);
    setBusy(null);
    if (error) {
      toast.error(humanizeError(error, t));
      return;
    }
    setRows((p) => p.map((r) => (r.id === id ? { ...r, ...fields } : r)));
  }

  async function remove(id: string) {
    setBusy(id);
    const { error } = await supabase.from("profile_contacts").delete().eq("id", id);
    setBusy(null);
    if (error) {
      toast.error(humanizeError(error, t));
      return;
    }
    setRows((p) => p.filter((r) => r.id !== id));
    toast.success("Törölve");
  }

  async function makePrimary(id: string) {
    // unset others first (client-side optimistic)
    const others = rows.filter((r) => r.id !== id && r.is_primary);
    for (const o of others) await patch(o.id, { is_primary: false });
    await patch(id, { is_primary: true });
  }

  if (loading) return <Loading />;

  return (
    <div className="space-y-4 max-w-3xl">
      <div className="rounded-lg border border-dashed border-border bg-card p-4 space-y-3">
        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Új kapcsolat
        </div>
        <div className="flex gap-2 flex-wrap items-end">
          <Field label="Típus">
            <select
              value={draft.tipus}
              onChange={(e) => setDraft({ ...draft, tipus: e.target.value as Contact["tipus"] })}
              className="px-3 py-2 rounded-md border border-input bg-background text-sm"
            >
              {CONTACT_TIPUSOK.map((c) => (
                <option key={c.value} value={c.value}>
                  {c.label}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Címke (opc.)">
            <input
              value={draft.cimke}
              onChange={(e) => setDraft({ ...draft, cimke: e.target.value.slice(0, 60) })}
              placeholder="munkahelyi, magán…"
              className="px-3 py-2 rounded-md border border-input bg-background text-sm"
            />
          </Field>
          <Field label="Érték">
            <input
              value={draft.ertek}
              onChange={(e) => setDraft({ ...draft, ertek: e.target.value.slice(0, 255) })}
              placeholder="+36 30 …"
              className="px-3 py-2 rounded-md border border-input bg-background text-sm min-w-[240px]"
            />
          </Field>
          <button
            type="button"
            onClick={add}
            disabled={busy === "add"}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90 disabled:opacity-50"
          >
            {busy === "add" ? <Loader2 className="size-3.5 animate-spin" /> : <Plus className="size-3.5" />}
            Hozzáadás
          </button>
        </div>
      </div>

      {rows.length === 0 ? (
        <div className="p-6 rounded-lg border border-dashed border-border text-sm text-muted-foreground text-center">
          Még nincs kapcsolat rögzítve.
        </div>
      ) : (
        <div className="rounded-lg border border-border bg-card divide-y divide-border">
          {rows.map((r) => {
            const typeLabel = CONTACT_TIPUSOK.find((c) => c.value === r.tipus)?.label ?? r.tipus;
            const b = busy === r.id;
            return (
              <div key={r.id} className="px-4 py-3 flex items-center gap-3 flex-wrap">
                <button
                  type="button"
                  onClick={() => makePrimary(r.id)}
                  disabled={b}
                  title={r.is_primary ? "Elsődleges" : "Tedd elsődlegessé"}
                  className={cn(
                    "size-7 rounded inline-flex items-center justify-center",
                    r.is_primary ? "text-warning" : "text-muted-foreground hover:text-foreground",
                  )}
                >
                  {r.is_primary ? <Star className="size-4 fill-current" /> : <StarOff className="size-4" />}
                </button>
                <div className="flex-1 min-w-[200px]">
                  <div className="text-sm font-semibold">
                    {typeLabel}
                    {r.cimke && (
                      <span className="ml-2 text-[10px] font-mono px-1.5 py-0.5 rounded bg-secondary text-muted-foreground">
                        {r.cimke}
                      </span>
                    )}
                  </div>
                  <div className="text-xs font-mono text-muted-foreground">{r.ertek}</div>
                </div>
                <label className="text-[11px] flex items-center gap-1.5 text-muted-foreground">
                  <input
                    type="checkbox"
                    checked={r.ertesites_engedelyezve}
                    disabled={b}
                    onChange={(e) => patch(r.id, { ertesites_engedelyezve: e.target.checked })}
                  />
                  értesít
                </label>
                <label className="text-[11px] flex items-center gap-1.5 text-muted-foreground">
                  <input
                    type="checkbox"
                    checked={r.csak_vesz_eseten}
                    disabled={b}
                    onChange={(e) => patch(r.id, { csak_vesz_eseten: e.target.checked })}
                  />
                  csak vész esetén
                </label>
                <button
                  type="button"
                  onClick={() => remove(r.id)}
                  disabled={b}
                  className="p-1.5 rounded text-destructive hover:bg-destructive/10 disabled:opacity-50"
                  aria-label="Törlés"
                >
                  {b ? <Loader2 className="size-3.5 animate-spin" /> : <Trash2 className="size-3.5" />}
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ============================================================
// Preferences
// ============================================================
const MUSAK_LABELS: Record<Preferences["preferalt_musakok"][number], string> = {
  nappal: "Nappal",
  delutan: "Délután",
  ejszaka: "Éjszaka",
  huszonnegy: "24 órás",
};

const NAP_LABELS = ["V", "H", "K", "Sze", "Cs", "P", "Szo"];

const PREF_STATUS_META: Record<PrefStatus, { label: string; cls: string }> = {
  tervezett: { label: "Tervezett", cls: "bg-secondary text-muted-foreground border-border" },
  jovahagyasra_var: { label: "Jóváhagyásra vár", cls: "bg-amber-500/15 text-amber-700 border-amber-500/30 dark:text-amber-300" },
  jovahagyott: { label: "Jóváhagyva", cls: "bg-emerald-500/15 text-emerald-700 border-emerald-500/30 dark:text-emerald-300" },
  elutasitott: { label: "Elutasítva", cls: "bg-destructive/15 text-destructive border-destructive/30" },
};

function emptyPref(userId: string, tenantId: string | null): Preferences {
  return {
    user_id: userId,
    tenant_id: tenantId,
    heti_max_ora: null,
    havi_max_ugyelet: null,
    preferalt_musakok: [],
    tiltott_napok: [],
    kozossegi_napok: [],
    preferalt_feladat_korok: [],
    ugyelet_utan_pihenonap: true,
    ugyelet_utan_min_ora: 24,
    egymas_utani_max_ugyelet: 1,
    last_minute_elerheto: false,
    last_minute_orahatar: null,
    utazasi_perc_max: null,
    nyelvek: [],
    megjegyzes: null,
    status: "tervezett",
    submitted_at: null,
    jovahagyo_id: null,
    jovahagyas_at: null,
    jovahagyas_indok: null,
    jovahagyas_feltetel: null,
  };
}

function PreferencesTab({ userId, tenantId }: { userId: string; tenantId: string | null }) {
  const { t } = useTranslation();
  const { user } = useAuth();
  const { can } = usePermissions();
  const [pref, setPref] = useState<Preferences | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [feladatKorok, setFeladatKorok] = useState<FeladatKor[]>([]);
  const [newDay, setNewDay] = useState("");
  const [newKorNev, setNewKorNev] = useState("");
  const [rejectReason, setRejectReason] = useState("");
  const [approveCondition, setApproveCondition] = useState("");

  const isOwn = user?.id === userId;
  const canApprove = (can("manage_schedule") || can("manage_tenant")) && !isOwn;
  const locked = pref?.status === "jovahagyasra_var" || pref?.status === "jovahagyott";

  useEffect(() => {
    (async () => {
      setLoading(true);
      const [prefRes, korokRes] = await Promise.all([
        supabase.from("profile_preferences").select("*").eq("user_id", userId).maybeSingle(),
        supabase
          .from("feladat_korok")
          .select("id, kulcs, nev, sorrend, rendszerszintu, aktiv")
          .eq("aktiv", true)
          .order("sorrend"),
      ]);
      setPref(((prefRes.data as Preferences | null) ?? emptyPref(userId, tenantId)));
      setFeladatKorok((korokRes.data ?? []) as FeladatKor[]);
      setLoading(false);
    })();
  }, [userId, tenantId]);

  function set<K extends keyof Preferences>(k: K, v: Preferences[K]) {
    if (!pref) return;
    setPref({ ...pref, [k]: v });
  }
  function toggleMusak(m: Preferences["preferalt_musakok"][number]) {
    if (!pref) return;
    const has = pref.preferalt_musakok.includes(m);
    set("preferalt_musakok", has ? pref.preferalt_musakok.filter((x) => x !== m) : [...pref.preferalt_musakok, m]);
  }
  function toggleNap(d: number) {
    if (!pref) return;
    const has = pref.tiltott_napok.includes(d);
    set("tiltott_napok", has ? pref.tiltott_napok.filter((x) => x !== d) : [...pref.tiltott_napok, d]);
  }
  function toggleKor(kulcs: string) {
    if (!pref) return;
    const has = pref.preferalt_feladat_korok.includes(kulcs);
    set(
      "preferalt_feladat_korok",
      has ? pref.preferalt_feladat_korok.filter((x) => x !== kulcs) : [...pref.preferalt_feladat_korok, kulcs],
    );
  }
  function addKozossegiNap() {
    if (!pref || !newDay) return;
    if (pref.kozossegi_napok.includes(newDay)) {
      setNewDay("");
      return;
    }
    set("kozossegi_napok", [...pref.kozossegi_napok, newDay].sort());
    setNewDay("");
  }
  function removeKozossegiNap(d: string) {
    if (!pref) return;
    set("kozossegi_napok", pref.kozossegi_napok.filter((x) => x !== d));
  }
  async function addCustomKor() {
    const nev = newKorNev.trim();
    if (!nev || !tenantId) return;
    const kulcs = "u_" + nev
      .toLowerCase()
      .replace(/[áàä]/g, "a").replace(/[éè]/g, "e").replace(/[íì]/g, "i")
      .replace(/[óòö]/g, "o").replace(/[őô]/g, "o").replace(/[úùü]/g, "u").replace(/[űû]/g, "u")
      .replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "").slice(0, 40);
    if (!kulcs || kulcs === "u_") return;
    const { data, error } = await supabase
      .from("feladat_korok")
      .insert({ tenant_id: tenantId, kulcs, nev, sorrend: 500, rendszerszintu: false, aktiv: true })
      .select("id, kulcs, nev, sorrend, rendszerszintu, aktiv")
      .single();
    if (error) {
      toast.error(humanizeError(error, t));
      return;
    }
    setFeladatKorok((prev) => [...prev, data as FeladatKor].sort((a, b) => a.sorrend - b.sorrend));
    toggleKor((data as FeladatKor).kulcs);
    setNewKorNev("");
    toast.success("Feladatkör hozzáadva");
  }

  async function save(nextStatus?: PrefStatus) {
    if (!pref) return;
    if (pref.heti_max_ora !== null && (pref.heti_max_ora < 0 || pref.heti_max_ora > 168)) {
      toast.error("Heti óra 0–168 között.");
      return;
    }
    const payload: Preferences = nextStatus ? { ...pref, status: nextStatus } : pref;
    setSaving(true);
    const { error } = await supabase
      .from("profile_preferences")
      .upsert(payload, { onConflict: "user_id" });
    setSaving(false);
    if (error) {
      toast.error(humanizeError(error, t));
      return;
    }
    setPref(payload);
    toast.success(nextStatus === "jovahagyasra_var" ? "Beküldve jóváhagyásra" : "Preferenciák mentve");
  }

  async function submitForApproval() {
    if (!pref) return;
    setSubmitting(true);
    await save("jovahagyasra_var");
    setSubmitting(false);
  }

  async function withdraw() {
    if (!pref) return;
    const { error } = await supabase
      .from("profile_preferences")
      .update({ status: "tervezett" })
      .eq("user_id", userId);
    if (error) {
      toast.error(humanizeError(error, t));
      return;
    }
    setPref({ ...pref, status: "tervezett", submitted_at: null });
    toast.success("Visszavonva");
  }

  async function approve() {
    if (!pref) return;
    const { error } = await supabase
      .from("profile_preferences")
      .update({
        status: "jovahagyott",
        jovahagyas_feltetel: approveCondition.trim() || null,
        jovahagyas_indok: null,
      })
      .eq("user_id", userId);
    if (error) {
      toast.error(humanizeError(error, t));
      return;
    }
    setApproveCondition("");
    toast.success("Jóváhagyva");
    const { data } = await supabase.from("profile_preferences").select("*").eq("user_id", userId).maybeSingle();
    if (data) setPref(data as Preferences);
  }

  async function reject() {
    if (!pref) return;
    if (!rejectReason.trim()) {
      toast.error("Elutasításhoz kötelező az indoklás.");
      return;
    }
    const { error } = await supabase
      .from("profile_preferences")
      .update({ status: "elutasitott", jovahagyas_indok: rejectReason.trim() })
      .eq("user_id", userId);
    if (error) {
      toast.error(humanizeError(error, t));
      return;
    }
    setRejectReason("");
    toast.success("Elutasítva");
    const { data } = await supabase.from("profile_preferences").select("*").eq("user_id", userId).maybeSingle();
    if (data) setPref(data as Preferences);
  }

  if (loading || !pref) return <Loading />;

  const meta = PREF_STATUS_META[pref.status];

  return (
    <div className="rounded-lg border border-border bg-card p-6 space-y-6 max-w-3xl">
      {/* Status bar */}
      <div className="flex items-center justify-between flex-wrap gap-3 -mt-2">
        <div className="flex items-center gap-2">
          <span className={cn("inline-flex items-center px-2.5 py-1 rounded-full text-[11px] font-semibold border", meta.cls)}>
            {meta.label}
          </span>
          {pref.submitted_at && (
            <span className="text-[11px] font-mono text-muted-foreground">
              Beküldve: {new Date(pref.submitted_at).toLocaleString("hu-HU")}
            </span>
          )}
        </div>
        {pref.status === "jovahagyott" && pref.jovahagyas_feltetel && (
          <div className="text-[11px] text-emerald-700 dark:text-emerald-300 max-w-md">
            <strong>Feltétel:</strong> {pref.jovahagyas_feltetel}
          </div>
        )}
        {pref.status === "elutasitott" && pref.jovahagyas_indok && (
          <div className="text-[11px] text-destructive max-w-md">
            <strong>Indok:</strong> {pref.jovahagyas_indok}
          </div>
        )}
      </div>

      {locked && (
        <div className="rounded-md border border-amber-500/30 bg-amber-500/5 px-3 py-2 text-xs text-amber-800 dark:text-amber-200">
          A preferenciák zárolva vannak{pref.status === "jovahagyasra_var" ? " amíg vezetői jóváhagyásra várnak." : ", mert már jóváhagyásra kerültek. Visszavonáshoz vond vissza a beküldést vagy kérj módosítást a vezetőtől."}
        </div>
      )}

      <fieldset disabled={locked && !canApprove} className="space-y-6 disabled:opacity-60">
        <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Field label="Heti max óra">
            <input
              type="number" min={0} max={168}
              value={pref.heti_max_ora ?? ""}
              onChange={(e) => set("heti_max_ora", e.target.value === "" ? null : Number(e.target.value))}
              className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
            />
          </Field>
          <Field label="Havi max ügyelet">
            <input
              type="number" min={0} max={31}
              value={pref.havi_max_ugyelet ?? ""}
              onChange={(e) => set("havi_max_ugyelet", e.target.value === "" ? null : Number(e.target.value))}
              className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
            />
          </Field>
          <Field label="Egymás utáni max ügyelet">
            <input
              type="number" min={0} max={10}
              value={pref.egymas_utani_max_ugyelet}
              onChange={(e) => set("egymas_utani_max_ugyelet", Number(e.target.value))}
              className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
            />
          </Field>
        </section>

        <section>
          <div className="text-[10px] font-mono uppercase text-muted-foreground tracking-wider mb-2">
            Preferált műszakok
          </div>
          <div className="flex gap-2 flex-wrap">
            {(Object.keys(MUSAK_LABELS) as Array<keyof typeof MUSAK_LABELS>).map((m) => {
              const active = pref.preferalt_musakok.includes(m);
              return (
                <button
                  key={m} type="button" onClick={() => toggleMusak(m)}
                  className={cn(
                    "px-3 py-1.5 rounded-full text-xs font-semibold border transition-colors",
                    active ? "bg-primary text-primary-foreground border-primary"
                           : "bg-background text-muted-foreground border-border hover:text-foreground",
                  )}
                >
                  {MUSAK_LABELS[m]}
                </button>
              );
            })}
          </div>
        </section>

        <section>
          <div className="text-[10px] font-mono uppercase text-muted-foreground tracking-wider mb-2">
            Preferált feladatkörök
          </div>
          <div className="flex gap-2 flex-wrap mb-3">
            {feladatKorok.map((k) => {
              const active = pref.preferalt_feladat_korok.includes(k.kulcs);
              return (
                <button
                  key={k.id} type="button" onClick={() => toggleKor(k.kulcs)}
                  className={cn(
                    "px-3 py-1.5 rounded-full text-xs font-semibold border transition-colors",
                    active ? "bg-primary text-primary-foreground border-primary"
                           : "bg-background text-muted-foreground border-border hover:text-foreground",
                  )}
                  title={k.rendszerszintu ? "Rendszer-szintű" : "Egyéni"}
                >
                  {k.nev}
                </button>
              );
            })}
          </div>
          <div className="flex gap-2 items-center">
            <input
              value={newKorNev}
              onChange={(e) => setNewKorNev(e.target.value)}
              placeholder="Új feladatkör neve…"
              className="px-3 py-1.5 rounded-md border border-input bg-background text-xs flex-1 max-w-xs"
            />
            <button
              type="button" onClick={addCustomKor}
              disabled={!newKorNev.trim()}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md bg-secondary text-foreground text-xs font-semibold hover:bg-secondary/80 disabled:opacity-40"
            >
              <Plus className="size-3" /> Hozzáadás
            </button>
          </div>
        </section>

        <section>
          <div className="text-[10px] font-mono uppercase text-muted-foreground tracking-wider mb-2">
            Tiltott napok (ismétlődő)
          </div>
          <div className="flex gap-2">
            {NAP_LABELS.map((lbl, idx) => {
              const active = pref.tiltott_napok.includes(idx);
              return (
                <button
                  key={idx} type="button" onClick={() => toggleNap(idx)}
                  className={cn(
                    "size-9 rounded-md text-xs font-semibold border",
                    active ? "bg-destructive/15 text-destructive border-destructive/30"
                           : "bg-background text-muted-foreground border-border",
                  )}
                >
                  {lbl}
                </button>
              );
            })}
          </div>
        </section>

        <section>
          <div className="text-[10px] font-mono uppercase text-muted-foreground tracking-wider mb-2">
            Közösségi napjaim
          </div>
          <div className="flex gap-2 items-center mb-3">
            <input
              type="date"
              value={newDay}
              onChange={(e) => setNewDay(e.target.value)}
              className="px-3 py-1.5 rounded-md border border-input bg-background text-xs"
            />
            <button
              type="button" onClick={addKozossegiNap}
              disabled={!newDay}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md bg-secondary text-foreground text-xs font-semibold hover:bg-secondary/80 disabled:opacity-40"
            >
              <Plus className="size-3" /> Hozzáadás
            </button>
          </div>
          {pref.kozossegi_napok.length === 0 ? (
            <div className="text-xs text-muted-foreground italic">Nincs megadva közösségi nap.</div>
          ) : (
            <div className="flex gap-1.5 flex-wrap">
              {pref.kozossegi_napok.map((d) => (
                <span
                  key={d}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-primary/10 text-primary text-[11px] font-mono"
                >
                  {d}
                  <button
                    type="button" onClick={() => removeKozossegiNap(d)}
                    className="hover:text-destructive"
                    aria-label="Eltávolítás"
                  >
                    <X className="size-3" />
                  </button>
                </span>
              ))}
            </div>
          )}
        </section>

        <section className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={pref.ugyelet_utan_pihenonap}
              onChange={(e) => set("ugyelet_utan_pihenonap", e.target.checked)} />
            Ügyelet után kötelező pihenőnap
          </label>
          <Field label="Ügyelet után min. óra">
            <input type="number" min={0} max={96} value={pref.ugyelet_utan_min_ora}
              onChange={(e) => set("ugyelet_utan_min_ora", Number(e.target.value))}
              className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm" />
          </Field>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={pref.last_minute_elerheto}
              onChange={(e) => set("last_minute_elerheto", e.target.checked)} />
            Last-minute helyettesítésre elérhető
          </label>
          <Field label="Last-minute óra-határ">
            <input type="number" min={0} value={pref.last_minute_orahatar ?? ""}
              onChange={(e) => set("last_minute_orahatar", e.target.value === "" ? null : Number(e.target.value))}
              placeholder="hány órán belül vállalja"
              className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm" />
          </Field>
          <Field label="Max utazás (perc)">
            <input type="number" min={0} value={pref.utazasi_perc_max ?? ""}
              onChange={(e) => set("utazasi_perc_max", e.target.value === "" ? null : Number(e.target.value))}
              className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm" />
          </Field>
          <Field label="Nyelvek (vesszővel)">
            <input value={pref.nyelvek.join(", ")}
              onChange={(e) => set("nyelvek", e.target.value.split(",").map((s) => s.trim()).filter(Boolean))}
              placeholder="hu, en, de"
              className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm" />
          </Field>
        </section>

        <Field label="Megjegyzés">
          <textarea value={pref.megjegyzes ?? ""}
            onChange={(e) => set("megjegyzes", e.target.value.slice(0, 1000))}
            rows={3}
            className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm" />
        </Field>
      </fieldset>

      {/* Action bar */}
      <div className="flex items-center gap-2 flex-wrap pt-2 border-t border-border">
        {isOwn && !locked && (
          <>
            <button type="button" onClick={() => save()} disabled={saving}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md bg-secondary text-foreground text-xs font-semibold hover:bg-secondary/80 disabled:opacity-50">
              {saving ? <Loader2 className="size-3.5 animate-spin" /> : <Save className="size-3.5" />}
              Piszkozat mentése
            </button>
            <button type="button" onClick={submitForApproval} disabled={submitting || saving}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90 disabled:opacity-50">
              {submitting ? <Loader2 className="size-3.5 animate-spin" /> : <Check className="size-3.5" />}
              Beküldés jóváhagyásra
            </button>
          </>
        )}
        {isOwn && pref.status === "jovahagyasra_var" && (
          <button type="button" onClick={withdraw}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md bg-secondary text-foreground text-xs font-semibold hover:bg-secondary/80">
            <X className="size-3.5" /> Beküldés visszavonása
          </button>
        )}
        {isOwn && pref.status === "elutasitott" && (
          <button type="button" onClick={() => save("tervezett")}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md bg-secondary text-foreground text-xs font-semibold hover:bg-secondary/80">
            Újra szerkesztés
          </button>
        )}
      </div>

      {/* Manager approval panel */}
      {canApprove && pref.status === "jovahagyasra_var" && (
        <div className="rounded-md border border-amber-500/30 bg-amber-500/5 p-4 space-y-3">
          <div className="text-xs font-semibold text-amber-800 dark:text-amber-200 flex items-center gap-2">
            <ShieldCheck className="size-4" /> Vezetői jóváhagyás
          </div>
          <Field label='Jóváhagyási feltétel (opcionális — pl. „csak Q1-re érvényes”)'>
            <input value={approveCondition} onChange={(e) => setApproveCondition(e.target.value)}
              placeholder="Feltétel a jóváhagyáshoz"
              className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm" />
          </Field>
          <Field label="Elutasítás indoka (kötelező elutasításhoz)">
            <textarea value={rejectReason} onChange={(e) => setRejectReason(e.target.value)} rows={2}
              className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm" />
          </Field>
          <div className="flex gap-2">
            <button type="button" onClick={approve}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700">
              <Check className="size-3.5" /> Jóváhagyás
            </button>
            <button type="button" onClick={reject} disabled={!rejectReason.trim()}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md bg-destructive text-destructive-foreground text-xs font-semibold hover:opacity-90 disabled:opacity-50">
              <X className="size-3.5" /> Elutasítás
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================================
// Roles (admin-editable)
// ============================================================
type RoleCatalogRow = { id: string; kulcs: string; megnevezes: string; kategoria: string; sorrend: number };
type SiteRow = { id: string; nev: string };
type OrgUnitRow = { id: string; nev: string; site_id: string };

function RolesTab({ userId, tenantId, canEdit }: { userId: string; tenantId: string | null; canEdit: boolean }) {
  const { t } = useTranslation();
  const [rows, setRows] = useState<UserRoleRow[]>([]);
  const [catalog, setCatalog] = useState<RoleCatalogRow[]>([]);
  const [sites, setSites] = useState<SiteRow[]>([]);
  const [orgUnits, setOrgUnits] = useState<OrgUnitRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [roleId, setRoleId] = useState("");
  const [siteId, setSiteId] = useState("");
  const [orgUnitId, setOrgUnitId] = useState("");
  const [reason, setReason] = useState("");

  async function reload() {
    const [{ data: ur }, { data: cat }, { data: st }, { data: ou }] = await Promise.all([
      supabase
        .from("user_roles")
        .select("id, role_id, site_id, org_unit_id, roles(kulcs, megnevezes, kategoria), sites(nev), org_units(nev)")
        .eq("user_id", userId),
      supabase.from("roles").select("id,kulcs,megnevezes,kategoria,sorrend").order("sorrend"),
      supabase.from("sites").select("id,nev").order("nev"),
      supabase.from("org_units").select("id,nev,site_id").order("nev"),
    ]);
    setRows((ur ?? []) as unknown as UserRoleRow[]);
    setCatalog((cat ?? []) as RoleCatalogRow[]);
    setSites((st ?? []) as SiteRow[]);
    setOrgUnits((ou ?? []) as OrgUnitRow[]);
    setLoading(false);
  }

  useEffect(() => {
    void reload();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId]);

  async function addRole() {
    if (!roleId || !tenantId) return;
    setBusy(true);
    const { data: inserted, error } = await supabase
      .from("user_roles")
      .insert({
        tenant_id: tenantId,
        user_id: userId,
        role_id: roleId,
        site_id: siteId || null,
        org_unit_id: orgUnitId || null,
      })
      .select("id")
      .maybeSingle();
    if (error) {
      setBusy(false);
      toast.error(humanizeError(error, t, { perm: "manage_roles" }));
      return;
    }
    await applyReason("user_roles", inserted?.id, reason);
    setRoleId("");
    setSiteId("");
    setOrgUnitId("");
    setReason("");
    await reload();
    setBusy(false);
    toast.success("Szerepkör hozzáadva.");
  }

  async function removeRole(id: string) {
    setBusy(true);
    const { error } = await supabase.from("user_roles").delete().eq("id", id);
    if (error) {
      setBusy(false);
      toast.error(humanizeError(error, t, { perm: "manage_roles" }));
      return;
    }
    await applyReason("user_roles", id, reason);
    setReason("");
    await reload();
    setBusy(false);
    toast.success("Szerepkör eltávolítva.");
  }

  if (loading) return <Loading />;

  const groups = catalog.reduce<Record<string, RoleCatalogRow[]>>((acc, r) => {
    (acc[r.kategoria] ??= []).push(r);
    return acc;
  }, {});
  const filteredOrgUnits = siteId ? orgUnits.filter((o) => o.site_id === siteId) : orgUnits;

  return (
    <div className="space-y-4">
      {rows.length === 0 ? (
        <div className="p-6 rounded-lg border border-dashed border-border text-sm text-muted-foreground text-center">
          Nincs hozzárendelt szerepkör.
        </div>
      ) : (
        <div className="rounded-lg border border-border bg-card divide-y divide-border">
          {rows.map((r) => (
            <div key={r.id} className="px-4 py-3 flex items-center justify-between gap-2">
              <div className="min-w-0">
                <div className="font-semibold text-sm">{r.roles?.megnevezes ?? "?"}</div>
                <div className="text-[11px] font-mono text-muted-foreground">
                  {r.roles?.kulcs} · {r.roles?.kategoria}
                  {r.sites?.nev && <> · {r.sites.nev}</>}
                  {r.org_units?.nev && <> · {r.org_units.nev}</>}
                </div>
              </div>
              {canEdit && (
                <button
                  type="button"
                  onClick={() => removeRole(r.id)}
                  disabled={busy}
                  className="p-1.5 rounded-md text-muted-foreground hover:text-warning hover:bg-warning/10 transition-colors disabled:opacity-30"
                  aria-label="Eltávolítás"
                >
                  <Trash2 className="size-3.5" />
                </button>
              )}
            </div>
          ))}
        </div>
      )}

      {canEdit && (
        <div className="rounded-lg border border-border bg-secondary/30 p-4 space-y-3">
          <div className="text-[10px] font-mono uppercase text-muted-foreground">
            Új szerepkör hozzárendelése
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-2">
            <select
              value={roleId}
              onChange={(e) => setRoleId(e.target.value)}
              className="md:col-span-2 px-3 py-2 bg-card border border-border rounded-lg text-sm"
            >
              <option value="">— Válasszon szerepkört —</option>
              {Object.entries(groups).map(([kat, list]) => (
                <optgroup key={kat} label={kat}>
                  {list.map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.megnevezes}
                    </option>
                  ))}
                </optgroup>
              ))}
            </select>
            <select
              value={siteId}
              onChange={(e) => {
                setSiteId(e.target.value);
                setOrgUnitId("");
              }}
              className="px-3 py-2 bg-card border border-border rounded-lg text-sm"
            >
              <option value="">— Bármely telephely —</option>
              {sites.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.nev}
                </option>
              ))}
            </select>
            <select
              value={orgUnitId}
              onChange={(e) => setOrgUnitId(e.target.value)}
              className="px-3 py-2 bg-card border border-border rounded-lg text-sm"
            >
              <option value="">— Bármely szervezeti egység —</option>
              {filteredOrgUnits.map((o) => (
                <option key={o.id} value={o.id}>
                  {o.nev}
                </option>
              ))}
            </select>
          </div>
          <ReasonInput value={reason} onChange={setReason} />
          <button
            type="button"
            onClick={addRole}
            disabled={busy || !roleId || !tenantId}
            className={cn(
              "inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold uppercase font-mono",
              "bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-40",
            )}
          >
            <Plus className="size-3.5" />
            Hozzáadás
          </button>
        </div>
      )}

      {!canEdit && rows.length > 0 && (
        <div className="text-[11px] font-mono uppercase text-muted-foreground">
          Csak olvasható. Szerepkör-szerkesztéshez „manage_roles" jogosultság szükséges.
        </div>
      )}
    </div>
  );
}

// ============================================================
// Skills
// ============================================================
function SkillsTab({
  userId,
  tenantId,
  canEditOthers,
}: {
  userId: string;
  tenantId: string | null;
  canEditOthers: boolean;
}) {
  const { t } = useTranslation();
  const [skills, setSkills] = useState<Skill[]>([]);
  const [mine, setMine] = useState<ProfileSkill[]>([]);
  const [loading, setLoading] = useState(true);
  const [skillId, setSkillId] = useState("");
  const [szint, setSzint] = useState(1);
  const [lejarat, setLejarat] = useState("");
  const [igazolvaAt, setIgazolvaAt] = useState("");
  const [adding, setAdding] = useState(false);

  async function load() {
    const [{ data: s }, { data: m }] = await Promise.all([
      supabase.from("skills").select("id, nev, kulcs, kategoria").order("nev"),
      supabase
        .from("profile_skills")
        .select("id, skill_id, szint, igazolva_at, lejarat, megjegyzes")
        .eq("user_id", userId),
    ]);
    setSkills((s ?? []) as Skill[]);
    setMine((m ?? []) as ProfileSkill[]);
    setLoading(false);
  }
  useEffect(() => {
    load();
  }, [userId]);

  const byId = useMemo(() => new Map(skills.map((s) => [s.id, s])), [skills]);
  const available = useMemo(() => {
    const usedIds = new Set(mine.map((m) => m.skill_id));
    return skills.filter((s) => !usedIds.has(s.id));
  }, [skills, mine]);

  async function add() {
    if (!skillId || !tenantId) return;
    setAdding(true);
    const { error } = await supabase.from("profile_skills").insert({
      tenant_id: tenantId,
      user_id: userId,
      skill_id: skillId,
      szint,
      igazolva_at: igazolvaAt || null,
      lejarat: lejarat || null,
    });
    setAdding(false);
    if (error) {
      toast.error(humanizeError(error, t, { perm: "manage_training" }));
      return;
    }
    setSkillId("");
    setSzint(1);
    setIgazolvaAt("");
    setLejarat("");
    load();
  }

  async function remove(id: string) {
    if (!window.confirm("Biztosan törli?")) return;
    const { error } = await supabase.from("profile_skills").delete().eq("id", id);
    if (error) {
      toast.error(humanizeError(error, t, { perm: "manage_training" }));
      return;
    }
    load();
  }

  if (loading) return <Loading />;

  return (
    <div className="space-y-4">
      {skills.length === 0 && (
        <div className="p-4 rounded-lg border border-warning/30 bg-warning/5 text-sm">
          Még nincs skill-katalógus. A bérlő-adminisztrátor töltse fel a /kepzes oldalon.
        </div>
      )}
      <div className="rounded-lg border border-border bg-card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-secondary text-[10px] uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="text-left px-3 py-2">Skill</th>
              <th className="text-left px-3 py-2">Szint</th>
              <th className="text-left px-3 py-2">Igazolva</th>
              <th className="text-left px-3 py-2">Lejár</th>
              <th className="px-3 py-2"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {mine.length === 0 ? (
              <tr>
                <td colSpan={5} className="px-3 py-6 text-center text-muted-foreground text-sm">
                  Még nincs felvett skill.
                </td>
              </tr>
            ) : (
              mine.map((m) => {
                const s = byId.get(m.skill_id);
                const status = expiryStatus(m.lejarat);
                return (
                  <tr key={m.id}>
                    <td className="px-3 py-2">
                      <div className="font-semibold">{s?.nev ?? m.skill_id}</div>
                      {s?.kategoria && (
                        <div className="text-[10px] font-mono text-muted-foreground">
                          {s.kategoria}
                        </div>
                      )}
                    </td>
                    <td className="px-3 py-2">
                      <SzintBadge n={m.szint} />
                    </td>
                    <td className="px-3 py-2 text-xs font-mono">{m.igazolva_at ?? "—"}</td>
                    <td className="px-3 py-2 text-xs font-mono">
                      <span className={cn("px-2 py-0.5 rounded", status.cls)}>
                        {m.lejarat ?? "nincs"}
                      </span>
                    </td>
                    <td className="px-3 py-2 text-right">
                      <button
                        type="button"
                        onClick={() => remove(m.id)}
                        className="text-muted-foreground hover:text-destructive p-1"
                      >
                        <Trash2 className="size-3.5" />
                      </button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {(canEditOthers || true) && available.length > 0 && (
        <div className="rounded-lg border border-border bg-card p-4 space-y-3">
          <div className="text-[10px] font-mono uppercase text-muted-foreground tracking-wider">
            Új skill hozzáadása
          </div>
          <div className="grid sm:grid-cols-5 gap-2">
            <select
              value={skillId}
              onChange={(e) => setSkillId(e.target.value)}
              className="sm:col-span-2 px-3 py-2 text-sm rounded-md border border-input bg-background"
            >
              <option value="">— válassz —</option>
              {available.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.nev}
                </option>
              ))}
            </select>
            <select
              value={szint}
              onChange={(e) => setSzint(Number(e.target.value))}
              className="px-3 py-2 text-sm rounded-md border border-input bg-background"
            >
              {[1, 2, 3, 4, 5].map((n) => (
                <option key={n} value={n}>
                  Szint {n}
                </option>
              ))}
            </select>
            <input
              type="date"
              value={igazolvaAt}
              onChange={(e) => setIgazolvaAt(e.target.value)}
              placeholder="igazolva"
              className="px-3 py-2 text-sm rounded-md border border-input bg-background"
            />
            <input
              type="date"
              value={lejarat}
              onChange={(e) => setLejarat(e.target.value)}
              placeholder="lejár"
              className="px-3 py-2 text-sm rounded-md border border-input bg-background"
            />
          </div>
          <button
            type="button"
            onClick={add}
            disabled={adding || !skillId}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md bg-primary text-primary-foreground text-xs font-semibold disabled:opacity-50"
          >
            {adding ? <Loader2 className="size-3.5 animate-spin" /> : <Plus className="size-3.5" />}
            Hozzáadás
          </button>
        </div>
      )}
    </div>
  );
}

function SzintBadge({ n }: { n: number }) {
  return (
    <div className="flex gap-0.5">
      {[1, 2, 3, 4, 5].map((i) => (
        <div
          key={i}
          className={cn("size-2 rounded-full", i <= n ? "bg-primary" : "bg-muted")}
        />
      ))}
    </div>
  );
}

function expiryStatus(lejarat: string | null) {
  if (!lejarat) return { cls: "bg-muted text-muted-foreground" };
  const days = (new Date(lejarat).getTime() - Date.now()) / 86400000;
  if (days < 0) return { cls: "bg-destructive/15 text-destructive font-semibold" };
  if (days < 30) return { cls: "bg-destructive/10 text-destructive" };
  if (days < 60) return { cls: "bg-warning/15 text-warning" };
  return { cls: "bg-success/10 text-success" };
}

// ============================================================
// Certifications
// ============================================================
function CertsTab({ userId, tenantId }: { userId: string; tenantId: string | null }) {
  const { t } = useTranslation();
  const [rows, setRows] = useState<Cert[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({
    nev: "",
    tipus: "oklevel",
    kibocsato: "",
    szam: "",
    kibocsatva: "",
    lejarat: "",
  });
  const [adding, setAdding] = useState(false);

  async function load() {
    const { data } = await supabase
      .from("profile_certifications")
      .select("*")
      .eq("user_id", userId)
      .order("kibocsatva", { ascending: false });
    setRows((data ?? []) as Cert[]);
    setLoading(false);
  }
  useEffect(() => {
    load();
  }, [userId]);

  async function add() {
    if (!form.nev || !tenantId) return;
    setAdding(true);
    const { error } = await supabase.from("profile_certifications").insert({
      tenant_id: tenantId,
      user_id: userId,
      nev: form.nev,
      tipus: form.tipus,
      kibocsato: form.kibocsato || null,
      szam: form.szam || null,
      kibocsatva: form.kibocsatva || null,
      lejarat: form.lejarat || null,
    });
    setAdding(false);
    if (error) {
      toast.error(humanizeError(error, t, { perm: "manage_training" }));
      return;
    }
    setForm({ nev: "", tipus: "oklevel", kibocsato: "", szam: "", kibocsatva: "", lejarat: "" });
    load();
  }
  async function remove(id: string) {
    if (!window.confirm("Biztosan törli?")) return;
    const { error } = await supabase.from("profile_certifications").delete().eq("id", id);
    if (error) {
      toast.error(humanizeError(error, t, { perm: "manage_training" }));
      return;
    }
    load();
  }

  if (loading) return <Loading />;

  return (
    <div className="space-y-4">
      <div className="rounded-lg border border-border bg-card divide-y divide-border">
        {rows.length === 0 ? (
          <div className="p-6 text-center text-sm text-muted-foreground">
            Még nincs feltöltött képzettség.
          </div>
        ) : (
          rows.map((c) => {
            const st = expiryStatus(c.lejarat);
            return (
              <div key={c.id} className="px-4 py-3 flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <div className="font-semibold text-sm">{c.nev}</div>
                  <div className="text-[11px] font-mono text-muted-foreground truncate">
                    {c.tipus}
                    {c.kibocsato && <> · {c.kibocsato}</>}
                    {c.szam && <> · {c.szam}</>}
                  </div>
                </div>
                <div className="flex items-center gap-3 shrink-0">
                  {c.lejarat && (
                    <span className={cn("text-[11px] font-mono px-2 py-0.5 rounded", st.cls)}>
                      lejár: {c.lejarat}
                    </span>
                  )}
                  <button
                    type="button"
                    onClick={() => remove(c.id)}
                    className="text-muted-foreground hover:text-destructive p-1"
                  >
                    <Trash2 className="size-3.5" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      <div className="rounded-lg border border-border bg-card p-4 space-y-3">
        <div className="text-[10px] font-mono uppercase text-muted-foreground tracking-wider">
          Új képzettség
        </div>
        <div className="grid sm:grid-cols-2 gap-2">
          <input
            placeholder="Megnevezés"
            value={form.nev}
            onChange={(e) => setForm({ ...form, nev: e.target.value })}
            className="px-3 py-2 text-sm rounded-md border border-input bg-background"
          />
          <select
            value={form.tipus}
            onChange={(e) => setForm({ ...form, tipus: e.target.value })}
            className="px-3 py-2 text-sm rounded-md border border-input bg-background"
          >
            <option value="oklevel">Oklevél</option>
            <option value="szakvizsga">Szakvizsga</option>
            <option value="licenc">Licenc</option>
            <option value="tovabbkepzes">Továbbképzés</option>
            <option value="egyeb">Egyéb</option>
          </select>
          <input
            placeholder="Kibocsátó"
            value={form.kibocsato}
            onChange={(e) => setForm({ ...form, kibocsato: e.target.value })}
            className="px-3 py-2 text-sm rounded-md border border-input bg-background"
          />
          <input
            placeholder="Iktatószám"
            value={form.szam}
            onChange={(e) => setForm({ ...form, szam: e.target.value })}
            className="px-3 py-2 text-sm rounded-md border border-input bg-background"
          />
          <input
            type="date"
            value={form.kibocsatva}
            onChange={(e) => setForm({ ...form, kibocsatva: e.target.value })}
            className="px-3 py-2 text-sm rounded-md border border-input bg-background"
          />
          <input
            type="date"
            value={form.lejarat}
            onChange={(e) => setForm({ ...form, lejarat: e.target.value })}
            className="px-3 py-2 text-sm rounded-md border border-input bg-background"
          />
        </div>
        <button
          type="button"
          onClick={add}
          disabled={adding || !form.nev}
          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md bg-primary text-primary-foreground text-xs font-semibold disabled:opacity-50"
        >
          {adding ? <Loader2 className="size-3.5 animate-spin" /> : <Plus className="size-3.5" />}
          Hozzáadás
        </button>
      </div>
    </div>
  );
}

// ============================================================
// Trainings (in progress)
// ============================================================
function TrainingsTab({ userId, tenantId }: { userId: string; tenantId: string | null }) {
  const { t } = useTranslation();
  const [rows, setRows] = useState<Training[]>([]);
  const [programs, setPrograms] = useState<{ id: string; nev: string }[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({
    nev: "",
    program_id: "",
    kezdes: "",
    varhato_veg: "",
    elorehaladas_pct: 0,
    statusz: "folyamatban",
  });
  const [adding, setAdding] = useState(false);

  async function load() {
    const [{ data: t1 }, { data: p }] = await Promise.all([
      supabase
        .from("profile_trainings")
        .select("*")
        .eq("user_id", userId)
        .order("kezdes", { ascending: false }),
      supabase.from("training_programs").select("id, nev").order("nev"),
    ]);
    setRows((t1 ?? []) as Training[]);
    setPrograms((p ?? []) as { id: string; nev: string }[]);
    setLoading(false);
  }
  useEffect(() => {
    load();
  }, [userId]);

  async function add() {
    if (!form.nev || !tenantId) return;
    setAdding(true);
    const { error } = await supabase.from("profile_trainings").insert({
      tenant_id: tenantId,
      user_id: userId,
      nev: form.nev,
      program_id: form.program_id || null,
      kezdes: form.kezdes || null,
      varhato_veg: form.varhato_veg || null,
      elorehaladas_pct: form.elorehaladas_pct,
      statusz: form.statusz,
    });
    setAdding(false);
    if (error) {
      toast.error(humanizeError(error, t, { perm: "manage_training" }));
      return;
    }
    setForm({
      nev: "",
      program_id: "",
      kezdes: "",
      varhato_veg: "",
      elorehaladas_pct: 0,
      statusz: "folyamatban",
    });
    load();
  }
  async function updateProgress(id: string, pct: number) {
    const { error } = await supabase
      .from("profile_trainings")
      .update({ elorehaladas_pct: pct })
      .eq("id", id);
    if (error) {
      toast.error(humanizeError(error, t, { perm: "manage_training" }));
      return;
    }
    setRows((r) => r.map((x) => (x.id === id ? { ...x, elorehaladas_pct: pct } : x)));
  }
  async function remove(id: string) {
    if (!window.confirm("Biztosan törli?")) return;
    const { error } = await supabase.from("profile_trainings").delete().eq("id", id);
    if (error) {
      toast.error(humanizeError(error, t, { perm: "manage_training" }));
      return;
    }
    load();
  }

  if (loading) return <Loading />;

  return (
    <div className="space-y-4">
      <div className="rounded-lg border border-border bg-card divide-y divide-border">
        {rows.length === 0 ? (
          <div className="p-6 text-center text-sm text-muted-foreground">
            Nincs folyamatban lévő képzés.
          </div>
        ) : (
          rows.map((tr) => (
            <div key={tr.id} className="px-4 py-3">
              <div className="flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <div className="font-semibold text-sm">{tr.nev}</div>
                  <div className="text-[11px] font-mono text-muted-foreground">
                    {tr.statusz}
                    {tr.kezdes && <> · {tr.kezdes}</>}
                    {tr.varhato_veg && <> → {tr.varhato_veg}</>}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => remove(tr.id)}
                  className="text-muted-foreground hover:text-destructive p-1"
                >
                  <Trash2 className="size-3.5" />
                </button>
              </div>
              <div className="mt-2 flex items-center gap-3">
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={tr.elorehaladas_pct}
                  onChange={(e) => updateProgress(tr.id, Number(e.target.value))}
                  className="flex-1"
                />
                <span className="text-xs font-mono font-semibold w-12 text-right">
                  {tr.elorehaladas_pct}%
                </span>
              </div>
            </div>
          ))
        )}
      </div>

      <div className="rounded-lg border border-border bg-card p-4 space-y-3">
        <div className="text-[10px] font-mono uppercase text-muted-foreground tracking-wider">
          Új képzés indítása
        </div>
        <div className="grid sm:grid-cols-2 gap-2">
          <input
            placeholder="Megnevezés"
            value={form.nev}
            onChange={(e) => setForm({ ...form, nev: e.target.value })}
            className="px-3 py-2 text-sm rounded-md border border-input bg-background"
          />
          <select
            value={form.program_id}
            onChange={(e) => setForm({ ...form, program_id: e.target.value })}
            className="px-3 py-2 text-sm rounded-md border border-input bg-background"
          >
            <option value="">— képzési program (opcionális) —</option>
            {programs.map((p) => (
              <option key={p.id} value={p.id}>
                {p.nev}
              </option>
            ))}
          </select>
          <input
            type="date"
            value={form.kezdes}
            onChange={(e) => setForm({ ...form, kezdes: e.target.value })}
            className="px-3 py-2 text-sm rounded-md border border-input bg-background"
          />
          <input
            type="date"
            value={form.varhato_veg}
            onChange={(e) => setForm({ ...form, varhato_veg: e.target.value })}
            className="px-3 py-2 text-sm rounded-md border border-input bg-background"
          />
        </div>
        <button
          type="button"
          onClick={add}
          disabled={adding || !form.nev}
          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md bg-primary text-primary-foreground text-xs font-semibold disabled:opacity-50"
        >
          {adding ? <Loader2 className="size-3.5 animate-spin" /> : <Plus className="size-3.5" />}
          Hozzáadás
        </button>
      </div>
    </div>
  );
}

function Loading() {
  return (
    <div className="p-8 flex items-center gap-2 text-muted-foreground text-sm">
      <Loader2 className="size-4 animate-spin" /> Betöltés…
    </div>
  );
}

// ============================================================
// Unavailability (Távollétek + jóváhagyási folyamat)
// ============================================================
type Unavailability = {
  id: string;
  user_id: string;
  tenant_id: string | null;
  tipus: "szabadsag" | "betegszabadsag" | "tovabbkepzes" | "konferencia" | "kotelezetts_ugy" | "egyeb_tavollet";
  kezdo_datum: string;
  zaro_datum: string;
  csak_delelott: boolean;
  csak_delutan: boolean;
  leiras: string | null;
  training_program_id: string | null;
  status: "tervezett" | "jovahagyasra_var" | "jovahagyott" | "elutasitott";
  jovahagyo_id: string | null;
  jovahagyas_at: string | null;
  jovahagyas_indok: string | null;
  akut: boolean;
  created_at: string;
};

const UNAV_TIPUS: Array<{ value: Unavailability["tipus"]; label: string }> = [
  { value: "szabadsag", label: "Szabadság" },
  { value: "betegszabadsag", label: "Betegszabadság" },
  { value: "tovabbkepzes", label: "Továbbképzés" },
  { value: "konferencia", label: "Konferencia" },
  { value: "kotelezetts_ugy", label: "Kötelezettség (hivatalos ügy)" },
  { value: "egyeb_tavollet", label: "Egyéb távollét" },
];

const STATUS_BADGE: Record<Unavailability["status"], { label: string; cls: string }> = {
  tervezett: { label: "Tervezett", cls: "bg-secondary text-muted-foreground" },
  jovahagyasra_var: { label: "Jóváhagyásra vár", cls: "bg-warning/15 text-warning" },
  jovahagyott: { label: "Jóváhagyva", cls: "bg-success/15 text-success" },
  elutasitott: { label: "Elutasítva", cls: "bg-destructive/15 text-destructive" },
};

function UnavailabilityTab({
  userId,
  tenantId,
  canApprove,
}: {
  userId: string;
  tenantId: string | null;
  canApprove: boolean;
}) {
  const { t } = useTranslation();
  const [rows, setRows] = useState<Unavailability[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const [reason, setReason] = useState("");
  const [openHistory, setOpenHistory] = useState<Record<string, boolean>>({});
  const [draft, setDraft] = useState({
    tipus: "szabadsag" as Unavailability["tipus"],
    kezdo_datum: "",
    zaro_datum: "",
    csak_delelott: false,
    csak_delutan: false,
    leiras: "",
  });
  const [calMonth, setCalMonth] = useState<Date>(new Date());
  const parseLocal = (s: string) => {
    const [y, m, d] = s.split("-").map(Number);
    return new Date(y, (m ?? 1) - 1, d ?? 1);
  };
  const dayBuckets = useMemo(() => {
    const approved: Date[] = [];
    const pending: Date[] = [];
    const planned: Date[] = [];
    const rejected: Date[] = [];
    for (const r of rows) {
      const start = parseLocal(r.kezdo_datum);
      const end = parseLocal(r.zaro_datum);
      for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
        const cur = new Date(d);
        if (r.status === "jovahagyott") approved.push(cur);
        else if (r.status === "jovahagyasra_var") pending.push(cur);
        else if (r.status === "tervezett") planned.push(cur);
        else if (r.status === "elutasitott") rejected.push(cur);
      }
    }
    return { approved, pending, planned, rejected };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rows]);

  async function load() {
    setLoading(true);
    const { data } = await supabase
      .from("profile_unavailability" as never)
      .select("*")
      .eq("user_id", userId)
      .order("kezdo_datum", { ascending: false });
    setRows((data ?? []) as unknown as Unavailability[]);
    setLoading(false);
  }
  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId]);

  async function add(submitForApproval: boolean) {
    if (!draft.kezdo_datum || !draft.zaro_datum) {
      toast.error("Adjon meg kezdő és záró dátumot.");
      return;
    }
    if (draft.zaro_datum < draft.kezdo_datum) {
      toast.error("A záró dátum nem lehet korábbi, mint a kezdő.");
      return;
    }
    setBusy("add");
    const payload = {
      user_id: userId,
      tenant_id: tenantId,
      tipus: draft.tipus,
      kezdo_datum: draft.kezdo_datum,
      zaro_datum: draft.zaro_datum,
      csak_delelott: draft.csak_delelott,
      csak_delutan: draft.csak_delutan,
      leiras: draft.leiras.trim() || null,
      status: submitForApproval ? "jovahagyasra_var" : "tervezett",
    };
    const { data, error } = await supabase
      .from("profile_unavailability" as never)
      .insert(payload as never)
      .select("*")
      .maybeSingle();
    setBusy(null);
    if (error) {
      toast.error(humanizeError(error, t));
      return;
    }
    if (data) {
      const row = data as unknown as Unavailability;
      await applyReason("profile_unavailability", row.id, reason);
      setRows((p) => [row, ...p]);
      setDraft({
        tipus: "szabadsag",
        kezdo_datum: "",
        zaro_datum: "",
        csak_delelott: false,
        csak_delutan: false,
        leiras: "",
      });
      setReason("");
      toast.success(submitForApproval ? "Beküldve jóváhagyásra" : "Tervezett távollét hozzáadva");
    }
  }

  async function changeStatus(
    row: Unavailability,
    status: Unavailability["status"],
    indok?: string,
  ) {
    setBusy(row.id);
    const patch: Partial<Unavailability> = { status };
    if (status === "jovahagyott" || status === "elutasitott") {
      patch.jovahagyo_id = (await supabase.auth.getUser()).data.user?.id ?? null;
      patch.jovahagyas_at = new Date().toISOString();
      patch.jovahagyas_indok = indok?.trim() || null;
    }
    const { error } = await supabase
      .from("profile_unavailability" as never)
      .update(patch as never)
      .eq("id", row.id);
    setBusy(null);
    if (error) {
      toast.error(humanizeError(error, t));
      return;
    }
    await applyReason("profile_unavailability", row.id, reason);
    setRows((p) => p.map((r) => (r.id === row.id ? { ...r, ...patch } as Unavailability : r)));
    setReason("");
    toast.success("Státusz frissítve");
  }

  async function remove(id: string) {
    if (!window.confirm("Biztosan törli ezt a távollétet?")) return;
    setBusy(id);
    const { error } = await supabase
      .from("profile_unavailability" as never)
      .delete()
      .eq("id", id);
    setBusy(null);
    if (error) {
      toast.error(humanizeError(error, t));
      return;
    }
    await applyReason("profile_unavailability", id, reason);
    setRows((p) => p.filter((r) => r.id !== id));
    setReason("");
    toast.success("Törölve");
  }

  if (loading) return <Loading />;

  // Visual calendar helpers
  const fmt = (d: Date) => {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
  };
  const range: DateRange | undefined =
    draft.kezdo_datum && draft.zaro_datum
      ? { from: parseLocal(draft.kezdo_datum), to: parseLocal(draft.zaro_datum) }
      : draft.kezdo_datum
      ? { from: parseLocal(draft.kezdo_datum), to: undefined }
      : undefined;

  return (
    <div className="space-y-4 max-w-4xl">
      <AcuteIllnessReport
        userId={userId}
        tenantId={tenantId}
        onCreated={(row) => setRows((p) => [row, ...p])}
      />

      <div className="rounded-lg border border-border bg-card p-4 space-y-3">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Szabadság-naptár · kattintással jelölje a tartományt
          </div>
          <div className="flex items-center gap-3 text-[11px] flex-wrap">
            <span className="inline-flex items-center gap-1"><span className="size-3 rounded bg-success/40 border border-success" />Jóváhagyva</span>
            <span className="inline-flex items-center gap-1"><span className="size-3 rounded bg-warning/40 border border-warning" />Vár</span>
            <span className="inline-flex items-center gap-1"><span className="size-3 rounded bg-secondary border border-border" />Tervezett</span>
            <span className="inline-flex items-center gap-1"><span className="size-3 rounded bg-destructive/30 border border-destructive line-through" />Elutasítva</span>
          </div>
        </div>
        <Calendar
          mode="range"
          numberOfMonths={2}
          weekStartsOn={1}
          month={calMonth}
          onMonthChange={setCalMonth}
          selected={range}
          onSelect={(r) => {
            setDraft((d) => ({
              ...d,
              kezdo_datum: r?.from ? fmt(r.from) : "",
              zaro_datum: r?.to ? fmt(r.to) : r?.from ? fmt(r.from) : "",
            }));
          }}
          modifiers={{
            approved: dayBuckets.approved,
            pending: dayBuckets.pending,
            planned: dayBuckets.planned,
            rejected: dayBuckets.rejected,
          }}
          modifiersClassNames={{
            approved: "bg-success/30 text-success-foreground font-semibold",
            pending: "bg-warning/30 text-warning-foreground font-semibold",
            planned: "bg-secondary text-foreground",
            rejected: "bg-destructive/20 text-destructive line-through",
          }}
          className="p-3 pointer-events-auto rounded-md border border-border bg-background"
        />
        {(draft.kezdo_datum || draft.zaro_datum) && (
          <div className="flex items-center justify-between text-xs">
            <span className="font-mono text-muted-foreground">
              Kijelölve: {draft.kezdo_datum || "—"} → {draft.zaro_datum || "—"}
            </span>
            <button
              type="button"
              onClick={() => setDraft((d) => ({ ...d, kezdo_datum: "", zaro_datum: "" }))}
              className="text-[11px] px-2 py-1 rounded border border-border hover:bg-secondary"
            >
              Kijelölés törlése
            </button>
          </div>
        )}
      </div>



      <div className="rounded-lg border border-dashed border-border bg-card p-4 space-y-3">
        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Új távollét rögzítése
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <Field label="Típus">
            <select
              value={draft.tipus}
              onChange={(e) => setDraft({ ...draft, tipus: e.target.value as Unavailability["tipus"] })}
              className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
            >
              {UNAV_TIPUS.map((x) => (
                <option key={x.value} value={x.value}>
                  {x.label}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Kezdő dátum">
            <input
              type="date"
              value={draft.kezdo_datum}
              onChange={(e) => setDraft({ ...draft, kezdo_datum: e.target.value })}
              className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
            />
          </Field>
          <Field label="Záró dátum">
            <input
              type="date"
              value={draft.zaro_datum}
              onChange={(e) => setDraft({ ...draft, zaro_datum: e.target.value })}
              className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
            />
          </Field>
        </div>
        <div className="flex gap-4 flex-wrap text-xs">
          <label className="flex items-center gap-1.5">
            <input
              type="checkbox"
              checked={draft.csak_delelott}
              onChange={(e) => setDraft({ ...draft, csak_delelott: e.target.checked, csak_delutan: false })}
            />
            csak délelőtt
          </label>
          <label className="flex items-center gap-1.5">
            <input
              type="checkbox"
              checked={draft.csak_delutan}
              onChange={(e) => setDraft({ ...draft, csak_delutan: e.target.checked, csak_delelott: false })}
            />
            csak délután
          </label>
        </div>
        <Field label="Leírás (pl. konferencia neve)">
          <input
            value={draft.leiras}
            onChange={(e) => setDraft({ ...draft, leiras: e.target.value.slice(0, 500) })}
            className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
          />
        </Field>
        <ReasonInput value={reason} onChange={setReason} placeholder="Indoklás (opcionális, audit-naplóba)" />
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => add(false)}
            disabled={busy === "add"}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md border border-border bg-background text-xs font-semibold hover:bg-secondary disabled:opacity-50"
          >
            {busy === "add" ? <Loader2 className="size-3.5 animate-spin" /> : <Plus className="size-3.5" />}
            Mentés tervezettként
          </button>
          <button
            type="button"
            onClick={() => add(true)}
            disabled={busy === "add"}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90 disabled:opacity-50"
          >
            <Clock className="size-3.5" />
            Beküldés jóváhagyásra
          </button>
        </div>
      </div>

      {rows.length === 0 ? (
        <div className="p-6 rounded-lg border border-dashed border-border text-sm text-muted-foreground text-center">
          Még nincs rögzített távollét.
        </div>
      ) : (
        <div className="rounded-lg border border-border bg-card divide-y divide-border">
          {rows.map((r) => {
            const typeLabel = UNAV_TIPUS.find((x) => x.value === r.tipus)?.label ?? r.tipus;
            const badge = STATUS_BADGE[r.status];
            const b = busy === r.id;
            return (
              <div key={r.id} className="px-4 py-3 space-y-2">
                <div className="flex items-center gap-3 flex-wrap">
                  <div className="flex-1 min-w-[240px]">
                    <div className="text-sm font-semibold flex items-center gap-2 flex-wrap">
                      {typeLabel}
                      <span className={cn("text-[10px] font-mono px-1.5 py-0.5 rounded uppercase", badge.cls)}>
                        {badge.label}
                      </span>
                      {(r.csak_delelott || r.csak_delutan) && (
                        <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-secondary text-muted-foreground">
                          {r.csak_delelott ? "DE" : "DU"}
                        </span>
                      )}
                    </div>
                    <div className="text-xs font-mono text-muted-foreground">
                      {r.kezdo_datum} → {r.zaro_datum}
                      {r.leiras && <> · {r.leiras}</>}
                    </div>
                    {r.jovahagyas_indok && (
                      <div className="text-[11px] text-muted-foreground italic mt-1">
                        „{r.jovahagyas_indok}"
                      </div>
                    )}
                  </div>
                  {r.status === "tervezett" && (
                    <button
                      type="button"
                      onClick={() => changeStatus(r, "jovahagyasra_var")}
                      disabled={b}
                      className="text-[11px] px-2 py-1 rounded border border-border hover:bg-secondary disabled:opacity-50"
                    >
                      Beküldés
                    </button>
                  )}
                  {canApprove && r.status === "jovahagyasra_var" && (
                    <>
                      <button
                        type="button"
                        onClick={() => changeStatus(r, "jovahagyott", reason)}
                        disabled={b}
                        className="inline-flex items-center gap-1 text-[11px] px-2 py-1 rounded bg-success/15 text-success hover:bg-success/25 disabled:opacity-50"
                      >
                        <Check className="size-3" /> Jóváhagy
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          const r2 = window.prompt("Elutasítás indoka (kötelező):") ?? "";
                          if (!r2.trim()) {
                            toast.error("Elutasításhoz kötelező az indoklás.");
                            return;
                          }
                          changeStatus(r, "elutasitott", r2);
                        }}
                        disabled={b}
                        className="inline-flex items-center gap-1 text-[11px] px-2 py-1 rounded bg-destructive/15 text-destructive hover:bg-destructive/25 disabled:opacity-50"
                      >
                        <X className="size-3" /> Elutasít
                      </button>
                    </>
                  )}
                  <button
                    type="button"
                    onClick={() => setOpenHistory((s) => ({ ...s, [r.id]: !s[r.id] }))}
                    className="p-1.5 rounded text-muted-foreground hover:bg-secondary"
                    aria-label="Előzmények"
                    title="Előzmények"
                  >
                    {openHistory[r.id] ? <ChevronDown className="size-3.5" /> : <ChevronRight className="size-3.5" />}
                  </button>
                  <button
                    type="button"
                    onClick={() => remove(r.id)}
                    disabled={b}
                    className="p-1.5 rounded text-destructive hover:bg-destructive/10 disabled:opacity-50"
                    aria-label="Törlés"
                  >
                    {b ? <Loader2 className="size-3.5 animate-spin" /> : <Trash2 className="size-3.5" />}
                  </button>
                </div>
                {openHistory[r.id] && (
                  <div className="pl-3 border-l-2 border-border/60">
                    <RecordHistory tableName="profile_unavailability" recordId={r.id} />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ============================================================
// Constraints (Korlátozó tényezők)
// ============================================================
type Constraint = {
  id: string;
  user_id: string;
  tenant_id: string | null;
  tipus: "terhes" | "szoptat" | "kisgyermek_otthon" | "egyedulnevelo" | "tartos_betegseg" | "mozgaskorlatozas" | "vedendokoru" | "egyeb";
  ervenyes_tol: string;
  ervenyes_ig: string | null;
  igazolas_url: string | null;
  hr_megjegyzes: string | null;
  megjegyzes: string | null;
};

const CONSTRAINT_TIPUS: Array<{ value: Constraint["tipus"]; label: string; hatas: string }> = [
  { value: "terhes", label: "Terhesség", hatas: "Nincs éjszakás, nincs sugárterhelt zóna" },
  { value: "szoptat", label: "Szoptat (1 éven belüli)", hatas: "Nincs éjszakás, hosszabbított szünetek" },
  { value: "kisgyermek_otthon", label: "Kisgyermek otthon (3 év alatt)", hatas: "Éjszakás csak hozzájárulással" },
  { value: "egyedulnevelo", label: "Egyedülnevelő szülő", hatas: "Éjszakás csak hozzájárulással" },
  { value: "tartos_betegseg", label: "Tartós betegség", hatas: "Egyéni elbírálás" },
  { value: "mozgaskorlatozas", label: "Mozgáskorlátozás", hatas: "Akadálymentes munkavégzés" },
  { value: "vedendokoru", label: "Védendő korú", hatas: "Túlóra/ügyelet korlát" },
  { value: "egyeb", label: "Egyéb", hatas: "" },
];

function ConstraintsTab({
  userId,
  tenantId,
  isHr,
}: {
  userId: string;
  tenantId: string | null;
  isHr: boolean;
}) {
  const { t } = useTranslation();
  const [rows, setRows] = useState<Constraint[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const [reason, setReason] = useState("");
  const [openHistory, setOpenHistory] = useState<Record<string, boolean>>({});
  const [draft, setDraft] = useState({
    tipus: "terhes" as Constraint["tipus"],
    ervenyes_tol: new Date().toISOString().slice(0, 10),
    ervenyes_ig: "",
    igazolas_url: "",
    megjegyzes: "",
  });

  async function load() {
    setLoading(true);
    const { data } = await supabase
      .from("profile_constraints" as never)
      .select("*")
      .eq("user_id", userId)
      .order("ervenyes_tol", { ascending: false });
    setRows((data ?? []) as unknown as Constraint[]);
    setLoading(false);
  }
  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId]);

  async function add() {
    if (!reason.trim()) {
      toast.error("Az indoklás kötelező (audit).");
      return;
    }
    setBusy("add");
    const payload = {
      user_id: userId,
      tenant_id: tenantId,
      tipus: draft.tipus,
      ervenyes_tol: draft.ervenyes_tol,
      ervenyes_ig: draft.ervenyes_ig || null,
      igazolas_url: draft.igazolas_url.trim() || null,
      megjegyzes: draft.megjegyzes.trim() || null,
    };
    const { data, error } = await supabase
      .from("profile_constraints" as never)
      .insert(payload as never)
      .select("*")
      .maybeSingle();
    setBusy(null);
    if (error) {
      toast.error(humanizeError(error, t));
      return;
    }
    if (data) {
      const row = data as unknown as Constraint;
      await applyReason("profile_constraints", row.id, reason);
      setRows((p) => [row, ...p]);
      setDraft({
        tipus: "terhes",
        ervenyes_tol: new Date().toISOString().slice(0, 10),
        ervenyes_ig: "",
        igazolas_url: "",
        megjegyzes: "",
      });
      setReason("");
      toast.success("Hozzáadva");
    }
  }

  async function setHrNote(id: string, note: string) {
    setBusy(id);
    const { error } = await supabase
      .from("profile_constraints" as never)
      .update({ hr_megjegyzes: note || null } as never)
      .eq("id", id);
    setBusy(null);
    if (error) {
      toast.error(humanizeError(error, t));
      return;
    }
    await applyReason("profile_constraints", id, reason);
    setRows((p) => p.map((r) => (r.id === id ? { ...r, hr_megjegyzes: note || null } : r)));
    setReason("");
  }

  async function remove(id: string) {
    if (!reason.trim()) {
      toast.error("Az indoklás kötelező a törléshez.");
      return;
    }
    if (!window.confirm("Biztosan törli ezt a bejegyzést?")) return;
    setBusy(id);
    const { error } = await supabase
      .from("profile_constraints" as never)
      .delete()
      .eq("id", id);
    setBusy(null);
    if (error) {
      toast.error(humanizeError(error, t));
      return;
    }
    await applyReason("profile_constraints", id, reason);
    setRows((p) => p.filter((r) => r.id !== id));
    setReason("");
    toast.success("Törölve");
  }

  if (loading) return <Loading />;

  return (
    <div className="space-y-4 max-w-3xl">
      <div className="rounded-md border border-warning/30 bg-warning/5 px-3 py-2 text-xs text-warning">
        Diszkrét adat. Csak Ön és a tenant-admin (HR) láthatja. Minden módosítás auditálva van.
      </div>

      <div className="rounded-lg border border-dashed border-border bg-card p-4 space-y-3">
        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Új korlátozó tényező
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <Field label="Típus">
            <select
              value={draft.tipus}
              onChange={(e) => setDraft({ ...draft, tipus: e.target.value as Constraint["tipus"] })}
              className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
            >
              {CONSTRAINT_TIPUS.map((x) => (
                <option key={x.value} value={x.value}>
                  {x.label}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Érvényes -tól">
            <input
              type="date"
              value={draft.ervenyes_tol}
              onChange={(e) => setDraft({ ...draft, ervenyes_tol: e.target.value })}
              className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
            />
          </Field>
          <Field label="Érvényes -ig (opc.)">
            <input
              type="date"
              value={draft.ervenyes_ig}
              onChange={(e) => setDraft({ ...draft, ervenyes_ig: e.target.value })}
              className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
            />
          </Field>
        </div>
        <Field label="Igazolás URL (opc.)">
          <input
            value={draft.igazolas_url}
            onChange={(e) => setDraft({ ...draft, igazolas_url: e.target.value.slice(0, 500) })}
            placeholder="https://…"
            className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm font-mono"
          />
        </Field>
        <Field label="Megjegyzés (opc.)">
          <textarea
            value={draft.megjegyzes}
            onChange={(e) => setDraft({ ...draft, megjegyzes: e.target.value.slice(0, 1000) })}
            rows={2}
            className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
          />
        </Field>
        <div className="text-[11px] text-muted-foreground">
          Munkajogi hatás (auto):{" "}
          <span className="italic">
            {CONSTRAINT_TIPUS.find((x) => x.value === draft.tipus)?.hatas || "—"}
          </span>
        </div>
        <ReasonInput value={reason} onChange={setReason} placeholder="Indoklás (kötelező — audit)" />
        <button
          type="button"
          onClick={add}
          disabled={busy === "add" || !reason.trim()}
          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90 disabled:opacity-50"
        >
          {busy === "add" ? <Loader2 className="size-3.5 animate-spin" /> : <Plus className="size-3.5" />}
          Hozzáadás
        </button>
      </div>

      {rows.length === 0 ? (
        <div className="p-6 rounded-lg border border-dashed border-border text-sm text-muted-foreground text-center">
          Nincs rögzített korlátozó tényező.
        </div>
      ) : (
        <div className="rounded-lg border border-border bg-card divide-y divide-border">
          {rows.map((r) => {
            const meta = CONSTRAINT_TIPUS.find((x) => x.value === r.tipus);
            const b = busy === r.id;
            return (
              <div key={r.id} className="px-4 py-3 space-y-2">
                <div className="flex items-center gap-3 flex-wrap">
                  <div className="flex-1 min-w-[200px]">
                    <div className="text-sm font-semibold">{meta?.label ?? r.tipus}</div>
                    <div className="text-xs font-mono text-muted-foreground">
                      {r.ervenyes_tol}
                      {r.ervenyes_ig ? ` → ${r.ervenyes_ig}` : " → (folyamatos)"}
                    </div>
                    {meta?.hatas && (
                      <div className="text-[11px] text-warning mt-0.5">⚠ {meta.hatas}</div>
                    )}
                    {r.megjegyzes && (
                      <div className="text-[11px] text-muted-foreground mt-1 italic">
                        {r.megjegyzes}
                      </div>
                    )}
                    {r.igazolas_url && (
                      <a
                        href={r.igazolas_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[11px] text-primary underline font-mono"
                      >
                        igazolás
                      </a>
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={() => setOpenHistory((s) => ({ ...s, [r.id]: !s[r.id] }))}
                    className="p-1.5 rounded text-muted-foreground hover:bg-secondary"
                    aria-label="Előzmények"
                    title="Előzmények"
                  >
                    {openHistory[r.id] ? <ChevronDown className="size-3.5" /> : <ChevronRight className="size-3.5" />}
                  </button>
                  <button
                    type="button"
                    onClick={() => remove(r.id)}
                    disabled={b}
                    className="p-1.5 rounded text-destructive hover:bg-destructive/10 disabled:opacity-50"
                    aria-label="Törlés"
                  >
                    {b ? <Loader2 className="size-3.5 animate-spin" /> : <Trash2 className="size-3.5" />}
                  </button>
                </div>
                {isHr && (
                  <div className="pl-2 border-l-2 border-warning/40">
                    <div className="text-[10px] font-mono uppercase text-warning mb-1">HR megjegyzés (titkos — csak tenant-admin)</div>
                    <textarea
                      defaultValue={r.hr_megjegyzes ?? ""}
                      onBlur={(e) => {
                        if (e.target.value !== (r.hr_megjegyzes ?? "")) setHrNote(r.id, e.target.value);
                      }}
                      rows={2}
                      placeholder="Csak HR látja…"
                      className="w-full px-2 py-1 text-xs rounded border border-input bg-background"
                    />
                  </div>
                )}
                {openHistory[r.id] && (
                  <div className="pl-3 border-l-2 border-border/60">
                    <RecordHistory tableName="profile_constraints" recordId={r.id} />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ============================================================
// Akut betegjelentés (gyors-jelölő)
// ============================================================
function AcuteIllnessReport({
  userId,
  tenantId,
  onCreated,
}: {
  userId: string;
  tenantId: string | null;
  onCreated: (row: Unavailability) => void;
}) {
  const { t } = useTranslation();
  const [open, setOpen] = useState(false);
  const today = new Date().toISOString().slice(0, 10);
  const defaultEnd = new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
  const [kezdo, setKezdo] = useState(today);
  const [zaro, setZaro] = useState(defaultEnd);
  const [leiras, setLeiras] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit() {
    if (!kezdo || !zaro) {
      toast.error("Adjon meg dátumot.");
      return;
    }
    if (zaro < kezdo) {
      toast.error("A záró dátum nem lehet korábbi, mint a kezdő.");
      return;
    }
    setBusy(true);
    const payload = {
      user_id: userId,
      tenant_id: tenantId,
      tipus: "betegszabadsag" as const,
      kezdo_datum: kezdo,
      zaro_datum: zaro,
      csak_delelott: false,
      csak_delutan: false,
      leiras: leiras.trim() || null,
      status: "jovahagyott" as const,
      akut: true,
      jovahagyas_at: new Date().toISOString(),
      jovahagyo_id: userId,
      jovahagyas_indok: "Akut betegjelentés (önbevallás)",
    };
    const { data, error } = await supabase
      .from("profile_unavailability" as never)
      .insert(payload as never)
      .select("*")
      .maybeSingle();
    setBusy(false);
    if (error) {
      toast.error(humanizeError(error, t));
      return;
    }
    if (data) {
      const row = data as unknown as Unavailability;
      await applyReason(
        "profile_unavailability",
        row.id,
        leiras.trim() || "Akut betegjelentés",
      );
      onCreated(row);
      toast.success("Akut betegjelentés rögzítve — a beosztásvezetők értesülnek.");
      setOpen(false);
      setLeiras("");
      setKezdo(today);
      setZaro(defaultEnd);
    }
  }

  return (
    <div className="rounded-lg border-2 border-destructive/40 bg-destructive/5 p-4 space-y-3">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div className="flex items-start gap-3">
          <div className="rounded-full bg-destructive/15 p-2 mt-0.5">
            <HeartPulse className="size-5 text-destructive" />
          </div>
          <div>
            <div className="text-sm font-semibold text-destructive">Akut betegjelentés</div>
            <div className="text-xs text-muted-foreground mt-0.5 max-w-xl">
              Hirtelen rosszullét vagy fertőző tünet esetén: egy kattintással jelez a beosztásvezetőnek,
              és a rendszer azonnal helyettesítési javaslatot készít az adminisztrációnak.
            </div>
          </div>
        </div>
        {!open && (
          <button
            type="button"
            onClick={() => setOpen(true)}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md bg-destructive text-destructive-foreground text-xs font-semibold hover:opacity-90"
          >
            <HeartPulse className="size-3.5" />
            Beteget jelentek
          </button>
        )}
      </div>
      {open && (
        <div className="space-y-3 pt-2 border-t border-destructive/20">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <Field label="Mettől (kezdő dátum)">
              <input
                type="date"
                value={kezdo}
                onChange={(e) => setKezdo(e.target.value)}
                className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
              />
            </Field>
            <Field label="Meddig (várható záró dátum)">
              <input
                type="date"
                value={zaro}
                onChange={(e) => setZaro(e.target.value)}
                className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
              />
            </Field>
          </div>
          <Field label='Megjegyzés (opcionális — pl. „magas láz, légúti tünet")'>
            <input
              value={leiras}
              onChange={(e) => setLeiras(e.target.value.slice(0, 300))}
              className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
              placeholder="Tünet, súlyosság…"
            />
          </Field>
          <div className="flex gap-2 justify-end">
            <button
              type="button"
              onClick={() => setOpen(false)}
              disabled={busy}
              className="px-3 py-2 rounded-md border border-border bg-background text-xs font-semibold hover:bg-secondary disabled:opacity-50"
            >
              Mégse
            </button>
            <button
              type="button"
              onClick={submit}
              disabled={busy}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md bg-destructive text-destructive-foreground text-xs font-semibold hover:opacity-90 disabled:opacity-50"
            >
              {busy ? <Loader2 className="size-3.5 animate-spin" /> : <HeartPulse className="size-3.5" />}
              Beteget jelentek most
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function SzabadsagAdatokTab({
  profile,
  onChange,
  isHr,
}: {
  profile: Profile;
  onChange: (p: Profile) => void;
  isHr: boolean;
}) {
  const { t } = useTranslation();
  const [vezetoi, setVezetoi] = useState<Profile["vezetoi_szint"]>(profile.vezetoi_szint ?? "nincs");
  const [sugar, setSugar] = useState(profile.sugarterheles_kategoria ?? "");
  const [oktatoi, setOktatoi] = useState(!!profile.oktatoi_munkakor);
  const [klinikai, setKlinikai] = useState(!!profile.klinikai_kombinalt);
  const [kjt, setKjt] = useState(profile.kjt_fizetesi_osztaly ?? "");
  const [belepes, setBelepes] = useState(profile.belepes_datum ?? "");
  const [gyerekek, setGyerekek] = useState<Array<{ nev?: string; szuletes: string; fogyatekos?: boolean }>>(
    profile.gyermek_szamok ?? [],
  );
  const [saving, setSaving] = useState(false);

  async function save() {
    setSaving(true);
    const patch = {
      vezetoi_szint: vezetoi || null,
      sugarterheles_kategoria: sugar || null,
      oktatoi_munkakor: oktatoi,
      klinikai_kombinalt: klinikai,
      kjt_fizetesi_osztaly: kjt || null,
      belepes_datum: belepes || null,
      gyermek_szamok: gyerekek,
    };
    const { error } = await supabase.from("profiles").update(patch).eq("id", profile.id);
    setSaving(false);
    if (error) {
      toast.error(humanizeError(error, t));
      return;
    }
    onChange({ ...profile, ...patch });
    toast.success("Mentve");
  }

  return (
    <div className="rounded-lg border border-border bg-card p-6 space-y-4 max-w-3xl">
      <p className="text-xs text-muted-foreground">
        Ezek az adatok határozzák meg az éves szabadság-egyenleget (Mt., Eszjtv., Kjt., Nftv.). Az életkor és a
        születési dátum az „Alapadatok" fülön módosítható.
      </p>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Field label="Vezetői szint">
          <select
            value={vezetoi ?? "nincs"}
            onChange={(e) => setVezetoi(e.target.value as Profile["vezetoi_szint"])}
            className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
          >
            <option value="nincs">nincs</option>
            <option value="vezeto">Vezető</option>
            <option value="magasabb_vezeto">Magasabb vezető</option>
          </select>
        </Field>
        <Field label="Sugárterhelési kategória">
          <select
            value={sugar}
            onChange={(e) => setSugar(e.target.value)}
            className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
          >
            <option value="">nincs</option>
            <option value="A">A</option>
            <option value="B">B</option>
            <option value="C">C</option>
          </select>
        </Field>
        <Field label="KJT fizetési osztály (A–J)">
          <input
            value={kjt}
            maxLength={2}
            onChange={(e) => setKjt(e.target.value.toUpperCase())}
            className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
          />
        </Field>
        <Field label="Első belépés (jogviszony)">
          <input
            type="date"
            value={belepes}
            onChange={(e) => setBelepes(e.target.value)}
            className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
          />
        </Field>
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={oktatoi} onChange={(e) => setOktatoi(e.target.checked)} />
          Oktatói munkakör (Nftv.)
        </label>
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={klinikai} onChange={(e) => setKlinikai(e.target.checked)} />
          Klinikai kombinált jogviszony (Nftv. 99/D §)
        </label>
      </div>

      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
            Gyermekek (16 év alatti)
          </h3>
          <button
            type="button"
            onClick={() => setGyerekek([...gyerekek, { nev: "", szuletes: "", fogyatekos: false }])}
            className="text-xs px-2 py-1 rounded-md bg-secondary text-secondary-foreground hover:opacity-90"
          >
            + Gyermek
          </button>
        </div>
        {gyerekek.length === 0 ? (
          <div className="text-xs text-muted-foreground">Nincs rögzítve gyermek.</div>
        ) : (
          <div className="space-y-2">
            {gyerekek.map((g, i) => (
              <div key={i} className="flex items-center gap-2 flex-wrap">
                <input
                  placeholder="Név (opcionális)"
                  value={g.nev ?? ""}
                  onChange={(e) => {
                    const arr = [...gyerekek];
                    arr[i] = { ...arr[i], nev: e.target.value };
                    setGyerekek(arr);
                  }}
                  className="flex-1 min-w-[160px] px-2 py-1 rounded-md border border-input bg-background text-sm"
                />
                <input
                  type="date"
                  value={g.szuletes}
                  onChange={(e) => {
                    const arr = [...gyerekek];
                    arr[i] = { ...arr[i], szuletes: e.target.value };
                    setGyerekek(arr);
                  }}
                  className="px-2 py-1 rounded-md border border-input bg-background text-sm"
                />
                <label className="text-xs flex items-center gap-1">
                  <input
                    type="checkbox"
                    checked={!!g.fogyatekos}
                    onChange={(e) => {
                      const arr = [...gyerekek];
                      arr[i] = { ...arr[i], fogyatekos: e.target.checked };
                      setGyerekek(arr);
                    }}
                  />
                  fogyatékos
                </label>
                <button
                  type="button"
                  onClick={() => setGyerekek(gyerekek.filter((_, j) => j !== i))}
                  className="text-xs text-destructive hover:underline"
                >
                  törlés
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {!isHr && (
        <p className="text-[11px] text-muted-foreground">
          Megjegyzés: néhány paraméter (KJT osztály, oktatói munkakör) HR jóváhagyással véglegesedik a számításnál.
        </p>
      )}

      <button
        type="button"
        onClick={save}
        disabled={saving}
        className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90 disabled:opacity-50"
      >
        {saving ? <Loader2 className="size-3.5 animate-spin" /> : <Save className="size-3.5" />}
        Mentés
      </button>
    </div>
  );
}
