import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Loader2, MapPin, LogIn, LogOut, Coffee, ShieldCheck, AlertTriangle, WifiOff, CloudUpload } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { useTranslation } from "react-i18next";
import { humanizeError } from "@/lib/humanize-error";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { enqueueAttendance, flushAttendance, pendingCount, registerOfflineFlushHandlers } from "@/lib/pwa/offline-attendance";

export const Route = createFileRoute("/_authenticated/jelenlet")({
  component: JelenletPage,
});

type AttEvent = {
  id: string;
  esemeny_tipus: string;
  idopont: string;
  modszer: string;
  geo_lat: number | null;
  geo_lng: number | null;
  horgony_egyezes: boolean | null;
  anchor_id: string | null;
};

type Anchor = {
  id: string;
  nev: string;
  tipus: string;
  geo_lat: number | null;
  geo_lng: number | null;
  geo_sugar_m: number | null;
};

type Consent = {
  id: string;
  cel: string;
  dokumentum_verzio: string;
  elfogadva_at: string;
  visszavonva_at: string | null;
};

const CONSENT_VERSION = "v1.0-2026-06";
const CONSENT_TEXT =
  "Hozzájárulok ahhoz, hogy a munkáltató a jelenléti rögzítés céljából a GPS-helyzetemet és eszközazonosítóimat (IP, böngésző) a munkaidőm rögzítésével együtt tárolja, a hatályos GDPR és Eüak. szerint. A hozzájárulás bármikor visszavonható.";

function distMeters(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371000;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

function JelenletPage() {
  const { user } = useAuth();
  const { t } = useTranslation();
  const [loading, setLoading] = useState(true);
  const [events, setEvents] = useState<AttEvent[]>([]);
  const [anchors, setAnchors] = useState<Anchor[]>([]);
  const [consents, setConsents] = useState<Consent[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [tenantId, setTenantId] = useState<string | null>(null);
  const [online, setOnline] = useState<boolean>(typeof navigator !== "undefined" ? navigator.onLine : true);
  const [pending, setPending] = useState<number>(0);

  useEffect(() => {
    if (!user) return;
    void load();
    void pendingCount().then(setPending);
    const setOn = () => setOnline(true);
    const setOff = () => setOnline(false);
    window.addEventListener("online", setOn);
    window.addEventListener("offline", setOff);
    const off = registerOfflineFlushHandlers((r) => {
      if (r.ok > 0) {
        toast.success(`${r.ok} offline esemény szinkronizálva`);
        void pendingCount().then(setPending);
        void load();
      }
    });
    return () => {
      window.removeEventListener("online", setOn);
      window.removeEventListener("offline", setOff);
      off();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  async function load() {
    if (!user) return;
    setLoading(true);
    try {
      const { data: prof } = await supabase
        .from("profiles")
        .select("tenant_id")
        .eq("id", user.id)
        .maybeSingle();
      const tid = (prof as any)?.tenant_id ?? null;
      setTenantId(tid);

      const since = new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString();
      const [{ data: ev }, { data: an }, { data: co }] = await Promise.all([
        supabase
          .from("attendance_events")
          .select("id,esemeny_tipus,idopont,modszer,geo_lat,geo_lng,horgony_egyezes,anchor_id")
          .eq("user_id", user.id)
          .gte("idopont", since)
          .order("idopont", { ascending: false })
          .limit(50),
        supabase
          .from("attendance_anchors")
          .select("id,nev,tipus,geo_lat,geo_lng,geo_sugar_m")
          .eq("ervenyes", true),
        supabase
          .from("gdpr_consents")
          .select("id,cel,dokumentum_verzio,elfogadva_at,visszavonva_at")
          .eq("user_id", user.id),
      ]);
      setEvents((ev ?? []) as AttEvent[]);
      setAnchors((an ?? []) as Anchor[]);
      setConsents((co ?? []) as Consent[]);
    } catch (e) {
      toast.error(humanizeError(e as Error, t));
    } finally {
      setLoading(false);
    }
  }

  function hasActiveConsent(cel: string): Consent | undefined {
    return consents.find(
      (c) => c.cel === cel && c.dokumentum_verzio === CONSENT_VERSION && !c.visszavonva_at,
    );
  }

  async function grantConsent(cel: string) {
    if (!user || !tenantId) return;
    const { error } = await (supabase.from("gdpr_consents") as any).insert({
      tenant_id: tenantId,
      user_id: user.id,
      cel,
      dokumentum_verzio: CONSENT_VERSION,
      szoveg_hivatkozas: "jelenlet-page",
      forras_user_agent: navigator.userAgent,
    });
    if (error) return toast.error(humanizeError(error, t));
    toast.success("Hozzájárulás rögzítve");
    void load();
  }

  async function revokeConsent(id: string) {
    const { error } = await (supabase.from("gdpr_consents") as any)
      .update({ visszavonva_at: new Date().toISOString() })
      .eq("id", id);
    if (error) return toast.error(humanizeError(error, t));
    toast.success("Hozzájárulás visszavonva");
    void load();
  }

  function getPosition(): Promise<GeolocationPosition | null> {
    return new Promise((resolve) => {
      if (!navigator.geolocation) return resolve(null);
      navigator.geolocation.getCurrentPosition(
        (p) => resolve(p),
        () => resolve(null),
        { enableHighAccuracy: true, timeout: 8000, maximumAge: 30000 },
      );
    });
  }

  async function record(type: "bejelentkezes" | "kijelentkezes" | "szunet_kezdet" | "szunet_veg") {
    if (!user || !tenantId) return;
    const helyConsent = hasActiveConsent("jelenlet_helymeghatarozas");
    const eszkozConsent = hasActiveConsent("jelenlet_eszkozazonosito");
    if (!helyConsent || !eszkozConsent) {
      toast.error("A rögzítéshez mindkét hozzájárulás szükséges (helymeghatározás + eszközazonosító)");
      return;
    }
    setSubmitting(true);
    try {
      const pos = await getPosition();
      let bestAnchor: Anchor | null = null;
      let matched = false;
      if (pos) {
        for (const a of anchors) {
          if (a.tipus !== "geofence" || a.geo_lat == null || a.geo_lng == null || !a.geo_sugar_m)
            continue;
          const d = distMeters(pos.coords.latitude, pos.coords.longitude, a.geo_lat, a.geo_lng);
          if (d <= a.geo_sugar_m && (!bestAnchor || d < (a.geo_sugar_m ?? 0))) {
            bestAnchor = a;
            matched = true;
          }
        }
      }
      const payload = {
        tenant_id: tenantId,
        user_id: user.id,
        esemeny_tipus: type,
        modszer: "web",
        anchor_id: bestAnchor?.id ?? null,
        geo_lat: pos?.coords.latitude ?? null,
        geo_lng: pos?.coords.longitude ?? null,
        geo_pontossag_m: pos?.coords.accuracy ?? null,
        horgony_egyezes: matched,
        user_agent: navigator.userAgent,
      };
      if (!navigator.onLine) {
        await enqueueAttendance(payload);
        setPending(await pendingCount());
        toast.success("Offline rögzítve — szinkronizálás visszakapcsoláskor");
        return;
      }
      const { error } = await (supabase.from("attendance_events") as any).insert(payload);
      if (error) {
        // fallback to offline queue
        await enqueueAttendance(payload);
        setPending(await pendingCount());
        toast.warning("Hálózati hiba — offline puffer használva");
        return;
      }
      toast.success(matched ? "Rögzítve (telephely-egyezés ✓)" : "Rögzítve (telephelyen kívül!)");
      void load();
    } catch (e) {
      toast.error(humanizeError(e as Error, t));
    } finally {
      setSubmitting(false);
    }
  }

  async function flushNow() {
    const r = await flushAttendance();
    if (r.ok > 0) toast.success(`${r.ok} esemény szinkronizálva`);
    if (r.fail > 0) toast.error(`${r.fail} sikertelen — próbálja újra`);
    setPending(await pendingCount());
    void load();
  }

  if (loading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const helyConsent = hasActiveConsent("jelenlet_helymeghatarozas");
  const eszkozConsent = hasActiveConsent("jelenlet_eszkozazonosito");
  const canRecord = !!helyConsent && !!eszkozConsent;
  const lastEvent = events[0];

  return (
    <div className="space-y-6 p-6 max-w-4xl">
      <div className="flex items-center gap-3">
        <MapPin className="h-6 w-6 text-primary" />
        <div className="flex-1">
          <h1 className="text-2xl font-semibold">Jelenléti rögzítés</h1>
          <p className="text-sm text-muted-foreground">PWA bejelentkezés/kijelentkezés GPS-anti-spoof ellenőrzéssel</p>
        </div>
        <div className="flex items-center gap-2 text-xs">
          {!online && (
            <span className="flex items-center gap-1 rounded border border-amber-500/40 bg-amber-500/10 text-amber-700 px-2 py-1">
              <WifiOff className="h-3 w-3" /> Offline
            </span>
          )}
          {pending > 0 && (
            <button onClick={flushNow} disabled={!online}
              className="flex items-center gap-1 rounded border border-primary/40 bg-primary/10 text-primary px-2 py-1 hover:bg-primary/20 disabled:opacity-50">
              <CloudUpload className="h-3 w-3" /> {pending} függő · szinkronizálás
            </button>
          )}
        </div>
      </div>

      {/* GDPR Consent Card */}
      <div className="rounded-lg border bg-card p-4 space-y-3">
        <div className="flex items-center gap-2">
          <ShieldCheck className="h-5 w-5 text-primary" />
          <h2 className="font-medium">GDPR-hozzájárulás</h2>
        </div>
        <p className="text-xs text-muted-foreground leading-relaxed">{CONSENT_TEXT}</p>
        <div className="text-[10px] font-mono text-muted-foreground">Verzió: {CONSENT_VERSION}</div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <ConsentRow
            label="Helymeghatározás (GPS)"
            consent={helyConsent}
            onGrant={() => grantConsent("jelenlet_helymeghatarozas")}
            onRevoke={() => helyConsent && revokeConsent(helyConsent.id)}
          />
          <ConsentRow
            label="Eszközazonosító (IP, UA)"
            consent={eszkozConsent}
            onGrant={() => grantConsent("jelenlet_eszkozazonosito")}
            onRevoke={() => eszkozConsent && revokeConsent(eszkozConsent.id)}
          />
        </div>
      </div>

      {/* Clock buttons */}
      <div className="rounded-lg border bg-card p-4 space-y-3">
        <div className="text-sm text-muted-foreground">
          Utolsó esemény:{" "}
          {lastEvent ? (
            <span className="font-mono">
              {lastEvent.esemeny_tipus} — {new Date(lastEvent.idopont).toLocaleString("hu-HU")}
              {lastEvent.horgony_egyezes === true && " ✓"}
              {lastEvent.horgony_egyezes === false && " ⚠"}
            </span>
          ) : (
            <span className="italic">nincs</span>
          )}
        </div>
        {!canRecord && (
          <div className="flex items-center gap-2 rounded border border-amber-500/30 bg-amber-500/5 p-2 text-xs text-amber-700 dark:text-amber-400">
            <AlertTriangle className="h-4 w-4" />
            Először adja meg mindkét GDPR-hozzájárulást fent.
          </div>
        )}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          <ClockBtn icon={LogIn} label="Bejelentkezés" onClick={() => record("bejelentkezes")} disabled={!canRecord || submitting} variant="primary" />
          <ClockBtn icon={Coffee} label="Szünet kezdet" onClick={() => record("szunet_kezdet")} disabled={!canRecord || submitting} />
          <ClockBtn icon={Coffee} label="Szünet vége" onClick={() => record("szunet_veg")} disabled={!canRecord || submitting} />
          <ClockBtn icon={LogOut} label="Kijelentkezés" onClick={() => record("kijelentkezes")} disabled={!canRecord || submitting} variant="danger" />
        </div>
      </div>

      {/* Recent events */}
      <div className="rounded-lg border bg-card">
        <div className="px-4 py-3 border-b text-sm font-medium">Utolsó 14 nap eseményei</div>
        <div className="divide-y">
          {events.length === 0 && <div className="p-4 text-sm text-muted-foreground italic">Nincs esemény</div>}
          {events.map((e) => (
            <div key={e.id} className="px-4 py-2 flex items-center gap-3 text-sm">
              <span
                className={cn(
                  "px-2 py-0.5 rounded text-xs font-mono",
                  e.esemeny_tipus === "bejelentkezes" && "bg-emerald-500/10 text-emerald-700 dark:text-emerald-400",
                  e.esemeny_tipus === "kijelentkezes" && "bg-rose-500/10 text-rose-700 dark:text-rose-400",
                  e.esemeny_tipus.startsWith("szunet") && "bg-amber-500/10 text-amber-700 dark:text-amber-400",
                  e.esemeny_tipus === "manualis_korrekcio" && "bg-blue-500/10 text-blue-700 dark:text-blue-400",
                )}
              >
                {e.esemeny_tipus}
              </span>
              <span className="font-mono text-xs">{new Date(e.idopont).toLocaleString("hu-HU")}</span>
              <span className="text-xs text-muted-foreground">{e.modszer}</span>
              {e.horgony_egyezes === true && <span className="text-xs text-emerald-600">✓ telephely</span>}
              {e.horgony_egyezes === false && <span className="text-xs text-amber-600">⚠ telephelyen kívül</span>}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function ConsentRow({
  label,
  consent,
  onGrant,
  onRevoke,
}: {
  label: string;
  consent: Consent | undefined;
  onGrant: () => void;
  onRevoke: () => void;
}) {
  return (
    <div className="flex items-center justify-between rounded border bg-background p-2">
      <div>
        <div className="text-sm">{label}</div>
        <div className="text-[10px] text-muted-foreground font-mono">
          {consent ? `✓ ${new Date(consent.elfogadva_at).toLocaleDateString("hu-HU")}` : "nincs hozzájárulás"}
        </div>
      </div>
      {consent ? (
        <button onClick={onRevoke} className="text-xs px-2 py-1 rounded border border-rose-500/30 text-rose-600 hover:bg-rose-500/10">
          Visszavonás
        </button>
      ) : (
        <button onClick={onGrant} className="text-xs px-2 py-1 rounded bg-primary text-primary-foreground hover:opacity-90">
          Elfogadom
        </button>
      )}
    </div>
  );
}

function ClockBtn({
  icon: Icon,
  label,
  onClick,
  disabled,
  variant,
}: {
  icon: typeof LogIn;
  label: string;
  onClick: () => void;
  disabled?: boolean;
  variant?: "primary" | "danger";
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={cn(
        "flex flex-col items-center gap-1 rounded-lg border p-3 text-sm transition disabled:opacity-40 disabled:cursor-not-allowed",
        variant === "primary" && "bg-primary text-primary-foreground border-primary hover:opacity-90",
        variant === "danger" && "bg-rose-600 text-white border-rose-600 hover:opacity-90",
        !variant && "bg-background hover:bg-accent",
      )}
    >
      <Icon className="h-5 w-5" />
      {label}
    </button>
  );
}
