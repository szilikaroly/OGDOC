import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useMemo, useState } from "react";
import { AlertTriangle, CheckCircle2, Download, FileSpreadsheet, FileText, ListChecks, Loader2, Lock, Plus, Search, Siren, Star, Trash2, Upload, UserCheck, X } from "lucide-react";
import {
  approveCase,
  bulkImportCases,
  cancelCase,
  createCase,
  listSeniorOperators,
  listSurgeryTypes,
  listWaitlist,
  searchPatients,
  triggerEmergency,
  updateCase,
} from "@/lib/or/board.functions";
import type { BulkImportResult } from "@/lib/or/board.functions";

import { usePermissions } from "@/hooks/use-permissions";
import { supabase } from "@/integrations/supabase/client";
import { toCsv, downloadCsv } from "@/lib/csv";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/muteti-terv/varolista")({
  component: WaitlistPage,
  head: () => ({ meta: [{ title: "Műtéti várólista" }] }),
});

type Prio = "elektiv" | "sürgos" | "azonnali";
type Status = "tervezett" | "jovahagyott" | "folyamatban" | "elvegzett" | "elhalasztott" | "torolt";

const PRIO_STYLE: Record<Prio, string> = {
  azonnali: "bg-destructive text-destructive-foreground",
  sürgos: "bg-warning/20 text-warning-foreground",
  elektiv: "bg-secondary text-muted-foreground",
};

const STATUS_STYLE: Record<Status, string> = {
  tervezett: "bg-secondary text-muted-foreground",
  jovahagyott: "bg-primary/15 text-primary",
  folyamatban: "bg-blue-500/15 text-blue-600",
  elvegzett: "bg-emerald-500/15 text-emerald-700",
  elhalasztott: "bg-warning/15 text-warning-foreground",
  torolt: "bg-muted text-muted-foreground line-through",
};

function WaitlistPage() {
  const { can, canReal, loading: permLoading } = usePermissions();
  const qc = useQueryClient();

  const [search, setSearch] = useState("");
  const [prioritas, setPrioritas] = useState<Prio | "">("");
  const [statusz, setStatusz] = useState<Status | "">("");
  const [csakVarolista, setCsakVarolista] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [showImport, setShowImport] = useState(false);

  const list = useServerFn(listWaitlist);
  const upd = useServerFn(updateCase);
  const appr = useServerFn(approveCase);
  const cancel = useServerFn(cancelCase);
  const emerg = useServerFn(triggerEmergency);

  const { data, isLoading } = useQuery({
    queryKey: ["or-waitlist", { search, prioritas, statusz, csakVarolista }],
    queryFn: () =>
      list({
        data: {
          search: search || null,
          prioritas: (prioritas || null) as Prio | null,
          statusz: (statusz || null) as Status | null,
          csakVarolista,
        },
      }),
  });

  useEffect(() => {
    const channel = supabase
      .channel("or-waitlist")
      .on("postgres_changes", { event: "*", schema: "public", table: "surgery_cases" }, () =>
        qc.invalidateQueries({ queryKey: ["or-waitlist"] }),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [qc]);

  const updMut = useMutation({
    mutationFn: (input: { id: string; patch: Partial<{ prioritas: Prio; statusz: Status; becsult_idotartam_perc: number; megjegyzes: string | null; kiemelt: boolean; delegalt_operator_id: string | null }> }) =>
      upd({ data: { id: input.id, ...input.patch } }),
    onSuccess: () => {
      toast.success("Frissítve");
      qc.invalidateQueries({ queryKey: ["or-waitlist"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const listOps = useServerFn(listSeniorOperators);
  const { data: seniorOps } = useQuery({
    queryKey: ["senior-operators"],
    queryFn: () => listOps(),
  });


  const apprMut = useMutation({
    mutationFn: (id: string) => appr({ data: { id } }),
    onSuccess: () => {
      toast.success("Jóváhagyva");
      qc.invalidateQueries({ queryKey: ["or-waitlist"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const cancelMut = useMutation({
    mutationFn: (id: string) => cancel({ data: { id } }),
    onSuccess: () => {
      toast.success("Törölve");
      qc.invalidateQueries({ queryKey: ["or-waitlist"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const emergMut = useMutation({
    mutationFn: (id: string) => emerg({ data: { caseId: id } }),
    onSuccess: () => toast.success("Sürgősségi push elindítva"),
    onError: (e: Error) => toast.error(e.message),
  });

  const patientMap = useMemo(() => new Map((data?.patients ?? []).map((p) => [p.id, p])), [data?.patients]);
  const typeMap = useMemo(() => new Map((data?.types ?? []).map((t) => [t.id, t])), [data?.types]);

  const importFn = useServerFn(bulkImportCases);
  const [importResult, setImportResult] = useState<BulkImportResult | null>(null);
  const [importSummary, setImportSummary] = useState<BulkImportResult | null>(null);

  const importMut = useMutation({
    mutationFn: (rows: ImportRow[]) => importFn({ data: { rows } }),
    onSuccess: (r) => {
      setImportResult(r);
      setImportSummary(r);
      if (r.created > 0) {
        toast.success(`${r.created} eset importálva${r.errors.length ? ` (${r.errors.length} hibás sor)` : ""}`);
        qc.invalidateQueries({ queryKey: ["or-waitlist"] });
      } else if (r.errors.length) {
        toast.error(`Egy sort sem sikerült importálni (${r.errors.length} hiba)`);
      }
    },
    onError: (e: Error) => toast.error(e.message),
  });

  async function handleImport(file: File) {
    try {
      const text = await file.text();
      const rows = parseImportCsv(text);
      if (rows.length === 0) {
        toast.error("Üres vagy érvénytelen CSV");
        return;
      }
      await importMut.mutateAsync(rows);
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  if (permLoading) return <div className="p-8 text-sm text-muted-foreground">Jogosultságok betöltése…</div>;
  if (!canReal("view_or_board")) {
    return (
      <div className="p-8">
        <div className="inline-flex items-center gap-2 rounded-md border border-border bg-card px-4 py-3 text-sm">
          <Lock className="size-4" /> Nincs jogosultsága a műtéti várólista megtekintéséhez.
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-4">
      <header className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <ListChecks className="size-5" /> Műtéti várólista
          </h1>
          <p className="mt-1 text-xs font-mono text-muted-foreground uppercase tracking-wider">
            Esetek karbantartása · prioritás · jóváhagyás · sürgős átminősítés
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={() => exportCsv(data?.cases ?? [], patientMap, typeMap)}
            disabled={!data?.cases.length}
            className="inline-flex items-center gap-1.5 h-9 px-3 rounded-md border border-border text-sm hover:bg-secondary disabled:opacity-50"
          >
            <Download className="size-3.5" /> CSV
          </button>
          <button
            type="button"
            onClick={() => exportPdf(data?.cases ?? [], patientMap, typeMap, { search, prioritas, statusz, csakVarolista })}
            disabled={!data?.cases.length}
            className="inline-flex items-center gap-1.5 h-9 px-3 rounded-md border border-border text-sm hover:bg-secondary disabled:opacity-50"
          >
            <FileText className="size-3.5" /> PDF
          </button>
          {can("book_or_case") && (
            <>
              <button
                type="button"
                onClick={() => setShowImport(true)}
                className="inline-flex items-center gap-1.5 h-9 px-3 rounded-md border border-border text-sm hover:bg-secondary"
              >
                <Upload className="size-3.5" /> Import
              </button>
              <button
                type="button"
                onClick={() => setShowCreate(true)}
                className="inline-flex items-center gap-2 h-9 px-3 rounded-md bg-primary text-primary-foreground text-sm font-semibold hover:opacity-90"
              >
                <Plus className="size-4" /> Új eset
              </button>
            </>
          )}
        </div>
      </header>

      {importSummary && (
        <div
          className={cn(
            "flex items-center justify-between rounded-lg border px-4 py-3 text-sm",
            importSummary.created > 0 && importSummary.errors.length === 0
              ? "bg-emerald-50 border-emerald-200 text-emerald-800"
              : importSummary.created > 0
                ? "bg-amber-50 border-amber-200 text-amber-800"
                : "bg-red-50 border-red-200 text-red-800"
          )}
        >
          <div className="flex items-center gap-2">
            {importSummary.created > 0 && importSummary.errors.length === 0 ? (
              <CheckCircle2 className="size-4 text-emerald-600" />
            ) : (
              <AlertTriangle className={cn("size-4", importSummary.created > 0 ? "text-amber-600" : "text-red-600")} />
            )}
            <span>
              <strong>{importSummary.created}</strong> sor importálva sikeresen
              {importSummary.errors.length > 0 && (
                <>, <strong>{importSummary.errors.length}</strong> sor hibás</>
              )}
              .
            </span>
          </div>
          <button
            type="button"
            onClick={() => setImportSummary(null)}
            className="rounded p-1 hover:bg-black/5 text-current"
            title="Bezárás"
          >
            <X className="size-4" />
          </button>
        </div>
      )}

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-2 rounded-lg border border-border bg-card p-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="size-3.5 absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Páciens, TAJ, megjegyzés…"
            className="h-9 w-full rounded-md border border-border bg-background pl-7 pr-3 text-sm"
          />
        </div>
        <select
          value={prioritas}
          onChange={(e) => setPrioritas(e.target.value as Prio | "")}
          className="h-9 rounded-md border border-border bg-background px-2 text-sm"
        >
          <option value="">Minden prioritás</option>
          <option value="azonnali">Azonnali</option>
          <option value="sürgos">Sürgős</option>
          <option value="elektiv">Elektív</option>
        </select>
        <select
          value={statusz}
          onChange={(e) => setStatusz(e.target.value as Status | "")}
          className="h-9 rounded-md border border-border bg-background px-2 text-sm"
        >
          <option value="">Minden státusz</option>
          <option value="tervezett">Tervezett</option>
          <option value="jovahagyott">Jóváhagyott</option>
          <option value="folyamatban">Folyamatban</option>
          <option value="elvegzett">Elvégzett</option>
          <option value="elhalasztott">Elhalasztott</option>
          <option value="torolt">Törölt</option>
        </select>
        <label className="inline-flex items-center gap-1.5 text-xs">
          <input
            type="checkbox"
            checked={csakVarolista}
            onChange={(e) => setCsakVarolista(e.target.checked)}
          />
          Csak még be nem osztott
        </label>
      </div>

      {/* Table */}
      <div className="rounded-lg border border-border bg-card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-secondary/40 text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="text-left px-3 py-2">Páciens</th>
              <th className="text-left px-3 py-2">Beavatkozás</th>
              <th className="text-left px-3 py-2">Időtartam</th>
              <th className="text-left px-3 py-2">Prioritás</th>
              <th className="text-left px-3 py-2">Státusz</th>
              <th className="text-left px-3 py-2">Beosztás</th>
              <th className="text-right px-3 py-2">Műveletek</th>
            </tr>
          </thead>
          <tbody>
            {isLoading && (
              <tr><td colSpan={7} className="px-3 py-6 text-center text-muted-foreground">Betöltés…</td></tr>
            )}
            {!isLoading && (data?.cases.length ?? 0) === 0 && (
              <tr><td colSpan={7} className="px-3 py-6 text-center text-muted-foreground italic">Nincs találat.</td></tr>
            )}
            {(data?.cases ?? []).map((c) => {
              const p = c.patient_id ? patientMap.get(c.patient_id) : null;
              const t = c.surgery_type_id ? typeMap.get(c.surgery_type_id) : null;
              const meta = c as typeof c & { conflict_flags?: string[]; requirements?: string[]; delegation_required?: boolean };
              const conflicts = meta.conflict_flags ?? [];
              const reqs = meta.requirements ?? [];
              const delegMissing = meta.delegation_required && !c.delegalt_operator_id;
              return (
                <tr
                  key={c.id}
                  className={cn(
                    "border-t border-border hover:bg-secondary/20",
                    conflicts.length > 0 && "bg-destructive/5",
                    delegMissing && conflicts.length === 0 && "bg-amber-50/40",
                  )}
                >
                  <td className="px-3 py-2">
                    <div className="font-semibold flex items-center gap-1.5 flex-wrap">
                      {p ? `${p.vezeteknev} ${p.keresztnev}` : "—"}
                      {can("book_or_case") ? (
                        <button
                          type="button"
                          title={c.kiemelt ? "Kiemelt — kattints a kikapcsoláshoz" : "Jelöld kiemeltnek"}
                          onClick={() =>
                            updMut.mutate({
                              id: c.id,
                              patch: { kiemelt: !c.kiemelt, ...(c.kiemelt ? { delegalt_operator_id: null } : {}) },
                            })
                          }
                          className={cn(
                            "inline-flex items-center rounded p-0.5 transition-colors",
                            c.kiemelt ? "text-amber-500 hover:text-amber-600" : "text-muted-foreground hover:text-amber-500",
                          )}
                        >
                          <Star className={cn("size-3.5", c.kiemelt && "fill-current")} />
                        </button>
                      ) : c.kiemelt ? (
                        <Star className="size-3.5 fill-current text-amber-500" />
                      ) : null}
                      {conflicts.length > 0 && (
                        <span
                          title={conflicts.join("\n")}
                          className="inline-flex items-center gap-0.5 text-[9px] font-mono uppercase bg-destructive/20 text-destructive rounded px-1.5 py-0.5 cursor-help"
                        >
                          <AlertTriangle className="size-2.5" /> {conflicts.length}
                        </span>
                      )}
                      {reqs.length > 0 && (
                        <span
                          title={reqs.join("\n")}
                          className="inline-flex items-center gap-0.5 text-[9px] font-mono uppercase bg-primary/10 text-primary rounded px-1.5 py-0.5 cursor-help"
                        >
                          {reqs.length} köv.
                        </span>
                      )}
                    </div>
                    {p?.taj && <div className="text-[10px] font-mono text-muted-foreground">TAJ: {p.taj}</div>}
                    {(c.kiemelt || meta.delegation_required) && can("book_or_case") && (
                      <div className="mt-1 flex items-center gap-1">
                        <UserCheck className={cn("size-3", delegMissing ? "text-destructive" : "text-muted-foreground")} />
                        <select
                          value={c.delegalt_operator_id ?? ""}
                          onChange={(e) =>
                            updMut.mutate({
                              id: c.id,
                              patch: { delegalt_operator_id: e.target.value || null },
                            })
                          }
                          className={cn(
                            "h-6 text-[10px] rounded border bg-background px-1 max-w-[160px]",
                            delegMissing ? "border-destructive" : "border-border",
                          )}
                        >
                          <option value="">— delegált operatőr —</option>
                          {(seniorOps ?? []).map((op) => (
                            <option key={op.id} value={op.id}>{op.teljes_nev ?? op.id.slice(0, 8)}</option>
                          ))}
                        </select>
                      </div>
                    )}
                  </td>
                  <td className="px-3 py-2">
                    <div className="text-xs">{t?.nev ?? "—"}</div>
                    {t?.kod && <div className="text-[10px] font-mono text-muted-foreground">{t.kod}</div>}
                  </td>
                  <td className="px-3 py-2 font-mono text-xs">
                    {c.becsult_idotartam_perc}p {c.posztop_apolasi_perc ? `+ ${c.posztop_apolasi_perc}p` : ""}
                  </td>

                  <td className="px-3 py-2">
                    {can("book_or_case") ? (
                      <select
                        value={c.prioritas}
                        onChange={(e) =>
                          updMut.mutate({ id: c.id, patch: { prioritas: e.target.value as Prio } })
                        }
                        className={cn("text-[10px] font-mono uppercase rounded px-1.5 py-0.5 border-0 cursor-pointer", PRIO_STYLE[c.prioritas as Prio])}
                      >
                        <option value="elektiv">elektiv</option>
                        <option value="sürgos">sürgos</option>
                        <option value="azonnali">azonnali</option>
                      </select>
                    ) : (
                      <span className={cn("text-[10px] font-mono uppercase rounded px-1.5 py-0.5", PRIO_STYLE[c.prioritas as Prio])}>
                        {c.prioritas}
                      </span>
                    )}
                  </td>
                  <td className="px-3 py-2">
                    <span className={cn("text-[10px] font-mono uppercase rounded px-1.5 py-0.5", STATUS_STYLE[c.statusz as Status])}>
                      {c.statusz}
                    </span>
                  </td>
                  <td className="px-3 py-2 text-xs">
                    {c.or_block_id ? (
                      <span className="text-emerald-600 font-semibold">Beosztva</span>
                    ) : (
                      <span className="text-muted-foreground italic">Várólistán</span>
                    )}
                  </td>
                  <td className="px-3 py-2 text-right space-x-1 whitespace-nowrap">
                    {can("trigger_or_emergency") && c.prioritas !== "azonnali" && c.statusz !== "torolt" && (
                      <button
                        type="button"
                        title="Sürgős → push"
                        onClick={() => emergMut.mutate(c.id)}
                        className="inline-flex items-center gap-1 text-[10px] font-bold uppercase bg-destructive/10 text-destructive hover:bg-destructive hover:text-destructive-foreground rounded px-2 py-1"
                      >
                        <Siren className="size-3" />
                      </button>
                    )}
                    {can("manage_or_blocks") && c.statusz === "tervezett" && (
                      <button
                        type="button"
                        title="Jóváhagyás"
                        onClick={() => apprMut.mutate(c.id)}
                        className="inline-flex items-center gap-1 text-[10px] font-bold uppercase bg-primary/10 text-primary hover:bg-primary hover:text-primary-foreground rounded px-2 py-1"
                      >
                        <CheckCircle2 className="size-3" />
                      </button>
                    )}
                    {can("book_or_case") && c.statusz !== "torolt" && c.statusz !== "elvegzett" && (
                      <button
                        type="button"
                        title="Törlés"
                        onClick={() => {
                          if (confirm("Biztosan törli az esetet?")) cancelMut.mutate(c.id);
                        }}
                        className="inline-flex items-center gap-1 text-[10px] font-bold uppercase bg-muted text-muted-foreground hover:bg-destructive hover:text-destructive-foreground rounded px-2 py-1"
                      >
                        <Trash2 className="size-3" />
                      </button>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {showImport && (
        <ImportDialog
          busy={importMut.isPending}
          onClose={() => setShowImport(false)}
          onSubmit={async (file) => {
            await handleImport(file);
            setShowImport(false);
          }}
        />
      )}

      {importResult && (
        <ImportResultDialog result={importResult} onClose={() => setImportResult(null)} />
      )}

      {showCreate && (
        <CreateCaseDialog
          onClose={() => setShowCreate(false)}
          onCreated={() => {
            setShowCreate(false);
            qc.invalidateQueries({ queryKey: ["or-waitlist"] });
          }}
        />
      )}
    </div>
  );
}

function CreateCaseDialog({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const create = useServerFn(createCase);
  const searchP = useServerFn(searchPatients);
  const listTypes = useServerFn(listSurgeryTypes);
  const listOps = useServerFn(listSeniorOperators);

  const [patientTerm, setPatientTerm] = useState("");
  const [patientId, setPatientId] = useState<string | null>(null);
  const [patientLabel, setPatientLabel] = useState("");
  const [surgeryTypeId, setSurgeryTypeId] = useState<string>("");
  const [duration, setDuration] = useState(60);
  const [posztop, setPosztop] = useState(15);
  const [prioritas, setPrioritas] = useState<Prio>("elektiv");
  const [megjegyzes, setMegjegyzes] = useState("");
  const [kiemelt, setKiemelt] = useState(false);
  const [delegaltOperatorId, setDelegaltOperatorId] = useState<string>("");

  const { data: types } = useQuery({ queryKey: ["surgery-types"], queryFn: () => listTypes() });
  const { data: seniorOps } = useQuery({ queryKey: ["senior-operators"], queryFn: () => listOps() });
  const { data: patients } = useQuery({
    queryKey: ["patients-search", patientTerm],
    queryFn: () => (patientTerm.length >= 2 ? searchP({ data: { term: patientTerm } }) : Promise.resolve([])),
    enabled: patientTerm.length >= 2,
  });

  const createMut = useMutation({
    mutationFn: () =>
      create({
        data: {
          patient_id: patientId!,
          surgery_type_id: surgeryTypeId || null,
          becsult_idotartam_perc: duration,
          posztop_apolasi_perc: posztop,
          prioritas,
          megjegyzes: megjegyzes || null,
          kiemelt,
          delegalt_operator_id: kiemelt && delegaltOperatorId ? delegaltOperatorId : null,
        },
      }),

    onSuccess: () => {
      toast.success("Eset létrehozva");
      onCreated();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  function pickType(id: string) {
    setSurgeryTypeId(id);
    const t = types?.find((x) => x.id === id);
    if (t) {
      setDuration(t.becsult_idotartam_perc);
      setPosztop(t.posztop_apolasi_perc);
    }
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={onClose}>
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-lg rounded-lg border border-border bg-card shadow-xl"
      >
        <div className="flex items-center justify-between px-4 py-3 border-b border-border">
          <h2 className="font-bold">Új műtéti eset</h2>
          <button type="button" onClick={onClose} className="text-muted-foreground hover:text-foreground">
            <X className="size-4" />
          </button>
        </div>
        <div className="p-4 space-y-3 text-sm">
          <div>
            <label className="text-xs font-mono uppercase text-muted-foreground">Páciens *</label>
            {patientId ? (
              <div className="mt-1 flex items-center justify-between rounded-md border border-border bg-background px-3 py-2">
                <span className="font-semibold">{patientLabel}</span>
                <button
                  type="button"
                  onClick={() => {
                    setPatientId(null);
                    setPatientLabel("");
                    setPatientTerm("");
                  }}
                  className="text-xs text-muted-foreground hover:text-destructive"
                >
                  Csere
                </button>
              </div>
            ) : (
              <>
                <input
                  value={patientTerm}
                  onChange={(e) => setPatientTerm(e.target.value)}
                  placeholder="Név vagy TAJ kereséshez (min. 2 karakter)"
                  className="mt-1 h-9 w-full rounded-md border border-border bg-background px-3"
                />
                {(patients?.length ?? 0) > 0 && (
                  <ul className="mt-1 rounded-md border border-border bg-background max-h-40 overflow-y-auto">
                    {patients!.map((p) => (
                      <li key={p.id}>
                        <button
                          type="button"
                          onClick={() => {
                            setPatientId(p.id);
                            setPatientLabel(`${p.vezeteknev} ${p.keresztnev}${p.taj ? ` · ${p.taj}` : ""}`);
                          }}
                          className="w-full text-left px-3 py-1.5 hover:bg-secondary text-xs"
                        >
                          <span className="font-semibold">{p.vezeteknev} {p.keresztnev}</span>
                          {p.taj && <span className="ml-2 font-mono text-muted-foreground">{p.taj}</span>}
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
              </>
            )}
          </div>

          <div>
            <label className="text-xs font-mono uppercase text-muted-foreground">Beavatkozás</label>
            <select
              value={surgeryTypeId}
              onChange={(e) => pickType(e.target.value)}
              className="mt-1 h-9 w-full rounded-md border border-border bg-background px-2"
            >
              <option value="">— válassz —</option>
              {(types ?? []).map((t) => (
                <option key={t.id} value={t.id}>{t.nev}{t.kod ? ` (${t.kod})` : ""}</option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-3 gap-2">
            <div>
              <label className="text-xs font-mono uppercase text-muted-foreground">Időtartam (p)</label>
              <input
                type="number"
                min={1}
                value={duration}
                onChange={(e) => setDuration(Number(e.target.value))}
                className="mt-1 h-9 w-full rounded-md border border-border bg-background px-3"
              />
            </div>
            <div>
              <label className="text-xs font-mono uppercase text-muted-foreground">Posztop (p)</label>
              <input
                type="number"
                min={0}
                value={posztop}
                onChange={(e) => setPosztop(Number(e.target.value))}
                className="mt-1 h-9 w-full rounded-md border border-border bg-background px-3"
              />
            </div>
            <div>
              <label className="text-xs font-mono uppercase text-muted-foreground">Prioritás</label>
              <select
                value={prioritas}
                onChange={(e) => setPrioritas(e.target.value as Prio)}
                className="mt-1 h-9 w-full rounded-md border border-border bg-background px-2"
              >
                <option value="elektiv">Elektív</option>
                <option value="sürgos">Sürgős</option>
                <option value="azonnali">Azonnali</option>
              </select>
            </div>
          </div>

          <div>
            <label className="text-xs font-mono uppercase text-muted-foreground">Megjegyzés</label>
            <textarea
              value={megjegyzes}
              onChange={(e) => setMegjegyzes(e.target.value)}
              rows={2}
              className="mt-1 w-full rounded-md border border-border bg-background px-3 py-2"
            />
          </div>

          <div className="rounded-md border border-border bg-secondary/30 p-2 space-y-2">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={kiemelt}
                onChange={(e) => {
                  setKiemelt(e.target.checked);
                  if (!e.target.checked) setDelegaltOperatorId("");
                }}
              />
              <Star className={cn("size-3.5", kiemelt ? "fill-amber-500 text-amber-500" : "text-muted-foreground")} />
              <span className="text-xs font-semibold">Kiemelt nagy műtét</span>
            </label>
            {kiemelt && (
              <div>
                <label className="text-xs font-mono uppercase text-muted-foreground">Delegált operatőr</label>
                <select
                  value={delegaltOperatorId}
                  onChange={(e) => setDelegaltOperatorId(e.target.value)}
                  className="mt-1 h-9 w-full rounded-md border border-border bg-background px-2 text-sm"
                >
                  <option value="">— válassz szenior operatőrt —</option>
                  {(seniorOps ?? []).map((op) => (
                    <option key={op.id} value={op.id}>{op.teljes_nev ?? op.id.slice(0, 8)}</option>
                  ))}
                </select>
              </div>
            )}
          </div>
        </div>

        <div className="px-4 py-3 border-t border-border flex justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            className="h-9 px-3 rounded-md border border-border text-sm hover:bg-secondary"
          >
            Mégse
          </button>
          <button
            type="button"
            disabled={!patientId || duration < 1 || createMut.isPending}
            onClick={() => createMut.mutate()}
            className="h-9 px-3 rounded-md bg-primary text-primary-foreground text-sm font-semibold disabled:opacity-50"
          >
            Létrehozás
          </button>
        </div>
      </div>
    </div>
  );
}

// ===== Export / Import helpers =====

type PatientLite = { id: string; vezeteknev: string; keresztnev: string; taj: string | null; szuletesi_datum: string | null };
type TypeLite = { id: string; nev: string; kod: string | null; becsult_idotartam_perc: number };
type CaseLite = {
  id: string;
  patient_id: string | null;
  surgery_type_id: string | null;
  or_block_id: string | null;
  becsult_idotartam_perc: number;
  posztop_apolasi_perc: number;
  prioritas: string;
  statusz: string;
  tervezett_kezdo_ido: string | null;
  megjegyzes: string | null;
  created_at: string;
  kiemelt?: boolean | null;
  delegalt_operator_id?: string | null;
};


type ImportRow = {
  taj: string;
  surgery_type_kod: string | null;
  becsult_idotartam_perc: number;
  posztop_apolasi_perc?: number;
  prioritas: "elektiv" | "sürgos" | "azonnali";
  megjegyzes: string | null;
};

function rowsToFlat(cases: CaseLite[], patients: Map<string, PatientLite>, types: Map<string, TypeLite>) {
  return cases.map((c) => {
    const p = c.patient_id ? patients.get(c.patient_id) : undefined;
    const t = c.surgery_type_id ? types.get(c.surgery_type_id) : undefined;
    return {
      taj: p?.taj ?? "",
      vezeteknev: p?.vezeteknev ?? "",
      keresztnev: p?.keresztnev ?? "",
      surgery_type_kod: t?.kod ?? "",
      surgery_type_nev: t?.nev ?? "",
      becsult_idotartam_perc: c.becsult_idotartam_perc,
      posztop_apolasi_perc: c.posztop_apolasi_perc,
      prioritas: c.prioritas,
      statusz: c.statusz,
      beosztva: c.or_block_id ? "igen" : "nem",
      megjegyzes: c.megjegyzes ?? "",
      created_at: c.created_at,
    };
  });
}

function exportCsv(cases: CaseLite[], patients: Map<string, PatientLite>, types: Map<string, TypeLite>) {
  const flat = rowsToFlat(cases, patients, types);
  const csv = toCsv(flat);
  const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-");
  downloadCsv(`varolista-${stamp}.csv`, csv);
}

function exportPdf(
  cases: CaseLite[],
  patients: Map<string, PatientLite>,
  types: Map<string, TypeLite>,
  filters: { search: string; prioritas: string; statusz: string; csakVarolista: boolean },
) {
  const flat = rowsToFlat(cases, patients, types);
  const stamp = new Date().toLocaleString("hu-HU");
  const filterChips: string[] = [];
  if (filters.search) filterChips.push(`Keresés: "${filters.search}"`);
  if (filters.prioritas) filterChips.push(`Prioritás: ${filters.prioritas}`);
  if (filters.statusz) filterChips.push(`Státusz: ${filters.statusz}`);
  if (filters.csakVarolista) filterChips.push("Csak nem beosztott");
  const esc = (s: unknown) =>
    String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));
  const rowsHtml = flat
    .map(
      (r) => `<tr>
      <td>${esc(r.vezeteknev)} ${esc(r.keresztnev)}<br><span class="m">${esc(r.taj)}</span></td>
      <td>${esc(r.surgery_type_nev)}<br><span class="m">${esc(r.surgery_type_kod)}</span></td>
      <td class="r">${r.becsult_idotartam_perc}p${r.posztop_apolasi_perc ? ` +${r.posztop_apolasi_perc}p` : ""}</td>
      <td><span class="b b-${esc(r.prioritas)}">${esc(r.prioritas)}</span></td>
      <td><span class="b">${esc(r.statusz)}</span></td>
      <td>${esc(r.beosztva)}</td>
      <td>${esc(r.megjegyzes)}</td>
    </tr>`,
    )
    .join("");
  const prioCount = flat.reduce(
    (acc, r) => ((acc[r.prioritas] = (acc[r.prioritas] ?? 0) + 1), acc),
    {} as Record<string, number>,
  );
  const totalMin = flat.reduce((s, r) => s + r.becsult_idotartam_perc + (r.posztop_apolasi_perc || 0), 0);
  const summary = [
    `${flat.length} eset`,
    `Σ ${Math.round(totalMin / 60)} óra ${totalMin % 60} perc`,
    prioCount["azonnali"] ? `${prioCount["azonnali"]} azonnali` : "",
    prioCount["sürgos"] ? `${prioCount["sürgos"]} sürgős` : "",
    prioCount["elektiv"] ? `${prioCount["elektiv"]} elektív` : "",
  ].filter(Boolean);

  const html = `<!doctype html><html lang="hu"><head><meta charset="utf-8"><title>Műtéti várólista — ${stamp}</title>
    <style>
      @page { size: A4 landscape; margin: 12mm 10mm 16mm 10mm; }
      *{box-sizing:border-box}
      html,body{margin:0;padding:0}
      body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',system-ui,sans-serif;color:#111;font-size:10.5px;line-height:1.35;-webkit-print-color-adjust:exact;print-color-adjust:exact}
      .page{padding:16px 18px 24px}
      header{display:flex;align-items:flex-end;justify-content:space-between;gap:16px;border-bottom:2px solid #111;padding-bottom:8px;margin-bottom:10px}
      h1{font-size:18px;margin:0;letter-spacing:-.01em}
      .sub{font-size:9px;color:#555;text-transform:uppercase;letter-spacing:.08em;margin-top:2px}
      .meta{text-align:right;font-size:9.5px;color:#555;line-height:1.45}
      .meta strong{color:#111}
      .chips{margin:6px 0 10px;display:flex;flex-wrap:wrap;gap:4px}
      .chip{display:inline-block;background:#f0f3ff;color:#1f2a5e;padding:2px 8px;border-radius:10px;font-size:9px;border:1px solid #d6def5}
      .summary{display:flex;gap:14px;font-size:10px;color:#333;margin-bottom:10px;padding:6px 10px;background:#fafafa;border:1px solid #eee;border-radius:4px}
      .summary b{color:#111}
      table{width:100%;border-collapse:collapse;table-layout:fixed}
      col.c-pat{width:18%} col.c-int{width:22%} col.c-dur{width:8%} col.c-pri{width:9%} col.c-st{width:11%} col.c-bo{width:7%} col.c-meg{width:25%}
      thead{display:table-header-group}
      tfoot{display:table-footer-group}
      tr{page-break-inside:avoid}
      th,td{border:1px solid #d8d8d8;padding:5px 7px;text-align:left;vertical-align:top;overflow-wrap:anywhere;word-break:break-word}
      th{background:#1f2937;color:#fff;font-size:8.5px;text-transform:uppercase;letter-spacing:.06em;font-weight:600;border-color:#1f2937}
      tbody tr:nth-child(even) td{background:#fafbfc}
      td.r{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap;font-size:10px}
      .m{color:#777;font-size:8.5px;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;display:block;margin-top:1px}
      .b{display:inline-block;font-size:8.5px;font-weight:600;text-transform:uppercase;letter-spacing:.05em;padding:1px 6px;border-radius:8px;background:#eee;color:#333;border:1px solid #ddd}
      .b-azonnali{background:#fee2e2;color:#991b1b;border-color:#fca5a5}
      .b-sürgos{background:#fef3c7;color:#92400e;border-color:#fcd34d}
      .b-elektiv{background:#e0e7ff;color:#3730a3;border-color:#c7d2fe}
      footer{position:fixed;bottom:6mm;left:10mm;right:10mm;border-top:1px solid #ddd;padding-top:4px;font-size:8.5px;color:#777;display:flex;justify-content:space-between}
      .toolbar{position:sticky;top:0;background:#fff;padding:10px 0;border-bottom:1px solid #eee;margin-bottom:10px;display:flex;gap:8px;align-items:center}
      .toolbar button{padding:6px 14px;border:1px solid #111;background:#111;color:#fff;border-radius:4px;cursor:pointer;font-size:11px;font-weight:600}
      .toolbar button.alt{background:#fff;color:#111}
      @media print{ .toolbar,.no-print{display:none!important} .page{padding:0} }
      @media screen{ body{background:#f5f5f5} .page{max-width:1180px;margin:16px auto;background:#fff;box-shadow:0 1px 4px rgba(0,0,0,.08);border-radius:4px} }
    </style></head><body>
    <div class="page">
      <div class="toolbar no-print">
        <button onclick="window.print()">Nyomtatás / PDF mentés</button>
        <button class="alt" onclick="window.close()">Bezárás</button>
      </div>
      <header>
        <div>
          <h1>Műtéti várólista</h1>
          <div class="sub">Operating Room — Waitlist Report</div>
        </div>
        <div class="meta">
          <div>Exportálva: <strong>${esc(stamp)}</strong></div>
          <div>Esetek: <strong>${flat.length}</strong></div>
        </div>
      </header>
      ${filterChips.length ? `<div class="chips">${filterChips.map((c) => `<span class="chip">${esc(c)}</span>`).join("")}</div>` : ""}
      <div class="summary">${summary.map((s) => `<span><b>${esc(s)}</b></span>`).join("")}</div>
      <table>
        <colgroup>
          <col class="c-pat"><col class="c-int"><col class="c-dur"><col class="c-pri"><col class="c-st"><col class="c-bo"><col class="c-meg">
        </colgroup>
        <thead><tr><th>Páciens</th><th>Beavatkozás</th><th>Időtartam</th><th>Prioritás</th><th>Státusz</th><th>Beosztva</th><th>Megjegyzés</th></tr></thead>
        <tbody>${rowsHtml || '<tr><td colspan="7" style="text-align:center;color:#888;padding:24px">Nincs adat</td></tr>'}</tbody>
      </table>
      <footer><span>Műtéti várólista — ${esc(stamp)}</span><span>${flat.length} eset</span></footer>
    </div>
    <script>setTimeout(()=>window.print(),350)<\/script>
    </body></html>`;
  const w = window.open("", "_blank", "width=1000,height=800");
  if (!w) {
    toast.error("Engedélyezze a felugró ablakokat a PDF exporthoz");
    return;
  }
  w.document.open();
  w.document.write(html);
  w.document.close();
}

function ImportDialog({
  busy,
  onClose,
  onSubmit,
}: {
  busy: boolean;
  onClose: () => void;
  onSubmit: (file: File) => void | Promise<void>;
}) {
  const [dragOver, setDragOver] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);

  function accept(f: File | null | undefined) {
    setError(null);
    if (!f) return;
    if (!/\.csv$/i.test(f.name) && f.type !== "text/csv" && f.type !== "application/vnd.ms-excel") {
      setError("Csak .csv fájlt lehet feltölteni");
      return;
    }
    if (f.size > 5 * 1024 * 1024) {
      setError("Fájl túl nagy (max. 5 MB)");
      return;
    }
    setFile(f);
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={busy ? undefined : onClose}>
      <div onClick={(e) => e.stopPropagation()} className="relative w-full max-w-lg rounded-lg border border-border bg-card shadow-xl overflow-hidden">
        {busy && (
          <div className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-3 bg-background/70 backdrop-blur-[2px]">
            <Loader2 className="size-8 animate-spin text-primary" />
            <div className="text-sm font-semibold text-foreground">Feldolgozás…</div>
            <div className="text-xs text-muted-foreground">Kérjük, várjon az eredményig</div>
          </div>
        )}
        <div className="flex items-center justify-between px-4 py-3 border-b border-border">
          <h2 className="font-bold inline-flex items-center gap-2"><Upload className="size-4" /> Várólista importálás</h2>
          <button type="button" disabled={busy} onClick={onClose} className="text-muted-foreground hover:text-foreground disabled:opacity-40">
            <X className="size-4" />
          </button>
        </div>
        <div className="p-4 space-y-3 text-sm">
          <label
            onDragOver={(e) => { if (!busy) { e.preventDefault(); setDragOver(true); } }}
            onDragLeave={() => setDragOver(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragOver(false);
              if (!busy) accept(e.dataTransfer.files?.[0]);
            }}
            className={cn(
              "block rounded-lg border-2 border-dashed px-6 py-10 text-center transition-colors",
              dragOver ? "border-primary bg-primary/5" : "border-border hover:border-primary/60 hover:bg-secondary/40",
              busy && "opacity-50 cursor-not-allowed",
            )}
          >
            <input
              type="file"
              accept=".csv,text/csv"
              className="hidden"
              disabled={busy}
              onChange={(e) => !busy && accept(e.target.files?.[0])}
            />
            <Upload className={cn("mx-auto mb-2 size-7", dragOver ? "text-primary" : "text-muted-foreground")} />
            <div className="text-sm font-semibold">
              {file ? file.name : "Húzd ide a CSV-t, vagy kattints a tallózáshoz"}
            </div>
            <div className="mt-1 text-[11px] text-muted-foreground">
              {file
                ? `${(file.size / 1024).toFixed(1)} KB · kattints másikért`
                : "Max. 5 MB · .csv · UTF-8 · ; vagy , elválasztó"}
            </div>
          </label>

          {error && (
            <div className="rounded-md border border-destructive/30 bg-destructive/10 text-destructive text-xs px-3 py-2">
              {error}
            </div>
          )}

          <div className="flex items-center justify-between gap-2">
            <details className="text-xs text-muted-foreground" open={!file}>
              <summary className={cn("cursor-pointer hover:text-foreground", busy && "pointer-events-none opacity-50")}>CSV formátum</summary>
              <pre className="mt-2 p-2 bg-secondary/40 rounded font-mono text-[10px] overflow-x-auto">taj;surgery_type_kod;becsult_idotartam_perc;posztop_apolasi_perc;prioritas;megjegyzes
123456789;CHOL;90;30;elektiv;Reggeli első műtét
234567890;APP;45;20;sürgos;</pre>
              <p className="mt-1">Kötelező: <code>taj</code>, <code>becsult_idotartam_perc</code>. Prioritás: <code>elektiv</code> / <code>sürgos</code> / <code>azonnali</code>.</p>
            </details>
            <button
              type="button"
              disabled={busy}
              onClick={() => {
                const sample = "taj;surgery_type_kod;becsult_idotartam_perc;posztop_apolasi_perc;prioritas;megjegyzes\n123456789;CHOL;90;30;elektiv;Reggeli első műtét\n234567890;APP;45;20;sürgos;";
                downloadCsv("varolista-minta.csv", sample);
              }}
              className="inline-flex items-center gap-1.5 h-8 px-2.5 rounded-md border border-border text-xs hover:bg-secondary whitespace-nowrap shrink-0 disabled:opacity-50"
            >
              <FileSpreadsheet className="size-3.5" /> Minta letöltése
            </button>
          </div>
        </div>
        <div className="px-4 py-3 border-t border-border flex justify-end gap-2">
          <button
            type="button"
            disabled={busy}
            onClick={onClose}
            className="h-9 px-3 rounded-md border border-border text-sm hover:bg-secondary disabled:opacity-50"
          >
            Mégse
          </button>
          <button
            type="button"
            disabled={!file || busy}
            onClick={() => file && onSubmit(file)}
            className="h-9 px-3 rounded-md bg-primary text-primary-foreground text-sm font-semibold disabled:opacity-50"
          >
            {busy ? "Feltöltés…" : "Feltöltés"}
          </button>
        </div>
      </div>
    </div>
  );
}

function ImportResultDialog({ result, onClose }: { result: BulkImportResult; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} className="w-full max-w-lg rounded-lg border border-border bg-card shadow-xl">
        <div className="flex items-center justify-between px-4 py-3 border-b border-border">
          <h2 className="font-bold">Import eredmény</h2>
          <button type="button" onClick={onClose} className="text-muted-foreground hover:text-foreground">
            <X className="size-4" />
          </button>
        </div>
        <div className="p-4 space-y-3 text-sm">
          <div className="flex gap-4">
            <div className="flex-1 rounded-md border border-border bg-emerald-500/10 p-3">
              <div className="text-2xl font-bold text-emerald-700">{result.created}</div>
              <div className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">Sikeresen létrehozva</div>
            </div>
            <div className="flex-1 rounded-md border border-border bg-destructive/10 p-3">
              <div className="text-2xl font-bold text-destructive">{result.errors.length}</div>
              <div className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">Hibás sor</div>
            </div>
          </div>
          {result.errors.length > 0 && (
            <div className="rounded-md border border-border max-h-60 overflow-y-auto">
              <table className="w-full text-xs">
                <thead className="bg-secondary/40 text-[10px] font-mono uppercase">
                  <tr><th className="text-left px-2 py-1">Sor</th><th className="text-left px-2 py-1">TAJ</th><th className="text-left px-2 py-1">Hiba</th></tr>
                </thead>
                <tbody>
                  {result.errors.map((e, i) => (
                    <tr key={i} className="border-t border-border">
                      <td className="px-2 py-1 font-mono">{e.row}</td>
                      <td className="px-2 py-1 font-mono">{e.taj}</td>
                      <td className="px-2 py-1 text-destructive">{e.reason}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          <details className="text-xs text-muted-foreground">
            <summary className="cursor-pointer hover:text-foreground">CSV formátum</summary>
            <pre className="mt-2 p-2 bg-secondary/40 rounded font-mono text-[10px] overflow-x-auto">taj;surgery_type_kod;becsult_idotartam_perc;posztop_apolasi_perc;prioritas;megjegyzes
123456789;CHOL;90;30;elektiv;Reggeli első műtét
234567890;APP;45;20;sürgos;</pre>
            <p className="mt-1">Kötelező: <code>taj</code>, <code>becsult_idotartam_perc</code>. Elválasztó: <code>;</code> vagy <code>,</code>. Prioritás: <code>elektiv</code> / <code>sürgos</code> / <code>azonnali</code>.</p>
          </details>
        </div>
        <div className="px-4 py-3 border-t border-border flex justify-end">
          <button type="button" onClick={onClose} className="h-9 px-3 rounded-md bg-primary text-primary-foreground text-sm font-semibold">Bezárás</button>
        </div>
      </div>
    </div>
  );
}

function parseImportCsv(text: string): ImportRow[] {
  // Strip BOM + split lines
  const clean = text.replace(/^\uFEFF/, "").trim();
  if (!clean) return [];
  const lines = clean.split(/\r?\n/);
  const delim = (lines[0].includes(";") ? ";" : ",");
  const parseLine = (line: string): string[] => {
    const out: string[] = [];
    let cur = "";
    let inQ = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (inQ) {
        if (ch === '"' && line[i + 1] === '"') { cur += '"'; i++; }
        else if (ch === '"') inQ = false;
        else cur += ch;
      } else if (ch === '"') inQ = true;
      else if (ch === delim) { out.push(cur); cur = ""; }
      else cur += ch;
    }
    out.push(cur);
    return out.map((s) => s.trim());
  };
  const header = parseLine(lines[0]).map((h) => h.toLowerCase());
  const idx = (name: string) => header.indexOf(name);
  const iTaj = idx("taj");
  const iKod = idx("surgery_type_kod");
  const iDur = idx("becsult_idotartam_perc");
  const iPosz = idx("posztop_apolasi_perc");
  const iPri = idx("prioritas");
  const iMeg = idx("megjegyzes");
  if (iTaj < 0 || iDur < 0) {
    throw new Error("Kötelező oszlopok hiányoznak: taj, becsult_idotartam_perc");
  }
  const rows: ImportRow[] = [];
  for (let li = 1; li < lines.length; li++) {
    const line = lines[li];
    if (!line.trim()) continue;
    const c = parseLine(line);
    const taj = c[iTaj];
    const dur = Number(c[iDur]);
    if (!taj || !Number.isFinite(dur) || dur <= 0) continue;
    const pri = (iPri >= 0 ? c[iPri] : "elektiv") || "elektiv";
    rows.push({
      taj,
      surgery_type_kod: iKod >= 0 && c[iKod] ? c[iKod] : null,
      becsult_idotartam_perc: Math.min(1440, Math.round(dur)),
      posztop_apolasi_perc: iPosz >= 0 && c[iPosz] ? Math.min(1440, Math.max(0, Math.round(Number(c[iPosz])))) : undefined,
      prioritas: (["elektiv", "sürgos", "azonnali"].includes(pri) ? pri : "elektiv") as ImportRow["prioritas"],
      megjegyzes: iMeg >= 0 && c[iMeg] ? c[iMeg] : null,
    });
  }
  return rows;
}
