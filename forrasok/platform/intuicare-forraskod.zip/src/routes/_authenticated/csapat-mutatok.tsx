import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Loader2, BarChart3 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend,
} from "recharts";

export const Route = createFileRoute("/_authenticated/csapat-mutatok")({
  component: CsapatMutatokPage,
});

type Assignment = {
  user_id: string;
  kezdo_idopont: string;
  zaro_idopont: string;
  ora: number;
  kategoria: string;
};
type Profile = { id: string; teljes_nev: string };

function monthBounds(d: Date): { start: string; end: string; label: string } {
  const s = new Date(d.getFullYear(), d.getMonth(), 1);
  const e = new Date(d.getFullYear(), d.getMonth() + 1, 1);
  const pad = (n: number) => String(n).padStart(2, "0");
  const iso = (x: Date) => `${x.getFullYear()}-${pad(x.getMonth() + 1)}-${pad(x.getDate())}`;
  return {
    start: iso(s),
    end: iso(e),
    label: `${s.getFullYear()}. ${pad(s.getMonth() + 1)}`,
  };
}

function CsapatMutatokPage() {
  const { user } = useAuth();
  const [month, setMonth] = useState(() => new Date());
  const [loading, setLoading] = useState(true);
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const bounds = useMemo(() => monthBounds(month), [month]);

  useEffect(() => {
    if (!user) return;
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, bounds.start]);

  async function load() {
    setLoading(true);
    const [aRes, pRes] = await Promise.all([
      supabase
        .from("schedule_assignments")
        .select("user_id,kezdo_idopont,zaro_idopont,ora,kategoria")
        .gte("kezdo_idopont", `${bounds.start}T00:00:00`)
        .lt("kezdo_idopont", `${bounds.end}T00:00:00`),
      supabase.from("profiles").select("id,teljes_nev"),
    ]);
    setAssignments((aRes.data ?? []) as Assignment[]);
    setProfiles((pRes.data ?? []) as Profile[]);
    setLoading(false);
  }

  const byPerson = useMemo(() => {
    const m = new Map<string, { rendes: number; ugyelet: number; keszenlet: number; ossz: number }>();
    for (const a of assignments) {
      const cur = m.get(a.user_id) ?? { rendes: 0, ugyelet: 0, keszenlet: 0, ossz: 0 };
      const ora = Number(a.ora) || 0;
      cur.ossz += ora;
      if (a.kategoria === "rendes") cur.rendes += ora;
      else if (a.kategoria === "ugyelet") cur.ugyelet += ora;
      else if (a.kategoria === "keszenlet") cur.keszenlet += ora;
      m.set(a.user_id, cur);
    }
    return m;
  }, [assignments]);

  const personChart = useMemo(() => {
    const nameOf = (id: string) =>
      profiles.find((p) => p.id === id)?.teljes_nev ?? id.slice(0, 6);
    const rows = Array.from(byPerson.entries()).map(([uid, v]) => ({
      name: nameOf(uid),
      rendes: Math.round(v.rendes * 10) / 10,
      ugyelet: Math.round(v.ugyelet * 10) / 10,
      keszenlet: Math.round(v.keszenlet * 10) / 10,
      ossz: v.ossz,
    }));
    rows.sort((a, b) => b.ossz - a.ossz);
    return rows;
  }, [byPerson, profiles]);

  const stats = useMemo(() => {
    const hours = personChart.map((p) => p.ossz);
    if (hours.length === 0) return { atlag: 0, szoras: 0, max: 0, min: 0, ossz: 0 };
    const ossz = hours.reduce((a, b) => a + b, 0);
    const atlag = ossz / hours.length;
    const variance = hours.reduce((a, b) => a + (b - atlag) ** 2, 0) / hours.length;
    return {
      atlag: Math.round(atlag * 10) / 10,
      szoras: Math.round(Math.sqrt(variance) * 10) / 10,
      max: Math.max(...hours),
      min: Math.min(...hours),
      ossz: Math.round(ossz * 10) / 10,
    };
  }, [personChart]);

  const kategoriaOssz = useMemo(() => {
    let r = 0, u = 0, k = 0;
    for (const v of byPerson.values()) { r += v.rendes; u += v.ugyelet; k += v.keszenlet; }
    return [
      { name: "Rendes", value: Math.round(r * 10) / 10 },
      { name: "Ügyelet", value: Math.round(u * 10) / 10 },
      { name: "Készenlét", value: Math.round(k * 10) / 10 },
    ];
  }, [byPerson]);

  function shiftMonth(delta: number) {
    const d = new Date(month);
    d.setMonth(d.getMonth() + delta);
    setMonth(d);
  }

  if (loading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const top3 = personChart.slice(0, 3);
  const bottom3 = personChart.slice(-3).reverse();

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <BarChart3 className="h-6 w-6 text-primary" />
          <div>
            <h1 className="text-2xl font-semibold">Csapat-mutatók</h1>
            <p className="text-sm text-muted-foreground">Havi terhelés-elemzés és kategória-bontás</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => shiftMonth(-1)} className="rounded border px-2 py-1 text-sm hover:bg-accent">← előző</button>
          <div className="px-3 py-1 rounded bg-secondary text-sm font-mono">{bounds.label}</div>
          <button onClick={() => shiftMonth(1)} className="rounded border px-2 py-1 text-sm hover:bg-accent">következő →</button>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <Stat label="Összes óra" value={stats.ossz} unit="h" />
        <Stat label="Átlag/fő" value={stats.atlag} unit="h" />
        <Stat label="Szórás" value={stats.szoras} unit="h" />
        <Stat label="Max/fő" value={stats.max} unit="h" />
        <Stat label="Min/fő" value={stats.min} unit="h" />
      </div>

      <div className="rounded-lg border bg-card p-4">
        <h2 className="text-sm font-semibold mb-3">Személyenkénti terhelés (kategória-bontásban)</h2>
        {personChart.length === 0 ? (
          <div className="text-sm text-muted-foreground italic">Nincs adat ebben a hónapban.</div>
        ) : (
          <div className="h-80">
            <ResponsiveContainer>
              <BarChart data={personChart}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} angle={-25} textAnchor="end" height={70} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip />
                <Legend />
                <Bar dataKey="rendes" stackId="a" fill="hsl(var(--primary))" />
                <Bar dataKey="ugyelet" stackId="a" fill="hsl(var(--destructive))" />
                <Bar dataKey="keszenlet" stackId="a" fill="hsl(var(--muted-foreground))" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="rounded-lg border bg-card p-4">
          <h2 className="text-sm font-semibold mb-3">Kategória-összesen</h2>
          {kategoriaOssz.every((k) => k.value === 0) ? (
            <div className="text-sm text-muted-foreground italic">Nincs adat.</div>
          ) : (
            <div className="h-56">
              <ResponsiveContainer>
                <BarChart data={kategoriaOssz} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                  <XAxis type="number" tick={{ fontSize: 11 }} />
                  <YAxis type="category" dataKey="name" tick={{ fontSize: 11 }} width={80} />
                  <Tooltip />
                  <Bar dataKey="value" fill="hsl(var(--primary))" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>

        <div className="rounded-lg border bg-card p-4 space-y-3">
          <div>
            <h2 className="text-sm font-semibold mb-2">Top 3 leterhelt</h2>
            {top3.length === 0 ? (
              <div className="text-xs text-muted-foreground italic">—</div>
            ) : (
              <ul className="space-y-1 text-sm">
                {top3.map((p) => (
                  <li key={p.name} className="flex justify-between border-b pb-1">
                    <span>{p.name}</span>
                    <span className="font-mono">{p.ossz} h</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
          <div>
            <h2 className="text-sm font-semibold mb-2">Legkevesebbet kapó (alsó 3)</h2>
            {bottom3.length === 0 ? (
              <div className="text-xs text-muted-foreground italic">—</div>
            ) : (
              <ul className="space-y-1 text-sm">
                {bottom3.map((p) => (
                  <li key={p.name} className="flex justify-between border-b pb-1">
                    <span>{p.name}</span>
                    <span className="font-mono">{p.ossz} h</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value, unit }: { label: string; value: number; unit?: string }) {
  return (
    <div className="rounded-lg border bg-card p-3">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="text-xl font-bold font-mono">{value}{unit && <span className="text-xs text-muted-foreground ml-1">{unit}</span>}</div>
    </div>
  );
}
