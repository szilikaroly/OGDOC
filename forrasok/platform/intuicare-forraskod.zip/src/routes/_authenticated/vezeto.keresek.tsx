import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import {
  ShieldCheck, RefreshCcw, Ban, ArrowLeftRight, Check, X, Clock,
  Filter, AlertCircle, Loader2, Calendar,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { usePermissions } from "@/hooks/use-permissions";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/vezeto/keresek")({
  component: VezetoiKeresekPage,
  head: () => ({
    meta: [
      { title: "Vezetői kérelmek — Beosztás-változtatások" },
      { name: "description", content: "Beosztás-változtatási (lemondás, csere) kérelmek vezetői döntéshez." },
    ],
  }),
});

type Row = {
  id: string;
  request_type: "cancel" | "swap";
  status: "pending" | "approved" | "rejected" | "cancelled";
  reason: string | null;
  created_at: string;
  decided_at: string | null;
  decision_note: string | null;
  requester_id: string;
  target_user_id: string | null;
  requester_name: string;
  target_name: string | null;
  decider_name: string | null;
  assignment: {
    kezdo_idopont: string;
    zaro_idopont: string;
    kategoria: string;
    status: string;
    org_unit?: string | null;
    site?: string | null;
    feladatkor?: string | null;
  } | null;
};

const TYPE_LABEL: Record<string, string> = { cancel: "Lemondás", swap: "Csere" };
const STATUS_BADGE: Record<string, { label: string; cls: string }> = {
  pending:   { label: "Függőben",  cls: "bg-amber-100 text-amber-800 border-amber-200" },
  approved:  { label: "Jóváhagyva", cls: "bg-emerald-100 text-emerald-800 border-emerald-200" },
  rejected:  { label: "Elutasítva", cls: "bg-rose-100 text-rose-800 border-rose-200" },
  cancelled: { label: "Visszavonva", cls: "bg-muted text-muted-foreground border-border" },
};

const fmtTs = (s: string) =>
  new Intl.DateTimeFormat("hu-HU", { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }).format(new Date(s));
const fmtRange = (a: string, b: string) =>
  `${new Date(a).toLocaleString("hu-HU", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })} – ${new Date(b).toLocaleTimeString("hu-HU", { hour: "2-digit", minute: "2-digit" })}`;

function VezetoiKeresekPage() {
  const { can, loading: permLoading } = usePermissions();
  const isManager = can("manage_schedule") || can("manage_tenant");

  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<string>("pending");
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [search, setSearch] = useState("");

  const [decide, setDecide] = useState<{ row: Row; outcome: "approved" | "rejected" } | null>(null);
  const [decisionNote, setDecisionNote] = useState("");
  const [submitting, setSubmitting] = useState(false);

  async function reload() {
    setLoading(true);
    const { data, error } = await supabase
      .from("schedule_change_requests")
      .select(`
        id, request_type, status, reason, created_at, decided_at, decision_note,
        requester_id, target_user_id,
        requester:profiles!schedule_change_requests_requester_id_fkey(teljes_nev, email),
        target:profiles!schedule_change_requests_target_user_id_fkey(teljes_nev, email),
        decider:profiles!schedule_change_requests_decided_by_fkey(teljes_nev, email),
        assignment:schedule_assignments!schedule_change_requests_assignment_id_fkey(
          kezdo_idopont, zaro_idopont, kategoria, status,
          org_units(nev), sites(nev), feladat_korok(nev)
        )
      `)
      .order("created_at", { ascending: false })
      .limit(500);

    if (error) {
      toast.error("Nem sikerült betölteni a kérelmeket", { description: error.message });
      setRows([]);
    } else {
      setRows((data ?? []).map((r: any) => ({
        ...r,
        requester_name: r.requester?.teljes_nev || r.requester?.email || "—",
        target_name: r.target?.teljes_nev || r.target?.email || null,
        decider_name: r.decider?.teljes_nev || r.decider?.email || null,
        assignment: r.assignment ? {
          ...r.assignment,
          org_unit: r.assignment.org_units?.nev ?? null,
          site: r.assignment.sites?.nev ?? null,
          feladatkor: r.assignment.feladat_korok?.nev ?? null,
        } : null,
      })));
    }
    setLoading(false);
  }

  useEffect(() => {
    if (!isManager) return;
    void reload();
  }, [isManager]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return rows.filter(r => {
      if (statusFilter !== "all" && r.status !== statusFilter) return false;
      if (typeFilter !== "all" && r.request_type !== typeFilter) return false;
      if (q) {
        const hay = [
          r.requester_name, r.target_name, r.reason, r.decision_note,
          r.assignment?.org_unit, r.assignment?.site, r.assignment?.feladatkor,
        ].filter(Boolean).join(" ").toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [rows, statusFilter, typeFilter, search]);

  const counts = useMemo(() => {
    const c = { pending: 0, approved: 0, rejected: 0, cancelled: 0 };
    rows.forEach(r => { c[r.status]++; });
    return c;
  }, [rows]);

  async function submitDecision() {
    if (!decide) return;
    const note = decisionNote.trim();
    if (note.length < 5) {
      toast.error("Indoklás kötelező", { description: "Legalább 5 karaktert írj a döntéshez." });
      return;
    }
    if (note.length > 1000) {
      toast.error("Az indoklás túl hosszú", { description: "Maximum 1000 karakter." });
      return;
    }
    setSubmitting(true);
    const { error } = await supabase.from("schedule_change_requests")
      .update({ status: decide.outcome, decision_note: note } as any)
      .eq("id", decide.row.id);
    setSubmitting(false);
    if (error) {
      toast.error("Döntés mentése sikertelen", { description: error.message });
      return;
    }
    toast.success(decide.outcome === "approved" ? "Kérés jóváhagyva" : "Kérés elutasítva");
    setDecide(null);
    setDecisionNote("");
    void reload();
  }

  if (permLoading) {
    return <div className="p-6 flex items-center gap-2 text-sm text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> Jogosultság ellenőrzése…</div>;
  }
  if (!isManager) {
    return (
      <div className="p-6 max-w-xl mx-auto">
        <Card>
          <CardContent className="pt-6 flex items-start gap-3">
            <AlertCircle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold">Nincs jogosultságod ehhez az oldalhoz.</p>
              <p className="text-sm text-muted-foreground">A beosztás-változtatási kérelmeket csak ütemezés-kezelő vezető láthatja.</p>
              <Link to="/iranyitopult"><Button variant="link" className="px-0 mt-2">Vissza az irányítópultra</Button></Link>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 space-y-4 max-w-7xl mx-auto">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h1 className="text-2xl font-semibold flex items-center gap-2">
            <ShieldCheck className="h-6 w-6 text-primary" /> Vezetői kérelmek
          </h1>
          <p className="text-sm text-muted-foreground">Lemondási és csere-kérelmek áttekintése és jóváhagyása.</p>
        </div>
        <Button variant="outline" size="sm" onClick={() => void reload()} disabled={loading}>
          <RefreshCcw className={`h-4 w-4 mr-1 ${loading ? "animate-spin" : ""}`} /> Frissítés
        </Button>
      </div>

      {/* Counts */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
        {(["pending", "approved", "rejected", "cancelled"] as const).map(s => {
          const sb = STATUS_BADGE[s];
          const active = statusFilter === s;
          return (
            <button
              key={s}
              type="button"
              onClick={() => setStatusFilter(active ? "all" : s)}
              className={`rounded-lg border p-3 text-left transition ${active ? "border-primary ring-2 ring-primary/20" : "hover:border-primary/50"}`}
            >
              <div className="flex items-center justify-between">
                <span className={`text-xs px-2 py-0.5 rounded-full border ${sb.cls}`}>{sb.label}</span>
                <span className="text-2xl font-semibold">{counts[s]}</span>
              </div>
              <p className="text-[10px] text-muted-foreground mt-1">
                {active ? "Aktív szűrő – kattints a feloldáshoz" : "Kattints a szűréshez"}
              </p>
            </button>
          );
        })}
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-4 flex flex-wrap items-end gap-3">
          <div className="flex-1 min-w-[200px]">
            <label className="text-xs font-medium mb-1 block flex items-center gap-1"><Filter className="h-3 w-3" /> Keresés</label>
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Név, indok, helyszín, feladatkör…"
              maxLength={100}
            />
          </div>
          <div className="w-40">
            <label className="text-xs font-medium mb-1 block">Státusz</label>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Mind</SelectItem>
                <SelectItem value="pending">Függőben</SelectItem>
                <SelectItem value="approved">Jóváhagyva</SelectItem>
                <SelectItem value="rejected">Elutasítva</SelectItem>
                <SelectItem value="cancelled">Visszavonva</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="w-40">
            <label className="text-xs font-medium mb-1 block">Típus</label>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Mind</SelectItem>
                <SelectItem value="cancel">Lemondás</SelectItem>
                <SelectItem value="swap">Csere</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* List */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base">
            {loading ? "Betöltés…" : `${filtered.length} kérelem`}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="py-8 text-center text-sm text-muted-foreground flex items-center justify-center gap-2">
              <Loader2 className="h-4 w-4 animate-spin" /> Betöltés…
            </div>
          ) : filtered.length === 0 ? (
            <p className="py-8 text-center text-sm text-muted-foreground">Nincs a szűrőnek megfelelő kérelem.</p>
          ) : (
            <ul className="divide-y">
              {filtered.map(r => {
                const sb = STATUS_BADGE[r.status];
                return (
                  <li key={r.id} className="py-3 space-y-2">
                    <div className="flex items-start justify-between gap-2 flex-wrap">
                      <div className="flex items-center gap-2 flex-wrap">
                        {r.request_type === "cancel"
                          ? <Ban className="h-4 w-4 text-rose-600" />
                          : <ArrowLeftRight className="h-4 w-4 text-blue-600" />}
                        <span className="font-medium">{TYPE_LABEL[r.request_type]}</span>
                        <span className="text-sm">{r.requester_name}</span>
                        {r.request_type === "swap" && r.target_name && (
                          <span className="text-sm text-muted-foreground">→ {r.target_name}</span>
                        )}
                        <Badge variant="outline" className={sb.cls}>{sb.label}</Badge>
                      </div>
                      <span className="text-xs text-muted-foreground flex items-center gap-1">
                        <Clock className="h-3 w-3" /> {fmtTs(r.created_at)}
                      </span>
                    </div>

                    {r.assignment && (
                      <div className="text-xs text-muted-foreground flex items-center gap-2 flex-wrap">
                        <Calendar className="h-3 w-3" />
                        <span className="font-medium text-foreground">{fmtRange(r.assignment.kezdo_idopont, r.assignment.zaro_idopont)}</span>
                        <span>•</span>
                        <span>{r.assignment.kategoria}</span>
                        {r.assignment.feladatkor && <><span>•</span><span>{r.assignment.feladatkor}</span></>}
                        {(r.assignment.site || r.assignment.org_unit) && (
                          <><span>•</span><span>{[r.assignment.site, r.assignment.org_unit].filter(Boolean).join(" · ")}</span></>
                        )}
                      </div>
                    )}

                    {r.reason && (
                      <p className="text-sm"><span className="text-xs font-medium text-muted-foreground">Indok: </span>{r.reason}</p>
                    )}
                    {r.decided_at && (
                      <p className="text-xs text-muted-foreground">
                        <span className="font-medium">Döntés:</span> {fmtTs(r.decided_at)}
                        {r.decider_name ? ` – ${r.decider_name}` : ""}
                        {r.decision_note ? ` — „${r.decision_note}"` : ""}
                      </p>
                    )}

                    {r.status === "pending" && (
                      <div className="flex gap-2 pt-1">
                        <Button size="sm" onClick={() => { setDecide({ row: r, outcome: "approved" }); setDecisionNote(""); }}>
                          <Check className="h-3 w-3 mr-1" /> Jóváhagy
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => { setDecide({ row: r, outcome: "rejected" }); setDecisionNote(""); }}>
                          <X className="h-3 w-3 mr-1" /> Elutasít
                        </Button>
                      </div>
                    )}
                  </li>
                );
              })}
            </ul>
          )}
        </CardContent>
      </Card>

      {/* Decide dialog */}
      <Dialog open={!!decide} onOpenChange={(o) => { if (!o) { setDecide(null); setDecisionNote(""); } }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {decide?.outcome === "approved" ? "Kérés jóváhagyása" : "Kérés elutasítása"}
            </DialogTitle>
            <DialogDescription>
              A döntés és az indoklás bekerül az audit-naplóba; a kérelmező automatikusan értesítést kap.
            </DialogDescription>
          </DialogHeader>
          {decide && (
            <div className="rounded border bg-muted/30 p-2 text-xs space-y-1">
              <p><span className="font-medium">{TYPE_LABEL[decide.row.request_type]}</span> – {decide.row.requester_name}
                {decide.row.target_name ? ` → ${decide.row.target_name}` : ""}</p>
              {decide.row.assignment && (
                <p className="text-muted-foreground">{fmtRange(decide.row.assignment.kezdo_idopont, decide.row.assignment.zaro_idopont)}</p>
              )}
              {decide.row.reason && <p className="text-muted-foreground">Indok: {decide.row.reason}</p>}
            </div>
          )}
          <div className="space-y-1">
            <label className="text-xs font-medium">
              Indoklás <span className="text-rose-600">*</span>
              <span className="ml-1 text-muted-foreground font-normal">(audithoz szükséges, min. 5 karakter)</span>
            </label>
            <Textarea
              value={decisionNote}
              onChange={(e) => setDecisionNote(e.target.value)}
              placeholder="Pl. szervezeti egyeztetés alapján jóváhagyva / nem teljesíthető, mert…"
              rows={4}
              maxLength={1000}
              required
            />
            <p className="text-[10px] text-muted-foreground text-right">{decisionNote.trim().length}/1000</p>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setDecide(null)} disabled={submitting}>Mégse</Button>
            <Button
              onClick={submitDecision}
              disabled={submitting || decisionNote.trim().length < 5}
              variant={decide?.outcome === "rejected" ? "destructive" : "default"}
            >
              {submitting ? "Mentés…" : decide?.outcome === "approved" ? "Jóváhagy" : "Elutasít"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
