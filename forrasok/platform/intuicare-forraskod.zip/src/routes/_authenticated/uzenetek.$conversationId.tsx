import { createFileRoute, useParams } from "@tanstack/react-router";
import { MessageThread } from "@/components/messaging/MessageThread";

export const Route = createFileRoute("/_authenticated/uzenetek/$conversationId")({
  component: ThreadPage,
});

function ThreadPage() {
  const { conversationId } = useParams({ from: "/_authenticated/uzenetek/$conversationId" });
  return <MessageThread key={conversationId} conversationId={conversationId} />;
}
