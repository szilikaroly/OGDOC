import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Clock, TrendingUp, Calculator, AlertTriangle, Loader2, Download, Plus } from "lucide-react";
import { useTranslation } from "react-i18next";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { usePermissions } from "@/hooks/use-permissions";
import { humanizeError } from "@/lib/humanize-error";
import { toast } from "sonner";
import { toCsv, downloadCsv } from "@/lib/csv";
import { buildIcs, downloadIcs } from "@/lib/ics-export";
import { CalendarDays } from "lucide-react";

export const Route = createFileRoute("/_authenticated/munkaido")({
  component: MunkaidoPage,
});

type LedgerRow = {
  id: string;
  datum: string;
  kezdo_idopont: string;
  zaro_idopont: string;
  kategoria: string;
  ora: number;
  ejszakai_ora: number;
  vasarnapi_ora: number;
  unnepnapi_ora: number;
  org_unit_id: string | null;
  megjegyzes: string | null;
};

type OvertimeRow = {
  ev: number | null;
  rendkivuli_ora: number | null;
  eves_rendkivuli_max: number | null;
  rendkivuli_kihasznaltsag_szazalek: number | null;
  ugyelet_plus_rendkivuli_ora: number | null;
  eves_ugyelet_rendkivuli_max: number | null;
  ugy_rend_kihasznaltsag_szazalek: number | null;
  ovt_ora: number | null;
};

type WageRow = {
  wage_code_id: string;
  kod: string;
  nev: string;
  ora: number;
  szorzo: number;
  egysegek: number;
};

function firstOfMonth(d: Date) {
  return new Date(d.getFullYear(), d.getMonth(), 1).toISOString().slice(0, 10);
}

function MunkaidoPage() {
  const { user } = useAuth();
  const { t } = useTranslation();
  const { can } = usePermissions();
  const isManager = can("manage_schedule") || can("manage_tenant");
  const [month, setMonth] = useState<string>(firstOfMonth(new Date()));
  const [ledger, setLedger] = useState<LedgerRow[]>([]);
  const [overtime, setOvertime] = useState<OvertimeRow | null>(null);
  const [wages, setWages] = useState<WageRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [simulating, setSimulating] = useState(false);


  useEffect(() => {
    if (!user) return;
    void loadAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, month]);

  async function loadAll() {
    if (!user) return;
    setLoading(true);
    try {
      const start = month;
      const end = new Date(new Date(month).setMonth(new Date(month).getMonth() + 1))
        .toISOString()
        .slice(0, 10);

      const [{ data: ledgerData, error: e1 }, { data: ovData, error: e2 }] = await Promise.all([
        supabase
          .from("work_time_ledger")
          .select("id,datum,kezdo_idopont,zaro_idopont,kategoria,ora,ejszakai_ora,vasarnapi_ora,unnepnapi_ora,org_unit_id,megjegyzes")
          .eq("user_id", user.id)
          .gte("datum", start)
          .lt("datum", end)
          .order("datum", { ascending: true }),
        supabase
          .from("v_overtime_ledger_yearly")
          .select("*")
          .eq("user_id", user.id)
          .eq("ev", new Date(month).getFullYear())
          .maybeSingle(),
      ]);
      if (e1) throw e1;
      if (e2) throw e2;
      setLedger((ledgerData ?? []) as LedgerRow[]);
      setOvertime((ovData ?? null) as OvertimeRow | null);
    } catch (err) {
      toast.error(humanizeError(err as any, t));
    } finally {
      setLoading(false);
    }
  }

  async function runWageSim() {
    if (!user) return;
    setSimulating(true);
    try {
      const { data, error } = await supabase.rpc("wage_simulation", {
        _user_id: user.id,
        _honap_kezdete: month,
      });
      if (error) throw error;
      setWages((data ?? []) as WageRow[]);
      toast.success("Bér-szimuláció kész");
    } catch (err) {
      toast.error(humanizeError(err as any, t));
    } finally {
      setSimulating(false);
    }
  }

  const totals = useMemo(() => {
    const sum = ledger.reduce(
      (a, r) => ({
        ora: a.ora + Number(r.ora || 0),
        ej: a.ej + Number(r.ejszakai_ora || 0),
        vas: a.vas + Number(r.vasarnapi_ora || 0),
        unn: a.unn + Number(r.unnepnapi_ora || 0),
      }),
      { ora: 0, ej: 0, vas: 0, unn: 0 },
    );
    const byKat = ledger.reduce<Record<string, number>>((acc, r) => {
      acc[r.kategoria] = (acc[r.kategoria] ?? 0) + Number(r.ora || 0);
      return acc;
    }, {});
    return { ...sum, byKat };
  }, [ledger]);

  const wageTotal = useMemo(
    () => wages.reduce((s, w) => s + Number(w.egysegek || 0), 0),
    [wages],
  );

  function exportLedgerCsv() {
    if (ledger.length === 0) return toast.error("Nincs exportálható tétel");
    const csv = toCsv(
      ledger.map((r) => ({
        datum: r.datum,
        kategoria: r.kategoria,
        kezdo: r.kezdo_idopont,
        zaro: r.zaro_idopont,
        ora: r.ora,
        ejszakai_ora: r.ejszakai_ora,
        vasarnapi_ora: r.vasarnapi_ora,
        unnepnapi_ora: r.unnepnapi_ora,
        megjegyzes: r.megjegyzes ?? "",
      })),
    );
    downloadCsv(`munkaido-ledger-${month.slice(0, 7)}.csv`, csv);
  }

  function exportWagesCsv() {
    if (wages.length === 0) return toast.error("Először futtasd a szimulációt");
    const csv = toCsv(
      wages.map((w) => ({
        kod: w.kod,
        nev: w.nev,
        ora: w.ora,
        szorzo: w.szorzo,
        egysegek: w.egysegek,
      })),
    );
    downloadCsv(`berszimulacio-${month.slice(0, 7)}.csv`, csv);
  }

  async function exportShiftsIcs() {
    if (!user) return;
    const start = month;
    const end = new Date(new Date(month).setMonth(new Date(month).getMonth() + 1))
      .toISOString()
      .slice(0, 10);
    const { data, error } = await supabase
      .from("schedule_assignments")
      .select("id,kezdo_idopont,zaro_idopont,kategoria,status,megjegyzes")
      .eq("user_id", user.id)
      .gte("kezdo_idopont", start)
      .lt("kezdo_idopont", end)
      .order("kezdo_idopont");
    if (error) { toast.error(humanizeError(error, t)); return; }
    const rows = (data ?? []) as Array<{
      id: string; kezdo_idopont: string; zaro_idopont: string;
      kategoria: string; status: string; megjegyzes: string | null;
    }>;
    if (rows.length === 0) { toast.error("Nincs exportálható műszak"); return; }
    const ics = buildIcs(
      rows.map((r) => ({
        uid: `${r.id}@medroster`,
        startUtc: new Date(r.kezdo_idopont),
        endUtc: new Date(r.zaro_idopont),
        summary: `Műszak — ${r.kategoria}`,
        description: [r.status ? `Státusz: ${r.status}` : null, r.megjegyzes]
          .filter(Boolean)
          .join("\n"),
      })),
      "MedRoster — saját műszakok",
    );
    downloadIcs(`muszakok-${month.slice(0, 7)}.ics`, ics);
  }

  return (

    <div className="p-6 max-w-6xl mx-auto space-y-6">
      <header className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Clock className="h-6 w-6" /> Munkaidő-mérleg
          </h1>
          <p className="text-sm text-muted-foreground">
            Tény-óra, pótléksávok és bér-szimuláció. <strong>Nem számfejtés</strong> — csak jelzés.
          </p>
        </div>
        <input
          type="month"
          value={month.slice(0, 7)}
          onChange={(e) => setMonth(`${e.target.value}-01`)}
          className="border rounded px-3 py-2 bg-background"
        />
      </header>


      {/* Havi összesítő */}
      <section className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card icon={Clock} label="Összes óra" value={totals.ora.toFixed(1)} />
        <Card icon={TrendingUp} label="Éjszakai (22–06)" value={totals.ej.toFixed(1)} />
        <Card icon={TrendingUp} label="Vasárnapi" value={totals.vas.toFixed(1)} />
        <Card icon={TrendingUp} label="Ünnepnapi" value={totals.unn.toFixed(1)} />
      </section>

      {/* Éves keret */}
      {overtime && (
        <section className="border rounded-lg p-4 space-y-3">
          <h2 className="font-semibold flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-amber-500" />
            Éves keret-kijelző ({overtime.ev})
          </h2>
          <Bar
            label="Rendkívüli munkaidő"
            value={Number(overtime.rendkivuli_ora ?? 0)}
            max={Number(overtime.eves_rendkivuli_max ?? 250)}
            pct={Number(overtime.rendkivuli_kihasznaltsag_szazalek ?? 0)}
          />
          <Bar
            label="Ügyelet + rendkívüli"
            value={Number(overtime.ugyelet_plus_rendkivuli_ora ?? 0)}
            max={Number(overtime.eves_ugyelet_rendkivuli_max ?? 416)}
            pct={Number(overtime.ugy_rend_kihasznaltsag_szazalek ?? 0)}
          />
          <div className="text-xs text-muted-foreground">
            ÖVT (önként vállalt) idén: <strong>{Number(overtime.ovt_ora ?? 0).toFixed(1)} ó</strong>
          </div>
        </section>
      )}

      {/* Kategóriánkénti bontás */}
      <section className="border rounded-lg p-4">
        <h2 className="font-semibold mb-3">Óra-kategóriák ({month.slice(0, 7)})</h2>
        {Object.keys(totals.byKat).length === 0 ? (
          <div className="text-sm text-muted-foreground">Nincs rögzített óra.</div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {Object.entries(totals.byKat).map(([k, v]) => (
              <div key={k} className="flex justify-between bg-muted/40 rounded px-3 py-2 text-sm">
                <span>{k}</span>
                <strong>{v.toFixed(1)} ó</strong>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Bér-szimuláció */}
      <section className="border rounded-lg p-4 space-y-3">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <h2 className="font-semibold flex items-center gap-2">
            <Calculator className="h-4 w-4" /> Bér-szimuláció
          </h2>
          <div className="flex gap-2">
            <button
              onClick={exportWagesCsv}
              disabled={wages.length === 0}
              className="px-3 py-1.5 rounded border text-sm disabled:opacity-40 flex items-center gap-1.5"
            >
              <Download className="h-3 w-3" /> CSV
            </button>
            <button
              onClick={runWageSim}
              disabled={simulating}
              className="px-3 py-1.5 rounded bg-primary text-primary-foreground text-sm disabled:opacity-50 flex items-center gap-2"
            >
              {simulating && <Loader2 className="h-3 w-3 animate-spin" />} Szimulál
            </button>
          </div>
        </div>
        {wages.length === 0 ? (
          <div className="text-sm text-muted-foreground">
            A „Szimulál" gomb a havi órákat összeveti a díjkód-leképezéssel. Nem számfejtés.
          </div>
        ) : (
          <>
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs uppercase text-muted-foreground border-b">
                  <th className="py-2">Kód</th>
                  <th>Megnevezés</th>
                  <th className="text-right">Óra</th>
                  <th className="text-right">Szorzó</th>
                  <th className="text-right">Egységek</th>
                </tr>
              </thead>
              <tbody>
                {wages.map((w) => (
                  <tr key={w.wage_code_id} className="border-b">
                    <td className="py-1.5 font-mono">{w.kod}</td>
                    <td>{w.nev}</td>
                    <td className="text-right">{Number(w.ora).toFixed(1)}</td>
                    <td className="text-right">{Number(w.szorzo).toFixed(2)}×</td>
                    <td className="text-right font-medium">{Number(w.egysegek).toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="font-bold">
                  <td colSpan={4} className="py-2 text-right">
                    Egységek összesen
                  </td>
                  <td className="text-right">{wageTotal.toFixed(2)}</td>
                </tr>
              </tfoot>
            </table>
            <p className="text-xs text-muted-foreground">
              Az egységek a wage_codes szorzói × óra. A tényleges bérezést a számfejtő rendszer
              határozza meg.
            </p>
          </>
        )}
      </section>

      {/* Manuális tényóra-bevitel (vezetők) */}
      {isManager && (
        <ManualLedgerForm
          tenantId={null}
          defaultUserId={user?.id ?? ""}
          onAdded={() => void loadAll()}
        />
      )}

      {/* Ledger lista */}
      <section className="border rounded-lg p-4">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-semibold">Munkaidő-ledger tételek</h2>
          <div className="flex items-center gap-2">
            <button
              onClick={exportShiftsIcs}
              className="px-3 py-1.5 rounded border text-sm flex items-center gap-1.5"
              title="Saját műszakok exportja iCalendar (.ics) formátumban"
            >
              <CalendarDays className="h-3 w-3" /> ICS
            </button>
            <button
              onClick={exportLedgerCsv}
              disabled={ledger.length === 0}
              className="px-3 py-1.5 rounded border text-sm disabled:opacity-40 flex items-center gap-1.5"
            >
              <Download className="h-3 w-3" /> CSV
            </button>
          </div>

        </div>
        {loading ? (
          <Loader2 className="h-4 w-4 animate-spin" />
        ) : ledger.length === 0 ? (
          <div className="text-sm text-muted-foreground">Nincs tétel a hónapra.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs uppercase text-muted-foreground border-b">
                  <th className="py-2">Dátum</th>
                  <th>Kategória</th>
                  <th>Idő</th>
                  <th className="text-right">Óra</th>
                  <th className="text-right">Éj</th>
                  <th className="text-right">Vas</th>
                  <th className="text-right">Ünn</th>
                </tr>
              </thead>
              <tbody>
                {ledger.map((r) => (
                  <tr key={r.id} className="border-b">
                    <td className="py-1.5">{r.datum}</td>
                    <td>{r.kategoria}</td>
                    <td className="text-xs text-muted-foreground">
                      {new Date(r.kezdo_idopont).toLocaleTimeString("hu", {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                      –
                      {new Date(r.zaro_idopont).toLocaleTimeString("hu", {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </td>
                    <td className="text-right">{Number(r.ora).toFixed(1)}</td>
                    <td className="text-right">{Number(r.ejszakai_ora).toFixed(1)}</td>
                    <td className="text-right">{Number(r.vasarnapi_ora).toFixed(1)}</td>
                    <td className="text-right">{Number(r.unnepnapi_ora).toFixed(1)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}

function Card({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof Clock;
  label: string;
  value: string;
}) {
  return (
    <div className="border rounded-lg p-4">
      <div className="flex items-center gap-2 text-xs uppercase text-muted-foreground">
        <Icon className="h-3.5 w-3.5" /> {label}
      </div>
      <div className="text-2xl font-bold mt-1">{value}</div>
    </div>
  );
}

function Bar({
  label,
  value,
  max,
  pct,
}: {
  label: string;
  value: number;
  max: number;
  pct: number;
}) {
  const safePct = Math.min(100, Math.max(0, pct));
  const color = safePct > 90 ? "bg-red-500" : safePct > 70 ? "bg-amber-500" : "bg-emerald-500";
  return (
    <div>
      <div className="flex justify-between text-xs mb-1">
        <span>{label}</span>
        <span>
          {value.toFixed(1)} / {max} ó ({safePct.toFixed(0)}%)
        </span>
      </div>
      <div className="h-2 bg-muted rounded overflow-hidden">
        <div className={`h-full ${color}`} style={{ width: `${safePct}%` }} />
      </div>
    </div>
  );
}

type ProfileLite = { id: string; teljes_nev: string; email: string };

function ManualLedgerForm({
  defaultUserId,
  onAdded,
}: {
  tenantId: string | null;
  defaultUserId: string;
  onAdded: () => void;
}) {
  const { t } = useTranslation();
  const [profiles, setProfiles] = useState<ProfileLite[]>([]);
  const [userId, setUserId] = useState(defaultUserId);
  const [kezdo, setKezdo] = useState("");
  const [zaro, setZaro] = useState("");
  const [kategoria, setKategoria] = useState("rendes");
  const [megj, setMegj] = useState("");
  const [potlekKod, setPotlekKod] = useState("");
  const [projekt, setProjekt] = useState("");
  const [koltseghely, setKoltseghely] = useState("");
  const [dijazasTipus, setDijazasTipus] = useState("alap");
  const [dontesSzam, setDontesSzam] = useState("");
  const [dontesDatum, setDontesDatum] = useState("");
  const [dontesIndok, setDontesIndok] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("profiles")
        .select("id,teljes_nev,email")
        .order("teljes_nev")
        .limit(500);
      setProfiles((data ?? []) as ProfileLite[]);
    })();
  }, []);

  async function submit() {
    if (!userId || !kezdo || !zaro) {
      toast.error("Munkavállaló, kezdő és záró kötelező");
      return;
    }
    const kez = new Date(kezdo);
    const zar = new Date(zaro);
    if (zar <= kez) {
      toast.error("A záró időpont a kezdő után legyen");
      return;
    }
    const ora = Math.round(((zar.getTime() - kez.getTime()) / 3600000) * 100) / 100;
    const datum = kez.toISOString().slice(0, 10);
    setSaving(true);
    const { data: p } = await supabase.from("profiles").select("tenant_id").eq("id", userId).maybeSingle();
    const tenant = (p as any)?.tenant_id;
    if (!tenant) {
      setSaving(false);
      return toast.error("Nincs tenant a célfelhasználón");
    }
    const dontes = (dontesSzam.trim() || dontesDatum || dontesIndok.trim())
      ? {
          dontes_szam: dontesSzam.trim() || null,
          dontes_datum: dontesDatum || null,
          indok: dontesIndok.trim() || null,
        }
      : null;
    const { error } = await (supabase.from("work_time_ledger") as any).insert({
      user_id: userId,
      tenant_id: tenant,
      datum,
      kezdo_idopont: kez.toISOString(),
      zaro_idopont: zar.toISOString(),
      ora,
      kategoria: kategoria as any,
      forras: "kezi_vezetoi",
      megjegyzes: megj.trim() || null,
      potlek_kod: potlekKod.trim() || null,
      projekt: projekt.trim() || null,
      koltseghely: koltseghely.trim() || null,
      dijazas_tipus: dijazasTipus,
      munkaltatoi_dontes: dontes,
    });
    setSaving(false);
    if (error) {
      toast.error(humanizeError(error as any, t));
      return;
    }
    toast.success("Tényóra rögzítve (auditálva)");
    setKezdo("");
    setZaro("");
    setMegj("");
    setPotlekKod("");
    setProjekt("");
    setKoltseghely("");
    setDontesSzam("");
    setDontesDatum("");
    setDontesIndok("");
    onAdded();
  }


  return (
    <section className="border rounded-lg p-4 space-y-3 bg-amber-500/5 border-amber-500/30">
      <div className="flex items-center gap-2">
        <Plus className="h-4 w-4 text-amber-600" />
        <h2 className="font-semibold">Manuális tényóra-bevitel (vezető)</h2>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <label className="text-xs space-y-1">
          <span className="text-muted-foreground">Munkavállaló</span>
          <select
            value={userId}
            onChange={(e) => setUserId(e.target.value)}
            className="w-full px-2 py-1.5 border rounded bg-background text-sm"
          >
            <option value="">— Válassz —</option>
            {profiles.map((p) => (
              <option key={p.id} value={p.id}>
                {p.teljes_nev} ({p.email})
              </option>
            ))}
          </select>
        </label>
        <label className="text-xs space-y-1">
          <span className="text-muted-foreground">Kategória</span>
          <select
            value={kategoria}
            onChange={(e) => setKategoria(e.target.value)}
            className="w-full px-2 py-1.5 border rounded bg-background text-sm"
          >
            <option value="rendes">rendes</option>
            <option value="ugyelet">ügyelet</option>
            <option value="keszenlet">készenlét</option>
            <option value="ovt">ÖVT</option>
            <option value="rendkivuli">rendkívüli</option>
            <option value="kompenzalo">kompenzáló</option>
            <option value="szabadsag">szabadság</option>
            <option value="tavollet">távollét</option>
          </select>
        </label>
        <label className="text-xs space-y-1">
          <span className="text-muted-foreground">Kezdő</span>
          <input
            type="datetime-local"
            value={kezdo}
            onChange={(e) => setKezdo(e.target.value)}
            className="w-full px-2 py-1.5 border rounded bg-background text-sm"
          />
        </label>
        <label className="text-xs space-y-1">
          <span className="text-muted-foreground">Záró</span>
          <input
            type="datetime-local"
            value={zaro}
            onChange={(e) => setZaro(e.target.value)}
            className="w-full px-2 py-1.5 border rounded bg-background text-sm"
          />
        </label>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 border-t pt-3">
        <label className="text-xs space-y-1">
          <span className="text-muted-foreground">Pótlék-kód</span>
          <input value={potlekKod} onChange={(e) => setPotlekKod(e.target.value)} placeholder="pl. P-EJ" className="w-full px-2 py-1.5 border rounded bg-background text-sm" />
        </label>
        <label className="text-xs space-y-1">
          <span className="text-muted-foreground">Díjazás típusa</span>
          <select value={dijazasTipus} onChange={(e) => setDijazasTipus(e.target.value)} className="w-full px-2 py-1.5 border rounded bg-background text-sm">
            <option value="alap">alap</option>
            <option value="potlek">pótlék</option>
            <option value="bonusz">bónusz</option>
            <option value="tulora">túlóra</option>
            <option value="keszenleti_dij">készenléti díj</option>
            <option value="ugyeleti_dij">ügyeleti díj</option>
          </select>
        </label>
        <label className="text-xs space-y-1">
          <span className="text-muted-foreground">Projekt</span>
          <input value={projekt} onChange={(e) => setProjekt(e.target.value)} className="w-full px-2 py-1.5 border rounded bg-background text-sm" />
        </label>
        <label className="text-xs space-y-1">
          <span className="text-muted-foreground">Költséghely</span>
          <input value={koltseghely} onChange={(e) => setKoltseghely(e.target.value)} className="w-full px-2 py-1.5 border rounded bg-background text-sm" />
        </label>
      </div>

      <details className="border rounded p-2 bg-background/50">
        <summary className="text-xs font-semibold cursor-pointer text-muted-foreground">Munkáltatói döntés (opcionális)</summary>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-2 mt-2">
          <label className="text-xs space-y-1">
            <span className="text-muted-foreground">Döntés száma</span>
            <input value={dontesSzam} onChange={(e) => setDontesSzam(e.target.value)} className="w-full px-2 py-1.5 border rounded bg-background text-sm" />
          </label>
          <label className="text-xs space-y-1">
            <span className="text-muted-foreground">Döntés dátuma</span>
            <input type="date" value={dontesDatum} onChange={(e) => setDontesDatum(e.target.value)} className="w-full px-2 py-1.5 border rounded bg-background text-sm" />
          </label>
          <label className="text-xs space-y-1">
            <span className="text-muted-foreground">Indok / hivatkozás</span>
            <input value={dontesIndok} onChange={(e) => setDontesIndok(e.target.value)} className="w-full px-2 py-1.5 border rounded bg-background text-sm" />
          </label>
        </div>
      </details>

      <textarea
        value={megj}
        onChange={(e) => setMegj(e.target.value.slice(0, 500))}
        placeholder="Megjegyzés (indok, hivatkozás)"
        rows={2}
        className="w-full px-2 py-1.5 border rounded bg-background text-sm"
      />

      <button
        onClick={submit}
        disabled={saving}
        className="px-3 py-1.5 rounded bg-amber-600 text-white text-xs font-semibold inline-flex items-center gap-1.5 disabled:opacity-50"
      >
        {saving ? <Loader2 className="h-3 w-3 animate-spin" /> : <Plus className="h-3 w-3" />}
        Rögzítés
      </button>
      <p className="text-[11px] text-muted-foreground">
        Minden bevitel auditálódik (audit_trigger_fn). A pótléksávok automatikusan kiszámolódnak.
      </p>
    </section>
  );
}
