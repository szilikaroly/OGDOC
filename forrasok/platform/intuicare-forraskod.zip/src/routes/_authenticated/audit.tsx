import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { supabase } from "@/integrations/supabase/client";
import { usePermissions } from "@/hooks/use-permissions";
import { useAuth } from "@/hooks/use-auth";
import { ShieldAlert, ShieldCheck, Loader2, RefreshCcw } from "lucide-react";
import { cn } from "@/lib/utils";
import { DiffView } from "@/lib/diff-view";

type AuditRow = {
  id: string;
  created_at: string;
  user_id: string | null;
  action: "INSERT" | "UPDATE" | "DELETE";
  table_name: string;
  record_id: string | null;
  before_data: Record<string, unknown> | null;
  after_data: Record<string, unknown> | null;
  reason: string | null;
};

type TestResult = { key: string; label: string; passed: boolean; detail?: string };

export const Route = createFileRoute("/_authenticated/audit")({
  component: AuditPage,
});

function AuditPage() {
  const { t } = useTranslation();
  const { can, loading: permLoading } = usePermissions();
  const { user } = useAuth();

  const [rows, setRows] = useState<AuditRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [tableFilter, setTableFilter] = useState<string>("");
  const [actionFilter, setActionFilter] = useState<"" | "INSERT" | "UPDATE" | "DELETE">("");
  const [search, setSearch] = useState("");

  const [tests, setTests] = useState<TestResult[] | null>(null);
  const [running, setRunning] = useState(false);

  async function load() {
    setLoading(true);
    const { data } = await supabase
      .from("admin_audit_log")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(500);
    setRows((data ?? []) as AuditRow[]);
    setLoading(false);
  }

  useEffect(() => {
    if (!permLoading && can("view_audit")) load();
  }, [permLoading, can]);

  const filtered = useMemo(() => {
    return rows.filter((r) => {
      if (tableFilter && r.table_name !== tableFilter) return false;
      if (actionFilter && r.action !== actionFilter) return false;
      if (search) {
        const hay = `${r.table_name} ${r.record_id ?? ""} ${JSON.stringify(r.before_data ?? {})} ${JSON.stringify(r.after_data ?? {})}`.toLowerCase();
        if (!hay.includes(search.toLowerCase())) return false;
      }
      return true;
    });
  }, [rows, tableFilter, actionFilter, search]);

  const tables = useMemo(
    () => Array.from(new Set(rows.map((r) => r.table_name))).sort(),
    [rows],
  );

  async function runTests() {
    if (!user) return;
    setRunning(true);
    const results: TestResult[] = [];
    const perms = [
      "manage_tenant",
      "manage_org",
      "manage_roles",
      "manage_schedule",
      "manage_training",
      "manage_patients",
      "view_audit",
      "view_team",
    ] as const;
    for (const p of perms) {
      const { data, error } = await supabase.rpc("has_permission", {
        _user_id: user.id,
        _perm: p,
      });
      results.push({
        key: `perm:${p}`,
        label: `Jogosultság: ${p}`,
        passed: Boolean(data) && !error,
        detail: error?.message,
      });
    }
    // Read checks across major admin tables
    const tablesToProbe = [
      "tenants",
      "clinics",
      "sites",
      "org_units",
      "user_roles",
      "profiles",
      "admin_audit_log",
    ] as const;
    for (const tbl of tablesToProbe) {
      const { error } = await supabase.from(tbl).select("id").limit(1);
      results.push({
        key: `read:${tbl}`,
        label: `Olvasás: ${tbl}`,
        passed: !error,
        detail: error?.message,
      });
    }
    // Write probe: insert + delete a throwaway clinic
    const probeName = `__probe_${Date.now()}`;
    const tenantId =
      (await supabase.from("profiles").select("tenant_id").eq("id", user.id).maybeSingle())
        .data?.tenant_id ?? null;
    if (tenantId) {
      const { data: ins, error: insErr } = await supabase
        .from("clinics")
        .insert({ tenant_id: tenantId, nev: probeName })
        .select("id")
        .maybeSingle();
      results.push({
        key: "write:clinics.insert",
        label: "Írás: clinics létrehozása",
        passed: !insErr && !!ins,
        detail: insErr?.message,
      });
      if (ins?.id) {
        const { error: updErr } = await supabase
          .from("clinics")
          .update({ nev: probeName + "_updated" })
          .eq("id", ins.id);
        results.push({
          key: "write:clinics.update",
          label: "Írás: clinics módosítás",
          passed: !updErr,
          detail: updErr?.message,
        });
        const { error: delErr } = await supabase.from("clinics").delete().eq("id", ins.id);
        results.push({
          key: "write:clinics.delete",
          label: "Írás: clinics törlés",
          passed: !delErr,
          detail: delErr?.message,
        });
      }
    }
    setTests(results);
    setRunning(false);
    // refresh audit log so the new entries appear
    load();
  }

  if (permLoading) {
    return (
      <div className="p-8 flex items-center gap-2 text-muted-foreground">
        <Loader2 className="size-4 animate-spin" />
        {t("common.loading")}
      </div>
    );
  }

  if (!can("view_audit")) {
    return (
      <div className="p-8">
        <div className="flex items-start gap-3 p-4 border border-warning/30 bg-warning/5 rounded-lg max-w-2xl">
          <ShieldAlert className="size-5 text-warning shrink-0 mt-0.5" />
          <div>
            <div className="font-semibold">{t("audit.no_access_title")}</div>
            <div className="text-sm text-muted-foreground mt-1">{t("audit.no_access_body")}</div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 space-y-8">
      <header className="flex items-end justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">{t("audit.title")}</h1>
          <p className="text-sm text-muted-foreground mt-1">{t("audit.subtitle")}</p>
        </div>
        <button
          type="button"
          onClick={load}
          className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-2 rounded-md border border-border hover:bg-secondary"
        >
          <RefreshCcw className="size-3.5" />
          {t("audit.refresh")}
        </button>
      </header>

      <section className="rounded-lg border border-border bg-card">
        <div className="p-4 border-b border-border flex items-center justify-between gap-4 flex-wrap">
          <div>
            <div className="font-semibold">{t("audit.tests_title")}</div>
            <div className="text-xs text-muted-foreground mt-0.5">{t("audit.tests_sub")}</div>
          </div>
          <button
            type="button"
            onClick={runTests}
            disabled={running}
            className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-2 rounded-md bg-primary text-primary-foreground hover:opacity-90 disabled:opacity-50"
          >
            {running ? <Loader2 className="size-3.5 animate-spin" /> : <ShieldCheck className="size-3.5" />}
            {t("audit.run_tests")}
          </button>
        </div>
        {tests && (
          <div className="p-4 grid sm:grid-cols-2 lg:grid-cols-3 gap-2">
            {tests.map((r) => (
              <div
                key={r.key}
                className={cn(
                  "flex items-start gap-2 p-2 rounded-md border text-xs",
                  r.passed
                    ? "border-success/30 bg-success/5"
                    : "border-destructive/30 bg-destructive/5",
                )}
              >
                <div
                  className={cn(
                    "mt-0.5 size-2 rounded-full shrink-0",
                    r.passed ? "bg-success" : "bg-destructive",
                  )}
                />
                <div className="min-w-0">
                  <div className="font-mono font-semibold truncate">{r.label}</div>
                  {!r.passed && r.detail && (
                    <div className="text-muted-foreground truncate">{r.detail}</div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      <section className="rounded-lg border border-border bg-card">
        <div className="p-4 border-b border-border flex items-center gap-3 flex-wrap">
          <input
            type="text"
            placeholder={t("audit.search_ph")}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="flex-1 min-w-[200px] px-3 py-1.5 text-sm rounded-md border border-input bg-background"
          />
          <select
            value={tableFilter}
            onChange={(e) => setTableFilter(e.target.value)}
            className="px-3 py-1.5 text-sm rounded-md border border-input bg-background"
          >
            <option value="">{t("audit.all_tables")}</option>
            {tables.map((tb) => (
              <option key={tb} value={tb}>
                {tb}
              </option>
            ))}
          </select>
          <select
            value={actionFilter}
            onChange={(e) => setActionFilter(e.target.value as "" | "INSERT" | "UPDATE" | "DELETE")}
            className="px-3 py-1.5 text-sm rounded-md border border-input bg-background"
          >
            <option value="">{t("audit.all_actions")}</option>
            <option value="INSERT">INSERT</option>
            <option value="UPDATE">UPDATE</option>
            <option value="DELETE">DELETE</option>
          </select>
          <div className="text-xs text-muted-foreground font-mono">
            {filtered.length} / {rows.length}
          </div>
        </div>

        {loading ? (
          <div className="p-8 flex items-center gap-2 text-muted-foreground text-sm">
            <Loader2 className="size-4 animate-spin" />
            {t("common.loading")}
          </div>
        ) : filtered.length === 0 ? (
          <div className="p-8 text-center text-sm text-muted-foreground">{t("audit.empty")}</div>
        ) : (
          <div className="divide-y divide-border max-h-[600px] overflow-y-auto">
            {filtered.map((r) => (
              <AuditRowView key={r.id} row={r} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

function AuditRowView({ row }: { row: AuditRow }) {
  const [open, setOpen] = useState(false);
  const [showUnchanged, setShowUnchanged] = useState(false);
  const actionColor =
    row.action === "INSERT"
      ? "bg-success/10 text-success border-success/30"
      : row.action === "DELETE"
        ? "bg-destructive/10 text-destructive border-destructive/30"
        : "bg-warning/10 text-warning border-warning/30";

  const name =
    (row.after_data?.nev as string | undefined) ??
    (row.before_data?.nev as string | undefined) ??
    row.record_id ??
    "";

  return (
    <div className="px-4 py-3 hover:bg-secondary/40">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="w-full flex items-center gap-3 text-left"
      >
        <span
          className={cn(
            "px-2 py-0.5 text-[10px] font-mono font-bold rounded border",
            actionColor,
          )}
        >
          {row.action}
        </span>
        <span className="font-mono text-xs font-semibold w-40 truncate">{row.table_name}</span>
        <span className="text-sm truncate flex-1">{name}</span>
        <span className="text-[11px] text-muted-foreground font-mono whitespace-nowrap">
          {new Date(row.created_at).toLocaleString()}
        </span>
      </button>
      {open && (
        <div className="mt-3 space-y-2">
          {row.action === "UPDATE" && (
            <label className="flex items-center gap-2 text-[11px] text-muted-foreground cursor-pointer">
              <input
                type="checkbox"
                checked={showUnchanged}
                onChange={(e) => setShowUnchanged(e.target.checked)}
                className="size-3"
              />
              Változatlan mezők mutatása
            </label>
          )}
          <DiffView
            before={row.before_data}
            after={row.after_data}
            showUnchanged={showUnchanged}
          />
          {row.reason && (
            <div className="flex items-start gap-2 p-2 rounded-md border border-primary/20 bg-primary/5 text-xs">
              <span className="text-[10px] font-mono uppercase tracking-wider text-primary shrink-0 mt-0.5">
                Indoklás
              </span>
              <span className="text-foreground">{row.reason}</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

