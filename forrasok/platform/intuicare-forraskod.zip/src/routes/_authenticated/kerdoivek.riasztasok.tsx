/**
 * Kritikus riasztások (pl. PHQ-9 #9 önkárosítás) dashboard.
 */
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { StatusBadge } from "@/components/ui/status-badge";
import { severityTone, statusTone } from "@/lib/ui/status-tone";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { listCriticalAlerts, acknowledgeAlert } from "@/lib/questionnaires/questionnaires.functions";

function RiasztasokPage() {
  const qc = useQueryClient();
  const listFn = useServerFn(listCriticalAlerts);
  const ackFn = useServerFn(acknowledgeAlert);
  const q = useQuery({ queryKey: ["crit-alerts"], queryFn: () => listFn() });

  const ack = useMutation({
    mutationFn: (vars: { id: string; note?: string }) => ackFn({ data: { alert_id: vars.id, note: vars.note } }),
    onSuccess: () => { toast.success("Nyugtázva."); qc.invalidateQueries({ queryKey: ["crit-alerts"] }); },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <main className="container mx-auto px-4 py-8">
      <Link to="/kerdoivek" className="text-sm text-primary hover:underline">← Vissza a kérdőívekhez</Link>
      <h1 className="mb-6 mt-2 text-2xl font-bold">Kritikus riasztások</h1>

      {q.isLoading && <Skeleton className="h-40 w-full" />}
      {q.isError && <p className="text-sm text-destructive">{(q.error as Error).message}</p>}

      <div className="space-y-2">
        {q.data?.map((a: any) => (
          <Card key={a.id}>
            <CardContent className="flex flex-wrap items-center justify-between gap-3 py-3">
              <div>
                <div className="flex items-center gap-2">
                  <StatusBadge tone={severityTone(a.severity)} pill>{a.severity}</StatusBadge>
                  <StatusBadge tone={statusTone(a.status)} pill>{a.status}</StatusBadge>
                  <span className="text-sm font-medium">{a.alert_type}</span>
                </div>
                <p className="mt-1 text-xs text-muted-foreground">
                  Létrehozva: {new Date(a.created_at).toLocaleString("hu-HU")}
                  {a.acknowledged_at && ` · Nyugtázva: ${new Date(a.acknowledged_at).toLocaleString("hu-HU")}`}
                </p>
                {a.resolution_note && <p className="mt-1 text-xs italic">{a.resolution_note}</p>}
              </div>
              {a.status === "open" && (
                <Button size="sm"
                  onClick={() => { const note = prompt("Megjegyzés (opcionális)") ?? undefined; ack.mutate({ id: a.id, note }); }}
                  disabled={ack.isPending}
                >Nyugtázás</Button>
              )}
            </CardContent>
          </Card>
        ))}
        {q.data && q.data.length === 0 && (
          <p className="text-sm text-muted-foreground">Nincs nyitott kritikus riasztás.</p>
        )}
      </div>
    </main>
  );
}

export const Route = createFileRoute("/_authenticated/kerdoivek/riasztasok")({
  component: RiasztasokPage,
  head: () => ({ meta: [{ title: "Kritikus riasztások" }] }),
  errorComponent: ({ error, reset }) => (
    <div className="p-6"><p className="text-destructive">{error.message}</p><Button onClick={reset}>Újra</Button></div>
  ),
  notFoundComponent: () => <div className="p-6">Nem található</div>,
});
