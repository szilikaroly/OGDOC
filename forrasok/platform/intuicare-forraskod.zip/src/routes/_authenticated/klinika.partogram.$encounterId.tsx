import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Activity, ArrowLeft, Loader2, Save, AlertTriangle, Plus, FileDown, Printer, FileText, Archive } from "lucide-react";
import { exportPartogramPdf, downloadPartogramText, printPartogram, buildPartogramText } from "@/lib/clinical/partogram-pdf";
import {
  ResponsiveContainer, ComposedChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ReferenceLine, ReferenceArea, Bar, Legend,
} from "recharts";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/klinika/partogram/$encounterId")({
  component: PartogramPage,
});

type Partogram = {
  id: string;
  encounter_id: string;
  patient_id: string;
  labor_start_ts: string;
  parity_gravida_json: any;
  membrane_status: string | null;
  notes_md: string | null;
};
type Entry = {
  id: string;
  recorded_at: string;
  cervix_cm: number | null;
  descent_station: number | null;
  contractions_per_10min: number | null;
  contraction_duration_sec: number | null;
  fetal_heart_rate: number | null;
  maternal_hr: number | null;
  maternal_bp_sys: number | null;
  maternal_bp_dia: number | null;
  temp_c: number | null;
  liquor_color: string | null;
  moulding: string | null;
  oxytocin_mu: number | null;
  drugs_text: string | null;
  notes: string | null;
};

const LIQUOR = [
  { v: "clear", label: "tiszta" },
  { v: "meconium", label: "meconium" },
  { v: "blood", label: "véres" },
  { v: "absent", label: "burok ép" },
];
const MOULDING = ["0", "+", "++", "+++"];

function PartogramPage() {
  const { user } = useAuth();
  const { encounterId } = Route.useParams();
  const [partogram, setPartogram] = useState<Partogram | null>(null);
  const [encounter, setEncounter] = useState<any>(null);
  const [patient, setPatient] = useState<any>(null);
  const [entries, setEntries] = useState<Entry[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    if (!user) return;
    void (async () => {
      setLoading(true);
      const { data: enc } = await supabase.from("clinical_encounters").select("*").eq("id", encounterId).maybeSingle();
      setEncounter(enc);
      if (enc) {
        const { data: pt } = await supabase.from("patients").select("vezeteknev, keresztnev, szuletesi_datum").eq("id", enc.patient_id).maybeSingle();
        setPatient(pt);
        const { data: p } = await supabase.from("obstetric_partograms").select("*").eq("encounter_id", encounterId).order("created_at", { ascending: false }).limit(1).maybeSingle();
        setPartogram(p as any);
        if (p) await loadEntries(p.id);
      }
      setLoading(false);
    })();
  }, [user, encounterId]);

  async function loadEntries(pid: string) {
    const { data } = await supabase.from("obstetric_partogram_entries").select("*").eq("partogram_id", pid).order("recorded_at", { ascending: true });
    setEntries((data ?? []) as Entry[]);
  }

  async function createPartogram() {
    if (!user || !encounter) return;
    setCreating(true);
    const { data, error } = await supabase.from("obstetric_partograms").insert({
      encounter_id: encounter.id,
      patient_id: encounter.patient_id,
      labor_start_ts: new Date().toISOString(),
      parity_gravida_json: {},
      created_by: user.id,
    }).select("*").maybeSingle();
    setCreating(false);
    if (error) toast.error(error.message);
    else { setPartogram(data as any); toast.success("Partogram megnyitva"); }
  }

  if (loading) return <div className="container py-8 flex items-center gap-2 text-sm"><Loader2 className="h-4 w-4 animate-spin" /> Betöltés…</div>;
  if (!encounter) return <div className="container py-8">Epizód nem található.</div>;

  return (
    <div className="container max-w-7xl py-6 space-y-4">
      <header className="rounded-xl border border-border bg-card p-4">
        <Link to="/klinika/beteg/$patientId" params={{ patientId: encounter.patient_id }} search={{ encounterId, tab: "overview" }}
          className="text-xs text-muted-foreground hover:underline flex items-center gap-1">
          <ArrowLeft className="h-3 w-3" /> Betegkarton
        </Link>
        <h1 className="text-2xl font-semibold mt-1 flex items-center gap-2">
          <Activity className="h-6 w-6 text-primary" /> Szülészeti partogram
        </h1>
        <p className="text-sm text-muted-foreground">
          {patient ? `${patient.vezeteknev} ${patient.keresztnev}` : ""} · epizód {encounter.encounter_type} · {new Date(encounter.start_ts).toLocaleString("hu-HU")}
        </p>
      </header>

      {!partogram ? (
        <div className="rounded-xl border border-border bg-card p-8 text-center">
          <p className="text-sm text-muted-foreground mb-4">Ehhez az epizódhoz még nincs partogram.</p>
          <button onClick={createPartogram} disabled={creating}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-sm rounded-md bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50">
            {creating ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />} Partogram indítása
          </button>
        </div>
      ) : (
        <PartogramView partogram={partogram} entries={entries} onRefresh={() => loadEntries(partogram.id)} userId={user!.id} patient={patient} encounter={encounter} />
      )}
    </div>
  );
}

function PartogramView({ partogram, entries, onRefresh, userId, patient, encounter }: { partogram: Partogram; entries: Entry[]; onRefresh: () => void; userId: string; patient: any; encounter: any }) {
  const labor0 = useMemo(() => new Date(partogram.labor_start_ts).getTime(), [partogram.labor_start_ts]);

  const chartData = useMemo(() => entries.map((e) => {
    const h = (new Date(e.recorded_at).getTime() - labor0) / 3600000;
    return {
      h: Math.round(h * 10) / 10,
      time: new Date(e.recorded_at).toLocaleTimeString("hu-HU", { hour: "2-digit", minute: "2-digit" }),
      cervix: e.cervix_cm,
      station: e.descent_station,
      fhr: e.fetal_heart_rate,
      ctx: e.contractions_per_10min,
      sys: e.maternal_bp_sys,
      dia: e.maternal_bp_dia,
      hr: e.maternal_hr,
      temp: e.temp_c,
    };
  }), [entries, labor0]);

  // WHO LCG alert line: aktív fázistól (cervix 5cm) 1 cm/h. Action line: alert + 4 h.
  const alertLine = (h: number) => Math.min(10, 5 + Math.max(0, h));
  const alertData = useMemo(() => {
    const maxH = Math.max(8, ...chartData.map((d) => d.h));
    return Array.from({ length: Math.ceil(maxH) + 1 }, (_, i) => ({ h: i, alert: alertLine(i), action: alertLine(Math.max(0, i - 4)) }));
  }, [chartData]);

  const merged = useMemo(() => {
    const byH = new Map<number, any>();
    alertData.forEach((d) => byH.set(d.h, { ...d }));
    chartData.forEach((d) => byH.set(d.h, { ...(byH.get(d.h) ?? { h: d.h }), ...d }));
    return Array.from(byH.values()).sort((a, b) => a.h - b.h);
  }, [chartData, alertData]);

  const lastEntry = entries[entries.length - 1];
  const alerts: string[] = [];
  if (lastEntry) {
    if (lastEntry.fetal_heart_rate != null && (lastEntry.fetal_heart_rate < 110 || lastEntry.fetal_heart_rate > 160))
      alerts.push(`Magzati szívhang ${lastEntry.fetal_heart_rate}/min — célsáv 110–160`);
    if (lastEntry.cervix_cm != null) {
      const h = (new Date(lastEntry.recorded_at).getTime() - labor0) / 3600000;
      if (h > 4 && lastEntry.cervix_cm < alertLine(h)) alerts.push(`Méhszáj-tágulás az alert vonal alatt (${lastEntry.cervix_cm} cm, ${h.toFixed(1)} ó)`);
    }
    if (lastEntry.contractions_per_10min != null && (lastEntry.contractions_per_10min < 2 || lastEntry.contractions_per_10min > 5))
      alerts.push(`Kontrakció ${lastEntry.contractions_per_10min}/10 perc — célsáv 2–5`);
    if (lastEntry.maternal_bp_sys != null && lastEntry.maternal_bp_dia != null && (lastEntry.maternal_bp_sys >= 140 || lastEntry.maternal_bp_dia >= 90))
      alerts.push(`Vérnyomás ${lastEntry.maternal_bp_sys}/${lastEntry.maternal_bp_dia} Hgmm — preeclampsia gyanú`);
    if (lastEntry.temp_c != null && lastEntry.temp_c >= 38) alerts.push(`Láz: ${lastEntry.temp_c} °C`);
    if (lastEntry.liquor_color === "meconium") alerts.push("Meconiumos magzatvíz");
  }

  return (
    <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
      <div className="xl:col-span-2 space-y-4">
        <ExportToolbar
          disabled={entries.length === 0}
          patient={patient}
          encounter={encounter}
          partogram={partogram}
          entries={entries}
          alerts={alerts}
          userId={userId}
        />
        {alerts.length > 0 && (
          <div className="rounded-xl border border-amber-400 bg-amber-50/60 p-3">
            <div className="flex items-center gap-2 text-sm font-semibold text-amber-800">
              <AlertTriangle className="h-4 w-4" /> Figyelmeztetések
            </div>
            <ul className="mt-1 text-sm text-amber-900 list-disc list-inside">{alerts.map((a, i) => <li key={i}>{a}</li>)}</ul>
          </div>
        )}

        <ChartCard title="Méhszáj dilatáció + magzati fej-állás (WHO LCG)">
          <ResponsiveContainer width="100%" height={300}>
            <ComposedChart data={merged}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="h" label={{ value: "óra a vajúdás kezdetétől", position: "insideBottom", offset: -2, fontSize: 11 }} />
              <YAxis yAxisId="cervix" domain={[0, 10]} label={{ value: "cm", angle: -90, position: "insideLeft", fontSize: 11 }} />
              <YAxis yAxisId="station" orientation="right" domain={[-5, 5]} label={{ value: "station", angle: 90, position: "insideRight", fontSize: 11 }} />
              <Tooltip />
              <Legend />
              <ReferenceArea yAxisId="cervix" y1={0} y2={5} fill="#94a3b8" fillOpacity={0.08} />
              <Line yAxisId="cervix" type="monotone" dataKey="alert" stroke="#f59e0b" strokeDasharray="4 4" dot={false} name="alert line" />
              <Line yAxisId="cervix" type="monotone" dataKey="action" stroke="#dc2626" strokeDasharray="4 4" dot={false} name="action line" />
              <Line yAxisId="cervix" type="monotone" dataKey="cervix" stroke="#2563eb" strokeWidth={2} name="méhszáj (cm)" />
              <Line yAxisId="station" type="monotone" dataKey="station" stroke="#16a34a" strokeWidth={2} name="fej-állás" />
            </ComposedChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Magzati szívhang & kontrakciók">
          <ResponsiveContainer width="100%" height={240}>
            <ComposedChart data={merged}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="h" />
              <YAxis yAxisId="fhr" domain={[80, 200]} label={{ value: "FHR /min", angle: -90, position: "insideLeft", fontSize: 11 }} />
              <YAxis yAxisId="ctx" orientation="right" domain={[0, 7]} label={{ value: "ctx/10 perc", angle: 90, position: "insideRight", fontSize: 11 }} />
              <Tooltip />
              <Legend />
              <ReferenceArea yAxisId="fhr" y1={110} y2={160} fill="#22c55e" fillOpacity={0.08} />
              <ReferenceLine yAxisId="fhr" y={110} stroke="#dc2626" strokeDasharray="3 3" />
              <ReferenceLine yAxisId="fhr" y={160} stroke="#dc2626" strokeDasharray="3 3" />
              <Line yAxisId="fhr" type="monotone" dataKey="fhr" stroke="#dc2626" strokeWidth={2} name="FHR /min" />
              <Bar yAxisId="ctx" dataKey="ctx" fill="#a78bfa" name="kontrakció/10 perc" />
            </ComposedChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Anyai vitálisok">
          <ResponsiveContainer width="100%" height={220}>
            <ComposedChart data={merged}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="h" />
              <YAxis yAxisId="bp" domain={[40, 200]} label={{ value: "Hgmm / /min", angle: -90, position: "insideLeft", fontSize: 11 }} />
              <YAxis yAxisId="temp" orientation="right" domain={[35, 41]} label={{ value: "°C", angle: 90, position: "insideRight", fontSize: 11 }} />
              <Tooltip />
              <Legend />
              <Line yAxisId="bp" type="monotone" dataKey="sys" stroke="#0ea5e9" name="RR sys" />
              <Line yAxisId="bp" type="monotone" dataKey="dia" stroke="#38bdf8" name="RR dia" />
              <Line yAxisId="bp" type="monotone" dataKey="hr" stroke="#f97316" name="anyai pulzus" />
              <Line yAxisId="temp" type="monotone" dataKey="temp" stroke="#dc2626" name="hőm." />
            </ComposedChart>
          </ResponsiveContainer>
        </ChartCard>

        <div className="rounded-xl border border-border bg-card">
          <div className="px-4 py-3 border-b border-border text-sm font-semibold">Rögzített bejegyzések ({entries.length})</div>
          {entries.length === 0 ? <p className="p-4 text-sm text-muted-foreground">Még nincs rögzítés.</p> : (
            <div className="overflow-auto max-h-80">
              <table className="w-full text-xs">
                <thead className="bg-muted/40">
                  <tr>
                    <th className="px-2 py-1.5 text-left">Idő</th><th className="px-2 py-1.5">Méhszáj</th><th className="px-2 py-1.5">Station</th>
                    <th className="px-2 py-1.5">FHR</th><th className="px-2 py-1.5">Ctx</th><th className="px-2 py-1.5">RR</th>
                    <th className="px-2 py-1.5">P</th><th className="px-2 py-1.5">Hőm</th><th className="px-2 py-1.5">Magzv.</th><th className="px-2 py-1.5">Oxy</th>
                  </tr>
                </thead>
                <tbody>
                  {entries.slice().reverse().map((e) => (
                    <tr key={e.id} className="border-t border-border font-mono">
                      <td className="px-2 py-1">{new Date(e.recorded_at).toLocaleTimeString("hu-HU", { hour: "2-digit", minute: "2-digit" })}</td>
                      <td className="px-2 py-1 text-center">{e.cervix_cm ?? "—"}</td>
                      <td className="px-2 py-1 text-center">{e.descent_station ?? "—"}</td>
                      <td className="px-2 py-1 text-center">{e.fetal_heart_rate ?? "—"}</td>
                      <td className="px-2 py-1 text-center">{e.contractions_per_10min ?? "—"}{e.contraction_duration_sec ? `×${e.contraction_duration_sec}s` : ""}</td>
                      <td className="px-2 py-1 text-center">{e.maternal_bp_sys ? `${e.maternal_bp_sys}/${e.maternal_bp_dia}` : "—"}</td>
                      <td className="px-2 py-1 text-center">{e.maternal_hr ?? "—"}</td>
                      <td className="px-2 py-1 text-center">{e.temp_c ?? "—"}</td>
                      <td className="px-2 py-1 text-center">{e.liquor_color ?? "—"}</td>
                      <td className="px-2 py-1 text-center">{e.oxytocin_mu ?? "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      <EntryForm partogramId={partogram.id} userId={userId} onSaved={onRefresh} />
    </div>
  );
}

function ChartCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-border bg-card p-3">
      <h3 className="text-sm font-semibold mb-2">{title}</h3>
      {children}
    </div>
  );
}

function EntryForm({ partogramId, userId, onSaved }: { partogramId: string; userId: string; onSaved: () => void }) {
  const [v, setV] = useState<Partial<Entry>>({});
  const [saving, setSaving] = useState(false);

  function up<K extends keyof Entry>(k: K, val: any) { setV((x) => ({ ...x, [k]: val === "" ? null : val })); }

  async function save() {
    setSaving(true);
    const row: any = {
      partogram_id: partogramId,
      created_by: userId,
      recorded_at: new Date().toISOString(),
      ...v,
    };
    const { error } = await supabase.from("obstetric_partogram_entries").insert(row);
    setSaving(false);
    if (error) toast.error(error.message);
    else { toast.success("Rögzítve"); setV({}); onSaved(); }
  }

  return (
    <aside className="rounded-xl border border-border bg-card p-4 space-y-3 xl:sticky xl:top-4 h-fit">
      <h3 className="text-sm font-semibold">Gyors-rögzítés</h3>
      <div className="grid grid-cols-2 gap-2">
        <NumF label="Méhszáj (cm)" step={0.5} v={v.cervix_cm} on={(x) => up("cervix_cm", x)} />
        <NumF label="Fej-állás (−5…+5)" step={1} v={v.descent_station} on={(x) => up("descent_station", x)} />
        <NumF label="FHR /min" step={1} v={v.fetal_heart_rate} on={(x) => up("fetal_heart_rate", x)} />
        <NumF label="Ctx /10 perc" step={1} v={v.contractions_per_10min} on={(x) => up("contractions_per_10min", x)} />
        <NumF label="Ctx tartam (s)" step={5} v={v.contraction_duration_sec} on={(x) => up("contraction_duration_sec", x)} />
        <NumF label="Anyai pulzus" step={1} v={v.maternal_hr} on={(x) => up("maternal_hr", x)} />
        <NumF label="RR sys" step={1} v={v.maternal_bp_sys} on={(x) => up("maternal_bp_sys", x)} />
        <NumF label="RR dia" step={1} v={v.maternal_bp_dia} on={(x) => up("maternal_bp_dia", x)} />
        <NumF label="Hőm. (°C)" step={0.1} v={v.temp_c} on={(x) => up("temp_c", x)} />
        <NumF label="Oxytocin (mU/perc)" step={0.5} v={v.oxytocin_mu} on={(x) => up("oxytocin_mu", x)} />
      </div>
      <SelF label="Magzatvíz" options={LIQUOR.map((l) => ({ v: l.v, label: l.label }))} v={v.liquor_color ?? ""} on={(x) => up("liquor_color", x)} />
      <SelF label="Moulding" options={MOULDING.map((m) => ({ v: m, label: m }))} v={v.moulding ?? ""} on={(x) => up("moulding", x)} />
      <label className="block">
        <span className="text-xs text-muted-foreground">Gyógyszer</span>
        <input value={v.drugs_text ?? ""} onChange={(e) => up("drugs_text", e.target.value)}
          className="mt-1 w-full px-2 py-1 text-sm rounded-md border border-border bg-background" />
      </label>
      <label className="block">
        <span className="text-xs text-muted-foreground">Megjegyzés</span>
        <textarea value={v.notes ?? ""} onChange={(e) => up("notes", e.target.value)} rows={2}
          className="mt-1 w-full px-2 py-1 text-sm rounded-md border border-border bg-background" />
      </label>
      <button onClick={save} disabled={saving}
        className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 text-sm rounded-md bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50">
        {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />} Rögzítés
      </button>
    </aside>
  );
}

function NumF({ label, step, v, on }: { label: string; step: number; v: any; on: (v: number | "") => void }) {
  return (
    <label className="block">
      <span className="text-[10px] text-muted-foreground">{label}</span>
      <input type="number" step={step} value={v ?? ""} onChange={(e) => on(e.target.value === "" ? "" : Number(e.target.value))}
        className="mt-0.5 w-full px-2 py-1 text-sm rounded-md border border-border bg-background font-mono" />
    </label>
  );
}
function SelF({ label, options, v, on }: { label: string; options: { v: string; label: string }[]; v: string; on: (v: string) => void }) {
  return (
    <label className="block">
      <span className="text-xs text-muted-foreground">{label}</span>
      <select value={v} onChange={(e) => on(e.target.value)} className="mt-1 w-full px-2 py-1.5 text-sm rounded-md border border-border bg-background">
        <option value="">—</option>
        {options.map((o) => <option key={o.v} value={o.v}>{o.label}</option>)}
      </select>
    </label>
  );
}

function ExportToolbar({ disabled, patient, encounter, partogram, entries, alerts, userId }: {
  disabled: boolean; patient: any; encounter: any; partogram: Partogram; entries: Entry[]; alerts: string[]; userId: string;
}) {
  const [saving, setSaving] = useState(false);

  async function saveToRecord() {
    if (!encounter) return;
    setSaving(true);
    const text = buildPartogramText({ patient, encounter, partogram, entries, alerts });
    const title = `Partogram export — ${new Date().toLocaleString("hu-HU")}`;
    const { error } = await supabase.from("clinical_notes").insert({
      encounter_id: encounter.id,
      patient_id: encounter.patient_id,
      author_id: userId,
      kind: "partogram_export",
      title,
      body_md: "```\n" + text + "\n```",
      structured_json: { partogram_id: partogram.id, entry_count: entries.length, alerts },
      ai_generated: false,
    });
    setSaving(false);
    if (error) toast.error(error.message);
    else toast.success("Mentve a beteg dokumentációjába");
  }

  const payload = { patient, encounter, partogram, entries, alerts };
  const btn = "inline-flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-md border border-border bg-card hover:bg-muted disabled:opacity-50";

  return (
    <div className="flex flex-wrap justify-end gap-2">
      <button onClick={() => printPartogram(payload)} disabled={disabled} className={btn}>
        <Printer className="h-3.5 w-3.5" /> Nyomtatás
      </button>
      <button onClick={() => downloadPartogramText(payload)} disabled={disabled} className={btn}>
        <FileText className="h-3.5 w-3.5" /> TXT export
      </button>
      <button onClick={() => exportPartogramPdf(payload)} disabled={disabled} className={btn}>
        <FileDown className="h-3.5 w-3.5" /> PDF export
      </button>
      <button onClick={saveToRecord} disabled={disabled || saving}
        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-md bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50">
        {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Archive className="h-3.5 w-3.5" />} Mentés a beteghez
      </button>
    </div>
  );
}
