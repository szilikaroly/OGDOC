import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Baby } from "lucide-react";
import { CalculatorShell, Card, Field, NumberInput, ScoreBadge } from "@/components/clinical/calc-shell";
import {
  scoreAPGAR, scoreBishop,
  type ApgarInput, type BishopInput,
} from "@/lib/clinical/scores";

export const Route = createFileRoute("/_authenticated/klinika/eszkozok/szules")({
  validateSearch: (s: Record<string, unknown>): { encounterId?: string; patientId?: string } => ({
    encounterId: typeof s.encounterId === "string" ? s.encounterId : undefined,
    patientId: typeof s.patientId === "string" ? s.patientId : undefined,
  }),
  component: SzulesPage,
});

const APGAR_OPTS: Record<keyof ApgarInput, [string, string, string]> = {
  heart_rate: ["nincs", "< 100", "≥ 100"],
  respiratory: ["nincs", "lassú/szabálytalan", "jó sírás"],
  muscle_tone: ["atonia", "enyhe flexió", "aktív mozgás"],
  reflex: ["nincs", "grimasz", "sírás / köhögés"],
  color: ["cianotikus / sápadt", "akrocianózis", "teljes rózsaszín"],
};
const APGAR_LABEL: Record<keyof ApgarInput, string> = {
  heart_rate: "Szívfrekvencia",
  respiratory: "Légzés",
  muscle_tone: "Izomtónus",
  reflex: "Reflex / ingerlékenység",
  color: "Bőrszín",
};

function SzulesPage() {
  const [tab, setTab] = useState<"apgar" | "bishop">("apgar");
  const [a, setA] = useState<ApgarInput>({ heart_rate: 2, respiratory: 2, muscle_tone: 2, reflex: 2, color: 2 });
  const [b, setB] = useState<BishopInput>({ dilation_cm: 2, effacement_pct: 50, station: -1, consistency: "kozepes", position: "kozepes" });

  const aR = useMemo(() => scoreAPGAR(a), [a]);
  const bR = useMemo(() => scoreBishop(b), [b]);

  return (
    <CalculatorShell
      title="Szülészet — APGAR & Bishop"
      subtitle="Újszülött adaptáció (AAP) és cervix érettség indukció előtt (Bishop 1964)."
      Icon={Baby}
      fromRoute="/_authenticated/klinika/eszkozok/szules"
      onReset={() => {
        setA({ heart_rate: 2, respiratory: 2, muscle_tone: 2, reflex: 2, color: 2 });
        setB({ dilation_cm: 2, effacement_pct: 50, station: -1, consistency: "kozepes", position: "kozepes" });
      }}
      getSaveBundle={() => tab === "apgar"
        ? { calculator: "apgar", inputs: a, outputs: aR, interpretation_md: `**APGAR:** ${aR.score}/10 · ${aR.category}\n\n${aR.note}` }
        : { calculator: "bishop", inputs: b, outputs: bR, interpretation_md: `**Bishop:** ${bR.score}/13\n\n${bR.interpretation}` }}
    >
      <div className="flex gap-2 border-b border-border">
        <Tab active={tab === "apgar"} onClick={() => setTab("apgar")}>APGAR</Tab>
        <Tab active={tab === "bishop"} onClick={() => setTab("bishop")}>Bishop</Tab>
      </div>

      {tab === "apgar" ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Card title="Paraméterek">
            {(Object.keys(APGAR_OPTS) as (keyof ApgarInput)[]).map((k) => (
              <Field key={k} label={APGAR_LABEL[k]}>
                <div className="flex gap-1">
                  {APGAR_OPTS[k].map((label, val) => (
                    <button
                      key={val}
                      onClick={() => setA({ ...a, [k]: val as 0 | 1 | 2 })}
                      className={`flex-1 px-2 py-1.5 text-xs rounded-md border ${a[k] === val ? "bg-primary text-primary-foreground border-primary" : "bg-background border-border hover:bg-accent"}`}
                    >
                      {val} · {label}
                    </button>
                  ))}
                </div>
              </Field>
            ))}
          </Card>
          <Card title="Eredmény" footer={aR.note}>
            <ScoreBadge score={`${aR.score}/10`} label={aR.category} tone={aR.score <= 3 ? "danger" : aR.score <= 6 ? "warn" : "ok"} />
          </Card>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Card title="Vaginális vizsgálat">
            <Field label="Tágulat (cm)"><NumberInput value={b.dilation_cm} onChange={(v) => setB({ ...b, dilation_cm: v ?? 0 })} /></Field>
            <Field label="Elvékonyodás (%)"><NumberInput value={b.effacement_pct} onChange={(v) => setB({ ...b, effacement_pct: v ?? 0 })} /></Field>
            <Field label="Beilleszkedés (station)">
              <select value={b.station} onChange={(e) => setB({ ...b, station: Number(e.target.value) as BishopInput["station"] })} className="w-full px-2 py-1.5 text-sm rounded-md border border-border bg-background">
                <option value={-3}>-3</option><option value={-2}>-2</option><option value={-1}>-1</option><option value={0}>0</option><option value={1}>+1 vagy +2</option>
              </select>
            </Field>
            <Field label="Konzisztencia">
              <select value={b.consistency} onChange={(e) => setB({ ...b, consistency: e.target.value as BishopInput["consistency"] })} className="w-full px-2 py-1.5 text-sm rounded-md border border-border bg-background">
                <option value="kemeny">kemény</option><option value="kozepes">közepes</option><option value="lagy">lágy</option>
              </select>
            </Field>
            <Field label="Pozíció">
              <select value={b.position} onChange={(e) => setB({ ...b, position: e.target.value as BishopInput["position"] })} className="w-full px-2 py-1.5 text-sm rounded-md border border-border bg-background">
                <option value="hatso">hátsó</option><option value="kozepes">közepes</option><option value="elulso">elülső</option>
              </select>
            </Field>
          </Card>
          <Card title="Eredmény" footer={bR.interpretation}>
            <ScoreBadge score={`${bR.score}/13`} tone={bR.score >= 8 ? "ok" : bR.score >= 6 ? "warn" : "danger"} />
            <ul className="text-sm grid grid-cols-2 gap-1 mt-2">
              {Object.entries(bR.parts).map(([k, v]) => (
                <li key={k} className="flex justify-between border-b border-border/50 py-1"><span>{k}</span><span className="font-mono">{v}</span></li>
              ))}
            </ul>
          </Card>
        </div>
      )}
    </CalculatorShell>
  );
}

function Tab({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button onClick={onClick} className={`px-4 py-2 text-sm font-medium border-b-2 -mb-px ${active ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"}`}>
      {children}
    </button>
  );
}
