/**
 * E2E teszt eszközök admin oldal.
 * - Bootstrap: 6 teszt user (e2e.admin/vezeto/sebesz1/sebesz2/recepcio/beteg) + role mapping.
 * - Cleanup adat: `cleanup_e2e_test_data()` RPC — minden E2E_ prefix-szel létrehozott rekord törlése.
 * - Cleanup user: e2e.*@medroster.test auth userek törlése Admin API-val.
 */
import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, UserPlus, Trash2, FlaskConical, Upload, CheckCircle2, XCircle, FileJson, Clock, ChevronDown, ChevronRight, RefreshCw, Copy, Image as ImageIcon, RotateCw } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import {
  bootstrapE2eUsers,
  cleanupE2eTestData,
  deleteE2eUsers,
} from "@/lib/admin/e2e-bootstrap.functions";

const LS_KEY = "medroster.e2e.lastJourney.v1";

export const Route = createFileRoute("/_authenticated/admin/e2e-teszt")({
  component: E2eTesztPage,
});

function E2eTesztPage() {
  const [busy, setBusy] = useState<string | null>(null);
  const [result, setResult] = useState<unknown>(null);
  const bootstrap = useServerFn(bootstrapE2eUsers);
  const cleanupData = useServerFn(cleanupE2eTestData);
  const cleanupUsers = useServerFn(deleteE2eUsers);

  async function run(name: string, fn: () => Promise<unknown>) {
    setBusy(name); setResult(null);
    try {
      const r = await fn();
      setResult(r);
      toast.success(name + " — kész");
    } catch (e: any) {
      setResult({ error: String(e?.message ?? e) });
      toast.error(name + " hiba: " + (e?.message ?? e));
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="container max-w-4xl py-8 space-y-6">
      <div className="flex items-center gap-3">
        <FlaskConical className="size-6 text-primary" />
        <div>
          <h1 className="text-2xl font-bold">E2E teszt eszközök</h1>
          <p className="text-sm text-muted-foreground">
            Automatizált tesztekhez szükséges felhasználók és törzsadatok kezelése.
            Csak <Badge variant="secondary">tenant_admin</Badge> használhatja.
          </p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><UserPlus className="size-4" /> Teszt felhasználók létrehozása</CardTitle>
          <CardDescription>
            6 auth user: <code>e2e.admin</code> / <code>vezeto</code> / <code>sebesz1</code> /{" "}
            <code>sebesz2</code> / <code>recepcio</code> / <code>beteg</code> @medroster.test.
            Jelszó: <code className="bg-muted px-1 rounded">E2eTest!2026</code>. Profile + szerepkör automatikusan.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Button disabled={!!busy} onClick={() => run("Bootstrap users", () => bootstrap({ data: undefined as any }))}>
            {busy === "Bootstrap users" ? <Loader2 className="size-4 animate-spin mr-2" /> : <UserPlus className="size-4 mr-2" />}
            Userek létrehozása / frissítése
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-destructive"><Trash2 className="size-4" /> Adattisztítás</CardTitle>
          <CardDescription>
            A migrációval létrehozott <code>E2E_</code> prefix-szel jelölt törzsadatok (műtő, ambulancia,
            sablon, surgery_type, küszöb, eszkalációs szabály, teszt beteg) és függő blokkok törlése.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex gap-2 flex-wrap">
          <Button variant="destructive" disabled={!!busy}
            onClick={() => { if (confirm("Biztosan törlöd az összes E2E_ rekordot?")) run("Cleanup data", () => cleanupData({ data: undefined as any })); }}>
            {busy === "Cleanup data" ? <Loader2 className="size-4 animate-spin mr-2" /> : <Trash2 className="size-4 mr-2" />}
            Teszt adatok törlése
          </Button>
          <Button variant="outline" disabled={!!busy}
            onClick={() => { if (confirm("Biztosan törlöd az e2e.* auth usereket?")) run("Cleanup users", () => cleanupUsers({ data: undefined as any })); }}>
            {busy === "Cleanup users" ? <Loader2 className="size-4 animate-spin mr-2" /> : <Trash2 className="size-4 mr-2" />}
            Teszt userek törlése
          </Button>
        </CardContent>
      </Card>

      {result !== null && (
        <Card>
          <CardHeader><CardTitle className="text-sm">Eredmény</CardTitle></CardHeader>
          <CardContent>
            <pre className="text-xs bg-muted p-3 rounded overflow-auto max-h-96">
              {JSON.stringify(result, null, 2)}
            </pre>
          </CardContent>
        </Card>
      )}

      <JourneyResultPanel />

      <Card>
        <CardHeader><CardTitle className="text-sm">Playwright forgatókönyv</CardTitle></CardHeader>
        <CardContent className="text-sm space-y-2 text-muted-foreground">
          <p>Userek létrehozása után helyileg futtasd:</p>
          <pre className="bg-muted p-2 rounded text-xs">python tests/e2e/full-clinical-journey.py</pre>
          <p>Eredmény: <code>/tmp/browser/journey/journey-result.json</code> — töltsd fel a fenti panelra.</p>
        </CardContent>
      </Card>
    </div>
  );
}

// ─── Journey eredmény panel ───────────────────────────────────────────
type JourneyStep = {
  step: number;
  name: string;
  status: "PASS" | "FAIL" | "BLOCKED" | string;
  note?: string;
  ts?: string;
  expected?: unknown;
  actual?: unknown;
  log?: string[];
  attachments?: string[]; // pl. ["03_lelet_klinika.png"]
};
type JourneyResult = {
  base_url?: string;
  duration_s?: number;
  total_steps?: number;
  passed?: number;
  failed?: number;
  loaded_at?: string;
  source?: string;
  steps: JourneyStep[];
};

function JourneyResultPanel() {
  const [data, setData] = useState<JourneyResult | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  const [shots, setShots] = useState<Record<string, string>>({}); // filename → blob URL
  const [openStep, setOpenStep] = useState<number | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  // ── Auto-load utolsó futás localStorage-ből ──
  useEffect(() => {
    try {
      const raw = localStorage.getItem(LS_KEY);
      if (!raw) return;
      const parsed = JSON.parse(raw) as JourneyResult;
      if (Array.isArray(parsed?.steps)) {
        setData(parsed);
        setFileName(parsed.source ?? "automatikus betöltés");
      }
    } catch {/* ignore */}
  }, []);

  function persist(json: JourneyResult, source: string) {
    const enriched: JourneyResult = { ...json, loaded_at: new Date().toISOString(), source };
    try { localStorage.setItem(LS_KEY, JSON.stringify(enriched)); } catch {/* quota */}
    setData(enriched);
  }

  async function onFile(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (!f) return;
    setFileName(f.name); setErr(null);
    try {
      const txt = await f.text();
      const json = JSON.parse(txt);
      if (!Array.isArray(json?.steps)) throw new Error("Hiányzó 'steps' tömb a JSON-ben");
      persist(json, f.name);
      toast.success(`Betöltve: ${json.steps.length} lépés`);
    } catch (e: any) {
      setErr(String(e?.message ?? e));
      toast.error("Parse hiba: " + (e?.message ?? e));
    }
  }

  function onScreenshots(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files ?? []);
    if (!files.length) return;
    const map: Record<string, string> = { ...shots };
    files.forEach((f) => { map[f.name] = URL.createObjectURL(f); });
    setShots(map);
    toast.success(`${files.length} képernyőkép betöltve`);
  }

  function clearCache() {
    try { localStorage.removeItem(LS_KEY); } catch {}
    setData(null); setFileName(null); setErr(null); setOpenStep(null);
    Object.values(shots).forEach((u) => URL.revokeObjectURL(u));
    setShots({});
    toast.success("Cache törölve");
  }

  function loadDemo() {
    const demo: JourneyResult = {
      base_url: "http://localhost:8080",
      duration_s: 42.5,
      total_steps: 3, passed: 2, failed: 1,
      steps: [
        { step: 1, name: "Admin szerepkör-osztás", status: "PASS", note: "screenshot mentve",
          log: ["login as admin", "GET /admin/szerepkorok 200", "screenshot 01_admin.png"],
          attachments: ["01_admin_szerepkorok.png"] },
        { step: 2, name: "Vezető — OR-blokk operatőr-kiosztás", status: "PASS", note: "",
          expected: { sebesz_user_id: "uuid" }, actual: { sebesz_user_id: "e2e.sebesz1@..." } },
        { step: 3, name: "Lelet + kritikus mérés", status: "FAIL", note: "selector nem található",
          expected: { observation_count: 1, alert_count: 1 },
          actual: { observation_count: 1, alert_count: 0 },
          log: ["click 'Új lelet' → OK", "input vércukor=14.5", "expect alert row → TIMEOUT 5000ms"] },
      ],
    };
    persist(demo, "demo");
  }

  const passed = data?.steps.filter((s) => s.status === "PASS").length ?? 0;
  const failed = data?.steps.filter((s) => s.status === "FAIL").length ?? 0;
  const blocked = data?.steps.filter((s) => s.status === "BLOCKED").length ?? 0;
  const total = data?.steps.length ?? 0;
  const passPct = total ? Math.round((passed / total) * 100) : 0;
  const failedSteps = useMemo(
    () => data?.steps.filter((s) => s.status === "FAIL" || s.status === "BLOCKED") ?? [],
    [data],
  );

  const rerunCmd = useMemo(() => {
    const ids = failedSteps.map((s) => s.step).join(",");
    return ids
      ? `python tests/e2e/full-clinical-journey.py --only ${ids}`
      : "python tests/e2e/full-clinical-journey.py";
  }, [failedSteps]);

  async function copyRerun() {
    try {
      await navigator.clipboard.writeText(rerunCmd);
      toast.success("Parancs vágólapon — futtasd a teszt gépen, majd töltsd fel az új JSON-t");
    } catch {
      toast.error("Vágólap nem elérhető");
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><FileJson className="size-4" /> E2E eredmény-összegző</CardTitle>
        <CardDescription>
          Töltsd fel a <code>journey-result.json</code>-t és (opcionális) a screenshot mappa fájljait.
          Az utolsó betöltés automatikusan megmarad ezen a böngészőn.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2 flex-wrap items-center">
          <Button type="button" variant="outline" onClick={() => fileRef.current?.click()}>
            <Upload className="size-4 mr-2" />journey-result.json
          </Button>
          <input ref={fileRef} type="file" accept="application/json,.json" className="hidden" onChange={onFile} />

          <label className="inline-flex">
            <Button type="button" variant="outline" asChild>
              <span><ImageIcon className="size-4 mr-2" />Screenshotok</span>
            </Button>
            <input type="file" accept="image/png,image/jpeg" multiple className="hidden" onChange={onScreenshots} />
          </label>

          <Button type="button" variant="ghost" size="sm" onClick={loadDemo}>Demo</Button>
          <Button type="button" variant="ghost" size="sm" onClick={clearCache}><RotateCw className="size-3 mr-1" />Cache ürítés</Button>
          {fileName && <Badge variant="secondary" className="font-mono text-xs">{fileName}</Badge>}
          {data?.loaded_at && (
            <span className="text-[10px] text-muted-foreground ml-auto">
              betöltve: {new Date(data.loaded_at).toLocaleString("hu-HU")}
            </span>
          )}
        </div>

        {err && <div className="text-sm text-destructive">{err}</div>}

        {data && (
          <>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <Stat label="Összes" value={total} />
              <Stat label="PASS" value={passed} tone="success" />
              <Stat label="FAIL" value={failed} tone="destructive" />
              <Stat label="BLOCKED" value={blocked} tone="warning" />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-muted-foreground">Sikeresség</span>
                <span className="font-medium">{passPct}%</span>
              </div>
              <Progress value={passPct} />
            </div>

            <div className="flex gap-4 text-xs text-muted-foreground flex-wrap items-center">
              {data.base_url && <span>🌐 {data.base_url}</span>}
              {data.duration_s != null && <span><Clock className="size-3 inline mr-1" />{data.duration_s}s</span>}
              {Object.keys(shots).length > 0 && <span>🖼 {Object.keys(shots).length} screenshot</span>}
            </div>

            {failedSteps.length > 0 && (
              <div className="border border-destructive/40 rounded-lg p-3 bg-destructive/5 space-y-3">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <h4 className="text-sm font-semibold text-destructive">
                    Sikertelen lépések ({failedSteps.length})
                  </h4>
                  <div className="flex gap-1">
                    <Button size="sm" variant="outline" onClick={copyRerun} className="h-7">
                      <Copy className="size-3 mr-1" />Re-run parancs másolása
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => fileRef.current?.click()} className="h-7">
                      <RefreshCw className="size-3 mr-1" />Új JSON betöltése
                    </Button>
                  </div>
                </div>
                <code className="block bg-muted/60 text-[10px] p-2 rounded font-mono overflow-x-auto">{rerunCmd}</code>
                <p className="text-[11px] text-muted-foreground">
                  Lefuttatja csak a sikertelen lépéseket a teszt gépen. A frissült{" "}
                  <code>journey-result.json</code>-t töltsd vissza az „Új JSON betöltése” gombbal —
                  a panel automatikusan frissül.
                </p>
              </div>
            )}

            <div className="border rounded-lg divide-y">
              {data.steps.map((s) => (
                <StepRow
                  key={s.step}
                  step={s}
                  open={openStep === s.step}
                  onToggle={() => setOpenStep(openStep === s.step ? null : s.step)}
                  screenshots={shots}
                />
              ))}
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}

function StepRow({
  step, open, onToggle, screenshots,
}: { step: JourneyStep; open: boolean; onToggle: () => void; screenshots: Record<string, string> }) {
  const hasDetails = !!(step.log?.length || step.expected != null || step.actual != null || step.attachments?.length || step.note);
  const resolvedShots = (step.attachments ?? [])
    .map((name) => ({ name, url: screenshots[name] }))
    .filter((s) => !!s.url);

  return (
    <Collapsible open={open} onOpenChange={onToggle}>
      <CollapsibleTrigger className="w-full text-left" disabled={!hasDetails}>
        <div className="flex items-start gap-3 p-2 text-sm hover:bg-muted/40 transition-colors">
          <span className="text-muted-foreground font-mono text-xs w-8 shrink-0 pt-0.5">
            {step.step.toString().padStart(2, "0")}
          </span>
          {hasDetails ? (
            open ? <ChevronDown className="size-4 shrink-0 mt-0.5 text-muted-foreground" />
                 : <ChevronRight className="size-4 shrink-0 mt-0.5 text-muted-foreground" />
          ) : <span className="w-4 shrink-0" />}
          <StatusIcon status={step.status} />
          <div className="flex-1 min-w-0">
            <div className="font-medium truncate">{step.name}</div>
            {step.note && <div className="text-xs text-muted-foreground truncate">{step.note}</div>}
          </div>
          <Badge variant={step.status === "PASS" ? "secondary" : step.status === "FAIL" ? "destructive" : "outline"} className="text-[10px] shrink-0">
            {step.status}
          </Badge>
        </div>
      </CollapsibleTrigger>
      <CollapsibleContent>
        <div className="px-3 pb-3 pl-14 space-y-3 bg-muted/20">
          {step.note && (
            <div>
              <div className="text-[10px] uppercase text-muted-foreground mb-1">Megjegyzés</div>
              <div className="text-xs">{step.note}</div>
            </div>
          )}
          {(step.expected != null || step.actual != null) && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              <div className="border rounded p-2 bg-emerald-500/5">
                <div className="text-[10px] uppercase text-emerald-700 mb-1">Várt</div>
                <pre className="text-[11px] font-mono whitespace-pre-wrap break-words">{JSON.stringify(step.expected ?? null, null, 2)}</pre>
              </div>
              <div className="border rounded p-2 bg-destructive/5">
                <div className="text-[10px] uppercase text-destructive mb-1">Tényleges</div>
                <pre className="text-[11px] font-mono whitespace-pre-wrap break-words">{JSON.stringify(step.actual ?? null, null, 2)}</pre>
              </div>
            </div>
          )}
          {step.log?.length ? (
            <div>
              <div className="text-[10px] uppercase text-muted-foreground mb-1">Log ({step.log.length})</div>
              <pre className="text-[11px] font-mono bg-background border rounded p-2 max-h-48 overflow-auto">
                {step.log.map((l, i) => `${(i + 1).toString().padStart(2, " ")}  ${l}`).join("\n")}
              </pre>
            </div>
          ) : null}
          {step.attachments?.length ? (
            <div>
              <div className="text-[10px] uppercase text-muted-foreground mb-1">
                Képernyőképek ({resolvedShots.length}/{step.attachments.length})
              </div>
              {resolvedShots.length === 0 ? (
                <div className="text-[11px] text-muted-foreground">
                  Hiányzó képek: {step.attachments.join(", ")} — töltsd fel a „Screenshotok” gombbal.
                </div>
              ) : (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {resolvedShots.map((s) => (
                    <a key={s.name} href={s.url} target="_blank" rel="noreferrer" className="block border rounded overflow-hidden hover:opacity-90">
                      <img src={s.url} alt={s.name} className="w-full h-32 object-cover" />
                      <div className="text-[10px] font-mono p-1 truncate bg-background">{s.name}</div>
                    </a>
                  ))}
                </div>
              )}
            </div>
          ) : null}
        </div>
      </CollapsibleContent>
    </Collapsible>
  );
}

function Stat({ label, value, tone }: { label: string; value: number; tone?: "success" | "destructive" | "warning" }) {
  const cls = tone === "success" ? "text-emerald-600" : tone === "destructive" ? "text-destructive" : tone === "warning" ? "text-amber-600" : "";
  return (
    <div className="border rounded-lg p-3">
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className={"text-2xl font-bold " + cls}>{value}</div>
    </div>
  );
}

function StatusIcon({ status }: { status: string }) {
  if (status === "PASS") return <CheckCircle2 className="size-4 text-emerald-600 shrink-0 mt-0.5" />;
  if (status === "FAIL") return <XCircle className="size-4 text-destructive shrink-0 mt-0.5" />;
  return <Clock className="size-4 text-amber-600 shrink-0 mt-0.5" />;
}

