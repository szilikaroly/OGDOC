/**
 * /admin/forditasok – fordítás-cache és glossary kezelő.
 */
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Trash2, Pencil, RotateCcw, Search, AlertTriangle, RefreshCw, Sparkles } from "lucide-react";
import { toast } from "sonner";
import {
  listTranslations,
  updateTranslation,
  deleteTranslation,
  retranslateAll,
  listGlossary,
  upsertGlossary,
  deleteGlossary,
  listMissingKeys,
  deleteMissingKey,
  processMissingKeys,
} from "@/lib/i18n/admin.functions";
import { SUPPORTED_LANGUAGES } from "@/i18n/languages";
import {
  listTranslationErrors,
  subscribeTranslationErrors,
  clearTranslationError,
  type TranslationError,
} from "@/lib/i18n/translation-errors";
import { translateBatch, translateBatchSafe } from "@/lib/i18n/translate.functions";
import { listNewsTranslationStatus, translateNewsPosts } from "@/lib/cms/i18n-news.functions";
import { Checkbox } from "@/components/ui/checkbox";
import { Newspaper } from "lucide-react";
import { useEffect } from "react";
import { hu as huLocale } from "@/i18n/locales/hu";
import { TranslationStudio } from "@/components/i18n/translation-studio";
import { LANG_CODES } from "@/i18n/languages";

function ForditasokAdmin() {
  return (
    <main className="p-6 space-y-4 max-w-7xl">
      <header>
        <h1 className="text-2xl font-bold">Fordításkezelő</h1>
        <p className="text-sm text-muted-foreground">
          Hiányzó kulcsok, kézi felülbírálás, glossary és újrafordítás.
        </p>
      </header>
      <Tabs defaultValue="studio">
        <TabsList>
          <TabsTrigger value="studio">Fordító Stúdió</TabsTrigger>
          <TabsTrigger value="prefetch">Előfordítás</TabsTrigger>
          <TabsTrigger value="missing">Hiányzó kulcsok</TabsTrigger>
          <TabsTrigger value="news">Hírek</TabsTrigger>
          <TabsTrigger value="cache">Fordítások</TabsTrigger>
          <TabsTrigger value="glossary">Szótár</TabsTrigger>
          <TabsTrigger value="errors">Hibák</TabsTrigger>
        </TabsList>
        <TabsContent value="studio"><TranslationStudio /></TabsContent>
        <TabsContent value="prefetch"><PrefetchTab /></TabsContent>
        <TabsContent value="missing"><MissingKeysTab /></TabsContent>
        <TabsContent value="news"><NewsTab /></TabsContent>
        <TabsContent value="cache"><TranslationsTab /></TabsContent>
        <TabsContent value="glossary"><GlossaryTab /></TabsContent>
        <TabsContent value="errors"><ErrorsTab /></TabsContent>
      </Tabs>
    </main>
  );
}

type AnyDict = Record<string, unknown>;
function flatten(obj: AnyDict, prefix = ""): Record<string, string> {
  const out: Record<string, string> = {};
  for (const [k, v] of Object.entries(obj)) {
    const p = prefix ? `${prefix}.${k}` : k;
    if (v && typeof v === "object" && !Array.isArray(v)) Object.assign(out, flatten(v as AnyDict, p));
    else if (typeof v === "string") out[p] = v;
  }
  return out;
}

function PrefetchTab() {
  const huFlat = flatten(huLocale as unknown as AnyDict);
  const allKeys = Object.keys(huFlat);
  const targets = LANG_CODES.filter((c) => c !== "hu");

  const [selected, setSelected] = useState<string[]>(["en"]);
  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState<{ lang: string; done: number; total: number; failed: number } | null>(null);
  const [log, setLog] = useState<string[]>([]);

  function toggle(code: string) {
    setSelected((s) => (s.includes(code) ? s.filter((x) => x !== code) : [...s, code]));
  }

  async function run() {
    if (selected.length === 0) {
      toast.error("Válassz legalább egy nyelvet");
      return;
    }
    setRunning(true);
    setLog([]);
    const CHUNK = 80;
    try {
      for (const lang of selected) {
        let failed = 0;
        setProgress({ lang, done: 0, total: allKeys.length, failed: 0 });
        for (let i = 0; i < allKeys.length; i += CHUNK) {
          const slice = allKeys.slice(i, i + CHUNK);
          const items = slice.map((k) => ({ key: k, source: huFlat[k], namespace: "ui" }));
          try {
            await translateBatch({ data: { items, target_lang: lang, kind: "ui", db_only: false } });
          } catch (e: any) {
            failed += slice.length;
            setLog((l) => [...l, `[${lang}] hiba @${i}: ${e?.message ?? "ismeretlen"}`]);
          }
          setProgress({ lang, done: Math.min(i + CHUNK, allKeys.length), total: allKeys.length, failed });
        }
        setLog((l) => [...l, `[${lang}] kész — ${allKeys.length - failed}/${allKeys.length}`]);
      }
      toast.success("Előfordítás kész");
    } finally {
      setRunning(false);
    }
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Teljes UI szótár előfordítása DB-be</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-sm text-muted-foreground">
            {allKeys.length} forráskulcs (locales/hu.ts). Cache-elt értékek kihagyva — csak a hiányzókat fordítja AI.
            Egy nyelv kb. {Math.ceil(allKeys.length / 80)} AI-hívás (max 80 elem / batch).
          </p>
          <div className="flex flex-wrap gap-2">
            {targets.map((code) => {
              const lang = SUPPORTED_LANGUAGES.find((l) => l.code === code)!;
              const active = selected.includes(code);
              return (
                <Button key={code} type="button" size="sm" variant={active ? "default" : "outline"} onClick={() => toggle(code)}>
                  {lang.flag} {lang.label}
                </Button>
              );
            })}
            <Button size="sm" variant="ghost" onClick={() => setSelected(targets as string[])}>Mind</Button>
            <Button size="sm" variant="ghost" onClick={() => setSelected([])}>Egyik se</Button>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button onClick={run} disabled={running}>
              <Sparkles className="h-4 w-4 mr-1.5" />
              {running ? "Fordítás folyamatban…" : `Indítás (${selected.length} nyelv)`}
            </Button>
            <Button
              variant="secondary"
              disabled={running}
              onClick={async () => {
                const all = targets as string[];
                setSelected(all);
                // Várjuk meg a state-frissítést egy tickkel, majd indítsuk.
                await new Promise((r) => setTimeout(r, 0));
                await run();
              }}
            >
              <Sparkles className="h-4 w-4 mr-1.5" />
              Mindet, egy gombnyomásra ({targets.length} nyelv)
            </Button>
          </div>

          {progress && (
            <div className="text-sm">
              <Badge variant="outline">{progress.lang}</Badge>{" "}
              {progress.done} / {progress.total} {progress.failed > 0 && <span className="text-destructive">({progress.failed} hiba)</span>}
              <div className="mt-1 h-2 bg-muted rounded overflow-hidden">
                <div className="h-full bg-primary transition-all" style={{ width: `${(progress.done / progress.total) * 100}%` }} />
              </div>
            </div>
          )}
          {log.length > 0 && (
            <div className="text-xs font-mono bg-muted p-2 rounded max-h-48 overflow-auto space-y-0.5">
              {log.map((l, i) => <div key={i}>{l}</div>)}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function MissingKeysTab() {
  const qc = useQueryClient();
  const [lang, setLang] = useState<string>("en");
  const list = useQuery({
    queryKey: ["i18n-missing", lang],
    queryFn: () => listMissingKeys({ data: { lang, limit: 500 } }),
  });
  const process = useMutation({
    mutationFn: () => processMissingKeys({ data: { lang, batch_size: 100 } }),
    onSuccess: (r) => {
      toast.success(`${r.processed} lefordítva · ${r.remaining} még hátra`);
      qc.invalidateQueries({ queryKey: ["i18n-missing"] });
      qc.invalidateQueries({ queryKey: ["i18n-translations"] });
    },
    onError: (e: any) => toast.error(e?.message ?? "Sikertelen"),
  });
  const del = useMutation({
    mutationFn: (id: string) => deleteMissingKey({ data: { id } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["i18n-missing"] }),
  });

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        <Select value={lang} onValueChange={setLang}>
          <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
          <SelectContent>
            {SUPPORTED_LANGUAGES.filter((l) => l.code !== "hu").map((l) => (
              <SelectItem key={l.code} value={l.code}>{l.flag} {l.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Button variant="outline" onClick={() => list.refetch()}>
          <RefreshCw className="h-4 w-4 mr-1.5" />Frissítés
        </Button>
        <Button onClick={() => process.mutate()} disabled={process.isPending || (list.data ?? []).length === 0}>
          <Sparkles className="h-4 w-4 mr-1.5" />
          {process.isPending ? "Fordítás…" : `AI fordítás (max 100, ${lang})`}
        </Button>
        <span className="text-sm text-muted-foreground ml-auto">
          {(list.data ?? []).length} hiányzó bejegyzés
        </span>
      </div>
      {list.isLoading && <p className="text-sm text-muted-foreground">Betöltés…</p>}
      <div className="border rounded-lg divide-y">
        {(list.data ?? []).map((row) => (
          <div key={row.id} className="p-3 grid grid-cols-[1fr_auto_auto] gap-2 items-center text-sm">
            <div>
              <div className="text-xs text-muted-foreground font-mono">{row.namespace} · {row.key}</div>
              <div className="mt-1 whitespace-pre-wrap">{row.source_text}</div>
            </div>
            <Badge variant="outline" className="text-[10px]">{row.hits}×</Badge>
            <Button variant="ghost" size="icon" onClick={() => del.mutate(row.id)}><Trash2 className="h-4 w-4" /></Button>
          </div>
        ))}
        {!list.isLoading && (list.data ?? []).length === 0 && (
          <p className="p-6 text-center text-sm text-muted-foreground">Nincs hiányzó kulcs ezen a nyelven 🎉</p>
        )}
      </div>
    </div>
  );
}

function TranslationsTab() {
  const qc = useQueryClient();
  const [lang, setLang] = useState<string>("en");
  const [search, setSearch] = useState("");
  const [editing, setEditing] = useState<{ id: string; value: string } | null>(null);

  const list = useQuery({
    queryKey: ["i18n-translations", lang, search],
    queryFn: () => listTranslations({ data: { lang, search: search || undefined, limit: 300 } }),
  });

  const upd = useMutation({
    mutationFn: (v: { id: string; value: string }) => updateTranslation({ data: v }),
    onSuccess: () => {
      toast.success("Mentve");
      setEditing(null);
      qc.invalidateQueries({ queryKey: ["i18n-translations"] });
    },
    onError: (e: any) => toast.error(e?.message ?? "Mentés sikertelen"),
  });
  const del = useMutation({
    mutationFn: (id: string) => deleteTranslation({ data: { id } }),
    onSuccess: () => {
      toast.success("Törölve");
      qc.invalidateQueries({ queryKey: ["i18n-translations"] });
    },
  });
  const retry = useMutation({
    mutationFn: () => retranslateAll({ data: { lang } }),
    onSuccess: (r) => {
      toast.success(`${r.cleared} bejegyzés törölve – újratöltődik használatkor`);
      qc.invalidateQueries({ queryKey: ["i18n-translations"] });
    },
    onError: (e: any) => toast.error(e?.message ?? "Sikertelen"),
  });

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        <Select value={lang} onValueChange={setLang}>
          <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
          <SelectContent>
            {SUPPORTED_LANGUAGES.filter((l) => l.code !== "hu").map((l) => (
              <SelectItem key={l.code} value={l.code}>{l.flag} {l.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <div className="relative flex-1 min-w-[200px] max-w-md">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input className="pl-8" placeholder="Keresés (forrás / kulcs / fordítás)…" value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <Button variant="outline" onClick={() => list.refetch()}>
          <RefreshCw className="h-4 w-4 mr-1.5" />Frissítés
        </Button>
        <Button variant="destructive" onClick={() => retry.mutate()} disabled={retry.isPending}>
          <RotateCcw className="h-4 w-4 mr-1.5" />Összes újrafordítása ({lang})
        </Button>
      </div>

      {list.isLoading && <p className="text-sm text-muted-foreground">Betöltés…</p>}
      {list.error && <p className="text-sm text-destructive">{(list.error as Error).message}</p>}

      <div className="border rounded-lg divide-y">
        {(list.data ?? []).map((row) => (
          <div key={row.id} className="p-3 grid grid-cols-1 md:grid-cols-[1fr_1fr_auto] gap-2 items-start text-sm">
            <div>
              <div className="text-xs text-muted-foreground font-mono">{row.namespace} · {row.key}</div>
              <div className="mt-1 whitespace-pre-wrap">{row.source_text}</div>
            </div>
            <div>
              <div className="text-xs text-muted-foreground flex items-center gap-1">
                {row.lang} {row.edited_by_user && <Badge variant="secondary" className="text-[10px]">kézi</Badge>}
              </div>
              <div className="mt-1 whitespace-pre-wrap">{row.value}</div>
            </div>
            <div className="flex gap-1">
              <Button variant="ghost" size="icon" onClick={() => setEditing({ id: row.id, value: row.value })}><Pencil className="h-4 w-4" /></Button>
              <Button variant="ghost" size="icon" onClick={() => del.mutate(row.id)}><Trash2 className="h-4 w-4" /></Button>
            </div>
          </div>
        ))}
        {!list.isLoading && (list.data ?? []).length === 0 && (
          <p className="p-6 text-center text-sm text-muted-foreground">Nincs bejegyzés</p>
        )}
      </div>

      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Fordítás szerkesztése</DialogTitle></DialogHeader>
          <textarea
            className="w-full min-h-32 rounded border bg-background p-2 text-sm"
            value={editing?.value ?? ""}
            onChange={(e) => setEditing((s) => (s ? { ...s, value: e.target.value } : s))}
          />
          <DialogFooter>
            <Button variant="ghost" onClick={() => setEditing(null)}>Mégse</Button>
            <Button disabled={upd.isPending} onClick={() => editing && upd.mutate(editing)}>Mentés</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function GlossaryTab() {
  const qc = useQueryClient();
  const list = useQuery({ queryKey: ["glossary"], queryFn: () => listGlossary() });
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<{ id?: string; term: string; target_lang: string; translation: string; notes?: string }>({
    term: "", target_lang: "en", translation: "",
  });

  const save = useMutation({
    mutationFn: (v: typeof form) => upsertGlossary({ data: v }),
    onSuccess: () => {
      toast.success("Mentve");
      setOpen(false);
      qc.invalidateQueries({ queryKey: ["glossary"] });
    },
    onError: (e: any) => toast.error(e?.message ?? "Mentés sikertelen"),
  });
  const del = useMutation({
    mutationFn: (id: string) => deleteGlossary({ data: { id } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["glossary"] }),
  });

  return (
    <div className="space-y-3">
      <div className="flex justify-end">
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setForm({ term: "", target_lang: "en", translation: "" })}>+ Új bejegyzés</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>{form.id ? "Szerkesztés" : "Új"} – szótár</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div><Label>Forrás (magyar)</Label><Input value={form.term} onChange={(e) => setForm({ ...form, term: e.target.value })} /></div>
              <div><Label>Célnyelv</Label>
                <Select value={form.target_lang} onValueChange={(v) => setForm({ ...form, target_lang: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{SUPPORTED_LANGUAGES.map((l) => <SelectItem key={l.code} value={l.code}>{l.flag} {l.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label>Fordítás</Label><Input value={form.translation} onChange={(e) => setForm({ ...form, translation: e.target.value })} /></div>
              <div><Label>Megjegyzés</Label><Input value={form.notes ?? ""} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
            </div>
            <DialogFooter>
              <Button variant="ghost" onClick={() => setOpen(false)}>Mégse</Button>
              <Button onClick={() => save.mutate(form)} disabled={save.isPending}>Mentés</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
      <div className="border rounded-lg divide-y">
        {(list.data ?? []).map((row) => (
          <div key={row.id} className="p-3 flex items-center gap-3 text-sm">
            <div className="flex-1">
              <span className="font-medium">{row.term}</span>
              <span className="mx-2 text-muted-foreground">→ {row.target_lang}</span>
              <span>{row.translation}</span>
              {row.notes && <span className="ml-2 text-xs text-muted-foreground italic">{row.notes}</span>}
            </div>
            <Button variant="ghost" size="icon" onClick={() => { setForm({ id: row.id, term: row.term, target_lang: row.target_lang, translation: row.translation, notes: row.notes ?? undefined }); setOpen(true); }}><Pencil className="h-4 w-4" /></Button>
            <Button variant="ghost" size="icon" onClick={() => del.mutate(row.id)}><Trash2 className="h-4 w-4" /></Button>
          </div>
        ))}
        {(list.data ?? []).length === 0 && <p className="p-6 text-center text-sm text-muted-foreground">Üres szótár</p>}
      </div>
    </div>
  );
}

function ErrorsTab() {
  const [errors, setErrors] = useState<TranslationError[]>(() => listTranslationErrors());
  useEffect(() => {
    const unsub = subscribeTranslationErrors(setErrors);
    return () => { unsub; };
  }, []);

  async function retry(err: TranslationError) {
    try {
      await translateBatchSafe({
        items: err.items.map((i) => ({ ...i, namespace: err.namespace })),
        target_lang: err.lang,
        kind: "ui",
      });

      toast.success("Sikeres újrapróbálás");
      clearTranslationError(err.id);
    } catch (e: any) {
      toast.error(e?.message ?? "Még mindig sikertelen");
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base flex items-center gap-2">
          <AlertTriangle className="h-4 w-4 text-amber-500" />
          Sikertelen fordítási kérések ({errors.length})
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {errors.length === 0 && <p className="text-sm text-muted-foreground">Nincs hibás kérés.</p>}
        {errors.map((e) => (
          <div key={e.id} className="border rounded p-3 text-sm space-y-2">
            <div className="flex items-center justify-between gap-2">
              <div>
                <Badge variant="outline">{e.lang}</Badge> <Badge variant="secondary">{e.namespace}</Badge>{" "}
                <span className="text-muted-foreground text-xs">{new Date(e.at).toLocaleTimeString()} · {e.items.length} elem</span>
              </div>
              <div className="flex gap-1">
                <Button size="sm" variant="outline" onClick={() => retry(e)}><RotateCcw className="h-3.5 w-3.5 mr-1" />Újra</Button>
                <Button size="sm" variant="ghost" onClick={() => clearTranslationError(e.id)}>Elvet</Button>
              </div>
            </div>
            <p className="text-destructive text-xs">{e.message}</p>
            <details className="text-xs">
              <summary className="cursor-pointer text-muted-foreground">Elemek ({e.items.length})</summary>
              <ul className="mt-1 list-disc pl-5 space-y-0.5">
                {e.items.slice(0, 20).map((it) => <li key={it.key} className="truncate">{it.source}</li>)}
                {e.items.length > 20 && <li>… +{e.items.length - 20} további</li>}
              </ul>
            </details>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}

function NewsTab() {
  const qc = useQueryClient();
  const [lang, setLang] = useState<string>("en");
  const [onlyMissing, setOnlyMissing] = useState(true);
  const [overwrite, setOverwrite] = useState(false);
  const [publishNow, setPublishNow] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState<{ done: number; total: number; failed: number } | null>(null);
  const [log, setLog] = useState<string[]>([]);

  const list = useQuery({
    queryKey: ["news-i18n-status", lang, onlyMissing],
    queryFn: () => listNewsTranslationStatus({ data: { target_lang: lang as any, only_missing: onlyMissing, limit: 200 } }),
  });

  function toggle(id: string) {
    setSelected((s) => {
      const n = new Set(s);
      n.has(id) ? n.delete(id) : n.add(id);
      return n;
    });
  }
  function selectAll() {
    const ids = (list.data ?? []).map((r) => r.id);
    setSelected(new Set(ids));
  }
  function clearAll() { setSelected(new Set()); }

  async function run() {
    const ids = Array.from(selected);
    if (ids.length === 0) { toast.error("Válassz legalább egy posztot"); return; }
    setRunning(true); setLog([]);
    const CHUNK = 5;
    let done = 0, failed = 0;
    setProgress({ done: 0, total: ids.length, failed: 0 });
    try {
      for (let i = 0; i < ids.length; i += CHUNK) {
        const batch = ids.slice(i, i + CHUNK);
        try {
          const res = await translateNewsPosts({
            data: {
              post_ids: batch,
              target_langs: [lang as any],
              overwrite,
              publish_immediately: publishNow,
            },
          });
          for (const s of res.summary ?? []) {
            if (!s.ok) { failed++; setLog((l) => [...l, `✗ ${s.slug} [${s.lang}]: ${s.error ?? "hiba"}`]); }
            else if (s.error) { setLog((l) => [...l, `↷ ${s.slug} [${s.lang}]: ${s.error}`]); }
            else { setLog((l) => [...l, `✓ ${s.slug} [${s.lang}]`]); }
          }
        } catch (e: any) {
          failed += batch.length;
          setLog((l) => [...l, `✗ batch @${i}: ${e?.message ?? "ismeretlen"}`]);
        }
        done += batch.length;
        setProgress({ done, total: ids.length, failed });
      }
      toast.success(`Fordítás kész — ${ids.length - failed}/${ids.length} sikeres`);
      qc.invalidateQueries({ queryKey: ["news-i18n-status"] });
      setSelected(new Set());
    } finally {
      setRunning(false);
    }
  }

  const rows = list.data ?? [];

  return (
    <div className="space-y-3">
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Newspaper className="h-4 w-4" />
            /hirek posztok AI fordítása
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex flex-wrap items-center gap-2">
            <Select value={lang} onValueChange={(v) => { setLang(v); setSelected(new Set()); }}>
              <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
              <SelectContent>
                {SUPPORTED_LANGUAGES.filter((l) => l.code !== "hu").map((l) => (
                  <SelectItem key={l.code} value={l.code}>{l.flag} {l.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <label className="flex items-center gap-2 text-sm">
              <Checkbox checked={onlyMissing} onCheckedChange={(v) => setOnlyMissing(!!v)} />
              Csak hiányzó
            </label>
            <label className="flex items-center gap-2 text-sm">
              <Checkbox checked={overwrite} onCheckedChange={(v) => setOverwrite(!!v)} />
              Felülír meglévőt
            </label>
            <label className="flex items-center gap-2 text-sm">
              <Checkbox checked={publishNow} onCheckedChange={(v) => setPublishNow(!!v)} />
              Publikálás azonnal (különben vázlat)
            </label>
            <Button variant="outline" size="sm" onClick={() => list.refetch()}>
              <RefreshCw className="h-4 w-4 mr-1.5" />Frissítés
            </Button>
            <div className="ml-auto flex gap-2">
              <Button variant="ghost" size="sm" onClick={selectAll} disabled={rows.length === 0}>Mind</Button>
              <Button variant="ghost" size="sm" onClick={clearAll} disabled={selected.size === 0}>Egyik se</Button>
              <Button onClick={run} disabled={running || selected.size === 0}>
                <Sparkles className="h-4 w-4 mr-1.5" />
                {running ? "Fordítás…" : `AI fordítás (${selected.size})`}
              </Button>
            </div>
          </div>

          {progress && (
            <div className="text-sm">
              <Badge variant="outline">{lang}</Badge>{" "}
              {progress.done} / {progress.total}
              {progress.failed > 0 && <span className="text-destructive"> ({progress.failed} hiba)</span>}
              <div className="mt-1 h-2 bg-muted rounded overflow-hidden">
                <div className="h-full bg-primary transition-all" style={{ width: `${(progress.done / progress.total) * 100}%` }} />
              </div>
            </div>
          )}

          {list.isLoading && <p className="text-sm text-muted-foreground">Betöltés…</p>}
          {list.error && <p className="text-sm text-destructive">{(list.error as Error).message}</p>}

          <div className="border rounded-lg divide-y max-h-[500px] overflow-auto">
            {rows.map((r) => (
              <label key={r.id} className="p-3 flex items-center gap-3 text-sm cursor-pointer hover:bg-muted/50">
                <Checkbox checked={selected.has(r.id)} onCheckedChange={() => toggle(r.id)} />
                <div className="flex-1 min-w-0">
                  <div className="font-medium truncate">{r.title}</div>
                  <div className="text-xs text-muted-foreground font-mono truncate">/hirek/{r.slug}</div>
                </div>
                <Badge variant={r.status === "published" ? "default" : "secondary"} className="text-[10px]">
                  {r.status}
                </Badge>
                {r.translated ? (
                  <Badge variant="outline" className="text-[10px]">van {lang}</Badge>
                ) : (
                  <Badge variant="destructive" className="text-[10px]">hiányzik</Badge>
                )}
              </label>
            ))}
            {!list.isLoading && rows.length === 0 && (
              <p className="p-6 text-center text-sm text-muted-foreground">
                {onlyMissing ? `Minden poszt le van fordítva ${lang} nyelvre 🎉` : "Nincs poszt"}
              </p>
            )}
          </div>

          {log.length > 0 && (
            <div className="text-xs font-mono bg-muted p-2 rounded max-h-48 overflow-auto space-y-0.5">
              {log.map((l, i) => <div key={i}>{l}</div>)}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

export const Route = createFileRoute("/_authenticated/admin/forditasok")({
  component: ForditasokAdmin,
  head: () => ({ meta: [{ title: "Fordításkezelő" }] }),
  errorComponent: ({ error, reset }) => (
    <div className="p-6 space-y-2">
      <p className="text-destructive">{error.message}</p>
      <Button onClick={reset}>Újra</Button>
    </div>
  ),
  notFoundComponent: () => <div className="p-6">Nem található</div>,
});
