import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import { CalendarClock, FileSignature, CheckCircle2, XCircle, Loader2 } from "lucide-react";
import {
  listAppointmentRequests,
  listReferralRequests,
  decideAppointmentRequest,
  decideReferralRequest,
} from "@/lib/portal/patient-requests.functions";

export const Route = createFileRoute("/_authenticated/admin/paciens-kerelmek")({
  component: PacientKerelmekPage,
});

const URGENCY_BADGE: Record<string, string> = {
  low: "bg-muted text-muted-foreground",
  normal: "bg-primary/10 text-primary",
  high: "bg-amber-500/20 text-amber-700 dark:text-amber-300",
  urgent: "bg-destructive/20 text-destructive",
};

function PacientKerelmekPage() {
  const [statusFilter, setStatusFilter] = useState<"pending" | "all">("pending");

  return (
    
      <div className="space-y-6">
        <header className="flex items-end justify-between gap-4 flex-wrap">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Páciens-kérelmek</h1>
            <p className="text-sm text-muted-foreground">
              Időpont- és beutaló-kérések központi inboxa. A döntés automatikusan értesíti a pácienst.
            </p>
          </div>
          <div className="flex gap-2">
            <Button
              size="sm"
              variant={statusFilter === "pending" ? "default" : "outline"}
              onClick={() => setStatusFilter("pending")}
            >
              Csak függő
            </Button>
            <Button
              size="sm"
              variant={statusFilter === "all" ? "default" : "outline"}
              onClick={() => setStatusFilter("all")}
            >
              Összes
            </Button>
          </div>
        </header>

        <Tabs defaultValue="appointments" className="space-y-4">
          <TabsList>
            <TabsTrigger value="appointments" className="gap-2">
              <CalendarClock className="h-4 w-4" /> Időpont-kérések
            </TabsTrigger>
            <TabsTrigger value="referrals" className="gap-2">
              <FileSignature className="h-4 w-4" /> Beutaló-kérések
            </TabsTrigger>
          </TabsList>

          <TabsContent value="appointments">
            <AppointmentRequests statusFilter={statusFilter} />
          </TabsContent>
          <TabsContent value="referrals">
            <ReferralRequests statusFilter={statusFilter} />
          </TabsContent>
        </Tabs>
      </div>
    
  );
}

function AppointmentRequests({ statusFilter }: { statusFilter: "pending" | "all" }) {
  const fetchFn = useServerFn(listAppointmentRequests);
  const decideFn = useServerFn(decideAppointmentRequest);
  const qc = useQueryClient();
  const query = useQuery({
    queryKey: ["patient-appointment-requests", statusFilter],
    queryFn: () => fetchFn({ data: { status: statusFilter } }),
  });
  const mutation = useMutation({
    mutationFn: (input: { id: string; decision: "approved" | "rejected"; staff_response?: string }) =>
      decideFn({ data: input }),
    onSuccess: (_d, v) => {
      toast.success(v.decision === "approved" ? "Időpont-kérés elfogadva" : "Időpont-kérés elutasítva");
      qc.invalidateQueries({ queryKey: ["patient-appointment-requests"] });
    },
    onError: (e: any) => toast.error(e?.message ?? "Hiba történt"),
  });

  if (query.isLoading) return <LoadingCard />;
  if (query.isError) return <ErrorCard message={(query.error as any)?.message} />;
  const rows = query.data ?? [];
  if (!rows.length)
    return (
      <Card>
        <CardContent className="py-12 text-center text-sm text-muted-foreground">
          Nincs {statusFilter === "pending" ? "függő" : ""} időpont-kérés.
        </CardContent>
      </Card>
    );

  return (
    <div className="space-y-3">
      {rows.map((r: any) => (
        <Card key={r.id}>
          <CardHeader className="pb-2">
            <div className="flex items-start justify-between gap-4 flex-wrap">
              <div>
                <CardTitle className="text-base">
                  {r.patient?.nev ?? "—"}{" "}
                  <span className="text-muted-foreground font-normal text-sm">
                    · {r.request_type === "new" ? "Új időpont" : r.request_type === "reschedule" ? "Áthelyezés" : "Lemondás"}
                  </span>
                </CardTitle>
                <p className="text-xs text-muted-foreground">
                  Beérkezett: {new Date(r.created_at).toLocaleString("hu-HU")}
                  {r.preferred_datetime && (
                    <> · Kért: {new Date(r.preferred_datetime).toLocaleString("hu-HU")}</>
                  )}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <Badge className={URGENCY_BADGE[r.urgency] ?? ""}>{r.urgency}</Badge>
                <StatusBadge status={r.status} />
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {r.reason && (
              <p className="text-sm rounded-md bg-muted/40 px-3 py-2">{r.reason}</p>
            )}
            {r.staff_response && (
              <p className="text-xs text-muted-foreground">Válasz: {r.staff_response}</p>
            )}
            {r.status === "pending" && (
              <div className="flex gap-2 pt-1">
                <DecisionButton
                  variant="approve"
                  onConfirm={(note) => mutation.mutate({ id: r.id, decision: "approved", staff_response: note })}
                  pending={mutation.isPending}
                />
                <DecisionButton
                  variant="reject"
                  onConfirm={(note) => mutation.mutate({ id: r.id, decision: "rejected", staff_response: note })}
                  pending={mutation.isPending}
                />
                <Button asChild variant="ghost" size="sm">
                  <Link to="/idopontok" search={{ patient_id: r.patient_id } as any}>
                    Idősáv megnyitása
                  </Link>
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

function ReferralRequests({ statusFilter }: { statusFilter: "pending" | "all" }) {
  const fetchFn = useServerFn(listReferralRequests);
  const decideFn = useServerFn(decideReferralRequest);
  const qc = useQueryClient();
  const query = useQuery({
    queryKey: ["patient-referral-requests", statusFilter],
    queryFn: () => fetchFn({ data: { status: statusFilter } }),
  });
  const mutation = useMutation({
    mutationFn: (input: { id: string; decision: "approved" | "rejected"; decision_note?: string }) =>
      decideFn({ data: input }),
    onSuccess: (_d, v) => {
      toast.success(v.decision === "approved" ? "Beutaló jóváhagyva" : "Beutaló elutasítva");
      qc.invalidateQueries({ queryKey: ["patient-referral-requests"] });
    },
    onError: (e: any) => toast.error(e?.message ?? "Hiba történt"),
  });

  if (query.isLoading) return <LoadingCard />;
  if (query.isError) return <ErrorCard message={(query.error as any)?.message} />;
  const rows = query.data ?? [];
  if (!rows.length)
    return (
      <Card>
        <CardContent className="py-12 text-center text-sm text-muted-foreground">
          Nincs {statusFilter === "pending" ? "függő" : ""} beutaló-kérés.
        </CardContent>
      </Card>
    );

  return (
    <div className="space-y-3">
      {rows.map((r: any) => (
        <Card key={r.id}>
          <CardHeader className="pb-2">
            <div className="flex items-start justify-between gap-4 flex-wrap">
              <div>
                <CardTitle className="text-base">
                  {r.patient?.nev ?? "—"}{" "}
                  <span className="text-muted-foreground font-normal text-sm">
                    · {r.specialty ?? r.request_type}
                  </span>
                </CardTitle>
                <p className="text-xs text-muted-foreground">
                  Beérkezett: {new Date(r.created_at).toLocaleString("hu-HU")}
                </p>
              </div>
              <StatusBadge status={r.status} />
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm rounded-md bg-muted/40 px-3 py-2">{r.reason}</p>
            {r.notes && <p className="text-xs text-muted-foreground">{r.notes}</p>}
            {r.decision_note && (
              <p className="text-xs text-muted-foreground">Döntés: {r.decision_note}</p>
            )}
            {r.status === "pending" && (
              <div className="flex gap-2 pt-1">
                <DecisionButton
                  variant="approve"
                  onConfirm={(note) => mutation.mutate({ id: r.id, decision: "approved", decision_note: note })}
                  pending={mutation.isPending}
                />
                <DecisionButton
                  variant="reject"
                  onConfirm={(note) => mutation.mutate({ id: r.id, decision: "rejected", decision_note: note })}
                  pending={mutation.isPending}
                />
              </div>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

function DecisionButton({
  variant,
  onConfirm,
  pending,
}: {
  variant: "approve" | "reject";
  onConfirm: (note?: string) => void;
  pending: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [note, setNote] = useState("");
  const isApprove = variant === "approve";
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm" variant={isApprove ? "default" : "destructive"} className="gap-2">
          {isApprove ? <CheckCircle2 className="h-4 w-4" /> : <XCircle className="h-4 w-4" />}
          {isApprove ? "Jóváhagyás" : "Elutasítás"}
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{isApprove ? "Jóváhagyás" : "Elutasítás"} megerősítése</DialogTitle>
        </DialogHeader>
        <Textarea
          placeholder={isApprove ? "Opcionális üzenet a páciensnek…" : "Indoklás (opcionális)…"}
          value={note}
          onChange={(e) => setNote(e.target.value)}
          rows={4}
        />
        <DialogFooter>
          <Button variant="ghost" onClick={() => setOpen(false)}>
            Mégse
          </Button>
          <Button
            variant={isApprove ? "default" : "destructive"}
            disabled={pending}
            onClick={() => {
              onConfirm(note.trim() || undefined);
              setOpen(false);
              setNote("");
            }}
          >
            {pending && <Loader2 className="h-4 w-4 animate-spin mr-2" />}
            Megerősítés
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    pending: "bg-amber-500/20 text-amber-700 dark:text-amber-300",
    approved: "bg-emerald-500/20 text-emerald-700 dark:text-emerald-300",
    rejected: "bg-destructive/20 text-destructive",
    rescheduled: "bg-primary/10 text-primary",
    cancelled: "bg-muted text-muted-foreground",
  };
  const label: Record<string, string> = {
    pending: "Függő",
    approved: "Elfogadva",
    rejected: "Elutasítva",
    rescheduled: "Áthelyezve",
    cancelled: "Lemondva",
  };
  return <Badge className={map[status] ?? ""}>{label[status] ?? status}</Badge>;
}

function LoadingCard() {
  return (
    <Card>
      <CardContent className="py-12 text-center text-sm text-muted-foreground">
        <Loader2 className="h-5 w-5 animate-spin inline mr-2" /> Betöltés…
      </CardContent>
    </Card>
  );
}

function ErrorCard({ message }: { message?: string }) {
  return (
    <Card>
      <CardContent className="py-12 text-center text-sm text-destructive">
        Hiba: {message ?? "ismeretlen"}
      </CardContent>
    </Card>
  );
}
