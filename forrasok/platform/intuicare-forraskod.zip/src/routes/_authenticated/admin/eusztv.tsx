import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Loader2, Plus, Trash2, Save, Calculator, ShieldAlert } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { usePermissions } from "@/hooks/use-permissions";
import {
  getGyakorlatiIdo,
  getJubileumiIdo,
  getIlletmeny,
  listServiceHistory,
  upsertServiceHistory,
  deleteServiceHistory,
  overrideServiceTime,
  listWageTable,
  upsertWageRow,
  listEusztvRows,
  upsertEusztvRow,
  deleteEusztvRow,
  bulkInsertServiceHistory,
} from "@/lib/eusztv/eusztv.functions";
import { ServiceHistoryPdfImport } from "@/components/eusztv/service-history-pdf-import";
import { EusztvCoverageMatrix } from "@/components/eusztv/coverage-matrix";

export const Route = createFileRoute("/_authenticated/admin/eusztv")({
  component: EusztvAdminPage,
});

type TabKey =
  | "lefedettseg"
  | "bertabla"
  | "szolgalati_ido"
  | "probaido"
  | "osszeferhetetlenseg"
  | "minosites"
  | "szabadsag"
  | "jubileum"
  | "vegkielegites"
  | "juttatasok"
  | "kirendelesek";

const TABS: { key: TabKey; label: string }[] = [
  { key: "lefedettseg", label: "Lefedettségi mátrix" },
  { key: "bertabla", label: "Bértábla (1. / 1/A. mell.)" },
  { key: "szolgalati_ido", label: "Gyakorlati idő" },
  { key: "probaido", label: "Próbaidő (3. §)" },
  { key: "osszeferhetetlenseg", label: "Összeférhetetlenség (4. §)" },
  { key: "minosites", label: "Minősítés (7. §)" },
  { key: "szabadsag", label: "Szabadság (6. §)" },
  { key: "jubileum", label: "Jubileum (9. §)" },
  { key: "vegkielegites", label: "Végkielégítés (12–13. §)" },
  { key: "juttatasok", label: "Juttatások (10. §)" },
  { key: "kirendelesek", label: "Kirendelés (11. §)" },
];

function EusztvAdminPage() {
  const { can, loading } = usePermissions();
  const [tab, setTab] = useState<TabKey>("bertabla");

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[300px]">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!can("manage_eusztv")) {
    return (
      <div className="container max-w-2xl mx-auto py-12">
        <div className="rounded-lg border border-destructive/30 bg-destructive/5 p-6 flex items-start gap-3">
          <ShieldAlert className="h-5 w-5 text-destructive mt-0.5" />
          <div>
            <h2 className="font-semibold">Nincs jogosultság</h2>
            <p className="text-sm text-muted-foreground">
              Ehhez a felülethez <code>manage_eusztv</code> jogosultság szükséges.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6 max-w-7xl">
      <header>
        <h1 className="text-2xl font-bold">Eüsztv. adminisztráció</h1>
        <p className="text-sm text-muted-foreground">
          2020. évi C. törvény az egészségügyi szolgálati jogviszonyról — teljes lefedettség.
        </p>
      </header>

      <div className="flex flex-wrap gap-1 border-b border-border">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`px-3 py-2 text-sm rounded-t-md transition-colors ${
              tab === t.key
                ? "bg-card border border-border border-b-card -mb-px font-medium"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="bg-card border border-border rounded-lg p-6 min-h-[400px]">
       {tab === "lefedettseg" && <EusztvCoverageMatrix />}
       {tab === "bertabla" && <BertablaTab />}
        {tab === "szolgalati_ido" && <SzolgalatiIdoTab />}
        {tab === "probaido" && <GenericCrudTab table="probaidok" title="Próbaidő" fields={PROBAIDO_FIELDS} />}
        {tab === "osszeferhetetlenseg" && <GenericCrudTab table="osszeferhetetlenseg_engedelyek" title="Összeférhetetlenségi engedély" fields={OSSZEFER_FIELDS} />}
        {tab === "minosites" && <GenericCrudTab table="minosites" title="Minősítés" fields={MINOSITES_FIELDS} />}
        {tab === "szabadsag" && <SzabadsagTab />}
        {tab === "jubileum" && <GenericCrudTab table="szolgalati_elismeres" title="Szolgálati elismerés (jubileum)" fields={JUBILEUM_FIELDS} />}
        {tab === "vegkielegites" && <GenericCrudTab table="vegkielegites_szamitasok" title="Végkielégítés-számítás" fields={VEGKI_FIELDS} />}
        {tab === "juttatasok" && <GenericCrudTab table="juttatasok" title="Juttatás" fields={JUTTATAS_FIELDS} />}
        {tab === "kirendelesek" && <GenericCrudTab table="kirendelesek" title="Kirendelés" fields={KIRENDELES_FIELDS} />}
      </div>
    </div>
  );
}

// =================================================================
// BÉRTÁBLA
// =================================================================
function BertablaTab() {
  const [tabla, setTabla] = useState<"orvos_1mell" | "szakdolgozo_1a_mell">("orvos_1mell");
  const listFn = useServerFn(listWageTable);
  const upsertFn = useServerFn(upsertWageRow);
  const qc = useQueryClient();

  const { data: rows = [], isLoading } = useQuery({
    queryKey: ["wage_table", tabla],
    queryFn: () => listFn({ data: { tabla_tipus: tabla } }),
  });

  const upsertMut = useMutation({
    mutationFn: (values: any) => upsertFn({ data: values }),
    onSuccess: () => {
      toast.success("Mentve");
      qc.invalidateQueries({ queryKey: ["wage_table"] });
    },
    onError: (e: any) => toast.error(String((e as any)?.message ?? e)),
  });

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <button
          onClick={() => setTabla("orvos_1mell")}
          className={`px-3 py-1.5 text-sm rounded border ${tabla === "orvos_1mell" ? "bg-primary text-primary-foreground" : "bg-card"}`}
        >
          Orvosi (1. mell.)
        </button>
        <button
          onClick={() => setTabla("szakdolgozo_1a_mell")}
          className={`px-3 py-1.5 text-sm rounded border ${tabla === "szakdolgozo_1a_mell" ? "bg-primary text-primary-foreground" : "bg-card"}`}
        >
          Szakdolgozói (1/A. mell.)
        </button>
      </div>

      {isLoading ? (
        <Loader2 className="h-5 w-5 animate-spin" />
      ) : (
        <div className="overflow-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted">
              <tr>
                <th className="p-2 text-left">Kategória</th>
                <th className="p-2 text-left">Osztály</th>
                <th className="p-2 text-left">Fokozat</th>
                <th className="p-2 text-left">Gyak. idő tól</th>
                <th className="p-2 text-left">ig (év)</th>
                <th className="p-2 text-right">Összeg (Ft)</th>
                <th className="p-2 text-right">Vez. szorzó</th>
                <th className="p-2 text-left">Érvényes-től</th>
                <th className="p-2"></th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r: any) => (
                <WageRow key={r.id} row={r} onSave={(v) => upsertMut.mutate({ id: r.id, ...v })} />
              ))}
              <NewWageRow tabla={tabla} onSave={(v) => upsertMut.mutate(v)} />
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function WageRow({ row, onSave }: { row: any; onSave: (v: any) => void }) {
  const [v, setV] = useState(row);
  return (
    <tr className="border-b">
      <td className="p-1"><input className="w-32 px-2 py-1 border rounded bg-background" value={v.besorolasi_kategoria || ""} onChange={(e) => setV({ ...v, besorolasi_kategoria: e.target.value })} /></td>
      <td className="p-1"><input className="w-16 px-2 py-1 border rounded bg-background" value={v.fizetesi_osztaly || ""} onChange={(e) => setV({ ...v, fizetesi_osztaly: e.target.value })} /></td>
      <td className="p-1"><input type="number" className="w-16 px-2 py-1 border rounded bg-background" value={v.fizetesi_fokozat || 0} onChange={(e) => setV({ ...v, fizetesi_fokozat: +e.target.value })} /></td>
      <td className="p-1"><input type="number" className="w-20 px-2 py-1 border rounded bg-background" value={v.gyakorlati_ido_tol_ev ?? ""} onChange={(e) => setV({ ...v, gyakorlati_ido_tol_ev: e.target.value === "" ? null : +e.target.value })} /></td>
      <td className="p-1"><input type="number" className="w-20 px-2 py-1 border rounded bg-background" value={v.gyakorlati_ido_ig_ev ?? ""} onChange={(e) => setV({ ...v, gyakorlati_ido_ig_ev: e.target.value === "" ? null : +e.target.value })} /></td>
      <td className="p-1"><input type="number" className="w-32 px-2 py-1 border rounded bg-background text-right" value={v.osszeg_ft ?? 0} onChange={(e) => setV({ ...v, osszeg_ft: +e.target.value })} /></td>
      <td className="p-1"><input type="number" step="0.01" className="w-20 px-2 py-1 border rounded bg-background text-right" value={v.vezeto_szorzo ?? 1.2} onChange={(e) => setV({ ...v, vezeto_szorzo: +e.target.value })} /></td>
      <td className="p-1"><input type="date" className="px-2 py-1 border rounded bg-background" value={v.ervenyes_tol} onChange={(e) => setV({ ...v, ervenyes_tol: e.target.value })} /></td>
      <td className="p-1">
        <button className="p-1 hover:bg-muted rounded" onClick={() => onSave({
          tabla_tipus: v.tabla_tipus,
          besorolasi_kategoria: v.besorolasi_kategoria,
          fizetesi_fokozat: v.fizetesi_fokozat,
          fizetesi_osztaly: v.fizetesi_osztaly || null,
          munkakor_megnevezes: v.munkakor_megnevezes,
          gyakorlati_ido_tol_ev: v.gyakorlati_ido_tol_ev,
          gyakorlati_ido_ig_ev: v.gyakorlati_ido_ig_ev,
          osszeg_ft: v.osszeg_ft,
          vezeto_szorzo: v.vezeto_szorzo,
          ervenyes_tol: v.ervenyes_tol,
        })}><Save className="h-4 w-4" /></button>
      </td>
    </tr>
  );
}

function NewWageRow({ tabla, onSave }: { tabla: "orvos_1mell" | "szakdolgozo_1a_mell"; onSave: (v: any) => void }) {
  const [v, setV] = useState({
    besorolasi_kategoria: tabla === "orvos_1mell" ? "orvos" : "szakdolgozo",
    fizetesi_fokozat: 1,
    fizetesi_osztaly: "",
    gyakorlati_ido_tol_ev: 0,
    gyakorlati_ido_ig_ev: null as number | null,
    osszeg_ft: 0,
    vezeto_szorzo: 1.2,
    ervenyes_tol: new Date().toISOString().slice(0, 10),
  });
  return (
    <tr className="bg-muted/30">
      <td className="p-1"><input className="w-32 px-2 py-1 border rounded bg-background" value={v.besorolasi_kategoria} onChange={(e) => setV({ ...v, besorolasi_kategoria: e.target.value })} /></td>
      <td className="p-1"><input className="w-16 px-2 py-1 border rounded bg-background" value={v.fizetesi_osztaly} onChange={(e) => setV({ ...v, fizetesi_osztaly: e.target.value })} /></td>
      <td className="p-1"><input type="number" className="w-16 px-2 py-1 border rounded bg-background" value={v.fizetesi_fokozat} onChange={(e) => setV({ ...v, fizetesi_fokozat: +e.target.value })} /></td>
      <td className="p-1"><input type="number" className="w-20 px-2 py-1 border rounded bg-background" value={v.gyakorlati_ido_tol_ev} onChange={(e) => setV({ ...v, gyakorlati_ido_tol_ev: +e.target.value })} /></td>
      <td className="p-1"><input type="number" className="w-20 px-2 py-1 border rounded bg-background" value={v.gyakorlati_ido_ig_ev ?? ""} onChange={(e) => setV({ ...v, gyakorlati_ido_ig_ev: e.target.value === "" ? null : +e.target.value })} /></td>
      <td className="p-1"><input type="number" className="w-32 px-2 py-1 border rounded bg-background text-right" value={v.osszeg_ft} onChange={(e) => setV({ ...v, osszeg_ft: +e.target.value })} /></td>
      <td className="p-1"><input type="number" step="0.01" className="w-20 px-2 py-1 border rounded bg-background text-right" value={v.vezeto_szorzo} onChange={(e) => setV({ ...v, vezeto_szorzo: +e.target.value })} /></td>
      <td className="p-1"><input type="date" className="px-2 py-1 border rounded bg-background" value={v.ervenyes_tol} onChange={(e) => setV({ ...v, ervenyes_tol: e.target.value })} /></td>
      <td className="p-1">
        <button className="p-1 hover:bg-muted rounded text-primary" onClick={() => onSave({ ...v, tabla_tipus: tabla, fizetesi_osztaly: v.fizetesi_osztaly || null })}>
          <Plus className="h-4 w-4" />
        </button>
      </td>
    </tr>
  );
}

// =================================================================
// SZOLGÁLATI IDŐ KALKULÁTOR + history CRUD
// =================================================================
function SzolgalatiIdoTab() {
  const [userId, setUserId] = useState<string>("");
  const [members, setMembers] = useState<Array<{ id: string; nev: string; tenant_id: string }>>([]);

  useEffect(() => {
    (async () => {
      const tenant = (await supabase.rpc("current_tenant_id")).data as string;
      const { data } = await supabase
        .from("profiles")
        .select("id, nev, tenant_id")
        .eq("tenant_id", tenant)
        .order("nev");
      setMembers((data as any) ?? []);
    })();
  }, []);

  return (
    <div className="space-y-4">
      <div>
        <label className="text-sm font-medium block mb-1">Csapattag</label>
        <select value={userId} onChange={(e) => setUserId(e.target.value)} className="w-full max-w-md px-3 py-2 border rounded bg-background">
          <option value="">— válassz —</option>
          {members.map((m) => (
            <option key={m.id} value={m.id}>{m.nev || m.id}</option>
          ))}
        </select>
      </div>
      {userId && <SzolgalatiIdoEditor userId={userId} tenantId={members.find((m) => m.id === userId)?.tenant_id || ""} />}
    </div>
  );
}

function SzolgalatiIdoEditor({ userId, tenantId }: { userId: string; tenantId: string }) {
  const gyakFn = useServerFn(getGyakorlatiIdo);
  const jubFn = useServerFn(getJubileumiIdo);
  const illFn = useServerFn(getIlletmeny);
  const listFn = useServerFn(listServiceHistory);
  const upsertFn = useServerFn(upsertServiceHistory);
  const deleteFn = useServerFn(deleteServiceHistory);
  const overrideFn = useServerFn(overrideServiceTime);
  const bulkFn = useServerFn(bulkInsertServiceHistory);
  const qc = useQueryClient();

  const { data: gyak } = useQuery({ queryKey: ["gyak", userId], queryFn: () => gyakFn({ data: { userId } }) });
  const { data: jub } = useQuery({ queryKey: ["jub", userId], queryFn: () => jubFn({ data: { userId } }) });
  const { data: ill } = useQuery({ queryKey: ["ill", userId], queryFn: () => illFn({ data: { userId } }) });
  const { data: hist = [] } = useQuery({ queryKey: ["psh", userId], queryFn: () => listFn({ data: { userId } }) });

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ["gyak", userId] });
    qc.invalidateQueries({ queryKey: ["jub", userId] });
    qc.invalidateQueries({ queryKey: ["ill", userId] });
    qc.invalidateQueries({ queryKey: ["psh", userId] });
  };

  const upsertMut = useMutation({ mutationFn: (v: any) => upsertFn({ data: v }), onSuccess: () => { toast.success("Mentve"); invalidate(); }, onError: (e: any) => toast.error(String((e as any)?.message ?? e)) });
  const deleteMut = useMutation({ mutationFn: (id: string) => deleteFn({ data: { id } }), onSuccess: () => { toast.success("Törölve"); invalidate(); } });
  const overrideMut = useMutation({ mutationFn: (v: any) => overrideFn({ data: v }), onSuccess: () => { toast.success("Felülbírálva"); invalidate(); }, onError: (e: any) => toast.error(String((e as any)?.message ?? e)) });

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="border rounded-lg p-4">
          <div className="text-xs text-muted-foreground flex items-center gap-1"><Calculator className="h-3 w-3" /> Gyakorlati idő (8. §)</div>
          <div className="text-2xl font-bold mt-1">{gyak?.evek ?? 0} év</div>
          <div className="text-xs text-muted-foreground">{gyak?.napok ?? 0} nap</div>
        </div>
        <div className="border rounded-lg p-4">
          <div className="text-xs text-muted-foreground">Jubileumhoz beszámítható (9. §)</div>
          <div className="text-2xl font-bold mt-1">{jub?.evek ?? 0} év</div>
          <div className="text-xs text-muted-foreground">{jub?.napok ?? 0} nap</div>
        </div>
        <div className="border rounded-lg p-4">
          <div className="text-xs text-muted-foreground">Aktuális illetmény (1. mell.)</div>
          <div className="text-2xl font-bold mt-1">{(ill?.vegso_ft ?? 0).toLocaleString("hu")} Ft</div>
          <div className="text-xs text-muted-foreground">{ill?.sav} · vez. {ill?.vezetoi_szorzo}x</div>
        </div>
      </div>

      <OverrideForm onSubmit={(v) => overrideMut.mutate({ ...v, user_id: userId, tenant_id: tenantId })} />

      <ServiceHistoryPdfImport
        onImport={async (rows) => {
          await bulkFn({ data: { user_id: userId, tenant_id: tenantId, rows } });
          toast.success(`${rows.length} sor importálva`);
          invalidate();
        }}
      />

      <div>
        <h3 className="font-medium mb-2">Korábbi munkáltatóknál szerzett szolgálati idő</h3>
        <div className="overflow-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted">
              <tr>
                <th className="p-2 text-left">Munkáltató</th>
                <th className="p-2 text-left">Fenntartó</th>
                <th className="p-2 text-left">Munkakör</th>
                <th className="p-2 text-left">Tól</th>
                <th className="p-2 text-left">Ig</th>
                <th className="p-2 text-center">Eüsztv.</th>
                <th className="p-2 text-center">Jub.</th>
                <th className="p-2"></th>
              </tr>
            </thead>
            <tbody>
              {hist.map((h: any) => (
                <ServiceRow key={h.id} row={h} onSave={(v) => upsertMut.mutate({ ...v, id: h.id, user_id: userId, tenant_id: tenantId })} onDelete={() => deleteMut.mutate(h.id)} />
              ))}
              <NewServiceRow onSave={(v) => upsertMut.mutate({ ...v, user_id: userId, tenant_id: tenantId })} />
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function OverrideForm({ onSubmit }: { onSubmit: (v: { tipus: "gyakorlati_ido" | "jubileumi"; napok_korrekcio: number; indok: string }) => void }) {
  const [open, setOpen] = useState(false);
  const [v, setV] = useState({ tipus: "gyakorlati_ido" as const, napok_korrekcio: 0, indok: "" });
  if (!open) return <button className="text-sm text-primary hover:underline" onClick={() => setOpen(true)}>+ HR felülbírálat hozzáadása</button>;
  return (
    <div className="border rounded p-3 space-y-2 bg-muted/30">
      <div className="flex gap-2 flex-wrap items-end">
        <div>
          <label className="text-xs">Típus</label>
          <select value={v.tipus} onChange={(e) => setV({ ...v, tipus: e.target.value as any })} className="px-2 py-1 border rounded bg-background block">
            <option value="gyakorlati_ido">Gyakorlati idő</option>
            <option value="jubileumi">Jubileumi</option>
          </select>
        </div>
        <div>
          <label className="text-xs">Napok ±</label>
          <input type="number" value={v.napok_korrekcio} onChange={(e) => setV({ ...v, napok_korrekcio: +e.target.value })} className="px-2 py-1 border rounded bg-background block w-24" />
        </div>
        <div className="flex-1 min-w-[200px]">
          <label className="text-xs">Indok</label>
          <input value={v.indok} onChange={(e) => setV({ ...v, indok: e.target.value })} className="px-2 py-1 border rounded bg-background block w-full" />
        </div>
        <button className="px-3 py-1.5 bg-primary text-primary-foreground rounded text-sm" onClick={() => { onSubmit(v); setOpen(false); setV({ tipus: "gyakorlati_ido", napok_korrekcio: 0, indok: "" }); }}>Rögzít</button>
        <button className="px-3 py-1.5 border rounded text-sm" onClick={() => setOpen(false)}>Mégse</button>
      </div>
    </div>
  );
}

function ServiceRow({ row, onSave, onDelete }: { row: any; onSave: (v: any) => void; onDelete: () => void }) {
  const [v, setV] = useState(row);
  return (
    <tr className="border-b">
      <td className="p-1"><input className="px-2 py-1 border rounded bg-background w-full" value={v.munkaltato_nev || ""} onChange={(e) => setV({ ...v, munkaltato_nev: e.target.value })} /></td>
      <td className="p-1">
        <select className="px-2 py-1 border rounded bg-background" value={v.fenntarto_tipus} onChange={(e) => setV({ ...v, fenntarto_tipus: e.target.value })}>
          {["allami", "onkormanyzati", "egyhazi", "magan", "kulfoldi", "egyeb"].map((x) => <option key={x} value={x}>{x}</option>)}
        </select>
      </td>
      <td className="p-1"><input className="px-2 py-1 border rounded bg-background w-full" value={v.munkakor || ""} onChange={(e) => setV({ ...v, munkakor: e.target.value })} /></td>
      <td className="p-1"><input type="date" className="px-2 py-1 border rounded bg-background" value={v.kezdo_datum} onChange={(e) => setV({ ...v, kezdo_datum: e.target.value })} /></td>
      <td className="p-1"><input type="date" className="px-2 py-1 border rounded bg-background" value={v.zaro_datum || ""} onChange={(e) => setV({ ...v, zaro_datum: e.target.value || null })} /></td>
      <td className="p-1 text-center"><input type="checkbox" checked={v.beszamithato_eusztv} onChange={(e) => setV({ ...v, beszamithato_eusztv: e.target.checked })} /></td>
      <td className="p-1 text-center"><input type="checkbox" checked={v.beszamithato_jubileum} onChange={(e) => setV({ ...v, beszamithato_jubileum: e.target.checked })} /></td>
      <td className="p-1 flex gap-1">
        <button className="p-1 hover:bg-muted rounded" onClick={() => onSave({
          munkaltato_nev: v.munkaltato_nev, fenntarto_tipus: v.fenntarto_tipus, munkakor: v.munkakor,
          kezdo_datum: v.kezdo_datum, zaro_datum: v.zaro_datum,
          beszamithato_eusztv: v.beszamithato_eusztv, beszamithato_jubileum: v.beszamithato_jubileum,
          forras: v.forras || "nyilatkozat",
        })}><Save className="h-4 w-4" /></button>
        <button className="p-1 hover:bg-destructive/10 rounded text-destructive" onClick={onDelete}><Trash2 className="h-4 w-4" /></button>
      </td>
    </tr>
  );
}

function NewServiceRow({ onSave }: { onSave: (v: any) => void }) {
  const [v, setV] = useState({
    munkaltato_nev: "", fenntarto_tipus: "allami", munkakor: "",
    kezdo_datum: "", zaro_datum: null as string | null,
    beszamithato_eusztv: true, beszamithato_jubileum: true, forras: "nyilatkozat",
  });
  return (
    <tr className="bg-muted/30">
      <td className="p-1"><input className="px-2 py-1 border rounded bg-background w-full" placeholder="Munkáltató neve" value={v.munkaltato_nev} onChange={(e) => setV({ ...v, munkaltato_nev: e.target.value })} /></td>
      <td className="p-1">
        <select className="px-2 py-1 border rounded bg-background" value={v.fenntarto_tipus} onChange={(e) => setV({ ...v, fenntarto_tipus: e.target.value })}>
          {["allami", "onkormanyzati", "egyhazi", "magan", "kulfoldi", "egyeb"].map((x) => <option key={x} value={x}>{x}</option>)}
        </select>
      </td>
      <td className="p-1"><input className="px-2 py-1 border rounded bg-background w-full" value={v.munkakor} onChange={(e) => setV({ ...v, munkakor: e.target.value })} /></td>
      <td className="p-1"><input type="date" className="px-2 py-1 border rounded bg-background" value={v.kezdo_datum} onChange={(e) => setV({ ...v, kezdo_datum: e.target.value })} /></td>
      <td className="p-1"><input type="date" className="px-2 py-1 border rounded bg-background" value={v.zaro_datum || ""} onChange={(e) => setV({ ...v, zaro_datum: e.target.value || null })} /></td>
      <td className="p-1 text-center"><input type="checkbox" checked={v.beszamithato_eusztv} onChange={(e) => setV({ ...v, beszamithato_eusztv: e.target.checked })} /></td>
      <td className="p-1 text-center"><input type="checkbox" checked={v.beszamithato_jubileum} onChange={(e) => setV({ ...v, beszamithato_jubileum: e.target.checked })} /></td>
      <td className="p-1">
        <button className="p-1 hover:bg-muted rounded text-primary" disabled={!v.munkaltato_nev || !v.kezdo_datum} onClick={() => {
          onSave(v);
          setV({ munkaltato_nev: "", fenntarto_tipus: "allami", munkakor: "", kezdo_datum: "", zaro_datum: null, beszamithato_eusztv: true, beszamithato_jubileum: true, forras: "nyilatkozat" });
        }}><Plus className="h-4 w-4" /></button>
      </td>
    </tr>
  );
}

// =================================================================
// SZABADSÁG (6. §) — egyszerű egyenleg-szerkesztő
// =================================================================
function SzabadsagTab() {
  const [ev, setEv] = useState(new Date().getFullYear());
  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      setLoading(true);
      const { data } = await supabase.from("szabadsag_evente").select("*, profiles!inner(nev)").eq("ev", ev);
      setRows((data as any) ?? []);
      setLoading(false);
    })();
  }, [ev]);

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <label className="text-sm">Év:</label>
        <input type="number" value={ev} onChange={(e) => setEv(+e.target.value)} className="px-2 py-1 border rounded bg-background w-24" />
      </div>
      {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : (
        <table className="w-full text-sm">
          <thead className="bg-muted">
            <tr><th className="p-2 text-left">Név</th><th className="p-2 text-right">Alap</th><th className="p-2 text-right">Pót</th><th className="p-2 text-right">Gyermek</th><th className="p-2 text-right">Kivett</th><th className="p-2 text-right">Egyenleg</th></tr>
          </thead>
          <tbody>
            {rows.length === 0 && <tr><td colSpan={6} className="p-4 text-center text-muted-foreground">Nincs adat. A szabadság-egyenlegek automatikusan generálódnak év elején.</td></tr>}
            {rows.map((r) => (
              <tr key={r.id} className="border-b">
                <td className="p-2">{r.profiles?.nev}</td>
                <td className="p-2 text-right">{r.alapszabadsag_nap}</td>
                <td className="p-2 text-right">{r.potszabadsag_nap}</td>
                <td className="p-2 text-right">{r.gyermek_potszabadsag_nap}</td>
                <td className="p-2 text-right">{r.kivett_nap}</td>
                <td className="p-2 text-right font-medium">{r.alapszabadsag_nap + r.potszabadsag_nap + r.gyermek_potszabadsag_nap - r.kivett_nap}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

// =================================================================
// GENERIKUS CRUD
// =================================================================
type Field = { name: string; label: string; type: "text" | "textarea" | "date" | "number" | "select" | "checkbox"; options?: string[]; required?: boolean };

const PROBAIDO_FIELDS: Field[] = [
  { name: "kezdo_datum", label: "Kezdő dátum", type: "date", required: true },
  { name: "tartam_honap", label: "Tartam (hónap, 1–4)", type: "number", required: true },
  { name: "mentesseg_jogcim", label: "Mentesség jogcím", type: "select", options: ["", "athelyezes", "azonos_felek", "kormrend_szakmai_gyakorlat", "hatarozott_ido"] },
  { name: "megjegyzes", label: "Megjegyzés", type: "textarea" },
];
const OSSZEFER_FIELDS: Field[] = [
  { name: "tipus", label: "Típus", type: "select", options: ["kulso_jogviszony", "szekhelyen_tevekenyseg", "tudomanyos", "oktatoi", "egyeb"], required: true },
  { name: "leiras", label: "Leírás", type: "textarea", required: true },
  { name: "engedelyezo_szerv", label: "Engedélyező szerv", type: "text" },
  { name: "kerelem_datum", label: "Kérelem dátuma", type: "date" },
  { name: "engedely_datum", label: "Engedély dátuma", type: "date" },
  { name: "lejarat", label: "Lejárat", type: "date" },
  { name: "status", label: "Státusz", type: "select", options: ["beadva", "engedelyezve", "elutasitva", "visszavonva", "lejart"] },
];
const MINOSITES_FIELDS: Field[] = [
  { name: "idoszak_tol", label: "Időszak tól", type: "date", required: true },
  { name: "idoszak_ig", label: "Időszak ig", type: "date", required: true },
  { name: "eredmeny", label: "Eredmény", type: "select", options: ["kivalo", "jo", "megfelelo", "nem_megfelelo"], required: true },
  { name: "szoveges_ertekeles", label: "Szöveges értékelés", type: "textarea" },
  { name: "alairt", label: "Aláírt", type: "checkbox" },
];
const JUBILEUM_FIELDS: Field[] = [
  { name: "fokozat", label: "Fokozat (25/30/40/45/50)", type: "number", required: true },
  { name: "varhato_datum", label: "Várható dátum", type: "date", required: true },
  { name: "kifizetes_datum", label: "Kifizetés dátuma", type: "date" },
  { name: "osszeg_ft", label: "Összeg (Ft)", type: "number" },
  { name: "status", label: "Státusz", type: "select", options: ["tervezett", "jovahagyva", "kifizetve", "elhalasztva"] },
];
const VEGKI_FIELDS: Field[] = [
  { name: "megszunes_jogcim", label: "Megszünés jogcím", type: "text", required: true },
  { name: "felmentesi_ido_nap", label: "Felmentési idő (nap)", type: "number" },
  { name: "vegkielegites_havi_szam", label: "Végkielégítés (havi szám)", type: "number" },
  { name: "havi_illetmeny_ft", label: "Havi illetmény (Ft)", type: "number" },
  { name: "szamitas_datum", label: "Számítás dátuma", type: "date" },
];
const JUTTATAS_FIELDS: Field[] = [
  { name: "tipus", label: "Típus", type: "select", options: ["lakhatasi_tamogatas", "koltsegterites", "utazasi", "kepzesi", "etkezesi", "cafeteria", "egyeb"], required: true },
  { name: "havi_osszeg_ft", label: "Havi összeg (Ft)", type: "number", required: true },
  { name: "kezdo_datum", label: "Kezdő dátum", type: "date", required: true },
  { name: "zaro_datum", label: "Záró dátum", type: "date" },
];
const KIRENDELES_FIELDS: Field[] = [
  { name: "cel_egeszsegugyi_szolgaltato", label: "Cél egészségügyi szolgáltató", type: "text", required: true },
  { name: "kezdo_datum", label: "Kezdő dátum", type: "date", required: true },
  { name: "zaro_datum", label: "Záró dátum", type: "date", required: true },
  { name: "indok", label: "Indok", type: "textarea" },
  { name: "napi_dij_ft", label: "Napi díj (Ft)", type: "number" },
  { name: "hozzajarult", label: "Hozzájárult", type: "checkbox" },
];

function GenericCrudTab({ table, title, fields }: { table: string; title: string; fields: Field[] }) {
  const [userId, setUserId] = useState<string>("");
  const [members, setMembers] = useState<Array<{ id: string; nev: string; tenant_id: string }>>([]);
  const [editing, setEditing] = useState<any | null>(null);

  const listFn = useServerFn(listEusztvRows);
  const upsertFn = useServerFn(upsertEusztvRow);
  const deleteFn = useServerFn(deleteEusztvRow);
  const qc = useQueryClient();

  useEffect(() => {
    (async () => {
      const tenant = (await supabase.rpc("current_tenant_id")).data as string;
      const { data } = await supabase.from("profiles").select("id, nev, tenant_id").eq("tenant_id", tenant).order("nev");
      setMembers((data as any) ?? []);
    })();
  }, []);

  const { data: rows = [], refetch } = useQuery({
    queryKey: ["eusztv", table, userId],
    queryFn: () => listFn({ data: { table, userId: userId || undefined } }),
    enabled: !!userId,
  });

  const upsertMut = useMutation({
    mutationFn: (v: any) => upsertFn({ data: { table, id: editing?.id, values: v } }),
    onSuccess: () => { toast.success("Mentve"); setEditing(null); refetch(); },
    onError: (e: any) => toast.error(String((e as any)?.message ?? e)),
  });
  const deleteMut = useMutation({
    mutationFn: (id: string) => deleteFn({ data: { table, id } }),
    onSuccess: () => { toast.success("Törölve"); refetch(); },
  });

  const tenantId = members.find((m) => m.id === userId)?.tenant_id || "";

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 flex-wrap">
        <select value={userId} onChange={(e) => setUserId(e.target.value)} className="px-3 py-2 border rounded bg-background min-w-[240px]">
          <option value="">— válassz csapattagot —</option>
          {members.map((m) => <option key={m.id} value={m.id}>{m.nev || m.id}</option>)}
        </select>
        {userId && (
          <button onClick={() => setEditing({})} className="px-3 py-2 bg-primary text-primary-foreground rounded text-sm inline-flex items-center gap-1">
            <Plus className="h-4 w-4" /> Új {title.toLowerCase()}
          </button>
        )}
      </div>

      {userId && (
        <div className="overflow-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted">
              <tr>
                {fields.slice(0, 4).map((f) => <th key={f.name} className="p-2 text-left">{f.label}</th>)}
                <th className="p-2"></th>
              </tr>
            </thead>
            <tbody>
              {rows.length === 0 && <tr><td colSpan={5} className="p-4 text-center text-muted-foreground">Nincs bejegyzés.</td></tr>}
              {rows.map((r: any) => (
                <tr key={r.id} className="border-b">
                  {fields.slice(0, 4).map((f) => (
                    <td key={f.name} className="p-2">{String(r[f.name] ?? "")}</td>
                  ))}
                  <td className="p-2 flex gap-1 justify-end">
                    <button className="text-primary text-xs hover:underline" onClick={() => setEditing(r)}>Szerkeszt</button>
                    <button className="text-destructive text-xs hover:underline" onClick={() => deleteMut.mutate(r.id)}>Töröl</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {editing && (
        <GenericForm
          fields={fields}
          initial={editing}
          onCancel={() => setEditing(null)}
          onSubmit={(v) => upsertMut.mutate({ ...v, user_id: userId, tenant_id: tenantId })}
        />
      )}
    </div>
  );
}

function GenericForm({ fields, initial, onSubmit, onCancel }: { fields: Field[]; initial: any; onSubmit: (v: any) => void; onCancel: () => void }) {
  const [v, setV] = useState<any>(initial);
  return (
    <div className="border rounded-lg p-4 bg-muted/30 space-y-3">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {fields.map((f) => (
          <div key={f.name}>
            <label className="text-xs block mb-1">{f.label}{f.required && " *"}</label>
            {f.type === "textarea" ? (
              <textarea className="w-full px-2 py-1 border rounded bg-background" rows={2} value={v[f.name] ?? ""} onChange={(e) => setV({ ...v, [f.name]: e.target.value })} />
            ) : f.type === "select" ? (
              <select className="w-full px-2 py-1 border rounded bg-background" value={v[f.name] ?? ""} onChange={(e) => setV({ ...v, [f.name]: e.target.value || null })}>
                {f.options?.map((o) => <option key={o} value={o}>{o || "—"}</option>)}
              </select>
            ) : f.type === "checkbox" ? (
              <input type="checkbox" checked={!!v[f.name]} onChange={(e) => setV({ ...v, [f.name]: e.target.checked })} />
            ) : (
              <input
                type={f.type}
                className="w-full px-2 py-1 border rounded bg-background"
                value={v[f.name] ?? ""}
                onChange={(e) => setV({ ...v, [f.name]: f.type === "number" ? (e.target.value === "" ? null : +e.target.value) : (e.target.value || null) })}
              />
            )}
          </div>
        ))}
      </div>
      <div className="flex gap-2">
        <button className="px-3 py-1.5 bg-primary text-primary-foreground rounded text-sm" onClick={() => onSubmit(v)}>Mentés</button>
        <button className="px-3 py-1.5 border rounded text-sm" onClick={onCancel}>Mégse</button>
      </div>
    </div>
  );
}
