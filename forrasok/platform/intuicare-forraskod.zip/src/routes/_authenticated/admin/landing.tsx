import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { listAllBlocks, saveBlock, deleteBlock, reorderBlocks, publishAllBlocks, bulkReplaceBlocks } from "@/lib/admin/landing.functions";
import { generateLandingBlock, generateFullLandingDraft } from "@/lib/admin/ai-settings.functions";
import { DynamicLanding } from "@/components/landing/dynamic-landing";
import { RouteErrorBoundary } from "@/lib/errors/route-boundaries";
import { Plus, Trash2, Sparkles, Save, Globe, Loader2, GripVertical } from "lucide-react";
import { useDraggable } from "@dnd-kit/core";
import { EditorWorkbench } from "@/components/cms/visual/editor-workbench";
import { RichTextEditor } from "@/components/cms/visual/rich-text-editor";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/admin/landing")({
  component: LandingEditor,
  errorComponent: RouteErrorBoundary,
  head: () => ({ meta: [{ title: "Landing szerkesztő – Admin" }] }),
});

const BLOCK_TYPES = [
  { value: "hero", label: "Hero" },
  { value: "feature_grid", label: "Funkciók (rács)" },
  { value: "stats", label: "Statisztika" },
  { value: "cta_band", label: "CTA sáv" },
  { value: "faq", label: "FAQ" },
  { value: "image_text", label: "Kép + szöveg" },
  { value: "custom_html", label: "Egyedi HTML" },
];

function LandingEditor() {
  const qc = useQueryClient();
  const list = useServerFn(listAllBlocks);
  const save = useServerFn(saveBlock);
  const del = useServerFn(deleteBlock);
  const reorder = useServerFn(reorderBlocks);
  const publish = useServerFn(publishAllBlocks);
  const aiField = useServerFn(generateLandingBlock);
  const aiFull = useServerFn(generateFullLandingDraft);
  const bulk = useServerFn(bulkReplaceBlocks);

  const { data: blocks, isLoading } = useQuery({
    queryKey: ["admin", "landing-blocks"],
    queryFn: () => list(),
  });

  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [aiPrompt, setAiPrompt] = useState("");
  const [aiBusy, setAiBusy] = useState(false);

  const sortedBlocks = (blocks ?? []).slice().sort((a, b) => a.position - b.position);
  const selected = sortedBlocks.find((b) => b.id === selectedId) ?? null;

  async function addBlock(type: string) {
    const pos = (sortedBlocks[sortedBlocks.length - 1]?.position ?? -1) + 1;
    const r = await save({ data: { block_type: type, position: pos, content: defaultContent(type), locale: "hu", is_published: false } });
    qc.invalidateQueries({ queryKey: ["admin", "landing-blocks"] });
    setSelectedId(r.id);
  }
  async function removeBlock(id: string) {
    if (!confirm("Törlöd?")) return;
    await del({ data: { id } });
    qc.invalidateQueries({ queryKey: ["admin", "landing-blocks"] });
    if (selectedId === id) setSelectedId(null);
  }
  const saveMut = useMutation({
    mutationFn: async (b: any) => save({ data: b }),
    onSuccess: () => {
      toast.success("Mentve");
      qc.invalidateQueries({ queryKey: ["admin", "landing-blocks"] });
    },
    onError: (e) => toast.error((e as Error).message),
  });
  async function publishAll() {
    if (!confirm("Minden blokkot publikálsz?")) return;
    await publish();
    toast.success("Publikálva");
    qc.invalidateQueries({ queryKey: ["admin", "landing-blocks"] });
  }
  async function aiGenerateField(field: string) {
    if (!selected) return;
    const prompt = window.prompt(`AI generálás — ${field}:`, "");
    if (!prompt) return;
    setAiBusy(true);
    try {
      const r = await aiField({ data: { blockType: selected.block_type, field, prompt } });
      updateContent(field, r.value);
    } finally { setAiBusy(false); }
  }
  async function aiGenerateFull() {
    if (!aiPrompt.trim()) return;
    if (!confirm("Az AI le fogja cserélni az összes jelenlegi blokkot (verzió mentve). Folytatod?")) return;
    setAiBusy(true);
    try {
      const r = await aiFull({ data: { prompt: aiPrompt } });
      if (!r.blocks?.length) { toast.error("Üres válasz"); return; }
      await bulk({ data: { blocks: r.blocks } });
      toast.success(`${r.blocks.length} blokk generálva (vázlat)`);
      qc.invalidateQueries({ queryKey: ["admin", "landing-blocks"] });
      setAiPrompt("");
    } catch (e) {
      toast.error((e as Error).message);
    } finally { setAiBusy(false); }
  }

  function updateContent(field: string, value: any) {
    if (!selected) return;
    const cur = (selected.content as any) ?? {};
    saveMut.mutate({ ...(selected as any), content: { ...cur, [field]: value } });
  }

  async function reorderIds(ids: string[]) {
    await reorder({ data: { orders: ids.map((id, i) => ({ id, position: i })) } });
    qc.invalidateQueries({ queryKey: ["admin", "landing-blocks"] });
  }

  async function insertAt({ type, index }: { type: string; index: number }) {
    const r = await save({ data: { block_type: type, position: index, content: defaultContent(type), locale: "hu", is_published: false } });
    const ids = sortedBlocks.map((b) => b.id);
    ids.splice(index, 0, r.id);
    await reorderIds(ids.filter((v, i, a) => a.indexOf(v) === i));
    setSelectedId(r.id);
  }

  return (
    <EditorWorkbench
      toolbar={
        <div className="flex items-center gap-2">
          <h2 className="text-sm font-semibold">Landing szerkesztő</h2>
          <Button size="sm" onClick={publishAll}><Globe className="size-4 mr-1" />Publikálás</Button>
        </div>
      }
      palette={
        <div className="p-3 space-y-3">
          <div className="space-y-2">
            <Textarea
              rows={3}
              value={aiPrompt}
              placeholder="Teljes oldal AI generálás — pl. 'Sportorvosi rendelő, modern, sportoló célközönség'"
              onChange={(e) => setAiPrompt(e.target.value)}
              className="text-xs"
            />
            <Button size="sm" className="w-full" onClick={aiGenerateFull} disabled={aiBusy || !aiPrompt.trim()}>
              {aiBusy ? <Loader2 className="size-4 animate-spin mr-1" /> : <Sparkles className="size-4 mr-1" />}
              AI generálás
            </Button>
          </div>
          <div className="border-t pt-3">
            <div className="text-xs font-semibold mb-2">+ Új blokk</div>
            <p className="text-[11px] text-muted-foreground mb-2">Kattints a végére szúráshoz, vagy húzd a kívánt pozícióra.</p>
            <div className="space-y-1">
              {BLOCK_TYPES.map((bt) => (
                <LandingPaletteItem
                  key={bt.value}
                  type={bt.value}
                  label={bt.label}
                  onInsert={() => addBlock(bt.value)}
                />
              ))}
            </div>
          </div>
        </div>
      }
      items={sortedBlocks.map((b) => ({
        id: b.id,
        type: b.block_type,
        subtitle: String((b.content as any)?.title ?? "—"),
      }))}
      loading={isLoading}
      selectedId={selectedId}
      onSelect={setSelectedId}
      onReorder={reorderIds}
      onInsertAt={({ type, index }: { type: string; index: number }) => insertAt({ type, index })}
      renderItem={(item: { id: string; type: string; subtitle?: string }) => {
        const b = sortedBlocks.find((x) => x.id === item.id)!;
        return (
          <div className="flex items-center gap-2">
            <div className="flex-1 min-w-0">
              <div className="text-xs font-medium flex items-center gap-1">
                {item.type}
                {b?.is_published && <Badge variant="outline" className="text-[9px]">élő</Badge>}
              </div>
              <div className="text-[10px] text-muted-foreground truncate">{item.subtitle}</div>
            </div>
            <span
              role="button"
              tabIndex={0}
              aria-label="Blokk törlése"
              className="p-1 text-destructive"
              onClick={(e) => { e.stopPropagation(); void removeBlock(item.id); }}
              onKeyDown={(e) => { if (e.key === "Enter") { e.stopPropagation(); void removeBlock(item.id); } }}
            >
              <Trash2 className="size-3" />
            </span>
          </div>
        );
      }}
      previewUrl="/"
      previewNonce={sortedBlocks.length + (saveMut.isSuccess ? 1 : 0)}
      inspector={
        selected ? (
          <div className="p-4 space-y-3">
            <h3 className="font-semibold flex items-center gap-2 text-sm">
              {selected.block_type} <Badge variant="outline">#{selected.position}</Badge>
            </h3>
            <BlockEditor
              block={selected}
              onField={(field, v) => updateContent(field, v)}
              onAiField={aiGenerateField}
            />
            <Button onClick={() => saveMut.mutate({ ...selected })} disabled={saveMut.isPending}>
              <Save className="size-4 mr-1" />Mentés
            </Button>
            <div className="pt-3 border-t">
              <div className="text-[11px] font-semibold text-muted-foreground mb-2">BLOKK ELŐNÉZET</div>
              <div className="border rounded-lg overflow-hidden bg-background">
                <DynamicLanding blocks={[selected] as any} brandName="Előnézet" />
              </div>
            </div>
          </div>
        ) : (
          <div className="p-6 text-center text-xs text-muted-foreground">
            Válassz egy blokkot szerkesztéshez, vagy húzz be újat a palettáról.
          </div>
        )
      }
    />
  );
}

function LandingPaletteItem({ type, label, onInsert }: { type: string; label: string; onInsert: () => void }) {
  const { attributes, listeners, setNodeRef, isDragging } = useDraggable({
    id: `palette:${type}`,
    data: { palette: true, type, defaults: defaultContent(type) },
  });
  return (
    <div ref={setNodeRef} className={`flex items-center gap-1 rounded border p-1.5 hover:bg-accent ${isDragging ? "opacity-50" : ""}`}>
      <button type="button" className="cursor-grab active:cursor-grabbing text-muted-foreground touch-none"
        aria-label={`${label} húzása`} {...attributes} {...listeners}>
        <GripVertical className="size-3.5" />
      </button>
      <button type="button" className="flex-1 text-left text-xs" onClick={onInsert}>
        <Plus className="size-3 mr-1 inline" />{label}
      </button>
    </div>
  );
}

function BlockEditor({ block, onField, onAiField }: { block: any; onField: (f: string, v: any) => void; onAiField: (f: string) => void }) {
  const c = block.content ?? {};
  const fields = fieldsFor(block.block_type);
  return (
    <div className="space-y-3">
      {fields.map((f) => (
        <div key={f.key} className="space-y-1">
          <div className="flex items-center justify-between">
            <label className="text-xs font-medium">{f.label}</label>
            {f.aiable && (
              <button onClick={() => onAiField(f.key)} className="text-xs text-primary inline-flex items-center gap-1">
                <Sparkles className="size-3" /> AI
              </button>
            )}
          </div>
          {f.type === "rich" ? (
            <RichTextEditor
              value={String(c[f.key] ?? "")}
              onChange={(html) => onField(f.key, html)}
              minRows={6}
            />
          ) : f.type === "textarea" ? (
            <Textarea rows={3} value={String(c[f.key] ?? "")} onChange={(e) => onField(f.key, e.target.value)} />
          ) : f.type === "json" ? (
            <Textarea rows={5} className="font-mono text-xs"
              value={typeof c[f.key] === "string" ? c[f.key] : JSON.stringify(c[f.key] ?? [], null, 2)}
              onChange={(e) => { try { onField(f.key, JSON.parse(e.target.value)); } catch { onField(f.key, e.target.value); } }} />
          ) : (
            <Input value={String(c[f.key] ?? "")} onChange={(e) => onField(f.key, e.target.value)} />
          )}
        </div>
      ))}
    </div>
  );
}


function fieldsFor(type: string): { key: string; label: string; type: "input" | "textarea" | "json" | "rich"; aiable?: boolean }[] {
  switch (type) {
    case "hero": return [
      { key: "title", label: "Cím", type: "input", aiable: true },
      { key: "subtitle", label: "Alcím", type: "textarea", aiable: true },
      { key: "cta_label", label: "CTA gomb felirat", type: "input" },
      { key: "cta_to", label: "CTA cél (/auth)", type: "input" },
    ];
    case "feature_grid": return [
      { key: "title", label: "Cím", type: "input", aiable: true },
      { key: "items", label: "Funkciók (JSON: [{title,description}])", type: "json", aiable: true },
    ];
    case "stats": return [
      { key: "items", label: "Statisztikák (JSON: [{value,label}])", type: "json", aiable: true },
    ];
    case "cta_band": return [
      { key: "title", label: "Cím", type: "input", aiable: true },
      { key: "subtitle", label: "Alcím", type: "input", aiable: true },
      { key: "cta_label", label: "CTA gomb", type: "input" },
      { key: "cta_to", label: "CTA cél", type: "input" },
    ];
    case "faq": return [
      { key: "title", label: "Cím", type: "input" },
      { key: "items", label: "FAQ (JSON: [{q,a}])", type: "json", aiable: true },
    ];
    case "image_text": return [
      { key: "title", label: "Cím", type: "input", aiable: true },
      { key: "body", label: "Szöveg", type: "rich", aiable: true },
      { key: "image_url", label: "Kép URL", type: "input" },
      { key: "image_alt", label: "Alt szöveg", type: "input", aiable: true },
    ];
    case "custom_html": return [{ key: "html", label: "HTML", type: "rich" }];
    default: return [];
  }
}

function defaultContent(type: string): Record<string, any> {
  switch (type) {
    case "hero": return { title: "Új cím", subtitle: "Új alcím", cta_label: "Belépés", cta_to: "/auth" };
    case "feature_grid": return { title: "Funkciók", items: [{ title: "Funkció 1", description: "Leírás" }] };
    case "stats": return { items: [{ value: "100+", label: "Felhasználó" }] };
    case "cta_band": return { title: "Csatlakozz", cta_label: "Indulás", cta_to: "/auth" };
    case "faq": return { title: "GYIK", items: [{ q: "Kérdés?", a: "Válasz." }] };
    case "image_text": return { title: "Cím", body: "Szöveg", image_url: "" };
    case "custom_html": return { html: "<p>Egyedi HTML</p>" };
    default: return {};
  }
}
