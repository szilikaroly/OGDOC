import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Activity, AlertTriangle, Clock, Loader2, PlayCircle, RefreshCw, Zap } from "lucide-react";
import { getEscalationCronStatus, runEscalationNow } from "@/lib/paciens-360/paciens-360.functions";

export const Route = createFileRoute("/_authenticated/admin/eszkalacio")({
  component: EszkalacioAdmin,
});

type Status = Awaited<ReturnType<typeof getEscalationCronStatus>>;

function EszkalacioAdmin() {
  const get = useServerFn(getEscalationCronStatus);
  const run = useServerFn(runEscalationNow);
  const [status, setStatus] = useState<Status | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [runMsg, setRunMsg] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    setLoading(true);
    setErr(null);
    try { setStatus(await get()); } catch (e) { setErr(e instanceof Error ? e.message : "Hiba."); }
    finally { setLoading(false); }
  }, [get]);

  useEffect(() => { void refresh(); }, [refresh]);

  const doRun = async () => {
    setBusy(true); setRunMsg(null); setErr(null);
    try {
      const r = await run();
      setRunMsg(`Lefutott. Szabályok: ${r.rules_evaluated}, eszkalált: ${r.escalated}${r.errors.length ? `, hiba: ${r.errors.length}` : ""}`);
      void refresh();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Hiba.");
    } finally {
      setBusy(false);
    }
  };

  const fmt = (iso?: string | null) => (iso ? new Date(iso).toLocaleString("hu-HU") : "—");

  return (
    <div className="container max-w-5xl py-6 space-y-4">
      <header className="rounded-2xl border border-border bg-gradient-to-br from-card to-card/60 p-5">
        <h1 className="text-2xl font-semibold flex items-center gap-2">
          <Zap className="h-6 w-6 text-violet-500" /> Eszkalációs futások
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          A pg_cron 5 percenként futtatja az eszkalációs szabályokat. Itt láthatod az ütemezést, az utolsó futásokat és kézzel is elindíthatsz egy kört.
        </p>
        <div className="mt-3 flex gap-2">
          <button onClick={refresh} disabled={loading} className="text-xs px-3 py-1.5 rounded-md border border-border hover:bg-accent inline-flex items-center gap-1 disabled:opacity-50">
            <RefreshCw className={"h-3 w-3 " + (loading ? "animate-spin" : "")} /> Frissítés
          </button>
          <button onClick={doRun} disabled={busy} className="text-xs px-3 py-1.5 rounded-md bg-violet-500 text-white hover:bg-violet-600 inline-flex items-center gap-1 disabled:opacity-50">
            {busy ? <Loader2 className="h-3 w-3 animate-spin" /> : <PlayCircle className="h-3 w-3" />} Futtatás most
          </button>
        </div>
        {runMsg && <div className="mt-2 text-xs text-emerald-600">{runMsg}</div>}
        {err && <div className="mt-2 text-xs text-rose-600 inline-flex items-center gap-1"><AlertTriangle className="h-3 w-3" /> {err}</div>}
      </header>

      {loading ? (
        <div className="text-sm text-muted-foreground inline-flex items-center gap-1"><Loader2 className="h-3 w-3 animate-spin" /> Betöltés…</div>
      ) : !status ? null : (
        <>
          <section className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <Card icon={Clock} label="Ütemezés (UTC)" value={status.job?.schedule ?? "—"} sub={status.job?.active === false ? "Inaktív!" : "Aktív"} />
            <Card icon={Clock} label="Utolsó futás" value={fmt(status.recent[0]?.start_time)} sub={status.recent[0]?.status ?? ""} />
            <Card icon={Clock} label="Következő futás (becslés)" value={fmt(status.nextRunIso)} />
            <Card icon={Activity} label="Eszkalált az utolsó körben" value={String(status.lastRunEscalated)} sub={`24 óra alatt: ${status.escalatedLast24h}`} />
          </section>

          <section className="rounded-xl border border-border bg-card p-4">
            <h2 className="text-sm font-semibold mb-3 flex items-center gap-2"><Activity className="h-4 w-4 text-primary" /> Utolsó 20 cron futás</h2>
            {status.recent.length === 0 ? (
              <div className="text-sm text-muted-foreground">Még nincs futási előzmény.</div>
            ) : (
              <div className="overflow-auto">
                <table className="w-full text-xs">
                  <thead className="text-muted-foreground">
                    <tr className="text-left border-b border-border">
                      <th className="py-1.5 pr-2">Kezdés</th>
                      <th className="py-1.5 pr-2">Vége</th>
                      <th className="py-1.5 pr-2">Státusz</th>
                      <th className="py-1.5 pr-2">Üzenet</th>
                    </tr>
                  </thead>
                  <tbody>
                    {status.recent.map((r, i) => (
                      <tr key={i} className="border-b border-border/40">
                        <td className="py-1.5 pr-2 font-mono">{fmt(r.start_time)}</td>
                        <td className="py-1.5 pr-2 font-mono">{fmt(r.end_time)}</td>
                        <td className="py-1.5 pr-2">
                          <span className={
                            "px-1.5 py-0.5 rounded text-[10px] font-mono uppercase " +
                            (r.status === "succeeded" ? "bg-emerald-500/15 text-emerald-700" : "bg-rose-500/15 text-rose-700")
                          }>{r.status}</span>
                        </td>
                        <td className="py-1.5 pr-2 text-muted-foreground truncate max-w-[420px]" title={r.return_message ?? ""}>{r.return_message ?? ""}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>
        </>
      )}
    </div>
  );
}

function Card({ icon: Icon, label, value, sub }: { icon: React.ComponentType<{ className?: string }>; label: string; value: string; sub?: string }) {
  return (
    <div className="rounded-xl border border-border bg-card p-3">
      <div className="text-[10px] uppercase text-muted-foreground inline-flex items-center gap-1"><Icon className="h-3 w-3" /> {label}</div>
      <div className="text-lg font-semibold mt-1">{value}</div>
      {sub && <div className="text-[11px] text-muted-foreground">{sub}</div>}
    </div>
  );
}
