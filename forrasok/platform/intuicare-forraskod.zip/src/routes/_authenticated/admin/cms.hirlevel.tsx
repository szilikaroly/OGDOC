/**
 * Admin hírlevél felület.
 */
import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Loader2, Send, Trash2, Plus } from "lucide-react";
import { listNewsletters, saveNewsletter, sendNewsletter, deleteNewsletter } from "@/lib/cms/newsletter.functions";

export const Route = createFileRoute("/_authenticated/admin/cms/hirlevel")({
  ssr: false,
  component: HirlevelAdmin,
});

function HirlevelAdmin() {
  const qc = useQueryClient();
  const listFn = useServerFn(listNewsletters);
  const saveFn = useServerFn(saveNewsletter);
  const sendFn = useServerFn(sendNewsletter);
  const delFn = useServerFn(deleteNewsletter);

  const q = useQuery({ queryKey: ["newsletters"], queryFn: () => listFn() });

  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [audience, setAudience] = useState<"all" | "tips" | "news" | "newsletter">("all");

  const save = useMutation({
    mutationFn: () => saveFn({ data: { subject, body_html: body, audience } }),
    onSuccess: () => {
      toast.success("Mentve");
      setSubject(""); setBody("");
      qc.invalidateQueries({ queryKey: ["newsletters"] });
    },
    onError: (e: any) => toast.error(e?.message ?? "Hiba"),
  });

  const send = useMutation({
    mutationFn: (id: string) => sendFn({ data: { id } }),
    onSuccess: (r: any) => {
      toast.success(`Elküldve ${r.sent} címzettnek`);
      qc.invalidateQueries({ queryKey: ["newsletters"] });
    },
    onError: (e: any) => toast.error(e?.message ?? "Hiba"),
  });

  const del = useMutation({
    mutationFn: (id: string) => delFn({ data: { id } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["newsletters"] }),
  });

  return (
    <div className="container mx-auto px-3 sm:px-6 lg:px-8 py-6 max-w-5xl">
      <h1 className="text-2xl font-bold mb-6">Hírlevél</h1>
      <div className="grid lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader><CardTitle className="text-base flex items-center gap-2"><Plus className="size-4" />Új körlevél</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <Input placeholder="Tárgy" value={subject} onChange={(e) => setSubject(e.target.value)} />
            <Select value={audience} onValueChange={(v) => setAudience(v as any)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Mindenki</SelectItem>
                <SelectItem value="tips">Tanácsokra feliratkozók</SelectItem>
                <SelectItem value="news">Hírekre feliratkozók</SelectItem>
                <SelectItem value="newsletter">Csak hírlevél-feliratkozók</SelectItem>
              </SelectContent>
            </Select>
            <Textarea rows={10} placeholder="HTML tartalom… (a system unsubscribe láblécet automatikusan hozzáfűzi)"
              value={body} onChange={(e) => setBody(e.target.value)} className="font-mono text-xs" />
            <Button
              onClick={() => save.mutate()}
              disabled={save.isPending || subject.length < 2 || body.length < 2}
              className="w-full"
            >
              {save.isPending && <Loader2 className="size-4 animate-spin mr-1" />}
              Vázlat mentése
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Korábbi körlevelek</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {q.isLoading && <div className="text-sm text-muted-foreground">Betöltés…</div>}
            {(q.data ?? []).map((n: any) => (
              <div key={n.id} className="border rounded p-3 text-sm">
                <div className="flex items-center justify-between gap-2">
                  <div className="font-medium truncate">{n.subject}</div>
                  <Badge variant={n.status === "sent" ? "default" : "outline"}>{n.status}</Badge>
                </div>
                <div className="text-xs text-muted-foreground mt-1">
                  {n.audience} · {n.sent_at ? new Date(n.sent_at).toLocaleString("hu-HU") + ` · ${n.sent_count} cím` : "vázlat"}
                </div>
                <div className="flex gap-1 mt-2">
                  {n.status !== "sent" && (
                    <Button size="sm" onClick={() => send.mutate(n.id)} disabled={send.isPending} className="gap-1">
                      <Send className="size-3.5" />Küldés
                    </Button>
                  )}
                  <Button size="sm" variant="ghost" onClick={() => del.mutate(n.id)}>
                    <Trash2 className="size-3.5" />
                  </Button>
                </div>
              </div>
            ))}
            {!q.isLoading && !q.data?.length && <div className="text-sm text-muted-foreground">Még nincs körlevél.</div>}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
