import { createFileRoute, Link } from "@tanstack/react-router";
import { useTranslation } from "react-i18next";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Sparkles, ClipboardCheck, History } from "lucide-react";
import { PagesAdmin } from "@/components/cms/pages-admin";
import { MenusAdmin } from "@/components/cms/menus-admin";
import { MediaAdmin } from "@/components/cms/media-admin";
import { RedirectsAdmin } from "@/components/cms/redirects-admin";
import { NewsAdmin } from "@/components/cms/news-admin";
import { ExperimentsAdmin } from "@/components/cms/experiments-admin";
import { CmsAnalytics } from "@/components/cms/cms-analytics";
import { FaqsAdmin } from "@/components/cms/faqs-admin";
import { TipsAdmin } from "@/components/cms/tips/tips-admin";
import { I18nAutoTranslateWidget } from "@/components/cms/i18n-auto-translate-widget";

export const Route = createFileRoute("/_authenticated/admin/cms/")({
  ssr: false,
  component: CmsAdminPage,
});

function CmsAdminPage() {
  const { t } = useTranslation();
  return (
    <div className="container mx-auto py-4 sm:py-8 px-3 sm:px-6 lg:px-8 max-w-7xl">
      <header className="mb-4 sm:mb-6 flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold">{t("cms.admin.title")}</h1>
          <p className="text-muted-foreground text-sm mt-1">{t("cms.admin.subtitle")}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button asChild variant="outline">
            <Link to="/admin/cms/jovahagyas" className="gap-2"><ClipboardCheck className="size-4" />{t("cms.admin.pending_approval")}</Link>
          </Button>
          <Button asChild variant="outline">
            <Link to="/admin/cms/naplo" className="gap-2"><History className="size-4" />{t("cms.admin.audit_log")}</Link>
          </Button>
          <Button asChild>
            <Link to="/admin/cms/visual" className="gap-2"><Sparkles className="size-4" />{t("cms.admin.visual_editor")}</Link>
          </Button>
        </div>
      </header>
      <div className="mb-4 sm:mb-6">
        <I18nAutoTranslateWidget />
      </div>
      <Tabs defaultValue="pages">
        <div className="-mx-3 sm:mx-0 overflow-x-auto">
          <TabsList className="mx-3 sm:mx-0 inline-flex w-max sm:w-auto">
            <TabsTrigger value="pages" className="min-h-11">{t("cms.admin.tabs.pages")}</TabsTrigger>
            <TabsTrigger value="news" className="min-h-11">{t("cms.admin.tabs.news")}</TabsTrigger>
            <TabsTrigger value="menus" className="min-h-11">{t("cms.admin.tabs.menus")}</TabsTrigger>
            <TabsTrigger value="media" className="min-h-11">{t("cms.admin.tabs.media")}</TabsTrigger>
            <TabsTrigger value="redirects" className="min-h-11">{t("cms.admin.tabs.redirects")}</TabsTrigger>
            <TabsTrigger value="experiments" className="min-h-11">{t("cms.admin.tabs.experiments")}</TabsTrigger>
            <TabsTrigger value="faqs" className="min-h-11">{t("cms.admin.tabs.faqs")}</TabsTrigger>
            <TabsTrigger value="tips" className="min-h-11">{t("cms.admin.tabs.tips")}</TabsTrigger>
            <TabsTrigger value="analytics" className="min-h-11">{t("cms.admin.tabs.analytics")}</TabsTrigger>
          </TabsList>
        </div>
        <TabsContent value="pages"><PagesAdmin /></TabsContent>
        <TabsContent value="news"><NewsAdmin /></TabsContent>
        <TabsContent value="menus"><MenusAdmin /></TabsContent>
        <TabsContent value="media"><MediaAdmin /></TabsContent>
        <TabsContent value="redirects"><RedirectsAdmin /></TabsContent>
        <TabsContent value="experiments"><ExperimentsAdmin /></TabsContent>
        <TabsContent value="faqs"><FaqsAdmin /></TabsContent>
        <TabsContent value="tips"><TipsAdmin /></TabsContent>
        <TabsContent value="analytics"><CmsAnalytics /></TabsContent>
      </Tabs>
    </div>
  );
}
