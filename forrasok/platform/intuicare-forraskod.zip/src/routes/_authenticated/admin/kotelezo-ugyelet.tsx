import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

import { toast } from "sonner";
import { humanizeError } from "@/lib/humanize-error";
import { useTranslation } from "react-i18next";
import { AlertTriangle, Plus, Trash2, Check, X as XIcon } from "lucide-react";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/admin/kotelezo-ugyelet")({
  component: KotelezoUgyeletPage,
});

type Rule = {
  id: string;
  tenant_id: string;
  scope_tipus: "global" | "foglalkozas_tipus" | "staff_role" | "site";
  scope_value: string | null;
  min_per_honap: number;
  max_per_honap: number | null;
  megjegyzes: string | null;
  aktiv: boolean;
};

type Exemption = {
  id: string;
  user_id: string;
  ok: "terhesseg" | "gyermekgondozas" | "kor" | "jogviszony" | "egeszsegugyi" | "egyeb";
  ervenyes_tol: string;
  ervenyes_ig: string | null;
  indok: string | null;
  status: "jovahagyasra_var" | "jovahagyott" | "elutasitott";
  jovahagyo_id: string | null;
  jovahagyas_at: string | null;
  jovahagyas_indok: string | null;
  profiles?: { teljes_nev: string; email: string } | null;
};

const SCOPE_OPTIONS = [
  { value: "global", label: "Mindenki" },
  { value: "foglalkozas_tipus", label: "Foglalkozás-típus" },
  { value: "staff_role", label: "Munkakör" },
  { value: "site", label: "Telephely" },
] as const;

const OK_LABELS: Record<Exemption["ok"], string> = {
  terhesseg: "Terhesség",
  gyermekgondozas: "Gyermekgondozás",
  kor: "Életkor",
  jogviszony: "Jogviszony",
  egeszsegugyi: "Egészségügyi",
  egyeb: "Egyéb",
};

function KotelezoUgyeletPage() {
  const { t } = useTranslation();
  const [tenantId, setTenantId] = useState<string | null>(null);
  const [isHr, setIsHr] = useState(false);
  const [rules, setRules] = useState<Rule[]>([]);
  const [exemptions, setExemptions] = useState<Exemption[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    const { data: prof } = await supabase.from("profiles").select("tenant_id").eq("id", user.id).maybeSingle();
    setTenantId(prof?.tenant_id ?? null);
    const { data: hr } = await supabase.rpc("has_permission", { _user_id: user.id, _perm: "manage_tenant" });
    setIsHr(Boolean(hr));
    const [r, e] = await Promise.all([
      supabase.from("mandatory_duty_rules").select("*").order("scope_tipus"),
      supabase.from("mandatory_duty_exemptions")
        .select("*, profiles!mandatory_duty_exemptions_user_id_fkey(teljes_nev,email)")
        .order("created_at", { ascending: false }),
    ]);
    setRules((r.data ?? []) as Rule[]);
    setExemptions((e.data ?? []) as unknown as Exemption[]);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  async function addRule() {
    if (!tenantId) return;
    const { error } = await supabase.from("mandatory_duty_rules").insert({
      tenant_id: tenantId, scope_tipus: "global", scope_value: null,
      min_per_honap: 4, max_per_honap: null, aktiv: true,
    });
    if (error) return toast.error(humanizeError(error, t));
    load();
  }
  async function updateRule(id: string, patch: Partial<Rule>) {
    const { error } = await supabase.from("mandatory_duty_rules").update(patch).eq("id", id);
    if (error) return toast.error(humanizeError(error, t));
    load();
  }
  async function deleteRule(r: Rule) {
    if (!window.confirm("Törlöd ezt a szabályt?")) return;
    const { error } = await supabase.from("mandatory_duty_rules").delete().eq("id", r.id);
    if (error) return toast.error(humanizeError(error, t));
    load();
  }

  async function approveExemption(ex: Exemption) {
    const { error } = await supabase.from("mandatory_duty_exemptions")
      .update({ status: "jovahagyott" }).eq("id", ex.id);
    if (error) return toast.error(humanizeError(error, t));
    toast.success("Mentesség jóváhagyva.");
    load();
  }
  async function rejectExemption(ex: Exemption) {
    const indok = window.prompt("Elutasítás indoka:");
    if (!indok) return;
    const { error } = await supabase.from("mandatory_duty_exemptions")
      .update({ status: "elutasitott", jovahagyas_indok: indok }).eq("id", ex.id);
    if (error) return toast.error(humanizeError(error, t));
    load();
  }

  return (
      <div className="p-8 max-w-6xl mx-auto">
        <div className="mb-6 flex items-center gap-3">
          <AlertTriangle className="size-6 text-primary" />
          <div className="flex-1">
            <h1 className="text-2xl font-bold">Kötelező ügyelet</h1>
            <p className="text-sm text-muted-foreground font-mono uppercase tracking-wider">
              Havi minimum szabályok és egyéni mentességek
            </p>
          </div>
          <a href="/admin/szervezet-sugo" className="text-xs underline text-muted-foreground hover:text-foreground">
            kézikönyv ↗
          </a>
        </div>

        <div className="mb-4 p-3 rounded-lg border border-primary/20 bg-primary/5 text-xs text-muted-foreground">
          <b className="text-foreground">Három szabály-réteg együtt:</b> (1) <i>Havi minimum / fő</i> – itt; (2) <i>Kötelező lefedés</i> – ügyeleti sor coverage-énél; (3) <i>Egyéni mentesség</i> – HR (tenant-admin) hagyja jóvá. Saját kérelmét senki nem hagyhatja jóvá; elutasításhoz indoklás kötelező.
        </div>

        {loading && <div className="text-sm text-muted-foreground">Betöltés…</div>}

        {!loading && (
          <>
            {/* RULES */}
            <section className="mb-8 bg-card border rounded-2xl p-4">
              <div className="flex items-center justify-between mb-3">
                <h2 className="font-semibold">Havi minimum szabályok</h2>
                <button type="button" onClick={addRule}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-primary text-primary-foreground rounded-lg text-xs font-mono font-semibold uppercase">
                  <Plus className="size-3.5" /> Új szabály
                </button>
              </div>
              {rules.length === 0 ? (
                <div className="text-sm text-muted-foreground italic">Nincs szabály.</div>
              ) : (
                <table className="w-full text-sm">
                  <thead className="text-xs uppercase text-muted-foreground">
                    <tr><th className="text-left p-2">Hatókör</th><th className="text-left p-2">Érték</th><th className="text-left p-2">Min/hó</th><th className="text-left p-2">Max/hó</th><th className="text-left p-2">Aktív</th><th></th></tr>
                  </thead>
                  <tbody>
                    {rules.map(r => (
                      <tr key={r.id} className="border-t">
                        <td className="p-2">
                          <select value={r.scope_tipus}
                            onChange={(e) => updateRule(r.id, { scope_tipus: e.target.value as Rule["scope_tipus"], scope_value: null })}
                            className="px-2 py-1 rounded border bg-background text-sm">
                            {SCOPE_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                          </select>
                        </td>
                        <td className="p-2">
                          {r.scope_tipus === "global" ? (
                            <span className="text-xs text-muted-foreground">—</span>
                          ) : r.scope_tipus === "foglalkozas_tipus" ? (
                            <select value={r.scope_value ?? ""}
                              onChange={(e) => updateRule(r.id, { scope_value: e.target.value })}
                              className="px-2 py-1 rounded border bg-background text-sm">
                              <option value="">(válassz)</option>
                              <option value="szakorvos">Szakorvos</option>
                              <option value="rezidens">Rezidens</option>
                              <option value="szakgyakornok">Szakgyakornok</option>
                              <option value="apolo">Ápoló</option>
                              <option value="asszisztens">Asszisztens</option>
                              <option value="egyeb">Egyéb</option>
                            </select>
                          ) : (
                            <input value={r.scope_value ?? ""}
                              onChange={(e) => updateRule(r.id, { scope_value: e.target.value })}
                              placeholder={r.scope_tipus === "site" ? "site_id" : "kulcs"}
                              className="px-2 py-1 rounded border bg-background text-sm w-48" />
                          )}
                        </td>
                        <td className="p-2">
                          <input type="number" min={0} value={r.min_per_honap}
                            onChange={(e) => updateRule(r.id, { min_per_honap: Number(e.target.value) })}
                            className="w-16 px-2 py-1 rounded border bg-background text-sm" />
                        </td>
                        <td className="p-2">
                          <input type="number" min={0} value={r.max_per_honap ?? ""}
                            onChange={(e) => updateRule(r.id, { max_per_honap: e.target.value ? Number(e.target.value) : null })}
                            className="w-16 px-2 py-1 rounded border bg-background text-sm" />
                        </td>
                        <td className="p-2">
                          <input type="checkbox" checked={r.aktiv}
                            onChange={(e) => updateRule(r.id, { aktiv: e.target.checked })} />
                        </td>
                        <td className="p-2 text-right">
                          <button type="button" onClick={() => deleteRule(r)}
                            className="text-muted-foreground hover:text-warning" aria-label="Törlés">
                            <Trash2 className="size-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </section>

            {/* EXEMPTIONS */}
            <section className="bg-card border rounded-2xl p-4">
              <div className="flex items-center justify-between mb-3">
                <h2 className="font-semibold">Egyéni mentességek</h2>
                <span className="text-xs text-muted-foreground">
                  {isHr ? "HR jóváhagyási nézet" : "Csak megtekintés (HR jóváhagyás szükséges)"}
                </span>
              </div>
              {exemptions.length === 0 ? (
                <div className="text-sm text-muted-foreground italic">Nincs mentesség rögzítve.</div>
              ) : (
                <table className="w-full text-sm">
                  <thead className="text-xs uppercase text-muted-foreground">
                    <tr>
                      <th className="text-left p-2">Felhasználó</th>
                      <th className="text-left p-2">Ok</th>
                      <th className="text-left p-2">Érvényesség</th>
                      <th className="text-left p-2">Indok</th>
                      <th className="text-left p-2">Státusz</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    {exemptions.map(ex => (
                      <tr key={ex.id} className="border-t align-top">
                        <td className="p-2">
                          <div className="font-medium">{ex.profiles?.teljes_nev ?? "—"}</div>
                          <div className="text-xs text-muted-foreground">{ex.profiles?.email}</div>
                        </td>
                        <td className="p-2">{OK_LABELS[ex.ok]}</td>
                        <td className="p-2 text-xs">
                          {ex.ervenyes_tol} – {ex.ervenyes_ig ?? "∞"}
                        </td>
                        <td className="p-2 text-xs max-w-xs">{ex.indok}</td>
                        <td className="p-2">
                          <span className={cn("px-2 py-0.5 rounded-full text-[10px] font-mono uppercase",
                            ex.status === "jovahagyott" && "bg-green-500/15 text-green-700 dark:text-green-300",
                            ex.status === "elutasitott" && "bg-red-500/15 text-red-700 dark:text-red-300",
                            ex.status === "jovahagyasra_var" && "bg-amber-500/15 text-amber-700 dark:text-amber-300",
                          )}>{ex.status}</span>
                        </td>
                        <td className="p-2 text-right whitespace-nowrap">
                          {isHr && ex.status === "jovahagyasra_var" && (
                            <div className="flex gap-1 justify-end">
                              <button type="button" onClick={() => approveExemption(ex)}
                                className="p-1 text-green-600 hover:bg-green-500/10 rounded" aria-label="Jóváhagy">
                                <Check className="size-4" />
                              </button>
                              <button type="button" onClick={() => rejectExemption(ex)}
                                className="p-1 text-red-600 hover:bg-red-500/10 rounded" aria-label="Elutasít">
                                <XIcon className="size-4" />
                              </button>
                            </div>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </section>
          </>
        )}
      </div>
  );
}
