import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Loader2, Shield, Plus, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { usePermissions } from "@/hooks/use-permissions";
import { toast } from "sonner";
import { humanizeError } from "@/lib/humanize-error";
import { useTranslation } from "react-i18next";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/admin/munkaido-szabalyok")({
  component: WorkTimeAdminPage,
});

type Rule = {
  id: string;
  jogviszony_tipus: string;
  fenntarto_tipus: string;
  napi_max_ora: number;
  napi_max_ora_ugyelettel: number;
  heti_max_ora: number;
  heti_max_ora_egeszsegugyi: number;
  heti_max_ora_ovt: number;
  napi_pihenes_min_ora: number;
  heti_egybefuggo_piheno_ora: number;
  havi_ugyelet_keszenlet_max: number;
  havi_keszenlet_max: number;
  eves_rendkivuli_max: number;
  eves_ugyelet_rendkivuli_max: number;
  eves_ovt_rendkivuli_max: number;
  ervenyes_tol: string;
  ugyelet_utan_piheno_nap: boolean;
  ugyelet_munkaidokeret_terhere: boolean;
  munkaszuneti_utan_szabadnap_fizetett: boolean;
  ejszakai_potlek_szazalek: number;
  vasarnapi_potlek_szazalek: number;
  unnepnapi_potlek_szazalek: number;
  ugyeleti_dij_szazalek: number;
  keszenleti_dij_szazalek: number;
  munkaidokeret_honap: number;
  jogszabaly_hivatkozas: string | null;
};

type WageCode = {
  id: string;
  kod: string;
  nev: string;
  alap_szorzo: number;
  kategoria: string | null;
  leiras: string | null;
  ervenyes: boolean;
};

type Mapping = {
  id: string;
  kategoria: string;
  sav: string;
  wage_code_id: string;
  felulirat_szorzo: number | null;
  prioritas: number;
  ervenyes_tol: string;
  ervenyes_ig: string | null;
};

type Holiday = {
  id: string;
  datum: string;
  nev: string;
  fizetett: boolean;
  forrasszoveg: string | null;
  tenant_id: string | null;
};

type CustomRule = {
  id: string;
  nev: string;
  szabaly_tipus: string;
  konfiguracio: Record<string, unknown>;
  jogszabaly_hivatkozas: string | null;
  prioritas: number;
  aktiv: boolean;
  ervenyes_tol: string;
  ervenyes_ig: string | null;
  jogviszony_tipus: string | null;
  fenntarto_tipus: string | null;
};

type WageTableRow = {
  id: string;
  tenant_id: string | null;
  besorolasi_kategoria: string;
  fizetesi_fokozat: number;
  munkakor_megnevezes: string | null;
  alapilletmeny_ft: number;
  garantalt_illetmeny_ft: number | null;
  potlek_alap_ft: number | null;
  ervenyes_tol: string;
  ervenyes_ig: string | null;
  jogszabaly_hivatkozas: string | null;
};

const JOGVISZONY_OPTS = [
  "kjt_kozalkalmazott",
  "egeszsegugyi_szolgalati",
  "munka_tv_kv",
  "megbizasi",
  "egyeni_vallalkozo",
  "tarsas_vallalkozo",
  "kozalkalmazotti_tovabbi",
  "rezidens_kepzes",
  "oszintszerzodes",
  "egyeb",
];
const FENNTARTO_OPTS = [
  "allami",
  "onkormanyzati",
  "egyhazi",
  "egyetemi_klinika",
  "maganszektor",
  "egyeb",
];
const CUSTOM_RULE_TYPES: Array<{ value: string; label: string; defaultConfig: Record<string, unknown> }> = [
  { value: "ugyelet_utan_piheno", label: "Ügyelet utáni pihenőnap", defaultConfig: { piheno_ora: 24, fizetett: true } },
  { value: "min_piheno_muszakok_kozott", label: "Min. pihenőidő műszakok között", defaultConfig: { min_ora: 11 } },
  { value: "unnep_auto_felar", label: "Ünnepnap auto-felár", defaultConfig: { felar_szazalek: 100 } },
  { value: "max_havi_potlek_ora", label: "Havi max. pótlék óra", defaultConfig: { max_ora: 50 } },
  { value: "max_heti_ugyelet", label: "Heti max. ügyelet", defaultConfig: { max_ora: 24 } },
  { value: "kotelezo_ebed_szunet", label: "Kötelező ebédszünet", defaultConfig: { min_perc: 20, muszak_ora_felett: 6 } },
  { value: "eltolt_muszak_korlat", label: "Eltolt műszak korlát", defaultConfig: { max_eltolas_ora: 4 } },
  { value: "egyedi", label: "Egyedi szabály", defaultConfig: {} },
];

const TABS = [
  { key: "rules", label: "Munkaidő-szabályok" },
  { key: "custom", label: "Egyedi szabályok" },
  { key: "codes", label: "Díjkódok" },
  { key: "mapping", label: "Díjkód-leképezés" },
  { key: "wagetable", label: "Eü. bértábla (2020. C tv.)" },
  { key: "holidays", label: "Munkaszüneti napok" },
] as const;

function WorkTimeAdminPage() {
  const perms = usePermissions();
  const [tab, setTab] = useState<(typeof TABS)[number]["key"]>("rules");

  const canManage = perms.can("manage_tenant") || perms.can("manage_worktime");
  if (!canManage) {
    return (
      <div className="p-6 text-sm text-muted-foreground">
        Munkaidő-adminisztráció: tenant-admin vagy <code>manage_worktime</code> jogosultság szükséges.
      </div>
    );
  }

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-4">
      <header>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Shield className="h-6 w-6" /> Munkaidő-adminisztráció
        </h1>
        <p className="text-sm text-muted-foreground">
          Szabályok, egyedi szabályok, díjkódok, leképezés, egészségügyi bértábla és munkaszüneti napok karbantartása. Minden módosítás auditálódik.
        </p>
      </header>
      <div className="flex gap-1 border-b flex-wrap">
        {TABS.map((tb) => (
          <button
            key={tb.key}
            onClick={() => setTab(tb.key)}
            className={cn(
              "px-4 py-2 text-sm font-semibold border-b-2 -mb-px transition-colors",
              tab === tb.key
                ? "border-primary text-foreground"
                : "border-transparent text-muted-foreground hover:text-foreground",
            )}
          >
            {tb.label}
          </button>
        ))}
      </div>
      {tab === "rules" && <RulesTab />}
      {tab === "custom" && <CustomRulesTab />}
      {tab === "codes" && <CodesTab />}
      {tab === "mapping" && <MappingTab />}
      {tab === "wagetable" && <WageTableTab />}
      {tab === "holidays" && <HolidaysTab />}
    </div>
  );
}

// =================================================================
// 1. Work-time rules — CRUD (új sor + új oszlopok)
// =================================================================
function RulesTab() {
  const { t } = useTranslation();
  const [rows, setRows] = useState<Rule[]>([]);
  const [loading, setLoading] = useState(true);
  const [showNew, setShowNew] = useState(false);
  const [draft, setDraft] = useState({
    jogviszony_tipus: "egeszsegugyi_szolgalati",
    fenntarto_tipus: "allami",
    napi_max_ora: 12,
    napi_max_ora_ugyelettel: 24,
    heti_max_ora: 40,
    heti_max_ora_egeszsegugyi: 48,
    heti_max_ora_ovt: 60,
    napi_pihenes_min_ora: 11,
    heti_egybefuggo_piheno_ora: 48,
    havi_ugyelet_keszenlet_max: 80,
    havi_keszenlet_max: 168,
    eves_rendkivuli_max: 250,
    eves_ugyelet_rendkivuli_max: 416,
    eves_ovt_rendkivuli_max: 416,
    munkaidokeret_honap: 1,
    ejszakai_potlek_szazalek: 15,
    vasarnapi_potlek_szazalek: 50,
    unnepnapi_potlek_szazalek: 100,
    ugyeleti_dij_szazalek: 50,
    keszenleti_dij_szazalek: 25,
    ugyelet_utan_piheno_nap: true,
    ugyelet_munkaidokeret_terhere: false,
    munkaszuneti_utan_szabadnap_fizetett: true,
    jogszabaly_hivatkozas: "2020. évi C. tv. 14. §",
  });

  useEffect(() => {
    void load();
  }, []);

  async function load() {
    setLoading(true);
    const { data, error } = await supabase
      .from("work_time_rules")
      .select("*")
      .order("jogviszony_tipus")
      .order("fenntarto_tipus");
    setLoading(false);
    if (error) toast.error(humanizeError(error, t));
    else setRows((data ?? []) as unknown as Rule[]);
  }

  async function updateField(id: string, key: string, value: unknown) {
    const { error } = await (supabase.from("work_time_rules") as any)
      .update({ [key]: value })
      .eq("id", id);
    if (error) toast.error(humanizeError(error, t));
    else toast.success("Mentve");
  }

  async function addRow() {
    // === Bemeneti validáció (negatív érték, irreális órasáv) ===
    const errs: string[] = [];
    if (draft.napi_max_ora <= 0 || draft.napi_max_ora > 24)
      errs.push("Napi max. óra 0 és 24 között lehet.");
    if (draft.napi_max_ora_ugyelettel < draft.napi_max_ora || draft.napi_max_ora_ugyelettel > 24)
      errs.push("Napi max. ügyelettel ≥ napi max. és ≤ 24.");
    if (draft.heti_max_ora <= 0 || draft.heti_max_ora > 168)
      errs.push("Heti max. óra 0 és 168 között lehet.");
    if (draft.heti_max_ora_ovt < draft.heti_max_ora || draft.heti_max_ora_ovt > 168)
      errs.push("Heti max. ÖVT ≥ heti max. és ≤ 168.");
    if (draft.napi_pihenes_min_ora < 0 || draft.napi_pihenes_min_ora > 24)
      errs.push("Napi pihenőidő 0–24 óra között.");
    if (draft.munkaidokeret_honap < 1 || draft.munkaidokeret_honap > 12)
      errs.push("Munkaidőkeret hossza 1–12 hónap.");
    for (const [k, v] of [
      ["ejszakai_potlek_szazalek", draft.ejszakai_potlek_szazalek],
      ["vasarnapi_potlek_szazalek", draft.vasarnapi_potlek_szazalek],
      ["unnepnapi_potlek_szazalek", draft.unnepnapi_potlek_szazalek],
      ["ugyeleti_dij_szazalek", draft.ugyeleti_dij_szazalek],
    ] as const) {
      if (v < 0 || v > 500) errs.push(`${k}: 0–500% közötti érték.`);
    }
    if (errs.length) return toast.error("Érvénytelen szabály", { description: errs.join(" · ") });

    const { data: tenantRow } = await supabase.rpc("current_tenant_id" as any);
    const { error } = await (supabase.from("work_time_rules") as any).insert({
      ...draft,
      tenant_id: tenantRow as any,
      ervenyes_tol: new Date().toISOString().slice(0, 10),
    });
    if (error) return toast.error(humanizeError(error, t));
    toast.success("Új szabály-sor felvéve");
    setShowNew(false);
    void load();
  }

  async function delRow(id: string) {
    if (!confirm("Törlöd a szabály-sort?")) return;
    const { error } = await supabase.from("work_time_rules").delete().eq("id", id);
    if (error) toast.error(humanizeError(error, t));
    else setRows(rows.filter((r) => r.id !== id));
  }

  if (loading) return <Loader2 className="h-5 w-5 animate-spin" />;
  return (
    <div className="space-y-3">
      <div className="flex justify-between items-center">
        <p className="text-xs text-muted-foreground">
          A szabály-sorok jogviszony × fenntartó kombinációra érvényesek. 2020. évi C. tv. és Mt. paraméterek tárolása.
        </p>
        <button
          onClick={() => setShowNew(!showNew)}
          className="px-3 py-1.5 rounded bg-primary text-primary-foreground text-xs font-semibold inline-flex items-center gap-1"
        >
          <Plus className="size-3" /> Új sor
        </button>
      </div>

      {showNew && (
        <div className="border rounded p-3 bg-card space-y-2">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            <Field label="Jogviszony">
              <select
                value={draft.jogviszony_tipus}
                onChange={(e) => setDraft({ ...draft, jogviszony_tipus: e.target.value })}
                className="w-full px-2 py-1.5 border rounded bg-background text-sm"
              >
                {JOGVISZONY_OPTS.map((o) => <option key={o} value={o}>{o}</option>)}
              </select>
            </Field>
            <Field label="Fenntartó">
              <select
                value={draft.fenntarto_tipus}
                onChange={(e) => setDraft({ ...draft, fenntarto_tipus: e.target.value })}
                className="w-full px-2 py-1.5 border rounded bg-background text-sm"
              >
                {FENNTARTO_OPTS.map((o) => <option key={o} value={o}>{o}</option>)}
              </select>
            </Field>
            <NumField label="Napi max." v={draft.napi_max_ora} min={0} max={24} warnAbove={16} onChange={(v) => setDraft({ ...draft, napi_max_ora: v })} />
            <NumField label="Napi max. ügy." v={draft.napi_max_ora_ugyelettel} min={0} max={24} onChange={(v) => setDraft({ ...draft, napi_max_ora_ugyelettel: v })} />
            <NumField label="Heti max." v={draft.heti_max_ora} min={0} max={168} warnAbove={60} onChange={(v) => setDraft({ ...draft, heti_max_ora: v })} />
            <NumField label="Heti max. ÖVT" v={draft.heti_max_ora_ovt} min={0} max={168} warnAbove={72} onChange={(v) => setDraft({ ...draft, heti_max_ora_ovt: v })} />
            <NumField label="Pihenő (min ó)" v={draft.napi_pihenes_min_ora} min={0} max={24} onChange={(v) => setDraft({ ...draft, napi_pihenes_min_ora: v })} />
            <NumField label="Mukidő keret (hó)" v={draft.munkaidokeret_honap} min={1} max={12} onChange={(v) => setDraft({ ...draft, munkaidokeret_honap: v })} step={1} />
            <NumField label="Éjszakai %" v={draft.ejszakai_potlek_szazalek} min={0} max={500} warnAbove={100} onChange={(v) => setDraft({ ...draft, ejszakai_potlek_szazalek: v })} />
            <NumField label="Vasárnap %" v={draft.vasarnapi_potlek_szazalek} min={0} max={500} warnAbove={100} onChange={(v) => setDraft({ ...draft, vasarnapi_potlek_szazalek: v })} />
            <NumField label="Ünnepnap %" v={draft.unnepnapi_potlek_szazalek} min={0} max={500} warnAbove={200} onChange={(v) => setDraft({ ...draft, unnepnapi_potlek_szazalek: v })} />
            <NumField label="Ügyeleti díj %" v={draft.ugyeleti_dij_szazalek} min={0} max={500} warnAbove={100} onChange={(v) => setDraft({ ...draft, ugyeleti_dij_szazalek: v })} />
          </div>
          <div className="flex flex-wrap gap-3 text-xs">
            <label className="flex items-center gap-1.5">
              <input type="checkbox" checked={draft.ugyelet_utan_piheno_nap} onChange={(e) => setDraft({ ...draft, ugyelet_utan_piheno_nap: e.target.checked })} />
              Ügyelet után pihenőnap kötelező
            </label>
            <label className="flex items-center gap-1.5">
              <input type="checkbox" checked={draft.ugyelet_munkaidokeret_terhere} onChange={(e) => setDraft({ ...draft, ugyelet_munkaidokeret_terhere: e.target.checked })} />
              Ügyelet munkaidőkeret terhére
            </label>
            <label className="flex items-center gap-1.5">
              <input type="checkbox" checked={draft.munkaszuneti_utan_szabadnap_fizetett} onChange={(e) => setDraft({ ...draft, munkaszuneti_utan_szabadnap_fizetett: e.target.checked })} />
              Munkaszüneti nap után fizetett szabadnap
            </label>
          </div>
          <Field label="Jogszabály-hivatkozás">
            <input
              value={draft.jogszabaly_hivatkozas}
              onChange={(e) => setDraft({ ...draft, jogszabaly_hivatkozas: e.target.value })}
              className="w-full px-2 py-1.5 border rounded bg-background text-sm"
            />
          </Field>
          <div className="flex gap-2">
            <button onClick={addRow} className="px-3 py-1.5 rounded bg-primary text-primary-foreground text-xs font-semibold">
              Mentés
            </button>
            <button onClick={() => setShowNew(false)} className="px-3 py-1.5 rounded border text-xs">
              Mégse
            </button>
          </div>
        </div>
      )}

      <div className="overflow-x-auto border rounded-lg">
        <table className="w-full text-xs">
          <thead className="bg-muted/40">
            <tr className="text-left">
              <th className="p-2">Jogv.</th>
              <th>Fenntartó</th>
              <th>Napi</th>
              <th>N+ügy.</th>
              <th>Heti</th>
              <th>Heti(ÖVT)</th>
              <th>Pih.</th>
              <th>Kerét hó</th>
              <th>Éj %</th>
              <th>Vas %</th>
              <th>Ünn %</th>
              <th>Ügy. díj %</th>
              <th>Ügy+pih</th>
              <th>Kerét-terh</th>
              <th>Mtsz fiz</th>
              <th>Jogszab.</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="border-t">
                <td className="p-2 font-mono">{r.jogviszony_tipus}</td>
                <td>{r.fenntarto_tipus}</td>
                <NumCell v={r.napi_max_ora} min={0} max={24} warnAbove={16} onSave={(v) => updateField(r.id, "napi_max_ora", v)} />
                <NumCell v={r.napi_max_ora_ugyelettel} min={0} max={24} onSave={(v) => updateField(r.id, "napi_max_ora_ugyelettel", v)} />
                <NumCell v={r.heti_max_ora} min={0} max={168} warnAbove={60} onSave={(v) => updateField(r.id, "heti_max_ora", v)} />
                <NumCell v={r.heti_max_ora_ovt} min={0} max={168} warnAbove={72} onSave={(v) => updateField(r.id, "heti_max_ora_ovt", v)} />
                <NumCell v={r.napi_pihenes_min_ora} min={0} max={24} onSave={(v) => updateField(r.id, "napi_pihenes_min_ora", v)} />
                <NumCell v={r.munkaidokeret_honap} min={1} max={12} step={1} onSave={(v) => updateField(r.id, "munkaidokeret_honap", v)} />
                <NumCell v={r.ejszakai_potlek_szazalek} min={0} max={500} warnAbove={100} onSave={(v) => updateField(r.id, "ejszakai_potlek_szazalek", v)} />
                <NumCell v={r.vasarnapi_potlek_szazalek} min={0} max={500} warnAbove={100} onSave={(v) => updateField(r.id, "vasarnapi_potlek_szazalek", v)} />
                <NumCell v={r.unnepnapi_potlek_szazalek} min={0} max={500} warnAbove={200} onSave={(v) => updateField(r.id, "unnepnapi_potlek_szazalek", v)} />
                <NumCell v={r.ugyeleti_dij_szazalek} min={0} max={500} warnAbove={100} onSave={(v) => updateField(r.id, "ugyeleti_dij_szazalek", v)} />
                <td className="text-center"><input type="checkbox" checked={r.ugyelet_utan_piheno_nap} onChange={(e) => updateField(r.id, "ugyelet_utan_piheno_nap", e.target.checked)} /></td>
                <td className="text-center"><input type="checkbox" checked={r.ugyelet_munkaidokeret_terhere} onChange={(e) => updateField(r.id, "ugyelet_munkaidokeret_terhere", e.target.checked)} /></td>
                <td className="text-center"><input type="checkbox" checked={r.munkaszuneti_utan_szabadnap_fizetett} onChange={(e) => updateField(r.id, "munkaszuneti_utan_szabadnap_fizetett", e.target.checked)} /></td>
                <td>
                  <input
                    defaultValue={r.jogszabaly_hivatkozas ?? ""}
                    onBlur={(e) => e.target.value !== (r.jogszabaly_hivatkozas ?? "") && updateField(r.id, "jogszabaly_hivatkozas", e.target.value || null)}
                    className="w-32 px-1 py-0.5 border rounded bg-background text-xs"
                  />
                </td>
                <td>
                  <button onClick={() => delRow(r.id)} className="p-1 text-destructive hover:bg-secondary rounded">
                    <Trash2 className="size-3.5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// =================================================================
// 2. Egyedi szabályok (work_time_custom_rules)
// =================================================================
function CustomRulesTab() {
  const { t } = useTranslation();
  const [rows, setRows] = useState<CustomRule[]>([]);
  const [loading, setLoading] = useState(true);
  const [tipus, setTipus] = useState("ugyelet_utan_piheno");
  const [nev, setNev] = useState("");
  const [konfigJson, setKonfigJson] = useState(JSON.stringify({ piheno_ora: 24 }, null, 2));
  const [jogszab, setJogszab] = useState("");
  const [prioritas, setPrioritas] = useState(100);
  const [jogviszony, setJogviszony] = useState("");
  const [fenntarto, setFenntarto] = useState("");

  useEffect(() => {
    void load();
  }, []);
  async function load() {
    setLoading(true);
    const { data, error } = await (supabase.from("work_time_custom_rules") as any)
      .select("*")
      .order("prioritas")
      .order("nev");
    setLoading(false);
    if (error) toast.error(humanizeError(error, t));
    else setRows((data ?? []) as CustomRule[]);
  }

  function onTypeChange(v: string) {
    setTipus(v);
    const def = CUSTOM_RULE_TYPES.find((c) => c.value === v);
    if (def) setKonfigJson(JSON.stringify(def.defaultConfig, null, 2));
  }

  async function add() {
    if (!nev.trim()) return toast.error("Név kötelező");
    let konfig: unknown = {};
    try {
      konfig = JSON.parse(konfigJson);
    } catch {
      return toast.error("A konfiguráció érvényes JSON kell legyen");
    }
    const { data: tenantRow } = await supabase.rpc("current_tenant_id" as any);
    const { data: u } = await supabase.auth.getUser();
    const { data, error } = await (supabase.from("work_time_custom_rules") as any)
      .insert({
        tenant_id: tenantRow as any,
        nev: nev.trim(),
        szabaly_tipus: tipus,
        konfiguracio: konfig,
        jogszabaly_hivatkozas: jogszab.trim() || null,
        prioritas,
        jogviszony_tipus: jogviszony || null,
        fenntarto_tipus: fenntarto || null,
        created_by: u?.user?.id ?? null,
      })
      .select()
      .single();
    if (error) return toast.error(humanizeError(error, t));
    setRows([...rows, data as CustomRule].sort((a, b) => a.prioritas - b.prioritas));
    setNev("");
    setJogszab("");
    toast.success("Egyedi szabály létrehozva");
  }

  async function toggleAktiv(r: CustomRule) {
    const { error } = await (supabase.from("work_time_custom_rules") as any)
      .update({ aktiv: !r.aktiv })
      .eq("id", r.id);
    if (error) toast.error(humanizeError(error, t));
    else setRows(rows.map((x) => (x.id === r.id ? { ...x, aktiv: !x.aktiv } : x)));
  }

  async function del(id: string) {
    if (!confirm("Törlöd?")) return;
    const { error } = await supabase.from("work_time_custom_rules" as any).delete().eq("id", id);
    if (error) toast.error(humanizeError(error, t));
    else setRows(rows.filter((r) => r.id !== id));
  }

  if (loading) return <Loader2 className="h-5 w-5 animate-spin" />;
  return (
    <div className="space-y-3">
      <div className="border rounded p-3 bg-card space-y-2">
        <h3 className="text-sm font-semibold">Új egyedi szabály</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          <Field label="Név">
            <input value={nev} onChange={(e) => setNev(e.target.value)} className="w-full px-2 py-1.5 border rounded bg-background text-sm" />
          </Field>
          <Field label="Szabály-típus">
            <select value={tipus} onChange={(e) => onTypeChange(e.target.value)} className="w-full px-2 py-1.5 border rounded bg-background text-sm">
              {CUSTOM_RULE_TYPES.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}
            </select>
          </Field>
          <Field label="Jogviszony (opcionális)">
            <select value={jogviszony} onChange={(e) => setJogviszony(e.target.value)} className="w-full px-2 py-1.5 border rounded bg-background text-sm">
              <option value="">— összes —</option>
              {JOGVISZONY_OPTS.map((o) => <option key={o} value={o}>{o}</option>)}
            </select>
          </Field>
          <Field label="Fenntartó (opcionális)">
            <select value={fenntarto} onChange={(e) => setFenntarto(e.target.value)} className="w-full px-2 py-1.5 border rounded bg-background text-sm">
              <option value="">— összes —</option>
              {FENNTARTO_OPTS.map((o) => <option key={o} value={o}>{o}</option>)}
            </select>
          </Field>
          <Field label="Prioritás">
            <input type="number" value={prioritas} onChange={(e) => setPrioritas(Number(e.target.value))} className="w-full px-2 py-1.5 border rounded bg-background text-sm" />
          </Field>
          <Field label="Jogszabály-hivatkozás">
            <input value={jogszab} onChange={(e) => setJogszab(e.target.value)} placeholder="pl. 2020. évi C. tv. 14. §" className="w-full px-2 py-1.5 border rounded bg-background text-sm" />
          </Field>
        </div>
        <Field label="Konfiguráció (JSON)">
          <textarea
            rows={5}
            value={konfigJson}
            onChange={(e) => setKonfigJson(e.target.value)}
            className="w-full px-2 py-1.5 border rounded bg-background text-xs font-mono"
          />
        </Field>
        <button onClick={add} className="px-3 py-1.5 rounded bg-primary text-primary-foreground text-xs font-semibold inline-flex items-center gap-1">
          <Plus className="size-3" /> Hozzáadás
        </button>
      </div>

      <div className="overflow-x-auto border rounded">
        <table className="w-full text-sm">
          <thead className="bg-muted/40 text-xs uppercase text-muted-foreground">
            <tr>
              <th className="p-2 text-left">Név</th>
              <th className="text-left">Típus</th>
              <th>Prio</th>
              <th>Aktív</th>
              <th className="text-left">Konfig</th>
              <th>Jogszabály</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="border-t align-top">
                <td className="p-2 font-medium">{r.nev}</td>
                <td className="font-mono text-xs">{r.szabaly_tipus}</td>
                <td className="text-center">{r.prioritas}</td>
                <td className="text-center">
                  <input type="checkbox" checked={r.aktiv} onChange={() => toggleAktiv(r)} />
                </td>
                <td className="text-xs font-mono max-w-[260px] truncate" title={JSON.stringify(r.konfiguracio)}>
                  {JSON.stringify(r.konfiguracio)}
                </td>
                <td className="text-xs">{r.jogszabaly_hivatkozas ?? "—"}</td>
                <td><button onClick={() => del(r.id)} className="p-1 text-destructive hover:bg-secondary rounded"><Trash2 className="size-3.5" /></button></td>
              </tr>
            ))}
            {rows.length === 0 && (
              <tr><td colSpan={7} className="p-4 text-center text-muted-foreground text-sm">Még nincs egyedi szabály.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// =================================================================
// 3. Wage codes
// =================================================================
function CodesTab() {
  const { t } = useTranslation();
  const [rows, setRows] = useState<WageCode[]>([]);
  const [loading, setLoading] = useState(true);
  const [kod, setKod] = useState("");
  const [nev, setNev] = useState("");
  const [szorzo, setSzorzo] = useState("1.000");

  useEffect(() => {
    void load();
  }, []);
  async function load() {
    setLoading(true);
    const { data, error } = await supabase.from("wage_codes").select("*").order("kod");
    setLoading(false);
    if (error) toast.error(humanizeError(error, t));
    else setRows((data ?? []) as WageCode[]);
  }
  async function add() {
    if (!kod.trim() || !nev.trim()) return toast.error("Kód és név kötelező");
    const szorzoNum = Number(szorzo);
    if (!Number.isFinite(szorzoNum) || szorzoNum < 0) {
      return toast.error("Az alap szorzó nem lehet negatív vagy érvénytelen.");
    }
    if (szorzoNum > 10) {
      return toast.error("Az alap szorzó nem lehet 10-nél nagyobb (irreális érték).");
    }
    const { data: tenantRow } = await supabase.rpc("current_tenant_id" as any);
    const { data, error } = await supabase
      .from("wage_codes")
      .insert({ kod: kod.trim(), nev: nev.trim(), alap_szorzo: szorzoNum, tenant_id: tenantRow as any })
      .select()
      .single();
    if (error) return toast.error(humanizeError(error, t));
    setRows([...rows, data as WageCode].sort((a, b) => a.kod.localeCompare(b.kod)));
    setKod("");
    setNev("");
    setSzorzo("1.000");
    toast.success("Hozzáadva");
  }
  async function update(id: string, patch: Partial<WageCode>) {
    const { error } = await (supabase.from("wage_codes") as any).update(patch).eq("id", id);
    if (error) toast.error(humanizeError(error, t));
    else toast.success("Mentve");
  }
  async function del(id: string) {
    if (!confirm("Biztosan törlöd?")) return;
    const { error } = await supabase.from("wage_codes").delete().eq("id", id);
    if (error) toast.error(humanizeError(error, t));
    else setRows(rows.filter((r) => r.id !== id));
  }

  if (loading) return <Loader2 className="h-5 w-5 animate-spin" />;
  return (
    <div className="space-y-3">
      <div className="border rounded p-3 flex flex-wrap gap-2 items-end bg-card">
        <label className="text-xs"><span className="block text-muted-foreground mb-1">Kód</span>
          <input value={kod} onChange={(e) => setKod(e.target.value)} className="px-2 py-1.5 border rounded bg-background text-sm w-32" />
        </label>
        <label className="text-xs flex-1 min-w-[200px]"><span className="block text-muted-foreground mb-1">Megnevezés</span>
          <input value={nev} onChange={(e) => setNev(e.target.value)} className="w-full px-2 py-1.5 border rounded bg-background text-sm" />
        </label>
        <label className="text-xs"><span className="block text-muted-foreground mb-1">Alap szorzó</span>
          <input type="number" step="0.001" value={szorzo} onChange={(e) => setSzorzo(e.target.value)} className="px-2 py-1.5 border rounded bg-background text-sm w-24" />
        </label>
        <button onClick={add} className="px-3 py-1.5 rounded bg-primary text-primary-foreground text-xs font-semibold inline-flex items-center gap-1"><Plus className="size-3" /> Új</button>
      </div>
      <div className="overflow-x-auto border rounded">
        <table className="w-full text-sm">
          <thead className="bg-muted/40 text-xs uppercase text-muted-foreground">
            <tr><th className="p-2 text-left">Kód</th><th className="text-left">Név</th><th>Szorzó</th><th>Érvényes</th><th></th></tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="border-t">
                <td className="p-2 font-mono">{r.kod}</td>
                <td><EditText v={r.nev} onSave={(v) => update(r.id, { nev: v })} /></td>
                <td className="text-center"><NumCell v={r.alap_szorzo} step={0.001} min={0} max={10} warnAbove={3} onSave={(v) => update(r.id, { alap_szorzo: v })} /></td>
                <td className="text-center">
                  <input type="checkbox" checked={r.ervenyes} onChange={(e) => update(r.id, { ervenyes: e.target.checked })} />
                </td>
                <td><button onClick={() => del(r.id)} className="p-1 text-destructive hover:bg-secondary rounded"><Trash2 className="size-3.5" /></button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// =================================================================
// 4. Wage mapping
// =================================================================
const KATEGORIAK = ["rendes", "ugyelet", "keszenlet", "ovt", "rendkivuli", "kompenzalo"];
const SAVOK = ["nappal", "ejszaka", "vasarnap", "unnep"];

function MappingTab() {
  const { t } = useTranslation();
  const [rows, setRows] = useState<Mapping[]>([]);
  const [codes, setCodes] = useState<WageCode[]>([]);
  const [loading, setLoading] = useState(true);
  const [kat, setKat] = useState("rendes");
  const [sav, setSav] = useState("nappal");
  const [codeId, setCodeId] = useState("");
  const [felul, setFelul] = useState("");

  useEffect(() => { void load(); }, []);
  async function load() {
    setLoading(true);
    const [r, c] = await Promise.all([
      supabase.from("wage_mapping").select("*").order("kategoria").order("sav"),
      supabase.from("wage_codes").select("*").eq("ervenyes", true).order("kod"),
    ]);
    setLoading(false);
    if (r.error) toast.error(humanizeError(r.error, t));
    else setRows((r.data ?? []) as Mapping[]);
    if (!c.error) setCodes((c.data ?? []) as WageCode[]);
  }
  async function add() {
    if (!codeId) return toast.error("Válassz díjkódot");
    const { data: tenantRow } = await supabase.rpc("current_tenant_id" as any);
    const { data, error } = await supabase
      .from("wage_mapping")
      .insert({
        kategoria: kat as any,
        sav,
        wage_code_id: codeId,
        felulirat_szorzo: felul ? Number(felul) : null,
        ervenyes_tol: new Date().toISOString().slice(0, 10),
        tenant_id: tenantRow as any,
      } as any)
      .select()
      .single();
    if (error) return toast.error(humanizeError(error, t));
    setRows([...rows, data as Mapping]);
    setFelul("");
    toast.success("Hozzáadva");
  }
  async function del(id: string) {
    if (!confirm("Törlöd?")) return;
    const { error } = await supabase.from("wage_mapping").delete().eq("id", id);
    if (error) toast.error(humanizeError(error, t));
    else setRows(rows.filter((r) => r.id !== id));
  }

  if (loading) return <Loader2 className="h-5 w-5 animate-spin" />;
  const codeMap = new Map(codes.map((c) => [c.id, c]));
  return (
    <div className="space-y-3">
      <div className="border rounded p-3 flex flex-wrap gap-2 items-end bg-card">
        <select value={kat} onChange={(e) => setKat(e.target.value)} className="px-2 py-1.5 border rounded bg-background text-sm">
          {KATEGORIAK.map((k) => <option key={k} value={k}>{k}</option>)}
        </select>
        <select value={sav} onChange={(e) => setSav(e.target.value)} className="px-2 py-1.5 border rounded bg-background text-sm">
          {SAVOK.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
        <select value={codeId} onChange={(e) => setCodeId(e.target.value)} className="px-2 py-1.5 border rounded bg-background text-sm flex-1 min-w-[200px]">
          <option value="">— Díjkód —</option>
          {codes.map((c) => <option key={c.id} value={c.id}>{c.kod} · {c.nev}</option>)}
        </select>
        <input type="number" step="0.001" placeholder="Felülírat szorzó" value={felul} onChange={(e) => setFelul(e.target.value)} className="px-2 py-1.5 border rounded bg-background text-sm w-32" />
        <button onClick={add} className="px-3 py-1.5 rounded bg-primary text-primary-foreground text-xs font-semibold inline-flex items-center gap-1"><Plus className="size-3" /> Új</button>
      </div>
      <div className="overflow-x-auto border rounded">
        <table className="w-full text-sm">
          <thead className="bg-muted/40 text-xs uppercase text-muted-foreground">
            <tr><th className="p-2 text-left">Kategória</th><th className="text-left">Sáv</th><th className="text-left">Díjkód</th><th>Felülírat</th><th>Érv. tól</th><th></th></tr>
          </thead>
          <tbody>
            {rows.map((r) => {
              const c = codeMap.get(r.wage_code_id);
              return (
                <tr key={r.id} className="border-t">
                  <td className="p-2 font-mono">{r.kategoria}</td>
                  <td>{r.sav}</td>
                  <td>{c ? `${c.kod} · ${c.nev}` : r.wage_code_id.slice(0, 8)}</td>
                  <td className="text-center">{r.felulirat_szorzo ?? "—"}</td>
                  <td className="text-center">{r.ervenyes_tol}</td>
                  <td><button onClick={() => del(r.id)} className="p-1 text-destructive hover:bg-secondary rounded"><Trash2 className="size-3.5" /></button></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// =================================================================
// 5. Eü. bértábla (2020. évi C. tv.)
// =================================================================
function WageTableTab() {
  const { t } = useTranslation();
  const [rows, setRows] = useState<WageTableRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [draft, setDraft] = useState({
    besorolasi_kategoria: "C",
    fizetesi_fokozat: 1,
    munkakor_megnevezes: "szakorvos",
    alapilletmeny_ft: 0,
    garantalt_illetmeny_ft: 0,
    potlek_alap_ft: 0,
    ervenyes_tol: new Date().toISOString().slice(0, 10),
    jogszabaly_hivatkozas: "2020. évi C. tv. 1. melléklet",
  });

  useEffect(() => { void load(); }, []);
  async function load() {
    setLoading(true);
    const { data, error } = await (supabase.from("wage_table_egeszsegugyi") as any)
      .select("*")
      .order("besorolasi_kategoria")
      .order("fizetesi_fokozat")
      .order("ervenyes_tol", { ascending: false });
    setLoading(false);
    if (error) toast.error(humanizeError(error, t));
    else setRows((data ?? []) as WageTableRow[]);
  }

  async function add() {
    if (draft.alapilletmeny_ft <= 0) return toast.error("Alapilletmény kötelező és pozitív.");
    if (draft.alapilletmeny_ft > 10_000_000) return toast.error("Az alapilletmény irreálisan magas (>10 M Ft).");
    if (draft.garantalt_illetmeny_ft < 0 || draft.potlek_alap_ft < 0)
      return toast.error("A garantált illetmény és pótlékalap nem lehet negatív.");
    if (draft.fizetesi_fokozat < 1 || draft.fizetesi_fokozat > 20)
      return toast.error("Fizetési fokozat 1–20 között.");
    const { data: tenantRow } = await supabase.rpc("current_tenant_id" as any);
    const { error } = await (supabase.from("wage_table_egeszsegugyi") as any).insert({
      ...draft,
      tenant_id: tenantRow as any,
      garantalt_illetmeny_ft: draft.garantalt_illetmeny_ft || null,
      potlek_alap_ft: draft.potlek_alap_ft || null,
    });
    if (error) return toast.error(humanizeError(error, t));
    toast.success("Bértábla-sor felvéve");
    void load();
  }

  async function del(id: string, tenantId: string | null) {
    if (tenantId === null) return toast.error("Globális (jogszabályi) sor nem törölhető — adj tenant-specifikus felülírást.");
    if (!confirm("Törlöd?")) return;
    const { error } = await supabase.from("wage_table_egeszsegugyi" as any).delete().eq("id", id);
    if (error) toast.error(humanizeError(error, t));
    else setRows(rows.filter((r) => r.id !== id));
  }

  if (loading) return <Loader2 className="h-5 w-5 animate-spin" />;
  return (
    <div className="space-y-3">
      <div className="border rounded p-3 bg-card space-y-2">
        <h3 className="text-sm font-semibold">Új bértábla-sor (2020. évi C. tv. — egészségügyi szolgálati jogviszony)</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          <Field label="Besorolási kat. (A–J)">
            <input value={draft.besorolasi_kategoria} onChange={(e) => setDraft({ ...draft, besorolasi_kategoria: e.target.value.toUpperCase().slice(0, 3) })} className="w-full px-2 py-1.5 border rounded bg-background text-sm" />
          </Field>
          <Field label="Fizetési fokozat">
            <input type="number" min={1} value={draft.fizetesi_fokozat} onChange={(e) => setDraft({ ...draft, fizetesi_fokozat: Number(e.target.value) })} className="w-full px-2 py-1.5 border rounded bg-background text-sm" />
          </Field>
          <Field label="Munkakör">
            <input value={draft.munkakor_megnevezes} onChange={(e) => setDraft({ ...draft, munkakor_megnevezes: e.target.value })} className="w-full px-2 py-1.5 border rounded bg-background text-sm" />
          </Field>
          <Field label="Érvényes tól">
            <input type="date" value={draft.ervenyes_tol} onChange={(e) => setDraft({ ...draft, ervenyes_tol: e.target.value })} className="w-full px-2 py-1.5 border rounded bg-background text-sm" />
          </Field>
          <Field label="Alapilletmény (Ft)">
            <input type="number" value={draft.alapilletmeny_ft} onChange={(e) => setDraft({ ...draft, alapilletmeny_ft: Number(e.target.value) })} className="w-full px-2 py-1.5 border rounded bg-background text-sm" />
          </Field>
          <Field label="Garantált illetm. (Ft)">
            <input type="number" value={draft.garantalt_illetmeny_ft} onChange={(e) => setDraft({ ...draft, garantalt_illetmeny_ft: Number(e.target.value) })} className="w-full px-2 py-1.5 border rounded bg-background text-sm" />
          </Field>
          <Field label="Pótlékalap (Ft)">
            <input type="number" value={draft.potlek_alap_ft} onChange={(e) => setDraft({ ...draft, potlek_alap_ft: Number(e.target.value) })} className="w-full px-2 py-1.5 border rounded bg-background text-sm" />
          </Field>
          <Field label="Jogszabály">
            <input value={draft.jogszabaly_hivatkozas} onChange={(e) => setDraft({ ...draft, jogszabaly_hivatkozas: e.target.value })} className="w-full px-2 py-1.5 border rounded bg-background text-sm" />
          </Field>
        </div>
        <button onClick={add} className="px-3 py-1.5 rounded bg-primary text-primary-foreground text-xs font-semibold inline-flex items-center gap-1">
          <Plus className="size-3" /> Hozzáadás
        </button>
      </div>

      <div className="overflow-x-auto border rounded">
        <table className="w-full text-sm">
          <thead className="bg-muted/40 text-xs uppercase text-muted-foreground">
            <tr>
              <th className="p-2 text-left">Kat.</th>
              <th>Fok.</th>
              <th className="text-left">Munkakör</th>
              <th className="text-right">Alapilletmény</th>
              <th className="text-right">Garantált</th>
              <th className="text-right">Pótlékalap</th>
              <th>Érv. tól</th>
              <th>Hatókör</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="border-t">
                <td className="p-2 font-mono">{r.besorolasi_kategoria}</td>
                <td className="text-center">{r.fizetesi_fokozat}</td>
                <td>{r.munkakor_megnevezes ?? "—"}</td>
                <td className="text-right tabular-nums">{r.alapilletmeny_ft.toLocaleString("hu")}</td>
                <td className="text-right tabular-nums">{r.garantalt_illetmeny_ft?.toLocaleString("hu") ?? "—"}</td>
                <td className="text-right tabular-nums">{r.potlek_alap_ft?.toLocaleString("hu") ?? "—"}</td>
                <td className="text-center">{r.ervenyes_tol}</td>
                <td className="text-center text-xs">{r.tenant_id === null ? "globális" : "tenant"}</td>
                <td>
                  <button onClick={() => del(r.id, r.tenant_id)} disabled={r.tenant_id === null} className="p-1 text-destructive hover:bg-secondary rounded disabled:opacity-30">
                    <Trash2 className="size-3.5" />
                  </button>
                </td>
              </tr>
            ))}
            {rows.length === 0 && (
              <tr><td colSpan={9} className="p-4 text-center text-muted-foreground text-sm">Még nincs bértábla-sor.</td></tr>
            )}
          </tbody>
        </table>
      </div>
      <p className="text-xs text-muted-foreground">
        A 2020. évi C. törvény (Eüsztv.) bértáblája besorolási kategóriák (A–J) és fizetési fokozatok szerint. Globális sorok minden tenant számára láthatók, tenant-specifikus felülírás új sorral lehetséges.
      </p>
    </div>
  );
}

// =================================================================
// 6. Public holidays
// =================================================================
function HolidaysTab() {
  const { t } = useTranslation();
  const [rows, setRows] = useState<Holiday[]>([]);
  const [loading, setLoading] = useState(true);
  const [year, setYear] = useState(new Date().getFullYear());
  const [datum, setDatum] = useState("");
  const [nev, setNev] = useState("");
  const [fizetett, setFizetett] = useState(true);

  useEffect(() => { void load(); }, [year]);
  async function load() {
    setLoading(true);
    const { data, error } = await supabase
      .from("public_holidays")
      .select("*")
      .gte("datum", `${year}-01-01`)
      .lt("datum", `${year + 1}-01-01`)
      .order("datum");
    setLoading(false);
    if (error) toast.error(humanizeError(error, t));
    else setRows((data ?? []) as Holiday[]);
  }
  async function add() {
    if (!datum || !nev.trim()) return toast.error("Dátum és név kötelező");
    const { data: tenantRow } = await supabase.rpc("current_tenant_id" as any);
    const { data, error } = await supabase
      .from("public_holidays")
      .insert({ datum, nev: nev.trim(), fizetett, tenant_id: tenantRow as any })
      .select()
      .single();
    if (error) return toast.error(humanizeError(error, t));
    setRows([...rows, data as Holiday].sort((a, b) => a.datum.localeCompare(b.datum)));
    setDatum("");
    setNev("");
    toast.success("Hozzáadva (tenant-specifikus)");
  }
  async function del(id: string, tenantId: string | null) {
    if (tenantId === null) return toast.error("Globális (Mt.) napokat nem törölhetsz — csak felülírni lehet tenant-specifikus sorral.");
    if (!confirm("Törlöd?")) return;
    const { error } = await supabase.from("public_holidays").delete().eq("id", id);
    if (error) toast.error(humanizeError(error, t));
    else setRows(rows.filter((r) => r.id !== id));
  }

  if (loading) return <Loader2 className="h-5 w-5 animate-spin" />;
  return (
    <div className="space-y-3">
      <div className="flex items-center gap-3">
        <label className="text-xs">Év:
          <input type="number" value={year} onChange={(e) => setYear(Number(e.target.value))} className="ml-2 px-2 py-1 border rounded bg-background w-24" />
        </label>
      </div>
      <div className="border rounded p-3 flex flex-wrap gap-2 items-end bg-card">
        <input type="date" value={datum} onChange={(e) => setDatum(e.target.value)} className="px-2 py-1.5 border rounded bg-background text-sm" />
        <input value={nev} onChange={(e) => setNev(e.target.value)} placeholder="Megnevezés" className="px-2 py-1.5 border rounded bg-background text-sm flex-1 min-w-[200px]" />
        <label className="text-xs flex items-center gap-1">
          <input type="checkbox" checked={fizetett} onChange={(e) => setFizetett(e.target.checked)} />
          Fizetett
        </label>
        <button onClick={add} className="px-3 py-1.5 rounded bg-primary text-primary-foreground text-xs font-semibold inline-flex items-center gap-1"><Plus className="size-3" /> Új</button>
      </div>
      <div className="overflow-x-auto border rounded">
        <table className="w-full text-sm">
          <thead className="bg-muted/40 text-xs uppercase text-muted-foreground">
            <tr><th className="p-2 text-left">Dátum</th><th className="text-left">Megnevezés</th><th>Fizetett</th><th>Hatókör</th><th>Forrás</th><th></th></tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="border-t">
                <td className="p-2 font-mono">{r.datum}</td>
                <td>{r.nev}</td>
                <td className="text-center">{r.fizetett ? "✓" : "—"}</td>
                <td className="text-center text-xs">{r.tenant_id === null ? "globális" : "tenant"}</td>
                <td className="text-xs text-muted-foreground">{r.forrasszoveg ?? "—"}</td>
                <td>
                  <button onClick={() => del(r.id, r.tenant_id)} className="p-1 text-destructive hover:bg-secondary rounded disabled:opacity-30" disabled={r.tenant_id === null}>
                    <Trash2 className="size-3.5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="text-xs text-muted-foreground">
        Globális (Mt. szerinti) napok minden tenant számára megjelennek. Tenant-specifikus felülírás új sor felvételével lehetséges.
      </p>
    </div>
  );
}

// =================================================================
// Helpers
// =================================================================
function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="text-xs space-y-1 block">
      <span className="block text-muted-foreground">{label}</span>
      {children}
    </label>
  );
}

function NumField({
  label,
  v,
  onChange,
  step = 0.5,
  min = 0,
  max,
  warnAbove,
}: {
  label: string;
  v: number;
  onChange: (v: number) => void;
  step?: number;
  min?: number;
  max?: number;
  warnAbove?: number;
}) {
  const invalid =
    !Number.isFinite(v) || v < min || (max !== undefined && v > max);
  const warn = !invalid && warnAbove !== undefined && v > warnAbove;
  const title = invalid
    ? `Megengedett tartomány: ${min}${max !== undefined ? `–${max}` : "+"}`
    : warn
      ? `Szokatlanul magas érték (>${warnAbove}). Ellenőrizd.`
      : undefined;
  return (
    <Field label={label}>
      <input
        type="number"
        step={step}
        min={min}
        max={max}
        value={v}
        title={title}
        aria-invalid={invalid || undefined}
        onChange={(e) => onChange(Number(e.target.value))}
        className={cn(
          "w-full px-2 py-1.5 border rounded bg-background text-sm",
          invalid && "border-destructive focus-visible:ring-2 focus-visible:ring-destructive",
          !invalid && warn && "border-yellow-500",
        )}
      />
    </Field>
  );
}

function NumCell({
  v,
  step = 0.5,
  onSave,
  min = 0,
  max,
  warnAbove,
}: {
  v: number;
  step?: number;
  onSave: (v: number) => void;
  min?: number;
  max?: number;
  warnAbove?: number;
}) {
  const [val, setVal] = useState(v);
  useEffect(() => setVal(v), [v]);
  const invalid =
    !Number.isFinite(val) || val < min || (max !== undefined && val > max);
  const warn = !invalid && warnAbove !== undefined && val > warnAbove;
  const title = invalid
    ? `Megengedett: ${min}${max !== undefined ? `–${max}` : "+"}`
    : warn
      ? `Szokatlan érték (>${warnAbove})`
      : undefined;
  return (
    <td className="p-1">
      <input
        type="number"
        step={step}
        min={min}
        max={max}
        value={val}
        title={title}
        aria-invalid={invalid || undefined}
        onChange={(e) => setVal(Number(e.target.value))}
        onBlur={() => {
          if (invalid) {
            toast.error(`Érvénytelen érték: ${val} (tartomány: ${min}${max !== undefined ? `–${max}` : "+"})`);
            setVal(v);
            return;
          }
          if (val !== v) onSave(val);
        }}
        className={cn(
          "w-20 border rounded px-1 py-0.5 bg-background text-right text-xs",
          invalid && "border-destructive",
          !invalid && warn && "border-yellow-500",
        )}
      />
    </td>
  );
}

function EditText({ v, onSave }: { v: string; onSave: (v: string) => void }) {
  const [val, setVal] = useState(v);
  useEffect(() => setVal(v), [v]);
  return (
    <input
      value={val}
      onChange={(e) => setVal(e.target.value)}
      onBlur={() => val !== v && onSave(val)}
      className="w-full px-2 py-0.5 border rounded bg-background text-sm"
    />
  );
}
