import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CATEGORIES, SETTINGS, getSettingDef } from "@/lib/admin/settings-catalog";
import { listAllSettings, upsertSetting, resetSetting, exportSettings, importSettings } from "@/lib/admin/settings.functions";
import { suggestSettingsBatch } from "@/lib/admin/ai-settings.functions";
import { SettingField } from "@/components/admin/setting-field";
import { RouteErrorBoundary } from "@/lib/errors/route-boundaries";
import { Sparkles, Download, Upload, Search, Save, Loader2, Undo2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/admin/beallitasok")({
  component: BeallitasokPage,
  errorComponent: RouteErrorBoundary,
  head: () => ({ meta: [{ title: "Rendszerbeállítások – Admin Control Center" }] }),
});

function BeallitasokPage() {
  const qc = useQueryClient();
  const list = useServerFn(listAllSettings);
  const upsert = useServerFn(upsertSetting);
  const reset = useServerFn(resetSetting);
  const exportFn = useServerFn(exportSettings);
  const importFn = useServerFn(importSettings);
  const batch = useServerFn(suggestSettingsBatch);

  const { data: rows, isLoading } = useQuery({
    queryKey: ["admin", "all-settings"],
    queryFn: () => list(),
  });

  const [active, setActive] = useState<string>(CATEGORIES[0]?.id ?? "general");
  const [search, setSearch] = useState("");
  const [dirty, setDirty] = useState<Record<string, unknown>>({});
  const [wizardOpen, setWizardOpen] = useState(false);
  const [wizardGoal, setWizardGoal] = useState("");
  const [wizardBusy, setWizardBusy] = useState(false);

  const valueMap = useMemo(() => {
    const m = new Map<string, unknown>();
    for (const r of rows ?? []) m.set(`${r.namespace}.${r.key}`, r.value);
    return m;
  }, [rows]);

  const filteredSettings = useMemo(() => {
    const term = search.trim().toLowerCase();
    return SETTINGS.filter((s) => {
      if (term) {
        const hay = `${s.namespace} ${s.key} ${s.label} ${s.description}`.toLowerCase();
        if (!hay.includes(term)) return false;
      } else {
        if (s.namespace !== active) return false;
      }
      return true;
    });
  }, [search, active]);

  const saveMut = useMutation({
    mutationFn: async (items: { namespace: string; key: string; value: unknown }[]) => {
      for (const it of items) await upsert({ data: { ...it, asDraft: false } });
    },
    onSuccess: () => {
      toast.success("Mentve");
      setDirty({});
      qc.invalidateQueries({ queryKey: ["admin", "all-settings"] });
      qc.invalidateQueries({ queryKey: ["app-settings"] });
    },
    onError: (e) => toast.error("Hiba: " + (e as Error).message),
  });

  function setValue(ns: string, key: string, v: unknown) {
    setDirty((d) => ({ ...d, [`${ns}.${key}`]: v }));
  }
  function getValue(ns: string, key: string) {
    const k = `${ns}.${key}`;
    if (k in dirty) return dirty[k];
    return valueMap.get(k) ?? getSettingDef(ns, key)?.default;
  }
  async function saveAll() {
    const items = Object.entries(dirty).map(([k, v]) => {
      const [ns, key] = k.split(".");
      return { namespace: ns, key, value: v };
    });
    if (items.length === 0) { toast.info("Nincs változás"); return; }
    saveMut.mutate(items);
  }

  async function doExport() {
    const data = await exportFn();
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `settings-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
  }
  async function doImport(file: File) {
    const text = await file.text();
    try {
      const items = JSON.parse(text);
      const r = await importFn({ data: { items } });
      toast.success(`${r.imported} beállítás importálva`);
      qc.invalidateQueries({ queryKey: ["admin", "all-settings"] });
    } catch (e) {
      toast.error("Import hiba: " + (e as Error).message);
    }
  }
  async function runWizard() {
    if (!wizardGoal.trim()) return;
    setWizardBusy(true);
    try {
      const r = await batch({ data: { goal: wizardGoal } });
      for (const s of r.suggestions) setValue(s.namespace, s.key, s.value);
      toast.success(`${r.suggestions.length} javaslat előtöltve — ellenőrizd és mentsd.`);
      setWizardOpen(false);
    } catch (e) {
      toast.error("Wizard hiba: " + (e as Error).message);
    } finally {
      setWizardBusy(false);
    }
  }

  // Ctrl+S / Cmd+S → mentés; '/' → kereső fókusz
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "s") {
        e.preventDefault();
        saveAll();
      } else if (e.key === "/" && document.activeElement?.tagName !== "INPUT" && document.activeElement?.tagName !== "TEXTAREA") {
        e.preventDefault();
        const input = document.querySelector<HTMLInputElement>('input[placeholder^="Keresés"]');
        input?.focus();
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dirty]);

  function renderField(def: typeof SETTINGS[number]) {
    return (
      <SettingField
        key={`${def.namespace}.${def.key}`}
        def={def}
        value={getValue(def.namespace, def.key)}
        onChange={(v) => setValue(def.namespace, def.key, v)}
        onReset={async () => {
          await reset({ data: { namespace: def.namespace, key: def.key } });
          toast.success("Visszaállítva");
          qc.invalidateQueries({ queryKey: ["admin", "all-settings"] });
          setDirty((d) => { const c = { ...d }; delete c[`${def.namespace}.${def.key}`]; return c; });
        }}
      />
    );
  }

  function groupedBySearch(items: typeof SETTINGS): [string, typeof SETTINGS][] {
    const m = new Map<string, typeof SETTINGS>();
    for (const it of items) {
      const arr = m.get(it.namespace) ?? [];
      arr.push(it);
      m.set(it.namespace, arr);
    }
    return Array.from(m.entries());
  }

  return (
    <div className="flex h-[calc(100vh-3.5rem)]">
      {/* Sidebar */}
      <aside className="w-64 border-r border-border/60 p-3 overflow-y-auto bg-muted/30">
        <h2 className="text-sm font-semibold mb-2 px-2">Kategóriák</h2>
        <nav className="space-y-0.5">
          {CATEGORIES.map((c) => (
            <button
              key={c.id}
              onClick={() => { setActive(c.id); setSearch(""); }}
              className={`w-full text-left px-2 py-1.5 rounded text-sm hover:bg-accent ${active === c.id && !search ? "bg-accent font-medium" : ""}`}
            >
              {c.label}
              <span className="ml-1 text-[10px] text-muted-foreground">
                ({SETTINGS.filter((s) => s.namespace === c.id).length})
              </span>
            </button>
          ))}
        </nav>
      </aside>

      {/* Main */}
      <main className="flex-1 overflow-y-auto">
        <header className="sticky top-0 z-10 bg-background/90 backdrop-blur border-b border-border/60 p-4 flex items-center gap-3 flex-wrap">
          <div className="flex-1 min-w-[200px] relative">
            <Search className="size-4 absolute left-2 top-2.5 text-muted-foreground" />
            <Input className="pl-8" placeholder="Keresés minden beállításban…" value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
          <Button variant="outline" size="sm" onClick={() => setWizardOpen(true)}>
            <Sparkles className="size-4 mr-1.5" /> AI Setup Wizard
          </Button>
          <Button variant="outline" size="sm" onClick={doExport}>
            <Download className="size-4 mr-1.5" /> Export
          </Button>
          <label className="inline-flex">
            <input type="file" accept="application/json" className="hidden" onChange={(e) => e.target.files && doImport(e.target.files[0])} />
            <span className="inline-flex h-9 items-center px-3 text-sm border rounded-md cursor-pointer hover:bg-accent">
              <Upload className="size-4 mr-1.5" /> Import
            </span>
          </label>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setDirty({})}
            disabled={Object.keys(dirty).length === 0 || saveMut.isPending}
            title="Mentett változások eldobása"
          >
            <Undo2 className="size-4 mr-1.5" /> Elvet
          </Button>
          <Button size="sm" onClick={saveAll} disabled={saveMut.isPending || Object.keys(dirty).length === 0}>
            {saveMut.isPending ? <Loader2 className="size-4 animate-spin mr-1.5" /> : <Save className="size-4 mr-1.5" />}
            Mentés ({Object.keys(dirty).length})
          </Button>
        </header>

        <div className="p-4 max-w-3xl mx-auto space-y-3">
          {!search && (
            <div className="mb-2">
              <h1 className="text-lg font-semibold">{CATEGORIES.find((c) => c.id === active)?.label}</h1>
              <p className="text-xs text-muted-foreground">{CATEGORIES.find((c) => c.id === active)?.description}</p>
            </div>
          )}
          {isLoading && <Card className="p-4">Betöltés…</Card>}
          {!isLoading && filteredSettings.length === 0 && (
            <Card className="p-4 text-sm text-muted-foreground">Nincs találat.</Card>
          )}
          {search && groupedBySearch(filteredSettings).map(([ns, items]) => (
            <div key={ns} className="space-y-2">
              <h3 className="text-xs uppercase tracking-wide text-muted-foreground pt-2">
                {CATEGORIES.find((c) => c.id === ns)?.label ?? ns}
              </h3>
              {items.map((def) => renderField(def))}
            </div>
          ))}
          {!search && filteredSettings.map((def) => renderField(def))}
        </div>
      </main>

      {/* Wizard modal */}
      {wizardOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => !wizardBusy && setWizardOpen(false)}>
          <Card className="max-w-lg w-full p-6 space-y-3" onClick={(e) => e.stopPropagation()}>
            <h2 className="text-lg font-semibold flex items-center gap-2"><Sparkles className="size-5 text-primary" /> AI Setup Wizard</h2>
            <p className="text-sm text-muted-foreground">Mondd el szabad szöveggel mit szeretnél — az AI több beállításra is javaslatot ad. <Badge variant="outline" className="text-[10px]">előtöltve, jóváhagyásra vár</Badge></p>
            <textarea
              className="w-full h-28 rounded border p-2 text-sm"
              placeholder="Pl.: 'Legyen pediátriai szakrendelő, barátságos hangvétellel, sárga-zöld branding, MFA minden szerepkörnek'"
              value={wizardGoal}
              onChange={(e) => setWizardGoal(e.target.value)}
            />
            <div className="flex justify-end gap-2">
              <Button variant="ghost" onClick={() => setWizardOpen(false)} disabled={wizardBusy}>Mégse</Button>
              <Button onClick={runWizard} disabled={wizardBusy || !wizardGoal.trim()}>
                {wizardBusy ? <Loader2 className="size-4 animate-spin mr-1.5" /> : <Sparkles className="size-4 mr-1.5" />}
                Javaslatokat kérek
              </Button>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}
