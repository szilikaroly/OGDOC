import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { humanizeError } from "@/lib/humanize-error";
import { useTranslation } from "react-i18next";
import { toast } from "sonner";
import { Loader2, UserCheck, AlertTriangle, Info, Search, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin/potlas")({
  component: PotlasPage,
});

type Candidate = {
  user_id: string;
  teljes_nev: string;
  email: string;
  foglalkozas_tipus: string;
  egyezo_skillek: string[];
  egyezo_kepzettsegek: string[];
  egyezo_skill_szam: number;
  egyezo_kepz_szam: number;
  pozitiv_kapcsolat: boolean;
  match_score: number;
  szabad: boolean;
  aktiv_korlatozok: string[];
};

type Assignment = {
  id: string;
  user_id: string;
  kezdo_idopont: string;
  zaro_idopont: string;
  kategoria: string;
  status: string;
};

function PotlasPage() {
  const { t } = useTranslation();
  const [people, setPeople] = useState<{ id: string; teljes_nev: string }[]>([]);
  const [userId, setUserId] = useState("");
  const [datum, setDatum] = useState(() => new Date().toISOString().slice(0, 10));
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [selectedAsgn, setSelectedAsgn] = useState<string | null>(null);
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [loading, setLoading] = useState(false);
  const [applying, setApplying] = useState<string | null>(null);

  useEffect(() => {
    void (async () => {
      const { data } = await supabase
        .from("profiles")
        .select("id, teljes_nev")
        .order("teljes_nev");
      setPeople((data ?? []) as { id: string; teljes_nev: string }[]);
    })();
  }, []);

  const search = useCallback(async () => {
    if (!userId || !datum) {
      toast.error("Válassz dolgozót és napot.");
      return;
    }
    setLoading(true);
    setCandidates([]);
    setAssignments([]);
    setSelectedAsgn(null);

    const dayStart = `${datum}T00:00:00`;
    const dayEnd = `${datum}T23:59:59`;
    const [a, c] = await Promise.all([
      supabase
        .from("schedule_assignments")
        .select("id, user_id, kezdo_idopont, zaro_idopont, kategoria, status")
        .eq("user_id", userId)
        .gte("kezdo_idopont", dayStart)
        .lte("kezdo_idopont", dayEnd)
        .order("kezdo_idopont"),
      (supabase as any).rpc("find_acute_replacements", {
        p_user_id: userId,
        p_datum: datum,
      }),
    ]);

    if (a.error) {
      toast.error(humanizeError(a.error, t));
    } else {
      setAssignments((a.data ?? []) as Assignment[]);
      if ((a.data ?? []).length > 0) setSelectedAsgn(a.data![0].id);
    }
    if (c.error) {
      toast.error(humanizeError(c.error, t));
    } else {
      setCandidates((c.data ?? []) as Candidate[]);
    }
    setLoading(false);
  }, [userId, datum, t]);

  async function applyReplacement(candidateUserId: string) {
    if (!selectedAsgn) {
      toast.error("Válassz műszakot, amit cserélni szeretnél.");
      return;
    }
    if (!confirm("Biztosan átírod a műszakot a kiválasztott helyettesre?")) return;
    setApplying(candidateUserId);
    const { error } = await supabase
      .from("schedule_assignments")
      .update({ user_id: candidateUserId, megjegyzes: "Pótlás (acute replacement)" })
      .eq("id", selectedAsgn);
    setApplying(null);
    if (error) return toast.error(humanizeError(error, t));
    toast.success("Pótlás rögzítve. A dolgozó értesítést kap.");
    void search();
  }

  return (
    <div className="p-6 space-y-4 max-w-6xl mx-auto">
      <header>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <UserCheck className="size-6 text-primary" /> Pótlási dialógus
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Akut helyettesítés: válaszd ki a kieső dolgozót és a napot, a rendszer skill-egyezés és kapcsolatok alapján rangsorolt jelöltlistát ad.
        </p>
      </header>

      <div className="bg-card border rounded-2xl p-4">
        <div className="flex items-start gap-2 text-sm text-muted-foreground mb-3">
          <Info className="size-4 mt-0.5 shrink-0 text-primary" />
          <p>
            <b>Hogyan használd?</b> 1) Válaszd ki a beteg/elérhetetlen dolgozót. 2) Add meg a napot. 3) A jelöltek között a zöld pipa = szabad és nincs aktív korlátozó. 4) Kattints az „Áthelyezem"-re a megfelelő műszakon — az audit naplóba kerül, és a dolgozó in-app értesítést kap.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <label className="block">
            <span className="block text-[11px] font-mono uppercase tracking-wider text-muted-foreground mb-1">Kieső dolgozó</span>
            <select className="w-full px-2 py-2 rounded border bg-background text-sm" value={userId} onChange={(e) => setUserId(e.target.value)}>
              <option value="">— válassz —</option>
              {people.map((p) => <option key={p.id} value={p.id}>{p.teljes_nev}</option>)}
            </select>
          </label>
          <label className="block">
            <span className="block text-[11px] font-mono uppercase tracking-wider text-muted-foreground mb-1">Nap</span>
            <input type="date" className="w-full px-2 py-2 rounded border bg-background text-sm" value={datum} onChange={(e) => setDatum(e.target.value)} />
          </label>
          <div className="flex items-end">
            <button onClick={search} disabled={loading} className="w-full inline-flex items-center justify-center gap-2 px-4 py-2 rounded bg-primary text-primary-foreground text-sm font-semibold disabled:opacity-50">
              {loading ? <Loader2 className="size-4 animate-spin" /> : <Search className="size-4" />}
              Pótlás keresése
            </button>
          </div>
        </div>
      </div>

      {assignments.length > 0 && (
        <div className="bg-card border rounded-2xl">
          <div className="px-4 py-2 border-b text-xs font-mono uppercase tracking-wider text-muted-foreground">
            Az adott nap műszakai ({assignments.length}) — válaszd ki, melyiket cseréled
          </div>
          <ul className="divide-y">
            {assignments.map((a) => {
              const sel = a.id === selectedAsgn;
              return (
                <li key={a.id} className={`px-4 py-2 text-sm flex items-center gap-3 cursor-pointer ${sel ? "bg-primary/5" : ""}`} onClick={() => setSelectedAsgn(a.id)}>
                  <input type="radio" checked={sel} onChange={() => setSelectedAsgn(a.id)} />
                  <span className="font-mono text-xs px-2 py-0.5 rounded bg-secondary">{a.kategoria}</span>
                  <span>{new Date(a.kezdo_idopont).toLocaleTimeString("hu-HU", { hour: "2-digit", minute: "2-digit" })}</span>
                  <ArrowRight className="size-3 text-muted-foreground" />
                  <span>{new Date(a.zaro_idopont).toLocaleTimeString("hu-HU", { hour: "2-digit", minute: "2-digit" })}</span>
                  <span className="ml-auto text-xs text-muted-foreground">{a.status}</span>
                </li>
              );
            })}
          </ul>
        </div>
      )}

      {candidates.length > 0 && (
        <div className="bg-card border rounded-2xl">
          <div className="px-4 py-2 border-b text-xs font-mono uppercase tracking-wider text-muted-foreground">
            Helyettesítő jelöltek ({candidates.length}) — match-score szerint rendezve
          </div>
          <ul className="divide-y">
            {candidates.map((c) => (
              <li key={c.user_id} className="px-4 py-3 flex items-center gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold">{c.teljes_nev}</span>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-secondary">{c.foglalkozas_tipus}</span>
                    {c.pozitiv_kapcsolat && (
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-900 border border-emerald-300">szívesen dolgozik vele</span>
                    )}
                    {c.szabad ? (
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-900 border border-emerald-300">szabad</span>
                    ) : (
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-rose-100 text-rose-900 border border-rose-300 flex items-center gap-1">
                        <AlertTriangle className="size-3" /> nem elérhető
                      </span>
                    )}
                  </div>
                  <div className="text-[11px] text-muted-foreground mt-1 space-x-2">
                    <span>skill: {c.egyezo_skill_szam}</span>
                    <span>· képzettség: {c.egyezo_kepz_szam}</span>
                    <span>· score: <b>{c.match_score}</b></span>
                    {c.egyezo_skillek.length > 0 && <span>· {c.egyezo_skillek.slice(0, 3).join(", ")}</span>}
                    {c.aktiv_korlatozok.length > 0 && <span className="text-warning">· korlát: {c.aktiv_korlatozok.join(", ")}</span>}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => applyReplacement(c.user_id)}
                  disabled={!selectedAsgn || !c.szabad || applying === c.user_id}
                  className="px-3 py-1.5 rounded bg-primary text-primary-foreground text-sm font-semibold disabled:opacity-40"
                >
                  {applying === c.user_id ? <Loader2 className="size-4 animate-spin" /> : "Áthelyezem"}
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}

      {!loading && userId && datum && candidates.length === 0 && assignments.length === 0 && (
        <div className="bg-card border rounded-2xl p-6 text-center text-sm text-muted-foreground">
          Nincs találat. Próbálj másik napot, vagy ellenőrizd, hogy a dolgozó skill/képzettség listája fel van-e véve.
        </div>
      )}
    </div>
  );
}
