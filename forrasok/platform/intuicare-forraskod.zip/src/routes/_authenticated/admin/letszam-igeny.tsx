import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

import { toast } from "sonner";
import { humanizeError } from "@/lib/humanize-error";
import { useTranslation } from "react-i18next";
import { Plus, Pencil, Trash2, Users, Save, X, Calendar } from "lucide-react";
import { RouteErrorBoundary } from "@/lib/errors/route-boundaries";

export const Route = createFileRoute("/_authenticated/admin/letszam-igeny")({
  component: LetszamIgenyPage,
  errorComponent: RouteErrorBoundary,
});

type OrgUnit = {
  id: string;
  nev: string;
  tipus: string;
  site_id: string;
  aktiv: boolean;
  min_letszam_napi: number | null;
  max_letszam_napi: number | null;
  mukodes_kezd: string | null;
  mukodes_veg: string | null;
};
type StaffRole = { id: string; kulcs: string; nev: string; sorrend: number };
type Skill = { id: string; nev: string };
type Template = {
  id: string;
  org_unit_id: string;
  nev: string;
  leiras: string | null;
  nap_bitmap: number;
  kezd_ido: string;
  veg_ido: string;
  kategoria: string;
  ervenyes_tol: string;
  ervenyes_ig: string | null;
  aktiv: boolean;
};
type TemplateRole = {
  id: string;
  template_id: string;
  staff_role_id: string;
  skill_id: string | null;
  min_letszam: number;
  max_letszam: number | null;
  kotelezo: boolean;
  sorrend: number;
};

const NAPOK = ["H", "K", "Sze", "Cs", "P", "Szo", "V"];
const KATEGORIAK = [
  { v: "rendes", l: "Rendes" },
  { v: "ugyelet", l: "Ügyelet" },
  { v: "keszenlet", l: "Készenlét" },
  { v: "sos", l: "SOS / sürgősségi" },
];
const RELEVANT_TIPUSOK = new Set(["muto", "kismuto", "fekvobeteg_osztaly", "ambulancia", "rendelo"]);

function LetszamIgenyPage() {
  const { t } = useTranslation();
  const [tenantId, setTenantId] = useState<string | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [orgUnits, setOrgUnits] = useState<OrgUnit[]>([]);
  const [roles, setRoles] = useState<StaffRole[]>([]);
  const [skills, setSkills] = useState<Skill[]>([]);
  const [templates, setTemplates] = useState<Template[]>([]);
  const [templateRoles, setTemplateRoles] = useState<TemplateRole[]>([]);
  const [selectedOrgUnit, setSelectedOrgUnit] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    const [{ data: prof }, { data: admin }] = await Promise.all([
      supabase.from("profiles").select("tenant_id").eq("id", user.id).maybeSingle(),
      supabase.rpc("has_permission", { _user_id: user.id, _perm: "manage_org" }),
    ]);
    setTenantId(prof?.tenant_id ?? null);
    setIsAdmin(Boolean(admin));

    const [{ data: ou }, { data: sr }, { data: sk }, { data: tpl }, { data: tplr }] = await Promise.all([
      supabase.from("org_units").select("id,nev,tipus,site_id,aktiv,min_letszam_napi,max_letszam_napi,mukodes_kezd,mukodes_veg").order("nev"),
      supabase.from("staff_roles").select("id,kulcs,nev,sorrend").order("sorrend"),
      supabase.from("skills").select("id,nev").order("nev"),
      supabase.from("staffing_templates").select("*").order("kezd_ido"),
      supabase.from("staffing_template_roles").select("*").order("sorrend"),
    ]);
    setOrgUnits((ou ?? []) as OrgUnit[]);
    setRoles((sr ?? []) as StaffRole[]);
    setSkills((sk ?? []) as Skill[]);
    setTemplates((tpl ?? []) as Template[]);
    setTemplateRoles((tplr ?? []) as TemplateRole[]);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const filteredOrgUnits = useMemo(
    () => orgUnits.filter((u) => RELEVANT_TIPUSOK.has(u.tipus) && u.aktiv),
    [orgUnits],
  );
  const currentTemplates = useMemo(
    () => templates.filter((t) => t.org_unit_id === selectedOrgUnit),
    [templates, selectedOrgUnit],
  );

  async function addTemplate() {
    if (!selectedOrgUnit || !tenantId) return;
    const nev = window.prompt("Sablon neve", "Új sablon");
    if (!nev) return;
    const { error } = await supabase.from("staffing_templates").insert({
      tenant_id: tenantId,
      org_unit_id: selectedOrgUnit,
      nev,
      nap_bitmap: 31, // H-P
      kezd_ido: "08:00",
      veg_ido: "16:00",
      kategoria: "rendes",
    });
    if (error) return toast.error(humanizeError(error, t, { perm: "manage_org" }));
    toast.success("Sablon létrehozva");
    load();
  }

  async function updateTemplate(id: string, patch: Partial<Template>) {
    const { error } = await supabase.from("staffing_templates").update(patch).eq("id", id);
    if (error) return toast.error(humanizeError(error, t, { perm: "manage_org" }));
    load();
  }

  async function deleteTemplate(id: string) {
    if (!window.confirm("Biztosan törli a sablont?")) return;
    const { error } = await supabase.from("staffing_templates").delete().eq("id", id);
    if (error) return toast.error(humanizeError(error, t, { perm: "manage_org" }));
    load();
  }

  async function addRoleRow(templateId: string) {
    if (!tenantId || roles.length === 0) return;
    const { error } = await supabase.from("staffing_template_roles").insert({
      tenant_id: tenantId,
      template_id: templateId,
      staff_role_id: roles[0].id,
      min_letszam: 1,
      kotelezo: true,
    });
    if (error) return toast.error(humanizeError(error, t, { perm: "manage_org" }));
    load();
  }

  async function updateRoleRow(id: string, patch: Partial<TemplateRole>) {
    const { error } = await supabase.from("staffing_template_roles").update(patch).eq("id", id);
    if (error) return toast.error(humanizeError(error, t, { perm: "manage_org" }));
    load();
  }

  async function deleteRoleRow(id: string) {
    const { error } = await supabase.from("staffing_template_roles").delete().eq("id", id);
    if (error) return toast.error(humanizeError(error, t, { perm: "manage_org" }));
    load();
  }

  return (
      <div className="p-8 max-w-7xl mx-auto">
        <div className="mb-6 flex items-center gap-3">
          <Users className="size-6 text-primary" />
          <div className="flex-1">
            <h1 className="text-2xl font-bold tracking-tight">Létszámigény-sablonok</h1>
            <p className="text-sm text-muted-foreground font-mono uppercase tracking-wider">
              Műtő- és osztály-szintű személyzeti minimum/maximum idősávonként
            </p>
          </div>
          <a href="/admin/szervezet-sugo" className="text-xs underline text-muted-foreground hover:text-foreground">
            kézikönyv ↗
          </a>
        </div>

        <div className="mb-4 p-3 rounded-lg border border-primary/20 bg-primary/5 text-xs text-muted-foreground">
          <b className="text-foreground">Tipp:</b> a sablonok a <i>tervezett</i> működésre vonatkoznak (osztály, műtő, ambulancia napi szerepkör-igénye). Az <b>ügyeleti</b> pozíciókat a Szervezet → Telephely → <i>Ügyeleti sorok</i> alatt rögzítsd; a beosztómotor a kettőt egyesíti (<code>generate_duty_demand</code> + <code>generate_demand_for_period</code>).
        </div>

        {!isAdmin && !loading && (
          <div className="mb-4 p-3 rounded-lg border border-warning/30 bg-warning/10 text-sm">
            Nincs manage_org jogosultsága. Csak olvasható módban látja.
          </div>
        )}

        {loading ? (
          <div className="p-8 text-center text-sm text-muted-foreground">Betöltés…</div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-[280px_1fr] gap-6">
            {/* Org unit list */}
            <aside className="bg-card border border-border rounded-2xl p-3 max-h-[80vh] overflow-y-auto">
              <div className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground mb-2 px-2">
                Egységek ({filteredOrgUnits.length})
              </div>
              {filteredOrgUnits.length === 0 ? (
                <div className="p-3 text-xs text-muted-foreground italic">
                  Nincs releváns egység. Először hozz létre műtőket/osztályokat a Szervezet oldalon.
                </div>
              ) : (
                <ul className="space-y-1">
                  {filteredOrgUnits.map((u) => {
                    const count = templates.filter((t) => t.org_unit_id === u.id).length;
                    return (
                      <li key={u.id}>
                        <button
                          type="button"
                          onClick={() => setSelectedOrgUnit(u.id)}
                          className={`w-full text-left p-2 rounded-lg text-sm transition-colors ${
                            selectedOrgUnit === u.id
                              ? "bg-primary text-primary-foreground"
                              : "hover:bg-secondary"
                          }`}
                        >
                          <div className="font-semibold">{u.nev}</div>
                          <div className="text-[10px] font-mono uppercase opacity-70">
                            {u.tipus} · {count} sablon
                          </div>
                        </button>
                      </li>
                    );
                  })}
                </ul>
              )}
            </aside>

            {/* Templates */}
            <div className="space-y-4">
              {!selectedOrgUnit ? (
                <div className="p-12 text-center bg-card border border-dashed border-border rounded-2xl">
                  <Calendar className="size-10 mx-auto text-muted-foreground mb-3" />
                  <p className="text-sm text-muted-foreground">
                    Válassz egy egységet a bal oldali listából
                  </p>
                </div>
              ) : (
                <>
                  <div className="flex items-center justify-between">
                    <h2 className="text-lg font-bold">
                      {orgUnits.find((u) => u.id === selectedOrgUnit)?.nev}
                    </h2>
                    {isAdmin && (
                      <button
                        type="button"
                        onClick={addTemplate}
                        className="inline-flex items-center gap-1.5 px-3 py-2 bg-primary text-primary-foreground rounded-lg text-xs font-mono font-semibold uppercase hover:bg-primary/90"
                      >
                        <Plus className="size-3.5" /> Új sablon
                      </button>
                    )}
                  </div>

                  {currentTemplates.length === 0 ? (
                    <div className="p-8 text-center bg-card border border-dashed border-border rounded-2xl text-sm text-muted-foreground">
                      Még nincs sablon. Adj hozzá egyet a fenti gombbal.
                    </div>
                  ) : (
                    currentTemplates.map((tpl) => (
                      <TemplateCard
                        key={tpl.id}
                        template={tpl}
                        roles={roles}
                        skills={skills}
                        rows={templateRoles.filter((r) => r.template_id === tpl.id)}
                        isAdmin={isAdmin}
                        onUpdate={(patch) => updateTemplate(tpl.id, patch)}
                        onDelete={() => deleteTemplate(tpl.id)}
                        onAddRow={() => addRoleRow(tpl.id)}
                        onUpdateRow={updateRoleRow}
                        onDeleteRow={deleteRoleRow}
                      />
                    ))
                  )}
                </>
              )}
            </div>
          </div>
        )}
      </div>
  );
}

function TemplateCard(props: {
  template: Template;
  roles: StaffRole[];
  skills: Skill[];
  rows: TemplateRole[];
  isAdmin: boolean;
  onUpdate: (patch: Partial<Template>) => void;
  onDelete: () => void;
  onAddRow: () => void;
  onUpdateRow: (id: string, patch: Partial<TemplateRole>) => void;
  onDeleteRow: (id: string) => void;
}) {
  const { template: tpl, roles, skills, rows, isAdmin } = props;
  const [edit, setEdit] = useState(false);
  const [form, setForm] = useState({
    nev: tpl.nev,
    kezd_ido: tpl.kezd_ido.slice(0, 5),
    veg_ido: tpl.veg_ido.slice(0, 5),
    kategoria: tpl.kategoria,
    nap_bitmap: tpl.nap_bitmap,
    ervenyes_tol: tpl.ervenyes_tol,
    ervenyes_ig: tpl.ervenyes_ig ?? "",
    aktiv: tpl.aktiv,
  });

  const totalMin = rows.reduce((s, r) => s + r.min_letszam, 0);
  const totalMax = rows.reduce((s, r) => s + (r.max_letszam ?? r.min_letszam), 0);

  function toggleNap(idx: number) {
    if (!isAdmin) return;
    const mask = 1 << idx;
    const next = form.nap_bitmap ^ mask;
    setForm({ ...form, nap_bitmap: next });
    if (!edit) props.onUpdate({ nap_bitmap: next });
  }

  function save() {
    props.onUpdate({
      nev: form.nev,
      kezd_ido: form.kezd_ido,
      veg_ido: form.veg_ido,
      kategoria: form.kategoria,
      nap_bitmap: form.nap_bitmap,
      ervenyes_tol: form.ervenyes_tol,
      ervenyes_ig: form.ervenyes_ig || null,
      aktiv: form.aktiv,
    });
    setEdit(false);
  }

  return (
    <div className="bg-card border border-border rounded-2xl overflow-hidden">
      <div className="p-4 border-b border-border flex items-start gap-3">
        <div className="flex-1 space-y-2">
          {edit ? (
            <input
              value={form.nev}
              onChange={(e) => setForm({ ...form, nev: e.target.value })}
              className="w-full px-2 py-1 rounded border border-border bg-background font-bold text-base"
            />
          ) : (
            <div className="font-bold text-base">{tpl.nev}</div>
          )}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <div className="flex gap-1">
              {NAPOK.map((n, i) => (
                <button
                  key={n}
                  type="button"
                  onClick={() => toggleNap(i)}
                  disabled={!isAdmin}
                  className={`w-7 h-7 rounded text-[10px] font-mono font-bold uppercase ${
                    form.nap_bitmap & (1 << i)
                      ? "bg-primary text-primary-foreground"
                      : "bg-secondary text-muted-foreground"
                  }`}
                >
                  {n}
                </button>
              ))}
            </div>
            {edit ? (
              <>
                <input type="time" value={form.kezd_ido} onChange={(e) => setForm({ ...form, kezd_ido: e.target.value })} className="px-2 py-1 rounded border border-border bg-background" />
                <span>–</span>
                <input type="time" value={form.veg_ido} onChange={(e) => setForm({ ...form, veg_ido: e.target.value })} className="px-2 py-1 rounded border border-border bg-background" />
                <select value={form.kategoria} onChange={(e) => setForm({ ...form, kategoria: e.target.value })} className="px-2 py-1 rounded border border-border bg-background">
                  {KATEGORIAK.map((k) => <option key={k.v} value={k.v}>{k.l}</option>)}
                </select>
              </>
            ) : (
              <span className="font-mono text-muted-foreground">
                {tpl.kezd_ido.slice(0, 5)}–{tpl.veg_ido.slice(0, 5)} · {tpl.kategoria}
              </span>
            )}
          </div>
          <div className="text-[10px] font-mono uppercase text-muted-foreground">
            Összesen: min {totalMin} fő{totalMax !== totalMin ? ` / max ${totalMax} fő` : ""}
          </div>
        </div>
        {isAdmin && (
          <div className="flex gap-1">
            {edit ? (
              <>
                <button type="button" onClick={save} className="p-1.5 rounded hover:bg-secondary text-success" title="Mentés">
                  <Save className="size-4" />
                </button>
                <button type="button" onClick={() => setEdit(false)} className="p-1.5 rounded hover:bg-secondary" title="Mégse">
                  <X className="size-4" />
                </button>
              </>
            ) : (
              <>
                <button type="button" onClick={() => setEdit(true)} className="p-1.5 rounded hover:bg-secondary" title="Szerkesztés">
                  <Pencil className="size-4" />
                </button>
                <button type="button" onClick={props.onDelete} className="p-1.5 rounded hover:bg-secondary text-destructive" title="Törlés">
                  <Trash2 className="size-4" />
                </button>
              </>
            )}
          </div>
        )}
      </div>

      <div className="p-3">
        <div className="grid grid-cols-[1fr_1fr_60px_60px_60px_36px] gap-2 text-[10px] font-mono uppercase text-muted-foreground px-2 pb-1">
          <div>Szerepkör</div><div>Skill (opc.)</div><div>Min</div><div>Max</div><div>Köt.</div><div />
        </div>
        {rows.length === 0 ? (
          <div className="px-2 py-3 text-xs italic text-muted-foreground">Nincs még szerepkör-sor.</div>
        ) : (
          rows.map((r) => (
            <div key={r.id} className="grid grid-cols-[1fr_1fr_60px_60px_60px_36px] gap-2 items-center px-2 py-1">
              <select
                disabled={!isAdmin}
                value={r.staff_role_id}
                onChange={(e) => props.onUpdateRow(r.id, { staff_role_id: e.target.value })}
                className="px-2 py-1 rounded border border-border bg-background text-sm"
              >
                {roles.map((sr) => <option key={sr.id} value={sr.id}>{sr.nev}</option>)}
              </select>
              <select
                disabled={!isAdmin}
                value={r.skill_id ?? ""}
                onChange={(e) => props.onUpdateRow(r.id, { skill_id: e.target.value || null })}
                className="px-2 py-1 rounded border border-border bg-background text-sm"
              >
                <option value="">— bármely —</option>
                {skills.map((sk) => <option key={sk.id} value={sk.id}>{sk.nev}</option>)}
              </select>
              <input
                type="number" min={0} disabled={!isAdmin}
                value={r.min_letszam}
                onChange={(e) => props.onUpdateRow(r.id, { min_letszam: Math.max(0, parseInt(e.target.value) || 0) })}
                className="px-2 py-1 rounded border border-border bg-background text-sm"
              />
              <input
                type="number" min={0} disabled={!isAdmin}
                value={r.max_letszam ?? ""}
                placeholder="—"
                onChange={(e) => {
                  const v = e.target.value === "" ? null : Math.max(0, parseInt(e.target.value) || 0);
                  props.onUpdateRow(r.id, { max_letszam: v });
                }}
                className="px-2 py-1 rounded border border-border bg-background text-sm"
              />
              <input
                type="checkbox" disabled={!isAdmin}
                checked={r.kotelezo}
                onChange={(e) => props.onUpdateRow(r.id, { kotelezo: e.target.checked })}
                className="size-4 mx-auto"
              />
              {isAdmin && (
                <button type="button" onClick={() => props.onDeleteRow(r.id)} className="p-1 rounded hover:bg-secondary text-destructive" title="Sor törlése">
                  <Trash2 className="size-3.5" />
                </button>
              )}
            </div>
          ))
        )}
        {isAdmin && (
          <button
            type="button"
            onClick={props.onAddRow}
            className="mt-2 w-full inline-flex items-center justify-center gap-1 px-3 py-2 bg-secondary rounded-lg text-xs font-mono font-semibold uppercase hover:bg-secondary/70"
          >
            <Plus className="size-3.5" /> Szerepkör-sor
          </button>
        )}
      </div>
    </div>
  );
}
