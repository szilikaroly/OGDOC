import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { humanizeError } from "@/lib/humanize-error";
import { useTranslation } from "react-i18next";
import { toast } from "sonner";
import { Loader2, Zap, Info, Plus, HandHeart, FileText } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin/tulora-pool")({
  component: TuloraPoolPage,
});

type Pref = {
  id: string;
  user_id: string;
  ervenyes_tol: string;
  ervenyes_ig: string | null;
  napok: number[];
  muszakok: string[];
  max_ora_havi: number | null;
  status: string;
  megjegyzes: string | null;
  csak_sajat_osztaly: boolean;
};

type Order = {
  id: string;
  user_id: string;
  kategoria: string;
  kezdo_idopont: string;
  zaro_idopont: string;
  ora: number;
  indok: string;
  status: string;
  elrendeles_at: string;
};

type Person = { id: string; teljes_nev: string };

const NAPNEVEK = ["—", "H", "K", "Sz", "Cs", "P", "Szo", "V"];

function TuloraPoolPage() {
  const { t } = useTranslation();
  const [prefs, setPrefs] = useState<Pref[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [people, setPeople] = useState<Person[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    user_id: "",
    kezdo_idopont: "",
    zaro_idopont: "",
    kategoria: "rendkivuli",
    indok: "",
    irasos_hivatkozas: "",
  });

  const load = useCallback(async () => {
    setLoading(true);
    const [p, o, pe] = await Promise.all([
      supabase.from("overtime_preferences").select("*").eq("status", "aktiv").order("ervenyes_tol", { ascending: false }),
      supabase.from("overtime_orders").select("*").order("elrendeles_at", { ascending: false }).limit(50),
      supabase.from("profiles").select("id, teljes_nev").order("teljes_nev"),
    ]);
    setPrefs((p.data ?? []) as Pref[]);
    setOrders((o.data ?? []) as Order[]);
    setPeople((pe.data ?? []) as Person[]);
    setLoading(false);
  }, []);

  useEffect(() => { void load(); }, [load]);

  async function submitOrder() {
    if (!form.user_id || !form.kezdo_idopont || !form.zaro_idopont || !form.indok.trim()) {
      toast.error("Kötelező: dolgozó, kezdés, vég, indoklás.");
      return;
    }
    const ora = (new Date(form.zaro_idopont).getTime() - new Date(form.kezdo_idopont).getTime()) / 3_600_000;
    if (ora <= 0) return toast.error("A vég legyen a kezdés után.");

    const { data: profile } = await supabase.from("profiles").select("tenant_id").eq("id", form.user_id).maybeSingle();
    const tenant_id = profile?.tenant_id;
    if (!tenant_id) return toast.error("A dolgozó tenant nem található.");

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return toast.error("Bejelentkezés szükséges.");

    const { error } = await supabase.from("overtime_orders").insert({
      tenant_id,
      user_id: form.user_id,
      elrendelo_id: user.id,
      kategoria: form.kategoria,
      kezdo_idopont: form.kezdo_idopont,
      zaro_idopont: form.zaro_idopont,
      ora,
      indok: form.indok,
      irasos_hivatkozas: form.irasos_hivatkozas || null,
    });
    if (error) return toast.error(humanizeError(error, t));
    toast.success("Túlóra elrendelve. A dolgozó értesítést kap.");
    setShowForm(false);
    setForm({ user_id: "", kezdo_idopont: "", zaro_idopont: "", kategoria: "rendkivuli", indok: "", irasos_hivatkozas: "" });
    void load();
  }

  const personName = (id: string) => people.find((p) => p.id === id)?.teljes_nev ?? id.slice(0, 8);

  if (loading) return <div className="p-6 flex items-center gap-2 text-sm text-muted-foreground"><Loader2 className="size-4 animate-spin" /> Betöltés…</div>;

  return (
    <div className="p-6 space-y-4 max-w-6xl mx-auto">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Zap className="size-6 text-primary" /> Túlóra-pool és elrendelés
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Önkéntes vállalások (lépcső 2.) és vezetői elrendelések (lépcső 3.) egy helyen.
          </p>
        </div>
        <button onClick={() => setShowForm((s) => !s)} className="px-3 py-2 rounded bg-primary text-primary-foreground text-sm font-semibold inline-flex items-center gap-2">
          <Plus className="size-4" /> Új elrendelés
        </button>
      </header>

      <div className="bg-card border rounded-2xl p-4">
        <div className="flex items-start gap-2 text-sm text-muted-foreground">
          <Info className="size-4 mt-0.5 shrink-0 text-primary" />
          <div className="space-y-1">
            <p className="font-medium text-foreground">Lépcsős kitöltési elv</p>
            <ol className="list-decimal pl-4 text-[12px] space-y-0.5">
              <li>RENDES kapacitás (normál munkaidő — itt nincs túlóra).</li>
              <li><b>Önkéntes pool</b>: az alábbi listából rangsorolj (legkevesebb eddigi túlóra, preferencia-egyezés, jogszerűség).</li>
              <li><b>Elrendelt túlóra</b>: csak akkor, ha még mindig hiány — vezetői döntés, írásos hivatkozással (528/2020 16. §).</li>
            </ol>
            <p className="text-[11px] mt-1">Az éves 250 h rendkívüli és 416 h ügyelet+rendkívüli korlátot a `work_time_ledger` jelzi a karakterlap mérlegen.</p>
          </div>
        </div>
      </div>

      {showForm && (
        <div className="bg-card border-2 border-primary rounded-2xl p-4 space-y-3">
          <div className="text-sm font-bold flex items-center gap-2"><FileText className="size-4" /> Új túlóra elrendelése</div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <label className="block">
              <span className="block text-[11px] font-mono uppercase tracking-wider text-muted-foreground mb-1">Dolgozó</span>
              <select className="w-full px-2 py-2 rounded border bg-background text-sm" value={form.user_id} onChange={(e) => setForm({ ...form, user_id: e.target.value })}>
                <option value="">— válassz —</option>
                {people.map((p) => <option key={p.id} value={p.id}>{p.teljes_nev}</option>)}
              </select>
            </label>
            <label className="block">
              <span className="block text-[11px] font-mono uppercase tracking-wider text-muted-foreground mb-1">Kategória</span>
              <select className="w-full px-2 py-2 rounded border bg-background text-sm" value={form.kategoria} onChange={(e) => setForm({ ...form, kategoria: e.target.value })}>
                <option value="rendkivuli">Rendkívüli munkaidő (túlóra)</option>
                <option value="ovt_egyeb">ÖVT — egyéb</option>
                <option value="ovt_ugyelet">ÖVT — ügyelet</option>
              </select>
            </label>
            <label className="block">
              <span className="block text-[11px] font-mono uppercase tracking-wider text-muted-foreground mb-1">Kezdés</span>
              <input type="datetime-local" className="w-full px-2 py-2 rounded border bg-background text-sm" value={form.kezdo_idopont} onChange={(e) => setForm({ ...form, kezdo_idopont: e.target.value })} />
            </label>
            <label className="block">
              <span className="block text-[11px] font-mono uppercase tracking-wider text-muted-foreground mb-1">Vég</span>
              <input type="datetime-local" className="w-full px-2 py-2 rounded border bg-background text-sm" value={form.zaro_idopont} onChange={(e) => setForm({ ...form, zaro_idopont: e.target.value })} />
            </label>
            <label className="block md:col-span-2">
              <span className="block text-[11px] font-mono uppercase tracking-wider text-muted-foreground mb-1">Indoklás (kötelező)</span>
              <textarea rows={2} className="w-full px-2 py-2 rounded border bg-background text-sm" value={form.indok} onChange={(e) => setForm({ ...form, indok: e.target.value })} placeholder="pl. Műszakhiány Kiss A. betegsége miatt" />
            </label>
            <label className="block md:col-span-2">
              <span className="block text-[11px] font-mono uppercase tracking-wider text-muted-foreground mb-1">Írásos elrendelés hivatkozása (opcionális)</span>
              <input type="text" className="w-full px-2 py-2 rounded border bg-background text-sm" value={form.irasos_hivatkozas} onChange={(e) => setForm({ ...form, irasos_hivatkozas: e.target.value })} placeholder="pl. iktatószám, vezetői utasítás száma" />
            </label>
          </div>
          <div className="flex gap-2 justify-end">
            <button onClick={() => setShowForm(false)} className="px-3 py-1.5 rounded border text-sm">Mégse</button>
            <button onClick={submitOrder} className="px-3 py-1.5 rounded bg-primary text-primary-foreground text-sm font-semibold">Elrendelem</button>
          </div>
        </div>
      )}

      <div className="bg-card border rounded-2xl">
        <div className="px-4 py-2 border-b text-xs font-mono uppercase tracking-wider text-muted-foreground flex items-center gap-2">
          <HandHeart className="size-4 text-emerald-600" /> Önkéntes pool — aktív „Túlórát szeretnék" jelölések ({prefs.length})
        </div>
        {prefs.length === 0 ? (
          <div className="p-6 text-center text-sm text-muted-foreground">Jelenleg nincs aktív önkéntes vállalás.</div>
        ) : (
          <ul className="divide-y">
            {prefs.map((p) => (
              <li key={p.id} className="px-4 py-2.5 text-sm flex items-start gap-3">
                <div className="flex-1 min-w-0">
                  <div className="font-medium">{personName(p.user_id)}</div>
                  <div className="text-[11px] text-muted-foreground space-x-2">
                    <span>{p.ervenyes_tol}{p.ervenyes_ig ? ` – ${p.ervenyes_ig}` : " – (nyitott)"}</span>
                    {p.napok?.length > 0 && <span>· napok: {p.napok.map((n) => NAPNEVEK[n] ?? n).join(",")}</span>}
                    {p.muszakok?.length > 0 && <span>· műszakok: {p.muszakok.join(",")}</span>}
                    {p.max_ora_havi && <span>· max {p.max_ora_havi} ó/hó</span>}
                    {p.csak_sajat_osztaly && <span>· csak saját osztály</span>}
                    {p.megjegyzes && <span>· {p.megjegyzes}</span>}
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>

      <div className="bg-card border rounded-2xl">
        <div className="px-4 py-2 border-b text-xs font-mono uppercase tracking-wider text-muted-foreground flex items-center gap-2">
          <FileText className="size-4 text-rose-600" /> Elrendelt túlórák (utolsó 50)
        </div>
        {orders.length === 0 ? (
          <div className="p-6 text-center text-sm text-muted-foreground">Még nincs elrendelt túlóra.</div>
        ) : (
          <ul className="divide-y">
            {orders.map((o) => (
              <li key={o.id} className="px-4 py-2.5 text-sm flex items-start gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{personName(o.user_id)}</span>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-secondary">{o.kategoria}</span>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded border">{o.status}</span>
                  </div>
                  <div className="text-[11px] text-muted-foreground">
                    {new Date(o.kezdo_idopont).toLocaleString("hu-HU")} – {new Date(o.zaro_idopont).toLocaleString("hu-HU")} · {o.ora} ó
                  </div>
                  <div className="text-[11px] mt-0.5">{o.indok}</div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
