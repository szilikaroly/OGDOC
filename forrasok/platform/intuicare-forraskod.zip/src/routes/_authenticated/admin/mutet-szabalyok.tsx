import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useMemo, useState } from "react";
import { ListChecks, Loader2, Lock, Save, Search, Star } from "lucide-react";
import {
  listSurgeryTypeRules,
  upsertSurgeryTypeRule,
  type SurgeryTypeRule,
} from "@/lib/or/surgery-rules.functions";
import { usePermissions } from "@/hooks/use-permissions";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/admin/mutet-szabalyok")({
  component: SurgeryRulesPage,
  head: () => ({ meta: [{ title: "Műtéti típus-szabályok" }] }),
});

type Draft = {
  kiemelt: boolean;
  delegalas_kotelezo: boolean;
  operator_min_seniority: "szakorvos" | "foorvos" | "";
  szukseges_skillek: string;
  kotelezo_eroforrasok: string;
};

function ruleToDraft(r: SurgeryTypeRule): Draft {
  return {
    kiemelt: r.kiemelt,
    delegalas_kotelezo: r.delegalas_kotelezo,
    operator_min_seniority: r.operator_min_seniority ?? "",
    szukseges_skillek: (r.szukseges_skillek ?? []).join(", "),
    kotelezo_eroforrasok: (r.kotelezo_eroforrasok ?? []).join(", "),
  };
}

function SurgeryRulesPage() {
  const { canReal, loading } = usePermissions();
  const qc = useQueryClient();
  const list = useServerFn(listSurgeryTypeRules);
  const upsert = useServerFn(upsertSurgeryTypeRule);
  const [q, setQ] = useState("");
  const [drafts, setDrafts] = useState<Record<string, Draft>>({});

  const { data, isLoading } = useQuery({
    queryKey: ["surgery-type-rules"],
    queryFn: () => list() as Promise<SurgeryTypeRule[]>,
  });

  const filtered: SurgeryTypeRule[] = useMemo(() => {
    const term = q.trim().toLowerCase();
    const list = (data ?? []) as SurgeryTypeRule[];
    if (!term) return list;
    return list.filter(
      (r) =>
        r.nev.toLowerCase().includes(term) ||
        (r.kod ?? "").toLowerCase().includes(term),
    );
  }, [data, q]);

  const saveMut = useMutation({
    mutationFn: async (input: { id: string; draft: Draft }) => {
      const d = input.draft;
      return upsert({
        data: {
          id: input.id,
          kiemelt: d.kiemelt,
          delegalas_kotelezo: d.delegalas_kotelezo,
          operator_min_seniority: d.operator_min_seniority || null,
          szukseges_skillek: d.szukseges_skillek
            ? d.szukseges_skillek.split(",").map((s) => s.trim()).filter(Boolean)
            : [],
          kotelezo_eroforrasok: d.kotelezo_eroforrasok
            ? d.kotelezo_eroforrasok.split(",").map((s) => s.trim()).filter(Boolean)
            : [],
        },
      });
    },
    onSuccess: (_r, vars) => {
      toast.success("Szabály mentve");
      setDrafts((p) => {
        const n = { ...p };
        delete n[vars.id];
        return n;
      });
      qc.invalidateQueries({ queryKey: ["surgery-type-rules"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (loading) return <div className="p-8 text-sm text-muted-foreground">Jogosultságok betöltése…</div>;
  if (!canReal("manage_or_blocks")) {
    return (
      <div className="p-8">
        <div className="inline-flex items-center gap-2 rounded-md border border-border bg-card px-4 py-3 text-sm">
          <Lock className="size-4" /> Nincs jogosultsága a műtéti típus-szabályok kezeléséhez.
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-4">
      <header>
        <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
          <ListChecks className="size-5" /> Műtéti típus-szabályok
        </h1>
        <p className="mt-1 text-xs font-mono text-muted-foreground uppercase tracking-wider">
          Kiemelt jelölés · min. operatőri szint · kötelező delegálás · skill / erőforrás követelmények
        </p>
      </header>

      <div className="relative max-w-md">
        <Search className="size-3.5 absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Keresés név vagy kód szerint…"
          className="h-9 w-full rounded-md border border-border bg-background pl-7 pr-3 text-sm"
        />
      </div>

      <div className="rounded-lg border border-border bg-card overflow-x-auto">
        <table className="w-full text-sm min-w-[1000px]">
          <thead className="bg-secondary/40 text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="text-left px-3 py-2">Típus</th>
              <th className="text-left px-2 py-2">Kiemelt</th>
              <th className="text-left px-2 py-2">Delegálás köt.</th>
              <th className="text-left px-2 py-2">Min. operatőr szint</th>
              <th className="text-left px-2 py-2">Szükséges skillek (vesszővel)</th>
              <th className="text-left px-2 py-2">Kötelező erőforrások</th>
              <th className="text-right px-2 py-2">Mentés</th>
            </tr>
          </thead>
          <tbody>
            {isLoading && (
              <tr><td colSpan={7} className="text-center py-6 text-muted-foreground">Betöltés…</td></tr>
            )}
            {!isLoading && filtered.length === 0 && (
              <tr><td colSpan={7} className="text-center py-6 italic text-muted-foreground">Nincs találat.</td></tr>
            )}
            {filtered.map((r) => {
              const d: Draft = drafts[r.id] ?? ruleToDraft(r);
              const dirty = drafts[r.id] !== undefined;
              function patch(p: Partial<Draft>) {
                setDrafts((prev) => ({ ...prev, [r.id]: { ...(prev[r.id] ?? ruleToDraft(r)), ...p } }));
              }
              return (
                <tr key={r.id} className={cn("border-t border-border align-top", dirty && "bg-amber-50/40")}>
                  <td className="px-3 py-2">
                    <div className="font-semibold">{r.nev}</div>
                    {r.kod && <div className="text-[10px] font-mono text-muted-foreground">{r.kod}</div>}
                    {r.kotelezo_muto_tipus && (
                      <div className="text-[10px] font-mono text-muted-foreground mt-0.5">Műtő: {r.kotelezo_muto_tipus}</div>
                    )}
                  </td>
                  <td className="px-2 py-2">
                    <label className="inline-flex items-center gap-1 cursor-pointer">
                      <input type="checkbox" checked={d.kiemelt} onChange={(e) => patch({ kiemelt: e.target.checked })} />
                      <Star className={cn("size-3.5", d.kiemelt ? "fill-amber-500 text-amber-500" : "text-muted-foreground")} />
                    </label>
                  </td>
                  <td className="px-2 py-2">
                    <input type="checkbox" checked={d.delegalas_kotelezo} onChange={(e) => patch({ delegalas_kotelezo: e.target.checked })} />
                  </td>
                  <td className="px-2 py-2">
                    <select
                      value={d.operator_min_seniority}
                      onChange={(e) => patch({ operator_min_seniority: e.target.value as Draft["operator_min_seniority"] })}
                      className="h-8 rounded border border-border bg-background px-1 text-xs"
                    >
                      <option value="">— nincs —</option>
                      <option value="szakorvos">Szakorvos</option>
                      <option value="foorvos">Főorvos</option>
                    </select>
                  </td>
                  <td className="px-2 py-2">
                    <input
                      value={d.szukseges_skillek}
                      onChange={(e) => patch({ szukseges_skillek: e.target.value })}
                      placeholder="laparoszkop, mikroszkop"
                      className="h-8 w-full min-w-[180px] rounded border border-border bg-background px-2 text-xs"
                    />
                  </td>
                  <td className="px-2 py-2">
                    <input
                      value={d.kotelezo_eroforrasok}
                      onChange={(e) => patch({ kotelezo_eroforrasok: e.target.value })}
                      placeholder="mikroszkop, c-iv"
                      className="h-8 w-full min-w-[180px] rounded border border-border bg-background px-2 text-xs"
                    />
                  </td>
                  <td className="px-2 py-2 text-right">
                    <button
                      type="button"
                      disabled={!dirty || saveMut.isPending}
                      onClick={() => saveMut.mutate({ id: r.id, draft: d })}
                      className="inline-flex items-center gap-1 h-8 px-2 rounded-md bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90 disabled:opacity-40"
                    >
                      {saveMut.isPending && saveMut.variables?.id === r.id ? <Loader2 className="size-3 animate-spin" /> : <Save className="size-3" />}
                      Mentés
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
