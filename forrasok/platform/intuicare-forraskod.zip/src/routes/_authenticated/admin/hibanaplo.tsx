import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { AlertTriangle, RefreshCw, Sparkles, Copy } from "lucide-react";
import {
  listErrorLog,
  suggestErrorFix,
} from "@/lib/errors/error-log.functions";
import { RouteErrorBoundary } from "@/lib/errors/route-boundaries";

export const Route = createFileRoute("/_authenticated/admin/hibanaplo")({
  component: HibanaploPage,
  errorComponent: RouteErrorBoundary,
  head: () => ({ meta: [{ title: "Hibanapló – Admin" }] }),
});

type Row = {
  id: string;
  code: string;
  kind: string;
  title: string | null;
  message: string | null;
  technical: string | null;
  route: string | null;
  query_params: Record<string, unknown> | null;
  user_id: string | null;
  user_agent: string | null;
  ai_suggestion: string | null;
  ai_suggested_at: string | null;
  created_at: string;
};

const KIND_LABEL: Record<string, string> = {
  missing_table: "Hiányzó tábla",
  missing_column: "Hiányzó oszlop",
  permission_denied: "Jogosultság",
  unauthorized: "Nincs bejelentkezve",
  not_found: "Nem található",
  network: "Hálózati",
  unknown: "Egyéb",
};

const KIND_CLR: Record<string, string> = {
  missing_table: "bg-red-100 text-red-800",
  missing_column: "bg-red-100 text-red-800",
  permission_denied: "bg-amber-100 text-amber-800",
  unauthorized: "bg-amber-100 text-amber-800",
  not_found: "bg-blue-100 text-blue-800",
  network: "bg-purple-100 text-purple-800",
  unknown: "bg-muted text-foreground",
};

function HibanaploPage() {
  const list = useServerFn(listErrorLog);
  const suggest = useServerFn(suggestErrorFix);
  const qc = useQueryClient();
  const [selected, setSelected] = useState<Row | null>(null);
  const [kindFilter, setKindFilter] = useState<string | null>(null);

  const { data, isLoading, refetch, isFetching } = useQuery({
    queryKey: ["error-log", kindFilter],
    queryFn: () => list({ data: { limit: 100, kind: kindFilter } }),
  });

  const suggestMut = useMutation({
    mutationFn: async (id: string) => suggest({ data: { errorId: id } }),
    onSuccess: (res) => {
      toast.success("AI javaslat elkészült");
      if (selected) setSelected({ ...selected, ai_suggestion: res.suggestion, ai_suggested_at: new Date().toISOString() });
      qc.invalidateQueries({ queryKey: ["error-log"] });
    },
    onError: (e: any) => toast.error(e?.message ?? "AI hiba"),
  });

  const rows = (data?.rows ?? []) as Row[];

  const copy = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast.success("Vágólapra másolva");
    } catch {
      toast.error("Nem sikerült másolni");
    }
  };

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <header className="mb-6 flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <AlertTriangle className="h-6 w-6 text-amber-600" /> Hibanapló
          </h1>
          <p className="text-sm text-muted-foreground">
            Központi kliens-oldali hibák. Az AI segéd elemzi és javításokat javasol.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <select
            value={kindFilter ?? ""}
            onChange={(e) => setKindFilter(e.target.value || null)}
            className="rounded-md border border-input bg-background px-3 py-2 text-sm"
          >
            <option value="">Összes típus</option>
            {Object.entries(KIND_LABEL).map(([k, v]) => (
              <option key={k} value={k}>
                {v}
              </option>
            ))}
          </select>
          <button
            onClick={() => refetch()}
            className="inline-flex items-center gap-1 rounded-md border border-input bg-background px-3 py-2 text-sm hover:bg-accent"
          >
            <RefreshCw className={`h-4 w-4 ${isFetching ? "animate-spin" : ""}`} /> Frissítés
          </button>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr,1.2fr] gap-6">
        <div className="rounded-md border border-border overflow-hidden">
          <div className="bg-muted px-3 py-2 text-xs font-medium text-muted-foreground">
            {isLoading ? "Betöltés…" : `${rows.length} bejegyzés`}
          </div>
          <ul className="divide-y divide-border max-h-[70vh] overflow-y-auto">
            {rows.map((r) => (
              <li
                key={r.id}
                onClick={() => setSelected(r)}
                className={`cursor-pointer px-3 py-2 hover:bg-accent ${selected?.id === r.id ? "bg-accent" : ""}`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span
                    className={`inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-medium ${
                      KIND_CLR[r.kind] ?? KIND_CLR.unknown
                    }`}
                  >
                    {KIND_LABEL[r.kind] ?? r.kind}
                  </span>
                  <span className="font-mono text-xs text-muted-foreground">{r.code}</span>
                </div>
                <div className="mt-1 truncate text-sm">{r.title ?? r.message ?? "—"}</div>
                <div className="mt-0.5 flex items-center justify-between text-[11px] text-muted-foreground">
                  <span className="truncate">{r.route ?? "?"}</span>
                  <span>{new Date(r.created_at).toLocaleString("hu-HU")}</span>
                </div>
              </li>
            ))}
            {rows.length === 0 && !isLoading ? (
              <li className="px-3 py-6 text-center text-sm text-muted-foreground">
                Nincs naplózott hiba 🎉
              </li>
            ) : null}
          </ul>
        </div>

        <div className="rounded-md border border-border p-4 min-h-[40vh]">
          {selected ? (
            <DetailView
              row={selected}
              onSuggest={() => suggestMut.mutate(selected.id)}
              suggesting={suggestMut.isPending}
              onCopy={copy}
            />
          ) : (
            <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
              Válasszon egy bejegyzést a részletekhez.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function DetailView({
  row,
  onSuggest,
  suggesting,
  onCopy,
}: {
  row: Row;
  onSuggest: () => void;
  suggesting: boolean;
  onCopy: (t: string) => void;
}) {
  return (
    <div className="space-y-4">
      <div className="flex items-start justify-between gap-2">
        <div>
          <div className="text-xs text-muted-foreground">Kód</div>
          <button
            onClick={() => onCopy(row.code)}
            className="font-mono text-lg font-semibold hover:underline"
          >
            {row.code} <Copy className="inline h-3 w-3" />
          </button>
        </div>
        <span
          className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ${
            KIND_CLR[row.kind] ?? KIND_CLR.unknown
          }`}
        >
          {KIND_LABEL[row.kind] ?? row.kind}
        </span>
      </div>

      <Field label="Cím" value={row.title} />
      <Field label="Üzenet" value={row.message} />
      <Field label="Útvonal" value={row.route} mono />
      <Field
        label="Query paraméterek"
        value={row.query_params && Object.keys(row.query_params).length > 0 ? JSON.stringify(row.query_params, null, 2) : "—"}
        mono
        pre
      />
      <Field label="Felhasználó ID" value={row.user_id ?? "anon"} mono />
      <Field label="User Agent" value={row.user_agent} mono />
      <Field label="Időpont" value={new Date(row.created_at).toLocaleString("hu-HU")} />

      {row.technical ? (
        <div>
          <div className="flex items-center justify-between">
            <div className="text-xs font-medium text-muted-foreground">Stack / technikai részletek</div>
            <button
              onClick={() => onCopy(row.technical!)}
              className="text-xs text-muted-foreground hover:text-foreground inline-flex items-center gap-1"
            >
              <Copy className="h-3 w-3" /> Másolás
            </button>
          </div>
          <pre className="mt-1 max-h-64 overflow-auto rounded-md bg-muted p-2 text-xs whitespace-pre-wrap break-all">
            {row.technical}
          </pre>
        </div>
      ) : null}

      <div className="rounded-md border border-border p-3 bg-muted/30">
        <div className="flex items-center justify-between gap-2">
          <div className="text-sm font-medium flex items-center gap-1">
            <Sparkles className="h-4 w-4 text-primary" /> AI javítási javaslat
          </div>
          <button
            onClick={onSuggest}
            disabled={suggesting}
            className="inline-flex items-center gap-1 rounded-md bg-primary px-3 py-1.5 text-xs font-medium text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
          >
            {suggesting ? "Elemzés…" : row.ai_suggestion ? "Újraelemzés" : "Elemzés indítása"}
          </button>
        </div>
        {row.ai_suggestion ? (
          <>
            <pre className="mt-2 whitespace-pre-wrap text-sm">{row.ai_suggestion}</pre>
            {row.ai_suggested_at ? (
              <div className="mt-1 text-[11px] text-muted-foreground">
                Generálva: {new Date(row.ai_suggested_at).toLocaleString("hu-HU")}
              </div>
            ) : null}
          </>
        ) : (
          <div className="mt-2 text-sm text-muted-foreground">
            Még nincs javaslat. Kattintson az "Elemzés indítása" gombra.
          </div>
        )}
      </div>
    </div>
  );
}

function Field({
  label,
  value,
  mono,
  pre,
}: {
  label: string;
  value: string | null | undefined;
  mono?: boolean;
  pre?: boolean;
}) {
  const Wrapper = pre ? "pre" : "div";
  return (
    <div>
      <div className="text-xs font-medium text-muted-foreground">{label}</div>
      <Wrapper
        className={`text-sm ${mono ? "font-mono" : ""} ${pre ? "whitespace-pre-wrap break-all bg-muted rounded p-2 mt-1" : ""}`}
      >
        {value || "—"}
      </Wrapper>
    </div>
  );
}
