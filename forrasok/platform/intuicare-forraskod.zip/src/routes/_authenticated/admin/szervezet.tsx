import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import { supabase } from "@/integrations/supabase/client";

import { toast } from "sonner";
import { humanizeError } from "@/lib/humanize-error";
import { applyReason } from "@/lib/audit-reason";
import { ReasonInput } from "@/components/reason-input";
import {
  Building2,
  MapPin,
  Hospital,
  ChevronRight,
  ChevronDown,
  Plus,
  Pencil,
  Trash2,
  GripVertical,
  X,
  Check,
  Settings2,
  Sparkles,
  AlertTriangle,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { UnitPropertiesDialog, type UnitTipus, type Uzemmod } from "@/components/szervezet/unit-properties-dialog";
import { SiteDutyPanel } from "@/components/szervezet/site-duty-panel";

export const Route = createFileRoute("/_authenticated/admin/szervezet")({
  component: SzervezetPage,
});

type Clinic = { id: string; nev: string; aktiv: boolean };
type Site = { id: string; clinic_id: string; nev: string; cim: string | null; aktiv: boolean };
type OrgUnitTipus = "fekvobeteg_osztaly" | "rendelo" | "ambulancia" | "muto" | "kismuto" | "ito" | "pito" | "egynapos" | "egyeb";
type OrgUnit = {
  id: string;
  site_id: string;
  parent_id: string | null;
  nev: string;
  tipus: OrgUnitTipus;
  aktiv: boolean;
  uzemmod: Uzemmod | null;
  unnepnap_uzemel: boolean;
  agyszam: number | null;
  muto_blokk_perc: number | null;
  floor_id: string | null;
};
type Floor = { id: string; site_id: string; tenant_id: string; szint: string; megnevezes: string | null; sorrend: number; aktiv: boolean };

type DragPayload =
  | { kind: "site"; id: string; clinic_id: string }
  | { kind: "org_unit"; id: string; site_id: string; parent_id: string | null };

const TIPUS_LABELS: Record<OrgUnitTipus, { hu: string; en: string }> = {
  fekvobeteg_osztaly: { hu: "Fekvőbeteg osztály", en: "Inpatient ward" },
  rendelo: { hu: "Rendelő", en: "Office" },
  ambulancia: { hu: "Ambulancia", en: "Ambulatory" },
  muto: { hu: "Műtő", en: "OR" },
  kismuto: { hu: "Kisműtő", en: "Minor OR" },
  ito: { hu: "ITO", en: "ICU" },
  pito: { hu: "PITO", en: "PICU" },
  egynapos: { hu: "1-napos sebészet", en: "Day surgery" },
  egyeb: { hu: "Egyéb", en: "Other" },
};

function SzervezetPage() {
  const { t, i18n } = useTranslation();
  const lang = i18n.language?.startsWith("en") ? "en" : "hu";
  const [clinics, setClinics] = useState<Clinic[]>([]);
  const [sites, setSites] = useState<Site[]>([]);
  const [orgUnits, setOrgUnits] = useState<OrgUnit[]>([]);
  const [floors, setFloors] = useState<Floor[]>([]);
  const [loading, setLoading] = useState(true);
  const [tenantId, setTenantId] = useState<string | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [conflicts, setConflicts] = useState<Record<string, { duty_lines_count: number; mandatory_coverage_count: number; duty_lines_without_eligibility: number }>>({});
  const [seeding, setSeeding] = useState(false);
  const [reason, setReason] = useState("");
  const reasonRef = useRef(reason);
  reasonRef.current = reason;
  const [dialogState, setDialogState] = useState<{
    open: boolean;
    mode: "create" | "edit";
    site_id: string;
    parent_id: string | null;
    unit?: OrgUnit;
  } | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;
    const { data: prof } = await supabase
      .from("profiles")
      .select("tenant_id")
      .eq("id", user.id)
      .maybeSingle();
    setTenantId(prof?.tenant_id ?? null);
    const { data: admin } = await supabase.rpc("has_permission", {
      _user_id: user.id,
      _perm: "manage_org",
    });
    setIsAdmin(Boolean(admin));
    const [{ data: c }, { data: s }, { data: o }, { data: f }, { data: cf }] = await Promise.all([
      supabase.from("clinics").select("id,nev,aktiv").order("nev"),
      supabase.from("sites").select("id,clinic_id,nev,cim,aktiv").order("nev"),
      supabase
        .from("org_units")
        .select("id,site_id,parent_id,nev,tipus,aktiv,uzemmod,unnepnap_uzemel,agyszam,muto_blokk_perc,floor_id")
        .order("nev"),
      supabase.from("floors").select("id,site_id,tenant_id,szint,megnevezes,sorrend,aktiv").order("sorrend"),
      (supabase as any).from("org_unit_conflicts").select("*"),
    ]);
    setClinics((c ?? []) as Clinic[]);
    setSites((s ?? []) as Site[]);
    setOrgUnits((o ?? []) as OrgUnit[]);
    setFloors((f ?? []) as Floor[]);
    const cmap: Record<string, any> = {};
    (cf ?? []).forEach((row: any) => { cmap[row.org_unit_id] = row; });
    setConflicts(cmap);
    setLoading(false);
  }, []);

  async function runSeed() {
    if (!tenantId) return;
    setSeeding(true);
    const { data, error } = await (supabase as any).rpc("seed_default_org_for_tenant", { _tenant_id: tenantId });
    setSeeding(false);
    if (error) return toast.error(humanizeError(error, t, { perm: "manage_tenant" }));
    if (data?.ok === false) return toast.warning("Már van klinika a tenant-ben — a sablon kihagyva.");
    toast.success("Minta szervezet létrehozva: 1 klinika, 1 telephely, 3 szint, 2 ellátóhely, 3 ügyeleti sor.");
    load();
  }

  useEffect(() => {
    load();
  }, [load]);

  // ---------- mutations ----------
  async function addClinic() {
    const nev = window.prompt(t("szervezet.new_clinic_name") ?? "Klinika neve");
    if (!nev || !tenantId) return;
    const { data, error } = await supabase
      .from("clinics")
      .insert({ tenant_id: tenantId, nev })
      .select("id")
      .maybeSingle();
    if (error) return toast.error(humanizeError(error, t, { perm: "manage_org" }));
    await applyReason("clinics", data?.id, reasonRef.current);
    toast.success(t("szervezet.created"));
    load();
  }
  async function renameClinic(c: Clinic) {
    const nev = window.prompt(t("szervezet.rename") ?? "Új név", c.nev);
    if (!nev || nev === c.nev) return;
    const { error } = await supabase.from("clinics").update({ nev }).eq("id", c.id);
    if (error) return toast.error(humanizeError(error, t, { perm: "manage_org" }));
    await applyReason("clinics", c.id, reasonRef.current);
    load();
  }
  async function deleteClinic(c: Clinic) {
    if (!window.confirm(`${t("szervezet.confirm_delete")} ${c.nev}?`)) return;
    const { error } = await supabase.from("clinics").delete().eq("id", c.id);
    if (error) return toast.error(humanizeError(error, t, { perm: "manage_org" }));
    await applyReason("clinics", c.id, reasonRef.current);
    toast.success(t("szervezet.deleted"));
    load();
  }
  async function addSite(clinic: Clinic) {
    const nev = window.prompt(t("szervezet.new_site_name") ?? "Telephely neve");
    if (!nev || !tenantId) return;
    const { data, error } = await supabase
      .from("sites")
      .insert({ tenant_id: tenantId, clinic_id: clinic.id, nev })
      .select("id")
      .maybeSingle();
    if (error) return toast.error(humanizeError(error, t, { perm: "manage_org" }));
    await applyReason("sites", data?.id, reasonRef.current);
    load();
  }
  async function renameSite(s: Site) {
    const nev = window.prompt(t("szervezet.rename") ?? "Új név", s.nev);
    if (!nev || nev === s.nev) return;
    const { error } = await supabase.from("sites").update({ nev }).eq("id", s.id);
    if (error) return toast.error(humanizeError(error, t, { perm: "manage_org" }));
    await applyReason("sites", s.id, reasonRef.current);
    load();
  }
  async function deleteSite(s: Site) {
    if (!window.confirm(`${t("szervezet.confirm_delete")} ${s.nev}?`)) return;
    const { error } = await supabase.from("sites").delete().eq("id", s.id);
    if (error) return toast.error(humanizeError(error, t, { perm: "manage_org" }));
    await applyReason("sites", s.id, reasonRef.current);
    load();
  }
  function addOrgUnit(site: Site, parent: OrgUnit | null) {
    if (!tenantId) return;
    setDialogState({ open: true, mode: "create", site_id: site.id, parent_id: parent?.id ?? null });
  }
  function editOrgUnit(u: OrgUnit) {
    setDialogState({ open: true, mode: "edit", site_id: u.site_id, parent_id: u.parent_id, unit: u });
  }
  async function renameOrgUnit(u: OrgUnit) {
    const nev = window.prompt(t("szervezet.rename") ?? "Új név", u.nev);
    if (!nev || nev === u.nev) return;
    const { error } = await supabase.from("org_units").update({ nev }).eq("id", u.id);
    if (error) return toast.error(humanizeError(error, t, { perm: "manage_org" }));
    await applyReason("org_units", u.id, reasonRef.current);
    load();
  }
  async function deleteOrgUnit(u: OrgUnit) {
    if (!window.confirm(`${t("szervezet.confirm_delete")} ${u.nev}?`)) return;
    const { error } = await supabase.from("org_units").delete().eq("id", u.id);
    if (error) return toast.error(humanizeError(error, t, { perm: "manage_org" }));
    await applyReason("org_units", u.id, reasonRef.current);
    load();
  }

  // ---------- drag-and-drop ----------
  async function moveSiteToClinic(siteId: string, clinicId: string) {
    const s = sites.find((x) => x.id === siteId);
    if (!s || s.clinic_id === clinicId) return;
    const { error } = await supabase.from("sites").update({ clinic_id: clinicId }).eq("id", siteId);
    if (error) return toast.error(humanizeError(error, t, { perm: "manage_org" }));
    await applyReason("sites", siteId, reasonRef.current);
    toast.success(t("szervezet.moved"));
    load();
  }
  async function moveOrgUnit(unitId: string, target: { site_id: string; parent_id: string | null }) {
    const u = orgUnits.find((x) => x.id === unitId);
    if (!u) return;
    const isDescendant = (anc: string, candidate: string | null): boolean => {
      if (!candidate) return false;
      if (candidate === anc) return true;
      const p = orgUnits.find((x) => x.id === candidate)?.parent_id ?? null;
      return isDescendant(anc, p);
    };
    if (target.parent_id && isDescendant(unitId, target.parent_id)) {
      toast.error(t("szervezet.cycle"));
      return;
    }
    if (u.site_id === target.site_id && u.parent_id === target.parent_id) return;
    const { error } = await supabase
      .from("org_units")
      .update({ site_id: target.site_id, parent_id: target.parent_id })
      .eq("id", unitId);
    if (error) return toast.error(humanizeError(error, t, { perm: "manage_org" }));
    await applyReason("org_units", unitId, reasonRef.current);
    toast.success(t("szervezet.moved"));
    load();
  }

  return (
      <div className="p-8 max-w-7xl mx-auto">
        <div className="mb-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Building2 className="size-6 text-primary" />
            <div>
              <h1 className="text-2xl font-bold tracking-tight">{t("szervezet.title")}</h1>
              <p className="text-sm text-muted-foreground font-mono uppercase tracking-wider">
                {t("szervezet.subtitle")}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <a href="/admin/szervezet-sugo" className="text-xs underline text-muted-foreground hover:text-foreground">
              kézikönyv ↗
            </a>
            {isAdmin && (
              <button
                type="button"
                onClick={addClinic}
                className="inline-flex items-center gap-1.5 px-3 py-2 bg-primary text-primary-foreground rounded-lg text-xs font-mono font-semibold uppercase hover:bg-primary/90"
              >
                <Plus className="size-3.5" />
                {t("szervezet.add_clinic")}
              </button>
            )}
          </div>
        </div>

        <div className="mb-4 p-3 rounded-lg border border-primary/20 bg-primary/5 text-xs text-muted-foreground">
          <b className="text-foreground">Hierarchia:</b> Klinika → Telephely → Ellátóhely (fa). A telephely soron kívül láthatod a <i>Szintek & ügyeleti sorok</i> panelt; közös műtőhöz több klinika köthető az ellátóhely tulajdonságainál.
        </div>

        {!isAdmin && !loading && (
          <div className="mb-4 p-3 rounded-lg border border-warning/30 bg-warning/10 text-sm">
            {t("szervezet.no_admin")}
          </div>
        )}

        {isAdmin && (
          <div className="mb-4">
            <ReasonInput value={reason} onChange={setReason} />
          </div>
        )}

        {!tenantId && !loading && (
          <div className="mb-4 p-3 rounded-lg border border-warning/30 bg-warning/10 text-sm">
            {t("szervezet.no_tenant")}
          </div>
        )}

        {/* Konfliktus-összesítő */}
        {!loading && clinics.length > 0 && (() => {
          const totals = Object.values(conflicts).reduce(
            (a, c) => ({ noElig: a.noElig + c.duty_lines_without_eligibility, mand: a.mand + c.mandatory_coverage_count }),
            { noElig: 0, mand: 0 }
          );
          if (totals.noElig === 0) return null;
          return (
            <div className="mb-4 p-3 rounded-lg border border-warning/40 bg-warning/10 text-sm flex items-start gap-2">
              <AlertTriangle className="size-4 mt-0.5 text-warning shrink-0" />
              <div>
                <b>{totals.noElig} ügyeleti sornak nincs eligibility-szabálya.</b> A beosztómotor ezekhez bárkit beoszthat — érdemes a sorhoz foglalkozást, munkakört vagy konkrét személyeket rendelni.
              </div>
            </div>
          );
        })()}

        {loading ? (
          <div className="p-8 text-center text-sm text-muted-foreground">{t("common.loading")}</div>
        ) : clinics.length === 0 ? (
          <div className="p-12 text-center bg-card border border-dashed border-border rounded-2xl space-y-4">
            <Hospital className="size-10 mx-auto text-muted-foreground" />
            <p className="text-sm text-muted-foreground">{t("szervezet.empty")}</p>
            {isAdmin && tenantId && (
              <div className="space-y-2">
                <button
                  type="button"
                  disabled={seeding}
                  onClick={runSeed}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 disabled:opacity-50"
                >
                  <Sparkles className="size-4" />
                  {seeding ? "Létrehozás…" : "Minta szervezet létrehozása"}
                </button>
                <p className="text-[11px] text-muted-foreground max-w-md mx-auto">
                  Egy kattintással létrejön egy minta klinika + telephely 3 szinttel, 1 fekvőbeteg osztály + 1 műtő, és 3 ügyeleti sor (nappali, éjszakai, háttér) példa-konfiggal. Utána szabadon szerkesztheted.
                </p>
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-3">
            {clinics.map((c) => (
              <ClinicCard
                key={c.id}
                clinic={c}
                sites={sites.filter((s) => s.clinic_id === c.id)}
                allOrgUnits={orgUnits}
                floors={floors}
                tenantId={tenantId}
                lang={lang}
                isAdmin={isAdmin}
                onAddSite={() => addSite(c)}
                onRenameClinic={() => renameClinic(c)}
                onDeleteClinic={() => deleteClinic(c)}
                onRenameSite={renameSite}
                onDeleteSite={deleteSite}
                onAddOrgUnit={addOrgUnit}
                onRenameOrgUnit={renameOrgUnit}
                onEditOrgUnit={editOrgUnit}
                onDeleteOrgUnit={deleteOrgUnit}
                onMoveSite={moveSiteToClinic}
                onMoveOrgUnit={moveOrgUnit}
              />
            ))}
          </div>
        )}

        <p className="mt-6 text-[10px] font-mono uppercase text-muted-foreground">
          {t("szervezet.dnd_hint")}
        </p>

        {dialogState && tenantId && (
          <UnitPropertiesDialog
            open={dialogState.open}
            onOpenChange={(o) => setDialogState((s) => (s ? { ...s, open: o } : s))}
            mode={dialogState.mode}
            initial={{
              id: dialogState.unit?.id,
              site_id: dialogState.site_id,
              parent_id: dialogState.parent_id,
              tenant_id: tenantId,
              nev: dialogState.unit?.nev,
              tipus: dialogState.unit?.tipus as UnitTipus | undefined,
              uzemmod: dialogState.unit?.uzemmod ?? null,
              unnepnap_uzemel: dialogState.unit?.unnepnap_uzemel ?? false,
              agyszam: dialogState.unit?.agyszam ?? null,
              muto_blokk_perc: dialogState.unit?.muto_blokk_perc ?? null,
              floor_id: dialogState.unit?.floor_id ?? null,
            }}
            floors={floors.filter((f) => f.site_id === dialogState.site_id)}
            onSaved={load}
          />
        )}
      </div>
  );
}

// ============ Clinic ============
function ClinicCard(props: {
  clinic: Clinic;
  sites: Site[];
  allOrgUnits: OrgUnit[];
  floors: Floor[];
  tenantId: string | null;
  lang: "hu" | "en";
  isAdmin: boolean;
  onAddSite: () => void;
  onRenameClinic: () => void;
  onDeleteClinic: () => void;
  onRenameSite: (s: Site) => void;
  onDeleteSite: (s: Site) => void;
  onAddOrgUnit: (s: Site, parent: OrgUnit | null) => void;
  onRenameOrgUnit: (u: OrgUnit) => void;
  onEditOrgUnit: (u: OrgUnit) => void;
  onDeleteOrgUnit: (u: OrgUnit) => void;
  onMoveSite: (siteId: string, clinicId: string) => void;
  onMoveOrgUnit: (unitId: string, target: { site_id: string; parent_id: string | null }) => void;
}) {
  const { t } = useTranslation();
  const { clinic, sites, isAdmin } = props;
  const [hover, setHover] = useState(false);
  const [open, setOpen] = useState(true);

  function onDragOver(e: React.DragEvent) {
    const dt = e.dataTransfer.types;
    if (dt.includes("application/x-site")) {
      e.preventDefault();
      setHover(true);
    }
  }
  function onDrop(e: React.DragEvent) {
    setHover(false);
    const raw = e.dataTransfer.getData("application/x-site");
    if (!raw) return;
    const payload = JSON.parse(raw) as DragPayload;
    if (payload.kind === "site") props.onMoveSite(payload.id, clinic.id);
  }

  return (
    <div
      onDragOver={onDragOver}
      onDragLeave={() => setHover(false)}
      onDrop={onDrop}
      className={cn(
        "bg-card border-2 rounded-2xl transition-colors",
        hover ? "border-primary" : "border-border",
      )}
    >
      <div className="p-4 flex items-center justify-between">
        <button
          type="button"
          onClick={() => setOpen(!open)}
          className="flex items-center gap-2 flex-1 text-left"
        >
          {open ? <ChevronDown className="size-4" /> : <ChevronRight className="size-4" />}
          <Hospital className="size-5 text-primary" />
          <div>
            <div className="font-bold text-base">{clinic.nev}</div>
            <div className="text-[10px] font-mono uppercase text-muted-foreground">
              {sites.length} {t("szervezet.sites_count")}
            </div>
          </div>
        </button>
        {isAdmin && (
          <div className="flex items-center gap-1">
            <IconBtn icon={Plus} label={t("szervezet.add_site")} onClick={props.onAddSite} />
            <IconBtn icon={Pencil} label={t("common.edit")} onClick={props.onRenameClinic} />
            <IconBtn
              icon={Trash2}
              label={t("common.delete")}
              danger
              onClick={props.onDeleteClinic}
            />
          </div>
        )}
      </div>
      {open && (
        <div className="px-4 pb-4 pl-10 space-y-2">
          {sites.length === 0 ? (
            <div className="p-4 text-xs text-muted-foreground italic">
              {t("szervezet.no_sites")}
            </div>
          ) : (
            sites.map((s) => (
              <SiteCard
                key={s.id}
                site={s}
                rootUnits={props.allOrgUnits.filter(
                  (u) => u.site_id === s.id && u.parent_id === null,
                )}
                allOrgUnits={props.allOrgUnits}
                floors={props.floors.filter((f) => f.site_id === s.id)}
                tenantId={props.tenantId}
                lang={props.lang}
                isAdmin={isAdmin}
                onRename={() => props.onRenameSite(s)}
                onDelete={() => props.onDeleteSite(s)}
                onAddOrgUnit={(parent) => props.onAddOrgUnit(s, parent)}
                onRenameOrgUnit={props.onRenameOrgUnit}
                onEditOrgUnit={props.onEditOrgUnit}
                onDeleteOrgUnit={props.onDeleteOrgUnit}
                onMoveOrgUnit={props.onMoveOrgUnit}
              />
            ))
          )}
        </div>
      )}
    </div>
  );
}

// ============ Site ============
function SiteCard(props: {
  site: Site;
  rootUnits: OrgUnit[];
  allOrgUnits: OrgUnit[];
  floors: Floor[];
  tenantId: string | null;
  lang: "hu" | "en";
  isAdmin: boolean;
  onRename: () => void;
  onDelete: () => void;
  onAddOrgUnit: (parent: OrgUnit | null) => void;
  onRenameOrgUnit: (u: OrgUnit) => void;
  onEditOrgUnit: (u: OrgUnit) => void;
  onDeleteOrgUnit: (u: OrgUnit) => void;
  onMoveOrgUnit: (unitId: string, target: { site_id: string; parent_id: string | null }) => void;
}) {
  const { t } = useTranslation();
  const { site, rootUnits, isAdmin } = props;
  const [hover, setHover] = useState(false);
  const [open, setOpen] = useState(true);

  function onDragStart(e: React.DragEvent) {
    const payload: DragPayload = { kind: "site", id: site.id, clinic_id: site.clinic_id };
    e.dataTransfer.setData("application/x-site", JSON.stringify(payload));
    e.dataTransfer.effectAllowed = "move";
  }
  function onDragOver(e: React.DragEvent) {
    if (e.dataTransfer.types.includes("application/x-org-unit")) {
      e.preventDefault();
      setHover(true);
    }
  }
  function onDrop(e: React.DragEvent) {
    setHover(false);
    const raw = e.dataTransfer.getData("application/x-org-unit");
    if (!raw) return;
    const payload = JSON.parse(raw) as DragPayload;
    if (payload.kind === "org_unit")
      props.onMoveOrgUnit(payload.id, { site_id: site.id, parent_id: null });
  }

  return (
    <div
      draggable={isAdmin}
      onDragStart={onDragStart}
      onDragOver={onDragOver}
      onDragLeave={() => setHover(false)}
      onDrop={onDrop}
      className={cn(
        "rounded-xl border-2 bg-secondary/30 transition-colors",
        hover ? "border-primary" : "border-border",
      )}
    >
      <div className="p-3 flex items-center gap-2">
        {isAdmin && <GripVertical className="size-4 text-muted-foreground cursor-grab shrink-0" />}
        <button
          type="button"
          onClick={() => setOpen(!open)}
          className="flex items-center gap-2 flex-1 text-left"
        >
          {open ? <ChevronDown className="size-4" /> : <ChevronRight className="size-4" />}
          <MapPin className="size-4 text-sky-600" />
          <div>
            <div className="font-semibold text-sm">{site.nev}</div>
            {site.cim && (
              <div className="text-[10px] font-mono text-muted-foreground">{site.cim}</div>
            )}
          </div>
        </button>
        {isAdmin && (
          <div className="flex items-center gap-1">
            <IconBtn
              icon={Plus}
              label={t("szervezet.add_unit")}
              onClick={() => props.onAddOrgUnit(null)}
            />
            <IconBtn icon={Pencil} label={t("common.edit")} onClick={props.onRename} />
            <IconBtn icon={Trash2} label={t("common.delete")} danger onClick={props.onDelete} />
          </div>
        )}
      </div>
      {open && (
        <div className="px-3 pb-3 pl-8 space-y-1.5">
          {rootUnits.length === 0 ? (
            <div className="p-3 text-xs text-muted-foreground italic">
              {t("szervezet.no_units")}
            </div>
          ) : (
            rootUnits.map((u) => (
              <OrgUnitNode
                key={u.id}
                unit={u}
                allOrgUnits={props.allOrgUnits}
                floors={props.floors}
                site={site}
                lang={props.lang}
                isAdmin={isAdmin}
                onAddChild={(parent) => props.onAddOrgUnit(parent)}
                onRename={props.onRenameOrgUnit}
                onEdit={props.onEditOrgUnit}
                onDelete={props.onDeleteOrgUnit}
                onMove={props.onMoveOrgUnit}
              />
            ))
          )}
          {props.tenantId && (
            <SiteDutyPanel
              siteId={site.id}
              tenantId={props.tenantId}
              isAdmin={isAdmin}
              orgUnits={props.allOrgUnits.filter((u) => u.site_id === site.id).map((u) => ({ id: u.id, nev: u.nev, tipus: u.tipus }))}
            />
          )}
        </div>
      )}
    </div>
  );
}

// ============ Org Unit (recursive) ============
function OrgUnitNode(props: {
  unit: OrgUnit;
  site: Site;
  allOrgUnits: OrgUnit[];
  floors: Floor[];
  lang: "hu" | "en";
  isAdmin: boolean;
  onAddChild: (parent: OrgUnit) => void;
  onRename: (u: OrgUnit) => void;
  onEdit: (u: OrgUnit) => void;
  onDelete: (u: OrgUnit) => void;
  onMove: (unitId: string, target: { site_id: string; parent_id: string | null }) => void;
}) {
  const { t } = useTranslation();
  const { unit, allOrgUnits, isAdmin } = props;
  const children = useMemo(
    () => allOrgUnits.filter((u) => u.parent_id === unit.id),
    [allOrgUnits, unit.id],
  );
  const [open, setOpen] = useState(true);
  const [hover, setHover] = useState(false);
  const floor = useMemo(
    () => props.floors.find((f) => f.id === unit.floor_id) ?? null,
    [props.floors, unit.floor_id],
  );

  function onDragStart(e: React.DragEvent) {
    e.stopPropagation();
    const payload: DragPayload = {
      kind: "org_unit",
      id: unit.id,
      site_id: unit.site_id,
      parent_id: unit.parent_id,
    };
    e.dataTransfer.setData("application/x-org-unit", JSON.stringify(payload));
    e.dataTransfer.effectAllowed = "move";
  }
  function onDragOver(e: React.DragEvent) {
    if (e.dataTransfer.types.includes("application/x-org-unit")) {
      e.preventDefault();
      e.stopPropagation();
      setHover(true);
    }
  }
  function onDrop(e: React.DragEvent) {
    e.stopPropagation();
    setHover(false);
    const raw = e.dataTransfer.getData("application/x-org-unit");
    if (!raw) return;
    const payload = JSON.parse(raw) as DragPayload;
    if (payload.kind === "org_unit" && payload.id !== unit.id) {
      props.onMove(payload.id, { site_id: unit.site_id, parent_id: unit.id });
    }
  }

  return (
    <div>
      <div
        draggable={isAdmin}
        onDragStart={onDragStart}
        onDragOver={onDragOver}
        onDragLeave={() => setHover(false)}
        onDrop={onDrop}
        className={cn(
          "group flex items-center gap-2 p-2 rounded-md border bg-card transition-colors",
          hover ? "border-primary bg-primary/5" : "border-border",
        )}
      >
        {isAdmin && (
          <GripVertical className="size-3.5 text-muted-foreground cursor-grab shrink-0" />
        )}
        <button
          type="button"
          onClick={() => setOpen(!open)}
          className="flex items-center gap-1.5 flex-1 text-left text-sm flex-wrap"
          disabled={children.length === 0}
        >
          {children.length > 0 ? (
            open ? (
              <ChevronDown className="size-3.5" />
            ) : (
              <ChevronRight className="size-3.5" />
            )
          ) : (
            <span className="inline-block size-3.5" />
          )}
          <span className="font-medium">{unit.nev}</span>
          <span className="px-1.5 py-0.5 rounded-full bg-secondary text-[9px] font-mono font-semibold uppercase">
            {TIPUS_LABELS[unit.tipus][props.lang]}
          </span>
          {unit.uzemmod && (
            <span className="px-1.5 py-0.5 rounded-full bg-sky-500/10 text-sky-700 dark:text-sky-300 text-[9px] font-mono uppercase">
              {unit.uzemmod}
            </span>
          )}
          {unit.unnepnap_uzemel && (
            <span className="px-1.5 py-0.5 rounded-full bg-amber-500/15 text-amber-700 dark:text-amber-300 text-[9px] font-mono uppercase">
              ünnepnap is
            </span>
          )}
          {floor && (
            <span className="px-1.5 py-0.5 rounded-full bg-secondary text-[9px] font-mono uppercase">
              {floor.szint}{floor.megnevezes ? ` · ${floor.megnevezes}` : ""}
            </span>
          )}
          {unit.agyszam != null && (
            <span className="text-[10px] text-muted-foreground">{unit.agyszam} ágy</span>
          )}
        </button>
        {isAdmin && (
          <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
            <IconBtn
              icon={Plus}
              label={t("szervezet.add_subunit")}
              small
              onClick={() => props.onAddChild(unit)}
            />
            <IconBtn
              icon={Settings2}
              label="Tulajdonságok"
              small
              onClick={() => props.onEdit(unit)}
            />
            <IconBtn
              icon={Pencil}
              label={t("common.edit")}
              small
              onClick={() => props.onRename(unit)}
            />
            <IconBtn
              icon={Trash2}
              label={t("common.delete")}
              small
              danger
              onClick={() => props.onDelete(unit)}
            />
          </div>
        )}
      </div>
      {open && children.length > 0 && (
        <div className="ml-5 mt-1 space-y-1 border-l border-border pl-3">
          {children.map((c) => (
            <OrgUnitNode key={c.id} {...props} unit={c} />
          ))}
        </div>
      )}
    </div>
  );
}

function IconBtn({
  icon: Icon,
  label,
  onClick,
  danger,
  small,
}: {
  icon: typeof Plus;
  label: string;
  onClick: () => void;
  danger?: boolean;
  small?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={label}
      title={label}
      className={cn(
        "rounded-md transition-colors",
        small ? "p-1" : "p-1.5",
        danger
          ? "text-muted-foreground hover:text-warning hover:bg-warning/10"
          : "text-muted-foreground hover:text-foreground hover:bg-secondary",
      )}
    >
      <Icon className={small ? "size-3" : "size-3.5"} />
    </button>
  );
}

// Avoid unused-import warning for Check/X (reserved for future inline editing)
void Check;
void X;
