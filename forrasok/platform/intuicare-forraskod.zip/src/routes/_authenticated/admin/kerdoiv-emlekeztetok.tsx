/**
 * Esemény-kötött automatikus kérdőív kiosztás + emlékeztető-bucketek beállítása.
 */
import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { ChevronLeft, Plus, Trash2, Pencil, AlertTriangle } from "lucide-react";
import {
  listEventTriggers, upsertEventTrigger, deleteEventTrigger,
} from "@/lib/questionnaires/questionnaires.functions";

type EventType = "appointment_created" | "appointment_scheduled" | "surgery_created" | "surgery_scheduled";
type Channel = "notification" | "push" | "email" | "sms";

const EVENT_LABEL: Record<EventType, string> = {
  appointment_created: "Időpont létrejött",
  appointment_scheduled: "Időpont megerősítve",
  surgery_created: "Műtét rögzítve",
  surgery_scheduled: "Műtét ütemezve",
};

function bucketLabel(n: number): string {
  return n < 0 ? `T${n}` : `T+${n}`;
}

function TriggerDialog({
  initial, onClose, onSaved,
}: {
  initial: any | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const fn = useServerFn(upsertEventTrigger);
  const [questionnaireId, setQid] = useState<string>(initial?.questionnaire_id ?? "");
  const [eventType, setEventType] = useState<EventType>(initial?.event_type ?? "appointment_created");
  const [dueOffset, setDueOffset] = useState<number>(initial?.due_offset_days ?? 7);
  const [buckets, setBuckets] = useState<string>(
    (initial?.reminder_buckets ?? [-7, -3, -1, 1, 3, 7]).join(", "),
  );
  const [channel, setChannel] = useState<Channel>(initial?.channel ?? "notification");
  const [active, setActive] = useState<boolean>(initial?.active ?? true);

  const questionnaires = useQuery({
    queryKey: ["questionnaires-active"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("questionnaires")
        .select("id, code, title")
        .eq("aktiv", true)
        .order("code");
      if (error) throw new Error(error.message);
      return data ?? [];
    },
  });

  const save = useMutation({
    mutationFn: async () => {
      const parsed = buckets.split(/[, ]+/).map((s) => Number(s.trim())).filter((n) => Number.isFinite(n));
      if (parsed.length === 0) throw new Error("Adj meg legalább egy bucket-et (pl. -7, -3, -1, 1, 3).");
      if (!questionnaireId) throw new Error("Kérdőív kötelező.");
      return fn({
        data: {
          id: initial?.id,
          questionnaire_id: questionnaireId,
          event_type: eventType,
          due_offset_days: dueOffset,
          reminder_buckets: parsed,
          channel,
          active,
        },
      });
    },
    onSuccess: () => { toast.success("Mentve"); onSaved(); onClose(); },
    onError: (e: any) => toast.error(e?.message ?? "Mentés sikertelen"),
  });

  return (
    <DialogContent className="max-w-lg">
      <DialogHeader><DialogTitle>{initial ? "Szabály szerkesztése" : "Új esemény-szabály"}</DialogTitle></DialogHeader>
      <div className="space-y-3">
        <div>
          <Label className="mb-1 block text-xs">Kérdőív</Label>
          <Select value={questionnaireId} onValueChange={setQid}>
            <SelectTrigger><SelectValue placeholder="Válassz…" /></SelectTrigger>
            <SelectContent>
              {(questionnaires.data ?? []).map((q: any) => (
                <SelectItem key={q.id} value={q.id}>{q.code} — {q.title}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label className="mb-1 block text-xs">Esemény típusa</Label>
          <Select value={eventType} onValueChange={(v) => setEventType(v as EventType)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {Object.entries(EVENT_LABEL).map(([k, v]) => (
                <SelectItem key={k} value={k}>{v}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label className="mb-1 block text-xs">Esedékesség nappal az esemény előtt</Label>
            <Input type="number" value={dueOffset} onChange={(e) => setDueOffset(Number(e.target.value))} />
            <p className="mt-1 text-xs text-muted-foreground">Pozitív = esemény előtt, 0 = az esemény napján.</p>
          </div>
          <div>
            <Label className="mb-1 block text-xs">Csatorna</Label>
            <Select value={channel} onValueChange={(v) => setChannel(v as Channel)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="notification">In-app értesítés</SelectItem>
                <SelectItem value="push">Push</SelectItem>
                <SelectItem value="email">E-mail</SelectItem>
                <SelectItem value="sms">SMS</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <div>
          <Label className="mb-1 block text-xs">Emlékeztető-bucketek (napok)</Label>
          <Input value={buckets} onChange={(e) => setBuckets(e.target.value)} placeholder="-7, -3, -1, 1, 3, 7" />
          <p className="mt-1 text-xs text-muted-foreground">
            Negatív szám = esedékesség előtt, pozitív = után. Az emlékeztetők addig ismétlődnek, amíg a kérdőív nincs kitöltve.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Switch checked={active} onCheckedChange={setActive} id="active" />
          <Label htmlFor="active">Aktív</Label>
        </div>
        <div className="flex justify-end gap-2 pt-2">
          <Button variant="ghost" onClick={onClose}>Mégse</Button>
          <Button onClick={() => save.mutate()} disabled={save.isPending}>Mentés</Button>
        </div>
      </div>
    </DialogContent>
  );
}

function EmlekeztetokPage() {
  const fn = useServerFn(listEventTriggers);
  const delFn = useServerFn(deleteEventTrigger);
  const qc = useQueryClient();
  const list = useQuery({ queryKey: ["event-triggers"], queryFn: () => fn(), retry: 2 });
  const [editing, setEditing] = useState<any | null>(null);
  const [open, setOpen] = useState(false);

  const del = useMutation({
    mutationFn: (id: string) => delFn({ data: { id } }),
    onSuccess: () => { toast.success("Törölve"); qc.invalidateQueries({ queryKey: ["event-triggers"] }); },
    onError: (e: any) => toast.error(e?.message ?? "Törlés sikertelen"),
  });

  const onSaved = () => qc.invalidateQueries({ queryKey: ["event-triggers"] });

  return (
    <main className="container mx-auto px-4 py-8">
      <header className="mb-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Link to="/admin/szervezet" className="text-sm text-primary hover:underline">
            <ChevronLeft className="inline h-4 w-4" /> Vissza
          </Link>
          <div>
            <h1 className="text-2xl font-bold">Kérdőív emlékeztetők & auto-kiosztás</h1>
            <p className="text-sm text-muted-foreground">
              Esemény-szabályok: új időpont / műtét esetén automatikus kiosztás és bucket-alapú ismétlődő emlékeztetők.
            </p>
          </div>
        </div>
        <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setEditing(null); }}>
          <DialogTrigger asChild>
            <Button onClick={() => { setEditing(null); setOpen(true); }}>
              <Plus className="mr-2 h-4 w-4" /> Új szabály
            </Button>
          </DialogTrigger>
          {open && <TriggerDialog initial={editing} onClose={() => { setOpen(false); setEditing(null); }} onSaved={onSaved} />}
        </Dialog>
      </header>

      {list.isLoading && <Skeleton className="h-64 w-full" />}
      {list.isError && (
        <Card className="border-destructive/40">
          <CardContent className="flex items-center gap-2 p-4 text-destructive">
            <AlertTriangle className="h-4 w-4" />
            <span className="text-sm">{(list.error as Error).message}</span>
          </CardContent>
        </Card>
      )}
      {list.data && list.data.length === 0 && (
        <Card><CardContent className="p-10 text-center text-sm text-muted-foreground">
          Még nincs szabály. Vegyél fel egyet, és új időpont/műtét esetén automatikusan kiosztásra kerül a kérdőív.
        </CardContent></Card>
      )}
      {list.data && list.data.length > 0 && (
        <Card>
          <CardHeader><CardTitle className="text-base">Szabályok</CardTitle></CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Kérdőív</TableHead>
                  <TableHead>Esemény</TableHead>
                  <TableHead>Esedékesség (nap)</TableHead>
                  <TableHead>Emlékeztető-bucketek</TableHead>
                  <TableHead>Csatorna</TableHead>
                  <TableHead>Aktív</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {list.data.map((r: any) => (
                  <TableRow key={r.id}>
                    <TableCell className="text-xs">
                      <div className="font-medium">{r.questionnaires?.code}</div>
                      <div className="text-muted-foreground">{r.questionnaires?.title}</div>
                    </TableCell>
                    <TableCell>{EVENT_LABEL[r.event_type as EventType] ?? r.event_type}</TableCell>
                    <TableCell className="font-mono">{r.due_offset_days >= 0 ? `T-${r.due_offset_days}` : `T+${-r.due_offset_days}`}</TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {(r.reminder_buckets ?? []).map((b: number) => (
                          <Badge key={b} variant={b < 0 ? "secondary" : "destructive"}>{bucketLabel(b)}</Badge>
                        ))}
                      </div>
                    </TableCell>
                    <TableCell><Badge variant="outline">{r.channel}</Badge></TableCell>
                    <TableCell>
                      <Badge variant={r.active ? "default" : "secondary"}>{r.active ? "igen" : "nem"}</Badge>
                    </TableCell>
                    <TableCell className="flex gap-1">
                      <Button size="sm" variant="ghost" onClick={() => { setEditing(r); setOpen(true); }}>
                        <Pencil className="h-3 w-3" />
                      </Button>
                      <Button size="sm" variant="ghost"
                        onClick={() => { if (confirm("Biztosan törlöd?")) del.mutate(r.id); }}>
                        <Trash2 className="h-3 w-3 text-destructive" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      <Card className="mt-6 bg-muted/30">
        <CardContent className="p-4 text-xs text-muted-foreground">
          <p className="mb-2 font-semibold text-foreground">Bucket-logika</p>
          <ul className="list-disc space-y-1 pl-4">
            <li>A napi cron (`questionnaire-cron`) minden nyitott hozzárendelést végignéz.</li>
            <li>Az esedékességhez képesti előjeles napszám alapján kiválasztja a legmagasabb még nem küldött bucketet.</li>
            <li>Egy bucket csatornánként pontosan egyszer megy ki; ugyanaz a kérdőív addig kap emlékeztetőt, amíg ki nincs töltve.</li>
            <li>Új időpont vagy műtét rögzítésekor a megfelelő szabály alapján automatikusan kiosztódik a kérdőív (duplikáció kizárva).</li>
          </ul>
        </CardContent>
      </Card>
    </main>
  );
}

export const Route = createFileRoute("/_authenticated/admin/kerdoiv-emlekeztetok")({
  component: EmlekeztetokPage,
});
