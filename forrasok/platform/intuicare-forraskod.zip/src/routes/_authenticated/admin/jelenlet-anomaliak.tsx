import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Loader2, AlertTriangle, Clock } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { usePermissions } from "@/hooks/use-permissions";
import { useTranslation } from "react-i18next";
import { humanizeError } from "@/lib/humanize-error";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/admin/jelenlet-anomaliak")({
  component: AnomaliesPage,
});

type Event = {
  id: string;
  user_id: string;
  esemeny_tipus: string;
  idopont: string;
  horgony_egyezes: boolean | null;
};

type Anomaly = {
  user_id: string;
  user_name: string;
  kind: "open_shift" | "missing_clockout" | "off_premises" | "duplicate";
  detail: string;
  ts: string;
};

const KIND_META: Record<Anomaly["kind"], { label: string; color: string }> = {
  open_shift: { label: "Túl hosszú nyitott műszak", color: "bg-amber-500/10 text-amber-700 border-amber-500/30" },
  missing_clockout: { label: "Hiányzó kijelentkezés", color: "bg-rose-500/10 text-rose-700 border-rose-500/30" },
  off_premises: { label: "Telephelyen kívül", color: "bg-orange-500/10 text-orange-700 border-orange-500/30" },
  duplicate: { label: "Duplikált bélyegzés", color: "bg-blue-500/10 text-blue-700 border-blue-500/30" },
};

function AnomaliesPage() {
  const { user } = useAuth();
  const { t } = useTranslation();
  const { can } = usePermissions();
  const isAdmin = can("manage_tenant") || can("manage_schedule");
  const [loading, setLoading] = useState(true);
  const [items, setItems] = useState<Anomaly[]>([]);
  const [days, setDays] = useState(7);

  useEffect(() => {
    if (!user || !isAdmin) {
      setLoading(false);
      return;
    }
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, isAdmin, days]);

  async function load() {
    setLoading(true);
    try {
      const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString();
      const [{ data: ev, error: evErr }, { data: pp }] = await Promise.all([
        supabase
          .from("attendance_events")
          .select("id,user_id,esemeny_tipus,idopont,horgony_egyezes")
          .gte("idopont", since)
          .order("idopont", { ascending: true }),
        supabase.from("profiles").select("id,teljes_nev"),
      ]);
      if (evErr) throw evErr;
      const nameMap = new Map<string, string>(
        (pp ?? []).map((p: { id: string; teljes_nev: string }) => [p.id, p.teljes_nev])
      );
      setItems(detect((ev ?? []) as Event[], nameMap));
    } catch (e) {
      toast.error(humanizeError(e as Error, t));
    } finally {
      setLoading(false);
    }
  }

  if (!isAdmin) return <div className="p-6 text-sm text-muted-foreground">Nincs jogosultság.</div>;
  if (loading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center gap-3">
        <AlertTriangle className="h-6 w-6 text-amber-600" />
        <div className="flex-1">
          <h1 className="text-2xl font-semibold">Bélyegzés-anomáliák</h1>
          <p className="text-sm text-muted-foreground">Automatikus szűrés a jelenléti eseményekből</p>
        </div>
        <label className="text-xs">Időablak (nap):
          <input type="number" min={1} max={90} value={days} onChange={(e) => setDays(Math.max(1, Math.min(90, parseInt(e.target.value) || 7)))}
            className="ml-2 w-16 rounded border bg-background px-2 py-1 text-xs" />
        </label>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        {(Object.keys(KIND_META) as Anomaly["kind"][]).map((k) => {
          const n = items.filter((i) => i.kind === k).length;
          return (
            <div key={k} className={cn("rounded border p-2 text-xs", KIND_META[k].color)}>
              <div className="font-mono font-semibold text-lg">{n}</div>
              <div>{KIND_META[k].label}</div>
            </div>
          );
        })}
      </div>

      <div className="rounded-lg border bg-card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/40 text-xs">
            <tr>
              <th className="px-3 py-2 text-left">Típus</th>
              <th className="px-3 py-2 text-left">Munkatárs</th>
              <th className="px-3 py-2 text-left">Részlet</th>
              <th className="px-3 py-2 text-left">Időpont</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {items.length === 0 && (
              <tr><td colSpan={4} className="px-3 py-6 text-center text-muted-foreground italic">Nincs anomália a megadott időszakban 🎉</td></tr>
            )}
            {items.map((a, i) => (
              <tr key={i}>
                <td className="px-3 py-1.5">
                  <span className={cn("px-2 py-0.5 rounded text-xs border", KIND_META[a.kind].color)}>{KIND_META[a.kind].label}</span>
                </td>
                <td className="px-3 py-1.5">{a.user_name}</td>
                <td className="px-3 py-1.5 text-xs text-muted-foreground">{a.detail}</td>
                <td className="px-3 py-1.5 font-mono text-xs"><Clock className="inline h-3 w-3 mr-1" />{new Date(a.ts).toLocaleString("hu-HU")}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

const MAX_OPEN_HOURS = 16;

function detect(events: Event[], names: Map<string, string>): Anomaly[] {
  const out: Anomaly[] = [];
  const byUser = new Map<string, Event[]>();
  for (const e of events) {
    const arr = byUser.get(e.user_id) ?? [];
    arr.push(e);
    byUser.set(e.user_id, arr);
  }
  const now = Date.now();
  for (const [uid, list] of byUser) {
    list.sort((a, b) => a.idopont.localeCompare(b.idopont));
    const name = names.get(uid) ?? uid.slice(0, 8);
    let openSince: Event | null = null;
    let lastTs = "";
    let lastType = "";
    for (const ev of list) {
      // off-premises
      if (ev.horgony_egyezes === false) {
        out.push({ user_id: uid, user_name: name, kind: "off_premises", detail: `${ev.esemeny_tipus} GPS-en kívül`, ts: ev.idopont });
      }
      // duplicates within 1 min
      if (lastTs && ev.esemeny_tipus === lastType && new Date(ev.idopont).getTime() - new Date(lastTs).getTime() < 60_000) {
        out.push({ user_id: uid, user_name: name, kind: "duplicate", detail: `${ev.esemeny_tipus} 1 percen belül`, ts: ev.idopont });
      }
      lastTs = ev.idopont;
      lastType = ev.esemeny_tipus;
      // open/close pairing
      if (ev.esemeny_tipus === "bejelentkezes") {
        if (openSince) {
          out.push({
            user_id: uid, user_name: name, kind: "missing_clockout",
            detail: `Nyitott shift (${openSince.idopont.slice(0, 16).replace("T", " ")}) nem zárult le új bejelentkezés előtt`,
            ts: openSince.idopont,
          });
        }
        openSince = ev;
      } else if (ev.esemeny_tipus === "kijelentkezes") {
        if (openSince) {
          const h = (new Date(ev.idopont).getTime() - new Date(openSince.idopont).getTime()) / 3_600_000;
          if (h > MAX_OPEN_HOURS) {
            out.push({ user_id: uid, user_name: name, kind: "open_shift", detail: `${h.toFixed(1)}h hosszú műszak`, ts: ev.idopont });
          }
          openSince = null;
        }
      }
    }
    // dangling open shift longer than MAX_OPEN_HOURS
    if (openSince) {
      const h = (now - new Date(openSince.idopont).getTime()) / 3_600_000;
      if (h > MAX_OPEN_HOURS) {
        out.push({
          user_id: uid, user_name: name, kind: "missing_clockout",
          detail: `${h.toFixed(1)}h óta nyitva — nincs kijelentkezés`,
          ts: openSince.idopont,
        });
      }
    }
  }
  return out.sort((a, b) => b.ts.localeCompare(a.ts));
}
