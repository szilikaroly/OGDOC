import { createFileRoute, Link } from "@tanstack/react-router";
import {
  BookOpen, Building2, Hospital, Layers, Shield, UserCheck, AlertTriangle,
  Users, Calendar, ArrowRight, HandHeart, Lightbulb,
} from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin/szervezet-sugo")({
  component: SugoPage,
});

function SugoPage() {
  return (
      <div className="p-8 max-w-4xl mx-auto">
        <div className="mb-6 flex items-center gap-3">
          <BookOpen className="size-6 text-primary" />
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Szervezet & ügyelet — kézikönyv</h1>
            <p className="text-sm text-muted-foreground font-mono uppercase tracking-wider">
              Hogyan épül fel az intézmény és hogyan generálódik az ügyeleti igény
            </p>
          </div>
        </div>

        <div className="space-y-6">
          <Section icon={Hospital} title="1. Hierarchia">
            <p>A struktúra három fő szinten épül fel:</p>
            <ul className="list-disc pl-5 space-y-1 text-sm">
              <li><b>Klinika</b> – jogi/szakmai egység (pl. „Aneszteziológiai és Intenzív Terápiás Klinika").</li>
              <li><b>Telephely</b> – fizikai épület/cím. Egy klinikának több telephelye is lehet.</li>
              <li><b>Ellátóhely</b> (org_unit) – konkrét osztály/műtő/ambulancia a telephelyen. Tetszőlegesen mélyen fa-struktúrába rendezhető (drag&drop a fán).</li>
            </ul>
          </Section>

          <Section icon={Layers} title="2. Szintek (emeletek)">
            <p>Telephelyenként rögzíthető a fizikai szintek listája (-1, 0, 1, tetőtér …). Az ellátóhely tulajdonságainál egy ellátóhely besorolható szintre — ez a betegútnál és az ügyeleti hívások logikájánál is segítség.</p>
          </Section>

          <Section icon={Building2} title="3. Ellátóhely-típus & üzemmód">
            <p>Az ellátóhely tulajdonságainál:</p>
            <ul className="list-disc pl-5 space-y-1 text-sm">
              <li><b>Típus</b>: <i>fekvőbeteg osztály, ITO, PITO, műtő, kisműtő, 1-napos sebészet, ambulancia, rendelő, egyéb</i>.</li>
              <li><b>Üzemmód</b>: <i>folyamatos 24/7, rendelési idő, programozott nappali, műtéti blokk</i>. Üresen hagyva a típus alapján automatikusan kerül kitöltésre.</li>
              <li><b>Ágyszám</b> osztályoknál, <b>műtéti blokk perc</b> műtőknél.</li>
              <li><b>Ünnepnapon üzemel</b> – a beosztómotor csak akkor generál ide igényt ünnepnapra, ha be van pipálva.</li>
            </ul>
          </Section>

          <Section icon={Hospital} title="4. Megosztott ellátóhely (közös műtő)">
            <p>Ha egy műtőt vagy egynapos sebészetet több klinika is használ, az ellátóhely tulajdonságainál a „Megosztó klinikák" listában jelölhető. Minden klinikához megadható a szerep:</p>
            <ul className="list-disc pl-5 space-y-1 text-sm">
              <li><b>Működtető</b> – aki üzemelteti / felel érte.</li>
              <li><b>Használó</b> – aki blokk-időt kap benne.</li>
            </ul>
          </Section>

          <Section icon={Shield} title="5. Ügyeleti sorok (telephely-szintű)">
            <p>Telephelyenként annyi ügyeleti sor hozható létre, ahányféle ügyeleti pozíciót szeretnél fenntartani. Példa konfiguráció (telephelyenként rugalmasan állítható):</p>
            <div className="bg-secondary/30 rounded-lg p-3 text-xs font-mono">
              <div>• Belgyógyászat nappali I. – nappali ügyelet, 2 fő, H–V, 08–20</div>
              <div>• Belgyógyászat éjszakai – éjszakai ügyelet, 1 fő, H–V, 20–08</div>
              <div>• Telephelyi háttér / műtéti – háttér-ügyelet, 1 fő, H–V, 0–24</div>
            </div>
            <p>Minden sornál beállítható: napok, kezdés/vég, létszám, ünnepnapi üzem, aktív/inaktív.</p>
            <p><b>Lefedett ellátóhelyek (coverage):</b> melyik osztályokon van jelen / hívható. A háttér-sor egyszerre több helyet is lefedhet (pl. „műtő is hívható").</p>
            <p><b>Ki ügyelhet (eligibility):</b> szűkíthető foglalkozás-típusra, munkakörre vagy konkrét személyre, prioritás szerint. Üres listánál mindenki alkalmas.</p>
          </Section>

          <Section icon={AlertTriangle} title="6. Kötelező ügyelet">
            <p>Három szabályrendszer együtt működik:</p>
            <ul className="list-disc pl-5 space-y-1 text-sm">
              <li><b>Havi minimum / fő</b> – szakorvosnak, rezidensnek stb. külön megadható (pl. szakorvos: min 4 ügyelet/hó).</li>
              <li><b>Kötelező lefedés / ellátóhely</b> – az ügyeleti sor coverage-sorai jelölik kötelezőnek (alapértelmezetten igen).</li>
              <li><b>Egyéni mentességek</b> – terhesség, gyermekgondozás, életkor, jogviszony, egészségügyi, egyéb. HR (tenant-admin) jogosultsággal jóváhagyandó; saját kérelmét senki nem hagyhatja jóvá.</li>
            </ul>
          </Section>

          <Section icon={Users} title="7. Létszámigény-sablonok">
            <p>Az osztály/műtő szintű napi szerepkör-igények (min/max fő szerepkörönként, sávonként). Ezeket a beosztómotor kombinálja az ügyeleti sorokkal.</p>
          </Section>

          <Section icon={Calendar} title="8. Beosztásmotor folyamat">
            <ol className="list-decimal pl-5 space-y-1 text-sm">
              <li>Időszak (pl. 1 hónap) választása.</li>
              <li><b>generate_duty_demand(site, from, to)</b> ledarálja az aktív ügyeleti sorokat napokra → kapunk napi várt ügyeleti pozíciókat.</li>
              <li><b>generate_demand_for_period(unit, from, to)</b> a sablonokból összeállítja a napi nem-ügyeleti igényt.</li>
              <li>A motor a két forrást egyesíti, alkalmazza a mentességeket, preferenciákat, képzettségeket, és kiosztja a műszakokat.</li>
              <li>Eredmény publikálása az érintettek értesítésével.</li>
            </ol>
          </Section>

          <Section icon={HandHeart} title="9. Önkéntes rendelkezésre állás (új)">
            <p>A dolgozók a karakterlapjuk <b>Rendelkezésre állás</b> fülén jelezhetik:</p>
            <ul className="list-disc pl-5 space-y-1 text-sm">
              <li><b>Tartalékos</b> – aznap nem dolgozik, de szükség esetén beosztható.</li>
              <li><b>Behívható</b> – otthonról adott időn belül beér.</li>
              <li><b>Szabad vagyok / vállalok</b> – önként vállal extra ügyeletet.</li>
            </ul>
            <p>A koordinátor pótlás során először az adott napra szabad vagyok / behívható jelzéseket kapja meg, csak utána generál körlevelet a tartalékosoknak.</p>
          </Section>

          <Section icon={Lightbulb} title="Lépésről-lépésre: első ügyeleti konfig egy új telephelyen">
            <ol className="list-decimal pl-5 space-y-2 text-sm">
              <li>
                <b>Klinika és telephely felvétele</b><br />
                <span className="text-muted-foreground">Szervezet → „+ Klinika" → név megadása → „+ Telephely" → cím megadása.</span>
              </li>
              <li>
                <b>Szintek rögzítése</b><br />
                <span className="text-muted-foreground">A telephely kártyájában „Szintek" panel → vegye fel a -1, 0, 1, 2 emeleteket sorrend szerint.</span>
              </li>
              <li>
                <b>Ellátóhelyek létrehozása</b><br />
                <span className="text-muted-foreground">Telephely fáján „+ Ellátóhely" → adja meg a típust (pl. <i>fekvőbeteg osztály</i>, <i>műtő</i>) → tulajdonságoknál szint, ágyszám / műtéti blokk perc, ünnepnapi üzem.</span>
              </li>
              <li>
                <b>Megosztott műtő</b> (ha van)<br />
                <span className="text-muted-foreground">A műtő tulajdonságainál „Megosztó klinikák" → vegye fel a klinikákat <i>működtető</i> / <i>használó</i> szereppel.</span>
              </li>
              <li>
                <b>Ügyeleti sorok</b> – példa: nappal 2 fő egy osztályon, éjjel 1 fő, + 1 telephelyi háttér<br />
                <ul className="list-disc pl-5 mt-1 space-y-0.5">
                  <li>„+ Ügyeleti sor" → név: <i>Belgyógyászat nappali</i>, szerep: <i>nappali_ugyelet</i>, létszám: <b>2</b>, napok: H–V, idő: 08:00–20:00.</li>
                  <li>„+ Ügyeleti sor" → név: <i>Belgyógyászat éjszakai</i>, szerep: <i>ejszakai_ugyelet</i>, létszám: <b>1</b>, idő: 20:00–08:00.</li>
                  <li>„+ Ügyeleti sor" → név: <i>Telephelyi háttér</i>, szerep: <i>hatter_ugyelet</i>, létszám: <b>1</b>, idő: 0–24.</li>
                </ul>
              </li>
              <li>
                <b>Lefedés (coverage)</b><br />
                <span className="text-muted-foreground">Minden ügyeleti sornál pipálja be, mely ellátóhelyeket fedi le. A „Telephelyi háttér"-nél jelölje be a műtőt is, hogy a háttérügyeletes oda is hívható legyen.</span>
              </li>
              <li>
                <b>Eligibility</b><br />
                <span className="text-muted-foreground">Az ügyeleti sor kibontva → „+ foglalkozás" pl. <i>orvos</i>; vagy „+ munkakör" pl. <i>szakorvos</i>; vagy „+ személy" konkrét névvel. Hagyja üresen, ha mindenki alkalmas.</span>
              </li>
              <li>
                <b>Kötelező ügyelet</b><br />
                <span className="text-muted-foreground">Admin → Kötelező ügyelet → új szabály: <i>foglalkozas_tipus</i> = orvos, <i>min</i> = 4 / hó. Mentességeket itt rögzítheti és HR (manage_tenant) hagyhatja jóvá.</span>
              </li>
              <li>
                <b>Próba generálás</b><br />
                <span className="text-muted-foreground">Beosztás → futtatás kiválasztott időszakra → ellenőrizze, hogy minden napra megjelenik-e a 2 nappali + 1 éjszakai + 1 háttér slot.</span>
              </li>
            </ol>
          </Section>

          <Section icon={Lightbulb} title="Lépésről-lépésre: egy dolgozó önként vállal extra ügyeletet">
            <ol className="list-decimal pl-5 space-y-1 text-sm">
              <li>Karakterlap → <b>Rendelkezésre állás</b> fül.</li>
              <li>„Szabad vagyok / vállalok" gomb.</li>
              <li>Napok megadása (vesszővel), opcionálisan idősáv, telephely vagy konkrét ügyeleti sor.</li>
              <li>Mentés → a koordinátor a pótlási felületen színes badge-dzsel látja, és egy kattintással beoszthatja.</li>
              <li>Lemondáshoz: „Visszavonom" gomb a sor mellett (a múltbeli rekordot is megőrizzük naplózás miatt).</li>
            </ol>
          </Section>

          <div className="grid grid-cols-2 gap-2 pt-2">
            <Link to="/admin/szervezet" className="bg-card border rounded-xl p-3 hover:border-primary flex items-center justify-between text-sm">
              <span className="flex items-center gap-2"><Building2 className="size-4" /> Szervezet</span>
              <ArrowRight className="size-4" />
            </Link>
            <Link to="/admin/kotelezo-ugyelet" className="bg-card border rounded-xl p-3 hover:border-primary flex items-center justify-between text-sm">
              <span className="flex items-center gap-2"><AlertTriangle className="size-4" /> Kötelező ügyelet</span>
              <ArrowRight className="size-4" />
            </Link>
            <Link to="/admin/letszam-igeny" className="bg-card border rounded-xl p-3 hover:border-primary flex items-center justify-between text-sm">
              <span className="flex items-center gap-2"><Users className="size-4" /> Létszámigény</span>
              <ArrowRight className="size-4" />
            </Link>
            <Link to="/karakterlap" className="bg-card border rounded-xl p-3 hover:border-primary flex items-center justify-between text-sm">
              <span className="flex items-center gap-2"><HandHeart className="size-4" /> Rendelkezésre állás</span>
              <ArrowRight className="size-4" />
            </Link>
            <Link to="/admin/potlas" className="bg-card border rounded-xl p-3 hover:border-primary flex items-center justify-between text-sm">
              <span className="flex items-center gap-2"><UserCheck className="size-4" /> Pótlás</span>
              <ArrowRight className="size-4" />
            </Link>
            <Link to="/admin/tulora-pool" className="bg-card border rounded-xl p-3 hover:border-primary flex items-center justify-between text-sm">
              <span className="flex items-center gap-2"><Lightbulb className="size-4" /> Túlóra-pool</span>
              <ArrowRight className="size-4" />
            </Link>
            <Link to="/admin/followup" className="bg-card border rounded-xl p-3 hover:border-primary flex items-center justify-between text-sm">
              <span className="flex items-center gap-2"><HandHeart className="size-4" /> Visszajelentő protokollok</span>
              <ArrowRight className="size-4" />
            </Link>
          </div>

          <Section icon={UserCheck} title="11. Pótlás (akut helyettesítés) — lépésről-lépésre">
            <ol className="list-decimal pl-5 space-y-1 text-sm">
              <li>Nyisd meg: <i>Admin ▸ Pótlás (helyettesítés)</i>.</li>
              <li>Válaszd ki a kieső dolgozót és a napot, majd kattints a <b>Pótlás keresése</b> gombra.</li>
              <li>A rendszer az adott nap műszakait listázza — válaszd ki, melyiket kell cserélni.</li>
              <li>A jelöltlista skill-egyezés, kapcsolati pontszám és aktív korlátozók szerint rangsorol. A zöld „szabad" jelű a legjobb választás.</li>
              <li>Kattints az <b>Áthelyezem</b>-re — a műszak átíródik, az audit naplóba kerül, és az új dolgozó in-app értesítést kap.</li>
            </ol>
          </Section>

          <Section icon={Lightbulb} title="12. Túlóra-pool és elrendelés — lépésről-lépésre">
            <p>A modul a <b>lépcsős kitöltés</b> elvét követi: 1) rendes kapacitás → 2) önkéntes pool → 3) elrendelt túlóra.</p>
            <ol className="list-decimal pl-5 space-y-1 text-sm">
              <li><b>Önkéntes pool</b>: a dolgozók a karakterlapjukon jelzik, ha vállalnak túlórát. A pool a <i>Túlóra-pool</i> oldalon látszik.</li>
              <li>Ha nincs elég önkéntes, a vezető a <b>Új elrendelés</b> gombbal túlórát rendelhet el — kötelező az indoklás és (528/2020 16. §) az írásos hivatkozás.</li>
              <li>A rendszer az éves 250 ó rendkívüli és 416 ó ügyelet+rendkívüli korlátot a karakterlap mérleg-widgetén jelzi.</li>
              <li>A dolgozó in-app értesítést kap (későbbi fázisban: email is).</li>
            </ol>
          </Section>
        </div>
      </div>
  );
}

function Section(props: { icon: React.ComponentType<{ className?: string }>; title: string; children: React.ReactNode }) {
  const Icon = props.icon;
  return (
    <section className="bg-card border rounded-2xl p-4 space-y-2">
      <h2 className="text-base font-bold flex items-center gap-2">
        <Icon className="size-5 text-primary" /> {props.title}
      </h2>
      <div className="text-sm text-muted-foreground space-y-2">{props.children}</div>
    </section>
  );
}
