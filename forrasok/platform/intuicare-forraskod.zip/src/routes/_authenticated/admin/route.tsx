import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";
import { classifyUser } from "@/lib/portal/user-classification.functions";

// Admin szekció guard: csak admin szerepkörrel rendelkező felhasználók léphetnek be.
// A szülő _authenticated route már gondoskodik a bejelentkezésről.
export const Route = createFileRoute("/_authenticated/admin")({
  ssr: false,
  beforeLoad: async ({ location }) => {
    try {
      const cls = await classifyUser();
      if (!cls.isAdmin) {
        throw redirect({
          to: "/unauthorized",
          search: { required: "admin", from: location.pathname } as any,
        });
      }
    } catch (e) {
      if ((e as any)?.isRedirect) throw e;
      throw redirect({
        to: "/unauthorized",
        search: { required: "admin", from: location.pathname } as any,
      });
    }
  },
  component: () => <Outlet />,
});
