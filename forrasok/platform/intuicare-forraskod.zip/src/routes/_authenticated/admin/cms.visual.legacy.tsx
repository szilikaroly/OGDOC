import { createFileRoute } from "@tanstack/react-router";
import { VisualEditor } from "@/components/cms/visual-editor";

export const Route = createFileRoute("/_authenticated/admin/cms/visual/legacy")({
  ssr: false,
  component: LegacyVisualEditorPage,
});

function LegacyVisualEditorPage() {
  return (
    <div className="container mx-auto py-3 sm:py-6 px-3 sm:px-6 lg:px-8 max-w-[1600px]">
      <header className="mb-3">
        <h1 className="text-xl sm:text-2xl font-bold">Klasszikus vizuális szerkesztő</h1>
        <p className="text-xs sm:text-sm text-muted-foreground">
          Iframe-előnézettel, JSON-szerkesztéssel. Az új szerkesztő blokk-szintű vázlatokkal dolgozik.
        </p>
      </header>
      <VisualEditor />
    </div>
  );
}
