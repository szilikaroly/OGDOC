import { createFileRoute, Outlet } from "@tanstack/react-router";

export const Route = createFileRoute("/_authenticated/admin/cms/visual")({
  ssr: false,
  component: () => <Outlet />,
});

