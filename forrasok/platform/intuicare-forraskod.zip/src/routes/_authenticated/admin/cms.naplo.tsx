import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { listAuditTrail, WORKFLOW_ENTITIES } from "@/lib/cms/workflow.functions";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";

const ACTIONS = [
  "create", "update", "delete",
  "submit_review", "approve", "reject",
  "publish", "unpublish", "revert", "restore",
];

const ACTION_LABEL: Record<string, string> = {
  create: "Létrehozás", update: "Módosítás", delete: "Törlés",
  submit_review: "Beküldés", approve: "Jóváhagyás", reject: "Elutasítás",
  publish: "Publikálás", unpublish: "Visszavonás", revert: "Visszaállítás", restore: "Helyreállítás",
};

export const Route = createFileRoute("/_authenticated/admin/cms/naplo")({
  ssr: false,
  component: AuditLogPage,
});

function AuditLogPage() {
  const listFn = useServerFn(listAuditTrail);
  const [entityType, setEntityType] = useState<string>("");
  const [action, setAction] = useState<string>("");
  const [email, setEmail] = useState<string>("");
  const [emailQ, setEmailQ] = useState<string>("");
  const [from, setFrom] = useState<string>("");
  const [to, setTo] = useState<string>("");
  const [page, setPage] = useState(1);
  const limit = 50;

  const fromIso = from ? new Date(from).toISOString() : undefined;
  const toIso = to ? new Date(to + "T23:59:59").toISOString() : undefined;

  const { data, isLoading } = useQuery({
    queryKey: ["audit-log", entityType, action, emailQ, fromIso, toIso, page],
    queryFn: () => listFn({
      data: {
        entity_type: (entityType || undefined) as any,
        action: action || undefined,
        actor_email: emailQ || undefined,
        from: fromIso,
        to: toIso,
        limit, offset: (page - 1) * limit,
      },
    }),
  });

  const rows = data?.rows ?? [];
  const total = data?.total ?? 0;
  const pages = Math.max(1, Math.ceil(total / limit));

  function exportCsv() {
    const head = ["created_at", "entity_type", "entity_id", "action", "actor_email", "comment"].join(",");
    const lines = rows.map((r: any) => [
      r.created_at, r.entity_type, r.entity_id, r.action,
      JSON.stringify(r.actor_email ?? ""), JSON.stringify(r.comment ?? ""),
    ].join(","));
    const blob = new Blob([head + "\n" + lines.join("\n")], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `cms-audit-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  function resetFilters() {
    setEntityType(""); setAction(""); setEmail(""); setEmailQ("");
    setFrom(""); setTo(""); setPage(1);
  }

  return (
    <div className="container mx-auto py-4 sm:py-8 px-3 sm:px-6 lg:px-8 max-w-6xl">
      <header className="mb-4 flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold">CMS audit napló</h1>
          <p className="text-muted-foreground text-sm mt-1">Minden tartalom-módosítás, jóváhagyás és publikálás teljes naplója.</p>
        </div>
        <Button variant="outline" onClick={exportCsv} disabled={rows.length === 0}>CSV export</Button>
      </header>

      <div className="flex flex-wrap items-end gap-2 mb-4">
        <Select value={entityType || "__all"} onValueChange={(v) => { setPage(1); setEntityType(v === "__all" ? "" : v); }}>
          <SelectTrigger className="w-[180px]"><SelectValue placeholder="Típus" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="__all">Összes típus</SelectItem>
            {WORKFLOW_ENTITIES.map((t) => (
              <SelectItem key={t} value={t}>{t}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={action || "__all"} onValueChange={(v) => { setPage(1); setAction(v === "__all" ? "" : v); }}>
          <SelectTrigger className="w-[180px]"><SelectValue placeholder="Művelet" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="__all">Összes művelet</SelectItem>
            {ACTIONS.map((a) => (
              <SelectItem key={a} value={a}>{ACTION_LABEL[a]}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <form
          className="flex gap-1"
          onSubmit={(e) => { e.preventDefault(); setPage(1); setEmailQ(email.trim()); }}
        >
          <Input
            type="search"
            placeholder="Felhasználó e-mail…"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-[200px]"
          />
          <Button type="submit" variant="outline" size="sm">Keres</Button>
        </form>
        <div className="flex items-center gap-1">
          <label className="text-xs text-muted-foreground">Tól</label>
          <Input type="date" value={from} onChange={(e) => { setPage(1); setFrom(e.target.value); }} className="w-[150px]" />
        </div>
        <div className="flex items-center gap-1">
          <label className="text-xs text-muted-foreground">Ig</label>
          <Input type="date" value={to} onChange={(e) => { setPage(1); setTo(e.target.value); }} className="w-[150px]" />
        </div>
        {(entityType || action || emailQ || from || to) && (
          <Button variant="ghost" size="sm" onClick={resetFilters}>Szűrők törlése</Button>
        )}
      </div>

      {isLoading ? (
        <p className="text-muted-foreground">Betöltés…</p>
      ) : rows.length === 0 ? (
        <p className="text-muted-foreground">Nincs naplóbejegyzés.</p>
      ) : (
        <div className="border rounded-lg overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50">
              <tr className="text-left">
                <th className="px-3 py-2">Időpont</th>
                <th className="px-3 py-2">Típus</th>
                <th className="px-3 py-2">Művelet</th>
                <th className="px-3 py-2">Szerző</th>
                <th className="px-3 py-2">Entity</th>
                <th className="px-3 py-2">Megjegyzés</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r: any) => (
                <tr key={r.id} className="border-t">
                  <td className="px-3 py-2 whitespace-nowrap text-xs">{new Date(r.created_at).toLocaleString("hu-HU")}</td>
                  <td className="px-3 py-2 text-xs">{r.entity_type}</td>
                  <td className="px-3 py-2"><Badge variant="secondary">{ACTION_LABEL[r.action] ?? r.action}</Badge></td>
                  <td className="px-3 py-2 text-xs">{r.actor_email ?? "—"}</td>
                  <td className="px-3 py-2 text-xs font-mono break-all">{r.entity_slug ?? r.entity_id}</td>
                  <td className="px-3 py-2 text-xs">{r.comment ?? "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {pages > 1 && (
        <div className="flex items-center justify-center gap-2 mt-4">
          <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(page - 1)}>Előző</Button>
          <span className="text-sm text-muted-foreground">{page} / {pages}</span>
          <Button variant="outline" size="sm" disabled={page >= pages} onClick={() => setPage(page + 1)}>Következő</Button>
          <span className="ml-2 text-xs text-muted-foreground">({total} bejegyzés)</span>
        </div>
      )}
    </div>
  );
}
