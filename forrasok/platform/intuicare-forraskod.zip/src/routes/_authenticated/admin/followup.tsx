/**
 * Admin — Visszajelentő (follow-up) protokollok szerkesztője.
 * Többfázisú kadencia + vizuális idővonal a fázisokról.
 */
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { ChevronLeft, Plus, Pencil, Trash2, CalendarClock } from "lucide-react";
import {
  listFollowupProtocols, upsertFollowupProtocol, deleteFollowupProtocol,
  upsertFollowupProtocolStep, deleteFollowupProtocolStep,
  listQuestionnairesForFollowup,
} from "@/lib/followup/followup.functions";

export const Route = createFileRoute("/_authenticated/admin/followup")({
  component: FollowupAdminPage,
});

type AnchorEvent = "birth" | "surgery_completed" | "discharge" | "visit_completed";
type Channel = "notification" | "push" | "email" | "sms";

const ANCHOR_LABEL: Record<AnchorEvent, string> = {
  birth: "Szülés",
  surgery_completed: "Műtét lezárva",
  discharge: "Elbocsátás",
  visit_completed: "Vizit lezárva",
};

const CHANNEL_LABEL: Record<Channel, string> = {
  notification: "Értesítés",
  push: "Push",
  email: "E-mail",
  sms: "SMS",
};

function fmtDays(d: number): string {
  if (d < 30) return `${d} nap`;
  if (d < 365) return `${Math.round(d / 30)} hó`;
  return `${(d / 365).toFixed(d % 365 === 0 ? 0 : 1)} év`;
}

function FollowupAdminPage() {
  const qc = useQueryClient();
  const list = useServerFn(listFollowupProtocols);
  const { data: protocols, isLoading } = useQuery({
    queryKey: ["followup", "protocols"],
    queryFn: () => list(),
  });

  const [editing, setEditing] = useState<any | null>(null);
  const [creating, setCreating] = useState(false);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const del = useServerFn(deleteFollowupProtocol);
  const delM = useMutation({
    mutationFn: (id: string) => del({ data: { id } }),
    onSuccess: () => {
      toast.success("Protokoll törölve");
      qc.invalidateQueries({ queryKey: ["followup", "protocols"] });
      setConfirmDeleteId(null);
    },
    onError: (e: any) => toast.error(e?.message ?? "Hiba"),
  });

  return (
    <div className="container mx-auto py-6 space-y-6 max-w-6xl">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Link to="/admin/szervezet" className="text-muted-foreground hover:text-foreground">
            <ChevronLeft className="size-4" />
          </Link>
          <div>
            <h1 className="text-2xl font-semibold">Visszajelentő protokollok</h1>
            <p className="text-sm text-muted-foreground">
              Többfázisú követés szülés / műtét / elbocsátás / vizit után.
            </p>
          </div>
        </div>
        <Button onClick={() => setCreating(true)}>
          <Plus className="size-4 mr-1" /> Új protokoll
        </Button>
      </div>

      {isLoading ? (
        <div className="text-sm text-muted-foreground">Betöltés…</div>
      ) : (protocols ?? []).length === 0 ? (
        <Card>
          <CardContent className="py-10 text-center text-sm text-muted-foreground">
            Még nincs protokoll. Kattints az „Új protokoll" gombra.
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {(protocols ?? []).map((p: any) => (
            <ProtocolCard
              key={p.id}
              protocol={p}
              onEdit={() => setEditing(p)}
              onDelete={() => setConfirmDeleteId(p.id)}
            />
          ))}
        </div>
      )}

      {(creating || editing) && (
        <ProtocolDialog
          initial={editing}
          onClose={() => { setCreating(false); setEditing(null); }}
          onSaved={() => {
            qc.invalidateQueries({ queryKey: ["followup", "protocols"] });
            setCreating(false); setEditing(null);
          }}
        />
      )}

      <AlertDialog open={!!confirmDeleteId} onOpenChange={(o) => !o && setConfirmDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Protokoll törlése</AlertDialogTitle>
            <AlertDialogDescription>
              Csak akkor törölhető, ha még nincs hozzárendelt követés. Aktív követések esetén inaktiváld.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Mégse</AlertDialogCancel>
            <AlertDialogAction onClick={() => confirmDeleteId && delM.mutate(confirmDeleteId)}>
              Törlés
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function ProtocolCard({
  protocol, onEdit, onDelete,
}: { protocol: any; onEdit: () => void; onDelete: () => void }) {
  const steps = [...(protocol.followup_protocol_steps ?? [])].sort(
    (a: any, b: any) => a.phase_order - b.phase_order,
  );
  const maxDay = Math.max(protocol.default_window_days, ...steps.map((s: any) => s.offset_days_to));

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-3">
          <div>
            <CardTitle className="flex items-center gap-2 text-base">
              {protocol.nev}
              <Badge variant="outline">{protocol.kod}</Badge>
              <Badge variant="secondary">{ANCHOR_LABEL[protocol.anchor_event as AnchorEvent]}</Badge>
              {!protocol.aktiv && <Badge variant="destructive">inaktív</Badge>}
            </CardTitle>
            {protocol.leiras && (
              <p className="text-sm text-muted-foreground mt-1">{protocol.leiras}</p>
            )}
            <p className="text-xs text-muted-foreground mt-1">
              Ablak: {fmtDays(protocol.default_window_days)} · {steps.length} fázis
            </p>
          </div>
          <div className="flex gap-1">
            <Button size="sm" variant="ghost" onClick={onEdit}>
              <Pencil className="size-3.5 mr-1" /> Szerkesztés
            </Button>
            <Button size="sm" variant="ghost" onClick={onDelete}>
              <Trash2 className="size-3.5" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <TimelineView steps={steps} maxDay={maxDay} />
        <StepsEditor protocolId={protocol.id} steps={steps} />
      </CardContent>
    </Card>
  );
}

function TimelineView({ steps, maxDay }: { steps: any[]; maxDay: number }) {
  if (steps.length === 0) {
    return (
      <div className="text-xs text-muted-foreground italic py-2">
        Még nincsenek fázisok. Add hozzá az elsőt lent.
      </div>
    );
  }
  return (
    <div className="space-y-1 py-2">
      <div className="relative h-2 bg-muted rounded overflow-hidden">
        {steps.map((s: any, i: number) => {
          const left = (s.offset_days_from / maxDay) * 100;
          const width = Math.max(0.5, ((s.offset_days_to - s.offset_days_from) / maxDay) * 100);
          const colors = [
            "bg-primary/70", "bg-blue-500/70", "bg-purple-500/70",
            "bg-pink-500/70", "bg-orange-500/70",
          ];
          return (
            <div
              key={s.id}
              className={`absolute h-full ${colors[i % colors.length]}`}
              style={{ left: `${left}%`, width: `${width}%` }}
              title={`${s.phase_label}: ${fmtDays(s.offset_days_from)} – ${fmtDays(s.offset_days_to)}`}
            />
          );
        })}
      </div>
      <div className="flex justify-between text-[10px] text-muted-foreground">
        <span>0</span>
        <span>{fmtDays(maxDay)}</span>
      </div>
    </div>
  );
}

function StepsEditor({ protocolId, steps }: { protocolId: string; steps: any[] }) {
  const qc = useQueryClient();
  const [editingStep, setEditingStep] = useState<any | null>(null);
  const [creatingStep, setCreatingStep] = useState(false);
  const del = useServerFn(deleteFollowupProtocolStep);
  const delM = useMutation({
    mutationFn: (id: string) => del({ data: { id } }),
    onSuccess: () => {
      toast.success("Fázis törölve");
      qc.invalidateQueries({ queryKey: ["followup", "protocols"] });
    },
    onError: (e: any) => toast.error(e?.message ?? "Hiba"),
  });

  return (
    <div className="mt-3 space-y-2">
      <div className="flex items-center justify-between">
        <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
          Fázisok
        </div>
        <Button size="sm" variant="outline" onClick={() => setCreatingStep(true)}>
          <Plus className="size-3 mr-1" /> Új fázis
        </Button>
      </div>
      {steps.length === 0 ? null : (
        <div className="space-y-1">
          {steps.map((s: any) => (
            <div
              key={s.id}
              className="flex items-center gap-3 text-sm border border-border rounded-md px-3 py-2 bg-card"
            >
              <CalendarClock className="size-4 text-muted-foreground shrink-0" />
              <div className="flex-1 min-w-0">
                <div className="font-medium truncate">{s.phase_label}</div>
                <div className="text-xs text-muted-foreground">
                  {fmtDays(s.offset_days_from)} – {fmtDays(s.offset_days_to)} · minden {fmtDays(s.cadence_days)} · {CHANNEL_LABEL[s.channel as Channel]}
                </div>
              </div>
              <Button size="sm" variant="ghost" onClick={() => setEditingStep(s)}>
                <Pencil className="size-3.5" />
              </Button>
              <Button size="sm" variant="ghost" onClick={() => delM.mutate(s.id)}>
                <Trash2 className="size-3.5" />
              </Button>
            </div>
          ))}
        </div>
      )}

      {(creatingStep || editingStep) && (
        <StepDialog
          protocolId={protocolId}
          initial={editingStep}
          defaultOrder={steps.length}
          onClose={() => { setCreatingStep(false); setEditingStep(null); }}
          onSaved={() => {
            qc.invalidateQueries({ queryKey: ["followup", "protocols"] });
            setCreatingStep(false); setEditingStep(null);
          }}
        />
      )}
    </div>
  );
}

function ProtocolDialog({
  initial, onClose, onSaved,
}: { initial: any | null; onClose: () => void; onSaved: () => void }) {
  const fn = useServerFn(upsertFollowupProtocol);
  const [kod, setKod] = useState(initial?.kod ?? "");
  const [nev, setNev] = useState(initial?.nev ?? "");
  const [leiras, setLeiras] = useState(initial?.leiras ?? "");
  const [anchor, setAnchor] = useState<AnchorEvent>(initial?.anchor_event ?? "visit_completed");
  const [window, setWindow] = useState<number>(initial?.default_window_days ?? 365);
  const [aktiv, setAktiv] = useState<boolean>(initial?.aktiv ?? true);

  const save = useMutation({
    mutationFn: () => fn({
      data: {
        id: initial?.id,
        kod, nev, leiras: leiras || null, anchor_event: anchor,
        default_window_days: window, aktiv,
      },
    }),
    onSuccess: () => { toast.success("Mentve"); onSaved(); },
    onError: (e: any) => toast.error(e?.message ?? "Hiba"),
  });

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{initial ? "Protokoll szerkesztése" : "Új protokoll"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Kód (slug)</Label>
              <Input value={kod} onChange={(e) => setKod(e.target.value)} placeholder="postpartum_mother" />
            </div>
            <div>
              <Label>Horgony-esemény</Label>
              <Select value={anchor} onValueChange={(v) => setAnchor(v as AnchorEvent)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(ANCHOR_LABEL).map(([k, v]) => (
                    <SelectItem key={k} value={k}>{v}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div>
            <Label>Név</Label>
            <Input value={nev} onChange={(e) => setNev(e.target.value)} />
          </div>
          <div>
            <Label>Leírás</Label>
            <Textarea value={leiras} onChange={(e) => setLeiras(e.target.value)} rows={2} />
          </div>
          <div className="grid grid-cols-2 gap-3 items-end">
            <div>
              <Label>Teljes követési ablak (nap)</Label>
              <Input
                type="number" min={1} max={36500}
                value={window} onChange={(e) => setWindow(Number(e.target.value))}
              />
            </div>
            <div className="flex items-center gap-2 pb-2">
              <Switch checked={aktiv} onCheckedChange={setAktiv} />
              <Label className="!mt-0">Aktív</Label>
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Mégse</Button>
          <Button onClick={() => save.mutate()} disabled={save.isPending || !kod || !nev}>
            Mentés
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function StepDialog({
  protocolId, initial, defaultOrder, onClose, onSaved,
}: {
  protocolId: string; initial: any | null; defaultOrder: number;
  onClose: () => void; onSaved: () => void;
}) {
  const fn = useServerFn(upsertFollowupProtocolStep);
  const listQ = useServerFn(listQuestionnairesForFollowup);
  const { data: questionnaires } = useQuery({
    queryKey: ["followup", "questionnaires"],
    queryFn: () => listQ(),
  });

  const [label, setLabel] = useState(initial?.phase_label ?? "");
  const [order, setOrder] = useState<number>(initial?.phase_order ?? defaultOrder);
  const [qid, setQid] = useState<string>(initial?.questionnaire_id ?? "");
  const [from, setFrom] = useState<number>(initial?.offset_days_from ?? 0);
  const [to, setTo] = useState<number>(initial?.offset_days_to ?? 28);
  const [cadence, setCadence] = useState<number>(initial?.cadence_days ?? 7);
  const [channel, setChannel] = useState<Channel>(initial?.channel ?? "notification");
  const [buckets, setBuckets] = useState<string>(
    (initial?.reminder_buckets ?? [-3, -1, 1]).join(", "),
  );

  const parsedBuckets = useMemo(
    () => buckets.split(",").map((s) => parseInt(s.trim(), 10)).filter((n) => Number.isFinite(n)),
    [buckets],
  );

  const occurrenceCount = useMemo(() => {
    if (cadence <= 0 || to < from) return 0;
    return Math.floor((to - from) / cadence) + 1;
  }, [from, to, cadence]);

  const save = useMutation({
    mutationFn: () => fn({
      data: {
        id: initial?.id,
        protocol_id: protocolId,
        phase_label: label,
        phase_order: order,
        questionnaire_id: qid,
        offset_days_from: from,
        offset_days_to: to,
        cadence_days: cadence,
        channel,
        reminder_buckets: parsedBuckets,
      },
    }),
    onSuccess: () => { toast.success("Fázis mentve"); onSaved(); },
    onError: (e: any) => toast.error(e?.message ?? "Hiba"),
  });

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>{initial ? "Fázis szerkesztése" : "Új fázis"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="grid grid-cols-3 gap-3">
            <div className="col-span-2">
              <Label>Fázis név</Label>
              <Input value={label} onChange={(e) => setLabel(e.target.value)} placeholder="1. hónap hetente" />
            </div>
            <div>
              <Label>Sorrend</Label>
              <Input type="number" value={order} onChange={(e) => setOrder(Number(e.target.value))} />
            </div>
          </div>
          <div>
            <Label>Kérdőív</Label>
            <Select value={qid} onValueChange={setQid}>
              <SelectTrigger><SelectValue placeholder="Válassz kérdőívet…" /></SelectTrigger>
              <SelectContent>
                {(questionnaires ?? []).map((q: any) => (
                  <SelectItem key={q.id} value={q.id}>{q.title} ({q.code})</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div>
              <Label>Kezdő (nap)</Label>
              <Input type="number" min={0} value={from} onChange={(e) => setFrom(Number(e.target.value))} />
            </div>
            <div>
              <Label>Vég (nap)</Label>
              <Input type="number" min={0} value={to} onChange={(e) => setTo(Number(e.target.value))} />
            </div>
            <div>
              <Label>Periódus (nap)</Label>
              <Input type="number" min={1} value={cadence} onChange={(e) => setCadence(Number(e.target.value))} />
            </div>
          </div>
          <div className="text-xs text-muted-foreground">
            {fmtDays(from)} – {fmtDays(to)} · {fmtDays(cadence)}-ente → kb. <b>{occurrenceCount}</b> kiküldés
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Csatorna</Label>
              <Select value={channel} onValueChange={(v) => setChannel(v as Channel)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(CHANNEL_LABEL).map(([k, v]) => (
                    <SelectItem key={k} value={k}>{v}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Emlékeztetők (napok, vesszővel)</Label>
              <Input value={buckets} onChange={(e) => setBuckets(e.target.value)} placeholder="-3, -1, 1" />
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Mégse</Button>
          <Button
            onClick={() => save.mutate()}
            disabled={save.isPending || !label || !qid || to < from}
          >
            Mentés
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
