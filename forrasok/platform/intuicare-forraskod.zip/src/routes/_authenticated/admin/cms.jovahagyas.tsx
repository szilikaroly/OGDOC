import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { listPendingReview } from "@/lib/cms/workflow.functions";
import { WorkflowActionBar } from "@/components/cms/workflow-action-bar";
import { AuditTrailDrawer } from "@/components/cms/audit-trail-drawer";
import { Badge } from "@/components/ui/badge";

const ENTITY_LABEL: Record<string, string> = {
  cms_pages: "Oldalak",
  cms_news_posts: "Hírek (Blog / Vlog)",
  cms_blocks: "Blokkok",
  cms_layout_blocks: "Layout blokkok",
  cms_menus: "Menük",
  cms_menu_items: "Menüpontok",
  cms_redirects: "Átirányítások",
  cms_staff_profiles: "Csapat profilok",
  cms_faqs: "GYIK",
  cms_design_tokens: "Dizájn tokenek",
  cms_site_settings: "Oldalbeállítások",
  cms_global_regions: "Globális régiók",
  cms_media: "Médiatár",
};

export const Route = createFileRoute("/_authenticated/admin/cms/jovahagyas")({
  ssr: false,
  component: PendingReviewPage,
});

function PendingReviewPage() {
  const listFn = useServerFn(listPendingReview);
  const { data, isLoading, refetch } = useQuery({
    queryKey: ["cms-pending-review"],
    queryFn: () => listFn(),
  });

  const groups = (data?.groups ?? []) as Array<{ entity_type: string; items: any[] }>;
  const total = groups.reduce((acc, g) => acc + g.items.length, 0);

  return (
    <div className="container mx-auto py-4 sm:py-8 px-3 sm:px-6 lg:px-8 max-w-6xl">
      <header className="mb-6">
        <h1 className="text-2xl sm:text-3xl font-bold">Jóváhagyásra váró tartalmak</h1>
        <p className="text-muted-foreground text-sm mt-1">
          {isLoading ? "Betöltés…" : `Összesen ${total} tartalom vár véleményezésre.`}
        </p>
      </header>

      {!isLoading && groups.length === 0 && (
        <p className="text-muted-foreground">Nincs jelenleg jóváhagyásra váró tartalom.</p>
      )}

      <div className="space-y-6">
        {groups.map((g) => (
          <section key={g.entity_type}>
            <h2 className="text-lg font-semibold mb-2 flex items-center gap-2">
              {ENTITY_LABEL[g.entity_type] ?? g.entity_type}
              <Badge variant="secondary">{g.items.length}</Badge>
            </h2>
            <ul className="divide-y border rounded-lg">
              {g.items.map((it: any) => {
                const title = it.meta?.title ?? it.meta?.name ?? it.meta?.kulcs ?? it.meta?.source_path ?? it.meta?.slug ?? it.id;
                return (
                  <li key={it.id} className="p-3 flex flex-wrap items-center justify-between gap-3">
                    <div className="min-w-0">
                      <div className="font-medium truncate">{title}</div>
                      <div className="text-xs text-muted-foreground">
                        Beküldve: {it.submitted_for_review_at ? new Date(it.submitted_for_review_at).toLocaleString("hu-HU") : "—"}
                      </div>
                    </div>
                    <div className="flex flex-wrap items-center gap-2">
                      <AuditTrailDrawer entity_type={g.entity_type as any} entity_id={it.id} />
                      <WorkflowActionBar
                        entity_type={g.entity_type as any}
                        entity_id={it.id}
                        state="in_review"
                        onChanged={() => refetch()}
                      />
                    </div>
                  </li>
                );
              })}
            </ul>
          </section>
        ))}
      </div>
    </div>
  );
}
