import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { toast } from "sonner";
import { Loader2, ShieldAlert, ShieldCheck, ShieldX, Search, RefreshCcw, Wrench } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { usePermissions, type PermissionKey } from "@/hooks/use-permissions";
import { humanizeError } from "@/lib/humanize-error";
import { cn } from "@/lib/utils";

type Role = { id: string; kulcs: string; megnevezes: string; kategoria: string; sorrend: number };
type RolePerm = { id: string; role_kulcs: string; perm: string };

const PERMS: { key: PermissionKey; label: string; desc: string }[] = [
  { key: "manage_tenant", label: "Bérlő", desc: "Bérlő alapadatok" },
  { key: "manage_org", label: "Szervezet", desc: "Klinika / telephely / egység" },
  { key: "manage_roles", label: "Szerepkörök", desc: "Felhasználói szerepkörök" },
  { key: "manage_schedule", label: "Beosztás", desc: "Műszakok, ügyeletek" },
  { key: "manage_training", label: "Képzés", desc: "Skill / képzés / beavatkozás" },
  { key: "manage_patients", label: "Páciensek", desc: "Páciens-adatok" },
  { key: "view_team", label: "Csapat", desc: "Csapat-megtekintés" },
  { key: "view_audit", label: "Audit", desc: "Audit napló" },
  { key: "manage_worktime", label: "Munkaidő", desc: "Munkaidő-szabályok, díjkódok, bértábla, egyedi szabályok" },
];

const CATEGORIES = ["admin", "vezeto", "orvos", "szakdolgozo"] as const;

// Canonical seed — MUST stay in sync with public.ensure_role_permissions_seed().
const CANONICAL_SEED: Array<[string, PermissionKey]> = [
  ["tenant_admin", "manage_tenant"],
  ["tenant_admin", "manage_org"], ["igazgato", "manage_org"], ["intezetvezeto", "manage_org"], ["telephelyvezeto", "manage_org"],
  ["tenant_admin", "manage_roles"], ["igazgato", "manage_roles"], ["intezetvezeto", "manage_roles"],
  ["tenant_admin", "manage_schedule"], ["igazgato", "manage_schedule"], ["intezetvezeto", "manage_schedule"], ["telephelyvezeto", "manage_schedule"], ["ugyeletvezeto", "manage_schedule"], ["beoszto", "manage_schedule"],
  ["tenant_admin", "manage_training"], ["igazgato", "manage_training"], ["intezetvezeto", "manage_training"], ["foorvos", "manage_training"],
  ["tenant_admin", "manage_patients"], ["igazgato", "manage_patients"], ["intezetvezeto", "manage_patients"], ["telephelyvezeto", "manage_patients"], ["foorvos", "manage_patients"], ["szakorvos", "manage_patients"], ["rezidens", "manage_patients"], ["szakgyakornok", "manage_patients"], ["vezetorezidens", "manage_patients"],
  ["tenant_admin", "view_audit"], ["igazgato", "view_audit"], ["intezetvezeto", "view_audit"],
  ["tenant_admin", "view_team"], ["igazgato", "view_team"], ["intezetvezeto", "view_team"], ["telephelyvezeto", "view_team"], ["foorvos", "view_team"], ["ugyeletvezeto", "view_team"], ["beoszto", "view_team"],
];

export const Route = createFileRoute("/_authenticated/admin/jogosultsagok")({
  component: PermMatrixPage,
});

function PermMatrixPage() {
  const { t } = useTranslation();
  const { can, loading: permLoading } = usePermissions();
  const [roles, setRoles] = useState<Role[]>([]);
  const [rolePerms, setRolePerms] = useState<RolePerm[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const [seeding, setSeeding] = useState(false);
  const [seedStep, setSeedStep] = useState<string>("");
  type SeedDiffItem = { role_kulcs: string; perm: string };
  type SeedRecord = {
    ts: number;
    inserted: number;
    diff?: SeedDiffItem[];
    status: "success" | "error";
    errorMessage?: string;
  };
  const [lastSeed, setLastSeed] = useState<SeedRecord | null>(() => {
    try {
      const raw = localStorage.getItem("medroster.lastSeed");
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  });

  const [roleSearch, setRoleSearch] = useState("");
  const [permSearch, setPermSearch] = useState("");
  const [category, setCategory] = useState<string>("");

  const isAdmin = can("manage_tenant");

  async function load() {
    setLoading(true);
    const [{ data: r }, { data: rp }] = await Promise.all([
      supabase.from("roles").select("*").order("sorrend"),
      supabase.from("role_permissions").select("*"),
    ]);
    setRoles((r ?? []) as Role[]);
    setRolePerms((rp ?? []) as RolePerm[]);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  const filteredRoles = useMemo(() => {
    const q = roleSearch.trim().toLowerCase();
    return roles.filter((r) => {
      if (category && r.kategoria !== category) return false;
      if (!q) return true;
      return (
        r.kulcs.toLowerCase().includes(q) ||
        r.megnevezes.toLowerCase().includes(q) ||
        r.kategoria.toLowerCase().includes(q)
      );
    });
  }, [roles, roleSearch, category]);

  const filteredPerms = useMemo(() => {
    const q = permSearch.trim().toLowerCase();
    if (!q) return PERMS;
    return PERMS.filter(
      (p) => p.key.toLowerCase().includes(q) || p.label.toLowerCase().includes(q),
    );
  }, [permSearch]);

  const activeCount = useMemo(() => {
    const rkSet = new Set(filteredRoles.map((r) => r.kulcs));
    const pkSet = new Set(filteredPerms.map((p) => p.key as string));
    return rolePerms.filter((rp) => rkSet.has(rp.role_kulcs) && pkSet.has(rp.perm)).length;
  }, [rolePerms, filteredRoles, filteredPerms]);

  const diffSet = useMemo(
    () => new Set((lastSeed?.diff ?? []).map((d) => `${d.role_kulcs}:${d.perm}`)),
    [lastSeed],
  );

  async function toggle(roleKulcs: string, perm: PermissionKey, current: boolean) {
    const key = `${roleKulcs}:${perm}`;
    setBusy(key);
    if (current) {
      const { error } = await supabase
        .from("role_permissions")
        .delete()
        .eq("role_kulcs", roleKulcs)
        .eq("perm", perm);
      if (error) toast.error(humanizeError(error, t, { perm: "manage_tenant" }));
      else {
        setRolePerms((p) => p.filter((x) => !(x.role_kulcs === roleKulcs && x.perm === perm)));
        toast.success(t("jogosultsagok.removed"));
      }
    } else {
      const { data, error } = await supabase
        .from("role_permissions")
        .insert({ role_kulcs: roleKulcs, perm })
        .select("*")
        .maybeSingle();
      if (error) toast.error(humanizeError(error, t, { perm: "manage_tenant" }));
      else if (data) {
        setRolePerms((p) => [...p, data as RolePerm]);
        toast.success(t("jogosultsagok.added"));
      }
    }
    setBusy(null);
  }

  async function runSeed() {
    if (seeding) return; // hard guard against parallel runs
    setSeeding(true);
    const toastId = toast.loading(t("jogosultsagok.seed_running"), {
      description: t("jogosultsagok.seed_step_snapshot"),
    });

    const finish = (entry: SeedRecord) => {
      try {
        localStorage.setItem("medroster.lastSeed", JSON.stringify(entry));
      } catch {}
      setLastSeed(entry);
      setSeedStep("");
      setSeeding(false);
    };

    // Helper: compute canonical-vs-actual diff (rows that *should* exist but don't).
    const computeMissing = (existing: Set<string>): SeedDiffItem[] =>
      CANONICAL_SEED
        .filter(([rk, p]) => !existing.has(`${rk}:${p}`))
        .map(([rk, p]) => ({ role_kulcs: rk, perm: p as string }));

    // 1. Snapshot before.
    setSeedStep(t("jogosultsagok.seed_step_snapshot"));
    const { data: before, error: beforeErr } = await supabase
      .from("role_permissions")
      .select("role_kulcs, perm");
    if (beforeErr) {
      const entry: SeedRecord = {
        ts: Date.now(),
        inserted: 0,
        status: "error",
        errorMessage: humanizeError(beforeErr, t, { perm: "manage_tenant" }),
      };
      toast.error(entry.errorMessage!, {
        id: toastId,
        description: t("jogosultsagok.seed_failed_desc"),
      });
      finish(entry);
      return;
    }
    const beforeSet = new Set((before ?? []).map((r) => `${r.role_kulcs}:${r.perm}`));

    // 2. Run RPC.
    setSeedStep(t("jogosultsagok.seed_step_rpc"));
    toast.loading(t("jogosultsagok.seed_running"), {
      id: toastId,
      description: t("jogosultsagok.seed_step_rpc"),
    });
    const { data: insertedCount, error } = await supabase.rpc("ensure_role_permissions_seed");
    if (error) {
      // Even on failure, show what *would* have been affected so the user can act.
      const missing = computeMissing(beforeSet);
      const entry: SeedRecord = {
        ts: Date.now(),
        inserted: 0,
        diff: missing,
        status: "error",
        errorMessage: humanizeError(error, t, { perm: "manage_tenant" }),
      };
      const preview = missing
        .slice(0, 5)
        .map((d) => `• ${d.role_kulcs} → ${d.perm}`)
        .join("\n");
      const extra = missing.length > 5 ? `\n… +${missing.length - 5}` : "";
      toast.error(entry.errorMessage!, {
        id: toastId,
        description:
          (missing.length > 0
            ? t("jogosultsagok.seed_error_missing", { count: missing.length }) + "\n" + preview + extra + "\n\n"
            : "") + t("jogosultsagok.seed_failed_desc"),
        duration: 12000,
      });
      finish(entry);
      return;
    }

    // 3. Snapshot after.
    setSeedStep(t("jogosultsagok.seed_step_verify"));
    toast.loading(t("jogosultsagok.seed_running"), {
      id: toastId,
      description: t("jogosultsagok.seed_step_verify"),
    });
    const { data: after, error: afterErr } = await supabase
      .from("role_permissions")
      .select("*");
    if (afterErr) {
      const entry: SeedRecord = {
        ts: Date.now(),
        inserted: typeof insertedCount === "number" ? insertedCount : 0,
        status: "error",
        errorMessage: humanizeError(afterErr, t, { perm: "manage_tenant" }),
      };
      toast.error(entry.errorMessage!, { id: toastId });
      finish(entry);
      return;
    }

    const diff = (after ?? [])
      .filter((r) => !beforeSet.has(`${r.role_kulcs}:${r.perm}`))
      .map((r) => ({ role_kulcs: r.role_kulcs, perm: r.perm }));
    const inserted = typeof insertedCount === "number" ? insertedCount : diff.length;
    const entry: SeedRecord = { ts: Date.now(), inserted, diff, status: "success" };
    setRolePerms((after ?? []) as RolePerm[]);

    if (inserted > 0) {
      const preview = diff
        .slice(0, 5)
        .map((d) => `• ${d.role_kulcs} → ${d.perm}`)
        .join("\n");
      const extra = diff.length > 5 ? `\n… +${diff.length - 5}` : "";
      toast.success(t("jogosultsagok.seed_inserted", { count: inserted }), {
        id: toastId,
        description: preview + extra,
        duration: 8000,
      });
    } else {
      toast.success(t("jogosultsagok.seed_uptodate"), {
        id: toastId,
        description: t("jogosultsagok.seed_last_run", {
          time: new Date(entry.ts).toLocaleString(),
        }),
      });
    }
    finish(entry);
  }

  if (permLoading || loading) {
    return (
      <div className="p-8 flex items-center gap-2 text-muted-foreground text-sm">
        <Loader2 className="size-4 animate-spin" /> {t("common.loading")}
      </div>
    );
  }

  return (
    <div className="p-8 space-y-6">
      <header className="flex items-end justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">{t("jogosultsagok.title")}</h1>
          <p className="text-sm text-muted-foreground mt-1">{t("jogosultsagok.subtitle")}</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={load}
            className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-2 rounded-md border border-border hover:bg-secondary"
          >
            <RefreshCcw className="size-3.5" />
            {t("audit.refresh")}
          </button>
          {isAdmin && (
            <div className="flex flex-col items-end gap-1">
              <button
                type="button"
                onClick={runSeed}
                disabled={seeding}
                aria-busy={seeding}
                className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-2 rounded-md border border-primary/30 bg-primary/10 text-primary hover:bg-primary/20 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {seeding ? <Loader2 className="size-3.5 animate-spin" /> : <Wrench className="size-3.5" />}
                {seeding ? t("jogosultsagok.seed_running") : t("jogosultsagok.seed_btn")}
              </button>
              {seeding ? (
                <div className="text-[10px] font-mono text-primary animate-pulse">
                  {seedStep || t("jogosultsagok.seed_step_snapshot")}
                </div>
              ) : (
                lastSeed && (
                  <div
                    className={cn(
                      "text-[10px] font-mono",
                      lastSeed.status === "error" ? "text-destructive" : "text-muted-foreground",
                    )}
                  >
                    {t("jogosultsagok.seed_last_run", {
                      time: new Date(lastSeed.ts).toLocaleString(),
                    })}
                    {" · "}
                    {lastSeed.status === "error"
                      ? t("jogosultsagok.seed_last_error")
                      : t("jogosultsagok.seed_last_count", { count: lastSeed.inserted })}
                  </div>
                )
              )}
            </div>
          )}
        </div>
      </header>

      {!isAdmin && (
        <div className="flex items-start gap-3 p-4 border border-warning/30 bg-warning/5 rounded-lg">
          <ShieldAlert className="size-5 text-warning shrink-0 mt-0.5" />
          <div className="text-sm">{t("jogosultsagok.read_only")}</div>
        </div>
      )}

      {lastSeed && lastSeed.diff && lastSeed.diff.length > 0 && (
        <div
          className={cn(
            "rounded-lg border p-4 space-y-2",
            lastSeed.status === "error"
              ? "border-destructive/30 bg-destructive/5"
              : "border-success/30 bg-success/5",
          )}
        >
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div
              className={cn(
                "flex items-center gap-2 text-sm font-semibold",
                lastSeed.status === "error" ? "text-destructive" : "text-success",
              )}
            >
              {lastSeed.status === "error" ? (
                <ShieldX className="size-4" />
              ) : (
                <ShieldCheck className="size-4" />
              )}
              {lastSeed.status === "error"
                ? t("jogosultsagok.seed_error_title", { count: lastSeed.diff.length })
                : t("jogosultsagok.seed_diff_title", { count: lastSeed.diff.length })}
            </div>
            <div className="text-[10px] font-mono text-muted-foreground">
              {new Date(lastSeed.ts).toLocaleString()}
            </div>
          </div>
          {lastSeed.status === "error" && lastSeed.errorMessage && (
            <div className="text-xs text-destructive">{lastSeed.errorMessage}</div>
          )}
          <div className="flex flex-wrap gap-1.5">
            {lastSeed.diff.map((d) => {
              const role = roles.find((r) => r.kulcs === d.role_kulcs);
              const perm = PERMS.find((p) => p.key === d.perm);
              return (
                <span
                  key={`${d.role_kulcs}:${d.perm}`}
                  className={cn(
                    "inline-flex items-center gap-1 text-[11px] font-mono px-2 py-0.5 rounded border",
                    lastSeed.status === "error"
                      ? "border-destructive/30 bg-destructive/10 text-destructive"
                      : "border-success/30 bg-success/10 text-success",
                  )}
                >
                  {role?.megnevezes ?? d.role_kulcs}
                  <span className="opacity-60">→</span>
                  {perm?.label ?? d.perm}
                </span>
              );
            })}
          </div>
          <div className="flex items-center gap-3">
            {lastSeed.status === "error" && (
              <button
                type="button"
                onClick={runSeed}
                disabled={seeding}
                className="text-[10px] font-semibold underline text-destructive hover:text-destructive/80 disabled:opacity-50"
              >
                {t("jogosultsagok.seed_retry")}
              </button>
            )}
            <button
              type="button"
              onClick={() => {
                try {
                  localStorage.removeItem("medroster.lastSeed");
                } catch {}
                setLastSeed(null);
              }}
              className="text-[10px] underline text-muted-foreground hover:text-foreground"
            >
              {t("jogosultsagok.seed_diff_dismiss")}
            </button>
          </div>
        </div>
      )}

      <div className="rounded-lg border border-border bg-card p-3 flex items-center gap-3 flex-wrap">
        <div className="flex items-center gap-2 flex-1 min-w-[200px]">
          <Search className="size-3.5 text-muted-foreground" />
          <input
            type="text"
            value={roleSearch}
            onChange={(e) => setRoleSearch(e.target.value)}
            placeholder={t("jogosultsagok.search_role")}
            className="flex-1 px-2 py-1 text-sm bg-transparent outline-none"
          />
        </div>
        <select
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          className="px-2 py-1 text-xs rounded-md border border-input bg-background"
        >
          <option value="">{t("jogosultsagok.all_categories")}</option>
          {CATEGORIES.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
        <div className="flex items-center gap-2 flex-1 min-w-[200px]">
          <Search className="size-3.5 text-muted-foreground" />
          <input
            type="text"
            value={permSearch}
            onChange={(e) => setPermSearch(e.target.value)}
            placeholder={t("jogosultsagok.search_perm")}
            className="flex-1 px-2 py-1 text-sm bg-transparent outline-none"
          />
        </div>
        <div className="text-[11px] font-mono text-muted-foreground whitespace-nowrap">
          {filteredRoles.length} szerepkör · {filteredPerms.length} jog · {activeCount} aktív
        </div>
      </div>

      <div className="rounded-lg border border-border bg-card overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-secondary text-[10px] uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="text-left px-3 py-2 sticky left-0 bg-secondary z-10 min-w-[200px]">
                Szerepkör
              </th>
              {filteredPerms.map((p) => (
                <th key={p.key} className="px-2 py-2 text-center min-w-[110px]">
                  <div className="font-semibold normal-case text-xs">{p.label}</div>
                  <div className="font-normal normal-case text-[10px] text-muted-foreground mt-0.5">
                    {p.desc}
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {filteredRoles.length === 0 && (
              <tr>
                <td
                  colSpan={filteredPerms.length + 1}
                  className="px-3 py-8 text-center text-muted-foreground text-sm"
                >
                  Nincs találat
                </td>
              </tr>
            )}
            {filteredRoles.map((r) => (
              <tr key={r.id} className="hover:bg-secondary/40">
                <td className="px-3 py-2 sticky left-0 bg-card font-semibold">
                  <div>{r.megnevezes}</div>
                  <div className="text-[10px] font-mono text-muted-foreground">
                    {r.kulcs} · {r.kategoria}
                  </div>
                </td>
                {filteredPerms.map((p) => {
                  const has = rolePerms.some(
                    (rp) => rp.role_kulcs === r.kulcs && rp.perm === p.key,
                  );
                  const key = `${r.kulcs}:${p.key}`;
                  const isBusy = busy === key;
                  const wasSeeded = diffSet.has(key);
                  return (
                    <td key={p.key} className="px-2 py-2 text-center">
                      <button
                        type="button"
                        disabled={!isAdmin || isBusy || seeding}
                        onClick={() => toggle(r.kulcs, p.key, has)}
                        className={cn(
                          "inline-flex items-center justify-center size-7 rounded transition-colors",
                          has
                            ? "bg-success/15 text-success hover:bg-success/25"
                            : "bg-muted text-muted-foreground hover:bg-muted/80",
                          wasSeeded &&
                            (lastSeed?.status === "error"
                              ? "ring-2 ring-destructive ring-offset-1 ring-offset-card"
                              : "ring-2 ring-success ring-offset-1 ring-offset-card"),
                          (!isAdmin || isBusy || seeding) && "opacity-50 cursor-not-allowed",
                        )}
                        title={
                          wasSeeded
                            ? lastSeed?.status === "error"
                              ? t("jogosultsagok.seed_diff_cell_missing")
                              : t("jogosultsagok.seed_diff_cell")
                            : has
                              ? "Eltávolítás"
                              : "Hozzáadás"
                        }
                      >
                        {isBusy ? (
                          <Loader2 className="size-3.5 animate-spin" />
                        ) : has ? (
                          <ShieldCheck className="size-3.5" />
                        ) : (
                          <span className="text-xs">·</span>
                        )}
                      </button>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
