import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { toast } from "sonner";
import { Loader2, Save, ShieldCheck } from "lucide-react";
import { RouteErrorBoundary } from "@/lib/errors/route-boundaries";
import { checkLeaveAdmin, upsertLeavePolicy } from "@/lib/leave/leave.functions";

export const Route = createFileRoute("/_authenticated/admin/szabadsag-szabalyzat")({
  component: SzabadsagSzabalyzatPage,
  errorComponent: RouteErrorBoundary,
});

type Policy = {
  id?: string;
  tenant_id: string;
  ev: number;
  alapszabadsag_mt: number;
  eletkor_pot: Array<{ kor: number; nap: number }>;
  gyermek_pot: { "1": number; "2": number; "3+": number; fogyatekos_plusz: number };
  apasagi_nap: number;
  szuloi_nap: number;
  eu_alap: { alap: number; felsofoku: number };
  oktatoi_max: number;
  oktatoi_max_targy: number;
  vezeto_magas_pot: number;
  vezeto_pot: number;
  sugar_pot: number;
  forced_takeout_deadline_mmdd: string;
  max_carryover_alap_quarter: boolean;
};

const DEFAULT_POLICY = (tenantId: string, ev: number): Policy => ({
  tenant_id: tenantId,
  ev,
  alapszabadsag_mt: 20,
  eletkor_pot: [
    { kor: 25, nap: 1 },
    { kor: 28, nap: 2 },
    { kor: 31, nap: 3 },
    { kor: 33, nap: 4 },
    { kor: 35, nap: 5 },
    { kor: 37, nap: 6 },
    { kor: 39, nap: 7 },
    { kor: 41, nap: 8 },
    { kor: 43, nap: 9 },
    { kor: 45, nap: 10 },
  ],
  gyermek_pot: { "1": 2, "2": 4, "3+": 7, fogyatekos_plusz: 2 },
  apasagi_nap: 10,
  szuloi_nap: 44,
  eu_alap: { alap: 20, felsofoku: 21 },
  oktatoi_max: 25,
  oktatoi_max_targy: 15,
  vezeto_magas_pot: 10,
  vezeto_pot: 5,
  sugar_pot: 10,
  forced_takeout_deadline_mmdd: "01-30",
  max_carryover_alap_quarter: true,
});

function SzabadsagSzabalyzatPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [permChecked, setPermChecked] = useState(false);
  const [tenantId, setTenantId] = useState<string | null>(null);
  const [ev, setEv] = useState(new Date().getFullYear());
  const [p, setP] = useState<Policy | null>(null);
  const [saving, setSaving] = useState(false);

  const checkPerm = useServerFn(checkLeaveAdmin);
  const upsertPolicy = useServerFn(upsertLeavePolicy);

  useEffect(() => {
    (async () => {
      try {
        const res = await checkPerm();
        if (!res.ok) {
          toast.error("Nincs jogosultságod a szabályzat kezeléséhez (manage_leave).");
          navigate({ to: "/dashboard" });
          return;
        }
        setPermChecked(true);
      } catch {
        toast.error("Jogosultság-ellenőrzés sikertelen.");
        navigate({ to: "/dashboard" });
      }
    })();
  }, [checkPerm, navigate]);

  useEffect(() => {
    if (!user || !permChecked) return;
    (async () => {
      const { data: prof } = await supabase
        .from("profiles")
        .select("tenant_id")
        .eq("id", user.id)
        .maybeSingle();
      setTenantId(prof?.tenant_id ?? null);
    })();
  }, [user, permChecked]);

  useEffect(() => {
    if (!tenantId) return;
    (async () => {
      const { data } = await supabase
        .from("leave_policy")
        .select("*")
        .eq("tenant_id", tenantId)
        .eq("ev", ev)
        .maybeSingle();
      if (data) setP(data as unknown as Policy);
      else setP(DEFAULT_POLICY(tenantId, ev));
    })();
  }, [tenantId, ev]);

  async function save() {
    if (!p) return;
    setSaving(true);
    try {
      await upsertPolicy({
        data: {
          ev: p.ev,
          policy: {
            alapszabadsag_mt: p.alapszabadsag_mt,
            eletkor_pot: p.eletkor_pot,
            gyermek_pot: p.gyermek_pot,
            apasagi_nap: p.apasagi_nap,
            szuloi_nap: p.szuloi_nap,
            eu_alap: p.eu_alap,
            oktatoi_max: p.oktatoi_max,
            oktatoi_max_targy: p.oktatoi_max_targy,
            vezeto_magas_pot: p.vezeto_magas_pot,
            vezeto_pot: p.vezeto_pot,
            sugar_pot: p.sugar_pot,
            forced_takeout_deadline_mmdd: p.forced_takeout_deadline_mmdd,
            max_carryover_alap_quarter: p.max_carryover_alap_quarter,
          },
        },
      });
      toast.success("Szabályzat mentve és auditálva.");
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setSaving(false);
    }
  }

  if (!permChecked) {
    return (
      <div className="p-12 flex items-center justify-center gap-2 text-muted-foreground">
        <ShieldCheck className="size-5" />
        Jogosultság ellenőrzése…
      </div>
    );
  }

  if (!p) {
    return (
      <div className="p-8 flex justify-center text-muted-foreground">
        <Loader2 className="size-6 animate-spin" />
      </div>
    );
  }

  return (
    <div className="p-8 max-w-3xl mx-auto space-y-6">
      <header className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Szabadság-szabályzat</h1>
          <p className="text-sm text-muted-foreground">
            Tenant-szintű paraméterek évenként (Mt., Eszjtv., Kjt., Nftv. alapján).
          </p>
        </div>
        <select
          value={ev}
          onChange={(e) => setEv(Number(e.target.value))}
          className="px-3 py-2 rounded-md border border-input bg-background text-sm"
        >
          {[ev + 1, ev, ev - 1].map((y) => (
            <option key={y} value={y}>
              {y}
            </option>
          ))}
        </select>
      </header>

      <Section title="Alapszabadság">
        <NumField label="Mt. alapszabadság (nap)" value={p.alapszabadsag_mt} onChange={(v) => setP({ ...p, alapszabadsag_mt: v })} />
        <NumField label="Eszjtv. alap (A–D)" value={p.eu_alap.alap} onChange={(v) => setP({ ...p, eu_alap: { ...p.eu_alap, alap: v } })} />
        <NumField label="Eszjtv. felsőfokú (E–J)" value={p.eu_alap.felsofoku} onChange={(v) => setP({ ...p, eu_alap: { ...p.eu_alap, felsofoku: v } })} />
      </Section>

      <Section title="Életkori pótszabadság (Mt. 117. §)">
        <table className="w-full text-sm">
          <thead className="text-xs uppercase text-muted-foreground">
            <tr>
              <th className="text-left p-2">Életkor (betöltött)</th>
              <th className="text-right p-2">Pótszabadság (nap)</th>
            </tr>
          </thead>
          <tbody>
            {p.eletkor_pot.map((row, i) => (
              <tr key={i} className="border-t border-border">
                <td className="p-1">
                  <input
                    type="number"
                    value={row.kor}
                    onChange={(e) => {
                      const arr = [...p.eletkor_pot];
                      arr[i] = { ...arr[i], kor: Number(e.target.value) };
                      setP({ ...p, eletkor_pot: arr });
                    }}
                    className="w-20 px-2 py-1 border border-input rounded bg-background text-sm"
                  />
                </td>
                <td className="p-1 text-right">
                  <input
                    type="number"
                    value={row.nap}
                    onChange={(e) => {
                      const arr = [...p.eletkor_pot];
                      arr[i] = { ...arr[i], nap: Number(e.target.value) };
                      setP({ ...p, eletkor_pot: arr });
                    }}
                    className="w-20 px-2 py-1 border border-input rounded bg-background text-sm text-right"
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Section>

      <Section title="Gyermek után járó pótszabadság (Mt. 118. §)">
        <NumField label="1 gyermek" value={p.gyermek_pot["1"]} onChange={(v) => setP({ ...p, gyermek_pot: { ...p.gyermek_pot, "1": v } })} />
        <NumField label="2 gyermek" value={p.gyermek_pot["2"]} onChange={(v) => setP({ ...p, gyermek_pot: { ...p.gyermek_pot, "2": v } })} />
        <NumField label="3+ gyermek" value={p.gyermek_pot["3+"]} onChange={(v) => setP({ ...p, gyermek_pot: { ...p.gyermek_pot, "3+": v } })} />
        <NumField label="Fogyatékos gyermekenként +" value={p.gyermek_pot.fogyatekos_plusz} onChange={(v) => setP({ ...p, gyermek_pot: { ...p.gyermek_pot, fogyatekos_plusz: v } })} />
      </Section>

      <Section title="Vezetői és oktatói pótszabadság (a magasabb jár)">
        <NumField label="Magasabb vezető" value={p.vezeto_magas_pot} onChange={(v) => setP({ ...p, vezeto_magas_pot: v })} />
        <NumField label="Vezető" value={p.vezeto_pot} onChange={(v) => setP({ ...p, vezeto_pot: v })} />
        <NumField label="Oktatói (max)" value={p.oktatoi_max} onChange={(v) => setP({ ...p, oktatoi_max: v })} />
        <NumField label="Oktatói (tárgyévre max)" value={p.oktatoi_max_targy} onChange={(v) => setP({ ...p, oktatoi_max_targy: v })} />
      </Section>

      <Section title="Egyéb">
        <NumField label="Apasági szabadság" value={p.apasagi_nap} onChange={(v) => setP({ ...p, apasagi_nap: v })} />
        <NumField label="Szülői szabadság" value={p.szuloi_nap} onChange={(v) => setP({ ...p, szuloi_nap: v })} />
        <NumField label="Sugárterhelési pótszabadság" value={p.sugar_pot} onChange={(v) => setP({ ...p, sugar_pot: v })} />
        <div>
          <label className="text-xs text-muted-foreground">Kényszerkiadás határidő (MM-DD)</label>
          <input
            value={p.forced_takeout_deadline_mmdd}
            onChange={(e) => setP({ ...p, forced_takeout_deadline_mmdd: e.target.value })}
            className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm font-mono"
          />
        </div>
        <label className="flex items-center gap-2 text-sm col-span-full">
          <input
            type="checkbox"
            checked={p.max_carryover_alap_quarter}
            onChange={(e) => setP({ ...p, max_carryover_alap_quarter: e.target.checked })}
          />
          Mt. 123. § – alapszabadság max 1/4-e vihető át
        </label>
      </Section>

      <button
        type="button"
        onClick={save}
        disabled={saving}
        className="inline-flex items-center gap-1.5 px-4 py-2 rounded-md bg-primary text-primary-foreground text-sm font-semibold hover:opacity-90 disabled:opacity-50"
      >
        {saving ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
        Mentés
      </button>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-lg border border-border bg-card p-4 space-y-3">
      <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">{title}</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">{children}</div>
    </section>
  );
}

function NumField({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) {
  return (
    <div>
      <label className="text-xs text-muted-foreground">{label}</label>
      <input
        type="number"
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm font-mono"
      />
    </div>
  );
}
