import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { getPortalAnalytics } from "@/lib/admin/portal-analytics.functions";
import { RouteErrorBoundary } from "@/lib/errors/route-boundaries";
import { extractRequestId } from "@/lib/errors/classify";
import { LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer } from "recharts";
import { Activity, ClipboardCheck, Clock, Sparkles } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin/portal-analitika")({
  component: PortalAnalitikaPage,
  errorComponent: RouteErrorBoundary,
  head: () => ({ meta: [{ title: "Portál analitika – Admin" }] }),
});

type Range = 7 | 30 | 90;

function PortalAnalitikaPage() {
  const [range, setRange] = useState<Range>(30);
  const fetcher = useServerFn(getPortalAnalytics);
  const { data, isLoading, error } = useQuery({
    queryKey: ["admin", "portal-analytics", range],
    queryFn: () => fetcher({ data: { days: range } }),
  });
  const analytics = data?.status === "ok" ? data : null;

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h1 className="text-2xl font-semibold">Portál analitika</h1>
          <p className="text-sm text-muted-foreground">Read-only mutatók a páciens-portál használatáról.</p>
        </div>
        <div className="flex gap-2">
          {([7, 30, 90] as Range[]).map((d) => (
            <Button key={d} variant={range === d ? "default" : "outline"} size="sm" onClick={() => setRange(d)}>
              {d} nap
            </Button>
          ))}
        </div>
      </div>

      {error && (() => {
        const { requestId, cleanMessage } = extractRequestId(error);
        return (
          <Card className="p-4 text-sm text-destructive space-y-1">
            <div>Nem sikerült betölteni: {cleanMessage || (error as Error).message}</div>
            {requestId && (
              <div className="text-xs font-mono text-muted-foreground">request_id: {requestId}</div>
            )}
          </Card>
        );
      })()}

      {data?.status === "forbidden" && (
        <Card className="p-4 text-sm text-muted-foreground">
          {data.message}
        </Card>
      )}

      {isLoading || (!analytics && data?.status !== "forbidden") ? (
        <Card className="p-6 text-sm text-muted-foreground">Betöltés…</Card>
      ) : analytics ? (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <KpiCard icon={<Activity className="h-4 w-4" />} label="Aktív páciensek" value={analytics.kpis.active_patients} hint={`Utolsó ${range} nap`} />
            <KpiCard icon={<ClipboardCheck className="h-4 w-4" />} label="Kitöltött kérdőívek" value={analytics.kpis.completed_questionnaires} hint={`Utolsó ${range} nap`} />
            <KpiCard icon={<Clock className="h-4 w-4" />} label="Riasztás válaszidő" value={`${analytics.kpis.avg_alert_ack_min} p`} hint={`p95: ${analytics.kpis.p95_alert_ack_min} p`} />
            <KpiCard icon={<Sparkles className="h-4 w-4" />} label="AI magyarázatok" value={analytics.kpis.ai_explanations} hint={`Utolsó ${range} nap`} />
          </div>

          <Card className="p-4">
            <div className="font-medium mb-3">Kérdőív kitöltések / nap</div>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={analytics.charts.questionnaire_daily}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
                  <Tooltip />
                  <Line type="monotone" dataKey="count" stroke="hsl(var(--primary))" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </>
      ) : (
        null
      )}
    </div>
  );
}

function KpiCard({ icon, label, value, hint }: { icon: React.ReactNode; label: string; value: number | string; hint?: string }) {
  return (
    <Card className="p-4">
      <div className="flex items-center gap-2 text-xs text-muted-foreground uppercase tracking-wide">
        {icon} {label}
      </div>
      <div className="text-2xl font-semibold mt-2">{value}</div>
      {hint && <div className="text-xs text-muted-foreground mt-1">{hint}</div>}
    </Card>
  );
}
