import { createFileRoute, Link } from "@tanstack/react-router";
import { LiveEditor } from "@/components/cms/visual/live-editor";
import { Button } from "@/components/ui/button";
import { Wrench } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin/cms/visual/")({
  ssr: false,
  component: VisualEditorPage,
});

function VisualEditorPage() {
  return (
    <div className="container mx-auto py-3 sm:py-6 px-3 sm:px-6 lg:px-8 max-w-[1600px]">
      <header className="mb-3 flex flex-wrap items-start justify-between gap-2">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold">Vizuális CMS szerkesztő</h1>
          <p className="text-xs sm:text-sm text-muted-foreground">
            A tényleges tervezett lap szerkeszthető in-place. Minden módosítás vázlatba kerül és blokk-szinten kell jóváhagyni.
          </p>
        </div>
        <Button asChild variant="outline" size="sm">
          <Link to="/admin/cms/visual/legacy" className="gap-1">
            <Wrench className="size-4" />Klasszikus szerkesztő
          </Link>
        </Button>
      </header>
      <LiveEditor />
    </div>
  );
}