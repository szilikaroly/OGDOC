import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, Fragment } from "react";
import { Loader2, MapPin, Plus, Trash2, Map as MapIcon } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { useTranslation } from "react-i18next";
import { usePermissions } from "@/hooks/use-permissions";
import { humanizeError } from "@/lib/humanize-error";
import { toast } from "sonner";
import { AnchorMap } from "@/components/jelenlet/anchor-map";

export const Route = createFileRoute("/_authenticated/admin/jelenlet-horgonyok")({
  component: AnchorsAdminPage,
});

type Anchor = {
  id: string;
  nev: string;
  tipus: string;
  geo_lat: number | null;
  geo_lng: number | null;
  geo_sugar_m: number | null;
  ip_cidr: string | null;
  ervenyes: boolean;
};

function AnchorsAdminPage() {
  const { user } = useAuth();
  const { t } = useTranslation();
  const { can } = usePermissions();
  const [rows, setRows] = useState<Anchor[]>([]);
  const [loading, setLoading] = useState(true);
  const [tenantId, setTenantId] = useState<string | null>(null);
  const [newNev, setNewNev] = useState("");
  const [mapId, setMapId] = useState<string | null>(null);
  const isAdmin = can("manage_tenant");

  useEffect(() => {
    if (!user) return;
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  async function load() {
    if (!user) return;
    setLoading(true);
    const { data: prof } = await supabase.from("profiles").select("tenant_id").eq("id", user.id).maybeSingle();
    setTenantId((prof as any)?.tenant_id ?? null);
    const { data, error } = await supabase
      .from("attendance_anchors")
      .select("id,nev,tipus,geo_lat,geo_lng,geo_sugar_m,ip_cidr,ervenyes")
      .order("nev");
    if (error) toast.error(humanizeError(error, t));
    else setRows((data ?? []) as Anchor[]);
    setLoading(false);
  }

  async function add() {
    if (!tenantId || !newNev.trim()) return;
    const { data, error } = await (supabase.from("attendance_anchors") as any)
      .insert({ tenant_id: tenantId, nev: newNev.trim(), tipus: "geofence", geo_sugar_m: 100 })
      .select()
      .single();
    if (error) return toast.error(humanizeError(error, t));
    setRows([...rows, data as Anchor]);
    setNewNev("");
  }

  async function update(id: string, patch: Partial<Anchor>) {
    const { error } = await (supabase.from("attendance_anchors") as any).update(patch).eq("id", id);
    if (error) return toast.error(humanizeError(error, t));
    setRows(rows.map((r) => (r.id === id ? { ...r, ...patch } : r)));
  }

  async function remove(id: string) {
    if (!confirm("Biztosan törli?")) return;
    const { error } = await supabase.from("attendance_anchors").delete().eq("id", id);
    if (error) return toast.error(humanizeError(error, t));
    setRows(rows.filter((r) => r.id !== id));
  }

  if (!isAdmin) {
    return <div className="p-6 text-sm text-muted-foreground">Nincs jogosultság.</div>;
  }
  if (loading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center gap-3">
        <MapPin className="h-6 w-6 text-primary" />
        <div>
          <h1 className="text-2xl font-semibold">Jelenléti horgonyok</h1>
          <p className="text-sm text-muted-foreground">Geofence / IP-tartomány telephely-egyezéshez</p>
        </div>
      </div>

      <div className="flex gap-2">
        <input
          value={newNev}
          onChange={(e) => setNewNev(e.target.value)}
          placeholder="Új horgony neve"
          className="flex-1 max-w-xs rounded border bg-background px-3 py-1.5 text-sm"
        />
        <button onClick={add} className="flex items-center gap-1 rounded bg-primary px-3 py-1.5 text-sm text-primary-foreground hover:opacity-90">
          <Plus className="h-4 w-4" /> Hozzáadás
        </button>
      </div>

      <div className="rounded-lg border bg-card overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-muted/40 text-xs">
            <tr>
              <th className="px-3 py-2 text-left">Név</th>
              <th className="px-3 py-2 text-left">Típus</th>
              <th className="px-3 py-2 text-left">Lat</th>
              <th className="px-3 py-2 text-left">Lng</th>
              <th className="px-3 py-2 text-left">Sugár (m)</th>
              <th className="px-3 py-2 text-left">IP CIDR</th>
              <th className="px-3 py-2 text-left">Érvényes</th>
              <th></th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {rows.map((r) => (
              <Fragment key={r.id}>
                <tr>
                  <td className="px-3 py-1">
                    <input defaultValue={r.nev} onBlur={(e) => e.target.value !== r.nev && update(r.id, { nev: e.target.value })} className="w-full bg-transparent" />
                  </td>
                  <td className="px-3 py-1">
                    <select defaultValue={r.tipus} onChange={(e) => update(r.id, { tipus: e.target.value })} className="bg-transparent">
                      <option value="geofence">geofence</option>
                      <option value="ip">ip</option>
                      <option value="nfc">nfc</option>
                      <option value="qr">qr</option>
                    </select>
                  </td>
                  <td className="px-3 py-1">
                    <input type="number" step="0.000001" defaultValue={r.geo_lat ?? ""} onBlur={(e) => update(r.id, { geo_lat: e.target.value ? Number(e.target.value) : null })} className="w-28 bg-transparent" />
                  </td>
                  <td className="px-3 py-1">
                    <input type="number" step="0.000001" defaultValue={r.geo_lng ?? ""} onBlur={(e) => update(r.id, { geo_lng: e.target.value ? Number(e.target.value) : null })} className="w-28 bg-transparent" />
                  </td>
                  <td className="px-3 py-1">
                    <input type="number" defaultValue={r.geo_sugar_m ?? ""} onBlur={(e) => update(r.id, { geo_sugar_m: e.target.value ? Number(e.target.value) : null })} className="w-20 bg-transparent" />
                  </td>
                  <td className="px-3 py-1">
                    <input defaultValue={r.ip_cidr ?? ""} placeholder="10.0.0.0/24" onBlur={(e) => update(r.id, { ip_cidr: e.target.value || null })} className="w-32 bg-transparent" />
                  </td>
                  <td className="px-3 py-1">
                    <input type="checkbox" checked={r.ervenyes} onChange={(e) => update(r.id, { ervenyes: e.target.checked })} />
                  </td>
                  <td className="px-3 py-1">
                    <div className="flex items-center gap-1">
                      {r.geo_lat != null && r.geo_lng != null && (
                        <button onClick={() => setMapId(mapId === r.id ? null : r.id)} title="Térkép" className="text-primary hover:opacity-80">
                          <MapIcon className="h-4 w-4" />
                        </button>
                      )}
                      <button onClick={() => remove(r.id)} className="text-rose-600 hover:text-rose-700">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
                {mapId === r.id && r.geo_lat != null && r.geo_lng != null && (
                  <tr>
                    <td colSpan={8} className="px-3 py-3 bg-muted/20">
                      <AnchorMap lat={r.geo_lat} lng={r.geo_lng} radiusM={r.geo_sugar_m} label={r.nev} />
                    </td>
                  </tr>
                )}
              </Fragment>
            ))}
            {rows.length === 0 && (
              <tr>
                <td colSpan={8} className="px-3 py-4 text-center text-muted-foreground italic">
                  Nincs horgony
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
