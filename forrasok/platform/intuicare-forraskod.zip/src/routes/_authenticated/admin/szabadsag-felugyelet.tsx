import { createFileRoute, useNavigate } from "@tanstack/react-router";
import React, { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import {
  Loader2,
  RefreshCw,
  Lock,
  PlayCircle,
  AlertTriangle,
  Download,
  FileText,
  ShieldCheck,
  History,
  ChevronDown,
  ChevronRight,
  X,
} from "lucide-react";
import { RouteErrorBoundary } from "@/lib/errors/route-boundaries";
import {
  recalcLeaveTenant,
  closeLeaveYear,
  enforceForcedLeave,
  exportLeavePlanCsv,
  generateLeavePlanPdf,
  listLeaveAudit,
  checkLeaveAdmin,
  type EnforceSummary,
} from "@/lib/leave/leave.functions";

export const Route = createFileRoute("/_authenticated/admin/szabadsag-felugyelet")({
  component: SzabadsagFelugyeletPage,
  errorComponent: RouteErrorBoundary,
});

type Row = {
  user_id: string;
  teljes_nev: string;
  ev: number;
  jaro: number;
  athozott: number;
  kiadott: number;
  hatralevo: number;
  forced: number;
  lezart: boolean;
};

type RunState =
  | { kind: "idle" }
  | { kind: "running"; label: string; percent?: number; note?: string }
  | {
      kind: "done";
      label: string;
      summary?: EnforceSummary;
      counts?: { total?: number; done?: number; failed?: number; notified?: number };
      ev: number;
      action: "recalc" | "close" | "dry" | "apply";
    };

function downloadBlob(filename: string, mime: string, data: BlobPart) {
  const blob = new Blob([data], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function SzabadsagFelugyeletPage() {
  const navigate = useNavigate();
  const [permChecked, setPermChecked] = useState(false);
  const [tab, setTab] = useState<"overview" | "audit">("overview");
  const [ev, setEv] = useState(new Date().getFullYear());
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [run, setRun] = useState<RunState>({ kind: "idle" });
  const [auditRows, setAuditRows] = useState<Array<Record<string, unknown>>>([]);
  const [auditLoading, setAuditLoading] = useState(false);
  const [auditExpanded, setAuditExpanded] = useState<string | null>(null);

  const checkPerm = useServerFn(checkLeaveAdmin);
  const recalc = useServerFn(recalcLeaveTenant);
  const close = useServerFn(closeLeaveYear);
  const enforce = useServerFn(enforceForcedLeave);
  const exportCsv = useServerFn(exportLeavePlanCsv);
  const exportPdf = useServerFn(generateLeavePlanPdf);
  const fetchAudit = useServerFn(listLeaveAudit);

  // RBAC guard
  useEffect(() => {
    (async () => {
      try {
        const res = await checkPerm();
        if (!res.ok) {
          toast.error("Nincs jogosultságod a szabadság-felügyelethez (manage_leave).");
          navigate({ to: "/dashboard" });
          return;
        }
        setPermChecked(true);
      } catch {
        toast.error("Jogosultság-ellenőrzés sikertelen.");
        navigate({ to: "/dashboard" });
      }
    })();
  }, [checkPerm, navigate]);

  async function load() {
    setLoading(true);
    const { data: ents } = await supabase
      .from("leave_entitlement")
      .select("user_id, ev, jaro_nap, manual_korrekcio, athozott_nap, kiadott_nap, forced_taken_nap, hatralevo, lezart_at")
      .eq("ev", ev);
    type Ent = {
      user_id: string;
      ev: number;
      jaro_nap: number;
      manual_korrekcio: number;
      athozott_nap: number;
      kiadott_nap: number;
      forced_taken_nap: number;
      hatralevo: number | null;
      lezart_at: string | null;
    };
    const entRows = (ents ?? []) as Ent[];
    const userIds = Array.from(new Set(entRows.map((r) => r.user_id)));
    const { data: profs } = userIds.length
      ? await supabase.from("profiles").select("id, teljes_nev").in("id", userIds)
      : { data: [] as Array<{ id: string; teljes_nev: string }> };
    const nameMap = new Map<string, string>((profs ?? []).map((p) => [p.id, p.teljes_nev]));

    const map = new Map<string, Row>();
    for (const r of entRows) {
      const cur = map.get(r.user_id) ?? {
        user_id: r.user_id,
        teljes_nev: nameMap.get(r.user_id) ?? r.user_id.slice(0, 8),
        ev: r.ev,
        jaro: 0,
        athozott: 0,
        kiadott: 0,
        hatralevo: 0,
        forced: 0,
        lezart: !!r.lezart_at,
      };
      cur.jaro += Number(r.jaro_nap) + Number(r.manual_korrekcio);
      cur.athozott += Number(r.athozott_nap);
      cur.kiadott += Number(r.kiadott_nap);
      cur.hatralevo += Number(r.hatralevo ?? 0);
      cur.forced += Number(r.forced_taken_nap);
      cur.lezart = cur.lezart && !!r.lezart_at;
      map.set(r.user_id, cur);
    }
    setRows(Array.from(map.values()).sort((a, b) => b.hatralevo - a.hatralevo));
    setLoading(false);
  }

  async function loadAudit() {
    setAuditLoading(true);
    try {
      const res = await fetchAudit({ data: { limit: 200 } });
      setAuditRows(res.rows as Array<Record<string, unknown>>);
    } catch (e) {
      toast.error(String((e as Error).message));
    } finally {
      setAuditLoading(false);
    }
  }

  useEffect(() => {
    if (permChecked) void load();
  }, [ev, permChecked]);

  useEffect(() => {
    if (permChecked && tab === "audit") void loadAudit();
  }, [tab, permChecked]);

  function riskLevel(r: Row): "ok" | "warn" | "bad" {
    const today = new Date();
    if (today.getFullYear() > r.ev) return r.hatralevo > 0 ? "bad" : "ok";
    if (today.getMonth() >= 10 && r.hatralevo > 5) return "warn";
    return "ok";
  }

  async function runRecalc() {
    setRun({ kind: "running", label: "Egyenlegek újraszámolása…" });
    try {
      const res = await recalc({ data: { ev } });
      setRun({
        kind: "done",
        label: "Újraszámolás kész",
        counts: { total: res.total, done: res.count, failed: res.failed },
        ev,
        action: "recalc",
      });
      await load();
    } catch (e) {
      toast.error(String((e as Error).message));
      setRun({ kind: "idle" });
    }
  }

  async function runClose() {
    if (!confirm(`Biztosan zárja a ${ev}-es évet? A hátralévő napok áthozódnak ${ev + 1}-re.`)) return;
    setRun({ kind: "running", label: `${ev}. év zárása…` });
    try {
      const res = await close({ data: { ev } });
      setRun({
        kind: "done",
        label: "Évzárás kész",
        counts: { done: res.count, notified: res.notified },
        ev,
        action: "close",
      });
      await load();
    } catch (e) {
      toast.error(String((e as Error).message));
      setRun({ kind: "idle" });
    }
  }

  async function runEnforce(dryRun: boolean) {
    setRun({
      kind: "running",
      label: dryRun ? "Kényszerkiadás szimuláció…" : "Kényszerkiadás véglegesítése…",
      note: dryRun ? "Nem készülnek tényleges bejegyzések." : "Bejegyzések, értesítések, audit log…",
    });
    try {
      const res = await enforce({ data: { ev, dryRun } });
      setRun({
        kind: "done",
        label: dryRun ? "Dry run kész" : "Kényszerkiadás véglegesítve",
        summary: res.summary,
        ev,
        action: dryRun ? "dry" : "apply",
      });
      if (!dryRun) await load();
    } catch (e) {
      toast.error(String((e as Error).message));
      setRun({ kind: "idle" });
    }
  }

  async function dlPlanCsv() {
    try {
      const res = await exportCsv({ data: { ev } });
      downloadBlob(res.filename, "text/csv;charset=utf-8", "\ufeff" + res.csv);
    } catch (e) {
      toast.error(String((e as Error).message));
    }
  }

  async function dlPlanPdf() {
    try {
      const res = await exportPdf({ data: { ev } });
      const bytes = Uint8Array.from(atob(res.pdf), (c) => c.charCodeAt(0));
      downloadBlob(res.filename, "application/pdf", bytes);
    } catch (e) {
      toast.error(`PDF generálás hiba: ${(e as Error).message}`);
    }
  }

  if (!permChecked) {
    return (
      <div className="p-12 flex items-center justify-center gap-2 text-muted-foreground">
        <ShieldCheck className="size-5" />
        Jogosultság ellenőrzése…
      </div>
    );
  }

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-6">
      <header className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Szabadság-felügyelet</h1>
          <p className="text-sm text-muted-foreground">
            Évenkénti egyenleg ellenőrzése, év zárása és kényszerkiadás futtatása.
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <select
            value={ev}
            onChange={(e) => setEv(Number(e.target.value))}
            className="px-3 py-2 rounded-md border border-input bg-background text-sm"
          >
            {[ev + 1, ev, ev - 1, ev - 2].map((y) => (
              <option key={y} value={y}>
                {y}
              </option>
            ))}
          </select>
          <button onClick={runRecalc} disabled={run.kind === "running"} className="btn-secondary">
            <RefreshCw className="size-3.5" /> Újraszámol
          </button>
          <button onClick={runClose} disabled={run.kind === "running"} className="btn-warning">
            <Lock className="size-3.5" /> Év zárása
          </button>
          <button onClick={() => runEnforce(true)} disabled={run.kind === "running"} className="btn-secondary">
            <AlertTriangle className="size-3.5" /> Kényszer (dry run)
          </button>
          <button onClick={() => runEnforce(false)} disabled={run.kind === "running"} className="btn-destructive">
            <PlayCircle className="size-3.5" /> Kényszer véglegesítése
          </button>
          <button onClick={dlPlanCsv} className="btn-secondary"><Download className="size-3.5" /> Terv CSV</button>
          <button onClick={dlPlanPdf} className="btn-secondary"><FileText className="size-3.5" /> Terv PDF</button>
        </div>
      </header>

      <style>{`
        .btn-secondary{display:inline-flex;align-items:center;gap:.25rem;padding:.5rem .75rem;border-radius:.375rem;background:hsl(var(--secondary));color:hsl(var(--secondary-foreground));font-size:.75rem;font-weight:600}
        .btn-secondary:hover{opacity:.9}
        .btn-warning{display:inline-flex;align-items:center;gap:.25rem;padding:.5rem .75rem;border-radius:.375rem;background:hsl(var(--warning));color:hsl(var(--warning-foreground));font-size:.75rem;font-weight:600}
        .btn-destructive{display:inline-flex;align-items:center;gap:.25rem;padding:.5rem .75rem;border-radius:.375rem;background:hsl(var(--destructive));color:hsl(var(--destructive-foreground));font-size:.75rem;font-weight:600}
        .btn-secondary:disabled,.btn-warning:disabled,.btn-destructive:disabled{opacity:.5;cursor:not-allowed}
      `}</style>

      <div className="flex gap-2 border-b border-border">
        <TabBtn active={tab === "overview"} onClick={() => setTab("overview")}>Áttekintés</TabBtn>
        <TabBtn active={tab === "audit"} onClick={() => setTab("audit")}>
          <History className="size-3.5" /> Audit napló
        </TabBtn>
      </div>

      {tab === "overview" ? (
        <div className="rounded-lg border border-border bg-card overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted text-xs uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="text-left p-3">Dolgozó</th>
                <th className="text-right p-3">Járó</th>
                <th className="text-right p-3">Áthozott</th>
                <th className="text-right p-3">Kiadott</th>
                <th className="text-right p-3">Kényszer</th>
                <th className="text-right p-3 font-bold">Hátralévő</th>
                <th className="text-center p-3">Állapot</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={7} className="p-8 text-center text-muted-foreground"><Loader2 className="size-5 animate-spin inline" /></td></tr>
              ) : rows.length === 0 ? (
                <tr><td colSpan={7} className="p-6 text-center text-muted-foreground text-xs">Nincs adat. Futtassa az „Újraszámol" gombot.</td></tr>
              ) : (
                rows.map((r) => {
                  const risk = riskLevel(r);
                  return (
                    <tr key={r.user_id} className="border-t border-border">
                      <td className="p-3 font-medium">{r.teljes_nev}</td>
                      <td className="p-3 text-right font-mono">{r.jaro.toFixed(1)}</td>
                      <td className="p-3 text-right font-mono text-warning">{r.athozott.toFixed(1)}</td>
                      <td className="p-3 text-right font-mono">{r.kiadott.toFixed(1)}</td>
                      <td className="p-3 text-right font-mono text-destructive">{r.forced.toFixed(1)}</td>
                      <td className="p-3 text-right font-mono font-bold">{r.hatralevo.toFixed(1)}</td>
                      <td className="p-3 text-center">
                        <span className={"inline-block size-2.5 rounded-full " + (risk === "bad" ? "bg-destructive" : risk === "warn" ? "bg-warning" : "bg-success")} />
                        {r.lezart && <span className="ml-2 text-[10px] text-muted-foreground">zárva</span>}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      ) : (
        <AuditPanel rows={auditRows} loading={auditLoading} expanded={auditExpanded} setExpanded={setAuditExpanded} />
      )}

      {run.kind !== "idle" && (
        <RunDialog state={run} onClose={() => setRun({ kind: "idle" })} />
      )}
    </div>
  );
}

function TabBtn({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`px-3 py-2 text-sm font-medium border-b-2 -mb-px inline-flex items-center gap-1.5 ${active ? "border-primary text-foreground" : "border-transparent text-muted-foreground hover:text-foreground"}`}
    >
      {children}
    </button>
  );
}

function RunDialog({ state, onClose }: { state: RunState; onClose: () => void }) {
  const running = state.kind === "running";
  return (
    <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-card border border-border rounded-lg shadow-2xl w-full max-w-2xl max-h-[85vh] overflow-auto">
        <div className="p-4 border-b border-border flex items-center justify-between">
          <h3 className="font-semibold text-sm flex items-center gap-2">
            {running ? <Loader2 className="size-4 animate-spin text-primary" /> : <PlayCircle className="size-4 text-success" />}
            {state.kind === "running" ? state.label : state.kind === "done" ? state.label : ""}
          </h3>
          {!running && (
            <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X className="size-4" /></button>
          )}
        </div>
        <div className="p-4 space-y-4">
          {state.kind === "running" && (
            <>
              <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                <div className="h-full bg-primary animate-pulse" style={{ width: `${state.percent ?? 60}%` }} />
              </div>
              {state.note && <p className="text-xs text-muted-foreground">{state.note}</p>}
            </>
          )}
          {state.kind === "done" && state.counts && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
              {state.counts.total != null && <StatCard label="Összes" v={state.counts.total} />}
              {state.counts.done != null && <StatCard label="Sikeres" v={state.counts.done} ok />}
              {state.counts.failed != null && <StatCard label="Hibás" v={state.counts.failed} bad />}
              {state.counts.notified != null && <StatCard label="Értesítve" v={state.counts.notified} />}
            </div>
          )}
          {state.kind === "done" && state.summary && (
            <SummaryView summary={state.summary} ev={state.ev} action={state.action} />
          )}
        </div>
      </div>
    </div>
  );
}

function StatCard({ label, v, ok, bad }: { label: string; v: number; ok?: boolean; bad?: boolean }) {
  return (
    <div className="rounded border border-border bg-background p-3">
      <div className="text-[10px] uppercase text-muted-foreground tracking-wider">{label}</div>
      <div className={`text-xl font-mono font-bold ${ok ? "text-success" : bad ? "text-destructive" : ""}`}>{v}</div>
    </div>
  );
}

function SummaryView({ summary, ev, action }: { summary: EnforceSummary; ev: number; action: string }) {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-2">
        <StatCard label="Érintett dolgozó" v={summary.affected_users} />
        <StatCard label="Összes nap" v={Number(summary.total_days.toFixed(1))} bad={action === "apply"} />
      </div>

      <div>
        <h4 className="text-xs font-semibold uppercase text-muted-foreground mb-2">Jogcímenként ({ev})</h4>
        <div className="rounded border border-border overflow-hidden">
          <table className="w-full text-xs">
            <tbody>
              {Object.entries(summary.by_jogcim).map(([j, n]) => (
                <tr key={j} className="border-t border-border first:border-t-0">
                  <td className="p-2">{j}</td>
                  <td className="p-2 text-right font-mono font-bold">{n.toFixed(1)} nap</td>
                </tr>
              ))}
              {Object.keys(summary.by_jogcim).length === 0 && (
                <tr><td className="p-3 text-center text-muted-foreground">Nincs érintett napszám.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <div>
        <h4 className="text-xs font-semibold uppercase text-muted-foreground mb-2">Dolgozónként</h4>
        <div className="rounded border border-border overflow-auto max-h-64">
          <table className="w-full text-xs">
            <thead className="bg-muted sticky top-0">
              <tr>
                <th className="text-left p-2">Dolgozó</th>
                <th className="text-right p-2">Összes</th>
                <th className="text-left p-2">Bontás</th>
              </tr>
            </thead>
            <tbody>
              {summary.by_user.map((u) => (
                <tr key={u.user_id} className="border-t border-border">
                  <td className="p-2 font-medium">{u.name}</td>
                  <td className="p-2 text-right font-mono font-bold">{u.total.toFixed(1)}</td>
                  <td className="p-2 text-muted-foreground">
                    {Object.entries(u.jogcims).map(([j, n]) => `${j}: ${n.toFixed(1)}`).join(" · ")}
                  </td>
                </tr>
              ))}
              {summary.by_user.length === 0 && (
                <tr><td colSpan={3} className="p-3 text-center text-muted-foreground">Nincs érintett dolgozó.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function AuditPanel({
  rows,
  loading,
  expanded,
  setExpanded,
}: {
  rows: Array<Record<string, unknown>>;
  loading: boolean;
  expanded: string | null;
  setExpanded: (id: string | null) => void;
}) {
  const ACTION_LABEL: Record<string, string> = {
    recalc_tenant: "Újraszámolás",
    close_year: "Évzárás",
    enforce_dry_run: "Kényszer (dry run)",
    enforce_apply: "Kényszer véglegesítés",
    policy_update: "Szabályzat módosítás",
  };
  return (
    <div className="rounded-lg border border-border bg-card overflow-hidden">
      {loading ? (
        <div className="p-8 text-center text-muted-foreground"><Loader2 className="size-5 animate-spin inline" /></div>
      ) : rows.length === 0 ? (
        <div className="p-6 text-center text-xs text-muted-foreground">Még nincs audit bejegyzés.</div>
      ) : (
        <table className="w-full text-xs">
          <thead className="bg-muted uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="text-left p-2">Dátum</th>
              <th className="text-left p-2">Aktor</th>
              <th className="text-left p-2">Művelet</th>
              <th className="text-left p-2">Év</th>
              <th className="text-left p-2">Érintett</th>
              <th className="text-right p-2">Nap</th>
              <th className="text-left p-2">Összegzés</th>
              <th className="w-8"></th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => {
              const id = r.id as string;
              const isOpen = expanded === id;
              return (
                <React.Fragment key={id}>
                  <tr className="border-t border-border hover:bg-muted/40 cursor-pointer" onClick={() => setExpanded(isOpen ? null : id)}>
                    <td className="p-2 font-mono">{new Date(r.created_at as string).toISOString().slice(0, 16).replace("T", " ")}</td>
                    <td className="p-2">{(r.actor_name as string) ?? "—"}</td>
                    <td className="p-2 font-medium">{ACTION_LABEL[r.action as string] ?? (r.action as string)}</td>
                    <td className="p-2">{(r.ev as number) ?? "—"}</td>
                    <td className="p-2">{(r.target_name as string) ?? "—"}</td>
                    <td className="p-2 text-right font-mono">{r.nap != null ? Number(r.nap).toFixed(1) : "—"}</td>
                    <td className="p-2 text-muted-foreground">{(r.summary as string) ?? ""}</td>
                    <td className="p-2 text-right">{isOpen ? <ChevronDown className="size-3 inline" /> : <ChevronRight className="size-3 inline" />}</td>
                  </tr>
                  {isOpen && (
                    <tr className="bg-muted/30 border-t border-border">
                      <td colSpan={8} className="p-3">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                          <Pre title="Előtte" json={r.before_data as string | null} />
                          <Pre title="Utána" json={r.after_data as string | null} />
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              );
            })}
          </tbody>
        </table>
      )}
    </div>
  );
}

function Pre({ title, json }: { title: string; json: string | null }) {
  return (
    <div>
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">{title}</div>
      <pre className="text-[11px] font-mono p-2 bg-background border border-border rounded max-h-48 overflow-auto whitespace-pre-wrap break-all">
        {json ? (() => { try { return JSON.stringify(JSON.parse(json), null, 2); } catch { return json; } })() : "—"}
      </pre>
    </div>
  );
}
