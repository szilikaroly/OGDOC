import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { StatusBadge, type StatusTone } from "@/components/ui/status-badge";
import { Mail, Send, RefreshCw, AlertTriangle, CheckCircle2, BellRing } from "lucide-react";

import {
  getDigestSettings,
  updateDigestSettings,
  listEmailLog,
  triggerWeeklyDigestNow,
  type DigestSettings,
} from "@/lib/email-admin.functions";
import {
  getPushAdminSettings,
  updatePushAdminSettings,
  type PushAdminSettings,
} from "@/lib/push/push.functions";


export const Route = createFileRoute("/_authenticated/admin/email")({
  component: EmailAdminPage,
});

const DAYS = ["Vasárnap", "Hétfő", "Kedd", "Szerda", "Csütörtök", "Péntek", "Szombat"];
const SECTIONS: Array<{ key: string; label: string }> = [
  { key: "new_patients", label: "Új páciensek" },
  { key: "questionnaires", label: "Kitöltött kérdőívek" },
  { key: "critical_alerts", label: "Kritikus riasztások" },
  { key: "referrals", label: "Beutaló kérelmek" },
  { key: "eeszt_errors", label: "EESZT szinkron hibák" },
];
const ROLE_OPTIONS = [
  { key: "tenant_admin", label: "Tenant admin" },
  { key: "igazgato", label: "Igazgató" },
  { key: "intezetvezeto", label: "Intézetvezető" },
  { key: "telephelyvezeto", label: "Telephelyvezető" },
  { key: "ugyeletvezeto", label: "Ügyeletvezető" },
  { key: "foorvos", label: "Főorvos" },
];

function statusTone(s: string | null): StatusTone {
  if (s === "sent") return "ok";
  if (s === "dlq" || s === "failed" || s === "bounced") return "bad";
  if (s === "suppressed" || s === "complained") return "warn";
  return "neutral";
}

function EmailAdminPage() {
  const getFn = useServerFn(getDigestSettings);
  const updateFn = useServerFn(updateDigestSettings);
  const triggerFn = useServerFn(triggerWeeklyDigestNow);
  const listLogFn = useServerFn(listEmailLog);
  const qc = useQueryClient();

  const settingsQ = useQuery<DigestSettings>({ queryKey: ["digest-settings"], queryFn: () => getFn() });
  const logQ = useQuery({ queryKey: ["email-log"], queryFn: () => listLogFn({ data: { days: 14 } }) });

  const [local, setLocal] = useState<DigestSettings | null>(null);
  useEffect(() => {
    if (settingsQ.data) setLocal(settingsQ.data);
  }, [settingsQ.data]);

  const saveMut = useMutation({
    mutationFn: async (patch: Partial<DigestSettings>) => updateFn({ data: patch as any }),
    onSuccess: (data) => {
      setLocal(data);
      qc.setQueryData(["digest-settings"], data);
      toast.success("Beállítások mentve");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const triggerMut = useMutation({
    mutationFn: () => triggerFn(),
    onSuccess: (r) => {
      if (r.ok) toast.success(`Digest kiküldve (${r.recipients} címzett)`);
      else toast.warning(`Nincs kiküldés: ${r.skipped ?? "ismeretlen"}`);
      qc.invalidateQueries({ queryKey: ["email-log"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const set = <K extends keyof DigestSettings>(k: K, v: DigestSettings[K]) => {
    if (!local) return;
    setLocal({ ...local, [k]: v });
  };

  const toggleSection = (key: string, value: boolean) => {
    if (!local) return;
    setLocal({ ...local, include_sections: { ...local.include_sections, [key]: value } });
  };

  const toggleRole = (key: string, value: boolean) => {
    if (!local) return;
    const next = new Set(local.recipient_roles ?? []);
    if (value) next.add(key);
    else next.delete(key);
    setLocal({ ...local, recipient_roles: Array.from(next) });
  };

  return (
    <main className="container mx-auto max-w-5xl px-4 py-6 space-y-6">
      <header className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Mail className="size-6" /> Email adminisztráció
          </h1>
          <p className="text-sm text-muted-foreground">Domain, heti összefoglaló és kiküldési napló</p>
        </div>
      </header>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle2 className="size-5 text-emerald-600" /> Email domain
          </CardTitle>
          <CardDescription>
            A küldési domain workspace szinten beállítható. Ha nincs csatolva ehhez a projekthez, a beállító varázsló segít.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          <p>
            Aktuális workspace domain: <code className="bg-muted px-1.5 py-0.5 rounded">notify.sos-24.hu</code> (verifikált)
          </p>
          <p className="text-muted-foreground">
            A projekthez csatolás után a heti digest, valamint a tranzakciós e-mailek a Lovable Email infrastruktúrán
            keresztül kerülnek kézbesítésre (sor, DLQ, suppression-kezelés).
          </p>
          <p className="text-xs text-muted-foreground">
            A projekthez csatoláshoz lépj a Project Settings → Email menüpontra, vagy kérd Lovable-től a setup varázslót a chatben.
          </p>
        </CardContent>
      </Card>

      <Tabs defaultValue="digest" className="w-full">
        <TabsList>
          <TabsTrigger value="digest">Heti összefoglaló</TabsTrigger>
          <TabsTrigger value="push">Push értesítések</TabsTrigger>
          <TabsTrigger value="log">Kiküldési napló</TabsTrigger>
        </TabsList>


        <TabsContent value="digest" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Beállítások</CardTitle>
              <CardDescription>Időpont, címzettek és tartalom testreszabása.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-5">
              {settingsQ.isLoading || !local ? (
                <p className="text-sm text-muted-foreground">Betöltés…</p>
              ) : (
                <>
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <Label className="text-base">Aktív</Label>
                      <p className="text-xs text-muted-foreground">A digest csak akkor megy ki, ha be van kapcsolva.</p>
                    </div>
                    <Switch checked={local.enabled} onCheckedChange={(v) => set("enabled", v)} />
                  </div>

                  <div className="grid sm:grid-cols-3 gap-4">
                    <div>
                      <Label>Hét napja</Label>
                      <Select value={String(local.day_of_week)} onValueChange={(v) => set("day_of_week", Number(v))}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {DAYS.map((d, i) => (
                            <SelectItem key={i} value={String(i)}>{d}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Helyi óra</Label>
                      <Input
                        type="number" min={0} max={23} value={local.hour_local}
                        onChange={(e) => set("hour_local", Math.max(0, Math.min(23, Number(e.target.value))))}
                      />
                    </div>
                    <div>
                      <Label>Időzóna</Label>
                      <Input value={local.timezone} onChange={(e) => set("timezone", e.target.value)} />
                    </div>
                  </div>

                  <div>
                    <Label className="text-base mb-2 block">Címzett szerepkörök</Label>
                    <div className="grid sm:grid-cols-2 gap-2">
                      {ROLE_OPTIONS.map((r) => {
                        const checked = (local.recipient_roles ?? []).includes(r.key);
                        return (
                          <label key={r.key} className="flex items-center gap-2 text-sm">
                            <Switch checked={checked} onCheckedChange={(v) => toggleRole(r.key, v)} />
                            {r.label} <code className="text-xs text-muted-foreground">{r.key}</code>
                          </label>
                        );
                      })}
                    </div>
                  </div>

                  <div>
                    <Label className="text-base mb-2 block">Tartalmi szekciók</Label>
                    <div className="grid sm:grid-cols-2 gap-2">
                      {SECTIONS.map((s) => {
                        const v = Boolean(local.include_sections?.[s.key]);
                        return (
                          <label key={s.key} className="flex items-center gap-2 text-sm">
                            <Switch checked={v} onCheckedChange={(val) => toggleSection(s.key, val)} />
                            {s.label}
                          </label>
                        );
                      })}
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t">
                    <p className="text-xs text-muted-foreground">
                      Utolsó kiküldés: {local.last_sent_at ? new Date(local.last_sent_at).toLocaleString("hu-HU") : "—"}
                    </p>
                    <div className="flex gap-2">
                      <Button
                        variant="outline" size="sm"
                        onClick={() => triggerMut.mutate()}
                        disabled={triggerMut.isPending}
                      >
                        <Send className="size-4 mr-1.5" />
                        {triggerMut.isPending ? "Küldés…" : "Digest küldése most"}
                      </Button>
                      <Button
                        size="sm"
                        onClick={() => saveMut.mutate({
                          enabled: local.enabled,
                          day_of_week: local.day_of_week,
                          hour_local: local.hour_local,
                          timezone: local.timezone,
                          recipient_roles: local.recipient_roles,
                          include_sections: local.include_sections,
                        })}
                        disabled={saveMut.isPending}
                      >
                        Mentés
                      </Button>
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="log">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Kiküldési napló (14 nap)</CardTitle>
                <CardDescription>A legutóbbi 500 küldés, message_id alapján deduplikálva.</CardDescription>
              </div>
              <Button variant="ghost" size="icon" aria-label="Frissítés" onClick={() => logQ.refetch()}>
                <RefreshCw className="size-4" />
              </Button>
            </CardHeader>
            <CardContent>
              {logQ.isLoading ? (
                <p className="text-sm text-muted-foreground">Betöltés…</p>
              ) : !logQ.data?.supported ? (
                <div className="flex items-start gap-2 text-sm text-amber-700 dark:text-amber-400">
                  <AlertTriangle className="size-4 mt-0.5" />
                  <p>Az email_send_log tábla még nincs létrehozva. A Lovable Email infrastruktúra beállítása után jelenik meg.</p>
                </div>
              ) : logQ.data.rows.length === 0 ? (
                <p className="text-sm text-muted-foreground">Nincs kiküldés a kiválasztott időszakban.</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="text-left text-xs text-muted-foreground border-b">
                      <tr>
                        <th className="py-2 pr-3">Időpont</th>
                        <th className="py-2 pr-3">Sablon</th>
                        <th className="py-2 pr-3">Címzett</th>
                        <th className="py-2 pr-3">Státusz</th>
                        <th className="py-2">Hiba</th>
                      </tr>
                    </thead>
                    <tbody>
                      {logQ.data.rows.map((r) => (
                        <tr key={r.id} className="border-b last:border-0">
                          <td className="py-1.5 pr-3 text-xs text-muted-foreground whitespace-nowrap">
                            {new Date(r.created_at).toLocaleString("hu-HU")}
                          </td>
                          <td className="py-1.5 pr-3">{r.template_name ?? "—"}</td>
                          <td className="py-1.5 pr-3">{r.recipient_email ?? "—"}</td>
                          <td className="py-1.5 pr-3">
                            <StatusBadge tone={statusTone(r.status)}>{r.status ?? "—"}</StatusBadge>
                          </td>
                          <td className="py-1.5 text-xs text-destructive">{r.error_message ?? ""}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="push">
          <PushSettingsCard />
        </TabsContent>
      </Tabs>

    </main>
  );
}

function PushSettingsCard() {
  const getFn = useServerFn(getPushAdminSettings);
  const updateFn = useServerFn(updatePushAdminSettings);
  const qc = useQueryClient();
  const q = useQuery<PushAdminSettings>({ queryKey: ["push-admin-settings"], queryFn: () => getFn() });
  const [subject, setSubject] = useState("");
  const [enabled, setEnabled] = useState(true);
  useEffect(() => {
    if (q.data) {
      setSubject(q.data.vapid_subject);
      setEnabled(q.data.enabled);
    }
  }, [q.data]);
  const saveMut = useMutation({
    mutationFn: (patch: { vapid_subject?: string; enabled?: boolean }) => updateFn({ data: patch }),
    onSuccess: (d) => {
      qc.setQueryData(["push-admin-settings"], d);
      toast.success("Push beállítások mentve");
    },
    onError: (e: Error) => toast.error(e.message),
  });
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BellRing className="size-5" /> Push értesítések (VAPID)
        </CardTitle>
        <CardDescription>
          A „subject” mező a böngészők push szolgáltatása felé azonosítja a feladót. Lehet
          <code className="bg-muted px-1 mx-1 rounded">mailto:…</code> vagy
          <code className="bg-muted px-1 mx-1 rounded">https://…</code>.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {q.isLoading || !q.data ? (
          <p className="text-sm text-muted-foreground">Betöltés…</p>
        ) : (
          <>
            <div className="flex items-center justify-between gap-4">
              <div>
                <Label className="text-base">Push küldés aktív</Label>
                <p className="text-xs text-muted-foreground">Kikapcsolva csak in-app értesítés megy ki.</p>
              </div>
              <Switch checked={enabled} onCheckedChange={setEnabled} />
            </div>
            <div>
              <Label htmlFor="vapid-subject">VAPID subject</Label>
              <Input
                id="vapid-subject"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="mailto:admin@pelda.hu"
              />
              <p className="text-xs text-muted-foreground mt-1">
                Pl.: <code>mailto:szilikaroly@gmail.com</code>
              </p>
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="flex items-center gap-2">
                {q.data.has_public_key ? (
                  <StatusBadge tone="ok">VAPID_PUBLIC_KEY konfigurálva</StatusBadge>
                ) : (
                  <StatusBadge tone="bad">VAPID_PUBLIC_KEY hiányzik</StatusBadge>
                )}
              </div>
              <div className="flex items-center gap-2">
                {q.data.has_private_key ? (
                  <StatusBadge tone="ok">VAPID_PRIVATE_KEY konfigurálva</StatusBadge>
                ) : (
                  <StatusBadge tone="bad">VAPID_PRIVATE_KEY hiányzik</StatusBadge>
                )}
              </div>
            </div>
            <div className="flex items-center justify-between pt-2 border-t">
              <p className="text-xs text-muted-foreground">
                Utolsó módosítás: {new Date(q.data.updated_at).toLocaleString("hu-HU")}
              </p>
              <Button
                size="sm"
                onClick={() => saveMut.mutate({ vapid_subject: subject.trim(), enabled })}
                disabled={saveMut.isPending}
              >
                Mentés
              </Button>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}

