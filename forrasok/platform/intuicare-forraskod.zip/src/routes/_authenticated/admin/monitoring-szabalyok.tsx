/**
 * Admin — Otthoni monitoring küszöbszabályok (monitoring_thresholds).
 * Globális (tenant) vagy páciens-specifikus küszöbök szerkesztése.
 */
import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { Plus, Pencil, Trash2, ChevronLeft, Activity } from "lucide-react";
import {
  listMonitoringThresholds, upsertMonitoringThreshold, deleteMonitoringThreshold,
} from "@/lib/monitoring/thresholds.functions";
import { ThresholdFormSchema } from "@/lib/monitoring/threshold-schema";
import { PatientPicker, type PatientPickerValue } from "@/components/admin/patient-picker";
import { listMonitoringPrograms } from "@/lib/admin/lookups.functions";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";

export const Route = createFileRoute("/_authenticated/admin/monitoring-szabalyok")({
  component: MonitoringSzabalyokPage,
});

const PRESET_KEYS = [
  { kulcs: "vernyomas_sys_max", unit: "mmHg", default: 140 },
  { kulcs: "vernyomas_dia_max", unit: "mmHg", default: 90 },
  { kulcs: "vercukor_max", unit: "mmol/L", default: 7.8 },
  { kulcs: "pulzus_max", unit: "bpm", default: 100 },
  { kulcs: "pulzus_min", unit: "bpm", default: 50 },
  { kulcs: "testho_max", unit: "°C", default: 38 },
  { kulcs: "magzatmozgas_min_per_ora", unit: "db/ó", default: 4 },
];

function EditDialog({
  initial, onClose, onSaved,
}: {
  initial: any | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const fn = useServerFn(upsertMonitoringThreshold);
  const [kulcs, setKulcs] = useState<string>(initial?.kulcs ?? PRESET_KEYS[0].kulcs);
  const [ertek, setErtek] = useState<string>(initial ? String(initial.ertek) : String(PRESET_KEYS[0].default));
  const [unit, setUnit] = useState<string>(initial?.unit ?? PRESET_KEYS[0].unit);
  const [megjegyzes, setMegjegyzes] = useState<string>(initial?.megjegyzes ?? "");
  const [patient, setPatient] = useState<PatientPickerValue>(
    initial?.patient_id ? { id: initial.patient_id, label: initial.patient_label ?? "Páciens-spec." } : null,
  );
  const [programId, setProgramId] = useState<string>(initial?.program_id ?? "");
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const programsFn = useServerFn(listMonitoringPrograms);
  const { data: programs } = useQuery({
    queryKey: ["admin", "monitoring-programs"],
    queryFn: () => programsFn(),
    staleTime: 60_000,
  });

  const validate = () => {
    const parsed = ThresholdFormSchema.safeParse({
      kulcs: kulcs.trim(),
      ertek: ertek === "" || Number.isNaN(Number(ertek)) ? Number.NaN : Number(ertek),
      unit: unit || null,
      megjegyzes: megjegyzes || null,
      patient_id: patient?.id || null,
      program_id: programId || null,
    });
    if (!parsed.success) {
      const errs: Record<string, string> = {};
      for (const issue of parsed.error.issues) {
        const k = String(issue.path[0] ?? "");
        if (k && !errs[k]) errs[k] = issue.message;
      }
      setFieldErrors(errs);
      return null;
    }
    setFieldErrors({});
    return parsed.data;
  };

  const save = useMutation({
    mutationFn: async () => {
      const v = validate();
      if (!v) throw new Error("Javítsa a kiemelt mezőket");
      return fn({ data: {
        id: initial?.id,
        kulcs: v.kulcs,
        ertek: v.ertek,
        unit: v.unit ?? null,
        megjegyzes: v.megjegyzes ?? null,
        patient_id: (v.patient_id as string | null) || null,
        program_id: (v.program_id as string | null) || null,
      }});
    },
    onSuccess: () => { toast.success("Mentve"); onSaved(); onClose(); },
    onError: (e: any) => toast.error(e?.message ?? "Hiba"),
  });

  const errClass = (k: string) => fieldErrors[k] ? "border-destructive focus-visible:ring-destructive" : "";
  const FieldError = ({ k }: { k: string }) =>
    fieldErrors[k] ? <p className="text-xs text-destructive">{fieldErrors[k]}</p> : null;

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{initial ? "Küszöb szerkesztése" : "Új küszöb"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1">
            <Label>Kulcs</Label>
            <Input value={kulcs} aria-invalid={!!fieldErrors.kulcs} className={errClass("kulcs")} onChange={(e) => {
              setKulcs(e.target.value);
              const p = PRESET_KEYS.find((k) => k.kulcs === e.target.value);
              if (p) { setUnit(p.unit); if (!initial) setErtek(String(p.default)); }
            }} list="threshold-presets" placeholder="pl. vernyomas_sys_max" />
            <datalist id="threshold-presets">
              {PRESET_KEYS.map((p) => <option key={p.kulcs} value={p.kulcs} />)}
            </datalist>
            <FieldError k="kulcs" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label>Érték</Label>
              <Input type="number" step="0.1" value={ertek} aria-invalid={!!fieldErrors.ertek} className={errClass("ertek")} onChange={(e) => setErtek(e.target.value)} />
              <FieldError k="ertek" />
            </div>
            <div className="space-y-1">
              <Label>Mértékegység</Label>
              <Input value={unit} aria-invalid={!!fieldErrors.unit} className={errClass("unit")} onChange={(e) => setUnit(e.target.value)} placeholder="pl. mmHg" />
              <FieldError k="unit" />
            </div>
          </div>
          <div className="space-y-1">
            <Label>Páciens <span className="text-muted-foreground text-xs">(üres = globális tenant-szabály)</span></Label>
            <PatientPicker value={patient} onChange={setPatient} ariaInvalid={!!fieldErrors.patient_id} />
            <FieldError k="patient_id" />
          </div>
          <div className="space-y-1">
            <Label>Monitoring program <span className="text-muted-foreground text-xs">(opcionális)</span></Label>
            <Select value={programId || "__none__"} onValueChange={(v) => setProgramId(v === "__none__" ? "" : v)}>
              <SelectTrigger aria-invalid={!!fieldErrors.program_id} className={errClass("program_id")}>
                <SelectValue placeholder="Nincs programhoz kötve" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="__none__">— Nincs programhoz kötve —</SelectItem>
                {(programs ?? []).map((p) => (
                  <SelectItem key={p.id} value={p.id}>
                    {p.tipus} · {p.kezdes ? new Date(p.kezdes).toLocaleDateString("hu-HU") : "—"}{!p.aktiv ? " (inaktív)" : ""}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <FieldError k="program_id" />
          </div>
          <div className="space-y-1">
            <Label>Megjegyzés</Label>
            <Textarea rows={2} value={megjegyzes} aria-invalid={!!fieldErrors.megjegyzes} className={errClass("megjegyzes")} onChange={(e) => setMegjegyzes(e.target.value)} />
            <FieldError k="megjegyzes" />
          </div>
          {Object.keys(fieldErrors).length > 0 && (
            <div className="rounded-md border border-destructive/40 bg-destructive/5 p-2 text-xs text-destructive">
              Javítsa a kiemelt mezőket a mentés előtt.
            </div>
          )}
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={onClose}>Mégse</Button>
          <Button onClick={() => save.mutate()} disabled={save.isPending}>Mentés</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function MonitoringSzabalyokPage() {
  const qc = useQueryClient();
  const list = useServerFn(listMonitoringThresholds);
  const { data, isLoading } = useQuery({ queryKey: ["monitoring", "thresholds"], queryFn: () => list() });
  const del = useServerFn(deleteMonitoringThreshold);
  const delM = useMutation({
    mutationFn: (id: string) => del({ data: { id } }),
    onSuccess: () => { toast.success("Törölve"); qc.invalidateQueries({ queryKey: ["monitoring", "thresholds"] }); },
    onError: (e: any) => toast.error(e?.message ?? "Hiba"),
  });
  const [editing, setEditing] = useState<any | null>(null);
  const [creating, setCreating] = useState(false);

  return (
    
      <div className="space-y-6">
        <div>
          <Link to="/admin/szervezet" className="text-xs text-muted-foreground hover:underline inline-flex items-center gap-1">
            <ChevronLeft className="h-3 w-3" /> Admin
          </Link>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <Activity className="h-6 w-6" /> Otthoni monitoring szabályok
          </h1>
          <p className="text-sm text-muted-foreground">
            Küszöbértékek mérésekhez (vérnyomás, vércukor, pulzus, magzatmozgás stb.). Páciens-specifikus felülírás támogatott.
          </p>
        </div>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-base">Küszöbök ({data?.length ?? 0})</CardTitle>
            <Button size="sm" onClick={() => setCreating(true)}><Plus className="h-4 w-4 mr-1" /> Új küszöb</Button>
          </CardHeader>
          <CardContent>
            {isLoading && <p className="text-sm text-muted-foreground">Betöltés…</p>}
            {!isLoading && (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Kulcs</TableHead>
                    <TableHead>Érték</TableHead>
                    <TableHead>Hatókör</TableHead>
                    <TableHead>Megjegyzés</TableHead>
                    <TableHead className="text-right">Művelet</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {(data ?? []).map((r: any) => (
                    <TableRow key={r.id}>
                      <TableCell className="font-mono text-xs">{r.kulcs}</TableCell>
                      <TableCell>{r.ertek} {r.unit ?? ""}</TableCell>
                      <TableCell>
                        {r.patient_id ? <Badge variant="outline">Páciens-spec.</Badge> : <Badge>Globális</Badge>}
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground max-w-md truncate">{r.megjegyzes ?? ""}</TableCell>
                      <TableCell className="text-right space-x-1">
                        <Button size="icon" variant="ghost" onClick={() => setEditing(r)}><Pencil className="h-4 w-4" /></Button>
                        <Button size="icon" variant="ghost" onClick={() => {
                          if (confirm("Biztos törlöd?")) delM.mutate(r.id);
                        }}><Trash2 className="h-4 w-4" /></Button>
                      </TableCell>
                    </TableRow>
                  ))}
                  {(data ?? []).length === 0 && !isLoading && (
                    <TableRow><TableCell colSpan={5} className="text-center text-sm text-muted-foreground py-8">Nincs küszöb rögzítve.</TableCell></TableRow>
                  )}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        {(editing || creating) && (
          <EditDialog
            initial={editing}
            onClose={() => { setEditing(null); setCreating(false); }}
            onSaved={() => qc.invalidateQueries({ queryKey: ["monitoring", "thresholds"] })}
          />
        )}
      </div>
    
  );
}
