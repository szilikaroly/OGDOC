import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { supabase } from "@/integrations/supabase/client";

import { toast } from "sonner";
import { humanizeError } from "@/lib/humanize-error";
import { applyReason } from "@/lib/audit-reason";
import { ReasonInput } from "@/components/reason-input";
import { Plus, Trash2, ShieldCheck, Search } from "lucide-react";
import { cn } from "@/lib/utils";
import { TranslatorMenu } from "@/components/i18n/TranslatorMenu";

export const Route = createFileRoute("/_authenticated/admin/szerepkorok")({
  component: SzerepkorokPage,
});

type Profile = { id: string; teljes_nev: string; email: string };
type Role = { id: string; kulcs: string; megnevezes: string; kategoria: string; sorrend: number };
type UserRole = {
  id: string;
  user_id: string;
  role_id: string;
  site_id: string | null;
  org_unit_id: string | null;
};
type Site = { id: string; nev: string };
type OrgUnit = { id: string; nev: string; site_id: string };

function SzerepkorokPage() {
  const { t } = useTranslation();
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [roles, setRoles] = useState<Role[]>([]);
  const [assignments, setAssignments] = useState<UserRole[]>([]);
  const [sites, setSites] = useState<Site[]>([]);
  const [orgUnits, setOrgUnits] = useState<OrgUnit[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [openProfileId, setOpenProfileId] = useState<string | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);

  async function loadAll() {
    setLoading(true);
    const [{ data: pr }, { data: rl }, { data: ur }, { data: st }, { data: ou }, { data: { user } }] =
      await Promise.all([
        supabase.from("profiles").select("id,teljes_nev,email").order("teljes_nev"),
        supabase.from("roles").select("id,kulcs,megnevezes,kategoria,sorrend").order("sorrend"),
        supabase.from("user_roles").select("id,user_id,role_id,site_id,org_unit_id"),
        supabase.from("sites").select("id,nev").order("nev"),
        supabase.from("org_units").select("id,nev,site_id").order("nev"),
        supabase.auth.getUser(),
      ]);
    setProfiles((pr ?? []) as Profile[]);
    setRoles((rl ?? []) as Role[]);
    setAssignments((ur ?? []) as UserRole[]);
    setSites((st ?? []) as Site[]);
    setOrgUnits((ou ?? []) as OrgUnit[]);
    if (user) {
      const { data: admin } = await supabase.rpc("has_permission", {
        _user_id: user.id,
        _perm: "manage_roles",
      });
      setIsAdmin(Boolean(admin));
    }
    setLoading(false);
  }

  useEffect(() => {
    loadAll();
  }, []);

  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim();
    if (!q) return profiles;
    return profiles.filter(
      (p) => p.teljes_nev.toLowerCase().includes(q) || p.email.toLowerCase().includes(q),
    );
  }, [profiles, search]);

  const rolesByUser = useMemo(() => {
    const map = new Map<string, UserRole[]>();
    for (const a of assignments) {
      const arr = map.get(a.user_id) ?? [];
      arr.push(a);
      map.set(a.user_id, arr);
    }
    return map;
  }, [assignments]);

  const roleById = useMemo(() => new Map(roles.map((r) => [r.id, r])), [roles]);

  return (
      <div className="p-8 max-w-6xl mx-auto">
        <div className="mb-6 flex items-center gap-3">
          <ShieldCheck className="size-6 text-primary" />
          <div>
            <h1 className="text-2xl font-bold tracking-tight">{t("szerepkorok.title")}</h1>
            <p className="text-sm text-muted-foreground font-mono uppercase tracking-wider">
              {t("szerepkorok.subtitle")}
            </p>
          </div>
        </div>

        {!isAdmin && !loading && (
          <div className="mb-4 p-3 rounded-lg border border-warning/30 bg-warning/10 text-sm">
            {t("szerepkorok.no_admin")}
          </div>
        )}

        <div className="mb-4 relative">
          <Search className="size-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t("common.search")}
            className="w-full pl-10 pr-3 py-2 bg-card border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>

        <div className="bg-card border border-border rounded-2xl overflow-hidden">
          {loading ? (
            <div className="p-8 text-center text-sm text-muted-foreground">{t("common.loading")}</div>
          ) : filtered.length === 0 ? (
            <div className="p-8 text-center text-sm text-muted-foreground">{t("common.empty")}</div>
          ) : (
            <ul className="divide-y divide-border">
              {filtered.map((p) => {
                const userRoles = rolesByUser.get(p.id) ?? [];
                const open = openProfileId === p.id;
                return (
                  <li key={p.id}>
                    <button
                      type="button"
                      onClick={() => setOpenProfileId(open ? null : p.id)}
                      className="w-full p-4 flex items-center justify-between hover:bg-secondary/40 transition-colors text-left"
                    >
                      <div>
                        <div className="text-sm font-semibold">{p.teljes_nev}</div>
                        <div className="text-xs text-muted-foreground font-mono">{p.email}</div>
                      </div>
                      <div className="flex items-center gap-1.5 flex-wrap justify-end max-w-xs">
                        {userRoles.length === 0 ? (
                          <span className="text-[10px] font-mono uppercase text-muted-foreground">
                            {t("szerepkorok.no_roles")}
                          </span>
                        ) : (
                          userRoles.map((ur) => {
                            const r = roleById.get(ur.role_id);
                            return (
                              <span
                                key={ur.id}
                                className="px-2 py-0.5 rounded-full bg-secondary text-[10px] font-mono font-semibold uppercase"
                              >
                                {r?.megnevezes ?? "?"}
                              </span>
                            );
                          })
                        )}
                      </div>
                    </button>
                    {open && (
                      <RoleAssignmentPanel
                        profile={p}
                        userRoles={userRoles}
                        roles={roles}
                        sites={sites}
                        orgUnits={orgUnits}
                        disabled={!isAdmin}
                        onChange={loadAll}
                      />
                    )}
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </div>
  );
}

function RoleAssignmentPanel({
  profile,
  userRoles,
  roles,
  sites,
  orgUnits,
  disabled,
  onChange,
}: {
  profile: Profile;
  userRoles: UserRole[];
  roles: Role[];
  sites: Site[];
  orgUnits: OrgUnit[];
  disabled: boolean;
  onChange: () => void;
}) {
  const { t } = useTranslation();
  const [roleId, setRoleId] = useState<string>("");
  const [siteId, setSiteId] = useState<string>("");
  const [orgUnitId, setOrgUnitId] = useState<string>("");
  const [busy, setBusy] = useState(false);
  const [reason, setReason] = useState("");

  async function add() {
    if (!roleId) return;
    setBusy(true);
    const { data: { user } } = await supabase.auth.getUser();
    const { data: prof } = await supabase
      .from("profiles")
      .select("tenant_id")
      .eq("id", user!.id)
      .maybeSingle();
    if (!prof?.tenant_id) {
      toast.error(t("szerepkorok.no_tenant"));
      setBusy(false);
      return;
    }
    const { data: inserted, error } = await supabase
      .from("user_roles")
      .insert({
        tenant_id: prof.tenant_id,
        user_id: profile.id,
        role_id: roleId,
        site_id: siteId || null,
        org_unit_id: orgUnitId || null,
      })
      .select("id")
      .maybeSingle();
    if (error) {
      setBusy(false);
      toast.error(humanizeError(error, t, { perm: "manage_roles" }));
      return;
    }
    await applyReason("user_roles", inserted?.id, reason);
    setBusy(false);
    toast.success(t("szerepkorok.added"));
    setRoleId("");
    setSiteId("");
    setOrgUnitId("");
    setReason("");
    onChange();
  }

  async function remove(id: string) {
    setBusy(true);
    const { error } = await supabase.from("user_roles").delete().eq("id", id);
    if (error) {
      setBusy(false);
      toast.error(humanizeError(error, t, { perm: "manage_roles" }));
      return;
    }
    await applyReason("user_roles", id, reason);
    setBusy(false);
    toast.success(t("szerepkorok.removed"));
    setReason("");
    onChange();
  }


  const groups = roles.reduce<Record<string, Role[]>>((acc, r) => {
    (acc[r.kategoria] ??= []).push(r);
    return acc;
  }, {});

  const filteredOrgUnits = siteId ? orgUnits.filter((ou) => ou.site_id === siteId) : orgUnits;

  return (
    <div className="px-4 pb-5 pt-1 bg-secondary/30 border-t border-border space-y-4">
      <div>
        <div className="text-[10px] font-mono uppercase text-muted-foreground mb-2">
          {t("szerepkorok.current")}
        </div>
        {userRoles.length === 0 ? (
          <div className="text-sm text-muted-foreground">{t("szerepkorok.no_roles")}</div>
        ) : (
          <ul className="space-y-1.5">
            {userRoles.map((ur) => {
              const r = roles.find((x) => x.id === ur.role_id);
              const site = sites.find((s) => s.id === ur.site_id);
              const ou = orgUnits.find((o) => o.id === ur.org_unit_id);
              return (
                <li
                  key={ur.id}
                  className="flex items-center justify-between bg-card border border-border rounded-md px-3 py-1.5"
                >
                  <div className="text-sm flex items-center gap-1">
                    <span className="font-semibold">{r?.megnevezes}</span>
                    <span className="ml-2 text-xs text-muted-foreground font-mono">
                      [{r?.kategoria}]
                    </span>
                    {r && (
                      <TranslatorMenu
                        namespace="roles.megnevezes"
                        itemKey={r.kulcs}
                        sourceText={r.megnevezes}
                      />
                    )}
                    {(site || ou) && (
                      <span className="ml-2 text-xs text-muted-foreground">
                        · {site?.nev}
                        {ou ? ` / ${ou.nev}` : ""}
                      </span>
                    )}
                  </div>
                  <button
                    type="button"
                    disabled={disabled || busy}
                    onClick={() => remove(ur.id)}
                    className="p-1.5 rounded-md text-muted-foreground hover:text-warning hover:bg-warning/10 transition-colors disabled:opacity-30"
                    aria-label={t("common.delete")}
                  >
                    <Trash2 className="size-3.5" />
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </div>

      <div>
        <div className="text-[10px] font-mono uppercase text-muted-foreground mb-2">
          {t("szerepkorok.add_new")}
        </div>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-2">
          <select
            value={roleId}
            onChange={(e) => setRoleId(e.target.value)}
            disabled={disabled}
            className="md:col-span-2 px-3 py-2 bg-card border border-border rounded-lg text-sm disabled:opacity-50"
          >
            <option value="">— {t("szerepkorok.pick_role")} —</option>
            {Object.entries(groups).map(([kat, list]) => (
              <optgroup key={kat} label={kat}>
                {list.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.megnevezes}
                  </option>
                ))}
              </optgroup>
            ))}
          </select>
          <select
            value={siteId}
            onChange={(e) => {
              setSiteId(e.target.value);
              setOrgUnitId("");
            }}
            disabled={disabled}
            className="px-3 py-2 bg-card border border-border rounded-lg text-sm disabled:opacity-50"
          >
            <option value="">— {t("szerepkorok.any_site")} —</option>
            {sites.map((s) => (
              <option key={s.id} value={s.id}>
                {s.nev}
              </option>
            ))}
          </select>
          <select
            value={orgUnitId}
            onChange={(e) => setOrgUnitId(e.target.value)}
            disabled={disabled}
            className="px-3 py-2 bg-card border border-border rounded-lg text-sm disabled:opacity-50"
          >
            <option value="">— {t("szerepkorok.any_unit")} —</option>
            {filteredOrgUnits.map((o) => (
              <option key={o.id} value={o.id}>
                {o.nev}
              </option>
            ))}
          </select>
        </div>
        {!disabled && (
          <ReasonInput value={reason} onChange={setReason} />
        )}
        <button
          type="button"
          onClick={add}
          disabled={disabled || busy || !roleId}
          className={cn(
            "mt-2 inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold uppercase font-mono",
            "bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-40",
          )}
        >
          <Plus className="size-3.5" />
          {t("szerepkorok.add")}
        </button>
      </div>
    </div>
  );
}
