import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { toast } from "sonner";
import { GraduationCap, Plus, Trash2, Loader2, Activity, BookOpen, ShieldAlert, ChevronDown, ChevronRight, Milestone } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { usePermissions } from "@/hooks/use-permissions";
import { humanizeError } from "@/lib/humanize-error";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/kepzes")({
  component: KepzesPage,
});

type Skill = { id: string; kulcs: string; nev: string; leiras: string | null; kategoria: string | null; specialty_id: string | null };
type Bea = { id: string; kod: string | null; nev: string; leiras: string | null; specialty_id: string | null };
type Program = { id: string; nev: string; leiras: string | null; honap_hossz: number | null };
type Specialty = { id: string; nev: string };

const TABS = [
  { key: "skills", icon: GraduationCap, label: "Skill-ek" },
  { key: "bea", icon: Activity, label: "Beavatkozások" },
  { key: "programs", icon: BookOpen, label: "Képzési programok" },
] as const;

function KepzesPage() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const { can, loading: permLoading } = usePermissions();
  const [tenantId, setTenantId] = useState<string | null>(null);
  const [tab, setTab] = useState<(typeof TABS)[number]["key"]>("skills");

  useEffect(() => {
    if (!user) return;
    supabase
      .from("profiles")
      .select("tenant_id")
      .eq("id", user.id)
      .maybeSingle()
      .then(({ data }) => setTenantId(data?.tenant_id ?? null));
  }, [user]);

  const canEdit = can("manage_training");

  if (permLoading) {
    return (
      <div className="p-8 flex items-center gap-2 text-muted-foreground text-sm">
        <Loader2 className="size-4 animate-spin" /> {t("common.loading")}
      </div>
    );
  }

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-6">
      <header>
        <h1 className="text-2xl font-bold tracking-tight">Képzés-katalógus</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Skill-ek, beavatkozások és képzési programok karbantartása.
        </p>
      </header>

      {!canEdit && (
        <div className="flex items-start gap-3 p-4 border border-warning/30 bg-warning/5 rounded-lg">
          <ShieldAlert className="size-5 text-warning shrink-0 mt-0.5" />
          <div className="text-sm">
            Csak olvasási hozzáférése van. Szerkesztéshez `manage_training` jogosultság kell.
          </div>
        </div>
      )}

      <div className="flex gap-1 border-b border-border">
        {TABS.map((tb) => {
          const Icon = tb.icon;
          const active = tab === tb.key;
          return (
            <button
              key={tb.key}
              type="button"
              onClick={() => setTab(tb.key)}
              className={cn(
                "inline-flex items-center gap-1.5 px-4 py-2 text-sm font-semibold border-b-2 -mb-px transition-colors",
                active
                  ? "border-primary text-foreground"
                  : "border-transparent text-muted-foreground hover:text-foreground",
              )}
            >
              <Icon className="size-3.5" />
              {tb.label}
            </button>
          );
        })}
      </div>

      {tab === "skills" && <SkillsAdmin tenantId={tenantId} canEdit={canEdit} />}
      {tab === "bea" && <BeaAdmin tenantId={tenantId} canEdit={canEdit} />}
      {tab === "programs" && <ProgramsAdmin tenantId={tenantId} canEdit={canEdit} />}
    </div>
  );
}

function useSpecialties(tenantId: string | null) {
  const [list, setList] = useState<Specialty[]>([]);
  useEffect(() => {
    if (!tenantId) return;
    supabase
      .from("specialties")
      .select("id, nev")
      .order("nev")
      .then(({ data }) => setList((data ?? []) as Specialty[]));
  }, [tenantId]);
  return list;
}

// ============ Skills ============
function SkillsAdmin({ tenantId, canEdit }: { tenantId: string | null; canEdit: boolean }) {
  const { t } = useTranslation();
  const specialties = useSpecialties(tenantId);
  const [rows, setRows] = useState<Skill[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ kulcs: "", nev: "", kategoria: "", specialty_id: "" });
  const [adding, setAdding] = useState(false);

  async function load() {
    const { data } = await supabase
      .from("skills")
      .select("id, kulcs, nev, leiras, kategoria, specialty_id")
      .order("nev");
    setRows((data ?? []) as Skill[]);
    setLoading(false);
  }
  useEffect(() => {
    load();
  }, []);

  async function add() {
    if (!form.nev || !form.kulcs || !tenantId) return;
    setAdding(true);
    const { error } = await supabase.from("skills").insert({
      tenant_id: tenantId,
      kulcs: form.kulcs.trim().toLowerCase().replace(/\s+/g, "_"),
      nev: form.nev,
      kategoria: form.kategoria || null,
      specialty_id: form.specialty_id || null,
    });
    setAdding(false);
    if (error) {
      toast.error(humanizeError(error, t, { perm: "manage_training" }));
      return;
    }
    setForm({ kulcs: "", nev: "", kategoria: "", specialty_id: "" });
    load();
  }
  async function remove(id: string) {
    if (!window.confirm("Biztosan törli?")) return;
    const { error } = await supabase.from("skills").delete().eq("id", id);
    if (error) {
      toast.error(humanizeError(error, t, { perm: "manage_training" }));
      return;
    }
    load();
  }

  if (loading) return <Loading />;

  return (
    <div className="space-y-4">
      <div className="rounded-lg border border-border bg-card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-secondary text-[10px] uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="text-left px-3 py-2">Kulcs</th>
              <th className="text-left px-3 py-2">Név</th>
              <th className="text-left px-3 py-2">Kategória</th>
              <th className="text-left px-3 py-2">Szakterület</th>
              <th className="px-3 py-2"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {rows.length === 0 ? (
              <tr>
                <td colSpan={5} className="px-3 py-6 text-center text-muted-foreground text-sm">
                  Még nincs skill.
                </td>
              </tr>
            ) : (
              rows.map((s) => (
                <tr key={s.id}>
                  <td className="px-3 py-2 font-mono text-xs">{s.kulcs}</td>
                  <td className="px-3 py-2 font-semibold">{s.nev}</td>
                  <td className="px-3 py-2 text-xs">{s.kategoria ?? "—"}</td>
                  <td className="px-3 py-2 text-xs">
                    {specialties.find((sp) => sp.id === s.specialty_id)?.nev ?? "—"}
                  </td>
                  <td className="px-3 py-2 text-right">
                    {canEdit && (
                      <button
                        type="button"
                        onClick={() => remove(s.id)}
                        className="text-muted-foreground hover:text-destructive p-1"
                      >
                        <Trash2 className="size-3.5" />
                      </button>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {canEdit && (
        <div className="rounded-lg border border-border bg-card p-4 space-y-3">
          <div className="text-[10px] font-mono uppercase text-muted-foreground tracking-wider">
            Új skill
          </div>
          <div className="grid sm:grid-cols-4 gap-2">
            <input
              placeholder="kulcs (pl. echo_basic)"
              value={form.kulcs}
              onChange={(e) => setForm({ ...form, kulcs: e.target.value })}
              className="px-3 py-2 text-sm rounded-md border border-input bg-background"
            />
            <input
              placeholder="Megjelenítendő név"
              value={form.nev}
              onChange={(e) => setForm({ ...form, nev: e.target.value })}
              className="px-3 py-2 text-sm rounded-md border border-input bg-background"
            />
            <input
              placeholder="Kategória"
              value={form.kategoria}
              onChange={(e) => setForm({ ...form, kategoria: e.target.value })}
              className="px-3 py-2 text-sm rounded-md border border-input bg-background"
            />
            <select
              value={form.specialty_id}
              onChange={(e) => setForm({ ...form, specialty_id: e.target.value })}
              className="px-3 py-2 text-sm rounded-md border border-input bg-background"
            >
              <option value="">— szakterület (opcionális) —</option>
              {specialties.map((sp) => (
                <option key={sp.id} value={sp.id}>
                  {sp.nev}
                </option>
              ))}
            </select>
          </div>
          <button
            type="button"
            onClick={add}
            disabled={adding || !form.nev || !form.kulcs}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md bg-primary text-primary-foreground text-xs font-semibold disabled:opacity-50"
          >
            {adding ? <Loader2 className="size-3.5 animate-spin" /> : <Plus className="size-3.5" />}
            Hozzáadás
          </button>
        </div>
      )}
    </div>
  );
}

// ============ Beavatkozások ============
function BeaAdmin({ tenantId, canEdit }: { tenantId: string | null; canEdit: boolean }) {
  const { t } = useTranslation();
  const specialties = useSpecialties(tenantId);
  const [rows, setRows] = useState<Bea[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ kod: "", nev: "", specialty_id: "" });
  const [adding, setAdding] = useState(false);

  async function load() {
    const { data } = await supabase
      .from("beavatkozasok")
      .select("id, kod, nev, leiras, specialty_id")
      .order("nev");
    setRows((data ?? []) as Bea[]);
    setLoading(false);
  }
  useEffect(() => {
    load();
  }, []);

  async function add() {
    if (!form.nev || !tenantId) return;
    setAdding(true);
    const { error } = await supabase.from("beavatkozasok").insert({
      tenant_id: tenantId,
      kod: form.kod || null,
      nev: form.nev,
      specialty_id: form.specialty_id || null,
    });
    setAdding(false);
    if (error) {
      toast.error(humanizeError(error, t, { perm: "manage_training" }));
      return;
    }
    setForm({ kod: "", nev: "", specialty_id: "" });
    load();
  }
  async function remove(id: string) {
    if (!window.confirm("Biztosan törli?")) return;
    const { error } = await supabase.from("beavatkozasok").delete().eq("id", id);
    if (error) {
      toast.error(humanizeError(error, t, { perm: "manage_training" }));
      return;
    }
    load();
  }

  if (loading) return <Loading />;

  return (
    <div className="space-y-4">
      <div className="rounded-lg border border-border bg-card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-secondary text-[10px] uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="text-left px-3 py-2">Kód</th>
              <th className="text-left px-3 py-2">Név</th>
              <th className="text-left px-3 py-2">Szakterület</th>
              <th className="px-3 py-2"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {rows.length === 0 ? (
              <tr>
                <td colSpan={4} className="px-3 py-6 text-center text-muted-foreground text-sm">
                  Még nincs beavatkozás.
                </td>
              </tr>
            ) : (
              rows.map((b) => (
                <tr key={b.id}>
                  <td className="px-3 py-2 font-mono text-xs">{b.kod ?? "—"}</td>
                  <td className="px-3 py-2 font-semibold">{b.nev}</td>
                  <td className="px-3 py-2 text-xs">
                    {specialties.find((sp) => sp.id === b.specialty_id)?.nev ?? "—"}
                  </td>
                  <td className="px-3 py-2 text-right">
                    {canEdit && (
                      <button
                        type="button"
                        onClick={() => remove(b.id)}
                        className="text-muted-foreground hover:text-destructive p-1"
                      >
                        <Trash2 className="size-3.5" />
                      </button>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {canEdit && (
        <div className="rounded-lg border border-border bg-card p-4 space-y-3">
          <div className="text-[10px] font-mono uppercase text-muted-foreground tracking-wider">
            Új beavatkozás
          </div>
          <div className="grid sm:grid-cols-3 gap-2">
            <input
              placeholder="Kód (OENO)"
              value={form.kod}
              onChange={(e) => setForm({ ...form, kod: e.target.value })}
              className="px-3 py-2 text-sm rounded-md border border-input bg-background"
            />
            <input
              placeholder="Név"
              value={form.nev}
              onChange={(e) => setForm({ ...form, nev: e.target.value })}
              className="px-3 py-2 text-sm rounded-md border border-input bg-background"
            />
            <select
              value={form.specialty_id}
              onChange={(e) => setForm({ ...form, specialty_id: e.target.value })}
              className="px-3 py-2 text-sm rounded-md border border-input bg-background"
            >
              <option value="">— szakterület —</option>
              {specialties.map((sp) => (
                <option key={sp.id} value={sp.id}>
                  {sp.nev}
                </option>
              ))}
            </select>
          </div>
          <button
            type="button"
            onClick={add}
            disabled={adding || !form.nev}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md bg-primary text-primary-foreground text-xs font-semibold disabled:opacity-50"
          >
            {adding ? <Loader2 className="size-3.5 animate-spin" /> : <Plus className="size-3.5" />}
            Hozzáadás
          </button>
        </div>
      )}
    </div>
  );
}

// ============ Programs ============
function ProgramsAdmin({ tenantId, canEdit }: { tenantId: string | null; canEdit: boolean }) {
  const { t } = useTranslation();
  const [rows, setRows] = useState<Program[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ nev: "", leiras: "", honap_hossz: "" });
  const [adding, setAdding] = useState(false);

  async function load() {
    const { data } = await supabase
      .from("training_programs")
      .select("id, nev, leiras, honap_hossz")
      .order("nev");
    setRows((data ?? []) as Program[]);
    setLoading(false);
  }
  useEffect(() => {
    load();
  }, []);

  async function add() {
    if (!form.nev || !tenantId) return;
    setAdding(true);
    const { error } = await supabase.from("training_programs").insert({
      tenant_id: tenantId,
      nev: form.nev,
      leiras: form.leiras || null,
      honap_hossz: form.honap_hossz ? Number(form.honap_hossz) : null,
    });
    setAdding(false);
    if (error) {
      toast.error(humanizeError(error, t, { perm: "manage_training" }));
      return;
    }
    setForm({ nev: "", leiras: "", honap_hossz: "" });
    load();
  }
  async function remove(id: string) {
    if (!window.confirm("Biztosan törli?")) return;
    const { error } = await supabase.from("training_programs").delete().eq("id", id);
    if (error) {
      toast.error(humanizeError(error, t, { perm: "manage_training" }));
      return;
    }
    load();
  }

  if (loading) return <Loading />;

  return (
    <div className="space-y-4">
      <div className="rounded-lg border border-border bg-card divide-y divide-border">
        {rows.length === 0 ? (
          <div className="p-6 text-center text-sm text-muted-foreground">
            Még nincs képzési program.
          </div>
        ) : (
          rows.map((p) => (
            <ProgramRow key={p.id} program={p} canEdit={canEdit} onDelete={() => remove(p.id)} />
          ))
        )}
      </div>


      {canEdit && (
        <div className="rounded-lg border border-border bg-card p-4 space-y-3">
          <div className="text-[10px] font-mono uppercase text-muted-foreground tracking-wider">
            Új képzési program
          </div>
          <div className="grid sm:grid-cols-3 gap-2">
            <input
              placeholder="Név"
              value={form.nev}
              onChange={(e) => setForm({ ...form, nev: e.target.value })}
              className="px-3 py-2 text-sm rounded-md border border-input bg-background"
            />
            <input
              placeholder="Hossz (hónap)"
              type="number"
              value={form.honap_hossz}
              onChange={(e) => setForm({ ...form, honap_hossz: e.target.value })}
              className="px-3 py-2 text-sm rounded-md border border-input bg-background"
            />
            <input
              placeholder="Leírás"
              value={form.leiras}
              onChange={(e) => setForm({ ...form, leiras: e.target.value })}
              className="px-3 py-2 text-sm rounded-md border border-input bg-background"
            />
          </div>
          <button
            type="button"
            onClick={add}
            disabled={adding || !form.nev}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md bg-primary text-primary-foreground text-xs font-semibold disabled:opacity-50"
          >
            {adding ? <Loader2 className="size-3.5 animate-spin" /> : <Plus className="size-3.5" />}
            Hozzáadás
          </button>
        </div>
      )}
    </div>
  );
}

function Loading() {
  return (
    <div className="p-8 flex items-center gap-2 text-muted-foreground text-sm">
      <Loader2 className="size-4 animate-spin" /> Betöltés…
    </div>
  );
}

// ============ Program details (elements + interventions) ============
type ProgramElement = {
  id: string;
  parent_element_id: string | null;
  kod: string | null;
  nev: string;
  kategoria: string | null;
  sorszam: number;
  idotartam_honap: number | null;
  milestone: string | null;
  klinikan_kivul_engedett: boolean;
};
type ProgramIntervention = {
  id: string;
  milestone: string | null;
  beavatkozas_nev: string;
  szerep: string;
  szint: string | null;
  required_esetszam: number;
  sorszam: number;
};

const MILESTONE_LABEL: Record<string, string> = {
  reszvizsga_1: "1. részvizsga",
  reszvizsga_2: "2. részvizsga",
  szakvizsga: "Szakvizsga",
};
const MILESTONE_ORDER = ["reszvizsga_1", "reszvizsga_2", "szakvizsga"];

function ProgramRow({ program, canEdit, onDelete }: { program: Program; canEdit: boolean; onDelete: () => void }) {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [elements, setElements] = useState<ProgramElement[]>([]);
  const [interventions, setInterventions] = useState<ProgramIntervention[]>([]);

  async function loadDetails() {
    setLoading(true);
    const [{ data: el }, { data: bv }] = await Promise.all([
      supabase
        .from("training_program_elements" as never)
        .select("id, parent_element_id, kod, nev, kategoria, sorszam, idotartam_honap, milestone, klinikan_kivul_engedett")
        .eq("program_id", program.id)
        .order("sorszam"),
      supabase
        .from("training_program_interventions" as never)
        .select("id, milestone, beavatkozas_nev, szerep, szint, required_esetszam, sorszam")
        .eq("program_id", program.id)
        .order("sorszam"),
    ]);
    setElements((el ?? []) as ProgramElement[]);
    setInterventions((bv ?? []) as ProgramIntervention[]);
    setLoading(false);
  }

  function toggle() {
    const next = !open;
    setOpen(next);
    if (next && elements.length === 0 && interventions.length === 0) loadDetails();
  }

  const roots = useMemo(() => elements.filter((e) => !e.parent_element_id), [elements]);
  const childrenOf = (id: string) => elements.filter((e) => e.parent_element_id === id);
  const interventionsByMilestone = useMemo(() => {
    const m: Record<string, ProgramIntervention[]> = {};
    interventions.forEach((iv) => {
      const k = iv.milestone ?? "egyeb";
      (m[k] ||= []).push(iv);
    });
    return m;
  }, [interventions]);

  return (
    <div className="bg-card">
      <div className="px-4 py-3 flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={toggle}
          className="flex items-center gap-2 min-w-0 text-left flex-1 hover:text-primary transition-colors"
        >
          {open ? <ChevronDown className="size-4 shrink-0" /> : <ChevronRight className="size-4 shrink-0" />}
          <div className="min-w-0">
            <div className="font-semibold text-sm">{program.nev}</div>
            <div className="text-[11px] font-mono text-muted-foreground">
              {program.honap_hossz ? `${program.honap_hossz} hónap` : "változó"}
              {program.leiras && <> · {program.leiras}</>}
            </div>
          </div>
        </button>
        {canEdit && (
          <button
            type="button"
            onClick={onDelete}
            className="text-muted-foreground hover:text-destructive p-1 shrink-0"
          >
            <Trash2 className="size-3.5" />
          </button>
        )}
      </div>

      {open && (
        <div className="px-4 pb-4 border-t border-border space-y-5 pt-4 bg-secondary/20">
          {loading ? (
            <div className="text-xs text-muted-foreground flex items-center gap-2">
              <Loader2 className="size-3 animate-spin" /> Részletek betöltése…
            </div>
          ) : (
            <>
              {/* Program elemek */}
              <section>
                <div className="text-[10px] font-mono uppercase text-muted-foreground tracking-wider mb-2">
                  Képzési elemek
                </div>
                {roots.length === 0 ? (
                  <div className="text-xs text-muted-foreground">Nincs strukturált elem.</div>
                ) : (
                  <div className="space-y-3">
                    {roots.map((root) => (
                      <div key={root.id} className="rounded-md border border-border bg-card">
                        <div className="px-3 py-2 flex items-center justify-between gap-2 border-b border-border">
                          <div className="flex items-center gap-2 min-w-0">
                            <Milestone className="size-3.5 text-primary shrink-0" />
                            <div className="font-semibold text-sm truncate">{root.nev}</div>
                          </div>
                          <div className="flex items-center gap-2 text-[10px] font-mono text-muted-foreground shrink-0">
                            {root.idotartam_honap != null && <span>{root.idotartam_honap} hó</span>}
                            {root.milestone && (
                              <span className="px-1.5 py-0.5 rounded bg-primary/10 text-primary">
                                {MILESTONE_LABEL[root.milestone] ?? root.milestone}
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="divide-y divide-border">
                          {childrenOf(root.id).length === 0 ? (
                            <div className="px-3 py-2 text-xs text-muted-foreground">Nincs alelem.</div>
                          ) : (
                            childrenOf(root.id).map((c) => (
                              <div key={c.id} className="px-3 py-1.5 flex items-center justify-between gap-2 text-xs">
                                <div className="flex items-center gap-2 min-w-0">
                                  <span className="font-mono text-[10px] text-muted-foreground shrink-0">{c.kod}</span>
                                  <span className="truncate">{c.nev}</span>
                                  {c.kategoria && (
                                    <span className="px-1.5 py-0.5 rounded bg-secondary text-[9px] uppercase tracking-wider text-muted-foreground shrink-0">
                                      {c.kategoria}
                                    </span>
                                  )}
                                </div>
                                <div className="flex items-center gap-2 text-[10px] font-mono text-muted-foreground shrink-0">
                                  {c.idotartam_honap != null && <span>{c.idotartam_honap} hó</span>}
                                  {c.milestone && (
                                    <span className="px-1.5 py-0.5 rounded bg-primary/10 text-primary">
                                      {MILESTONE_LABEL[c.milestone] ?? c.milestone}
                                    </span>
                                  )}
                                  {c.klinikan_kivul_engedett && (
                                    <span className="px-1.5 py-0.5 rounded bg-success/10 text-success">
                                      klinikán kívül is
                                    </span>
                                  )}
                                </div>
                              </div>
                            ))
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </section>

              {/* Beavatkozási előírások mérföldkövenként */}
              <section>
                <div className="text-[10px] font-mono uppercase text-muted-foreground tracking-wider mb-2">
                  Beavatkozási előírások
                </div>
                {Object.keys(interventionsByMilestone).length === 0 ? (
                  <div className="text-xs text-muted-foreground">Nincs előírt beavatkozás.</div>
                ) : (
                  <div className="space-y-3">
                    {MILESTONE_ORDER.filter((m) => interventionsByMilestone[m]).map((m) => (
                      <div key={m} className="rounded-md border border-border bg-card overflow-hidden">
                        <div className="px-3 py-1.5 bg-secondary text-[10px] font-mono uppercase tracking-wider text-muted-foreground flex items-center justify-between">
                          <span>{MILESTONE_LABEL[m] ?? m}</span>
                          <span>{interventionsByMilestone[m].length} tétel</span>
                        </div>
                        <table className="w-full text-xs">
                          <thead className="text-[10px] uppercase tracking-wider text-muted-foreground">
                            <tr>
                              <th className="text-left px-3 py-1.5">Beavatkozás</th>
                              <th className="text-left px-3 py-1.5">Szerep</th>
                              <th className="text-left px-3 py-1.5">Szint</th>
                              <th className="text-right px-3 py-1.5">Esetszám</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-border">
                            {interventionsByMilestone[m].map((iv) => (
                              <tr key={iv.id}>
                                <td className="px-3 py-1.5">{iv.beavatkozas_nev}</td>
                                <td className="px-3 py-1.5 text-muted-foreground">{iv.szerep}</td>
                                <td className="px-3 py-1.5 font-mono">{iv.szint ?? "—"}</td>
                                <td className="px-3 py-1.5 text-right font-mono font-semibold">{iv.required_esetszam}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    ))}
                  </div>
                )}
              </section>
            </>
          )}
        </div>
      )}
    </div>
  );
}

