import { createFileRoute, Outlet, useNavigate, useRouterState } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { listConversations } from "@/lib/messaging/conversations.functions";
import { ConversationList } from "@/components/messaging/ConversationList";
import { MessageSquarePlus, Stethoscope, Inbox, RefreshCw } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { ListSkeleton } from "@/components/ui/list-skeletons";
import { usePullToRefresh } from "@/hooks/use-pull-to-refresh";

export const Route = createFileRoute("/_authenticated/uzenetek")({
  component: MessagingLayout,
});

const PATIENT_KINDS = new Set(["patient_provider", "patient_team"]);

function MessagingLayout() {
  const navigate = useNavigate();
  const list = useServerFn(listConversations);
  const [filter, setFilter] = useState<"all" | "patient">("all");
  const { data, refetch, isLoading } = useQuery({
    queryKey: ["messaging", "conversations"],
    queryFn: () => list(),
    refetchOnWindowFocus: true,
  });

  useEffect(() => {
    const ch = supabase
      .channel("messaging-conv-list")
      .on("postgres_changes", { event: "*", schema: "public", table: "messages" }, () => refetch())
      .on("postgres_changes", { event: "*", schema: "public", table: "conversations" }, () => refetch())
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [refetch]);

  const items = data ?? [];
  const filtered = useMemo(
    () => (filter === "patient" ? items.filter((c: any) => PATIENT_KINDS.has(c.kind)) : items),
    [items, filter],
  );
  const patientUnread = useMemo(
    () => items.filter((c: any) => PATIENT_KINDS.has(c.kind)).reduce((s: number, c: any) => s + (c.unread_count || 0), 0),
    [items],
  );

  // Mobilon: ha van kiválasztott beszélgetés, csak a thread látszik. Ha nincs, csak a lista.
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const hasSelection = /\/uzenetek\/[^/]+/.test(pathname) && !pathname.endsWith("/uzenetek/uj");

  const { bind, pulling, progress } = usePullToRefresh(async () => { await refetch(); });

  return (
    <div className="flex h-[calc(100dvh-4rem-4rem)] lg:h-[calc(100vh-4rem)] overflow-hidden">
      <aside
        className={`${hasSelection ? "hidden lg:flex" : "flex"} w-full lg:w-80 shrink-0 border-r border-border bg-card flex-col`}
      >
        <div className="p-3 sm:p-4 border-b border-border flex items-center justify-between gap-2">
          <h2 className="font-bold text-sm uppercase tracking-wider truncate">Üzenetek</h2>
          <div className="flex items-center gap-1 shrink-0">
            <button
              type="button"
              onClick={() => refetch()}
              aria-label="Frissítés"
              className="inline-flex items-center justify-center size-9 rounded-md text-muted-foreground hover:bg-secondary"
            >
              <RefreshCw className="size-4" />
            </button>
            <button
              type="button"
              onClick={() => navigate({ to: "/uzenetek/uj" })}
              className="inline-flex items-center gap-1.5 px-2.5 min-h-9 rounded-md bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90"
            >
              <MessageSquarePlus className="size-3.5" /> Új
            </button>
          </div>
        </div>
        <div className="px-3 pt-3 pb-2 flex gap-1.5 border-b border-border">
          <button
            type="button"
            onClick={() => setFilter("all")}
            className={`inline-flex items-center gap-1.5 px-2.5 min-h-9 rounded-md text-xs font-medium ${filter === "all" ? "bg-secondary text-foreground" : "text-muted-foreground hover:bg-secondary/50"}`}
          >
            <Inbox className="size-3.5" /> Mind ({items.length})
          </button>
          <button
            type="button"
            onClick={() => setFilter("patient")}
            className={`inline-flex items-center gap-1.5 px-2.5 min-h-9 rounded-md text-xs font-medium ${filter === "patient" ? "bg-secondary text-foreground" : "text-muted-foreground hover:bg-secondary/50"}`}
          >
            <Stethoscope className="size-3.5" /> Pácienstől
            {patientUnread > 0 && (
              <span className="px-1.5 rounded-full bg-primary text-primary-foreground text-[10px] font-bold">
                {patientUnread}
              </span>
            )}
          </button>
        </div>
        <div className="flex-1 overflow-y-auto relative" {...bind}>
          {pulling && (
            <div
              className="absolute top-0 inset-x-0 flex items-center justify-center text-[10px] text-muted-foreground bg-muted/50 transition-all"
              style={{ height: `${Math.round(progress * 32)}px`, opacity: progress }}
            >
              {progress >= 1 ? "Engedd el a frissítéshez…" : "Húzd lejjebb…"}
            </div>
          )}
          {isLoading ? (
            <ListSkeleton rows={6} className="p-2" />
          ) : (
            <ConversationList items={filtered} />
          )}
        </div>
      </aside>
      <section className={`${hasSelection ? "flex" : "hidden lg:flex"} flex-1 min-w-0 flex-col bg-background`}>
        <Outlet />
      </section>
    </div>
  );
}
