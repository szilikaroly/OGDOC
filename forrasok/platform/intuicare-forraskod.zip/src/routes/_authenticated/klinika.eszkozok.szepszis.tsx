import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { ShieldAlert } from "lucide-react";
import { CalculatorShell, Card, Field, NumberInput, ScoreBadge, Toggle } from "@/components/clinical/calc-shell";
import {
  scoreQSofa, scoreSOFA, scoreNEWS2,
  type QSofaInput, type SofaInput, type News2Input,
} from "@/lib/clinical/scores";

export const Route = createFileRoute("/_authenticated/klinika/eszkozok/szepszis")({
  validateSearch: (s: Record<string, unknown>): { encounterId?: string; patientId?: string } => ({
    encounterId: typeof s.encounterId === "string" ? s.encounterId : undefined,
    patientId: typeof s.patientId === "string" ? s.patientId : undefined,
  }),
  component: SzepszisPage,
});

function SzepszisPage() {
  const [tab, setTab] = useState<"qsofa" | "sofa" | "news2">("news2");
  const [q, setQ] = useState<QSofaInput>({ sbp_le_100: false, rr_ge_22: false, altered_mental: false });
  const [s, setS] = useState<SofaInput>({ pao2_fio2: 400, on_mech_vent: false, platelets_x10e9_l: 200, bilirubin_umol_l: 10, map_mmhg: 80, pressors: "none", gcs: 15, creatinine_umol_l: 80 });
  const [n, setN] = useState<News2Input>({ rr: 16, spo2: 98, on_supplemental_o2: false, scale2_chronic_hypercapnia: false, temp: 36.8, sbp: 120, hr: 75, consciousness: "A" });

  const qR = useMemo(() => scoreQSofa(q), [q]);
  const sR = useMemo(() => scoreSOFA(s), [s]);
  const nR = useMemo(() => scoreNEWS2(n), [n]);

  return (
    <CalculatorShell
      title="Szepszis & korai felismerés — qSOFA / SOFA / NEWS2"
      subtitle="Sepsis-3 (JAMA 2016) és NICE NEWS2 (2017) pontszámok."
      Icon={ShieldAlert}
      fromRoute="/_authenticated/klinika/eszkozok/szepszis"
      onReset={() => {
        setQ({ sbp_le_100: false, rr_ge_22: false, altered_mental: false });
        setS({ pao2_fio2: 400, on_mech_vent: false, platelets_x10e9_l: 200, bilirubin_umol_l: 10, map_mmhg: 80, pressors: "none", gcs: 15, creatinine_umol_l: 80 });
        setN({ rr: 16, spo2: 98, on_supplemental_o2: false, scale2_chronic_hypercapnia: false, temp: 36.8, sbp: 120, hr: 75, consciousness: "A" });
      }}
      getSaveBundle={() => tab === "qsofa"
        ? { calculator: "qsofa", inputs: q, outputs: qR, interpretation_md: `**qSOFA:** ${qR.score}/3 · ${qR.positive ? "POZITÍV" : "negatív"}\n\n${qR.note}` }
        : tab === "sofa"
          ? { calculator: "sofa", inputs: s, outputs: sR, interpretation_md: `**SOFA összpontszám:** ${sR.total} · becsült mortalitás ≈ ${sR.mortalityEstPct}%\n\nRészpontok: resp ${sR.parts.resp}, coag ${sR.parts.coag}, máj ${sR.parts.liver}, kardio ${sR.parts.cardio}, CNS ${sR.parts.cns}, vese ${sR.parts.renal}` }
          : { calculator: "news2", inputs: n, outputs: nR, interpretation_md: `**NEWS2:** ${nR.total} pont (${nR.riskLabel}${nR.redFlag ? ", piros zászló" : ""})\n\n${nR.action}` }}
    >
      <div className="flex gap-2 border-b border-border">
        <Tab active={tab === "news2"} onClick={() => setTab("news2")}>NEWS2</Tab>
        <Tab active={tab === "qsofa"} onClick={() => setTab("qsofa")}>qSOFA</Tab>
        <Tab active={tab === "sofa"} onClick={() => setTab("sofa")}>SOFA</Tab>
      </div>

      {tab === "qsofa" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Card title="Kritériumok">
            <Toggle checked={q.sbp_le_100} onChange={(v) => setQ({ ...q, sbp_le_100: v })} label="Szisztolés RR ≤ 100 Hgmm" />
            <Toggle checked={q.rr_ge_22} onChange={(v) => setQ({ ...q, rr_ge_22: v })} label="Légzésszám ≥ 22/perc" />
            <Toggle checked={q.altered_mental} onChange={(v) => setQ({ ...q, altered_mental: v })} label="Tudatzavar (GCS < 15)" />
          </Card>
          <Card title="Eredmény" footer={qR.note}>
            <ScoreBadge score={qR.score} label={`/3 · ${qR.positive ? "POZITÍV" : "negatív"}`} tone={qR.positive ? "danger" : "ok"} />
          </Card>
        </div>
      )}

      {tab === "sofa" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Card title="Bemenetek">
            <div className="grid grid-cols-2 gap-3">
              <Field label="PaO₂ / FiO₂"><NumberInput value={s.pao2_fio2} onChange={(v) => setS({ ...s, pao2_fio2: v ?? 0 })} /></Field>
              <Field label="Thrombocyta (×10⁹/L)"><NumberInput value={s.platelets_x10e9_l} onChange={(v) => setS({ ...s, platelets_x10e9_l: v ?? 0 })} /></Field>
              <Field label="Bilirubin (µmol/L)"><NumberInput value={s.bilirubin_umol_l} onChange={(v) => setS({ ...s, bilirubin_umol_l: v ?? 0 })} /></Field>
              <Field label="MAP (Hgmm)"><NumberInput value={s.map_mmhg} onChange={(v) => setS({ ...s, map_mmhg: v ?? 0 })} /></Field>
              <Field label="GCS"><NumberInput value={s.gcs} onChange={(v) => setS({ ...s, gcs: v ?? 0 })} /></Field>
              <Field label="Kreatinin (µmol/L)"><NumberInput value={s.creatinine_umol_l} onChange={(v) => setS({ ...s, creatinine_umol_l: v ?? 0 })} /></Field>
              <Field label="Diurézis (ml/24h, opc.)"><NumberInput value={s.urine_ml_24h} onChange={(v) => setS({ ...s, urine_ml_24h: v })} /></Field>
              <Field label="Vazopresszor">
                <select value={s.pressors} onChange={(e) => setS({ ...s, pressors: e.target.value as SofaInput["pressors"] })} className="w-full px-2 py-1.5 text-sm rounded-md border border-border bg-background">
                  <option value="none">nincs</option>
                  <option value="dopa_low">dopamin ≤ 5</option>
                  <option value="dopa_mid">dopamin 5–15</option>
                  <option value="dopa_high_or_nor_low">dopa &gt; 15 / nor ≤ 0,1</option>
                  <option value="nor_mid_or_high">nor &gt; 0,1 µg/kg/perc</option>
                </select>
              </Field>
            </div>
            <Toggle checked={s.on_mech_vent} onChange={(v) => setS({ ...s, on_mech_vent: v })} label="Gépi lélegeztetés" />
          </Card>
          <Card title="Eredmény" footer={`Becsült mortalitás ≈ ${sR.mortalityEstPct}%`}>
            <ScoreBadge score={sR.total} label="SOFA össz." tone={sR.total >= 10 ? "danger" : sR.total >= 6 ? "warn" : "ok"} />
            <ul className="text-sm grid grid-cols-2 gap-1 mt-2">
              {Object.entries(sR.parts).map(([k, v]) => (
                <li key={k} className="flex justify-between border-b border-border/50 py-1">
                  <span className="capitalize">{k}</span><span className="font-mono">{v}</span>
                </li>
              ))}
            </ul>
          </Card>
        </div>
      )}

      {tab === "news2" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Card title="Vitálisok">
            <div className="grid grid-cols-2 gap-3">
              <Field label="Légzésszám (/min)"><NumberInput value={n.rr} onChange={(v) => setN({ ...n, rr: v ?? 0 })} /></Field>
              <Field label="SpO₂ (%)"><NumberInput value={n.spo2} onChange={(v) => setN({ ...n, spo2: v ?? 0 })} /></Field>
              <Field label="Hőmérséklet (°C)"><NumberInput value={n.temp} step={0.1} onChange={(v) => setN({ ...n, temp: v ?? 0 })} /></Field>
              <Field label="Szisztolés RR (Hgmm)"><NumberInput value={n.sbp} onChange={(v) => setN({ ...n, sbp: v ?? 0 })} /></Field>
              <Field label="Pulzus (/min)"><NumberInput value={n.hr} onChange={(v) => setN({ ...n, hr: v ?? 0 })} /></Field>
              <Field label="Tudat (ACVPU)">
                <select value={n.consciousness} onChange={(e) => setN({ ...n, consciousness: e.target.value as News2Input["consciousness"] })} className="w-full px-2 py-1.5 text-sm rounded-md border border-border bg-background">
                  <option value="A">Alert</option><option value="C">Confused</option><option value="V">Voice</option><option value="P">Pain</option><option value="U">Unresponsive</option>
                </select>
              </Field>
            </div>
            <Toggle checked={n.on_supplemental_o2} onChange={(v) => setN({ ...n, on_supplemental_o2: v })} label="Kiegészítő oxigén" />
            <Toggle checked={n.scale2_chronic_hypercapnia} onChange={(v) => setN({ ...n, scale2_chronic_hypercapnia: v })} label="Scale 2 (krónikus CO₂-retenció, pl. COPD)" />
          </Card>
          <Card title="Eredmény" footer={nR.action}>
            <ScoreBadge score={nR.total} label={`pont · ${nR.riskLabel}${nR.redFlag ? " · piros" : ""}`} tone={nR.riskLabel === "magas" || nR.redFlag ? "danger" : nR.riskLabel === "közepes" ? "warn" : "ok"} />
            <ul className="text-sm grid grid-cols-2 gap-1 mt-2">
              {Object.entries(nR.parts).map(([k, v]) => (
                <li key={k} className="flex justify-between border-b border-border/50 py-1">
                  <span>{k}</span><span className="font-mono">{v}</span>
                </li>
              ))}
            </ul>
          </Card>
        </div>
      )}
    </CalculatorShell>
  );
}

function Tab({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button onClick={onClick} className={`px-4 py-2 text-sm font-medium border-b-2 -mb-px ${active ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"}`}>
      {children}
    </button>
  );
}
