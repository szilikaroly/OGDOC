import { createFileRoute, Link, useSearch } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Activity, Save, Loader2, AlertTriangle, ArrowLeft, RotateCcw } from "lucide-react";
import { analyzeBloodGas, type VergazInput } from "@/lib/clinical/vergaz";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/klinika/eszkozok/vergaz")({
  validateSearch: (s: Record<string, unknown>): { encounterId?: string; patientId?: string } => ({
    encounterId: typeof s.encounterId === "string" ? s.encounterId : undefined,
    patientId: typeof s.patientId === "string" ? s.patientId : undefined,
  }),
  component: VergazPage,
});

type FieldDef = { key: keyof VergazInput; label: string; unit?: string; step?: number; hint?: string };

const F_GAS: FieldDef[] = [
  { key: "pH", label: "pH", step: 0.01, hint: "7.35–7.45" },
  { key: "pCO2", label: "pCO₂", unit: "mmHg", step: 0.1, hint: "35–45" },
  { key: "pO2", label: "pO₂", unit: "mmHg", step: 0.1, hint: "80–100" },
  { key: "HCO3", label: "HCO₃⁻", unit: "mmol/L", step: 0.1, hint: "22–26" },
  { key: "BE", label: "BE", unit: "mmol/L", step: 0.1, hint: "±2" },
  { key: "sO2", label: "sO₂", unit: "%", step: 1, hint: ">95" },
  { key: "FiO2", label: "FiO₂", unit: "%", step: 1, hint: "21 (szoba)" },
  { key: "Hb", label: "Hb", unit: "g/L", step: 1, hint: "120–160" },
  { key: "laktat", label: "Laktát", unit: "mmol/L", step: 0.1, hint: "<2" },
];
const F_ELYTE: FieldDef[] = [
  { key: "Na", label: "Na⁺", unit: "mmol/L", step: 1, hint: "135–145" },
  { key: "K", label: "K⁺", unit: "mmol/L", step: 0.1, hint: "3.5–5.1" },
  { key: "Cl", label: "Cl⁻", unit: "mmol/L", step: 1, hint: "98–107" },
  { key: "Ca", label: "Ca²⁺", unit: "mmol/L", step: 0.01 },
  { key: "Mg", label: "Mg²⁺", unit: "mmol/L", step: 0.01 },
  { key: "albumin", label: "Albumin", unit: "g/L", step: 1, hint: "35–50" },
];
const F_METAB: FieldDef[] = [
  { key: "glukoz", label: "Glükóz", unit: "mmol/L", step: 0.1 },
  { key: "urea", label: "Urea", unit: "mmol/L", step: 0.1 },
  { key: "kreatinin", label: "Kreatinin", unit: "µmol/L", step: 1 },
  { key: "ozm_mert", label: "Mért osmolalitás", unit: "mOsm/kg", step: 1 },
  { key: "bOHB", label: "β-OHB", unit: "mmol/L", step: 0.1 },
  { key: "testsuly", label: "Testsúly", unit: "kg", step: 1 },
];

function VergazPage() {
  const { user } = useAuth();
  const { encounterId, patientId } = useSearch({ from: "/_authenticated/klinika/eszkozok/vergaz" });
  const [input, setInput] = useState<VergazInput>({ FiO2: 21 });
  const [saving, setSaving] = useState(false);

  const result = useMemo(() => analyzeBloodGas(input), [input]);

  function reset() {
    setInput({ FiO2: 21 });
  }

  async function saveToEncounter() {
    if (!user || !encounterId || !patientId) {
      toast.error("Nincs aktív ellátási epizód a mentéshez");
      return;
    }
    setSaving(true);
    try {
      const { error } = await supabase.from("clinical_calculator_results").insert({
        encounter_id: encounterId,
        patient_id: patientId,
        calculator: "bloodgas",
        inputs_json: input as any,
        outputs_json: result as any,
        interpretation_md: result.interpretation,
        created_by: user.id,
      });
      if (error) throw error;

      // Also write key observations as LOINC-coded entries
      const obs: Array<{ loinc: string; display: string; value?: number; unit: string }> = [];
      const addIf = (loinc: string, display: string, value: number | undefined, unit: string) => {
        if (value !== undefined && Number.isFinite(value)) obs.push({ loinc, display, value, unit });
      };
      addIf("2744-1", "pH (vérgáz)", input.pH, "");
      addIf("2019-8", "pCO₂", input.pCO2, "mmHg");
      addIf("2703-7", "pO₂", input.pO2, "mmHg");
      addIf("1963-8", "HCO₃⁻", input.HCO3 ?? result.hco3Calc, "mmol/L");
      addIf("2524-7", "Laktát", input.laktat, "mmol/L");
      addIf("2951-2", "Nátrium", input.Na, "mmol/L");
      addIf("2823-3", "Kálium", input.K, "mmol/L");
      if (obs.length > 0) {
        await supabase.from("clinical_observations").insert(
          obs.map((o) => ({
            encounter_id: encounterId,
            patient_id: patientId,
            category: "laboratory",
            loinc_code: o.loinc,
            code_display: o.display,
            value_quantity: o.value,
            value_unit: o.unit,
            performer_id: user.id,
            source: "calculator",
          })),
        );
      }
      toast.success("Mentve a betegkartonhoz");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Mentés sikertelen");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="container max-w-7xl py-6 space-y-4">
      <header className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <Link to="/klinika/eszkozok" className="text-xs text-muted-foreground hover:underline flex items-center gap-1">
            <ArrowLeft className="h-3 w-3" /> Eszközök
          </Link>
          <h1 className="text-2xl font-semibold mt-1 flex items-center gap-2">
            <Activity className="h-6 w-6 text-primary" /> Vérgáz Elemző
          </h1>
          <p className="text-sm text-muted-foreground">
            Sav-bázis · oxigenizáció · anion gap · delta-delta · DDx · folyadékterápiás javaslat.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={reset} className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-md border border-border hover:bg-accent">
            <RotateCcw className="h-3.5 w-3.5" /> Új
          </button>
          {encounterId && patientId && (
            <button
              onClick={saveToEncounter}
              disabled={saving}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-md bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
            >
              {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
              Mentés a betegkartonhoz
            </button>
          )}
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <div className="lg:col-span-4 space-y-4">
          <InputCard title="Vérgáz" fields={F_GAS} input={input} setInput={setInput} />
          <InputCard title="Elektrolitok" fields={F_ELYTE} input={input} setInput={setInput} />
          <InputCard title="Metabolikus / vesefunkció" fields={F_METAB} input={input} setInput={setInput} />
        </div>
        <div className="lg:col-span-8 space-y-4">
          <PrimaryCard r={result} />
          <OxygenationCard r={result} />
          <AnionGapCard r={result} />
          <DDxCard r={result} />
        </div>
      </div>
    </div>
  );
}

function InputCard({ title, fields, input, setInput }: {
  title: string;
  fields: FieldDef[];
  input: VergazInput;
  setInput: (v: VergazInput) => void;
}) {
  return (
    <div className="rounded-xl border border-border bg-card">
      <div className="px-4 py-3 border-b border-border text-sm font-semibold">{title}</div>
      <div className="p-4 grid grid-cols-2 gap-3">
        {fields.map((f) => (
          <label key={String(f.key)} className="block">
            <span className="text-xs text-muted-foreground flex items-center justify-between">
              <span>{f.label}{f.unit ? ` (${f.unit})` : ""}</span>
              {f.hint && <span className="text-[10px] opacity-70">{f.hint}</span>}
            </span>
            <input
              type="number"
              step={f.step}
              value={(input[f.key] as number | undefined) ?? ""}
              onChange={(e) => {
                const v = e.target.value;
                setInput({ ...input, [f.key]: v === "" ? undefined : Number(v) });
              }}
              className="mt-1 w-full px-2 py-1.5 text-sm rounded-md border border-border bg-background font-mono"
            />
          </label>
        ))}
      </div>
    </div>
  );
}

function PrimaryCard({ r }: { r: ReturnType<typeof analyzeBloodGas> }) {
  const sevColor =
    r.severity === "severe" ? "bg-red-100 text-red-800 border-red-300"
    : r.severity === "moderate" ? "bg-amber-100 text-amber-800 border-amber-300"
    : r.severity === "mild" ? "bg-yellow-50 text-yellow-800 border-yellow-200"
    : "bg-emerald-50 text-emerald-800 border-emerald-200";
  return (
    <div className="rounded-xl border border-border bg-card overflow-hidden">
      <div className="px-4 py-3 border-b border-border text-sm font-semibold">Elsődleges értelmezés</div>
      <div className="p-4 space-y-3">
        {r.primary ? (
          <>
            <div className={`inline-block px-3 py-1.5 rounded-full border text-sm font-semibold ${sevColor}`}>
              {r.primary}{r.severity ? ` · ${r.severity}` : ""}
            </div>
            {r.compensation && <p className="text-sm">{r.compensation}</p>}
            {r.hco3Source === "calculated" && r.hco3Calc !== undefined && (
              <div className="text-xs text-muted-foreground">
                HCO₃⁻ Henderson-Hasselbalch alapján számítva: <span className="font-mono">{r.hco3Calc.toFixed(1)}</span> mmol/L
              </div>
            )}
            {r.warnings.map((w, i) => (
              <div key={i} className="flex items-start gap-2 text-sm p-2 rounded-md bg-red-50 text-red-800 border border-red-200">
                <AlertTriangle className="h-4 w-4 flex-shrink-0 mt-0.5" /> {w}
              </div>
            ))}
          </>
        ) : (
          <p className="text-sm text-muted-foreground">Adj meg legalább pH-t és pCO₂-t az értelmezéshez.</p>
        )}
      </div>
    </div>
  );
}

function OxygenationCard({ r }: { r: ReturnType<typeof analyzeBloodGas> }) {
  if (r.PFRatio === undefined && r.AAGradient === undefined) return null;
  return (
    <div className="rounded-xl border border-border bg-card">
      <div className="px-4 py-3 border-b border-border text-sm font-semibold">Oxigenizáció</div>
      <div className="p-4 grid grid-cols-2 gap-3 text-sm">
        {r.PFRatio !== undefined && (
          <Stat label="P/F arány" value={Math.round(r.PFRatio).toString()} hint={r.PFRatio < 200 ? "súlyos hypoxia" : r.PFRatio < 300 ? "ARDS-küszöb" : "normál"} />
        )}
        {r.AAGradient !== undefined && (
          <Stat label="A-a gradiens" value={r.AAGradient.toFixed(1)} unit="mmHg" hint={r.AAGradient > 20 ? "↑ — diffúziós/shunt" : "normál"} />
        )}
      </div>
    </div>
  );
}

function AnionGapCard({ r }: { r: ReturnType<typeof analyzeBloodGas> }) {
  if (r.AG === undefined) return null;
  return (
    <div className="rounded-xl border border-border bg-card">
      <div className="px-4 py-3 border-b border-border text-sm font-semibold">Anion gap & osmolalitás</div>
      <div className="p-4 grid grid-cols-2 md:grid-cols-3 gap-3 text-sm">
        <Stat label="AG" value={r.AG.toFixed(1)} unit="mmol/L" hint={r.AG > 12 ? "emelkedett" : "normál"} />
        {r.cAG !== undefined && <Stat label="Korr. AG (albumin)" value={r.cAG.toFixed(1)} unit="mmol/L" />}
        {r.deltaRatio !== undefined && (
          <Stat label="Delta-delta" value={r.deltaRatio.toFixed(2)}
            hint={r.deltaRatio < 1 ? "kevert NAGMA" : r.deltaRatio > 2 ? "egyidejű met. alkalózis" : "tiszta HAGMA"} />
        )}
        {r.expectedCO2Winter !== undefined && (
          <Stat label="Winter (várt pCO₂)" value={r.expectedCO2Winter.toFixed(1)} unit="mmHg" />
        )}
        {r.osmCalc !== undefined && <Stat label="Számolt osm" value={r.osmCalc.toFixed(0)} unit="mOsm/kg" />}
        {r.osmGap !== undefined && (
          <Stat label="Osm gap" value={r.osmGap.toFixed(1)} hint={r.osmGap > 10 ? "↑ — toxikus alkohol gyanú" : "normál"} />
        )}
      </div>
    </div>
  );
}

function DDxCard({ r }: { r: ReturnType<typeof analyzeBloodGas> }) {
  if (r.ddx.length === 0) return null;
  return (
    <div className="rounded-xl border border-border bg-card">
      <div className="px-4 py-3 border-b border-border text-sm font-semibold">Differenciáldiagnózis</div>
      <ul className="p-4 space-y-2 text-sm list-disc list-inside">
        {r.ddx.map((d, i) => <li key={i}>{d}</li>)}
      </ul>
    </div>
  );
}

function Stat({ label, value, unit, hint }: { label: string; value: string; unit?: string; hint?: string }) {
  return (
    <div className="p-3 rounded-lg bg-muted/40">
      <div className="text-[10px] uppercase font-mono text-muted-foreground tracking-wider">{label}</div>
      <div className="text-lg font-semibold font-mono mt-0.5">{value}{unit && <span className="text-xs text-muted-foreground ml-1">{unit}</span>}</div>
      {hint && <div className="text-[11px] text-muted-foreground mt-0.5">{hint}</div>}
    </div>
  );
}
