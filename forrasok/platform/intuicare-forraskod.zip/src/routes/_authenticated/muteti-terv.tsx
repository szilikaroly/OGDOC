import { createFileRoute, Link, Outlet } from "@tanstack/react-router";
import { Calendar, ListChecks } from "lucide-react";

export const Route = createFileRoute("/_authenticated/muteti-terv")({
  component: OrLayout,
});

function OrLayout() {
  return (
    <div className="min-h-full">
      <nav className="border-b border-border bg-card/40 px-6 py-2 flex gap-1">
        <TabLink to="/muteti-terv/blokkok" icon={<Calendar className="size-3.5" />} label="Blokk-naptár" />
        <TabLink to="/muteti-terv/varolista" icon={<ListChecks className="size-3.5" />} label="Várólista" />
      </nav>
      <Outlet />
    </div>
  );
}

function TabLink({ to, icon, label }: { to: string; icon: React.ReactNode; label: string }) {
  return (
    <Link
      to={to}
      className="px-3 py-1.5 rounded-md text-xs font-mono uppercase tracking-wider text-muted-foreground hover:text-foreground hover:bg-secondary inline-flex items-center gap-1.5 transition-colors"
      activeProps={{ className: "bg-secondary text-foreground" }}
    >
      {icon} {label}
    </Link>
  );
}
