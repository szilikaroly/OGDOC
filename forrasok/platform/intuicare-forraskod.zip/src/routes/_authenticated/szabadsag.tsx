import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { Palmtree, Loader2, AlertTriangle, Info, Download, FileText } from "lucide-react";
import { toast } from "sonner";
import { RouteErrorBoundary } from "@/lib/errors/route-boundaries";
import { exportLeaveBalanceCsv, generateLeaveBalancePdf } from "@/lib/leave/leave.functions";

export const Route = createFileRoute("/_authenticated/szabadsag")({
  component: SzabadsagPage,
  errorComponent: RouteErrorBoundary,
});

type Entitlement = {
  id: string;
  ev: number;
  jogcim: string;
  jaro_nap: number;
  manual_korrekcio: number;
  athozott_nap: number;
  kiadott_nap: number;
  terv_nap: number;
  forced_taken_nap: number;
  hatralevo: number;
  lezart_at: string | null;
};

type Unav = {
  id: string;
  tipus: string;
  status: string;
  kezdo_datum: string;
  zaro_datum: string;
  jogcim: string | null;
  forrasev: number | null;
  is_kenyszer: boolean;
  nap_szam: number | null;
  leiras: string | null;
};

const JOGCIM_LABELS: Record<string, string> = {
  alap: "Alapszabadság",
  eletkor: "Életkori pótszabadság",
  gyermek: "Gyermek után járó",
  vezetoi: "Vezetői pótszabadság",
  oktatoi: "Oktatói pótszabadság",
  sugar: "Sugárterhelési pótszabadság",
  apasagi: "Apasági szabadság",
  szuloi: "Szülői szabadság",
  tanulmanyi: "Tanulmányi szabadság",
  egyeb_pot: "Egyéb pótszabadság",
};

function SzabadsagPage() {
  const { user } = useAuth();
  const [ev, setEv] = useState(new Date().getFullYear());
  const [items, setItems] = useState<Entitlement[]>([]);
  const [unavs, setUnavs] = useState<Unav[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    setLoading(true);
    (async () => {
      const [{ data: ents }, { data: us }] = await Promise.all([
        supabase
          .from("leave_entitlement")
          .select("*")
          .eq("user_id", user.id)
          .eq("ev", ev)
          .order("jogcim"),
        supabase
          .from("profile_unavailability")
          .select("id, tipus, status, kezdo_datum, zaro_datum, jogcim, forrasev, is_kenyszer, nap_szam, leiras")
          .eq("user_id", user.id)
          .gte("kezdo_datum", `${ev}-01-01`)
          .lte("kezdo_datum", `${ev}-12-31`)
          .order("kezdo_datum", { ascending: false }),
      ]);
      if (cancelled) return;
      setItems((ents ?? []) as Entitlement[]);
      setUnavs((us ?? []) as Unav[]);
      setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [user, ev]);

  const total = useMemo(() => {
    return items.reduce(
      (acc, e) => {
        acc.jaro += Number(e.jaro_nap) + Number(e.manual_korrekcio);
        acc.athozott += Number(e.athozott_nap);
        acc.kiadott += Number(e.kiadott_nap);
        acc.hatralevo += Number(e.hatralevo);
        return acc;
      },
      { jaro: 0, athozott: 0, kiadott: 0, hatralevo: 0 },
    );
  }, [items]);

  const elozoEviKenyszer = unavs.filter((u) => u.is_kenyszer);

  return (
    <div className="p-8 max-w-5xl mx-auto space-y-6">
      <header className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <Palmtree className="size-6 text-primary" />
            Szabadságom
          </h1>
          <p className="text-sm text-muted-foreground">
            Évenkénti és jogcímenkénti egyenleg. Új igénylést a Karakterlap → Távollétek alatt rögzíthet.
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <select
            value={ev}
            onChange={(e) => setEv(Number(e.target.value))}
            className="px-3 py-2 rounded-md border border-input bg-background text-sm"
          >
            {[ev + 1, ev, ev - 1, ev - 2].map((y) => (
              <option key={y} value={y}>{y}</option>
            ))}
          </select>
          <DownloadButtons ev={ev} />
        </div>
      </header>

      {loading ? (
        <div className="p-12 flex justify-center text-muted-foreground">
          <Loader2 className="size-6 animate-spin" />
        </div>
      ) : (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <StatCard label="Idei járó" value={total.jaro} accent="primary" />
            <StatCard label="Áthozott" value={total.athozott} accent="warning" />
            <StatCard label="Kiadott" value={total.kiadott} accent="muted" />
            <StatCard label="Hátralévő" value={total.hatralevo} accent="success" />
          </div>

          {elozoEviKenyszer.length > 0 && (
            <div className="rounded-lg border border-destructive/40 bg-destructive/10 p-4 space-y-2">
              <div className="flex items-center gap-2 font-semibold text-sm">
                <AlertTriangle className="size-4 text-destructive" />
                Előző évi kényszerkiadás
              </div>
              <ul className="text-xs space-y-1">
                {elozoEviKenyszer.map((k) => (
                  <li key={k.id} className="font-mono">
                    {k.kezdo_datum} – {k.zaro_datum} · {k.nap_szam ?? "-"} nap · forrásév {k.forrasev}
                  </li>
                ))}
              </ul>
            </div>
          )}

          <section>
            <h2 className="text-lg font-semibold mb-3">Jogcímek</h2>
            <div className="rounded-lg border border-border bg-card overflow-hidden">
              <table className="w-full text-sm">
                <thead className="bg-muted text-xs uppercase tracking-wider text-muted-foreground">
                  <tr>
                    <th className="text-left p-3">Jogcím</th>
                    <th className="text-right p-3">Járó</th>
                    <th className="text-right p-3">Korrekció</th>
                    <th className="text-right p-3">Áthozott</th>
                    <th className="text-right p-3">Kiadott</th>
                    <th className="text-right p-3">Tervezett</th>
                    <th className="text-right p-3">Kényszer</th>
                    <th className="text-right p-3 font-bold">Hátralévő</th>
                  </tr>
                </thead>
                <tbody>
                  {items.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="p-6 text-center text-muted-foreground text-xs">
                        Erre az évre még nincs kiszámolt egyenleg. Kérje a HR-t az újraszámolásra.
                      </td>
                    </tr>
                  ) : (
                    items.map((e) => (
                      <tr key={e.id} className="border-t border-border">
                        <td className="p-3 font-medium">{JOGCIM_LABELS[e.jogcim] ?? e.jogcim}</td>
                        <td className="p-3 text-right font-mono">{e.jaro_nap}</td>
                        <td className="p-3 text-right font-mono text-muted-foreground">{e.manual_korrekcio}</td>
                        <td className="p-3 text-right font-mono text-warning">{e.athozott_nap}</td>
                        <td className="p-3 text-right font-mono">{e.kiadott_nap}</td>
                        <td className="p-3 text-right font-mono text-muted-foreground">{e.terv_nap}</td>
                        <td className="p-3 text-right font-mono text-destructive">{e.forced_taken_nap}</td>
                        <td className="p-3 text-right font-mono font-bold">{e.hatralevo}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-3">Idei távollétek</h2>
            <div className="rounded-lg border border-border bg-card divide-y divide-border">
              {unavs.length === 0 ? (
                <div className="p-4 text-xs text-muted-foreground flex items-center gap-2">
                  <Info className="size-4" /> Nincs rögzített távollét ebben az évben.
                </div>
              ) : (
                unavs.map((u) => (
                  <div key={u.id} className="p-3 flex items-center justify-between gap-3 text-sm">
                    <div>
                      <div className="font-medium">
                        {u.tipus} {u.jogcim ? `· ${JOGCIM_LABELS[u.jogcim] ?? u.jogcim}` : ""}
                      </div>
                      <div className="text-xs text-muted-foreground font-mono">
                        {u.kezdo_datum} – {u.zaro_datum} · {u.nap_szam ?? "-"} nap
                        {u.is_kenyszer ? " · KÉNYSZERKIADÁS" : ""}
                      </div>
                      {u.leiras && <div className="text-xs text-muted-foreground mt-1">{u.leiras}</div>}
                    </div>
                    <StatusBadge status={u.status} />
                  </div>
                ))
              )}
            </div>
          </section>
        </>
      )}
    </div>
  );
}

function StatCard({ label, value, accent }: { label: string; value: number; accent: "primary" | "warning" | "muted" | "success" }) {
  const accentCls =
    accent === "primary"
      ? "text-primary"
      : accent === "warning"
        ? "text-warning"
        : accent === "success"
          ? "text-success"
          : "text-muted-foreground";
  return (
    <div className="rounded-lg border border-border bg-card p-4">
      <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className={`text-2xl font-bold font-mono ${accentCls}`}>{value.toFixed(1)}</div>
      <div className="text-[10px] text-muted-foreground">munkanap</div>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { cls: string; label: string }> = {
    jovahagyott: { cls: "bg-success/20 text-success", label: "Jóváhagyva" },
    jovahagyasra_var: { cls: "bg-warning/20 text-warning", label: "Vár" },
    tervezett: { cls: "bg-secondary text-muted-foreground", label: "Tervezett" },
    elutasitott: { cls: "bg-destructive/20 text-destructive", label: "Elutasítva" },
  };
  const m = map[status] ?? { cls: "bg-secondary text-muted-foreground", label: status };
  return <span className={`text-[10px] px-2 py-1 rounded-full font-semibold ${m.cls}`}>{m.label}</span>;
}

function DownloadButtons({ ev }: { ev: number }) {
  const csv = useServerFn(exportLeaveBalanceCsv);
  const pdf = useServerFn(generateLeaveBalancePdf);
  const [busy, setBusy] = useState<"csv" | "pdf" | null>(null);

  async function dl(kind: "csv" | "pdf") {
    setBusy(kind);
    try {
      if (kind === "csv") {
        const r = await csv({ data: { ev } });
        const blob = new Blob(["\ufeff" + r.csv], { type: "text/csv;charset=utf-8" });
        triggerDownload(blob, r.filename);
      } else {
        const r = await pdf({ data: { ev } });
        const bytes = Uint8Array.from(atob(r.pdf), (c) => c.charCodeAt(0));
        triggerDownload(new Blob([bytes], { type: "application/pdf" }), r.filename);
      }
    } catch (e) {
      toast.error(`Letöltés hiba: ${(e as Error).message}`);
    } finally {
      setBusy(null);
    }
  }
  return (
    <>
      <button
        type="button"
        onClick={() => dl("csv")}
        disabled={busy !== null}
        className="inline-flex items-center gap-1 px-3 py-2 rounded-md bg-secondary text-secondary-foreground text-xs font-semibold hover:opacity-90 disabled:opacity-50"
      >
        {busy === "csv" ? <Loader2 className="size-3.5 animate-spin" /> : <Download className="size-3.5" />} CSV
      </button>
      <button
        type="button"
        onClick={() => dl("pdf")}
        disabled={busy !== null}
        className="inline-flex items-center gap-1 px-3 py-2 rounded-md bg-secondary text-secondary-foreground text-xs font-semibold hover:opacity-90 disabled:opacity-50"
      >
        {busy === "pdf" ? <Loader2 className="size-3.5 animate-spin" /> : <FileText className="size-3.5" />} PDF
      </button>
    </>
  );
}

function triggerDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}
