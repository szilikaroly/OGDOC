import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { ArrowLeft, LineChart as LineChartIcon, Printer, Loader2, Activity } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, ReferenceArea } from "recharts";
import { supabase } from "@/integrations/supabase/client";
import { LOINC } from "@/lib/clinical/fhir-codes";

export const Route = createFileRoute("/_authenticated/klinika/lazlap/$encounterId")({
  component: LazlapView,
});

type Obs = {
  id: string;
  loinc_code: string | null;
  code_display: string;
  category: string;
  value_quantity: number | null;
  value_unit: string | null;
  effective_ts: string;
  interpretation: string | null;
};

type Encounter = {
  id: string; patient_id: string; encounter_type: string; status: string;
  start_ts: string; end_ts: string | null; chief_complaint: string | null;
  patients?: { vezeteknev: string; keresztnev: string; taj: string | null; szuletesi_datum: string | null; nem: string | null } | null;
};

const SERIES = [
  { key: "8867-4", label: "HR", color: "#dc2626", axis: "left" },
  { key: "9279-1", label: "RR", color: "#7c3aed", axis: "left" },
  { key: "8480-6", label: "SBP", color: "#0ea5e9", axis: "left" },
  { key: "8462-4", label: "DBP", color: "#0284c7", axis: "left" },
  { key: "8310-5", label: "T °C", color: "#f59e0b", axis: "right" },
  { key: "2708-6", label: "SpO₂", color: "#10b981", axis: "right" },
];

function LazlapView() {
  const { encounterId } = Route.useParams();
  const [encounter, setEncounter] = useState<Encounter | null>(null);
  const [obs, setObs] = useState<Obs[]>([]);
  const [therapy, setTherapy] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    const [{ data: enc }, { data: o }, { data: tx }] = await Promise.all([
      supabase.from("clinical_encounters")
        .select("*, patients(vezeteknev, keresztnev, taj, szuletesi_datum, nem)")
        .eq("id", encounterId).maybeSingle(),
      supabase.from("clinical_observations").select("*").eq("encounter_id", encounterId).order("effective_ts"),
      supabase.from("clinical_therapy_orders").select("*").eq("encounter_id", encounterId).order("created_at"),
    ]);
    setEncounter(enc as Encounter | null);
    setObs((o ?? []) as Obs[]);
    setTherapy(tx ?? []);
    setLoading(false);
  }
  useEffect(() => { void load(); }, [encounterId]);

  const chartData = useMemo(() => {
    // Pivot vitals by timestamp
    const map = new Map<string, any>();
    obs.filter((o) => o.category === "vital-signs" && o.loinc_code && o.value_quantity !== null).forEach((o) => {
      const ts = new Date(o.effective_ts).getTime();
      const slot = map.get(o.effective_ts) ?? { ts, label: new Date(o.effective_ts).toLocaleString("hu-HU", { month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" }) };
      slot[o.loinc_code!] = o.value_quantity;
      map.set(o.effective_ts, slot);
    });
    return Array.from(map.values()).sort((a, b) => a.ts - b.ts);
  }, [obs]);

  const labs = obs.filter((o) => o.category === "laboratory");
  const fluids = obs.filter((o) => o.category === "fluid-balance");
  const pain = obs.filter((o) => o.category === "pain");

  if (loading) return <div className="container py-8 flex items-center gap-2 text-sm"><Loader2 className="h-4 w-4 animate-spin" /> Betöltés…</div>;
  if (!encounter) return <div className="container py-8">Epizód nem található.</div>;

  return (
    <div className="container max-w-7xl py-6 space-y-4 print:py-2">
      <header className="rounded-xl border border-border bg-card p-4 print:border-0 print:p-0">
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div>
            <Link to="/klinika/beteg/$patientId" params={{ patientId: encounter.patient_id }} search={{ encounterId }} className="text-xs text-muted-foreground hover:underline flex items-center gap-1 print:hidden">
              <ArrowLeft className="h-3 w-3" /> Betegkarton
            </Link>
            <h1 className="text-2xl font-semibold mt-1 flex items-center gap-2">
              <LineChartIcon className="h-6 w-6 text-primary" /> Digitális lázlap
            </h1>
            <p className="text-sm">
              <strong>{encounter.patients?.vezeteknev} {encounter.patients?.keresztnev}</strong>
              {" · "}TAJ: {encounter.patients?.taj ?? "—"}{" · "}Szül.: {encounter.patients?.szuletesi_datum ?? "—"}
            </p>
            <p className="text-xs text-muted-foreground">
              Epizód: {encounter.encounter_type} · {new Date(encounter.start_ts).toLocaleString("hu-HU")}
              {encounter.end_ts ? ` – ${new Date(encounter.end_ts).toLocaleString("hu-HU")}` : " (folyamatban)"}
            </p>
          </div>
          <button onClick={() => window.print()} className="print:hidden inline-flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-md border border-border hover:bg-accent">
            <Printer className="h-3.5 w-3.5" /> Nyomtatás (PDF)
          </button>
        </div>
      </header>

      <section className="rounded-xl border border-border bg-card p-4 print:break-inside-avoid">
        <h2 className="text-sm font-semibold mb-3 flex items-center gap-2"><Activity className="h-4 w-4 text-primary" /> Vitálisok időbeli alakulása</h2>
        {chartData.length === 0 ? (
          <p className="text-sm text-muted-foreground">Még nincs rögzített vitális.</p>
        ) : (
          <div style={{ width: "100%", height: 360 }}>
            <ResponsiveContainer>
              <LineChart data={chartData} margin={{ top: 10, right: 30, left: 0, bottom: 30 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="label" angle={-25} textAnchor="end" height={60} tick={{ fontSize: 11 }} />
                <YAxis yAxisId="left" domain={[0, 200]} tick={{ fontSize: 11 }} label={{ value: "HR/RR/BP", angle: -90, position: "insideLeft", fontSize: 11 }} />
                <YAxis yAxisId="right" orientation="right" domain={[30, 110]} tick={{ fontSize: 11 }} label={{ value: "T °C / SpO₂", angle: 90, position: "insideRight", fontSize: 11 }} />
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                {/* Fever band */}
                <ReferenceArea yAxisId="right" y1={38} y2={42} fill="#fecaca" fillOpacity={0.25} />
                {SERIES.map((s) => (
                  <Line key={s.key} yAxisId={s.axis as any} type="monotone" dataKey={s.key} name={s.label} stroke={s.color} strokeWidth={2} dot={{ r: 3 }} connectNulls />
                ))}
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <section className="rounded-xl border border-border bg-card">
          <div className="px-4 py-3 border-b border-border text-sm font-semibold">Laborértékek</div>
          {labs.length === 0 ? <p className="p-4 text-sm text-muted-foreground">Nincs.</p> : (
            <ul className="divide-y divide-border text-sm">
              {labs.map((l) => (
                <li key={l.id} className="px-4 py-2 flex items-center justify-between gap-2">
                  <span>{l.code_display}</span>
                  <span className="font-mono">{l.value_quantity} {l.value_unit}<span className="ml-2 text-xs text-muted-foreground">{new Date(l.effective_ts).toLocaleString("hu-HU")}</span></span>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="rounded-xl border border-border bg-card">
          <div className="px-4 py-3 border-b border-border text-sm font-semibold">Folyadékmérleg & fájdalom</div>
          {fluids.length === 0 && pain.length === 0 ? <p className="p-4 text-sm text-muted-foreground">Nincs.</p> : (
            <ul className="divide-y divide-border text-sm">
              {[...fluids, ...pain].sort((a, b) => +new Date(a.effective_ts) - +new Date(b.effective_ts)).map((l) => (
                <li key={l.id} className="px-4 py-2 flex items-center justify-between gap-2">
                  <span>{l.code_display}</span>
                  <span className="font-mono">{l.value_quantity} {l.value_unit}<span className="ml-2 text-xs text-muted-foreground">{new Date(l.effective_ts).toLocaleString("hu-HU")}</span></span>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      <section className="rounded-xl border border-border bg-card">
        <div className="px-4 py-3 border-b border-border text-sm font-semibold">Terápia / rendelvény</div>
        {therapy.length === 0 ? <p className="p-4 text-sm text-muted-foreground">Nincs.</p> : (
          <table className="w-full text-sm">
            <thead className="bg-muted/40 text-xs"><tr>
              <th className="px-3 py-2 text-left">Típus</th><th className="px-3 py-2 text-left">Megnevezés</th>
              <th className="px-3 py-2 text-left">Dózis</th><th className="px-3 py-2 text-left">Gyakoriság</th><th className="px-3 py-2 text-left">Időtartam</th>
            </tr></thead>
            <tbody>
              {therapy.map((r) => (
                <tr key={r.id} className="border-t border-border">
                  <td className="px-3 py-2 text-xs">{r.kind}</td>
                  <td className="px-3 py-2">{r.display}</td>
                  <td className="px-3 py-2 font-mono text-xs">{r.dose ?? "—"}</td>
                  <td className="px-3 py-2 font-mono text-xs">{r.frequency ?? "—"}</td>
                  <td className="px-3 py-2 font-mono text-xs">{r.duration ?? "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>

      <p className="text-[10px] text-muted-foreground print:text-center">
        Adatok LOINC-kódolva. Nyomtatási nézet: A4 fekvő ajánlott.
      </p>
    </div>
  );
}
