import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Stethoscope, Wrench, Plus, FileText, Loader2, Activity, ChevronRight } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/klinika/")({
  component: KlinikaIndex,
});

type Patient = {
  id: string;
  vezeteknev: string;
  keresztnev: string;
  taj: string | null;
  szuletesi_datum: string | null;
};

type Encounter = {
  id: string;
  patient_id: string;
  encounter_type: string;
  status: string;
  start_ts: string;
  chief_complaint: string | null;
  patients?: { vezeteknev: string; keresztnev: string } | null;
};

function KlinikaIndex() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [patients, setPatients] = useState<Patient[]>([]);
  const [encounters, setEncounters] = useState<Encounter[]>([]);
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;
    void load();
  }, [user]);

  async function load() {
    setLoading(true);
    const [{ data: pats }, { data: encs }] = await Promise.all([
      supabase.from("patients").select("id, vezeteknev, keresztnev, taj, szuletesi_datum").order("vezeteknev").limit(200),
      supabase
        .from("clinical_encounters")
        .select("id, patient_id, encounter_type, status, start_ts, chief_complaint, patients(vezeteknev, keresztnev)")
        .order("start_ts", { ascending: false })
        .limit(20),
    ]);
    setPatients((pats ?? []) as Patient[]);
    setEncounters((encs ?? []) as unknown as Encounter[]);
    setLoading(false);
  }

  async function openOrCreateEncounter(p: Patient, type: string = "ambulatory") {
    if (!user) return;
    setCreating(p.id);
    try {
      // Check active
      const { data: active } = await supabase
        .from("clinical_encounters")
        .select("id")
        .eq("patient_id", p.id)
        .eq("status", "in-progress")
        .order("start_ts", { ascending: false })
        .limit(1)
        .maybeSingle();
      let encId = active?.id;
      if (!encId) {
        const { data, error } = await supabase
          .from("clinical_encounters")
          .insert({ patient_id: p.id, encounter_type: type, status: "in-progress", created_by: user.id })
          .select("id")
          .single();
        if (error) throw error;
        encId = data.id;
        toast.success("Új ellátási epizód megnyitva");
      }
      navigate({ to: "/klinika/beteg/$patientId", params: { patientId: p.id }, search: { encounterId: encId } });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Hiba történt");
    } finally {
      setCreating(null);
    }
  }

  const filtered = patients.filter((p) => {
    if (!q.trim()) return true;
    const s = `${p.vezeteknev} ${p.keresztnev} ${p.taj ?? ""}`.toLowerCase();
    return s.includes(q.toLowerCase());
  });

  return (
    <div className="container max-w-7xl py-6 space-y-6">
      <header className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-semibold flex items-center gap-2">
            <Stethoscope className="h-6 w-6 text-primary" /> Klinikai modul
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Betegellátás, dokumentáció, digitális lázlap és klinikai döntéstámogató eszközök — FHIR-szerű adatmodellel, LOINC/SNOMED kódolással.
          </p>
        </div>
        <Link to="/klinika/eszkozok" className="inline-flex items-center gap-2 px-4 py-2 rounded-md border border-border bg-card hover:bg-accent text-sm">
          <Wrench className="h-4 w-4" /> Eszközök / Kalkulátorok
        </Link>
      </header>

      <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 rounded-xl border border-border bg-card">
          <div className="p-4 border-b border-border flex items-center gap-3">
            <h2 className="text-sm font-semibold flex-1">Beteg keresése és ellátás indítása</h2>
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Név vagy TAJ…"
              className="px-3 py-1.5 text-sm rounded-md border border-border bg-background w-64"
            />
          </div>
          <div className="max-h-[60vh] overflow-auto divide-y divide-border">
            {loading ? (
              <div className="p-6 flex items-center gap-2 text-sm text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" /> Betöltés…
              </div>
            ) : filtered.length === 0 ? (
              <div className="p-6 text-sm text-muted-foreground">Nincs találat.</div>
            ) : (
              filtered.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  disabled={creating === p.id}
                  onClick={() => openOrCreateEncounter(p)}
                  className="w-full px-4 py-3 flex items-center gap-3 hover:bg-accent/40 text-left disabled:opacity-50"
                >
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium">
                      {p.vezeteknev} {p.keresztnev}
                    </div>
                    <div className="text-xs text-muted-foreground truncate">
                      TAJ: {p.taj ?? "—"} · Szül.: {p.szuletesi_datum ?? "—"}
                    </div>
                  </div>
                  {creating === p.id ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <span className="inline-flex items-center gap-1 text-xs text-primary">
                      <Plus className="h-3.5 w-3.5" /> Ellátás <ChevronRight className="h-3.5 w-3.5" />
                    </span>
                  )}
                </button>
              ))
            )}
          </div>
        </div>

        <div className="rounded-xl border border-border bg-card">
          <div className="p-4 border-b border-border flex items-center gap-2">
            <Activity className="h-4 w-4 text-primary" />
            <h2 className="text-sm font-semibold">Utolsó epizódok</h2>
          </div>
          <div className="max-h-[60vh] overflow-auto divide-y divide-border">
            {encounters.length === 0 && !loading ? (
              <div className="p-4 text-sm text-muted-foreground">Még nincs epizód.</div>
            ) : (
              encounters.map((e) => (
                <Link
                  key={e.id}
                  to="/klinika/beteg/$patientId"
                  params={{ patientId: e.patient_id }}
                  search={{ encounterId: e.id }}
                  className="block px-4 py-3 hover:bg-accent/40"
                >
                  <div className="flex items-center justify-between gap-2">
                    <div className="text-sm font-medium truncate">
                      {e.patients?.vezeteknev} {e.patients?.keresztnev}
                    </div>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded-full uppercase font-mono ${
                      e.status === "in-progress" ? "bg-emerald-100 text-emerald-800" : "bg-muted text-muted-foreground"
                    }`}>{e.status}</span>
                  </div>
                  <div className="text-xs text-muted-foreground mt-0.5">
                    {new Date(e.start_ts).toLocaleString("hu-HU")} · {e.encounter_type}
                  </div>
                  {e.chief_complaint && (
                    <div className="text-xs text-muted-foreground mt-1 line-clamp-1 flex items-center gap-1">
                      <FileText className="h-3 w-3" /> {e.chief_complaint}
                    </div>
                  )}
                </Link>
              ))
            )}
          </div>
        </div>
      </section>
    </div>
  );
}
