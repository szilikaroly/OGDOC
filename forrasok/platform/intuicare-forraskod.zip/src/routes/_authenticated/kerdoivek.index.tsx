/**
 * Kérdőív-könyvtár — aktív/licencelt kérdőívek listája.
 */
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { T } from "@/components/T";
import { TranslateButton } from "@/components/TranslateButton";

function KerdoivekIndex() {
  const q = useQuery({
    queryKey: ["questionnaires"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("questionnaires")
        .select("id, code, title, mode, licenc, aktiv, language")
        .order("code");
      if (error) throw new Error(error.message);
      return data ?? [];
    },
  });

  return (
    <main className="container mx-auto px-4 py-8">
      <header className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Kérdőívek</h1>
          <p className="text-sm text-muted-foreground">Klinikai és élmény-mérő eszközök könyvtára.</p>
        </div>
        <div className="flex gap-4 text-sm">
          <Link to="/kerdoivek/varo" className="text-primary hover:underline">Kioszk váró →</Link>
          <Link to="/kerdoivek/recepcio" className="text-primary hover:underline">Recepció (QR) →</Link>
          <Link to="/kerdoivek/attekintes" className="text-primary hover:underline">Áttekintés →</Link>
          <Link to="/kerdoivek/riasztasok" className="text-primary hover:underline">Kritikus riasztások →</Link>
        </div>



      </header>

      {q.isLoading && <Skeleton className="h-40 w-full" />}
      {q.isError && <p className="text-sm text-destructive">{(q.error as Error).message}</p>}

      <div className="grid gap-3 md:grid-cols-2">
        {q.data?.map((k) => (
          <Card key={k.id} className={k.aktiv ? "" : "opacity-60"}>
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center justify-between text-base">
                <span>{k.code}</span>
                <div className="flex items-center gap-1">
                  {!k.aktiv && <Badge variant="outline">licenc szükséges</Badge>}
                  <TranslateButton text={`${k.code} – ${k.title}`} />
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent className="text-sm">
              <T text={k.title} as="p" className="font-medium" />
              <div className="mt-2 flex gap-2 text-xs text-muted-foreground">
                <Badge variant="secondary">{k.mode}</Badge>
                <Badge variant="secondary">{k.licenc}</Badge>
                <span>{k.language}</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </main>
  );
}

export const Route = createFileRoute("/_authenticated/kerdoivek/")({
  component: KerdoivekIndex,
  head: () => ({ meta: [{ title: "Kérdőívek" }] }),
  errorComponent: ({ error, reset }) => (
    <div className="p-6"><p className="text-destructive">{error.message}</p><Button onClick={reset}>Újra</Button></div>
  ),
  notFoundComponent: () => <div className="p-6">Nem található</div>,
});
