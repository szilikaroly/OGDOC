import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { classifyUser } from "@/lib/portal/user-classification.functions";

// Az integration-managed mintát követjük: ssr off (a session localStorage-ben él),
// a beforeLoad ellenőrzi a felhasználót és /auth-ra dob, ha nincs.
// Plusz: ha a user CSAK páciens (nincs staff szerepköre), átirányítjuk a /portal-ra.
export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    const { data, error } = await supabase.auth.getUser();
    if (error || !data.user) {
      throw redirect({ to: "/auth" });
    }
    try {
      const cls = await classifyUser();
      if (!cls.isStaff && cls.isPatient) {
        throw redirect({ to: "/portal" });
      }
    } catch (e) {
      // ha a classify hibázik, ne blokkoljuk a navigációt (csak loggoljuk)
      if ((e as any)?.isRedirect) throw e;
      console.warn("classifyUser failed in _authenticated gate", e);
    }
    return { user: data.user };
  },
  component: AuthedLayout,
});

import { AppShell } from "@/components/app-shell";

function AuthedLayout() {
  return (
    <AppShell>
      <Outlet />
    </AppShell>
  );
}
