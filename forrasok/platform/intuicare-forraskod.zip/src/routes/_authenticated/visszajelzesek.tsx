/**
 * Visszajelentő (follow-up) rendszer áttekintő — staff oldal.
 * Tabok: Protokollok / Aktív követések / Esedékességek / Riasztások (auto recall).
 */
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { StatusBadge } from "@/components/ui/status-badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Inbox, Activity, ListChecks, AlertTriangle } from "lucide-react";
import {
  listFollowupProtocols, toggleFollowupProtocol,
  listFollowupEnrollments, listFollowupOccurrences,
  setFollowupEnrollmentStatus,
} from "@/lib/followup/followup.functions";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/visszajelzesek")({
  component: VisszajelzesekPage,
  errorComponent: ({ error }) => (
    <div className="p-6">
      <p className="text-destructive">Hiba: {error.message}</p>
    </div>
  ),
  notFoundComponent: () => <div className="p-6">Az oldal nem található.</div>,
});

function fmt(iso: string | null | undefined): string {
  if (!iso) return "—";
  return new Date(iso).toLocaleString("hu-HU", {
    year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit",
  });
}
function patientName(p: any): string {
  if (!p) return "—";
  return `${p.vezeteknev ?? ""} ${p.keresztnev ?? ""}`.trim() || "—";
}

function VisszajelzesekPage() {
  const qc = useQueryClient();
  const protocolsFn = useServerFn(listFollowupProtocols);
  const toggleFn = useServerFn(toggleFollowupProtocol);
  const enrollFn = useServerFn(listFollowupEnrollments);
  const occFn = useServerFn(listFollowupOccurrences);
  const setStatusFn = useServerFn(setFollowupEnrollmentStatus);

  const protocols = useQuery({ queryKey: ["fu-protocols"], queryFn: () => protocolsFn() });
  const enrollments = useQuery({
    queryKey: ["fu-enrollments", "active"],
    queryFn: () => enrollFn({ data: { status: "active" } }),
  });
  const occOpen = useQuery({
    queryKey: ["fu-occ", "sent"],
    queryFn: () => occFn({ data: { status: "sent" } }),
  });

  // Riasztások: patient_appointment_requests followup_auto_recall
  const recalls = useQuery({
    queryKey: ["fu-recalls"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("patient_appointment_requests")
        .select("id, patient_id, urgency, status, reason, created_at")
        .eq("request_type", "followup_auto_recall")
        .order("created_at", { ascending: false })
        .limit(200);
      if (error) throw error;
      return data ?? [];
    },
  });

  return (
    <div className="p-6 space-y-4">
      <header>
        <h1 className="text-2xl font-bold">Visszajelentő rendszer</h1>
        <p className="text-sm text-muted-foreground">
          Szülés / műtét / elbocsátás / vizit utáni automatizált követés tünet-alapú kontroll-foglalási javaslattal.
        </p>
      </header>

      <Tabs defaultValue="protocols">
        <TabsList>
          <TabsTrigger value="protocols"><ListChecks className="h-4 w-4 mr-1" />Protokollok</TabsTrigger>
          <TabsTrigger value="enrollments"><Activity className="h-4 w-4 mr-1" />Aktív követések</TabsTrigger>
          <TabsTrigger value="occurrences"><Inbox className="h-4 w-4 mr-1" />Esedékességek</TabsTrigger>
          <TabsTrigger value="recalls"><AlertTriangle className="h-4 w-4 mr-1" />Auto-kontroll javaslatok</TabsTrigger>
        </TabsList>

        <TabsContent value="protocols" className="space-y-3">
          {protocols.isLoading && <Skeleton className="h-32" />}
          {protocols.data?.map((p: any) => (
            <Card key={p.id}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0">
                <div>
                  <CardTitle className="text-base">{p.nev}</CardTitle>
                  <p className="text-xs text-muted-foreground">
                    Horgony: <Badge variant="secondary">{p.anchor_event}</Badge> ·{" "}
                    Ablak: {p.default_window_days} nap
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground">{p.aktiv ? "Aktív" : "Inaktív"}</span>
                  <Switch
                    checked={p.aktiv}
                    onCheckedChange={async (v) => {
                      await toggleFn({ data: { id: p.id, aktiv: v } });
                      qc.invalidateQueries({ queryKey: ["fu-protocols"] });
                    }}
                  />
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm mb-2">{p.leiras}</p>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Fázis</TableHead>
                      <TableHead>Naptól-ig</TableHead>
                      <TableHead>Ismétlés</TableHead>
                      <TableHead>Csatorna</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {(p.followup_protocol_steps ?? [])
                      .sort((a: any, b: any) => a.phase_order - b.phase_order)
                      .map((s: any) => (
                        <TableRow key={s.id}>
                          <TableCell>{s.phase_label}</TableCell>
                          <TableCell>{s.offset_days_from}–{s.offset_days_to} nap</TableCell>
                          <TableCell>{s.cadence_days} naponta</TableCell>
                          <TableCell><Badge variant="outline">{s.channel}</Badge></TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="enrollments">
          <Card>
            <CardContent className="pt-4">
              {enrollments.isLoading && <Skeleton className="h-32" />}
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Páciens</TableHead>
                    <TableHead>Protokoll</TableHead>
                    <TableHead>Horgony</TableHead>
                    <TableHead>Státusz</TableHead>
                    <TableHead></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {enrollments.data?.map((e: any) => (
                    <TableRow key={e.id}>
                      <TableCell>{patientName(e.patients)}</TableCell>
                      <TableCell>{e.followup_protocols?.nev}</TableCell>
                      <TableCell>{fmt(e.anchor_at)}</TableCell>
                      <TableCell><Badge>{e.status}</Badge></TableCell>
                      <TableCell>
                        <Button
                          size="sm" variant="outline"
                          onClick={async () => {
                            await setStatusFn({ data: { id: e.id, status: "paused", paused_reason: "Staff szüneteltette" } });
                            qc.invalidateQueries({ queryKey: ["fu-enrollments"] });
                          }}
                        >Szüneteltetés</Button>
                      </TableCell>
                    </TableRow>
                  ))}
                  {enrollments.data?.length === 0 && (
                    <TableRow><TableCell colSpan={5} className="text-center text-muted-foreground py-6">Nincs aktív követés.</TableCell></TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="occurrences">
          <Card>
            <CardContent className="pt-4">
              {occOpen.isLoading && <Skeleton className="h-32" />}
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Páciens</TableHead>
                    <TableHead>Protokoll</TableHead>
                    <TableHead>Esedékes</TableHead>
                    <TableHead>Státusz</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {occOpen.data?.map((o: any) => (
                    <TableRow key={o.id}>
                      <TableCell>{patientName(o.followup_enrollments?.patients)}</TableCell>
                      <TableCell>{o.followup_enrollments?.followup_protocols?.nev}</TableCell>
                      <TableCell>{fmt(o.due_at)}</TableCell>
                      <TableCell><StatusBadge tone={o.status === "missed" ? "bad" : "info"}>{o.status}</StatusBadge></TableCell>
                    </TableRow>
                  ))}
                  {occOpen.data?.length === 0 && (
                    <TableRow><TableCell colSpan={4} className="text-center text-muted-foreground py-6">Nincs nyitott esedékesség.</TableCell></TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="recalls">
          <Card>
            <CardContent className="pt-4">
              {recalls.isLoading && <Skeleton className="h-32" />}
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Időpont</TableHead>
                    <TableHead>Sürgősség</TableHead>
                    <TableHead>Indok</TableHead>
                    <TableHead>Státusz</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recalls.data?.map((r: any) => (
                    <TableRow key={r.id}>
                      <TableCell>{fmt(r.created_at)}</TableCell>
                      <TableCell>
                        <StatusBadge
                          tone={r.urgency === "urgent" ? "bad" : r.urgency === "soon" ? "warn" : "info"}
                        >{r.urgency}</StatusBadge>
                      </TableCell>
                      <TableCell className="text-sm">{r.reason}</TableCell>
                      <TableCell><Badge>{r.status}</Badge></TableCell>
                    </TableRow>
                  ))}
                  {recalls.data?.length === 0 && (
                    <TableRow><TableCell colSpan={4} className="text-center text-muted-foreground py-6">Nincs automatikus javaslat.</TableCell></TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
