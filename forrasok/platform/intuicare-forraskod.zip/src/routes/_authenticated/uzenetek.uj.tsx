import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { listTeamMembers, createConversation } from "@/lib/messaging/conversations.functions";
import { useState } from "react";
import { Users, User, Bot, Stethoscope } from "lucide-react";

export const Route = createFileRoute("/_authenticated/uzenetek/uj")({
  component: NewConversationPage,
});

type Kind = "dm" | "group" | "patient_team" | "ai_assistant";

function NewConversationPage() {
  const navigate = useNavigate();
  const list = useServerFn(listTeamMembers);
  const create = useServerFn(createConversation);
  const { data: members } = useQuery({ queryKey: ["messaging", "team"], queryFn: () => list() });

  const [kind, setKind] = useState<Kind>("dm");
  const [title, setTitle] = useState("");
  const [selected, setSelected] = useState<Set<string>>(new Set());

  const m = useMutation({
    mutationFn: async () => {
      const res = await create({
        data: {
          kind,
          title: title.trim() || undefined,
          participant_user_ids: kind === "ai_assistant" ? [] : Array.from(selected),
        },
      });
      return res.id;
    },
    onSuccess: (id) => navigate({ to: "/uzenetek/$conversationId", params: { conversationId: id } }),
  });

  const kindOptions: Array<{ key: Kind; label: string; icon: typeof User; desc: string }> = [
    { key: "dm", label: "1:1 csapatkolléga", icon: User, desc: "Privát üzenet egy munkatársnak" },
    { key: "group", label: "Csapat-csoport", icon: Users, desc: "Több munkatárs közös szobája" },
    { key: "patient_team", label: "Beteg ellátócsapat", icon: Stethoscope, desc: "Beteghez kötött belső koordináció" },
    { key: "ai_assistant", label: "AI asszisztens", icon: Bot, desc: "Segít megtalálni korábbi orvost és időpontot" },
  ];

  return (
    <div className="flex-1 overflow-auto p-8 max-w-3xl">
      <h1 className="text-2xl font-bold mb-1">Új beszélgetés</h1>
      <p className="text-sm text-muted-foreground mb-6">Válassz típust és tagokat.</p>

      <div className="grid grid-cols-2 gap-3 mb-6">
        {kindOptions.map((o) => {
          const active = kind === o.key;
          const Icon = o.icon;
          return (
            <button
              key={o.key}
              type="button"
              onClick={() => setKind(o.key)}
              className={`text-left p-4 rounded-lg border transition-colors ${active ? "border-primary bg-primary/5" : "border-border hover:bg-secondary/40"}`}
            >
              <div className="flex items-center gap-2 mb-1 font-semibold text-sm">
                <Icon className="size-4" /> {o.label}
              </div>
              <div className="text-xs text-muted-foreground">{o.desc}</div>
            </button>
          );
        })}
      </div>

      {(kind === "group" || kind === "patient_team") && (
        <div className="mb-4">
          <label className="block text-xs font-semibold mb-1.5 uppercase tracking-wide">Cím (opcionális)</label>
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="pl. Belgyógyászati ügyelet"
            className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm"
          />
        </div>
      )}

      {kind !== "ai_assistant" && (
        <div className="mb-6">
          <label className="block text-xs font-semibold mb-2 uppercase tracking-wide">
            Tagok {kind === "dm" ? "(válassz egyet)" : ""}
          </label>
          <div className="max-h-80 overflow-auto border border-border rounded-md divide-y divide-border">
            {(members ?? []).map((p) => {
              const checked = selected.has(p.id);
              return (
                <label key={p.id} className="flex items-center gap-3 px-3 py-2 cursor-pointer hover:bg-secondary/40">
                  <input
                    type={kind === "dm" ? "radio" : "checkbox"}
                    name="member"
                    checked={checked}
                    onChange={() => {
                      const next = new Set(kind === "dm" ? [] : selected);
                      if (kind === "dm") next.add(p.id);
                      else if (checked) next.delete(p.id);
                      else next.add(p.id);
                      setSelected(next);
                    }}
                  />
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium truncate">{p.teljes_nev}</div>
                    <div className="text-xs text-muted-foreground truncate">{p.email}</div>
                  </div>
                  <span className="text-[10px] uppercase font-mono text-muted-foreground">{p.foglalkozas_tipus}</span>
                </label>
              );
            })}
          </div>
        </div>
      )}

      <div className="flex gap-2">
        <button
          type="button"
          onClick={() => m.mutate()}
          disabled={m.isPending || (kind !== "ai_assistant" && selected.size === 0)}
          className="px-4 py-2 rounded-md bg-primary text-primary-foreground text-sm font-semibold disabled:opacity-50"
        >
          {m.isPending ? "Létrehozás…" : "Beszélgetés indítása"}
        </button>
        <button
          type="button"
          onClick={() => navigate({ to: "/uzenetek" })}
          className="px-4 py-2 rounded-md border border-border text-sm font-semibold"
        >
          Mégse
        </button>
      </div>
      {m.error && <div className="text-destructive text-sm mt-3">{(m.error as Error).message}</div>}
    </div>
  );
}
