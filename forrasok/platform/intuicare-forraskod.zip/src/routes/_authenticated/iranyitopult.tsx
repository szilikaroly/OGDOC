import { createFileRoute, redirect } from "@tanstack/react-router";
import { useAuth } from "@/hooks/use-auth";
import { WIDGET_CATALOG } from "@/components/iranyitopult/widgets";
import { useDashboardConfig, DashboardSidebar, SIZE_COL } from "@/components/iranyitopult/dashboard-sidebar";
import { classifyUser } from "@/lib/portal/user-classification.functions";
import { PushPermissionPrompt } from "@/components/messaging/PushPermissionPrompt";

export const Route = createFileRoute("/_authenticated/iranyitopult")({
  ssr: false,
  beforeLoad: async ({ location }) => {
    try {
      const cls = await classifyUser();
      // Csak staff (orvos / admin / egyéb szerepkörrel rendelkező) léphet be.
      if (!cls.isStaff) {
        throw redirect({
          to: "/unauthorized",
          search: { required: "staff", from: location.pathname } as any,
        });
      }
    } catch (e) {
      if ((e as any)?.isRedirect) throw e;
      throw redirect({
        to: "/unauthorized",
        search: { required: "staff", from: location.pathname } as any,
      });
    }
  },
  component: Iranyitopult,
});

function Iranyitopult() {
  const { user } = useAuth();
  const { config, setConfig, loaded } = useDashboardConfig();

  if (!user) return <div className="p-6 text-sm text-muted-foreground">Bejelentkezés szükséges.</div>;
  if (!loaded) return <div className="p-6 text-sm text-muted-foreground">Irányítópult betöltése…</div>;

  return (
    <div className="flex min-h-[calc(100vh-3rem)]">
      <main className="flex-1 p-4 md:p-6 overflow-auto">
        <div className="mb-5">
          <h1 className="text-2xl font-bold">Irányítópult</h1>
          <p className="text-sm text-muted-foreground">Üdvözöljük! Itt találja a beosztását, szabadságát, üzeneteit és a klinika híreit.</p>
        </div>
        <PushPermissionPrompt />

        <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
          {config.widgets.filter(w => w.enabled).map(w => {
            const meta = WIDGET_CATALOG.find(c => c.id === w.id);
            if (!meta) return null;
            const Comp = meta.component;
            return (
              <div key={w.id} className={`col-span-1 ${SIZE_COL[w.size]}`}>
                <Comp />
              </div>
            );
          })}
        </div>
      </main>
      <DashboardSidebar config={config} setConfig={setConfig} />
    </div>
  );
}
