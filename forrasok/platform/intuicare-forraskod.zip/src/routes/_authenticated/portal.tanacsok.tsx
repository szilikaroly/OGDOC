/**
 * Bejelentkezett portál: tanácsok személyre szabva (kiemelt + lista).
 */
import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";
import { listPublishedTips, listTipCategories } from "@/lib/cms/tips.functions";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, Star } from "lucide-react";
import { useState } from "react";
import { SmartImage } from "@/components/ui/smart-image";
import { PullToRefreshPage } from "@/components/ui/mobile-list";
import { useListRefresh } from "@/hooks/use-list-refresh";

export const Route = createFileRoute("/_authenticated/portal/tanacsok")({
  component: PortalTanacsokPage,
});

function PortalTanacsokPage() {
  const { i18n } = useTranslation();
  const locale = i18n.language || "hu";
  const [cat, setCat] = useState<string | null>(null);
  const listFn = useServerFn(listPublishedTips);
  const catsFn = useServerFn(listTipCategories);
  const { data } = useQuery({
    queryKey: ["portal-tanacsok", locale, cat],
    queryFn: () => listFn({ data: { locale, category: cat ?? undefined, limit: 60 } }),
  });
  const { data: cats = [] } = useQuery({ queryKey: ["tanacs-cats"], queryFn: () => catsFn() });
  const tips = (data?.tips ?? []) as any[];
  const localizedName = (i18nObj: any) => (i18nObj?.[locale] ?? i18nObj?.hu ?? "—") as string;

  const onRefresh = useListRefresh([["portal-tanacsok"], ["tanacs-cats"]]);
  return (
    <PullToRefreshPage onRefresh={onRefresh}>
    <main className="container mx-auto px-3 sm:px-6 lg:px-8 py-4 sm:py-8 max-w-6xl">
      <header className="mb-4">
        <h1 className="text-2xl sm:text-3xl font-bold">Tanácsok</h1>
        <p className="text-muted-foreground text-sm mt-1">Lektorált egészségügyi tartalmak.</p>
      </header>
      <div className="flex flex-wrap gap-1.5 mb-4">
        <Badge variant={!cat ? "default" : "outline"} className="cursor-pointer min-h-7" onClick={() => setCat(null)}>Mind</Badge>
        {(cats as any[]).map((c) => (
          <Badge key={c.id} variant={cat === c.slug ? "default" : "outline"} className="cursor-pointer min-h-7" onClick={() => setCat(c.slug)}>{localizedName(c.name_i18n)}</Badge>
        ))}
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {tips.map((t) => {
          const tr = (t.cms_tip_translations ?? [])[0];
          return (
            <Link key={t.id} to="/tanacsok/$slug" params={{ slug: t.slug }} className="block">
              <Card className="h-full hover:border-primary transition overflow-hidden">
                {t.cover_url && <SmartImage src={t.cover_url} alt="" sizesPreset="card" className="w-full aspect-video object-cover" />}
                <CardContent className="p-3">
                  <p className="font-semibold leading-tight flex items-start gap-1">
                    {t.featured && <Star className="size-3 fill-amber-500 text-amber-500 shrink-0 mt-1" />}
                    {tr?.title ?? t.slug}
                  </p>
                  {tr?.lead && <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{tr.lead}</p>}
                  {t.reading_minutes ? <span className="inline-flex items-center gap-1 mt-2 text-[11px] text-muted-foreground"><Clock className="size-3" />{t.reading_minutes} perc</span> : null}
                </CardContent>
              </Card>
            </Link>
          );
        })}
        {!tips.length && <p className="text-sm text-muted-foreground col-span-full text-center py-8">Nincs még tartalom.</p>}
      </div>
    </main>
    </PullToRefreshPage>
  );
}
