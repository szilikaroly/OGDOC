import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/_authenticated/muteti-terv/")({
  beforeLoad: () => {
    throw redirect({ to: "/muteti-terv/blokkok" });
  },
});
