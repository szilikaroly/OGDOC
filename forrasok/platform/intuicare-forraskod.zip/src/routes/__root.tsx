import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";
import { Toaster, toast } from "sonner";

import appCss from "../styles.css?url";
import { RootErrorBoundary } from "../lib/errors/route-boundaries";
import { supabase } from "../integrations/supabase/client";
import "../i18n";
import { AutoTranslateProvider } from "../components/AutoTranslateProvider";
import { TranslationDebugPanel } from "../components/i18n/translation-debug-panel";
import { ExperimentDebugOverlay } from "../components/cms/experiment-debug-overlay";

import { ThemeApplier } from "../components/theme-applier";
import { useViewTransitions } from "../hooks/use-view-transitions";
import { PwaInstallPrompt } from "../components/pwa-install-prompt";
import { GlobalActionErrorBoundary } from "../components/global-action-error-boundary";
import { OfflineBadge } from "../components/pwa/offline-badge";
import { initQueryPersistence } from "../lib/pwa/query-persist";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Az oldal nem található</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          A keresett oldal nem létezik vagy áthelyezték.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Vissza a főoldalra
          </Link>
        </div>
      </div>
    </div>
  );
}

const ErrorComponent = RootErrorBoundary;

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { name: "theme-color", content: "#0F172A" },
      { name: "apple-mobile-web-app-capable", content: "yes" },
      { name: "apple-mobile-web-app-status-bar-style", content: "black-translucent" },
      { title: "MedRoster Suite Pro - HR, Munkaidő és időpontfoglaló" },
      {
        name: "description",
        content:
          "Klinikai HR és intelligens beosztómotor – multi-tenant SaaS több klinikának, telephellyel, osztállyal és szakterülettel.",
      },
      { name: "author", content: "MedRoster" },
      { property: "og:title", content: "MedRoster Suite Pro - HR, Munkaidő és időpontfoglaló" },
      {
        property: "og:description",
        content: "Klinikai HR és intelligens beosztómotor",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "twitter:title", content: "MedRoster Suite Pro - HR, Munkaidő és időpontfoglaló" },
      { name: "description", content: "AI alapú egészségügyi rendszer mely optimalizálja az ellátás minden dimenzióját." },
      { property: "og:description", content: "AI alapú egészségügyi rendszer mely optimalizálja az ellátás minden dimenzióját." },
      { name: "twitter:description", content: "AI alapú egészségügyi rendszer mely optimalizálja az ellátás minden dimenzióját." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/965da657-00a0-46cd-ab40-f4c472b3ba37/id-preview-3252d354--23fe2ad3-1ad0-4e50-b650-1486a8fd8e70.lovable.app-1781909890646.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/965da657-00a0-46cd-ab40-f4c472b3ba37/id-preview-3252d354--23fe2ad3-1ad0-4e50-b650-1486a8fd8e70.lovable.app-1781909890646.png" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/manifest.webmanifest" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap",
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="hu">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  useEffect(() => {
    // React Query cache perzisztálása (offline listák/oldalak).
    initQueryPersistence(queryClient);

    // Service worker registration (PWA + offline attendance buffer).
    // Preview iframe-ekben kihagyjuk, hogy ne cache-eljünk elavult tartalmat.
    if ("serviceWorker" in navigator) {
      const host = window.location.hostname;
      const isPreview =
        host.startsWith("id-preview--") ||
        host.startsWith("preview--") ||
        host.endsWith(".lovableproject.com") ||
        host.endsWith(".lovableproject-dev.com");
      const killSwitch = new URLSearchParams(window.location.search).get("sw") === "off";
      if (killSwitch) {
        navigator.serviceWorker.getRegistrations().then((regs) =>
          regs.forEach((r) => r.unregister()),
        ).catch(() => {});
      } else if (!isPreview) {
        navigator.serviceWorker.register("/sw.js").catch(() => {});
      }
    }
    const { data: sub } = supabase.auth.onAuthStateChange((event) => {
      if (event !== "SIGNED_IN") return;
      // Post-migration / post-login self-heal of role_permissions seed.
      // Non-admins are blocked by SECURITY DEFINER + RLS; failure is silent.
      void supabase.rpc("ensure_role_permissions_seed").then(
        ({ data, error }) => {
          if (error) return;
          const inserted = typeof data === "number" ? data : 0;
          try {
            localStorage.setItem(
              "medroster.lastSeed",
              JSON.stringify({ ts: Date.now(), inserted }),
            );
          } catch {}
          if (inserted > 0) {
            toast.success(`${inserted} hiányzó jogosultság-alap automatikusan pótolva`);
            console.info("[self-heal] role_permissions seed inserted:", inserted);
          }
        },
        () => {},
      );
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:left-2 focus:z-[100] focus:px-3 focus:py-2 focus:rounded-md focus:bg-primary focus:text-primary-foreground focus:shadow-lg"
      >
        Ugrás a tartalomra
      </a>
      <UserLocaleSync />
      <AutoTranslateProvider />
      <ThemeApplier />
      <GlobalActionErrorBoundary />
      <ViewTransitionBridge />
      {/* Required: nested routes render here. Removing <Outlet /> breaks all child routes. */}
      <div id="main-content" className="min-h-dvh" style={{ paddingTop: "env(safe-area-inset-top)", paddingBottom: "env(safe-area-inset-bottom)" }}>
        <Outlet />
      </div>
      <ResponsiveToaster />
      <PwaInstallPrompt />
      <OfflineBadge />
      <TranslationDebugPanel />
      <ExperimentDebugOverlay />


    </QueryClientProvider>
  );
}

function ViewTransitionBridge() {
  useViewTransitions();
  return null;
}

/** Toaster mobilon top-center (hüvelykujj-távol), desktopon top-right. */
function ResponsiveToaster() {
  const isMobile =
    typeof window !== "undefined" &&
    window.matchMedia?.("(max-width: 640px)").matches;
  return (
    <Toaster
      position={isMobile ? "top-center" : "top-right"}
      richColors
      closeButton
      offset={isMobile ? 12 : 24}
    />
  );
}





function UserLocaleSync() {
  useEffect(() => {
    let cancelled = false;
    let saveTimer: ReturnType<typeof setTimeout> | null = null;

    async function loadProfileLocale() {
      const { data } = await supabase.auth.getUser();
      if (!data.user || cancelled) return;
      try {
        const { getUserLocale } = await import("@/lib/i18n/admin.functions");
        const r = await getUserLocale();
        if (cancelled || !r?.locale) return;
        const i18n = (await import("@/i18n")).default;
        if (i18n.language?.split("-")[0] !== r.locale) {
          i18n.changeLanguage(r.locale);
        }
      } catch {/* not signed in or no profile yet */}
    }

    loadProfileLocale();

    // Save on language change
    import("@/i18n").then(({ default: i18n }) => {
      i18n.on("languageChanged", (lng) => {
        if (saveTimer) clearTimeout(saveTimer);
        saveTimer = setTimeout(async () => {
          try {
            const { saveUserLocale } = await import("@/lib/i18n/admin.functions");
            await saveUserLocale({ data: { locale: lng } });
          } catch {/* not signed in */}
        }, 800);
      });
    });

    return () => { cancelled = true; if (saveTimer) clearTimeout(saveTimer); };
  }, []);
  return null;
}
