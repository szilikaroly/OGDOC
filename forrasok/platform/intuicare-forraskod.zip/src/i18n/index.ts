import i18n from "i18next";
import { initReactI18next } from "react-i18next";
import LanguageDetector from "i18next-browser-languagedetector";
import { hu } from "./locales/hu";
import { en } from "./locales/en";
import { LANG_CODES } from "./languages";

type AnyDict = Record<string, unknown>;

// Flatten nested HU dictionary into dot.notation keys for batch translation.
function flatten(obj: AnyDict, prefix = ""): Record<string, string> {
  const out: Record<string, string> = {};
  for (const [k, v] of Object.entries(obj)) {
    const p = prefix ? `${prefix}.${k}` : k;
    if (v && typeof v === "object" && !Array.isArray(v)) {
      Object.assign(out, flatten(v as AnyDict, p));
    } else if (typeof v === "string") {
      out[p] = v;
    }
  }
  return out;
}

const huFlat = flatten(hu as unknown as AnyDict);

// Queue and debounce missing keys per language
const pending = new Map<string, Set<string>>();
let flushTimer: ReturnType<typeof setTimeout> | null = null;

async function flush() {
  flushTimer = null;
  const tasks: Array<Promise<void>> = [];
  for (const [lng, keys] of pending.entries()) {
    if (keys.size === 0) continue;
    const allItems = Array.from(keys)
      .map((k) => ({ key: k, source: huFlat[k] ?? k, namespace: "ui" }))
      .filter((i) => typeof i.source === "string" && i.source.length > 0);
    keys.clear();
    if (allItems.length === 0) continue;

    tasks.push(
      (async () => {
        try {
          const { translateBatchSafe } = await import("@/lib/i18n/translate.functions");
          const merged = await translateBatchSafe({
            items: allItems,
            target_lang: lng,
            kind: "ui",
            db_only: true,
          });

          const bundle: AnyDict = {};
          for (const [dotKey, value] of Object.entries(merged)) {
            const parts = dotKey.split(".");
            let cur: AnyDict = bundle;
            for (let i = 0; i < parts.length - 1; i++) {
              cur[parts[i]] = (cur[parts[i]] as AnyDict) ?? {};
              cur = cur[parts[i]] as AnyDict;
            }
            cur[parts[parts.length - 1]] = value;
          }
          i18n.addResourceBundle(lng, "translation", bundle, true, true);
          if (i18n.language === lng) {
            i18n.changeLanguage(lng);
          }
        } catch (err: any) {
          console.warn("[i18n] auto-translate failed", err);
          try {
            const { recordTranslationError } = await import("@/lib/i18n/translation-errors");
            recordTranslationError({
              lang: lng,
              namespace: "ui",
              items: allItems,
              message: String(err?.message ?? err ?? "Ismeretlen hiba"),
            });
          } catch {/* ignore */}
        }
      })(),
    );
  }
  await Promise.allSettled(tasks);
}

function queueMissing(lng: string, key: string) {
  if (lng === "hu" || !LANG_CODES.includes(lng as never)) return;
  if (!huFlat[key]) return;
  // Kliens-oldali „hiányzó kulcs” store — a TranslationDebugPanel ebből
  // olvas, hogy admin/QA azonnal lássa mit nem fordítottunk le.
  import("@/lib/i18n/missing-keys-store").then(({ missingKeysStore }) => {
    missingKeysStore.record(lng, key, huFlat[key]);
  }).catch(() => {/* ignore */});
  if (!pending.has(lng)) pending.set(lng, new Set());
  pending.get(lng)!.add(key);
  if (!flushTimer) flushTimer = setTimeout(flush, 350);
}


if (!i18n.isInitialized) {
  i18n
    .use(LanguageDetector)
    .use(initReactI18next)
    .init({
      resources: { hu: { translation: hu }, en: { translation: en } },
      fallbackLng: "hu",
      supportedLngs: [...LANG_CODES],
      nonExplicitSupportedLngs: true,
      load: "languageOnly",
      interpolation: { escapeValue: false },
      saveMissing: true,
      missingKeyHandler: (lngs, _ns, key) => {
        for (const lng of lngs) queueMissing(lng, key);
      },
      detection: {
        order: ["localStorage", "navigator"],
        caches: ["localStorage"],
        lookupLocalStorage: "medroster_lang",
      },
    });
}

// When language switches to a non-baked language, bulk-prefetch all UI keys.
const prefetched = new Set<string>(["hu", "en"]);
i18n.on("languageChanged", (lng) => {
  if (prefetched.has(lng) || !LANG_CODES.includes(lng as never)) return;
  prefetched.add(lng);
  for (const k of Object.keys(huFlat)) queueMissing(lng, k);
});

export default i18n;
