export const SUPPORTED_LANGUAGES = [
  { code: "hu", label: "Magyar", flag: "🇭🇺" },
  { code: "en", label: "English", flag: "🇬🇧" },
  { code: "de", label: "Deutsch", flag: "🇩🇪" },
  { code: "ro", label: "Română", flag: "🇷🇴" },
  { code: "sk", label: "Slovenčina", flag: "🇸🇰" },
  { code: "sr", label: "Srpski", flag: "🇷🇸" },
  { code: "uk", label: "Українська", flag: "🇺🇦" },
  { code: "ru", label: "Русский", flag: "🇷🇺" },
  { code: "zh", label: "中文", flag: "🇨🇳" },
  { code: "fil", label: "Filipino", flag: "🇵🇭" },
] as const;

export type LangCode = (typeof SUPPORTED_LANGUAGES)[number]["code"];
export const LANG_CODES = SUPPORTED_LANGUAGES.map((l) => l.code);
