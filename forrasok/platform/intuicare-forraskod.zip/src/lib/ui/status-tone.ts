import type { StatusTone } from "@/components/ui/status-badge";

/** Klinikai severity → StatusBadge tone leképzés. */
export function severityTone(s: string | null | undefined): StatusTone {
  if (!s) return "neutral";
  const v = s.toLowerCase();
  if (v === "critical" || v === "high" || v === "severe") return "bad";
  if (v === "medium" || v === "moderate") return "warn";
  if (v === "low" || v === "mild") return "info";
  return "neutral";
}

/** Általános státusz string → tone (open/closed/expired/acknowledged stb.). */
export function statusTone(s: string | null | undefined): StatusTone {
  if (!s) return "neutral";
  const v = s.toLowerCase();
  if (v === "open" || v === "expired" || v === "failed" || v === "cancelled" || v === "rejected") return "bad";
  if (v === "pending" || v === "in_progress" || v === "due") return "warn";
  if (v === "closed" || v === "completed" || v === "acknowledged" || v === "resolved" || v === "ok" || v === "printed" || v === "sent" || v === "active") return "ok";
  return "neutral";
}

/** Esedékességi tone (időpontig hátralévő idő alapján). */
export function dueTone(dueIso: string | null | undefined): { tone: StatusTone; label: string } {
  if (!dueIso) return { tone: "neutral", label: "Időkorlát nélkül" };
  const t = new Date(dueIso).getTime();
  const now = Date.now();
  if (t < now) return { tone: "bad", label: "Esedékes" };
  if (t - now < 24 * 3600 * 1000) return { tone: "warn", label: "24 órán belül" };
  return { tone: "neutral", label: new Date(dueIso).toLocaleString("hu-HU") };
}
