/**
 * Kérdőív-pontozás (tiszta TS).
 *
 * A `definition` a DB-ben tárolt `questionnaires` rekord scoring/cutoffs/items
 * mezőit várja JSON-ban. Csak az általunk seedelt, szabad licencű eszközöket
 * támogatjuk explicit logikával; egyéb kérdőívek a generikus összegzéssel
 * pontozhatók.
 *
 * Alskálák (subscale_scores):
 *   - PHQ-9 → phq2 (tétel 1+2), bucket: pozitiv ha >=3
 *   - GAD-7 → gad2 (tétel 1+2), bucket: pozitiv ha >=3
 *   - PHQ-4 → phq2 (1+2), gad2 (3+4)
 *   - WHO-5 → raw (0–25) és index (raw × 4, 0–100); jólléti küszöb 50 alatt
 *   - AUDIT-C → total + nemi küszöb (férfi >=4, nő >=3) flag-ben
 *   - PHQ-9 → critical (#9 > 0)
 */

export type QuestionnaireItem = {
  index: number;          // 1-alapú sorszám
  text: string;
  type: "likert" | "boolean" | "multi";
  options?: { value: number; label: string }[];
};

export type SeverityCutoff = {
  min: number;
  max: number;
  severity: string; // pl. "enyhe", "kozepes", "sulyos"
};

export type QuestionnaireDefinition = {
  code: string;                 // PHQ9, GAD7, PHQ4, AUDITC, AUDIT, FAGERSTROM, WHO5, CGCAHPS, NPS
  items: QuestionnaireItem[];
  scoring: {
    type: "sum" | "weighted" | "nps" | "domain_avg";
    weights?: number[];
    nps_item_index?: number;    // 0–10 skálán
    domains?: { name: string; items: number[] }[];
  };
  cutoffs?: SeverityCutoff[];
  critical_item_index?: number; // pl. PHQ-9 #9 (1-alapú)
};

export type ScoringContext = {
  /** AUDIT-C nemi küszöb (férfi 4, nő 3). */
  sex?: "ferfi" | "no" | "egyeb" | null;
};

export type ScoringResult = {
  total_score: number | null;
  severity: string | null;
  nps_score: number | null;
  domain_scores?: Record<string, number>;
  /** Alskálák és származtatott pontszámok (DB: questionnaire_responses.subscale_scores jsonb). */
  subscale_scores: Record<string, number | string | boolean>;
  critical_triggered: boolean;
};

export type AnswerMap = Record<number, number>;

function pickSeverity(score: number, cutoffs?: SeverityCutoff[]): string | null {
  if (!cutoffs?.length) return null;
  for (const c of cutoffs) {
    if (score >= c.min && score <= c.max) return c.severity;
  }
  return null;
}

function sumItems(answers: AnswerMap, indices: number[]): number {
  let s = 0;
  for (const i of indices) {
    const v = answers[i];
    if (typeof v === "number") s += v;
  }
  return s;
}

/* ---------- Eszköz-specifikus alskála-szabályok ---------- */

export function phq2Bucket(score: number): "negativ" | "pozitiv" {
  // ≥3 → tovább kell vinni PHQ-9-re (Kroenke 2003)
  return score >= 3 ? "pozitiv" : "negativ";
}

export function gad2Bucket(score: number): "negativ" | "pozitiv" {
  // ≥3 → tovább GAD-7-re (Kroenke 2007)
  return score >= 3 ? "pozitiv" : "negativ";
}

export function who5Bucket(indexScore: number): "jollet_csokkent" | "normal" {
  // <50 → jóllét-csökkenés (depresszió-szűrés javasolt)
  return indexScore < 50 ? "jollet_csokkent" : "normal";
}

export function auditCBucket(score: number, sex?: ScoringContext["sex"]): "negativ" | "pozitiv" {
  const cutoff = sex === "no" ? 3 : 4;
  return score >= cutoff ? "pozitiv" : "negativ";
}

export function phq9SeverityFromScore(score: number): string {
  if (score <= 4) return "minimal";
  if (score <= 9) return "enyhe";
  if (score <= 14) return "kozepes";
  if (score <= 19) return "kozepesen_sulyos";
  return "sulyos";
}

/* ---------- Központi pontozó ---------- */

export function scoreResponse(
  def: QuestionnaireDefinition,
  answers: AnswerMap,
  ctx: ScoringContext = {},
): ScoringResult {
  const result: ScoringResult = {
    total_score: null,
    severity: null,
    nps_score: null,
    subscale_scores: {},
    critical_triggered: checkCritical(def, answers),
  };

  switch (def.scoring.type) {
    case "sum": {
      const s = sumItems(answers, def.items.map((i) => i.index));
      result.total_score = s;
      result.severity = pickSeverity(s, def.cutoffs);
      break;
    }
    case "weighted": {
      let s = 0;
      def.items.forEach((it, i) => {
        const v = answers[it.index];
        const w = def.scoring.weights?.[i] ?? 1;
        if (typeof v === "number") s += v * w;
      });
      result.total_score = s;
      result.severity = pickSeverity(s, def.cutoffs);
      break;
    }
    case "nps": {
      const idx = def.scoring.nps_item_index ?? 1;
      const v = answers[idx];
      if (typeof v === "number") result.nps_score = v;
      break;
    }
    case "domain_avg": {
      const domain_scores: Record<string, number> = {};
      for (const d of def.scoring.domains ?? []) {
        const vals: number[] = [];
        for (const idx of d.items) {
          const v = answers[idx];
          if (typeof v === "number") vals.push(v);
        }
        if (vals.length) {
          domain_scores[d.name] = vals.reduce((a, b) => a + b, 0) / vals.length;
        }
      }
      result.domain_scores = domain_scores;
      break;
    }
  }

  // Eszköz-specifikus alskálák / származtatott pontszámok
  switch (def.code) {
    case "PHQ9": {
      const phq2 = sumItems(answers, [1, 2]);
      result.subscale_scores.phq2 = phq2;
      result.subscale_scores.phq2_bucket = phq2Bucket(phq2);
      result.subscale_scores.item9 = answers[9] ?? 0;
      if (result.total_score !== null) {
        result.severity = phq9SeverityFromScore(result.total_score);
      }
      break;
    }
    case "GAD7": {
      const gad2 = sumItems(answers, [1, 2]);
      result.subscale_scores.gad2 = gad2;
      result.subscale_scores.gad2_bucket = gad2Bucket(gad2);
      break;
    }
    case "PHQ4": {
      const phq2 = sumItems(answers, [1, 2]);
      const gad2 = sumItems(answers, [3, 4]);
      result.subscale_scores.phq2 = phq2;
      result.subscale_scores.gad2 = gad2;
      result.subscale_scores.phq2_bucket = phq2Bucket(phq2);
      result.subscale_scores.gad2_bucket = gad2Bucket(gad2);
      break;
    }
    case "WHO5": {
      const raw = sumItems(answers, [1, 2, 3, 4, 5]);
      const indexScore = raw * 4; // 0–100
      result.total_score = indexScore;
      result.subscale_scores.raw = raw;
      result.subscale_scores.who5_index = indexScore;
      result.subscale_scores.bucket = who5Bucket(indexScore);
      result.severity = who5Bucket(indexScore);
      break;
    }
    case "AUDITC": {
      const s = result.total_score ?? sumItems(answers, [1, 2, 3]);
      result.subscale_scores.auditc = s;
      result.subscale_scores.sex_cutoff = ctx.sex === "no" ? 3 : 4;
      result.subscale_scores.bucket = auditCBucket(s, ctx.sex);
      if (!result.severity) result.severity = auditCBucket(s, ctx.sex);
      break;
    }
  }

  return result;
}

/**
 * Kritikus tétel detekció: pl. PHQ-9 9. tétel (öngyilkossági gondolatok) > 0.
 */
export function checkCritical(
  def: QuestionnaireDefinition,
  answers: AnswerMap,
): boolean {
  if (!def.critical_item_index) return false;
  const v = answers[def.critical_item_index];
  return typeof v === "number" && v > 0;
}

/**
 * NPS aggregáció egy 0–10 válasz-listából (Bain & Co. definíció).
 * Promoter: 9–10, Passzív: 7–8, Detraktor: 0–6.
 */
export function aggregateNps(scores: number[]): number {
  if (!scores.length) return 0;
  let prom = 0, det = 0;
  for (const s of scores) {
    if (s >= 9) prom++;
    else if (s <= 6) det++;
  }
  return Math.round(((prom - det) / scores.length) * 100);
}
