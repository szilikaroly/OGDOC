/**
 * Kérdőív kiosztás + válasz-feldolgozás — védett (klinikus).
 */
import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";
import { scoreResponse, type QuestionnaireDefinition, type AnswerMap } from "./scoring";

async function getTenantId(supabase: any, userId: string): Promise<string> {
  const { data, error } = await supabase
    .from("profiles").select("tenant_id").eq("id", userId).single();
  if (error) throw new Error(error.message);
  const t = data?.tenant_id;
  if (!t) throw new Error("Hiányzó tenant.");
  return t as string;
}

function randomToken(len = 32): string {
  const a = "abcdefghijklmnopqrstuvwxyz0123456789";
  const buf = new Uint8Array(len);
  crypto.getRandomValues(buf);
  let s = "";
  for (let i = 0; i < len; i++) s += a[buf[i] % a.length];
  return s;
}

const AssignInput = z.object({
  questionnaire_id: z.string().uuid(),
  patient_id: z.string().uuid().nullable(),
  appointment_id: z.string().uuid().nullable(),
  due_at: z.string().nullable().optional(),
});

export const assignQuestionnaire = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => AssignInput.parse(d))
  .handler(async ({ data, context }) => {
    const tenant_id = await getTenantId(context.supabase, context.userId);
    const { data: row, error } = await context.supabase
      .from("questionnaire_assignments")
      .insert({
        tenant_id,
        questionnaire_id: data.questionnaire_id,
        patient_id: data.patient_id,
        appointment_id: data.appointment_id,
        due_at: data.due_at ?? null,
        assigned_by: context.userId,
        status: "assigned",
        token: randomToken(),
      })
      .select()
      .single();
    if (error) throw new Error(error.message);
    return row;
  });

const SubmitInput = z.object({
  questionnaire_id: z.string().uuid(),
  assignment_id: z.string().uuid().nullable().optional(),
  patient_id: z.string().uuid().nullable(),
  appointment_id: z.string().uuid().nullable().optional(),
  answers: z.record(z.string(), z.number()),
  is_anonymous: z.boolean().default(false),
  consent_to_record: z.boolean().default(true),
});

export const submitQuestionnaireResponse = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => SubmitInput.parse(d))
  .handler(async ({ data, context }) => {
    const { data: q, error: qerr } = await context.supabase
      .from("questionnaires").select("*").eq("id", data.questionnaire_id).single();
    if (qerr || !q) throw new Error(qerr?.message ?? "Kérdőív nem található.");

    const answers: AnswerMap = {};
    for (const [k, v] of Object.entries(data.answers)) answers[Number(k)] = v;

    // AUDIT-C nemi küszöbhöz: páciens neme
    let sex: "ferfi" | "no" | "egyeb" | null = null;
    if (data.patient_id && !data.is_anonymous) {
      const { data: p } = await context.supabase
        .from("patients").select("nem").eq("id", data.patient_id).maybeSingle();
      const raw = (p?.nem ?? "").toString().toLowerCase();
      if (["no", "nő", "female", "f"].includes(raw)) sex = "no";
      else if (["ferfi", "férfi", "male", "m"].includes(raw)) sex = "ferfi";
      else if (raw) sex = "egyeb";
    }

    const score = scoreResponse(q as unknown as QuestionnaireDefinition, answers, { sex });
    const tenant_id = await getTenantId(context.supabase, context.userId);

    const { data: row, error } = await context.supabase
      .from("questionnaire_responses")
      .insert({
        tenant_id,
        questionnaire_id: data.questionnaire_id,
        assignment_id: data.assignment_id ?? null,
        patient_id: data.is_anonymous ? null : data.patient_id,
        appointment_id: data.appointment_id ?? null,
        answers: data.answers,
        total_score: score.total_score,
        severity: score.severity,
        subscale_scores: score.subscale_scores,
        critical_triggered: score.critical_triggered,
        is_anonymous: data.is_anonymous,
        consent_to_record: data.consent_to_record,
      })
      .select("id, total_score, severity, subscale_scores, critical_triggered")
      .single();
    if (error) throw new Error(error.message);

    // Ha az assignment is meg van adva, frissítjük az állapotát "kitöltött"-re
    if (data.assignment_id) {
      await context.supabase
        .from("questionnaire_assignments")
        .update({ status: "completed" })
        .eq("id", data.assignment_id);
    }

    // Visszajelentő rendszer — tünet-alapú automatikus kontroll-foglalás javaslat
    let recall: any = null;
    try {
      const rules = ((q as any)?.recall_rules?.rules ?? []) as Array<{
        if: { code: string; min: number };
        then: { recall: string; specialty?: string };
      }>;
      if (rules.length > 0 && !data.is_anonymous && data.patient_id && row?.id) {
        const items: Array<{ id: number; code?: string }> = ((q as any)?.items as any) ?? [];
        const codeById: Record<number, string> = {};
        items.forEach((it) => { if (it.code) codeById[it.id] = it.code; });
        const valueByCode: Record<string, number> = {};
        for (const [k, v] of Object.entries(data.answers)) {
          const c = codeById[Number(k)];
          if (c) valueByCode[c] = Number(v);
        }
        const order = ["urgent_24h", "soon_72h", "soon_7d", "soon_14d"];
        const hits = rules.filter((r) => (valueByCode[r.if.code] ?? 0) >= r.if.min)
          .sort((a, b) => order.indexOf(a.then.recall) - order.indexOf(b.then.recall));
        if (hits.length > 0) {
          const top = hits[0];
          const urgencyMap: Record<string, string> = {
            urgent_24h: "urgent", soon_72h: "soon", soon_7d: "soon", soon_14d: "routine",
          };
          const { data: pu } = await context.supabase
            .from("patient_users").select("user_id").eq("patient_id", data.patient_id).maybeSingle();
          const userId = (pu as any)?.user_id ?? context.userId;
          const { data: req } = await context.supabase
            .from("patient_appointment_requests")
            .insert({
              tenant_id, patient_id: data.patient_id, user_id: userId,
              request_type: "followup_auto_recall", status: "auto_suggested",
              urgency: urgencyMap[top.then.recall] ?? "routine",
              reason: `Visszajelentő rendszer riasztás: ${top.if.code} ≥ ${top.if.min}`,
            }).select("id").single();
          recall = { triggered: true, request_id: (req as any)?.id, recall: top.then.recall, specialty: top.then.specialty };
        }
      }
    } catch (e) {
      console.warn("recall eval failed", e);
    }

    return { response: row, critical_triggered: score.critical_triggered, recall };
  });

/* ---------- Kritikus riasztások ---------- */
export const listCriticalAlerts = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("critical_result_alerts")
      .select("id, alert_type, severity, status, created_at, response_id, patient_id, acknowledged_by, acknowledged_at, resolution_note")
      .order("created_at", { ascending: false })
      .limit(200);
    if (error) throw new Error(error.message);
    return data ?? [];
  });

const AckInput = z.object({
  alert_id: z.string().uuid(),
  note: z.string().max(500).optional(),
});

export const acknowledgeAlert = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => AckInput.parse(d))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("critical_result_alerts")
      .update({
        status: "acknowledged",
        acknowledged_by: context.userId,
        acknowledged_at: new Date().toISOString(),
        resolution_note: data.note ?? null,
      })
      .eq("id", data.alert_id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/* ---------- Kiosztás-állapotok (admin / klinikus) ---------- */

const ListAssignmentsInput = z.object({
  patient_id: z.string().uuid().optional(),
  status: z.enum(["assigned", "in_progress", "completed", "expired", "cancelled"]).optional(),
  only_open: z.boolean().optional(),
});

export const listQuestionnaireAssignments = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => ListAssignmentsInput.parse(d))
  .handler(async ({ data, context }) => {
    let q = context.supabase
      .from("questionnaire_assignments")
      .select("id, questionnaire_id, patient_id, kind, status, due_at, assigned_at, reminded_at, reminder_count, token, questionnaires(code, title, becsult_perc, kioszk_eligible)")
      .order("due_at", { ascending: true, nullsFirst: false })
      .limit(500);
    if (data.patient_id) q = q.eq("patient_id", data.patient_id);
    if (data.status) q = q.eq("status", data.status);
    if (data.only_open) q = q.in("status", ["assigned", "in_progress"]);
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);

    const now = Date.now();
    return (rows ?? []).map((r: any) => {
      const due = r.due_at ? new Date(r.due_at).getTime() : null;
      let derived: "tervezett" | "esedekes" | "kitoltott" | "elmaradt" | "lemondva" = "tervezett";
      if (r.status === "completed") derived = "kitoltott";
      else if (r.status === "expired") derived = "elmaradt";
      else if (r.status === "cancelled") derived = "lemondva";
      else if (due !== null && due <= now) derived = "esedekes";
      return { ...r, derived_status: derived };
    });
  });

/* ---------- Kioszk váró ---------- */

export const listWaitingPatients = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const today = new Date();
    const startOfDay = new Date(today.getFullYear(), today.getMonth(), today.getDate()).toISOString();
    const { data, error } = await context.supabase
      .from("patient_checkin")
      .select("id, patient_id, appointment_id, status, queue_position, checkin_ts, called_ts, patients(id, vezeteknev, keresztnev, szuletesi_datum, nem), appointments(id, scheduled_start, scheduled_end)")
      .gte("checkin_ts", startOfDay)
      .in("status", ["arrived", "in_room"])
      .order("queue_position", { ascending: true, nullsFirst: false })
      .order("checkin_ts", { ascending: true })
      .limit(200);
    if (error) throw new Error(error.message);
    return data ?? [];
  });

/* ---------- Recepciós: kioszk-eligible, aktív hozzárendelések QR-nyomtatáshoz ---------- */
export const listKioskEligibleAssignments = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("questionnaire_assignments")
      .select(
        "id, token, status, due_at, assigned_at, patient_id, questionnaire_id, " +
          "print_status, printed_at, printed_by, print_cancelled_at, print_cancelled_by, " +
          "patients(id, vezeteknev, keresztnev, szuletesi_datum, taj), " +
          "questionnaires!inner(code, title, becsult_perc, kioszk_eligible)"
      )
      .in("status", ["assigned", "in_progress"])
      .eq("questionnaires.kioszk_eligible", true)
      .order("due_at", { ascending: true, nullsFirst: false })
      .limit(500);
    if (error) throw new Error(error.message);
    return data ?? [];
  });

const SetPrintStatusInput = z.object({
  assignment_id: z.string().uuid(),
  print_status: z.enum(["not_printed", "printed", "cancelled"]),
});

export const setKioskPrintStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => SetPrintStatusInput.parse(d))
  .handler(async ({ data, context }) => {
    const now = new Date().toISOString();
    let patch:
      | { print_status: "printed"; printed_at: string; printed_by: string; print_cancelled_at: null; print_cancelled_by: null }
      | { print_status: "cancelled"; print_cancelled_at: string; print_cancelled_by: string }
      | { print_status: "not_printed"; printed_at: null; printed_by: null; print_cancelled_at: null; print_cancelled_by: null };
    if (data.print_status === "printed") {
      patch = { print_status: "printed", printed_at: now, printed_by: context.userId, print_cancelled_at: null, print_cancelled_by: null };
    } else if (data.print_status === "cancelled") {
      patch = { print_status: "cancelled", print_cancelled_at: now, print_cancelled_by: context.userId };
    } else {
      patch = { print_status: "not_printed", printed_at: null, printed_by: null, print_cancelled_at: null, print_cancelled_by: null };
    }
    const { data: row, error } = await context.supabase
      .from("questionnaire_assignments")
      .update(patch)
      .eq("id", data.assignment_id)
      .select("id, print_status, printed_at, print_cancelled_at")
      .single();
    if (error) throw new Error(error.message);
    return row;
  });


const QuestionnaireIdInput = z.object({ questionnaire_id: z.string().uuid() });

export const getQuestionnaireForFill = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => QuestionnaireIdInput.parse(d))
  .handler(async ({ data, context }) => {
    const { data: q, error } = await context.supabase
      .from("questionnaires")
      .select("id, code, title, leiras, language, items, becsult_perc, kioszk_eligible")
      .eq("id", data.questionnaire_id)
      .single();
    if (error || !q) throw new Error(error?.message ?? "Kérdőív nem található.");
    return q;
  });


/* ---------- Manuális trigger admin felületre ---------- */
export const runQuestionnaireMaintenance = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    // Csak admin (manage_tenant) futtathatja
    const { data: isAdmin } = await context.supabase
      .rpc("has_permission", { _user_id: context.userId, _perm: "manage_tenant" });
    if (!isAdmin) throw new Error("Nincs jogosultsága a karbantartás futtatásához.");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const [scheduled, expired, reminded] = await Promise.all([
      supabaseAdmin.rpc("process_questionnaire_schedules"),
      supabaseAdmin.rpc("expire_overdue_questionnaire_assignments"),
      supabaseAdmin.rpc("send_questionnaire_reminders"),
    ]);
    if (scheduled.error) throw new Error(scheduled.error.message);
    if (expired.error) throw new Error(expired.error.message);
    if (reminded.error) throw new Error(reminded.error.message);
    return {
      schedules: scheduled.data ?? [],
      expired_count: expired.data ?? 0,
      reminder_count: reminded.data ?? 0,
    };
  });

/* ---------- Klinikus áttekintő nézet (C fázis) ---------- */

const OverviewInput = z.object({
  from: z.string().optional(),           // ISO date (kitöltés / due dátum kezdő)
  to: z.string().optional(),             // ISO date vége (inkluzív, nap végéig)
  questionnaire_id: z.string().uuid().optional(),
  severity: z.enum(["minimal", "mild", "moderate", "severe", "critical"]).optional(),
  min_total: z.number().optional(),
  max_total: z.number().optional(),
  subscale_key: z.string().max(64).optional(),
  subscale_min: z.number().optional(),
  alert_status: z.enum(["open", "acknowledged", "resolved", "all"]).optional(),
});

/** Riasztások + a hozzájuk tartozó válasz scoringja és páciens-azonosítók. */
export const listAlertOverview = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => OverviewInput.parse(d))
  .handler(async ({ data, context }) => {
    let q = context.supabase
      .from("critical_result_alerts")
      .select(
        "id, alert_type, severity, status, created_at, response_id, patient_id, " +
          "acknowledged_at, resolution_note, " +
          "questionnaire_responses!inner(id, questionnaire_id, total_score, severity, subscale_scores, completed_at, " +
            "questionnaires(code, title)), " +
          "patients(vezeteknev, keresztnev, taj)"
      )
      .order("created_at", { ascending: false })
      .limit(500);

    if (data.alert_status && data.alert_status !== "all") q = q.eq("status", data.alert_status);
    if (data.from) q = q.gte("created_at", data.from);
    if (data.to) {
      const end = new Date(data.to);
      end.setHours(23, 59, 59, 999);
      q = q.lte("created_at", end.toISOString());
    }
    if (data.questionnaire_id) q = q.eq("questionnaire_responses.questionnaire_id", data.questionnaire_id);
    if (data.severity) q = q.eq("questionnaire_responses.severity", data.severity);
    if (data.min_total != null) q = q.gte("questionnaire_responses.total_score", data.min_total);
    if (data.max_total != null) q = q.lte("questionnaire_responses.total_score", data.max_total);

    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);

    // Subscale szűrés kliens oldalon (jsonb), kis lista miatt elég gyors
    const filtered = (rows ?? []).filter((r: any) => {
      if (!data.subscale_key) return true;
      const sub = r.questionnaire_responses?.subscale_scores?.[data.subscale_key];
      if (sub == null) return false;
      if (data.subscale_min != null && Number(sub) < data.subscale_min) return false;
      return true;
    });
    return filtered;
  });

/** Elmaradt (expired) és lejárt-de-nyitva (overdue) assignmentek listája. */
const OverdueInput = z.object({
  from: z.string().optional(),
  to: z.string().optional(),
  questionnaire_id: z.string().uuid().optional(),
  scope: z.enum(["expired", "overdue_open", "all"]).default("all"),
});

export const listOverdueAssignments = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => OverdueInput.parse(d))
  .handler(async ({ data, context }) => {
    let q = context.supabase
      .from("questionnaire_assignments")
      .select(
        "id, status, due_at, assigned_at, reminder_count, patient_id, questionnaire_id, " +
          "patients(vezeteknev, keresztnev, taj), " +
          "questionnaires(code, title, becsult_perc)"
      )
      .order("due_at", { ascending: true, nullsFirst: false })
      .limit(500);

    const nowIso = new Date().toISOString();
    if (data.scope === "expired") q = q.eq("status", "expired");
    else if (data.scope === "overdue_open") q = q.in("status", ["assigned", "in_progress"]).lt("due_at", nowIso);
    else q = q.or(`status.eq.expired,and(status.in.(assigned,in_progress),due_at.lt.${nowIso})`);

    if (data.questionnaire_id) q = q.eq("questionnaire_id", data.questionnaire_id);
    if (data.from) q = q.gte("due_at", data.from);
    if (data.to) {
      const end = new Date(data.to);
      end.setHours(23, 59, 59, 999);
      q = q.lte("due_at", end.toISOString());
    }
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

/** Egy konkrét válasz részletei a drill-downhoz. */
const ResponseDetailInput = z.object({ response_id: z.string().uuid() });

export const getResponseDetail = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => ResponseDetailInput.parse(d))
  .handler(async ({ data, context }) => {
    const { data: row, error } = await context.supabase
      .from("questionnaire_responses")
      .select(
        "id, completed_at, total_score, severity, subscale_scores, answers, critical_triggered, " +
          "questionnaires(code, title, items), " +
          "patients(vezeteknev, keresztnev, taj, szuletesi_datum)"
      )
      .eq("id", data.response_id)
      .single();
    if (error || !row) throw new Error(error?.message ?? "Válasz nem található.");
    return row;
  });


/* ---------- D fázis: event trigger CRUD ---------- */

const EventType = z.enum([
  "appointment_created",
  "appointment_scheduled",
  "surgery_created",
  "surgery_scheduled",
]);

export const listEventTriggers = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("questionnaire_event_triggers")
      .select("id, questionnaire_id, event_type, due_offset_days, reminder_buckets, channel, active, created_at, questionnaires(code, title)")
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

const UpsertTriggerInput = z.object({
  id: z.string().uuid().optional(),
  questionnaire_id: z.string().uuid(),
  event_type: EventType,
  due_offset_days: z.number().int().min(-365).max(365),
  reminder_buckets: z.array(z.number().int().min(-90).max(90)).min(1).max(20),
  channel: z.enum(["notification", "push", "email", "sms"]).default("notification"),
  active: z.boolean().default(true),
});

export const upsertEventTrigger = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => UpsertTriggerInput.parse(d))
  .handler(async ({ data, context }) => {
    const tenant_id = await getTenantId(context.supabase, context.userId);
    const row = {
      tenant_id,
      questionnaire_id: data.questionnaire_id,
      event_type: data.event_type,
      due_offset_days: data.due_offset_days,
      reminder_buckets: data.reminder_buckets,
      channel: data.channel,
      active: data.active,
    };
    if (data.id) {
      const { error } = await context.supabase
        .from("questionnaire_event_triggers").update(row).eq("id", data.id);
      if (error) throw new Error(error.message);
      return { id: data.id };
    }
    const { data: ins, error } = await context.supabase
      .from("questionnaire_event_triggers")
      .insert({ ...row, created_by: context.userId })
      .select("id").single();
    if (error) throw new Error(error.message);
    return { id: ins.id };
  });

export const deleteEventTrigger = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("questionnaire_event_triggers").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
