/**
 * Kioszk-kitöltés szerver-fn-ek — PUBLIKUS, nincs requireSupabaseAuth.
 * Auth: assignment.token + opcionális 4-jegyű PIN (páciens születésnap DDMM).
 * Minden DB hozzáférés SECURITY DEFINER RPC-n keresztül (kiosk_load / autosave / submit_response).
 */
import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";
import { scoreResponse, type QuestionnaireDefinition, type AnswerMap } from "./scoring";

function serverClient() {
  return createClient(
    process.env.SUPABASE_URL!,
    process.env.SUPABASE_PUBLISHABLE_KEY!,
    { auth: { storage: undefined, persistSession: false, autoRefreshToken: false } },
  );
}

const TokenPin = z.object({
  token: z.string().min(8).max(64),
  pin: z.string().max(8).optional().nullable(),
});

export const kioskLoad = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => TokenPin.parse(d))
  .handler(async ({ data }) => {
    const sb = serverClient();
    const { data: res, error } = await sb.rpc("kiosk_load", {
      _token: data.token,
      _pin: data.pin ?? "",
    });
    if (error) throw new Error(error.message);
    return res as {
      ok: boolean;
      reason?: string;
      status?: string;
      assignment?: {
        id: string; status: string; due_at: string | null;
        draft_answers: Record<string, number> | null;
        draft_saved_at: string | null;
        requires_pin: boolean;
      };
      questionnaire?: {
        id: string; code: string; title: string; leiras: string | null;
        language: string | null;
        items: { index: number; text: string; type: string; options?: { value: number; label: string }[] }[];
        becsult_perc: number | null;
      };
      patient_name?: string | null;
    };
  });

const AutosaveInput = TokenPin.extend({
  answers: z.record(z.string(), z.number()),
});

export const kioskAutosave = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => AutosaveInput.parse(d))
  .handler(async ({ data }) => {
    const sb = serverClient();
    const { data: res, error } = await sb.rpc("kiosk_autosave", {
      _token: data.token,
      _pin: data.pin ?? "",
      _answers: data.answers,
    });
    if (error) throw new Error(error.message);
    return res as { ok: boolean; reason?: string; saved_at?: string };
  });

const SubmitInput = TokenPin.extend({
  answers: z.record(z.string(), z.number()),
});

export const kioskSubmit = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => SubmitInput.parse(d))
  .handler(async ({ data }) => {
    const sb = serverClient();

    // 1) Betöltés — visszaadja a kérdőív definícióját + ellenőrzi a token+PIN-t
    const { data: loaded, error: lerr } = await sb.rpc("kiosk_load", {
      _token: data.token,
      _pin: data.pin ?? "",
    });
    if (lerr) throw new Error(lerr.message);
    const payload = loaded as { ok: boolean; reason?: string; questionnaire?: QuestionnaireDefinition };
    if (!payload?.ok || !payload.questionnaire) {
      throw new Error(payload?.reason === "invalid_token_or_pin" ? "Érvénytelen kód vagy PIN." : "Beküldés nem lehetséges.");
    }

    // 2) Scoring TS-ben
    const answers: AnswerMap = {};
    for (const [k, v] of Object.entries(data.answers)) answers[Number(k)] = v;
    const score = scoreResponse(payload.questionnaire, answers, { sex: null });

    // 3) Beillesztés a SECURITY DEFINER RPC-n keresztül — a trigger automatikusan generálja a riasztásokat
    const { data: res, error } = await sb.rpc("kiosk_submit_response", {
      _token: data.token,
      _pin: data.pin ?? "",
      _answers: data.answers,
      _total_score: score.total_score,
      _severity: score.severity,
      _subscale_scores: score.subscale_scores,
      _critical_triggered: score.critical_triggered,
    });
    if (error) throw new Error(error.message);
    const r = res as { ok: boolean; reason?: string; response_id?: string; critical_triggered?: boolean };
    if (!r.ok) throw new Error(r.reason ?? "Beküldés sikertelen.");
    return {
      ok: true as const,
      response_id: r.response_id!,
      critical_triggered: r.critical_triggered ?? false,
    };
  });
