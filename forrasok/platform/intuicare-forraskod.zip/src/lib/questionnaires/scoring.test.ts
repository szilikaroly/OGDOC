import { describe, it, expect } from "vitest";
import {
  scoreResponse,
  checkCritical,
  aggregateNps,
  phq2Bucket,
  gad2Bucket,
  who5Bucket,
  auditCBucket,
  phq9SeverityFromScore,
  type QuestionnaireDefinition,
} from "./scoring";

const mkItems = (n: number) =>
  Array.from({ length: n }, (_, i) => ({ index: i + 1, text: `q-${i + 1}`, type: "likert" as const }));

const phq9: QuestionnaireDefinition = {
  code: "PHQ9",
  items: mkItems(9),
  scoring: { type: "sum" },
  critical_item_index: 9,
};

const gad7: QuestionnaireDefinition = {
  code: "GAD7",
  items: mkItems(7),
  scoring: { type: "sum" },
  cutoffs: [
    { min: 0, max: 4, severity: "minimal" },
    { min: 5, max: 9, severity: "enyhe" },
    { min: 10, max: 14, severity: "kozepes" },
    { min: 15, max: 21, severity: "sulyos" },
  ],
};

const phq4: QuestionnaireDefinition = { code: "PHQ4", items: mkItems(4), scoring: { type: "sum" } };
const who5: QuestionnaireDefinition = { code: "WHO5", items: mkItems(5), scoring: { type: "sum" } };
const auditc: QuestionnaireDefinition = { code: "AUDITC", items: mkItems(3), scoring: { type: "sum" } };

describe("PHQ-9", () => {
  it("severity-bucketezés a Kroenke-féle vágópontokkal", () => {
    expect(phq9SeverityFromScore(0)).toBe("minimal");
    expect(phq9SeverityFromScore(7)).toBe("enyhe");
    expect(phq9SeverityFromScore(12)).toBe("kozepes");
    expect(phq9SeverityFromScore(17)).toBe("kozepesen_sulyos");
    expect(phq9SeverityFromScore(22)).toBe("sulyos");
  });
  it("PHQ-2 alskála + kritikus #9", () => {
    const r = scoreResponse(phq9, { 1: 2, 2: 2, 3: 1, 4: 1, 5: 1, 6: 1, 7: 1, 8: 1, 9: 1 });
    expect(r.total_score).toBe(11);
    expect(r.severity).toBe("kozepes");
    expect(r.subscale_scores.phq2).toBe(4);
    expect(r.subscale_scores.phq2_bucket).toBe("pozitiv");
    expect(r.subscale_scores.item9).toBe(1);
    expect(r.critical_triggered).toBe(true);
  });
  it("#9 = 0 → nincs kritikus", () => {
    expect(checkCritical(phq9, { 9: 0 })).toBe(false);
  });
});

describe("GAD-7 + GAD-2 alskála", () => {
  it("összegez és bucketez", () => {
    const r = scoreResponse(gad7, { 1: 2, 2: 1, 3: 1, 4: 1, 5: 1, 6: 1, 7: 1 });
    expect(r.total_score).toBe(8);
    expect(r.severity).toBe("enyhe");
    expect(r.subscale_scores.gad2).toBe(3);
    expect(r.subscale_scores.gad2_bucket).toBe("pozitiv");
  });
  it("GAD-2 cutoff = 3", () => {
    expect(gad2Bucket(2)).toBe("negativ");
    expect(gad2Bucket(3)).toBe("pozitiv");
    expect(phq2Bucket(3)).toBe("pozitiv");
  });
});

describe("PHQ-4 (kombinált PHQ-2 + GAD-2)", () => {
  it("mindkét alskálát számolja", () => {
    const r = scoreResponse(phq4, { 1: 2, 2: 2, 3: 1, 4: 1 });
    expect(r.subscale_scores.phq2).toBe(4);
    expect(r.subscale_scores.gad2).toBe(2);
    expect(r.subscale_scores.phq2_bucket).toBe("pozitiv");
    expect(r.subscale_scores.gad2_bucket).toBe("negativ");
  });
});

describe("WHO-5", () => {
  it("raw × 4 = index, <50 → jóllét-csökkenés", () => {
    const r = scoreResponse(who5, { 1: 2, 2: 2, 3: 2, 4: 2, 5: 2 }); // raw=10, idx=40
    expect(r.subscale_scores.raw).toBe(10);
    expect(r.subscale_scores.who5_index).toBe(40);
    expect(r.total_score).toBe(40);
    expect(r.severity).toBe("jollet_csokkent");
    expect(who5Bucket(50)).toBe("normal");
  });
});

describe("AUDIT-C nemi küszöb", () => {
  it("férfi cutoff = 4", () => {
    const r = scoreResponse(auditc, { 1: 2, 2: 1, 3: 1 }, { sex: "ferfi" }); // 4
    expect(r.subscale_scores.bucket).toBe("pozitiv");
    expect(r.subscale_scores.sex_cutoff).toBe(4);
  });
  it("nő cutoff = 3", () => {
    const r = scoreResponse(auditc, { 1: 1, 2: 1, 3: 1 }, { sex: "no" }); // 3
    expect(r.subscale_scores.bucket).toBe("pozitiv");
    expect(r.subscale_scores.sex_cutoff).toBe(3);
  });
  it("határ alatt → negativ", () => {
    expect(auditCBucket(2, "no")).toBe("negativ");
    expect(auditCBucket(3, "ferfi")).toBe("negativ");
  });
});

describe("NPS aggregáció", () => {
  it("Bain definíció szerint", () => {
    expect(aggregateNps([10, 9, 9, 8, 7, 6, 5, 0])).toBe(0);
    expect(aggregateNps([10, 10, 10])).toBe(100);
    expect(aggregateNps([0, 0, 0])).toBe(-100);
    expect(aggregateNps([])).toBe(0);
  });
});
