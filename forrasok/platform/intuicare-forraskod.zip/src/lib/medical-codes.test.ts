import { describe, it, expect } from "vitest";
import { BNO_SEED, OENO_SEED, searchCodes } from "./medical-codes";

describe("medical-codes searchCodes", () => {
  it("returns top results matching by kod prefix", () => {
    const r = searchCodes(BNO_SEED, "I10");
    expect(r.length).toBeGreaterThan(0);
    expect(r[0].kod).toBe("I10");
  });

  it("matches case-insensitively by name fragment", () => {
    const r = searchCodes(BNO_SEED, "appendicitis");
    expect(r.find((c) => c.kod === "K35.8")).toBeDefined();
  });

  it("returns slice of seed when query is empty", () => {
    const r = searchCodes(OENO_SEED, "");
    expect(r.length).toBeLessThanOrEqual(12);
    expect(r[0]).toEqual(OENO_SEED[0]);
  });

  it("respects limit argument", () => {
    const r = searchCodes(BNO_SEED, "i", 3);
    expect(r.length).toBeLessThanOrEqual(3);
  });

  it("returns empty array for no-match query", () => {
    const r = searchCodes(BNO_SEED, "zzz-nem-letezo-kod-xyz");
    expect(r).toHaveLength(0);
  });
});
