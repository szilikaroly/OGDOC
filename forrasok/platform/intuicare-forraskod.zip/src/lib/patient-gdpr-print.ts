import { exportPatientGdpr } from "@/lib/patient-gdpr-export";

function esc(s: unknown): string {
  return String(s ?? "").replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[c] as string));
}

async function sha256Hex(s: string): Promise<string> {
  const buf = new TextEncoder().encode(s);
  const hash = await crypto.subtle.digest("SHA-256", buf);
  return Array.from(new Uint8Array(hash)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

export async function openPatientGdprPrint(patientId: string) {
  const { payload } = await exportPatientGdpr(patientId);
  const p = (payload as any).patient ?? {};
  const enc = ((payload as any).encounters ?? []) as Array<Record<string, any>>;
  const ee = ((payload as any).eeszt_links ?? []) as Array<Record<string, any>>;
  const hash = await sha256Hex(JSON.stringify(payload));

  const fmt = (v: any) => (v ? new Date(v).toLocaleString("hu-HU") : "—");
  const encRows = enc.map((e) => `
    <tr>
      <td>${esc(fmt(e.ellatas_kezdete))}</td>
      <td>${esc(e.tipus ?? "—")}</td>
      <td>${esc((e.bno_kodok ?? []).join(", "))}</td>
      <td>${esc((e.oeno_kodok ?? []).join(", "))}</td>
      <td>${esc(e.status)}</td>
      <td>${esc(e.szerzo_alairas_at ? "aláírt" : "–")} / ${esc(e.ellenjegyzo_alairas_at ? "ellenjegyzett" : "–")}</td>
    </tr>`).join("");

  const eeRows = ee.map((l) => `
    <tr>
      <td>${esc(l.page_id ?? "—")}</td>
      <td>${esc(l.oid ?? "—")}</td>
      <td>${esc(l.hozzajarulas_status ?? "—")}</td>
      <td>${esc(fmt(l.utolso_sync_at))}</td>
    </tr>`).join("");

  const html = `<!doctype html><html lang="hu"><head><meta charset="utf-8" />
<title>GDPR adatkivonat · ${esc(p.vezeteknev)} ${esc(p.keresztnev)}</title>
<style>
  body { font-family: -apple-system, system-ui, sans-serif; color: #111; max-width: 880px; margin: 24px auto; padding: 0 24px; }
  header { border-bottom: 2px solid #111; padding-bottom: 8px; margin-bottom: 16px; }
  h1 { font-size: 18px; margin: 0; }
  h2 { font-size: 13px; margin: 16px 0 6px; text-transform: uppercase; letter-spacing: 0.06em; color: #333; }
  .meta { font-size: 11px; color: #555; }
  .hash { font-family: ui-monospace, Menlo, monospace; font-size: 10px; word-break: break-all; color: #444; }
  .basis { background: #fff8e1; border: 1px solid #f1d27d; padding: 8px 10px; border-radius: 4px; font-size: 11px; margin: 12px 0; }
  table { width: 100%; border-collapse: collapse; font-size: 11px; margin: 6px 0; }
  th, td { border: 1px solid #e2e2e2; padding: 4px 6px; text-align: left; vertical-align: top; }
  th { background: #f6f6f6; font-weight: 600; }
  .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 4px 16px; font-size: 12px; }
  .grid dt { color: #666; }
  footer { margin-top: 24px; font-size: 10px; color: #777; border-top: 1px solid #ddd; padding-top: 8px; }
  @media print { body { margin: 0; } }
</style></head><body>
<header>
  <h1>GDPR adatkivonat · ${esc(p.vezeteknev)} ${esc(p.keresztnev)}</h1>
  <div class="meta">Készült: ${esc(new Date().toLocaleString("hu-HU"))} · Séma: ${esc((payload as any).schema)}</div>
  <div class="hash">Integritás-hash (SHA-256 a teljes JSON-payload felett): ${hash}</div>
</header>

<div class="basis"><strong>Jogalap:</strong> ${esc((payload as any).legal_basis)}</div>

<h2>Páciens-törzs</h2>
<dl class="grid">
  <dt>TAJ</dt><dd>${esc(p.taj ?? "—")}</dd>
  <dt>Születési dátum</dt><dd>${esc(p.szuletesi_datum ?? "—")}</dd>
  <dt>Nem</dt><dd>${esc(p.nem ?? "—")}</dd>
  <dt>Fő diagnózis (BNO)</dt><dd>${esc(p.fo_diagnozis_bno ?? "—")}</dd>
</dl>

<h2>Ellátási epizódok (${enc.length})</h2>
${enc.length === 0 ? '<div class="meta">Nincs rögzített epizód.</div>' : `
<table>
  <thead><tr><th>Kezdés</th><th>Típus</th><th>BNO</th><th>OENO</th><th>Státusz</th><th>Aláírások</th></tr></thead>
  <tbody>${encRows}</tbody>
</table>`}

<h2>EESZT-kapcsolatok (${ee.length})</h2>
${ee.length === 0 ? '<div class="meta">Nincs EESZT-kapcsolat.</div>' : `
<table>
  <thead><tr><th>PAGE-ID</th><th>OID</th><th>Hozzájárulás</th><th>Utolsó szinkron</th></tr></thead>
  <tbody>${eeRows}</tbody>
</table>`}

<footer>
  Az integritás-hash a fenti JSON-payloadon (séma + adat) számolt SHA-256 érték.
  A nyomtatott példány hitelességét ezzel ellenőrizhető a kiállító rendszerben.
</footer>
</body></html>`;

  const w = window.open("", "_blank");
  if (!w) throw new Error("Felugró ablak letiltva");
  w.document.write(html);
  w.document.close();
  setTimeout(() => { try { w.print(); } catch { /* noop */ } }, 250);
}
