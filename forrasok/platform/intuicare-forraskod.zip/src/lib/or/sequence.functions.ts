import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";
import { generateText, Output } from "ai";
import { createLovableAiGatewayProvider } from "@/lib/ai-gateway.server";

// ----- Manual reorder via DnD -----
const ReorderInput = z.object({
  blockId: z.string().uuid(),
  orderedCaseIds: z.array(z.string().uuid()).min(1).max(50),
});

export const reorderBlockCases = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => ReorderInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { error } = await supabase.rpc("reorder_block_cases", {
      _block_id: data.blockId,
      _ordered_case_ids: data.orderedCaseIds,
    });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// ----- AI ordering -----
const AiInput = z.object({
  blockId: z.string().uuid(),
  weights: z
    .object({
      priority: z.boolean().default(true),
      shortFirst: z.boolean().default(true),
      sterility: z.boolean().default(true),
      groupSimilar: z.boolean().default(true),
      surgeonLoad: z.boolean().default(true),
    })
    .default({
      priority: true,
      shortFirst: true,
      sterility: true,
      groupSimilar: true,
      surgeonLoad: true,
    }),
});

const OrderSchema = z.object({
  orderedCaseIds: z.array(z.string()),
  rationale: z.string(),
});

export type AiOrderResult = z.infer<typeof OrderSchema>;

function priorityRank(priority?: string | null) {
  if (priority === "azonnali") return 0;
  if (priority === "sürgos" || priority === "sürgős") return 1;
  return 2;
}

function fallbackOrderCases(
  items: {
    id: string;
    durationMin: number;
    priority: string;
    sterility?: string;
    typeCode?: string | null;
  }[],
) {
  return [...items]
    .sort((a, b) => {
      const prio = priorityRank(a.priority) - priorityRank(b.priority);
      if (prio !== 0) return prio;
      const sterility =
        (a.sterility === "szennyezett" ? 1 : 0) - (b.sterility === "szennyezett" ? 1 : 0);
      if (sterility !== 0) return sterility;
      const type = (a.typeCode ?? "").localeCompare(b.typeCode ?? "", "hu");
      if (type !== 0) return type;
      return a.durationMin - b.durationMin;
    })
    .map((item) => item.id);
}

export const aiOrderBlockCases = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => AiInput.parse(d))
  .handler(async ({ data, context }): Promise<AiOrderResult> => {
    const { supabase } = context;

    const { data: block } = await supabase
      .from("or_blocks")
      .select("id, datum, kezdo_ido, veg_ido, sebesz_user_id, specialty_id, org_unit_id")
      .eq("id", data.blockId)
      .maybeSingle();
    if (!block) throw new Error("Blokk nem található");

    const { data: cases } = await supabase
      .from("surgery_cases")
      .select(
        "id, becsult_idotartam_perc, posztop_apolasi_perc, prioritas, statusz, surgery_type_id, sort_order",
      )
      .eq("or_block_id", data.blockId)
      .not("statusz", "in", "(torolt,elvegzett)");

    if (!cases || cases.length === 0) {
      return { orderedCaseIds: [], rationale: "Üres blokk, nincs mit rendezni." };
    }
    if (cases.length === 1) {
      return { orderedCaseIds: [cases[0].id], rationale: "Egyetlen eset a blokkban." };
    }

    const typeIds = Array.from(
      new Set(cases.map((c) => c.surgery_type_id).filter(Boolean)),
    ) as string[];
    const { data: types } = typeIds.length
      ? await supabase
          .from("surgery_types")
          .select("id, nev, kod, kotelezo_muto_tipus")
          .in("id", typeIds)
      : {
          data: [] as {
            id: string;
            nev: string;
            kod: string | null;
            kotelezo_muto_tipus: string | null;
          }[],
        };

    const typeMap = new Map((types ?? []).map((t) => [t.id, t]));

    const items = cases.map((c) => {
      const t = c.surgery_type_id ? typeMap.get(c.surgery_type_id) : null;
      const nameLc = (t?.nev ?? "").toLowerCase();
      const sterility =
        nameLc.includes("szennyez") || nameLc.includes("septik") || nameLc.includes("fertoz")
          ? "szennyezett"
          : "tiszta";
      return {
        id: c.id,
        durationMin: c.becsult_idotartam_perc ?? 60,
        priority: c.prioritas ?? "elektiv",
        typeName: t?.nev ?? "ismeretlen",
        typeCode: t?.kod ?? null,
        sterility,
      };
    });

    const key = process.env.LOVABLE_API_KEY;
    if (!key) throw new Error("AI gateway nincs konfigurálva.");
    const gateway = createLovableAiGatewayProvider(key);

    const weightSummary = [
      data.weights.priority && "1) Prioritás (azonnali → sürgős → elektív)",
      data.weights.shortFirst && "2) Rövidebb esetek előre (gyors kapacitásfelszabadítás)",
      data.weights.sterility && "3) Sterilitás: tiszta esetek előre, szennyezett a nap végére",
      data.weights.groupSimilar && "4) Hasonló műtét-típusok egymás után (kevesebb átállás)",
      data.weights.surgeonLoad && "5) Operatőr terhelhetőség / képzettség (pl. daganatsebészet)",
    ]
      .filter(Boolean)
      .join("\n");

    let output: AiOrderResult;
    try {
      const result = await generateText({
        model: gateway("google/gemini-3-flash-preview"),
        output: Output.object({ schema: OrderSchema }),
        system:
          "Te egy műtéti blokk-koordinátor vagy. Rendezd a megadott eseteket optimális sorrendbe a megadott szempontok szerint. Minden eset-ID-t pontosan egyszer használj fel a sorrendben.",
        prompt: `BLOKK: ${block.kezdo_ido}–${block.veg_ido} (${block.datum})

SZEMPONTOK SÚLYOZÁSA (sorrendben):
${weightSummary || "Alapértelmezett: prioritás → időtartam → sterilitás"}

ESETEK:
${JSON.stringify(items, null, 2)}

Add vissza a "orderedCaseIds" tömböt (az összes ID, optimális műtéti sorrendben), és egy rövid magyar nyelvű "rationale" szöveget (max 2 mondat).`,
      });
      output = result.output;
    } catch (error) {
      console.warn("AI order schema mismatch, using deterministic fallback", error);
      output = {
        orderedCaseIds: fallbackOrderCases(items),
        rationale:
          "Az AI válasza nem volt feldolgozható, ezért szabályalapú sorrend készült prioritás, sterilitás, típus és időtartam alapján.",
      };
    }

    // Safety: ensure no missing/duplicate ids
    const validIds = new Set(items.map((i) => i.id));
    const seen = new Set<string>();
    const ordered: string[] = [];
    for (const id of output.orderedCaseIds) {
      if (validIds.has(id) && !seen.has(id)) {
        seen.add(id);
        ordered.push(id);
      }
    }
    for (const id of validIds) {
      if (!seen.has(id)) ordered.push(id);
    }

    return { orderedCaseIds: ordered, rationale: output.rationale };
  });

// ----- AI auto-schedule: assign waitlist cases to blocks for a date -----
const AutoInput = z.object({ date: z.string() });

const AutoSchema = z.object({
  assignments: z.array(
    z.object({
      caseId: z.string(),
      blockId: z.string(),
      indok: z.string(),
    }),
  ),
  unplaced: z.array(z.object({ caseId: z.string(), indok: z.string() })),
  rationale: z.string(),
});

export type AutoScheduleResult = z.infer<typeof AutoSchema> & {
  applied: number;
  skipped: { caseId: string; reason: string }[];
};

function fallbackAutoSchedule(
  blockSummaries: {
    id: string;
    roomType: string | null;
    freeMin: number;
    turnover: number;
  }[],
  waitlistItems: {
    id: string;
    durationMin: number;
    priority: string;
    requiredRoomType: string | null;
  }[],
): z.infer<typeof AutoSchema> {
  const blocks = blockSummaries.map((block) => ({ ...block }));
  const assignments: z.infer<typeof AutoSchema>["assignments"] = [];
  const unplaced: z.infer<typeof AutoSchema>["unplaced"] = [];

  const cases = [...waitlistItems].sort((a, b) => {
    const prio = priorityRank(a.priority) - priorityRank(b.priority);
    if (prio !== 0) return prio;
    return a.durationMin - b.durationMin;
  });

  for (const c of cases) {
    const block = blocks
      .filter(
        (b) =>
          (!c.requiredRoomType || !b.roomType || b.roomType === c.requiredRoomType) &&
          c.durationMin <= b.freeMin,
      )
      .sort((a, b) => b.freeMin - a.freeMin)[0];

    if (!block) {
      unplaced.push({ caseId: c.id, indok: "Nincs megfelelő műtő-típus vagy szabad kapacitás." });
      continue;
    }

    assignments.push({
      caseId: c.id,
      blockId: block.id,
      indok: "Szabályalapú fallback: prioritás és szabad kapacitás alapján.",
    });
    block.freeMin -= c.durationMin + block.turnover;
  }

  return {
    assignments,
    unplaced,
    rationale:
      "Az AI válasza nem volt feldolgozható, ezért szabályalapú beosztás készült prioritás és kapacitás alapján.",
  };
}

export const aiAutoSchedule = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => AutoInput.parse(d))
  .handler(async ({ data, context }): Promise<AutoScheduleResult> => {
    const { supabase, userId } = context;

    const { data: hasPerm } = await supabase.rpc("has_permission", {
      _user_id: userId,
      _perm: "book_or_case",
    });
    if (!hasPerm) throw new Error("Nincs jogosultsága automata beosztásra.");

    const [{ data: blocks }, { data: bookedCases }, { data: waitlist }, { data: rooms }] =
      await Promise.all([
        supabase
          .from("or_blocks")
          .select("id, org_unit_id, kezdo_ido, veg_ido, specialty_id, statusz, surgossegi_keret")
          .eq("datum", data.date)
          .neq("statusz", "felszabaditott"),
        supabase
          .from("surgery_cases")
          .select("id, or_block_id, becsult_idotartam_perc")
          .not("or_block_id", "is", null),
        supabase
          .from("surgery_cases")
          .select(
            "id, becsult_idotartam_perc, posztop_apolasi_perc, prioritas, statusz, surgery_type_id",
          )
          .is("or_block_id", null)
          .in("statusz", ["tervezett", "jovahagyott"])
          .limit(50),
        supabase
          .from("or_room_profiles")
          .select("id, org_unit_id, tipus, tartalek, fordulo_ido_perc")
          .eq("aktiv", true),
      ]);

    if (!blocks || blocks.length === 0) {
      return {
        assignments: [],
        unplaced: [],
        rationale: "Nincs aktív blokk erre a napra.",
        applied: 0,
        skipped: [],
      };
    }
    if (!waitlist || waitlist.length === 0) {
      return {
        assignments: [],
        unplaced: [],
        rationale: "Üres a várólista.",
        applied: 0,
        skipped: [],
      };
    }

    const typeIds = Array.from(
      new Set(waitlist.map((c) => c.surgery_type_id).filter(Boolean)),
    ) as string[];
    const { data: types } = typeIds.length
      ? await supabase
          .from("surgery_types")
          .select("id, nev, kod, kotelezo_muto_tipus")
          .in("id", typeIds)
      : {
          data: [] as {
            id: string;
            nev: string;
            kod: string | null;
            kotelezo_muto_tipus: string | null;
          }[],
        };

    const typeMap = new Map((types ?? []).map((t) => [t.id, t]));
    const roomByOrg = new Map((rooms ?? []).map((r) => [r.org_unit_id, r]));

    // compute free capacity per block (minutes left after currently-booked cases)
    const blockSummaries = blocks.map((b) => {
      const room = roomByOrg.get(b.org_unit_id);
      const startM = b.kezdo_ido
        ? parseInt(b.kezdo_ido.slice(0, 2)) * 60 + parseInt(b.kezdo_ido.slice(3, 5))
        : 0;
      const endM = b.veg_ido
        ? parseInt(b.veg_ido.slice(0, 2)) * 60 + parseInt(b.veg_ido.slice(3, 5))
        : 0;
      const totalMin = Math.max(0, endM - startM);
      const usedMin = (bookedCases ?? [])
        .filter((c) => c.or_block_id === b.id)
        .reduce((s, c) => s + (c.becsult_idotartam_perc ?? 0), 0);
      return {
        id: b.id,
        time: `${b.kezdo_ido?.slice(0, 5)}–${b.veg_ido?.slice(0, 5)}`,
        roomType: room?.tipus ?? null,
        freeMin: Math.max(0, totalMin - usedMin),
        turnover: room?.fordulo_ido_perc ?? 15,
        surgossegi: b.surgossegi_keret,
      };
    });

    const waitlistItems = waitlist.map((c) => {
      const t = c.surgery_type_id ? typeMap.get(c.surgery_type_id) : null;
      return {
        id: c.id,
        durationMin: c.becsult_idotartam_perc ?? 60,
        priority: c.prioritas ?? "elektiv",
        requiredRoomType: t?.kotelezo_muto_tipus ?? null,
        typeName: t?.nev ?? "ismeretlen",
      };
    });

    const key = process.env.LOVABLE_API_KEY;
    if (!key) throw new Error("AI gateway nincs konfigurálva.");
    const gateway = createLovableAiGatewayProvider(key);

    let output: z.infer<typeof AutoSchema>;
    try {
      const result = await generateText({
        model: gateway("google/gemini-3-flash-preview"),
        output: Output.object({ schema: AutoSchema }),
        system:
          "Te egy műtéti beosztás-tervező vagy. Oszd ki a várólista eseteit a megadott blokkokba úgy, hogy: (1) prioritás (azonnali → sürgős → elektív), (2) blokkonkénti maradék kapacitás (durationMin nem haladhatja meg a freeMin értéket), (3) ha a beavatkozásnak van requiredRoomType, csak olyan blokkba tehető, ahol roomType megegyezik, (4) hasonló esetek csoportosítása. Egy esetet csak egy blokkhoz rendelj. Add vissza a maradékot az unplaced tömbben rövid indokkal.",
        prompt: `DÁTUM: ${data.date}

BLOKKOK:
${JSON.stringify(blockSummaries, null, 2)}

VÁRÓLISTA:
${JSON.stringify(waitlistItems, null, 2)}

Adj vissza minden esethez egy assignment-et (caseId, blockId, indok) vagy tedd unplaced-be (caseId, indok). A rationale legyen rövid magyar összefoglaló (max 2 mondat).`,
      });
      output = result.output;
    } catch (error) {
      console.warn("AI auto-schedule schema mismatch, using deterministic fallback", error);
      output = fallbackAutoSchedule(blockSummaries, waitlistItems);
    }

    // Validate & apply: only assign if block exists, has capacity, and room-type matches
    const blockMap = new Map(blockSummaries.map((b) => [b.id, { ...b }]));
    const caseMap = new Map(waitlistItems.map((c) => [c.id, c]));
    const applied: typeof output.assignments = [];
    const skipped: { caseId: string; reason: string }[] = [];

    for (const a of output.assignments) {
      const c = caseMap.get(a.caseId);
      const b = blockMap.get(a.blockId);
      if (!c || !b) {
        skipped.push({ caseId: a.caseId, reason: "Ismeretlen eset vagy blokk" });
        continue;
      }
      if (c.requiredRoomType && b.roomType && c.requiredRoomType !== b.roomType) {
        skipped.push({
          caseId: a.caseId,
          reason: `Műtő-típus eltérés (${b.roomType} ≠ ${c.requiredRoomType})`,
        });
        continue;
      }
      if (c.durationMin > b.freeMin) {
        skipped.push({
          caseId: a.caseId,
          reason: `Nincs elég kapacitás (${c.durationMin}p > ${b.freeMin}p)`,
        });
        continue;
      }
      // assign
      const { error } = await supabase
        .from("surgery_cases")
        .update({ or_block_id: b.id })
        .eq("id", a.caseId);
      if (error) {
        skipped.push({ caseId: a.caseId, reason: error.message });
        continue;
      }
      b.freeMin -= c.durationMin + b.turnover;
      applied.push(a);
    }

    // Recompute times for affected blocks
    const affectedBlocks = Array.from(new Set(applied.map((a) => a.blockId)));
    for (const bid of affectedBlocks) {
      await supabase.rpc("recompute_block_case_times", { _block_id: bid });
    }

    return {
      assignments: applied,
      unplaced: output.unplaced,
      rationale: output.rationale,
      applied: applied.length,
      skipped,
    };
  });
