import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const Input = z.object({ date: z.string() });

export type OrConflict = {
  id: string; // synthetic id
  severity: "critical" | "warning";
  kind: "inactive_room" | "missing_profile" | "overbooked" | "case_out_of_window" | "released_with_cases";
  title: string;
  reason: string;
  suggestion: string;
  blockId: string | null;
  orgUnitId: string | null;
  orgUnitName: string | null;
  caseIds: string[];
};

function diffMinutes(start: string, end: string) {
  const [sh, sm] = start.split(":").map(Number);
  const [eh, em] = end.split(":").map(Number);
  return eh * 60 + em - (sh * 60 + sm);
}

export const listOrConflicts = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => Input.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase } = context;

    const [blocksRes, profilesRes, unitsRes] = await Promise.all([
      supabase
        .from("or_blocks")
        .select("id, org_unit_id, datum, kezdo_ido, veg_ido, statusz")
        .eq("datum", data.date),
      supabase.from("or_room_profiles").select("org_unit_id, aktiv"),
      supabase.from("org_units").select("id, nev, tipus, aktiv"),
    ]);

    const blocks = blocksRes.data ?? [];
    const profiles = profilesRes.data ?? [];
    const units = unitsRes.data ?? [];
    const profileByUnit = new Map(profiles.map((p) => [p.org_unit_id, p]));
    const unitById = new Map(units.map((u) => [u.id, u]));

    const blockIds = blocks.map((b) => b.id);
    const { data: cases } = blockIds.length
      ? await supabase
          .from("surgery_cases")
          .select("id, or_block_id, becsult_idotartam_perc, tervezett_kezdo_ido")
          .in("or_block_id", blockIds)
      : { data: [] as any[] };

    const conflicts: OrConflict[] = [];

    for (const b of blocks) {
      const unit = unitById.get(b.org_unit_id);
      const profile = profileByUnit.get(b.org_unit_id);
      const unitName = unit?.nev ?? "(ismeretlen műtő)";
      const myCases = (cases ?? []).filter((c) => c.or_block_id === b.id);

      // missing profile
      if (!profile) {
        conflicts.push({
          id: `mp-${b.id}`,
          severity: "warning",
          kind: "missing_profile",
          title: `Hiányzó műtő-profil: ${unitName}`,
          reason: `A(z) "${unitName}" műtőhöz nem tartozik műtő-profil, így a blokk nem jelenik meg a naptárban.`,
          suggestion: "Hozz létre vagy aktiválj egy műtő-profilt a szervezet adminban.",
          blockId: b.id,
          orgUnitId: b.org_unit_id,
          orgUnitName: unitName,
          caseIds: myCases.map((c) => c.id),
        });
      } else if (
        profile.aktiv === false ||
        unit?.aktiv === false ||
        !unit ||
        !["muto", "kismuto"].includes(unit?.tipus ?? "")
      ) {
        conflicts.push({
          id: `ir-${b.id}`,
          severity: "critical",
          kind: "inactive_room",
          title: `Inaktív műtő, aktív blokk: ${unitName}`,
          reason: `A(z) "${unitName}" műtő inaktív vagy nem műtő típusú, mégis van rá ${myCases.length} beosztott eset.`,
          suggestion:
            "Reaktiváld a műtőt a szervezet adminban, vagy szabadítsd fel a blokkot és helyezd át az eseteket.",
          blockId: b.id,
          orgUnitId: b.org_unit_id,
          orgUnitName: unitName,
          caseIds: myCases.map((c) => c.id),
        });
      }

      // released with cases
      if (b.statusz === "felszabaditott" && myCases.length > 0) {
        conflicts.push({
          id: `rc-${b.id}`,
          severity: "critical",
          kind: "released_with_cases",
          title: `Felszabadított blokk beosztott esetekkel: ${unitName}`,
          reason: `A blokk felszabadításra került, de még ${myCases.length} eset szerepel benne.`,
          suggestion: "Helyezd át az eseteket másik blokkba vagy vond vissza a felszabadítást.",
          blockId: b.id,
          orgUnitId: b.org_unit_id,
          orgUnitName: unitName,
          caseIds: myCases.map((c) => c.id),
        });
      }

      // overbooked
      const totalMin = b.kezdo_ido && b.veg_ido ? diffMinutes(b.kezdo_ido, b.veg_ido) : 0;
      const usedMin = myCases.reduce((s, c) => s + (c.becsult_idotartam_perc ?? 0), 0);
      if (totalMin > 0 && usedMin > totalMin) {
        conflicts.push({
          id: `ob-${b.id}`,
          severity: "warning",
          kind: "overbooked",
          title: `Túlcsorduló blokk: ${unitName} (${b.kezdo_ido?.slice(0, 5)}–${b.veg_ido?.slice(0, 5)})`,
          reason: `A beosztott esetek összesen ${usedMin} percet vesznek igénybe, de a blokk csak ${totalMin} perces.`,
          suggestion: `Növeld a blokk idejét legalább ${usedMin} percre, vagy helyezz át ${usedMin - totalMin} percnyi esetet.`,
          blockId: b.id,
          orgUnitId: b.org_unit_id,
          orgUnitName: unitName,
          caseIds: myCases.map((c) => c.id),
        });
      }

      // case out of window
      for (const c of myCases) {
        if (!c.tervezett_kezdo_ido || !b.kezdo_ido || !b.veg_ido) continue;
        const d = new Date(c.tervezett_kezdo_ido);
        const hh = d.getHours();
        const mm = d.getMinutes();
        const caseStart = hh * 60 + mm;
        const [bsH, bsM] = b.kezdo_ido.split(":").map(Number);
        const [beH, beM] = b.veg_ido.split(":").map(Number);
        const bStart = bsH * 60 + bsM;
        const bEnd = beH * 60 + beM;
        const caseEnd = caseStart + (c.becsult_idotartam_perc ?? 0);
        if (caseStart < bStart || caseEnd > bEnd) {
          conflicts.push({
            id: `cw-${c.id}`,
            severity: "warning",
            kind: "case_out_of_window",
            title: `Eset a blokk idősávján kívül: ${unitName}`,
            reason: `Az eset tervezett kezdete ${String(hh).padStart(2, "0")}:${String(mm).padStart(2, "0")}, ami nem fér bele a blokk ${b.kezdo_ido.slice(0, 5)}–${b.veg_ido.slice(0, 5)} sávjába.`,
            suggestion: "Igazítsd az eset tervezett kezdetét a blokk idősávjához.",
            blockId: b.id,
            orgUnitId: b.org_unit_id,
            orgUnitName: unitName,
            caseIds: [c.id],
          });
        }
      }
    }

    return { conflicts, generatedAt: new Date().toISOString() };
  });
