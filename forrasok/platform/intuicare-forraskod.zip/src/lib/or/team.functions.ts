import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const SENIOR_ROLES = new Set(["szakorvos", "foorvos", "szakteruleti_expert", "vezetorezidens"]);
const JUNIOR_ROLES = new Set(["rezidens", "szakgyakornok"]);
const ASSIST_THRESHOLD = 3;

type Seniority = "senior" | "junior" | "egyeb";

export type NextAssignment = { date: string; case_id: string; type_name: string };

export type EligiblePerson = {
  user_id: string;
  teljes_nev: string;
  seniority: Seniority;
  role_keys: string[];
  daily_cap: number;
  daily_used: number;
  weekly_hours_cap: number;
  weekly_hours_used: number;
  next_assignments: NextAssignment[];
};

const GenInput = z.object({ date: z.string() });

export type TeamPlanItem = {
  user_id: string;
  user_name: string;
  szerep: "operator" | "asszisztens" | "felugyelo";
  seniority: Seniority;
  indok: string;
};

export type TeamPlanRow = {
  case_id: string;
  patient_name: string;
  type_name: string;
  beavatkozas_id: string | null;
  time_label: string;
  kiemelt: boolean;
  prior_assist_count: number;
  items: TeamPlanItem[];
  warnings: string[];
};

export type TeamPlanResult = {
  date: string;
  rows: TeamPlanRow[];
  eligible: EligiblePerson[];
  summary: {
    cases: number;
    juniorPromoted: number;
    kiemelt: number;
    missingTeam: number;
  };
};

function pickLeastLoaded<T extends { user_id: string }>(
  candidates: T[],
  loadByUser: Map<string, { day: number; week: number; month: number }>,
): T | null {
  if (candidates.length === 0) return null;
  const scored = candidates.map((c) => {
    const l = loadByUser.get(c.user_id) ?? { day: 0, week: 0, month: 0 };
    // Composite: day weight strongest, then week, then month
    return { c, score: l.day * 100 + l.week * 10 + l.month };
  });
  scored.sort((a, b) => a.score - b.score);
  return scored[0].c;
}

function bumpLoad(
  map: Map<string, { day: number; week: number; month: number }>,
  userId: string,
) {
  const cur = map.get(userId) ?? { day: 0, week: 0, month: 0 };
  map.set(userId, { day: cur.day + 1, week: cur.week + 1, month: cur.month + 1 });
}

function startOfWeekIso(date: string) {
  const d = new Date(date + "T00:00:00Z");
  const dow = (d.getUTCDay() + 6) % 7; // Mon=0
  d.setUTCDate(d.getUTCDate() - dow);
  return d.toISOString().slice(0, 10);
}
function startOfMonthIso(date: string) {
  return date.slice(0, 7) + "-01";
}
function endOfMonthIso(date: string) {
  const d = new Date(date + "T00:00:00Z");
  const end = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0));
  return end.toISOString().slice(0, 10);
}
function addDaysIso(date: string, days: number) {
  const d = new Date(date + "T00:00:00Z");
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

export const aiGenerateTeamPlan = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => GenInput.parse(d))
  .handler(async ({ data, context }): Promise<TeamPlanResult> => {
    const { supabase, userId } = context;

    const { data: hasPerm } = await supabase.rpc("has_permission", {
      _user_id: userId,
      _perm: "book_or_case",
    });
    if (!hasPerm) throw new Error("Nincs jogosultsága csapat-beosztásra.");

    // 1) Blocks + cases for the day
    const { data: blocks } = await supabase
      .from("or_blocks")
      .select("id, org_unit_id, kezdo_ido, veg_ido")
      .eq("datum", data.date)
      .neq("statusz", "felszabaditott");

    if (!blocks || blocks.length === 0) {
      return {
        date: data.date,
        rows: [],
        eligible: [],
        summary: { cases: 0, juniorPromoted: 0, kiemelt: 0, missingTeam: 0 },
      };
    }

    const blockIds = blocks.map((b) => b.id);
    const blockMap = new Map(blocks.map((b) => [b.id, b]));

    const { data: cases } = await supabase
      .from("surgery_cases")
      .select(
        "id, patient_id, surgery_type_id, or_block_id, prioritas, kiemelt, delegalt_operator_id, sort_order, tervezett_kezdo_ido, becsult_idotartam_perc",
      )
      .in("or_block_id", blockIds)
      .not("statusz", "in", "(torolt,elvegzett)");

    if (!cases || cases.length === 0) {
      return {
        date: data.date,
        rows: [],
        eligible: [],
        summary: { cases: 0, juniorPromoted: 0, kiemelt: 0, missingTeam: 0 },
      };
    }

    // 2) Lookups: patients, types
    const patientIds = Array.from(new Set(cases.map((c) => c.patient_id).filter(Boolean))) as string[];
    const typeIds = Array.from(new Set(cases.map((c) => c.surgery_type_id).filter(Boolean))) as string[];

    const [{ data: patients }, { data: types }] = await Promise.all([
      patientIds.length
        ? supabase.from("patients").select("id, vezeteknev, keresztnev").in("id", patientIds)
        : Promise.resolve({ data: [] as { id: string; vezeteknev: string; keresztnev: string }[] }),
      typeIds.length
        ? supabase
            .from("surgery_types")
            .select("id, nev, kod, kiemelt, beavatkozas_id")
            .in("id", typeIds)
        : Promise.resolve({
            data: [] as { id: string; nev: string; kod: string | null; kiemelt: boolean; beavatkozas_id: string | null }[],
          }),
    ]);
    const patientMap = new Map((patients ?? []).map((p) => [p.id, p]));
    const typeMap = new Map((types ?? []).map((t) => [t.id, t]));

    // 3) Eligible staff (rezidens/szakgyakornok/szakorvos/foorvos/szakteruleti_expert/vezetorezidens) in tenant
    const { data: userRoleRows } = await supabase
      .from("user_roles")
      .select("user_id, roles!inner(kulcs)");

    const roleByUser = new Map<string, string[]>();
    for (const r of (userRoleRows ?? []) as { user_id: string; roles: { kulcs: string } | { kulcs: string }[] }[]) {
      const kulcs = Array.isArray(r.roles) ? r.roles[0]?.kulcs : r.roles?.kulcs;
      if (!kulcs) continue;
      const arr = roleByUser.get(r.user_id) ?? [];
      arr.push(kulcs);
      roleByUser.set(r.user_id, arr);
    }

    const candidateUserIds = Array.from(roleByUser.keys()).filter((uid) => {
      const keys = roleByUser.get(uid) ?? [];
      return keys.some((k) => SENIOR_ROLES.has(k) || JUNIOR_ROLES.has(k));
    });

    const { data: profilesRows } = candidateUserIds.length
      ? await supabase
          .from("profiles")
          .select("id, teljes_nev, aktiv, napi_mutet_cap")
          .in("id", candidateUserIds)
          .eq("aktiv", true)
      : { data: [] as { id: string; teljes_nev: string; aktiv: boolean; napi_mutet_cap: number | null }[] };

    const eligible: EligiblePerson[] = (profilesRows ?? []).map((p) => {
      const keys = roleByUser.get(p.id) ?? [];
      const seniority: Seniority = keys.some((k) => SENIOR_ROLES.has(k))
        ? "senior"
        : keys.some((k) => JUNIOR_ROLES.has(k))
          ? "junior"
          : "egyeb";
      return {
        user_id: p.id,
        teljes_nev: p.teljes_nev,
        seniority,
        role_keys: keys,
        daily_cap: (p as { napi_mutet_cap: number | null }).napi_mutet_cap ?? 2,
        daily_used: 0,
        weekly_hours_cap: 40,
        weekly_hours_used: 0,
        next_assignments: [],
      };
    });

    const seniors = eligible.filter((e) => e.seniority === "senior");
    const juniors = eligible.filter((e) => e.seniority === "junior");

    // 4) Assist counts per (user, beavatkozas_id) — from profile_beavatkozasok (sum)
    const beavatkozasIds = Array.from(
      new Set((types ?? []).map((t) => t.beavatkozas_id).filter(Boolean)),
    ) as string[];

    const pbCounts = new Map<string, number>(); // key = `${user}::${beavatkozas}`
    if (beavatkozasIds.length && candidateUserIds.length) {
      const { data: pb } = await supabase
        .from("profile_beavatkozasok")
        .select("user_id, beavatkozas_id, alkalom")
        .in("user_id", candidateUserIds)
        .in("beavatkozas_id", beavatkozasIds);
      for (const r of (pb ?? []) as { user_id: string; beavatkozas_id: string; alkalom: number }[]) {
        const k = `${r.user_id}::${r.beavatkozas_id}`;
        pbCounts.set(k, (pbCounts.get(k) ?? 0) + (r.alkalom ?? 0));
      }
    }

    // 5) Past asszisztens assignments (count toward threshold) — all-time, joined to type to map beavatkozas_id
    const { data: pastAssistRows } = await supabase
      .from("surgery_case_assignments")
      .select("user_id, szerep, surgery_cases!inner(surgery_type_id)")
      .eq("szerep", "asszisztens");
    for (const r of (pastAssistRows ?? []) as {
      user_id: string;
      surgery_cases: { surgery_type_id: string | null } | { surgery_type_id: string | null }[];
    }[]) {
      const t = Array.isArray(r.surgery_cases) ? r.surgery_cases[0] : r.surgery_cases;
      const typeId = t?.surgery_type_id ?? null;
      if (!typeId) continue;
      const beavatkozasId = typeMap.get(typeId)?.beavatkozas_id ?? null;
      if (!beavatkozasId) continue;
      const k = `${r.user_id}::${beavatkozasId}`;
      pbCounts.set(k, (pbCounts.get(k) ?? 0) + 1);
    }

    // 6) Load balancing — count existing assignments in day/week/month windows
    const weekStart = startOfWeekIso(data.date);
    const weekEnd = addDaysIso(weekStart, 6);
    const monthStart = startOfMonthIso(data.date);
    const monthEnd = endOfMonthIso(data.date);

    // Fetch case ids in those windows via or_blocks dates → cases
    const { data: monthBlocks } = await supabase
      .from("or_blocks")
      .select("id, datum")
      .gte("datum", monthStart)
      .lte("datum", monthEnd);
    const monthBlockIds = (monthBlocks ?? []).map((b) => b.id);
    const blockDate = new Map((monthBlocks ?? []).map((b) => [b.id, b.datum]));

    const { data: monthCases } = monthBlockIds.length
      ? await supabase
          .from("surgery_cases")
          .select("id, or_block_id, surgery_type_id, becsult_idotartam_perc")
          .in("or_block_id", monthBlockIds)
      : { data: [] as { id: string; or_block_id: string | null; surgery_type_id: string | null; becsult_idotartam_perc: number | null }[] };

    const caseDate = new Map(
      (monthCases ?? []).map((c) => [c.id, blockDate.get(c.or_block_id!) ?? null]),
    );
    const caseDuration = new Map(
      (monthCases ?? []).map((c) => [c.id, c.becsult_idotartam_perc ?? 60]),
    );
    const caseType = new Map(
      (monthCases ?? []).map((c) => [c.id, c.surgery_type_id ?? null]),
    );
    const monthCaseIds = (monthCases ?? []).map((c) => c.id);

    const { data: monthAssigns } = monthCaseIds.length
      ? await supabase
          .from("surgery_case_assignments")
          .select("user_id, case_id")
          .in("case_id", monthCaseIds)
      : { data: [] as { user_id: string; case_id: string }[] };

    const loadByUser = new Map<string, { day: number; week: number; month: number }>();
    const hoursByUser = new Map<string, { day: number; week: number }>();
    const upcomingByUser = new Map<string, NextAssignment[]>();
    for (const r of monthAssigns ?? []) {
      const d = caseDate.get(r.case_id);
      if (!d) continue;
      const cur = loadByUser.get(r.user_id) ?? { day: 0, week: 0, month: 0 };
      cur.month += 1;
      if (d >= weekStart && d <= weekEnd) cur.week += 1;
      if (d === data.date) cur.day += 1;
      loadByUser.set(r.user_id, cur);

      const dur = caseDuration.get(r.case_id) ?? 60;
      const h = hoursByUser.get(r.user_id) ?? { day: 0, week: 0 };
      if (d >= weekStart && d <= weekEnd) h.week += dur;
      if (d === data.date) h.day += dur;
      hoursByUser.set(r.user_id, h);

      if (d >= data.date) {
        const arr = upcomingByUser.get(r.user_id) ?? [];
        const typeId = caseType.get(r.case_id);
        const tName = typeId ? typeMap.get(typeId)?.nev ?? "—" : "—";
        arr.push({ date: d, case_id: r.case_id, type_name: tName });
        upcomingByUser.set(r.user_id, arr);
      }
    }

    // Enrich eligible with capacity + upcoming
    for (const e of eligible) {
      const l = loadByUser.get(e.user_id);
      const h = hoursByUser.get(e.user_id);
      e.daily_used = l?.day ?? 0;
      e.weekly_hours_used = Math.round(((h?.week ?? 0) / 60) * 10) / 10;
      const up = (upcomingByUser.get(e.user_id) ?? [])
        .sort((a, b) => a.date.localeCompare(b.date))
        .slice(0, 3);
      e.next_assignments = up;
    }

    // 7) Order cases: by block start, then sort_order, then by priority
    const prioRank: Record<string, number> = { azonnali: 0, sürgos: 1, "sürgős": 1, elektiv: 2 };
    const sortedCases = [...cases].sort((a, b) => {
      const ba = blockMap.get(a.or_block_id!)?.kezdo_ido ?? "";
      const bb = blockMap.get(b.or_block_id!)?.kezdo_ido ?? "";
      if (ba !== bb) return ba.localeCompare(bb);
      const pa = prioRank[a.prioritas ?? "elektiv"] ?? 9;
      const pb = prioRank[b.prioritas ?? "elektiv"] ?? 9;
      if (pa !== pb) return pa - pb;
      return (a.sort_order ?? 0) - (b.sort_order ?? 0);
    });

    const rows: TeamPlanRow[] = [];
    let juniorPromoted = 0;
    let kiemeltCount = 0;
    let missingTeam = 0;

    const seniorById = new Map(seniors.map((s) => [s.user_id, s]));

    for (const c of sortedCases) {
      const t = c.surgery_type_id ? typeMap.get(c.surgery_type_id) : null;
      const p = c.patient_id ? patientMap.get(c.patient_id) : null;
      const block = blockMap.get(c.or_block_id!);
      const kiemelt = c.kiemelt || (t?.kiemelt ?? false);
      const beavatkozasId = t?.beavatkozas_id ?? null;
      const warnings: string[] = [];
      const items: TeamPlanItem[] = [];

      if (kiemelt) kiemeltCount += 1;

      // Determine junior pool's assist count for this beavatkozas
      const juniorCounts = juniors.map((j) => ({
        ...j,
        prior: beavatkozasId ? pbCounts.get(`${j.user_id}::${beavatkozasId}`) ?? 0 : 0,
      }));

      let pickedJuniorAssist = 0;

      if (kiemelt) {
        // Senior operator (delegated if set, else least-loaded senior)
        let op: EligiblePerson | null = null;
        if (c.delegalt_operator_id && seniorById.has(c.delegalt_operator_id)) {
          op = seniorById.get(c.delegalt_operator_id)!;
        } else if (c.delegalt_operator_id) {
          // delegated to someone not in senior list (junior or outside) — honor it but warn
          const all = eligible.find((e) => e.user_id === c.delegalt_operator_id);
          if (all) {
            op = all;
            warnings.push("Delegált operatőr nem szakorvos/főorvos.");
          }
        }
        if (!op) op = pickLeastLoaded(seniors, loadByUser);
        if (op) {
          items.push({
            user_id: op.user_id,
            user_name: op.teljes_nev,
            szerep: "operator",
            seniority: op.seniority,
            indok: c.delegalt_operator_id
              ? "Kiemelt műtét — várólistán delegált operatőr"
              : "Kiemelt műtét — szenior operatőr (legkevésbé terhelt)",
          });
          bumpLoad(loadByUser, op.user_id);
        } else {
          warnings.push("Nincs elérhető szenior operatőr.");
        }
        // Junior assist for learning (round-robin by load)
        const jr = pickLeastLoaded(juniorCounts, loadByUser);
        if (jr) {
          items.push({
            user_id: jr.user_id,
            user_name: jr.teljes_nev,
            szerep: "asszisztens",
            seniority: "junior",
            indok: "Kiemelt műtét melletti tanulási asszisztálás",
          });
          bumpLoad(loadByUser, jr.user_id);
        }
      } else {
        // Pick junior balanced
        const jr = pickLeastLoaded(juniorCounts, loadByUser);
        if (!jr) {
          warnings.push("Nincs elérhető rezidens / szakgyakornok.");
          // fall back: senior operator only
          const op = pickLeastLoaded(seniors, loadByUser);
          if (op) {
            items.push({
              user_id: op.user_id,
              user_name: op.teljes_nev,
              szerep: "operator",
              seniority: "senior",
              indok: "Junior hiányában szenior operatőr",
            });
            bumpLoad(loadByUser, op.user_id);
          }
        } else {
          pickedJuniorAssist = jr.prior;
          const promoted = jr.prior >= ASSIST_THRESHOLD;
          if (promoted) juniorPromoted += 1;

          if (promoted) {
            // Junior operator + senior assistant + felugyelo
            items.push({
              user_id: jr.user_id,
              user_name: jr.teljes_nev,
              szerep: "operator",
              seniority: "junior",
              indok: `Promóció: ${jr.prior} korábbi asszisztálás (≥${ASSIST_THRESHOLD}) → operatőr besorolás`,
            });
            bumpLoad(loadByUser, jr.user_id);

            const sen1 = pickLeastLoaded(seniors, loadByUser);
            if (sen1) {
              items.push({
                user_id: sen1.user_id,
                user_name: sen1.teljes_nev,
                szerep: "asszisztens",
                seniority: "senior",
                indok: "Szakorvosi asszisztálás junior operatőr mellett",
              });
              bumpLoad(loadByUser, sen1.user_id);
            }
            const sen2 = pickLeastLoaded(
              seniors.filter((s) => !sen1 || s.user_id !== sen1.user_id),
              loadByUser,
            );
            if (sen2) {
              items.push({
                user_id: sen2.user_id,
                user_name: sen2.teljes_nev,
                szerep: "felugyelo",
                seniority: "senior",
                indok: "Felügyelet a junior operatőr mellett",
              });
              bumpLoad(loadByUser, sen2.user_id);
            } else if (sen1) {
              warnings.push("Csak egy szenior elérhető — felügyeletet ugyanaz a személy adja.");
            } else {
              warnings.push("Nincs szenior asszisztálás / felügyelet.");
            }
          } else {
            // Senior operator + junior assistant
            const sen = pickLeastLoaded(seniors, loadByUser);
            if (sen) {
              items.push({
                user_id: sen.user_id,
                user_name: sen.teljes_nev,
                szerep: "operator",
                seniority: "senior",
                indok: "Szenior operatőr (legkevésbé terhelt)",
              });
              bumpLoad(loadByUser, sen.user_id);
            } else {
              warnings.push("Nincs elérhető szenior operatőr.");
            }
            items.push({
              user_id: jr.user_id,
              user_name: jr.teljes_nev,
              szerep: "asszisztens",
              seniority: "junior",
              indok: `Tanulási asszisztálás (${jr.prior}/${ASSIST_THRESHOLD})`,
            });
            bumpLoad(loadByUser, jr.user_id);
          }
        }
      }

      if (items.length === 0) missingTeam += 1;

      rows.push({
        case_id: c.id,
        patient_name: p ? `${p.vezeteknev} ${p.keresztnev}` : "—",
        type_name: t?.nev ?? "—",
        beavatkozas_id: beavatkozasId,
        time_label: block ? `${block.kezdo_ido?.slice(0, 5)}–${block.veg_ido?.slice(0, 5)}` : "—",
        kiemelt,
        prior_assist_count: pickedJuniorAssist,
        items,
        warnings,
      });
    }

    return {
      date: data.date,
      rows,
      eligible,
      summary: { cases: rows.length, juniorPromoted, kiemelt: kiemeltCount, missingTeam },
    };
  });

// ---- Apply ----
const ApplyInput = z.object({
  date: z.string(),
  assignments: z.array(
    z.object({
      case_id: z.string().uuid(),
      items: z.array(
        z.object({
          user_id: z.string().uuid(),
          szerep: z.enum(["operator", "asszisztens", "felugyelo", "aneszteziologus", "mutos_szakdolgozo", "egyeb"]),
          indok: z.string().nullable().optional(),
        }),
      ),
    }),
  ),
});

export const applyTeamPlan = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => ApplyInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;

    const { data: hasPerm } = await supabase.rpc("has_permission", {
      _user_id: userId,
      _perm: "manage_or_blocks",
    });
    const { data: hasBook } = await supabase.rpc("has_permission", {
      _user_id: userId,
      _perm: "book_or_case",
    });
    if (!hasPerm && !hasBook) throw new Error("Nincs jogosultsága csapat-beosztás mentésére.");

    // Get tenant_id from profile
    const { data: profile } = await supabase
      .from("profiles")
      .select("tenant_id")
      .eq("id", userId)
      .maybeSingle();
    if (!profile?.tenant_id) throw new Error("Hiányzó tenant.");

    const caseIds = data.assignments.map((a) => a.case_id);
    if (caseIds.length === 0) return { inserted: 0 };

    // Clear existing AI-generated assignments for these cases
    await supabase
      .from("surgery_case_assignments")
      .delete()
      .in("case_id", caseIds)
      .eq("ai_generated", true);

    // Build insert rows (dedupe by case+user+szerep)
    const seen = new Set<string>();
    const rows: Array<{
      tenant_id: string;
      case_id: string;
      user_id: string;
      szerep: string;
      indok: string | null;
      ai_generated: boolean;
      created_by: string;
    }> = [];
    for (const a of data.assignments) {
      for (const it of a.items) {
        const key = `${a.case_id}::${it.user_id}::${it.szerep}`;
        if (seen.has(key)) continue;
        seen.add(key);
        rows.push({
          tenant_id: profile.tenant_id,
          case_id: a.case_id,
          user_id: it.user_id,
          szerep: it.szerep,
          indok: it.indok ?? null,
          ai_generated: true,
          created_by: userId,
        });
      }
    }

    if (rows.length === 0) return { inserted: 0 };

    const { error } = await supabase
      .from("surgery_case_assignments")
      .upsert(rows, { onConflict: "case_id,user_id,szerep" });
    if (error) throw new Error(error.message);

    return { inserted: rows.length };
  });
