import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

export type SurgeryTypeRule = {
  id: string;
  nev: string;
  kod: string | null;
  kiemelt: boolean;
  delegalas_kotelezo: boolean;
  operator_min_seniority: "szakorvos" | "foorvos" | null;
  szukseges_szerepek: string[] | null;
  szukseges_skillek: string[] | null;
  kotelezo_eroforrasok: string[] | null;
  kotelezo_muto_tipus: string | null;
  aktiv: boolean;
};

export const listSurgeryTypeRules = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase } = context;
    const { data, error } = await supabase
      .from("surgery_types")
      .select(
        "id, nev, kod, kiemelt, delegalas_kotelezo, operator_min_seniority, szukseges_szerepek, szukseges_skillek, kotelezo_eroforrasok, kotelezo_muto_tipus, aktiv",
      )
      .order("nev");
    if (error) throw new Error(error.message);
    const toArr = (v: unknown): string[] | null =>
      Array.isArray(v) ? (v as string[]) : null;
    const rules: SurgeryTypeRule[] = (data ?? []).map((r) => ({
      id: r.id as string,
      nev: r.nev as string,
      kod: (r.kod as string | null) ?? null,
      kiemelt: Boolean(r.kiemelt),
      delegalas_kotelezo: Boolean(r.delegalas_kotelezo),
      operator_min_seniority: (r.operator_min_seniority as "szakorvos" | "foorvos" | null) ?? null,
      szukseges_szerepek: toArr(r.szukseges_szerepek),
      szukseges_skillek: toArr(r.szukseges_skillek),
      kotelezo_eroforrasok: toArr(r.kotelezo_eroforrasok),
      kotelezo_muto_tipus: (r.kotelezo_muto_tipus as string | null) ?? null,
      aktiv: Boolean(r.aktiv),
    }));
    return rules;
  });

const UpsertInput = z.object({
  id: z.string().uuid(),
  kiemelt: z.boolean().optional(),
  delegalas_kotelezo: z.boolean().optional(),
  operator_min_seniority: z.enum(["szakorvos", "foorvos"]).nullable().optional(),
  szukseges_skillek: z.array(z.string()).nullable().optional(),
  kotelezo_eroforrasok: z.array(z.string()).nullable().optional(),
});

export const upsertSurgeryTypeRule = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => UpsertInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: hasPerm } = await supabase.rpc("has_permission", {
      _user_id: userId,
      _perm: "manage_or_blocks",
    });
    if (!hasPerm) throw new Error("Nincs jogosultsága műtéti szabályok módosítására.");

    const { id, ...patch } = data;
    const updatePatch: Record<string, unknown> = { ...patch };
    const { error } = await supabase
      .from("surgery_types")
      .update(updatePatch as never)
      .eq("id", id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
