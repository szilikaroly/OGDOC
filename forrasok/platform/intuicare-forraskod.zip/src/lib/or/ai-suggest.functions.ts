import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";
import { generateText, Output } from "ai";
import { createLovableAiGatewayProvider } from "@/lib/ai-gateway.server";

const Input = z.object({ date: z.string() });

const SuggestionSchema = z.object({
  matches: z.array(
    z.object({
      caseId: z.string(),
      blockId: z.string(),
      tervezettKezdoIdo: z.string().nullable(),
      indok: z.string(),
    }),
  ),
  releases: z.array(z.object({ blockId: z.string(), indok: z.string() })),
  rearrangements: z.array(
    z.object({ caseId: z.string(), javaslat: z.string(), indok: z.string() }),
  ),
  delays: z.array(
    z.object({ caseId: z.string(), kesesPerc: z.number(), indok: z.string() }),
  ),
});

export type OrAiSuggestion = z.infer<typeof SuggestionSchema>;

export const aiSuggestSchedule = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => Input.parse(d))
  .handler(async ({ data, context }): Promise<OrAiSuggestion> => {
    const { supabase } = context;
    const date = data.date;

    const [{ data: blocks }, { data: cases }, { data: waitlist }, { data: rooms }] =
      await Promise.all([
        supabase
          .from("or_blocks")
          .select("id, org_unit_id, kezdo_ido, veg_ido, specialty_id, statusz, surgossegi_keret")
          .eq("datum", date),
        supabase
          .from("surgery_cases")
          .select(
            "id, or_block_id, becsult_idotartam_perc, posztop_apolasi_perc, prioritas, statusz, tervezett_kezdo_ido, surgery_type_id",
          )
          .not("or_block_id", "is", null),
        supabase
          .from("surgery_cases")
          .select(
            "id, becsult_idotartam_perc, prioritas, statusz, tervezett_kezdo_ido, surgery_type_id",
          )
          .is("or_block_id", null)
          .in("statusz", ["tervezett", "jovahagyott"])
          .limit(50),
        supabase
          .from("or_room_profiles")
          .select("id, org_unit_id, tipus, tartalek, napi_kezdo_ido, napi_veg_ido, fordulo_ido_perc")
          .eq("aktiv", true),
      ]);

    // Compute delays locally (deterministic; AI can still annotate)
    const now = new Date();
    const localDelays = (cases ?? [])
      .filter((c) => {
        if (!c.tervezett_kezdo_ido) return false;
        if (c.statusz === "elvegzett" || c.statusz === "torolt") return false;
        return new Date(c.tervezett_kezdo_ido).getTime() + 5 * 60_000 < now.getTime();
      })
      .map((c) => ({
        caseId: c.id,
        kesesPerc: Math.round(
          (now.getTime() - new Date(c.tervezett_kezdo_ido!).getTime()) / 60_000,
        ),
        indok: "Tervezett kezdés lejárt, az eset még nem indult el.",
      }));

    const key = process.env.LOVABLE_API_KEY;
    if (!key) {
      // Graceful fallback: still surface delays + naive matches
      return { matches: [], releases: [], rearrangements: [], delays: localDelays };
    }

    const gateway = createLovableAiGatewayProvider(key);

    const prompt = `Te műtéti beosztás-asszisztens vagy. Az alábbi adatok alapján adj JSON javaslatot.
Szabályok:
- "matches": csak olyan eseteket párosíts blokkhoz, ahol a blokk specialty_id-ja egyezik a surgery_type szakterületével (ha nincs adat, hagyd ki). Ne lépd túl a blokk hosszát. Sürgős eseteket előrébb vegyél.
- "releases": jelöld a blokkokat, ahol nincs egy eset sem és a nap > 50%-a már eltelt.
- "rearrangements": azonnali prioritású esetekhez javasolj elektív eltolást ugyanabban a blokkban.
- "delays": csak rövid magyarázat a már eltolódott esetekhez.
A válasz csak a megadott séma legyen.

DATUM: ${date}
BLOKKOK: ${JSON.stringify(blocks ?? [])}
FOGLALT_ESETEK: ${JSON.stringify(cases ?? [])}
VAROLISTA: ${JSON.stringify(waitlist ?? [])}
TERMEK: ${JSON.stringify(rooms ?? [])}`;

    try {
      const { experimental_output } = await generateText({
        model: gateway("google/gemini-2.5-flash"),
        prompt,
        experimental_output: Output.object({ schema: SuggestionSchema }),
      });
      const out = experimental_output as OrAiSuggestion;
      // Merge AI delays with locally computed (AI sometimes omits)
      const seen = new Set(out.delays.map((d) => d.caseId));
      const merged = [...out.delays, ...localDelays.filter((d) => !seen.has(d.caseId))];
      return { ...out, delays: merged };
    } catch {
      return { matches: [], releases: [], rearrangements: [], delays: localDelays };
    }
  });

// ----- previewEligibility: live tooltip during drag -----
const PreviewInput = z.object({ caseId: z.string().uuid(), date: z.string() });

export type EligibilityMap = Record<string, { allowed: boolean; reason: string }>;

export const previewEligibility = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => PreviewInput.parse(d))
  .handler(async ({ data, context }): Promise<EligibilityMap> => {
    const { supabase, userId } = context;

    const { data: blocks } = await supabase
      .from("or_blocks")
      .select("id, statusz, kezdo_ido, veg_ido")
      .eq("datum", data.date);

    const { data: c } = await supabase
      .from("surgery_cases")
      .select("id, surgery_type_id, becsult_idotartam_perc, prioritas")
      .eq("id", data.caseId)
      .maybeSingle();

    if (!c) return {};

    const map: EligibilityMap = {};
    for (const b of blocks ?? []) {
      let allowed = true;
      let reason = "Engedélyezett";

      if (b.statusz === "felszabaditott") {
        allowed = false;
        reason = "Blokk felszabadítva";
      } else {
        const { data: rpc } = await supabase.rpc("can_book_into_block", {
          _user_id: userId,
          _block_id: b.id,
        });
        if (!rpc) {
          allowed = false;
          reason = "Nincs jogosultsága / szakterület eltérés";
        } else if (b.kezdo_ido && b.veg_ido && c.becsult_idotartam_perc) {
          const start = parseInt(b.kezdo_ido.slice(0, 2)) * 60 + parseInt(b.kezdo_ido.slice(3, 5));
          const end = parseInt(b.veg_ido.slice(0, 2)) * 60 + parseInt(b.veg_ido.slice(3, 5));
          if (end - start < c.becsult_idotartam_perc) {
            allowed = false;
            reason = "Blokk rövidebb mint az eset becsült hossza";
          }
        }
      }
      map[b.id] = { allowed, reason };
    }
    return map;
  });

// ============================================================================
// CASCADE REPLAN — több műtét összehangolása, domino-hatás minimalizálása
// ============================================================================
//
// Trigger: egy eset megcsúszik (késés / sebész nem tud továbbjutni / felszerelés-
// hiány). A fn lokálisan kiszámolja a downstream csúszást ugyanabban a blokkban,
// majd az AI komplex átrendezést javasol: csere, helyettesítés, blokk-csere,
// halasztás — úgy, hogy a teljes napi csúszás minimális legyen.

const CascadeInput = z.object({
  date: z.string(),
  triggerCaseId: z.string().uuid().nullable().optional(),
  delayMinutes: z.number().int().min(0).optional(), // ha ismert
  unavailableUserIds: z.array(z.string().uuid()).optional(), // sebészek, akik nem juttatnak tovább
  reason: z.string().max(500).optional(),
});

const CascadeStep = z.discriminatedUnion("type", [
  z.object({
    type: z.literal("move"),
    caseId: z.string(),
    toBlockId: z.string(),
    newStart: z.string().nullable(),
    indok: z.string(),
  }),
  z.object({
    type: z.literal("swap"),
    caseAId: z.string(),
    caseBId: z.string(),
    indok: z.string(),
  }),
  z.object({
    type: z.literal("substitute_staff"),
    blockId: z.string(),
    toUserId: z.string(),
    indok: z.string(),
  }),
  z.object({
    type: z.literal("release"),
    blockId: z.string(),
    indok: z.string(),
  }),
  z.object({
    type: z.literal("defer"),
    caseId: z.string(),
    indok: z.string(),
  }),
]);

const CascadePlanSchema = z.object({
  triggerSummary: z.string(),
  estimatedSavedMinutes: z.number(),
  cascadeRisk: z.enum(["alacsony", "kozepes", "magas"]),
  steps: z.array(CascadeStep).max(12),
  warnings: z.array(z.string()).max(5),
});

export type CascadePlan = z.infer<typeof CascadePlanSchema>;
export type CascadeStepT = z.infer<typeof CascadeStep>;

export const cascadeReplan = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => CascadeInput.parse(d))
  .handler(async ({ data, context }): Promise<CascadePlan> => {
    const { supabase } = context;
    const { date } = data;

    const [{ data: blocks }, { data: cases }, { data: waitlist }, { data: pool }] =
      await Promise.all([
        supabase
          .from("or_blocks")
          .select("id, org_unit_id, kezdo_ido, veg_ido, specialty_id, sebesz_user_id, statusz")
          .eq("datum", date),
        supabase
          .from("surgery_cases")
          .select(
            "id, or_block_id, becsult_idotartam_perc, posztop_apolasi_perc, prioritas, statusz, tervezett_kezdo_ido, surgery_type_id",
          )
          .not("or_block_id", "is", null),
        supabase
          .from("surgery_cases")
          .select("id, becsult_idotartam_perc, prioritas, surgery_type_id")
          .is("or_block_id", null)
          .in("statusz", ["tervezett", "jovahagyott"])
          .limit(30),
        supabase
          .from("or_staff_pool")
          .select("user_id, or_suite_id, eligible_szerep, ervenyes_tol, ervenyes_ig"),
      ]);

    // Lokális downstream kaszkád-számítás
    const triggerCase = (cases ?? []).find((c) => c.id === data.triggerCaseId);
    const delay = data.delayMinutes ?? 0;
    const downstream: Array<{ caseId: string; slipMin: number; blockId: string }> = [];
    if (triggerCase?.or_block_id && delay > 0) {
      const sameBlock = (cases ?? [])
        .filter(
          (c) =>
            c.or_block_id === triggerCase.or_block_id &&
            c.id !== triggerCase.id &&
            c.tervezett_kezdo_ido &&
            triggerCase.tervezett_kezdo_ido &&
            new Date(c.tervezett_kezdo_ido) > new Date(triggerCase.tervezett_kezdo_ido),
        )
        .sort((a, b) => a.tervezett_kezdo_ido!.localeCompare(b.tervezett_kezdo_ido!));
      for (const c of sameBlock) {
        downstream.push({ caseId: c.id, slipMin: delay, blockId: c.or_block_id! });
      }
    }

    const key = process.env.LOVABLE_API_KEY;
    if (!key) {
      return {
        triggerSummary: triggerCase
          ? `Eset #${triggerCase.id.slice(0, 6)} ${delay} perc csúszása ${downstream.length} további esetet érint.`
          : "Nincs trigger megadva.",
        estimatedSavedMinutes: 0,
        cascadeRisk: downstream.length >= 3 ? "magas" : downstream.length > 0 ? "kozepes" : "alacsony",
        steps: [],
        warnings: ["AI gateway nem elérhető — csak lokális kaszkád-elemzés."],
      };
    }

    const gateway = createLovableAiGatewayProvider(key);
    const prompt = `Te műtéti koordinátor vagy. Egy esemény miatt domino-csúszás fenyeget. Adj minimális lépésszámú átrendezést.

SZABÁLYOK:
- "move": áthelyezés másik blokkba (csak ha specialty és időkeret stimmel).
- "swap": két azonos szakterületű eset cseréje két blokk között.
- "substitute_staff": helyettesítő sebész a pool-ból (ugyanaz a szakma, érvényesség OK, nincs a unavailableUserIds-ban).
- "release": üres / nem hasznosítható blokk felszabadítása.
- "defer": eset visszatétele a várólistára (csak elektív, NEM "azonnali" prioritás).
- A sürgős és "azonnali" esetek prioritást kapnak, ne halaszd őket.
- Cél: a teljes napi össz-csúszás csökkentése. estimatedSavedMinutes legyen reális.
- Max 12 lépés. Indokold magyarul, röviden (1 mondat).

INPUT:
DATUM: ${date}
TRIGGER_CASE: ${JSON.stringify(triggerCase ?? null)}
KESES_PERC: ${delay}
NEM_ELERHETO_SEBESZEK: ${JSON.stringify(data.unavailableUserIds ?? [])}
REASON: ${data.reason ?? ""}
LOKALIS_DOWNSTREAM: ${JSON.stringify(downstream)}
BLOKKOK: ${JSON.stringify(blocks ?? [])}
FOGLALT_ESETEK: ${JSON.stringify(cases ?? [])}
VAROLISTA: ${JSON.stringify(waitlist ?? [])}
STAFF_POOL: ${JSON.stringify(pool ?? [])}`;

    try {
      const { experimental_output } = await generateText({
        model: gateway("google/gemini-2.5-flash"),
        prompt,
        experimental_output: Output.object({ schema: CascadePlanSchema }),
      });
      return experimental_output as CascadePlan;
    } catch (err) {
      return {
        triggerSummary: `Lokális elemzés: ${downstream.length} downstream eset érintett.`,
        estimatedSavedMinutes: 0,
        cascadeRisk: downstream.length >= 3 ? "magas" : downstream.length > 0 ? "kozepes" : "alacsony",
        steps: [],
        warnings: [`AI hiba: ${(err as Error).message}`],
      };
    }
  });

// ----- applyCascadePlan: lépések szekvenciális végrehajtása -----
const ApplyInput = z.object({ steps: z.array(CascadeStep).max(12) });

export const applyCascadePlan = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => ApplyInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const results: Array<{ ok: boolean; step: CascadeStepT; error?: string }> = [];

    for (const step of data.steps) {
      try {
        if (step.type === "move") {
          const { data: allowed } = await supabase.rpc("can_book_into_block", {
            _user_id: userId,
            _block_id: step.toBlockId,
          });
          if (!allowed) throw new Error("Nincs jog a célblokkba foglalni.");
          const { error } = await supabase
            .from("surgery_cases")
            .update({ or_block_id: step.toBlockId, tervezett_kezdo_ido: step.newStart })
            .eq("id", step.caseId);
          if (error) throw new Error(error.message);
        } else if (step.type === "swap") {
          const { data: pair } = await supabase
            .from("surgery_cases")
            .select("id, or_block_id, tervezett_kezdo_ido")
            .in("id", [step.caseAId, step.caseBId]);
          if (!pair || pair.length !== 2) throw new Error("Csere: eset nem található.");
          const a = pair.find((p) => p.id === step.caseAId)!;
          const b = pair.find((p) => p.id === step.caseBId)!;
          const { error: e1 } = await supabase
            .from("surgery_cases")
            .update({ or_block_id: b.or_block_id, tervezett_kezdo_ido: b.tervezett_kezdo_ido })
            .eq("id", a.id);
          if (e1) throw new Error(e1.message);
          const { error: e2 } = await supabase
            .from("surgery_cases")
            .update({ or_block_id: a.or_block_id, tervezett_kezdo_ido: a.tervezett_kezdo_ido })
            .eq("id", b.id);
          if (e2) throw new Error(e2.message);
        } else if (step.type === "substitute_staff") {
          const { error } = await supabase
            .from("or_blocks")
            .update({ sebesz_user_id: step.toUserId })
            .eq("id", step.blockId);
          if (error) throw new Error(error.message);
        } else if (step.type === "release") {
          const { error } = await supabase
            .from("or_blocks")
            .update({ statusz: "felszabaditott" })
            .eq("id", step.blockId);
          if (error) throw new Error(error.message);
        } else if (step.type === "defer") {
          const { error } = await supabase
            .from("surgery_cases")
            .update({ or_block_id: null, tervezett_kezdo_ido: null })
            .eq("id", step.caseId);
          if (error) throw new Error(error.message);
        }
        results.push({ ok: true, step });
      } catch (err) {
        results.push({ ok: false, step, error: (err as Error).message });
      }
    }

    return {
      applied: results.filter((r) => r.ok).length,
      failed: results.filter((r) => !r.ok).length,
      results,
    };
  });
