import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

// ----- listBoard -----
const ListInput = z.object({
  date: z.string(), // ISO yyyy-mm-dd
  suiteId: z.string().uuid().nullable().optional(),
});

export const listBoard = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => ListInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase } = context;

    const { data: rooms } = await supabase
      .from("or_room_profiles")
      .select("id, org_unit_id, or_suite_id, tipus, tartalek, napi_kezdo_ido, napi_veg_ido, fordulo_ido_perc, aktiv")
      .eq("aktiv", true)
      .order("tipus");

    const { data: blocks } = await supabase
      .from("or_blocks")
      .select("id, org_unit_id, datum, kezdo_ido, veg_ido, specialty_id, sebesz_user_id, statusz, surgossegi_keret, megjegyzes")
      .eq("datum", data.date);

    const blockIds = (blocks ?? []).map((b) => b.id);
    const { data: cases } = blockIds.length
      ? await supabase
          .from("surgery_cases")
          .select("id, patient_id, surgery_type_id, or_block_id, becsult_idotartam_perc, posztop_apolasi_perc, prioritas, statusz, tervezett_kezdo_ido, jovahagyta_user_id, sort_order")
          .in("or_block_id", blockIds)
          .order("sort_order", { ascending: true, nullsFirst: false })
          .order("created_at", { ascending: true })
      : { data: [] as never[] };

    const { data: waitlist } = await supabase
      .from("surgery_cases")
      .select("id, patient_id, surgery_type_id, becsult_idotartam_perc, prioritas, statusz")
      .is("or_block_id", null)
      .in("statusz", ["tervezett", "jovahagyott"])
      .limit(50);

    return { rooms: rooms ?? [], blocks: blocks ?? [], cases: cases ?? [], waitlist: waitlist ?? [] };
  });

// ----- bookCaseToBlock -----
const BookInput = z.object({
  caseId: z.string().uuid(),
  blockId: z.string().uuid(),
  tervezettKezdoIdo: z.string().nullable().optional(),
});

export const bookCaseToBlock = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => BookInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;

    // server-side permission gate via security definer
    const { data: allowed, error: rpcErr } = await supabase.rpc("can_book_into_block", {
      _user_id: userId,
      _block_id: data.blockId,
    });
    if (rpcErr) throw new Error(rpcErr.message);
    if (!allowed) throw new Error("Nincs jogosultsága ebbe a blokkba foglalni.");

    const { error } = await supabase
      .from("surgery_cases")
      .update({
        or_block_id: data.blockId,
        tervezett_kezdo_ido: data.tervezettKezdoIdo ?? null,
      })
      .eq("id", data.caseId);
    if (error) throw new Error(error.message);

    return { ok: true };
  });

// ----- releaseBlock -----
const ReleaseInput = z.object({ blockId: z.string().uuid() });

export const releaseBlock = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => ReleaseInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { error } = await supabase
      .from("or_blocks")
      .update({ statusz: "felszabaditott" })
      .eq("id", data.blockId);
    if (error) throw new Error(error.message); // RLS gates by manage_or_blocks
    return { ok: true };
  });

// ----- triggerEmergency -----
const EmergencyInput = z.object({
  caseId: z.string().uuid(),
  tervezettKezdoIdo: z.string().nullable().optional(),
});

export const triggerEmergency = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => EmergencyInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;

    // explicit perm check (defense in depth; RLS also enforces)
    const { data: hasPerm } = await supabase.rpc("has_permission", {
      _user_id: userId,
      _perm: "trigger_or_emergency",
    });
    if (!hasPerm) throw new Error("Nincs jogosultsága sürgősségi eset indítására.");

    const { error } = await supabase
      .from("surgery_cases")
      .update({
        prioritas: "azonnali",
        tervezett_kezdo_ido: data.tervezettKezdoIdo ?? new Date().toISOString(),
      })
      .eq("id", data.caseId);
    if (error) throw new Error(error.message);

    return { ok: true };
  });

// ----- respondToEmergency -----
const RespondInput = z.object({
  caseId: z.string().uuid(),
  notificationId: z.string().uuid().nullable().optional(),
  tudJonni: z.boolean(),
  etaPerc: z.number().int().nonnegative().nullable().optional(),
  megjegyzes: z.string().max(500).nullable().optional(),
});

export const respondToEmergency = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => RespondInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: prof } = await supabase.from("profiles").select("tenant_id").eq("id", userId).maybeSingle();
    if (!prof?.tenant_id) throw new Error("No tenant");

    const { error } = await supabase.from("or_emergency_responses").upsert(
      {
        tenant_id: prof.tenant_id,
        surgery_case_id: data.caseId,
        user_id: userId,
        notification_id: data.notificationId ?? null,
        tud_jonni: data.tudJonni,
        eta_perc: data.etaPerc ?? null,
        megjegyzes: data.megjegyzes ?? null,
      },
      { onConflict: "surgery_case_id,user_id" },
    );
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// ----- listWaitlist (full management view) -----
const WaitlistInput = z.object({
  search: z.string().nullable().optional(),
  prioritas: z.enum(["elektiv", "sürgos", "azonnali"]).nullable().optional(),
  statusz: z.enum(["tervezett", "jovahagyott", "folyamatban", "elvegzett", "elhalasztott", "torolt"]).nullable().optional(),
  csakVarolista: z.boolean().optional(),
  limit: z.number().int().positive().max(500).optional(),
});

export const listWaitlist = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => WaitlistInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    let q = supabase
      .from("surgery_cases")
      .select(
        "id, patient_id, surgery_type_id, or_block_id, becsult_idotartam_perc, posztop_apolasi_perc, prioritas, statusz, tervezett_kezdo_ido, megjegyzes, created_at, jovahagyta_user_id, jovahagyas_at, kiemelt, delegalt_operator_id",
      )
      .order("prioritas", { ascending: false })
      .order("created_at", { ascending: true })
      .limit(data.limit ?? 200);


    if (data.csakVarolista) q = q.is("or_block_id", null);
    if (data.prioritas) q = q.eq("prioritas", data.prioritas);
    if (data.statusz) q = q.eq("statusz", data.statusz);

    const { data: cases, error } = await q;
    if (error) throw new Error(error.message);

    const patientIds = Array.from(new Set((cases ?? []).map((c) => c.patient_id).filter(Boolean))) as string[];
    const typeIds = Array.from(new Set((cases ?? []).map((c) => c.surgery_type_id).filter(Boolean))) as string[];

    const [{ data: patients }, { data: types }] = await Promise.all([
      patientIds.length
        ? supabase.from("patients").select("id, vezeteknev, keresztnev, taj, szuletesi_datum").in("id", patientIds)
        : Promise.resolve({ data: [] as { id: string; vezeteknev: string; keresztnev: string; taj: string | null; szuletesi_datum: string | null }[] }),
      typeIds.length
        ? supabase.from("surgery_types").select("id, nev, kod, kotelezo_muto_tipus, becsult_idotartam_perc, kiemelt, delegalas_kotelezo, operator_min_seniority, szukseges_skillek, kotelezo_eroforrasok").in("id", typeIds)
        : Promise.resolve({ data: [] as { id: string; nev: string; kod: string | null; kotelezo_muto_tipus: string | null; becsult_idotartam_perc: number; kiemelt: boolean; delegalas_kotelezo: boolean; operator_min_seniority: string | null; szukseges_skillek: string[] | null; kotelezo_eroforrasok: string[] | null }[] }),
    ]);

    type TypeRow = {
      id: string; nev: string; kod: string | null; kotelezo_muto_tipus: string | null;
      becsult_idotartam_perc: number; kiemelt: boolean; delegalas_kotelezo: boolean;
      operator_min_seniority: string | null;
      szukseges_skillek: string[] | null; kotelezo_eroforrasok: string[] | null;
    };
    const toArr = (v: unknown): string[] | null => (Array.isArray(v) ? (v as string[]) : null);
    const typesNorm: TypeRow[] = ((types ?? []) as Array<Record<string, unknown>>).map((t) => ({
      id: t.id as string,
      nev: t.nev as string,
      kod: (t.kod as string | null) ?? null,
      kotelezo_muto_tipus: (t.kotelezo_muto_tipus as string | null) ?? null,
      becsult_idotartam_perc: (t.becsult_idotartam_perc as number) ?? 0,
      kiemelt: Boolean(t.kiemelt),
      delegalas_kotelezo: Boolean(t.delegalas_kotelezo),
      operator_min_seniority: (t.operator_min_seniority as string | null) ?? null,
      szukseges_skillek: toArr(t.szukseges_skillek),
      kotelezo_eroforrasok: toArr(t.kotelezo_eroforrasok),
    }));

    let filtered = cases ?? [];
    if (data.search) {
      const term = data.search.toLowerCase();
      const pMap = new Map((patients ?? []).map((p) => [p.id, p] as const));
      filtered = filtered.filter((c) => {
        const p = c.patient_id ? pMap.get(c.patient_id) : null;
        const hay = [p?.vezeteknev, p?.keresztnev, p?.taj, c.megjegyzes, c.id].filter(Boolean).join(" ").toLowerCase();
        return hay.includes(term);
      });
    }

    const typeById = new Map(typesNorm.map((t) => [t.id, t]));
    const casesWithFlags = filtered.map((c) => {
      const t = c.surgery_type_id ? typeById.get(c.surgery_type_id) : null;
      const conflict_flags: string[] = [];
      const requirements: string[] = [];
      let delegation_required = false;
      if (t) {
        const effKiemelt = c.kiemelt || t.kiemelt;
        if (t.delegalas_kotelezo || effKiemelt) {
          delegation_required = true;
          if (!c.delegalt_operator_id) {
            conflict_flags.push("Kötelező delegált operatőr hiányzik");
          }
        }
        if (t.operator_min_seniority) {
          requirements.push(`Min. szint: ${t.operator_min_seniority}`);
        }
        if (t.szukseges_skillek && t.szukseges_skillek.length > 0) {
          requirements.push(`Skill: ${t.szukseges_skillek.join(", ")}`);
        }
        if (t.kotelezo_eroforrasok && t.kotelezo_eroforrasok.length > 0) {
          requirements.push(`Erőforrás: ${t.kotelezo_eroforrasok.join(", ")}`);
        }
      }
      return { ...c, conflict_flags, requirements, delegation_required };
    });

    return { cases: casesWithFlags, patients: patients ?? [], types: typesNorm };
  });

// ----- createCase -----
const CreateCaseInput = z.object({
  patient_id: z.string().uuid(),
  surgery_type_id: z.string().uuid().nullable().optional(),
  becsult_idotartam_perc: z.number().int().positive().max(1440),
  posztop_apolasi_perc: z.number().int().nonnegative().max(1440).optional(),
  prioritas: z.enum(["elektiv", "sürgos", "azonnali"]).default("elektiv"),
  megjegyzes: z.string().max(1000).nullable().optional(),
  kiemelt: z.boolean().optional(),
  delegalt_operator_id: z.string().uuid().nullable().optional(),
});

export const createCase = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => CreateCaseInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: prof } = await supabase.from("profiles").select("tenant_id").eq("id", userId).maybeSingle();
    if (!prof?.tenant_id) throw new Error("No tenant");

    const { data: hasPerm } = await supabase.rpc("has_permission", {
      _user_id: userId,
      _perm: "book_or_case",
    });
    if (!hasPerm) throw new Error("Nincs jogosultsága várólista-tétel létrehozására.");

    const { data: row, error } = await supabase
      .from("surgery_cases")
      .insert({
        tenant_id: prof.tenant_id,
        patient_id: data.patient_id,
        surgery_type_id: data.surgery_type_id ?? null,
        becsult_idotartam_perc: data.becsult_idotartam_perc,
        posztop_apolasi_perc: data.posztop_apolasi_perc ?? 0,
        prioritas: data.prioritas,
        statusz: "tervezett",
        megjegyzes: data.megjegyzes ?? null,
        kiemelt: data.kiemelt ?? false,
        delegalt_operator_id: data.delegalt_operator_id ?? null,
        created_by: userId,
      })
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    return { ok: true, id: row.id };
  });

// ----- updateCase -----
const UpdateCaseInput = z.object({
  id: z.string().uuid(),
  prioritas: z.enum(["elektiv", "sürgos", "azonnali"]).optional(),
  statusz: z.enum(["tervezett", "jovahagyott", "folyamatban", "elvegzett", "elhalasztott", "torolt"]).optional(),
  becsult_idotartam_perc: z.number().int().positive().max(1440).optional(),
  megjegyzes: z.string().max(1000).nullable().optional(),
  kiemelt: z.boolean().optional(),
  delegalt_operator_id: z.string().uuid().nullable().optional(),
});


export const updateCase = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => UpdateCaseInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { id, ...patch } = data;
    const { error } = await supabase.from("surgery_cases").update(patch).eq("id", id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// ----- approveCase -----
export const approveCase = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: hasPerm } = await supabase.rpc("has_permission", {
      _user_id: userId,
      _perm: "manage_or_blocks",
    });
    if (!hasPerm) throw new Error("Nincs jogosultsága jóváhagyni.");

    const { error } = await supabase
      .from("surgery_cases")
      .update({ statusz: "jovahagyott", jovahagyta_user_id: userId, jovahagyas_at: new Date().toISOString() })
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// ----- cancelCase -----
export const cancelCase = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid(), reason: z.string().max(500).optional() }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { error } = await supabase
      .from("surgery_cases")
      .update({ statusz: "torolt", megjegyzes: data.reason ?? null })
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// ----- searchPatients -----
export const searchPatients = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ term: z.string().min(1).max(100) }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const term = `%${data.term}%`;
    const { data: rows, error } = await supabase
      .from("patients")
      .select("id, vezeteknev, keresztnev, taj, szuletesi_datum")
      .or(`vezeteknev.ilike.${term},keresztnev.ilike.${term},taj.ilike.${term}`)
      .limit(20);
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

// ----- listSurgeryTypes -----
export const listSurgeryTypes = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase } = context;
    const { data, error } = await supabase
      .from("surgery_types")
      .select("id, nev, kod, becsult_idotartam_perc, posztop_apolasi_perc, kotelezo_muto_tipus")
      .eq("aktiv", true)
      .order("nev");
    if (error) throw new Error(error.message);
    return data ?? [];
  });

// ----- listSeniorOperators (for delegált operatőr select) -----
const SENIOR_ROLE_KEYS = ["szakorvos", "foorvos", "szakteruleti_expert", "vezetorezidens"];
export const listSeniorOperators = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const { data: prof } = await supabase.from("profiles").select("tenant_id").eq("id", userId).maybeSingle();
    if (!prof?.tenant_id) return [];
    const { data: roleRows } = await supabase
      .from("roles")
      .select("id, kulcs")
      .in("kulcs", SENIOR_ROLE_KEYS);
    const roleIds = (roleRows ?? []).map((r) => r.id);
    if (roleIds.length === 0) return [];
    const { data: urs } = await supabase
      .from("user_roles")
      .select("user_id, role_id")
      .in("role_id", roleIds);
    const userIds = Array.from(new Set((urs ?? []).map((u) => u.user_id)));
    if (userIds.length === 0) return [];
    const { data: profiles } = await supabase
      .from("profiles")
      .select("id, teljes_nev")
      .eq("tenant_id", prof.tenant_id)
      .in("id", userIds)
      .order("teljes_nev");
    return (profiles ?? []) as { id: string; teljes_nev: string | null }[];
  });


// ----- bulkImportCases -----
const BulkRow = z.object({
  taj: z.string().trim().min(1).max(20),
  surgery_type_kod: z.string().trim().max(50).nullable().optional(),
  becsult_idotartam_perc: z.number().int().positive().max(1440),
  posztop_apolasi_perc: z.number().int().nonnegative().max(1440).optional(),
  prioritas: z.enum(["elektiv", "sürgos", "azonnali"]).default("elektiv"),
  megjegyzes: z.string().max(1000).nullable().optional(),
});
const BulkInput = z.object({ rows: z.array(BulkRow).min(1).max(500) });

export type BulkImportResult = {
  created: number;
  errors: { row: number; taj: string; reason: string }[];
};

export const bulkImportCases = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => BulkInput.parse(d))
  .handler(async ({ data, context }): Promise<BulkImportResult> => {
    const { supabase, userId } = context;

    const { data: prof } = await supabase
      .from("profiles")
      .select("tenant_id")
      .eq("id", userId)
      .maybeSingle();
    if (!prof?.tenant_id) throw new Error("No tenant");

    const { data: hasPerm } = await supabase.rpc("has_permission", {
      _user_id: userId,
      _perm: "book_or_case",
    });
    if (!hasPerm) throw new Error("Nincs jogosultsága várólista-tétel létrehozására.");

    const tajList = Array.from(new Set(data.rows.map((r) => r.taj)));
    const kodList = Array.from(
      new Set(data.rows.map((r) => r.surgery_type_kod).filter(Boolean) as string[]),
    );

    const [{ data: patients }, { data: types }] = await Promise.all([
      supabase.from("patients").select("id, taj").in("taj", tajList),
      kodList.length
        ? supabase.from("surgery_types").select("id, kod").in("kod", kodList).eq("aktiv", true)
        : Promise.resolve({ data: [] as { id: string; kod: string | null }[] }),
    ]);

    const pMap = new Map((patients ?? []).map((p) => [p.taj, p.id]));
    const tMap = new Map((types ?? []).map((t) => [t.kod, t.id]));

    const errors: BulkImportResult["errors"] = [];
    const inserts: Array<{
      tenant_id: string;
      patient_id: string;
      surgery_type_id: string | null;
      becsult_idotartam_perc: number;
      posztop_apolasi_perc: number;
      prioritas: "elektiv" | "sürgos" | "azonnali";
      statusz: "tervezett";
      megjegyzes: string | null;
      created_by: string;
    }> = [];

    data.rows.forEach((r, idx) => {
      const pid = pMap.get(r.taj);
      if (!pid) {
        errors.push({ row: idx + 1, taj: r.taj, reason: "Páciens nem található TAJ alapján" });
        return;
      }
      let stId: string | null = null;
      if (r.surgery_type_kod) {
        const tid = tMap.get(r.surgery_type_kod);
        if (!tid) {
          errors.push({ row: idx + 1, taj: r.taj, reason: `Ismeretlen beavatkozás kód: ${r.surgery_type_kod}` });
          return;
        }
        stId = tid;
      }
      inserts.push({
        tenant_id: prof.tenant_id as string,
        patient_id: pid,
        surgery_type_id: stId,
        becsult_idotartam_perc: r.becsult_idotartam_perc,
        posztop_apolasi_perc: r.posztop_apolasi_perc ?? 0,
        prioritas: r.prioritas,
        statusz: "tervezett",
        megjegyzes: r.megjegyzes ?? null,
        created_by: userId,
      });
    });

    let created = 0;
    if (inserts.length) {
      const { error, count } = await supabase
        .from("surgery_cases")
        .insert(inserts, { count: "exact" });
      if (error) throw new Error(error.message);
      created = count ?? inserts.length;
    }
    return { created, errors };
  });

// ----- listOrOrgUnits (rooms used in OR planning) -----
export const listOrOrgUnits = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase } = context;
    const { data: rooms, error: rErr } = await supabase
      .from("or_room_profiles")
      .select("org_unit_id")
      .eq("aktiv", true);
    if (rErr) throw new Error(rErr.message);
    const ids = Array.from(new Set((rooms ?? []).map((r) => r.org_unit_id).filter(Boolean))) as string[];
    if (!ids.length) return [];
    const { data, error } = await supabase
      .from("org_units")
      .select("id, nev, tipus")
      .in("id", ids)
      .order("nev");
    if (error) throw new Error(error.message);
    return data ?? [];
  });

// ----- listSpecialties -----
export const listSpecialties = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase } = context;
    const { data, error } = await supabase
      .from("specialties")
      .select("id, nev")
      .order("nev");
    if (error) throw new Error(error.message);
    return data ?? [];
  });

// ----- createBlock -----
const CreateBlockInput = z.object({
  org_unit_id: z.string().uuid(),
  datum: z.string(),
  kezdo_ido: z.string(),
  veg_ido: z.string(),
  specialty_id: z.string().uuid().nullable().optional(),
  sebesz_user_id: z.string().uuid().nullable().optional(),
  megjegyzes: z.string().max(500).nullable().optional(),
});

export const createBlock = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => CreateBlockInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: hasPerm } = await supabase.rpc("has_permission", {
      _user_id: userId,
      _perm: "manage_or_blocks",
    });
    if (!hasPerm) throw new Error("Nincs jogosultsága blokk létrehozására.");

    const { data: prof } = await supabase.from("profiles").select("tenant_id").eq("id", userId).maybeSingle();
    if (!prof?.tenant_id) throw new Error("No tenant");

    if (data.kezdo_ido >= data.veg_ido) throw new Error("A vég-időnek a kezdő-idő után kell lennie.");

    const { data: row, error } = await supabase
      .from("or_blocks")
      .insert({
        tenant_id: prof.tenant_id,
        org_unit_id: data.org_unit_id,
        datum: data.datum,
        kezdo_ido: data.kezdo_ido,
        veg_ido: data.veg_ido,
        specialty_id: data.specialty_id ?? null,
        sebesz_user_id: data.sebesz_user_id ?? null,
        statusz: "allokalt",
        megjegyzes: data.megjegyzes ?? null,
        created_by: userId,
      })
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    return { ok: true, id: row.id };
  });

