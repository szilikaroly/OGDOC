import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/* eslint-disable @typescript-eslint/no-explicit-any */
type SB = any;

export type Section360Key =
  | "patient"
  | "encounters"
  | "diagnoses"
  | "therapies"
  | "vitals"
  | "labs"
  | "measurements"
  | "alerts"
  | "referrals"
  | "notes"
  | "questionnaires";

function toBase64(bytes: Uint8Array): string {
  let s = "";
  for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
  return btoa(s);
}

const fmt = (d?: string | null) => (d ? new Date(d).toLocaleString("hu-HU") : "—");
const fmtD = (d?: string | null) => (d ? new Date(d).toLocaleDateString("hu-HU") : "—");

export const generatePaciens360Pdf = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { patientId: string; sections: Section360Key[]; from?: string | null; to?: string | null }) => d)
  .handler(async ({ data, context }) => {
    const sb = context.supabase as SB;
    const pid = data.patientId;
    const set = new Set(data.sections);
    const from = data.from ?? null;
    const to = data.to ?? null;

    const dateFilter = (q: any, col: string) => {
      let r = q;
      if (from) r = r.gte(col, from);
      if (to) r = r.lte(col, to);
      return r;
    };

    const { data: p, error: pe } = await sb
      .from("patients")
      .select("id,taj,vezeteknev,keresztnev,szuletesi_datum,nem,anyja_neve,fo_diagnozis_bno")
      .eq("id", pid)
      .maybeSingle();
    if (pe) throw new Error(pe.message);
    if (!p) throw new Error("Páciens nem található vagy nincs jogosultság.");

    const sections: Array<{ title: string; rows: Array<Record<string, string>>; cols: Array<{ key: string; label: string; w: number }>; partial?: boolean }> = [];

    if (set.has("patient")) {
      sections.push({
        title: "Alapadatok",
        cols: [
          { key: "k", label: "Mező", w: 30 },
          { key: "v", label: "Érték", w: 70 },
        ],
        rows: [
          { k: "Név", v: `${p.vezeteknev ?? ""} ${p.keresztnev ?? ""}`.trim() },
          { k: "TAJ", v: p.taj ?? "—" },
          { k: "Születési dátum", v: p.szuletesi_datum ?? "—" },
          { k: "Nem", v: p.nem ?? "—" },
          { k: "Anyja neve", v: p.anyja_neve ?? "—" },
          { k: "Fő BNO", v: p.fo_diagnozis_bno ?? "—" },
        ],
      });
    }

    if (set.has("encounters")) {
      const { data: rows } = await dateFilter(
        sb.from("clinical_encounters").select("encounter_type,status,start_ts,end_ts,chief_complaint,location").eq("patient_id", pid).order("start_ts", { ascending: false }).limit(100),
        "start_ts",
      );
      sections.push({
        title: "Epizódok",
        cols: [
          { key: "t", label: "Típus", w: 15 },
          { key: "st", label: "Státusz", w: 15 },
          { key: "s", label: "Kezdet", w: 20 },
          { key: "e", label: "Vég", w: 20 },
          { key: "c", label: "Panasz/Hely", w: 30 },
        ],
        rows: (rows ?? []).map((r: any) => ({ t: r.encounter_type, st: r.status, s: fmt(r.start_ts), e: fmt(r.end_ts), c: r.chief_complaint ?? r.location ?? "" })),
      });
    }

    if (set.has("diagnoses")) {
      const { data: rows } = await sb
        .from("clinical_diagnoses")
        .select("icd10_code,display,is_primary,certainty,onset_date")
        .eq("patient_id", pid)
        .order("is_primary", { ascending: false })
        .limit(200);
      sections.push({
        title: "Diagnózisok",
        cols: [
          { key: "c", label: "BNO", w: 15 },
          { key: "d", label: "Megnevezés", w: 45 },
          { key: "p", label: "Fő", w: 10 },
          { key: "ce", label: "Biz.", w: 15 },
          { key: "o", label: "Kezdet", w: 15 },
        ],
        rows: (rows ?? []).map((r: any) => ({ c: r.icd10_code ?? "", d: r.display ?? "", p: r.is_primary ? "✓" : "", ce: r.certainty ?? "", o: fmtD(r.onset_date) })),
      });
    }

    if (set.has("therapies")) {
      const { data: rows } = await sb
        .from("clinical_therapy_orders")
        .select("display,dose,route,frequency,status,starts_on,ends_on")
        .eq("patient_id", pid)
        .order("created_at", { ascending: false })
        .limit(200);
      sections.push({
        title: "Terápia",
        cols: [
          { key: "d", label: "Készítmény", w: 35 },
          { key: "do", label: "Dózis", w: 15 },
          { key: "f", label: "Gyakoriság", w: 20 },
          { key: "st", label: "Státusz", w: 15 },
          { key: "p", label: "Időszak", w: 15 },
        ],
        rows: (rows ?? []).map((r: any) => ({ d: r.display ?? "", do: r.dose ?? "", f: r.frequency ?? "", st: r.status ?? "", p: `${fmtD(r.starts_on)}–${fmtD(r.ends_on)}` })),
      });
    }

    const obsCols = [
      { key: "n", label: "Paraméter", w: 35 },
      { key: "v", label: "Érték", w: 20 },
      { key: "u", label: "Egys.", w: 10 },
      { key: "i", label: "Int.", w: 10 },
      { key: "t", label: "Időpont", w: 25 },
    ];

    if (set.has("vitals")) {
      const { data: rows } = await dateFilter(
        sb.from("clinical_observations").select("code_display,loinc_code,value_quantity,value_string,value_unit,interpretation,effective_ts").eq("patient_id", pid).eq("category", "vital-signs").order("effective_ts", { ascending: false }).limit(200),
        "effective_ts",
      );
      sections.push({
        title: "Vitális paraméterek",
        cols: obsCols,
        rows: (rows ?? []).map((r: any) => ({ n: r.code_display ?? r.loinc_code ?? "", v: String(r.value_quantity ?? r.value_string ?? ""), u: r.value_unit ?? "", i: r.interpretation ?? "", t: fmt(r.effective_ts) })),
      });
    }

    if (set.has("labs")) {
      const { data: rows } = await dateFilter(
        sb.from("clinical_observations").select("code_display,loinc_code,value_quantity,value_string,value_unit,interpretation,effective_ts").eq("patient_id", pid).eq("category", "laboratory").order("effective_ts", { ascending: false }).limit(200),
        "effective_ts",
      );
      sections.push({
        title: "Labor",
        cols: obsCols,
        rows: (rows ?? []).map((r: any) => ({ n: r.code_display ?? r.loinc_code ?? "", v: String(r.value_quantity ?? r.value_string ?? ""), u: r.value_unit ?? "", i: r.interpretation ?? "", t: fmt(r.effective_ts) })),
      });
    }

    if (set.has("measurements")) {
      const { data: rows } = await dateFilter(
        sb.from("measurements").select("kind,ts,value,value2,unit").eq("patient_id", pid).order("ts", { ascending: false }).limit(200),
        "ts",
      );
      sections.push({
        title: "Otthoni mérések",
        cols: [
          { key: "k", label: "Típus", w: 20 },
          { key: "v", label: "Érték", w: 25 },
          { key: "u", label: "Egys.", w: 15 },
          { key: "t", label: "Időpont", w: 40 },
        ],
        rows: (rows ?? []).map((r: any) => ({ k: r.kind, v: `${r.value ?? ""}${r.value2 != null ? "/" + r.value2 : ""}`, u: r.unit ?? "", t: fmt(r.ts) })),
      });
    }

    if (set.has("alerts")) {
      const { data: rows } = await dateFilter(
        sb.from("clinical_critical_alerts").select("severity,source,code,message,triggered_at,acknowledged_at").eq("patient_id", pid).order("triggered_at", { ascending: false }).limit(200),
        "triggered_at",
      );
      sections.push({
        title: "Kritikus riasztások",
        cols: [
          { key: "s", label: "Súly", w: 12 },
          { key: "src", label: "Forrás", w: 15 },
          { key: "c", label: "Kód", w: 13 },
          { key: "m", label: "Üzenet", w: 35 },
          { key: "t", label: "Időpont", w: 15 },
          { key: "a", label: "Nyugt.", w: 10 },
        ],
        rows: (rows ?? []).map((r: any) => ({ s: r.severity, src: r.source ?? "", c: r.code ?? "", m: r.message ?? "", t: fmt(r.triggered_at), a: r.acknowledged_at ? "✓" : "" })),
      });
    }

    if (set.has("referrals")) {
      const { data: rows } = await dateFilter(
        sb.from("patient_referral_requests").select("request_type,specialty,reason,status,created_at").eq("patient_id", pid).order("created_at", { ascending: false }).limit(100),
        "created_at",
      );
      sections.push({
        title: "Beutalók / receptek",
        cols: [
          { key: "t", label: "Típus", w: 15 },
          { key: "sp", label: "Szakma", w: 20 },
          { key: "r", label: "Indok", w: 35 },
          { key: "st", label: "Státusz", w: 15 },
          { key: "c", label: "Beadva", w: 15 },
        ],
        rows: (rows ?? []).map((r: any) => ({ t: r.request_type ?? "", sp: r.specialty ?? "", r: r.reason ?? "", st: r.status ?? "", c: fmtD(r.created_at) })),
      });
    }

    if (set.has("notes")) {
      const { data: rows } = await dateFilter(
        sb.from("clinical_notes").select("title,kind,ai_generated,signed_at,created_at").eq("patient_id", pid).order("created_at", { ascending: false }).limit(100),
        "created_at",
      );
      sections.push({
        title: "Klinikai jegyzetek",
        cols: [
          { key: "t", label: "Cím", w: 45 },
          { key: "k", label: "Típus", w: 15 },
          { key: "ai", label: "AI", w: 10 },
          { key: "s", label: "Státusz", w: 15 },
          { key: "c", label: "Létrehozva", w: 15 },
        ],
        rows: (rows ?? []).map((r: any) => ({ t: r.title ?? "", k: r.kind ?? "", ai: r.ai_generated ? "✓" : "", s: r.signed_at ? "aláírva" : "vázlat", c: fmtD(r.created_at) })),
      });
    }

    if (set.has("questionnaires")) {
      const { data: rows } = await dateFilter(
        sb.from("questionnaire_assignments").select("status,due_at,created_at").eq("patient_id", pid).order("created_at", { ascending: false }).limit(100),
        "created_at",
      );
      sections.push({
        title: "Kérdőívek",
        cols: [
          { key: "st", label: "Státusz", w: 30 },
          { key: "d", label: "Határidő", w: 35 },
          { key: "c", label: "Létrehozva", w: 35 },
        ],
        rows: (rows ?? []).map((r: any) => ({ st: r.status ?? "", d: fmtD(r.due_at), c: fmtD(r.created_at) })),
      });
    }

    // Detect partial / truncated sections by comparing row count to known limit
    const SECTION_LIMITS: Record<string, number> = {
      "Epizódok": 100,
      "Diagnózisok": 200,
      "Terápia": 200,
      "Vitális paraméterek": 200,
      "Labor": 200,
      "Otthoni mérések": 200,
      "Kritikus riasztások": 200,
      "Beutalók / receptek": 100,
      "Klinikai jegyzetek": 100,
      "Kérdőívek": 100,
    };
    const partialReasons: string[] = [];
    for (const sec of sections) {
      const lim = SECTION_LIMITS[sec.title];
      if (lim != null && sec.rows.length >= lim) {
        sec.partial = true;
        partialReasons.push(`A „${sec.title}” szakasz a felső korlátot (${lim} sor) elérte; lehet, hogy nem minden tétel látszik.`);
      }
    }
    partialReasons.push(
      "A jelentés csak azokat a rekordokat tartalmazza, amelyeket az ön szerepköre RLS szabályok szerint olvashat.",
    );
    if (from || to) {
      partialReasons.push("A megadott dátumtartomány az adatokat tovább szűkíti — a jelentés nem a teljes előzményt mutatja.");
    }

    const generatedAt = new Date().toISOString();
    const dataVersion = `${generatedAt.slice(0, 19).replace("T", " ")}Z`;

    const { renderPaciens360Pdf } = await import("./paciens-360-pdf.server");
    const range = from || to ? ` · ${from ?? "…"} – ${to ?? "…"}` : "";
    const bytes = await renderPaciens360Pdf({
      title: "Páciens 360 jelentés",
      subtitle: `${p.vezeteknev ?? ""} ${p.keresztnev ?? ""} · TAJ: ${p.taj ?? "—"} · ${new Date().toLocaleString("hu-HU")}${range}`,
      sections,
      meta: {
        generatedAt: new Date().toLocaleString("hu-HU"),
        dataVersion,
        rlsScope: `user:${context.userId}`,
        partialReasons,
      },
    });
    return {
      pdf: toBase64(bytes),
      filename: `paciens-360-${p.vezeteknev ?? ""}-${p.keresztnev ?? ""}-${new Date().toISOString().slice(0, 10)}.pdf`.replace(/\s+/g, "_"),
      meta: { generatedAt, dataVersion, partialReasons },
    };
  });

export const ALERT_STATUSES = [
  "open",
  "acknowledged",
  "escalated",
  "documented",
  "resolved",
] as const;
export type AlertStatus = (typeof ALERT_STATUSES)[number];

export const acknowledgeCriticalAlert = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { alertId: string }) => d)
  .handler(async ({ data, context }) => {
    const sb = context.supabase as SB;
    const { error } = await sb
      .from("clinical_critical_alerts")
      .update({
        acknowledged_at: new Date().toISOString(),
        acknowledged_by: context.userId,
        workflow_status: "acknowledged",
      })
      .eq("id", data.alertId);
    if (error) throw new Error(error.message);
    await sb.from("clinical_alert_status_log").insert({
      alert_id: data.alertId,
      actor_id: context.userId,
      from_status: null,
      to_status: "acknowledged",
      note: null,
    });
    return { ok: true };
  });

export const updateAlertWorkflowStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { alertId: string; toStatus: AlertStatus; note?: string | null }) => d)
  .handler(async ({ data, context }) => {
    const sb = context.supabase as SB;
    if (!ALERT_STATUSES.includes(data.toStatus)) {
      throw new Error("Érvénytelen státusz.");
    }
    const { data: cur, error: ce } = await sb
      .from("clinical_critical_alerts")
      .select("workflow_status,acknowledged_at")
      .eq("id", data.alertId)
      .maybeSingle();
    if (ce) throw new Error(ce.message);
    const from = (cur?.workflow_status as string | null) ?? "open";
    const patch: Record<string, unknown> = { workflow_status: data.toStatus };
    if (
      (data.toStatus === "acknowledged" || data.toStatus === "escalated" || data.toStatus === "resolved") &&
      !cur?.acknowledged_at
    ) {
      patch.acknowledged_at = new Date().toISOString();
      patch.acknowledged_by = context.userId;
    }
    const { error: ue } = await sb
      .from("clinical_critical_alerts")
      .update(patch)
      .eq("id", data.alertId);
    if (ue) throw new Error(ue.message);
    const { error: le } = await sb.from("clinical_alert_status_log").insert({
      alert_id: data.alertId,
      actor_id: context.userId,
      from_status: from,
      to_status: data.toStatus,
      note: data.note ?? null,
    });
    if (le) throw new Error(le.message);
    return { ok: true };
  });

export const listAlertStatusLog = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { alertId: string }) => d)
  .handler(async ({ data, context }) => {
    const sb = context.supabase as SB;
    const { data: rows, error } = await sb
      .from("clinical_alert_status_log")
      .select("id,from_status,to_status,note,actor_id,created_at")
      .eq("alert_id", data.alertId)
      .order("created_at", { ascending: false })
      .limit(100);
    if (error) throw new Error(error.message);
    return (rows ?? []) as Array<{
      id: string;
      from_status: string | null;
      to_status: string;
      note: string | null;
      actor_id: string | null;
      created_at: string;
    }>;
  });

/* ---------------- Saved views (kedvencek) ---------------- */

export type SavedView = {
  id: string;
  patient_id: string | null;
  name: string;
  filters: Record<string, any>;
  is_default: boolean;
  created_at: string;
};

export const listSavedViews = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { patientId?: string | null }) => d)
  .handler(async ({ data, context }) => {
    const sb = context.supabase as SB;
    let q = sb
      .from("paciens_360_saved_views")
      .select("id,patient_id,name,filters,is_default,created_at")
      .eq("user_id", context.userId)
      .order("is_default", { ascending: false })
      .order("created_at", { ascending: false });
    if (data.patientId) {
      q = q.or(`patient_id.is.null,patient_id.eq.${data.patientId}`);
    }
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    return (rows ?? []) as SavedView[];
  });

export const saveSavedView = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { id?: string; patientId?: string | null; name: string; filters: Record<string, any>; isDefault?: boolean }) => d)
  .handler(async ({ data, context }) => {
    const sb = context.supabase as SB;
    const name = data.name.trim();
    if (!name) throw new Error("Adj nevet a nézetnek.");
    if (data.isDefault) {
      await sb
        .from("paciens_360_saved_views")
        .update({ is_default: false })
        .eq("user_id", context.userId);
    }
    if (data.id) {
      const { error } = await sb
        .from("paciens_360_saved_views")
        .update({ name, filters: data.filters, is_default: !!data.isDefault })
        .eq("id", data.id)
        .eq("user_id", context.userId);
      if (error) throw new Error(error.message);
      return { id: data.id };
    }
    const { data: row, error } = await sb
      .from("paciens_360_saved_views")
      .insert({
        user_id: context.userId,
        patient_id: data.patientId ?? null,
        name,
        filters: data.filters,
        is_default: !!data.isDefault,
      })
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    return { id: (row as { id: string }).id };
  });

export const deleteSavedView = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { id: string }) => d)
  .handler(async ({ data, context }) => {
    const sb = context.supabase as SB;
    const { error } = await sb
      .from("paciens_360_saved_views")
      .delete()
      .eq("id", data.id)
      .eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/* ---------------- Escalation rules ---------------- */

export type EscalationRule = {
  id: string;
  name: string;
  severity: string | null;
  source: string | null;
  escalate_after_minutes: number;
  target_role: string | null;
  active: boolean;
  created_at: string;
};

export const listEscalationRules = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const sb = context.supabase as SB;
    const { data, error } = await sb
      .from("clinical_alert_escalation_rules")
      .select("id,name,severity,source,escalate_after_minutes,target_role,active,created_at")
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return (data ?? []) as EscalationRule[];
  });

export const upsertEscalationRule = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: {
    id?: string;
    name: string;
    severity?: string | null;
    source?: string | null;
    escalateAfterMinutes: number;
    targetRole?: string | null;
    active: boolean;
  }) => d)
  .handler(async ({ data, context }) => {
    const sb = context.supabase as SB;
    if (!data.name.trim()) throw new Error("Adj nevet a szabálynak.");
    if (data.escalateAfterMinutes < 1) throw new Error("Az eszkalációs idő legalább 1 perc.");
    const { data: prof } = await sb
      .from("profiles")
      .select("tenant_id")
      .eq("id", context.userId)
      .maybeSingle();
    const tenantId = (prof as { tenant_id?: string } | null)?.tenant_id;
    if (!tenantId) throw new Error("Nincs tenant.");
    const payload = {
      tenant_id: tenantId,
      name: data.name.trim(),
      severity: data.severity ?? null,
      source: data.source ?? null,
      escalate_after_minutes: data.escalateAfterMinutes,
      target_role: data.targetRole ?? null,
      active: data.active,
    };
    if (data.id) {
      const { error } = await sb
        .from("clinical_alert_escalation_rules")
        .update(payload)
        .eq("id", data.id);
      if (error) throw new Error(error.message);
      return { id: data.id };
    }
    const { data: row, error } = await sb
      .from("clinical_alert_escalation_rules")
      .insert({ ...payload, created_by: context.userId })
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    return { id: (row as { id: string }).id };
  });

export const deleteEscalationRule = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { id: string }) => d)
  .handler(async ({ data, context }) => {
    const sb = context.supabase as SB;
    const { error } = await sb
      .from("clinical_alert_escalation_rules")
      .delete()
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/* ---------------- Escalation cron monitoring & manual run ---------------- */

async function assertAdmin(sb: SB, userId: string) {
  const { data, error } = await sb.rpc("has_role", { _user_id: userId, _role_kulcs: "tenant_admin" });
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Csak admin férhet hozzá.");
}

export const getEscalationCronStatus = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context.supabase as SB, context.userId);
    const { getEscalationCronStats } = await import("./escalation.server");
    return getEscalationCronStats();
  });

export const runEscalationNow = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context.supabase as SB, context.userId);
    const { runEscalationOnce } = await import("./escalation.server");
    return runEscalationOnce({ notePrefix: "Manuális teljes futtatás" });
  });

export const listOpenAlertsForTest = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { severity?: string | null; source?: string | null; limit?: number }) => d)
  .handler(async ({ data, context }) => {
    const sb = context.supabase as SB;
    let q = sb
      .from("clinical_critical_alerts")
      .select("id, severity, source, code, message, triggered_at, workflow_status, patient_id, patients!inner(vezeteknev, keresztnev, taj)")
      .or("workflow_status.is.null,workflow_status.eq.open,workflow_status.eq.acknowledged")
      .order("triggered_at", { ascending: false })
      .limit(Math.min(data.limit ?? 25, 100));
    if (data.severity) q = q.eq("severity", data.severity);
    if (data.source) q = q.eq("source", data.source);
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    return (rows ?? []) as Array<{
      id: string; severity: string; source: string; code: string | null; message: string | null;
      triggered_at: string; workflow_status: string | null; patient_id: string;
      patients: { vezeteknev: string | null; keresztnev: string | null; taj: string | null };
    }>;
  });

export const testEscalationRuleOnAlert = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { ruleId: string; alertId: string }) => d)
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase as SB, context.userId);
    const { runEscalationOnce } = await import("./escalation.server");
    return runEscalationOnce({
      ruleIds: [data.ruleId],
      alertId: data.alertId,
      force: true,
      notePrefix: "TESZT futtatás",
    });
  });
