/* eslint-disable @typescript-eslint/no-explicit-any */
import { supabaseAdmin } from "@/integrations/supabase/client.server";

export type EscalationRunOptions = {
  ruleIds?: string[] | null;
  alertId?: string | null;
  /** When true, ignores `escalate_after_minutes` (manual/test mode). */
  force?: boolean;
  notePrefix?: string;
};

export type EscalationRunResult = {
  rules_evaluated: number;
  escalated: number;
  errors: string[];
  ran_at: string;
};

type Rule = {
  id: string;
  tenant_id: string | null;
  name: string;
  severity: string | null;
  source: string | null;
  escalate_after_minutes: number;
  target_role: string | null;
};

export async function runEscalationOnce(opts: EscalationRunOptions = {}): Promise<EscalationRunResult> {
  const errors: string[] = [];
  let escalated = 0;

  let rq: any = supabaseAdmin
    .from("clinical_alert_escalation_rules")
    .select("id, tenant_id, name, severity, source, escalate_after_minutes, target_role, active")
    .eq("active", true);
  if (opts.ruleIds && opts.ruleIds.length > 0) rq = rq.in("id", opts.ruleIds);

  const { data: rules, error: rulesErr } = await rq;
  if (rulesErr) throw new Error(rulesErr.message);
  const ruleList = (rules ?? []) as Rule[];

  for (const rule of ruleList) {
    let q: any = supabaseAdmin
      .from("clinical_critical_alerts")
      .select("id, patient_id, workflow_status, severity, source, triggered_at, patients!inner(tenant_id)")
      .or("workflow_status.is.null,workflow_status.eq.open,workflow_status.eq.acknowledged")
      .is("escalated_at", null);
    if (!opts.force) {
      const cutoff = new Date(Date.now() - rule.escalate_after_minutes * 60_000).toISOString();
      q = q.lt("triggered_at", cutoff);
    }
    if (opts.alertId) q = q.eq("id", opts.alertId);
    if (rule.tenant_id) q = q.eq("patients.tenant_id", rule.tenant_id);
    if (rule.severity) q = q.eq("severity", rule.severity);
    if (rule.source) q = q.eq("source", rule.source);

    const { data: matches, error: mErr } = await q.limit(500);
    if (mErr) { errors.push(`rule ${rule.id}: ${mErr.message}`); continue; }

    for (const a of (matches ?? []) as Array<{ id: string; workflow_status: string | null }>) {
      const fromStatus = a.workflow_status ?? "open";
      const nowIso = new Date().toISOString();
      const { error: uErr } = await supabaseAdmin
        .from("clinical_critical_alerts")
        .update({ workflow_status: "escalated", escalated_at: nowIso })
        .eq("id", a.id);
      if (uErr) { errors.push(`alert ${a.id}: ${uErr.message}`); continue; }
      const noteBase = opts.notePrefix ?? "Automatikus eszkaláció";
      const { error: lErr } = await supabaseAdmin
        .from("clinical_alert_status_log")
        .insert({
          alert_id: a.id,
          actor_id: null,
          from_status: fromStatus,
          to_status: "escalated",
          note: `${noteBase} · szabály: ${rule.name} (${rule.escalate_after_minutes} perc)`,
        });
      if (lErr) errors.push(`log ${a.id}: ${lErr.message}`);
      escalated++;
    }
  }

  return { rules_evaluated: ruleList.length, escalated, errors, ran_at: new Date().toISOString() };
}

export async function getEscalationCronStats() {
  // Job row
  const { data: jobRows, error: jobErr } = await (supabaseAdmin as any)
    .schema("cron")
    .from("job")
    .select("jobid, schedule, command, active, jobname")
    .eq("jobname", "escalate-alerts-every-5min");
  if (jobErr) throw new Error(jobErr.message);
  const job = (jobRows ?? [])[0] as
    | { jobid: number; schedule: string; command: string; active: boolean; jobname: string }
    | undefined;

  let recent: Array<{ start_time: string; end_time: string | null; status: string; return_message: string | null }> = [];
  if (job) {
    const { data: runs, error: rErr } = await (supabaseAdmin as any)
      .schema("cron")
      .from("job_run_details")
      .select("start_time, end_time, status, return_message")
      .eq("jobid", job.jobid)
      .order("start_time", { ascending: false })
      .limit(20);
    if (rErr) throw new Error(rErr.message);
    recent = (runs ?? []) as typeof recent;
  }

  // Compute next run estimate from "*/N * * * *" schedule
  let nextRunIso: string | null = null;
  if (job?.schedule) {
    const m = job.schedule.match(/^\*\/(\d+)\s+\*\s+\*\s+\*\s+\*$/);
    if (m) {
      const step = parseInt(m[1], 10);
      const now = new Date();
      const min = now.getUTCMinutes();
      const add = step - (min % step);
      const next = new Date(now);
      next.setUTCSeconds(0, 0);
      next.setUTCMinutes(min + add);
      nextRunIso = next.toISOString();
    }
  }

  // Alerts touched in the last run window
  const lastStart = recent[0]?.start_time ?? null;
  const prevStart = recent[1]?.start_time ?? null;
  let lastRunEscalated = 0;
  if (lastStart) {
    const { count } = await (supabaseAdmin as any)
      .from("clinical_alert_status_log")
      .select("id", { count: "exact", head: true })
      .eq("to_status", "escalated")
      .is("actor_id", null)
      .gte("created_at", prevStart ?? lastStart);
    lastRunEscalated = count ?? 0;
  }

  // Last 24h total
  const dayAgo = new Date(Date.now() - 24 * 3600_000).toISOString();
  const { count: day } = await (supabaseAdmin as any)
    .from("clinical_alert_status_log")
    .select("id", { count: "exact", head: true })
    .eq("to_status", "escalated")
    .is("actor_id", null)
    .gte("created_at", dayAgo);

  return {
    job: job
      ? { jobid: job.jobid, jobname: job.jobname, schedule: job.schedule, active: job.active }
      : null,
    recent,
    nextRunIso,
    lastRunEscalated,
    escalatedLast24h: day ?? 0,
  };
}
