/**
 * Szerveroldali PDF: Páciens 360 jelentés.
 * Csak server function .handler-ben dinamikus importtal.
 */
import React from "react";
import { Document, Page, Text, View, StyleSheet, renderToBuffer } from "@react-pdf/renderer";

const s = StyleSheet.create({
  page: { padding: 36, fontSize: 10, fontFamily: "Helvetica", color: "#111827" },
  h1: { fontSize: 16, fontWeight: 700, color: "#0f766e", marginBottom: 4 },
  meta: { fontSize: 9, color: "#6b7280", marginBottom: 10 },
  h2: { fontSize: 12, fontWeight: 700, marginTop: 12, marginBottom: 4, color: "#0f766e" },
  row: { flexDirection: "row", borderBottomWidth: 0.5, borderColor: "#e5e7eb", paddingVertical: 3 },
  cell: { fontSize: 9, paddingRight: 6 },
  muted: { color: "#6b7280" },
  empty: { fontSize: 9, color: "#6b7280", fontStyle: "italic" },
  metaBox: { marginTop: 6, padding: 6, borderWidth: 0.5, borderColor: "#d1d5db", borderRadius: 3, backgroundColor: "#f9fafb" },
  metaLine: { fontSize: 8, color: "#374151", marginBottom: 1 },
  partial: { marginTop: 4, padding: 6, borderWidth: 0.5, borderColor: "#f59e0b", borderRadius: 3, backgroundColor: "#fffbeb" },
  partialTitle: { fontSize: 9, color: "#b45309", fontWeight: 700, marginBottom: 2 },
  partialText: { fontSize: 8, color: "#92400e" },
  secPartial: { fontSize: 8, color: "#b45309", marginTop: 2, fontStyle: "italic" },
  footer: { position: "absolute", bottom: 20, left: 36, right: 36, fontSize: 7, color: "#9ca3af", textAlign: "center", borderTopWidth: 0.5, borderColor: "#e5e7eb", paddingTop: 4 },
});


type Sec = { title: string; rows: Array<Record<string, string>>; cols: Array<{ key: string; label: string; w: number }>; partial?: boolean };

export type Paciens360PdfInput = {
  title: string;
  subtitle: string;
  sections: Sec[];
  meta: {
    generatedAt: string;
    dataVersion: string;
    rlsScope: string;
    partialReasons: string[];
  };
};

export async function renderPaciens360Pdf(opts: Paciens360PdfInput): Promise<Uint8Array> {
  const metaBox = React.createElement(
    View,
    { style: s.metaBox },
    React.createElement(Text, { style: s.metaLine }, `Generálva: ${opts.meta.generatedAt}`),
    React.createElement(Text, { style: s.metaLine }, `Adatverzió: ${opts.meta.dataVersion}`),
    React.createElement(Text, { style: s.metaLine }, `Hozzáférési szint: ${opts.meta.rlsScope}`),
  );

  const partialBox =
    opts.meta.partialReasons.length > 0
      ? React.createElement(
          View,
          { style: s.partial },
          React.createElement(Text, { style: s.partialTitle }, "⚠ Részleges adat"),
          ...opts.meta.partialReasons.map((r, i) =>
            React.createElement(Text, { key: i, style: s.partialText }, `• ${r}`),
          ),
        )
      : null;

  const doc = React.createElement(
    Document,
    null,
    React.createElement(
      Page,
      { size: "A4", style: s.page },
      React.createElement(Text, { style: s.h1 }, opts.title),
      React.createElement(Text, { style: s.meta }, opts.subtitle),
      metaBox,
      partialBox,
      ...opts.sections.map((sec, i) =>
        React.createElement(
          View,
          { key: i, wrap: false },
          React.createElement(Text, { style: s.h2 }, sec.title),
          sec.partial
            ? React.createElement(
                Text,
                { style: s.secPartial },
                `(részleges – csak az első ${sec.rows.length} sor jelenik meg)`,
              )
            : null,
          sec.rows.length === 0
            ? React.createElement(Text, { style: s.empty }, "Nincs adat.")
            : React.createElement(
                View,
                null,
                React.createElement(
                  View,
                  { style: s.row },
                  ...sec.cols.map((c) =>
                    React.createElement(
                      Text,
                      { key: c.key, style: [s.cell, s.muted, { width: `${c.w}%` }] },
                      c.label.toUpperCase(),
                    ),
                  ),
                ),
                ...sec.rows.map((r, ri) =>
                  React.createElement(
                    View,
                    { key: ri, style: s.row },
                    ...sec.cols.map((c) =>
                      React.createElement(
                        Text,
                        { key: c.key, style: [s.cell, { width: `${c.w}%` }] },
                        r[c.key] ?? "—",
                      ),
                    ),
                  ),
                ),
              ),
        ),
      ),
      React.createElement(
        Text,
        { style: s.footer, fixed: true, render: ({ pageNumber, totalPages }: { pageNumber: number; totalPages: number }) =>
          `Páciens 360 · v${opts.meta.dataVersion} · ${opts.meta.generatedAt} · oldal ${pageNumber}/${totalPages}` },
      ),
    ),
  );
  return await renderToBuffer(doc);
}

