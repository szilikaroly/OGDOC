import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const TranslateInput = z.object({
  message_id: z.string().uuid(),
  target_lang: z.string().min(2).max(8),
});

export const translateMessage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => TranslateInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    if (data.target_lang === "hu") return { translation: null, cached: false };

    const { data: existing } = await supabase
      .from("message_translations")
      .select("translated_text")
      .eq("message_id", data.message_id)
      .eq("lang", data.target_lang)
      .maybeSingle();
    if (existing?.translated_text) return { translation: existing.translated_text, cached: true };

    const { data: msg } = await supabase
      .from("messages")
      .select("body, source_lang")
      .eq("id", data.message_id)
      .maybeSingle();
    if (!msg?.body) return { translation: null, cached: false };
    if (msg.source_lang && msg.source_lang === data.target_lang) {
      return { translation: msg.body, cached: false };
    }

    const key = process.env.LOVABLE_API_KEY;
    if (!key) throw new Error("Missing LOVABLE_API_KEY");
    const { createLovableAiGatewayProvider } = await import("@/lib/ai-gateway.server");
    const { generateText } = await import("ai");
    const gateway = createLovableAiGatewayProvider(key);
    const model = gateway("google/gemini-3-flash-preview");
    const langNames: Record<string, string> = {
      en: "English", de: "German", ro: "Romanian", sk: "Slovak", sr: "Serbian",
      uk: "Ukrainian", ru: "Russian", zh: "Chinese", fil: "Filipino", hu: "Hungarian",
    };
    const { text } = await generateText({
      model,
      system: `You are a precise medical chat translator. Translate the user's message to ${langNames[data.target_lang] ?? data.target_lang}. Preserve names, dates, numbers, units, medication names. Output ONLY the translation, no preface, no quotes.`,
      prompt: msg.body,
    });
    const translation = text.trim();
    await supabase.from("message_translations").insert({
      message_id: data.message_id,
      lang: data.target_lang,
      translated_text: translation,
      model: "google/gemini-3-flash-preview",
    });
    return { translation, cached: false };
  });

const TranscribeInput = z.object({ attachment_id: z.string().uuid() });
export const transcribeAttachment = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => TranscribeInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { data: att, error } = await supabase
      .from("message_attachments")
      .select("id, storage_path, mime, transcript")
      .eq("id", data.attachment_id)
      .maybeSingle();
    if (error || !att) throw new Error("Csatolmány nem található");
    if (att.transcript) return { transcript: att.transcript, cached: true };

    const { data: signed } = await supabase.storage
      .from("chat-attachments")
      .createSignedUrl(att.storage_path, 300);
    if (!signed) throw new Error("Nem sikerült URL-t kérni a hangfájlhoz");

    const audioRes = await fetch(signed.signedUrl);
    if (!audioRes.ok) throw new Error("Nem sikerült letölteni a hangfájlt");
    const audioBlob = await audioRes.blob();

    const key = process.env.LOVABLE_API_KEY;
    if (!key) throw new Error("Missing LOVABLE_API_KEY");

    const ext = ({
      "audio/webm": "webm", "audio/mp4": "m4a", "audio/mpeg": "mp3", "audio/mp3": "mp3",
      "audio/wav": "wav", "audio/ogg": "ogg", "audio/m4a": "m4a",
    } as Record<string, string>)[att.mime] ?? "webm";

    const form = new FormData();
    form.append("model", "openai/gpt-4o-mini-transcribe");
    form.append("file", audioBlob, `recording.${ext}`);

    const r = await fetch("https://ai.gateway.lovable.dev/v1/audio/transcriptions", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}` },
      body: form,
    });
    if (!r.ok) throw new Error(`Átirat hiba: ${r.status} ${await r.text().catch(() => "")}`);
    const json = (await r.json()) as { text?: string };
    const transcript = (json.text ?? "").trim();
    await supabase
      .from("message_attachments")
      .update({ transcript, ai_summary_status: "done" })
      .eq("id", att.id);
    return { transcript, cached: false };
  });

const SummarizeInput = z.object({ attachment_id: z.string().uuid() });
export const summarizeAttachment = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => SummarizeInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { data: att } = await supabase
      .from("message_attachments")
      .select("id, storage_path, mime, kind, ai_summary, original_name")
      .eq("id", data.attachment_id)
      .maybeSingle();
    if (!att) throw new Error("Csatolmány nem található");
    if (att.ai_summary) return { summary: att.ai_summary, cached: true };
    if (att.kind !== "pdf" && att.kind !== "spreadsheet") {
      return { summary: null, cached: false };
    }

    const { data: signed } = await supabase.storage
      .from("chat-attachments")
      .createSignedUrl(att.storage_path, 300);
    if (!signed) throw new Error("Nem sikerült URL-t kérni a fájlhoz");
    const fileRes = await fetch(signed.signedUrl);
    if (!fileRes.ok) throw new Error("Nem sikerült letölteni a fájlt");

    const key = process.env.LOVABLE_API_KEY;
    if (!key) throw new Error("Missing LOVABLE_API_KEY");
    const { createLovableAiGatewayProvider } = await import("@/lib/ai-gateway.server");
    const { generateText } = await import("ai");
    const gateway = createLovableAiGatewayProvider(key);
    const model = gateway("google/gemini-3-flash-preview");

    let summary = "";
    try {
      if (att.kind === "pdf") {
        const buf = await fileRes.arrayBuffer();
        const { text } = await generateText({
          model,
          messages: [
            {
              role: "user",
              content: [
                { type: "text", text: `Foglald össze tömören, magyar nyelven, max 8 felsoroláspontban a csatolt PDF dokumentum tartalmát (${att.original_name}). Emelj ki dátumokat, gyógyszerneveket, dózisokat, leletek főbb értékeit, diagnózisokat. Ne találj ki adatot.` },
                { type: "file", data: new Uint8Array(buf), mediaType: "application/pdf", filename: att.original_name },
              ],
            },
          ],
        });
        summary = text.trim();
      } else {

        const buf = await fileRes.arrayBuffer();
        const XLSX = await import("xlsx");
        const wb = XLSX.read(buf, { type: "array" });
        const previewParts: string[] = [];
        for (const name of wb.SheetNames.slice(0, 5)) {
          const sheet = wb.Sheets[name];
          const json = XLSX.utils.sheet_to_json(sheet, { header: 1, blankrows: false }) as unknown[][];
          const top = json.slice(0, 50);
          previewParts.push(`### ${name}\n${top.map((r) => (r as unknown[]).slice(0, 12).join("\t")).join("\n")}`);
        }
        const preview = previewParts.join("\n\n").slice(0, 12000);
        const { text } = await generateText({
          model,
          system: "Adatfájl-elemző asszisztens vagy. Foglald össze magyarul, tömören, max 8 felsoroláspontban a táblázat tartalmát: oszlopok, sorok száma, fő minták, kiugró értékek, lehetséges célja.",
          prompt: `Fájl: ${att.original_name}\n\nElőnézet (első sorok):\n${preview}`,
        });
        summary = text.trim();
      }
      await supabase
        .from("message_attachments")
        .update({ ai_summary: summary, ai_summary_status: "done", ai_summary_lang: "hu" })
        .eq("id", att.id);
      return { summary, cached: false };
    } catch (e) {
      await supabase
        .from("message_attachments")
        .update({ ai_summary_status: "failed" })
        .eq("id", att.id);
      throw e;
    }
  });
