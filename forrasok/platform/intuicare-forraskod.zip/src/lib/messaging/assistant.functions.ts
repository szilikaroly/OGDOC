import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const AskInput = z.object({
  conversation_id: z.string().uuid(),
  question: z.string().min(1).max(2000),
  patient_id: z.string().uuid().nullable().optional(),
});

/**
 * AI előjegyzés-asszisztens — egyszerű v1: a beteg saját előzményeinek keresése,
 * orvos-javaslat a leggyakoribb gondozó alapján, és szabad slot-ok listázása.
 * A tényleges foglalás külön server fn-en keresztül történik (lásd `bookAssistantSlot`),
 * a UI-ban a felhasználó megerősítésével.
 */
export const askAssistant = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => AskInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase } = context;

    const patientId = data.patient_id ?? null;
    let historySummary = "";
    let suggestedProviderId: string | null = null;
    let availableSlots: Array<{ id: string; starts_at: string; provider_name: string | null }> = [];

    if (patientId) {
      const { data: encs } = await supabase
        .from("patient_encounters")
        .select("id, ellatas_kezdete, bno_kodok, osszefoglalo, vezeto_orvos_id")
        .eq("patient_id", patientId)
        .order("ellatas_kezdete", { ascending: false })
        .limit(20);
      const list = encs ?? [];
      historySummary = list
        .map((e) => `- ${e.ellatas_kezdete?.slice(0, 10) ?? "?"} • ${(e.bno_kodok ?? []).join(",")} • ${e.osszefoglalo ?? ""}`)
        .join("\n");

      const counts = new Map<string, number>();
      for (const e of list) {
        if (e.vezeto_orvos_id) counts.set(e.vezeto_orvos_id, (counts.get(e.vezeto_orvos_id) ?? 0) + 1);
      }
      let best: [string, number] | null = null;
      for (const [k, v] of counts) if (!best || v > best[1]) best = [k, v];
      suggestedProviderId = best?.[0] ?? null;

      if (suggestedProviderId) {
        // appointment_slots → resource_id → appointment_resources.provider_user_id (ha létezik)
        const { data: slots } = await supabase
          .from("appointment_slots")
          .select("id, kezdo_ts, resource_id, foglalt_szam, kapacitas, status")
          .gte("kezdo_ts", new Date().toISOString())
          .eq("status", "szabad")
          .order("kezdo_ts", { ascending: true })
          .limit(20);
        const { data: prof } = await supabase
          .from("profiles")
          .select("teljes_nev")
          .eq("id", suggestedProviderId)
          .maybeSingle();
        availableSlots = (slots ?? [])
          .filter((s) => s.foglalt_szam < s.kapacitas)
          .slice(0, 5)
          .map((s) => ({
            id: s.id,
            starts_at: s.kezdo_ts,
            provider_name: prof?.teljes_nev ?? null,
          }));
      }
    }


    const key = process.env.LOVABLE_API_KEY;
    if (!key) throw new Error("Missing LOVABLE_API_KEY");
    const { createLovableAiGatewayProvider } = await import("@/lib/ai-gateway.server");
    const { generateText } = await import("ai");
    const gateway = createLovableAiGatewayProvider(key);
    const model = gateway("google/gemini-3-flash-preview");

    const sys = `Te egy klinikai elő­jegyzési asszisztens vagy. Röviden, magyarul válaszolj. Csak a megadott előzményadatokra támaszkodj. Ha javasolsz időpontot, mindig kérj megerősítést.`;
    const ctx = patientId
      ? `Beteg azonosító: ${patientId}\n\nKorábbi találkozók (max 20):\n${historySummary || "Nincs adat."}\n\nJavasolt orvos: ${suggestedProviderId ?? "nincs"}\nSzabad időpontok:\n${availableSlots.map((s) => `- ${s.starts_at} • ${s.provider_name ?? ""} (slot: ${s.id})`).join("\n") || "Nincs."}\n`
      : "Nincs aktív beteg-kontextus.";

    const { text } = await generateText({
      model,
      system: sys,
      prompt: `Kontextus:\n${ctx}\n\nKérdés: ${data.question}`,
    });

    const answer = text.trim();

    // Üzenetként rögzítjük az asszisztens válaszát
    const { data: msg } = await supabase
      .from("messages")
      .insert({
        conversation_id: data.conversation_id,
        sender_user_id: null,
        sender_kind: "ai",
        body: answer,
        source_lang: "hu",
      })
      .select("id")
      .single();

    await supabase.from("ai_assistant_actions").insert({
      conversation_id: data.conversation_id,
      user_id: context.userId,
      kind: "lookup_history",
      payload: { question: data.question, patient_id: patientId },
      result: {
        suggested_provider_id: suggestedProviderId,
        slot_count: availableSlots.length,
        slots: availableSlots,
        message_id: msg?.id,
      },
    });

    return {
      answer,
      message_id: msg?.id ?? null,
      suggested_provider_id: suggestedProviderId,
      slots: availableSlots,
    };
  });

const BookAssistantInput = z.object({
  conversation_id: z.string().uuid(),
  slot_id: z.string().uuid(),
  patient_id: z.string().uuid(),
  reason: z.string().max(500).optional(),
});

/**
 * Megerősített foglalás az AI asszisztens által javasolt slot-ra.
 * Optimista zárolás version mezővel; rögzít system üzenetet és ai_assistant_actions auditot.
 */
export const bookAssistantSlot = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => BookAssistantInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;

    const { data: slot } = await supabase
      .from("appointment_slots")
      .select("id, tenant_id, resource_id, kezdo_ts, foglalt_szam, kapacitas, status, version")
      .eq("id", data.slot_id)
      .maybeSingle();
    if (!slot) throw new Error("Időpont nem található");
    if (slot.status !== "szabad" || slot.foglalt_szam >= slot.kapacitas) {
      throw new Error("Az időpont már nem foglalható");
    }

    const { generateBookingCode } = await import("@/lib/booking/slots");
    const foglalasKod = generateBookingCode();
    const { data: appt, error: aErr } = await supabase
      .from("appointments")
      .insert({
        tenant_id: slot.tenant_id,
        slot_id: slot.id,
        resource_id: slot.resource_id,
        patient_id: data.patient_id,
        ok: data.reason ?? "AI asszisztens javaslat",
        status: "foglalt",
        foglalas_kod: foglalasKod,
        created_by: userId,
      })
      .select("id, foglalas_kod")
      .single();
    if (aErr) throw new Error(aErr.message);

    const { error: uErr } = await supabase
      .from("appointment_slots")
      .update({
        foglalt_szam: slot.foglalt_szam + 1,
        status: slot.foglalt_szam + 1 >= slot.kapacitas ? "foglalt" : "szabad",
      })
      .eq("id", slot.id)
      .eq("version", slot.version);
    if (uErr) throw new Error("Az időpont időközben módosult, próbálja újra.");

    const when = new Date(slot.kezdo_ts).toLocaleString("hu-HU");
    await supabase.from("messages").insert({
      conversation_id: data.conversation_id,
      sender_user_id: null,
      sender_kind: "system",
      body: `Új időpontot foglaltunk: ${when}. Foglalási kód: ${appt?.foglalas_kod ?? "—"}.`,
      source_lang: "hu",
    });

    await supabase.from("ai_assistant_actions").insert({
      conversation_id: data.conversation_id,
      user_id: userId,
      kind: "confirm_booking",
      payload: { slot_id: data.slot_id, patient_id: data.patient_id },
      result: { appointment_id: appt?.id, foglalas_kod: appt?.foglalas_kod, when },
    });

    return { appointment_id: appt?.id, foglalas_kod: appt?.foglalas_kod, when };
  });
