import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const CreateInput = z.object({
  kind: z.enum(["dm", "group", "patient_provider", "patient_team", "ai_assistant"]),
  title: z.string().max(200).optional(),
  patient_id: z.string().uuid().nullable().optional(),
  participant_user_ids: z.array(z.string().uuid()).max(50).default([]),
});

export const createConversation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => CreateInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;

    // resolve tenant from caller profile
    const { data: prof } = await supabase
      .from("profiles")
      .select("tenant_id")
      .eq("id", userId)
      .maybeSingle();
    if (!prof?.tenant_id) throw new Error("No tenant for current user");

    const { data: conv, error } = await supabase
      .from("conversations")
      .insert({
        tenant_id: prof.tenant_id,
        kind: data.kind,
        title: data.title ?? null,
        patient_id: data.patient_id ?? null,
        created_by: userId,
      })
      .select("id")
      .single();
    if (error || !conv) throw new Error(error?.message ?? "Failed to create");

    // always include creator
    const participants = Array.from(new Set([userId, ...data.participant_user_ids])).map((uid) => ({
      conversation_id: conv.id,
      user_id: uid,
      role: uid === userId ? "owner" : "member",
    }));
    const { error: pErr } = await supabase.from("conversation_participants").insert(participants);
    if (pErr) throw new Error(pErr.message);

    return { id: conv.id };
  });

export const listConversations = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    // get participant rows first to know which convs
    const { data: parts } = await supabase
      .from("conversation_participants")
      .select("conversation_id, last_read_at, auto_translate, muted")
      .eq("user_id", userId);
    const ids = (parts ?? []).map((p) => p.conversation_id);
    if (ids.length === 0) return [];

    const { data: convs } = await supabase
      .from("conversations")
      .select("id, kind, title, patient_id, last_message_at, created_at, created_by")
      .in("id", ids)
      .order("last_message_at", { ascending: false });

    const partsMap = new Map(
      (parts ?? []).map((p) => [p.conversation_id, p]),
    );

    // hydrate participant names + last message preview + unread count
    const out = await Promise.all(
      (convs ?? []).map(async (c) => {
        const [{ data: members }, { data: lastMsgArr }, { count: unread }] = await Promise.all([
          supabase
            .from("conversation_participants")
            .select("user_id, patient_id, role")
            .eq("conversation_id", c.id),
          supabase
            .from("messages")
            .select("id, body, sender_user_id, sender_kind, created_at")
            .eq("conversation_id", c.id)
            .is("deleted_at", null)
            .order("created_at", { ascending: false })
            .limit(1),
          (async () => {
            const lastRead = partsMap.get(c.id)?.last_read_at;
            const q = supabase
              .from("messages")
              .select("id", { count: "exact", head: true })
              .eq("conversation_id", c.id)
              .neq("sender_user_id", userId);
            if (lastRead) q.gt("created_at", lastRead);
            return q;
          })(),
        ]);

        const memberIds = (members ?? []).map((m) => m.user_id).filter(Boolean) as string[];
        const { data: profiles } = memberIds.length
          ? await supabase.from("profiles").select("id, teljes_nev, avatar_url").in("id", memberIds)
          : { data: [] as Array<{ id: string; teljes_nev: string; avatar_url: string | null }> };

        const lastMsg = lastMsgArr?.[0] ?? null;
        return {
          id: c.id,
          kind: c.kind,
          title: c.title,
          patient_id: c.patient_id,
          last_message_at: c.last_message_at,
          last_message: lastMsg ? { body: lastMsg.body, created_at: lastMsg.created_at, sender_user_id: lastMsg.sender_user_id } : null,
          unread_count: unread ?? 0,
          auto_translate: partsMap.get(c.id)?.auto_translate ?? true,
          muted: partsMap.get(c.id)?.muted ?? false,
          members: (members ?? []).map((m) => ({
            user_id: m.user_id,
            patient_id: m.patient_id,
            role: m.role,
            name: profiles?.find((p) => p.id === m.user_id)?.teljes_nev ?? null,
            avatar_url: profiles?.find((p) => p.id === m.user_id)?.avatar_url ?? null,
          })),
        };
      }),
    );
    return out;
  });

const SetAutoTrInput = z.object({ conversation_id: z.string().uuid(), auto_translate: z.boolean() });
export const setAutoTranslate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => SetAutoTrInput.parse(d))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("conversation_participants")
      .update({ auto_translate: data.auto_translate })
      .eq("conversation_id", data.conversation_id)
      .eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

const MarkReadInput = z.object({ conversation_id: z.string().uuid() });
export const markRead = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => MarkReadInput.parse(d))
  .handler(async ({ data, context }) => {
    const now = new Date().toISOString();
    await context.supabase
      .from("conversation_participants")
      .update({ last_read_at: now })
      .eq("conversation_id", data.conversation_id)
      .eq("user_id", context.userId);
    return { ok: true, at: now };
  });

export const listTeamMembers = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data: prof } = await context.supabase
      .from("profiles")
      .select("tenant_id")
      .eq("id", context.userId)
      .maybeSingle();
    if (!prof?.tenant_id) return [];
    const { data } = await context.supabase
      .from("profiles")
      .select("id, teljes_nev, email, avatar_url, foglalkozas_tipus")
      .eq("tenant_id", prof.tenant_id)
      .eq("aktiv", true)
      .neq("id", context.userId)
      .order("teljes_nev");
    return data ?? [];
  });
