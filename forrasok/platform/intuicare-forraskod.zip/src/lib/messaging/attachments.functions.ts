import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const ALLOWED_MIME = new Set<string>([
  "image/png", "image/jpeg", "image/jpg", "image/webp", "image/gif", "image/heic",
  "application/pdf",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  "application/vnd.ms-excel",
  "text/csv", "text/plain",
  "audio/webm", "audio/mp4", "audio/mpeg", "audio/mp3", "audio/wav", "audio/ogg", "audio/m4a",
]);
const MAX_SIZE = 20 * 1024 * 1024;

function kindFromMime(mime: string): "image" | "pdf" | "spreadsheet" | "audio" | "file" {
  if (mime.startsWith("image/")) return "image";
  if (mime === "application/pdf") return "pdf";
  if (mime.startsWith("audio/")) return "audio";
  if (mime.includes("spreadsheet") || mime.includes("excel") || mime === "text/csv") return "spreadsheet";
  return "file";
}

const UploadUrlInput = z.object({
  conversation_id: z.string().uuid(),
  filename: z.string().min(1).max(255),
  mime: z.string().min(1).max(200),
  size_bytes: z.number().int().min(1).max(MAX_SIZE),
});

export const requestUploadUrl = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => UploadUrlInput.parse(d))
  .handler(async ({ data, context }) => {
    if (!ALLOWED_MIME.has(data.mime)) throw new Error(`Nem támogatott fájltípus: ${data.mime}`);
    if (data.size_bytes > MAX_SIZE) throw new Error("Túl nagy fájl (max 20MB)");

    const isPart = await context.supabase
      .rpc("is_conversation_participant", { _conv_id: data.conversation_id, _user_id: context.userId });
    if (!isPart.data) throw new Error("Nincs hozzáférés a beszélgetéshez");

    const safe = data.filename.replace(/[^a-zA-Z0-9._-]+/g, "_").slice(0, 100);
    const objectKey = `${data.conversation_id}/${crypto.randomUUID()}-${safe}`;

    const { data: signed, error } = await context.supabase
      .storage
      .from("chat-attachments")
      .createSignedUploadUrl(objectKey);
    if (error || !signed) throw new Error(error?.message ?? "Nem sikerült feltöltési URL-t kérni");

    return {
      upload_url: signed.signedUrl,
      token: signed.token,
      object_path: objectKey,
      kind: kindFromMime(data.mime),
    };
  });

const FinalizeInput = z.object({
  conversation_id: z.string().uuid(),
  object_path: z.string().min(1),
  filename: z.string().min(1).max(255),
  mime: z.string().min(1).max(200),
  size_bytes: z.number().int().min(1).max(MAX_SIZE),
  duration_ms: z.number().int().nonnegative().optional(),
});

export const finalizeAttachment = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => FinalizeInput.parse(d))
  .handler(async ({ data, context }) => {
    if (!ALLOWED_MIME.has(data.mime)) throw new Error("Nem támogatott fájltípus");
    const kind = kindFromMime(data.mime);
    const summaryStatus = kind === "pdf" || kind === "spreadsheet" || kind === "audio" ? "pending" : "skipped";

    const { data: row, error } = await context.supabase
      .from("message_attachments")
      .insert({
        conversation_id: data.conversation_id,
        uploaded_by: context.userId,
        storage_path: data.object_path,
        mime: data.mime,
        size_bytes: data.size_bytes,
        original_name: data.filename,
        kind,
        duration_ms: data.duration_ms ?? null,
        ai_summary_status: summaryStatus,
      })
      .select("id, kind")
      .single();
    if (error || !row) throw new Error(error?.message ?? "Hiba a csatolmány rögzítésekor");
    return { id: row.id, kind: row.kind };
  });

const SignedGetInput = z.object({ attachment_id: z.string().uuid() });
export const getAttachmentUrl = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => SignedGetInput.parse(d))
  .handler(async ({ data, context }) => {
    const { data: att, error } = await context.supabase
      .from("message_attachments")
      .select("storage_path, mime")
      .eq("id", data.attachment_id)
      .maybeSingle();
    if (error || !att) throw new Error("Csatolmány nem található");
    const { data: signed, error: e2 } = await context.supabase
      .storage
      .from("chat-attachments")
      .createSignedUrl(att.storage_path, 60 * 30);
    if (e2 || !signed) throw new Error(e2?.message ?? "Nem sikerült URL-t kérni");
    return { url: signed.signedUrl, mime: att.mime };
  });
