import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const ListInput = z.object({
  conversation_id: z.string().uuid(),
  before: z.string().datetime().optional(),
  limit: z.number().int().min(1).max(200).default(80),
});

export const listMessages = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => ListInput.parse(d))
  .handler(async ({ data, context }) => {
    let q = context.supabase
      .from("messages")
      .select("id, conversation_id, sender_user_id, sender_kind, body, source_lang, reply_to_id, edited_at, deleted_at, created_at")
      .eq("conversation_id", data.conversation_id)
      .order("created_at", { ascending: false })
      .limit(data.limit);
    if (data.before) q = q.lt("created_at", data.before);
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    const msgs = (rows ?? []).reverse();

    const ids = msgs.map((m) => m.id);
    const [{ data: atts }, { data: trs }, { data: receipts }] = await Promise.all([
      ids.length
        ? context.supabase
            .from("message_attachments")
            .select("id, message_id, kind, mime, size_bytes, original_name, storage_path, ai_summary, ai_summary_status, transcript, duration_ms")
            .in("message_id", ids)
        : Promise.resolve({ data: [] as any[] }),
      ids.length
        ? context.supabase
            .from("message_translations")
            .select("message_id, lang, translated_text")
            .in("message_id", ids)
        : Promise.resolve({ data: [] as any[] }),
      ids.length
        ? context.supabase
            .from("message_read_receipts")
            .select("message_id, reader_user_id, read_at")
            .in("message_id", ids)
        : Promise.resolve({ data: [] as any[] }),
    ]);

    const senderIds = Array.from(new Set(msgs.map((m) => m.sender_user_id).filter(Boolean) as string[]));
    const { data: profs } = senderIds.length
      ? await context.supabase.from("profiles").select("id, teljes_nev, avatar_url").in("id", senderIds)
      : { data: [] as Array<{ id: string; teljes_nev: string; avatar_url: string | null }> };

    return msgs.map((m) => ({
      ...m,
      sender_name: profs?.find((p) => p.id === m.sender_user_id)?.teljes_nev ?? null,
      sender_avatar: profs?.find((p) => p.id === m.sender_user_id)?.avatar_url ?? null,
      attachments: (atts ?? []).filter((a: any) => a.message_id === m.id),
      translations: Object.fromEntries(
        (trs ?? []).filter((t: any) => t.message_id === m.id).map((t: any) => [t.lang, t.translated_text]),
      ),
      read_by: (receipts ?? []).filter((r: any) => r.message_id === m.id).map((r: any) => r.reader_user_id),
    }));
  });

const SendInput = z.object({
  conversation_id: z.string().uuid(),
  body: z.string().max(8000).optional(),
  source_lang: z.string().max(8).optional(),
  attachment_ids: z.array(z.string().uuid()).max(10).default([]),
  reply_to_id: z.string().uuid().nullable().optional(),
});

export const sendMessage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => SendInput.parse(d))
  .handler(async ({ data, context }) => {
    if (!data.body && data.attachment_ids.length === 0) {
      throw new Error("Üzenet vagy csatolmány szükséges");
    }
    const { data: msg, error } = await context.supabase
      .from("messages")
      .insert({
        conversation_id: data.conversation_id,
        sender_user_id: context.userId,
        sender_kind: "user",
        body: data.body ?? null,
        source_lang: data.source_lang ?? null,
        reply_to_id: data.reply_to_id ?? null,
      })
      .select("id, created_at")
      .single();
    if (error || !msg) throw new Error(error?.message ?? "Failed to send");

    if (data.attachment_ids.length > 0) {
      await context.supabase
        .from("message_attachments")
        .update({ message_id: msg.id })
        .in("id", data.attachment_ids)
        .eq("uploaded_by", context.userId);
    }
    return { id: msg.id, created_at: msg.created_at };
  });

const EditInput = z.object({ id: z.string().uuid(), body: z.string().min(1).max(8000) });
export const editMessage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => EditInput.parse(d))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("messages")
      .update({ body: data.body, edited_at: new Date().toISOString() })
      .eq("id", data.id)
      .eq("sender_user_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

const DelInput = z.object({ id: z.string().uuid() });
export const deleteMessage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => DelInput.parse(d))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("messages")
      .update({ deleted_at: new Date().toISOString(), body: null })
      .eq("id", data.id)
      .eq("sender_user_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

const ReceiptInput = z.object({ message_ids: z.array(z.string().uuid()).min(1).max(200) });
export const sendReadReceipts = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => ReceiptInput.parse(d))
  .handler(async ({ data, context }) => {
    const rows = data.message_ids.map((id) => ({ message_id: id, reader_user_id: context.userId }));
    await context.supabase
      .from("message_read_receipts")
      .upsert(rows, { onConflict: "message_id,reader_user_id", ignoreDuplicates: true });
    return { ok: true };
  });
