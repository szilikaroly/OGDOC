import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

export type TriageUrgency = "routine" | "soon" | "urgent" | "emergency";

export type TriageResult = {
  urgency: TriageUrgency;
  category: string;
  summary: string;
  suggested_replies: string[];
  book_appointment: { recommended: boolean; reason: string };
  slots: Array<{ id: string; starts_at: string; provider_name: string | null }>;
  patient_id: string | null;
  source_message_id: string | null;
  cached: boolean;
};

const TriageInput = z.object({
  conversation_id: z.string().uuid(),
  force: z.boolean().optional(),
});

/**
 * Staff oldali AI triage: az utolsó páciens-üzenetre súlyozott választ,
 * sürgősségi besorolást és időpont-foglalási javaslatot generál
 * az anamnesztikus adatok (encounters, BNO, riasztások) alapján.
 * Eredmény cache-elve az ai_assistant_actions táblában.
 */
export const aiTriageMessage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => TriageInput.parse(d))
  .handler(async ({ data, context }): Promise<TriageResult> => {
    const { supabase, userId } = context;

    // 1) conversation + patient
    const { data: conv } = await supabase
      .from("conversations")
      .select("id, patient_id, kind, tenant_id")
      .eq("id", data.conversation_id)
      .maybeSingle();
    if (!conv) throw new Error("Beszélgetés nem található");

    // 2) last patient-side messages
    const { data: msgs } = await supabase
      .from("messages")
      .select("id, body, sender_kind, sender_user_id, sender_patient_id, created_at")
      .eq("conversation_id", data.conversation_id)
      .is("deleted_at", null)
      .order("created_at", { ascending: false })
      .limit(15);
    const lastIncoming = (msgs ?? []).find(
      (m) => m.sender_kind === "patient" || (m.sender_user_id && m.sender_user_id !== userId && m.sender_kind !== "ai"),
    );
    const sourceMessageId = lastIncoming?.id ?? null;

    // 3) cached?
    if (!data.force && sourceMessageId) {
      const { data: cached } = await supabase
        .from("ai_assistant_actions")
        .select("result, created_at")
        .eq("conversation_id", data.conversation_id)
        .eq("kind", "triage")
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      const r = (cached?.result ?? null) as any;
      if (r?.source_message_id === sourceMessageId) {
        return { ...(r as TriageResult), cached: true };
      }
    }

    // 4) patient anamnesis
    let anamnesis = "Nincs anamnesztikus adat.";
    let openAlerts = "Nincs aktív riasztás.";
    let suggestedProviderId: string | null = null;
    if (conv.patient_id) {
      const { data: encs } = await supabase
        .from("patient_encounters")
        .select("ellatas_kezdete, bno_kodok, osszefoglalo, vezeto_orvos_id")
        .eq("patient_id", conv.patient_id)
        .order("ellatas_kezdete", { ascending: false })
        .limit(10);
      const list = encs ?? [];
      if (list.length) {
        anamnesis = list
          .map(
            (e) =>
              `- ${e.ellatas_kezdete?.slice(0, 10) ?? "?"} • BNO: ${(e.bno_kodok ?? []).join(",") || "—"} • ${e.osszefoglalo ?? ""}`,
          )
          .join("\n");
      }
      const counts = new Map<string, number>();
      for (const e of list) if (e.vezeto_orvos_id) counts.set(e.vezeto_orvos_id, (counts.get(e.vezeto_orvos_id) ?? 0) + 1);
      let best: [string, number] | null = null;
      for (const [k, v] of counts) if (!best || v > best[1]) best = [k, v];
      suggestedProviderId = best?.[0] ?? null;

      const { data: alerts } = await supabase
        .from("clinical_critical_alerts")
        .select("severity, message, code, created_at, acknowledged_at")
        .eq("patient_id", conv.patient_id)
        .is("acknowledged_at", null)
        .order("created_at", { ascending: false })
        .limit(5);
      if (alerts && alerts.length) {
        openAlerts = alerts.map((a) => `- [${a.severity}] ${a.code ?? ""} ${a.message ?? ""}`).join("\n");
      }
    }

    // 5) free slots for suggested provider
    let slots: TriageResult["slots"] = [];
    if (suggestedProviderId && conv.patient_id) {
      const { data: res } = await supabase
        .from("appointment_resources")
        .select("id")
        .eq("orvos_id", suggestedProviderId)
        .eq("aktiv", true);
      const resIds = (res ?? []).map((r) => r.id);
      if (resIds.length) {
        const { data: sl } = await supabase
          .from("appointment_slots")
          .select("id, kezdo_ts, foglalt_szam, kapacitas, status")
          .in("resource_id", resIds)
          .gte("kezdo_ts", new Date().toISOString())
          .eq("status", "szabad")
          .order("kezdo_ts", { ascending: true })
          .limit(20);
        const { data: prof } = await supabase
          .from("profiles")
          .select("teljes_nev")
          .eq("id", suggestedProviderId)
          .maybeSingle();
        slots = (sl ?? [])
          .filter((s) => s.foglalt_szam < s.kapacitas)
          .slice(0, 5)
          .map((s) => ({ id: s.id, starts_at: s.kezdo_ts, provider_name: prof?.teljes_nev ?? null }));
      }
    }

    // 6) AI call (structured)
    const key = process.env.LOVABLE_API_KEY;
    if (!key) throw new Error("Missing LOVABLE_API_KEY");
    const { createLovableAiGatewayProvider } = await import("@/lib/ai-gateway.server");
    const { generateText, Output } = await import("ai");
    const gateway = createLovableAiGatewayProvider(key);
    const model = gateway("google/gemini-3-flash-preview");

    const lastBody = lastIncoming?.body ?? "(nincs új páciens üzenet)";
    const recentThread = (msgs ?? [])
      .slice(0, 8)
      .reverse()
      .map((m) => `${m.sender_kind === "patient" ? "PÁCIENS" : m.sender_kind === "ai" ? "AI" : "STAFF"}: ${m.body ?? "(üres)"}`)
      .join("\n");

    const schema = z.object({
      urgency: z.enum(["routine", "soon", "urgent", "emergency"]),
      category: z.string().min(1).max(80),
      summary: z.string().min(1).max(800),
      suggested_replies: z.array(z.string().min(1).max(600)).min(2).max(4),
      book_appointment: z.object({
        recommended: z.boolean(),
        reason: z.string().max(400),
      }),
    });

    const sys = `Te egy magyar nyelvű klinikai triage-asszisztens vagy egészségügyi staff számára. 
Sürgősségi besorolást, választervezeteket és időpont-foglalási javaslatot adsz a páciens utolsó üzenete és anamnesztikus adatai alapján.
Sürgősség skála: routine (sima panasz), soon (1-3 nap), urgent (24 óra), emergency (azonnali, hívja a 112-t / SBO).
Választervezetek empatikus, második személyű, magyar nyelvű, max 3 mondat, konkrét következő lépéssel.
Soha ne diagnosztizálj — javaslatot adsz, a döntés a klinikus felelőssége.`;

    const prompt = `=== Utolsó páciens üzenet ===
${lastBody}

=== Beszélgetés (utolsó 8) ===
${recentThread}

=== Anamnesztikus előzmények ===
${anamnesis}

=== Aktív riasztások ===
${openAlerts}

=== Elérhető szabad időpontok ===
${slots.map((s) => `- ${s.starts_at} (${s.provider_name ?? "—"})`).join("\n") || "Nincs."}`;

    const { experimental_output } = await generateText({
      model,
      system: sys,
      prompt,
      experimental_output: Output.object({ schema }),
    });

    const out = experimental_output as z.infer<typeof schema>;

    const result: TriageResult = {
      urgency: out.urgency,
      category: out.category,
      summary: out.summary,
      suggested_replies: out.suggested_replies,
      book_appointment: out.book_appointment,
      slots,
      patient_id: conv.patient_id,
      source_message_id: sourceMessageId,
      cached: false,
    };

    await supabase.from("ai_assistant_actions").insert({
      conversation_id: data.conversation_id,
      user_id: userId,
      kind: "triage",
      payload: { source_message_id: sourceMessageId },
      result,
    });

    // Push értesítés sürgős / vészhelyzet besorolásnál a staff résztvevőknek.
    if (result.urgency === "urgent" || result.urgency === "emergency") {
      try {
        const { data: parts } = await supabase
          .from("conversation_participants")
          .select("user_id")
          .eq("conversation_id", data.conversation_id);
        const staffIds = Array.from(new Set((parts ?? []).map((p) => p.user_id).filter((v): v is string => !!v && v !== userId)));
        if (staffIds.length) {
          const { pushToUser } = await import("@/lib/push/push-sender.server");
          const title = result.urgency === "emergency" ? "🚨 Vészhelyzet — új triage" : "⚠️ Sürgős triage javaslat";
          await Promise.all(
            staffIds.map((uid) =>
              pushToUser(uid, {
                title,
                body: result.summary.slice(0, 140),
                url: `/uzenetek/${data.conversation_id}`,
                tag: `triage-${data.conversation_id}`,
              }).catch(() => null),
            ),
          );
        }
      } catch {/* push hiba ne törje el a triage flowt */}
    }

    return result;
  });

const BookInput = z.object({
  conversation_id: z.string().uuid(),
  slot_id: z.string().uuid(),
  patient_id: z.string().uuid(),
  ok: z.string().max(400).optional(),
});

/**
 * Staff által megerősített AI időpont-foglalás. Optimista counter növelés
 * + appointments insert + rendszerüzenet a beszélgetésbe.
 */
export const bookTriageSlot = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => BookInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: slot } = await supabase
      .from("appointment_slots")
      .select("id, tenant_id, resource_id, kezdo_ts, foglalt_szam, kapacitas, status, version")
      .eq("id", data.slot_id)
      .maybeSingle();
    if (!slot) throw new Error("Időpont nem található");
    if (slot.status !== "szabad" || slot.foglalt_szam >= slot.kapacitas) {
      throw new Error("Az időpont már nem foglalható");
    }

    const _kodBuf = new Uint8Array(8);
    crypto.getRandomValues(_kodBuf);
    const _alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    const foglalasKod = Array.from(_kodBuf, (b) => _alpha[b % _alpha.length]).join("");
    const { data: appt, error: aErr } = await supabase
      .from("appointments")
      .insert({
        tenant_id: slot.tenant_id,
        slot_id: slot.id,
        resource_id: slot.resource_id,
        patient_id: data.patient_id,
        ok: data.ok ?? "AI triage javaslat",
        status: "foglalt",
        foglalas_kod: foglalasKod,
        created_by: userId,
      })
      .select("id, foglalas_kod")
      .single();
    if (aErr) throw new Error(aErr.message);

    await supabase
      .from("appointment_slots")
      .update({
        foglalt_szam: slot.foglalt_szam + 1,
        status: slot.foglalt_szam + 1 >= slot.kapacitas ? "foglalt" : "szabad",
      })
      .eq("id", slot.id)
      .eq("version", slot.version);

    const when = new Date(slot.kezdo_ts).toLocaleString("hu-HU");
    await supabase.from("messages").insert({
      conversation_id: data.conversation_id,
      sender_user_id: null,
      sender_kind: "system",
      body: `Új időpontot foglaltunk: ${when}. Foglalási kód: ${appt?.foglalas_kod ?? "—"}.`,
      source_lang: "hu",
    });

    return { appointment_id: appt?.id, foglalas_kod: appt?.foglalas_kod, when };
  });
