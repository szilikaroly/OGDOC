/**
 * Per-tab store of failed translation batches, with retry support.
 * Tiny zustand-style implementation to avoid adding deps.
 */
export type TranslationError = {
  id: string;
  lang: string;
  namespace: string;
  items: Array<{ key: string; source: string }>;
  message: string;
  at: number;
};

type Listener = (errors: TranslationError[]) => void;

const errors: TranslationError[] = [];
const listeners = new Set<Listener>();

export function listTranslationErrors(): TranslationError[] {
  return errors.slice();
}

export function subscribeTranslationErrors(l: Listener) {
  listeners.add(l);
  return () => listeners.delete(l);
}

function notify() {
  const snap = errors.slice();
  for (const l of listeners) l(snap);
}

export function recordTranslationError(e: Omit<TranslationError, "id" | "at">) {
  errors.unshift({ ...e, id: Math.random().toString(36).slice(2), at: Date.now() });
  if (errors.length > 50) errors.length = 50;
  notify();
}

export function clearTranslationError(id: string) {
  const idx = errors.findIndex((e) => e.id === id);
  if (idx >= 0) {
    errors.splice(idx, 1);
    notify();
  }
}

export function clearAllTranslationErrors() {
  errors.length = 0;
  notify();
}
