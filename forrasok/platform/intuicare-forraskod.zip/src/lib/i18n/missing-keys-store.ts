/**
 * Kliens-oldali „hiányzó fordítási kulcs” gyűjtő.
 *
 * Az i18next `missingKeyHandler` (src/i18n/index.ts) minden alkalommal ide
 * regisztrálja azokat a kulcsokat, amelyek egy adott nyelven a HU forrásra
 * esnek vissza. A TranslationDebugPanel iratkozik fel a store-ra és listázza
 * őket + egy kattintással újrafordíttatja.
 *
 * Nem használunk zustandot: ez egy pehelysúlyú pub/sub, hogy ne kelljen a
 * hot-path (missingKeyHandler) egy egész library-t betölteni.
 */

export type MissingEntry = {
  key: string;
  source: string;      // A magyar forrás (locales/hu.ts alapján), ha ismert.
  firstSeen: number;
  hits: number;
};

type State = Record<string, Map<string, MissingEntry>>; // lang → key → entry

const state: State = {};
const listeners = new Set<() => void>();
const snapshotCache: Record<string, MissingEntry[]> = {};
const EMPTY: MissingEntry[] = [];

function invalidate(lang?: string) {
  if (lang) delete snapshotCache[lang];
  else for (const k of Object.keys(snapshotCache)) delete snapshotCache[k];
}

function emit() {
  for (const l of listeners) l();
}

export const missingKeysStore = {
  record(lang: string, key: string, source: string) {
    if (!lang || lang === "hu") return;
    const bucket = (state[lang] ??= new Map());
    const prev = bucket.get(key);
    if (prev) {
      prev.hits += 1;
    } else {
      bucket.set(key, { key, source, firstSeen: Date.now(), hits: 1 });
    }
    invalidate(lang);
    // Debounce-oljuk az emit-et, hogy render alatt ne triggereljünk sokat.
    scheduleEmit();
  },

  clear(lang?: string) {
    if (lang) state[lang]?.clear();
    else for (const k of Object.keys(state)) state[k].clear();
    invalidate(lang);
    emit();
  },

  clearKey(lang: string, key: string) {
    state[lang]?.delete(key);
    invalidate(lang);
    emit();
  },

  list(lang: string): MissingEntry[] {
    const cached = snapshotCache[lang];
    if (cached) return cached;
    const bucket = state[lang];
    if (!bucket || bucket.size === 0) {
      snapshotCache[lang] = EMPTY;
      return EMPTY;
    }
    const snap = Array.from(bucket.values()).sort((a, b) => b.hits - a.hits);
    snapshotCache[lang] = snap;
    return snap;
  },

  count(lang: string): number {
    return state[lang]?.size ?? 0;
  },

  subscribe(fn: () => void) {
    listeners.add(fn);
    return () => listeners.delete(fn);
  },
};

let emitTimer: ReturnType<typeof setTimeout> | null = null;
function scheduleEmit() {
  if (emitTimer) return;
  emitTimer = setTimeout(() => {
    emitTimer = null;
    emit();
  }, 250);
}
