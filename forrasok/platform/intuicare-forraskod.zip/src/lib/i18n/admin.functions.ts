/**
 * Server functions: list missing keys, retry failed translations, glossary CRUD.
 */
import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

export const listTranslations = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        lang: z.string().min(2).max(8).optional(),
        namespace: z.string().optional(),
        search: z.string().optional(),
        limit: z.number().int().min(1).max(500).default(200),
      })
      .parse(input ?? {}),
  )
  .handler(async ({ data, context }) => {
    let q = context.supabase
      .from("i18n_translations")
      .select("id,namespace,key,lang,source_text,value,edited_by_user,updated_at,kind")
      .order("updated_at", { ascending: false })
      .limit(data.limit);
    if (data.lang) q = q.eq("lang", data.lang);
    if (data.namespace) q = q.eq("namespace", data.namespace);
    if (data.search)
      q = q.or(`source_text.ilike.%${data.search}%,value.ilike.%${data.search}%,key.ilike.%${data.search}%`);
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

export const updateTranslation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ id: z.string().uuid(), value: z.string().min(1).max(8000) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("i18n_translations")
      .update({ value: data.value, edited_by_user: true, updated_at: new Date().toISOString() })
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteTranslation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("i18n_translations").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const retranslateAll = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ lang: z.string().min(2).max(8), namespace: z.string().optional() }).parse(input),
  )
  .handler(async ({ data, context }) => {
    // Wipe non-edited rows; next access triggers AI refill.
    let q = context.supabase
      .from("i18n_translations")
      .delete()
      .eq("lang", data.lang)
      .eq("edited_by_user", false);
    if (data.namespace) q = q.eq("namespace", data.namespace);
    const { error, count } = await q;
    if (error) throw new Error(error.message);
    return { cleared: count ?? 0 };
  });

// Glossary
export const listGlossary = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("translation_glossary")
      .select("id,term,target_lang,translation,notes,updated_at")
      .order("term");
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const upsertGlossary = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        id: z.string().uuid().optional(),
        term: z.string().min(1).max(200),
        target_lang: z.string().min(2).max(8),
        translation: z.string().min(1).max(500),
        notes: z.string().max(500).optional(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const payload = {
      term: data.term,
      target_lang: data.target_lang,
      translation: data.translation,
      notes: data.notes ?? null,
      updated_at: new Date().toISOString(),
    };
    if (data.id) {
      const { error } = await context.supabase
        .from("translation_glossary")
        .update(payload)
        .eq("id", data.id);
      if (error) throw new Error(error.message);
    } else {
      const { error } = await context.supabase.from("translation_glossary").insert(payload);
      if (error) throw new Error(error.message);
    }
    return { ok: true };
  });

export const deleteGlossary = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("translation_glossary").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// Save user language preference
export const saveUserLocale = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ locale: z.string().min(2).max(8) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("profiles")
      .update({ locale: data.locale })
      .eq("id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const getUserLocale = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data } = await context.supabase
      .from("profiles")
      .select("locale")
      .eq("id", context.userId)
      .maybeSingle();
    return { locale: (data?.locale as string | null) ?? null };
  });

// ===== Missing keys =====

export const listMissingKeys = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        lang: z.string().min(2).max(8).optional(),
        limit: z.number().int().min(1).max(1000).default(500),
      })
      .parse(input ?? {}),
  )
  .handler(async ({ data, context }) => {
    let q = context.supabase
      .from("i18n_missing_keys")
      .select("id,namespace,key,lang,source_text,kind,hits,last_seen_at")
      .order("last_seen_at", { ascending: false })
      .limit(data.limit);
    if (data.lang) q = q.eq("lang", data.lang);
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

export const deleteMissingKey = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("i18n_missing_keys")
      .delete()
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/**
 * Processes accumulated missing keys for a given language via AI.
 * Pulls all missing rows, calls translateBatch (non-db_only mode),
 * which upserts to i18n_translations and clears the missing rows.
 */
export const processMissingKeys = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        lang: z.string().min(2).max(8),
        batch_size: z.number().int().min(1).max(200).default(100),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { data: rows, error } = await supabase
      .from("i18n_missing_keys")
      .select("namespace,key,source_text,kind")
      .eq("lang", data.lang)
      .order("last_seen_at", { ascending: false })
      .limit(data.batch_size);
    if (error) throw new Error(error.message);
    if (!rows || rows.length === 0) return { processed: 0, remaining: 0 };

    const items = rows.map((r) => ({
      key: r.key as string,
      source: r.source_text as string,
      namespace: r.namespace as string,
    }));
    const kindGroup = (rows[0]?.kind as "ui" | "content") ?? "ui";

    const { translateBatchCore } = await import("./translate.functions");
    await translateBatchCore(supabase, {
      items,
      target_lang: data.lang,
      kind: kindGroup,
      db_only: false,
    });

    const { count } = await supabase
      .from("i18n_missing_keys")
      .select("id", { count: "exact", head: true })
      .eq("lang", data.lang);

    return { processed: rows.length, remaining: count ?? 0 };
  });

