/**
 * Komplex fordítómodul – szerverfüggvények.
 * Szövegtár (i18n_source_strings): minden hard-coded felirat + részletes magyarázat.
 * Fordítás: nyelvenként vagy „mind egyben”, csak hiányzók vagy teljes újrafordítás.
 */
import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const SyncInput = z.object({
  items: z
    .array(
      z.object({
        namespace: z.string().min(1).max(128).default("ui"),
        key: z.string().min(1).max(512),
        source_text: z.string().min(1).max(8000),
      }),
    )
    .min(1)
    .max(500),
});

const ListInput = z.object({
  namespace: z.string().max(128).optional(),
  search: z.string().max(200).optional(),
  only_missing_description: z.boolean().default(false),
  limit: z.number().int().min(1).max(500).default(100),
  offset: z.number().int().min(0).default(0),
});

const UpdateInput = z.object({
  id: z.string().uuid(),
  description: z.string().max(4000).nullish(),
  translator_note: z.string().max(2000).nullish(),
  screen: z.string().max(200).nullish(),
  element_type: z.string().max(32).optional(),
  max_length: z.number().int().min(1).max(4000).nullish(),
  is_active: z.boolean().optional(),
});

const DescribeInput = z.object({
  namespace: z.string().max(128).optional(),
  limit: z.number().int().min(1).max(60).default(30),
});

const RunInput = z.object({
  langs: z.array(z.string().min(2).max(8)).min(1).max(20),
  namespace: z.string().max(128).optional(),
  mode: z.enum(["missing", "full"]).default("missing"),
  offset: z.number().int().min(0).default(0),
  limit: z.number().int().min(1).max(60).default(40),
  job_id: z.string().uuid().optional(),
});

async function assertAdmin(ctx: { supabase: any; userId: string }) {
  const { data, error } = await ctx.supabase.rpc("has_role", {
    _user_id: ctx.userId,
    _role_kulcs: "tenant_admin",
  });
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Forbidden — admin jogosultság szükséges.");
}

/** Hard-coded feliratok beolvasása a szövegtárba (meglévő magyarázatot nem írja felül). */
export const syncSourceStrings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => SyncInput.parse(input))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { screenFromKey } = await import("./registry.server");

    const keys = data.items.map((i) => i.key);
    const { data: existing } = await context.supabase
      .from("i18n_source_strings")
      .select("id,namespace,key,source_text")
      .in("key", keys);
    const existingMap = new Map(
      (existing ?? []).map((r: any) => [`${r.namespace}::${r.key}`, r]),
    );

    let inserted = 0;
    let updated = 0;
    const toInsert: any[] = [];
    for (const it of data.items) {
      const prev: any = existingMap.get(`${it.namespace}::${it.key}`);
      if (!prev) {
        toInsert.push({
          namespace: it.namespace,
          key: it.key,
          source_text: it.source_text,
          screen: screenFromKey(it.key),
        });
        inserted++;
      } else if (prev.source_text !== it.source_text) {
        const { error } = await context.supabase
          .from("i18n_source_strings")
          .update({ source_text: it.source_text })
          .eq("id", prev.id);
        if (!error) updated++;
      }
    }
    if (toInsert.length > 0) {
      const { error } = await context.supabase
        .from("i18n_source_strings")
        .upsert(toInsert, { onConflict: "namespace,key", ignoreDuplicates: true });
      if (error) throw new Error(error.message);
    }
    return { inserted, updated, total: data.items.length };
  });

export const listSourceStrings = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => ListInput.parse(input ?? {}))
  .handler(async ({ data, context }) => {
    let q = context.supabase
      .from("i18n_source_strings")
      .select(
        "id,namespace,key,source_text,element_type,screen,description,translator_note,max_length,is_active,ai_described,updated_at",
        { count: "exact" },
      )
      .order("key")
      .range(data.offset, data.offset + data.limit - 1);
    if (data.namespace) q = q.eq("namespace", data.namespace);
    if (data.only_missing_description) q = q.is("description", null);
    if (data.search)
      q = q.or(
        `key.ilike.%${data.search}%,source_text.ilike.%${data.search}%,description.ilike.%${data.search}%`,
      );
    const { data: rows, error, count } = await q;
    if (error) throw new Error(error.message);
    return { rows: rows ?? [], count: count ?? 0 };
  });

export const updateSourceString = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => UpdateInput.parse(input))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { normalizeElementType } = await import("./registry.server");
    const patch = {
      ...(data.description !== undefined ? { description: data.description ?? null } : {}),
      ...(data.translator_note !== undefined ? { translator_note: data.translator_note ?? null } : {}),
      ...(data.screen !== undefined ? { screen: data.screen ?? null } : {}),
      ...(data.max_length !== undefined ? { max_length: data.max_length ?? null } : {}),
      ...(data.is_active !== undefined ? { is_active: data.is_active } : {}),
      ...(data.element_type ? { element_type: normalizeElementType(data.element_type) } : {}),
    };
    const { error } = await (context.supabase as any)
      .from("i18n_source_strings")
      .update(patch)
      .eq("id", data.id);

    if (error) throw new Error(error.message);
    return { ok: true };
  });

/** AI (Gemini) magyarázat-generálás a magyarázat nélküli feliratokhoz — kötegelve. */
export const generateDescriptions = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => DescribeInput.parse(input ?? {}))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { describeSourceStrings, normalizeElementType } = await import("./registry.server");

    let q = context.supabase
      .from("i18n_source_strings")
      .select("id,namespace,key,source_text,element_type,screen")
      .is("description", null)
      .eq("is_active", true)
      .order("key")
      .limit(data.limit);
    if (data.namespace) q = q.eq("namespace", data.namespace);
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    if (!rows || rows.length === 0) return { described: 0, remaining: 0 };

    const described = await describeSourceStrings(rows as any);
    let ok = 0;
    for (const r of rows as any[]) {
      const d = described[`${r.namespace}::${r.key}`];
      if (!d) continue;
      const { error: uErr } = await context.supabase
        .from("i18n_source_strings")
        .update({
          description: d.description,
          element_type: normalizeElementType(d.element_type),
          ai_described: true,
        })
        .eq("id", r.id);
      if (!uErr) ok++;
    }

    const { count } = await context.supabase
      .from("i18n_source_strings")
      .select("id", { count: "exact", head: true })
      .is("description", null);

    return { described: ok, remaining: count ?? 0 };
  });

export const startTranslationJob = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        langs: z.array(z.string().min(2).max(8)).min(1).max(20),
        namespace: z.string().max(128).optional(),
        mode: z.enum(["missing", "full"]).default("missing"),
        total: z.number().int().min(0).default(0),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { data: row, error } = await context.supabase
      .from("i18n_translation_jobs")
      .insert({
        langs: data.langs,
        namespace: data.namespace ?? null,
        mode: data.mode,
        total: data.total,
        started_by: context.userId,
      })
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    return { job_id: row.id as string };
  });

export const finishTranslationJob = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        job_id: z.string().uuid(),
        translated: z.number().int().min(0),
        failed: z.number().int().min(0),
        error: z.string().max(2000).nullish(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const status = data.error ? "failed" : data.failed > 0 ? "partial" : "done";
    const { error } = await context.supabase
      .from("i18n_translation_jobs")
      .update({
        translated: data.translated,
        failed: data.failed,
        error: data.error ?? null,
        status,
        finished_at: new Date().toISOString(),
      })
      .eq("id", data.job_id);
    if (error) throw new Error(error.message);
    return { ok: true, status };
  });

/**
 * Egy köteg fordítása: a szövegtár [offset, offset+limit) szelete,
 * a megadott nyelvekre, magyarázat-kontextussal, Gemini-vel.
 */
export const runTranslationBatch = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => RunInput.parse(input))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { translateWithContext, stableHash } = await import("./registry.server");
    const { supabase } = context;

    let q = supabase
      .from("i18n_source_strings")
      .select(
        "id,namespace,key,source_text,element_type,screen,description,translator_note,max_length",
        { count: "exact" },
      )
      .eq("is_active", true)
      .order("key")
      .range(data.offset, data.offset + data.limit - 1);
    if (data.namespace) q = q.eq("namespace", data.namespace);
    const { data: rows, error, count } = await q;
    if (error) throw new Error(error.message);

    const total = count ?? 0;
    if (!rows || rows.length === 0) {
      return { total, processed: 0, translated: 0, skipped: 0, next_offset: null as number | null };
    }

    let translated = 0;
    let skipped = 0;

    for (const lang of data.langs) {
      if (lang === "hu") continue;

      const { data: cached } = await supabase
        .from("i18n_translations")
        .select("namespace,key,value,source_hash,edited_by_user")
        .eq("lang", lang)
        .in(
          "key",
          rows.map((r: any) => r.key),
        );
      const cacheMap = new Map((cached ?? []).map((c: any) => [`${c.namespace}::${c.key}`, c]));

      const todo = (rows as any[]).filter((r) => {
        const c: any = cacheMap.get(`${r.namespace}::${r.key}`);
        if (!c) return true;
        if (c.edited_by_user) return false; // kézi fordítást soha nem írunk felül
        if (data.mode === "full") return true;
        return c.source_hash !== stableHash(r.source_text) || !c.value;
      });
      skipped += rows.length - todo.length;
      if (todo.length === 0) continue;

      const { data: glossary } = await supabase
        .from("translation_glossary")
        .select("term,translation")
        .eq("target_lang", lang);

      const out = await translateWithContext(todo as any, lang, glossary ?? []);

      const upsertRows = todo
        .map((r: any) => {
          const value = out[`${r.namespace}::${r.key}`];
          if (!value) return null;
          return {
            namespace: r.namespace,
            key: r.key,
            lang,
            value: String(value),
            source_text: r.source_text,
            source_hash: stableHash(r.source_text),
            kind: "ui",
            edited_by_user: false,
            updated_at: new Date().toISOString(),
          };
        })
        .filter(Boolean) as any[];

      if (upsertRows.length > 0) {
        const { error: upErr } = await supabase
          .from("i18n_translations")
          .upsert(upsertRows, { onConflict: "namespace,key,lang", ignoreDuplicates: false });
        if (upErr) throw new Error(upErr.message);
        translated += upsertRows.length;
        await supabase
          .from("i18n_missing_keys")
          .delete()
          .eq("lang", lang)
          .in("key", upsertRows.map((r) => r.key));
      }
    }

    const nextOffset = data.offset + rows.length;
    return {
      total,
      processed: rows.length,
      translated,
      skipped,
      next_offset: nextOffset < total ? nextOffset : null,
    };
  });

/** Nyelvenkénti lefedettség: hány forráskulcsnak van már fordítása. */
export const getCoverage = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ namespace: z.string().max(128).optional() }).parse(input ?? {}),
  )
  .handler(async ({ data, context }) => {
    let base = context.supabase
      .from("i18n_source_strings")
      .select("id", { count: "exact", head: true })
      .eq("is_active", true);
    if (data.namespace) base = base.eq("namespace", data.namespace);
    const { count: total } = await base;

    const { data: rows, error } = await context.supabase
      .from("i18n_translations")
      .select("lang,key")
      .eq("kind", "ui")
      .limit(50000);
    if (error) throw new Error(error.message);

    const per = new Map<string, number>();
    for (const r of (rows ?? []) as any[]) per.set(r.lang, (per.get(r.lang) ?? 0) + 1);

    const { count: described } = await context.supabase
      .from("i18n_source_strings")
      .select("id", { count: "exact", head: true })
      .not("description", "is", null);

    return {
      total: total ?? 0,
      described: described ?? 0,
      per_lang: Array.from(per.entries()).map(([lang, done]) => ({ lang, done })),
    };
  });

export const listTranslationJobs = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("i18n_translation_jobs")
      .select("id,langs,namespace,mode,status,total,translated,failed,error,started_at,finished_at")
      .order("started_at", { ascending: false })
      .limit(20);
    if (error) throw new Error(error.message);
    return data ?? [];
  });
