import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";


export const SUPPORTED_LANGUAGES = [
  { code: "hu", label: "Magyar", flag: "🇭🇺" },
  { code: "en", label: "English", flag: "🇬🇧" },
  { code: "de", label: "Deutsch", flag: "🇩🇪" },
  { code: "ro", label: "Română", flag: "🇷🇴" },
  { code: "sk", label: "Slovenčina", flag: "🇸🇰" },
  { code: "sr", label: "Srpski", flag: "🇷🇸" },
  { code: "uk", label: "Українська", flag: "🇺🇦" },
  { code: "ru", label: "Русский", flag: "🇷🇺" },
  { code: "zh", label: "中文", flag: "🇨🇳" },
  { code: "fil", label: "Filipino", flag: "🇵🇭" },
] as const;

export type LangCode = (typeof SUPPORTED_LANGUAGES)[number]["code"];

const ItemSchema = z.object({
  key: z.string().min(1).max(512),
  source: z.string().min(1).max(8000),
  namespace: z.string().min(1).max(128).default("ui"),
});

const TranslateBatchInput = z.object({
  items: z.array(ItemSchema).min(1).max(200),
  target_lang: z.string().min(2).max(8),
  kind: z.enum(["ui", "content"]).default("ui"),
  db_only: z.boolean().default(false),
});

const TranslateInlineInput = z.object({
  text: z.string().min(1).max(8000),
  target_lang: z.string().min(2).max(8),
});

function sha256(s: string) {
  // Lightweight non-crypto hash (xxhash-style) – cache key only, no security use.
  const t = s.trim();
  let h1 = 0xdeadbeef ^ t.length;
  let h2 = 0x41c6ce57 ^ t.length;
  for (let i = 0; i < t.length; i++) {
    const ch = t.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return (
    (h2 >>> 0).toString(16).padStart(8, "0") +
    (h1 >>> 0).toString(16).padStart(8, "0") +
    t.length.toString(16)
  ).slice(0, 32);
}

function langLabel(code: string) {
  return SUPPORTED_LANGUAGES.find((l) => l.code === code)?.label ?? code;
}

async function aiTranslateBatch(
  texts: Record<string, string>,
  targetLang: string,
  glossary: Array<{ term: string; translation: string }>,
) {
  const key = process.env.LOVABLE_API_KEY;
  if (!key) throw new Error("Missing LOVABLE_API_KEY");
  const { createLovableAiGatewayProvider } = await import("@/lib/ai-gateway.server");
  const { generateText } = await import("ai");
  const gateway = createLovableAiGatewayProvider(key);
  const model = gateway("google/gemini-3-flash-preview");

  const glossaryStr = glossary.length
    ? `\nKötelező szótár (eredeti → célnyelv):\n${glossary.map((g) => `- ${g.term} → ${g.translation}`).join("\n")}`
    : "";

  const system = `Te orvosi és HR szakfordító vagy. A forrásnyelv magyar, fordíts ${langLabel(targetLang)} (${targetLang}) nyelvre.
- Csak a fordított értéket add vissza minden kulcshoz, mindenféle magyarázat nélkül.
- Megőrzöd a változókat (pl. {{name}}, {count}), HTML tageket és írásjeleket.
- Tömör, formális, szakmai stílus.
- A válaszod KIZÁRÓLAG egy érvényes JSON objektum, ahol a kulcsok azonosak a bemenettel.${glossaryStr}`;

  const prompt = `Fordítsd le a következő JSON értékeit ${targetLang} nyelvre. Csak a JSON-t add vissza:\n\n${JSON.stringify(texts, null, 2)}`;

  const { text } = await generateText({ model, system, prompt });
  let parsed: Record<string, string>;
  try {
    const cleaned = text.replace(/^```json\s*/i, "").replace(/^```\s*/i, "").replace(/```\s*$/i, "").trim();
    parsed = JSON.parse(cleaned);
  } catch {
    throw new Error("AI fordító érvénytelen választ adott");
  }
  return parsed;
}

export type TranslateBatchInputType = z.infer<typeof TranslateBatchInput>;

export async function translateBatchCore(
  supabase: any,
  data: TranslateBatchInputType,
): Promise<Record<string, string>> {
  const { items, target_lang, kind, db_only } = data;

  if (target_lang === "hu") {
    return Object.fromEntries(items.map((i) => [i.key, i.source]));
  }

  const itemMap = new Map(items.map((i) => [`${i.namespace}::${i.key}`, i]));
  const namespaces = Array.from(new Set(items.map((i) => i.namespace)));
  const keys = items.map((i) => i.key);

  const { data: cached } = await supabase
    .from("i18n_translations")
    .select("namespace,key,value,source_hash")
    .in("namespace", namespaces)
    .in("key", keys)
    .eq("lang", target_lang);

  const result: Record<string, string> = {};
  const need: Record<string, string> = {};
  const cacheMap = new Map(
    (cached ?? []).map((r: any) => [`${r.namespace}::${r.key}`, r]),
  );

  for (const it of items) {
    const cacheKey = `${it.namespace}::${it.key}`;
    const c: any = cacheMap.get(cacheKey);
    const hash = sha256(it.source);
    if (c && c.source_hash === hash && c.value) {
      result[it.key] = c.value;
    } else {
      need[cacheKey] = it.source;
    }
  }

  if (Object.keys(need).length === 0) return result;

  if (db_only) {
    const missingRows = Object.entries(need).map(([cacheKey, source]) => {
      const it = itemMap.get(cacheKey)!;
      return {
        namespace: it.namespace,
        key: it.key,
        lang: target_lang,
        source_text: source,
        kind,
        hits: 1,
        last_seen_at: new Date().toISOString(),
      };
    });
    if (missingRows.length > 0) {
      await supabase
        .from("i18n_missing_keys")
        .upsert(missingRows, { onConflict: "namespace,key,lang", ignoreDuplicates: false });
    }
    return result;
  }

  const { data: glossary } = await supabase
    .from("translation_glossary")
    .select("term,translation")
    .eq("target_lang", target_lang);

  const translated = await aiTranslateBatch(need, target_lang, glossary ?? []);

  const rows = Object.entries(translated).map(([cacheKey, value]) => {
    const it = itemMap.get(cacheKey)!;
    return {
      namespace: it.namespace,
      key: it.key,
      lang: target_lang,
      value: String(value),
      source_text: it.source,
      source_hash: sha256(it.source),
      kind,
    };
  });

  if (rows.length > 0) {
    const { error } = await supabase
      .from("i18n_translations")
      .upsert(rows, { onConflict: "namespace,key,lang", ignoreDuplicates: false });
    if (error) console.error("i18n cache upsert failed", error);
    await supabase
      .from("i18n_missing_keys")
      .delete()
      .eq("lang", target_lang)
      .in("key", rows.map((r) => r.key));
  }

  for (const [cacheKey, value] of Object.entries(translated)) {
    const it = itemMap.get(cacheKey)!;
    result[it.key] = String(value);
  }

  return result;
}

export const translateBatch = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => TranslateBatchInput.parse(input))
  .handler(async ({ data, context }) => {
    return translateBatchCore(context.supabase, data);
  });

/**
 * Maximum items per translateBatch call (server-side Zod enforces .max(200)).
 * Keep client chunks below this to avoid ZodError: too_big.
 */
export const TRANSLATE_BATCH_MAX = 200 as const;
const TRANSLATE_BATCH_CHUNK = 150 as const;

/**
 * Client-safe wrapper that pre-validates and chunks any items array
 * larger than TRANSLATE_BATCH_MAX before invoking translateBatch.
 * Use this from all UI/hook call sites instead of translateBatch directly
 * when item count is unbounded.
 */
export async function translateBatchSafe(args: {
  items: Array<{ key: string; source: string; namespace?: string }>;
  target_lang: string;
  kind?: "ui" | "content";
  db_only?: boolean;
}): Promise<Record<string, string>> {
  const { items, target_lang, kind = "ui", db_only = false } = args;
  if (!Array.isArray(items) || items.length === 0) return {};

  const merged: Record<string, string> = {};
  for (let i = 0; i < items.length; i += TRANSLATE_BATCH_CHUNK) {
    const chunk = items.slice(i, i + TRANSLATE_BATCH_CHUNK);
    if (chunk.length > TRANSLATE_BATCH_MAX) {
      throw new Error(
        `translateBatchSafe: chunk size ${chunk.length} exceeds server limit ${TRANSLATE_BATCH_MAX}`,
      );
    }
    const res = (await translateBatch({
      data: { items: chunk, target_lang, kind, db_only },
    })) as Record<string, string>;
    Object.assign(merged, res);
  }
  return merged;
}




export const translateInline = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => TranslateInlineInput.parse(input))
  .handler(async ({ data, context }) => {
    const { text, target_lang } = data;
    if (target_lang === "hu") return { translation: text };

    const key = `inline_${sha256(text)}`;
    const { supabase } = context;

    const { data: cached } = await supabase
      .from("i18n_translations")
      .select("value,source_hash")
      .eq("namespace", "inline")
      .eq("key", key)
      .eq("lang", target_lang)
      .maybeSingle();

    if (cached?.value && cached.source_hash === sha256(text)) {
      return { translation: cached.value, cached: true };
    }

    const { data: glossary } = await supabase
      .from("translation_glossary")
      .select("term,translation")
      .eq("target_lang", target_lang);

    const out = await aiTranslateBatch({ [key]: text }, target_lang, glossary ?? []);
    const translation = String(out[key] ?? text);

    await supabase.from("i18n_translations").upsert(
      [
        {
          namespace: "inline",
          key,
          lang: target_lang,
          value: translation,
          source_text: text,
          source_hash: sha256(text),
          kind: "content",
        },
      ],
      { onConflict: "namespace,key,lang", ignoreDuplicates: false },
    );

    return { translation, cached: false };
  });

export const listSupportedLanguages = createServerFn({ method: "GET" }).handler(async () => {
  return SUPPORTED_LANGUAGES.map((l) => ({ ...l }));
});
