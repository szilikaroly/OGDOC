/**
 * Szerveroldali segédek a komplex fordítómodulhoz (Gemini / Lovable AI Gateway).
 * Csak szerver-környezetben töltődik be (handler-en belüli dinamikus import).
 */
import { SUPPORTED_LANGUAGES } from "@/i18n/languages";

export type SourceStringRow = {
  id: string;
  namespace: string;
  key: string;
  source_text: string;
  element_type: string;
  screen: string | null;
  description: string | null;
  translator_note: string | null;
  max_length: number | null;
};

export function langLabel(code: string) {
  return SUPPORTED_LANGUAGES.find((l) => l.code === code)?.label ?? code;
}

export function stableHash(s: string) {
  const t = s.trim();
  let h1 = 0xdeadbeef ^ t.length;
  let h2 = 0x41c6ce57 ^ t.length;
  for (let i = 0; i < t.length; i++) {
    const ch = t.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return (
    (h2 >>> 0).toString(16).padStart(8, "0") +
    (h1 >>> 0).toString(16).padStart(8, "0") +
    t.length.toString(16)
  ).slice(0, 32);
}

async function gemini() {
  const key = process.env.LOVABLE_API_KEY;
  if (!key) throw new Error("Hiányzó LOVABLE_API_KEY — az AI fordító nem elérhető.");
  const { createLovableAiGatewayProvider } = await import("@/lib/ai-gateway.server");
  const { generateText } = await import("ai");
  const gateway = createLovableAiGatewayProvider(key);
  return { model: gateway("google/gemini-3.6-flash"), generateText };
}

function parseJsonObject(text: string): Record<string, string> {
  const cleaned = text
    .replace(/^```json\s*/i, "")
    .replace(/^```\s*/i, "")
    .replace(/```\s*$/i, "")
    .trim();
  try {
    return JSON.parse(cleaned);
  } catch {
    const start = cleaned.indexOf("{");
    const end = cleaned.lastIndexOf("}");
    if (start >= 0 && end > start) {
      try {
        return JSON.parse(cleaned.slice(start, end + 1));
      } catch {
        /* fall through */
      }
    }
    throw new Error("Az AI fordító érvénytelen (nem JSON) választ adott.");
  }
}

/**
 * Kontextus-tudatos kötegelt fordítás: minden kulcshoz átadjuk a
 * részletes magyarázatot, elemtípust és képernyőt, hogy a Gemini
 * a valódi UI-jelentés szerint fordítson.
 */
export async function translateWithContext(
  rows: SourceStringRow[],
  targetLang: string,
  glossary: Array<{ term: string; translation: string }>,
): Promise<Record<string, string>> {
  if (rows.length === 0) return {};
  const { model, generateText } = await gemini();

  const glossaryStr = glossary.length
    ? `\nKötelező szótár (forrás → cél):\n${glossary.map((g) => `- ${g.term} → ${g.translation}`).join("\n")}`
    : "";

  const payload = rows.map((r) => ({
    key: `${r.namespace}::${r.key}`,
    text: r.source_text,
    type: r.element_type,
    screen: r.screen ?? undefined,
    meaning: r.description ?? undefined,
    note: r.translator_note ?? undefined,
    max_length: r.max_length ?? undefined,
  }));

  const system = `Te egészségügyi és HR szoftver szakfordító vagy. A forrásnyelv magyar, a célnyelv ${langLabel(targetLang)} (${targetLang}).
Szabályok:
- Minden elemnél figyelembe veszed a "meaning" (részletes magyarázat), "type" (UI elem típusa), "screen" és "note" mezőket.
- Gombokhoz/címkékhez rövid, felszólító vagy főnévi forma illik; hibaüzenetekhez világos, udvarias mondat.
- A "max_length" korlátot betartod, ha meg van adva.
- A változókat ({{name}}, {count}, %s), HTML tageket és írásjeleket változatlanul megőrzöd.
- Formális, szakmai, félreérthetetlen orvosi terminológia.
- A válaszod KIZÁRÓLAG egy JSON objektum: { "namespace::key": "fordítás", ... } — magyarázat nélkül.${glossaryStr}`;

  const { text } = await generateText({
    model,
    system,
    prompt: `Fordítsd le az alábbi UI szövegeket ${targetLang} nyelvre:\n\n${JSON.stringify(payload, null, 1)}`,
  });

  return parseJsonObject(text);
}

/**
 * Részletes magyarázat generálása minden forrásszöveghez (magyarul),
 * ami a fordítás kontextusa és egyben admin dokumentáció lesz.
 */
export async function describeSourceStrings(
  rows: Array<Pick<SourceStringRow, "namespace" | "key" | "source_text" | "element_type" | "screen">>,
): Promise<Record<string, { description: string; element_type: string }>> {
  if (rows.length === 0) return {};
  const { model, generateText } = await gemini();

  const system = `Te egy magyar nyelvű orvosi/HR szoftver UX-írója vagy.
Minden felirathoz adj RÖVID, de KONKRÉT magyarázatot magyarul (1-2 mondat):
mit jelent, hol jelenik meg, mire kattint/lát a felhasználó, és mire kell figyelni fordításkor.
Határozd meg az elem típusát is: label | button | title | placeholder | helper | error | menu | badge | content | other.
A kulcs (pl. "portal.leletek.title") és a szöveg együtt segít.
A válaszod KIZÁRÓLAG JSON: { "namespace::key": { "description": "...", "element_type": "..." }, ... }`;

  const payload = rows.map((r) => ({
    key: `${r.namespace}::${r.key}`,
    text: r.source_text,
    screen: r.screen ?? undefined,
  }));

  const { text } = await generateText({
    model,
    system,
    prompt: `Írj magyarázatot ezekhez a UI feliratokhoz:\n\n${JSON.stringify(payload, null, 1)}`,
  });

  const parsed = parseJsonObject(text) as unknown as Record<
    string,
    { description?: string; element_type?: string } | string
  >;
  const out: Record<string, { description: string; element_type: string }> = {};
  for (const [k, v] of Object.entries(parsed)) {
    if (typeof v === "string") out[k] = { description: v, element_type: "label" };
    else if (v && typeof v === "object" && v.description)
      out[k] = { description: String(v.description), element_type: String(v.element_type ?? "label") };
  }
  return out;
}

const ALLOWED_TYPES = new Set([
  "label",
  "button",
  "title",
  "placeholder",
  "helper",
  "error",
  "menu",
  "badge",
  "content",
  "other",
]);

export function normalizeElementType(t: string | undefined | null) {
  const v = String(t ?? "label").toLowerCase();
  return ALLOWED_TYPES.has(v) ? v : "label";
}

/** Kulcsból kitalált képernyő-szegmens (pl. "portal.leletek.title" → "portal.leletek"). */
export function screenFromKey(key: string) {
  const parts = key.split(".");
  return parts.length > 1 ? parts.slice(0, -1).join(".") : null;
}
