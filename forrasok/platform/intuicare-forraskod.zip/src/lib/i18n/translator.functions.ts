/**
 * AI-fordító modul — tenant-szintű, cache-elt fordítások 9 nyelven.
 */
import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";
import { createHash } from "crypto";

export const SUPPORTED_LANGS = ["en", "hu", "ro", "sr", "zh", "fil", "de", "uk", "ru"] as const;
export type Lang = (typeof SUPPORTED_LANGS)[number];

export const LANG_LABELS: Record<Lang, string> = {
  en: "English",
  hu: "Magyar",
  ro: "Română",
  sr: "Srpski",
  zh: "中文",
  fil: "Filipino",
  de: "Deutsch",
  uk: "Українська",
  ru: "Русский",
};

const LANG_FULL_NAME: Record<Lang, string> = {
  en: "English",
  hu: "Hungarian",
  ro: "Romanian",
  sr: "Serbian",
  zh: "Simplified Chinese",
  fil: "Filipino (Tagalog)",
  de: "German",
  uk: "Ukrainian",
  ru: "Russian",
};

function hashText(s: string) {
  return createHash("sha256").update(s).digest("hex").slice(0, 16);
}

async function getTenantId(supabase: any, userId: string): Promise<string> {
  const { data } = await supabase.from("profiles").select("tenant_id").eq("id", userId).maybeSingle();
  const t = data?.tenant_id as string | null | undefined;
  if (!t) throw new Error("Hiányzó tenant.");
  return t;
}

/* ---------- Lekérdezés ---------- */

const GetInput = z.object({
  namespace: z.string().min(1).max(80),
  key: z.string().min(1).max(200),
});

export const getTranslationsForKey = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => GetInput.parse(d))
  .handler(async ({ data, context }) => {
    const tenant_id = await getTenantId(context.supabase, context.userId);
    const { data: rows, error } = await context.supabase
      .from("i18n_translations")
      .select("lang, value, source_text, source_hash, edited_by_user, updated_at")
      .eq("tenant_id", tenant_id)
      .eq("namespace", data.namespace)
      .eq("key", data.key);
    if (error) throw new Error(error.message);
    const map: Record<string, { value: string; source_text: string; source_hash: string; edited_by_user: boolean; updated_at: string }> = {};
    for (const r of rows ?? []) map[r.lang] = r as any;
    return map;
  });

/* ---------- Egyetlen nyelv mentése (kézi szerkesztés) ---------- */

const SaveInput = z.object({
  namespace: z.string().min(1).max(80),
  key: z.string().min(1).max(200),
  source_text: z.string().min(1),
  lang: z.enum(SUPPORTED_LANGS),
  value: z.string().min(1),
});

export const saveTranslation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => SaveInput.parse(d))
  .handler(async ({ data, context }) => {
    const tenant_id = await getTenantId(context.supabase, context.userId);
    const { error } = await context.supabase
      .from("i18n_translations")
      .upsert(
        {
          tenant_id,
          namespace: data.namespace,
          key: data.key,
          source_text: data.source_text,
          source_hash: hashText(data.source_text),
          lang: data.lang,
          value: data.value,
          edited_by_user: true,
        },
        { onConflict: "tenant_id,namespace,key,lang" },
      );
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/* ---------- AI-fordítás (Lovable AI Gateway) ---------- */

const TranslateInput = z.object({
  namespace: z.string().min(1).max(80),
  key: z.string().min(1).max(200),
  source_text: z.string().min(1).max(4000),
  source_lang: z.enum(SUPPORTED_LANGS).default("hu"),
  target_langs: z.array(z.enum(SUPPORTED_LANGS)).min(1),
  overwrite_edited: z.boolean().default(false),
});

export const translateText = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => TranslateInput.parse(d))
  .handler(async ({ data, context }) => {
    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) throw new Error("Hiányzó LOVABLE_API_KEY.");
    const tenant_id = await getTenantId(context.supabase, context.userId);
    const source_hash = hashText(data.source_text);

    // 1) Cache: már létező, friss fordítások
    const { data: existing } = await context.supabase
      .from("i18n_translations")
      .select("lang, value, source_hash, edited_by_user")
      .eq("tenant_id", tenant_id)
      .eq("namespace", data.namespace)
      .eq("key", data.key)
      .in("lang", data.target_langs);

    const cachedFresh = new Map<string, string>();
    const protectedEdited = new Set<string>();
    for (const row of existing ?? []) {
      if (row.edited_by_user && !data.overwrite_edited) {
        protectedEdited.add(row.lang);
        cachedFresh.set(row.lang, row.value);
        continue;
      }
      if (row.source_hash === source_hash) {
        cachedFresh.set(row.lang, row.value);
      }
    }

    const needed = data.target_langs.filter((l) => !cachedFresh.has(l));
    const results: Record<string, { value: string; cached: boolean; protected_edit: boolean }> = {};
    for (const [lang, value] of cachedFresh.entries()) {
      results[lang] = { value, cached: true, protected_edit: protectedEdited.has(lang) };
    }

    if (needed.length > 0) {
      const { createLovableAiGatewayProvider } = await import("@/lib/ai-gateway.server");
      const { generateText, Output } = await import("ai");
      const gateway = createLovableAiGatewayProvider(apiKey);

      const schema = z.object({
        translations: z.array(
          z.object({
            lang: z.enum(SUPPORTED_LANGS),
            value: z.string(),
          }),
        ),
      });

      const sourceLangName = LANG_FULL_NAME[data.source_lang];
      const targetList = needed.map((l) => `- ${l}: ${LANG_FULL_NAME[l]}`).join("\n");

      const prompt = [
        `You translate short healthcare UI labels and values from ${sourceLangName} into the following languages:`,
        targetList,
        ``,
        `Context: clinical staff scheduling / patient questionnaire / hospital UI. Keep medical terminology precise. Match the source register (formal). Preserve placeholders, numbers, units, dates verbatim.`,
        `Namespace: ${data.namespace}`,
        `Key: ${data.key}`,
        `Source text: """${data.source_text}"""`,
        ``,
        `Return one item per requested language using the language code exactly as listed.`,
      ].join("\n");

      const { experimental_output } = await generateText({
        model: gateway("google/gemini-3-flash-preview"),
        experimental_output: Output.object({ schema }),
        prompt,
      });

      const upserts: any[] = [];
      for (const t of experimental_output.translations) {
        if (!needed.includes(t.lang)) continue;
        results[t.lang] = { value: t.value, cached: false, protected_edit: false };
        upserts.push({
          tenant_id,
          namespace: data.namespace,
          key: data.key,
          source_text: data.source_text,
          source_hash,
          lang: t.lang,
          value: t.value,
          edited_by_user: false,
        });
      }
      if (upserts.length) {
        const { error } = await context.supabase
          .from("i18n_translations")
          .upsert(upserts, { onConflict: "tenant_id,namespace,key,lang" });
        if (error) throw new Error(error.message);
      }
    }

    return { source_hash, results };
  });
