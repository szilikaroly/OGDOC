/**
 * Pure (DB-független) mag a greedy beosztáshoz.
 * A `generate.ts` ezt a magot tölti adatokkal a Supabase-ből; tesztben pedig
 * közvetlenül hívható, hogy a kemény szabályokat (R1 — egy fő, egy nap, egy
 * műszak; R-unavail; megfelelő jelölthiány) determinisztikusan ellenőrizzük.
 */

export type CorePerson = {
  id: string;
  teljes_nev: string;
  /** képzésben lévő-e (S3-ban: csak supervisorral osztható be) */
  kepzesben?: boolean;
};

export type CoreShift = {
  kulcs: "nappal" | "ugyelet" | "keszenlet";
  kezd: string;  // HH:mm
  veg: string;   // HH:mm
  kategoria: "rendes" | "ugyelet" | "keszenlet";
  fo: number;
  /** Opcionális szerepkör-kulcs (pl. "aneszteziologus") — ha meg van adva,
   *  csak az ezt a kulcsot a `roleKeysByUser`-ben tartalmazó jelölt választható. */
  staff_role_kulcs?: string;
  /** Opcionális skill-id — csak az ezt birtokló jelölt választható. */
  skill_id?: string;
};

export type CoreDailyDemand = {
  date: string; // ISO yyyy-mm-dd
  shifts: CoreShift[];
};

export type CoreDailyPref = {
  user_id: string;
  nap_iso: number; // 1=Hé .. 7=Va
  ugyelet_vallal: boolean | null;
  preferalt_kezd: string | null;
};

export type CoreInput = {
  people: CorePerson[];
  demand: CoreDailyDemand[];
  /** kulcs: `${user_id}|${yyyy-mm-dd}` */
  unavailable: Set<string>;
  /** induló terhelés órákban (pin-elt vagy korábbi műszakokból) */
  initialLoadH: Map<string, number>;
  dailyPrefs: CoreDailyPref[];
  /** kulcs: user_id → Set(staff_role kulcsok), pl. {"aneszteziologus","asszisztens"} */
  roleKeysByUser?: Map<string, Set<string>>;
  /** kulcs: user_id → Set(skill_id) */
  skillsByUser?: Map<string, Set<string>>;
  /**
   * Opcionális H-feltétel: ha egy adott napon képzésben lévő kerülne kiosztásra,
   * előtte ellenőrizzük, hogy van-e jelenlévő szakorvos. A kallback igaz =
   * engedélyezett.
   */
  supervisesOk?: (candidateId: string, date: string, assignedSoFar: string[]) => boolean;
};

export type CoreAssignment = {
  user_id: string;
  date: string;
  kezd: string;
  veg: string;
  ora: number;
  kategoria: CoreShift["kategoria"];
  kulcs: CoreShift["kulcs"];
  reason: "legkisebb_terheles" | "kenyszer_valasztas";
};

export type CoreExplanation = {
  user_id: string | null;
  date: string;
  szint: "info" | "figyelmeztetes" | "sertes";
  kulcs: string;
  szoveg: string;
};

export type CoreResult = {
  assignments: CoreAssignment[];
  explanations: CoreExplanation[];
  hardViolations: number;
  softScore: number;
  loadH: Map<string, number>;
};

export function hoursBetween(kezd: string, veg: string): number {
  const [a, b] = kezd.split(":").map(Number);
  const [c, d] = veg.split(":").map(Number);
  let h = c - a + (d - b) / 60;
  if (h <= 0) h += 24;
  return h;
}

export function runGreedy(input: CoreInput): CoreResult {
  const { people, demand, unavailable, initialLoadH, dailyPrefs, supervisesOk, roleKeysByUser, skillsByUser } = input;
  const loadH = new Map(initialLoadH);
  for (const p of people) if (!loadH.has(p.id)) loadH.set(p.id, 0);

  const prefsByUser = new Map<string, CoreDailyPref[]>();
  for (const pr of dailyPrefs) {
    const arr = prefsByUser.get(pr.user_id) ?? [];
    arr.push(pr);
    prefsByUser.set(pr.user_id, arr);
  }

  const assignments: CoreAssignment[] = [];
  const explanations: CoreExplanation[] = [];
  let hardViolations = 0;

  for (const day of demand) {
    const napIso = ((new Date(day.date).getDay() + 6) % 7) + 1;
    for (const sh of day.shifts) {
      const ora = hoursBetween(sh.kezd, sh.veg);
      let candidates = people
        .filter((p) => !unavailable.has(`${p.id}|${day.date}`))
        .filter((p) => !assignments.some((a) => a.user_id === p.id && a.date === day.date))
        .filter((p) => !sh.staff_role_kulcs || (roleKeysByUser?.get(p.id)?.has(sh.staff_role_kulcs) ?? false))
        .filter((p) => !sh.skill_id || (skillsByUser?.get(p.id)?.has(sh.skill_id) ?? false))
        .map((p) => {
          const dayPref = (prefsByUser.get(p.id) ?? []).find((x) => x.nap_iso === napIso);
          let score = loadH.get(p.id) ?? 0;
          if (sh.kategoria === "ugyelet" && dayPref?.ugyelet_vallal === false) score += 1000;
          if (dayPref?.preferalt_kezd && dayPref.preferalt_kezd.startsWith(sh.kezd.slice(0, 2))) score -= 5;
          return { person: p, score };
        })
        .sort((a, b) => a.score - b.score);

      for (let i = 0; i < sh.fo; i++) {
        // S3.1: domain-egyező supervisor jelenléte (ha callback van)
        let pick = candidates[0];
        if (supervisesOk && pick?.person.kepzesben) {
          const assignedToday = assignments.filter((a) => a.date === day.date).map((a) => a.user_id);
          while (pick && pick.person.kepzesben && !supervisesOk(pick.person.id, day.date, assignedToday)) {
            candidates = candidates.slice(1);
            pick = candidates[0];
          }
        }
        if (!pick) {
          explanations.push({
            user_id: null,
            date: day.date,
            szint: "sertes",
            kulcs: "fedhetetlen_keret",
            szoveg: `Nincs elég jelölt: ${sh.kulcs} ${day.date} ${sh.kezd}-${sh.veg}`,
          });
          hardViolations++;
          continue;
        }
        candidates = candidates.slice(1);
        assignments.push({
          user_id: pick.person.id,
          date: day.date,
          kezd: sh.kezd,
          veg: sh.veg,
          ora,
          kategoria: sh.kategoria,
          kulcs: sh.kulcs,
          reason: pick.score >= 1000 ? "kenyszer_valasztas" : "legkisebb_terheles",
        });
        loadH.set(pick.person.id, (loadH.get(pick.person.id) ?? 0) + ora);
        explanations.push({
          user_id: pick.person.id,
          date: day.date,
          szint: pick.score >= 1000 ? "figyelmeztetes" : "info",
          kulcs: pick.score >= 1000 ? "kenyszer_valasztas" : "legkisebb_terheles",
          szoveg:
            pick.score >= 1000
              ? `${pick.person.teljes_nev}: kényszerválasztás`
              : `${pick.person.teljes_nev}: legkisebb terhelés (${(loadH.get(pick.person.id) ?? 0).toFixed(1)}h)`,
        });
      }
    }
  }

  const softScore = Array.from(loadH.values()).reduce((s, h) => s + h, 0);
  return { assignments, explanations, hardViolations, softScore, loadH };
}
