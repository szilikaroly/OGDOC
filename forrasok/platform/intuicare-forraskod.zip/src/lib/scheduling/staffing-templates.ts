/**
 * Sablon-alapú napi shift-igény generálás.
 * A DB-RPC (`generate_demand_for_period`) ezt a logikát SQL-ben implementálja;
 * itt egy tiszta TS-változat, hogy klienssel és tesztekkel ellenőrizhető legyen.
 */

export type StaffingTemplate = {
  id: string;
  org_unit_id: string;
  nev: string;
  nap_bitmap: number; // bit 0 = Hé, …, bit 6 = Va
  kezd_ido: string;   // HH:mm
  veg_ido: string;    // HH:mm
  kategoria: "rendes" | "ugyelet" | "keszenlet" | "sos";
  ervenyes_tol: string; // yyyy-mm-dd
  ervenyes_ig: string | null;
  aktiv: boolean;
};

export type StaffingTemplateRole = {
  id: string;
  template_id: string;
  staff_role_id: string;
  staff_role_kulcs: string;
  skill_id: string | null;
  min_letszam: number;
  max_letszam: number | null;
  kotelezo: boolean;
};

export type ExpandedDemand = {
  date: string;
  template_id: string;
  template_nev: string;
  kezd_ido: string;
  veg_ido: string;
  kategoria: string;
  staff_role_kulcs: string;
  skill_id: string | null;
  min_letszam: number;
  max_letszam: number | null;
  kotelezo: boolean;
};

function iso(d: Date): string {
  return d.toISOString().slice(0, 10);
}

/** Hét napjának ISO indexe → bitmap bit (Hé=0). */
function dowToBit(d: Date): number {
  // JS getDay(): 0=Vasárnap … 6=Szombat → konvertálás Hé=0
  return (d.getDay() + 6) % 7;
}

export function expandTemplateToDays(
  template: StaffingTemplate,
  roles: StaffingTemplateRole[],
  from: string,
  to: string,
): ExpandedDemand[] {
  if (!template.aktiv) return [];
  const out: ExpandedDemand[] = [];
  const start = new Date(from + "T00:00:00Z");
  const end = new Date(to + "T00:00:00Z");
  const tplStart = new Date(template.ervenyes_tol + "T00:00:00Z");
  const tplEnd = template.ervenyes_ig ? new Date(template.ervenyes_ig + "T00:00:00Z") : null;

  for (let d = new Date(start); d <= end; d.setUTCDate(d.getUTCDate() + 1)) {
    if (d < tplStart) continue;
    if (tplEnd && d > tplEnd) continue;
    const bit = dowToBit(d);
    if ((template.nap_bitmap & (1 << bit)) === 0) continue;
    for (const r of roles) {
      out.push({
        date: iso(d),
        template_id: template.id,
        template_nev: template.nev,
        kezd_ido: template.kezd_ido,
        veg_ido: template.veg_ido,
        kategoria: template.kategoria,
        staff_role_kulcs: r.staff_role_kulcs,
        skill_id: r.skill_id,
        min_letszam: r.min_letszam,
        max_letszam: r.max_letszam,
        kotelezo: r.kotelezo,
      });
    }
  }
  return out;
}
