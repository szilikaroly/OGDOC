import { describe, it, expect } from "vitest";

// A DailyDemand 'hoursBetween' jellegű időszámítási logikájának tesztje
// (ugyanaz a képlet, amelyet a generate.ts is használ).
function hoursBetween(kezd: string, veg: string): number {
  const [a, b] = kezd.split(":").map(Number);
  const [c, d] = veg.split(":").map(Number);
  let h = c - a + (d - b) / 60;
  if (h <= 0) h += 24;
  return h;
}

describe("scheduling hoursBetween", () => {
  it("counts full daytime shift", () => {
    expect(hoursBetween("08:00", "16:00")).toBe(8);
  });

  it("counts half-hour precision", () => {
    expect(hoursBetween("08:00", "16:30")).toBe(8.5);
  });

  it("wraps across midnight (ügyelet)", () => {
    expect(hoursBetween("20:00", "08:00")).toBe(12);
  });

  it("handles exact 24h shift as 24 (kezd==veg → 24, not 0)", () => {
    expect(hoursBetween("08:00", "08:00")).toBe(24);
  });
});
