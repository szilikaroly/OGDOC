/**
 * Simple greedy schedule generator (interim solver).
 * Distributes daily required shifts among eligible people, minimizing per-person
 * total load and respecting hard rules (unavailability, pin protection).
 *
 * Full YALPS LP-formulation will replace this; the interface is stable.
 */
import { supabase } from "@/integrations/supabase/client";

export type DailyDemand = {
  date: string; // ISO yyyy-mm-dd
  shifts: Array<{
    kulcs: "nappal" | "ugyelet" | "keszenlet";
    kezd: string; // HH:mm
    veg: string;  // HH:mm
    kategoria: "rendes" | "ugyelet" | "keszenlet";
    fo: number;   // hány emberre van szükség
  }>;
};

export type GenerateInput = {
  tenantId: string;
  initiatorId: string;
  orgUnitId: string | null;
  weekStart: string; // ISO yyyy-mm-dd (hétfő)
  demand: DailyDemand[];
  dryRun?: boolean;
};

export type GenerateResult = {
  runId: string;
  inserted: number;
  hardViolations: number;
  softScore: number;
  explanations: Array<{ user_id: string | null; datum: string; szint: string; kulcs: string; szoveg: string }>;
};

function hoursBetween(kezd: string, veg: string): number {
  const [a, b] = kezd.split(":").map(Number);
  const [c, d] = veg.split(":").map(Number);
  let h = c - a + (d - b) / 60;
  if (h <= 0) h += 24;
  return h;
}

export async function generateSchedule(input: GenerateInput): Promise<GenerateResult> {
  const { tenantId, initiatorId, orgUnitId, weekStart, demand, dryRun } = input;

  // 1) Load eligible profiles in same tenant
  const { data: ppl, error: ppErr } = await supabase
    .from("profiles")
    .select("id,teljes_nev")
    .eq("tenant_id", tenantId)
    .eq("aktiv", true);
  if (ppErr) throw ppErr;
  const people = (ppl ?? []) as Array<{ id: string; teljes_nev: string }>;
  if (people.length === 0) {
    throw new Error("Nincs aktív munkatárs a bérlőben");
  }

  // 2) Load profile_unavailability for the week
  const weekEnd = new Date(weekStart);
  weekEnd.setDate(weekEnd.getDate() + 7);
  const weekEndIso = weekEnd.toISOString().slice(0, 10);

  const [{ data: una }, { data: pinAss }, { data: dailyPrefs }] = await Promise.all([
    supabase
      .from("profile_unavailability")
      .select("user_id,kezdo_datum,zaro_datum,status")
      .lte("kezdo_datum", weekEndIso)
      .gte("zaro_datum", weekStart),
    supabase
      .from("schedule_assignments")
      .select("user_id,kezdo_idopont,ora")
      .gte("kezdo_idopont", `${weekStart}T00:00:00`)
      .lt("kezdo_idopont", `${weekEndIso}T00:00:00`),
    supabase
      .from("profile_daily_preferences")
      .select("user_id,nap_iso,preferalt_kezd,preferalt_veg,kerult_kezd,kerult_veg,ugyelet_vallal")
      .is("ervenyes_ig", null),
  ]);

  const unav = new Set<string>();
  for (const u of (una ?? []) as Array<{ user_id: string; kezdo_datum: string; zaro_datum: string; status: string }>) {
    if (u.status !== "elutasitva") {
      const a = new Date(u.kezdo_datum);
      const b = new Date(u.zaro_datum);
      for (let d = new Date(a); d <= b; d.setDate(d.getDate() + 1)) {
        unav.add(`${u.user_id}|${d.toISOString().slice(0, 10)}`);
      }
    }
  }

  // Existing load per person (hours)
  const loadH = new Map<string, number>(people.map((p) => [p.id, 0]));
  for (const a of (pinAss ?? []) as Array<{ user_id: string; ora: number }>) {
    loadH.set(a.user_id, (loadH.get(a.user_id) ?? 0) + Number(a.ora));
  }

  const prefsByUser = new Map<string, Array<{ nap_iso: number; ugyelet_vallal: boolean | null; preferalt_kezd: string | null }>>();
  for (const pr of (dailyPrefs ?? []) as Array<{ user_id: string; nap_iso: number; ugyelet_vallal: boolean | null; preferalt_kezd: string | null; preferalt_veg: string | null; kerult_kezd: string | null; kerult_veg: string | null }>) {
    const arr = prefsByUser.get(pr.user_id) ?? [];
    arr.push(pr);
    prefsByUser.set(pr.user_id, arr);
  }

  // 3) Create run row (skip for dry run)
  let runId = "";
  if (!dryRun) {
    const { data: runRow, error: runErr } = await (supabase.from("schedule_runs") as any)
      .insert({
        tenant_id: tenantId,
        indito_id: initiatorId,
        idoszak_kezdet: weekStart,
        idoszak_veg: weekEndIso,
        org_unit_id: orgUnitId,
        solver: "greedy-v1",
        status: "futo",
        parameterek: { demand },
      })
      .select("id")
      .single();
    if (runErr) throw runErr;
    runId = runRow.id as string;
  }

  // 4) Greedy assignment per shift
  const explanations: GenerateResult["explanations"] = [];
  const newAssignments: Array<{
    tenant_id: string;
    user_id: string;
    org_unit_id: string | null;
    kezdo_idopont: string;
    zaro_idopont: string;
    ora: number;
    kategoria: string;
    pin: boolean;
    forras: string;
    created_by: string;
    run_id: string;
    megjegyzes: string | null;
  }> = [];
  let hardViolations = 0;

  for (const day of demand) {
    const napIso = ((new Date(day.date).getDay() + 6) % 7) + 1; // 1=Hé
    for (const sh of day.shifts) {
      const ora = hoursBetween(sh.kezd, sh.veg);
      const candidates = people
        .filter((p) => !unav.has(`${p.id}|${day.date}`))
        // not already assigned same day same shift
        .filter((p) => !newAssignments.some((a) => a.user_id === p.id && a.kezdo_idopont.startsWith(day.date)))
        .map((p) => {
          const prefList = prefsByUser.get(p.id) ?? [];
          const dayPref = prefList.find((x) => x.nap_iso === napIso);
          let score = (loadH.get(p.id) ?? 0); // lower is better
          if (sh.kategoria === "ugyelet" && dayPref?.ugyelet_vallal === false) score += 1000;
          if (dayPref?.preferalt_kezd && dayPref.preferalt_kezd.startsWith(sh.kezd.slice(0, 2))) score -= 5;
          return { person: p, score, dayPref };
        })
        .sort((a, b) => a.score - b.score);

      for (let i = 0; i < sh.fo; i++) {
        const pick = candidates[i];
        if (!pick) {
          explanations.push({
            user_id: null,
            datum: day.date,
            szint: "sertes",
            kulcs: "fedhetetlen_keret",
            szoveg: `Nincs elég jelölt a(z) ${sh.kulcs} műszakhoz (${day.date} ${sh.kezd}-${sh.veg})`,
          });
          hardViolations++;
          continue;
        }
        const kezdo = `${day.date}T${sh.kezd}:00`;
        const vegDate = sh.veg <= sh.kezd
          ? new Date(new Date(day.date).getTime() + 86400000).toISOString().slice(0, 10)
          : day.date;
        const zaro = `${vegDate}T${sh.veg}:00`;
        newAssignments.push({
          tenant_id: tenantId,
          user_id: pick.person.id,
          org_unit_id: orgUnitId,
          kezdo_idopont: kezdo,
          zaro_idopont: zaro,
          ora,
          kategoria: sh.kategoria,
          pin: false,
          forras: "solver",
          created_by: initiatorId,
          run_id: runId,
          megjegyzes: null,
        });
        loadH.set(pick.person.id, (loadH.get(pick.person.id) ?? 0) + ora);
        explanations.push({
          user_id: pick.person.id,
          datum: day.date,
          szint: pick.score >= 1000 ? "figyelmeztetes" : "info",
          kulcs: pick.score >= 1000 ? "kenyszer_valasztas" : "legkisebb_terheles",
          szoveg: pick.score >= 1000
            ? `${pick.person.teljes_nev}: kényszerválasztás (preferencia ellentétes)`
            : `${pick.person.teljes_nev}: ő volt a legkisebb terheléssel (${(loadH.get(pick.person.id) ?? 0).toFixed(1)}h)`,
        });
      }
    }
  }

  // 5) Insert assignments (skip for dry run)
  let insertedCount = 0;
  if (!dryRun && newAssignments.length > 0) {
    const { data: ins, error: insErr } = await (supabase.from("schedule_assignments") as any)
      .insert(newAssignments)
      .select("id,user_id,kezdo_idopont");
    if (insErr) throw insErr;
    insertedCount = (ins ?? []).length;

    const idxByKey = new Map<string, string>();
    for (const r of (ins ?? []) as Array<{ id: string; user_id: string; kezdo_idopont: string }>) {
      idxByKey.set(`${r.user_id}|${r.kezdo_idopont.slice(0, 10)}`, r.id);
    }
    const expRows = explanations.map((e) => ({
      tenant_id: tenantId,
      run_id: runId,
      assignment_id: e.user_id ? idxByKey.get(`${e.user_id}|${e.datum}`) ?? null : null,
      user_id: e.user_id,
      datum: e.datum,
      szint: e.szint,
      kulcs: e.kulcs,
      szoveg: e.szoveg,
    }));
    if (expRows.length > 0) {
      await (supabase.from("schedule_explanations") as any).insert(expRows);
    }
  } else if (dryRun) {
    insertedCount = newAssignments.length;
  }

  const softScore = Array.from(loadH.values()).reduce((s, h) => s + h, 0);

  // 6) Finalize run (skip for dry run)
  if (!dryRun) {
    await (supabase.from("schedule_runs") as any)
      .update({
        status: "kesz",
        hard_sertes_szam: hardViolations,
        lagy_pontszam: softScore,
        eredmeny_osszegzes: { inserted: insertedCount, hardViolations, softScore },
      })
      .eq("id", runId);
  }

  return { runId, inserted: insertedCount, hardViolations, softScore, explanations };
}
