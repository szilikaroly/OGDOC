import { describe, it, expect } from "vitest";
import { expandTemplateToDays, type StaffingTemplate, type StaffingTemplateRole } from "./staffing-templates";
import { runGreedy, type CoreInput } from "./greedy-core";

const tpl: StaffingTemplate = {
  id: "t1",
  org_unit_id: "ou1",
  nev: "Hétköznapi műtéti nap",
  nap_bitmap: 31, // Hé-Pé (bit 0..4)
  kezd_ido: "08:00",
  veg_ido: "16:00",
  kategoria: "rendes",
  ervenyes_tol: "2026-01-01",
  ervenyes_ig: null,
  aktiv: true,
};
const roles: StaffingTemplateRole[] = [
  { id: "r1", template_id: "t1", staff_role_id: "sr1", staff_role_kulcs: "aneszteziologus", skill_id: null, min_letszam: 1, max_letszam: 1, kotelezo: true },
  { id: "r2", template_id: "t1", staff_role_id: "sr2", staff_role_kulcs: "asszisztens",     skill_id: null, min_letszam: 1, max_letszam: 1, kotelezo: true },
];

describe("expandTemplateToDays", () => {
  it("csak hétköznapokat ad vissza Hé-P bitmap esetén", () => {
    // 2026-06-15 = hétfő, 2026-06-21 = vasárnap
    const out = expandTemplateToDays(tpl, roles, "2026-06-15", "2026-06-21");
    const napok = Array.from(new Set(out.map((x) => x.date))).sort();
    expect(napok).toEqual(["2026-06-15", "2026-06-16", "2026-06-17", "2026-06-18", "2026-06-19"]);
    // minden napon 2 szerepkör-sor
    expect(out.length).toBe(5 * 2);
  });

  it("aktív=false esetén üres", () => {
    const out = expandTemplateToDays({ ...tpl, aktiv: false }, roles, "2026-06-15", "2026-06-19");
    expect(out).toEqual([]);
  });

  it("ervenyes_ig szűkíti az intervallumot", () => {
    const out = expandTemplateToDays({ ...tpl, ervenyes_ig: "2026-06-16" }, roles, "2026-06-15", "2026-06-19");
    const napok = Array.from(new Set(out.map((x) => x.date))).sort();
    expect(napok).toEqual(["2026-06-15", "2026-06-16"]);
  });
});

describe("runGreedy + szerepkör-szűrés", () => {
  it("csak aneszteziológus jogosult kerülhet az aneszt sorra; ha nincs, hardViolation", () => {
    const input: CoreInput = {
      people: [
        { id: "u-anest", teljes_nev: "Aneszt Anna" },
        { id: "u-assz",  teljes_nev: "Asszisz Aladár" },
      ],
      demand: [{ date: "2026-06-15", shifts: [
        { kulcs: "nappal", kezd: "08:00", veg: "16:00", kategoria: "rendes", fo: 1, staff_role_kulcs: "aneszteziologus" },
        { kulcs: "nappal", kezd: "08:00", veg: "16:00", kategoria: "rendes", fo: 1, staff_role_kulcs: "asszisztens" },
      ]}],
      unavailable: new Set(),
      initialLoadH: new Map(),
      dailyPrefs: [],
      roleKeysByUser: new Map([
        ["u-anest", new Set(["aneszteziologus"])],
        ["u-assz",  new Set(["asszisztens"])],
      ]),
    };
    const r = runGreedy(input);
    expect(r.hardViolations).toBe(0);
    expect(r.assignments.find((a) => a.user_id === "u-anest")?.kezd).toBe("08:00");
    expect(r.assignments.find((a) => a.user_id === "u-assz")?.kezd).toBe("08:00");
  });

  it("ha nincs aneszt jogosult, a sor hardViolation-t okoz", () => {
    const input: CoreInput = {
      people: [{ id: "u-assz", teljes_nev: "Asszisz" }],
      demand: [{ date: "2026-06-15", shifts: [
        { kulcs: "nappal", kezd: "08:00", veg: "16:00", kategoria: "rendes", fo: 1, staff_role_kulcs: "aneszteziologus" },
      ]}],
      unavailable: new Set(),
      initialLoadH: new Map(),
      dailyPrefs: [],
      roleKeysByUser: new Map([["u-assz", new Set(["asszisztens"])]]),
    };
    const r = runGreedy(input);
    expect(r.hardViolations).toBe(1);
  });
});
