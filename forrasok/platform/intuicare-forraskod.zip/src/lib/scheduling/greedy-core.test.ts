import { describe, it, expect } from "vitest";
import { runGreedy, hoursBetween, type CoreInput } from "./greedy-core";

const mkInput = (over: Partial<CoreInput> = {}): CoreInput => ({
  people: [
    { id: "u1", teljes_nev: "Dr A" },
    { id: "u2", teljes_nev: "Dr B" },
  ],
  demand: [
    {
      date: "2026-01-05", // hétfő
      shifts: [{ kulcs: "ugyelet", kezd: "16:00", veg: "08:00", kategoria: "ugyelet", fo: 1 }],
    },
  ],
  unavailable: new Set(),
  initialLoadH: new Map(),
  dailyPrefs: [],
  ...over,
});

describe("runGreedy", () => {
  it("kiosztja a műszakot a legkisebb terhelésűre (tie-break: első jelölt)", () => {
    const r = runGreedy(mkInput());
    expect(r.assignments).toHaveLength(1);
    expect(r.assignments[0].user_id).toBe("u1");
    expect(r.hardViolations).toBe(0);
    expect(r.loadH.get("u1")).toBeCloseTo(16);
  });

  it("kihagyja a tartózkodás-jelentésben lévőt (unav)", () => {
    const r = runGreedy(
      mkInput({ unavailable: new Set(["u1|2026-01-05"]) }),
    );
    expect(r.assignments[0].user_id).toBe("u2");
  });

  it("hardViolation, ha nincs elég jelölt", () => {
    const r = runGreedy(
      mkInput({
        unavailable: new Set(["u1|2026-01-05", "u2|2026-01-05"]),
      }),
    );
    expect(r.assignments).toHaveLength(0);
    expect(r.hardViolations).toBe(1);
    expect(r.explanations[0].szint).toBe("sertes");
  });

  it("egy fő egy napon csak egy műszakra kerül", () => {
    const r = runGreedy({
      ...mkInput(),
      demand: [
        {
          date: "2026-01-05",
          shifts: [
            { kulcs: "nappal", kezd: "08:00", veg: "16:00", kategoria: "rendes", fo: 1 },
            { kulcs: "ugyelet", kezd: "16:00", veg: "08:00", kategoria: "ugyelet", fo: 1 },
          ],
        },
      ],
    });
    expect(r.assignments).toHaveLength(2);
    expect(new Set(r.assignments.map((a) => a.user_id))).toEqual(new Set(["u1", "u2"]));
  });

  it("ügyelet-megtagadást figyelembe vesz (kenyszer_valasztas, ha más nincs)", () => {
    const r = runGreedy({
      ...mkInput(),
      people: [{ id: "u1", teljes_nev: "Dr A" }],
      dailyPrefs: [{ user_id: "u1", nap_iso: 1, ugyelet_vallal: false, preferalt_kezd: null }],
    });
    expect(r.assignments[0].reason).toBe("kenyszer_valasztas");
  });

  it("S3.1 — képzésben lévő supervisor nélkül nem kerül be (hardViolation)", () => {
    const r = runGreedy({
      people: [{ id: "rez", teljes_nev: "Rezidens", kepzesben: true }],
      demand: [
        {
          date: "2026-01-05",
          shifts: [{ kulcs: "nappal", kezd: "08:00", veg: "16:00", kategoria: "rendes", fo: 1 }],
        },
      ],
      unavailable: new Set(),
      initialLoadH: new Map(),
      dailyPrefs: [],
      supervisesOk: () => false, // soha nincs supervisor
    });
    expect(r.assignments).toHaveLength(0);
    expect(r.hardViolations).toBe(1);
  });

  it("S3.1 — képzésben lévő bekerül, ha a supervisor jelen van", () => {
    const r = runGreedy({
      people: [{ id: "rez", teljes_nev: "Rezidens", kepzesben: true }],
      demand: [
        {
          date: "2026-01-05",
          shifts: [{ kulcs: "nappal", kezd: "08:00", veg: "16:00", kategoria: "rendes", fo: 1 }],
        },
      ],
      unavailable: new Set(),
      initialLoadH: new Map(),
      dailyPrefs: [],
      supervisesOk: () => true,
    });
    expect(r.assignments).toHaveLength(1);
    expect(r.hardViolations).toBe(0);
  });
});

describe("hoursBetween", () => {
  it("átfedi az éjfélt", () => {
    expect(hoursBetween("22:00", "06:00")).toBe(8);
    expect(hoursBetween("16:00", "08:00")).toBe(16);
  });
});
