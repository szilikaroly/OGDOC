/**
 * Cron / external scheduler authentication helper.
 *
 * Expectation: caller provides `Authorization: Bearer <CRON_SECRET>` (preferred)
 * or — for backwards compatibility with pg_net/Supabase scheduler — the
 * `apikey` / `x-api-key` header containing the publishable key.
 *
 * SECURITY: If neither `CRON_SECRET` nor `SUPABASE_PUBLISHABLE_KEY` is
 * configured on the server, every request is rejected (we never fall through
 * to "no auth required"). Comparisons use `timingSafeEqual` to avoid timing
 * oracles on the secret.
 */
import { timingSafeEqual } from "node:crypto";

function safeEqual(a: string, b: string): boolean {
  const ab = Buffer.from(a);
  const bb = Buffer.from(b);
  if (ab.length !== bb.length) return false;
  return timingSafeEqual(ab, bb);
}

export type CronAuthResult =
  | { ok: true }
  | { ok: false; status: 401 | 500; body: { error: string } };

export function verifyCronRequest(request: Request): CronAuthResult {
  const cronSecret = process.env.CRON_SECRET?.trim();
  const publishable = process.env.SUPABASE_PUBLISHABLE_KEY?.trim();

  if (!cronSecret && !publishable) {
    // Misconfigured server: never serve the endpoint unauthenticated.
    return { ok: false, status: 500, body: { error: "cron_secret_not_configured" } };
  }

  // Preferred: Authorization: Bearer <secret>
  const authHeader = request.headers.get("authorization") ?? "";
  const bearer = authHeader.toLowerCase().startsWith("bearer ")
    ? authHeader.slice(7).trim()
    : null;
  if (bearer && cronSecret && safeEqual(bearer, cronSecret)) return { ok: true };

  // Backwards-compatible: apikey / x-api-key with publishable key
  const apiKey = request.headers.get("apikey") ?? request.headers.get("x-api-key");
  if (apiKey && publishable && safeEqual(apiKey, publishable)) return { ok: true };

  return { ok: false, status: 401, body: { error: "unauthorized" } };
}

export function cronAuthErrorResponse(result: Extract<CronAuthResult, { ok: false }>): Response {
  return new Response(JSON.stringify(result.body), {
    status: result.status,
    headers: { "content-type": "application/json" },
  });
}
