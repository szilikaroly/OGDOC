/**
 * 7. fázis — Foglalás-életciklus + elégedettségi meghívó.
 *
 * Védett serverFn-ek (manage_schedule jog):
 *  - markArrived: foglalt → megerkezett (+ patient_checkin sor opcionálisan)
 *  - markCompleted: megerkezett → befejezett (+ auto-meghívó megnyit)
 *  - markNoShow: foglalt/megerositendo → nem_jelent_meg
 *  - issueSatisfactionInvite: link generálás + notification a foglaló klinikusnak,
 *    e-mail küldés helykitöltő (Resend kapcsoló még nincs konfigurálva).
 */
import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const PermError = "Nincs jogosultsága a foglalás státusz módosításához.";

async function assertSchedulePermission(supabase: any, userId: string) {
  const { data, error } = await supabase.rpc("has_permission", {
    _user_id: userId,
    _perm: "manage_schedule",
  });
  if (error) throw new Error(error.message);
  if (!data) throw new Error(PermError);
}

async function transition(
  supabase: any,
  userId: string,
  appointmentId: string,
  toStatus: "megerkezett" | "befejezett" | "nem_jelent_meg",
  reason?: string,
) {
  const { data: appt, error: aerr } = await supabase
    .from("appointments")
    .select("id, status, tenant_id, foglalas_kod, vendeg_email")
    .eq("id", appointmentId)
    .single();
  if (aerr || !appt) throw new Error(aerr?.message ?? "Foglalás nem található.");
  if (appt.status === toStatus) return appt;
  if (appt.status === "lemondva") throw new Error("Lemondott foglalás nem módosítható.");

  const { error: uerr } = await supabase
    .from("appointments")
    .update({ status: toStatus })
    .eq("id", appointmentId);
  if (uerr) throw new Error(uerr.message);

  await supabase.from("appointment_status_events").insert({
    appointment_id: appointmentId,
    from_status: appt.status,
    to_status: toStatus,
    actor_id: userId,
    reason: reason ?? null,
    tenant_id: appt.tenant_id,
  });
  return appt;
}

const IdInput = z.object({ appointment_id: z.string().uuid() });
const IdReason = IdInput.extend({ reason: z.string().max(500).optional() });

export const markArrived = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => IdInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertSchedulePermission(context.supabase, context.userId);
    await transition(context.supabase, context.userId, data.appointment_id, "megerkezett");
    return { ok: true };
  });

export const markCompleted = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => IdInput.extend({ send_invite: z.boolean().default(true) }).parse(d))
  .handler(async ({ data, context }) => {
    await assertSchedulePermission(context.supabase, context.userId);
    const appt = await transition(
      context.supabase,
      context.userId,
      data.appointment_id,
      "befejezett",
    );
    let invite_url: string | null = null;
    if (data.send_invite && appt && (appt as any).foglalas_kod) {
      invite_url = await issueInviteInternal(
        context.supabase,
        context.userId,
        data.appointment_id,
      );
    }
    return { ok: true, invite_url };
  });

export const markNoShow = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => IdReason.parse(d))
  .handler(async ({ data, context }) => {
    await assertSchedulePermission(context.supabase, context.userId);
    await transition(
      context.supabase,
      context.userId,
      data.appointment_id,
      "nem_jelent_meg",
      data.reason,
    );
    return { ok: true };
  });

/** Generál egy publikus elégedettségi felmérés URL-t és értesítést rögzít. */
async function issueInviteInternal(
  supabase: any,
  userId: string,
  appointmentId: string,
): Promise<string> {
  const { data: appt, error } = await supabase
    .from("appointments")
    .select("foglalas_kod, vendeg_email, tenant_id, megjegyzes")
    .eq("id", appointmentId)
    .single();
  if (error || !appt) throw new Error(error?.message ?? "Foglalás nem található.");

  const base = process.env.PUBLIC_BASE_URL ?? "";
  const url = `${base}/elegedettseg/${appt.foglalas_kod}`;

  // értesítés a foglalás-tulajdonosnak (jelenlegi felhasználó)
  await supabase.from("notifications").insert({
    tenant_id: appt.tenant_id,
    user_id: userId,
    tipus: "elegedettseg",
    cim: "Elégedettségi felmérés kiküldve",
    uzenet: `Foglalás ${appt.foglalas_kod} — link: ${url}`,
    link: "/elegedettseg",
  });

  // jegyzés a foglaláson (egyszerű naplózás; valódi e-mail küldés Resend bekötés után aktiválható)
  const note = `[${new Date().toISOString().slice(0, 19)}] Felmérés link generálva: ${url}`;
  await supabase
    .from("appointments")
    .update({
      megjegyzes: appt.megjegyzes ? `${appt.megjegyzes}\n${note}` : note,
    })
    .eq("id", appointmentId);

  return url;
}

export const issueSatisfactionInvite = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => IdInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertSchedulePermission(context.supabase, context.userId);
    const url = await issueInviteInternal(context.supabase, context.userId, data.appointment_id);
    return { ok: true, url };
  });
