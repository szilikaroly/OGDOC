/**
 * Időpontfoglaló — slot-generálás heti sablonból (tiszta TS, framework-független).
 *
 * A DB-szintű generálást később egy RPC végezheti; ez a modul a kliens-/teszt-
 * oldali ellenőrzést és előnézetet támogatja, valamint az admin UI „generálás
 * időszakra" gombjának a háttér-számítását.
 */

export type AppointmentTemplate = {
  id: string;
  resource_id: string;
  org_unit_id: string | null;
  nap_bitmap: number; // bit 0 = Hé … bit 6 = Va
  kezd_ido: string;   // "HH:mm"
  veg_ido: string;    // "HH:mm"
  slot_perc: number;  // pl. 15
  kapacitas: number;  // alap 1
  ervenyes_tol: string; // "YYYY-MM-DD"
  ervenyes_ig: string | null;
  aktiv: boolean;
};

export type GeneratedSlot = {
  resource_id: string;
  org_unit_id: string | null;
  template_id: string;
  kezdo_ts: string; // ISO
  veg_ts: string;   // ISO
  kapacitas: number;
};

const TZ_OFFSET_MINUTES = 0; // a slotokat UTC ISO-ban adjuk vissza; a megjelenítés TZ-felelős

function parseHHmm(s: string): { h: number; m: number } {
  const [h, m] = s.split(":").map((x) => Number(x));
  if (!Number.isFinite(h) || !Number.isFinite(m)) {
    throw new Error(`Érvénytelen idő: ${s}`);
  }
  return { h, m };
}

function isoDateOnly(d: Date): string {
  return d.toISOString().slice(0, 10);
}

function addMinutes(d: Date, minutes: number): Date {
  return new Date(d.getTime() + minutes * 60_000);
}

function* dateRange(from: string, to: string): Generator<Date> {
  const start = new Date(`${from}T00:00:00Z`);
  const end = new Date(`${to}T00:00:00Z`);
  for (let d = new Date(start); d <= end; d = addMinutes(d, 24 * 60)) {
    yield new Date(d);
  }
}

/**
 * ISO-hét nap-bit: 0 = Hé … 6 = Va.
 */
function isoDowBit(d: Date): number {
  // Date.getUTCDay(): 0=Sun … 6=Sat → ISO: Mon=0 … Sun=6
  const dow = d.getUTCDay();
  return dow === 0 ? 6 : dow - 1;
}

export function expandSlotsFromTemplate(
  tpl: AppointmentTemplate,
  from: string,
  to: string,
  holidays: string[] = [],
): GeneratedSlot[] {
  if (!tpl.aktiv) return [];
  const slotMin = Math.max(1, Math.trunc(tpl.slot_perc));
  const { h: sh, m: sm } = parseHHmm(tpl.kezd_ido);
  const { h: eh, m: em } = parseHHmm(tpl.veg_ido);
  const startMin = sh * 60 + sm;
  const endMin = eh * 60 + em;
  if (endMin <= startMin) return [];

  const holidaySet = new Set(holidays);
  const validFrom = new Date(`${tpl.ervenyes_tol}T00:00:00Z`);
  const validTo = tpl.ervenyes_ig ? new Date(`${tpl.ervenyes_ig}T00:00:00Z`) : null;

  const out: GeneratedSlot[] = [];
  for (const day of dateRange(from, to)) {
    if (day < validFrom) continue;
    if (validTo && day > validTo) continue;
    const bit = isoDowBit(day);
    if ((tpl.nap_bitmap & (1 << bit)) === 0) continue;
    const dayKey = isoDateOnly(day);
    if (holidaySet.has(dayKey)) continue;

    for (let cur = startMin; cur + slotMin <= endMin; cur += slotMin) {
      const startTs = new Date(day);
      startTs.setUTCMinutes(cur - TZ_OFFSET_MINUTES);
      const endTs = addMinutes(startTs, slotMin);
      out.push({
        resource_id: tpl.resource_id,
        org_unit_id: tpl.org_unit_id,
        template_id: tpl.id,
        kezdo_ts: startTs.toISOString(),
        veg_ts: endTs.toISOString(),
        kapacitas: tpl.kapacitas,
      });
    }
  }
  return out;
}

/**
 * Rövid, ember által beírható foglalási kód generálása (10 karakter, kerüli a
 * félreérthető glifeket: 0/O, 1/I/L). Alapértelmezésben kriptográfiailag erős
 * forrásból (WebCrypto / Node crypto) húz; tesztekben átadható determinisztikus
 * `rand` függvény.
 */
export function generateBookingCode(rand?: () => number): string {
  const alphabet = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
  const length = 10;
  if (rand) {
    let out = "";
    for (let i = 0; i < length; i++) {
      out += alphabet[Math.floor(rand() * alphabet.length)];
    }
    return out;
  }
  // Kriptográfiailag erős: rejection sampling, hogy ne torzítsa az eloszlást
  // (256 mod 31 != 0). Az alphabet hossza 31, így a 248..255 byte-okat eldobjuk.
  const cryptoObj: Crypto | undefined =
    typeof globalThis !== "undefined" ? (globalThis as { crypto?: Crypto }).crypto : undefined;
  if (!cryptoObj?.getRandomValues) {
    throw new Error("Cryptographically secure RNG is required to generate booking codes");
  }
  const maxAcceptable = Math.floor(256 / alphabet.length) * alphabet.length; // 248
  let out = "";
  const buf = new Uint8Array(length * 2);
  while (out.length < length) {
    cryptoObj.getRandomValues(buf);
    for (let i = 0; i < buf.length && out.length < length; i++) {
      const b = buf[i];
      if (b < maxAcceptable) out += alphabet[b % alphabet.length];
    }
  }
  return out;
}
