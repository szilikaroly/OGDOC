import { describe, it, expect } from "vitest";
import {
  expandSlotsFromTemplate,
  generateBookingCode,
  type AppointmentTemplate,
} from "./slots";

const baseTpl: AppointmentTemplate = {
  id: "tpl-1",
  resource_id: "res-1",
  org_unit_id: null,
  nap_bitmap: 0b0011111, // Hé–Pé
  kezd_ido: "08:00",
  veg_ido: "12:00",
  slot_perc: 15,
  kapacitas: 1,
  ervenyes_tol: "2026-01-01",
  ervenyes_ig: null,
  aktiv: true,
};

describe("expandSlotsFromTemplate", () => {
  it("Hé–Pé sablon 4 órás napra 16 slotot ad / nap", () => {
    // 2026-06-22 (Hé) – 2026-06-26 (Pé)
    const slots = expandSlotsFromTemplate(baseTpl, "2026-06-22", "2026-06-26");
    expect(slots).toHaveLength(16 * 5);
    expect(slots[0]?.kezdo_ts.endsWith("T08:00:00.000Z")).toBe(true);
  });

  it("hétvégét kihagy és ünnepnapot kizár", () => {
    const slots = expandSlotsFromTemplate(
      baseTpl,
      "2026-06-22",
      "2026-06-28",
      ["2026-06-24"], // Sze ünnep
    );
    expect(slots).toHaveLength(16 * 4); // Sze kihagyva
  });

  it("inaktív sablon nem ad slotot", () => {
    const slots = expandSlotsFromTemplate(
      { ...baseTpl, aktiv: false },
      "2026-06-22",
      "2026-06-26",
    );
    expect(slots).toHaveLength(0);
  });

  it("érvényesség határoló: ervenyes_ig", () => {
    const slots = expandSlotsFromTemplate(
      { ...baseTpl, ervenyes_ig: "2026-06-23" },
      "2026-06-22",
      "2026-06-26",
    );
    expect(slots).toHaveLength(16 * 2);
  });
});

describe("generateBookingCode", () => {
  it("10 karakteres, csak engedélyezett glifek", () => {
    const code = generateBookingCode(() => 0.5);
    expect(code).toHaveLength(10);
    expect(/^[ABCDEFGHJKMNPQRSTUVWXYZ23456789]+$/.test(code)).toBe(true);
  });
});
