/**
 * Időpontfoglaló — admin/klinikus oldali serverFn-ek (védett, requireSupabaseAuth).
 *
 * A publikus vendég-foglalás külön TanStack server route-okban él
 * (src/routes/api/public/booking/*), mert a vendég nincs bejelentkezve.
 */
import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";
import { expandSlotsFromTemplate, type AppointmentTemplate } from "./slots";

const TenantPermError = "Nincs jogosultsága a foglaló-modul kezeléséhez.";

async function assertSchedulePermission(supabase: any, userId: string): Promise<void> {
  const { data, error } = await supabase.rpc("has_permission", {
    _user_id: userId,
    _perm: "manage_schedule",
  });
  if (error) throw new Error(error.message);
  if (!data) throw new Error(TenantPermError);
}

async function getTenantId(supabase: any, userId: string): Promise<string> {
  const { data, error } = await supabase
    .from("profiles").select("tenant_id").eq("id", userId).single();
  if (error) throw new Error(error.message);
  const t = data?.tenant_id;
  if (!t) throw new Error("Hiányzó tenant.");
  return t as string;
}

/** napok (ISO 1=Hé … 7=Va) → bitmap (bit 0 = Hé … bit 6 = Va) */
function napokToBitmap(napok: number[]): number {
  let m = 0;
  for (const n of napok) {
    if (n >= 1 && n <= 7) m |= 1 << (n - 1);
  }
  return m;
}

/* ---------- Erőforrások listája (admin) ---------- */
export const listResources = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("appointment_resources")
      .select("id, nev, tipus, orvos_id, org_unit_id, szakma_id, aktiv, leiras")
      .order("nev");
    if (error) throw new Error(error.message);
    return data ?? [];
  });

/* ---------- Sablon CRUD ---------- */
const TemplateInput = z.object({
  id: z.string().uuid().optional(),
  resource_id: z.string().uuid(),
  nev: z.string().min(1).max(200),
  napok: z.array(z.number().int().min(1).max(7)).min(1),
  kezd_ido: z.string().regex(/^\d{2}:\d{2}$/),
  veg_ido: z.string().regex(/^\d{2}:\d{2}$/),
  slot_perc: z.number().int().min(5).max(240),
  kapacitas: z.number().int().min(1).max(20).default(1),
  ervenyes_tol: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  ervenyes_ig: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).nullable().optional(),
  aktiv: z.boolean().default(true),
  unnepnap_uzemel: z.boolean().default(false),
});

export const upsertTemplate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => TemplateInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertSchedulePermission(context.supabase, context.userId);
    const tenant_id = await getTenantId(context.supabase, context.userId);
    const payload = { ...data, tenant_id };
    const { data: row, error } = await context.supabase
      .from("appointment_templates")
      .upsert(payload, { onConflict: "id" })
      .select()
      .single();
    if (error) throw new Error(error.message);
    return row;
  });

/* ---------- Slot-generálás időszakra ---------- */
const GenerateInput = z.object({
  template_id: z.string().uuid(),
  from: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  to: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
});

export const generateSlots = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => GenerateInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertSchedulePermission(context.supabase, context.userId);
    const { data: tpl, error: terr } = await context.supabase
      .from("appointment_templates").select("*").eq("id", data.template_id).single();
    if (terr || !tpl) throw new Error(terr?.message ?? "Sablon nem található.");
    const { data: holidays } = await context.supabase
      .from("public_holidays")
      .select("datum")
      .gte("datum", data.from)
      .lte("datum", data.to);
    const holidayDates = (tpl.unnepnap_uzemel ? [] : (holidays ?? [])).map(
      (h: { datum: string }) => h.datum,
    );
    // adapter: a tiszta TS slot-generátor `nap_bitmap`-et használ
    const tplForExpand: AppointmentTemplate = {
      id: tpl.id,
      resource_id: tpl.resource_id,
      org_unit_id: null,
      nap_bitmap: napokToBitmap(tpl.napok ?? []),
      kezd_ido: tpl.kezd_ido,
      veg_ido: tpl.veg_ido,
      slot_perc: tpl.slot_perc,
      kapacitas: tpl.kapacitas,
      ervenyes_tol: tpl.ervenyes_tol,
      ervenyes_ig: tpl.ervenyes_ig,
      aktiv: tpl.aktiv,
    };
    const slots = expandSlotsFromTemplate(tplForExpand, data.from, data.to, holidayDates);
    if (!slots.length) return { inserted: 0 };
    const rows = slots.map((s) => ({
      resource_id: s.resource_id,
      org_unit_id: s.org_unit_id,
      template_id: s.template_id,
      kezdo_ts: s.kezdo_ts,
      veg_ts: s.veg_ts,
      kapacitas: s.kapacitas,
      tenant_id: tpl.tenant_id,
      status: "szabad" as const,
    }));
    const { error, count } = await context.supabase
      .from("appointment_slots")
      .upsert(rows, { onConflict: "resource_id,kezdo_ts", ignoreDuplicates: true, count: "exact" });
    if (error) throw new Error(error.message);
    return { inserted: count ?? rows.length };
  });

/* ---------- Foglalások admin nézet ---------- */
const AppointmentsListInput = z.object({
  from: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  to: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  resource_id: z.string().uuid().optional(),
});

export const listAppointments = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => AppointmentsListInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertSchedulePermission(context.supabase, context.userId);
    let q = context.supabase
      .from("appointments")
      .select("id, foglalas_kod, status, sync_statusz, vendeg_nev, vendeg_email, vendeg_telefon, megjegyzes, resource_id, slot_id, appointment_slots!inner(kezdo_ts, veg_ts)")
      .gte("appointment_slots.kezdo_ts", `${data.from}T00:00:00Z`)
      .lte("appointment_slots.kezdo_ts", `${data.to}T23:59:59Z`);
    if (data.resource_id) q = q.eq("resource_id", data.resource_id);
    const { data: rows, error } = await q.order("created_at", { ascending: false }).limit(500);
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

/* ---------- Lemondás (admin) ---------- */
const CancelInput = z.object({
  appointment_id: z.string().uuid(),
  reason: z.string().min(1).max(500),
});

export const adminCancelAppointment = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => CancelInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertSchedulePermission(context.supabase, context.userId);
    const { data: appt, error: aerr } = await context.supabase
      .from("appointments").select("id, slot_id, status, tenant_id").eq("id", data.appointment_id).single();
    if (aerr || !appt) throw new Error(aerr?.message ?? "Foglalás nem található.");
    if (appt.status === "lemondva") return { ok: true };

    const { error: uerr } = await context.supabase
      .from("appointments")
      .update({ status: "lemondva" })
      .eq("id", data.appointment_id);
    if (uerr) throw new Error(uerr.message);

    await context.supabase.from("appointment_status_events").insert({
      appointment_id: data.appointment_id,
      from_status: appt.status,
      to_status: "lemondva",
      actor_id: context.userId,
      reason: data.reason,
      tenant_id: appt.tenant_id,
    });
    await context.supabase
      .from("appointment_slots")
      .update({ status: "szabad" })
      .eq("id", appt.slot_id);
    return { ok: true };
  });
