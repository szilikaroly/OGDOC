/**
 * Video URL helpers — extract IDs, build embed URLs, and produce a
 * normalized technical metadata shape (poster/width/height/duration)
 * that self-host, YouTube and Vimeo videos can all be rendered from
 * the same way.
 *
 * Pure, isomorphic.
 */

export type VideoProvider = "youtube" | "vimeo" | "file";

/** Default embed size for iframe-based providers (YouTube / Vimeo). */
export const DEFAULT_EMBED_WIDTH = 1280;
export const DEFAULT_EMBED_HEIGHT = 720;

export function detectProvider(url: string | null | undefined): VideoProvider | null {
  if (!url) return null;
  const u = url.toLowerCase();
  if (u.includes("youtube.com") || u.includes("youtu.be")) return "youtube";
  if (u.includes("vimeo.com")) return "vimeo";
  if (/\.(mp4|webm|mov|m4v)(\?|$)/i.test(u)) return "file";
  return null;
}

export function extractYouTubeId(url: string): string | null {
  try {
    const u = new URL(url);
    if (u.hostname.includes("youtu.be")) return u.pathname.slice(1).split("/")[0] || null;
    if (u.searchParams.get("v")) return u.searchParams.get("v");
    const m = u.pathname.match(/\/embed\/([^/?]+)/) || u.pathname.match(/\/shorts\/([^/?]+)/);
    if (m) return m[1];
    return null;
  } catch { return null; }
}

export function extractVimeoId(url: string): string | null {
  try {
    const u = new URL(url);
    const m = u.pathname.match(/\/(\d+)/);
    return m ? m[1] : null;
  } catch { return null; }
}

export function buildEmbedUrl(url: string | null | undefined, provider?: VideoProvider | null): string | null {
  if (!url) return null;
  const p = provider ?? detectProvider(url);
  if (p === "youtube") {
    const id = extractYouTubeId(url);
    return id ? `https://www.youtube-nocookie.com/embed/${id}?rel=0` : null;
  }
  if (p === "vimeo") {
    const id = extractVimeoId(url);
    return id ? `https://player.vimeo.com/video/${id}?dnt=1` : null;
  }
  if (p === "file") return url;
  return null;
}

export function buildVideoThumbnail(
  url: string | null | undefined,
  provider?: VideoProvider | null,
): string | null {
  if (!url) return null;
  const p = provider ?? detectProvider(url);
  if (p === "youtube") {
    const id = extractYouTubeId(url);
    return id ? `https://i.ytimg.com/vi/${id}/hqdefault.jpg` : null;
  }
  return null;
}

export function formatDuration(seconds: number | null | undefined): string {
  if (!seconds || seconds < 0) return "";
  const s = Math.floor(seconds);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
  return `${m}:${String(sec).padStart(2, "0")}`;
}

export function durationToISO8601(seconds: number | null | undefined): string | undefined {
  if (!seconds || seconds < 0) return undefined;
  const s = Math.floor(seconds);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  let out = "PT";
  if (h) out += `${h}H`;
  if (m) out += `${m}M`;
  if (sec || (!h && !m)) out += `${sec}S`;
  return out;
}

/* ============================================================
 * Normalized video meta — self-host, YouTube, Vimeo unified
 * ============================================================ */

/** Loose input coming from either a `cms_news_posts` row or a block payload. */
export interface VideoInput {
  video_provider?: VideoProvider | null;
  video_url?: string | null;
  video_embed_url?: string | null;
  video_thumbnail_url?: string | null;
  video_duration_seconds?: number | null;
  video_width?: number | null;
  video_height?: number | null;
  /** Optional fallback poster (e.g. featured image). */
  fallback_poster?: string | null;
}

export interface VideoMeta {
  provider: VideoProvider | null;
  /** Canonical source URL (page URL for YT/Vimeo, file URL for self-host). */
  url: string | null;
  /** URL to embed in an <iframe> OR play in a <video> tag. Null if unusable. */
  embedUrl: string | null;
  /** Poster image for the player and og:image. */
  poster: string | null;
  /** Intrinsic width in px (defaults to 1280 for iframe providers). */
  width: number | null;
  /** Intrinsic height in px (defaults to 720 for iframe providers). */
  height: number | null;
  /** Duration in seconds. */
  durationSeconds: number | null;
  /** Duration formatted mm:ss / hh:mm:ss. */
  durationLabel: string;
  /** ISO 8601 duration for schema.org VideoObject. */
  durationIso: string | undefined;
  /** Aspect ratio expressed as `${w}/${h}`, for CSS `aspect-ratio`. */
  aspectRatio: string;
  /** Convenience: true when we have a working embed. */
  isPlayable: boolean;
  /** Convenience: true for self-hosted file. */
  isFile: boolean;
}

/**
 * Normalize any video input into a uniform shape.
 * The same output feeds the CMS renderer, vlog page, og:video tags and
 * schema.org VideoObject JSON-LD.
 */
export function normalizeVideoMeta(input: VideoInput | null | undefined): VideoMeta {
  const src = input ?? {};
  const url = src.video_url ?? null;
  const provider = (src.video_provider ?? detectProvider(url)) as VideoProvider | null;

  const embedUrl = src.video_embed_url || buildEmbedUrl(url, provider) || null;
  const poster =
    src.video_thumbnail_url ||
    buildVideoThumbnail(url, provider) ||
    src.fallback_poster ||
    null;

  const isFile = provider === "file";
  const defaultsForEmbed = provider === "youtube" || provider === "vimeo";
  const width = src.video_width ?? (defaultsForEmbed ? DEFAULT_EMBED_WIDTH : null);
  const height = src.video_height ?? (defaultsForEmbed ? DEFAULT_EMBED_HEIGHT : null);

  const durationSeconds = src.video_duration_seconds ?? null;
  const aspectRatio = width && height ? `${width}/${height}` : "16/9";

  return {
    provider,
    url,
    embedUrl,
    poster,
    width,
    height,
    durationSeconds,
    durationLabel: formatDuration(durationSeconds),
    durationIso: durationToISO8601(durationSeconds),
    aspectRatio,
    isPlayable: !!embedUrl,
    isFile,
  };
}

/**
 * Best-effort oEmbed fetch for YouTube and Vimeo. Returns width/height,
 * poster and — for Vimeo — duration. Safe to call from Worker runtime
 * (uses `fetch` only). YouTube's oEmbed does not expose duration.
 */
export async function fetchVideoOEmbed(url: string): Promise<{
  provider: VideoProvider;
  width?: number;
  height?: number;
  thumbnail_url?: string;
  duration?: number;
  title?: string;
} | null> {
  const provider = detectProvider(url);
  if (!provider || provider === "file") return null;

  const endpoint =
    provider === "youtube"
      ? `https://www.youtube.com/oembed?format=json&url=${encodeURIComponent(url)}`
      : `https://vimeo.com/api/oembed.json?url=${encodeURIComponent(url)}`;

  try {
    const r = await fetch(endpoint, { headers: { accept: "application/json" } });
    if (!r.ok) return null;
    const j: any = await r.json();
    return {
      provider,
      width: typeof j.width === "number" ? j.width : undefined,
      height: typeof j.height === "number" ? j.height : undefined,
      thumbnail_url: typeof j.thumbnail_url === "string" ? j.thumbnail_url : undefined,
      duration: typeof j.duration === "number" ? j.duration : undefined,
      title: typeof j.title === "string" ? j.title : undefined,
    };
  } catch {
    return null;
  }
}
