/**
 * Tanácsok – megtekintés / lájk / komment szerver fn-ek.
 * Mind anon-safe; mutációknál RLS érvényesül.
 */
import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

function pub() {
  return createClient(
    process.env.SUPABASE_URL!,
    process.env.SUPABASE_PUBLISHABLE_KEY!,
    { auth: { storage: undefined, persistSession: false, autoRefreshToken: false } },
  );
}

/* ------- megtekintés (anon-ok is loggolhatnak) ------- */
export const recordTipView = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) =>
    z.object({
      tipId: z.string().uuid(),
      sessionHash: z.string().max(64).optional(),
      locale: z.string().max(8).optional(),
    }).parse(d),
  )
  .handler(async ({ data }) => {
    const sb = pub();
    await sb.from("cms_tip_views").insert({
      tip_id: data.tipId,
      session_hash: data.sessionHash ?? null,
      locale: data.locale ?? null,
    });
    return { ok: true };
  });

/* ------- lájkok ------- */
export const getTipEngagement = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) => z.object({ tipId: z.string().uuid() }).parse(d))
  .handler(async ({ data }) => {
    const sb = pub();
    const [{ count: views }, { count: likes }, { count: comments }] = await Promise.all([
      sb.from("cms_tip_views").select("*", { count: "exact", head: true }).eq("tip_id", data.tipId),
      sb.from("cms_tip_likes").select("*", { count: "exact", head: true }).eq("tip_id", data.tipId),
      sb.from("cms_tip_comments").select("*", { count: "exact", head: true }).eq("tip_id", data.tipId).eq("status", "approved"),
    ]);
    return { views: views ?? 0, likes: likes ?? 0, comments: comments ?? 0 };
  });

export const toggleTipLike = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ tipId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const sb = context.supabase as any;
    const { data: existing } = await sb
      .from("cms_tip_likes")
      .select("user_id")
      .eq("tip_id", data.tipId)
      .eq("user_id", context.userId)
      .maybeSingle();
    if (existing) {
      await sb.from("cms_tip_likes").delete().eq("tip_id", data.tipId).eq("user_id", context.userId);
      return { liked: false };
    }
    await sb.from("cms_tip_likes").insert({ tip_id: data.tipId, user_id: context.userId });
    return { liked: true };
  });

export const isTipLiked = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ tipId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { data: row } = await (context.supabase as any)
      .from("cms_tip_likes")
      .select("user_id")
      .eq("tip_id", data.tipId)
      .eq("user_id", context.userId)
      .maybeSingle();
    return { liked: !!row };
  });

/* ------- kommentek ------- */
export const listTipComments = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) => z.object({ tipId: z.string().uuid() }).parse(d))
  .handler(async ({ data }) => {
    const sb = pub();
    const { data: rows } = await sb
      .from("cms_tip_comments")
      .select("id, parent_id, body, status, created_at, user_id")
      .eq("tip_id", data.tipId)
      .eq("status", "approved")
      .order("created_at", { ascending: true })
      .limit(200);
    return rows ?? [];
  });

export const postTipComment = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({
      tipId: z.string().uuid(),
      body: z.string().min(2).max(2000),
      parentId: z.string().uuid().optional(),
    }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { data: row, error } = await (context.supabase as any)
      .from("cms_tip_comments")
      .insert({
        tip_id: data.tipId,
        user_id: context.userId,
        body: data.body,
        parent_id: data.parentId ?? null,
        status: "pending",
      })
      .select("*")
      .single();
    if (error) throw new Error(error.message);
    return row;
  });

export const moderateTipComment = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({
      id: z.string().uuid(),
      status: z.enum(["approved", "rejected", "pending"]),
    }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { data: isAdmin } = await (context.supabase as any).rpc("has_role", { _user_id: context.userId, _role: "admin" });
    if (!isAdmin) throw new Error("Forbidden");
    const { error } = await (context.supabase as any)
      .from("cms_tip_comments")
      .update({ status: data.status })
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const listPendingComments = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data: isAdmin } = await (context.supabase as any).rpc("has_role", { _user_id: context.userId, _role: "admin" });
    if (!isAdmin) throw new Error("Forbidden");
    const { data: rows } = await (context.supabase as any)
      .from("cms_tip_comments")
      .select("id, tip_id, user_id, body, status, created_at")
      .in("status", ["pending"])
      .order("created_at", { ascending: false })
      .limit(100);
    return rows ?? [];
  });
