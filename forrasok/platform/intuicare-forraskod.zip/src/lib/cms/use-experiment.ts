/**
 * React hook a publikus CMS blokk-rendererhez.
 * Adott blockId-re lekéri a futó A/B kísérleteket, sticky variantot választ
 * (session_id alapú, determinisztikus), automatikusan view-t trackel,
 * és visszaadja a variant.content override-ot + trackGoal callbacket.
 */
import { useEffect, useMemo, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getRunningExperimentsForBlock } from "./experiments.functions";
import {
  getOrCreateSessionId,
  pickVariant,
  trackExperimentEvent,
  type Variant,
} from "./experiments";
import { installTrackingBootstrap, registerActiveExperiment } from "./tracking-bootstrap";
import { addDebugEntry, removeDebugEntry } from "./experiment-debug";

export interface ExperimentSelection {
  experimentId: string;
  experimentName?: string;
  variantId: string;
  variantKey: string;
  isControl?: boolean;
  content: Record<string, any>;
}

export interface UseExperimentResult {
  /** A blockhoz kiválasztott variantok (több párhuzamos kísérlet esetén is). */
  selections: ExperimentSelection[];
  /** Az első kísérlet variant.content-je, mergelésre alkalmas objektum. */
  variantContent: Record<string, any> | null;
  /** Konverziós esemény jelzés — az összes aktív kísérletre elküldi. */
  trackGoal: (name?: string, params?: Record<string, unknown>) => void;
  isLoading: boolean;
}

const EMPTY: UseExperimentResult = {
  selections: [],
  variantContent: null,
  trackGoal: () => {},
  isLoading: false,
};

/**
 * @param blockId Publikus block id (cms_blocks.id vagy layout_blocks.id).
 * @param opts.kind Melyik oszlopra keressen — alapból "block".
 * @param opts.enabled Kikapcsolható (pl. admin edit / draft nézetben).
 */
export function useExperiment(
  blockId: string | undefined,
  opts: {
    kind?: "block" | "layout_block";
    enabled?: boolean;
    blockType?: string;
    blockLabel?: string;
  } = {},
): UseExperimentResult {
  const enabled = (opts.enabled ?? true) && !!blockId && typeof window !== "undefined";
  const fetchExps = useServerFn(getRunningExperimentsForBlock);
  const kind = opts.kind ?? "block";

  const { data, isLoading } = useQuery({
    queryKey: ["cms-experiments", kind, blockId],
    enabled,
    staleTime: 5 * 60 * 1000,
    gcTime: 10 * 60 * 1000,
    queryFn: async () => {
      const payload = kind === "layout_block"
        ? { layout_block_id: blockId! }
        : { block_id: blockId! };
      return fetchExps({ data: payload });
    },
  });

  const selections = useMemo<ExperimentSelection[]>(() => {
    if (!enabled || !data?.experiments?.length) return [];
    const sid = getOrCreateSessionId();
    const out: ExperimentSelection[] = [];
    for (const exp of data.experiments as any[]) {
      const variants: Variant[] = (exp.cms_experiment_variants ?? []).map((v: any) => ({
        id: v.id,
        key: v.key,
        weight: Number(v.weight ?? 1),
        content: v.content ?? {},
        is_control: !!v.is_control,
      }));
      if (variants.length === 0) continue;
      const picked = pickVariant(exp.id, variants, sid, Number(exp.traffic_allocation ?? 1));
      if (!picked) continue;
      out.push({
        experimentId: exp.id,
        experimentName: exp.name ?? undefined,
        variantId: picked.id,
        variantKey: picked.key,
        isControl: !!picked.is_control,
        content: (picked.content && typeof picked.content === "object") ? picked.content : {},
      });
    }
    return out;
  }, [data, enabled]);

  // View tracking — sessiononként egyszer / kísérlet.
  const trackedRef = useRef<Set<string>>(new Set());
  useEffect(() => {
    if (!enabled) return;
    for (const sel of selections) {
      const key = `cms_exp_viewed:${sel.experimentId}`;
      if (trackedRef.current.has(sel.experimentId)) continue;
      try {
        if (window.sessionStorage.getItem(key) === sel.variantId) {
          trackedRef.current.add(sel.experimentId);
          continue;
        }
        window.sessionStorage.setItem(key, sel.variantId);
      } catch { /* private mode */ }
      trackedRef.current.add(sel.experimentId);
      trackExperimentEvent({
        experiment_id: sel.experimentId,
        variant_id: sel.variantId,
        event_type: "view",
      });
    }
  }, [enabled, selections]);

  // Regisztráljuk az aktív variantokat a globális trackernek (window.lovableTrack + [data-track])
  // + a debug store-ba is bejegyezzük (admin overlayhez).
  useEffect(() => {
    if (!enabled || selections.length === 0 || !blockId) return;
    installTrackingBootstrap();
    const disposers = selections.map((s) => {
      const dkey = `${blockId}::${s.experimentId}`;
      addDebugEntry({
        key: dkey,
        blockId,
        blockKind: kind,
        blockType: opts.blockType,
        blockLabel: opts.blockLabel,
        experimentId: s.experimentId,
        experimentName: s.experimentName,
        variantId: s.variantId,
        variantKey: s.variantKey,
        isControl: s.isControl,
      });
      const off = registerActiveExperiment({ experimentId: s.experimentId, variantId: s.variantId });
      return () => { off(); removeDebugEntry(dkey); };
    });
    return () => { for (const d of disposers) d(); };
  }, [enabled, selections, blockId, kind, opts.blockType, opts.blockLabel]);

  const variantContent = selections[0]?.content ?? null;

  const trackGoal = useMemo(() => {
    return (name?: string, params?: Record<string, unknown>) => {
      for (const sel of selections) {
        trackExperimentEvent({
          experiment_id: sel.experimentId,
          variant_id: sel.variantId,
          event_type: "goal",
          event_name: name,
          params,
        });
      }
    };
  }, [selections]);

  if (!enabled) return EMPTY;
  return { selections, variantContent, trackGoal, isLoading };
}
