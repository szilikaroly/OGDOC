/**
 * AI-asszisztált tartalom-készítés Tanácsokhoz.
 * - Draft szövegből / hangból / dokumentumból
 * - Auto-fordítás 9 nyelvre
 * - Inline szerkesztő-asszisztens (improve)
 * - SEO javaslat
 */
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const GATEWAY = "https://ai.gateway.lovable.dev/v1/chat/completions";
const DEFAULT_MODEL = "google/gemini-2.5-flash";
const PRO_MODEL = "google/gemini-2.5-pro";

async function callGateway(body: any) {
  const apiKey = process.env.LOVABLE_API_KEY;
  if (!apiKey) throw new Error("LOVABLE_API_KEY hiányzik");
  const res = await fetch(GATEWAY, {
    method: "POST",
    headers: { "content-type": "application/json", authorization: `Bearer ${apiKey}` },
    body: JSON.stringify(body),
  });
  if (res.status === 429) throw new Error("AI rate limit – próbáld pár perc múlva.");
  if (res.status === 402) throw new Error("AI kredit elfogyott – egészítsd ki a workspace egyenleget.");
  if (!res.ok) {
    const t = await res.text();
    throw new Error(`AI hiba ${res.status}: ${t.slice(0, 240)}`);
  }
  return (await res.json()) as any;
}

function extractJson(text: string): any {
  // strip code fences
  const cleaned = text.replace(/^```(?:json)?\s*/i, "").replace(/```\s*$/i, "").trim();
  try { return JSON.parse(cleaned); } catch {}
  // try to find first { ... }
  const m = cleaned.match(/\{[\s\S]*\}/);
  if (m) {
    try { return JSON.parse(m[0]); } catch {}
  }
  throw new Error("AI nem JSON választ adott");
}

const DraftSchemaText = `Adj VISSZA EGYETLEN érvényes JSON-t, ezzel a sémával:
{
  "title": string,                       // tömör, vonzó cím
  "lead": string,                        // 1-2 mondatos összefoglaló (max 200 karakter)
  "body_html": string,                   // sanitizable HTML (h2, h3, p, ul, ol, strong, em, a). Ne tartalmazzon scriptet vagy stílust.
  "suggested_slug": string,              // kisbetűs, kötőjeles
  "suggested_tags": string[],            // max 6
  "reading_minutes": number              // becsült olvasási idő
}
Csak a JSON-t küldd vissza, semmi mást.`;

const SYSTEM_HU = `Magyar nyelvű egészségügyi szerkesztő-asszisztens vagy egy klinika tudásbázisához ("Tanácsok"). Mindig közérthető, lektorált, biztonságos tanácsokat fogalmazz meg, ne adj egyéni orvosi tanácsot, és emeld ki, mikor kell orvoshoz fordulni. A választ a kért JSON-sémában add vissza.`;

// ============== Draft from text ==============

export const aiDraftTipFromText = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({
    source_text: z.string().min(20).max(20000),
    locale: z.string().default("hu"),
    audience: z.string().optional(),
  }).parse(d))
  .handler(async ({ data }) => {
    const userPrompt = `${data.audience ? `CÉLKÖZÖNSÉG: ${data.audience}\n\n` : ""}FORRÁS:\n${data.source_text}\n\nFeladat: készíts ennek alapján egy publikálható egészségügyi „Tanács" cikket a(z) ${data.locale} nyelven. ${DraftSchemaText}`;
    const json = await callGateway({
      model: DEFAULT_MODEL,
      messages: [{ role: "system", content: SYSTEM_HU }, { role: "user", content: userPrompt }],
      response_format: { type: "json_object" },
    });
    const txt = json.choices?.[0]?.message?.content ?? "";
    return extractJson(txt);
  });

// ============== Draft from audio ==============

export const aiDraftTipFromAudio = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({
    audio_base64: z.string().min(1),
    format: z.enum(["wav", "mp3", "webm", "m4a", "ogg"]).default("webm"),
    locale: z.string().default("hu"),
    audience: z.string().optional(),
  }).parse(d))
  .handler(async ({ data }) => {
    const userPrompt = [
      { type: "text", text: `${data.audience ? `CÉLKÖZÖNSÉG: ${data.audience}\n\n` : ""}Hallgasd meg az alábbi hangfelvételt, írj át, majd készíts belőle publikálható ${data.locale} nyelvű "Tanács" cikket. ${DraftSchemaText}` },
      { type: "input_audio", input_audio: { data: data.audio_base64, format: data.format } },
    ];
    const json = await callGateway({
      model: PRO_MODEL,
      messages: [{ role: "system", content: SYSTEM_HU }, { role: "user", content: userPrompt }],
      response_format: { type: "json_object" },
    });
    const txt = json.choices?.[0]?.message?.content ?? "";
    return extractJson(txt);
  });

// ============== Draft from document ==============

export const aiDraftTipFromDocument = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({
    file_base64: z.string().min(1),
    mime: z.string().min(3),
    filename: z.string().default("dokumentum.pdf"),
    locale: z.string().default("hu"),
    audience: z.string().optional(),
  }).parse(d))
  .handler(async ({ data }) => {
    const userPrompt = [
      { type: "text", text: `${data.audience ? `CÉLKÖZÖNSÉG: ${data.audience}\n\n` : ""}Olvasd el a csatolt dokumentumot, és készíts belőle egy publikálható ${data.locale} nyelvű „Tanács" cikket. ${DraftSchemaText}` },
      { type: "file", file: { filename: data.filename, file_data: `data:${data.mime};base64,${data.file_base64}` } },
    ];
    const json = await callGateway({
      model: PRO_MODEL,
      messages: [{ role: "system", content: SYSTEM_HU }, { role: "user", content: userPrompt }],
      response_format: { type: "json_object" },
    });
    const txt = json.choices?.[0]?.message?.content ?? "";
    return extractJson(txt);
  });

// ============== Translate to many locales ==============

export const aiTranslateTipToLocale = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({
    tip_id: z.string().uuid(),
    source_locale: z.string().default("hu"),
    target_locale: z.string().min(2),
  }).parse(d))
  .handler(async ({ data, context }) => {
    const { data: src, error } = await context.supabase
      .from("cms_tip_translations").select("*").eq("tip_id", data.tip_id).eq("locale", data.source_locale).maybeSingle();
    if (error) throw new Error(error.message);
    if (!src) throw new Error(`Nincs ${data.source_locale} forrás-fordítás`);

    const prompt = `Az alábbi mezőket fordítsd le pontosan, természetes nyelven a(z) ${data.target_locale} nyelvre. Tartsd meg a HTML struktúrát a body_html-ben. Add vissza ezzel a sémával:
{ "title": string, "lead": string, "body_html": string, "seo_title": string, "seo_description": string }
Csak a JSON-t.

FORRÁS (${data.source_locale}):
TITLE: ${src.title}
LEAD: ${src.lead ?? ""}
BODY_HTML: ${src.body_html ?? ""}
SEO_TITLE: ${src.seo_title ?? src.title}
SEO_DESCRIPTION: ${src.seo_description ?? src.lead ?? ""}`;

    const json = await callGateway({
      model: DEFAULT_MODEL,
      messages: [
        { role: "system", content: "Szakszerű egészségügyi szövegek fordítója vagy. Tartsd a tárgyilagos hangnemet és a HTML struktúrát." },
        { role: "user", content: prompt },
      ],
      response_format: { type: "json_object" },
    });
    const translated = extractJson(json.choices?.[0]?.message?.content ?? "");

    const upsert = {
      tip_id: data.tip_id,
      locale: data.target_locale,
      title: translated.title ?? "",
      lead: translated.lead ?? "",
      body_html: translated.body_html ?? "",
      body_json: {},
      seo_title: translated.seo_title ?? null,
      seo_description: translated.seo_description ?? null,
      ai_generated: true,
      ai_source_lang: data.source_locale,
      translation_status: "ai" as const,
    };
    const { error: upErr } = await context.supabase
      .from("cms_tip_translations").upsert(upsert, { onConflict: "tip_id,locale" });
    if (upErr) throw new Error(upErr.message);
    return { ok: true, locale: data.target_locale };
  });

// ============== Inline improve ==============

export const aiImproveTipText = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({
    html: z.string().min(1),
    instruction: z.string().min(2).max(400),
    locale: z.string().default("hu"),
  }).parse(d))
  .handler(async ({ data }) => {
    const json = await callGateway({
      model: DEFAULT_MODEL,
      messages: [
        { role: "system", content: `${SYSTEM_HU} Csak a kért HTML-t add vissza, semmi mást, kódblokk nélkül.` },
        { role: "user", content: `INSTRUKCIÓ: ${data.instruction}\nNyelv: ${data.locale}\nEREDETI HTML:\n${data.html}\n\nAdd vissza a módosított HTML-t.` },
      ],
    });
    const txt = String(json.choices?.[0]?.message?.content ?? "").replace(/^```(?:html)?\s*/i, "").replace(/```\s*$/i, "").trim();
    return { html: txt };
  });

// ============== SEO suggest ==============

export const aiSuggestTipSeo = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({
    title: z.string().min(1),
    lead: z.string().default(""),
    body_html: z.string().default(""),
    locale: z.string().default("hu"),
  }).parse(d))
  .handler(async ({ data }) => {
    const prompt = `Adj SEO javaslatot ehhez a Tanács cikkhez. Add vissza:
{ "seo_title": string (<=60 char), "seo_description": string (<=160 char), "og_title": string }
Nyelv: ${data.locale}
TITLE: ${data.title}
LEAD: ${data.lead}
BODY: ${data.body_html.replace(/<[^>]+>/g, " ").slice(0, 1500)}`;
    const json = await callGateway({
      model: DEFAULT_MODEL,
      messages: [{ role: "system", content: "SEO szakértő vagy." }, { role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });
    return extractJson(json.choices?.[0]?.message?.content ?? "");
  });
