/**
 * AI-alapú hír-poszt fordítás.
 * - Minden célnyelvre külön `cms_news_posts` sort hoz létre (ugyanaz a slug),
 *   a szöveges mezőket (title, excerpt, seo_title, seo_description,
 *   featured_image_alt, video_transcript, body JSON stringjei) Gemini
 *   fordítja le a `translation_glossary` figyelembevételével.
 * - Már létező locale-sort csak `overwrite=true` esetén ír felül.
 */
import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";
import { SUPPORTED_LANGUAGES, type LangCode } from "@/i18n/languages";

const LANG_CODES = SUPPORTED_LANGUAGES.map((l) => l.code) as unknown as [LangCode, ...LangCode[]];

async function assertCmsAccess(ctx: { supabase: any; userId: string }) {
  const { data, error } = await ctx.supabase.rpc("has_cms_access", { _user_id: ctx.userId });
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Forbidden");
}

// ── String-leaf util a body JSON-hoz ─────────────────────────────────────
type StringLeaf = { path: (string | number)[]; value: string };
const SKIP_KEYS = new Set([
  "id","slug","url","href","src","image","image_url","img","icon","type","kind",
  "variant","color","bg","background","className","target","rel","email","phone",
  "tel","locale","lang","utm",
]);
function collectStrings(node: any, out: StringLeaf[], path: (string | number)[] = []) {
  if (node == null) return;
  if (typeof node === "string") {
    if (/^(https?:|mailto:|tel:|\/|#)/i.test(node.trim())) return;
    const parent = path[path.length - 1];
    if (typeof parent === "string" && SKIP_KEYS.has(parent)) return;
    if (node.trim().length < 2 || !/[\p{L}]/u.test(node)) return;
    out.push({ path: [...path], value: node });
    return;
  }
  if (Array.isArray(node)) { node.forEach((v, i) => collectStrings(v, out, [...path, i])); return; }
  if (typeof node === "object") {
    for (const [k, v] of Object.entries(node)) {
      if (SKIP_KEYS.has(k)) continue;
      collectStrings(v, out, [...path, k]);
    }
  }
}
function setAtPath(root: any, path: (string | number)[], value: any) {
  let cur = root;
  for (let i = 0; i < path.length - 1; i++) cur = cur[path[i]];
  cur[path[path.length - 1]] = value;
}

// ── AI hívás ─────────────────────────────────────────────────────────────
async function aiTranslate(
  supabase: any,
  texts: Record<string, string>,
  target_lang: string,
  source_lang: string,
): Promise<Record<string, string>> {
  if (target_lang === source_lang || Object.keys(texts).length === 0) return texts;
  const key = process.env.LOVABLE_API_KEY;
  if (!key) throw new Error("Hiányzó LOVABLE_API_KEY.");
  const { createLovableAiGatewayProvider } = await import("@/lib/ai-gateway.server");
  const { generateText } = await import("ai");
  const gateway = createLovableAiGatewayProvider(key);
  const model = gateway("google/gemini-3-flash-preview");

  const { data: glossary } = await supabase
    .from("translation_glossary")
    .select("term,translation")
    .eq("target_lang", target_lang);
  const glossaryStr = (glossary ?? []).length
    ? `\nKötelező szótár:\n${(glossary ?? []).map((g: any) => `- ${g.term} → ${g.translation}`).join("\n")}`
    : "";

  const targetLabel = SUPPORTED_LANGUAGES.find((l) => l.code === target_lang)?.label ?? target_lang;
  const system = `Szakfordító vagy egészségügyi/klinikai hír-tartalomra. Forrásnyelv ${source_lang}, cél ${targetLabel} (${target_lang}).
- Csak az értékeket fordítsd, JSON kulcsokat változatlanul hagyd.
- Változók ({{var}}, {n}), HTML/Markdown tagek, URL-ek, e-mailek, számok, dátumok, egységek maradjanak.
- Természetes, közérthető sajtónyelv, ne túlformalizáld.
- A válasz KIZÁRÓLAG egy érvényes JSON objektum azonos kulcsokkal.${glossaryStr}`;
  const prompt = `Fordítsd le a következő JSON értékeit:\n\n${JSON.stringify(texts, null, 2)}`;
  const { text } = await generateText({ model, system, prompt });
  const cleaned = text.replace(/^```json\s*/i, "").replace(/^```\s*/i, "").replace(/```\s*$/i, "").trim();
  return JSON.parse(cleaned) as Record<string, string>;
}

// ── Listázás: melyik posztból hiányzik adott nyelvi variáns ───────────────
export const listNewsTranslationStatus = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({
    target_lang: z.enum(LANG_CODES),
    source_lang: z.enum(LANG_CODES).default("hu"),
    only_missing: z.boolean().default(true),
    limit: z.number().int().min(1).max(200).default(100),
  }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const sb = context.supabase;

    const { data: sourcePosts, error } = await sb
      .from("cms_news_posts")
      .select("id,slug,title,status,published_at,updated_at")
      .eq("locale", data.source_lang)
      .order("published_at", { ascending: false, nullsFirst: false })
      .limit(data.limit);
    if (error) throw new Error(error.message);

    const slugs = (sourcePosts ?? []).map((p: any) => p.slug);
    const { data: existing } = slugs.length
      ? await sb.from("cms_news_posts")
          .select("slug,updated_at")
          .eq("locale", data.target_lang)
          .in("slug", slugs)
      : { data: [] as any[] };
    const existingMap = new Map((existing ?? []).map((r: any) => [r.slug, r.updated_at]));

    const rows = (sourcePosts ?? []).map((p: any) => ({
      id: p.id,
      slug: p.slug,
      title: p.title,
      status: p.status,
      published_at: p.published_at,
      source_updated_at: p.updated_at,
      target_updated_at: existingMap.get(p.slug) ?? null,
      translated: existingMap.has(p.slug),
    }));
    return data.only_missing ? rows.filter((r) => !r.translated) : rows;
  });

// ── Fordítás ─────────────────────────────────────────────────────────────
const Input = z.object({
  post_ids: z.array(z.string().uuid()).min(1).max(20),
  target_langs: z.array(z.enum(LANG_CODES)).min(1),
  source_lang: z.enum(LANG_CODES).default("hu"),
  overwrite: z.boolean().default(false),
  publish_immediately: z.boolean().default(false),
});

const SIMPLE_TEXT_FIELDS = [
  "title", "excerpt", "seo_title", "seo_description",
  "featured_image_alt", "video_transcript",
] as const;

export const translateNewsPosts = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => Input.parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const sb = context.supabase;

    const { data: sources, error } = await sb
      .from("cms_news_posts")
      .select("*")
      .in("id", data.post_ids)
      .eq("locale", data.source_lang);
    if (error) throw new Error(error.message);
    if (!sources?.length) return { ok: true, translated: 0, summary: [] };

    const summary: Array<{ post_id: string; slug: string; lang: string; ok: boolean; error?: string }> = [];
    let translated = 0;

    for (const src of sources) {
      for (const lang of data.target_langs) {
        if (lang === data.source_lang) continue;
        try {
          const { data: existing } = await sb
            .from("cms_news_posts")
            .select("id")
            .eq("slug", src.slug)
            .eq("locale", lang)
            .maybeSingle();
          if (existing?.id && !data.overwrite) {
            summary.push({ post_id: src.id, slug: src.slug, lang, ok: true, error: "skipped (exists)" });
            continue;
          }

          // 1) Egyszerű mezők
          const texts: Record<string, string> = {};
          for (const f of SIMPLE_TEXT_FIELDS) {
            const v = (src as any)[f];
            if (typeof v === "string" && v.trim().length >= 2) texts[f] = v;
          }
          // 2) body JSON leveleitől
          const leaves: StringLeaf[] = [];
          collectStrings(src.body ?? {}, leaves);
          leaves.forEach((l, i) => { texts[`b${i}`] = l.value; });

          const out = Object.keys(texts).length
            ? await aiTranslate(sb, texts, lang, data.source_lang)
            : {};

          const bodyClone = JSON.parse(JSON.stringify(src.body ?? {}));
          leaves.forEach((l, i) => {
            const v = out[`b${i}`];
            if (typeof v === "string") setAtPath(bodyClone, l.path, v);
          });

          const row: any = {
            slug: src.slug,
            locale: lang,
            title: out.title ?? src.title,
            excerpt: out.excerpt ?? src.excerpt,
            seo_title: out.seo_title ?? src.seo_title,
            seo_description: out.seo_description ?? src.seo_description,
            featured_image_alt: out.featured_image_alt ?? src.featured_image_alt,
            featured_image_url: src.featured_image_url,
            og_image_url: src.og_image_url,
            body: bodyClone,
            category_id: src.category_id,
            author_id: src.author_id,
            post_type: src.post_type,
            video_provider: src.video_provider,
            video_url: src.video_url,
            video_embed_url: src.video_embed_url,
            video_thumbnail_url: src.video_thumbnail_url,
            video_duration_seconds: src.video_duration_seconds,
            video_transcript: out.video_transcript ?? src.video_transcript,
            status: data.publish_immediately ? src.status : "draft",
            workflow_state: "draft",
            published_at: data.publish_immediately ? src.published_at : null,
            updated_by: context.userId,
          };
          if (existing?.id) row.id = existing.id;

          const { error: eUp } = await sb.from("cms_news_posts").upsert(row);
          if (eUp) throw new Error(eUp.message);
          translated++;
          summary.push({ post_id: src.id, slug: src.slug, lang, ok: true });
        } catch (err: any) {
          summary.push({
            post_id: src.id, slug: src.slug, lang, ok: false,
            error: String(err?.message ?? err).slice(0, 200),
          });
        }
      }
    }

    return { ok: true, translated, summary };
  });
