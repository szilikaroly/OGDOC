/**
 * Public + editor server functions for cms_design_tokens.
 * Tokens are key/value pairs (token_key like "brand.primary", value JSON).
 * Public read is allowed (FOR SELECT USING true); writes need an editor.
 */
import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { Database } from "@/integrations/supabase/types";

function publicClient() {
  return createClient<Database>(
    process.env.SUPABASE_URL!,
    process.env.SUPABASE_PUBLISHABLE_KEY!,
    { auth: { storage: undefined, persistSession: false, autoRefreshToken: false } },
  );
}

export type DesignToken = {
  id?: string;
  token_key: string;
  value: any;
  scope?: string;
  description?: string | null;
};

export const listPublicDesignTokens = createServerFn({ method: "GET" })
  .handler(async (): Promise<DesignToken[]> => {
    const sb = publicClient();
    const { data } = await (sb as any)
      .from("cms_design_tokens")
      .select("id,token_key,value,scope,description");
    return (data ?? []) as DesignToken[];
  });

export const listDesignTokens = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await (context.supabase as any)
      .from("cms_design_tokens")
      .select("*")
      .order("scope", { ascending: true })
      .order("token_key", { ascending: true });
    if (error) throw error;
    return data as DesignToken[];
  });

export const upsertDesignToken = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: DesignToken) => input)
  .handler(async ({ data, context }) => {
    const row = { ...data, updated_by: context.userId };
    const { data: out, error } = await (context.supabase as any)
      .from("cms_design_tokens")
      .upsert(row, { onConflict: "token_key" })
      .select("*")
      .single();
    if (error) throw error;
    return out as DesignToken;
  });

export const deleteDesignToken = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string }) => input)
  .handler(async ({ data, context }) => {
    const { error } = await (context.supabase as any)
      .from("cms_design_tokens")
      .delete()
      .eq("id", data.id);
    if (error) throw error;
    return { ok: true };
  });
