/**
 * A/B kísérlet konverziós eseménydefiníciók és Zod-alapú paraméter-validálás.
 * A definíciókat az admin adja meg (név + mezők), a track endpoint pedig
 * ezek alapján validálja a beérkező `params` objektumot.
 */
import { z } from "zod";

export type FieldType = "string" | "number" | "boolean" | "url";

export interface ConversionEventField {
  name: string;
  type: FieldType;
  required?: boolean;
  max?: number;
}

export interface ConversionEventDef {
  name: string;
  description?: string;
  fields: ConversionEventField[];
}

const FieldSchema = z.object({
  name: z.string().min(1).max(60).regex(/^[a-zA-Z_][a-zA-Z0-9_]*$/, "csak betű/szám/_"),
  type: z.enum(["string", "number", "boolean", "url"]),
  required: z.boolean().optional(),
  max: z.number().int().positive().max(2000).optional(),
});

export const ConversionEventDefSchema = z.object({
  name: z.string().min(1).max(80).regex(/^[a-zA-Z0-9_.-]+$/),
  description: z.string().max(500).optional(),
  fields: z.array(FieldSchema).max(20).default([]),
});

export const ConversionEventsSchema = z.array(ConversionEventDefSchema).max(50);

/** Egy adott definícióhoz Zod schema építése a `params` validáláshoz. */
export function buildParamsSchema(def: ConversionEventDef): z.ZodTypeAny {
  const shape: Record<string, z.ZodTypeAny> = {};
  for (const f of def.fields ?? []) {
    let s: z.ZodTypeAny;
    switch (f.type) {
      case "number": s = z.number().finite(); break;
      case "boolean": s = z.boolean(); break;
      case "url": s = z.string().url().max(f.max ?? 500); break;
      case "string":
      default: s = z.string().max(f.max ?? 500); break;
    }
    shape[f.name] = f.required ? s : s.optional();
  }
  return z.object(shape).strict();
}
