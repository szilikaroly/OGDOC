/**
 * Automatikus JSON-LD generátor CMS oldalakhoz.
 *
 * A fő entitás típusát a `page.schema_type` határozza meg:
 *   - "auto"           → tartalom + slug + blokkok alapján találjuk ki
 *   - "webpage"        → WebPage
 *   - "article"        → Article (+ WebPage)
 *   - "faqpage"        → FAQPage (+ WebPage) – FAQ blokkokból
 *   - "contactpage"    → ContactPage (+ ContactPoint a site beállításokból)
 *   - "aboutpage"      → AboutPage
 *   - "service"        → Service
 *   - "organization"   → Organization (site beállításokból merge)
 *   - "localbusiness"  → LocalBusiness / MedicalOrganization
 *   - "collectionpage" → CollectionPage (pl. hír-index)
 *
 * Emellé mindig kimegy: BreadcrumbList, FAQPage (ha van FAQ blokk),
 * és Physician / ItemList (ha van team blokk).
 */

import { SITE_ORIGIN, SITE_NAME_DEFAULT, type SiteDefaults } from "./og-meta";

type AnyBlock = { block_type?: string; type?: string; content?: any };

export type SchemaType =
  | "auto" | "webpage" | "article" | "faqpage" | "contactpage"
  | "aboutpage" | "service" | "organization" | "localbusiness" | "collectionpage";

type PageLike = {
  id?: string;
  title?: string;
  slug?: string;
  description?: string | null;
  seo_title?: string | null;
  seo_description?: string | null;
  published_at?: string | null;
  updated_at?: string | null;
  featured_image_url?: string | null;
  og_image_url?: string | null;
  kind?: string | null;
  type?: string | null;
  schema_type?: SchemaType | string | null;
  author_name?: string | null;
};

export type BuildJsonLdInput = {
  page: PageLike;
  blocks: AnyBlock[];
  url: string;
  image?: string | null;
  siteDefaults?: SiteDefaults | null;
  /** Extra breadcrumb crumb-ok az oldal fölé (pl. "Hírek" → "cikk címe"). */
  extraBreadcrumbs?: Array<{ name: string; url: string }>;
};

/** Auto-detektálás blokkok + slug + tartalom alapján. */
export function detectSchemaType(page: PageLike, blocks: AnyBlock[] = []): SchemaType {
  const slug = (page.slug ?? "").toLowerCase();
  const hasType = (t: string) =>
    blocks.some((b) => (b.block_type ?? b.type) === t);

  if (hasType("klinika_contact") || hasType("dyn_contact_form") || /kapcsolat|contact/.test(slug))
    return "contactpage";
  if (page.kind === "article" || page.type === "article" ||
      slug.startsWith("hirek/") || slug.startsWith("blog/") ||
      (!!page.published_at && (hasType("richtext") && hasType("heading"))))
    return "article";
  if (hasType("klinika_faq") || hasType("dyn_faq")) return "faqpage";
  if (/^(rolunk|about|klinika)$/.test(slug)) return "aboutpage";
  if (/^szolgaltatas|services?\b/.test(slug)) return "service";
  return "webpage";
}

export function buildJsonLdForPage(input: BuildJsonLdInput): Array<Record<string, unknown>> {
  const { page, blocks, url, image, siteDefaults } = input;
  const out: Array<Record<string, unknown>> = [];
  const siteName = siteDefaults?.site_name || SITE_NAME_DEFAULT;
  const title = page.seo_title || page.title || "";
  const description = page.seo_description || page.description || "";

  const declared = (page.schema_type ?? "auto") as SchemaType;
  const schemaType: SchemaType = declared === "auto" ? detectSchemaType(page, blocks) : declared;

  // ── Fő entitás (WebPage / ContactPage / AboutPage / CollectionPage) ───
  const mainType =
    schemaType === "contactpage"    ? "ContactPage"    :
    schemaType === "aboutpage"      ? "AboutPage"      :
    schemaType === "collectionpage" ? "CollectionPage" :
    schemaType === "service"        ? "WebPage"        : // Service külön node
    "WebPage";

  const webPage: Record<string, unknown> = {
    "@context": "https://schema.org",
    "@type": mainType,
    name: title,
    description,
    url,
    inLanguage: "hu",
    isPartOf: { "@type": "WebSite", name: siteName, url: SITE_ORIGIN },
  };
  if (image) webPage.primaryImageOfPage = { "@type": "ImageObject", url: image };
  if (page.updated_at) webPage.dateModified = page.updated_at;
  if (page.published_at) webPage.datePublished = page.published_at;
  out.push(webPage);

  // ── ContactPage extra: ContactPoint (site org-ból vagy contact blokkból) ─
  if (schemaType === "contactpage") {
    const cp = buildContactPoint(siteDefaults, blocks);
    if (cp) out.push({ "@context": "https://schema.org", ...cp });
  }

  // ── Organization / LocalBusiness node ─────────────────────────────────
  if (schemaType === "organization" || schemaType === "localbusiness") {
    const org = buildOrgNode(schemaType, siteDefaults, image, url);
    out.push(org);
  }

  // ── Service node ──────────────────────────────────────────────────────
  if (schemaType === "service") {
    out.push({
      "@context": "https://schema.org",
      "@type": "Service",
      name: title,
      description,
      url,
      provider: { "@type": "Organization", name: siteName, url: SITE_ORIGIN },
      image: image || undefined,
    });
  }




  // ── BreadcrumbList ───────────────────────────────────────────────
  out.push(buildBreadcrumbs(url, page.title || title, input.extraBreadcrumbs));

  // ── FAQPage (klinika_faq / dyn_faq) ──────────────────────────────
  const faqItems: Array<{ q: string; a: string }> = [];
  for (const b of blocks ?? []) {
    const t = b.block_type ?? b.type;
    if ((t === "klinika_faq" || t === "dyn_faq") && Array.isArray(b.content?.items)) {
      for (const it of b.content.items) {
        if (it?.q && it?.a) faqItems.push({ q: String(it.q), a: String(it.a) });
      }
    }
  }
  if (faqItems.length) {
    out.push({
      "@context": "https://schema.org",
      "@type": "FAQPage",
      mainEntity: faqItems.map((f) => ({
        "@type": "Question",
        name: f.q,
        acceptedAnswer: { "@type": "Answer", text: f.a },
      })),
    });
  }

  // ── Physician (team / orvos blokkokból) ──────────────────────────
  const physicians: Array<Record<string, unknown>> = [];
  for (const b of blocks ?? []) {
    const t = b.block_type ?? b.type;
    if (t === "klinika_team" && Array.isArray(b.content?.items)) {
      for (const p of b.content.items) {
        if (p?.name) {
          physicians.push({
            "@type": "Physician",
            name: String(p.name),
            jobTitle: p.title || p.role || undefined,
            image: p.avatar_url || p.image || undefined,
            medicalSpecialty: p.specialty || undefined,
          });
        }
      }
    }
    if (t === "dyn_doctor_card" && b.content?.slug) {
      physicians.push({
        "@type": "Physician",
        name: b.content?.name || b.content.slug,
        url: `${SITE_ORIGIN}/munkatarsak/${b.content.slug}`,
      });
    }
  }
  if (physicians.length === 1) {
    out.push({ "@context": "https://schema.org", ...physicians[0] });
  } else if (physicians.length > 1) {
    out.push({
      "@context": "https://schema.org",
      "@type": "ItemList",
      itemListElement: physicians.map((p, i) => ({
        "@type": "ListItem",
        position: i + 1,
        item: p,
      })),
    });
  }

  // ── Article (ha a page valódi cikk) ──────────────────────────────
  const isArticle = schemaType === "article" ||
    page.kind === "article" || page.type === "article" ||
    (!!page.published_at && (page.slug?.startsWith("hirek/") || page.slug?.startsWith("blog/")));
  if (isArticle) {
    out.push({
      "@context": "https://schema.org",
      "@type": "Article",
      headline: title,
      description,
      image: image || undefined,
      datePublished: page.published_at || undefined,
      dateModified: page.updated_at || page.published_at || undefined,
      author: page.author_name
        ? { "@type": "Person", name: page.author_name }
        : { "@type": "Organization", name: siteName },
      publisher: {
        "@type": "Organization",
        name: siteName,
        logo: siteDefaults?.default_og_image_url
          ? { "@type": "ImageObject", url: siteDefaults.default_og_image_url }
          : undefined,
      },
      mainEntityOfPage: { "@type": "WebPage", "@id": url },
    });
  }

  return out;
}

function buildBreadcrumbs(
  url: string,
  leafName: string,
  extra?: Array<{ name: string; url: string }>,
): Record<string, unknown> {
  let path = "/";
  try {
    path = new URL(url).pathname || "/";
  } catch {
    /* ignore */
  }
  const segments = path.split("/").filter(Boolean);
  const items: Array<{ name: string; url: string }> = [{ name: "Kezdőlap", url: SITE_ORIGIN + "/" }];
  if (extra?.length) items.push(...extra);
  let acc = "";
  segments.forEach((seg, idx) => {
    acc += "/" + seg;
    const isLast = idx === segments.length - 1;
    items.push({
      name: isLast ? leafName : humanize(seg),
      url: SITE_ORIGIN + acc,
    });
  });
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: items.map((it, i) => ({
      "@type": "ListItem",
      position: i + 1,
      name: it.name,
      item: it.url,
    })),
  };
}

function humanize(seg: string): string {
  const map: Record<string, string> = {
    o: "Oldalak",
    hirek: "Hírek",
    blog: "Blog",
    vlog: "Vlog",
    tanacsok: "Tanácsok",
    munkatarsak: "Munkatársak",
    foglalas: "Időpontfoglalás",
    portal: "Portál",
  };
  if (map[seg]) return map[seg];
  return seg.replace(/-/g, " ").replace(/^./, (c) => c.toUpperCase());
}

// ── Helpers: ContactPoint / Organization / LocalBusiness ──────────
function buildContactPoint(
  siteDefaults: SiteDefaults | null | undefined,
  blocks: AnyBlock[],
): Record<string, unknown> | null {
  const org = (siteDefaults as any)?.organization_jsonld as Record<string, unknown> | undefined;
  const orgCp = org?.contactPoint as Record<string, unknown> | undefined;
  const contactBlock = (blocks ?? []).find((b) => {
    const t = b.block_type ?? b.type;
    return t === "klinika_contact" || t === "dyn_contact_form";
  });
  const c = (contactBlock?.content ?? {}) as Record<string, unknown>;
  const telephone = (c.phone as string) || (orgCp?.telephone as string) || (org?.telephone as string);
  const email = (c.email as string) || (orgCp?.email as string) || (org?.email as string);
  if (!telephone && !email) return null;
  return {
    "@type": "ContactPoint",
    contactType: (orgCp?.contactType as string) || "customer service",
    telephone,
    email,
    areaServed: (orgCp?.areaServed as string) || "HU",
    availableLanguage: (orgCp?.availableLanguage as string[]) || ["hu", "en"],
  };
}

function buildOrgNode(
  kind: "organization" | "localbusiness",
  siteDefaults: SiteDefaults | null | undefined,
  image: string | null | undefined,
  url: string,
): Record<string, unknown> {
  const org = ((siteDefaults as any)?.organization_jsonld ?? {}) as Record<string, unknown>;
  const type = kind === "localbusiness"
    ? (org["@type"] as string) || "MedicalOrganization"
    : "Organization";
  const name = (org.name as string) || siteDefaults?.site_name || SITE_NAME_DEFAULT;
  const logoUrl = (org.logo as string) || siteDefaults?.default_og_image_url || image || undefined;
  const node: Record<string, unknown> = {
    "@context": "https://schema.org",
    "@type": type,
    name,
    url: (org.url as string) || SITE_ORIGIN,
    ...(logoUrl ? { logo: { "@type": "ImageObject", url: logoUrl } } : {}),
    ...(org.telephone ? { telephone: org.telephone } : {}),
    ...(org.email ? { email: org.email } : {}),
    ...(org.address ? { address: org.address } : {}),
    ...(org.geo ? { geo: org.geo } : {}),
    ...(org.openingHoursSpecification ? { openingHoursSpecification: org.openingHoursSpecification } : {}),
    ...(org.sameAs ? { sameAs: org.sameAs } : {}),
    ...(org.priceRange ? { priceRange: org.priceRange } : {}),
    mainEntityOfPage: url,
  };
  return node;
}
