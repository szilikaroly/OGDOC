/**
 * A/B kísérlet kliens-helperek (pure JS, böngészőben futtatható).
 *  - sticky session id (`cms_sid` localStorage)
 *  - determinisztikus súlyozott variánsválasztás
 *  - track helper a publikus végpont meghívásához
 */

const SID_KEY = "cms_sid";

export function getOrCreateSessionId(): string {
  if (typeof window === "undefined") return "ssr";
  let sid = window.localStorage.getItem(SID_KEY);
  if (!sid) {
    sid = (crypto?.randomUUID?.() ?? String(Math.random()).slice(2)) + "_" + Date.now().toString(36);
    try { window.localStorage.setItem(SID_KEY, sid); } catch { /* private mode */ }
  }
  return sid;
}

/** Egyszerű 32-bit FNV-1a hash, determinisztikus súly-elosztáshoz. */
function fnv1a(str: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = (h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24))) >>> 0;
  }
  return h >>> 0;
}

export interface Variant {
  id: string;
  key: string;
  weight: number;
  content: any;
  is_control?: boolean;
}

/**
 * Variáns választás determinisztikusan a session_id + experiment_id alapján.
 * A `traffic_allocation` (0..1) szabályozza, hogy a látogatók hány %-a kerüljön a kísérletbe;
 * az "out" eset → control variant.
 */
export function pickVariant(
  experimentId: string,
  variants: Variant[],
  sessionId: string,
  trafficAllocation = 1,
): Variant | null {
  if (variants.length === 0) return null;
  const bucket = fnv1a(sessionId + ":" + experimentId) % 10000; // 0..9999
  if (bucket >= Math.floor(trafficAllocation * 10000)) {
    return variants.find((v) => v.is_control) ?? variants[0];
  }
  const total = variants.reduce((acc, v) => acc + Math.max(0, v.weight), 0);
  if (total <= 0) return variants[0];
  const r = (fnv1a(experimentId + ":" + sessionId) % 10000) / 10000 * total;
  let acc = 0;
  for (const v of variants) {
    acc += Math.max(0, v.weight);
    if (r < acc) return v;
  }
  return variants[variants.length - 1];
}

/** Track esemény (view/goal). Fire-and-forget, nem dob hibát. */
export function trackExperimentEvent(input: {
  experiment_id: string;
  variant_id: string;
  event_type: "view" | "goal";
  path?: string;
  referrer?: string;
  event_name?: string;
  params?: Record<string, unknown>;
}): void {
  if (typeof window === "undefined") return;
  const payload = {
    ...input,
    session_id: getOrCreateSessionId(),
    path: input.path ?? window.location.pathname,
    referrer: input.referrer ?? document.referrer ?? "",
  };
  try {
    const body = JSON.stringify(payload);
    if (navigator.sendBeacon) {
      navigator.sendBeacon("/api/public/experiments/track", new Blob([body], { type: "application/json" }));
    } else {
      fetch("/api/public/experiments/track", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body,
        keepalive: true,
      }).catch(() => {});
    }
  } catch { /* ignore */ }
}

/** Két-arányú z-test p-value (kétoldalú), normál közelítéssel. */
export function twoProportionPValue(
  goalsA: number, viewsA: number,
  goalsB: number, viewsB: number,
): number {
  if (viewsA === 0 || viewsB === 0) return 1;
  const pA = goalsA / viewsA;
  const pB = goalsB / viewsB;
  const pPool = (goalsA + goalsB) / (viewsA + viewsB);
  const se = Math.sqrt(pPool * (1 - pPool) * (1 / viewsA + 1 / viewsB));
  if (se === 0) return 1;
  const z = (pB - pA) / se;
  // kétoldali normál CDF közelítés (Abramowitz & Stegun 7.1.26)
  const erf = (x: number) => {
    const a1 = 0.254829592, a2 = -0.284496736, a3 = 1.421413741;
    const a4 = -1.453152027, a5 = 1.061405429, p = 0.3275911;
    const sign = x < 0 ? -1 : 1;
    const ax = Math.abs(x);
    const t = 1 / (1 + p * ax);
    const y = 1 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * Math.exp(-ax * ax);
    return sign * y;
  };
  const p = 2 * (1 - 0.5 * (1 + erf(Math.abs(z) / Math.SQRT2)));
  return Math.max(0, Math.min(1, p));
}
