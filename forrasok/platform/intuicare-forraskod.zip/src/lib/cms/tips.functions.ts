/**
 * CMS Tanácsok (tips) — public + admin server functions with versioning.
 */
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { createClient } from "@supabase/supabase-js";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

function publicClient() {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_PUBLISHABLE_KEY;
  if (!url || !key) throw new Error("Missing Supabase env");
  return createClient(url, key, {
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
  });
}

async function assertCmsAccess(ctx: { supabase: any; userId: string }) {
  const { data, error } = await ctx.supabase.rpc("has_cms_access", { _user_id: ctx.userId });
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Forbidden");
}

// ============== Snapshot helper ==============
async function snapshotTip(sb: any, tipId: string, userId: string | null, note?: string) {
  const [{ data: tip }, { data: trs }, { data: tagMap }, { data: audMap }] = await Promise.all([
    sb.from("cms_tips").select("*").eq("id", tipId).maybeSingle(),
    sb.from("cms_tip_translations").select("*").eq("tip_id", tipId),
    sb.from("cms_tip_tag_map").select("tag_id").eq("tip_id", tipId),
    sb.from("cms_tip_audience_map").select("audience_id").eq("tip_id", tipId),
  ]);
  if (!tip) return;
  const { data: maxV } = await sb
    .from("cms_tip_versions")
    .select("version")
    .eq("tip_id", tipId)
    .order("version", { ascending: false })
    .limit(1)
    .maybeSingle();
  const nextVersion = (maxV?.version ?? 0) + 1;
  await sb.from("cms_tip_versions").insert({
    tip_id: tipId,
    version: nextVersion,
    snapshot: { tip, translations: trs ?? [], tag_ids: (tagMap ?? []).map((m: any) => m.tag_id), audience_ids: (audMap ?? []).map((m: any) => m.audience_id) },
    note: note ?? null,
    created_by: userId,
  });
}

// ============== Audit helper ==============
async function auditTip(sb: any, userId: string | null, action: string, tipId: string, before: any, after: any, summary?: string) {
  try {
    await sb.from("admin_audit_log").insert({
      user_id: userId,
      table_name: "cms_tips",
      record_id: tipId,
      action,
      before_data: before ?? null,
      after_data: after ?? null,
      summary: summary ?? null,
    });
  } catch { /* never block mutation on audit */ }
}

// ============== PUBLIC ==============

export const listPublishedTips = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) =>
    z.object({
      locale: z.string().default("hu"),
      category: z.string().optional(),
      audience: z.string().optional(),
      tag: z.string().optional(),
      featured_only: z.boolean().default(false),
      limit: z.number().int().min(1).max(60).default(20),
      offset: z.number().int().min(0).default(0),
    }).parse(d ?? {})
  )
  .handler(async ({ data }) => {
    const sb = publicClient();
    let catId: string | null = null;
    if (data.category) {
      const { data: c } = await sb.from("cms_tip_categories").select("id").eq("slug", data.category).maybeSingle();
      catId = c?.id ?? null;
      if (!catId) return { tips: [], total: 0 };
    }
    let audId: string | null = null;
    if (data.audience) {
      const { data: a } = await sb.from("cms_tip_audiences").select("id").eq("slug", data.audience).maybeSingle();
      audId = a?.id ?? null;
      if (!audId) return { tips: [], total: 0 };
    }
    let tagId: string | null = null;
    if (data.tag) {
      const { data: t } = await sb.from("cms_tip_tags").select("id").eq("slug", data.tag).maybeSingle();
      tagId = t?.id ?? null;
      if (!tagId) return { tips: [], total: 0 };
    }

    let q = sb.from("cms_tips")
      .select("id,slug,category_id,cover_url,featured,published_at,reading_minutes,cms_tip_categories(slug,name_i18n),cms_tip_translations!inner(locale,title,lead,og_image),cms_tip_audience_map(audience_id),cms_tip_tag_map(tag_id)", { count: "exact" })
      .eq("status", "published")
      .lte("published_at", new Date().toISOString())
      .eq("cms_tip_translations.locale", data.locale)
      .order("featured", { ascending: false })
      .order("published_at", { ascending: false })
      .range(data.offset, data.offset + data.limit - 1);
    if (catId) q = q.eq("category_id", catId);
    if (data.featured_only) q = q.eq("featured", true);

    const { data: rows, count, error } = await q;
    if (error) throw new Error(error.message);
    let filtered: any[] = rows ?? [];
    if (audId) filtered = filtered.filter((r: any) => (r.cms_tip_audience_map ?? []).some((m: any) => m.audience_id === audId));
    if (tagId) filtered = filtered.filter((r: any) => (r.cms_tip_tag_map ?? []).some((m: any) => m.tag_id === tagId));
    return { tips: filtered, total: count ?? filtered.length };
  });

export const getPublishedTipBySlug = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) => z.object({ slug: z.string().min(1), locale: z.string().default("hu") }).parse(d))
  .handler(async ({ data }) => {
    const sb = publicClient();
    const { data: tip, error } = await sb.from("cms_tips")
      .select("*,cms_tip_categories(slug,name_i18n),cms_tip_translations(*),cms_tip_audience_map(cms_tip_audiences(slug,name_i18n)),cms_tip_tag_map(cms_tip_tags(slug,name_i18n))")
      .eq("slug", data.slug)
      .eq("status", "published")
      .lte("published_at", new Date().toISOString())
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!tip) return null;
    const trs: any[] = (tip as any).cms_tip_translations ?? [];
    const tr = trs.find((t) => t.locale === data.locale) ?? trs.find((t) => t.locale === "hu") ?? trs[0] ?? null;
    return { tip, translation: tr };
  });

export const listTipCategories = createServerFn({ method: "GET" })
  .handler(async () => {
    const sb = publicClient();
    const { data, error } = await sb.from("cms_tip_categories").select("*").order("sort_order");
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const listTipTags = createServerFn({ method: "GET" })
  .handler(async () => {
    const sb = publicClient();
    const { data, error } = await sb.from("cms_tip_tags").select("*").order("slug");
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const listTipAudiences = createServerFn({ method: "GET" })
  .handler(async () => {
    const sb = publicClient();
    const { data, error } = await sb.from("cms_tip_audiences").select("*").order("sort_order");
    if (error) throw new Error(error.message);
    return data ?? [];
  });

// ============== ADMIN ==============

export const adminListTips = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ status: z.string().optional(), search: z.string().optional() }).parse(d ?? {}))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    let q = context.supabase.from("cms_tips")
      .select("id,slug,status,featured,published_at,updated_at,cover_url,category_id,cms_tip_categories(slug,name_i18n),cms_tip_translations(locale,title,translation_status)")
      .order("updated_at", { ascending: false });
    if (data.status) q = q.eq("status", data.status);
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    let res = rows ?? [];
    if (data.search) {
      const s = data.search.toLowerCase();
      res = res.filter((r: any) =>
        r.slug.toLowerCase().includes(s) ||
        (r.cms_tip_translations ?? []).some((t: any) => (t.title ?? "").toLowerCase().includes(s))
      );
    }
    return res;
  });

export const adminGetTip = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const { data: tip, error } = await context.supabase.from("cms_tips")
      .select("*,cms_tip_translations(*),cms_tip_tag_map(tag_id),cms_tip_audience_map(audience_id)")
      .eq("id", data.id).single();
    if (error) throw new Error(error.message);
    return tip;
  });

const TipMetaInput = z.object({
  id: z.string().uuid().optional(),
  slug: z.string().min(1).regex(/^[a-z0-9-]+$/),
  category_id: z.string().uuid().nullable().optional(),
  cover_url: z.string().nullable().optional(),
  status: z.enum(["draft", "published", "archived"]).default("draft"),
  featured: z.boolean().default(false),
  published_at: z.string().nullable().optional(),
  reading_minutes: z.number().int().nullable().optional(),
  audience_ids: z.array(z.string().uuid()).default([]),
  tag_ids: z.array(z.string().uuid()).default([]),
});

export const adminUpsertTip = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => TipMetaInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const { audience_ids, tag_ids, ...rest } = data;
    let pubAt = rest.published_at ? new Date(rest.published_at).toISOString() : null;
    if (rest.status === "published" && !pubAt) pubAt = new Date().toISOString();
    const payload: any = { ...rest, published_at: pubAt };

    let tipId = data.id;
    if (tipId) {
      const { error } = await context.supabase.from("cms_tips").update(payload).eq("id", tipId);
      if (error) throw new Error(error.message);
    } else {
      payload.author_id = context.userId;
      const { data: row, error } = await context.supabase.from("cms_tips").insert(payload).select("id").single();
      if (error) throw new Error(error.message);
      tipId = row.id;
    }

    // sync taxonomies
    await context.supabase.from("cms_tip_tag_map").delete().eq("tip_id", tipId);
    if (tag_ids.length) {
      const { error: e } = await context.supabase.from("cms_tip_tag_map").insert(tag_ids.map((tag_id) => ({ tip_id: tipId, tag_id })));
      if (e) throw new Error(e.message);
    }
    await context.supabase.from("cms_tip_audience_map").delete().eq("tip_id", tipId);
    if (audience_ids.length) {
      const { error: e } = await context.supabase.from("cms_tip_audience_map").insert(audience_ids.map((audience_id) => ({ tip_id: tipId, audience_id })));
      if (e) throw new Error(e.message);
    }

    await snapshotTip(context.supabase, tipId!, context.userId, "meta-update");
    await auditTip(context.supabase, context.userId, data.id ? "update" : "create", tipId!, null, payload, `Tip ${data.slug}`);
    return { id: tipId };
  });

const TipTranslationInput = z.object({
  tip_id: z.string().uuid(),
  locale: z.string().min(2),
  title: z.string().default(""),
  lead: z.string().default(""),
  body_html: z.string().default(""),
  body_json: z.any().optional(),
  seo_title: z.string().nullable().optional(),
  seo_description: z.string().nullable().optional(),
  og_image: z.string().nullable().optional(),
  ai_generated: z.boolean().default(false),
  ai_source_lang: z.string().nullable().optional(),
  translation_status: z.enum(["manual", "ai", "reviewed"]).default("manual"),
});

export const adminUpsertTipTranslation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => TipTranslationInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const payload: any = { ...data, body_json: data.body_json ?? {} };
    const { error } = await context.supabase
      .from("cms_tip_translations")
      .upsert(payload, { onConflict: "tip_id,locale" });
    if (error) throw new Error(error.message);
    await snapshotTip(context.supabase, data.tip_id, context.userId, `translation:${data.locale}`);
    await auditTip(context.supabase, context.userId, "update_translation", data.tip_id, null, { locale: data.locale }, `Translation ${data.locale}`);
    return { ok: true };
  });

export const adminDeleteTip = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const { error } = await context.supabase.from("cms_tips").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    await auditTip(context.supabase, context.userId, "delete", data.id, null, null);
    return { ok: true };
  });

export const adminPublishTip = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid(), publish: z.boolean() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const update: any = data.publish
      ? { status: "published", published_at: new Date().toISOString() }
      : { status: "draft" };
    const { error } = await context.supabase.from("cms_tips").update(update).eq("id", data.id);
    if (error) throw new Error(error.message);
    await snapshotTip(context.supabase, data.id, context.userId, data.publish ? "published" : "unpublished");
    await auditTip(context.supabase, context.userId, data.publish ? "publish" : "unpublish", data.id, null, update);
    return { ok: true };
  });

export const adminListTipVersions = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ tip_id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const { data: rows, error } = await context.supabase
      .from("cms_tip_versions")
      .select("id,version,note,created_by,created_at,snapshot")
      .eq("tip_id", data.tip_id)
      .order("version", { ascending: false });
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

export const adminRestoreTipVersion = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ version_id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const { data: ver, error } = await context.supabase
      .from("cms_tip_versions")
      .select("tip_id,version,snapshot")
      .eq("id", data.version_id)
      .single();
    if (error) throw new Error(error.message);
    const snap: any = ver.snapshot;
    const tipId = ver.tip_id as string;
    // restore tip row
    const { id, created_at, updated_at, ...tipFields } = snap.tip ?? {};
    await context.supabase.from("cms_tips").update(tipFields).eq("id", tipId);
    // wipe + restore translations
    await context.supabase.from("cms_tip_translations").delete().eq("tip_id", tipId);
    if (Array.isArray(snap.translations) && snap.translations.length) {
      const trs = snap.translations.map((t: any) => {
        const { id: _i, created_at: _c, updated_at: _u, ...rest } = t;
        return { ...rest, tip_id: tipId };
      });
      await context.supabase.from("cms_tip_translations").insert(trs);
    }
    // taxonomies
    await context.supabase.from("cms_tip_tag_map").delete().eq("tip_id", tipId);
    if (Array.isArray(snap.tag_ids) && snap.tag_ids.length) {
      await context.supabase.from("cms_tip_tag_map").insert(snap.tag_ids.map((tag_id: string) => ({ tip_id: tipId, tag_id })));
    }
    await context.supabase.from("cms_tip_audience_map").delete().eq("tip_id", tipId);
    if (Array.isArray(snap.audience_ids) && snap.audience_ids.length) {
      await context.supabase.from("cms_tip_audience_map").insert(snap.audience_ids.map((audience_id: string) => ({ tip_id: tipId, audience_id })));
    }
    await snapshotTip(context.supabase, tipId, context.userId, `restored from v${ver.version}`);
    return { ok: true };
  });

// ============== Taxonomy admin (categories/tags/audiences) ==============

const TaxInput = z.object({
  id: z.string().uuid().optional(),
  slug: z.string().min(1).regex(/^[a-z0-9-]+$/),
  name_i18n: z.record(z.string(), z.string()).default({}),
  description_i18n: z.record(z.string(), z.string()).default({}).optional(),
  sort_order: z.number().int().default(0).optional(),
  icon: z.string().nullable().optional(),
  color: z.string().nullable().optional(),
});

function makeTaxUpsert(table: "cms_tip_categories" | "cms_tip_tags" | "cms_tip_audiences") {
  return createServerFn({ method: "POST" })
    .middleware([requireSupabaseAuth])
    .inputValidator((d: unknown) => TaxInput.parse(d))
    .handler(async ({ data, context }) => {
      await assertCmsAccess(context);
      const payload: any = { ...data };
      if (data.id) {
        const { error } = await context.supabase.from(table).update(payload).eq("id", data.id);
        if (error) throw new Error(error.message);
        return { id: data.id };
      }
      const { data: row, error } = await context.supabase.from(table).insert(payload).select("id").single();
      if (error) throw new Error(error.message);
      return { id: row.id };
    });
}

function makeTaxDelete(table: "cms_tip_categories" | "cms_tip_tags" | "cms_tip_audiences") {
  return createServerFn({ method: "POST" })
    .middleware([requireSupabaseAuth])
    .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
    .handler(async ({ data, context }) => {
      await assertCmsAccess(context);
      const { error } = await context.supabase.from(table).delete().eq("id", data.id);
      if (error) throw new Error(error.message);
      return { ok: true };
    });
}

export const adminUpsertTipCategory = makeTaxUpsert("cms_tip_categories");
export const adminDeleteTipCategory = makeTaxDelete("cms_tip_categories");
export const adminUpsertTipTag = makeTaxUpsert("cms_tip_tags");
export const adminDeleteTipTag = makeTaxDelete("cms_tip_tags");
export const adminUpsertTipAudience = makeTaxUpsert("cms_tip_audiences");
export const adminDeleteTipAudience = makeTaxDelete("cms_tip_audiences");
