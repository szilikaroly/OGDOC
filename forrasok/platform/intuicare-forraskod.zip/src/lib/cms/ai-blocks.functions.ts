/**
 * AI-segéd a CMS vizuális szerkesztőhöz:
 *  - generateBlockContent: rövid prompt + blokk-típus alapján JSON content-et
 *    állít elő a Lovable AI Gateway-en keresztül (Gemini Flash).
 *
 * A visszaadott JSON-t a szerkesztő közvetlenül beilleszti a blokkba.
 */
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const Input = z.object({
  blockType: z.string().min(1),
  prompt: z.string().min(3).max(2000),
  locale: z.string().default("hu"),
});

const GATEWAY = "https://ai.gateway.lovable.dev/v1/chat/completions";
const MODEL = "google/gemini-2.5-flash";

export const generateBlockContent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => Input.parse(d))
  .handler(async ({ data }) => {
    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) throw new Error("Hiányzik a LOVABLE_API_KEY.");

    const sys = [
      "Te egy egyetemi klinika CMS asszisztens vagy.",
      `A felhasználó egy "${data.blockType}" típusú blokkhoz kér tartalmat (${data.locale} nyelven).`,
      "Válaszolj KIZÁRÓLAG egy JSON objektummal, magyar nyelven, professzionális, egészségügyi hangnemben.",
      "A JSON sémát te választod meg a blokk típusa alapján — pl. hero: {kicker,title,lead,ctas:[{label,href}]};",
      "intro_grid/3col_features: {kicker,title,lead,items:[{title,text,icon?}]};",
      "stats: {items:[{value,label,icon?}]}; faq: {items:[{q,a}]}; cta_band: {title,text,cta:{label,href}};",
      "rich_text: {html}; team: {title,members:[{name,role,bio?}]}.",
      "Soha ne tegyél magyarázó szöveget vagy markdown-blokkot a JSON köré.",
    ].join(" ");

    const res = await fetch(GATEWAY, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: MODEL,
        response_format: { type: "json_object" },
        messages: [
          { role: "system", content: sys },
          { role: "user", content: data.prompt },
        ],
      }),
    });

    if (res.status === 429) throw new Error("AI rate limit — próbáld újra később.");
    if (res.status === 402) throw new Error("Elfogytak az AI kreditek a workspace-en.");
    if (!res.ok) throw new Error(`AI hiba: ${res.status} ${await res.text()}`);

    const json: any = await res.json();
    const raw = json?.choices?.[0]?.message?.content ?? "{}";
    let parsed: any;
    try {
      parsed = JSON.parse(raw);
    } catch {
      throw new Error("Az AI nem érvényes JSON-t adott vissza.");
    }
    return { content: parsed };
  });

// ─────────────────────────────────────────────────────────────────────────
// Oldal-szintű AI vázlat: egy promptból teljes szekció-sorozat (több blokk).
// Visszaad: { blocks: [{ block_type, content }] } — a kliens szúrja be őket.
// ─────────────────────────────────────────────────────────────────────────

const PageDraftInput = z.object({
  prompt: z.string().min(3).max(2000),
  locale: z.string().default("hu"),
  allowedTypes: z.array(z.string()).min(1).max(40),
  maxBlocks: z.number().int().min(1).max(12).default(6),
});

export const generatePageDraft = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => PageDraftInput.parse(d))
  .handler(async ({ data }) => {
    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) throw new Error("Hiányzik a LOVABLE_API_KEY.");

    const sys = [
      "Te egy egyetemi klinika CMS asszisztens vagy.",
      `A felhasználó egy KOMPLETT aloldal-vázlatot kér (${data.locale} nyelven).`,
      "Válaszolj KIZÁRÓLAG egy JSON objektummal a következő sémában:",
      `{"blocks":[{"block_type":"...","content":{...}}, ...]}`,
      `Maximum ${data.maxBlocks} blokkot adj vissza. A blokkok logikus sorrendben (hero → bemutatás → részletek → CTA → kontakt) kövessék egymást.`,
      `A block_type CSAK a megengedett értékek egyike lehet: ${data.allowedTypes.join(", ")}.`,
      "Tartalom: magyarul, professzionális egészségügyi hangnem; ne találj ki konkrét neveket, telefonszámokat, e-maileket.",
      "Tipikus content sémák blokktípusonként:",
      'klinika_hero: {kicker,title,lead,ctas:[{label,href}]};',
      'klinika_intro_grid/klinika_3col_features: {kicker,title,lead,items:[{title,text}]};',
      'klinika_stats: {items:[{value,label}]};',
      'klinika_icon_grid: {title,items:[{title,text}]};',
      'klinika_faq: {title,items:[{q,a}]};',
      'cta_band: {title,text,cta:{label,href}};',
      'rich_text: {html};',
      'klinika_contact: {title,phone:"",email:"",address:"",ctas:[{label,href}]}.',
      "Soha ne tegyél magyarázó szöveget vagy markdown-blokkot a JSON köré.",
    ].join(" ");

    const res = await fetch(GATEWAY, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({
        model: MODEL,
        response_format: { type: "json_object" },
        messages: [
          { role: "system", content: sys },
          { role: "user", content: data.prompt },
        ],
      }),
    });

    if (res.status === 429) throw new Error("AI rate limit — próbáld újra később.");
    if (res.status === 402) throw new Error("Elfogytak az AI kreditek a workspace-en.");
    if (!res.ok) throw new Error(`AI hiba: ${res.status} ${await res.text()}`);

    const json: any = await res.json();
    const raw = json?.choices?.[0]?.message?.content ?? "{}";
    let parsed: any;
    try { parsed = JSON.parse(raw); } catch { throw new Error("Az AI nem érvényes JSON-t adott vissza."); }

    const allowed = new Set(data.allowedTypes);
    const blocks: Array<{ block_type: string; content: any }> = Array.isArray(parsed?.blocks) ? parsed.blocks : [];
    const safe = blocks
      .filter((b) => b && typeof b.block_type === "string" && allowed.has(b.block_type))
      .slice(0, data.maxBlocks)
      .map((b) => ({ block_type: b.block_type, content: b.content ?? {} }));

    if (safe.length === 0) throw new Error("Az AI nem adott vissza érvényes blokkokat.");
    return { blocks: safe };
  });

// ─────────────────────────────────────────────────────────────────────────
// Kontextus-tudatos AI: megkapja az oldal jelenlegi blokkjait és egy prompt-ot,
// visszaad egy új blokkot + javasolt beszúrási pozíciót (0 = elejére,
// N = végére). A kliens ezt közvetlenül beszúrja.
// ─────────────────────────────────────────────────────────────────────────

const ContextInput = z.object({
  pageId: z.string().uuid(),
  prompt: z.string().min(3).max(2000),
  locale: z.string().default("hu"),
  allowedTypes: z.array(z.string()).min(1).max(50),
});

export const generateContextualBlock = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => ContextInput.parse(d))
  .handler(async ({ data, context }) => {
    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) throw new Error("Hiányzik a LOVABLE_API_KEY.");

    // Aktuális oldal blokkjainak betöltése kontextusnak
    const sb = (context as any).supabase;
    const { data: pageRow } = await sb
      .from("cms_pages")
      .select("id,title,slug,seo_description")
      .eq("id", data.pageId)
      .maybeSingle();
    const { data: blockRows } = await sb
      .from("cms_layout_blocks")
      .select("position,block_type,content")
      .eq("page_id", data.pageId)
      .order("position", { ascending: true });

    const contextBlocks = (blockRows ?? []).map((b: any) => ({
      position: b.position,
      block_type: b.block_type,
      // rövidítjük a content-et, hogy ne fogyasszunk sok tokent
      summary: JSON.stringify(b.content ?? {}).slice(0, 300),
    }));

    const sys = [
      "Te egy egyetemi klinika CMS asszisztense vagy.",
      `Kapsz egy oldal jelenlegi blokk-listáját és egy felhasználói kérést (${data.locale}).`,
      "Feladatod: EGY új blokk megtervezése, ami illeszkedik az oldal kontextusához.",
      'Ha a kérésben helymegjelölés szerepel (pl. legalulra, hero után, középre), a insert_position mezőben add meg a 0-tól induló indexet, ahová beszúrandó (0 = elejére, N = végére).',
      "Válaszolj KIZÁRÓLAG JSON objektummal az alábbi sémában:",
      `{"block_type":"...","content":{...},"insert_position":N,"rationale":"rövid magyarázat"}`,
      `A block_type CSAK a megengedett értékek egyike lehet: ${data.allowedTypes.join(", ")}.`,
      "Tipikus content sémák: klinika_hero:{kicker,title,lead,ctas:[{label,href}]}; cta_band:{title,text,cta:{label,href}}; klinika_intro_grid:{kicker,title,lead,items:[{title,text}]}; klinika_faq:{title,items:[{q,a}]}; rich_text:{html}.",
      'Az href-ek mindig valós útvonalak legyenek (/foglalas/uj, /portal/orvos-kereso, /kapcsolat, tel:..., mailto:...), soha nem üres vagy "#".',
      "Magyar nyelv, egészségügyi hangnem, semmi kitalált konkrét név/email/telefonszám.",
    ].join(" ");

    const userMsg = JSON.stringify({
      page: pageRow ? { title: pageRow.title, slug: pageRow.slug, description: pageRow.seo_description } : null,
      current_blocks: contextBlocks,
      total_blocks: contextBlocks.length,
      request: data.prompt,
    });

    const res = await fetch(GATEWAY, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({
        model: MODEL,
        response_format: { type: "json_object" },
        messages: [
          { role: "system", content: sys },
          { role: "user", content: userMsg },
        ],
      }),
    });

    if (res.status === 429) throw new Error("AI rate limit — próbáld újra később.");
    if (res.status === 402) throw new Error("Elfogytak az AI kreditek a workspace-en.");
    if (!res.ok) throw new Error(`AI hiba: ${res.status} ${await res.text()}`);

    const json: any = await res.json();
    const raw = json?.choices?.[0]?.message?.content ?? "{}";
    let parsed: any;
    try { parsed = JSON.parse(raw); } catch { throw new Error("Az AI nem érvényes JSON-t adott vissza."); }

    const allowed = new Set(data.allowedTypes);
    if (!parsed?.block_type || !allowed.has(parsed.block_type)) {
      throw new Error(`Ismeretlen block_type: ${parsed?.block_type ?? "?"}`);
    }
    const total = contextBlocks.length;
    const rawPos = Number(parsed?.insert_position);
    const insert_position = Number.isFinite(rawPos)
      ? Math.max(0, Math.min(total, Math.floor(rawPos)))
      : total;

    return {
      block_type: parsed.block_type as string,
      content: parsed.content ?? {},
      insert_position,
      rationale: typeof parsed.rationale === "string" ? parsed.rationale.slice(0, 300) : "",
    };
  });
