/**
 * Block-level draft + approval workflow for cms_layout_blocks.
 *
 * - Editors save changes into `draft_content`/`draft_style` (status=pending).
 * - Publishers (`cms_publisher` / `tenant_admin`) approve → copy to live
 *   `content`/`style` and clear the draft. Reject discards the draft.
 * - The publicly-rendered `content`/`style` columns are NEVER mutated by
 *   editors directly through this module — only by approval.
 */
import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export type PendingDraft = {
  id: string;
  page_id: string | null;
  position: number;
  block_type: string;
  content: any;
  style: any;
  draft_content: any;
  draft_style: any;
  draft_status: "none" | "pending" | "approved" | "rejected";
  draft_updated_at: string | null;
  draft_updated_by: string | null;
  draft_note: string | null;
};

async function requireCmsEditor(supabase: any, userId: string) {
  const { data, error } = await supabase.rpc("has_cms_editor", { _user_id: userId });
  if (error) throw error;
  if (!data) throw new Error("Forbidden: CMS-szerkesztő szerepkör szükséges.");
}
async function requireCmsPublisher(supabase: any, userId: string) {
  const { data, error } = await supabase.rpc("has_cms_publisher", { _user_id: userId });
  if (error) throw error;
  if (!data) throw new Error("Forbidden: CMS-publikáló szerepkör szükséges.");
}

async function audit(
  supabase: any,
  action: "update" | "approve" | "reject",
  blockId: string,
  before: any,
  after: any,
  comment?: string | null,
) {
  try {
    await supabase.rpc("cms_audit_write", {
      _entity_type: "cms_layout_block",
      _entity_id: blockId,
      _action: action,
      _before: before,
      _after: after,
      _comment: comment ?? null,
    });
  } catch {
    /* audit best-effort */
  }
}

/** Save (or update) a pending draft for a block. */
export const saveBlockDraft = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i: { blockId: string; content?: any; style?: any; note?: string | null }) => i)
  .handler(async ({ data, context }) => {
    const sb = context.supabase as any;
    await requireCmsEditor(sb, context.userId);

    const { data: before } = await sb
      .from("cms_layout_blocks")
      .select("draft_content,draft_style,draft_status")
      .eq("id", data.blockId)
      .maybeSingle();

    const patch: Record<string, any> = {
      draft_status: "pending",
      draft_updated_at: new Date().toISOString(),
      draft_updated_by: context.userId,
      draft_note: data.note ?? null,
    };
    if (data.content !== undefined) patch.draft_content = data.content;
    if (data.style !== undefined) patch.draft_style = data.style;

    const { data: row, error } = await sb
      .from("cms_layout_blocks")
      .update(patch)
      .eq("id", data.blockId)
      .select("*")
      .single();
    if (error) throw error;
    await audit(sb, "update", data.blockId, before, patch, "draft saved");
    return row;
  });

/** Discard the editor's own pending draft (no approval needed). */
export const discardBlockDraft = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i: { blockId: string }) => i)
  .handler(async ({ data, context }) => {
    const sb = context.supabase as any;
    await requireCmsEditor(sb, context.userId);
    const { error } = await sb
      .from("cms_layout_blocks")
      .update({
        draft_content: null,
        draft_style: null,
        draft_status: "none",
        draft_updated_at: null,
        draft_updated_by: null,
        draft_note: null,
      })
      .eq("id", data.blockId);
    if (error) throw error;
    await audit(sb, "update", data.blockId, null, null, "draft discarded");
    return { ok: true };
  });

/** Approve a pending draft → copy to live content/style and clear draft. */
export const approveBlockDraft = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i: { blockId: string; note?: string | null }) => i)
  .handler(async ({ data, context }) => {
    const sb = context.supabase as any;
    await requireCmsPublisher(sb, context.userId);

    const { data: row, error: e1 } = await sb
      .from("cms_layout_blocks")
      .select("content,style,draft_content,draft_style,draft_status")
      .eq("id", data.blockId)
      .maybeSingle();
    if (e1) throw e1;
    if (!row || row.draft_status !== "pending") throw new Error("Nincs függő módosítás.");

    const newContent = row.draft_content ?? row.content;
    const newStyle = row.draft_style ?? row.style;

    const { error: e2 } = await sb
      .from("cms_layout_blocks")
      .update({
        content: newContent,
        style: newStyle,
        draft_content: null,
        draft_style: null,
        draft_status: "approved",
        draft_note: data.note ?? null,
        updated_by: context.userId,
      })
      .eq("id", data.blockId);
    if (e2) throw e2;

    await audit(
      sb,
      "approve",
      data.blockId,
      { content: row.content, style: row.style },
      { content: newContent, style: newStyle },
      data.note ?? null,
    );
    return { ok: true };
  });

/** Reject a pending draft → discard the draft, leave live content intact. */
export const rejectBlockDraft = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i: { blockId: string; note?: string | null }) => i)
  .handler(async ({ data, context }) => {
    const sb = context.supabase as any;
    await requireCmsPublisher(sb, context.userId);

    const { data: before } = await sb
      .from("cms_layout_blocks")
      .select("draft_content,draft_style")
      .eq("id", data.blockId)
      .maybeSingle();

    const { error } = await sb
      .from("cms_layout_blocks")
      .update({
        draft_content: null,
        draft_style: null,
        draft_status: "rejected",
        draft_note: data.note ?? null,
      })
      .eq("id", data.blockId);
    if (error) throw error;
    await audit(sb, "reject", data.blockId, before, null, data.note ?? null);
    return { ok: true };
  });

/** Bulk approve multiple pending drafts. */
export const bulkApproveDrafts = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i: { blockIds: string[]; note?: string | null }) => i)
  .handler(async ({ data, context }) => {
    const sb = context.supabase as any;
    await requireCmsPublisher(sb, context.userId);
    let n = 0;
    for (const id of data.blockIds) {
      const { data: row } = await sb
        .from("cms_layout_blocks")
        .select("content,style,draft_content,draft_style,draft_status")
        .eq("id", id)
        .maybeSingle();
      if (!row || row.draft_status !== "pending") continue;
      const newContent = row.draft_content ?? row.content;
      const newStyle = row.draft_style ?? row.style;
      await sb
        .from("cms_layout_blocks")
        .update({
          content: newContent,
          style: newStyle,
          draft_content: null,
          draft_style: null,
          draft_status: "approved",
          draft_note: data.note ?? null,
          updated_by: context.userId,
        })
        .eq("id", id);
      await audit(sb, "approve", id, { content: row.content, style: row.style }, { content: newContent, style: newStyle }, data.note ?? null);
      n++;
    }
    return { ok: true, approved: n };
  });

/** List pending block drafts for a page (admin view). */
export const listPendingDraftsForPage = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i: { pageId: string }) => i)
  .handler(async ({ data, context }) => {
    const sb = context.supabase as any;
    await requireCmsEditor(sb, context.userId);
    const { data: rows, error } = await sb
      .from("cms_layout_blocks")
      .select("id,page_id,position,block_type,content,style,draft_content,draft_style,draft_status,draft_updated_at,draft_updated_by,draft_note")
      .eq("page_id", data.pageId)
      .eq("draft_status", "pending")
      .order("position", { ascending: true });
    if (error) throw error;
    return (rows ?? []) as PendingDraft[];
  });

/** Global pending count — for badges across the admin shell. */
export const countAllPendingDrafts = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const sb = context.supabase as any;
    await requireCmsEditor(sb, context.userId);
    const { count, error } = await sb
      .from("cms_layout_blocks")
      .select("id", { count: "exact", head: true })
      .eq("draft_status", "pending");
    if (error) throw error;
    return { count: count ?? 0 };
  });
