/**
 * Kliensoldali auto-tracking a CMS A/B kísérletekhez.
 *
 * - `window.lovableTrack(name, params?)` — programmatic API bárhonnan.
 * - `[data-track="event_name"]` (opcionálisan `data-track-params='{"foo":"bar"}'`)
 *   attribútum: automatikus klikk-listener a document szinten.
 *
 * Az események a `window.__lovableExperiments` regiszterben tárolt aktív
 * (experiment,variant) párokra tüzelnek — a regisztert a `useExperiment` hook tölti.
 */
import { trackExperimentEvent } from "./experiments";

export interface RegisteredExperiment {
  experimentId: string;
  variantId: string;
}

declare global {
  interface Window {
    __lovableExperiments?: RegisteredExperiment[];
    lovableTrack?: (name: string, params?: Record<string, unknown>) => void;
    __lovableTrackingInstalled?: boolean;
  }
}

/** Aktív (experiment,variant) regiszter — a hook add/remove-olja magát. */
export function registerActiveExperiment(exp: RegisteredExperiment): () => void {
  if (typeof window === "undefined") return () => {};
  const list = (window.__lovableExperiments ??= []);
  list.push(exp);
  return () => {
    if (!window.__lovableExperiments) return;
    window.__lovableExperiments = window.__lovableExperiments.filter(
      (e) => !(e.experimentId === exp.experimentId && e.variantId === exp.variantId),
    );
  };
}

function fire(name: string, params?: Record<string, unknown>) {
  const active = (typeof window !== "undefined" && window.__lovableExperiments) || [];
  if (active.length === 0) return;
  for (const { experimentId, variantId } of active) {
    trackExperimentEvent({
      experiment_id: experimentId,
      variant_id: variantId,
      event_type: "goal",
      event_name: name,
      params,
    });
  }
}

export function installTrackingBootstrap(): void {
  if (typeof window === "undefined") return;
  if (window.__lovableTrackingInstalled) return;
  window.__lovableTrackingInstalled = true;

  window.lovableTrack = (name: string, params?: Record<string, unknown>) => {
    if (!name || typeof name !== "string") return;
    fire(name, params);
  };

  document.addEventListener(
    "click",
    (ev) => {
      const target = ev.target as Element | null;
      if (!target || !(target as any).closest) return;
      const el = (target as Element).closest<HTMLElement>("[data-track]");
      if (!el) return;
      const name = el.getAttribute("data-track");
      if (!name) return;
      let params: Record<string, unknown> | undefined;
      const raw = el.getAttribute("data-track-params");
      if (raw) {
        try { params = JSON.parse(raw); } catch { /* ignore */ }
      }
      fire(name, params);
    },
    { capture: true, passive: true },
  );
}
