/**
 * Előregyártott blokk-sablonok a vizuális szerkesztő "Sablonok" gallériájához.
 * Minden sablon = (block_type, content) páros, ami egyetlen kattintással
 * beszúrható az aktuális oldal végére.
 *
 * A katalógus többféle block-típust fed le: hero, tartalom, lista, CTA,
 * dinamikus (élő adat) blokkok is.
 */
export type BlockTemplate = {
  id: string;
  label: string;
  category: "hero" | "content" | "cta" | "list" | "dynamic" | "media";
  description: string;
  block_type: string;
  content: Record<string, unknown>;
};

export const BLOCK_TEMPLATES: BlockTemplate[] = [
  // ── HERO ──────────────────────────────────────────────────────────────
  {
    id: "hero-default",
    label: "Hero — bemutatkozó",
    category: "hero",
    description: "Klasszikus nyitóblokk kicker/cím/lead + két CTA.",
    block_type: "klinika_hero",
    content: {
      kicker: "Egyetemi klinika",
      title: "Magas színvonalú ellátás, kutatás és oktatás egy helyen",
      lead: "Modern diagnosztika, multidiszciplináris csapat és betegközpontú gondoskodás.",
      ctas: [
        { label: "Időpontfoglalás", href: "/foglalas/uj", variant: "primary" },
        { label: "Orvost keresek", href: "/portal/orvos-kereso", variant: "secondary" },
      ],
    },
  },

  // ── CONTENT ───────────────────────────────────────────────────────────
  {
    id: "intro-3col",
    label: "3 oszlopos bemutató",
    category: "content",
    description: "Kicker + cím + lead + 3 kártya.",
    block_type: "klinika_intro_grid",
    content: {
      kicker: "Rólunk",
      title: "Amit a betegeink elvárhatnak",
      lead: "Több évtizedes tapasztalat és nemzetközi protokollok.",
      items: [
        { title: "Szakértő csapat", text: "Egyetemi oktatók, kutatók és gyakorló orvosok." },
        { title: "Modern eszközpark", text: "Legújabb diagnosztikai és terápiás technológia." },
        { title: "Betegközpontú szemlélet", text: "Egyéni igényekre szabott kezelési tervek." },
      ],
    },
  },
  {
    id: "stats",
    label: "Statisztika sáv",
    category: "content",
    description: "Ikon + szám + felirat (impact band).",
    block_type: "klinika_stats",
    content: {
      items: [
        { value: "25 000+", label: "Éves betegellátás" },
        { value: "60+", label: "Szakorvos" },
        { value: "18", label: "Szakambulancia" },
        { value: "24/7", label: "Sürgősségi készenlét" },
      ],
    },
  },
  {
    id: "icon-grid",
    label: "Ikon-rács (sötét)",
    category: "content",
    description: "2-4 oszlopos ikonos kártyák sötét háttéren.",
    block_type: "klinika_icon_grid",
    content: {
      title: "Szolgáltatásaink",
      items: [
        { title: "Szakrendelések", text: "18+ szakambulancia egy helyen." },
        { title: "Diagnosztika", text: "Labor, képalkotás, funkcionális vizsgálatok." },
        { title: "Rehabilitáció", text: "Egyénre szabott terápiás programok." },
        { title: "Ambuláns ellátás", text: "Rövid várakozási idővel." },
      ],
    },
  },
  {
    id: "faq",
    label: "GYIK — alap",
    category: "content",
    description: "Lenyíló kérdés-válasz lista 3 elemmel.",
    block_type: "klinika_faq",
    content: {
      title: "Gyakori kérdések",
      items: [
        { q: "Hogyan tudok időpontot foglalni?", a: "Online a Foglalás menüben, vagy telefonon hivatali időben." },
        { q: "Milyen dokumentumokat hozzak?", a: "TAJ-kártya, személyi igazolvány, korábbi leletek." },
        { q: "Van-e parkoló?", a: "Igen, a klinika területén korlátozott számú parkolóhely érhető el." },
      ],
    },
  },
  {
    id: "rich-text",
    label: "Rich text — bekezdés",
    category: "content",
    description: "Egyszerű HTML bekezdés, tetszőlegesen szerkeszthető.",
    block_type: "rich_text",
    content: {
      html: "<h2>Új szekció címe</h2><p>Írd át ezt a szöveget a jobb oldali szerkesztőben. Használhatsz <strong>félkövér</strong> és <em>dőlt</em> formátumot is.</p>",
    },
  },

  // ── LIST ──────────────────────────────────────────────────────────────
  {
    id: "team",
    label: "Csapat rács",
    category: "list",
    description: "Statikus csapatkártyák avatárokkal.",
    block_type: "klinika_team",
    content: {
      title: "Munkatársaink",
      members: [
        { name: "Dr. Példa Anna", role: "Osztályvezető főorvos" },
        { name: "Dr. Példa Béla", role: "Szakorvos" },
        { name: "Dr. Példa Csilla", role: "Szakorvos" },
      ],
    },
  },
  {
    id: "links-grid",
    label: "Hasznos linkek",
    category: "list",
    description: "Külső link-csempék rácsba rendezve.",
    block_type: "klinika_links_grid",
    content: {
      title: "Hasznos linkek",
      items: [
        { label: "Beteg-tájékoztatók", href: "/betegtajekoztatok" },
        { label: "Egyetemi oldal", href: "https://u-szeged.hu" },
        { label: "Kutatás", href: "/kutatas" },
      ],
    },
  },

  // ── CTA ───────────────────────────────────────────────────────────────
  {
    id: "cta-band",
    label: "CTA sáv",
    category: "cta",
    description: "Egysoros felhívás gombbal.",
    block_type: "cta_band",
    content: {
      title: "Foglaljon időpontot online",
      text: "Néhány kattintással, biztonságos rendszerben.",
      cta: { label: "Foglalás indítása", href: "/foglalas/uj" },
    },
  },
  {
    id: "contact",
    label: "Kapcsolat + térkép",
    category: "content",
    description: "Térkép + elérhetőség + CTA gombok.",
    block_type: "klinika_contact",
    content: {
      title: "Elérhetőségeink",
      address: "6720 Szeged, Korányi fasor 8.",
      phone: "+36 62 545 000",
      email: "info@klinika.hu",
      map_embed_url: "https://www.openstreetmap.org/export/embed.html?bbox=20.14,46.24,20.16,46.26&layer=mapnik",
      ctas: [
        { label: "Útvonaltervezés", href: "https://maps.google.com" },
        { label: "Telefonhívás", href: "tel:+3662545000" },
      ],
    },
  },

  // ── DYNAMIC (élő) ─────────────────────────────────────────────────────
  {
    id: "dyn-doctor-schedule",
    label: "Élő: Orvos szabad időpontok",
    category: "dynamic",
    description: "appointment_slots élő listája szűrővel + foglalás CTA.",
    block_type: "dyn_doctor_schedule",
    content: { title: "Szabad időpontok", doctor_id: "", specialty_id: "", org_unit_id: "", days: 14 },
  },
  {
    id: "dyn-booking-widget",
    label: "Élő: Foglalási widget",
    category: "dynamic",
    description: "Következő szabad időpontok mini-listája + prefill CTA a foglalási flow-ba.",
    block_type: "dyn_booking_widget",
    content: { title: "Foglaljon időpontot", lead: "Válasszon a következő szabad időpontok közül.", doctor_id: "", specialty_id: "", org_unit_id: "", days: 7, max_slots: 6 },
  },
  {
    id: "dyn-staff-grid",
    label: "Élő: Munkatársak rácsa",
    category: "dynamic",
    description: "cms_staff_profiles publikus listája.",
    block_type: "dyn_staff_grid",
    content: { title: "Munkatársaink", locale: "hu", specialty: "", limit: 12 },
  },
  {
    id: "dyn-news-list",
    label: "Élő: Hírek lista",
    category: "dynamic",
    description: "Legfrissebb publikált hírek automatikusan.",
    block_type: "dyn_news_list",
    content: { title: "Legfrissebb híreink", locale: "hu", limit: 6 },
  },
  {
    id: "dyn-tips-list",
    label: "Élő: Tanácsok lista",
    category: "dynamic",
    description: "cms_tips publikus tanácsok.",
    block_type: "dyn_tips_list",
    content: { title: "Egészség-tippek", locale: "hu", limit: 6, featured_only: false },
  },
  {
    id: "dyn-faq",
    label: "Élő: GYIK (tag-szűrt)",
    category: "dynamic",
    description: "cms_faqs sorai tag-szűréssel.",
    block_type: "dyn_faq",
    content: { title: "Gyakori kérdések", tag: "", locale: "hu", limit: 20 },
  },
  {
    id: "dyn-contact-form",
    label: "Élő: Kapcsolatfelvétel űrlap",
    category: "dynamic",
    description: "Anonym üzenet küldés a contact_messages táblába.",
    block_type: "dyn_contact_form",
    content: { title: "Írjon nekünk", lead: "Munkatársunk 1 munkanapon belül válaszol.", org_unit_id: null },
  },
];
