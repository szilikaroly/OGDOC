/**
 * CMS Dinamikus blokkok – publikus szerver fn-ek (anon olvasás, kontaktbeküldés).
 *
 * Minden fn a SUPABASE_PUBLISHABLE_KEY-en keresztül megy → RLS érvényesül,
 * így csak az `is_published = true` / publikus policy-vel rendelkező sorokat
 * látja az anon hívó.
 */
import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";

function pub() {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_PUBLISHABLE_KEY;
  if (!url || !key) throw new Error("Missing Supabase env");
  return createClient(url, key, {
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
  });
}

/* ---------- Staff profile (publikus) ---------- */
export const getPublicStaffProfile = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) =>
    z.object({ slug: z.string().min(1).max(200), locale: z.string().default("hu") }).parse(d),
  )
  .handler(async ({ data }) => {
    const s = pub();
    const { data: row, error } = await s
      .from("cms_staff_profiles")
      .select("id, profile_id, slug, locale, display_name, title, photo_url, bio, specialties, languages, publications, publish_schedule, seo_title, seo_description")
      .eq("slug", data.slug)
      .eq("locale", data.locale)
      .eq("is_published", true)
      .maybeSingle();
    if (error) throw new Error(error.message);
    return row;
  });

/* ---------- Staff lista (admin paraméter-választóhoz vagy lapozó listához) ---------- */
export const listPublicStaff = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) =>
    z.object({ locale: z.string().default("hu"), specialty: z.string().optional() }).parse(d),
  )
  .handler(async ({ data }) => {
    const s = pub();
    let q = s
      .from("cms_staff_profiles")
      .select("id, slug, display_name, title, photo_url, specialties, sort_order")
      .eq("locale", data.locale)
      .eq("is_published", true)
      .order("sort_order", { ascending: true })
      .limit(200);
    if (data.specialty) q = q.contains("specialties", [data.specialty]);
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

/* ---------- FAQ lista (publikus) ---------- */
export const listPublicFaqs = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) =>
    z
      .object({
        locale: z.string().default("hu"),
        tag: z.string().optional(),
        limit: z.number().int().min(1).max(50).default(20),
      })
      .parse(d),
  )
  .handler(async ({ data }) => {
    const s = pub();
    let q = s
      .from("cms_faqs")
      .select("id, question, answer, tags, sort_order")
      .eq("locale", data.locale)
      .eq("is_published", true)
      .order("sort_order", { ascending: true })
      .limit(data.limit);
    if (data.tag) q = q.contains("tags", [data.tag]);
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

/* ---------- Orvos / szakma rendelési idők (publikus, foglalható szabad slotok) ---------- */
const ScheduleInput = z.object({
  doctor_id: z.string().uuid().optional(),
  specialty_id: z.string().uuid().optional(),
  org_unit_id: z.string().uuid().optional(),
  days: z.number().int().min(1).max(60).default(14),
});

export const getDoctorSchedule = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) => ScheduleInput.parse(d))
  .handler(async ({ data }) => {
    if (!data.doctor_id && !data.specialty_id && !data.org_unit_id) {
      return { resources: [], slots: [] };
    }
    const s = pub();
    const fromDate = new Date();
    const toDate = new Date(Date.now() + data.days * 24 * 60 * 60 * 1000);
    const fromIso = fromDate.toISOString();
    const toIso = toDate.toISOString();

    let rq = s
      .from("appointment_resources")
      .select("id, nev, tipus, orvos_id, szakma_id, org_unit_id, aktiv")
      .eq("aktiv", true)
      .limit(50);
    if (data.doctor_id) rq = rq.eq("orvos_id", data.doctor_id);
    if (data.specialty_id) rq = rq.eq("szakma_id", data.specialty_id);
    if (data.org_unit_id) rq = rq.eq("org_unit_id", data.org_unit_id);
    const { data: resources, error: rerr } = await rq;
    if (rerr) throw new Error(rerr.message);
    const ids = (resources ?? []).map((r: any) => r.id);
    if (!ids.length) return { resources: [], slots: [] };

    const { data: slots, error: serr } = await s
      .from("appointment_slots")
      .select("id, resource_id, kezdo_ts, veg_ts, kapacitas, status")
      .in("resource_id", ids)
      .eq("status", "szabad")
      .gte("kezdo_ts", fromIso)
      .lte("kezdo_ts", toIso)
      .order("kezdo_ts", { ascending: true })
      .limit(500);
    if (serr) throw new Error(serr.message);
    return { resources: resources ?? [], slots: slots ?? [] };
  });

/* ---------- Site beállítások (publikus: SOS, default OG, default locale) ---------- */
export const getPublicSiteSettings = createServerFn({ method: "GET" }).handler(async () => {
  const s = pub();
  const { data, error } = await s
    .from("cms_site_settings")
    .select("sos_active, sos_message, default_og_image_url, default_locale, organization_jsonld")
    .eq("id", 1)
    .maybeSingle();
  if (error) throw new Error(error.message);
  return data ?? { sos_active: false, sos_message: null, default_og_image_url: null, default_locale: "hu", organization_jsonld: null };
});

/* ---------- Kapcsolatfelvétel beküldése (anon engedélyezett INSERT) ---------- */
const ContactInput = z.object({
  org_unit_id: z.string().uuid().nullable().optional(),
  source_page_slug: z.string().max(300).nullable().optional(),
  sender_name: z.string().min(2).max(200),
  sender_email: z.string().email().max(320),
  sender_phone: z.string().max(50).nullable().optional(),
  subject: z.string().max(300).nullable().optional(),
  body: z.string().min(5).max(5000),
  locale: z.string().default("hu"),
  hp: z.string().max(0).optional(), // honeypot: legyen üres
});

export const submitContactMessage = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => ContactInput.parse(d))
  .handler(async ({ data }) => {
    if (data.hp && data.hp.length > 0) return { ok: true }; // spam – csendben elnyel
    const s = pub();
    const { error } = await s.from("contact_messages").insert({
      org_unit_id: data.org_unit_id ?? null,
      source_page_slug: data.source_page_slug ?? null,
      sender_name: data.sender_name,
      sender_email: data.sender_email,
      sender_phone: data.sender_phone ?? null,
      subject: data.subject ?? null,
      body: data.body,
      locale: data.locale,
    });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/* ---------- Departments (org_units publikus listája paraméter-választóhoz) ---------- */
export const listPublicOrgUnits = createServerFn({ method: "GET" }).handler(async () => {
  const s = pub();
  const { data, error } = await s
    .from("org_units")
    .select("id, nev, rovid_nev, szint")
    .order("nev")
    .limit(500);
  if (error) throw new Error(error.message);
  return data ?? [];
});

export const getOrgUnit = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data }) => {
    const s = pub();
    const { data: row, error } = await s
      .from("org_units")
      .select("*")
      .eq("id", data.id)
      .maybeSingle();
    if (error) throw new Error(error.message);
    return row;
  });
