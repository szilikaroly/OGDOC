// Kliens-oldali kép-optimalizálás: WebP konverzió + opcionális resize.
// Canvas API-t használ, nincs külső függőség.

export type ConvertOptions = {
  maxWidth?: number;     // ha az eredeti szélesebb, lekicsinyíti
  quality?: number;      // 0..1
  format?: "image/webp"; // jelenleg csak WebP (canvas.toBlob nem támogatja megbízhatóan az AVIF-et)
};

const SKIP_MIME = new Set([
  "image/svg+xml",
  "image/gif",
  "image/webp",
  "image/avif",
]);

export function shouldConvertImage(file: File): boolean {
  if (!file.type.startsWith("image/")) return false;
  if (SKIP_MIME.has(file.type)) return false;
  return true;
}

export async function convertToWebp(
  file: File,
  opts: ConvertOptions = {},
): Promise<File> {
  const { maxWidth = 2000, quality = 0.85 } = opts;

  if (!shouldConvertImage(file)) return file;

  // dekódolás
  const bitmap = await createImageBitmap(file).catch(() => null);
  if (!bitmap) return file;

  const ratio = bitmap.width > maxWidth ? maxWidth / bitmap.width : 1;
  const w = Math.round(bitmap.width * ratio);
  const h = Math.round(bitmap.height * ratio);

  const canvas = typeof OffscreenCanvas !== "undefined"
    ? new OffscreenCanvas(w, h)
    : Object.assign(document.createElement("canvas"), { width: w, height: h });

  const ctx = (canvas as any).getContext("2d");
  if (!ctx) { bitmap.close(); return file; }
  ctx.drawImage(bitmap, 0, 0, w, h);
  bitmap.close();

  let blob: Blob | null;
  if (canvas instanceof OffscreenCanvas) {
    try {
      blob = await canvas.convertToBlob({ type: "image/webp", quality });
    } catch {
      blob = null;
    }
  } else {
    blob = await new Promise<Blob | null>((resolve) =>
      (canvas as HTMLCanvasElement).toBlob(resolve, "image/webp", quality),
    );
  }

  if (!blob) return file;

  // ha a konverzió nem nyer méretet, megtartjuk az eredetit
  if (blob.size >= file.size) return file;

  const newName = file.name.replace(/\.[^.]+$/, "") + ".webp";
  return new File([blob], newName, { type: "image/webp", lastModified: Date.now() });
}
