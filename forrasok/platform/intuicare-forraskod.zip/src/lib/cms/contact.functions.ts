/**
 * CMS Contact messages – admin lista + kezelés (cms_editor/admin).
 * Híd: kezelés jelzéssel automatikusan értesíti az osztály felelősét.
 */
import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

async function assertCms(ctx: { supabase: any; userId: string }) {
  const { data, error } = await ctx.supabase.rpc("has_cms_access", { _user_id: ctx.userId });
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Nincs CMS jogosultságod.");
}

export const listContactMessages = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({ status: z.enum(["new", "read", "replied", "archived", "all"]).default("new") }).parse(d ?? {}),
  )
  .handler(async ({ data, context }) => {
    await assertCms(context);
    let q = context.supabase
      .from("contact_messages")
      .select("*, org_units(id, nev)")
      .order("created_at", { ascending: false })
      .limit(200);
    if (data.status !== "all") q = q.eq("status", data.status);
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

export const updateContactStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z
      .object({
        id: z.string().uuid(),
        status: z.enum(["new", "read", "replied", "archived"]),
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    await assertCms(context);
    const patch: any = { status: data.status };
    if (data.status !== "new") {
      patch.handled_by = context.userId;
      patch.handled_at = new Date().toISOString();
    }
    const { error } = await context.supabase
      .from("contact_messages")
      .update(patch)
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const countNewContactMessages = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertCms(context);
    const { count, error } = await context.supabase
      .from("contact_messages")
      .select("id", { count: "exact", head: true })
      .eq("status", "new");
    if (error) throw new Error(error.message);
    return { count: count ?? 0 };
  });
