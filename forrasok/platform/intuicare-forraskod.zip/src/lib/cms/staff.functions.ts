/**
 * CMS Staff profilok – admin CRUD (cms_editor/admin).
 */
import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

async function assertCms(ctx: { supabase: any; userId: string }) {
  const { data, error } = await ctx.supabase.rpc("has_cms_access", { _user_id: ctx.userId });
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Nincs CMS jogosultságod.");
}

const StaffInput = z.object({
  id: z.string().uuid().optional(),
  profile_id: z.string().uuid(),
  slug: z.string().min(1).regex(/^[a-z0-9-]+$/),
  locale: z.string().default("hu"),
  display_name: z.string().min(1).max(200),
  title: z.string().nullable().optional(),
  photo_url: z.string().nullable().optional(),
  bio: z.string().nullable().optional(),
  specialties: z.array(z.string()).default([]),
  languages: z.array(z.string()).default([]),
  publications: z.any().default([]),
  publish_schedule: z.boolean().default(false),
  is_published: z.boolean().default(false),
  sort_order: z.number().int().default(0),
  seo_title: z.string().nullable().optional(),
  seo_description: z.string().nullable().optional(),
});

export const listStaffProfiles = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertCms(context);
    const { data, error } = await context.supabase
      .from("cms_staff_profiles")
      .select("*")
      .order("locale")
      .order("sort_order")
      .order("display_name");
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const saveStaffProfile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => StaffInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertCms(context);
    const { data: row, error } = await context.supabase
      .from("cms_staff_profiles")
      .upsert(data as any, { onConflict: "id" })
      .select()
      .single();
    if (error) throw new Error(error.message);
    return row;
  });

export const deleteStaffProfile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCms(context);
    const { error } = await context.supabase.from("cms_staff_profiles").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/* ---------- Profile (orvos) választó az admin felületre ---------- */
export const listCandidateProfiles = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertCms(context);
    const { data, error } = await context.supabase
      .from("profiles")
      .select("id, nev, email, tenant_id")
      .order("nev")
      .limit(500);
    if (error) throw new Error(error.message);
    return data ?? [];
  });
