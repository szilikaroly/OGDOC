/**
 * Központi HTML-sanitizálás CMS eredetű rich-text tartalomhoz.
 * Minden `dangerouslySetInnerHTML` hívás előtt ezt kell használni,
 * hogy egy kompromittált szerkesztői fiók se tudjon scriptet injektálni.
 */
import DOMPurify from "dompurify";

/** SSR fallback: nincs DOM, ezért a veszélyes elemeket/attribútumokat kiszűrjük. */
function stripDangerous(html: string): string {
  return html
    .replace(/<\s*(script|style|object|embed|link|meta|base)\b[\s\S]*?<\s*\/\s*\1\s*>/gi, "")
    .replace(/<\s*(script|style|object|embed|link|meta|base)\b[^>]*\/?>/gi, "")
    .replace(/\son[a-z]+\s*=\s*"[^"]*"/gi, "")
    .replace(/\son[a-z]+\s*=\s*'[^']*'/gi, "")
    .replace(/\son[a-z]+\s*=\s*[^\s>]+/gi, "")
    .replace(/(href|src|xlink:href)\s*=\s*(["']?)\s*javascript:[^"'>\s]*\2/gi, '$1="#"');
}

export function sanitizeCmsHtml(html: string | null | undefined): string {
  const value = String(html ?? "");
  if (!value) return "";
  if (typeof window === "undefined") return stripDangerous(value);
  return DOMPurify.sanitize(value, {
    ADD_TAGS: ["iframe", "video", "source"],
    ADD_ATTR: [
      "allow", "allowfullscreen", "frameborder", "scrolling", "target",
      "loading", "referrerpolicy", "controls", "playsinline", "poster",
      "data-embed", "data-src", "data-provider", "data-title", "data-align", "data-href", "data-href-target",
    ],
  });

}
