/**
 * Publikus dolgozói lista + opt-in láthatóság.
 * - listPublishedStaff: anon publishable client, csak engedélyezett mezők.
 * - updateMyStaffVisibility: csak saját rekordra.
 */
import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

function pub() {
  return createClient(
    process.env.SUPABASE_URL!,
    process.env.SUPABASE_PUBLISHABLE_KEY!,
    { auth: { storage: undefined, persistSession: false, autoRefreshToken: false } },
  );
}

const ALLOWED_FIELDS = new Set([
  "display_name", "title", "photo_url", "bio", "specialties", "languages",
  "publications", "publish_schedule",
]);

function applyVisibility(row: any): any {
  if (!row) return row;
  if (row.public_visibility === "full") {
    return row;
  }
  // partial → csak public_fields-ben true-ra állítottak
  const fields = (row.public_fields ?? {}) as Record<string, boolean>;
  const out: any = {
    id: row.id, slug: row.slug, locale: row.locale,
    display_name: row.display_name, // név mindig látszik
  };
  for (const k of Object.keys(fields)) {
    if (fields[k] && ALLOWED_FIELDS.has(k)) out[k] = row[k];
  }
  return out;
}

export const listPublishedStaff = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) =>
    z.object({
      locale: z.string().default("hu"),
      specialty: z.string().optional(),
      limit: z.number().int().min(1).max(200).default(60),
    }).parse(d),
  )
  .handler(async ({ data }) => {
    const sb = pub();
    let q = sb
      .from("cms_staff_profiles")
      .select("id, slug, locale, display_name, title, photo_url, bio, specialties, languages, publications, publish_schedule, public_visibility, public_fields, sort_order")
      .eq("locale", data.locale)
      .eq("is_published", true)
      .neq("public_visibility", "private")
      .order("sort_order", { ascending: true })
      .limit(data.limit);
    if (data.specialty) q = q.contains("specialties", [data.specialty]);
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    return (rows ?? []).map(applyVisibility);
  });

export const getPublishedStaffBySlug = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) =>
    z.object({ slug: z.string().min(1), locale: z.string().default("hu") }).parse(d),
  )
  .handler(async ({ data }) => {
    const sb = pub();
    const { data: row } = await sb
      .from("cms_staff_profiles")
      .select("*")
      .eq("slug", data.slug)
      .eq("locale", data.locale)
      .eq("is_published", true)
      .neq("public_visibility", "private")
      .maybeSingle();
    return applyVisibility(row);
  });

/* ------- self-service: mit jelenítsek meg publikusan ------- */
const VisibilityInput = z.object({
  is_published: z.boolean(),
  public_visibility: z.enum(["private", "partial", "full"]),
  public_fields: z.record(z.string(), z.boolean()).default({}),
});

export const getMyStaffVisibility = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data } = await (context.supabase as any)
      .from("cms_staff_profiles")
      .select("id, slug, display_name, is_published, public_visibility, public_fields")
      .eq("profile_id", context.userId)
      .eq("locale", "hu")
      .maybeSingle();
    return data ?? null;
  });

export const updateMyStaffVisibility = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => VisibilityInput.parse(d))
  .handler(async ({ data, context }) => {
    const { error } = await (context.supabase as any)
      .from("cms_staff_profiles")
      .update({
        is_published: data.is_published,
        public_visibility: data.public_visibility,
        public_fields: data.public_fields,
      })
      .eq("profile_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
