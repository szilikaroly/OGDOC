/**
 * CMS block catalog — central registry of block types with UI metadata.
 * Each block has a stable `type` key persisted in `cms_layout_blocks.block_type`
 * or inside `cms_global_regions.blocks[].type`.
 *
 * Content payloads are JSON; renderer components defensively access them. A
 * strict Zod schema per block can be added in a later phase for the visual
 * editor (auto-generated forms).
 */

export type BlockCategory = "hero" | "content" | "list" | "cta" | "media" | "layout" | "klinika";

export type BlockMeta = {
  type: string;
  label: string;
  description: string;
  category: BlockCategory;
  /** Default content payload used when inserting a new block in the editor. */
  defaults?: Record<string, unknown>;
  /** Region keys where the block is allowed; empty = any. */
  regions?: string[];
};

export const BLOCK_CATALOG: BlockMeta[] = [
  // ── Klinika-specific layout blocks (preserve current SZTE landing look) ──
  { type: "klinika_top_bar", label: "Felső sáv", description: "Sötét felső segéd-sáv egyetemi linkekkel.", category: "klinika", regions: ["top_bar"] },
  { type: "klinika_site_header", label: "Egyetemi fejléc", description: "Címer, intézménynév és belépés gomb.", category: "klinika", regions: ["header"] },
  { type: "klinika_main_nav", label: "Fő navigáció", description: "Sticky menü szekciókhoz.", category: "klinika", regions: ["main_nav"] },
  { type: "klinika_hero", label: "Hero kép + cím", description: "Háttérképes nyitóblokk kicker/cím/lead/CTA-kkal.", category: "hero" },
  { type: "klinika_intro_grid", label: "3 oszlopos bemutató", description: "Kicker + cím + lead + 3 kártya.", category: "content" },
  { type: "klinika_stats", label: "Statisztika sáv", description: "Ikon + szám + felirat (impact band).", category: "content" },
  { type: "klinika_icon_grid", label: "Ikon-rács (sötét)", description: "2-4 oszlopos ikonos kártyák sötét háttéren.", category: "content" },
  { type: "klinika_schedule_table", label: "Rendelési idők", description: "Táblázat + jobb oldali infókártyák + CTA-k.", category: "content" },
  { type: "klinika_team", label: "Csapat rács", description: "Avatarrós csapatkártyák.", category: "list" },
  { type: "klinika_3col_features", label: "3 oszlopos kiemelés", description: "Felső arany szegéllyel.", category: "content" },
  { type: "klinika_news", label: "Hírek (kézi)", description: "Statikus hír-rács (a hirek táblától független).", category: "list" },
  { type: "klinika_logo_grid", label: "Projekt-logó rács", description: "Szöveges logó-mező rács.", category: "list" },
  { type: "klinika_jobs", label: "Álláslehetőségek", description: "Sötét sáv jobb oldali állás-listával.", category: "cta" },
  { type: "klinika_links_grid", label: "Hasznos linkek", description: "Külső link-csempék.", category: "list" },
  { type: "klinika_faq", label: "GYIK", description: "Lenyíló kérdés-válasz lista.", category: "content" },
  { type: "klinika_contact", label: "Kapcsolat + térkép", description: "Térkép + elérhetőség sor + CTA gombok.", category: "content" },
  { type: "klinika_footer", label: "Lábléc (4 oszlop)", description: "Link-oszlopok + social ikonok + jogi sor.", category: "klinika", regions: ["footer"] },

  // ── Generic blocks (can be added on any page) ──
  { type: "rich_text", label: "Szöveg (rich)", description: "Tiptap-szerkesztett HTML.", category: "content", defaults: { html: "<p>Új szöveg</p>" } },
  { type: "image_text", label: "Kép + szöveg", description: "Két oszlopos elrendezés.", category: "content" },
  { type: "cta_band", label: "CTA sáv", description: "Egysoros felhívás gombbal.", category: "cta" },
  { type: "embed_html", label: "Egyedi HTML", description: "Beágyazott raw HTML.", category: "media" },
  { type: "divider", label: "Elválasztó", description: "Vízszintes vonal.", category: "layout" },
  {
    type: "nav_menu", label: "Menü (cms_menus)", category: "layout",
    description: "CMS-ben kezelt menü beillesztése slug + nyelv alapján.",
    defaults: { slug: "main", locale: "hu", variant: "horizontal" },
  },


  // ── Dinamikus (élő DB) blokkok ──
  {
    type: "dyn_doctor_card", label: "Orvos kártya (élő)", category: "content",
    description: "Adatbázisból betöltött orvos-profil slug alapján.",
    defaults: { slug: "", locale: "hu" },
  },
  {
    type: "dyn_faq", label: "GYIK (élő, tag-szűrt)", category: "content",
    description: "cms_faqs sorai tag-szűréssel, lokálé szerint.",
    defaults: { title: "Gyakori kérdések", tag: "", locale: "hu", limit: 20 },
  },
  {
    type: "dyn_contact_form", label: "Kapcsolatfelvétel űrlap", category: "cta",
    description: "Üzenet a contact_messages táblába (anon).",
    defaults: { title: "Írjon nekünk", lead: "Munkatársunk 1 munkanapon belül válaszol.", org_unit_id: null },
  },
  {
    type: "dyn_doctor_schedule", label: "Orvos szabad időpontok (élő)", category: "content",
    description: "appointment_slots élő listája szűrővel + foglalás CTA.",
    defaults: { title: "Szabad időpontok", doctor_id: "", specialty_id: "", org_unit_id: "", days: 14 },
  },
  {
    type: "dyn_booking_widget", label: "Foglalási widget (élő)", category: "cta",
    description: "Kompakt widget: következő szabad időpontok + prefill CTA a foglalási flow-ba.",
    defaults: { title: "Foglaljon időpontot", lead: "", doctor_id: "", specialty_id: "", org_unit_id: "", days: 7, max_slots: 6 },
  },
  {
    type: "dyn_staff_grid", label: "Munkatársak (élő)", category: "list",
    description: "cms_staff_profiles publikus listája, opcionális szakterület-szűrővel.",
    defaults: { title: "Munkatársaink", locale: "hu", specialty: "", limit: 12 },
  },
  {
    type: "dyn_news_list", label: "Hírek lista (élő)", category: "list",
    description: "cms_news_posts legutóbbi publikált hírei.",
    defaults: { title: "Legfrissebb híreink", locale: "hu", limit: 6 },
  },
  {
    type: "dyn_tips_list", label: "Tanácsok lista (élő)", category: "list",
    description: "cms_tips publikus tanácsok, kategória / közönség szűrővel.",
    defaults: { title: "Tanácsok", locale: "hu", limit: 6, featured_only: false },
  },
  {
    type: "dyn_news_hero", label: "Hír fejléc (élő)", category: "hero",
    description: "Nagy borító, cím, kivonat és metaadatok — post_slug alapján automatikus kiegészítéssel.",
    defaults: { title: "", excerpt: "", cover: "", cover_alt: "", post_slug: "", locale: "hu" },
  },
  {
    type: "dyn_news_related", label: "Kapcsolódó hírek (élő)", category: "list",
    description: "Az aktuális hír kategóriájából ajánl további cikkeket.",
    defaults: { title: "Kapcsolódó cikkek", post_slug: "", limit: 3, locale: "hu" },
  },
  {
    type: "dyn_share_bar", label: "Megosztó sáv", category: "cta",
    description: "Natív Share API + link vágólapra másolás.",
    defaults: { title: "" },
  },
];

export const BLOCK_BY_TYPE: Record<string, BlockMeta> = Object.fromEntries(
  BLOCK_CATALOG.map((b) => [b.type, b]),
);

export const REGION_KEYS = ["top_bar", "header", "main_nav", "footer", "mobile_drawer"] as const;
export type RegionKey = typeof REGION_KEYS[number];

export const REGION_META: Record<RegionKey, { label: string; description: string }> = {
  top_bar: { label: "Felső segéd-sáv", description: "Egyetemi linkek, EN, kontraszt." },
  header: { label: "Fejléc", description: "Címer, intézménynév, belépés." },
  main_nav: { label: "Fő menü", description: "Sticky szekció-navigáció." },
  footer: { label: "Lábléc", description: "Link-oszlopok, social, jogi sor." },
  mobile_drawer: { label: "Mobil menü", description: "Hamburger-menü tartalom." },
};
