/**
 * Kliensoldali debug store: mely blockhoz melyik A/B kísérlet-variant lett választva
 * az aktuális oldalon. Csak admin-only overlay olvassa (?expdebug=1).
 */
import { useEffect, useState } from "react";

export interface ExperimentDebugEntry {
  key: string; // uniq: blockId + experimentId
  blockId: string;
  blockKind: "block" | "layout_block";
  blockType?: string;
  blockLabel?: string;
  experimentId: string;
  experimentName?: string;
  variantId: string;
  variantKey: string;
  isControl?: boolean;
}

type Listener = (entries: ExperimentDebugEntry[]) => void;

const store = new Map<string, ExperimentDebugEntry>();
const listeners = new Set<Listener>();

function emit() {
  const snapshot = Array.from(store.values());
  for (const l of listeners) l(snapshot);
}

export function addDebugEntry(entry: ExperimentDebugEntry) {
  store.set(entry.key, entry);
  emit();
}

export function removeDebugEntry(key: string) {
  if (store.delete(key)) emit();
}

export function getDebugEntries(): ExperimentDebugEntry[] {
  return Array.from(store.values());
}

export function subscribeDebug(l: Listener): () => void {
  listeners.add(l);
  l(Array.from(store.values()));
  return () => { listeners.delete(l); };
}

/** React hook — visszaadja az aktuálisan aktív debug bejegyzéseket. */
export function useExperimentDebugEntries(): ExperimentDebugEntry[] {
  const [entries, setEntries] = useState<ExperimentDebugEntry[]>(() => getDebugEntries());
  useEffect(() => subscribeDebug(setEntries), []);
  return entries;
}
