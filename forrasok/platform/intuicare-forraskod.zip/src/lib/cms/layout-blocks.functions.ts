/**
 * Server functions for CMS layout blocks + global regions.
 * Public reads use a publishable server client (RLS allows anon SELECT on
 * published rows). Writes require has_cms_access via the auth middleware.
 */
import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { Database } from "@/integrations/supabase/types";

function publicClient() {
  return createClient<Database>(
    process.env.SUPABASE_URL!,
    process.env.SUPABASE_PUBLISHABLE_KEY!,
    { auth: { storage: undefined, persistSession: false, autoRefreshToken: false } },
  );
}

export type LayoutBlock = {
  id: string;
  page_id: string | null;
  region_key: string | null;
  position: number;
  block_type: string;
  content: Record<string, any>;
  style: Record<string, any>;
  locale: string;
  status: string;
};

export type GlobalRegion = {
  region_key: string;
  locale: string;
  blocks: Array<{ id?: string; type: string; content: Record<string, any>; style?: Record<string, any> }>;
};

export type HomeLayout = {
  page: { id: string; title: string; seo_title: string | null; seo_description: string | null; og_image_url: string | null; layout: string } | null;
  blocks: LayoutBlock[];
  regions: GlobalRegion[];
};

/** Public — returns the published home page layout + its blocks + global regions. */
export const getHomeLayout = createServerFn({ method: "GET" })
  .inputValidator((input?: { locale?: string }) => ({ locale: input?.locale ?? "hu" }))
  .handler(async ({ data }): Promise<HomeLayout> => {
    const sb = publicClient();
    const { data: page } = await (sb as any)
      .from("cms_pages")
      .select("id,title,seo_title,seo_description,og_image_url,layout")
      .eq("is_home", true)
      .eq("status", "published")
      .maybeSingle();

    let blocks: LayoutBlock[] = [];
    if (page?.id) {
      const { data: rows } = await (sb as any)
        .from("cms_layout_blocks")
        .select("id,page_id,region_key,position,block_type,content,style,locale,status")
        .eq("page_id", page.id)
        .eq("locale", data.locale)
        .eq("status", "published")
        .order("position", { ascending: true });
      blocks = (rows ?? []) as LayoutBlock[];
    }

    const { data: regionRows } = await (sb as any)
      .from("cms_global_regions")
      .select("region_key,locale,blocks")
      .eq("locale", data.locale)
      .eq("status", "published");

    return {
      page: page ?? null,
      blocks,
      regions: (regionRows ?? []) as GlobalRegion[],
    };
  });

/** Public — fetch only the published global regions for a locale. */
export const getGlobalRegions = createServerFn({ method: "GET" })
  .inputValidator((input?: { locale?: string }) => ({ locale: input?.locale ?? "hu" }))
  .handler(async ({ data }): Promise<GlobalRegion[]> => {
    const sb = publicClient();
    const { data: regionRows } = await (sb as any)
      .from("cms_global_regions")
      .select("region_key,locale,blocks")
      .eq("locale", data.locale)
      .eq("status", "published");
    return (regionRows ?? []) as GlobalRegion[];
  });

/** Editor — list ALL global regions (any status) for the admin UI. */
export const listGlobalRegions = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input?: { locale?: string }) => ({ locale: input?.locale ?? "hu" }))
  .handler(async ({ data, context }) => {
    const { data: rows, error } = await (context.supabase as any)
      .from("cms_global_regions")
      .select("*")
      .eq("locale", data.locale);
    if (error) throw error;
    return (rows ?? []) as Array<GlobalRegion & { status: string }>;
  });

/** Editor — list blocks of one page (all statuses) for the admin UI. */
export const listPageBlocks = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { pageId: string; locale?: string }) => ({ pageId: input.pageId, locale: input.locale ?? "hu" }))
  .handler(async ({ data, context }) => {
    const { data: rows, error } = await (context.supabase as any)
      .from("cms_layout_blocks")
      .select("*")
      .eq("page_id", data.pageId)
      .eq("locale", data.locale)
      .order("position", { ascending: true });
    if (error) throw error;
    return rows as LayoutBlock[];
  });

/** Editor — upsert one block (insert when id missing, update when present). */
export const upsertLayoutBlock = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: Partial<LayoutBlock> & { block_type: string }) => input)
  .handler(async ({ data, context }) => {
    const row = { ...data, updated_by: context.userId };
    const { data: out, error } = await (context.supabase as any)
      .from("cms_layout_blocks")
      .upsert(row)
      .select("*")
      .single();
    if (error) throw error;
    return out as LayoutBlock;
  });

export const deleteLayoutBlock = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string }) => input)
  .handler(async ({ data, context }) => {
    const { error } = await (context.supabase as any).from("cms_layout_blocks").delete().eq("id", data.id);
    if (error) throw error;
    return { ok: true };
  });

export const reorderLayoutBlocks = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { items: Array<{ id: string; position: number }> }) => input)
  .handler(async ({ data, context }) => {
    for (const it of data.items) {
      await (context.supabase as any).from("cms_layout_blocks").update({ position: it.position }).eq("id", it.id);
    }
    return { ok: true };
  });

/**
 * Editor — másol vagy áthelyez blokkokat oldalak között.
 * `mode: "copy"` új ID-kkal létrehoz, `mode: "move"` áthelyezi a meglévőket.
 * Mindig a célközpont végére fűzi (pozíciók helyesen továbbgörgetve).
 */
export const transferBlocks = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { blockIds: string[]; targetPageId: string; mode: "copy" | "move" }) => input)
  .handler(async ({ data, context }) => {
    if (!data.blockIds.length) return { ok: true, inserted: 0 };
    const sb = context.supabase as any;

    const { data: src, error: e1 } = await sb
      .from("cms_layout_blocks")
      .select("id,page_id,region_key,block_type,content,style,locale,status")
      .in("id", data.blockIds);
    if (e1) throw e1;
    if (!src?.length) return { ok: true, inserted: 0 };

    const { data: lastRow } = await sb
      .from("cms_layout_blocks")
      .select("position")
      .eq("page_id", data.targetPageId)
      .order("position", { ascending: false })
      .limit(1)
      .maybeSingle();
    let nextPos = (lastRow?.position ?? -1) + 1;

    if (data.mode === "move") {
      for (const b of src) {
        const { error } = await sb
          .from("cms_layout_blocks")
          .update({ page_id: data.targetPageId, position: nextPos++, updated_by: context.userId })
          .eq("id", b.id);
        if (error) throw error;
      }
      return { ok: true, inserted: src.length };
    }

    // copy → ID nélkül beszúrjuk
    const rows = src.map((b: any) => ({
      page_id: data.targetPageId,
      region_key: b.region_key,
      block_type: b.block_type,
      content: b.content,
      style: b.style,
      locale: b.locale,
      status: b.status,
      position: nextPos++,
      updated_by: context.userId,
    }));
    const { error: e2 } = await sb.from("cms_layout_blocks").insert(rows);
    if (e2) throw e2;
    return { ok: true, inserted: rows.length };
  });

/** Editor — replace a global region's blocks JSON wholesale. */
export const saveGlobalRegion = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { region_key: string; locale?: string; blocks: GlobalRegion["blocks"] }) => input)
  .handler(async ({ data, context }) => {
    const row = {
      region_key: data.region_key,
      locale: data.locale ?? "hu",
      blocks: data.blocks,
      status: "published",
      updated_by: context.userId,
    };
    const { data: out, error } = await (context.supabase as any)
      .from("cms_global_regions")
      .upsert(row, { onConflict: "region_key,locale" })
      .select("*")
      .single();
    if (error) throw error;
    return out;
  });
