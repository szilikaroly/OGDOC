/**
 * CMS News content type — categories (parent/child), tags, guest authors and posts.
 * Public read functions use the server publishable client (anon, respecting RLS).
 * Admin functions require CMS access via has_cms_access().
 */
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { createClient } from "@supabase/supabase-js";

function publicClient() {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_PUBLISHABLE_KEY;
  if (!url || !key) throw new Error("Missing Supabase env");
  return createClient(url, key, {
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
  });
}

async function assertCmsAccess(ctx: { supabase: any; userId: string }) {
  const { data, error } = await ctx.supabase.rpc("has_cms_access", { _user_id: ctx.userId });
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Forbidden");
}

// ============== PUBLIC ==============

export const listPublishedNews = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) =>
    z.object({
      category: z.string().optional(),
      tag: z.string().optional(),
      q: z.string().trim().max(120).optional(),
      locale: z.string().default("hu"),
      post_type: z.enum(["blog", "vlog"]).optional(),
      sort: z.enum(["newest", "popular", "oldest"]).default("newest"),
      limit: z.number().int().min(1).max(50).default(12),
      offset: z.number().int().min(0).default(0),
    }).parse(d ?? {})
  )
  .handler(async ({ data }) => {
    const sb = publicClient();
    let q = sb.from("cms_news_posts")
      .select("id,slug,title,excerpt,featured_image_url,featured_image_alt,published_at,view_count,category_id,author_id,post_type,video_provider,video_url,video_embed_url,video_thumbnail_url,video_duration_seconds,video_width,video_height,cms_news_categories(slug,name),cms_news_authors(display_name,avatar_url),cms_news_post_tags(cms_news_tags(slug,name))", { count: "exact" })
      .eq("locale", data.locale)
      .eq("status", "published")
      .lte("published_at", new Date().toISOString());
    if (data.sort === "popular") {
      q = q.order("view_count", { ascending: false, nullsFirst: false }).order("published_at", { ascending: false });
    } else if (data.sort === "oldest") {
      q = q.order("published_at", { ascending: true });
    } else {
      q = q.order("published_at", { ascending: false });
    }
    q = q.range(data.offset, data.offset + data.limit - 1);
    if (data.post_type) q = q.eq("post_type", data.post_type);
    if (data.q) {
      const term = data.q.replace(/[%,()]/g, " ").trim();
      if (term) {
        const like = `%${term}%`;
        q = q.or(`title.ilike.${like},excerpt.ilike.${like},seo_title.ilike.${like},seo_description.ilike.${like}`);
      }
    }
    if (data.category) {
      const { data: cat } = await sb.from("cms_news_categories").select("id").eq("slug", data.category).maybeSingle();
      if (cat?.id) q = q.eq("category_id", cat.id);
    }
    const { data: posts, count, error } = await q;
    if (error) throw new Error(error.message);
    let filtered = posts ?? [];
    if (data.tag) {
      filtered = filtered.filter((p: any) =>
        (p.cms_news_post_tags ?? []).some((pt: any) => pt.cms_news_tags?.slug === data.tag)
      );
    }
    return { posts: filtered, total: count ?? filtered.length };
  });


export const getPublishedNewsBySlug = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) => z.object({
    slug: z.string().min(1),
    locale: z.string().default("hu"),
    expected_type: z.enum(["blog", "vlog"]).optional(),
    previewToken: z.string().uuid().optional(),
  }).parse(d))
  .handler(async ({ data }) => {
    const sb = publicClient();
    let q = sb.from("cms_news_posts")
      .select("*,cms_news_categories(slug,name),cms_news_authors(display_name,avatar_url,bio),cms_news_post_tags(cms_news_tags(slug,name))")
      .eq("slug", data.slug)
      .eq("locale", data.locale);
    if (!data.previewToken) {
      q = q.eq("status", "published").lte("published_at", new Date().toISOString());
    }
    const { data: post, error } = await q.maybeSingle();
    if (error) throw new Error(error.message);
    if (!post) return null;
    if (data.previewToken && (post as any).preview_token !== data.previewToken) return null;
    if (data.expected_type && (post as any).post_type !== data.expected_type) return null;
    // best-effort view count bump csak publikus nézetnél
    if (!data.previewToken) {
      sb.rpc("cms_news_increment_view", { _slug: data.slug }).then(() => {}, () => {});
    }
    return { ...post, preview: !!data.previewToken } as any;
  });



export const listPublicCategories = createServerFn({ method: "GET" })
  .handler(async () => {
    const sb = publicClient();
    const { data, error } = await sb.from("cms_news_categories")
      .select("id,parent_id,slug,name,description,sort_order")
      .eq("is_active", true)
      .order("sort_order");
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const listPublicTags = createServerFn({ method: "GET" })
  .handler(async () => {
    const sb = publicClient();
    const { data, error } = await sb.from("cms_news_tags").select("id,slug,name").order("name");
    if (error) throw new Error(error.message);
    return data ?? [];
  });

// ============== ADMIN: categories ==============

const CategoryInput = z.object({
  id: z.string().uuid().optional(),
  parent_id: z.string().uuid().nullable().optional(),
  slug: z.string().min(1).regex(/^[a-z0-9-]+$/),
  name: z.string().min(1),
  description: z.string().nullable().optional(),
  sort_order: z.number().int().default(0),
  is_active: z.boolean().default(true),
});

export const adminListCategories = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertCmsAccess(context);
    const { data, error } = await context.supabase.from("cms_news_categories").select("*").order("sort_order");
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const adminUpsertCategory = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => CategoryInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    if (data.id) {
      const { error } = await context.supabase.from("cms_news_categories").update(data).eq("id", data.id);
      if (error) throw new Error(error.message);
      return { id: data.id };
    }
    const { data: row, error } = await context.supabase.from("cms_news_categories").insert(data).select("id").single();
    if (error) throw new Error(error.message);
    return { id: row.id };
  });

export const adminDeleteCategory = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const { error } = await context.supabase.from("cms_news_categories").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// ============== ADMIN: tags ==============

export const adminListTags = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertCmsAccess(context);
    const { data, error } = await context.supabase.from("cms_news_tags").select("*").order("name");
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const adminUpsertTag = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({
    id: z.string().uuid().optional(),
    slug: z.string().min(1).regex(/^[a-z0-9-]+$/),
    name: z.string().min(1),
  }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    if (data.id) {
      const { error } = await context.supabase.from("cms_news_tags").update(data).eq("id", data.id);
      if (error) throw new Error(error.message);
      return { id: data.id };
    }
    const { data: row, error } = await context.supabase.from("cms_news_tags").insert(data).select("id").single();
    if (error) throw new Error(error.message);
    return { id: row.id };
  });

export const adminDeleteTag = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const { error } = await context.supabase.from("cms_news_tags").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// ============== ADMIN: authors ==============

const AuthorInput = z.object({
  id: z.string().uuid().optional(),
  user_id: z.string().uuid().nullable().optional(),
  display_name: z.string().min(1),
  bio: z.string().nullable().optional(),
  avatar_url: z.string().nullable().optional(),
  email: z.string().email().nullable().optional(),
  is_guest: z.boolean().default(false),
});

export const adminListAuthors = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertCmsAccess(context);
    const { data, error } = await context.supabase.from("cms_news_authors").select("*").order("display_name");
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const adminUpsertAuthor = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => AuthorInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    if (data.id) {
      const { error } = await context.supabase.from("cms_news_authors").update(data).eq("id", data.id);
      if (error) throw new Error(error.message);
      return { id: data.id };
    }
    const { data: row, error } = await context.supabase.from("cms_news_authors").insert(data).select("id").single();
    if (error) throw new Error(error.message);
    return { id: row.id };
  });

export const adminDeleteAuthor = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const { error } = await context.supabase.from("cms_news_authors").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// ============== ADMIN: posts ==============

const PostInput = z.object({
  id: z.string().uuid().optional(),
  slug: z.string().min(1).regex(/^[a-z0-9-]+$/),
  locale: z.string().default("hu"),
  title: z.string().min(1),
  excerpt: z.string().nullable().optional(),
  body_html: z.string().default(""),
  featured_image_url: z.string().nullable().optional(),
  featured_image_alt: z.string().nullable().optional(),
  author_id: z.string().uuid().nullable().optional(),
  category_id: z.string().uuid().nullable().optional(),
  status: z.enum(["draft", "scheduled", "published", "archived"]).default("draft"),
  published_at: z.string().nullable().optional(),
  seo_title: z.string().nullable().optional(),
  seo_description: z.string().nullable().optional(),
  og_image_url: z.string().nullable().optional(),
  tag_ids: z.array(z.string().uuid()).default([]),
  post_type: z.enum(["blog", "vlog"]).default("blog"),
  video_provider: z.enum(["youtube", "vimeo", "file"]).nullable().optional(),
  video_url: z.string().nullable().optional(),
  video_embed_url: z.string().nullable().optional(),
  video_thumbnail_url: z.string().nullable().optional(),
  video_duration_seconds: z.number().int().nullable().optional(),
  video_width: z.number().int().positive().nullable().optional(),
  video_height: z.number().int().positive().nullable().optional(),
  video_transcript: z.string().nullable().optional(),
}).superRefine((v, ctx) => {
  if (v.post_type === "vlog" && !v.video_url) {
    ctx.addIssue({ code: z.ZodIssueCode.custom, path: ["video_url"], message: "Vlog bejegyzéshez videó URL kötelező." });
  }
});


export const adminListPosts = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertCmsAccess(context);
    const { data, error } = await context.supabase.from("cms_news_posts")
      .select("id,slug,locale,title,status,published_at,category_id,author_id,view_count,updated_at,post_type,preview_token,cms_news_categories(name),cms_news_authors(display_name)")
      .order("updated_at", { ascending: false });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const getNewsPreviewLink = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const { data: row, error } = await context.supabase
      .from("cms_news_posts").select("slug, post_type, preview_token").eq("id", data.id).single();
    if (error) throw new Error(error.message);
    return { slug: row.slug, post_type: row.post_type, token: row.preview_token };
  });


export const adminGetPost = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const { data: post, error } = await context.supabase.from("cms_news_posts")
      .select("*,cms_news_post_tags(tag_id)").eq("id", data.id).single();
    if (error) throw new Error(error.message);
    return post;
  });

export const adminUpsertPost = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => PostInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const { tag_ids, body_html, published_at, ...rest } = data;
    // auto-derive status from schedule
    const now = Date.now();
    let status = rest.status;
    let publishedAt = published_at ? new Date(published_at).toISOString() : null;
    if (status === "published" && !publishedAt) publishedAt = new Date().toISOString();
    if (status === "published" && publishedAt && new Date(publishedAt).getTime() > now) status = "scheduled";
    if (status === "scheduled" && publishedAt && new Date(publishedAt).getTime() <= now) status = "published";

    // Unified video normalization — poster / width / height / duration are
    // filled in with sensible defaults for every provider (YouTube, Vimeo, file).
    let videoEmbed = rest.video_embed_url ?? null;
    let videoThumb = rest.video_thumbnail_url ?? null;
    let videoWidth = rest.video_width ?? null;
    let videoHeight = rest.video_height ?? null;
    if (rest.post_type === "vlog" && rest.video_url) {
      const { normalizeVideoMeta } = await import("./video");
      const meta = normalizeVideoMeta({
        video_provider: rest.video_provider ?? null,
        video_url: rest.video_url,
        video_embed_url: videoEmbed,
        video_thumbnail_url: videoThumb,
        video_width: videoWidth,
        video_height: videoHeight,
        fallback_poster: rest.featured_image_url ?? null,
      });
      videoEmbed = meta.embedUrl;
      videoThumb = meta.poster;
      videoWidth = meta.width;
      videoHeight = meta.height;
    }

    const payload: any = {
      ...rest,
      status,
      published_at: publishedAt,
      video_embed_url: videoEmbed,
      video_thumbnail_url: videoThumb,
      video_width: videoWidth,
      video_height: videoHeight,
      body: { html: body_html ?? "" },
      updated_by: context.userId,
    };
    // clear video fields entirely for blog posts
    if (payload.post_type === "blog") {
      payload.video_provider = null;
      payload.video_url = null;
      payload.video_embed_url = null;
      payload.video_thumbnail_url = null;
      payload.video_duration_seconds = null;
      payload.video_width = null;
      payload.video_height = null;
      payload.video_transcript = null;
    }

    let postId = data.id;
    if (postId) {
      const { error } = await context.supabase.from("cms_news_posts").update(payload).eq("id", postId);
      if (error) throw new Error(error.message);
    } else {
      payload.created_by = context.userId;
      const { data: row, error } = await context.supabase.from("cms_news_posts").insert(payload).select("id").single();
      if (error) throw new Error(error.message);
      postId = row.id;
    }
    // sync tags
    await context.supabase.from("cms_news_post_tags").delete().eq("post_id", postId);
    if (tag_ids.length) {
      const { error: tErr } = await context.supabase.from("cms_news_post_tags").insert(
        tag_ids.map((tag_id) => ({ post_id: postId, tag_id }))
      );
      if (tErr) throw new Error(tErr.message);
    }

    // Auto-create/update the block-based CMS page for this post so it can be
    // edited in the visual editor at /admin/cms.
    try {
      await ensureCmsPageForPost(context.supabase, postId!, {
        slug: rest.slug,
        locale: rest.locale ?? "hu",
        title: rest.title,
        excerpt: rest.excerpt ?? null,
        featured_image_url: rest.featured_image_url ?? null,
        featured_image_alt: rest.featured_image_alt ?? null,
        seo_title: rest.seo_title ?? null,
        seo_description: rest.seo_description ?? null,
        og_image_url: rest.og_image_url ?? null,
        status,
        published_at: publishedAt,
        body_html: body_html ?? "",
      });
    } catch (e) {
      // Non-fatal — post save should still succeed even if the CMS page could not be provisioned.
      console.warn("[news] ensureCmsPageForPost failed:", (e as Error)?.message);
    }
    return { id: postId };
  });

/**
 * Ensures a `cms_pages` row (slug `hirek/<post-slug>`) exists for the given
 * news post. Creates default blocks (hero, richtext, share, related) the first
 * time; on subsequent saves only updates the page metadata and never
 * overwrites the editor's block layout.
 */
async function ensureCmsPageForPost(
  sb: any,
  postId: string,
  p: {
    slug: string; locale: string; title: string; excerpt: string | null;
    featured_image_url: string | null; featured_image_alt: string | null;
    seo_title: string | null; seo_description: string | null; og_image_url: string | null;
    status: string; published_at: string | null; body_html: string;
  },
) {
  const cmsSlug = `hirek/${p.slug}`;
  const { data: existingPost } = await sb.from("cms_news_posts").select("cms_page_id").eq("id", postId).maybeSingle();
  let pageId: string | null = existingPost?.cms_page_id ?? null;

  const pageMeta = {
    slug: cmsSlug,
    locale: p.locale,
    title: p.title,
    description: p.excerpt,
    status: ["draft", "published", "scheduled", "archived"].includes(p.status) ? p.status : "draft",
    seo_title: p.seo_title,
    seo_description: p.seo_description,
    og_image_url: p.og_image_url ?? p.featured_image_url,
    template: "default",
    published_at: p.published_at,
    schema_type: "article",
  };

  if (pageId) {
    await sb.from("cms_pages").update(pageMeta).eq("id", pageId);
  } else {
    // Match by (slug, locale) unique constraint if the row already exists.
    const { data: existingPage } = await sb.from("cms_pages")
      .select("id").eq("slug", cmsSlug).eq("locale", p.locale).maybeSingle();
    if (existingPage?.id) {
      pageId = existingPage.id;
      await sb.from("cms_pages").update(pageMeta).eq("id", pageId);
    } else {
      const { data: created, error: cErr } = await sb.from("cms_pages").insert(pageMeta).select("id").single();
      if (cErr) throw new Error(cErr.message);
      pageId = created.id;
      // Seed default blocks
      await sb.from("cms_blocks").insert([
        { page_id: pageId, block_type: "dyn_news_hero", position: 0, locale: p.locale, is_published: true,
          content: { title: p.title, excerpt: p.excerpt, cover: p.featured_image_url, cover_alt: p.featured_image_alt, post_slug: p.slug } },
        { page_id: pageId, block_type: "richtext", position: 1, locale: p.locale, is_published: true,
          content: { html: p.body_html } },
        { page_id: pageId, block_type: "dyn_share_bar", position: 2, locale: p.locale, is_published: true,
          content: { title: p.title } },
        { page_id: pageId, block_type: "dyn_news_related", position: 3, locale: p.locale, is_published: true,
          content: { title: "Kapcsolódó cikkek", post_slug: p.slug, limit: 3 } },
      ]);
    }
    await sb.from("cms_news_posts").update({ cms_page_id: pageId }).eq("id", postId);
  }
  return pageId;
}


/**
 * Admin helper — fetches oEmbed metadata for a YouTube/Vimeo URL and
 * returns the unified {provider, embed_url, thumbnail, width, height, duration}
 * shape the editor pre-fills the video fields with. Auth-gated to CMS editors
 * to avoid turning this into a public URL prober.
 */
export const adminFetchVideoMeta = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ url: z.string().min(4) }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const { detectProvider, buildEmbedUrl, buildVideoThumbnail, fetchVideoOEmbed, DEFAULT_EMBED_WIDTH, DEFAULT_EMBED_HEIGHT } = await import("./video");
    const provider = detectProvider(data.url);
    if (!provider) return { ok: false as const, error: "Ismeretlen szolgáltató" };
    if (provider === "file") {
      return {
        ok: true as const,
        provider,
        embed_url: data.url,
        thumbnail_url: null,
        width: null,
        height: null,
        duration_seconds: null,
      };
    }
    const oembed = await fetchVideoOEmbed(data.url).catch(() => null);
    return {
      ok: true as const,
      provider,
      embed_url: buildEmbedUrl(data.url, provider),
      thumbnail_url: oembed?.thumbnail_url ?? buildVideoThumbnail(data.url, provider),
      width: oembed?.width ?? DEFAULT_EMBED_WIDTH,
      height: oembed?.height ?? DEFAULT_EMBED_HEIGHT,
      duration_seconds: oembed?.duration ?? null,
    };
  });


export const adminDeletePost = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const { error } = await context.supabase.from("cms_news_posts").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// ============== Public Q&A — AI chatbot on a news article ==============

export const askNewsQuestion = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => z.object({
    slug: z.string().min(1),
    question: z.string().min(2).max(500),
    history: z.array(z.object({ role: z.enum(["user", "assistant"]), content: z.string() })).max(20).default([]),
  }).parse(d))
  .handler(async ({ data }) => {
    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) throw new Error("AI nincs beállítva");
    const sb = publicClient();
    const { data: post } = await sb.from("cms_news_posts")
      .select("title,excerpt,body,cms_news_categories(name)")
      .eq("slug", data.slug).eq("status", "published").lte("published_at", new Date().toISOString())
      .maybeSingle();
    if (!post) throw new Error("Hír nem található");
    const bodyText = (() => {
      try {
        const html = (post.body as any)?.html ?? "";
        return String(html).replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim().slice(0, 6000);
      } catch { return ""; }
    })();
    const system = `Magyar nyelvű asszisztens vagy egy klinikai hírportálon. A felhasználó kérdéseit kizárólag az alábbi cikk tartalma alapján válaszold meg, tömören, közérthetően. Ha a kérdés nem kapcsolódik vagy nincs benne info, mondd ezt el, és ajánld a /o/kapcsolat oldalt vagy a hivatalos elérhetőséget. Soha ne adj egyéni orvosi tanácsot — utalj a kezelőorvosra.\n\nCIKK CÍME: ${post.title}\nKIVONAT: ${post.excerpt ?? ""}\nTARTALOM: ${bodyText}`;
    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [{ role: "system", content: system }, ...data.history, { role: "user", content: data.question }],
      }),
    });
    if (!res.ok) {
      const text = await res.text();
      throw new Error(`AI hiba: ${res.status} ${text.slice(0, 200)}`);
    }
    const json: any = await res.json();
    const reply = json.choices?.[0]?.message?.content ?? "Sajnos most nem tudok válaszolni.";
    return { reply };
  });
