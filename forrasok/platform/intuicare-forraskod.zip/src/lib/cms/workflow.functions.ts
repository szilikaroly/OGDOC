/**
 * CMS workflow + audit log szerver fn-ek.
 * Minden művelet a `cms_audit_log`-ba is bejegyzést készít (security definer fn-en át).
 */
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

// Engedélyezett entitás-típusok (whitelist) – SQL injection elleni védelem.
export const WORKFLOW_ENTITIES = [
  "cms_pages",
  "cms_news_posts",
  "cms_blocks",
  "cms_layout_blocks",
  "cms_menus",
  "cms_menu_items",
  "cms_redirects",
  "cms_staff_profiles",
  "cms_faqs",
  "cms_design_tokens",
  "cms_site_settings",
  "cms_global_regions",
  "cms_media",
] as const;

export type WorkflowEntity = (typeof WORKFLOW_ENTITIES)[number];

const EntityEnum = z.enum(WORKFLOW_ENTITIES);

async function assertCmsAccess(ctx: { supabase: any; userId: string }) {
  const { data, error } = await ctx.supabase.rpc("has_cms_access", { _user_id: ctx.userId });
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Forbidden");
}

async function assertCmsRole(
  ctx: { supabase: any; userId: string },
  role: "editor" | "reviewer" | "publisher",
) {
  const fnName = role === "editor"
    ? "has_cms_editor"
    : role === "reviewer"
    ? "has_cms_reviewer"
    : "has_cms_publisher";
  const { data, error } = await ctx.supabase.rpc(fnName, { _user_id: ctx.userId });
  if (error) throw new Error(error.message);
  if (!data) throw new Error(`Forbidden: ${role} szerepkör szükséges`);
}

/** Az entitás aktuális sorát olvassa, JSON snapshotként visszaadva. */
async function loadEntity(sb: any, entityType: WorkflowEntity, id: string) {
  const { data, error } = await sb.from(entityType).select("*").eq("id", id).maybeSingle();
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Az entitás nem található");
  return data as Record<string, any>;
}

async function writeAudit(
  sb: any,
  args: {
    entity_type: WorkflowEntity;
    entity_id: string;
    action:
      | "create" | "update" | "delete"
      | "submit_review" | "approve" | "reject"
      | "publish" | "unpublish" | "revert" | "restore";
    before?: any;
    after?: any;
    comment?: string | null;
  },
) {
  const before = args.before ?? null;
  const after = args.after ?? null;
  const { error } = await sb.rpc("cms_audit_write", {
    _entity_type: args.entity_type,
    _entity_id: args.entity_id,
    _action: args.action,
    _before: before,
    _after: after,
    _comment: args.comment ?? null,
    _entity_slug: (after?.slug ?? before?.slug) ?? null,
    _entity_locale: (after?.locale ?? before?.locale) ?? null,
    _request_meta: {},
  });
  if (error) throw new Error(error.message);
}

// ============== SUBMIT FOR REVIEW ==============

export const submitForReview = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({
      entity_type: EntityEnum,
      entity_id: z.string().uuid(),
      comment: z.string().max(500).optional(),
    }).parse(d),
  )
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    await assertCmsRole(context, "editor");
    const before = await loadEntity(context.supabase, data.entity_type, data.entity_id);
    if (!["draft", "rejected"].includes(before.workflow_state)) {
      throw new Error(`Csak vázlat vagy elutasított állapotból küldhető véleményezésre (jelenleg: ${before.workflow_state}).`);
    }
    const patch = {
      workflow_state: "in_review",
      submitted_for_review_at: new Date().toISOString(),
      submitted_by: context.userId,
      rejected_at: null, rejected_by: null, rejection_reason: null,
    };
    const { error } = await (context.supabase as any).from(data.entity_type).update(patch).eq("id", data.entity_id);
    if (error) throw new Error(error.message);
    const after = { ...before, ...patch };
    await writeAudit(context.supabase, {
      entity_type: data.entity_type, entity_id: data.entity_id,
      action: "submit_review", before, after, comment: data.comment ?? null,
    });
    return { ok: true };
  });

// ============== APPROVE ==============

export const approveContent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({
      entity_type: EntityEnum,
      entity_id: z.string().uuid(),
      comment: z.string().max(500).optional(),
    }).parse(d),
  )
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    await assertCmsRole(context, "reviewer");
    const before = await loadEntity(context.supabase, data.entity_type, data.entity_id);
    if (before.workflow_state !== "in_review") {
      throw new Error(`Csak véleményezés alatt levő tartalom hagyható jóvá (jelenleg: ${before.workflow_state}).`);
    }
    const patch = {
      workflow_state: "approved",
      approved_at: new Date().toISOString(),
      approved_by: context.userId,
    };
    const { error } = await (context.supabase as any).from(data.entity_type).update(patch).eq("id", data.entity_id);
    if (error) throw new Error(error.message);
    const after = { ...before, ...patch };
    await writeAudit(context.supabase, {
      entity_type: data.entity_type, entity_id: data.entity_id,
      action: "approve", before, after, comment: data.comment ?? null,
    });
    return { ok: true };
  });

// ============== REJECT ==============

export const rejectContent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({
      entity_type: EntityEnum,
      entity_id: z.string().uuid(),
      reason: z.string().min(2).max(1000),
    }).parse(d),
  )
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    await assertCmsRole(context, "reviewer");
    const before = await loadEntity(context.supabase, data.entity_type, data.entity_id);
    if (!["in_review", "approved"].includes(before.workflow_state)) {
      throw new Error(`Csak véleményezés vagy jóváhagyott állapotból utasítható el (jelenleg: ${before.workflow_state}).`);
    }
    const patch = {
      workflow_state: "rejected",
      rejected_at: new Date().toISOString(),
      rejected_by: context.userId,
      rejection_reason: data.reason,
    };
    const { error } = await (context.supabase as any).from(data.entity_type).update(patch).eq("id", data.entity_id);
    if (error) throw new Error(error.message);
    const after = { ...before, ...patch };
    await writeAudit(context.supabase, {
      entity_type: data.entity_type, entity_id: data.entity_id,
      action: "reject", before, after, comment: data.reason,
    });
    return { ok: true };
  });

// ============== PUBLISH ==============

export const publishContent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({
      entity_type: EntityEnum,
      entity_id: z.string().uuid(),
      comment: z.string().max(500).optional(),
    }).parse(d),
  )
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    await assertCmsRole(context, "publisher");
    const before = await loadEntity(context.supabase, data.entity_type, data.entity_id);
    if (!["approved", "in_review", "draft"].includes(before.workflow_state)) {
      throw new Error(`Ebből az állapotból nem publikálható (${before.workflow_state}).`);
    }
    const patch: Record<string, any> = {
      workflow_state: "published",
      approved_at: before.approved_at ?? new Date().toISOString(),
      approved_by: before.approved_by ?? context.userId,
    };
    // szinkronizáljuk a publikációs mezőt is, ha létezik
    if ("status" in before) patch.status = "published";
    if ("is_published" in before) patch.is_published = true;
    if ("is_active" in before) patch.is_active = true;
    if ("published_at" in before && !before.published_at) patch.published_at = new Date().toISOString();

    const { error } = await (context.supabase as any).from(data.entity_type).update(patch).eq("id", data.entity_id);
    if (error) throw new Error(error.message);
    const after = { ...before, ...patch };
    await writeAudit(context.supabase, {
      entity_type: data.entity_type, entity_id: data.entity_id,
      action: "publish", before, after, comment: data.comment ?? null,
    });
    return { ok: true };
  });

// ============== UNPUBLISH ==============

export const unpublishContent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({
      entity_type: EntityEnum,
      entity_id: z.string().uuid(),
      comment: z.string().max(500).optional(),
    }).parse(d),
  )
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    await assertCmsRole(context, "publisher");
    const before = await loadEntity(context.supabase, data.entity_type, data.entity_id);
    if (before.workflow_state !== "published") {
      throw new Error(`Csak publikált tartalom vonható vissza (jelenleg: ${before.workflow_state}).`);
    }
    const patch: Record<string, any> = { workflow_state: "draft" };
    if ("status" in before) patch.status = "draft";
    if ("is_published" in before) patch.is_published = false;
    const { error } = await (context.supabase as any).from(data.entity_type).update(patch).eq("id", data.entity_id);
    if (error) throw new Error(error.message);
    const after = { ...before, ...patch };
    await writeAudit(context.supabase, {
      entity_type: data.entity_type, entity_id: data.entity_id,
      action: "unpublish", before, after, comment: data.comment ?? null,
    });
    return { ok: true };
  });

// ============== REVERT ==============

export const revertToVersion = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({
      entity_type: EntityEnum,
      entity_id: z.string().uuid(),
      audit_log_id: z.string().uuid(),
      mode: z.enum(["full", "diff"]).default("full"),
      comment: z.string().max(500).optional(),
    }).parse(d),
  )
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    await assertCmsRole(context, "reviewer");
    const { data: log, error: logErr } = await (context.supabase as any)
      .from("cms_audit_log").select("*")
      .eq("id", data.audit_log_id).maybeSingle();
    if (logErr) throw new Error(logErr.message);
    if (!log) throw new Error("Audit log bejegyzés nem található");
    if (log.entity_type !== data.entity_type || log.entity_id !== data.entity_id) {
      throw new Error("Az audit log nem ehhez az entitáshoz tartozik");
    }
    const snapshot = (log.before ?? null) as Record<string, any> | null;
    if (!snapshot) throw new Error("Ennek a bejegyzésnek nincs visszaállítható snapshot-ja");

    const before = await loadEntity(context.supabase, data.entity_type, data.entity_id);

    // Mit állítunk vissza?
    let patch: Record<string, any>;
    if (data.mode === "full") {
      // teljes felülírás – kizárva pár metaadat (id, timestampek, workflow mezők)
      const FORBIDDEN = new Set([
        "id", "created_at", "updated_at",
        "workflow_state", "submitted_for_review_at", "submitted_by",
        "approved_at", "approved_by", "rejected_at", "rejected_by", "rejection_reason",
      ]);
      patch = {};
      for (const [k, v] of Object.entries(snapshot)) {
        if (!FORBIDDEN.has(k)) patch[k] = v;
      }
    } else {
      // diff mód: csak a snapshot ÉS a log.diff-ben szereplő kulcsok
      const keys = Object.keys((log.diff ?? {}) as object);
      patch = {};
      for (const k of keys) {
        if (k in snapshot) patch[k] = (snapshot as any)[k];
      }
    }
    // revert után vissza vázlatba kerül
    patch.workflow_state = "draft";

    const { error } = await (context.supabase as any).from(data.entity_type).update(patch).eq("id", data.entity_id);
    if (error) throw new Error(error.message);
    const after = { ...before, ...patch };
    await writeAudit(context.supabase, {
      entity_type: data.entity_type, entity_id: data.entity_id,
      action: "revert", before, after,
      comment: data.comment ?? `Visszaállítva (${data.mode}) az audit bejegyzés ${data.audit_log_id} alapján`,
    });
    return { ok: true };
  });

// ============== AUDIT TRAIL ==============

export const listAuditTrail = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({
      entity_type: EntityEnum.optional(),
      entity_id: z.string().uuid().optional(),
      actor_id: z.string().uuid().optional(),
      actor_email: z.string().trim().min(1).optional(),
      action: z.string().optional(),
      from: z.string().datetime().optional(),
      to: z.string().datetime().optional(),
      limit: z.number().int().min(1).max(200).default(50),
      offset: z.number().int().min(0).default(0),
    }).parse(d ?? {}),
  )
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    let q = (context.supabase as any)
      .from("cms_audit_log")
      .select("*", { count: "exact" })
      .order("created_at", { ascending: false })
      .range(data.offset, data.offset + data.limit - 1);
    if (data.entity_type) q = q.eq("entity_type", data.entity_type);
    if (data.entity_id) q = q.eq("entity_id", data.entity_id);
    if (data.actor_id) q = q.eq("actor_id", data.actor_id);
    if (data.actor_email) q = q.ilike("actor_email", `%${data.actor_email}%`);
    if (data.action) q = q.eq("action", data.action as any);
    if (data.from) q = q.gte("created_at", data.from);
    if (data.to) q = q.lte("created_at", data.to);
    const { data: rows, count, error } = await q;
    if (error) throw new Error(error.message);
    return { rows: rows ?? [], total: count ?? 0 };
  });

// ============== PENDING REVIEW QUEUE ==============

export const listPendingReview = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertCmsAccess(context);
    const results: Array<{ entity_type: WorkflowEntity; items: any[] }> = [];
    for (const t of WORKFLOW_ENTITIES) {
      const { data, error } = await (context.supabase as any)
        .from(t)
        .select("id,workflow_state,submitted_for_review_at,submitted_by,updated_at")
        .eq("workflow_state", "in_review")
        .order("submitted_for_review_at", { ascending: true })
        .limit(50);
      if (error) continue; // egy tábla hiba ne döntse el az egészet
      if ((data ?? []).length > 0) {
        // próbáljunk title/slug-ot is hozni egy második körrel
        const ids = data!.map((d: any) => d.id);
        const { data: titles } = await (context.supabase as any)
          .from(t).select("id,title,slug,name,kulcs,source_path").in("id", ids);
        const tmap = new Map((titles ?? []).map((r: any) => [r.id, r]));
        results.push({
          entity_type: t,
          items: data!.map((d: any) => ({ ...d, meta: tmap.get(d.id) ?? null })),
        });
      }
    }
    return { groups: results };
  });
