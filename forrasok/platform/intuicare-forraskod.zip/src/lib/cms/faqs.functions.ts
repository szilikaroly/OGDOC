/**
 * CMS FAQ – admin CRUD.
 */
import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

async function assertCms(ctx: { supabase: any; userId: string }) {
  const { data, error } = await ctx.supabase.rpc("has_cms_access", { _user_id: ctx.userId });
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Nincs CMS jogosultságod.");
}

const FaqInput = z.object({
  id: z.string().uuid().optional(),
  locale: z.string().default("hu"),
  question: z.string().min(1).max(500),
  answer: z.string().min(1).max(5000),
  tags: z.array(z.string()).default([]),
  sort_order: z.number().int().default(0),
  is_published: z.boolean().default(true),
});

export const listFaqs = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertCms(context);
    const { data, error } = await context.supabase
      .from("cms_faqs")
      .select("*")
      .order("locale")
      .order("sort_order")
      .order("question");
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const saveFaq = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => FaqInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertCms(context);
    const { data: row, error } = await context.supabase
      .from("cms_faqs")
      .upsert(data as any, { onConflict: "id" })
      .select()
      .single();
    if (error) throw new Error(error.message);
    return row;
  });

export const deleteFaq = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCms(context);
    const { error } = await context.supabase.from("cms_faqs").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
