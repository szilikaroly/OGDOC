/**
 * Hírlevél + tanácsok feliratkozás.
 */
import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

function pub() {
  return createClient(
    process.env.SUPABASE_URL!,
    process.env.SUPABASE_PUBLISHABLE_KEY!,
    { auth: { storage: undefined, persistSession: false, autoRefreshToken: false } },
  );
}

/* ------- anon e-mail feliratkozás ------- */
export const subscribeNewsletter = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) =>
    z.object({
      email: z.string().email().max(200),
      source: z.string().max(80).optional(),
    }).parse(d),
  )
  .handler(async ({ data }) => {
    const sb = pub();
    const { error } = await sb
      .from("cms_newsletter_subscribers")
      .upsert({ email: data.email.toLowerCase(), source: data.source ?? null }, { onConflict: "email" });
    if (error && !String(error.message).includes("duplicate")) throw new Error(error.message);
    return { ok: true };
  });

/* ------- bejelentkezett: tanács feliratkozás ------- */
export const getMyTipSubscription = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data } = await (context.supabase as any)
      .from("cms_tip_subscribers")
      .select("*")
      .eq("user_id", context.userId)
      .maybeSingle();
    return data ?? { user_id: context.userId, email_enabled: true, push_enabled: false, audiences: [] };
  });

export const updateMyTipSubscription = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({
      email_enabled: z.boolean(),
      push_enabled: z.boolean(),
      audiences: z.array(z.string()).default([]),
    }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { error } = await (context.supabase as any)
      .from("cms_tip_subscribers")
      .upsert({
        user_id: context.userId,
        email_enabled: data.email_enabled,
        push_enabled: data.push_enabled,
        audiences: data.audiences,
      }, { onConflict: "user_id" });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/* ------- admin hírlevél műveletek ------- */
async function assertAdmin(context: any) {
  const { data: ok } = await context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" });
  if (!ok) throw new Error("Forbidden");
}

export const listNewsletters = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    const { data } = await (context.supabase as any)
      .from("cms_newsletters")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(50);
    return data ?? [];
  });

export const saveNewsletter = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({
      id: z.string().uuid().optional(),
      subject: z.string().min(2).max(200),
      body_html: z.string().min(2),
      audience: z.enum(["all", "tips", "news", "newsletter"]).default("all"),
    }).parse(d),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const row = { ...data, created_by: context.userId };
    const { data: out, error } = await (context.supabase as any)
      .from("cms_newsletters")
      .upsert(row)
      .select("*")
      .single();
    if (error) throw new Error(error.message);
    return out;
  });

export const sendNewsletter = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const sb = context.supabase as any;
    const { data: nl } = await sb.from("cms_newsletters").select("*").eq("id", data.id).maybeSingle();
    if (!nl) throw new Error("Nem található");
    if (nl.status === "sent") throw new Error("Már elküldve");

    await sb.from("cms_newsletters").update({ status: "sending" }).eq("id", data.id);

    // Címzettek
    const { data: subs } = await sb
      .from("cms_newsletter_subscribers")
      .select("email")
      .is("unsubscribed_at", null);
    const emails: string[] = (subs ?? []).map((s: any) => s.email);

    // Email-ek queue-ba; ha nincs email infra, csak loggolunk és átállítjuk sent-re.
    let sent = 0;
    try {
      for (const to of emails) {
        const { error } = await sb.rpc("enqueue_email", {
          _queue: "transactional_emails",
          _payload: {
            template: "newsletter-generic",
            to,
            subject: nl.subject,
            data: { body_html: nl.body_html },
            idempotency_key: `newsletter-${data.id}-${to}`,
          },
        });
        if (!error) sent += 1;
      }
    } catch {
      /* enqueue_email may not exist if email infra not set up yet */
    }

    await sb
      .from("cms_newsletters")
      .update({ status: "sent", sent_at: new Date().toISOString(), sent_count: sent })
      .eq("id", data.id);

    return { ok: true, sent };
  });

export const deleteNewsletter = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    await (context.supabase as any).from("cms_newsletters").delete().eq("id", data.id);
    return { ok: true };
  });
