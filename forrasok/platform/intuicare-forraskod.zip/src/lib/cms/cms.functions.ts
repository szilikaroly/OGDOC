/**
 * CMS server-side functions: pages, blocks, menus, media, redirects, i18n.
 */
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { createClient } from "@supabase/supabase-js";

async function assertCmsAccess(ctx: { supabase: any; userId: string }) {
  const { data, error } = await ctx.supabase.rpc("has_cms_access", { _user_id: ctx.userId });
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Forbidden");
}

function publicClient() {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_PUBLISHABLE_KEY;
  if (!url || !key) throw new Error("Missing Supabase env");
  return createClient(url, key, {
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
  });
}

// ---------------- PAGES ----------------
const PageInput = z.object({
  id: z.string().uuid().optional(),
  slug: z.string().regex(/^([a-z0-9-]+(\/[a-z0-9-]+)*)?$/),
  locale: z.string().default("hu"),
  parent_id: z.string().uuid().nullable().optional(),
  title: z.string().min(1),
  description: z.string().nullable().optional(),
  status: z.enum(["draft", "published", "scheduled", "archived"]).default("draft"),
  sort_order: z.number().int().default(0),
  seo_title: z.string().nullable().optional(),
  seo_description: z.string().nullable().optional(),
  og_image_url: z.string().nullable().optional(),
  show_in_sitemap: z.boolean().default(true),
  template: z.string().default("default"),
  noindex: z.boolean().default(false),
  scheduled_publish_at: z.string().datetime().nullable().optional(),
  schema_type: z.enum([
    "auto",
    "webpage",
    "article",
    "faqpage",
    "contactpage",
    "aboutpage",
    "service",
    "organization",
    "localbusiness",
    "collectionpage",
  ]).default("auto"),
});

export const listPages = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertCmsAccess(context);
    const { data, error } = await context.supabase
      .from("cms_pages")
      .select("*")
      .order("locale")
      .order("sort_order")
      .order("title");
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const getPageWithBlocks = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const { data: page, error } = await context.supabase
      .from("cms_pages").select("*").eq("id", data.id).single();
    if (error) throw new Error(error.message);
    const { data: blocks } = await context.supabase
      .from("cms_blocks").select("*").eq("page_id", data.id).order("position");
    return { page, blocks: blocks ?? [] };
  });

export const savePage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => PageInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const payload: any = {
      ...data,
      updated_by: context.userId,
      published_at: data.status === "published" ? new Date().toISOString() : null,
    };
    if (data.id) {
      // Detect slug change to auto-create a 301 redirect from the old URL.
      const { data: prev } = await context.supabase
        .from("cms_pages").select("slug,locale").eq("id", data.id).single();
      const { error } = await context.supabase.from("cms_pages").update(payload).eq("id", data.id);
      if (error) throw new Error(error.message);
      if (prev && prev.slug && prev.slug !== data.slug) {
        const oldPath = `/o/${prev.slug}`;
        const newPath = `/o/${data.slug}`;
        // 1) Upsert 301 old → new (idempotent on source_path).
        await context.supabase.from("cms_redirects").upsert({
          source_path: oldPath,
          target_path: newPath,
          status_code: 301,
          is_active: true,
          note: `Auto: slug változás (${prev.slug} → ${data.slug})`,
        }, { onConflict: "source_path" });
        // 2) Retarget any existing redirects that pointed at the old URL,
        //    so redirect chains stay one hop.
        await context.supabase.from("cms_redirects")
          .update({ target_path: newPath })
          .eq("target_path", oldPath);
        // 3) If a stale reverse redirect exists (new → old), drop it.
        await context.supabase.from("cms_redirects")
          .delete().eq("source_path", newPath).eq("target_path", oldPath);
      }
      return { id: data.id, slugChanged: !!(prev && prev.slug && prev.slug !== data.slug) };
    }
    const { data: row, error } = await context.supabase
      .from("cms_pages").insert({ ...payload, created_by: context.userId }).select("id").single();
    if (error) throw new Error(error.message);
    return { id: row.id, slugChanged: false };
  });


export const deletePage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const { error } = await context.supabase.from("cms_pages").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const publishPageSnapshot = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ pageId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const { data: page } = await context.supabase.from("cms_pages").select("*").eq("id", data.pageId).single();
    const { data: blocks } = await context.supabase.from("cms_blocks").select("*").eq("page_id", data.pageId).order("position");
    const { data: maxRow } = await context.supabase
      .from("cms_page_versions").select("version").eq("page_id", data.pageId).order("version", { ascending: false }).limit(1).single();
    const nextVersion = (maxRow?.version ?? 0) + 1;
    await context.supabase.from("cms_page_versions").insert({
      page_id: data.pageId,
      version: nextVersion,
      snapshot: { page, blocks },
      is_published: true,
      created_by: context.userId,
    });
    await context.supabase.from("cms_pages").update({ status: "published", published_at: new Date().toISOString() }).eq("id", data.pageId);
    return { version: nextVersion };
  });

/** Save a draft snapshot (does NOT publish). Used by the visual editor's version history. */
export const snapshotPageVersion = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ pageId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const { data: page } = await context.supabase.from("cms_pages").select("*").eq("id", data.pageId).single();
    const { data: blocks } = await context.supabase.from("cms_blocks").select("*").eq("page_id", data.pageId).order("position");
    const { data: maxRow } = await context.supabase
      .from("cms_page_versions").select("version").eq("page_id", data.pageId).order("version", { ascending: false }).limit(1).maybeSingle();
    const nextVersion = (maxRow?.version ?? 0) + 1;
    const { error } = await context.supabase.from("cms_page_versions").insert({
      page_id: data.pageId,
      version: nextVersion,
      snapshot: { page, blocks },
      is_published: false,
      created_by: context.userId,
    });
    if (error) throw new Error(error.message);
    return { version: nextVersion };
  });

export const listPageVersions = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ pageId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const { data: rows, error } = await context.supabase
      .from("cms_page_versions")
      .select("id,version,is_published,created_at,created_by")
      .eq("page_id", data.pageId)
      .order("version", { ascending: false })
      .limit(50);
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

/** Restore an older snapshot: rewrite cms_pages + cms_blocks from the chosen version. */
export const rollbackPageVersion = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ pageId: z.string().uuid(), versionId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const { data: ver, error } = await context.supabase
      .from("cms_page_versions").select("snapshot,version").eq("id", data.versionId).single();
    if (error || !ver) throw new Error(error?.message ?? "Version not found");
    const snap = (ver.snapshot ?? {}) as { page?: any; blocks?: any[] };
    if (snap.page) {
      const { id: _ignore, created_at, updated_at, ...rest } = snap.page;
      await context.supabase.from("cms_pages").update(rest).eq("id", data.pageId);
    }
    if (Array.isArray(snap.blocks)) {
      await context.supabase.from("cms_blocks").delete().eq("page_id", data.pageId);
      if (snap.blocks.length) {
        const cleaned = snap.blocks.map(({ id: _i, created_at: _c, updated_at: _u, ...b }: any) => ({
          ...b, page_id: data.pageId,
        }));
        await context.supabase.from("cms_blocks").insert(cleaned);
      }
    }
    // Stamp a new snapshot to mark the restore in history.
    const { data: maxRow } = await context.supabase
      .from("cms_page_versions").select("version").eq("page_id", data.pageId).order("version", { ascending: false }).limit(1).single();
    const nextVersion = (maxRow?.version ?? 0) + 1;
    await context.supabase.from("cms_page_versions").insert({
      page_id: data.pageId,
      version: nextVersion,
      snapshot: snap,
      is_published: false,
      created_by: context.userId,
    });
    return { ok: true, restoredFromVersion: ver.version, newVersion: nextVersion };
  });

const BlockInput = z.object({
  id: z.string().uuid().optional(),
  page_id: z.string().uuid(),
  block_type: z.string(),
  position: z.number().int().default(0),
  locale: z.string().default("hu"),
  content: z.record(z.string(), z.unknown()).default({}),
  variant: z.string().default("default"),
  is_published: z.boolean().default(true),
});

export const saveBlock = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => BlockInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const payload = data as any;
    if (data.id) {
      const { error } = await context.supabase.from("cms_blocks").update(payload).eq("id", data.id);
      if (error) throw new Error(error.message);
      return { id: data.id };
    }
    const { data: row, error } = await context.supabase.from("cms_blocks").insert(payload).select("id").single();
    if (error) throw new Error(error.message);
    return { id: row.id };
  });

export const deleteBlock = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const { error } = await context.supabase.from("cms_blocks").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const reorderBlocks = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ orders: z.array(z.object({ id: z.string().uuid(), position: z.number().int() })) }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    for (const o of data.orders) {
      await context.supabase.from("cms_blocks").update({ position: o.position }).eq("id", o.id);
    }
    return { ok: true };
  });

export const reorderPages = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({
    updates: z.array(z.object({
      id: z.string().uuid(),
      parent_id: z.string().uuid().nullable(),
      sort_order: z.number().int(),
    })),
  }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    for (const u of data.updates) {
      if (u.parent_id === u.id) throw new Error("Egy oldal nem lehet a saját szülője.");
      if (u.parent_id) {
        let cur: string | null = u.parent_id;
        for (let i = 0; i < 8 && cur; i++) {
          if (cur === u.id) throw new Error("Körkörös hierarchia.");
          const { data: row } = await context.supabase.from("cms_pages").select("parent_id").eq("id", cur).maybeSingle() as { data: { parent_id: string | null } | null };
          cur = row?.parent_id ?? null;
        }
      }
      const { error } = await context.supabase
        .from("cms_pages")
        .update({ parent_id: u.parent_id, sort_order: u.sort_order, updated_by: context.userId })
        .eq("id", u.id);
      if (error) throw new Error(error.message);
    }
    return { ok: true };
  });

export const pageSeoAudit = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ pageId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const { data: page, error } = await context.supabase.from("cms_pages").select("*").eq("id", data.pageId).single();
    if (error) throw new Error(error.message);
    const { data: blocks } = await context.supabase.from("cms_blocks").select("*").eq("page_id", data.pageId).order("position");

    const issues: { level: "error" | "warn" | "info"; msg: string }[] = [];
    const title = (page.seo_title ?? page.title ?? "").trim();
    const desc = (page.seo_description ?? page.description ?? "").trim();

    if (!title) issues.push({ level: "error", msg: "Hiányzó SEO cím." });
    else if (title.length < 25) issues.push({ level: "warn", msg: `SEO cím rövid (${title.length} kar.) — ajánlott 30-60.` });
    else if (title.length > 65) issues.push({ level: "warn", msg: `SEO cím hosszú (${title.length} kar.) — ajánlott 30-60.` });

    if (!desc) issues.push({ level: "error", msg: "Hiányzó SEO leírás." });
    else if (desc.length < 80) issues.push({ level: "warn", msg: `SEO leírás rövid (${desc.length} kar.) — ajánlott 80-160.` });
    else if (desc.length > 170) issues.push({ level: "warn", msg: `SEO leírás hosszú (${desc.length} kar.) — ajánlott 80-160.` });

    if (!page.og_image_url) issues.push({ level: "info", msg: "Nincs Open Graph kép — a social megosztás generikus lesz." });
    if (page.noindex) issues.push({ level: "warn", msg: "Az oldal noindex — keresőmotorok nem indexelik." });
    if (!page.show_in_sitemap) issues.push({ level: "info", msg: "Nem szerepel a sitemap.xml-ben." });

    let h1Count = 0;
    let imagesWithoutAlt = 0;
    let totalImages = 0;
    let internalLinks = 0;
    let externalLinks = 0;
    let wordCount = 0;
    for (const b of blocks ?? []) {
      const c: any = b.content ?? {};
      if (b.block_type === "heading") h1Count++;
      if (b.block_type === "image") {
        totalImages++;
        if (!c.alt || !String(c.alt).trim()) imagesWithoutAlt++;
      }
      if (b.block_type === "richtext" && c.html) {
        const html = String(c.html);
        h1Count += (html.match(/<h1\b/gi) ?? []).length;
        const imgs = html.match(/<img\b[^>]*>/gi) ?? [];
        totalImages += imgs.length;
        for (const img of imgs) {
          if (!/alt\s*=\s*["'][^"']+["']/i.test(img)) imagesWithoutAlt++;
        }
        const links = html.match(/<a\b[^>]*href=["']([^"']+)["']/gi) ?? [];
        for (const m of links) {
          const href = m.match(/href=["']([^"']+)["']/i)?.[1] ?? "";
          if (/^https?:\/\//i.test(href)) externalLinks++;
          else if (href.startsWith("/") || href.startsWith("#")) internalLinks++;
        }
        const text = html.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
        wordCount += text ? text.split(" ").length : 0;
      }
    }
    if (h1Count === 0) issues.push({ level: "warn", msg: "Nincs H1 címsor az oldalon." });
    else if (h1Count > 1) issues.push({ level: "warn", msg: `Több H1 (${h1Count}) — ajánlott pontosan 1.` });
    if (imagesWithoutAlt > 0) issues.push({ level: "warn", msg: `${imagesWithoutAlt} kép alt szöveg nélkül (a11y/SEO).` });
    if (wordCount < 200 && (blocks?.length ?? 0) > 0) issues.push({ level: "info", msg: `Szószám alacsony (~${wordCount}) — gazdagabb tartalom jobb rangsorolást ad.` });
    if (internalLinks === 0 && (blocks?.length ?? 0) > 0) issues.push({ level: "info", msg: "Nincs belső hivatkozás — érdemes kapcsolódó oldalakra mutatni." });

    const score = Math.max(0, 100 - issues.filter(i => i.level === "error").length * 25 - issues.filter(i => i.level === "warn").length * 10 - issues.filter(i => i.level === "info").length * 3);
    return {
      score,
      issues,
      stats: { h1Count, totalImages, imagesWithoutAlt, internalLinks, externalLinks, wordCount, blocks: blocks?.length ?? 0 },
      page: { title, desc, slug: page.slug, locale: page.locale, status: page.status },
    };
  });



// ---------------- MENUS ----------------
export const listMenus = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertCmsAccess(context);
    const { data } = await context.supabase.from("cms_menus").select("*").order("name");
    return data ?? [];
  });

export const getMenuItems = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ menuId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const { data: items } = await context.supabase
      .from("cms_menu_items").select("*").eq("menu_id", data.menuId).order("position");
    return items ?? [];
  });

const MenuItemInput = z.object({
  id: z.string().uuid().optional(),
  menu_id: z.string().uuid(),
  parent_id: z.string().uuid().nullable().optional(),
  position: z.number().int().default(0),
  label: z.string().min(1),
  url: z.string().nullable().optional(),
  page_id: z.string().uuid().nullable().optional(),
  locale: z.string().default("hu"),
  open_in_new_tab: z.boolean().default(false),
  icon: z.string().nullable().optional(),
});

export const saveMenuItem = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => MenuItemInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    if (data.id) {
      const { error } = await context.supabase.from("cms_menu_items").update(data).eq("id", data.id);
      if (error) throw new Error(error.message);
      return { id: data.id };
    }
    const { data: row, error } = await context.supabase.from("cms_menu_items").insert(data).select("id").single();
    if (error) throw new Error(error.message);
    return { id: row.id };
  });

export const deleteMenuItem = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const { error } = await context.supabase.from("cms_menu_items").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/**
 * Publikus menü lekérdezés slug + locale alapján — a nav_menu blokk és bármely
 * SSR-elt fejléc/footer használhatja. RLS-en keresztül anon olvasható.
 */
export const getPublicMenu = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) =>
    z.object({ slug: z.string().min(1).max(80), locale: z.string().default("hu") }).parse(d),
  )
  .handler(async ({ data }) => {
    const sb = publicClient();
    const { data: menu } = await (sb as any)
      .from("cms_menus")
      .select("id,key,name")
      .eq("key", data.slug)
      .maybeSingle();
    if (!menu) return { menu: null, items: [] as any[] };
    const { data: items } = await (sb as any)
      .from("cms_menu_items")
      .select("id,parent_id,position,label,url,page_id,locale,open_in_new_tab,icon")
      .eq("menu_id", menu.id)
      .eq("locale", data.locale)
      .order("position", { ascending: true });
    // Resolve page_id → slug for internal links (one extra query, batched)
    const pageIds = (items ?? []).map((i: any) => i.page_id).filter(Boolean);
    let pageSlugs: Record<string, string> = {};
    if (pageIds.length) {
      const { data: pages } = await (sb as any)
        .from("cms_pages").select("id,slug,is_home").in("id", pageIds);
      for (const p of pages ?? []) pageSlugs[p.id] = p.is_home ? "/" : `/o/${p.slug}`;
    }
    const resolved = (items ?? []).map((i: any) => ({
      ...i,
      href: i.url ?? (i.page_id ? pageSlugs[i.page_id] ?? "#" : "#"),
    }));
    return { menu, items: resolved };
  });


// ---------------- MEDIA ----------------
export const listMedia = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertCmsAccess(context);
    const { data } = await context.supabase.from("cms_media").select("*").order("created_at", { ascending: false }).limit(500);
    return data ?? [];
  });

export const registerMedia = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({
    storage_path: z.string(),
    file_name: z.string(),
    mime_type: z.string(),
    size_bytes: z.number().int(),
    alt_text: z.string().optional(),
    caption: z.string().optional(),
    category: z.string().optional(),
  }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const { data: row, error } = await context.supabase.from("cms_media")
      .insert({ ...data, uploaded_by: context.userId }).select("*").single();
    if (error) throw new Error(error.message);
    return row;
  });

export const deleteMedia = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid(), storage_path: z.string() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    await context.supabase.storage.from("cms-media").remove([data.storage_path]);
    await context.supabase.from("cms_media").delete().eq("id", data.id);
    return { ok: true };
  });

export const signMediaUrl = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ path: z.string() }).parse(d))
  .handler(async ({ data, context }) => {
    const { data: signed } = await context.supabase.storage.from("cms-media").createSignedUrl(data.path, 60 * 60 * 24 * 7);
    return { url: signed?.signedUrl ?? null };
  });

// ---------------- REDIRECTS ----------------
const RedirectInput = z.object({
  id: z.string().uuid().optional(),
  source_path: z.string().min(1),
  target_path: z.string().min(1),
  status_code: z.number().int().default(301),
  note: z.string().nullable().optional(),
  is_active: z.boolean().default(true),
});

export const listRedirects = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertCmsAccess(context);
    const { data } = await context.supabase.from("cms_redirects").select("*").order("source_path");
    return data ?? [];
  });

export const saveRedirect = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => RedirectInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    if (data.id) {
      const { error } = await context.supabase.from("cms_redirects").update(data).eq("id", data.id);
      if (error) throw new Error(error.message);
      return { id: data.id };
    }
    const { data: row, error } = await context.supabase.from("cms_redirects").insert(data).select("id").single();
    if (error) throw new Error(error.message);
    return { id: row.id };
  });

export const deleteRedirect = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const { error } = await context.supabase.from("cms_redirects").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// ---------------- i18n / Translation ----------------
export const upsertI18n = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({
    entity_type: z.string(),
    entity_id: z.string().uuid(),
    locale: z.string(),
    data: z.record(z.string(), z.unknown()),
  }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const { error } = await context.supabase.from("cms_i18n_content").upsert({
      ...data, updated_by: context.userId, updated_at: new Date().toISOString(),
    } as any, { onConflict: "entity_type,entity_id,locale" });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const aiTranslate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({
    text: z.string(),
    source_locale: z.string().default("hu"),
    target_locale: z.string(),
  }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) throw new Error("Missing LOVABLE_API_KEY");
    const langs: Record<string, string> = {
      hu: "Hungarian", en: "English", de: "German", zh: "Simplified Chinese",
      fil: "Filipino", sr: "Serbian", ro: "Romanian",
    };
    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Lovable-API-Key": apiKey },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: `You are a professional medical clinic website translator. Translate from ${langs[data.source_locale] ?? data.source_locale} to ${langs[data.target_locale] ?? data.target_locale}. Preserve HTML tags and formatting exactly. Output ONLY the translation, no commentary.` },
          { role: "user", content: data.text },
        ],
      }),
    });
    if (!res.ok) throw new Error(`AI gateway ${res.status}`);
    const json = await res.json();
    return { text: json.choices?.[0]?.message?.content ?? "" };
  });

// ---------------- PUBLIC (no auth) ----------------
export const getPublishedPage = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) =>
    z.object({
      slug: z.string(),
      locale: z.string().default("hu"),
      previewToken: z.string().uuid().optional(),
    }).parse(d),
  )
  .handler(async ({ data }) => {
    const sb = publicClient();
    // Lusta auto-publish: minden olvasáskor élesítjük az esedékes ütemezett oldalakat.
    const { error: promoteError } = await sb.rpc("cms_promote_scheduled_pages");
    if (promoteError) {
      console.warn("Scheduled CMS publish promotion skipped", promoteError.message);
    }

    let q = sb.from("cms_pages").select("*").eq("slug", data.slug).eq("locale", data.locale);
    const { data: page } = await q.maybeSingle();
    if (!page) return null;

    const isPublic = page.status === "published";
    const tokenMatches = !!data.previewToken && data.previewToken === page.preview_token;
    if (!isPublic && !tokenMatches) return null;

    const blocksQ = sb.from("cms_blocks").select("*").eq("page_id", page.id).order("position");
    const { data: blocks } = isPublic
      ? await blocksQ.eq("is_published", true)
      : await blocksQ; // előnézet: minden blokk
    return { page, blocks: blocks ?? [], preview: !isPublic && tokenMatches };
  });

export const schedulePagePublish = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({
      pageId: z.string().uuid(),
      when: z.string().datetime().nullable(),
    }).parse(d),
  )
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    if (data.when && new Date(data.when).getTime() <= Date.now()) {
      throw new Error("Az ütemezett időpontnak a jövőben kell lennie.");
    }
    const patch: any = data.when
      ? { status: "scheduled", scheduled_publish_at: data.when, published_at: null }
      : { status: "draft", scheduled_publish_at: null };
    const { error } = await context.supabase.from("cms_pages").update(patch).eq("id", data.pageId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/** Immediate publish without creating a version snapshot (lightweight toggle). */
export const publishPage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ pageId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const { error } = await context.supabase
      .from("cms_pages")
      .update({ status: "published", published_at: new Date().toISOString(), scheduled_publish_at: null })
      .eq("id", data.pageId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/** Revoke a page back to draft (keeps content, hides from public routes). */
export const unpublishPage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ pageId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const { error } = await context.supabase
      .from("cms_pages")
      .update({ status: "draft", published_at: null, scheduled_publish_at: null })
      .eq("id", data.pageId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const getPagePreviewLink = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ pageId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const { data: row, error } = await context.supabase
      .from("cms_pages").select("slug, preview_token").eq("id", data.pageId).single();
    if (error) throw new Error(error.message);
    return { slug: row.slug, token: row.preview_token };
  });

export const getActiveMenu = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) => z.object({ key: z.string(), locale: z.string().default("hu") }).parse(d))
  .handler(async ({ data }) => {
    const sb = publicClient();
    const { data: menu } = await sb.from("cms_menus").select("id,key,name,location").eq("key", data.key).maybeSingle();
    if (!menu) return null;
    const { data: items } = await sb.from("cms_menu_items").select("*")
      .eq("menu_id", menu.id).eq("locale", data.locale).order("position");
    return { menu, items: items ?? [] };
  });

export const getPublicRedirect = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) => z.object({ source: z.string() }).parse(d))
  .handler(async ({ data }) => {
    const sb = publicClient();
    const { data: r } = await sb.from("cms_redirects").select("target_path,status_code")
      .eq("source_path", data.source).eq("is_active", true).maybeSingle();
    return r ?? null;
  });

export const listSitemapEntries = createServerFn({ method: "GET" })
  .handler(async () => {
    const sb = publicClient();
    const { data } = await sb.from("cms_pages").select("slug,locale,updated_at")
      .eq("status", "published").eq("show_in_sitemap", true);
    return data ?? [];
  });

// View tracking — anon-safe via SECURITY DEFINER RPC
export const trackPageView = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => z.object({ pageId: z.string().uuid() }).parse(d))
  .handler(async ({ data }) => {
    const sb = publicClient();
    const { error } = await sb.rpc("cms_page_view_record", { _page_id: data.pageId });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const getPageViewStats = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ pageId: z.string().uuid(), days: z.number().int().min(1).max(90).default(30) }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const since = new Date(Date.now() - data.days * 86400_000).toISOString().slice(0, 10);
    const { data: rows, error } = await context.supabase
      .from("cms_page_views")
      .select("day,views")
      .eq("page_id", data.pageId)
      .gte("day", since)
      .order("day");
    if (error) throw new Error(error.message);
    const { data: page } = await context.supabase
      .from("cms_pages").select("title,slug,view_count,last_viewed_at").eq("id", data.pageId).single() as { data: any };
    const total = (rows ?? []).reduce((s: number, r: any) => s + (r.views ?? 0), 0);
    return { page, daily: rows ?? [], windowTotal: total, days: data.days };
  });

export const getCmsGlobalStats = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ days: z.number().int().min(1).max(90).default(30) }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const since = new Date(Date.now() - data.days * 86400_000).toISOString().slice(0, 10);

    const { data: pagesAll } = await context.supabase
      .from("cms_pages")
      .select("id,title,slug,locale,status,view_count,last_viewed_at");

    const { data: viewsRows } = await context.supabase
      .from("cms_page_views")
      .select("page_id,day,views")
      .gte("day", since);

    const byPage = new Map<string, number>();
    const byDay = new Map<string, number>();
    for (const r of (viewsRows ?? []) as any[]) {
      byPage.set(r.page_id, (byPage.get(r.page_id) ?? 0) + (r.views ?? 0));
      byDay.set(r.day, (byDay.get(r.day) ?? 0) + (r.views ?? 0));
    }

    const top = (pagesAll ?? [])
      .map((p: any) => ({ ...p, windowViews: byPage.get(p.id) ?? 0 }))
      .sort((a, b) => b.windowViews - a.windowViews)
      .slice(0, 10);

    const totalPages = (pagesAll ?? []).length;
    const publishedPages = (pagesAll ?? []).filter((p: any) => p.status === "published").length;
    const draftPages = (pagesAll ?? []).filter((p: any) => p.status === "draft").length;
    const totalAllTime = (pagesAll ?? []).reduce((s: number, p: any) => s + (p.view_count ?? 0), 0);
    const totalWindow = Array.from(byDay.values()).reduce((s, v) => s + v, 0);

    // Daily series filled
    const series: { day: string; views: number }[] = [];
    const today = new Date();
    for (let i = data.days - 1; i >= 0; i--) {
      const key = new Date(today.getTime() - i * 86400_000).toISOString().slice(0, 10);
      series.push({ day: key, views: byDay.get(key) ?? 0 });
    }

    return { top, totalPages, publishedPages, draftPages, totalAllTime, totalWindow, days: data.days, series };
  });


