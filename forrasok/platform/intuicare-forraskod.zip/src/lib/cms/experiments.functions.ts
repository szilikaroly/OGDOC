/**
 * A/B kísérlet server fn-ek. Adminok kezelik a kísérleteket és variánsokat,
 * a publikus rendererhez külön getRunningExperimentsForBlock fn ad adatot.
 */
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { createClient } from "@supabase/supabase-js";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { ConversionEventsSchema } from "./conversion-events";

function publicClient() {
  const url = process.env.SUPABASE_URL!;
  const key = process.env.SUPABASE_PUBLISHABLE_KEY!;
  return createClient(url, key, {
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
  });
}

async function assertCmsAccess(ctx: { supabase: any; userId: string }) {
  const { data, error } = await ctx.supabase.rpc("has_cms_access", { _user_id: ctx.userId });
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Forbidden");
}

// ============== PUBLIC ==============

export const getRunningExperimentsForBlock = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) => z.object({
    block_id: z.string().uuid().optional(),
    layout_block_id: z.string().uuid().optional(),
  }).parse(d ?? {}))
  .handler(async ({ data }) => {
    if (!data.block_id && !data.layout_block_id) return { experiments: [] };
    const sb = publicClient();
    let q = sb.from("cms_experiments")
      .select("id,name,status,traffic_allocation,goal_event,block_id,layout_block_id,cms_experiment_variants(id,key,name,is_control,weight,content)")
      .eq("status", "running");
    if (data.block_id) q = q.eq("block_id", data.block_id);
    if (data.layout_block_id) q = q.eq("layout_block_id", data.layout_block_id);
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    return { experiments: rows ?? [] };
  });

// ============== ADMIN ==============

const ExperimentInput = z.object({
  id: z.string().uuid().optional(),
  name: z.string().min(1).max(200),
  description: z.string().max(2000).optional().nullable(),
  block_id: z.string().uuid().optional().nullable(),
  layout_block_id: z.string().uuid().optional().nullable(),
  status: z.enum(["draft", "running", "paused", "completed"]).default("draft"),
  traffic_allocation: z.number().min(0.01).max(1).default(1),
  goal_event: z.string().min(1).max(80),
  conversion_events: ConversionEventsSchema.optional(),
}).superRefine((v, ctx) => {
  const has = (x: unknown) => x !== null && x !== undefined && x !== "";
  if (has(v.block_id) === has(v.layout_block_id)) {
    ctx.addIssue({ code: z.ZodIssueCode.custom, path: ["block_id"], message: "Pontosan egy block_id vagy layout_block_id kötelező." });
  }
});

export const adminListExperiments = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({
    status: z.enum(["draft", "running", "paused", "completed"]).optional(),
  }).parse(d ?? {}))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    let q = context.supabase.from("cms_experiments")
      .select("*,cms_experiment_variants(id,key,name,is_control,weight)")
      .order("created_at", { ascending: false });
    if (data.status) q = q.eq("status", data.status);
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

export const adminGetExperiment = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const { data: row, error } = await context.supabase.from("cms_experiments")
      .select("*,cms_experiment_variants(*)").eq("id", data.id).maybeSingle();
    if (error) throw new Error(error.message);
    return row;
  });

export const adminUpsertExperiment = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => ExperimentInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const payload: any = { ...data };
    if (payload.id) {
      const id = payload.id;
      delete payload.id;
      const { error } = await context.supabase.from("cms_experiments").update(payload).eq("id", id);
      if (error) throw new Error(error.message);
      return { id };
    }
    const { data: row, error } = await context.supabase.from("cms_experiments").insert(payload).select("id").single();
    if (error) throw new Error(error.message);
    return { id: row.id };
  });

const VariantInput = z.object({
  id: z.string().uuid().optional(),
  experiment_id: z.string().uuid(),
  key: z.string().min(1).max(20).regex(/^[A-Za-z0-9_-]+$/),
  name: z.string().max(120).optional().nullable(),
  is_control: z.boolean().default(false),
  weight: z.number().min(0).max(100).default(1),
  content: z.any().default({}),
});

export const adminUpsertVariant = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => VariantInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const payload: any = { ...data };
    if (payload.id) {
      const id = payload.id;
      delete payload.id;
      const { error } = await context.supabase.from("cms_experiment_variants").update(payload).eq("id", id);
      if (error) throw new Error(error.message);
      return { id };
    }
    const { data: row, error } = await context.supabase.from("cms_experiment_variants").insert(payload).select("id").single();
    if (error) throw new Error(error.message);
    return { id: row.id };
  });

export const adminDeleteVariant = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const { error } = await context.supabase.from("cms_experiment_variants").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const adminSetExperimentStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({
    id: z.string().uuid(),
    status: z.enum(["draft", "running", "paused", "completed"]),
    winner_variant_id: z.string().uuid().optional().nullable(),
  }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const patch: any = { status: data.status };
    if (data.status === "running") patch.started_at = new Date().toISOString();
    if (data.status === "completed") {
      patch.ended_at = new Date().toISOString();
      if (data.winner_variant_id) patch.winner_variant_id = data.winner_variant_id;
    }
    const { error } = await context.supabase.from("cms_experiments").update(patch).eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const adminGetExperimentStats = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({
    id: z.string().uuid(),
    days: z.number().int().min(1).max(365).default(30),
  }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const since = new Date(Date.now() - data.days * 86400 * 1000).toISOString();
    const { data: rows, error } = await (context.supabase as any)
      .from("cms_experiment_events")
      .select("variant_id,event_type,created_at")
      .eq("experiment_id", data.id)
      .gte("created_at", since);
    if (error) throw new Error(error.message);
    const agg = new Map<string, { views: number; goals: number }>();
    for (const r of (rows ?? []) as any[]) {
      const s = agg.get(r.variant_id) ?? { views: 0, goals: 0 };
      if (r.event_type === "view") s.views++; else if (r.event_type === "goal") s.goals++;
      agg.set(r.variant_id, s);
    }
    return Array.from(agg.entries()).map(([variant_id, v]) => ({
      variant_id,
      views: v.views,
      goals: v.goals,
      conversion_rate: v.views > 0 ? v.goals / v.views : 0,
    }));
  });

export const adminGetExperimentDailyStats = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({
    id: z.string().uuid(),
    from: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
    to: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  }).parse(d))
  .handler(async ({ data, context }) => {
    await assertCmsAccess(context);
    const fromIso = new Date(data.from + "T00:00:00.000Z").toISOString();
    const toIso = new Date(data.to + "T23:59:59.999Z").toISOString();

    const { data: exp, error: expErr } = await context.supabase
      .from("cms_experiments")
      .select("id,name,cms_experiment_variants(id,key,name)")
      .eq("id", data.id)
      .maybeSingle();
    if (expErr) throw new Error(expErr.message);
    if (!exp) throw new Error("Kísérlet nem található");

    const { data: rows, error } = await (context.supabase as any)
      .from("cms_experiment_events")
      .select("variant_id,event_type,created_at")
      .eq("experiment_id", data.id)
      .gte("created_at", fromIso)
      .lte("created_at", toIso);
    if (error) throw new Error(error.message);

    const bucket = new Map<string, { views: number; goals: number }>();
    for (const r of (rows ?? []) as any[]) {
      const day = String(r.created_at).slice(0, 10);
      const key = `${day}|${r.variant_id}`;
      const s = bucket.get(key) ?? { views: 0, goals: 0 };
      if (r.event_type === "view") s.views++; else if (r.event_type === "goal") s.goals++;
      bucket.set(key, s);
    }
    const variants: any[] = exp.cms_experiment_variants ?? [];
    const variantMap = new Map(variants.map((v: any) => [v.id, v]));
    const daily = Array.from(bucket.entries()).map(([k, v]) => {
      const [day, variant_id] = k.split("|");
      const vv = variantMap.get(variant_id) as any;
      return {
        date: day,
        variant_id,
        variant_key: vv?.key ?? "",
        variant_name: vv?.name ?? "",
        views: v.views,
        goals: v.goals,
        conversion_rate: v.views > 0 ? v.goals / v.views : 0,
      };
    }).sort((a, b) => a.date.localeCompare(b.date) || a.variant_key.localeCompare(b.variant_key));

    return { experiment_name: exp.name, rows: daily };
  });
