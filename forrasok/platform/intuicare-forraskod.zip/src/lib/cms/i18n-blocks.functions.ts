/**
 * AI-alapú blokk-fordítás a CMS vizuális szerkesztőhöz.
 * - `translateBlock`: egy blokk `content` stringjeit lefordítja megadott
 *   nyelvekre, majd upsertelt (locale-enként külön) blokkot hoz létre a
 *   forrás blokk (page_id, position, block_type) alapján.
 * - `translateBlocks`: több blokkra iterál (soros).
 */
import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";
import { SUPPORTED_LANGUAGES, type LangCode } from "@/i18n/languages";

const LANG_CODES = SUPPORTED_LANGUAGES.map((l) => l.code) as unknown as [LangCode, ...LangCode[]];

const Input = z.object({
  block_ids: z.array(z.string().uuid()).min(1).max(50),
  target_langs: z.array(z.enum(LANG_CODES)).min(1),
  source_lang: z.enum(LANG_CODES).default("hu"),
  overwrite_edited: z.boolean().default(false),
});

// ── Utilities ────────────────────────────────────────────────────────────
type StringLeaf = { path: (string | number)[]; value: string };

const SHOULD_TRANSLATE_KEYS = new Set([
  "title", "subtitle", "heading", "text", "body", "description", "label",
  "cta", "cta_label", "button", "button_label", "caption", "quote",
  "author", "name", "question", "answer", "placeholder", "html", "content",
  "alt", "summary", "excerpt",
]);
const SKIP_KEYS = new Set([
  "id", "slug", "url", "href", "src", "image", "image_url", "img", "icon",
  "type", "kind", "variant", "color", "bg", "background", "className",
  "target", "rel", "email", "phone", "tel", "locale", "lang", "utm",
]);

function collectStrings(node: any, out: StringLeaf[], path: (string | number)[] = []) {
  if (node == null) return;
  if (typeof node === "string") {
    const parent = path[path.length - 1];
    const parentKey = typeof parent === "string" ? parent : "";
    // Skip URLs and non-text technical strings
    if (/^(https?:|mailto:|tel:|\/|#)/i.test(node.trim())) return;
    if (typeof parent === "string" && SKIP_KEYS.has(parent)) return;
    // Only translate if it looks like human text (has a letter and length ≥ 2)
    if (node.trim().length < 2 || !/[\p{L}]/u.test(node)) return;
    // Prefer known-translatable keys, but also translate any string > 3 chars
    // that isn't in SKIP_KEYS (defensive).
    if (parentKey && SKIP_KEYS.has(parentKey)) return;
    out.push({ path: [...path], value: node });
    return;
  }
  if (Array.isArray(node)) {
    node.forEach((v, i) => collectStrings(v, out, [...path, i]));
    return;
  }
  if (typeof node === "object") {
    for (const [k, v] of Object.entries(node)) {
      if (SKIP_KEYS.has(k)) continue;
      collectStrings(v, out, [...path, k]);
    }
  }
}

function setAtPath(root: any, path: (string | number)[], value: any) {
  let cur = root;
  for (let i = 0; i < path.length - 1; i++) cur = cur[path[i]];
  cur[path[path.length - 1]] = value;
}

async function aiTranslate(
  supabase: any,
  texts: Record<string, string>,
  target_lang: string,
  source_lang: string,
): Promise<Record<string, string>> {
  if (target_lang === source_lang) return texts;
  const key = process.env.LOVABLE_API_KEY;
  if (!key) throw new Error("Hiányzó LOVABLE_API_KEY.");
  const { createLovableAiGatewayProvider } = await import("@/lib/ai-gateway.server");
  const { generateText } = await import("ai");
  const gateway = createLovableAiGatewayProvider(key);
  const model = gateway("google/gemini-3-flash-preview");

  const { data: glossary } = await supabase
    .from("translation_glossary")
    .select("term,translation")
    .eq("target_lang", target_lang);
  const glossaryStr = (glossary ?? []).length
    ? `\nKötelező szótár:\n${(glossary ?? []).map((g: any) => `- ${g.term} → ${g.translation}`).join("\n")}`
    : "";

  const targetLabel = SUPPORTED_LANGUAGES.find((l) => l.code === target_lang)?.label ?? target_lang;
  const system = `Szakfordító vagy egészségügyi/klinikai kontextusra. A forrásnyelv ${source_lang}, fordíts ${targetLabel} (${target_lang}) nyelvre.
- Csak az értékeket fordítsd. A JSON kulcsokat változatlanul hagyd.
- Megőrzöd a változókat ({{name}}, {count}), HTML tageket, számokat, dátumokat, egységeket, e-maileket, URL-eket, telefonszámokat változatlanul.
- Tömör, formális szaknyelv.
- A válasz KIZÁRÓLAG egy érvényes JSON objektum, azonos kulcsokkal.${glossaryStr}`;
  const prompt = `Fordítsd le a következő JSON értékeit:\n\n${JSON.stringify(texts, null, 2)}`;

  const { text } = await generateText({ model, system, prompt });
  const cleaned = text.replace(/^```json\s*/i, "").replace(/^```\s*/i, "").replace(/```\s*$/i, "").trim();
  return JSON.parse(cleaned) as Record<string, string>;
}

// ── Handler ──────────────────────────────────────────────────────────────
export const translateBlocks = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => Input.parse(d))
  .handler(async ({ data, context }) => {
    const sb = context.supabase as any;
    const { data: sourceBlocks, error: e1 } = await sb
      .from("cms_layout_blocks")
      .select("id,page_id,region_key,position,block_type,content,style,locale,status")
      .in("id", data.block_ids)
      .eq("locale", data.source_lang);
    if (e1) throw new Error(e1.message);
    if (!sourceBlocks?.length) return { ok: true, translated: 0, langs: [] as string[] };

    const summary: Array<{ block_id: string; lang: string; strings: number; ok: boolean; error?: string }> = [];
    let translatedCount = 0;

    for (const src of sourceBlocks) {
      const leaves: StringLeaf[] = [];
      collectStrings(src.content ?? {}, leaves);
      if (!leaves.length) continue;

      const texts: Record<string, string> = {};
      leaves.forEach((l, i) => { texts[`s${i}`] = l.value; });

      for (const lang of data.target_langs) {
        if (lang === data.source_lang) continue;

        // Skip if target locale block already exists AND overwrite is off
        const { data: existing } = await sb
          .from("cms_layout_blocks")
          .select("id, updated_at")
          .eq("page_id", src.page_id)
          .eq("position", src.position)
          .eq("block_type", src.block_type)
          .eq("locale", lang)
          .maybeSingle();

        if (existing?.id && !data.overwrite_edited) {
          summary.push({ block_id: src.id, lang, strings: 0, ok: true, error: "skipped (exists)" });
          continue;
        }

        try {
          const translated = await aiTranslate(sb, texts, lang, data.source_lang);
          const clone = JSON.parse(JSON.stringify(src.content ?? {}));
          leaves.forEach((l, i) => {
            const v = translated[`s${i}`];
            if (typeof v === "string") setAtPath(clone, l.path, v);
          });

          const row: any = {
            page_id: src.page_id,
            region_key: src.region_key,
            position: src.position,
            block_type: src.block_type,
            content: clone,
            style: src.style,
            locale: lang,
            status: src.status,
            updated_by: context.userId,
          };
          if (existing?.id) row.id = existing.id;

          const { error: eUp } = await sb.from("cms_layout_blocks").upsert(row);
          if (eUp) throw new Error(eUp.message);
          translatedCount++;
          summary.push({ block_id: src.id, lang, strings: leaves.length, ok: true });
        } catch (err: any) {
          summary.push({ block_id: src.id, lang, strings: leaves.length, ok: false, error: String(err?.message ?? err).slice(0, 200) });
        }
      }
    }

    return { ok: true, translated: translatedCount, summary };
  });
