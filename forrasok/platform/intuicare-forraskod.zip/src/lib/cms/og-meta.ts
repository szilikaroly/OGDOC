/**
 * Központi OG / Twitter / kanonikus meta helper minden CMS 2. fázis
 * tartalomtípushoz (CMS oldalak, Hírek/Blog, Vlog, Tanácsok, listák).
 *
 * Cél: minden slug-oldal egységes megosztási preview-t kapjon akkor is,
 * ha a szerkesztő nem tölti ki az OG mezőket – fallback lánc alapján.
 */

export const SITE_ORIGIN = "https://intuicare-planner.lovable.app";
export const SITE_NAME_DEFAULT = "Szülészeti és Nőgyógyászati Klinika";

export type SiteDefaults = {
  default_og_image_url?: string | null;
  site_name?: string | null;
  organization_jsonld?: Record<string, unknown> | null;
};

export type BuildHeadInput = {
  kind?: "article" | "video" | "website";
  title: string;
  description?: string | null;
  /** Full absolute URL. */
  url: string;
  image?: string | null;
  imageAlt?: string | null;
  siteDefaults?: SiteDefaults | null;
  /** Default "summary_large_image", video-nál "player". */
  twitterCard?: "summary" | "summary_large_image" | "player";
  /** noindex + nofollow (pl. draft preview). */
  noindex?: boolean;
  /** Extra meta-k, amiket a hívó pluszban felhasogatna (article:published_time stb.). */
  extraMeta?: Array<Record<string, string>>;
  /** Extra <script type="application/ld+json"> tartalmak. */
  jsonLd?: Array<Record<string, unknown>>;
};

export type BuildHeadOutput = {
  meta: Array<Record<string, string>>;
  links: Array<Record<string, string>>;
  scripts: Array<{ type: string; children: string }>;
};

/**
 * Egységes meta csomag: title/description/OG/Twitter/canonical + opcionális JSON-LD.
 * A hívó `head()` továbbadhatja saját JSON-LD-jét a `jsonLd` mezőn.
 */
export function buildContentHead(input: BuildHeadInput): BuildHeadOutput {
  const kind = input.kind ?? "website";
  const ogType = kind === "video" ? "video.other" : kind === "article" ? "article" : "website";
  const twitterCard = input.twitterCard ?? (kind === "video" ? "player" : "summary_large_image");
  const description = (input.description ?? "").trim();
  const siteName = input.siteDefaults?.site_name || SITE_NAME_DEFAULT;
  const image = input.image || input.siteDefaults?.default_og_image_url || null;
  const imageAlt = input.imageAlt || input.title;

  const meta: Array<Record<string, string>> = [
    { title: input.title },
    { name: "description", content: description },
    { property: "og:title", content: input.title },
    { property: "og:description", content: description },
    { property: "og:type", content: ogType },
    { property: "og:url", content: input.url },
    { property: "og:site_name", content: siteName },
    { name: "twitter:card", content: twitterCard },
    { name: "twitter:title", content: input.title },
    { name: "twitter:description", content: description },
  ];

  if (image) {
    meta.push({ property: "og:image", content: image });
    meta.push({ property: "og:image:alt", content: imageAlt });
    meta.push({ name: "twitter:image", content: image });
    meta.push({ name: "twitter:image:alt", content: imageAlt });
  }

  if (input.noindex) {
    meta.push({ name: "robots", content: "noindex,nofollow" });
  }

  if (input.extraMeta?.length) {
    for (const m of input.extraMeta) meta.push(m);
  }

  const scripts = (input.jsonLd ?? []).map((obj) => ({
    type: "application/ld+json",
    children: JSON.stringify(obj),
  }));

  return {
    meta,
    links: [{ rel: "canonical", href: input.url }],
    scripts,
  };
}

/** Helper: abszolút URL építése relatív path-ból. */
export function absoluteUrl(path: string): string {
  const p = path.startsWith("/") ? path : `/${path}`;
  return `${SITE_ORIGIN}${p}`;
}

/**
 * Dinamikus (Satori-alapú) OG-image URL egy CMS oldalhoz.
 * A `v` cache-buster segít friss preview-t kérni, ha az oldal módosult.
 */
export function dynamicOgImageUrl(slug: string, version?: string | number | null): string {
  const s = slug.replace(/^\//, "");
  const qs = version ? `?v=${encodeURIComponent(String(version))}` : "";
  return `${SITE_ORIGIN}/api/public/og/${s}${qs}`;
}

/**
 * Kép fallback lánc leaf routokhoz – az elsőt választja, ami tényleges URL.
 */
export function pickOgImage(...candidates: Array<string | null | undefined>): string | null {
  for (const c of candidates) {
    if (typeof c === "string" && c.trim().length > 0) return c;
  }
  return null;
}

/**
 * Site defaults biztonságos fallback – akkor is működik, ha a
 * `getPublicSiteSettings` hívás loaderben nem futott le.
 */
export function normalizeSiteDefaults(raw: unknown): SiteDefaults {
  const r = (raw ?? {}) as Record<string, unknown>;
  const orgJsonLd = r.organization_jsonld as Record<string, unknown> | null | undefined;
  const site_name =
    (typeof r.site_name === "string" ? r.site_name : null) ??
    (orgJsonLd && typeof orgJsonLd.name === "string" ? (orgJsonLd.name as string) : null) ??
    SITE_NAME_DEFAULT;
  return {
    default_og_image_url:
      typeof r.default_og_image_url === "string" ? (r.default_og_image_url as string) : null,
    site_name,
    organization_jsonld:
      orgJsonLd && typeof orgJsonLd === "object" ? orgJsonLd : null,
  };
}
