/**
 * Client-side SEO health check for CMS pages.
 * Runs live against the form state so the editor can react as the user types
 * — no server round-trip. Same rules as the server-side pageSeoAudit.
 */

export type SeoIssueLevel = "error" | "warn" | "info";
export type SeoIssue = { level: SeoIssueLevel; msg: string; field?: string };

export type SeoLintInput = {
  title?: string | null;
  seo_title?: string | null;
  description?: string | null;
  seo_description?: string | null;
  og_image_url?: string | null;
  slug?: string | null;
  noindex?: boolean | null;
  show_in_sitemap?: boolean | null;
  status?: string | null;
};

export type SeoLintResult = {
  score: number;
  issues: SeoIssue[];
  effectiveTitle: string;
  effectiveDescription: string;
  canonical: string;
};

export function lintPageSeo(p: SeoLintInput, opts?: { baseUrl?: string }): SeoLintResult {
  const issues: SeoIssue[] = [];
  const title = (p.seo_title ?? p.title ?? "").trim();
  const desc = (p.seo_description ?? p.description ?? "").trim();
  const base = opts?.baseUrl ?? (typeof window !== "undefined" ? window.location.origin : "");
  const slug = (p.slug ?? "").replace(/^\/+/, "");
  const canonical = `${base}/${slug === "" ? "" : `o/${slug}`}`.replace(/\/$/, "") || `${base}/`;

  if (!title) issues.push({ level: "error", msg: "Hiányzó SEO cím.", field: "seo_title" });
  else if (title.length < 25) issues.push({ level: "warn", msg: `SEO cím rövid (${title.length} kar.) — ajánlott 30–60.`, field: "seo_title" });
  else if (title.length > 65) issues.push({ level: "warn", msg: `SEO cím hosszú (${title.length} kar.) — ajánlott 30–60.`, field: "seo_title" });

  if (!desc) issues.push({ level: "error", msg: "Hiányzó SEO leírás.", field: "seo_description" });
  else if (desc.length < 80) issues.push({ level: "warn", msg: `SEO leírás rövid (${desc.length} kar.) — ajánlott 80–160.`, field: "seo_description" });
  else if (desc.length > 170) issues.push({ level: "warn", msg: `SEO leírás hosszú (${desc.length} kar.) — ajánlott 80–160.`, field: "seo_description" });

  if (!p.og_image_url) issues.push({ level: "info", msg: "Nincs OG kép — a megosztási preview generikus lesz.", field: "og_image_url" });
  else if (!/^https?:\/\//i.test(p.og_image_url)) issues.push({ level: "warn", msg: "OG kép URL abszolút (https://…) kell legyen.", field: "og_image_url" });

  if (p.noindex) issues.push({ level: "warn", msg: "Az oldal noindex — keresők nem indexelik.", field: "noindex" });
  if (p.show_in_sitemap === false) issues.push({ level: "info", msg: "Nem szerepel a sitemap-ben.", field: "show_in_sitemap" });

  if (p.status === "published" && p.noindex) {
    issues.push({ level: "warn", msg: "Élő oldal noindex-szel — ellentmondásos állapot." });
  }

  if (p.slug && !/^([a-z0-9-]+(\/[a-z0-9-]+)*)?$/.test(p.slug)) {
    issues.push({ level: "error", msg: "Érvénytelen slug (csak kisbetű, szám, kötőjel, / megengedett).", field: "slug" });
  }

  const errors = issues.filter(i => i.level === "error").length;
  const warns = issues.filter(i => i.level === "warn").length;
  const infos = issues.filter(i => i.level === "info").length;
  const score = Math.max(0, 100 - errors * 25 - warns * 10 - infos * 3);

  return { score, issues, effectiveTitle: title, effectiveDescription: desc, canonical };
}

/** Emit save-time toasts for the SEO health of a page draft. */
export function toastSeoOnSave(result: SeoLintResult, toast: { error: (m: string) => void; warning?: (m: string) => void; info?: (m: string) => void; success?: (m: string) => void }) {
  const errs = result.issues.filter(i => i.level === "error");
  const warns = result.issues.filter(i => i.level === "warn");
  if (errs.length) {
    toast.error(`SEO: ${errs.length} kritikus hiba — ${errs[0].msg}`);
  } else if (warns.length) {
    (toast.warning ?? toast.info ?? toast.error)(`SEO figyelmeztetés: ${warns[0].msg}${warns.length > 1 ? ` (+${warns.length - 1} további)` : ""}`);
  } else if (toast.success) {
    toast.success(`SEO OK (${result.score}/100)`);
  }
}
