/**
 * CMS Site beállítások – admin (egysoros singleton tábla).
 */
import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

async function assertCms(ctx: { supabase: any; userId: string }) {
  const { data, error } = await ctx.supabase.rpc("has_cms_access", { _user_id: ctx.userId });
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Nincs CMS jogosultságod.");
}

export const getSiteSettings = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertCms(context);
    const { data, error } = await context.supabase
      .from("cms_site_settings")
      .select("*")
      .eq("id", 1)
      .maybeSingle();
    if (error) throw new Error(error.message);
    return data;
  });

const SettingsInput = z.object({
  sos_active: z.boolean().default(false),
  sos_message: z.string().nullable().optional(),
  robots_txt: z.string().nullable().optional(),
  default_og_image_url: z.string().nullable().optional(),
  default_locale: z.string().default("hu"),
  organization_jsonld: z.any().nullable().optional(),
});

export const saveSiteSettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => SettingsInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertCms(context);
    const { error } = await context.supabase
      .from("cms_site_settings")
      .update({ ...data, updated_by: context.userId })
      .eq("id", 1);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
