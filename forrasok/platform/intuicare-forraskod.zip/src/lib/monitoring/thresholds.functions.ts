import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const listMonitoringThresholds = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase } = context;
    const { data, error } = await supabase
      .from("monitoring_thresholds")
      .select("id, kulcs, ertek, unit, megjegyzes, patient_id, program_id, tenant_id, updated_at")
      .order("kulcs", { ascending: true })
      .limit(500);
    if (error) throw new Error(error.message);
    return data ?? [];
  });

const ThresholdInput = z.object({
  id: z.string().uuid().optional(),
  kulcs: z.string().trim().min(2).max(80).regex(/^[a-z0-9_]+$/i, "Érvénytelen kulcs"),
  ertek: z.number().finite().gte(-10000).lte(100000),
  unit: z.string().trim().max(20).optional().nullable(),
  megjegyzes: z.string().trim().max(500).optional().nullable(),
  patient_id: z.string().uuid().optional().nullable(),
  program_id: z.string().uuid().optional().nullable(),
});

export const upsertMonitoringThreshold = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => ThresholdInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    // resolve tenant via profile
    const { data: prof } = await supabase.from("profiles").select("tenant_id").eq("id", userId).maybeSingle();
    if (!prof?.tenant_id) throw new Error("Hiányzó tenant");
    const payload = {
      id: data.id,
      kulcs: data.kulcs,
      ertek: data.ertek,
      unit: data.unit ?? null,
      megjegyzes: data.megjegyzes ?? null,
      patient_id: data.patient_id ?? null,
      program_id: data.program_id ?? null,
      tenant_id: prof.tenant_id,
      beallito_id: userId,
    };
    const { error } = await supabase.from("monitoring_thresholds").upsert(payload);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteMonitoringThreshold = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("monitoring_thresholds").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
