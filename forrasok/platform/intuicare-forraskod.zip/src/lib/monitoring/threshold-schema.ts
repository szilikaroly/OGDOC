import { z } from "zod";

/**
 * Shared Zod schema for monitoring threshold form/server validation.
 * Hard caps prevent nonsensical values reaching the DB.
 */
export const ThresholdFormSchema = z.object({
  kulcs: z
    .string()
    .trim()
    .min(2, "A kulcs legalább 2 karakter")
    .max(80, "A kulcs legfeljebb 80 karakter")
    .regex(/^[a-z0-9_]+$/i, "Csak betű, szám és aláhúzás engedélyezett"),
  ertek: z
    .number({ message: "Adjon meg egy érvényes számot" })
    .finite("A szám nem lehet végtelen")
    .gte(-10000, "Túl kicsi érték")
    .lte(100000, "Túl nagy érték"),
  unit: z.string().trim().max(20, "Mértékegység túl hosszú").optional().nullable(),
  megjegyzes: z.string().trim().max(500, "Megjegyzés túl hosszú").optional().nullable(),
  patient_id: z
    .string()
    .trim()
    .uuid("Érvénytelen páciens UUID")
    .optional()
    .nullable()
    .or(z.literal("")),
  program_id: z
    .string()
    .trim()
    .uuid("Érvénytelen program UUID")
    .optional()
    .nullable()
    .or(z.literal("")),
});

export type ThresholdFormValues = z.infer<typeof ThresholdFormSchema>;
