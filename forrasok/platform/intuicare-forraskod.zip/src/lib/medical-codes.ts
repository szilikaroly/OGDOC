// Mag-mintázat BNO-10 és OENO kódokhoz autocomplete-hez.
// Bővíthető saját kódlistával vagy NEAK exporttal.
export type CodeEntry = { kod: string; nev: string };

export const BNO_SEED: CodeEntry[] = [
  { kod: "I10", nev: "Esszenciális (elsődleges) hypertensio" },
  { kod: "I20.0", nev: "Instabil angina" },
  { kod: "I21.4", nev: "Akut subendocardialis myocardialis infarctus" },
  { kod: "I25.1", nev: "Atheroscleroticus szívbetegség" },
  { kod: "I48.0", nev: "Paroxysmalis pitvarfibrilláció" },
  { kod: "I50.0", nev: "Pangásos szívelégtelenség" },
  { kod: "J18.9", nev: "Pneumonia, nem meghatározott" },
  { kod: "J44.1", nev: "COPD akut exacerbatióval" },
  { kod: "K35.8", nev: "Akut appendicitis, nem meghatározott" },
  { kod: "K80.1", nev: "Cholelithiasis, cholecystitissel" },
  { kod: "N18.3", nev: "Krónikus vesebetegség, 3. stádium" },
  { kod: "E11.9", nev: "2-es típusú diabetes mellitus, szövődmény nélkül" },
  { kod: "S06.0", nev: "Agyrázkódás" },
  { kod: "S72.0", nev: "Combnyaktörés" },
  { kod: "Z51.1", nev: "Daganatos kemoterápia" },
  { kod: "R07.4", nev: "Mellkasi fájdalom, nem meghatározott" },
  { kod: "R10.4", nev: "Egyéb és nem meghatározott hasi fájdalom" },
];

export const OENO_SEED: CodeEntry[] = [
  { kod: "11041", nev: "Általános belgyógyászati vizsgálat" },
  { kod: "11500", nev: "Sürgősségi ellátás" },
  { kod: "12001", nev: "EKG, 12 elvezetéses" },
  { kod: "16630", nev: "Hasi UH-vizsgálat" },
  { kod: "29001", nev: "Mellkasröntgen, 1 irány" },
  { kod: "53110", nev: "Appendectomia" },
  { kod: "55510", nev: "Cholecystectomia laparoszkópos" },
  { kod: "58220", nev: "Femurszeg / DHS-behelyezés" },
  { kod: "91101", nev: "Anaesthesia, általános, intubatiós" },
  { kod: "93211", nev: "Pleurapunkció" },
];

export function searchCodes(seed: CodeEntry[], q: string, limit = 12): CodeEntry[] {
  const s = q.trim().toLowerCase();
  if (!s) return seed.slice(0, limit);
  return seed
    .filter((c) => c.kod.toLowerCase().includes(s) || c.nev.toLowerCase().includes(s))
    .slice(0, limit);
}
