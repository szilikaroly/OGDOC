/**
 * Szerveroldali PDF generátor szabadság-egyenleghez és kényszerkiadási tervhez.
 * server-only: csak server function-ön belül szabad dynamic import-tal betölteni.
 */
import React from "react";
import { Document, Page, Text, View, StyleSheet, renderToBuffer } from "@react-pdf/renderer";

const styles = StyleSheet.create({
  page: { padding: 36, fontSize: 10, fontFamily: "Helvetica", color: "#111827" },
  h1: { fontSize: 16, fontWeight: 700, color: "#0f766e", marginBottom: 4 },
  h2: { fontSize: 12, fontWeight: 700, marginTop: 14, marginBottom: 6 },
  meta: { fontSize: 9, color: "#6b7280", marginBottom: 12 },
  table: { width: "100%", marginTop: 4 },
  tr: { flexDirection: "row", borderBottomWidth: 0.5, borderColor: "#d1d5db", paddingVertical: 4 },
  th: { fontSize: 8, color: "#6b7280", textTransform: "uppercase", fontWeight: 700, paddingHorizontal: 4 },
  td: { fontSize: 10, paddingHorizontal: 4 },
  right: { textAlign: "right" },
  bold: { fontWeight: 700 },
});

export type BalanceRow = {
  jogcim: string;
  jaro: number;
  korr: number;
  athozott: number;
  kiadott: number;
  terv: number;
  forced: number;
  hatralevo: number;
};

export type PlanRow = {
  user: string;
  jogcim: string;
  nap: number;
  kezdo: string;
  zaro: string;
};

export async function renderBalancePdf(opts: {
  title: string;
  subtitle: string;
  rows: BalanceRow[];
  total: { jaro: number; athozott: number; kiadott: number; hatralevo: number };
}): Promise<Uint8Array> {
  const doc = React.createElement(
    Document,
    null,
    React.createElement(
      Page,
      { size: "A4", style: styles.page },
      React.createElement(Text, { style: styles.h1 }, opts.title),
      React.createElement(Text, { style: styles.meta }, opts.subtitle),
      React.createElement(
        View,
        { style: styles.table },
        React.createElement(
          View,
          { style: styles.tr },
          React.createElement(Text, { style: [styles.th, { flex: 3 }] }, "Jogcím"),
          React.createElement(Text, { style: [styles.th, { flex: 1 }, styles.right] }, "Járó"),
          React.createElement(Text, { style: [styles.th, { flex: 1 }, styles.right] }, "Korr."),
          React.createElement(Text, { style: [styles.th, { flex: 1 }, styles.right] }, "Áthozott"),
          React.createElement(Text, { style: [styles.th, { flex: 1 }, styles.right] }, "Kiadott"),
          React.createElement(Text, { style: [styles.th, { flex: 1 }, styles.right] }, "Tervezett"),
          React.createElement(Text, { style: [styles.th, { flex: 1 }, styles.right] }, "Kényszer"),
          React.createElement(Text, { style: [styles.th, { flex: 1 }, styles.right] }, "Hátra"),
        ),
        ...opts.rows.map((r, i) =>
          React.createElement(
            View,
            { style: styles.tr, key: i },
            React.createElement(Text, { style: [styles.td, { flex: 3 }] }, r.jogcim),
            React.createElement(Text, { style: [styles.td, { flex: 1 }, styles.right] }, r.jaro.toFixed(1)),
            React.createElement(Text, { style: [styles.td, { flex: 1 }, styles.right] }, r.korr.toFixed(1)),
            React.createElement(Text, { style: [styles.td, { flex: 1 }, styles.right] }, r.athozott.toFixed(1)),
            React.createElement(Text, { style: [styles.td, { flex: 1 }, styles.right] }, r.kiadott.toFixed(1)),
            React.createElement(Text, { style: [styles.td, { flex: 1 }, styles.right] }, r.terv.toFixed(1)),
            React.createElement(Text, { style: [styles.td, { flex: 1 }, styles.right] }, r.forced.toFixed(1)),
            React.createElement(Text, { style: [styles.td, { flex: 1 }, styles.right, styles.bold] }, r.hatralevo.toFixed(1)),
          ),
        ),
      ),
      React.createElement(Text, { style: styles.h2 }, "Összesítés"),
      React.createElement(
        Text,
        { style: styles.td },
        `Járó: ${opts.total.jaro.toFixed(1)} · Áthozott: ${opts.total.athozott.toFixed(1)} · Kiadott: ${opts.total.kiadott.toFixed(1)} · Hátralévő: ${opts.total.hatralevo.toFixed(1)} munkanap`,
      ),
    ),
  );
  const buf = await renderToBuffer(doc);
  return new Uint8Array(buf);
}

export async function renderPlanPdf(opts: {
  title: string;
  subtitle: string;
  rows: PlanRow[];
}): Promise<Uint8Array> {
  const doc = React.createElement(
    Document,
    null,
    React.createElement(
      Page,
      { size: "A4", style: styles.page },
      React.createElement(Text, { style: styles.h1 }, opts.title),
      React.createElement(Text, { style: styles.meta }, opts.subtitle),
      React.createElement(
        View,
        { style: styles.table },
        React.createElement(
          View,
          { style: styles.tr },
          React.createElement(Text, { style: [styles.th, { flex: 3 }] }, "Dolgozó"),
          React.createElement(Text, { style: [styles.th, { flex: 2 }] }, "Jogcím"),
          React.createElement(Text, { style: [styles.th, { flex: 1 }, styles.right] }, "Nap"),
          React.createElement(Text, { style: [styles.th, { flex: 2 }] }, "Kezdő"),
          React.createElement(Text, { style: [styles.th, { flex: 2 }] }, "Záró"),
        ),
        ...opts.rows.map((r, i) =>
          React.createElement(
            View,
            { style: styles.tr, key: i },
            React.createElement(Text, { style: [styles.td, { flex: 3 }] }, r.user),
            React.createElement(Text, { style: [styles.td, { flex: 2 }] }, r.jogcim),
            React.createElement(Text, { style: [styles.td, { flex: 1 }, styles.right, styles.bold] }, r.nap.toFixed(1)),
            React.createElement(Text, { style: [styles.td, { flex: 2 }] }, r.kezdo),
            React.createElement(Text, { style: [styles.td, { flex: 2 }] }, r.zaro),
          ),
        ),
      ),
    ),
  );
  const buf = await renderToBuffer(doc);
  return new Uint8Array(buf);
}
