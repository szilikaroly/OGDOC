import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/* eslint-disable @typescript-eslint/no-explicit-any */
type SB = any;

const JOGCIM_LABEL: Record<string, string> = {
  alap: "Alapszabadság",
  eletkor: "Életkori pótszabadság",
  gyermek: "Gyermek után járó",
  vezetoi: "Vezetői pótszabadság",
  oktatoi: "Oktatói pótszabadság",
  sugar: "Sugárterhelési pótszabadság",
  apasagi: "Apasági szabadság",
  szuloi: "Szülői szabadság",
  tanulmanyi: "Tanulmányi szabadság",
  egyeb_pot: "Egyéb pótszabadság",
};

async function requirePerm(
  supabase: SB,
  userId: string,
  perm: string,
): Promise<{ tenantId: string }> {
  const { data: ok, error } = await supabase.rpc("has_permission", {
    _user_id: userId,
    _perm: perm,
  });
  if (error) throw new Error(error.message);
  if (!ok) throw new Error(`403: Hiányzó jogosultság (${perm}).`);
  const { data: prof, error: pe } = await supabase
    .from("profiles")
    .select("tenant_id")
    .eq("id", userId)
    .maybeSingle();
  if (pe || !prof?.tenant_id) throw new Error("Nincs tenant.");
  return { tenantId: prof.tenant_id as string };
}

async function logAudit(
  supabase: SB,
  tenantId: string,
  actorId: string,
  action: "recalc_tenant" | "close_year" | "enforce_dry_run" | "enforce_apply" | "policy_update",
  payload: {
    ev?: number | null;
    target?: string | null;
    jogcim?: string | null;
    nap?: number | null;
    before?: unknown;
    after?: unknown;
    summary?: string;
  },
) {
  await supabase.rpc("log_leave_admin", {
    _tenant: tenantId,
    _actor: actorId,
    _action: action,
    _ev: payload.ev ?? null,
    _target_user: payload.target ?? null,
    _jogcim: payload.jogcim ?? null,
    _nap: payload.nap ?? null,
    _before: (payload.before ?? null) as any,
    _after: (payload.after ?? null) as any,
    _summary: payload.summary ?? null,
  });
}

export const checkLeaveAdmin = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const sb = context.supabase as SB;
    const { data: ok } = await sb.rpc("has_permission", {
      _user_id: context.userId,
      _perm: "manage_leave",
    });
    return { ok: !!ok };
  });

export const recalcLeave = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { userId: string; ev: number }) => d)
  .handler(async ({ data, context }) => {
    const sb = context.supabase as SB;
    await requirePerm(sb, context.userId, "manage_leave");
    const { error } = await sb.rpc("recalc_leave_entitlements", {
      _user_id: data.userId,
      _ev: data.ev,
    });
    if (error) throw new Error(error.message);
    return { ok: true as const };
  });

export const recalcLeaveTenant = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { ev: number }) => d)
  .handler(async ({ data, context }) => {
    const sb = context.supabase as SB;
    const { tenantId } = await requirePerm(sb, context.userId, "manage_leave");
    const { data: profiles, error } = await sb
      .from("profiles")
      .select("id")
      .eq("tenant_id", tenantId);
    if (error) throw new Error(error.message);
    const list = (profiles ?? []) as Array<{ id: string }>;
    let done = 0;
    let failed = 0;
    for (const p of list) {
      const { error: e2 } = await sb.rpc("recalc_leave_entitlements", {
        _user_id: p.id,
        _ev: data.ev,
      });
      if (!e2) done++;
      else failed++;
    }
    await logAudit(sb, tenantId, context.userId, "recalc_tenant", {
      ev: data.ev,
      summary: `Újraszámolás – ${done}/${list.length} sikeres, ${failed} hibás`,
      after: { done, failed, total: list.length },
    });
    return { ok: true as const, count: done, failed, total: list.length };
  });

export const closeLeaveYear = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { ev: number }) => d)
  .handler(async ({ data, context }) => {
    const sb = context.supabase as SB;
    const { tenantId } = await requirePerm(sb, context.userId, "manage_leave");
    const { data: cnt, error } = await sb.rpc("close_leave_year", {
      _tenant: tenantId,
      _ev: data.ev,
      _actor: context.userId,
    });
    if (error) throw new Error(error.message);

    const { data: logs } = await sb
      .from("leave_carryover_log")
      .select("user_id, jogcim, nap, tipus")
      .eq("tenant_id", tenantId)
      .eq("from_year", data.ev)
      .gte("created_at", new Date(Date.now() - 60_000).toISOString());

    const byUser = new Map<string, Array<{ jogcim: string; athozott: number; elveszett: number }>>();
    for (const l of (logs ?? []) as Array<{ user_id: string; jogcim: string; nap: number; tipus: string }>) {
      const arr = byUser.get(l.user_id) ?? [];
      let row = arr.find((r) => r.jogcim === (JOGCIM_LABEL[l.jogcim] ?? l.jogcim));
      if (!row) {
        row = { jogcim: JOGCIM_LABEL[l.jogcim] ?? l.jogcim, athozott: 0, elveszett: 0 };
        arr.push(row);
      }
      if (l.tipus === "carryover") row.athozott += Number(l.nap);
      else if (l.tipus === "forfeit") row.elveszett += Number(l.nap);
      byUser.set(l.user_id, arr);
    }

    const { notifyCarryoverFinalized } = await import("./leave-notify.server");
    await notifyCarryoverFinalized(sb, {
      tenantId,
      fromYear: data.ev,
      toYear: data.ev + 1,
      byUser,
    });

    await logAudit(sb, tenantId, context.userId, "close_year", {
      ev: data.ev,
      summary: `Évzárás ${data.ev} → ${data.ev + 1}: ${cnt as number} egyenleg lezárva, ${byUser.size} dolgozó értesítve`,
      after: { closed_rows: cnt, notified_users: byUser.size },
    });
    return { ok: true as const, count: (cnt as number) ?? 0, notified: byUser.size };
  });

export type EnforceRow = {
  user_id: string;
  jogcim: string;
  nap: number;
  kezdo: string;
  zaro: string;
  applied: boolean;
};

export type EnforceSummary = {
  total_days: number;
  affected_users: number;
  by_jogcim: Record<string, number>;
  by_user: Array<{ user_id: string; name: string; total: number; jogcims: Record<string, number> }>;
};

export const enforceForcedLeave = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { ev: number; dryRun?: boolean }) => d)
  .handler(async ({ data, context }) => {
    const sb = context.supabase as SB;
    const { tenantId } = await requirePerm(sb, context.userId, "manage_leave");
    const dryRun = data.dryRun ?? false;
    const { data: rows, error } = await sb.rpc("enforce_forced_leave_takeout", {
      _tenant: tenantId,
      _ev: data.ev,
      _actor: context.userId,
      _dry_run: dryRun,
    });
    if (error) throw new Error(error.message);
    const list = (rows ?? []) as EnforceRow[];

    const userIds = Array.from(new Set(list.map((r) => r.user_id)));
    const { data: profs } = userIds.length
      ? await sb.from("profiles").select("id, teljes_nev").in("id", userIds)
      : { data: [] as Array<{ id: string; teljes_nev: string }> };
    const nameMap = new Map<string, string>(
      ((profs ?? []) as Array<{ id: string; teljes_nev: string }>).map((p) => [p.id, p.teljes_nev]),
    );

    const summary: EnforceSummary = {
      total_days: 0,
      affected_users: userIds.length,
      by_jogcim: {},
      by_user: [],
    };
    const userAgg = new Map<string, { total: number; jogcims: Record<string, number> }>();
    for (const r of list) {
      summary.total_days += Number(r.nap);
      const jLabel = JOGCIM_LABEL[r.jogcim] ?? r.jogcim;
      summary.by_jogcim[jLabel] = (summary.by_jogcim[jLabel] ?? 0) + Number(r.nap);
      const u = userAgg.get(r.user_id) ?? { total: 0, jogcims: {} };
      u.total += Number(r.nap);
      u.jogcims[jLabel] = (u.jogcims[jLabel] ?? 0) + Number(r.nap);
      userAgg.set(r.user_id, u);
    }
    summary.by_user = Array.from(userAgg.entries()).map(([uid, v]) => ({
      user_id: uid,
      name: nameMap.get(uid) ?? uid.slice(0, 8),
      total: Number(v.total.toFixed(2)),
      jogcims: v.jogcims,
    }));

    if (!dryRun && list.length > 0) {
      const itemsByUser = new Map<string, EnforceRow[]>();
      for (const r of list) {
        const arr = itemsByUser.get(r.user_id) ?? [];
        arr.push(r);
        itemsByUser.set(r.user_id, arr);
      }
      const { notifyForcedTakeoutFinalized } = await import("./leave-notify.server");
      await notifyForcedTakeoutFinalized(sb, {
        tenantId,
        ev: data.ev,
        itemsByUser,
        nameMap,
      });
    }

    await logAudit(sb, tenantId, context.userId, dryRun ? "enforce_dry_run" : "enforce_apply", {
      ev: data.ev,
      nap: summary.total_days,
      summary: `${dryRun ? "Dry run" : "Véglegesítés"}: ${summary.affected_users} dolgozó, ${summary.total_days.toFixed(1)} nap`,
      after: summary as unknown,
    });

    return { ok: true as const, rows: list, summary };
  });

export const listLeaveAudit = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { ev?: number; limit?: number }) => d)
  .handler(async ({ data, context }) => {
    const sb = context.supabase as SB;
    await requirePerm(sb, context.userId, "manage_leave");
    let q = sb
      .from("leave_admin_audit")
      .select("id, actor_user_id, action, ev, target_user_id, jogcim, nap, before_data, after_data, summary, created_at")
      .order("created_at", { ascending: false })
      .limit(Math.min(data.limit ?? 100, 500));
    if (data.ev) q = q.eq("ev", data.ev);
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);

    type AuditRow = {
      id: string;
      actor_user_id: string | null;
      action: string;
      ev: number | null;
      target_user_id: string | null;
      jogcim: string | null;
      nap: number | null;
      before_data: string | null;
      after_data: string | null;
      summary: string | null;
      created_at: string;
      actor_name?: string | null;
      target_name?: string | null;
    };
    const list = ((rows ?? []) as Array<Record<string, unknown>>).map((r) => ({
      ...r,
      before_data: r.before_data == null ? null : JSON.stringify(r.before_data),
      after_data: r.after_data == null ? null : JSON.stringify(r.after_data),
    })) as AuditRow[];
    const userIds = Array.from(
      new Set(list.flatMap((r) => [r.actor_user_id, r.target_user_id]).filter((x): x is string => !!x)),
    );
    const { data: profs } = userIds.length
      ? await sb.from("profiles").select("id, teljes_nev").in("id", userIds)
      : { data: [] as Array<{ id: string; teljes_nev: string }> };
    const nameMap = new Map<string, string>(
      ((profs ?? []) as Array<{ id: string; teljes_nev: string }>).map((p) => [p.id, p.teljes_nev]),
    );
    return {
      rows: list.map((r) => ({
        ...r,
        actor_name: r.actor_user_id ? nameMap.get(r.actor_user_id) ?? null : null,
        target_name: r.target_user_id ? nameMap.get(r.target_user_id) ?? null : null,
      })),
    };
  });

export const upsertLeavePolicy = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { policy: Record<string, unknown>; ev: number }) => d)
  .handler(async ({ data, context }) => {
    const sb = context.supabase as SB;
    const { tenantId } = await requirePerm(sb, context.userId, "manage_leave");

    const { data: before } = await sb
      .from("leave_policy")
      .select("*")
      .eq("tenant_id", tenantId)
      .eq("ev", data.ev)
      .maybeSingle();

    const payload: Record<string, unknown> = { ...data.policy, tenant_id: tenantId, ev: data.ev };
    const { error } = await sb
      .from("leave_policy")
      .upsert(payload, { onConflict: "tenant_id,ev" });
    if (error) throw new Error(error.message);

    await logAudit(sb, tenantId, context.userId, "policy_update", {
      ev: data.ev,
      summary: before ? `Szabályzat módosítva (${data.ev})` : `Szabályzat létrehozva (${data.ev})`,
      before: (before ?? null) as unknown,
      after: payload as unknown,
    });
    return { ok: true as const };
  });

function csvEscape(v: unknown): string {
  const s = v == null ? "" : String(v);
  if (s.includes(",") || s.includes('"') || s.includes("\n")) {
    return `"${s.replace(/"/g, '""')}"`;
  }
  return s;
}

export const exportLeaveBalanceCsv = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { userId?: string; ev: number }) => d)
  .handler(async ({ data, context }) => {
    const sb = context.supabase as SB;
    const targetUserId = data.userId ?? context.userId;
    if (targetUserId !== context.userId) {
      await requirePerm(sb, context.userId, "manage_leave");
    }
    const { data: ents, error } = await sb
      .from("leave_entitlement")
      .select("*")
      .eq("user_id", targetUserId)
      .eq("ev", data.ev)
      .order("jogcim");
    if (error) throw new Error(error.message);
    const header = ["jogcim", "jaro_nap", "manual_korrekcio", "athozott_nap", "kiadott_nap", "terv_nap", "forced_taken_nap", "hatralevo"];
    const lines = [header.join(",")];
    for (const r of (ents ?? []) as Array<Record<string, unknown>>) {
      lines.push(header.map((h) => csvEscape(r[h])).join(","));
    }
    return { csv: lines.join("\n"), filename: `szabadsag-egyenleg-${data.ev}.csv` };
  });

export const exportLeavePlanCsv = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { ev: number }) => d)
  .handler(async ({ data, context }) => {
    const sb = context.supabase as SB;
    const { tenantId } = await requirePerm(sb, context.userId, "manage_leave");
    const { data: rows, error } = await sb.rpc("enforce_forced_leave_takeout", {
      _tenant: tenantId,
      _ev: data.ev,
      _actor: context.userId,
      _dry_run: true,
    });
    if (error) throw new Error(error.message);
    const list = (rows ?? []) as EnforceRow[];
    const userIds = Array.from(new Set(list.map((r) => r.user_id)));
    const { data: profs } = userIds.length
      ? await sb.from("profiles").select("id, teljes_nev").in("id", userIds)
      : { data: [] as Array<{ id: string; teljes_nev: string }> };
    const nameMap = new Map<string, string>(
      ((profs ?? []) as Array<{ id: string; teljes_nev: string }>).map((p) => [p.id, p.teljes_nev]),
    );
    const header = ["dolgozo", "jogcim", "nap", "kezdo", "zaro"];
    const lines = [header.join(",")];
    for (const r of list) {
      lines.push(
        [
          csvEscape(nameMap.get(r.user_id) ?? r.user_id),
          csvEscape(JOGCIM_LABEL[r.jogcim] ?? r.jogcim),
          csvEscape(r.nap),
          csvEscape(r.kezdo),
          csvEscape(r.zaro),
        ].join(","),
      );
    }
    return { csv: lines.join("\n"), filename: `kenyszerkiadasi-terv-${data.ev}.csv` };
  });

function toBase64(bytes: Uint8Array): string {
  let s = "";
  for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
  return btoa(s);
}

export const generateLeaveBalancePdf = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { userId?: string; ev: number }) => d)
  .handler(async ({ data, context }) => {
    const sb = context.supabase as SB;
    const targetUserId = data.userId ?? context.userId;
    if (targetUserId !== context.userId) {
      await requirePerm(sb, context.userId, "manage_leave");
    }
    const [{ data: ents }, { data: prof }] = await Promise.all([
      sb
        .from("leave_entitlement")
        .select("*")
        .eq("user_id", targetUserId)
        .eq("ev", data.ev)
        .order("jogcim"),
      sb.from("profiles").select("teljes_nev").eq("id", targetUserId).maybeSingle(),
    ]);
    const rows = ((ents ?? []) as Array<Record<string, number | string>>).map((e) => ({
      jogcim: JOGCIM_LABEL[String(e.jogcim)] ?? String(e.jogcim),
      jaro: Number(e.jaro_nap),
      korr: Number(e.manual_korrekcio),
      athozott: Number(e.athozott_nap),
      kiadott: Number(e.kiadott_nap),
      terv: Number(e.terv_nap),
      forced: Number(e.forced_taken_nap),
      hatralevo: Number(e.hatralevo),
    }));
    const total = rows.reduce(
      (acc, r) => ({
        jaro: acc.jaro + r.jaro + r.korr,
        athozott: acc.athozott + r.athozott,
        kiadott: acc.kiadott + r.kiadott,
        hatralevo: acc.hatralevo + r.hatralevo,
      }),
      { jaro: 0, athozott: 0, kiadott: 0, hatralevo: 0 },
    );
    const { renderBalancePdf } = await import("./leave-pdf.server");
    const bytes = await renderBalancePdf({
      title: `Szabadság-egyenleg ${data.ev}`,
      subtitle: `${(prof as { teljes_nev?: string } | null)?.teljes_nev ?? targetUserId} · ${new Date().toISOString().slice(0, 10)}`,
      rows,
      total,
    });
    return { pdf: toBase64(bytes), filename: `szabadsag-egyenleg-${data.ev}.pdf` };
  });

export const generateLeavePlanPdf = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { ev: number }) => d)
  .handler(async ({ data, context }) => {
    const sb = context.supabase as SB;
    const { tenantId } = await requirePerm(sb, context.userId, "manage_leave");
    const { data: rows, error } = await sb.rpc("enforce_forced_leave_takeout", {
      _tenant: tenantId,
      _ev: data.ev,
      _actor: context.userId,
      _dry_run: true,
    });
    if (error) throw new Error(error.message);
    const list = (rows ?? []) as EnforceRow[];
    const userIds = Array.from(new Set(list.map((r) => r.user_id)));
    const { data: profs } = userIds.length
      ? await sb.from("profiles").select("id, teljes_nev").in("id", userIds)
      : { data: [] as Array<{ id: string; teljes_nev: string }> };
    const nameMap = new Map<string, string>(
      ((profs ?? []) as Array<{ id: string; teljes_nev: string }>).map((p) => [p.id, p.teljes_nev]),
    );

    const { renderPlanPdf } = await import("./leave-pdf.server");
    const bytes = await renderPlanPdf({
      title: `Kényszerkiadási terv ${data.ev}`,
      subtitle: `Készült: ${new Date().toISOString().slice(0, 16).replace("T", " ")} · ${list.length} sor`,
      rows: list.map((r) => ({
        user: nameMap.get(r.user_id) ?? r.user_id,
        jogcim: JOGCIM_LABEL[r.jogcim] ?? r.jogcim,
        nap: Number(r.nap),
        kezdo: r.kezdo,
        zaro: r.zaro,
      })),
    });
    return { pdf: toBase64(bytes), filename: `kenyszerkiadasi-terv-${data.ev}.pdf` };
  });
