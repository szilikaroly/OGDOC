/**
 * Szabadság-modul értesítő helperek.
 * server-only modul – csak server function-ből hívható.
 */
import { renderForcedTakeoutHtml } from "@/lib/email-templates/forced-takeout";
import { renderCarryoverHtml } from "@/lib/email-templates/carryover-notice";
import { sendEmail } from "@/lib/email/send.server";

const JOGCIM_LABEL: Record<string, string> = {
  alap: "Alapszabadság",
  eletkor: "Életkori pótszabadság",
  gyermek: "Gyermek után járó",
  vezetoi: "Vezetői pótszabadság",
  oktatoi: "Oktatói pótszabadság",
  sugar: "Sugárterhelési pótszabadság",
  apasagi: "Apasági szabadság",
  szuloi: "Szülői szabadság",
  tanulmanyi: "Tanulmányi szabadság",
  egyeb_pot: "Egyéb pótszabadság",
};

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type SupabaseLike = any;

async function getUserEmails(supabase: SupabaseLike, userIds: string[]): Promise<Map<string, string>> {
  if (!userIds.length) return new Map();
  const out = new Map<string, string>();
  try {
    const { data } = await supabase
      .from("profile_contacts")
      .select("user_id, ertek, tipus")
      .in("user_id", userIds)
      .eq("tipus", "email");
    for (const r of (data ?? []) as Array<{ user_id: string; ertek: string }>) {
      if (!out.has(r.user_id) && r.ertek) out.set(r.user_id, r.ertek);
    }
  } catch {
    // contacts table optional
  }
  return out;
}

async function getProfilesById(
  supabase: SupabaseLike,
  userIds: string[],
): Promise<Map<string, { teljes_nev: string; tenant_id: string }>> {
  if (!userIds.length) return new Map();
  const { data } = await supabase
    .from("profiles")
    .select("id, teljes_nev, tenant_id")
    .in("id", userIds);
  return new Map(
    ((data ?? []) as Array<{ id: string; teljes_nev: string; tenant_id: string }>).map((p) => [p.id, { teljes_nev: p.teljes_nev, tenant_id: p.tenant_id }]),
  );
}

export async function notifyForcedTakeoutFinalized(
  supabase: SupabaseLike,
  opts: {
    tenantId: string;
    ev: number;
    itemsByUser: Map<string, Array<{ jogcim: string; nap: number; kezdo: string; zaro: string }>>;
    nameMap: Map<string, string>;
    deadlineMmDd?: string;
  },
): Promise<void> {
  const userIds = Array.from(opts.itemsByUser.keys());
  const profMap = await getProfilesById(supabase, userIds);
  const emailMap = await getUserEmails(supabase, userIds);
  const notifRows: Array<{ tenant_id: string; user_id: string; tipus: string; cim: string; uzenet: string; link: string }> = [];

  for (const [uid, items] of opts.itemsByUser.entries()) {
    const napok = items.reduce((s, i) => s + Number(i.nap), 0);
    const cim = `Kötelező szabadság kiadás – ${opts.ev}`;
    const uzenet = `${napok.toFixed(1)} nap szabadság kötelező kiadásra került ${items.length} időszakban (${opts.ev + 1}. ${opts.deadlineMmDd ?? "01-30"} határidő miatt).`;
    notifRows.push({
      tenant_id: opts.tenantId,
      user_id: uid,
      tipus: "warning",
      cim,
      uzenet,
      link: "/szabadsag",
    });

    const email = emailMap.get(uid);
    if (email) {
      const html = renderForcedTakeoutHtml({
        name: opts.nameMap.get(uid) ?? profMap.get(uid)?.teljes_nev ?? "Munkatárs",
        ev: opts.ev,
        deadlineMmDd: opts.deadlineMmDd ?? "01-30",
        items: items.map((i) => ({
          kezdo: i.kezdo,
          zaro: i.zaro,
          nap: Number(i.nap),
          jogcim: JOGCIM_LABEL[i.jogcim] ?? i.jogcim,
          forrasev: opts.ev,
        })),
        reason: "Az előző évi ki nem vett szabadság kiadása a Mt. határidő miatt kötelező.",
      });
      // best-effort
      await sendEmail({ to: email, subject: cim, html });
    }
  }

  if (notifRows.length) {
    await supabase.from("notifications").insert(notifRows);
  }
}

export async function notifyCarryoverFinalized(
  supabase: SupabaseLike,
  opts: {
    tenantId: string;
    fromYear: number;
    toYear: number;
    byUser: Map<string, Array<{ jogcim: string; athozott: number; elveszett: number }>>;
    deadlineMmDd?: string;
  },
): Promise<void> {
  const userIds = Array.from(opts.byUser.keys());
  const profMap = await getProfilesById(supabase, userIds);
  const emailMap = await getUserEmails(supabase, userIds);
  const notifRows: Array<{ tenant_id: string; user_id: string; tipus: string; cim: string; uzenet: string; link: string }> = [];

  for (const [uid, items] of opts.byUser.entries()) {
    const totalAt = items.reduce((s, i) => s + i.athozott, 0);
    const totalEl = items.reduce((s, i) => s + i.elveszett, 0);
    const cim = `Szabadság áthozat: ${opts.fromYear} → ${opts.toYear}`;
    const uzenet = `${totalAt.toFixed(1)} nap áthozva${totalEl > 0 ? `, ${totalEl.toFixed(1)} nap elveszett az Mt. 123. § korlát miatt` : ""}. Kiadási határidő: ${opts.toYear}. ${opts.deadlineMmDd ?? "01-30"}.`;
    notifRows.push({
      tenant_id: opts.tenantId,
      user_id: uid,
      tipus: "info",
      cim,
      uzenet,
      link: "/szabadsag",
    });

    const email = emailMap.get(uid);
    if (email) {
      const html = renderCarryoverHtml({
        name: profMap.get(uid)?.teljes_nev ?? "Munkatárs",
        fromYear: opts.fromYear,
        toYear: opts.toYear,
        deadlineMmDd: opts.deadlineMmDd ?? "01-30",
        items,
      });
      await sendEmail({ to: email, subject: cim, html });
    }
  }

  if (notifRows.length) {
    await supabase.from("notifications").insert(notifRows);
  }
}
