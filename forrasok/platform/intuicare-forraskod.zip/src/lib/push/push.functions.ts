import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const SaveInput = z.object({
  endpoint: z.string().url(),
  p256dh: z.string().min(1),
  auth: z.string().min(1),
  user_agent: z.string().optional().nullable(),
});

/** Web Push subscription mentése a bejelentkezett felhasználóhoz. */
export const savePushSubscription = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => SaveInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { error } = await supabase
      .from("push_subscriptions")
      .upsert(
        {
          user_id: userId,
          endpoint: data.endpoint,
          p256dh: data.p256dh,
          auth: data.auth,
          user_agent: data.user_agent ?? null,
          last_used_at: new Date().toISOString(),
        },
        { onConflict: "endpoint" },
      );
    if (error) throw new Error(error.message);
    return { ok: true };
  });

const RemoveInput = z.object({ endpoint: z.string().url() });
export const deletePushSubscription = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => RemoveInput.parse(d))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("push_subscriptions")
      .delete()
      .eq("endpoint", data.endpoint)
      .eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/** Kliensoldali public VAPID kulcs visszaadása (publishable). */
export const getVapidPublicKey = createServerFn({ method: "GET" }).handler(async () => {
  return { publicKey: process.env.VAPID_PUBLIC_KEY ?? "" };
});

// ============= Admin: VAPID subject + push enabled =============

export type PushAdminSettings = {
  tenant_id: string;
  vapid_subject: string;
  enabled: boolean;
  updated_at: string;
  has_public_key: boolean;
  has_private_key: boolean;
};

async function ensureAdmin(supabase: any, userId: string): Promise<void> {
  const { data, error } = await supabase.rpc("has_any_role", {
    _user_id: userId,
    _role_kulcsok: ["tenant_admin", "igazgato"],
  });
  if (error) throw error;
  if (!data) throw new Error("Forbidden");
}

async function getTenantId(supabase: any, userId: string): Promise<string> {
  const { data } = await supabase
    .from("user_roles")
    .select("tenant_id")
    .eq("user_id", userId)
    .not("tenant_id", "is", null)
    .limit(1)
    .maybeSingle();
  if (data?.tenant_id) return data.tenant_id as string;
  const { data: t } = await supabase.from("tenants").select("id").eq("aktiv", true).limit(1).maybeSingle();
  if (!t?.id) throw new Error("Nincs elérhető tenant");
  return t.id as string;
}

export const getPushAdminSettings = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<PushAdminSettings> => {
    const { supabase, userId } = context as any;
    await ensureAdmin(supabase, userId);
    const tenantId = await getTenantId(supabase, userId);

    const { data, error } = await supabase
      .from("push_settings" as any)
      .select("*")
      .eq("tenant_id", tenantId)
      .maybeSingle();
    if (error) throw error;

    let row = data as any;
    if (!row) {
      const { data: created, error: insErr } = await supabase
        .from("push_settings" as any)
        .insert({ tenant_id: tenantId, updated_by: userId })
        .select("*")
        .single();
      if (insErr) throw insErr;
      row = created;
    }

    return {
      tenant_id: row.tenant_id,
      vapid_subject: row.vapid_subject,
      enabled: row.enabled,
      updated_at: row.updated_at,
      has_public_key: Boolean(process.env.VAPID_PUBLIC_KEY),
      has_private_key: Boolean(process.env.VAPID_PRIVATE_KEY),
    };
  });

const subjectSchema = z
  .string()
  .trim()
  .min(7)
  .refine((s) => /^mailto:[^\s@]+@[^\s@]+\.[^\s@]+$/i.test(s) || /^https:\/\/[^\s]+$/i.test(s), {
    message: "A subject mailto: vagy https:// formátumú lehet",
  });

export const updatePushAdminSettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({
      vapid_subject: subjectSchema.optional(),
      enabled: z.boolean().optional(),
    }).parse(d),
  )
  .handler(async ({ data, context }): Promise<PushAdminSettings> => {
    const { supabase, userId } = context as any;
    await ensureAdmin(supabase, userId);
    const tenantId = await getTenantId(supabase, userId);

    const patch: Record<string, unknown> = { updated_by: userId, updated_at: new Date().toISOString() };
    if (data.vapid_subject !== undefined) patch.vapid_subject = data.vapid_subject;
    if (data.enabled !== undefined) patch.enabled = data.enabled;

    const { data: updated, error } = await supabase
      .from("push_settings" as any)
      .upsert({ tenant_id: tenantId, ...patch }, { onConflict: "tenant_id" })
      .select("*")
      .single();
    if (error) throw error;

    return {
      tenant_id: (updated as any).tenant_id,
      vapid_subject: (updated as any).vapid_subject,
      enabled: (updated as any).enabled,
      updated_at: (updated as any).updated_at,
      has_public_key: Boolean(process.env.VAPID_PUBLIC_KEY),
      has_private_key: Boolean(process.env.VAPID_PRIVATE_KEY),
    };
  });
