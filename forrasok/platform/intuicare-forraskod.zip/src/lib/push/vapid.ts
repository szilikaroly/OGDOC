// VAPID public key for browser Web Push subscription.
// Safe to expose to the client — the private key is server-only (VAPID_PRIVATE_KEY secret).
export const VAPID_PUBLIC_KEY =
  "BBuIA3UL1HR-QaNh0PB072axuBgtoYHXm8rvNifbB7z8jxWc066oVXl4RsnlAYZ06hRilGnYatpathEasY-XqHs";

export function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const rawData = atob(base64);
  const output = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) output[i] = rawData.charCodeAt(i);
  return output;
}
