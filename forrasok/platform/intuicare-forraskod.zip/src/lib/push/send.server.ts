// Server-only Web Push helper. Sends a push to all subscriptions for the given user(s).
import webpush from "web-push";
import { VAPID_PUBLIC_KEY } from "@/lib/push/vapid";

let configured = false;
function configure() {
  if (configured) return;
  const priv = process.env.VAPID_PRIVATE_KEY;
  const subject = process.env.VAPID_SUBJECT ?? "mailto:notify@sos-24.hu";
  if (!priv) throw new Error("VAPID_PRIVATE_KEY missing");
  webpush.setVapidDetails(subject, VAPID_PUBLIC_KEY, priv);
  configured = true;
}

export type PushPayload = {
  title: string;
  body: string;
  url?: string;
  tag?: string;
};

export type PushSubscriptionRow = {
  id: string;
  endpoint: string;
  p256dh: string;
  auth: string;
};

export async function sendPushToSubscriptions(
  subs: PushSubscriptionRow[],
  payload: PushPayload,
): Promise<{ sent: number; gone: string[]; failed: number }> {
  configure();
  const gone: string[] = [];
  let sent = 0;
  let failed = 0;
  await Promise.all(
    subs.map(async (s) => {
      try {
        await webpush.sendNotification(
          { endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } },
          JSON.stringify(payload),
          { TTL: 3600 },
        );
        sent++;
      } catch (e: unknown) {
        const status = (e as { statusCode?: number }).statusCode;
        if (status === 404 || status === 410) gone.push(s.endpoint);
        else failed++;
      }
    }),
  );
  return { sent, gone, failed };
}
