/**
 * Web Push küldő (server-only). VAPID JWT-t Web Crypto API-val gyártja,
 * AES128GCM payload titkosítást használ. Workerd / Cloudflare-kompatibilis.
 *
 * Szükséges env változók (Lovable Cloud secrets):
 *   - VAPID_PUBLIC_KEY  (base64url, ~88 char)
 *   - VAPID_PRIVATE_KEY (base64url, ~43 char)
 *   - VAPID_SUBJECT     (mailto:admin@example.com vagy https://example.com)
 *
 * Hiányzó konfigurációnál a küldés csendben no-op (in-app toast/realtime
 * marad a fallback) — így a build és a triage flow nem törik el.
 */

function b64urlEncode(buf: ArrayBuffer | Uint8Array): string {
  const bytes = buf instanceof Uint8Array ? buf : new Uint8Array(buf as ArrayBuffer);
  let bin = "";
  for (let i = 0; i < bytes.byteLength; i++) bin += String.fromCharCode(bytes[i]);
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function b64urlDecode(s: string): Uint8Array {
  const pad = s.length % 4 === 0 ? "" : "=".repeat(4 - (s.length % 4));
  const b64 = (s + pad).replace(/-/g, "+").replace(/_/g, "/");
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

async function importVapidKey(privateKeyB64u: string, publicKeyB64u: string) {
  // JWK ES256 import
  const d = b64urlEncode(b64urlDecode(privateKeyB64u));
  const pub = b64urlDecode(publicKeyB64u); // 65 bytes uncompressed (0x04 || X || Y)
  if (pub.length !== 65 || pub[0] !== 0x04) throw new Error("VAPID public key must be 65-byte uncompressed");
  const x = b64urlEncode(pub.slice(1, 33));
  const y = b64urlEncode(pub.slice(33, 65));
  return crypto.subtle.importKey(
    "jwk",
    { kty: "EC", crv: "P-256", x, y, d, ext: true } as JsonWebKey,
    { name: "ECDSA", namedCurve: "P-256" },
    false,
    ["sign"],
  );
}

async function buildVapidJwt(audience: string, subject: string, privKey: string, pubKey: string): Promise<string> {
  const header = { typ: "JWT", alg: "ES256" };
  const payload = { aud: audience, exp: Math.floor(Date.now() / 1000) + 12 * 3600, sub: subject };
  const enc = new TextEncoder();
  const input = `${b64urlEncode(enc.encode(JSON.stringify(header)))}.${b64urlEncode(enc.encode(JSON.stringify(payload)))}`;
  const key = await importVapidKey(privKey, pubKey);
  const sig = await crypto.subtle.sign({ name: "ECDSA", hash: "SHA-256" }, key, enc.encode(input));
  return `${input}.${b64urlEncode(sig)}`;
}

/* ---------- AES128GCM payload encryption (RFC 8291) ---------- */

async function hkdf(salt: Uint8Array, ikm: Uint8Array, info: Uint8Array, length: number): Promise<Uint8Array> {
  const baseKey = await crypto.subtle.importKey("raw", ikm as unknown as BufferSource, "HKDF", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "HKDF", hash: "SHA-256", salt: salt as unknown as BufferSource, info: info as unknown as BufferSource },
    baseKey,
    length * 8,
  );
  return new Uint8Array(bits);
}

async function encryptPayload(
  payload: string,
  uaPublicKeyB64u: string,
  authSecretB64u: string,
): Promise<{ ciphertext: Uint8Array; serverPublicKey: Uint8Array; salt: Uint8Array }> {
  const uaPublic = b64urlDecode(uaPublicKeyB64u);
  const authSecret = b64urlDecode(authSecretB64u);

  // Server ECDH keypair
  const serverKp = (await crypto.subtle.generateKey(
    { name: "ECDH", namedCurve: "P-256" },
    true,
    ["deriveBits"],
  )) as CryptoKeyPair;
  const serverPubRaw = new Uint8Array(await crypto.subtle.exportKey("raw", serverKp.publicKey));

  const uaPubKey = await crypto.subtle.importKey(
    "raw", uaPublic as unknown as BufferSource, { name: "ECDH", namedCurve: "P-256" }, false, [],
  );
  const sharedBits = await crypto.subtle.deriveBits({ name: "ECDH", public: uaPubKey }, serverKp.privateKey, 256);
  const ecdh = new Uint8Array(sharedBits);

  const enc = new TextEncoder();
  const keyInfo = new Uint8Array([
    ...enc.encode("WebPush: info\0"),
    ...uaPublic,
    ...serverPubRaw,
  ]);
  const ikm = await hkdf(authSecret, ecdh, keyInfo, 32);

  const salt = crypto.getRandomValues(new Uint8Array(16));
  const cek = await hkdf(salt, ikm, enc.encode("Content-Encoding: aes128gcm\0"), 16);
  const nonce = await hkdf(salt, ikm, enc.encode("Content-Encoding: nonce\0"), 12);

  // header: salt(16) | rs(4=4096) | idlen(1) | keyid(serverPub 65)
  const rs = 4096;
  const header = new Uint8Array(16 + 4 + 1 + 65);
  header.set(salt, 0);
  new DataView(header.buffer).setUint32(16, rs);
  header[20] = 65;
  header.set(serverPubRaw, 21);

  // body: payload || 0x02 (last record padding delimiter)
  const data = enc.encode(payload);
  const padded = new Uint8Array(data.length + 1);
  padded.set(data, 0);
  padded[data.length] = 0x02;

  const cekKey = await crypto.subtle.importKey("raw", cek as unknown as BufferSource, { name: "AES-GCM" }, false, ["encrypt"]);
  const ct = new Uint8Array(
    await crypto.subtle.encrypt({ name: "AES-GCM", iv: nonce as unknown as BufferSource }, cekKey, padded as unknown as BufferSource),
  );

  const full = new Uint8Array(header.length + ct.length);
  full.set(header, 0);
  full.set(ct, header.length);

  return { ciphertext: full, serverPublicKey: serverPubRaw, salt };
}

export type PushSubRow = {
  endpoint: string;
  p256dh: string;
  auth: string;
};

export type PushPayload = {
  title: string;
  body?: string;
  url?: string;
  tag?: string;
  icon?: string;
};

/** Egyetlen subscription kiszolgálása. Hiba esetén false-t ad vissza. */
async function resolveVapidSubject(): Promise<string | null> {
  // DB-bol olvas elsodlegesen (admin-bol szerkezheto), env csak fallback.
  try {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data } = await supabaseAdmin
      .from("push_settings" as any)
      .select("vapid_subject, enabled")
      .limit(1)
      .maybeSingle();
    if (data && (data as any).enabled === false) return null;
    if (data && (data as any).vapid_subject) return (data as any).vapid_subject as string;
  } catch {
    // ignored — env fallback
  }
  return process.env.VAPID_SUBJECT ?? null;
}

export async function sendWebPush(sub: PushSubRow, payload: PushPayload): Promise<{ ok: boolean; status?: number; error?: string; gone?: boolean }> {
  const pub = process.env.VAPID_PUBLIC_KEY;
  const priv = process.env.VAPID_PRIVATE_KEY;
  const sub_ = await resolveVapidSubject();
  if (!pub || !priv || !sub_) return { ok: false, error: "VAPID config missing" };


  try {
    const url = new URL(sub.endpoint);
    const audience = `${url.protocol}//${url.host}`;
    const jwt = await buildVapidJwt(audience, sub_, priv, pub);

    const { ciphertext } = await encryptPayload(JSON.stringify(payload), sub.p256dh, sub.auth);

    const res = await fetch(sub.endpoint, {
      method: "POST",
      headers: {
        "Content-Encoding": "aes128gcm",
        "Content-Type": "application/octet-stream",
        "TTL": "86400",
        "Authorization": `vapid t=${jwt}, k=${pub}`,
        "Content-Length": String(ciphertext.length),
      },
      body: ciphertext as unknown as BodyInit,
    });
    if (res.status === 201 || res.status === 200 || res.status === 202) return { ok: true, status: res.status };
    if (res.status === 404 || res.status === 410) return { ok: false, status: res.status, gone: true };
    return { ok: false, status: res.status, error: await res.text().catch(() => "") };
  } catch (e: any) {
    return { ok: false, error: e?.message ?? String(e) };
  }
}

/**
 * Push küldése egy adott userId-hoz tartozó összes subscription-re.
 * supabaseAdmin-t használ (RLS bypass) — kizárólag verifikált flow-ból hívható.
 */
export async function pushToUser(userId: string, payload: PushPayload): Promise<{ sent: number; failed: number; pruned: number }> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data: subs } = await supabaseAdmin
    .from("push_subscriptions")
    .select("endpoint, p256dh, auth")
    .eq("user_id", userId);
  if (!subs || subs.length === 0) return { sent: 0, failed: 0, pruned: 0 };

  let sent = 0, failed = 0, pruned = 0;
  await Promise.all(
    subs.map(async (s) => {
      const r = await sendWebPush(s as PushSubRow, payload);
      if (r.ok) sent++;
      else {
        failed++;
        if (r.gone) {
          await supabaseAdmin.from("push_subscriptions").delete().eq("endpoint", s.endpoint);
          pruned++;
        }
      }
    }),
  );
  return { sent, failed, pruned };
}
