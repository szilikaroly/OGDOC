// Phase 2 klinikai pontszámok — tiszta függvények, React-független.
// Források: ESC 2024 AF, KDIGO 2024, Wells/Geneva eredeti közlemények, Sepsis-3, NICE NEWS2, AAP APGAR, Bishop 1964.
// Csak döntéstámogatás — orvosi mérlegelést nem helyettesít.

export type Sex = "M" | "F";

// ───────────────────────────── CHA2DS2-VASc ─────────────────────────────
export type ChaInput = {
  age: number;
  sex: Sex;
  chf: boolean;
  hypertension: boolean;
  diabetes: boolean;
  stroke_tia_te: boolean;     // 2 pont
  vascular: boolean;          // MI, PAD, aorta plaque
};
export type ChaResult = {
  score: number;
  parts: Array<{ label: string; pts: number }>;
  annualStrokePct: number;
  recommendation: string;
};
const CHA_STROKE_PCT = [0.2, 0.6, 2.2, 3.2, 4.8, 7.2, 9.7, 11.2, 10.8, 12.2];
export function scoreCHA2DS2VASc(i: ChaInput): ChaResult {
  const parts: Array<{ label: string; pts: number }> = [];
  if (i.chf) parts.push({ label: "Pangásos szívelégtelenség", pts: 1 });
  if (i.hypertension) parts.push({ label: "Hipertónia", pts: 1 });
  if (i.age >= 75) parts.push({ label: "Életkor ≥ 75 év", pts: 2 });
  else if (i.age >= 65) parts.push({ label: "Életkor 65–74 év", pts: 1 });
  if (i.diabetes) parts.push({ label: "Diabétesz", pts: 1 });
  if (i.stroke_tia_te) parts.push({ label: "Stroke / TIA / thromboembolia", pts: 2 });
  if (i.vascular) parts.push({ label: "Érbetegség (MI, PAD, aorta plakk)", pts: 1 });
  if (i.sex === "F") parts.push({ label: "Női nem", pts: 1 });
  const score = parts.reduce((s, p) => s + p.pts, 0);
  const effective = i.sex === "F" ? Math.max(0, score - 1) : score; // ESC: nő ≥3, férfi ≥2
  let recommendation = "OAC nem javasolt.";
  if ((i.sex === "M" && score >= 2) || (i.sex === "F" && score >= 3)) {
    recommendation = "Tartós orális antikoaguláció (DOAC preferált, kivéve mech. billentyű / mod-súlyos MS).";
  } else if ((i.sex === "M" && score === 1) || (i.sex === "F" && score === 2)) {
    recommendation = "OAC mérlegelhető — egyéni rizikó (HAS-BLED, beteg preferencia).";
  }
  return {
    score,
    parts,
    annualStrokePct: CHA_STROKE_PCT[Math.min(effective, CHA_STROKE_PCT.length - 1)],
    recommendation,
  };
}

// ───────────────────────────── HAS-BLED ─────────────────────────────
export type HasBledInput = {
  hypertension_uncontrolled: boolean; // SBP > 160
  renal_abnormal: boolean;            // dialízis, transzplantáció, kreat > 200 µmol/L
  liver_abnormal: boolean;            // krón. hepatopathia / bilirubin > 2× / AST > 3×
  stroke_history: boolean;
  bleeding_history: boolean;
  labile_inr: boolean;                // VKA-n; <60% time-in-range
  age65_plus: boolean;
  drugs_antiplatelet_nsaid: boolean;
  alcohol_8plus_per_week: boolean;
};
export type HasBledResult = {
  score: number;
  parts: Array<{ label: string; pts: number }>;
  riskLabel: "alacsony" | "közepes" | "magas";
  annualBleedPct: number;
  note: string;
};
export function scoreHasBled(i: HasBledInput): HasBledResult {
  const map: Array<[boolean, string]> = [
    [i.hypertension_uncontrolled, "Hipertónia (SBP > 160 Hgmm)"],
    [i.renal_abnormal, "Vesefunkció zavar"],
    [i.liver_abnormal, "Májfunkció zavar"],
    [i.stroke_history, "Korábbi stroke"],
    [i.bleeding_history, "Vérzés anamnézis / hajlam"],
    [i.labile_inr, "Labilis INR (VKA mellett)"],
    [i.age65_plus, "Életkor > 65 év"],
    [i.drugs_antiplatelet_nsaid, "Vérzést fokozó szer (TAG / NSAID)"],
    [i.alcohol_8plus_per_week, "Alkohol ≥ 8 ital / hét"],
  ];
  const parts = map.filter(([v]) => v).map(([, l]) => ({ label: l, pts: 1 }));
  const score = parts.length;
  const annual = [1.13, 1.02, 1.88, 3.74, 8.7, 12.5][Math.min(score, 5)];
  const riskLabel = score >= 3 ? "magas" : score >= 2 ? "közepes" : "alacsony";
  return {
    score,
    parts,
    riskLabel,
    annualBleedPct: annual,
    note:
      score >= 3
        ? "Magas vérzéskockázat — nem kontraindikáció, de fokozott monitorozás és módosítható rizikók kezelése (BP, NSAID, alkohol)."
        : "Folytatható antikoaguláció a szokásos protokoll szerint.",
  };
}

// ───────────────────────────── CKD-EPI 2021 (race-free) ─────────────────────────────
export type CkdEpiInput = {
  age: number;
  sex: Sex;
  creatinine_umol_l: number;          // µmol/L
};
export type CkdEpiResult = {
  egfr: number;                       // ml/min/1,73 m²
  stage: "G1" | "G2" | "G3a" | "G3b" | "G4" | "G5";
  description: string;
  recommendation: string;
};
export function ckdEpi2021(i: CkdEpiInput): CkdEpiResult {
  // Convert µmol/L → mg/dL
  const scr = i.creatinine_umol_l / 88.4;
  const kappa = i.sex === "F" ? 0.7 : 0.9;
  const alpha = i.sex === "F" ? -0.241 : -0.302;
  const minPart = Math.pow(Math.min(scr / kappa, 1), alpha);
  const maxPart = Math.pow(Math.max(scr / kappa, 1), -1.2);
  const sexFactor = i.sex === "F" ? 1.012 : 1.0;
  const egfr = 142 * minPart * maxPart * Math.pow(0.9938, i.age) * sexFactor;
  let stage: CkdEpiResult["stage"] = "G1";
  let desc = "Normál vesefunkció";
  if (egfr < 15) { stage = "G5"; desc = "Veseelégtelenség (RRT mérlegelendő)"; }
  else if (egfr < 30) { stage = "G4"; desc = "Súlyos GFR-csökkenés"; }
  else if (egfr < 45) { stage = "G3b"; desc = "Mérsékelten súlyos GFR-csökkenés"; }
  else if (egfr < 60) { stage = "G3a"; desc = "Enyhe–mérsékelt GFR-csökkenés"; }
  else if (egfr < 90) { stage = "G2"; desc = "Enyhe GFR-csökkenés"; }
  let rec = "Évenkénti rutin kontroll.";
  if (stage === "G3a" || stage === "G3b") rec = "Nefrológiai konzílium mérlegelése, gyógyszerdózis-revízió, ACR és K+ ellenőrzés.";
  else if (stage === "G4") rec = "Nefrológiai gondozás kötelező, RRT előkészítés, ACEi/ARB + SGLT2i optimalizálás.";
  else if (stage === "G5") rec = "RRT (dialízis vagy transzplantáció) indítása.";
  return { egfr, stage, description: desc, recommendation: rec };
}

// ───────────────────────────── Wells (PE) ─────────────────────────────
export type WellsPeInput = {
  clinical_signs_dvt: boolean;        // 3
  pe_most_likely_dx: boolean;         // 3
  hr_over_100: boolean;               // 1.5
  immobilization_or_surgery_4w: boolean; // 1.5
  prev_dvt_pe: boolean;               // 1.5
  hemoptysis: boolean;                // 1
  malignancy_active: boolean;         // 1
};
export type WellsPeResult = {
  score: number;
  threeTier: "alacsony" | "közepes" | "magas";
  twoTier: "valószínűtlen" | "valószínű";
  next: string;
};
export function scoreWellsPE(i: WellsPeInput): WellsPeResult {
  const s =
    (i.clinical_signs_dvt ? 3 : 0) +
    (i.pe_most_likely_dx ? 3 : 0) +
    (i.hr_over_100 ? 1.5 : 0) +
    (i.immobilization_or_surgery_4w ? 1.5 : 0) +
    (i.prev_dvt_pe ? 1.5 : 0) +
    (i.hemoptysis ? 1 : 0) +
    (i.malignancy_active ? 1 : 0);
  const three = s > 6 ? "magas" : s >= 2 ? "közepes" : "alacsony";
  const two = s > 4 ? "valószínű" : "valószínűtlen";
  const next =
    two === "valószínűtlen"
      ? "D-dimer (életkor-korrigált küszöbbel) — ha negatív, PE kizárva."
      : "Azonnali CT pulmonális angiográfia (vagy V/Q, ha CTPA nem elérhető / kontraindikált).";
  return { score: s, threeTier: three, twoTier: two, next };
}

// ───────────────────────────── Geneva (revised, PE) ─────────────────────────────
export type GenevaInput = {
  age_over_65: boolean;               // 1
  prev_dvt_pe: boolean;               // 3
  surgery_or_fracture_1m: boolean;    // 2
  malignancy_active: boolean;         // 2
  unilateral_leg_pain: boolean;       // 3
  hemoptysis: boolean;                // 2
  hr_75_94: boolean;                  // 3
  hr_95_plus: boolean;                // 5
  pain_on_palpation_unilateral_edema: boolean; // 4
};
export type GenevaResult = {
  score: number;
  threeTier: "alacsony" | "közepes" | "magas";
  next: string;
};
export function scoreGenevaPE(i: GenevaInput): GenevaResult {
  const s =
    (i.age_over_65 ? 1 : 0) +
    (i.prev_dvt_pe ? 3 : 0) +
    (i.surgery_or_fracture_1m ? 2 : 0) +
    (i.malignancy_active ? 2 : 0) +
    (i.unilateral_leg_pain ? 3 : 0) +
    (i.hemoptysis ? 2 : 0) +
    (i.hr_95_plus ? 5 : i.hr_75_94 ? 3 : 0) +
    (i.pain_on_palpation_unilateral_edema ? 4 : 0);
  const tier = s >= 11 ? "magas" : s >= 4 ? "közepes" : "alacsony";
  const next =
    tier === "alacsony"
      ? "D-dimer (életkor-korrigált) — ha negatív, PE kizárva."
      : tier === "közepes"
        ? "D-dimer; pozitív esetén CTPA."
        : "Közvetlen CTPA.";
  return { score: s, threeTier: tier, next };
}

// ───────────────────────────── qSOFA ─────────────────────────────
export type QSofaInput = { sbp_le_100: boolean; rr_ge_22: boolean; altered_mental: boolean };
export type QSofaResult = { score: number; positive: boolean; note: string };
export function scoreQSofa(i: QSofaInput): QSofaResult {
  const s = (i.sbp_le_100 ? 1 : 0) + (i.rr_ge_22 ? 1 : 0) + (i.altered_mental ? 1 : 0);
  return {
    score: s,
    positive: s >= 2,
    note:
      s >= 2
        ? "Szepszis gyanú — laktát, kultúrák, full SOFA számítás, korai szélesspektrumú antibiotikum."
        : "Alacsony rövid távú mortalitás; klinikai monitorozás.",
  };
}

// ───────────────────────────── SOFA (Sepsis-3) ─────────────────────────────
export type SofaInput = {
  pao2_fio2: number;                  // mmHg / fraction (FiO2 fraction)
  on_mech_vent: boolean;
  platelets_x10e9_l: number;
  bilirubin_umol_l: number;
  map_mmhg: number;
  pressors: "none" | "dopa_low" | "dopa_mid" | "dopa_high_or_nor_low" | "nor_mid_or_high";
  gcs: number;                        // 3..15
  creatinine_umol_l: number;
  urine_ml_24h?: number;
};
export type SofaResult = {
  total: number;
  parts: { resp: number; coag: number; liver: number; cardio: number; cns: number; renal: number };
  mortalityEstPct: number;
};
function sofaResp(pf: number, vent: boolean) {
  if (pf < 100 && vent) return 4;
  if (pf < 200 && vent) return 3;
  if (pf < 300) return 2;
  if (pf < 400) return 1;
  return 0;
}
function sofaCoag(plt: number) { return plt < 20 ? 4 : plt < 50 ? 3 : plt < 100 ? 2 : plt < 150 ? 1 : 0; }
function sofaLiver(bili: number) {
  if (bili >= 204) return 4;
  if (bili >= 102) return 3;
  if (bili >= 33) return 2;
  if (bili >= 20) return 1;
  return 0;
}
function sofaCardio(map: number, p: SofaInput["pressors"]) {
  switch (p) {
    case "nor_mid_or_high": return 4;
    case "dopa_high_or_nor_low": return 3;
    case "dopa_mid": return 3;
    case "dopa_low": return 2;
  }
  return map < 70 ? 1 : 0;
}
function sofaCns(gcs: number) {
  if (gcs < 6) return 4;
  if (gcs < 10) return 3;
  if (gcs < 13) return 2;
  if (gcs < 15) return 1;
  return 0;
}
function sofaRenal(cr: number, urine?: number) {
  if (cr >= 440 || (urine !== undefined && urine < 200)) return 4;
  if (cr >= 300 || (urine !== undefined && urine < 500)) return 3;
  if (cr >= 171) return 2;
  if (cr >= 110) return 1;
  return 0;
}
export function scoreSOFA(i: SofaInput): SofaResult {
  const parts = {
    resp: sofaResp(i.pao2_fio2, i.on_mech_vent),
    coag: sofaCoag(i.platelets_x10e9_l),
    liver: sofaLiver(i.bilirubin_umol_l),
    cardio: sofaCardio(i.map_mmhg, i.pressors),
    cns: sofaCns(i.gcs),
    renal: sofaRenal(i.creatinine_umol_l, i.urine_ml_24h),
  };
  const total = Object.values(parts).reduce((a, b) => a + b, 0);
  const mort = total >= 15 ? 80 : total >= 13 ? 50 : total >= 11 ? 40 : total >= 9 ? 20 : total >= 7 ? 15 : total >= 4 ? 7 : 2;
  return { total, parts, mortalityEstPct: mort };
}

// ───────────────────────────── NEWS2 ─────────────────────────────
export type News2Input = {
  rr: number;
  spo2: number;
  on_supplemental_o2: boolean;
  scale2_chronic_hypercapnia: boolean; // COPD CO2-retenció
  temp: number;
  sbp: number;
  hr: number;
  consciousness: "A" | "C" | "V" | "P" | "U"; // ACVPU
};
export type News2Result = {
  total: number;
  parts: Record<string, number>;
  redFlag: boolean;
  riskLabel: "alacsony" | "közepes" | "magas";
  action: string;
};
function newsRR(rr: number) { if (rr <= 8) return 3; if (rr <= 11) return 1; if (rr <= 20) return 0; if (rr <= 24) return 2; return 3; }
function newsSpO2Scale1(s: number) { if (s <= 91) return 3; if (s <= 93) return 2; if (s <= 95) return 1; return 0; }
function newsSpO2Scale2(s: number, onO2: boolean) {
  if (s <= 83) return 3; if (s <= 85) return 2; if (s <= 87) return 1;
  if (s <= 92) return 0;
  if (!onO2) return 0;
  if (s <= 94) return 1; if (s <= 96) return 2; return 3;
}
function newsTemp(t: number) { if (t <= 35) return 3; if (t <= 36) return 1; if (t <= 38) return 0; if (t <= 39) return 1; return 2; }
function newsSBP(s: number) { if (s <= 90) return 3; if (s <= 100) return 2; if (s <= 110) return 1; if (s <= 219) return 0; return 3; }
function newsHR(h: number) { if (h <= 40) return 3; if (h <= 50) return 1; if (h <= 90) return 0; if (h <= 110) return 1; if (h <= 130) return 2; return 3; }
export function scoreNEWS2(i: News2Input): News2Result {
  const parts: Record<string, number> = {
    "Légzésszám": newsRR(i.rr),
    "SpO₂": i.scale2_chronic_hypercapnia ? newsSpO2Scale2(i.spo2, i.on_supplemental_o2) : newsSpO2Scale1(i.spo2),
    "Kiegészítő O₂": i.on_supplemental_o2 ? 2 : 0,
    "Hőmérséklet": newsTemp(i.temp),
    "Szisztolés RR": newsSBP(i.sbp),
    "Pulzus": newsHR(i.hr),
    "Tudat (ACVPU)": i.consciousness === "A" ? 0 : 3,
  };
  const total = Object.values(parts).reduce((a, b) => a + b, 0);
  const redFlag = Object.values(parts).some((v) => v === 3);
  let label: News2Result["riskLabel"] = "alacsony";
  let action = "12 óránként vitálisok.";
  if (total >= 7) { label = "magas"; action = "Folyamatos monitorozás, sürgős kritikus team-konzílium, ITO-átvétel mérlegelése."; }
  else if (total >= 5 || redFlag) { label = "közepes"; action = "Óránkénti vitálisok, sürgős orvosi értékelés ≤ 1 órán belül."; }
  else if (total >= 1) { action = "4–6 óránként vitálisok."; }
  return { total, parts, redFlag, riskLabel: label, action };
}

// ───────────────────────────── APGAR ─────────────────────────────
export type ApgarInput = {
  heart_rate: 0 | 1 | 2;       // 0 = nincs, 1 = <100, 2 = ≥100
  respiratory: 0 | 1 | 2;      // 0 = nincs, 1 = lassú/szabálytalan, 2 = jó sírás
  muscle_tone: 0 | 1 | 2;      // 0 = atonia, 1 = enyhe, 2 = aktív
  reflex: 0 | 1 | 2;           // 0 = nincs, 1 = grimasz, 2 = sírás/köhögés
  color: 0 | 1 | 2;            // 0 = cianotikus/sápadt, 1 = akrocianózis, 2 = teljes rózsaszín
};
export type ApgarResult = { score: number; category: "súlyos depresszió" | "mérsékelt depresszió" | "jó adaptáció"; note: string };
export function scoreAPGAR(i: ApgarInput): ApgarResult {
  const s = i.heart_rate + i.respiratory + i.muscle_tone + i.reflex + i.color;
  const cat = s <= 3 ? "súlyos depresszió" : s <= 6 ? "mérsékelt depresszió" : "jó adaptáció";
  const note = s <= 3
    ? "Aktív újraélesztés szükséges (NRP algoritmus)."
    : s <= 6 ? "Stimuláció, oxigén, szoros megfigyelés; 5. perces APGAR ismétlése." : "Rutin újszülött ellátás.";
  return { score: s, category: cat, note };
}

// ───────────────────────────── Bishop ─────────────────────────────
export type BishopInput = {
  dilation_cm: number;          // 0 / 1–2 / 3–4 / 5+
  effacement_pct: number;       // 0–30 / 40–50 / 60–70 / 80+
  station: -3 | -2 | -1 | 0 | 1; // Hodge-síkokhoz konvertálva
  consistency: "kemeny" | "kozepes" | "lagy";
  position: "hatso" | "kozepes" | "elulso";
};
export type BishopResult = {
  score: number;
  parts: Record<string, number>;
  interpretation: string;
};
export function scoreBishop(i: BishopInput): BishopResult {
  const pDil = i.dilation_cm >= 5 ? 3 : i.dilation_cm >= 3 ? 2 : i.dilation_cm >= 1 ? 1 : 0;
  const pEff = i.effacement_pct >= 80 ? 3 : i.effacement_pct >= 60 ? 2 : i.effacement_pct >= 40 ? 1 : 0;
  const pSta = i.station >= 1 ? 3 : i.station === 0 ? 2 : i.station === -1 ? 1 : 0;
  const pCon = i.consistency === "lagy" ? 2 : i.consistency === "kozepes" ? 1 : 0;
  const pPos = i.position === "elulso" ? 2 : i.position === "kozepes" ? 1 : 0;
  const score = pDil + pEff + pSta + pCon + pPos;
  const interp = score >= 8
    ? "Kedvező cervix — indukció valószínűleg sikeres (≈ spontán szülés esélye)."
    : score >= 6 ? "Mérsékelten kedvező — indukció mérlegelhető, érlelés nem feltétlen szükséges."
    : "Kedvezőtlen cervix — cervix-érlelés javasolt (PGE2 / Foley / misoprostol az intézményi protokoll szerint).";
  return {
    score,
    parts: { "Tágulat": pDil, "Elvékonyodás": pEff, "Beilleszkedés": pSta, "Konzisztencia": pCon, "Pozíció": pPos },
    interpretation: interp,
  };
}
