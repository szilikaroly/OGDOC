// Diabétesz kiegészítő gyógyszerek — ADA/EASD 2024-2025.
// 5 osztály: Metformin, SU, SGLT2, DPP4, GLP1.

export type DrugId = "metformin" | "su" | "sglt2" | "dpp4" | "glp1";
export type DrugStatus = "none" | "current" | "planned" | "stop";
export type Safety = "ok" | "cau" | "con" | "ins";

export type DrugInfo = {
  id: DrugId;
  cls: string;
  hu: string;
  color: string;
  drugs: string[];
  mech: string;
  hba1c: string;
  weight: string;
  cv: string;
  hypoRisk: "low" | "moderate" | "high";
  pregnancy: { safety: Safety; note: string };
  ckd: Array<{ gfr: string; safety: Safety; text: string }>;
  combo: string;
  positives: string[];
  insulinReduction: number; // becsült NE/nap csökkentés inzulin-kombóban
  patient: {
    how: string;
    what: string;
    watch: string;
    good: string;
    stopNote: string;
  };
};

export const DIAB_DRUGS: DrugInfo[] = [
  {
    id: "metformin",
    cls: "Biguanid",
    hu: "Metformin",
    color: "#0EA5E9",
    drugs: ["Metformin Sandoz", "Adimet", "Meglucon", "Stadamet", "Glucophage"],
    mech: "Csökkenti a máj glukoneogenezisét, javítja az inzulin-szenzitivitást.",
    hba1c: "−1.0 to −1.5%",
    weight: "Súlyneutrális / enyhe ↓",
    cv: "Neutrális → enyhe előny",
    hypoRisk: "low",
    pregnancy: { safety: "cau", note: "Gesztációs DM-ben adható, de inzulin a 1. választás." },
    ckd: [
      { gfr: ">60", safety: "ok", text: "Teljes dózis" },
      { gfr: "45–60", safety: "ok", text: "Maximum 2000 mg/nap" },
      { gfr: "30–45", safety: "cau", text: "Max 1000 mg/nap, óvatosság" },
      { gfr: "<30", safety: "con", text: "ELLENJAVALLT — laktát-acidózis rizikó" },
    ],
    combo: "Minden más OAD-vel és inzulinnal kombinálható (1. választás).",
    positives: ["Olcsó", "Évtizedes tapasztalat", "Súlyt nem növel", "Hypoglikémia nélkül"],
    insulinReduction: 0,
    patient: {
      how: "Étkezés közben/után, kezdetben 500 mg napi 1×, fokozatosan emelve.",
      what: "Csökkenti a máj cukortermelését — éhomi vércukor csökken.",
      watch: "GI panaszok (hasmenés, hányinger) első 2 hét. Kontrasztanyag előtt 48 órával állítsuk le.",
      good: "Hatékony, biztonságos, súlytolerált.",
      stopNote: "Vesefunkció romlásnál (eGFR<30) azonnal leállítandó.",
    },
  },
  {
    id: "su",
    cls: "Szulfonil­urea",
    hu: "SU",
    color: "#F59E0B",
    drugs: ["Glimepirid", "Diaprel MR (gliclazid)", "Maninil (glibenclamid)"],
    mech: "Béta-sejt inzulin-elválasztást stimulál.",
    hba1c: "−1.0 to −1.5%",
    weight: "+2–3 kg",
    cv: "Neutrális (gliclazid) / kérdéses (glibenclamid)",
    hypoRisk: "high",
    pregnancy: { safety: "con", note: "Nem ajánlott — átjut a placentán." },
    ckd: [
      { gfr: ">60", safety: "ok", text: "Adható" },
      { gfr: "30–60", safety: "cau", text: "Gliclazid preferált, dóziscsökkentés" },
      { gfr: "<30", safety: "con", text: "ELLENJAVALLT (kivéve gliclazid óvatosan)" },
    ],
    combo: "GLP1-gyel óvatosan (hypo↑). Inzulinnal kerülendő ha lehet.",
    positives: ["Olcsó", "Gyors hatás", "Effektív rövid távon"],
    insulinReduction: 6,
    patient: {
      how: "Reggel étkezés előtt 30 perccel.",
      what: "Több inzulint ürít a hasnyálmirigy — vércukor csökken.",
      watch: "HYPOGLIKÉMIA! Étkezés kihagyása, intenzív edzés, alkohol fokozzák a rizikót.",
      good: "Gyors hatás, könnyen elérhető.",
      stopNote: "Vese-/májfunkciós romlásnál, hypos epizódoknál újra mérlegelendő.",
    },
  },
  {
    id: "sglt2",
    cls: "SGLT2-gátló",
    hu: "SGLT2",
    color: "#10B981",
    drugs: ["Forxiga (dapagliflozin)", "Jardiance (empagliflozin)", "Invokana (canagliflozin)"],
    mech: "Glükóz-reabszorpció gátlása a proximális vesetubulusban — glikozuria.",
    hba1c: "−0.5 to −1.0%",
    weight: "−2 to −3 kg",
    cv: "JELENTŐS ELŐNY — MACE↓, HF-hospitalizáció↓",
    hypoRisk: "low",
    pregnancy: { safety: "con", note: "Ellenjavallt — magzati vesefejlődési kockázat." },
    ckd: [
      { gfr: ">60", safety: "ok", text: "Első választás, ha CV-rizikó / HF / CKD" },
      { gfr: "30–60", safety: "ok", text: "Adható (dapa/empa CKD-indikáció)" },
      { gfr: "20–30", safety: "cau", text: "Csökkenő glikémiás hatás, de szerv-védelem megmarad" },
      { gfr: "<20", safety: "con", text: "Általában leállítandó" },
    ],
    combo: "Metforminnal, GLP1-gyel kiváló. SU-val/inzulinnal hypo-rizikó alacsony.",
    positives: ["CV/HF/vese protekció", "Súlycsökkentés", "Vérnyomás↓", "Albuminuria↓"],
    insulinReduction: 8,
    patient: {
      how: "Naponta 1×, reggel, étkezéstől függetlenül.",
      what: "A felesleges cukor a vizelettel távozik. Vesét és szívet véd.",
      watch: "Genitális gombásodás, dehydratáció (sok folyadék!), euglikémiás DKA — szigorú diéta/alkohol esetén kerülendő.",
      good: "Szív- és vese-protekció, súlycsökkentés.",
      stopNote: "Akut betegségben (infekció, műtét, böjt) átmenetileg leállítandó.",
    },
  },
  {
    id: "dpp4",
    cls: "DPP-4 gátló",
    hu: "DPP4",
    color: "#8B5CF6",
    drugs: ["Januvia (sitagliptin)", "Galvus (vildagliptin)", "Trajenta (linagliptin)"],
    mech: "GLP-1 lebontásának gátlása — endogén inkretin↑.",
    hba1c: "−0.5 to −0.8%",
    weight: "Súlyneutrális",
    cv: "Neutrális (saxa: HF↑)",
    hypoRisk: "low",
    pregnancy: { safety: "con", note: "Nem javasolt." },
    ckd: [
      { gfr: ">60", safety: "ok", text: "Teljes dózis" },
      { gfr: "30–60", safety: "ok", text: "Dóziscsökkentés (linagliptin kivétel)" },
      { gfr: "<30", safety: "ok", text: "Linagliptin teljes dózisban; egyébként redukáljuk" },
    ],
    combo: "Metforminnal jó. GLP-1-gyel NE (azonos mechanizmus).",
    positives: ["Hypo-mentes", "Vesében biztonságos", "Súlyneutrális"],
    insulinReduction: 4,
    patient: {
      how: "Naponta 1×, étkezéstől függetlenül.",
      what: "Inkretin-hormonok lebontását gátolja — étkezéskor több saját inzulin.",
      watch: "Ritka pancreatitis, ízületi fájdalom.",
      good: "Egyszerű, jól tolerált.",
      stopNote: "Pancreatitis-gyanúnál azonnal leállítandó.",
    },
  },
  {
    id: "glp1",
    cls: "GLP-1 RA",
    hu: "GLP-1",
    color: "#EF4444",
    drugs: ["Ozempic (semaglutid s.c.)", "Trulicity (dulaglutid)", "Victoza (liraglutid)", "Rybelsus (semaglutid p.o.)"],
    mech: "GLP-1 receptor agonista — étvágy↓, gyomorürülés↓, glükagon↓.",
    hba1c: "−1.0 to −1.8%",
    weight: "−3 to −6 kg",
    cv: "JELENTŐS ELŐNY — MACE↓, CV-mortalitás↓",
    hypoRisk: "low",
    pregnancy: { safety: "con", note: "Ellenjavallt — fogamzás előtt 2 hónappal leállítani." },
    ckd: [
      { gfr: ">30", safety: "ok", text: "Teljes dózis" },
      { gfr: "15–30", safety: "cau", text: "Semaglutid / dulaglutid adható" },
      { gfr: "<15", safety: "cau", text: "Korlátozott adat — egyedi mérlegelés" },
    ],
    combo: "Metforminnal + SGLT2-vel triple therapy. SU-val hypo-rizikó↑.",
    positives: ["Súlycsökkentés", "CV-protekció", "Étvágy↓", "Hypo-mentes"],
    insulinReduction: 12,
    patient: {
      how: "Heti 1× s.c. (Ozempic/Trulicity), napi 1× s.c. (Victoza), napi 1× p.o. (Rybelsus, éhomra).",
      what: "Csökkenti az étvágyat, lassítja a gyomorürülést, étkezéskor segíti az inzulint.",
      watch: "Hányinger első hetekben (általában elmúlik), pancreatitis-gyanú, MTC familiáris anamnézisnél kerülendő.",
      good: "Hatékony súlycsökkentés és szív-védelem.",
      stopNote: "Műtét/böjt előtt 1 héttel leállítandó (gyomorürülés).",
    },
  },
];

export const DRUG_BY_ID: Record<DrugId, DrugInfo> = DIAB_DRUGS.reduce((acc, d) => {
  acc[d.id] = d;
  return acc;
}, {} as Record<DrugId, DrugInfo>);

// Kombináció-elemzés
export function analyzeDrugCombo(statuses: Partial<Record<DrugId, DrugStatus>>): {
  warnings: string[];
  totalInsulinReduction: number;
  active: DrugId[];
} {
  const active = (Object.entries(statuses) as Array<[DrugId, DrugStatus]>)
    .filter(([, s]) => s === "current" || s === "planned")
    .map(([k]) => k);

  const warnings: string[] = [];
  if (active.includes("dpp4") && active.includes("glp1")) {
    warnings.push("DPP-4 + GLP-1 RA NEM kombinálható — azonos mechanizmus, nincs additív hatás.");
  }
  if (active.includes("su") && active.includes("glp1")) {
    warnings.push("SU + GLP-1 RA — hypoglikémia rizikó↑, SU dózis csökkentése javasolt.");
  }
  if (active.includes("su") && active.includes("sglt2")) {
    warnings.push("SU + SGLT2 — euglikémiás DKA + hypo kombi-rizikó.");
  }

  const totalInsulinReduction = active.reduce((sum, id) => sum + DRUG_BY_ID[id].insulinReduction, 0);

  return { warnings, totalInsulinReduction, active };
}

// Excel/CSV heti VC parser
export type ParsedVcRow = {
  date: string; // ISO YYYY-MM-DD
  measurements: Partial<Record<
    "night" | "fasting" | "regPP" | "lunchPre" | "lunchPP" | "dinnerPre" | "dinnerPP",
    number
  >>;
  bolus_r?: number;
  bolus_d?: number;
  bolus_e?: number;
  basal?: number;
};

const VC_COLUMNS = ["date", "bolus_r", "bolus_d", "bolus_e", "basal",
  "night", "fasting", "regPP", "lunchPre", "lunchPP", "dinnerPre", "dinnerPP"] as const;

export function parseWeeklyPaste(raw: string): ParsedVcRow[] {
  const lines = raw.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  const out: ParsedVcRow[] = [];
  for (const line of lines) {
    const cols = line.split(/\t|;|,/).map((c) => c.trim());
    if (cols.length < 2) continue;
    const dateMatch = cols[0].match(/(\d{4})[-./](\d{1,2})[-./](\d{1,2})/);
    if (!dateMatch) continue;
    const iso = `${dateMatch[1]}-${dateMatch[2].padStart(2, "0")}-${dateMatch[3].padStart(2, "0")}`;
    const row: ParsedVcRow = { date: iso, measurements: {} };
    for (let i = 1; i < cols.length && i < VC_COLUMNS.length; i++) {
      const key = VC_COLUMNS[i];
      const num = Number(cols[i].replace(",", "."));
      if (Number.isNaN(num)) continue;
      if (key === "bolus_r" || key === "bolus_d" || key === "bolus_e" || key === "basal") {
        row[key] = num;
      } else if (key !== "date") {
        row.measurements[key] = num;
      }
    }
    out.push(row);
  }
  return out;
}

// Heti elemzés
export type WeeklyAnalysis = {
  avgFasting: number | null;
  avgBasal: number | null;
  avgBolus: number | null;
  tir: number | null;
  hypoCount: number;
  hyperCount: number;
  dawnDays: number;
  basalTrend: "increase" | "decrease" | "stable";
  highStreak: number;
  lowStreak: number;
};

export function analyzeWeek(rows: ParsedVcRow[]): WeeklyAnalysis {
  const all: number[] = [];
  const fasting: number[] = [];
  const basals: number[] = [];
  const boluses: number[] = [];
  let hypoCount = 0;
  let hyperCount = 0;
  let dawnDays = 0;
  let highStreak = 0;
  let lowStreak = 0;
  let runHigh = 0;
  let runLow = 0;

  for (const r of rows) {
    Object.values(r.measurements).forEach((v) => {
      if (typeof v === "number") {
        all.push(v);
        if (v < 3.9) hypoCount++;
        if (v > 10) hyperCount++;
      }
    });
    if (r.measurements.fasting !== undefined) {
      fasting.push(r.measurements.fasting);
      if (r.measurements.fasting > 7.2) { runHigh++; runLow = 0; }
      else if (r.measurements.fasting < 4.4) { runLow++; runHigh = 0; }
      else { runHigh = 0; runLow = 0; }
      highStreak = Math.max(highStreak, runHigh);
      lowStreak = Math.max(lowStreak, runLow);
    }
    if (r.measurements.night !== undefined && r.measurements.fasting !== undefined) {
      if (r.measurements.fasting - r.measurements.night > 2) dawnDays++;
    }
    if (r.basal !== undefined) basals.push(r.basal);
    const b = (r.bolus_r ?? 0) + (r.bolus_d ?? 0) + (r.bolus_e ?? 0);
    if (b > 0) boluses.push(b);
  }

  const avg = (arr: number[]) => arr.length ? Math.round(arr.reduce((a, b) => a + b, 0) / arr.length * 10) / 10 : null;
  const tir = all.length
    ? Math.round(all.filter((v) => v >= 4.4 && v <= 10.0).length / all.length * 100)
    : null;

  let basalTrend: WeeklyAnalysis["basalTrend"] = "stable";
  if (basals.length >= 3) {
    const first = basals.slice(0, Math.ceil(basals.length / 2)).reduce((a, b) => a + b, 0) / Math.ceil(basals.length / 2);
    const last = basals.slice(Math.ceil(basals.length / 2)).reduce((a, b) => a + b, 0) / Math.floor(basals.length / 2);
    if (last - first > 2) basalTrend = "increase";
    else if (first - last > 2) basalTrend = "decrease";
  }

  return {
    avgFasting: avg(fasting),
    avgBasal: avg(basals),
    avgBolus: avg(boluses),
    tir,
    hypoCount,
    hyperCount,
    dawnDays,
    basalTrend,
    highStreak,
    lowStreak,
  };
}
