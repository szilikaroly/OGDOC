import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { generateText } from "ai";
import { createLovableAiGatewayProvider } from "@/lib/ai-gateway.server";

export type AiNoteKind = "anamnesis" | "epicrisis" | "diet" | "results_summary";

type Input = {
  patientId: string;
  encounterId: string;
  kind: AiNoteKind;
  extraContext?: string;
};

function validate(input: unknown): Input {
  const v = input as Input;
  if (!v?.patientId || !v?.encounterId) throw new Error("patientId és encounterId kötelező");
  if (!["anamnesis", "epicrisis", "diet", "results_summary"].includes(v.kind)) throw new Error("érvénytelen kind");
  return v;
}

const SYSTEM = `Magyar nyelvű, FHIR-tudatos klinikai dokumentáló asszisztens vagy.
A válasz mindig magyar nyelvű, strukturált Markdown.
Csak a megadott betegadatokból dolgozz; ne találj ki adatot. Hiányzó adatot jelölj „—" jellel.
Ne adj diagnózist orvosi felelősséggel — döntéstámogatást nyújtasz, az orvos szerkeszti és aláírja.`;

function promptFor(kind: AiNoteKind, ctx: string): string {
  if (kind === "anamnesis") {
    return `Készíts strukturált **anamnézis** vázlatot a következő szakaszokkal:
- **Fő panasz** (CC)
- **Jelen panasz részletei** (HPI: kezdet, jelleg, súlyosság, lefolyás)
- **Kórelőzmény** (krónikus betegségek, korábbi műtétek)
- **Gyógyszeres anamnézis** (aktuális gyógyszerek, allergia)
- **Családi anamnézis**
- **Szociális anamnézis** (foglalkozás, dohányzás, alkohol)
- **Funkcionális státusz**

Beteg-és epizódadatok:
${ctx}`;
  }
  if (kind === "epicrisis") {
    return `Készíts **epikrízis** vázlatot a következő szakaszokkal:
- **Felvétel oka**
- **Lényeges anamnézis**
- **Vizsgálati eredmények** (vitálisok, labor, képalkotás összegzése)
- **Diagnózisok** (BNO-kódokkal, ha vannak)
- **Lefolyás és terápia**
- **Kibocsátási állapot**
- **Javaslatok** (gyógyszerelés, kontroll időpontok, életmód)

Beteg-és epizódadatok:
${ctx}`;
  }
  if (kind === "results_summary") {
    return `Készíts strukturált **lelet-összefoglalót** (klinikai review) az alábbi vázlatban. Magyar nyelvű, tömör, csak a megadott adatokból dolgozz:
- **Kulcsmegfigyelések** (kóros vitálisok, laboreltérések, képalkotás — irány + mértékegység)
- **Trendek** (rosszabbodó / javuló paraméterek, ha van legalább 2 mérés)
- **Kritikus / azonnali figyelmet igénylő értékek** (❗ jellel)
- **Kontextus a diagnózisokkal** (mely lelet melyik dg-t támogatja vagy cáfolja)
- **Terápia-hatás értékelése** (ha releváns)
- **Javasolt következő lépések** (kiegészítő vizsgálat, kontroll, konzílium)

Beteg-és epizódadatok:
${ctx}`;
  }
  return `Készíts **személyre szabott diétás tervet** a következő szakaszokkal:
- **Napi energia- és makrotápanyag-cél** (kcal, fehérje g/ttkg, szénhidrát %, zsír %)
- **Étkezési séma** (reggeli, tízórai, ebéd, uzsonna, vacsora — példa-fogásokkal)
- **Javasolt élelmiszerek** (csoportokba rendezve)
- **Kerülendő / korlátozandó élelmiszerek** (indokkal)
- **Folyadékfogyasztás**
- **Kontroll és követés** (mit, milyen gyakran mérjen)

Beteg-és epizódadatok:
${ctx}`;
}

export const generateAiClinicalNote = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(validate)
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { patientId, encounterId, kind, extraContext } = data;

    const [patient, encounter, observations, diagnoses, therapy, calc] = await Promise.all([
      supabase.from("patients").select("vezeteknev, keresztnev, szuletesi_datum, nem, fo_diagnozis_bno, taj").eq("id", patientId).maybeSingle(),
      supabase.from("clinical_encounters").select("encounter_type, status, start_ts, end_ts, chief_complaint").eq("id", encounterId).maybeSingle(),
      supabase.from("clinical_observations").select("category, code_display, value_quantity, value_unit, value_string, effective_ts, interpretation").eq("patient_id", patientId).order("effective_ts", { ascending: false }).limit(40),
      supabase.from("clinical_diagnoses").select("icd10_code, display, certainty, is_primary, onset_date").eq("patient_id", patientId),
      supabase.from("clinical_therapy_orders").select("kind, display, dose, frequency, duration").eq("patient_id", patientId).order("created_at", { ascending: false }).limit(20),
      supabase.from("clinical_calculator_results").select("calculator, interpretation_md, created_at").eq("patient_id", patientId).order("created_at", { ascending: false }).limit(5),
    ]);

    const ctxLines: string[] = [];
    if (patient.data) {
      const p = patient.data as any;
      ctxLines.push(`### Beteg\n- Név: ${p.vezeteknev} ${p.keresztnev}\n- Születési dátum: ${p.szuletesi_datum ?? "—"}\n- Nem: ${p.nem ?? "—"}\n- Fő dg (BNO): ${p.fo_diagnozis_bno ?? "—"}`);
    }
    if (encounter.data) {
      const e = encounter.data as any;
      ctxLines.push(`### Aktuális epizód\n- Típus: ${e.encounter_type}\n- Státusz: ${e.status}\n- Kezdet: ${e.start_ts}${e.end_ts ? `\n- Vég: ${e.end_ts}` : ""}\n- Fő panasz: ${e.chief_complaint ?? "—"}`);
    }
    if (observations.data?.length) {
      const lines = observations.data.map((o: any) => `- [${o.category}] ${o.code_display}: ${o.value_quantity ?? o.value_string ?? "—"} ${o.value_unit ?? ""} (${new Date(o.effective_ts).toLocaleString("hu-HU")}${o.interpretation ? `, ${o.interpretation}` : ""})`).join("\n");
      ctxLines.push(`### Megfigyelések (legutóbbi 40)\n${lines}`);
    }
    if (diagnoses.data?.length) {
      const lines = diagnoses.data.map((d: any) => `- ${d.icd10_code ?? "—"} ${d.display} (${d.certainty}${d.is_primary ? ", primer" : ""}${d.onset_date ? `, kezdet: ${d.onset_date}` : ""})`).join("\n");
      ctxLines.push(`### Diagnózisok\n${lines}`);
    }
    if (therapy.data?.length) {
      const lines = therapy.data.map((t: any) => `- [${t.kind}] ${t.display}${t.dose ? ` · ${t.dose}` : ""}${t.frequency ? ` · ${t.frequency}` : ""}${t.duration ? ` · ${t.duration}` : ""}`).join("\n");
      ctxLines.push(`### Aktuális terápia / rendelvények\n${lines}`);
    }
    if (calc.data?.length) {
      ctxLines.push(`### Korábbi kalkulátor-eredmények\n${calc.data.map((c: any) => `- ${c.calculator} (${new Date(c.created_at).toLocaleDateString("hu-HU")})`).join("\n")}`);
    }
    if (extraContext) ctxLines.push(`### Egyéb megjegyzés az orvostól\n${extraContext}`);

    const key = process.env.LOVABLE_API_KEY;
    if (!key) throw new Error("LOVABLE_API_KEY hiányzik");
    const gateway = createLovableAiGatewayProvider(key);

    let text: string;
    try {
      const result = await generateText({
        model: gateway("google/gemini-3-flash-preview"),
        system: SYSTEM,
        prompt: promptFor(kind, ctxLines.join("\n\n")),
      });
      text = result.text;
    } catch (e: any) {
      const msg = String(e?.message ?? e);
      if (msg.includes("429")) throw new Error("Az AI szolgáltatás jelenleg túl van terhelve (429). Próbáld újra később.");
      if (msg.includes("402")) throw new Error("Elfogytak a Lovable AI kreditek (402). Tölts fel a workspace beállításokban.");
      throw new Error(`AI generálás sikertelen: ${msg}`);
    }

    const titleMap: Record<AiNoteKind, string> = {
      anamnesis: "Anamnézis (AI vázlat)",
      epicrisis: "Epikrízis (AI vázlat)",
      diet: "Diétás terv (AI vázlat)",
      results_summary: "Lelet-összefoglaló (AI vázlat)",
    };
    const title = titleMap[kind];

    const { data: note, error } = await supabase.from("clinical_notes").insert({
      encounter_id: encounterId,
      patient_id: patientId,
      author_id: userId,
      kind,
      title,
      body_md: text,
      ai_generated: true,
    }).select("id").maybeSingle();
    if (error) throw new Error(error.message);

    return { id: note?.id ?? null, text };
  });
