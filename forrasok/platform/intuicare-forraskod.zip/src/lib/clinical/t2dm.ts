// ADA/EASD 2024-szerű, egyszerűsített 2-es típusú diabetes terápiatervező logika.
// Nem helyettesíti az orvosi döntést — segédeszköz.

export type T2dmInputs = {
  age: number;
  weightKg: number;
  heightCm: number;
  hba1c_pct: number; // %
  egfr_ml_min_173: number; // ml/min/1.73 m2
  ascvd: boolean;
  heart_failure: boolean;
  ckd: boolean; // klinikailag diagnosztizált CKD vagy albuminuria
  hypo_risk_high: boolean;
  cost_sensitive: boolean;
  pregnancy: boolean;
  current_meds: string; // szabad szöveg
};

export type T2dmRecommendation = {
  drug: string;
  rationale: string;
  caution?: string;
};

export type T2dmResult = {
  bmi: number;
  bmi_class: string;
  hba1c_target: string;
  first_line: T2dmRecommendation[];
  add_on: T2dmRecommendation[];
  avoid: T2dmRecommendation[];
  lifestyle: string[];
  monitoring: string[];
  interpretation_md: string;
};

function bmiClass(bmi: number): string {
  if (bmi < 18.5) return "alultáplált";
  if (bmi < 25) return "normál";
  if (bmi < 30) return "túlsúly";
  if (bmi < 35) return "I. fokú elhízás";
  if (bmi < 40) return "II. fokú elhízás";
  return "III. fokú elhízás";
}

export function evaluateT2dm(i: T2dmInputs): T2dmResult {
  const bmi = i.weightKg / Math.pow(i.heightCm / 100, 2);
  const first: T2dmRecommendation[] = [];
  const add: T2dmRecommendation[] = [];
  const avoid: T2dmRecommendation[] = [];

  // Cél HbA1c (ADA 2024)
  let target = "< 7,0 %";
  if (i.age >= 75 || i.hypo_risk_high) target = "7,0 – 8,0 % (lazábbra véve idős / hipo-érzékeny betegnél)";
  if (i.pregnancy) target = "< 6,0 % (lehetőség szerint, hipo nélkül) — gestációs/preg-diabetes protokoll";

  // Terhesség → speciális
  if (i.pregnancy) {
    avoid.push({ drug: "Minden orális antidiabetikum (kivéve metformin szigorú indikációval)", rationale: "Terhességben kontraindikált / nem javasolt." });
    first.push({ drug: "Inzulin (bázis ± étkezési)", rationale: "Terhességben elsőként választandó, biztonságos és titrálható." });
  } else {
    // Metformin alap
    if (i.egfr_ml_min_173 >= 30) {
      first.push({
        drug: "Metformin",
        rationale: "Elsőként választandó orális szer minden T2DM-ben (eGFR ≥ 30).",
        caution: i.egfr_ml_min_173 < 45 ? "eGFR 30–45 között max. 1000 mg/nap, szoros vesefunkció-ellenőrzés." : undefined,
      });
    } else {
      avoid.push({ drug: "Metformin", rationale: "eGFR < 30 esetén kontraindikált (laktát-acidózis kockázat)." });
    }

    // CV / HF / CKD prioritás → SGLT2i és/vagy GLP-1 RA, hba1c-függetlenül
    if (i.heart_failure && i.egfr_ml_min_173 >= 20) {
      add.push({ drug: "SGLT2-gátló (dapagliflozin / empagliflozin)", rationale: "Szívelégtelenségben bizonyított mortalitás- és hospitalizáció-csökkentés (DAPA-HF, EMPEROR)." });
    }
    if (i.ckd && i.egfr_ml_min_173 >= 20) {
      add.push({ drug: "SGLT2-gátló (dapagliflozin / empagliflozin)", rationale: "CKD-ban (eGFR ≥ 20, albuminuria) nefroprotektív (DAPA-CKD, EMPA-KIDNEY)." });
    }
    if (i.ascvd) {
      add.push({ drug: "GLP-1 RA (semaglutid / liraglutid / dulaglutid)", rationale: "ASCVD esetén MACE-csökkentés (LEADER, REWIND, SUSTAIN-6)." });
      if (i.egfr_ml_min_173 >= 20) {
        add.push({ drug: "vagy SGLT2-gátló", rationale: "ASCVD-ben szintén MACE-csökkentő (EMPA-REG, CANVAS)." });
      }
    }

    // Súly fókusz
    if (bmi >= 27) {
      add.push({ drug: "GLP-1 RA (semaglutid s.c. preferált) vagy tirzepatid", rationale: "Jelentős testsúlycsökkentés + HbA1c javulás." });
    }

    // Hipoglikémia minimalizálás
    if (i.hypo_risk_high) {
      avoid.push({ drug: "Szulfonilureák (glimepirid, gliklazid), glinidek", rationale: "Magas hipoglikémia-rizikónál kerülendők." });
      avoid.push({ drug: "Premix inzulinok kombinációja, ha elkerülhető", rationale: "Nehezen titrálhatók, hipo-kockázat." });
    }

    // Költség
    if (i.cost_sensitive && i.egfr_ml_min_173 >= 30 && !i.ascvd && !i.heart_failure && !i.ckd) {
      add.push({ drug: "Szulfonilurea (gliklazid MR) vagy DPP-4 gátló", rationale: "Költséghatékony 2. vonalbeli opciók, ha CV/CKD-indikáció nincs." });
    }

    // Inzulin küszöb
    if (i.hba1c_pct >= 10) {
      add.push({ drug: "Bázis inzulin (glargin / detemir / degludek)", rationale: "Súlyos hyperglykaemia (HbA1c ≥ 10 %) vagy katabolikus tünetek esetén korai inzulin." });
    }
  }

  const lifestyle = [
    "Mediterrán vagy DASH diéta — ≥ 5–7 % testsúlycsökkentés.",
    "Legalább 150 perc/hét mérsékelt intenzitású aerob mozgás + heti 2× ellenállás-tréning.",
    "Dohányzás elhagyása, alkohol < 1 (♀) / < 2 (♂) standard ital/nap.",
    "Stresszkezelés, alvás 7–9 óra/éjszaka, glikémiás napló vagy CGM.",
  ];

  const monitoring = [
    "HbA1c 3 havonta, ha nem cél; majd 6 havonta.",
    "Vesefunkció (kreatinin, eGFR, ACR) évente — SGLT2/metformin titrálás miatt.",
    "Lipid panel, májfunkció évente.",
    "Szemészet, neuropathia (10g monofilament), láb-státusz évente.",
    "Vérnyomás minden vizit, cél < 130/80 Hgmm.",
  ];

  const interpretation = `### T2DM terápiajavaslat összegzése

**BMI:** ${bmi.toFixed(1)} kg/m² (${bmiClass(bmi)})  
**HbA1c cél:** ${target}  
**eGFR:** ${i.egfr_ml_min_173} ml/min/1,73 m² · **HbA1c jelenleg:** ${i.hba1c_pct} %

#### Elsővonalbeli
${first.map((r) => `- **${r.drug}** — ${r.rationale}${r.caution ? `  \n  ⚠️ ${r.caution}` : ""}`).join("\n") || "_(nincs specifikus elsővonalbeli ajánlás)_"}

#### Hozzáadandó / preferált
${add.map((r) => `- **${r.drug}** — ${r.rationale}`).join("\n") || "_(nincs további szer-prioritás)_"}

#### Kerülendő
${avoid.map((r) => `- **${r.drug}** — ${r.rationale}`).join("\n") || "_(nincs külön kerülendő szer)_"}

#### Életmódi pillérek
${lifestyle.map((l) => `- ${l}`).join("\n")}

#### Monitorozás
${monitoring.map((m) => `- ${m}`).join("\n")}

> Ez egy döntéstámogató összegzés. A végső terápiát mindig az orvos egyéni mérlegelése határozza meg a beteg komplett klinikai állapota alapján.
`;

  return {
    bmi,
    bmi_class: bmiClass(bmi),
    hba1c_target: target,
    first_line: first,
    add_on: add,
    avoid,
    lifestyle,
    monitoring,
    interpretation_md: interpretation,
  };
}
