import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

type Patient = { vezeteknev?: string; keresztnev?: string; szuletesi_datum?: string } | null;
type Encounter = { encounter_type?: string; start_ts?: string; id?: string } | null;
type Partogram = {
  id: string;
  labor_start_ts: string;
  membrane_status: string | null;
  notes_md: string | null;
  parity_gravida_json: any;
};
type Entry = {
  recorded_at: string;
  cervix_cm: number | null;
  descent_station: number | null;
  contractions_per_10min: number | null;
  contraction_duration_sec: number | null;
  fetal_heart_rate: number | null;
  maternal_hr: number | null;
  maternal_bp_sys: number | null;
  maternal_bp_dia: number | null;
  temp_c: number | null;
  liquor_color: string | null;
  moulding: string | null;
  oxytocin_mu: number | null;
  drugs_text: string | null;
  notes: string | null;
};

export type PartogramExportInput = {
  patient: Patient;
  encounter: Encounter;
  partogram: Partogram;
  entries: Entry[];
  alerts: string[];
};

export function buildPartogramText(opts: PartogramExportInput): string {
  const { patient, encounter, partogram, entries, alerts } = opts;
  const name = patient ? `${patient.vezeteknev ?? ""} ${patient.keresztnev ?? ""}`.trim() : "—";
  const dob = patient?.szuletesi_datum ?? "—";
  const enc = encounter ? `${encounter.encounter_type ?? ""} · ${encounter.start_ts ? new Date(encounter.start_ts).toLocaleString("hu-HU") : ""}` : "—";
  const laborStart = new Date(partogram.labor_start_ts).toLocaleString("hu-HU");
  const labor0 = new Date(partogram.labor_start_ts).getTime();
  const pg = partogram.parity_gravida_json ?? {};

  const lines: string[] = [];
  lines.push("SZÜLÉSZETI PARTOGRAM");
  lines.push("=".repeat(60));
  lines.push(`Beteg: ${name}`);
  lines.push(`Születési dátum: ${dob}`);
  lines.push(`Epizód: ${enc}`);
  lines.push(`Vajúdás kezdete: ${laborStart}`);
  if (partogram.membrane_status) lines.push(`Burok: ${partogram.membrane_status}`);
  if (pg && (pg.gravida || pg.para)) lines.push(`G/P: ${pg.gravida ?? "?"}/${pg.para ?? "?"}`);
  lines.push(`Generálva: ${new Date().toLocaleString("hu-HU")}`);
  lines.push("");

  if (alerts.length) {
    lines.push("FIGYELMEZTETÉSEK:");
    alerts.forEach((a) => lines.push(`  • ${a}`));
    lines.push("");
  }

  lines.push(`BEJEGYZÉSEK (${entries.length}):`);
  lines.push("-".repeat(60));
  entries.forEach((e) => {
    const h = ((new Date(e.recorded_at).getTime() - labor0) / 3600000).toFixed(1);
    const t = new Date(e.recorded_at).toLocaleString("hu-HU", { month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" });
    const parts: string[] = [`[${t} | +${h}h]`];
    if (e.cervix_cm != null) parts.push(`méhszáj ${e.cervix_cm}cm`);
    if (e.descent_station != null) parts.push(`station ${e.descent_station}`);
    if (e.fetal_heart_rate != null) parts.push(`FHR ${e.fetal_heart_rate}/min`);
    if (e.contractions_per_10min != null) parts.push(`ctx ${e.contractions_per_10min}/10p${e.contraction_duration_sec ? `×${e.contraction_duration_sec}s` : ""}`);
    if (e.maternal_bp_sys && e.maternal_bp_dia) parts.push(`RR ${e.maternal_bp_sys}/${e.maternal_bp_dia}`);
    if (e.maternal_hr != null) parts.push(`P ${e.maternal_hr}`);
    if (e.temp_c != null) parts.push(`${e.temp_c}°C`);
    if (e.liquor_color) parts.push(`magzv.: ${e.liquor_color}`);
    if (e.moulding) parts.push(`mould. ${e.moulding}`);
    if (e.oxytocin_mu != null) parts.push(`oxy ${e.oxytocin_mu}mU`);
    lines.push(parts.join(" | "));
    if (e.drugs_text) lines.push(`    gyógyszer: ${e.drugs_text}`);
    if (e.notes) lines.push(`    megj.: ${e.notes}`);
  });

  if (partogram.notes_md) {
    lines.push("");
    lines.push("MEGJEGYZÉSEK:");
    lines.push(partogram.notes_md);
  }
  return lines.join("\n");
}

export function downloadPartogramText(opts: PartogramExportInput) {
  const text = buildPartogramText(opts);
  const fname = `partogram_${(opts.patient?.vezeteknev ?? "beteg")}_${new Date().toISOString().slice(0, 10)}.txt`;
  const blob = new Blob(["\uFEFF" + text], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = fname;
  document.body.appendChild(a); a.click(); a.remove();
  URL.revokeObjectURL(url);
}

export function printPartogram(opts: PartogramExportInput) {
  const text = buildPartogramText(opts);
  const w = window.open("", "_blank", "width=900,height=1000");
  if (!w) return;
  const esc = (s: string) => s.replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]!));
  w.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>Partogram</title>
    <style>body{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:11px;padding:24px;white-space:pre-wrap;line-height:1.45;color:#111}@media print{body{padding:12mm}}</style>
    </head><body>${esc(text)}</body></html>`);
  w.document.close();
  w.focus();
  setTimeout(() => { w.print(); }, 250);
}


export function exportPartogramPdf(opts: {
  patient: Patient;
  encounter: Encounter;
  partogram: Partogram;
  entries: Entry[];
  alerts: string[];
}) {
  const { patient, encounter, partogram, entries, alerts } = opts;
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const margin = 12;
  let y = margin;

  doc.setFont("helvetica", "bold");
  doc.setFontSize(16);
  doc.text("Szülészeti partogram", margin, y);
  y += 7;

  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  const name = patient ? `${patient.vezeteknev ?? ""} ${patient.keresztnev ?? ""}`.trim() : "—";
  const dob = patient?.szuletesi_datum ?? "—";
  const enc = encounter ? `${encounter.encounter_type ?? ""} · ${encounter.start_ts ? new Date(encounter.start_ts).toLocaleString("hu-HU") : ""}` : "—";
  const laborStart = new Date(partogram.labor_start_ts).toLocaleString("hu-HU");

  doc.text(`Beteg: ${name}`, margin, y); y += 5;
  doc.text(`Születési dátum: ${dob}`, margin, y); y += 5;
  doc.text(`Epizód: ${enc}`, margin, y); y += 5;
  doc.text(`Vajúdás kezdete: ${laborStart}`, margin, y); y += 5;
  if (partogram.membrane_status) { doc.text(`Burok: ${partogram.membrane_status}`, margin, y); y += 5; }
  const pg = partogram.parity_gravida_json ?? {};
  if (pg && (pg.gravida || pg.para)) { doc.text(`G/P: ${pg.gravida ?? "?"}/${pg.para ?? "?"}`, margin, y); y += 5; }
  doc.text(`Generálva: ${new Date().toLocaleString("hu-HU")}`, margin, y); y += 7;

  if (alerts.length > 0) {
    doc.setFont("helvetica", "bold");
    doc.setTextColor(180, 60, 0);
    doc.text("Figyelmeztetések:", margin, y); y += 5;
    doc.setFont("helvetica", "normal");
    alerts.forEach((a) => { doc.text(`• ${a}`, margin + 2, y); y += 5; });
    doc.setTextColor(0, 0, 0);
    y += 2;
  }

  const labor0 = new Date(partogram.labor_start_ts).getTime();
  const rows = entries.map((e) => {
    const h = ((new Date(e.recorded_at).getTime() - labor0) / 3600000).toFixed(1);
    return [
      new Date(e.recorded_at).toLocaleString("hu-HU", { month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" }),
      h,
      e.cervix_cm ?? "—",
      e.descent_station ?? "—",
      e.fetal_heart_rate ?? "—",
      e.contractions_per_10min != null ? `${e.contractions_per_10min}${e.contraction_duration_sec ? `×${e.contraction_duration_sec}s` : ""}` : "—",
      e.maternal_bp_sys && e.maternal_bp_dia ? `${e.maternal_bp_sys}/${e.maternal_bp_dia}` : "—",
      e.maternal_hr ?? "—",
      e.temp_c ?? "—",
      e.liquor_color ?? "—",
      e.moulding ?? "—",
      e.oxytocin_mu ?? "—",
      [e.drugs_text, e.notes].filter(Boolean).join(" / ") || "—",
    ];
  });

  autoTable(doc, {
    startY: y,
    head: [["Idő", "Óra", "Méhszáj cm", "Station", "FHR", "Ctx/10p", "RR", "Pulzus", "Hőm °C", "Magzv.", "Mould.", "Oxy mU", "Megj."]],
    body: rows,
    styles: { fontSize: 7, cellPadding: 1.2 },
    headStyles: { fillColor: [37, 99, 235], textColor: 255, fontSize: 7 },
    margin: { left: margin, right: margin },
  });

  let finalY = (doc as any).lastAutoTable?.finalY ?? y;
  if (partogram.notes_md) {
    finalY += 6;
    if (finalY > 270) { doc.addPage(); finalY = margin; }
    doc.setFont("helvetica", "bold");
    doc.text("Megjegyzések:", margin, finalY); finalY += 5;
    doc.setFont("helvetica", "normal");
    const lines = doc.splitTextToSize(partogram.notes_md, 210 - margin * 2);
    doc.text(lines, margin, finalY);
  }

  const total = doc.getNumberOfPages();
  for (let i = 1; i <= total; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setTextColor(120);
    doc.text(`${i} / ${total}`, 210 - margin, 290, { align: "right" });
  }

  const fname = `partogram_${(patient?.vezeteknev ?? "beteg")}_${new Date().toISOString().slice(0, 10)}.pdf`;
  doc.save(fname);
}
