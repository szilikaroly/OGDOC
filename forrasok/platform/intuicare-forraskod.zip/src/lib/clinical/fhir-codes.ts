// LOINC / SNOMED catalog for the clinical module.
// Single source of truth for observation labels, units, ranges.

export type LoincItem = {
  loinc: string;
  hu: string;
  en: string;
  unit: string;
  category: "vital-signs" | "laboratory" | "exam" | "fluid-balance" | "pain" | "survey";
  ref?: { low?: number; high?: number; criticalLow?: number; criticalHigh?: number };
  step?: number;
  min?: number;
  max?: number;
};

export const LOINC: Record<string, LoincItem> = {
  // Vital signs
  HR: { loinc: "8867-4", hu: "Pulzus", en: "Heart rate", unit: "/min", category: "vital-signs",
    ref: { low: 60, high: 100, criticalLow: 40, criticalHigh: 130 }, step: 1, min: 20, max: 250 },
  RR: { loinc: "9279-1", hu: "Légzésszám", en: "Respiratory rate", unit: "/min", category: "vital-signs",
    ref: { low: 12, high: 20, criticalLow: 8, criticalHigh: 30 }, step: 1, min: 4, max: 60 },
  SBP: { loinc: "8480-6", hu: "Vérnyomás (szisztolés)", en: "Systolic BP", unit: "mmHg", category: "vital-signs",
    ref: { low: 90, high: 140, criticalLow: 70, criticalHigh: 180 }, step: 1, min: 40, max: 260 },
  DBP: { loinc: "8462-4", hu: "Vérnyomás (diasztolés)", en: "Diastolic BP", unit: "mmHg", category: "vital-signs",
    ref: { low: 60, high: 90, criticalLow: 40, criticalHigh: 120 }, step: 1, min: 20, max: 160 },
  TEMP: { loinc: "8310-5", hu: "Testhőmérséklet", en: "Body temperature", unit: "°C", category: "vital-signs",
    ref: { low: 36, high: 37.5, criticalLow: 35, criticalHigh: 39.5 }, step: 0.1, min: 30, max: 43 },
  SPO2: { loinc: "2708-6", hu: "SpO₂", en: "Oxygen saturation", unit: "%", category: "vital-signs",
    ref: { low: 95, high: 100, criticalLow: 90 }, step: 1, min: 50, max: 100 },
  WEIGHT: { loinc: "29463-7", hu: "Testsúly", en: "Body weight", unit: "kg", category: "vital-signs",
    step: 0.1, min: 0.5, max: 400 },
  HEIGHT: { loinc: "8302-2", hu: "Testmagasság", en: "Body height", unit: "cm", category: "vital-signs",
    step: 0.5, min: 20, max: 250 },
  BMI: { loinc: "39156-5", hu: "BMI", en: "Body mass index", unit: "kg/m²", category: "vital-signs",
    ref: { low: 18.5, high: 25 }, step: 0.1, min: 5, max: 80 },
  PAIN: { loinc: "72514-3", hu: "Fájdalom (VAS)", en: "Pain intensity 0-10", unit: "/10", category: "pain",
    ref: { high: 3, criticalHigh: 7 }, step: 1, min: 0, max: 10 },

  // Common labs
  GLUC: { loinc: "2345-7", hu: "Glükóz (vér)", en: "Glucose", unit: "mmol/L", category: "laboratory",
    ref: { low: 3.9, high: 6.1, criticalLow: 2.5, criticalHigh: 22 }, step: 0.1 },
  HBA1C: { loinc: "4548-4", hu: "HbA1c", en: "Hemoglobin A1c", unit: "%", category: "laboratory",
    ref: { high: 6.5 }, step: 0.1 },
  CREAT: { loinc: "2160-0", hu: "Kreatinin", en: "Creatinine", unit: "µmol/L", category: "laboratory",
    ref: { low: 53, high: 106 }, step: 1 },
  NA: { loinc: "2951-2", hu: "Nátrium", en: "Sodium", unit: "mmol/L", category: "laboratory",
    ref: { low: 135, high: 145, criticalLow: 120, criticalHigh: 160 }, step: 1 },
  K: { loinc: "2823-3", hu: "Kálium", en: "Potassium", unit: "mmol/L", category: "laboratory",
    ref: { low: 3.5, high: 5.1, criticalLow: 2.5, criticalHigh: 6.5 }, step: 0.1 },
  CL: { loinc: "2075-0", hu: "Klorid", en: "Chloride", unit: "mmol/L", category: "laboratory",
    ref: { low: 98, high: 107 }, step: 1 },
  HGB: { loinc: "718-7", hu: "Hemoglobin", en: "Hemoglobin", unit: "g/L", category: "laboratory",
    ref: { low: 120, high: 160, criticalLow: 70 }, step: 1 },
  CRP: { loinc: "1988-5", hu: "CRP", en: "C-reactive protein", unit: "mg/L", category: "laboratory",
    ref: { high: 5, criticalHigh: 100 }, step: 0.1 },
  PH: { loinc: "2744-1", hu: "pH (vérgáz)", en: "Blood pH", unit: "", category: "laboratory",
    ref: { low: 7.35, high: 7.45, criticalLow: 7.2, criticalHigh: 7.55 }, step: 0.01 },
  PCO2: { loinc: "2019-8", hu: "pCO₂", en: "pCO2", unit: "mmHg", category: "laboratory",
    ref: { low: 35, high: 45 }, step: 0.1 },
  PO2: { loinc: "2703-7", hu: "pO₂", en: "pO2", unit: "mmHg", category: "laboratory",
    ref: { low: 80, high: 100 }, step: 0.1 },
  HCO3: { loinc: "1963-8", hu: "HCO₃⁻", en: "Bicarbonate", unit: "mmol/L", category: "laboratory",
    ref: { low: 22, high: 26 }, step: 0.1 },
  LACT: { loinc: "2524-7", hu: "Laktát", en: "Lactate", unit: "mmol/L", category: "laboratory",
    ref: { high: 2, criticalHigh: 4 }, step: 0.1 },

  // Fluid balance
  FLUID_IN: { loinc: "9192-6", hu: "Bevitel", en: "Fluid intake", unit: "mL", category: "fluid-balance", step: 10 },
  FLUID_OUT: { loinc: "9187-6", hu: "Kiválasztás", en: "Fluid output", unit: "mL", category: "fluid-balance", step: 10 },
};

export type LoincKey = keyof typeof LOINC;

export const VITAL_KEYS: LoincKey[] = ["HR", "RR", "SBP", "DBP", "TEMP", "SPO2", "PAIN"];
export const ANTHROPOMETRY_KEYS: LoincKey[] = ["WEIGHT", "HEIGHT", "BMI"];
export const COMMON_LAB_KEYS: LoincKey[] = ["GLUC", "HBA1C", "CREAT", "NA", "K", "CL", "HGB", "CRP", "LACT"];
export const BLOODGAS_KEYS: LoincKey[] = ["PH", "PCO2", "PO2", "HCO3", "LACT", "NA", "K", "CL"];

export function interpretValue(key: LoincKey, value: number): LoincItem["category"] extends never ? string : "normal" | "low" | "high" | "critical-low" | "critical-high" {
  const ref = LOINC[key]?.ref;
  if (!ref) return "normal" as never;
  if (ref.criticalLow !== undefined && value <= ref.criticalLow) return "critical-low" as never;
  if (ref.criticalHigh !== undefined && value >= ref.criticalHigh) return "critical-high" as never;
  if (ref.low !== undefined && value < ref.low) return "low" as never;
  if (ref.high !== undefined && value > ref.high) return "high" as never;
  return "normal" as never;
}

export function formatRef(key: LoincKey): string {
  const r = LOINC[key]?.ref;
  if (!r) return "";
  if (r.low !== undefined && r.high !== undefined) return `${r.low}–${r.high} ${LOINC[key].unit}`;
  if (r.high !== undefined) return `< ${r.high} ${LOINC[key].unit}`;
  if (r.low !== undefined) return `> ${r.low} ${LOINC[key].unit}`;
  return "";
}
