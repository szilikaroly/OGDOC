import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

/**
 * Hang-alapú klinikai anamnézis / panaszfelvétel.
 * A kliens base64-be kódolt hangfelvételt küld (webm/mp4/wav), a
 * szerver a Lovable AI Gateway `/audio/transcriptions` végpontján
 * átiratozza. Ha a beszélő nem magyarul mondta, magyarra fordítjuk
 * egy gyors modellhívással.
 */
const Input = z.object({
  audio_base64: z.string().min(64),
  mime: z.string().min(3).max(64).default("audio/webm"),
  target_lang: z.string().min(2).max(8).default("hu"),
});

const EXT_MAP: Record<string, string> = {
  "audio/webm": "webm",
  "audio/mp4": "m4a",
  "audio/m4a": "m4a",
  "audio/mpeg": "mp3",
  "audio/mp3": "mp3",
  "audio/wav": "wav",
  "audio/x-wav": "wav",
  "audio/ogg": "ogg",
};

export const transcribeClinicalAudio = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => Input.parse(d))
  .handler(async ({ data }) => {
    const key = process.env.LOVABLE_API_KEY;
    if (!key) throw new Error("LOVABLE_API_KEY hiányzik");

    const mime = (data.mime.split(";")[0] || "audio/webm").trim();
    const ext = EXT_MAP[mime] ?? "webm";

    const bytes = Uint8Array.from(atob(data.audio_base64), (c) => c.charCodeAt(0));
    if (bytes.byteLength < 1024) {
      throw new Error("A hangfelvétel túl rövid vagy üres — próbáld újra.");
    }
    const blob = new Blob([bytes], { type: mime });

    const form = new FormData();
    form.append("model", "openai/gpt-4o-mini-transcribe");
    form.append("file", blob, `recording.${ext}`);

    const r = await fetch("https://ai.gateway.lovable.dev/v1/audio/transcriptions", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}` },
      body: form,
    });
    if (!r.ok) {
      const body = await r.text().catch(() => "");
      throw new Error(`Átirat hiba (${r.status}): ${body.slice(0, 200)}`);
    }
    const json = (await r.json()) as { text?: string };
    const original = (json.text ?? "").trim();
    if (!original) return { original_text: "", translated_text: "", detected_language: null };

    // Egyszerű nyelvi heurisztika: ha az eredeti szöveg tartalmaz magyar
    // ékezetes karaktereket, valószínűleg magyarul van — nem fordítjuk.
    const looksHungarian = /[őűáéíóúüö]/i.test(original);
    if (data.target_lang !== "hu" || looksHungarian) {
      return { original_text: original, translated_text: original, detected_language: looksHungarian ? "hu" : null };
    }

    try {
      const { createLovableAiGatewayProvider } = await import("@/lib/ai-gateway.server");
      const { generateText } = await import("ai");
      const gateway = createLovableAiGatewayProvider(key);
      const { text } = await generateText({
        model: gateway("google/gemini-3-flash-preview"),
        system:
          "Precíz orvosi tolmács vagy. Fordítsd magyarra az alábbi átiratot. Tartsd meg a neveket, dátumokat, mértékegységeket, gyógyszerneveket. CSAK a fordítást add vissza.",
        prompt: original,
      });
      return { original_text: original, translated_text: text.trim(), detected_language: null };
    } catch {
      return { original_text: original, translated_text: original, detected_language: null };
    }
  });
