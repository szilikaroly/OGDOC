// ADA 2025 inzulin kalkulátor — TDD, ISF, ICR, hatásmódosítók, korrekciós bólusz.
// Forrás: ADA Standards of Care 2025; magyar diabetológiai gyakorlat.

export type InsulinMode = "bb" | "premix2" | "premix3";
export type DiabetesType = "t1" | "t2" | "t2r" | "gest";
export type BolusType = "analog" | "regular";
export type MealRatio = "333" | "402040" | "204040" | "403030";

export type Modifiers = {
  steroid: boolean;
  ckd: boolean;
  surgery: boolean;
  infection: boolean;
  pregnancy: boolean;
  elderly: boolean;
  obese: boolean;
  enteral: boolean;
};

export const DEFAULT_MODIFIERS: Modifiers = {
  steroid: false, ckd: false, surgery: false, infection: false,
  pregnancy: false, elderly: false, obese: false, enteral: false,
};

export type InsulinInputs = {
  mode: InsulinMode;
  diabetesType: DiabetesType;
  weightKg: number;
  bolusType: BolusType;
  mealRatio: MealRatio;
  modifiers: Modifiers;
  currentVc: number | null;
  targetVc: number;
};

export type InsulinResult = {
  tdd: number;
  baseTdd: number;
  baseFactor: number;
  modifierFactor: number;
  basal: number;
  bolusTotal: number;
  doses: { r: number; d: number; e: number; b: number };
  icr: number;
  isf: number;
  correctionBolus: number | null;
  hypoBlock: boolean;
  modifierNotes: string[];
};

const BASE_FACTOR: Record<DiabetesType, number> = {
  t1: 0.5,
  t2: 0.3,   // inzulin-naiv
  t2r: 0.4,  // alapozott / már inzulinkezelt
  gest: 0.4,
};

const MODIFIER_DEF: Array<{ k: keyof Modifiers; delta: number; label: string }> = [
  { k: "steroid", delta: 0.25, label: "Szteroid (+25%)" },
  { k: "ckd", delta: -0.20, label: "CKD eGFR<45 (−20%)" },
  { k: "surgery", delta: 0.10, label: "Perioperatív (+10%)" },
  { k: "infection", delta: 0.15, label: "Akut infekció (+15%)" },
  { k: "pregnancy", delta: 0.10, label: "Terhesség (+10%)" },
  { k: "elderly", delta: -0.15, label: "Idős/frailty (−15%)" },
  { k: "obese", delta: 0.10, label: "Obesitas BMI>35 (+10%)" },
  { k: "enteral", delta: -0.20, label: "Enterális/parenterális (−20%)" },
];

function splitBB(total: number, ratio: MealRatio) {
  // BB: 50% bázis, 50% prandiális — étrendi arányban szétosztva (r/d/e).
  const basal = round1(total * 0.5);
  const meal = total - basal;
  const map: Record<MealRatio, [number, number, number]> = {
    "333": [1 / 3, 1 / 3, 1 / 3],
    "402040": [0.4, 0.2, 0.4],
    "204040": [0.2, 0.4, 0.4],
    "403030": [0.4, 0.3, 0.3],
  };
  const [rr, dd, ee] = map[ratio];
  return { basal, r: round1(meal * rr), d: round1(meal * dd), e: round1(meal * ee), b: 0 };
}

function splitPremix2(total: number) {
  // Premix 2× — reggel 2/3, este 1/3
  return { basal: 0, r: round1(total * (2 / 3)), d: 0, e: round1(total * (1 / 3)), b: 0 };
}

function splitPremix3(total: number) {
  // Premix 3× — 40/20/40
  return { basal: 0, r: round1(total * 0.4), d: round1(total * 0.2), e: round1(total * 0.4), b: 0 };
}

export function round1(n: number): number {
  return Math.round(n * 10) / 10;
}

export function calculateInsulin(input: InsulinInputs): InsulinResult {
  const baseFactor = BASE_FACTOR[input.diabetesType];
  const baseTdd = input.weightKg * baseFactor;

  // Hatásmódosítók: szorzótényezők összegzése (1 + Σδ), clamp 0.4..2.0
  const notes: string[] = [];
  let factor = 1;
  for (const m of MODIFIER_DEF) {
    if (input.modifiers[m.k]) {
      factor += m.delta;
      notes.push(m.label);
    }
  }
  factor = Math.max(0.4, Math.min(2.0, factor));
  const tdd = round1(baseTdd * factor);

  let parts: { basal: number; r: number; d: number; e: number; b: number };
  if (input.mode === "bb") parts = splitBB(tdd, input.mealRatio);
  else if (input.mode === "premix2") parts = splitPremix2(tdd);
  else parts = splitPremix3(tdd);

  const bolusTotal = round1(parts.r + parts.d + parts.e + parts.b);

  // ISF (mmol/L csökkenés 1 NE-re) — ADA: 100 / TDD (mg/dL → mmol/L átkonvertálva: ~1.8/TDD).
  // ICR (g szénhidrát / 1 NE) — analog: 500/TDD, regular: 450/TDD.
  const isf = round1(1.8 / tdd * 10) / 10; // mmol/L per NE, kerekítés 0.1
  const isfFinal = round1(100 / tdd / 18); // ≈ konvencionális mmol/L per NE
  const icr = round1((input.bolusType === "analog" ? 500 : 450) / tdd);

  // Korrekciós bólusz
  let correction: number | null = null;
  let hypoBlock = false;
  if (input.currentVc !== null && !Number.isNaN(input.currentVc)) {
    if (input.currentVc < 3.9) {
      hypoBlock = true;
    } else {
      const diff = input.currentVc - input.targetVc;
      const c = diff / Math.max(0.1, isfFinal);
      correction = round1(Math.max(0, c));
    }
  }

  return {
    tdd,
    baseTdd: round1(baseTdd),
    baseFactor,
    modifierFactor: round1(factor * 100) / 100,
    basal: parts.basal,
    bolusTotal,
    doses: { r: parts.r, d: parts.d, e: parts.e, b: parts.b },
    icr,
    isf: isfFinal,
    correctionBolus: correction,
    hypoBlock,
    modifierNotes: notes,
  };
}

// Készítmény-katalógus
export const INSULIN_PREPS = {
  bolus: [
    { id: "novorapid", name: "NovoRapid (aspart)", kind: "analog" },
    { id: "humalog", name: "Humalog (lispro)", kind: "analog" },
    { id: "apidra", name: "Apidra (glulisine)", kind: "analog" },
    { id: "fiasp", name: "Fiasp (fast aspart)", kind: "analog" },
    { id: "lyumjev", name: "Lyumjev (ultra-rapid lispro)", kind: "analog" },
    { id: "humulinr", name: "Humulin R (regular)", kind: "regular" },
    { id: "actrapid", name: "Actrapid (regular)", kind: "regular" },
  ],
  basal: [
    { id: "toujeo", name: "Toujeo (glargine U300)", kind: "analog" },
    { id: "tresiba", name: "Tresiba (degludec)", kind: "analog" },
    { id: "lantus", name: "Lantus (glargine U100)", kind: "analog" },
    { id: "levemir", name: "Levemir (detemir)", kind: "analog" },
    { id: "humulinn", name: "Humulin N (NPH)", kind: "nph" },
    { id: "insulatard", name: "Insulatard (NPH)", kind: "nph" },
  ],
  premix: [
    { id: "novomix30", name: "NovoMix 30 (aspart 30/70)", kind: "analog-mix" },
    { id: "humalogmix25", name: "Humalog Mix25 (lispro 25/75)", kind: "analog-mix" },
    { id: "humalogmix50", name: "Humalog Mix50 (lispro 50/50)", kind: "analog-mix" },
    { id: "ryzodeg", name: "Ryzodeg (degludec/aspart 70/30)", kind: "co-formula" },
    { id: "humulinm3", name: "Humulin M3 (regular/NPH 30/70)", kind: "regular-mix" },
  ],
};
