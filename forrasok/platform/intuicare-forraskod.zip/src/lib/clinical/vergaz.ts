// Vérgáz Elemző — kliensoldali számítások.
// Pure functions, no React.

export type VergazInput = {
  pH?: number;
  pCO2?: number;        // mmHg
  pO2?: number;         // mmHg
  HCO3?: number;        // mmol/L
  BE?: number;          // mmol/L
  sO2?: number;         // %
  FiO2?: number;        // %  (default 21)
  Hb?: number;          // g/L
  laktat?: number;      // mmol/L
  Na?: number; K?: number; Cl?: number;
  Ca?: number; Mg?: number; albumin?: number; // g/L
  glukoz?: number; urea?: number; kreatinin?: number; // µmol/L
  ozm_mert?: number;
  bOHB?: number;
  testsuly?: number;
  tudat?: "eber" | "konfuz" | "somnolens" | "coma";
};

export type VergazResult = {
  hco3Calc?: number;          // calculated from H-H
  hco3Source: "measured" | "calculated" | "missing";
  AG?: number;
  cAG?: number;               // albumin corrected
  expectedCO2Winter?: number; // for metab acidosis
  expectedCO2MetAlk?: number; // for metab alkalosis
  AAGradient?: number;
  PFRatio?: number;           // pO2 / FiO2 (FiO2 fraction)
  osmCalc?: number;
  osmGap?: number;
  deltaRatio?: number;        // (AG-12)/(24-HCO3)
  primary?: string;
  compensation?: string;
  severity?: "normal" | "mild" | "moderate" | "severe";
  ddx: string[];
  warnings: string[];
  interpretation: string;
};

export function analyzeBloodGas(i: VergazInput): VergazResult {
  const r: VergazResult = { hco3Source: "missing", ddx: [], warnings: [], interpretation: "" };

  // HCO3 — measured or H-H calculated
  if (i.HCO3 !== undefined && Number.isFinite(i.HCO3)) {
    r.hco3Calc = i.HCO3;
    r.hco3Source = "measured";
  } else if (i.pH !== undefined && i.pCO2 !== undefined) {
    r.hco3Calc = 0.03 * i.pCO2 * Math.pow(10, i.pH - 6.1);
    r.hco3Source = "calculated";
  }
  const HCO3 = r.hco3Calc;

  // Anion gap
  if (i.Na !== undefined && i.Cl !== undefined && HCO3 !== undefined) {
    r.AG = i.Na - (i.Cl + HCO3);
    if (i.albumin !== undefined) r.cAG = r.AG + 0.25 * (40 - i.albumin);
  }

  // Acid-base classification
  if (i.pH !== undefined && i.pCO2 !== undefined && HCO3 !== undefined) {
    const pH = i.pH;
    const pCO2 = i.pCO2;
    const acidemia = pH < 7.35;
    const alkalemia = pH > 7.45;
    let primary = "Normál sav-bázis";

    if (acidemia) {
      if (HCO3 < 22) {
        primary = "Metabolikus acidózis";
        r.expectedCO2Winter = 1.5 * HCO3 + 8; // ±2
      } else if (pCO2 > 45) {
        primary = "Respiratorikus acidózis";
      } else {
        primary = "Acidózis (kevert)";
      }
    } else if (alkalemia) {
      if (HCO3 > 26) {
        primary = "Metabolikus alkalózis";
        r.expectedCO2MetAlk = 0.7 * HCO3 + 21;
      } else if (pCO2 < 35) {
        primary = "Respiratorikus alkalózis";
      } else {
        primary = "Alkalózis (kevert)";
      }
    } else {
      // pH normal — check for compensated or mixed
      if (HCO3 < 22 && pCO2 < 35) primary = "Kompenzált metabolikus acidózis / kevert";
      else if (HCO3 > 26 && pCO2 > 45) primary = "Kompenzált metabolikus alkalózis / kevert";
    }
    r.primary = primary;

    // Compensation comment
    if (r.expectedCO2Winter !== undefined) {
      const dev = pCO2 - r.expectedCO2Winter;
      r.compensation = Math.abs(dev) <= 2
        ? "Megfelelő respiratorikus kompenzáció (Winter)."
        : dev > 2
          ? "Elégtelen respiratorikus kompenzáció — egyidejű respiratorikus acidózis."
          : "Túlkompenzáció — egyidejű respiratorikus alkalózis.";
    } else if (r.expectedCO2MetAlk !== undefined) {
      const dev = pCO2 - r.expectedCO2MetAlk;
      r.compensation = Math.abs(dev) <= 5
        ? "Megfelelő respiratorikus kompenzáció."
        : dev > 5 ? "Egyidejű respiratorikus acidózis." : "Egyidejű respiratorikus alkalózis.";
    }

    // Delta-delta
    if (r.AG !== undefined && r.AG > 12) {
      const deltaAG = r.AG - 12;
      const deltaHCO3 = 24 - HCO3;
      if (deltaHCO3 > 0) r.deltaRatio = deltaAG / deltaHCO3;
    }

    // Severity by pH
    if (pH < 7.20 || pH > 7.55) r.severity = "severe";
    else if (pH < 7.30 || pH > 7.50) r.severity = "moderate";
    else if (acidemia || alkalemia) r.severity = "mild";
    else r.severity = "normal";
  }

  // Oxygenation
  const FiO2frac = (i.FiO2 ?? 21) / 100;
  if (i.pO2 !== undefined) {
    r.PFRatio = i.pO2 / FiO2frac;
    if (i.pCO2 !== undefined) {
      // A-a gradient at sea level (PB=760, PH2O=47, R=0.8)
      const PAO2 = FiO2frac * (760 - 47) - i.pCO2 / 0.8;
      r.AAGradient = PAO2 - i.pO2;
    }
  }

  // Osmolality
  if (i.Na !== undefined && i.glukoz !== undefined && i.urea !== undefined) {
    r.osmCalc = 2 * i.Na + i.glukoz + i.urea;
    if (i.ozm_mert !== undefined) r.osmGap = i.ozm_mert - r.osmCalc;
  }

  // DDx hints
  if (r.AG !== undefined && r.AG > 12) {
    r.ddx.push("HAGMA (high AG metab. acidózis) — MUDPILES / GOLD MARK: laktát, ketózis (DKA, alkohol), urémia, methanol, etilénglikol, salicilát.");
  }
  if (r.AG !== undefined && r.AG <= 12 && r.primary === "Metabolikus acidózis") {
    r.ddx.push("NAGMA (normál AG) — hasmenés, RTA, korai veseelégtelenség.");
  }
  if (i.laktat !== undefined && i.laktat >= 4) r.ddx.push(`Súlyos hyperlaktatémia (${i.laktat} mmol/L) — sepsis, shock, hipoperfúzió.`);
  if (i.bOHB !== undefined && i.bOHB >= 3) r.ddx.push(`Ketózis (β-OHB ${i.bOHB} mmol/L) — DKA gyanú.`);
  if (r.osmGap !== undefined && r.osmGap > 10) r.ddx.push(`Emelkedett ozmolalitás-gap (${r.osmGap.toFixed(1)}) — methanol, etilénglikol gyanú.`);
  if (r.PFRatio !== undefined && r.PFRatio < 300) {
    const sev = r.PFRatio < 100 ? "súlyos" : r.PFRatio < 200 ? "közepes" : "enyhe";
    r.ddx.push(`ARDS-kritérium (${sev}) — P/F arány ${Math.round(r.PFRatio)}.`);
  }

  // Warnings
  if (i.pH !== undefined && (i.pH < 7.2 || i.pH > 7.55)) r.warnings.push("Életveszélyes pH — azonnali beavatkozás.");
  if (i.K !== undefined && (i.K < 3.0 || i.K > 6.0)) r.warnings.push(`Kritikus K⁺ (${i.K} mmol/L).`);
  if (i.Na !== undefined && (i.Na < 125 || i.Na > 155)) r.warnings.push(`Kritikus Na⁺ (${i.Na} mmol/L).`);

  // Compact interpretation
  const parts: string[] = [];
  if (r.primary) parts.push(r.primary);
  if (r.severity) parts.push(`(${r.severity})`);
  if (r.compensation) parts.push("— " + r.compensation);
  r.interpretation = parts.join(" ");

  return r;
}
