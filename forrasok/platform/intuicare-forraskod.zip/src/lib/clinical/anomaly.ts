/**
 * Egyszerű z-score alapú anomália detektálás idősorra.
 * Egy pontot anomáliásnak jelölünk, ha |z| >= threshold (default 2).
 * Robusztusabb verzióhoz mediánt + MAD-ot használunk az átlag+szórás helyett,
 * mert a klinikai sorokban előforduló outlierek torzítják a paraméteres számítást.
 */
export type AnomalyPoint = {
  ts: string;
  value: number;
  z: number;
  isAnomaly: boolean;
};

export function detectAnomalies(
  series: { ts: string; value: number }[],
  opts: { threshold?: number; window?: number } = {},
): AnomalyPoint[] {
  const threshold = opts.threshold ?? 2;
  const window = opts.window ?? Math.min(30, series.length);
  if (series.length < 4) return series.map((s) => ({ ...s, z: 0, isAnomaly: false }));

  return series.map((point, i) => {
    const start = Math.max(0, i - window);
    const slice = series.slice(start, i + 1).map((s) => s.value);
    const sorted = [...slice].sort((a, b) => a - b);
    const median = sorted[Math.floor(sorted.length / 2)];
    const deviations = slice.map((v) => Math.abs(v - median)).sort((a, b) => a - b);
    const mad = deviations[Math.floor(deviations.length / 2)] || 1e-9;
    const z = (0.6745 * (point.value - median)) / mad;
    return { ts: point.ts, value: point.value, z, isAnomaly: Math.abs(z) >= threshold };
  });
}
