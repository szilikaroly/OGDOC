import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

// === SZÁMÍTÓK ===

export const getGyakorlatiIdo = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { userId: string; datum?: string }) => d)
  .handler(async ({ data, context }) => {
    const { data: rows, error } = await context.supabase
      .rpc("calc_gyakorlati_ido", { p_user_id: data.userId, p_datum: data.datum ?? new Date().toISOString().slice(0, 10) });
    if (error) throw new Error(error.message);
    const r = (rows as any)?.[0] ?? { napok: 0, evek: 0 };
    return { napok: Number(r.napok ?? 0), evek: Number(r.evek ?? 0) };
  });

export const getJubileumiIdo = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { userId: string; datum?: string }) => d)
  .handler(async ({ data, context }) => {
    const { data: rows, error } = await context.supabase
      .rpc("calc_jubileumi_ido", { p_user_id: data.userId, p_datum: data.datum ?? new Date().toISOString().slice(0, 10) });
    if (error) throw new Error(error.message);
    const r = (rows as any)?.[0] ?? { napok: 0, evek: 0 };
    return { napok: Number(r.napok ?? 0), evek: Number(r.evek ?? 0) };
  });

export const getIlletmeny = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { userId: string; datum?: string }) => d)
  .handler(async ({ data, context }) => {
    const { data: rows, error } = await context.supabase
      .rpc("calc_illetmeny", { p_user_id: data.userId, p_datum: data.datum ?? new Date().toISOString().slice(0, 10) });
    if (error) throw new Error(error.message);
    const r = (rows as any)?.[0] ?? {};
    return {
      alap_ft: Number(r.alap_ft ?? 0),
      sav: String(r.sav ?? "nincs_besorolas"),
      vezetoi_szorzo: Number(r.vezetoi_szorzo ?? 1),
      vegso_ft: Number(r.vegso_ft ?? 0),
      gyakorlati_evek: Number(r.gyakorlati_evek ?? 0),
    };
  });

// === SZOLGÁLATI ELŐZMÉNY ===

export const listServiceHistory = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { userId: string }) => d)
  .handler(async ({ data, context }) => {
    const { data: rows, error } = await context.supabase
      .from("profile_service_history")
      .select("*")
      .eq("user_id", data.userId)
      .order("kezdo_datum", { ascending: true });
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

export const upsertServiceHistory = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: {
    id?: string;
    user_id: string;
    tenant_id: string;
    munkaltato_nev: string;
    fenntarto_tipus: string;
    munkakor?: string | null;
    kezdo_datum: string;
    zaro_datum?: string | null;
    beszamithato_eusztv: boolean;
    beszamithato_jubileum: boolean;
    forras: string;
    megjegyzes?: string | null;
  }) => d)
  .handler(async ({ data, context }) => {
    const payload = { ...data, rogzitette_user_id: context.userId };
    const { error } = data.id
      ? await context.supabase.from("profile_service_history").update(payload).eq("id", data.id)
      : await context.supabase.from("profile_service_history").insert(payload as any);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteServiceHistory = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { id: string }) => d)
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("profile_service_history").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const bulkInsertServiceHistory = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: {
    user_id: string;
    tenant_id: string;
    rows: Array<{
      munkaltato_nev: string;
      fenntarto_tipus: string;
      munkakor?: string | null;
      kezdo_datum: string;
      zaro_datum?: string | null;
      beszamithato_eusztv: boolean;
      beszamithato_jubileum: boolean;
    }>;
  }) => d)
  .handler(async ({ data, context }) => {
    if (!data.rows.length) return { ok: true, inserted: 0 };
    const payload = data.rows.map((r) => ({
      ...r,
      user_id: data.user_id,
      tenant_id: data.tenant_id,
      forras: "dokumentum",
      rogzitette_user_id: context.userId,
    }));
    const { error } = await context.supabase.from("profile_service_history").insert(payload as any);
    if (error) throw new Error(error.message);
    return { ok: true, inserted: payload.length };
  });

export const overrideServiceTime = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: {
    user_id: string;
    tenant_id: string;
    tipus: "gyakorlati_ido" | "jubileumi";
    napok_korrekcio: number;
    indok: string;
  }) => d)
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("profile_service_time_overrides")
      .insert({ ...data, jovahagyo_user_id: context.userId } as any);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// === BÉRTÁBLA ===

export const listWageTable = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { tabla_tipus?: "orvos_1mell" | "szakdolgozo_1a_mell" }) => d)
  .handler(async ({ data, context }) => {
    let q = context.supabase.from("wage_table_egeszsegugyi").select("*").order("ervenyes_tol", { ascending: false }).order("gyakorlati_ido_tol_ev", { ascending: true, nullsFirst: true });
    if (data.tabla_tipus) q = q.eq("tabla_tipus", data.tabla_tipus);
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

export const upsertWageRow = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: {
    id?: string;
    tenant_id?: string | null;
    tabla_tipus: "orvos_1mell" | "szakdolgozo_1a_mell";
    besorolasi_kategoria: string;
    fizetesi_fokozat: number;
    fizetesi_osztaly?: string | null;
    munkakor_megnevezes?: string | null;
    gyakorlati_ido_tol_ev?: number | null;
    gyakorlati_ido_ig_ev?: number | null;
    osszeg_ft: number;
    vezeto_szorzo?: number;
    ervenyes_tol: string;
    ervenyes_ig?: string | null;
  }) => d)
  .handler(async ({ data, context }) => {
    const payload = { ...data, alapilletmeny_ft: data.osszeg_ft };
    const { error } = data.id
      ? await context.supabase.from("wage_table_egeszsegugyi").update(payload).eq("id", data.id)
      : await context.supabase.from("wage_table_egeszsegugyi").insert(payload as any);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// === GENERIKUS LISTA — egyszerű CRUD-kompatibilis ===

export const listEusztvRows = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { table: string; userId?: string }) => d)
  .handler(async ({ data, context }) => {
    const allowed = ["osszeferhetetlenseg_engedelyek", "minosites", "szolgalati_elismeres", "vegkielegites_szamitasok", "juttatasok", "kirendelesek", "probaidok"];
    if (!allowed.includes(data.table)) throw new Error("Tiltott tábla");
    let q = context.supabase.from(data.table as any).select("*").order("created_at", { ascending: false });
    if (data.userId) q = q.eq("user_id", data.userId);
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

export const upsertEusztvRow = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { table: string; id?: string; values: Record<string, any> }) => d)
  .handler(async ({ data, context }) => {
    const allowed = ["osszeferhetetlenseg_engedelyek", "minosites", "szolgalati_elismeres", "vegkielegites_szamitasok", "juttatasok", "kirendelesek", "probaidok"];
    if (!allowed.includes(data.table)) throw new Error("Tiltott tábla");
    const { error } = data.id
      ? await context.supabase.from(data.table as any).update(data.values).eq("id", data.id)
      : await context.supabase.from(data.table as any).insert(data.values as any);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteEusztvRow = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { table: string; id: string }) => d)
  .handler(async ({ data, context }) => {
    const allowed = ["osszeferhetetlenseg_engedelyek", "minosites", "szolgalati_elismeres", "vegkielegites_szamitasok", "juttatasok", "kirendelesek", "probaidok", "profile_service_time_overrides"];
    if (!allowed.includes(data.table)) throw new Error("Tiltott tábla");
    const { error } = await context.supabase.from(data.table as any).delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
