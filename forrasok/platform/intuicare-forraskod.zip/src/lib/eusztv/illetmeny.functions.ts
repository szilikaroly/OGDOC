/**
 * Karakterlap illetmény-modul szerver-függvényei:
 *  - időszakos havi munkaidő-keret (CRUD)
 *  - mentett illetmény-snapshotok (CRUD)
 *  - Eüsztv. lefedettségi mátrix lekérdezés
 */
import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

/* =====================  WORK-TIME FRAME  ===================== */

export const listWorkTimeFrames = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { userId: string }) => d)
  .handler(async ({ data, context }) => {
    const { data: rows, error } = await context.supabase
      .from("profile_work_time_frame" as any)
      .select("*")
      .eq("user_id", data.userId)
      .order("ervenyes_tol", { ascending: false });
    if (error) throw new Error(error.message);
    return (rows as any[]) ?? [];
  });

// ISO nap (YYYY-MM-DD) — cross-checkoljuk, hogy valid dátum
const isoDate = z
  .string()
  .regex(/^\d{4}-\d{2}-\d{2}$/, "ISO nap (YYYY-MM-DD) formátum kötelező")
  .refine((s) => !Number.isNaN(new Date(`${s}T00:00:00Z`).getTime()), "Érvénytelen dátum");

const FrameSchema = z
  .object({
    id: z.string().uuid().optional(),
    // user_id / tenant_id kliensről érkezik, de a szerver felülírja az auth. userrel
    user_id: z.string().uuid(),
    tenant_id: z.string().uuid(),
    ervenyes_tol: isoDate,
    ervenyes_ig: isoDate.nullable().optional(),
    havi_orakeret: z
      .number()
      .finite()
      .min(0, "Havi órakeret nem lehet negatív")
      .max(744, "Havi órakeret nem lehet több, mint 744 (31×24 óra)")
      .nullable()
      .optional(),
    szazalek: z
      .number()
      .finite()
      .min(0, "Százalék nem lehet negatív")
      .max(200, "Százalék legfeljebb 200 lehet")
      .nullable()
      .optional(),
    indok: z.string().trim().max(500, "Indok max. 500 karakter").nullable().optional(),
  })
  .refine(
    (d) => !d.ervenyes_ig || d.ervenyes_ig >= d.ervenyes_tol,
    { message: "Az érvényesség vége nem lehet korábbi, mint a kezdete", path: ["ervenyes_ig"] },
  )
  .refine(
    (d) => d.havi_orakeret != null || d.szazalek != null,
    { message: "Adj meg havi órakeretet vagy százalékot", path: ["havi_orakeret"] },
  );

/** A bejelentkezett user tenant_id-je (authoritative). */
async function getUserTenantId(supabase: any, userId: string): Promise<string | null> {
  const { data, error } = await supabase
    .from("profiles")
    .select("tenant_id")
    .eq("id", userId)
    .maybeSingle();
  if (error) return null;
  return (data?.tenant_id as string | null) ?? null;
}

export const upsertWorkTimeFrame = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => FrameSchema.parse(d))
  .handler(async ({ data, context }) => {
    // Szerveroldali authoritative értékek — a kliens által küldött user_id/tenant_id-t felülírjuk
    const tenantId = await getUserTenantId(context.supabase, context.userId);
    if (!tenantId) throw new Error("A felhasználóhoz nincs tenant hozzárendelve.");

    // Update esetén ellenőrizzük, hogy a rekord tényleg a felhasználóé (védelem forge-olt ID ellen)
    if (data.id) {
      const { data: existing, error: exErr } = await context.supabase
        .from("profile_work_time_frame" as any)
        .select("id, user_id")
        .eq("id", data.id)
        .maybeSingle();
      if (exErr) throw new Error(exErr.message);
      if (!existing || (existing as any).user_id !== context.userId) {
        throw new Error("Nem módosíthatsz másik felhasználó munkaidő-keretét.");
      }
    }

    const payload = {
      ...data,
      user_id: context.userId, // felülírás
      tenant_id: tenantId, // felülírás
      rogzitette_user_id: context.userId,
    };
    const { error } = data.id
      ? await context.supabase.from("profile_work_time_frame" as any).update(payload).eq("id", data.id)
      : await context.supabase.from("profile_work_time_frame" as any).insert(payload as any);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteWorkTimeFrame = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { id: string }) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    // Csak saját sorát törölheti — explicit user_id feltétel az id mellé
    const { error } = await context.supabase
      .from("profile_work_time_frame" as any)
      .delete()
      .eq("id", data.id)
      .eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/** Aktív munkaidő-keret egy adott napra. */
export const getActiveWorkTimeFrame = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { userId: string; datum?: string }) => d)
  .handler(async ({ data, context }) => {
    const datum = data.datum ?? new Date().toISOString().slice(0, 10);
    const { data: rows, error } = await context.supabase
      .from("profile_work_time_frame" as any)
      .select("*")
      .eq("user_id", data.userId)
      .lte("ervenyes_tol", datum)
      .order("ervenyes_tol", { ascending: false })
      .limit(10);
    if (error) throw new Error(error.message);
    const aktiv = (rows as any[])?.find(
      (r) => !r.ervenyes_ig || r.ervenyes_ig >= datum,
    );
    return aktiv ?? null;
  });

/* =====================  ILLETMENY SNAPSHOTS  ===================== */

export const listIlletmenySnapshots = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { userId: string }) => d)
  .handler(async ({ data, context }) => {
    const { data: rows, error } = await context.supabase
      .from("illetmeny_snapshots" as any)
      .select("*")
      .eq("user_id", data.userId)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return (rows as any[]) ?? [];
  });

/** Numerikus mezők bemenetből/eredményből — egyike sem negatív, korlátozott felső határ. */
const MAX_FT = 1_000_000_000; // 1 milliárd Ft — bőven felette bármely reális havi tétel
const MAX_TETEL = 200; // egyéb díjak / korrekciók / hivatkozások max db

const numericFtField = z.number().finite();
const nonNegNumericFtField = z.number().finite().min(0).max(MAX_FT);

const TetelSchema = z.object({
  cimke: z.string().max(200),
  osszeg: numericFtField.min(-MAX_FT).max(MAX_FT),
});

const BemenetSchema = z
  .object({
    orakeret: z.number().finite().min(0).max(744).optional(),
    ugyHetkoznap: z.number().finite().min(0).max(744).optional(),
    ugyHetvege: z.number().finite().min(0).max(744).optional(),
    ugyUnnep: z.number().finite().min(0).max(744).optional(),
    potHetkoznap: z.number().finite().min(0).max(500).optional(),
    potHetvege: z.number().finite().min(0).max(500).optional(),
    potUnnep: z.number().finite().min(0).max(500).optional(),
    keszenletOra: z.number().finite().min(0).max(744).optional(),
    keszenletPot: z.number().finite().min(0).max(500).optional(),
    havi: nonNegNumericFtField.optional(),
    oradij: nonNegNumericFtField.optional(),
    vezetoiSzorzo: z.number().finite().min(0).max(10).optional(),
    alap_ft: nonNegNumericFtField.optional(),
    egyebOsszesen: numericFtField.min(-MAX_FT).max(MAX_FT).optional(),
    korrOsszesen: numericFtField.min(-MAX_FT).max(MAX_FT).optional(),
    egyebDijak: z.array(TetelSchema).max(MAX_TETEL).optional(),
    korrekciok: z.array(TetelSchema).max(MAX_TETEL).optional(),
  })
  .catchall(z.unknown()); // egyéb ismeretlen mezőket megőrzünk, de nem validáljuk típust

const EredmenySchema = z
  .object({
    ugyHetkoznapOsszeg: nonNegNumericFtField.optional(),
    ugyHetvegeOsszeg: nonNegNumericFtField.optional(),
    ugyUnnepOsszeg: nonNegNumericFtField.optional(),
    keszenletOsszeg: nonNegNumericFtField.optional(),
    ugyOsszesen: nonNegNumericFtField.optional(),
    vegosszeg: nonNegNumericFtField.optional(),
  })
  .catchall(z.unknown());

const SnapSchema = z.object({
  user_id: z.string().uuid(),
  tenant_id: z.string().uuid(),
  cimke: z.string().trim().min(1, "Címke kötelező").max(200, "Címke max. 200 karakter"),
  vonatkozasi_datum: isoDate,
  bemenet: BemenetSchema,
  eredmeny: EredmenySchema,
  vegosszeg_ft: z.number().finite().min(0, "Végösszeg nem lehet negatív").max(MAX_FT),
  jogi_hivatkozasok: z.array(z.unknown()).max(MAX_TETEL),
});

export const saveIlletmenySnapshot = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => SnapSchema.parse(d))
  .handler(async ({ data, context }) => {
    // Authoritative user_id / tenant_id — a kliens által küldött mezőket felülírjuk
    const tenantId = await getUserTenantId(context.supabase, context.userId);
    if (!tenantId) throw new Error("A felhasználóhoz nincs tenant hozzárendelve.");

    // Sanity: az eredmény.vegosszeg (ha jelen van) egyezzen a top-level vegosszeg_ft-tel
    // 1 Ft tolerancia kerekítésre.
    const eredmenyVeg = data.eredmeny.vegosszeg;
    if (typeof eredmenyVeg === "number" && Math.abs(eredmenyVeg - data.vegosszeg_ft) > 1) {
      throw new Error(
        `Ellentmondó végösszeg: eredmeny.vegosszeg (${eredmenyVeg}) ≠ vegosszeg_ft (${data.vegosszeg_ft}).`,
      );
    }

    // Vonatkozási dátum nem lehet 10 évnél régebbi, se 1 évnél későbbi (jövőbeli tervezés OK)
    const dnum = new Date(`${data.vonatkozasi_datum}T00:00:00Z`).getTime();
    const now = Date.now();
    if (dnum < now - 10 * 365 * 86400_000 || dnum > now + 365 * 86400_000) {
      throw new Error("Vonatkozási dátum ésszerűtlen (10 év vissza / 1 év előre).");
    }

    // Payload — user_id és tenant_id kényszerítve az auth. contextből
    const payload = {
      ...data,
      user_id: context.userId,
      tenant_id: tenantId,
      created_by: context.userId,
    };

    const { data: row, error } = await context.supabase
      .from("illetmeny_snapshots" as any)
      .insert(payload as any)
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    return { ok: true, id: (row as any).id as string };
  });

export const deleteIlletmenySnapshot = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { id: string }) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    // Csak saját snapshotját törölheti — explicit user_id feltétel
    const { error } = await context.supabase
      .from("illetmeny_snapshots" as any)
      .delete()
      .eq("id", data.id)
      .eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/* =====================  EUSZTV COVERAGE MATRIX  ===================== */

/** Statikus Eüsztv. szakasz-katalógus → ezeket próbáljuk minimum-lefedni. */
const EUSZTV_SECTIONS: Array<{
  szakasz: string;
  cim: string;
  tabla: string;
  filter?: Record<string, unknown>;
  min: number;
}> = [
  { szakasz: "3. §", cim: "Próbaidő", tabla: "probaidok", min: 1 },
  { szakasz: "4. §", cim: "Összeférhetetlenség", tabla: "osszeferhetetlenseg_engedelyek", min: 1 },
  { szakasz: "5. § / 16. §", cim: "Munkaidő szabályok", tabla: "work_time_rules", min: 1 },
  { szakasz: "6. §", cim: "Szabadság szabályzat", tabla: "leave_policy", min: 1 },
  { szakasz: "7. §", cim: "Minősítés", tabla: "minosites", min: 1 },
  { szakasz: "8. § + 1. melléklet", cim: "Bértábla — orvosi", tabla: "wage_table_egeszsegugyi", filter: { tabla_tipus: "orvos_1mell" }, min: 1 },
  { szakasz: "8. § + 1/A. melléklet", cim: "Bértábla — szakdolgozói", tabla: "wage_table_egeszsegugyi", filter: { tabla_tipus: "szakdolgozo_1a_mell" }, min: 1 },
  { szakasz: "9. §", cim: "Jubileumi elismerés", tabla: "szolgalati_elismeres", min: 1 },
  { szakasz: "10. §", cim: "Juttatások", tabla: "juttatasok", min: 1 },
  { szakasz: "11. §", cim: "Kirendelés", tabla: "kirendelesek", min: 1 },
  { szakasz: "12–13. §", cim: "Végkielégítés", tabla: "vegkielegites_szamitasok", min: 1 },
  { szakasz: "Korm. r. 256/2013.", cim: "Ügyeleti díjak (work_time_rules)", tabla: "work_time_rules", min: 1 },
];

export const getEusztvCoverage = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const results = await Promise.all(
      EUSZTV_SECTIONS.map(async (s) => {
        let q = context.supabase.from(s.tabla as any).select("id", { count: "exact", head: true });
        if (s.filter) for (const [k, v] of Object.entries(s.filter)) q = q.eq(k, v as any);
        const { count, error } = await q;
        const found = error ? 0 : (count ?? 0);
        return {
          szakasz: s.szakasz,
          cim: s.cim,
          tabla: s.tabla,
          szukseges: s.min,
          megvan: found,
          status: found >= s.min ? "ok" : found > 0 ? "reszleges" : "hianyzik",
          hiba: error?.message ?? null,
        };
      }),
    );
    const osszesen = results.length;
    const lefedett = results.filter((r) => r.status === "ok").length;
    return {
      generalt: new Date().toISOString(),
      osszesen,
      lefedett,
      szazalek: Math.round((lefedett / osszesen) * 100),
      tetelek: results,
    };
  });
