/**
 * Az illetmény-számítás minden számolt tételének kötelező jogi hivatkozása.
 * Audit motor: minden nem-nulla tételhez ellenőrzi a hivatkozás meglétét és
 * jelez minden hiányzó / hiányos jogalapot.
 *
 * Tisztán kliens-biztos modul — a PDF generátor és a UI is használja.
 */

export type LegalRefKey =
  | "alap_illetmeny"
  | "vezetoi_szorzo"
  | "munkaidokeret"
  | "oradij"
  | "ugyelet_hetkoznap"
  | "ugyelet_hetvege"
  | "ugyelet_unnep"
  | "keszenlet"
  | "egyeb_juttatas"
  | "korrekcio";

export type LegalRef = {
  cimke: string;
  jogszabaly: string;
  szakasz: string;
  kategoria: "alap" | "vezetoi" | "munkaido" | "ugyelet" | "juttatas" | "korrekcio";
};

export const LEGAL_REFS: Record<LegalRefKey, LegalRef> = {
  alap_illetmeny: {
    cimke: "Alap illetmény (besorolási sáv)",
    jogszabaly: "2020. évi C. törvény (Eüsztv.)",
    szakasz: "8. § + 1. / 1/A. melléklet",
    kategoria: "alap",
  },
  vezetoi_szorzo: {
    cimke: "Vezetői szorzó",
    jogszabaly: "2020. évi C. törvény (Eüsztv.)",
    szakasz: "8. § (4) bek.",
    kategoria: "vezetoi",
  },
  munkaidokeret: {
    cimke: "Havi munkaidő-keret",
    jogszabaly: "2012. évi I. tv. (Mt.) + 2020. évi C. tv. (Eüsztv.)",
    szakasz: "Mt. 93–94. §; Eüsztv. 16. §",
    kategoria: "munkaido",
  },
  oradij: {
    cimke: "Számított óradíj (havi illetmény / munkaidő-keret)",
    jogszabaly: "2012. évi I. tv. (Mt.)",
    szakasz: "139. § (2) bek.",
    kategoria: "alap",
  },
  ugyelet_hetkoznap: {
    cimke: "Hétköznapi ügyelet díjazása",
    jogszabaly: "256/2013. (VII. 5.) Korm. r.; 2012. évi I. tv. (Mt.)",
    szakasz: "Korm. r. 5. §; Mt. 144. §",
    kategoria: "ugyelet",
  },
  ugyelet_hetvege: {
    cimke: "Hétvégi ügyelet díjazása",
    jogszabaly: "256/2013. (VII. 5.) Korm. r.",
    szakasz: "5. § (4) bek.",
    kategoria: "ugyelet",
  },
  ugyelet_unnep: {
    cimke: "Munkaszüneti napi ügyelet díjazása",
    jogszabaly: "2012. évi I. tv. (Mt.); 256/2013. Korm. r.",
    szakasz: "Mt. 143. § (4); Korm. r. 5. §",
    kategoria: "ugyelet",
  },
  keszenlet: {
    cimke: "Készenléti díj",
    jogszabaly: "2012. évi I. tv. (Mt.)",
    szakasz: "144. § (2) bek.",
    kategoria: "ugyelet",
  },
  egyeb_juttatas: {
    cimke: "Egyéb juttatás / bér jellegű kifizetés",
    jogszabaly: "2020. évi C. törvény (Eüsztv.)",
    szakasz: "10. §",
    kategoria: "juttatas",
  },
  korrekcio: {
    cimke: "Korrekció (utólagos elszámolás)",
    jogszabaly: "2012. évi I. tv. (Mt.); 2020. évi C. tv. (Eüsztv.)",
    szakasz: "Mt. 155. §; Eüsztv. 8. §",
    kategoria: "korrekcio",
  },
};

export type AuditIssue = {
  severity: "error" | "warning" | "info";
  cimke: string;
  uzenet: string;
  szukseges_hivatkozas?: LegalRef;
};

export type AuditInput = {
  havi: number;
  orakeret: number;
  oradij: number;
  vezetoiSzorzo: number;
  ugyHetkoznap: number;
  ugyHetvege: number;
  ugyUnnep: number;
  keszenletOra: number;
  egyebOsszesen: number;
  korrOsszesen: number;
};

/** Visszaadja az adott tételek lefedettségéhez tartozó *aktív* hivatkozásokat. */
export function aktivHivatkozasok(input: AuditInput): LegalRef[] {
  const refs: LegalRef[] = [LEGAL_REFS.alap_illetmeny, LEGAL_REFS.munkaidokeret, LEGAL_REFS.oradij];
  if (input.vezetoiSzorzo && input.vezetoiSzorzo !== 1) refs.push(LEGAL_REFS.vezetoi_szorzo);
  if (input.ugyHetkoznap > 0) refs.push(LEGAL_REFS.ugyelet_hetkoznap);
  if (input.ugyHetvege > 0) refs.push(LEGAL_REFS.ugyelet_hetvege);
  if (input.ugyUnnep > 0) refs.push(LEGAL_REFS.ugyelet_unnep);
  if (input.keszenletOra > 0) refs.push(LEGAL_REFS.keszenlet);
  if (input.egyebOsszesen !== 0) refs.push(LEGAL_REFS.egyeb_juttatas);
  if (input.korrOsszesen !== 0) refs.push(LEGAL_REFS.korrekcio);
  // dedupe
  return Array.from(new Map(refs.map((r) => [r.szakasz, r])).values());
}

/**
 * Strukturális audit: észleli, ha egy számolt tételnek nincs jogi alapja,
 * vagy az alap-paraméterek hiányosak.
 */
export function auditIlletmeny(input: AuditInput): AuditIssue[] {
  const out: AuditIssue[] = [];

  if (input.havi <= 0) {
    out.push({
      severity: "error",
      cimke: "Havi illetmény",
      uzenet: "A számolt havi illetmény nulla — ellenőrizd a besorolást és a bértáblát.",
      szukseges_hivatkozas: LEGAL_REFS.alap_illetmeny,
    });
  }
  if (input.orakeret <= 0) {
    out.push({
      severity: "error",
      cimke: "Munkaidő-keret",
      uzenet: "Hiányzik a havi munkaidő-keret — óradíj nem számolható.",
      szukseges_hivatkozas: LEGAL_REFS.munkaidokeret,
    });
  }
  if (input.oradij <= 0 && (input.ugyHetkoznap || input.ugyHetvege || input.ugyUnnep || input.keszenletOra)) {
    out.push({
      severity: "error",
      cimke: "Óradíj",
      uzenet: "Ügyeleti vagy készenléti tétel szerepel, de az óradíj nulla.",
      szukseges_hivatkozas: LEGAL_REFS.oradij,
    });
  }
  if (input.vezetoiSzorzo > 1 && !LEGAL_REFS.vezetoi_szorzo) {
    out.push({
      severity: "warning",
      cimke: "Vezetői szorzó",
      uzenet: "Vezetői szorzó alkalmazva — ellenőrizd az Eüsztv. 8. § (4) szerinti besorolást.",
      szukseges_hivatkozas: LEGAL_REFS.vezetoi_szorzo,
    });
  }
  if (input.ugyHetkoznap + input.ugyHetvege + input.ugyUnnep > 0) {
    out.push({
      severity: "info",
      cimke: "Ügyeleti pótlékok",
      uzenet: "Ellenőrizd a havi 14 ügyelet + 10 készenlét felső korlátot (Eüsztv. 16. §).",
    });
  }
  if (input.korrOsszesen !== 0) {
    out.push({
      severity: "info",
      cimke: "Korrekció",
      uzenet: "Korrekció szerepel a kalkulációban — a Mt. 155. § szerinti indoklás szükséges.",
      szukseges_hivatkozas: LEGAL_REFS.korrekcio,
    });
  }

  return out;
}
