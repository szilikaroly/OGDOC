import { useQueryClient, type QueryKey } from "@tanstack/react-query";

/**
 * Optimistic mutation segéd – tömör recept TanStack Query-hez.
 *
 *   const mut = useMutation(optimisticOptions({
 *     queryClient,
 *     queryKey: ["messages", threadId],
 *     mutationFn: (text) => sendMessage({ threadId, text }),
 *     applyOptimistic: (prev, text) => [...(prev ?? []), { id: "tmp", text, pending: true }],
 *   }));
 */
export function optimisticOptions<TData, TVariables, TList>({
  queryClient,
  queryKey,
  mutationFn,
  applyOptimistic,
}: {
  queryClient: ReturnType<typeof useQueryClient>;
  queryKey: QueryKey;
  mutationFn: (vars: TVariables) => Promise<TData>;
  applyOptimistic: (prev: TList | undefined, vars: TVariables) => TList;
}) {
  return {
    mutationFn,
    onMutate: async (vars: TVariables) => {
      await queryClient.cancelQueries({ queryKey });
      const previous = queryClient.getQueryData<TList>(queryKey);
      queryClient.setQueryData<TList>(queryKey, (old) => applyOptimistic(old, vars));
      return { previous };
    },
    onError: (_err: unknown, _vars: TVariables, ctx: { previous: TList | undefined } | undefined) => {
      if (ctx?.previous !== undefined) {
        queryClient.setQueryData(queryKey, ctx.previous);
      }
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey });
    },
  };
}

/**
 * Rövid haptikus visszajelzés (Android Chrome / támogatott eszközök).
 * Csendesen no-op, ha a böngésző nem támogatja.
 */
export function haptic(pattern: number | number[] = 12) {
  try {
    if (typeof navigator !== "undefined" && "vibrate" in navigator) {
      navigator.vibrate(pattern);
    }
  } catch {/* noop */}
}
