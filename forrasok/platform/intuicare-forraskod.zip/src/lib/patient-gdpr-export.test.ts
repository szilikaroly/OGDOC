import { describe, it, expect } from "vitest";

// A patient-gdpr-export modul közvetlen tesztelése a Supabase mockja nélkül nehéz,
// így itt csak a payload-struktúra szerződését rögzítjük, amelyet a print/JSON kód is használ.

describe("patient GDPR payload shape contract", () => {
  it("has required schema fields", () => {
    const minimal = {
      schema: "patient-gdpr-export/v1",
      generated_at: new Date().toISOString(),
      legal_basis: "GDPR Art. 15 — érintetti hozzáférési jog",
      patient: { id: "x", vezeteknev: "Teszt", keresztnev: "Elek" },
      encounters: [],
      eeszt_links: [],
      counts: { encounters: 0, eeszt_links: 0 },
    };

    expect(minimal.schema).toBe("patient-gdpr-export/v1");
    expect(minimal.legal_basis).toMatch(/GDPR/i);
    expect(minimal.patient).toHaveProperty("vezeteknev");
    expect(Array.isArray(minimal.encounters)).toBe(true);
    expect(Array.isArray(minimal.eeszt_links)).toBe(true);
    expect(minimal.counts.encounters).toBe(0);
  });
});
