// Site-wide contextual help registry.
// Keyed by route pathname prefix. The HelpButton picks the longest matching prefix.

export type HelpLink = { label: string; to: string };

export type HelpEntry = {
  title: string;
  summary: string;
  steps?: string[];
  tips?: string[];
  permissions?: string[];
  related?: HelpLink[];
};

export const HELP_REGISTRY: Record<string, HelpEntry> = {
  "/iranyitopult": {
    title: "Irányítópult",
    summary:
      "Személyre szabható kezdőoldal widgetekkel: beosztás, szabadság-egyenleg, hírek, riasztások. A widgetek elrendezése drag-and-droppal módosítható, a beállítás csak Önre vonatkozik.",
    steps: [
      "Új widget hozzáadása: jobb felső + ikon -> válassza ki a kívánt widgetet.",
      "Sorrend módosítása: fogja meg a widget fejlécét és húzza új helyre.",
      "Widget eltávolítása: a fogantyú melletti × ikon.",
    ],
    tips: [
      "A widget-választék a szerepkörétől függ — adminoknak több típus elérhető.",
      "Mobilon a widgetek egymás alá rendeződnek olvashatóbb formátumban.",
    ],
  },

  "/beosztas": {
    title: "Beosztás",
    summary:
      "Havi beosztás megtekintése és szerkesztése. AI-alapú generálás, ütközés-hőtérkép, megosztási link, nyomtatás és cellaszintű magyarázatok.",
    steps: [
      "Hónap váltása a felső navigátorral; szűrés ellátóhelyre / szerepkörre.",
      "AI-generálás: 'Beosztás generálása' gomb -> válassza a hatókört és a kívánt szabályokat.",
      "Egy műszak részleteinek megtekintése: kattintson a cellára (eredmény + magyarázat).",
      "Megosztás külsős kollégával: 'Megosztás' -> token-link generálás.",
    ],
    tips: [
      "A piros sávok munkajogi vagy kompetencia-konfliktust jeleznek — vigye az egeret föléjük a részletekért.",
      "Kérelmek (csere, lemondás) a vezető oldalán futnak be jóváhagyásra.",
    ],
    related: [
      { label: "Vezetői kérelmek", to: "/vezeto/keresek" },
      { label: "Munkaidő-szabályok", to: "/admin/munkaido-szabalyok" },
      { label: "Létszámigény-sablonok", to: "/admin/letszam-igeny" },
    ],
  },

  "/vezeto/keresek": {
    title: "Beosztás-kérelmek",
    summary:
      "Csere-, lemondási- és szabadság-kérelmek központi jóváhagyási felülete vezetőknek.",
    steps: [
      "Szűrés státuszra (függő / elfogadott / elutasított) és típusra.",
      "Kattintás a sorra -> részletek + jóváhagyás vagy elutasítás indoklással.",
      "Tömeges műveletek a kijelölő-mezőkkel.",
    ],
  },

  "/muteti-terv/blokkok": {
    title: "OR tábla – Blokkok",
    summary:
      "Műtéti blokk-tábla drag-and-drop esetbeosztással. AI-sorrendezővel, csapat-tervezővel, ütközés- és sürgősségi panellel.",
    steps: [
      "Eset hozzárendelése: húzza az esetet a várólistából a kívánt blokkba.",
      "Csapat tervezése: blokk fejlécén 'Csapat' gomb -> szerep/szint szerinti automatikus javaslat, kézi csere, auto-fix.",
      "Sürgősségi eset: piros 'Sürgősségi' gomb -> kaszkád-újratervező javasol elhalasztást.",
      "Sorrend optimalizálása: 'AI-sorrend' -> előkészítési idő és kompetencia szerint rangsorol.",
    ],
    tips: [
      "Kiemelt műtétnél kötelező a delegált operatőr — a sor amber/piros jelzéssel figyelmeztet.",
      "A szabályok típusonként a Műtéti szabályok admin oldalon konfigurálhatók.",
    ],
    related: [
      { label: "Műtéti várólista", to: "/muteti-terv/varolista" },
      { label: "Műtéti szabályok", to: "/admin/mutet-szabalyok" },
    ],
  },

  "/muteti-terv/varolista": {
    title: "Műtéti várólista",
    summary:
      "Várólistán lévő esetek kezelése: felvétel, jóváhagyás, prioritás, sürgősségi triggerek, bulk import/export.",
    steps: [
      "Új eset: '+ Új' gomb, páciens kiválasztás, típus, becsült idő.",
      "Kiemelt műtét: csillag ikon a páciens neve mellett — delegált operatőr-választó jelenik meg.",
      "Bulk import: 'CSV import' — előbb sablon letöltése.",
    ],
    tips: [
      "A piros badge tényleges konfliktust jelez (pl. hiányzó delegálás), a kék badge csak informatív követelmény (skill, erőforrás).",
    ],
    related: [
      { label: "OR tábla", to: "/muteti-terv/blokkok" },
      { label: "Műtéti szabályok", to: "/admin/mutet-szabalyok" },
    ],
  },

  "/admin/mutet-szabalyok": {
    title: "Műtéti típus-szabályok",
    summary:
      "Műtéti típusonkénti elvárások: kiemelt jelölés, kötelező delegálás, minimum operatőri szint, szükséges skillek és erőforrások.",
    steps: [
      "Soron belül módosíthatja a beállításokat — a változtatások amber háttérrel jelzik a mentésre váró állapotot.",
      "'Mentés' gombbal véglegesítheti soronként.",
    ],
    permissions: ["manage_or_blocks"],
  },

  "/admin/paciens-kerelmek": {
    title: "Páciens-kérelmek inbox",
    summary:
      "A páciens portálról beérkező időpont- és beutaló-kérések központi feldolgozása. Jóváhagyás vagy elutasítás után a páciens automatikusan értesítést kap az in-app értesítőbe.",
    steps: [
      "Tab váltással válasszon az időpont- és beutaló-kérések között.",
      "'Csak függő' / 'Összes' szűrővel állítsa be a nézetet.",
      "Jóváhagyáskor / elutasításkor opcionálisan írjon a páciensnek üzenetet — ez kerül az értesítés szövegébe.",
    ],
    related: [
      { label: "Időpontok", to: "/idopontok" },
      { label: "Páciensek", to: "/paciensek" },
    ],
    permissions: ["manage_patients"],
  },

  "/portal/elojegyzes": {
    title: "Előjegyzés",
    summary:
      "Időpont-kérés a kezelőcsapatától. Ha orvos-keresőből vagy beutaló-listából érkezett, a kontextus (orvos / szakterület / beutaló) automatikusan kitöltődik és átkerül a stáb inboxába.",
    tips: [
      "Sürgős panasz esetén válassza a 'Sürgős' szintet — ez kiemeli a kérést a stáb inboxában.",
      "A kérés státuszáról és a stáb válaszáról automatikus értesítést kap.",
    ],
  },

  "/portal/zarojelentes": {
    title: "Zárójelentések, leletezések",
    summary:
      "Az aláírt orvosi dokumentumai (zárójelentés, ambuláns lap, konzílium, vizit). Csak az aláírt — tehát véglegesített — dokumentumok jelennek meg.",
    tips: [
      "Több családtag esetén a felső gombsorral válthat páciens között.",
      "Új aláírt dokumentumról automatikus értesítést kap.",
    ],
  },

  "/admin/monitoring-szabalyok": {
    title: "Monitoring szabályok",
    summary:
      "Mérési küszöbértékek beállítása (vérnyomás, vércukor, pulzus, magzatmozgás stb.). Globális tenant-szabály vagy páciens-specifikus felülírás. A küszöbátlépés kritikus riasztást generálhat.",
    steps: [
      "Új küszöb létrehozása: 'Új küszöb' gomb, kulcs választása listából vagy egyedi név.",
      "Páciens-specifikus szabályhoz töltse ki a Páciens ID mezőt; üresen hagyva globális (tenant-szintű).",
    ],
    permissions: ["manage_patients"],
  },

  "/admin/followup": {
    title: "Utánkövetési protokollok",
    summary:
      "Többfázisú utánkövetési ütemtervek (pl. szülés utáni, műtét utáni). Fázisonként kérdőív, kadencia és emlékeztető-bucketek.",
    permissions: ["manage_patients"],
  },

  "/portal/utokovetes": {
    title: "Utánkövetésem",
    summary:
      "Az Önhöz rendelt aktív utánkövetési protokollok és lépés-idővonal. Az esedékes fázisokhoz tartozó kérdőívek a Kérdőívek menüben tölthetők ki.",
    tips: [
      "A protokoll lépéseinek időablakát a horgony-esemény (pl. szülés, műtét) dátumához viszonyítva számoljuk.",
      "Az 'Esedékes' jelzéssel ellátott fázis kérdőíve aktív kitöltésre vár.",
    ],
  },






  "/karakterlap": {
    title: "Karakterlap",
    summary:
      "Saját profilja: foglalkoztatási adatok, képzettségek, akkreditációk, beavatkozás-kompetenciák, napi preferenciák, rendelkezésre állás, túlóra-pool, párkapcsolati műszakok, értesítések.",
    tips: [
      "Az adatok közvetlenül befolyásolják a beosztómotor javaslatait és a műtéti csapatválasztást.",
      "Akkreditáció lejárata előtt 30 nappal automatikus értesítést kap.",
    ],
  },

  "/csapat": {
    title: "Csapat",
    summary:
      "Kollégái jelenlegi státusza (ügyeletes, szabadságon, elérhető), elérhetőségek, CSV export.",
  },

  "/csapat-mutatok": {
    title: "Csapat-mutatók",
    summary:
      "Aggregált műszak-statisztikák: ügyeletek száma, túlóra-eloszlás, egyéni terhelés-összehasonlítás Recharts diagramokon.",
  },

  "/kepzes": {
    title: "Képzés",
    summary:
      "Képzési programok, mérföldkövek, skill-katalógus, beavatkozás-típusok. Akkreditációk és előrehaladás nyomon követése.",
  },

  "/munkaido": {
    title: "Munkaidő",
    summary:
      "Egyéni munkaidő-főkönyv. Túlóra-egyenleg, pihentető-idő, CSV és ICS naptár export.",
    tips: [
      "A piros sorok munkajogi határérték-túllépést jeleznek (napi/heti max, pihenőidő).",
    ],
  },

  "/jelenlet": {
    title: "Jelenlét",
    summary:
      "GPS/NFC alapú be- és kijelentkezés. Offline-képes — hálózat-kiesés esetén a műveletek várakoznak és automatikusan szinkronizálnak.",
    steps: [
      "Check-in: műszak kezdetén a 'Bejelentkezés' gomb (a GPS/NFC anchor automatikusan validál).",
      "Szünet: 'Szünet kezdés' / 'Szünet vége' — az idő automatikusan kivonásra kerül.",
      "Check-out: 'Kijelentkezés' — ledger frissül a tényleges óraszámmal.",
    ],
    related: [
      { label: "Jelenlét-horgonyok", to: "/admin/jelenlet-horgonyok" },
      { label: "Jelenlét-anomáliák", to: "/admin/jelenlet-anomaliak" },
    ],
  },

  "/szabadsag": {
    title: "Szabadság",
    summary:
      "Szabadság-jogosultság és kérelmek. Egyenleg típusonként, kérelem-beküldés, PDF letöltés.",
    steps: [
      "Új kérelem: '+ Új szabadság' -> típus, dátumtartomány, indok.",
      "PDF letöltés: az elfogadott kérelmen a 'PDF' gomb.",
    ],
  },

  "/klinika": {
    title: "Klinika főoldal",
    summary:
      "Aktív klinikai esetek (encounters) és páciens-lista. Új encounter indítása, EESZT-integráció.",
    related: [
      { label: "Páciensek", to: "/paciensek" },
      { label: "Klinikai eszközök", to: "/klinika/eszkozok" },
    ],
  },

  "/klinika/eszkozok": {
    title: "Klinikai eszközök",
    summary:
      "Klinikai kalkulátorok és döntéstámogató eszközök: vérgáz, kardiológia (CHA₂DS₂-VASc, HAS-BLED), szepszis (SOFA, qSOFA), embólia (Wells, Geneva), vese (eGFR), diabétesz (ADA 2025), szülészet (Bishop).",
    tips: [
      "Minden számolás magyarázattal és referencia-tartománnyal jelenik meg.",
      "Az eredmények menthetők az aktuális encounterhez (`clinical_calculator_results` tábla).",
    ],
  },

  "/paciensek": {
    title: "Páciensek",
    summary:
      "Páciens-nyilvántartás kereséssel, encounter-szerkesztővel, EESZT-szinkron panellel és GDPR export funkcióval.",
  },

  "/paciens-360": {
    title: "Páciens 360°",
    summary:
      "Holisztikus páciens-nézet: teljes kórtörténet, labor, gyógyszer, diagnózis, megfigyelések, üzenetek, AI-magyarázatok, mentett nézetek.",
  },

  "/kerdoivek": {
    title: "Kérdőívek",
    summary:
      "Aktív kérdőívek könyvtára (PHQ-9, GAD-7, stb.). Kiosztás, kioszk-mód, klinikus áttekintő, kritikus riasztások.",
    related: [
      { label: "Klinikus áttekintő", to: "/kerdoivek/attekintes" },
      { label: "Váró / Kioszk", to: "/kerdoivek/varo" },
      { label: "Kritikus riasztások", to: "/kerdoivek/riasztasok" },
    ],
  },

  "/idopontok": {
    title: "Időpontok",
    summary:
      "Admin időpont-kezelő naptár-nézet. Adminisztratív lemondás, slot-sablonok generálása.",
    related: [{ label: "Heti sablonok", to: "/idopontok/sablonok" }],
  },

  "/uzenetek": {
    title: "Üzenetek",
    summary:
      "Belső üzenetközpont valós idejű szálakkal. AI-triage, automata fordítás, csatolmányok, push opt-in.",
    tips: [
      "Új üzenetnél az AI-triage automatikusan javaslatot tesz a prioritásra.",
    ],
  },

  "/elegedettseg": {
    title: "Elégedettségi dashboard",
    summary:
      "NPS-trendek (promoter − detractor), legutóbbi páciens-visszajelzések.",
  },

  "/visszajelzesek": {
    title: "Follow-up rendszer",
    summary:
      "Protokoll-alapú beteg-követés. Aktív követések, esedékességek, auto-recall riasztások.",
  },

  "/audit": {
    title: "Audit napló",
    summary:
      "Teljes INSERT/UPDATE/DELETE napló diff-nézettel. `view_audit` jogosultsággal érhető el.",
    permissions: ["view_audit"],
  },

  "/admin/szervezet": {
    title: "Szervezet",
    summary:
      "Klinika -> telephely -> ellátóhely fa-struktúra drag-and-droppal. Szintek, megosztott műtők, ügyeleti sorok, eligibility.",
    related: [{ label: "Részletes kézikönyv", to: "/admin/szervezet-sugo" }],
    permissions: ["manage_org"],
  },

  "/admin/szerepkorok": {
    title: "Szerepkörök",
    summary: "Szerepkörök CRUD kezelése — munkakörök, kategóriák, prioritás.",
    permissions: ["manage_roles"],
  },

  "/admin/jogosultsagok": {
    title: "Jogosultságok",
    summary:
      "Szerepkör–jogosultság mátrix. A permission key-ek határozzák meg, melyik felület érhető el.",
    permissions: ["manage_roles"],
  },

  "/admin/munkaido-szabalyok": {
    title: "Munkaidő-szabályok",
    summary:
      "Jogszabályi munkaidő-határértékek (napi/heti max, pihenőidő) konfigurálása — a beosztómotor inputja.",
  },

  "/admin/jelenlet-horgonyok": {
    title: "Jelenlét-horgonyok",
    summary: "GPS/NFC anchor-pontok regisztrálása épületenként a jelenlét-validáláshoz.",
  },

  "/admin/jelenlet-anomaliak": {
    title: "Jelenlét-anomáliák",
    summary:
      "Automatikus eltérés-detekció (hiányzó check-in, dupla esemény) és manuális korrekciós workflow.",
  },

  "/admin/kotelezo-ugyelet": {
    title: "Kötelező ügyelet",
    summary:
      "Havi ügyeleti minimumok kategóriánként, kötelező lefedés ellátóhelyenként, egyéni mentességek HR-jóváhagyással.",
    related: [{ label: "Kézikönyv", to: "/admin/szervezet-sugo" }],
  },

  "/admin/potlas": {
    title: "Pótlás / Helyettesítés",
    summary:
      "Hiányzó kolléga helyettesítőjének keresése skill-egyezés alapján; AI-képesség-szűrő rangsorolja a jelölteket.",
  },

  "/admin/tulora-pool": {
    title: "Túlóra-pool",
    summary:
      "Önkéntes túlóra-preferenciák (napok, műszakok, max óra/hó); extra kapacitás-pool a beosztómotorhoz.",
  },

  "/admin/szabadsag-felugyelet": {
    title: "Szabadság-felügyelet",
    summary:
      "Admin áttekintő: ki hány napot vett ki, kinek jár még; átvitel-határidő riasztások.",
  },

  "/admin/szabadsag-szabalyzat": {
    title: "Szabadság-szabályzat",
    summary:
      "Tenant-szintű szabadság-jogszabály konfigurálása: átvitel limit, lejárat, kötelező kivétel.",
  },

  "/admin/letszam-igeny": {
    title: "Létszámigény-sablonok",
    summary:
      "Napi szerepkör-létszám-igények (min/max fő szerepkörönként és sávonként) — a beosztómotor egyik fő inputja.",
  },

  "/admin/szervezet-sugo": {
    title: "Szervezet kézikönyv",
    summary:
      "Teljes szöveges útmutató a szervezeti hierarchiához, ügyeleti sorokhoz és a beosztómotor folyamatához.",
  },

  "/admin/forditasok": {
    title: "Fordításkezelő",
    summary:
      "i18n kulcsok szerkesztője. Hiányzó fordítások listája, AI auto-fordítás többnyelvű kontextushoz.",
  },

  "/admin/hibanaplo": {
    title: "Hibanapló",
    summary:
      "Kliens-oldali hibák naplója. AI javítási javaslattal (`suggestErrorFix`).",
  },

  "/admin/email": {
    title: "E-mail admin",
    summary: "E-mail sablonok és digest-időzítések konfigurálása.",
  },

  "/admin/eszkalacio": {
    title: "Eszkaláció",
    summary:
      "Klinikai riasztás-eszkalációs szabályok és routing konfigurálása (kihez, milyen csatornán).",
  },




  "/admin/kerdoiv-emlekeztetok": {
    title: "Kérdőív-emlékeztetők",
    summary: "Automatikus kérdőív-emlékeztető időzítők konfigurálása.",
  },

  // Páciens portal
  "/portal": {
    title: "Páciens portál",
    summary:
      "Saját időpontok, leletek, mérések, üzenetek, kérdőívek, beutalók és életmód-tanácsadó egy helyen.",
  },
};

/** Pick the most specific help entry for a pathname (longest matching prefix). */
export function findHelpEntry(pathname: string): HelpEntry | null {
  const keys = Object.keys(HELP_REGISTRY).sort((a, b) => b.length - a.length);
  for (const k of keys) {
    if (pathname === k || pathname.startsWith(k + "/")) {
      return HELP_REGISTRY[k];
    }
  }
  return null;
}
