import { supabase } from "@/integrations/supabase/client";

export async function exportPatientGdpr(patientId: string): Promise<{ filename: string; payload: Record<string, unknown> }> {
  const [patient, encounters, eeszt] = await Promise.all([
    supabase.from("patients").select("*").eq("id", patientId).maybeSingle(),
    supabase.from("patient_encounters").select("*").eq("patient_id", patientId).order("ellatas_kezdete", { ascending: false }),
    supabase.from("eeszt_patient_links").select("*").eq("patient_id", patientId),
  ]);

  const errors = [patient.error, encounters.error, eeszt.error].filter(Boolean);
  if (errors.length > 0) throw new Error(errors.map((e) => e!.message).join(" · "));

  const payload = {
    schema: "patient-gdpr-export/v1",
    generated_at: new Date().toISOString(),
    legal_basis: "GDPR Art. 15 — érintetti hozzáférési jog",
    patient: patient.data ?? null,
    encounters: encounters.data ?? [],
    eeszt_links: eeszt.data ?? [],
    counts: {
      encounters: (encounters.data ?? []).length,
      eeszt_links: (eeszt.data ?? []).length,
    },
  };

  const name = patient.data
    ? `${(patient.data as any).vezeteknev}_${(patient.data as any).keresztnev}`.replace(/[^a-zA-Z0-9_-]/g, "")
    : "patient";
  const filename = `gdpr-${name}-${new Date().toISOString().slice(0, 10)}.json`;

  return { filename, payload };
}

export function downloadJson(filename: string, payload: unknown) {
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
