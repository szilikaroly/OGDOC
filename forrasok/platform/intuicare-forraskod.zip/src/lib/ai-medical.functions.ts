import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export type CodeSuggestion = {
  bno: Array<{ kod: string; nev: string; magyarazat?: string }>;
  oeno: Array<{ kod: string; nev: string; magyarazat?: string }>;
  osszefoglalo: string;
};

const SYSTEM_PROMPT = `You are a Hungarian medical coding assistant. Given a free-text clinical note (dekurzus) in Hungarian, return:
- BNO-10 (ICD-10 Hungarian) diagnosis code candidates
- OENO procedure code candidates
- a 1-2 sentence Hungarian summary (osszefoglalo)
Be conservative — only suggest codes well-supported by the text. Respond strictly via the provided tool call.`;

export const suggestMedicalCodes = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { text: string }) => {
    if (!input?.text || typeof input.text !== "string") throw new Error("text required");
    if (input.text.length > 8000) throw new Error("text too long");
    return { text: input.text };
  })
  .handler(async ({ data }): Promise<CodeSuggestion> => {
    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) throw new Error("LOVABLE_API_KEY missing");

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user", content: data.text },
        ],
        tools: [
          {
            type: "function",
            function: {
              name: "suggest_codes",
              description: "Return suggested BNO-10 and OENO codes plus a short summary",
              parameters: {
                type: "object",
                additionalProperties: false,
                properties: {
                  bno: {
                    type: "array",
                    items: {
                      type: "object",
                      additionalProperties: false,
                      properties: {
                        kod: { type: "string" },
                        nev: { type: "string" },
                        magyarazat: { type: "string" },
                      },
                      required: ["kod", "nev"],
                    },
                  },
                  oeno: {
                    type: "array",
                    items: {
                      type: "object",
                      additionalProperties: false,
                      properties: {
                        kod: { type: "string" },
                        nev: { type: "string" },
                        magyarazat: { type: "string" },
                      },
                      required: ["kod", "nev"],
                    },
                  },
                  osszefoglalo: { type: "string" },
                },
                required: ["bno", "oeno", "osszefoglalo"],
              },
            },
          },
        ],
        tool_choice: { type: "function", function: { name: "suggest_codes" } },
      }),
    });

    if (res.status === 429) throw new Error("AI rate limit — próbálja kicsit később.");
    if (res.status === 402) throw new Error("AI keret elfogyott. Töltse fel a Lovable workspace egyenleget.");
    if (!res.ok) {
      const txt = await res.text();
      throw new Error(`AI hiba: ${res.status} ${txt.slice(0, 200)}`);
    }
    const json = await res.json() as any;
    const call = json?.choices?.[0]?.message?.tool_calls?.[0];
    if (!call) throw new Error("AI nem adott vissza struktúrált választ");
    const args = JSON.parse(call.function.arguments) as CodeSuggestion;
    return {
      bno: Array.isArray(args.bno) ? args.bno : [],
      oeno: Array.isArray(args.oeno) ? args.oeno : [],
      osszefoglalo: typeof args.osszefoglalo === "string" ? args.osszefoglalo : "",
    };
  });
