import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export type DigestSettings = {
  tenant_id: string;
  enabled: boolean;
  day_of_week: number;
  hour_local: number;
  timezone: string;
  recipient_roles: string[];
  include_sections: Record<string, boolean>;
  last_sent_at: string | null;
  updated_at: string;
};

async function ensureAdmin(supabase: any, userId: string): Promise<void> {
  const { data, error } = await supabase.rpc("has_any_role", {
    _user_id: userId,
    _role_kulcsok: ["tenant_admin", "igazgato"],
  });
  if (error) throw error;
  if (!data) throw new Error("Forbidden");
}

async function getTenantId(supabase: any, userId: string): Promise<string> {
  const { data } = await supabase
    .from("user_roles")
    .select("tenant_id")
    .eq("user_id", userId)
    .not("tenant_id", "is", null)
    .limit(1)
    .maybeSingle();
  if (data?.tenant_id) return data.tenant_id as string;
  const { data: t } = await supabase.from("tenants").select("id").eq("aktiv", true).limit(1).maybeSingle();
  if (!t?.id) throw new Error("Nincs elérhető tenant");
  return t.id as string;
}

export const getDigestSettings = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<DigestSettings> => {
    const { supabase, userId } = context as any;
    await ensureAdmin(supabase, userId);
    const tenantId = await getTenantId(supabase, userId);

    const { data, error } = await supabase
      .from("email_digest_settings")
      .select("*")
      .eq("tenant_id", tenantId)
      .maybeSingle();
    if (error) throw error;
    if (data) return data as DigestSettings;

    const { data: created, error: insErr } = await supabase
      .from("email_digest_settings")
      .insert({ tenant_id: tenantId, updated_by: userId })
      .select("*")
      .single();
    if (insErr) throw insErr;
    return created as DigestSettings;
  });

export const updateDigestSettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: Partial<Omit<DigestSettings, "tenant_id" | "updated_at" | "last_sent_at">>) => {
    if (!input || typeof input !== "object") throw new Error("invalid input");
    return input;
  })
  .handler(async ({ data, context }): Promise<DigestSettings> => {
    const { supabase, userId } = context as any;
    await ensureAdmin(supabase, userId);
    const tenantId = await getTenantId(supabase, userId);

    const patch: Record<string, unknown> = { updated_by: userId };
    for (const k of ["enabled", "day_of_week", "hour_local", "timezone", "recipient_roles", "include_sections"] as const) {
      if ((data as any)[k] !== undefined) patch[k] = (data as any)[k];
    }

    const { data: updated, error } = await supabase
      .from("email_digest_settings")
      .upsert({ tenant_id: tenantId, ...patch }, { onConflict: "tenant_id" })
      .select("*")
      .single();
    if (error) throw error;
    return updated as DigestSettings;
  });

export type EmailLogRow = {
  id: string;
  message_id: string | null;
  template_name: string | null;
  recipient_email: string | null;
  status: string | null;
  error_message: string | null;
  created_at: string;
};

export const listEmailLog = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input?: { days?: number; template?: string | null; status?: string | null }) => ({
    days: Math.max(1, Math.min(90, Number(input?.days ?? 7))),
    template: input?.template ?? null,
    status: input?.status ?? null,
  }))
  .handler(async ({ data, context }): Promise<{ rows: EmailLogRow[]; supported: boolean }> => {
    const { supabase, userId } = context as any;
    await ensureAdmin(supabase, userId);

    const since = new Date(Date.now() - data.days * 86400_000).toISOString();
    const { data: rows, error } = await supabase
      .from("email_send_log" as any)
      .select("id, message_id, template_name, recipient_email, status, error_message, created_at")
      .gte("created_at", since)
      .order("created_at", { ascending: false })
      .limit(500);

    if (error) {
      const msg = String((error as any).message || "");
      if (msg.includes("does not exist") || (error as any).code === "42P01") {
        return { rows: [], supported: false };
      }
      throw error;
    }

    const seen = new Set<string>();
    const deduped: EmailLogRow[] = [];
    for (const r of (rows as any[]) ?? []) {
      const key = r.message_id ?? r.id;
      if (seen.has(key)) continue;
      seen.add(key);
      if (data.template && r.template_name !== data.template) continue;
      if (data.status && r.status !== data.status) continue;
      deduped.push(r as EmailLogRow);
    }
    return { rows: deduped, supported: true };
  });

export const triggerWeeklyDigestNow = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<{ ok: boolean; recipients: number; skipped?: string }> => {
    const { supabase, userId } = context as any;
    await ensureAdmin(supabase, userId);
    const tenantId = await getTenantId(supabase, userId);

    const mod = await import("./weekly-digest.server");
    return await mod.runWeeklyDigestForTenant(tenantId, { force: true });
  });
