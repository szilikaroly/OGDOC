import type { PostgrestError } from "@supabase/supabase-js";
import type { TFunction } from "i18next";

export type SupabaseLikeError =
  | PostgrestError
  | { message?: string; code?: string; details?: string; hint?: string }
  | Error
  | null
  | undefined;

/**
 * Maps Supabase / PostgREST errors to user-friendly Hungarian/English messages.
 * Specifically catches RLS / permission denied errors so the user understands
 * WHY an admin action failed instead of seeing a cryptic SQL string.
 */
export function humanizeError(err: SupabaseLikeError, t: TFunction, ctx?: { perm?: string }): string {
  if (!err) return "";
  const code = (err as { code?: string }).code ?? "";
  const message = (err as { message?: string }).message ?? String(err);
  const lower = message.toLowerCase();

  // Postgres / PostgREST RLS & permission codes
  if (code === "42501" || lower.includes("permission denied")) {
    return t("errors.permission_denied", { perm: ctx?.perm ?? "—" });
  }
  if (code === "PGRST301" || lower.includes("jwt") || lower.includes("not authenticated")) {
    return t("errors.not_authenticated");
  }
  if (code === "42P17" || lower.includes("infinite recursion")) {
    return t("errors.rls_recursion");
  }
  if (lower.includes("row-level security") || lower.includes("violates row-level security")) {
    return t("errors.rls_violation", { perm: ctx?.perm ?? "—" });
  }
  if (code === "23505" || lower.includes("duplicate key")) {
    return t("errors.duplicate");
  }
  if (code === "23503" || lower.includes("foreign key")) {
    return t("errors.foreign_key");
  }
  if (code === "23502" || lower.includes("not-null")) {
    return t("errors.not_null");
  }
  return message;
}
