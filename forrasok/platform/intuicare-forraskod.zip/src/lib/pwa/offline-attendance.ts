/**
 * IndexedDB-backed offline buffer for attendance events.
 * Buffers inserts when offline; flushes on `online` event and via SW background sync.
 */
import { supabase } from "@/integrations/supabase/client";

const DB = "medroster-offline";
const STORE = "attendance_queue";

type QueuedEvent = {
  id?: number;
  payload: Record<string, unknown>;
  queued_at: number;
};

function open(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) {
        db.createObjectStore(STORE, { keyPath: "id", autoIncrement: true });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function enqueueAttendance(payload: Record<string, unknown>): Promise<void> {
  const db = await open();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).add({ payload, queued_at: Date.now() } as QueuedEvent);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
  try {
    const reg = await navigator.serviceWorker?.ready;
    (reg as any)?.sync?.register("attendance-flush").catch(() => {});
  } catch {}
}

export async function pendingCount(): Promise<number> {
  try {
    const db = await open();
    return await new Promise<number>((resolve) => {
      const tx = db.transaction(STORE, "readonly");
      const req = tx.objectStore(STORE).count();
      req.onsuccess = () => resolve(req.result as number);
      req.onerror = () => resolve(0);
    });
  } catch {
    return 0;
  }
}

export async function flushAttendance(): Promise<{ ok: number; fail: number }> {
  if (!navigator.onLine) return { ok: 0, fail: 0 };
  const db = await open();
  const items: QueuedEvent[] = await new Promise((resolve) => {
    const tx = db.transaction(STORE, "readonly");
    const req = tx.objectStore(STORE).getAll();
    req.onsuccess = () => resolve((req.result as QueuedEvent[]) ?? []);
    req.onerror = () => resolve([]);
  });
  let ok = 0;
  let fail = 0;
  for (const it of items) {
    const { error } = await (supabase.from("attendance_events") as any).insert(it.payload);
    if (error) {
      fail++;
      continue;
    }
    ok++;
    await new Promise<void>((resolve) => {
      const tx = db.transaction(STORE, "readwrite");
      tx.objectStore(STORE).delete(it.id!);
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
    });
  }
  return { ok, fail };
}

export function registerOfflineFlushHandlers(onFlush: (r: { ok: number; fail: number }) => void) {
  const handler = () => void flushAttendance().then(onFlush);
  window.addEventListener("online", handler);
  navigator.serviceWorker?.addEventListener("message", (ev) => {
    if ((ev.data as any)?.type === "FLUSH_ATTENDANCE") handler();
  });
  return () => window.removeEventListener("online", handler);
}
