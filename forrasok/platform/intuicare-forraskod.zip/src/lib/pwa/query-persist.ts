import type { QueryClient } from "@tanstack/react-query";
import { persistQueryClient } from "@tanstack/react-query-persist-client";
import type { Persister } from "@tanstack/react-query-persist-client";
import { get, set, del } from "idb-keyval";

/**
 * IndexedDB-backed persister a React Query cache-hez.
 * Csak allow-listás queryKey-ek kerülnek perzisztálásra —
 * privát/formadatok soha.
 */

const STORAGE_KEY = "intuicare-rq-cache";
const MAX_AGE = 1000 * 60 * 60 * 24; // 24h

// Prefix-ek, amelyek offline olvashatók legyenek.
const ALLOWED_PREFIXES: readonly string[] = [
  "cms",
  "portal-list",
  "portal",
  "orvos-kereso",
  "public-page",
  "blog",
  "hirek",
  "tanacsok",
  "vlog",
];

function isAllowedKey(queryKey: unknown): boolean {
  if (!Array.isArray(queryKey) || queryKey.length === 0) return false;
  const first = queryKey[0];
  if (typeof first !== "string") return false;
  return ALLOWED_PREFIXES.includes(first);
}

function createIdbPersister(): Persister {
  return {
    persistClient: async (client) => {
      try {
        await set(STORAGE_KEY, client);
      } catch {
        /* quota / private mode */
      }
    },
    restoreClient: async () => {
      try {
        return (await get(STORAGE_KEY)) as any;
      } catch {
        return undefined;
      }
    },
    removeClient: async () => {
      try {
        await del(STORAGE_KEY);
      } catch {}
    },
  };
}

export function initQueryPersistence(queryClient: QueryClient) {
  if (typeof window === "undefined") return;
  if (!("indexedDB" in window)) return;

  const buster = import.meta.env.VITE_BUILD_HASH ?? "dev";

  persistQueryClient({
    queryClient: queryClient as any,
    persister: createIdbPersister(),
    maxAge: MAX_AGE,
    buster: String(buster),
    dehydrateOptions: {
      shouldDehydrateQuery: (query) => {
        if (query.state.status !== "success") return false;
        return isAllowedKey(query.queryKey);
      },
    },
  });
}
