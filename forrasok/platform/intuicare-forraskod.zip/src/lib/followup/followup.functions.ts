/**
 * Visszajelentő (follow-up) rendszer — admin / staff server-fn-ek.
 */
import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

async function getTenantId(supabase: any, userId: string): Promise<string> {
  const { data, error } = await supabase
    .from("profiles").select("tenant_id").eq("id", userId).single();
  if (error) throw new Error(error.message);
  const t = data?.tenant_id;
  if (!t) throw new Error("Hiányzó tenant.");
  return t as string;
}

/* ---------- Protokollok ---------- */
export const listFollowupProtocols = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("followup_protocols")
      .select("id, kod, nev, leiras, anchor_event, default_window_days, aktiv, followup_protocol_steps(id, phase_label, phase_order, questionnaire_id, offset_days_from, offset_days_to, cadence_days, channel)")
      .order("kod", { ascending: true });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

const ToggleInput = z.object({ id: z.string().uuid(), aktiv: z.boolean() });
export const toggleFollowupProtocol = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => ToggleInput.parse(d))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("followup_protocols")
      .update({ aktiv: data.aktiv })
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/* ---------- Enrollment-ek ---------- */
const ListEnrollmentsInput = z.object({
  patient_id: z.string().uuid().optional(),
  status: z.enum(["active", "paused", "completed", "cancelled"]).optional(),
}).default({});

export const listFollowupEnrollments = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => ListEnrollmentsInput.parse(d))
  .handler(async ({ data, context }) => {
    let q = context.supabase
      .from("followup_enrollments")
      .select("id, patient_id, protocol_id, anchor_at, status, paused_reason, created_at, followup_protocols(kod, nev, anchor_event), patients(id, vezeteknev, keresztnev)")
      .order("anchor_at", { ascending: false })
      .limit(500);
    if (data.patient_id) q = q.eq("patient_id", data.patient_id);
    if (data.status) q = q.eq("status", data.status);
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

const EnrollInput = z.object({
  patient_id: z.string().uuid(),
  protocol_kod: z.string().min(1),
  anchor_at: z.string().optional(),
  anchor_ref: z.record(z.string(), z.any()).optional(),
});

export const enrollPatientFollowup = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => EnrollInput.parse(d))
  .handler(async ({ data, context }) => {
    const tenant_id = await getTenantId(context.supabase, context.userId);
    const { data: proto, error: pe } = await context.supabase
      .from("followup_protocols").select("id")
      .eq("tenant_id", tenant_id).eq("kod", data.protocol_kod).eq("aktiv", true)
      .maybeSingle();
    if (pe) throw new Error(pe.message);
    if (!proto) throw new Error("Protokoll nem található.");
    const anchor_at = data.anchor_at ?? new Date().toISOString();
    const { data: row, error } = await context.supabase
      .from("followup_enrollments")
      .insert({
        tenant_id, patient_id: data.patient_id, protocol_id: proto.id,
        anchor_at, anchor_ref: data.anchor_ref ?? {},
        status: "active", created_by: context.userId,
      })
      .select("id").single();
    if (error) throw new Error(error.message);
    return row;
  });

const SetEnrollStatusInput = z.object({
  id: z.string().uuid(),
  status: z.enum(["active", "paused", "completed", "cancelled"]),
  paused_reason: z.string().optional(),
});

export const setFollowupEnrollmentStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => SetEnrollStatusInput.parse(d))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("followup_enrollments")
      .update({ status: data.status, paused_reason: data.paused_reason ?? null })
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/* ---------- Occurrence-ek ---------- */
const ListOccurrencesInput = z.object({
  status: z.enum(["scheduled", "sent", "responded", "missed", "cancelled"]).optional(),
  patient_id: z.string().uuid().optional(),
}).default({});

export const listFollowupOccurrences = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => ListOccurrencesInput.parse(d))
  .handler(async ({ data, context }) => {
    let q = context.supabase
      .from("followup_occurrences")
      .select("id, enrollment_id, step_id, due_at, status, responded_at, assignment_id, followup_enrollments!inner(patient_id, protocol_id, followup_protocols(kod, nev), patients(vezeteknev, keresztnev))")
      .order("due_at", { ascending: false })
      .limit(500);
    if (data.status) q = q.eq("status", data.status);
    if (data.patient_id) q = q.eq("followup_enrollments.patient_id", data.patient_id);
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

/* ---------- Recall (tünet-alapú kontroll-foglalási javaslat) ---------- */
type RecallRule = {
  if: { code: string; min: number };
  then: { recall: "urgent_24h" | "soon_72h" | "soon_7d" | "soon_14d"; specialty?: string };
};

const RecallUrgencyMap: Record<string, string> = {
  urgent_24h: "urgent",
  soon_72h: "soon",
  soon_7d: "soon",
  soon_14d: "routine",
};

const EvalRecallInput = z.object({
  response_id: z.string().uuid(),
});

export const evaluateFollowupRecall = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => EvalRecallInput.parse(d))
  .handler(async ({ data, context }) => {
    const { data: resp, error: re } = await context.supabase
      .from("questionnaire_responses")
      .select("id, tenant_id, patient_id, questionnaire_id, answers, severity")
      .eq("id", data.response_id).maybeSingle();
    if (re) throw new Error(re.message);
    if (!resp || !resp.patient_id) return { triggered: false, reason: "no_patient" };

    const { data: q, error: qe } = await context.supabase
      .from("questionnaires")
      .select("items, recall_rules")
      .eq("id", resp.questionnaire_id).single();
    if (qe) throw new Error(qe.message);

    const items: Array<{ id: number; code?: string }> = (q.items as any) ?? [];
    const codeById: Record<number, string> = {};
    items.forEach((it) => { if (it.code) codeById[it.id] = it.code; });
    const answers = (resp.answers as Record<string, number>) ?? {};
    const valueByCode: Record<string, number> = {};
    for (const [k, v] of Object.entries(answers)) {
      const c = codeById[Number(k)];
      if (c) valueByCode[c] = v;
    }

    const rules: RecallRule[] = ((q.recall_rules as any)?.rules ?? []) as RecallRule[];
    const hits = rules.filter((r) => (valueByCode[r.if.code] ?? 0) >= r.if.min);
    if (hits.length === 0) return { triggered: false };

    // Legsúlyosabb találat: prioritás sorrend
    const order = ["urgent_24h", "soon_72h", "soon_7d", "soon_14d"];
    hits.sort((a, b) => order.indexOf(a.then.recall) - order.indexOf(b.then.recall));
    const top = hits[0];

    // Keressük a patient_users linket → user_id
    const { data: pu } = await context.supabase
      .from("patient_users").select("user_id").eq("patient_id", resp.patient_id).maybeSingle();
    const userId = (pu as any)?.user_id ?? resp.patient_id; // fallback

    const urgency = RecallUrgencyMap[top.then.recall] ?? "routine";
    const insertRow: any = {
      tenant_id: resp.tenant_id,
      patient_id: resp.patient_id,
      user_id: userId,
      request_type: "followup_auto_recall",
      status: "auto_suggested",
      urgency,
      reason: `Visszajelentő rendszer riasztás: ${top.if.code} ≥ ${top.if.min}`,
    };
    const { data: req, error: ie } = await context.supabase
      .from("patient_appointment_requests")
      .insert(insertRow)
      .select("id").single();
    if (ie) {
      // Ne álljon meg a submit, csak naplózzuk
      console.warn("recall request insert failed", ie.message);
      return { triggered: true, error: ie.message };
    }
    return { triggered: true, request_id: (req as any).id, recall: top.then.recall, specialty: top.then.specialty };
  });

/* ---------- Admin CRUD: protocols + steps ---------- */

const ProtocolUpsertInput = z.object({
  id: z.string().uuid().optional(),
  kod: z.string().min(1).max(64),
  nev: z.string().min(1).max(200),
  leiras: z.string().max(2000).optional().nullable(),
  anchor_event: z.enum(["birth", "surgery_completed", "discharge", "visit_completed"]),
  default_window_days: z.number().int().min(1).max(36500),
  aktiv: z.boolean().default(true),
});

export const upsertFollowupProtocol = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => ProtocolUpsertInput.parse(d))
  .handler(async ({ data, context }) => {
    const tenant_id = await getTenantId(context.supabase, context.userId);
    const row = {
      tenant_id,
      kod: data.kod,
      nev: data.nev,
      leiras: data.leiras ?? null,
      anchor_event: data.anchor_event,
      default_window_days: data.default_window_days,
      aktiv: data.aktiv,
    };
    if (data.id) {
      const { error } = await context.supabase
        .from("followup_protocols").update(row).eq("id", data.id);
      if (error) throw new Error(error.message);
      return { id: data.id };
    }
    const { data: ins, error } = await context.supabase
      .from("followup_protocols").insert(row).select("id").single();
    if (error) throw new Error(error.message);
    return { id: (ins as any).id };
  });

const DeleteIdInput = z.object({ id: z.string().uuid() });

export const deleteFollowupProtocol = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => DeleteIdInput.parse(d))
  .handler(async ({ data, context }) => {
    // Csak akkor töröljük, ha nincs aktív enrollment
    const { count } = await context.supabase
      .from("followup_enrollments")
      .select("id", { count: "exact", head: true })
      .eq("protocol_id", data.id);
    if ((count ?? 0) > 0) {
      throw new Error("Nem törölhető — már van hozzá rendelt követés. Inaktiváld helyette.");
    }
    const { error } = await context.supabase
      .from("followup_protocols").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

const StepUpsertInput = z.object({
  id: z.string().uuid().optional(),
  protocol_id: z.string().uuid(),
  phase_label: z.string().min(1).max(200),
  phase_order: z.number().int().min(0).max(100),
  questionnaire_id: z.string().uuid(),
  offset_days_from: z.number().int().min(0).max(36500),
  offset_days_to: z.number().int().min(0).max(36500),
  cadence_days: z.number().int().min(1).max(36500),
  channel: z.enum(["notification", "push", "email", "sms"]).default("notification"),
  reminder_buckets: z.array(z.number().int()).default([]),
});

export const upsertFollowupProtocolStep = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => StepUpsertInput.parse(d))
  .handler(async ({ data, context }) => {
    if (data.offset_days_to < data.offset_days_from) {
      throw new Error("A fázis vége nem lehet a kezdete előtt.");
    }
    const row = {
      protocol_id: data.protocol_id,
      phase_label: data.phase_label,
      phase_order: data.phase_order,
      questionnaire_id: data.questionnaire_id,
      offset_days_from: data.offset_days_from,
      offset_days_to: data.offset_days_to,
      cadence_days: data.cadence_days,
      channel: data.channel,
      reminder_buckets: data.reminder_buckets,
    };
    if (data.id) {
      const { error } = await context.supabase
        .from("followup_protocol_steps").update(row).eq("id", data.id);
      if (error) throw new Error(error.message);
      return { id: data.id };
    }
    const { data: ins, error } = await context.supabase
      .from("followup_protocol_steps").insert(row).select("id").single();
    if (error) throw new Error(error.message);
    return { id: (ins as any).id };
  });

export const deleteFollowupProtocolStep = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => DeleteIdInput.parse(d))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("followup_protocol_steps").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/* ---------- Kérdőív-lista a step szerkesztőhöz ---------- */
export const listQuestionnairesForFollowup = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("questionnaires")
      .select("id, code, title")
      .eq("aktiv", true)
      .order("title", { ascending: true });
    if (error) throw new Error(error.message);
    return data ?? [];
  });
