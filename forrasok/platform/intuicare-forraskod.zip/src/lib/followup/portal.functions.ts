import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const listMyFollowupEnrollments = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    // get my patient ids
    const { data: links } = await supabase
      .from("patient_users")
      .select("patient_id")
      .eq("user_id", userId);
    const patientIds = (links ?? []).map((l: any) => l.patient_id);
    if (!patientIds.length) return { enrollments: [] as any[], pendingQuestionnaires: [] as any[] };

    const { data: enrolls, error } = await supabase
      .from("followup_enrollments")
      .select("id, protocol_id, patient_id, anchor_at, status, updated_at")
      .in("patient_id", patientIds)
      .order("anchor_at", { ascending: false })
      .limit(50);
    if (error) throw new Error(error.message);
    const protocolIds = Array.from(new Set((enrolls ?? []).map((e: any) => e.protocol_id)));
    let protocols: Record<string, any> = {};
    if (protocolIds.length) {
      const { data: ps } = await supabase
        .from("followup_protocols")
        .select("id, kod, nev, leiras, anchor_event, default_window_days")
        .in("id", protocolIds);
      protocols = Object.fromEntries((ps ?? []).map((p: any) => [p.id, p]));
    }
    // fetch steps for each protocol
    let stepsByProto: Record<string, any[]> = {};
    if (protocolIds.length) {
      const { data: ss } = await supabase
        .from("followup_protocol_steps")
        .select("id, protocol_id, phase_order, phase_label, offset_days_from, offset_days_to, cadence_days, channel")
        .in("protocol_id", protocolIds)
        .order("phase_order", { ascending: true });
      for (const s of ss ?? []) {
        (stepsByProto[s.protocol_id] ||= []).push(s);
      }
    }
    const enrollments = (enrolls ?? []).map((e: any) => ({
      ...e,
      protocol: protocols[e.protocol_id] ?? null,
      steps: stepsByProto[e.protocol_id] ?? [],
    }));

    // pending questionnaire assignments for these patients
    const { data: assigns } = await supabase
      .from("questionnaire_assignments")
      .select("id, patient_id, questionnaire_id, due_at, assigned_at, status, kind, questionnaires(id, title, becsult_perc)")
      .in("patient_id", patientIds)
      .in("status", ["assigned", "in_progress"])
      .order("due_at", { ascending: true, nullsFirst: false })
      .limit(50);

    return { enrollments, pendingQuestionnaires: assigns ?? [] };
  });
