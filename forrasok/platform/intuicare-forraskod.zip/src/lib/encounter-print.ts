import { BNO_SEED, OENO_SEED } from "@/lib/medical-codes";
import type { EncounterRow } from "@/components/paciensek/encounter-editor";

function esc(s: string | null | undefined): string {
  return String(s ?? "").replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[c] as string));
}

async function sha256Hex(s: string): Promise<string> {
  const buf = new TextEncoder().encode(s);
  const hash = await crypto.subtle.digest("SHA-256", buf);
  return Array.from(new Uint8Array(hash)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

export async function openEncounterPrint(opts: {
  encounter: EncounterRow;
  patientName: string;
  patientTaj: string | null;
  patientBirth: string | null;
  beavatkozasok: Array<{ id: string; kod: string; nev: string }>;
  szerzoName?: string;
  ellenjegyzoName?: string;
}) {
  const e = opts.encounter;
  const hash = await sha256Hex(JSON.stringify({
    id: e.id, patient: e.patient_id, start: e.ellatas_kezdete, end: e.ellatas_vege,
    bno: e.bno_kodok, oeno: e.oeno_kodok, beav: e.beavatkozas_ids, body: e.osszefoglalo,
    szerzo: e.szerzo_id, szerzo_at: e.szerzo_alairas_at,
    ellen: e.ellenjegyzo_id, ellen_at: e.ellenjegyzo_alairas_at,
  }));

  const bnoRows = (e.bno_kodok ?? []).map((k) => {
    const f = BNO_SEED.find((x) => x.kod === k);
    return `<li><code>${esc(k)}</code> — ${esc(f?.nev)}</li>`;
  }).join("");
  const oenoRows = (e.oeno_kodok ?? []).map((k) => {
    const f = OENO_SEED.find((x) => x.kod === k);
    return `<li><code>${esc(k)}</code> — ${esc(f?.nev)}</li>`;
  }).join("");
  const beavRows = (e.beavatkozas_ids ?? []).map((id) => {
    const f = opts.beavatkozasok.find((x) => x.id === id);
    return `<li><code>${esc(f?.kod)}</code> — ${esc(f?.nev)}</li>`;
  }).join("");

  const html = `<!doctype html><html lang="hu"><head><meta charset="utf-8" />
<title>Ellátási epizód · ${esc(opts.patientName)}</title>
<style>
  body { font-family: -apple-system, system-ui, sans-serif; color: #111; max-width: 780px; margin: 24px auto; padding: 0 24px; }
  header { border-bottom: 2px solid #111; padding-bottom: 8px; margin-bottom: 16px; }
  h1 { font-size: 18px; margin: 0; }
  .meta { font-size: 11px; color: #555; display: flex; justify-content: space-between; margin-top: 4px; }
  .hash { font-family: ui-monospace, Menlo, monospace; font-size: 10px; word-break: break-all; }
  section { margin: 14px 0; }
  h2 { font-size: 13px; margin: 12px 0 4px; text-transform: uppercase; letter-spacing: 0.06em; color: #333; }
  ul { margin: 4px 0 4px 18px; padding: 0; font-size: 12px; }
  code { background: #f1f1f1; padding: 1px 4px; border-radius: 3px; font-size: 11px; }
  .body { white-space: pre-wrap; font-size: 12px; padding: 8px; background: #fafafa; border: 1px solid #eee; border-radius: 4px; }
  .sign { border-top: 1px solid #ccc; padding-top: 8px; margin-top: 16px; display: grid; grid-template-columns: 1fr 1fr; gap: 12px; font-size: 11px; }
  .badge { display: inline-block; padding: 2px 8px; border-radius: 8px; font-size: 10px; background: #eef; color: #224; }
  @media print { body { margin: 0; } header { page-break-after: avoid; } }
</style></head><body>
<header>
  <h1>Ellátási epizód · ${esc(opts.patientName)}</h1>
  <div class="meta">
    <span>TAJ: ${esc(opts.patientTaj ?? "—")} · szül: ${esc(opts.patientBirth ?? "—")}</span>
    <span class="badge">${esc(e.status)}</span>
  </div>
  <div class="meta"><span>Epizód: ${esc(e.id)}</span><span>Kezdés: ${esc(new Date(e.ellatas_kezdete).toLocaleString("hu-HU"))}${e.ellatas_vege ? " · Vége: " + esc(new Date(e.ellatas_vege).toLocaleString("hu-HU")) : ""}</span></div>
  <div class="meta"><span>Típus: ${esc(e.tipus)}${e.intezmenyi_azonosito ? " · Int.az.: " + esc(e.intezmenyi_azonosito) : ""}</span></div>
  <div class="meta hash">Integritás-hash (SHA-256): ${hash}</div>
</header>

${bnoRows ? `<section><h2>BNO-10 diagnózisok</h2><ul>${bnoRows}</ul></section>` : ""}
${oenoRows ? `<section><h2>OENO beavatkozás-kódok</h2><ul>${oenoRows}</ul></section>` : ""}
${beavRows ? `<section><h2>Belső beavatkozás-tételek</h2><ul>${beavRows}</ul></section>` : ""}

<section><h2>Összefoglaló / dekurzus</h2>
  <div class="body">${esc(e.osszefoglalo ?? "")}</div>
</section>

<div class="sign">
  <div><b>Szerző</b><br/>
    ${e.szerzo_alairas_at
      ? `${esc(opts.szerzoName ?? e.szerzo_id ?? "")}<br/><span class="hash">aláírva: ${esc(new Date(e.szerzo_alairas_at).toLocaleString("hu-HU"))}</span>`
      : `<i>nincs aláírás</i>`}
  </div>
  <div><b>Ellenjegyző</b><br/>
    ${e.ellenjegyzo_alairas_at
      ? `${esc(opts.ellenjegyzoName ?? e.ellenjegyzo_id ?? "")}<br/><span class="hash">ellenjegyezve: ${esc(new Date(e.ellenjegyzo_alairas_at).toLocaleString("hu-HU"))}</span>`
      : `<i>nincs ellenjegyzés</i>`}
  </div>
</div>

<script>setTimeout(() => window.print(), 200);</script>
</body></html>`;

  const w = window.open("", "_blank", "width=900,height=1000");
  if (!w) {
    alert("Engedélyezze a popup-ablakot a PDF-exporthoz.");
    return;
  }
  w.document.open();
  w.document.write(html);
  w.document.close();
}
