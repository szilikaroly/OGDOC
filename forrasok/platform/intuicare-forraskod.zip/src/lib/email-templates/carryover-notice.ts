/**
 * Email sablon: szabadság áthozat értesítés évzáráskor.
 */
export type CarryoverData = {
  name: string;
  fromYear: number;
  toYear: number;
  items: Array<{ jogcim: string; athozott: number; elveszett?: number }>;
  deadlineMmDd: string;
  appUrl?: string;
};

function esc(s: string | number): string {
  return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));
}

export function renderCarryoverHtml(d: CarryoverData): string {
  const rows = d.items
    .map(
      (it) => `
      <tr>
        <td style="padding:6px 8px;border-bottom:1px solid #e5e7eb;font-size:13px">${esc(it.jogcim)}</td>
        <td style="padding:6px 8px;border-bottom:1px solid #e5e7eb;text-align:right;font-family:ui-monospace,monospace;font-size:13px">${esc(it.athozott)} nap</td>
        <td style="padding:6px 8px;border-bottom:1px solid #e5e7eb;text-align:right;font-family:ui-monospace,monospace;font-size:13px;color:${it.elveszett && it.elveszett > 0 ? "#b91c1c" : "#6b7280"}">${esc(it.elveszett ?? 0)}</td>
      </tr>`,
    )
    .join("");
  const cta = d.appUrl
    ? `<p style="margin:22px 0 0"><a href="${esc(d.appUrl)}" style="display:inline-block;background:#0f766e;color:#fff;text-decoration:none;padding:10px 18px;border-radius:8px;font-weight:600">Egyenlegem</a></p>`
    : "";
  return `<!doctype html><html lang="hu"><head><meta charset="utf-8"><title>Szabadság áthozat</title></head>
<body style="margin:0;background:#ffffff;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;color:#111827">
<div style="max-width:600px;margin:0 auto;padding:24px">
  <h1 style="margin:0 0 6px;font-size:20px;color:#0f766e">Szabadság áthozat ${esc(d.fromYear)} → ${esc(d.toYear)}</h1>
  <p style="margin:0 0 14px;color:#374151;font-size:14px">Kedves ${esc(d.name)}!</p>
  <p style="margin:0 0 14px;color:#374151;font-size:14px">
    A ${esc(d.fromYear)}. év lezárásra került. A hátralévő napjaid áthozásra kerültek a ${esc(d.toYear)}. évre.
    Az áthozott napokat <strong>${esc(d.toYear)}. ${esc(d.deadlineMmDd)}</strong>-ig kötelező kiadni.
  </p>
  <table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;border-collapse:collapse;margin-top:8px">
    <thead><tr>
      <th style="text-align:left;padding:6px 8px;font-size:11px;text-transform:uppercase;color:#6b7280;border-bottom:1px solid #d1d5db">Jogcím</th>
      <th style="text-align:right;padding:6px 8px;font-size:11px;text-transform:uppercase;color:#6b7280;border-bottom:1px solid #d1d5db">Áthozott</th>
      <th style="text-align:right;padding:6px 8px;font-size:11px;text-transform:uppercase;color:#6b7280;border-bottom:1px solid #d1d5db">Elveszett</th>
    </tr></thead>
    <tbody>${rows}</tbody>
  </table>
  ${cta}
  <p style="margin:24px 0 0;color:#9ca3af;font-size:11px">Az „elveszett" oszlop az Mt. 123. § szerinti 1/4 korlát miatt nem áthozható napokat tartalmazza.</p>
</div></body></html>`;
}
