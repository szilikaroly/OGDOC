/**
 * Heti email-összefoglaló sablon — egyszerű HTML renderer (külső React Email dep nélkül).
 */
export type DigestData = {
  weekStart: string;
  weekEnd: string;
  newPatients: number;
  questionnaires: number;
  criticalAlerts: number;
  referrals: number;
  eesztErrors: number;
};

const BRAND_BG = "#ffffff";
const BRAND_ACCENT = "#0f766e";

function esc(s: string | number): string {
  return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));
}

function statCard(label: string, value: number, accent = BRAND_ACCENT): string {
  return `
    <td style="padding:8px;width:50%;vertical-align:top">
      <div style="border:1px solid #e5e7eb;border-radius:8px;padding:14px 16px;background:#fafafa">
        <div style="font-size:12px;color:#6b7280;text-transform:uppercase;letter-spacing:.04em">${esc(label)}</div>
        <div style="font-size:28px;font-weight:700;color:${accent};margin-top:4px">${esc(value)}</div>
      </div>
    </td>`;
}

export function renderWeeklyDigestHtml(d: DigestData): string {
  return `<!doctype html><html lang="hu"><head><meta charset="utf-8"><title>Heti összefoglaló</title></head>
<body style="margin:0;padding:0;background:${BRAND_BG};font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;color:#111827">
  <div style="max-width:600px;margin:0 auto;padding:24px">
    <h1 style="margin:0 0 6px;font-size:22px;color:${BRAND_ACCENT}">Heti összefoglaló</h1>
    <p style="margin:0 0 18px;color:#6b7280;font-size:14px">${esc(d.weekStart)} – ${esc(d.weekEnd)}</p>

    <table role="presentation" cellpadding="0" cellspacing="0" border="0" style="width:100%;border-collapse:separate;border-spacing:0">
      <tr>
        ${statCard("Új páciensek", d.newPatients)}
        ${statCard("Kitöltött kérdőívek", d.questionnaires)}
      </tr>
      <tr>
        ${statCard("Kritikus riasztások", d.criticalAlerts, "#dc2626")}
        ${statCard("Beutaló kérelmek", d.referrals)}
      </tr>
    </table>

    <p style="margin:24px 0 0;font-size:13px;color:#6b7280">
      A részletekért lépj be a portálra. Ez egy automatikus üzenet a heti összefoglaló alapján.
    </p>
  </div>
</body></html>`;
}
