/**
 * Email sablon: kötelező (kényszer) szabadság-kiadás értesítője.
 */
export type ForcedTakeoutData = {
  name: string;
  ev: number;
  deadlineMmDd: string;
  items: Array<{ kezdo: string; zaro: string; nap: number; jogcim: string; forrasev?: number | null }>;
  reason?: string;
  appUrl?: string;
};

function esc(s: string | number): string {
  return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));
}

export function renderForcedTakeoutHtml(d: ForcedTakeoutData): string {
  const rows = d.items
    .map(
      (it) => `
      <tr>
        <td style="padding:6px 8px;border-bottom:1px solid #e5e7eb;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:13px">${esc(it.kezdo)} – ${esc(it.zaro)}</td>
        <td style="padding:6px 8px;border-bottom:1px solid #e5e7eb;text-align:right;font-family:ui-monospace,monospace;font-size:13px">${esc(it.nap)} nap</td>
        <td style="padding:6px 8px;border-bottom:1px solid #e5e7eb;font-size:13px">${esc(it.jogcim)}${it.forrasev ? ` <span style="color:#6b7280">(${esc(it.forrasev)})</span>` : ""}</td>
      </tr>`,
    )
    .join("");
  const cta = d.appUrl
    ? `<p style="margin:22px 0 0"><a href="${esc(d.appUrl)}" style="display:inline-block;background:#0f766e;color:#fff;text-decoration:none;padding:10px 18px;border-radius:8px;font-weight:600">Megnyitás</a></p>`
    : "";
  return `<!doctype html><html lang="hu"><head><meta charset="utf-8"><title>Kötelező szabadság kiadás</title></head>
<body style="margin:0;background:#ffffff;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;color:#111827">
<div style="max-width:600px;margin:0 auto;padding:24px">
  <h1 style="margin:0 0 6px;font-size:20px;color:#0f766e">Kötelező szabadság kiadás (${esc(d.ev)})</h1>
  <p style="margin:0 0 14px;color:#374151;font-size:14px">Kedves ${esc(d.name)}!</p>
  <p style="margin:0 0 14px;color:#374151;font-size:14px">
    A ${esc(d.ev)}. évi (vagy korábbról áthozott) ki nem vett szabadság<strong>napjai kötelező kiadásra kerültek</strong>,
    a ${esc(d.ev + 1)}. ${esc(d.deadlineMmDd)} törvényi határidő miatt.
  </p>
  <table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;border-collapse:collapse;margin-top:8px">
    <thead><tr>
      <th style="text-align:left;padding:6px 8px;font-size:11px;text-transform:uppercase;color:#6b7280;border-bottom:1px solid #d1d5db">Időszak</th>
      <th style="text-align:right;padding:6px 8px;font-size:11px;text-transform:uppercase;color:#6b7280;border-bottom:1px solid #d1d5db">Napok</th>
      <th style="text-align:left;padding:6px 8px;font-size:11px;text-transform:uppercase;color:#6b7280;border-bottom:1px solid #d1d5db">Jogcím (forrásév)</th>
    </tr></thead>
    <tbody>${rows}</tbody>
  </table>
  ${d.reason ? `<p style="margin:18px 0 0;color:#6b7280;font-size:12px"><strong>Indok:</strong> ${esc(d.reason)}</p>` : ""}
  ${cta}
  <p style="margin:24px 0 0;color:#9ca3af;font-size:11px">Ha kérdésed van, fordulj a HR-hez vagy a felettesedhez.</p>
</div></body></html>`;
}
