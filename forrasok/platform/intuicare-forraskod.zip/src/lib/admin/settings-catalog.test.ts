import { describe, it, expect } from "vitest";
import { CATEGORIES, SETTINGS, getSettingDef, publicKeys } from "./settings-catalog";

describe("settings-catalog integritás", () => {
  it("minden beállítás namespace-e létezik a kategóriák között", () => {
    const ids = new Set(CATEGORIES.map((c) => c.id));
    for (const s of SETTINGS) {
      expect(ids.has(s.namespace), `Ismeretlen namespace: ${s.namespace}`).toBe(true);
    }
  });

  it("nincs duplikált (namespace,key) kulcs", () => {
    const seen = new Set<string>();
    for (const s of SETTINGS) {
      const k = `${s.namespace}.${s.key}`;
      expect(seen.has(k), `Duplikált beállítás: ${k}`).toBe(false);
      seen.add(k);
    }
  });

  it("enum típus default értéke szerepel az options között", () => {
    for (const s of SETTINGS) {
      if (s.type !== "enum") continue;
      const values = (s.options ?? []).map((o) => o.value);
      expect(values, `${s.namespace}.${s.key} hiányzó options`).toContain(String(s.default));
    }
  });

  it("number típus default a min/max tartományban van", () => {
    for (const s of SETTINGS) {
      if (s.type !== "number" && s.type !== "duration_seconds") continue;
      const v = Number(s.default);
      if (typeof s.min === "number") expect(v).toBeGreaterThanOrEqual(s.min);
      if (typeof s.max === "number") expect(v).toBeLessThanOrEqual(s.max);
    }
  });

  it("getSettingDef visszaad ismert beállítást, ismeretlent nem", () => {
    expect(getSettingDef("general", "brand_name")).toBeDefined();
    expect(getSettingDef("general", "nincs_ilyen")).toBeUndefined();
  });

  it("publicKeys csak public scope-ot ad vissza", () => {
    const pub = publicKeys();
    for (const { namespace, key } of pub) {
      expect(getSettingDef(namespace, key)?.scope).toBe("public");
    }
  });

  it("label és description nem üres", () => {
    for (const s of SETTINGS) {
      expect(s.label.trim().length, `${s.namespace}.${s.key} label üres`).toBeGreaterThan(0);
    }
  });
});
