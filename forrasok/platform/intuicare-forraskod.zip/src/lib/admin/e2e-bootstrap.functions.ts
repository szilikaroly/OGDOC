/**
 * E2E teszt user bootstrap + cleanup szerver funkciók.
 * Csak `tenant_admin` szerepkörrel hívhatók.
 *
 * - `bootstrapE2eUsers`: létrehoz 6 auth user-t fix jelszóval, profile + szerepkör mapping-gel.
 * - `cleanupE2eTestData`: a migrációban definiált `public.cleanup_e2e_test_data()` RPC-t hívja.
 * - `deleteE2eUsers`: az E2E auth user-eket törli (Admin API).
 *
 * A `supabaseAdmin` import KIZÁRÓLAG a handler törzsén belül történik (lásd
 * tanstack-supabase-import-graph), különben a client bundle leak-ne.
 */
import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const E2E_TENANT_ID = "13aacb24-a6c2-445c-84b5-5ddbd1fcca82";
const E2E_PASSWORD = "E2eTest!2026";
const E2E_DOMAIN = "medroster.test";

type StaffSpec = {
  slug: "admin" | "vezeto" | "sebesz1" | "sebesz2" | "recepcio";
  fullName: string;
  foglalkozas: "orvos" | "szakdolgozo" | "egyeb";
  roleKey: string; // public.roles.kulcs
};

const STAFF: StaffSpec[] = [
  { slug: "admin",    fullName: "E2E Admin",      foglalkozas: "egyeb",       roleKey: "tenant_admin" },
  { slug: "vezeto",   fullName: "E2E Vezető",     foglalkozas: "orvos",       roleKey: "intezetvezeto" },
  { slug: "sebesz1",  fullName: "E2E Sebész 1",   foglalkozas: "orvos",       roleKey: "szakorvos" },
  { slug: "sebesz2",  fullName: "E2E Sebész 2",   foglalkozas: "orvos",       roleKey: "szakorvos" },
  { slug: "recepcio", fullName: "E2E Recepció",   foglalkozas: "szakdolgozo", roleKey: "pro" },
];

async function assertTenantAdmin(supabase: any, userId: string) {
  const { data, error } = await supabase
    .from("user_roles")
    .select("role_id, roles!inner(kulcs)")
    .eq("user_id", userId)
    .eq("tenant_id", E2E_TENANT_ID);
  if (error) throw new Error("Jogosultság ellenőrzés hiba: " + error.message);
  const isAdmin = (data ?? []).some((r: any) => r.roles?.kulcs === "tenant_admin");
  if (!isAdmin) throw new Error("Forbidden: csak tenant_admin futtathatja");
}

export const bootstrapE2eUsers = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertTenantAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const results: Array<{ slug: string; email: string; status: string; user_id?: string; error?: string }> = [];

    // Lekérjük a role katalógust
    const { data: rolesCatalog, error: rolesErr } = await supabaseAdmin
      .from("roles").select("id, kulcs");
    if (rolesErr) throw new Error("roles olvasás: " + rolesErr.message);
    const roleByKey = new Map<string, string>();
    (rolesCatalog ?? []).forEach((r: any) => roleByKey.set(r.kulcs, r.id));

    // ===== STAFF userek =====
    for (const s of STAFF) {
      const email = `e2e.${s.slug}@${E2E_DOMAIN}`;
      try {
        // Létezik már?
        let userId: string | undefined;
        const { data: existing } = await supabaseAdmin.auth.admin.listUsers({ page: 1, perPage: 200 });
        const found = existing?.users?.find((u: any) => u.email === email);
        if (found) {
          userId = found.id;
        } else {
          const { data: created, error: cErr } = await supabaseAdmin.auth.admin.createUser({
            email, password: E2E_PASSWORD, email_confirm: true,
            user_metadata: { teljes_nev: s.fullName, e2e: true },
          });
          if (cErr) throw cErr;
          userId = created.user?.id;
        }
        if (!userId) throw new Error("nincs user_id");

        // Profile upsert
        const { error: pErr } = await supabaseAdmin.from("profiles").upsert({
          id: userId,
          tenant_id: E2E_TENANT_ID,
          teljes_nev: s.fullName,
          email,
          foglalkozas_tipus: s.foglalkozas,
          aktiv: true,
        }, { onConflict: "id" });
        if (pErr) throw pErr;

        // Role mapping
        const roleId = roleByKey.get(s.roleKey);
        if (!roleId) throw new Error(`role nem található: ${s.roleKey}`);
        const { error: rErr } = await supabaseAdmin.from("user_roles").upsert({
          tenant_id: E2E_TENANT_ID,
          user_id: userId,
          role_id: roleId,
        }, { onConflict: "tenant_id,user_id,role_id" });
        if (rErr && !rErr.message.includes("duplicate")) throw rErr;

        results.push({ slug: s.slug, email, status: found ? "exists" : "created", user_id: userId });
      } catch (e: any) {
        results.push({ slug: s.slug, email, status: "error", error: String(e?.message ?? e) });
      }
    }

    // ===== Beteg user =====
    const betegEmail = `e2e.beteg@${E2E_DOMAIN}`;
    try {
      let userId: string | undefined;
      const { data: existing } = await supabaseAdmin.auth.admin.listUsers({ page: 1, perPage: 200 });
      const found = existing?.users?.find((u: any) => u.email === betegEmail);
      if (found) userId = found.id;
      else {
        const { data: created, error: cErr } = await supabaseAdmin.auth.admin.createUser({
          email: betegEmail, password: E2E_PASSWORD, email_confirm: true,
          user_metadata: { teljes_nev: "E2E Teszt Béla", e2e: true, role: "patient" },
        });
        if (cErr) throw cErr;
        userId = created.user?.id;
      }
      if (!userId) throw new Error("nincs user_id");

      // patient_users link a seed-elt E2E_Teszt Béla rekorddal
      const { data: patient } = await supabaseAdmin
        .from("patients")
        .select("id")
        .eq("tenant_id", E2E_TENANT_ID)
        .eq("vezeteknev", "E2E_Teszt")
        .eq("keresztnev", "Béla")
        .maybeSingle();

      if (patient?.id) {
        const { error: linkErr } = await supabaseAdmin.from("patient_users").upsert({
          user_id: userId, patient_id: patient.id, tenant_id: E2E_TENANT_ID,
          kapcsolat: "self", verified_at: new Date().toISOString(),
        }, { onConflict: "user_id,patient_id" });
        if (linkErr && !linkErr.message.includes("duplicate")) throw linkErr;
      }
      results.push({ slug: "beteg", email: betegEmail, status: found ? "exists" : "created", user_id: userId });
    } catch (e: any) {
      results.push({ slug: "beteg", email: betegEmail, status: "error", error: String(e?.message ?? e) });
    }

    return { ok: true, password: E2E_PASSWORD, users: results };
  });

export const cleanupE2eTestData = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertTenantAdmin(context.supabase, context.userId);
    const { data, error } = await context.supabase.rpc("cleanup_e2e_test_data");
    if (error) throw new Error(error.message);
    return { ok: true, result: data };
  });

export const deleteE2eUsers = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertTenantAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: list, error: lErr } = await supabaseAdmin.auth.admin.listUsers({ page: 1, perPage: 200 });
    if (lErr) throw new Error(lErr.message);
    const targets = (list?.users ?? []).filter((u: any) => (u.email ?? "").startsWith("e2e.") && (u.email ?? "").endsWith(`@${E2E_DOMAIN}`));
    const removed: string[] = [];
    for (const u of targets) {
      const { error } = await supabaseAdmin.auth.admin.deleteUser(u.id);
      if (!error) removed.push(u.email!);
    }
    return { ok: true, removed_count: removed.length, removed };
  });
