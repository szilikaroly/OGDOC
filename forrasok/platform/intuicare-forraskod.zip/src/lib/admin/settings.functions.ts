/**
 * Admin beállítások CRUD szerver funkciói.
 * Olvasás: publikus kulcsok bárki számára (anon is); privát kulcsok admin only.
 * Írás / publikálás / törlés: csak admin.
 */
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { createClient } from "@supabase/supabase-js";
import { SETTINGS, getSettingDef } from "./settings-catalog";

async function assertAdmin(ctx: { supabase: any; userId: string }) {
  const { data, error } = await ctx.supabase.rpc("has_role", { _user_id: ctx.userId, _role_kulcs: "tenant_admin" });
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Forbidden — admin jogosultság szükséges.");
}

/** Publikus beállítások lekérése (anon is hívhatja, server publishable client). */
export const getPublicSettings = createServerFn({ method: "GET" }).handler(async () => {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_PUBLISHABLE_KEY;
  if (!url || !key) return {};
  const sb = createClient(url, key, {
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
  });
  const { data, error } = await sb
    .from("app_settings")
    .select("namespace,key,value")
    .eq("is_public", true);
  if (error) return {};
  const out: Record<string, any> = {};
  for (const row of data ?? []) {
    out[`${(row as any).namespace}.${(row as any).key}`] = (row as any).value;
  }
  return out as Record<string, any>;
});

/** Minden beállítás (admin) — vázlat + élő érték együtt. */
export const listAllSettings = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    const { data, error } = await context.supabase
      .from("app_settings")
      .select("id,namespace,key,value,draft_value,is_public,updated_by,updated_at");
    if (error) throw new Error(error.message);
    // Merge with catalog defaults so brand new settings show up
    const map = new Map<string, any>();
    for (const row of data ?? []) map.set(`${row.namespace}.${row.key}`, row);
    return SETTINGS.map((s) => {
      const row = map.get(`${s.namespace}.${s.key}`);
      return {
        namespace: s.namespace,
        key: s.key,
        value: row?.value ?? s.default,
        draft_value: row?.draft_value ?? null,
        is_public: row?.is_public ?? s.scope === "public",
        updated_by: row?.updated_by ?? null,
        updated_at: row?.updated_at ?? null,
        exists: !!row,
      };
    });
  });

/** Egy érték frissítése (vázlatként vagy élőben). */
const UpsertInput = z.object({
  namespace: z.string(),
  key: z.string(),
  value: z.unknown(),
  asDraft: z.boolean().optional().default(false),
});

export const upsertSetting = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => UpsertInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const def = getSettingDef(data.namespace, data.key);
    if (!def) throw new Error(`Ismeretlen beállítás: ${data.namespace}.${data.key}`);
    const payload: any = {
      namespace: data.namespace,
      key: data.key,
      is_public: def.scope === "public",
      updated_by: context.userId,
    };
    if (data.asDraft) payload.draft_value = data.value;
    else { payload.value = data.value; payload.draft_value = null; }

    const { error } = await context.supabase
      .from("app_settings")
      .upsert(payload, { onConflict: "namespace,key" });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/** Vázlat publikálása. */
export const publishDraft = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ namespace: z.string(), key: z.string() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { data: row, error } = await context.supabase
      .from("app_settings")
      .select("id,draft_value")
      .eq("namespace", data.namespace).eq("key", data.key).maybeSingle();
    if (error) throw new Error(error.message);
    if (!row?.draft_value) return { ok: true };
    const { error: e2 } = await context.supabase
      .from("app_settings")
      .update({ value: row.draft_value, draft_value: null, updated_by: context.userId })
      .eq("id", row.id);
    if (e2) throw new Error(e2.message);
    return { ok: true };
  });

/** Reset to default. */
export const resetSetting = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ namespace: z.string(), key: z.string() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const def = getSettingDef(data.namespace, data.key);
    if (!def) throw new Error("Ismeretlen kulcs");
    const { error } = await context.supabase
      .from("app_settings")
      .upsert({
        namespace: data.namespace, key: data.key, value: def.default as any, draft_value: null,
        is_public: def.scope === "public", updated_by: context.userId,
      } as any, { onConflict: "namespace,key" });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/** Audit log egy kulcshoz. */
export const getAudit = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ namespace: z.string(), key: z.string(), limit: z.number().optional().default(20) }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { data: rows, error } = await context.supabase
      .from("app_settings_audit")
      .select("action,old_value,new_value,changed_by,changed_at,reason")
      .eq("namespace", data.namespace).eq("key", data.key)
      .order("changed_at", { ascending: false }).limit(data.limit);
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

/** Tömeges export / import. */
export const exportSettings = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    const { data, error } = await context.supabase
      .from("app_settings").select("namespace,key,value,is_public");
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const importSettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ items: z.array(z.object({
    namespace: z.string(), key: z.string(), value: z.unknown(),
  })) }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    let imported = 0;
    for (const item of data.items) {
      const def = getSettingDef(item.namespace, item.key);
      if (!def) continue;
      const { error } = await context.supabase.from("app_settings").upsert({
        namespace: item.namespace, key: item.key, value: item.value as any,
        is_public: def.scope === "public", updated_by: context.userId,
      } as any, { onConflict: "namespace,key" });
      if (!error) imported++;
    }
    return { imported };
  });
