/**
 * Admin portál-analitika: read-only aggregátumok a páciens-portál használatáról.
 * Csak admin szerepkörrel hívható.
 */
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const RangeInput = z.object({
  days: z.union([z.literal(7), z.literal(30), z.literal(90)]).default(30),
});

async function canViewPortalAnalytics(ctx: { supabase: any; userId: string }) {
  const { data: hasPermission, error: permissionError } = await ctx.supabase.rpc("has_permission", {
    _user_id: ctx.userId,
    _perm: "manage_tenant",
  });
  if (permissionError) throw new Error(permissionError.message);
  if (hasPermission) return true;

  const { data: isTenantAdmin, error: roleError } = await ctx.supabase.rpc("has_role", {
    _user_id: ctx.userId,
    _role_kulcs: "tenant_admin",
  });
  if (roleError) throw new Error(roleError.message);
  return Boolean(isTenantAdmin);
}

export const getPortalAnalytics = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => RangeInput.parse(d ?? {}))
  .handler(async ({ data, context }) => {
    const allowed = await canViewPortalAnalytics(context);
    if (!allowed) {
      return {
        status: "forbidden" as const,
        message: "Nincs jogosultság a portál analitika megtekintéséhez.",
      };
    }

    const { supabase } = context;
    const sinceIso = new Date(Date.now() - data.days * 86400_000).toISOString();

    // KPI 1 — active patients (any portal-side write or notification view in window)
    const { count: activePatients } = await supabase
      .from("notifications")
      .select("user_id", { count: "exact", head: true })
      .gte("created_at", sinceIso);

    // KPI 2 — completed questionnaires in window
    const { count: completedQuestionnaires } = await supabase
      .from("questionnaire_responses")
      .select("id", { count: "exact", head: true })
      .gte("created_at", sinceIso);

    // KPI 3 — critical alerts response time (avg, p95)
    const { data: alerts } = await supabase
      .from("clinical_critical_alerts")
      .select("created_at, acknowledged_at")
      .gte("created_at", sinceIso)
      .not("acknowledged_at", "is", null)
      .limit(2000);
    const deltas = (alerts ?? [])
      .map((a: any) => {
        const t1 = new Date(a.created_at).getTime();
        const t2 = new Date(a.acknowledged_at).getTime();
        return Math.max(0, (t2 - t1) / 60000); // minutes
      })
      .sort((a, b) => a - b);
    const avgAckMin = deltas.length ? deltas.reduce((s, v) => s + v, 0) / deltas.length : 0;
    const p95AckMin = deltas.length ? deltas[Math.min(deltas.length - 1, Math.floor(deltas.length * 0.95))] : 0;

    // KPI 4 — AI explanation usage count
    const { count: aiExplanations } = await supabase
      .from("patient_ai_explanations")
      .select("id", { count: "exact", head: true })
      .gte("created_at", sinceIso);

    // Chart: questionnaires per day
    const { data: qDaily } = await supabase
      .from("questionnaire_responses")
      .select("created_at")
      .gte("created_at", sinceIso)
      .limit(5000);
    const byDay: Record<string, number> = {};
    for (const r of qDaily ?? []) {
      const k = new Date((r as any).created_at).toISOString().slice(0, 10);
      byDay[k] = (byDay[k] ?? 0) + 1;
    }
    const questionnaireDaily = Object.entries(byDay)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([date, count]) => ({ date, count }));

    return {
      status: "ok" as const,
      range_days: data.days,
      kpis: {
        active_patients: activePatients ?? 0,
        completed_questionnaires: completedQuestionnaires ?? 0,
        avg_alert_ack_min: Math.round(avgAckMin * 10) / 10,
        p95_alert_ack_min: Math.round(p95AckMin * 10) / 10,
        ai_explanations: aiExplanations ?? 0,
      },
      charts: {
        questionnaire_daily: questionnaireDaily,
      },
    };
  });
