/**
 * AI asszisztens szerver funkciói — beállítások és landing blokkok javaslata.
 * Csak admin hívhatja.
 */
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { generateText } from "ai";
import { createLovableAiGatewayProvider } from "@/lib/ai-gateway.server";
import { getSettingDef } from "./settings-catalog";

async function assertAdmin(ctx: { supabase: any; userId: string }) {
  const { data, error } = await ctx.supabase.rpc("has_role", { _user_id: ctx.userId, _role_kulcs: "tenant_admin" });
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Forbidden");
}

function getGateway() {
  const key = process.env.LOVABLE_API_KEY;
  if (!key) throw new Error("LOVABLE_API_KEY hiányzik");
  return createLovableAiGatewayProvider(key);
}

const DEFAULT_MODEL = "google/gemini-3-flash-preview";

/** Konkrét beállítás-értékhez javaslat. */
export const suggestSettingValue = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({
    namespace: z.string(), key: z.string(),
    currentValue: z.unknown().optional(),
    goal: z.string().optional(),
    brandContext: z.string().optional(),
  }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const def = getSettingDef(data.namespace, data.key);
    if (!def) throw new Error("Ismeretlen kulcs");
    const gateway = getGateway();
    const prompt = `Beállítás: ${def.label} (${def.namespace}.${def.key})
Leírás: ${def.description}
Típus: ${def.type}${def.options ? `\nLehetséges értékek: ${def.options.map(o=>o.value).join(", ")}` : ""}
Alapérték: ${JSON.stringify(def.default)}
Jelenlegi érték: ${JSON.stringify(data.currentValue ?? def.default)}
${data.brandContext ? `Brand kontextus: ${data.brandContext}` : ""}
${data.goal ? `Cél: ${data.goal}` : ""}
${def.aiPrompt ? `Útmutató: ${def.aiPrompt}` : ""}

Adj VISSZA egyetlen JSON objektumot ezzel a sémával:
{ "value": <a javasolt érték a megfelelő típusban>, "rationale": "<rövid magyar indoklás>" }
Csak a JSON-t add vissza, semmi mást.`;

    const { text } = await generateText({
      model: gateway(DEFAULT_MODEL),
      prompt,
    });
    let parsedValue: any = def.default;
    let parsedRationale = "";
    try {
      const clean = text.trim().replace(/^```(?:json)?\s*/i, "").replace(/```\s*$/, "");
      const p = JSON.parse(clean);
      parsedValue = p.value;
      parsedRationale = String(p.rationale ?? "");
    } catch {
      parsedValue = text.trim();
      parsedRationale = "Nem strukturált válasz";
    }
    await context.supabase.from("ai_setting_suggestions").insert({
      target_kind: "setting",
      target_namespace: data.namespace,
      target_key: data.key,
      goal: data.goal,
      suggested_value: parsedValue,
      rationale: parsedRationale,
      model: DEFAULT_MODEL,
      created_by: context.userId,
    });
    return { value: JSON.stringify(parsedValue), rationale: parsedRationale };
  });

/** Beállítás magyarázat tooltip-hez. */
export const explainSetting = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ namespace: z.string(), key: z.string() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const def = getSettingDef(data.namespace, data.key);
    if (!def) throw new Error("Ismeretlen kulcs");
    const gateway = getGateway();
    const { text } = await generateText({
      model: gateway(DEFAULT_MODEL),
      prompt: `Magyarázd el 3-4 mondatban magyarul, mit jelent és mire hat az alábbi rendszerbeállítás egy egészségügyi platformon:
"${def.label}" — ${def.description}
Típus: ${def.type}, alapérték: ${JSON.stringify(def.default)}.`,
    });
    return { explanation: text.trim() };
  });

/** Landing blokk-mező javaslat. */
export const generateLandingBlock = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({
    blockType: z.string(),
    field: z.string(),
    prompt: z.string(),
    brandContext: z.string().optional(),
  }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const gateway = getGateway();
    const { text } = await generateText({
      model: gateway(DEFAULT_MODEL),
      prompt: `Generálj szöveget egy "${data.blockType}" landing page blokk "${data.field}" mezőjéhez.
${data.brandContext ? `Brand: ${data.brandContext}\n` : ""}Kérés: ${data.prompt}
Válasz: csak a szöveg, jelölés nélkül. Magyarul.`,
    });
    return { value: text.trim() };
  });

/** Teljes landing draft generálás. */
export const generateFullLandingDraft = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({
    prompt: z.string(),
    brandContext: z.string().optional(),
  }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const gateway = getGateway();
    const { text } = await generateText({
      model: gateway("google/gemini-2.5-pro"),
      prompt: `Tervezz egy landing page blokk-listát egészségügyi platformhoz.
${data.brandContext ? `Brand: ${data.brandContext}\n` : ""}Kérés: ${data.prompt}

Adj vissza egyetlen JSON tömböt ezzel a sémával:
[
  {"block_type":"hero","content":{"title":"...","subtitle":"...","cta_label":"...","cta_to":"/auth"}},
  {"block_type":"feature_grid","content":{"title":"...","items":[{"title":"...","description":"..."}]}},
  {"block_type":"stats","content":{"items":[{"value":"...","label":"..."}]}},
  {"block_type":"cta_band","content":{"title":"...","cta_label":"...","cta_to":"/auth"}},
  {"block_type":"faq","content":{"items":[{"q":"...","a":"..."}]}}
]
Csak JSON, semmi más. Magyarul.`,
    });
    let blocks: any[] = [];
    try {
      const clean = text.trim().replace(/^```(?:json)?\s*/i, "").replace(/```\s*$/, "");
      blocks = JSON.parse(clean);
    } catch {
      blocks = [];
    }
    return { blocks };
  });

/** Batch javaslat — több beállítás egy célhoz. */
export const suggestSettingsBatch = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({
    goal: z.string(),
    namespace: z.string().optional(),
  }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { SETTINGS } = await import("./settings-catalog");
    const targets = SETTINGS.filter((s) => !data.namespace || s.namespace === data.namespace).slice(0, 30);
    const gateway = getGateway();
    const list = targets.map((s) => `- ${s.namespace}.${s.key} (${s.type}, default: ${JSON.stringify(s.default)}): ${s.label}`).join("\n");
    const { text } = await generateText({
      model: gateway("google/gemini-2.5-pro"),
      prompt: `Cél: ${data.goal}

Itt az elérhető beállítások listája:
${list}

Adj VISSZA egyetlen JSON tömböt csak azokkal, amelyeket javasolsz módosítani:
[{"namespace":"...","key":"...","value":<új érték>,"rationale":"..."}]
Csak JSON, semmi más.`,
    });
    let arr: any[] = [];
    try {
      const clean = text.trim().replace(/^```(?:json)?\s*/i, "").replace(/```\s*$/, "");
      arr = JSON.parse(clean);
    } catch {}
    return { suggestions: Array.isArray(arr) ? arr : [] };
  });
