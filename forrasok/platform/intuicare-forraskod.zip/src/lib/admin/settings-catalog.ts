/**
 * Beállítás-katalógus — egyetlen forrásigazság.
 * Új beállítás hozzáadásához csak ezt a fájlt kell bővíteni.
 *
 * type: a renderelt mező típusa
 * scope: 'public' = anon is olvashatja (pl. landing/branding), 'private' = admin-only
 */

export type SettingType =
  | "string"
  | "text"
  | "markdown"
  | "number"
  | "boolean"
  | "color"
  | "enum"
  | "json"
  | "duration_seconds"
  | "role_list"
  | "string_list";

export type SettingDef = {
  namespace: string;
  key: string;
  label: string;
  description: string;
  type: SettingType;
  default: unknown;
  options?: { value: string; label: string }[];
  scope: "public" | "private";
  aiPrompt?: string; // helper prompt for AI suggestion
  min?: number;
  max?: number;
};

export type SettingCategory = {
  id: string;
  label: string;
  icon: string; // lucide name
  description: string;
};

export const CATEGORIES: SettingCategory[] = [
  { id: "general", label: "Általános", icon: "Settings", description: "Márka, alapértelmezett nyelv, időzóna." },
  { id: "appearance", label: "Megjelenés", icon: "Palette", description: "Színek, betűtípusok, sűrűség." },
  { id: "auth", label: "Authentikáció", icon: "ShieldCheck", description: "Bejelentkezés, MFA, session." },
  { id: "patient_portal", label: "Páciens portál", icon: "Heart", description: "Modulok kapcsolói, üzenetek." },
  { id: "schedule", label: "Beosztás motor", icon: "CalendarRange", description: "Súlyok, küszöbök, cadenciák." },
  { id: "duty", label: "Ügyelet", icon: "AlertTriangle", description: "Kötelező ügyelet, túlóra plafon." },
  { id: "clinical", label: "Klinikai", icon: "Activity", description: "Vitális küszöbök, eszkaláció." },
  { id: "notifications", label: "Értesítések", icon: "Bell", description: "Csatornák, csendes órák." },
  { id: "email", label: "Email", icon: "Mail", description: "Feladó, sablonok." },
  { id: "integrations", label: "Integrációk", icon: "Plug", description: "EESZT, webhook, naptár." },
  { id: "ai", label: "AI / LLM", icon: "Sparkles", description: "Modellek, költségplafon, promptok." },
  { id: "i18n", label: "Lokalizáció", icon: "Languages", description: "Nyelvek, auto-fordítás." },
  { id: "privacy", label: "Adatvédelem", icon: "Lock", description: "Megőrzés, consent." },
  { id: "feature_flags", label: "Feature flagek", icon: "ToggleLeft", description: "Modul be/ki kapcsolók." },
  { id: "observability", label: "Megfigyelhetőség", icon: "Eye", description: "Log retention, hibanapló." },
];

export const SETTINGS: SettingDef[] = [
  // General
  { namespace: "general", key: "brand_name", label: "Márkanév", description: "A felületen megjelenő név.", type: "string", default: "MedRoster Suite Pro", scope: "public", aiPrompt: "Javasolj egy márkanevet egészségügyi platformnak" },
  { namespace: "general", key: "tagline", label: "Tagline", description: "Rövid leírás (header / og:description).", type: "string", default: "Egészségügyi platform", scope: "public", aiPrompt: "Írj egy 6-10 szavas tagline-t" },
  { namespace: "general", key: "logo_url", label: "Logo URL", description: "Logó kép URL (PNG/SVG).", type: "string", default: "", scope: "public" },
  { namespace: "general", key: "favicon_url", label: "Favicon URL", description: "Favicon kép.", type: "string", default: "/favicon.ico", scope: "public" },
  { namespace: "general", key: "default_locale", label: "Alap nyelv", description: "Alapértelmezett UI nyelv.", type: "enum", default: "hu", scope: "public", options: [{value:"hu",label:"Magyar"},{value:"en",label:"English"},{value:"de",label:"Deutsch"}] },
  { namespace: "general", key: "timezone", label: "Időzóna", description: "IANA TZ azonosító.", type: "string", default: "Europe/Budapest", scope: "private" },
  { namespace: "general", key: "currency", label: "Pénznem", description: "ISO 4217 kód.", type: "string", default: "HUF", scope: "private" },

  // Appearance
  { namespace: "appearance", key: "primary_color", label: "Elsődleges szín", description: "Brand primary szín (HSL/HEX).", type: "color", default: "#0ea5e9", scope: "public", aiPrompt: "Javasolj egy elegáns elsődleges színt egészségügyi platformhoz" },
  { namespace: "appearance", key: "accent_color", label: "Kiemelő szín", description: "Accent szín CTA-khoz.", type: "color", default: "#8b5cf6", scope: "public" },
  { namespace: "appearance", key: "sidebar_color", label: "Oldalsáv szín", description: "Oldalsáv háttér.", type: "color", default: "#0f172a", scope: "public" },
  { namespace: "appearance", key: "font_heading", label: "Cím font", description: "Google Fonts név.", type: "string", default: "Inter", scope: "public" },
  { namespace: "appearance", key: "font_body", label: "Szövegtörzs font", description: "Google Fonts név.", type: "string", default: "Inter", scope: "public" },
  { namespace: "appearance", key: "radius", label: "Sarokrádiusz (rem)", description: "Globális border-radius.", type: "number", default: 0.5, min: 0, max: 2, scope: "public" },
  { namespace: "appearance", key: "density", label: "Sűrűség", description: "UI komponensek sűrűsége.", type: "enum", default: "comfortable", scope: "public", options: [{value:"compact",label:"Sűrű"},{value:"comfortable",label:"Tágas"}] },
  { namespace: "appearance", key: "default_theme", label: "Alap téma", description: "Világos / sötét / rendszer.", type: "enum", default: "system", scope: "public", options: [{value:"light",label:"Világos"},{value:"dark",label:"Sötét"},{value:"system",label:"Rendszer"}] },
  { namespace: "appearance", key: "custom_css", label: "Custom CSS", description: "Globálisan injektált CSS.", type: "markdown", default: "", scope: "public" },

  // Auth
  { namespace: "auth", key: "allowed_providers", label: "Engedélyezett providerek", description: "Bejelentkezési módok.", type: "string_list", default: ["email","google"], scope: "private" },
  { namespace: "auth", key: "password_min_length", label: "Min. jelszóhossz", description: "Karakter.", type: "number", default: 12, min: 8, max: 64, scope: "private" },
  { namespace: "auth", key: "otp_expiry_seconds", label: "OTP érvényesség (s)", description: "Egyszer használatos kód lejárata.", type: "duration_seconds", default: 600, scope: "private" },
  { namespace: "auth", key: "session_timeout_seconds", label: "Session timeout (s)", description: "Inaktivitási kilépés.", type: "duration_seconds", default: 3600, scope: "private" },
  { namespace: "auth", key: "require_mfa_for_roles", label: "MFA kötelező szerepkörök", description: "Listán szereplő rolik esetén kötelező MFA.", type: "role_list", default: ["admin"], scope: "private" },

  // Patient portal
  { namespace: "patient_portal", key: "module_appointments", label: "Időpontok modul", description: "Időpont foglalás engedélyezve.", type: "boolean", default: true, scope: "public" },
  { namespace: "patient_portal", key: "module_messages", label: "Üzenetek modul", description: "Páciens üzenetváltás.", type: "boolean", default: true, scope: "public" },
  { namespace: "patient_portal", key: "module_lab_results", label: "Leletek modul", description: "Lelet megtekintés.", type: "boolean", default: true, scope: "public" },
  { namespace: "patient_portal", key: "module_lifestyle", label: "Életmód modul", description: "Életmód napló.", type: "boolean", default: true, scope: "public" },
  { namespace: "patient_portal", key: "module_sos", label: "SOS modul", description: "Sürgős hívás gomb.", type: "boolean", default: true, scope: "public" },
  { namespace: "patient_portal", key: "module_questionnaires", label: "Kérdőívek modul", description: "Kérdőív kitöltés.", type: "boolean", default: true, scope: "public" },
  { namespace: "patient_portal", key: "welcome_message", label: "Üdvözlő üzenet", description: "Portál landingen megjelenő szöveg.", type: "text", default: "Üdvözöljük a betegportálon!", scope: "public", aiPrompt: "Írj egy meleg, megnyugtató üdvözlést páciensportálra" },

  // Schedule
  { namespace: "schedule", key: "weight_fairness", label: "Méltányosság súly", description: "0–1 között.", type: "number", default: 0.7, min: 0, max: 1, scope: "private" },
  { namespace: "schedule", key: "weight_continuity", label: "Kontinuitás súly", description: "0–1 között.", type: "number", default: 0.5, min: 0, max: 1, scope: "private" },
  { namespace: "schedule", key: "weight_load", label: "Terhelés súly", description: "0–1 között.", type: "number", default: 0.8, min: 0, max: 1, scope: "private" },
  { namespace: "schedule", key: "auto_publish_day", label: "Auto-publikálás napja", description: "Hónap napja (1–28).", type: "number", default: 20, min: 1, max: 28, scope: "private" },
  { namespace: "schedule", key: "reminder_days_before", label: "Emlékeztető (nap)", description: "Műszak előtti emlékeztető.", type: "number", default: 1, min: 0, max: 7, scope: "private" },

  // Duty
  { namespace: "duty", key: "mandatory_duty_per_month", label: "Kötelező ügyelet / hó", description: "Alapérték.", type: "number", default: 4, min: 0, max: 20, scope: "private" },
  { namespace: "duty", key: "max_overtime_hours_month", label: "Max túlóra (óra/hó)", description: "Korlát.", type: "number", default: 80, min: 0, max: 200, scope: "private" },
  { namespace: "duty", key: "allow_opt_out", label: "Opt-out engedélyezve", description: "Dolgozó kérhet mentességet.", type: "boolean", default: true, scope: "private" },

  // Clinical
  { namespace: "clinical", key: "hr_alert_high", label: "Pulzus alert (felső)", description: "BPM küszöb.", type: "number", default: 120, min: 50, max: 220, scope: "private" },
  { namespace: "clinical", key: "hr_alert_low", label: "Pulzus alert (alsó)", description: "BPM küszöb.", type: "number", default: 45, min: 20, max: 80, scope: "private" },
  { namespace: "clinical", key: "bp_systolic_high", label: "RR systolic (felső)", description: "Hgmm.", type: "number", default: 180, scope: "private" },
  { namespace: "clinical", key: "critical_result_response_min", label: "Kritikus eredmény válaszidő (perc)", description: "SLA.", type: "number", default: 15, scope: "private" },
  { namespace: "clinical", key: "ai_explanation_enabled", label: "AI magyarázat engedélyezve", description: "Páciens-barát magyarázatok.", type: "boolean", default: true, scope: "public" },

  // Notifications
  { namespace: "notifications", key: "channel_email", label: "Email csatorna", description: "", type: "boolean", default: true, scope: "private" },
  { namespace: "notifications", key: "channel_push", label: "Push csatorna", description: "", type: "boolean", default: true, scope: "private" },
  { namespace: "notifications", key: "channel_sms", label: "SMS csatorna", description: "", type: "boolean", default: false, scope: "private" },
  { namespace: "notifications", key: "quiet_hours_start", label: "Csendes órák kezdete", description: "HH:MM.", type: "string", default: "22:00", scope: "private" },
  { namespace: "notifications", key: "quiet_hours_end", label: "Csendes órák vége", description: "HH:MM.", type: "string", default: "07:00", scope: "private" },
  { namespace: "notifications", key: "digest_cadence", label: "Digest gyakoriság", description: "", type: "enum", default: "daily", scope: "private", options: [{value:"off",label:"Ki"},{value:"daily",label:"Napi"},{value:"weekly",label:"Heti"}] },

  // Email
  { namespace: "email", key: "from_name", label: "Feladó név", description: "", type: "string", default: "MedRoster", scope: "private" },
  { namespace: "email", key: "from_address", label: "Feladó email", description: "", type: "string", default: "noreply@medroster.app", scope: "private" },
  { namespace: "email", key: "header_html", label: "Email header HTML", description: "Minden levél tetején.", type: "markdown", default: "", scope: "private" },
  { namespace: "email", key: "footer_html", label: "Email footer HTML", description: "Minden levél alján.", type: "markdown", default: "", scope: "private" },
  { namespace: "email", key: "template_welcome", label: "Welcome sablon", description: "Markdown.", type: "markdown", default: "Üdvözöljük {{name}}!", scope: "private", aiPrompt: "Írj egy welcome emailt új felhasználónak egészségügyi platformra" },
  { namespace: "email", key: "template_appointment_reminder", label: "Időpont emlékeztető", description: "Markdown.", type: "markdown", default: "Emlékeztető: {{date}} időpontja közeleg.", scope: "private" },

  // Integrations
  { namespace: "integrations", key: "eeszt_enabled", label: "EESZT integráció", description: "", type: "boolean", default: false, scope: "private" },
  { namespace: "integrations", key: "eeszt_endpoint", label: "EESZT endpoint", description: "URL.", type: "string", default: "", scope: "private" },
  { namespace: "integrations", key: "webhook_url", label: "Webhook URL", description: "Külső események fogadása.", type: "string", default: "", scope: "private" },
  { namespace: "integrations", key: "calendar_sync", label: "Naptár szinkron", description: "iCal feed engedélyezve.", type: "boolean", default: true, scope: "private" },

  // AI
  { namespace: "ai", key: "model_chat", label: "Chat modell", description: "Lovable AI modell.", type: "enum", default: "google/gemini-3-flash-preview", scope: "private", options: [
    {value:"google/gemini-3-flash-preview",label:"Gemini 3 Flash (gyors)"},
    {value:"google/gemini-2.5-flash",label:"Gemini 2.5 Flash"},
    {value:"google/gemini-2.5-pro",label:"Gemini 2.5 Pro (erős)"},
  ]},
  { namespace: "ai", key: "model_explanation", label: "Magyarázat modell", description: "Páciens-barát magyarázat.", type: "enum", default: "google/gemini-3-flash-preview", scope: "private", options: [
    {value:"google/gemini-3-flash-preview",label:"Gemini 3 Flash"},
    {value:"google/gemini-2.5-pro",label:"Gemini 2.5 Pro"},
  ]},
  { namespace: "ai", key: "daily_token_budget", label: "Napi token plafon", description: "Globális limit.", type: "number", default: 1_000_000, scope: "private" },
  { namespace: "ai", key: "system_prompt_chat", label: "Chat system prompt", description: "Globális rendszerszint.", type: "markdown", default: "Te egy segítőkész egészségügyi asszisztens vagy.", scope: "private", aiPrompt: "Írj egy felelősségteljes system promptot egészségügyi chat asszisztenshez" },

  // i18n
  { namespace: "i18n", key: "enabled_locales", label: "Engedélyezett nyelvek", description: "ISO kódok listája.", type: "string_list", default: ["hu","en"], scope: "public" },
  { namespace: "i18n", key: "auto_translate", label: "Auto-fordítás", description: "Hiányzó kulcsok AI fordítása.", type: "boolean", default: true, scope: "private" },

  // Privacy
  { namespace: "privacy", key: "retention_days_audit", label: "Audit megőrzés (nap)", description: "", type: "number", default: 365, scope: "private" },
  { namespace: "privacy", key: "retention_days_messages", label: "Üzenetek megőrzés (nap)", description: "", type: "number", default: 1825, scope: "private" },
  { namespace: "privacy", key: "consent_text_gdpr", label: "GDPR consent szöveg", description: "Markdown.", type: "markdown", default: "Beleegyezem az adatkezelésbe.", scope: "public" },

  // Feature flags
  { namespace: "feature_flags", key: "landing_dynamic", label: "Dinamikus landing", description: "Adatvezérelt kezdőoldal aktív.", type: "boolean", default: false, scope: "public" },
  { namespace: "feature_flags", key: "ai_setup_wizard", label: "AI Setup Wizard", description: "Aktiválja az admin AI varázslót.", type: "boolean", default: true, scope: "private" },
  { namespace: "feature_flags", key: "experimental_or_planner", label: "Experimental OR Planner", description: "", type: "boolean", default: false, scope: "private" },

  // Observability
  { namespace: "observability", key: "log_retention_days", label: "Hibanapló megőrzés (nap)", description: "", type: "number", default: 90, scope: "private" },
  { namespace: "observability", key: "log_level", label: "Log szint", description: "", type: "enum", default: "info", scope: "private", options: [
    {value:"debug",label:"debug"},{value:"info",label:"info"},{value:"warn",label:"warn"},{value:"error",label:"error"},
  ]},
];

export function getSettingDef(namespace: string, key: string): SettingDef | undefined {
  return SETTINGS.find((s) => s.namespace === namespace && s.key === key);
}

export function listByNamespace(namespace: string): SettingDef[] {
  return SETTINGS.filter((s) => s.namespace === namespace);
}

export function publicKeys(): { namespace: string; key: string }[] {
  return SETTINGS.filter((s) => s.scope === "public").map(({ namespace, key }) => ({ namespace, key }));
}
