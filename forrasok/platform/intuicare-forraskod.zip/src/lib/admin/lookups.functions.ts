/**
 * Admin segéd lookup-ok: páciens-keresés, monitoring program lista.
 * Csak `manage_patients` / `manage_tenant` jogosultsággal használható.
 */
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const searchPatientsForAdmin = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({ q: z.string().trim().max(80).default("") }).parse(d ?? {}),
  )
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const q = data.q.trim();
    let query = supabase
      .from("patients")
      .select("id, vezeteknev, keresztnev, taj, szuletesi_datum")
      .order("vezeteknev", { ascending: true })
      .limit(25);
    if (q.length >= 2) {
      // case-insensitive partial match on either name or TAJ
      query = query.or(
        `vezeteknev.ilike.%${q}%,keresztnev.ilike.%${q}%,taj.ilike.%${q}%`,
      );
    }
    const { data: rows, error } = await query;
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

export const listMonitoringPrograms = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("monitoring_programs")
      .select("id, tipus, aktiv, kezdes, varhato_veg")
      .order("kezdes", { ascending: false })
      .limit(200);
    if (error) throw new Error(error.message);
    return data ?? [];
  });
