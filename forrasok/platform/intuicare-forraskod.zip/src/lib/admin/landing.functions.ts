/**
 * Landing page blokk CRUD + publikálás.
 */
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { createClient } from "@supabase/supabase-js";

async function assertAdmin(ctx: { supabase: any; userId: string }) {
  const { data, error } = await ctx.supabase.rpc("has_role", { _user_id: ctx.userId, _role_kulcs: "tenant_admin" });
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Forbidden");
}

export const listAllBlocks = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    const { data, error } = await context.supabase
      .from("landing_page_blocks")
      .select("*").order("position", { ascending: true });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const getPublishedBlocks = createServerFn({ method: "GET" }).handler(async () => {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_PUBLISHABLE_KEY;
  if (!url || !key) return [];
  const sb = createClient(url, key, {
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
  });
  const { data, error } = await sb
    .from("landing_page_blocks")
    .select("id,block_type,position,locale,content,variant")
    .eq("is_published", true)
    .order("position", { ascending: true });
  if (error) return [];
  return data ?? [];
});

const BlockInput = z.object({
  id: z.string().optional(),
  block_type: z.string(),
  position: z.number().int(),
  locale: z.string().default("hu"),
  content: z.record(z.string(), z.unknown()),
  is_published: z.boolean().optional().default(false),
  variant: z.string().optional().default("default"),
});

export const saveBlock = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => BlockInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    if (data.id) {
      const { error } = await context.supabase
        .from("landing_page_blocks")
        .update({ ...data, updated_by: context.userId } as any)
        .eq("id", data.id);
      if (error) throw new Error(error.message);
      return { ok: true, id: data.id };
    }
    const { data: row, error } = await context.supabase
      .from("landing_page_blocks")
      .insert({ ...data, updated_by: context.userId } as any)
      .select("id").single();
    if (error) throw new Error(error.message);
    return { ok: true, id: (row as any).id as string };
  });

export const deleteBlock = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { error } = await context.supabase.from("landing_page_blocks").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const reorderBlocks = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ orders: z.array(z.object({ id: z.string(), position: z.number().int() })) }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    for (const o of data.orders) {
      await context.supabase.from("landing_page_blocks").update({ position: o.position }).eq("id", o.id);
    }
    return { ok: true };
  });

export const publishAllBlocks = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    // snapshot
    const { data: all } = await context.supabase.from("landing_page_blocks").select("*");
    await context.supabase.from("landing_page_versions").insert({
      label: `Publikálás ${new Date().toISOString()}`, snapshot: all ?? [], created_by: context.userId,
    });
    const { error } = await context.supabase
      .from("landing_page_blocks")
      .update({ is_published: true, updated_by: context.userId })
      .neq("id", "00000000-0000-0000-0000-000000000000");
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const bulkReplaceBlocks = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({
    blocks: z.array(z.object({
      block_type: z.string(),
      content: z.record(z.string(), z.unknown()),
    })),
    locale: z.string().optional().default("hu"),
  }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    // snapshot existing
    const { data: existing } = await context.supabase
      .from("landing_page_blocks").select("*").eq("locale", data.locale);
    await context.supabase.from("landing_page_versions").insert({
      label: `AI generálás előtt ${new Date().toISOString()}`, snapshot: existing ?? [], created_by: context.userId,
    });
    await context.supabase.from("landing_page_blocks").delete().eq("locale", data.locale);
    const rows = data.blocks.map((b, i) => ({
      block_type: b.block_type,
      position: i,
      locale: data.locale,
      content: b.content,
      is_published: false,
      updated_by: context.userId,
    }));
    const { error } = await context.supabase.from("landing_page_blocks").insert(rows as any);
    if (error) throw new Error(error.message);
    return { ok: true, inserted: rows.length };
  });
