import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type PortalPatient = {
  id: string;
  taj: string | null;
  nev: string;
  szuletesi_datum: string | null;
  nem: string | null;
  kapcsolat: string;
};

async function fetchMyPatients(): Promise<PortalPatient[]> {
  const { data: links, error } = await supabase
    .from("patient_users")
    .select("kapcsolat, patient_id, patients(id, taj, vezeteknev, keresztnev, szuletesi_datum, nem)")
    .order("created_at", { ascending: true });
  if (error) throw error;
  return ((links ?? []) as any[])
    .filter((l) => l.patients)
    .map((l) => ({
      id: l.patients.id,
      taj: l.patients.taj,
      nev: `${l.patients.vezeteknev ?? ""} ${l.patients.keresztnev ?? ""}`.trim(),
      szuletesi_datum: l.patients.szuletesi_datum,
      nem: l.patients.nem,
      kapcsolat: l.kapcsolat,
    }));
}

export function useMyPatients() {
  return useQuery({ queryKey: ["portal", "my-patients"], queryFn: fetchMyPatients });
}
