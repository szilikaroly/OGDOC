import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const Input = z.object({ patient_id: z.string().uuid() });

export type LifestyleCoachOutput = {
  summary: string;
  achievements: string[];
  focus_areas: { area: string; tip: string }[];
  weekly_goal: string;
};

/**
 * Életmód-coach: az utolsó 14 nap életmód-naplója + mérések alapján rövid
 * személyre szabott tanácsot ad. Cache 6 óra (in-memory N/A, mindig friss).
 */
export const lifestyleCoach = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => Input.parse(d))
  .handler(async ({ data, context }) => {
    const { userId } = context;
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: link } = await supabaseAdmin
      .from("patient_users").select("patient_id").eq("user_id", userId).eq("patient_id", data.patient_id).maybeSingle();
    if (!link) throw new Error("Nincs jogosultság.");

    const since = new Date(Date.now() - 14 * 86_400_000).toISOString();
    const [{ data: lifestyle }, { data: meresek }] = await Promise.all([
      supabaseAdmin.from("patient_lifestyle_log")
        .select("category, notes, value_json, logged_at")
        .eq("patient_id", data.patient_id).gte("logged_at", since).order("logged_at", { ascending: false }).limit(50),
      supabaseAdmin.from("measurements")
        .select("kind, value, value2, unit, ts")
        .eq("patient_id", data.patient_id).gte("ts", since).order("ts", { ascending: false }).limit(80),
    ]);

    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) throw new Error("AI gateway nincs konfigurálva.");

    if ((lifestyle?.length ?? 0) + (meresek?.length ?? 0) === 0) {
      return {
        summary: "Az elmúlt 2 hétben nem rögzítettél elég adatot a személyre szabott visszajelzéshez.",
        achievements: [],
        focus_areas: [{ area: "rögzítés", tip: "Próbálj naponta legalább egy bejegyzést készíteni (étkezés, mozgás vagy mérés)." }],
        weekly_goal: "Hozz létre 5 napi életmód-bejegyzést a következő héten.",
      } satisfies LifestyleCoachOutput;
    }

    const prompt = `Életmód-napló (utolsó 14 nap):\n${(lifestyle ?? []).map((l: any) =>
      `- [${new Date(l.logged_at).toLocaleDateString("hu-HU")}] ${l.category}: ${l.notes ?? "—"}`).join("\n") || "—"}\n
Mérések:\n${(meresek ?? []).map((m: any) =>
      `- [${new Date(m.ts).toLocaleDateString("hu-HU")}] ${m.kind}: ${m.value}${m.value2 ? "/" + m.value2 : ""} ${m.unit ?? ""}`).join("\n") || "—"}\n
Add vissza a megadott JSON formátumban.`;

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Lovable-API-Key": apiKey },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: SYSTEM },
          { role: "user", content: prompt },
        ],
        response_format: { type: "json_object" },
      }),
    });
    if (res.status === 429) throw new Error("AI túlterhelt.");
    if (res.status === 402) throw new Error("AI kredit elfogyott.");
    if (!res.ok) throw new Error(`AI hiba: ${res.status}`);
    const j = await res.json();
    const content = j.choices?.[0]?.message?.content ?? "{}";
    let parsed: any = {};
    try { parsed = JSON.parse(content); } catch { parsed = { summary: content }; }

    return {
      summary: String(parsed.summary ?? ""),
      achievements: Array.isArray(parsed.achievements) ? parsed.achievements : [],
      focus_areas: Array.isArray(parsed.focus_areas) ? parsed.focus_areas : [],
      weekly_goal: String(parsed.weekly_goal ?? ""),
    } satisfies LifestyleCoachOutput;
  });

const SYSTEM = `Magyar életmód-coach laikusoknak. Pozitív, motiváló, ÁLTALÁNOS tanácsok. SOHA ne adj gyógyszert / diagnózist. JSON kötelező:
{
  "summary": "2-3 mondat: mi jellemző az utóbbi 2 hétre",
  "achievements": ["pozitív minta 1", "pozitív minta 2"],
  "focus_areas": [{"area": "alvás|mozgás|étkezés|stressz|...", "tip": "1 konkrét, kis lépés"}],
  "weekly_goal": "1 mondat, mérhető heti cél"
}`;
