import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const StatusFilter = z.enum(["pending", "all"]).default("pending");

export const listAppointmentRequests = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ status: StatusFilter }).parse(d ?? {}))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    let q = supabase
      .from("patient_appointment_requests")
      .select(
        "id, patient_id, request_type, urgency, reason, preferred_datetime, status, staff_response, created_at, doctor_user_id, specialty_id, preferred_slot_id, appointment_id, resolved_at",
      )
      .order("created_at", { ascending: false })
      .limit(200);
    if (data.status === "pending") q = q.eq("status", "pending");
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    const patientIds = Array.from(new Set((rows ?? []).map((r) => r.patient_id).filter(Boolean)));
    let patients: Record<string, { nev: string; szuletesi_datum: string | null }> = {};
    if (patientIds.length) {
      const { data: ps } = await supabase
        .from("patients")
        .select("id, vezeteknev, keresztnev, szuletesi_datum")
        .in("id", patientIds);
      patients = Object.fromEntries(
        (ps ?? []).map((p: any) => [
          p.id,
          { nev: `${p.vezeteknev ?? ""} ${p.keresztnev ?? ""}`.trim() || "—", szuletesi_datum: p.szuletesi_datum },
        ]),
      );
    }
    return (rows ?? []).map((r: any) => ({ ...r, patient: patients[r.patient_id] ?? null }));
  });

export const listReferralRequests = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ status: StatusFilter }).parse(d ?? {}))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    let q = supabase
      .from("patient_referral_requests")
      .select(
        "id, patient_id, request_type, specialty, reason, notes, status, decision_note, created_at, decided_at, decided_by, pdf_url, eeszt_ref",
      )
      .order("created_at", { ascending: false })
      .limit(200);
    if (data.status === "pending") q = q.eq("status", "pending");
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    const patientIds = Array.from(new Set((rows ?? []).map((r) => r.patient_id).filter(Boolean)));
    let patients: Record<string, { nev: string; szuletesi_datum: string | null }> = {};
    if (patientIds.length) {
      const { data: ps } = await supabase
        .from("patients")
        .select("id, vezeteknev, keresztnev, szuletesi_datum")
        .in("id", patientIds);
      patients = Object.fromEntries(
        (ps ?? []).map((p: any) => [
          p.id,
          { nev: `${p.vezeteknev ?? ""} ${p.keresztnev ?? ""}`.trim() || "—", szuletesi_datum: p.szuletesi_datum },
        ]),
      );
    }
    return (rows ?? []).map((r: any) => ({ ...r, patient: patients[r.patient_id] ?? null }));
  });

const DecisionInput = z.object({
  id: z.string().uuid(),
  decision: z.enum(["approved", "rejected"]),
  staff_response: z.string().max(2000).optional(),
});

export const decideAppointmentRequest = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => DecisionInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: req, error: re } = await supabase
      .from("patient_appointment_requests")
      .update({
        status: data.decision,
        staff_response: data.staff_response ?? null,
        resolved_by: userId,
        resolved_at: new Date().toISOString(),
      })
      .eq("id", data.id)
      .select("user_id, patient_id, request_type")
      .maybeSingle();
    if (re) throw new Error(re.message);

    // notify patient
    if (req?.user_id) {
      await supabase.from("notifications").insert({
        user_id: req.user_id,
        tipus: data.decision === "approved" ? "success" : "warning",
        cim:
          data.decision === "approved"
            ? "Időpont-kérése elfogadva"
            : "Időpont-kérése elutasítva",
        uzenet: data.staff_response ?? null,
        link: "/portal/idopontok",
      });
    }
    return { ok: true };
  });

export const decideReferralRequest = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z
      .object({
        id: z.string().uuid(),
        decision: z.enum(["approved", "rejected"]),
        decision_note: z.string().max(2000).optional(),
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: req, error } = await supabase
      .from("patient_referral_requests")
      .update({
        status: data.decision,
        decision_note: data.decision_note ?? null,
        decided_by: userId,
        decided_at: new Date().toISOString(),
      })
      .eq("id", data.id)
      .select("patient_id")
      .maybeSingle();
    if (error) throw new Error(error.message);

    // try to notify the linked patient_user
    if (req?.patient_id) {
      const { data: link } = await supabase
        .from("patient_users")
        .select("user_id")
        .eq("patient_id", req.patient_id)
        .limit(1)
        .maybeSingle();
      if (link?.user_id) {
        await supabase.from("notifications").insert({
          user_id: link.user_id,
          tipus: data.decision === "approved" ? "success" : "warning",
          cim:
            data.decision === "approved"
              ? "Beutaló-kérése elfogadva"
              : "Beutaló-kérése elutasítva",
          uzenet: data.decision_note ?? null,
          link: "/portal/beutalok",
        });
      }
    }
    return { ok: true };
  });

export const getPatientRequestCounts = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase } = context;
    const [a, r] = await Promise.all([
      supabase
        .from("patient_appointment_requests")
        .select("id", { count: "exact", head: true })
        .eq("status", "pending"),
      supabase
        .from("patient_referral_requests")
        .select("id", { count: "exact", head: true })
        .eq("status", "pending"),
    ]);
    return { appointments: a.count ?? 0, referrals: r.count ?? 0 };
  });
