import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/**
 * Staff-facing SOS card reader for paciens-360.
 * Allowed by 'Staff olvashatja SOS kártyát' policy (view_patient_data).
 */
export const getStaffSosCard = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ patient_id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { data: card, error } = await supabase
      .from("patient_emergency_card")
      .select(
        "vercsoport, allergiak, kronikus_betegsegek, gyogyszerek, sos_kontakt_nev, sos_kontakt_telefon, egyeb_info, updated_at",
      )
      .eq("patient_id", data.patient_id)
      .maybeSingle();
    if (error) throw new Error(error.message);
    return card;
  });
