import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const SearchInput = z.object({
  q: z.string().max(100).optional(),
  specialty_id: z.string().uuid().optional(),
  site_id: z.string().uuid().optional(),
  only_available: z.boolean().optional(),
  sort: z.enum(["relevance", "name"]).default("relevance"),
  limit: z.number().int().min(1).max(50).default(20),
});

export type DoctorResult = {
  id: string;
  teljes_nev: string | null;
  bemutatkozas: string | null;
  avatar_url: string | null;
  foglalkozas_tipus: string | null;
  specialties: { id: string; nev: string; kod: string }[];
};

/**
 * Public doctor search for authenticated patients.
 * Returns only profiles with bemutatkozas_publikus=true AND aktiv=true.
 */
export const searchDoctors = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => SearchInput.parse(d))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    let q = supabaseAdmin
      .from("profiles")
      .select("id, teljes_nev, bemutatkozas, avatar_url, foglalkozas_tipus, tenant_id")
      .eq("aktiv", true)
      .eq("bemutatkozas_publikus", true)
      .limit(data.limit);

    if (data.q && data.q.trim()) {
      q = q.ilike("teljes_nev", `%${data.q.trim()}%`);
    }
    const { data: profs } = await q;
    if (!profs?.length) return [] as DoctorResult[];

    // join specialties via org_unit_specialties / profile_employment is complex;
    // for now we attach all specialties declared in their tenants' org_unit_specialties
    // limited to those that match the search filter.
    const profileIds = profs.map((p) => p.id);
    let specByProfile: Record<string, DoctorResult["specialties"]> = {};
    let siteByProfile: Record<string, Set<string>> = {};
    let orgUnitsByProfile: Record<string, Set<string>> = {};

    if (profileIds.length) {
      const { data: emp } = await supabaseAdmin
        .from("profile_employment")
        .select("user_id, org_unit_id")
        .in("user_id", profileIds);
      const orgIds = Array.from(new Set((emp ?? []).map((e: any) => e.org_unit_id).filter(Boolean)));

      // org_unit_id → site_id map
      let siteByOrgUnit: Record<string, string | null> = {};
      let specMap: Record<string, { id: string; nev: string; kod: string }[]> = {};
      if (orgIds.length) {
        const [{ data: ous }, { data: units }] = await Promise.all([
          supabaseAdmin
            .from("org_unit_specialties")
            .select("org_unit_id, specialty_id, specialties(id, nev, kod)")
            .in("org_unit_id", orgIds),
          supabaseAdmin.from("org_units").select("id, site_id").in("id", orgIds),
        ]);
        for (const r of (ous ?? []) as any[]) {
          if (!r.specialties) continue;
          (specMap[r.org_unit_id] ??= []).push(r.specialties);
        }
        for (const u of (units ?? []) as any[]) siteByOrgUnit[u.id] = u.site_id;
      }
      for (const e of (emp ?? []) as any[]) {
        const arr = specMap[e.org_unit_id] ?? [];
        (specByProfile[e.user_id] ??= []).push(...arr);
        (orgUnitsByProfile[e.user_id] ??= new Set()).add(e.org_unit_id);
        const sid = siteByOrgUnit[e.org_unit_id];
        if (sid) (siteByProfile[e.user_id] ??= new Set()).add(sid);
      }
      // dedupe + filter by specialty_id if requested
      for (const k of Object.keys(specByProfile)) {
        const seen = new Set<string>();
        specByProfile[k] = specByProfile[k].filter((s) => {
          if (seen.has(s.id)) return false;
          seen.add(s.id);
          return data.specialty_id ? s.id === data.specialty_id : true;
        });
      }
    }

    // Availability filter: doctors with at least one free slot in the next 14 days.
    let availableProfileIds: Set<string> | null = null;
    if (data.only_available) {
      const horizonEnd = new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString();
      const nowIso = new Date().toISOString();
      const { data: slots } = await supabaseAdmin
        .from("appointment_slots")
        .select("resource_id, kezdo_ts, kapacitas, foglalt_szam, status")
        .in("resource_id", profileIds)
        .gte("kezdo_ts", nowIso)
        .lte("kezdo_ts", horizonEnd)
        .eq("status", "szabad");
      availableProfileIds = new Set(
        (slots ?? [])
          .filter((s: any) => (s.kapacitas ?? 0) > (s.foglalt_szam ?? 0))
          .map((s: any) => s.resource_id),
      );
    }

    let results: DoctorResult[] = profs.map((p: any) => ({
      id: p.id,
      teljes_nev: p.teljes_nev,
      bemutatkozas: p.bemutatkozas,
      avatar_url: p.avatar_url,
      foglalkozas_tipus: p.foglalkozas_tipus,
      specialties: specByProfile[p.id] ?? [],
    }));

    if (data.specialty_id) results = results.filter((r) => r.specialties.length > 0);
    if (data.site_id) results = results.filter((r) => siteByProfile[r.id]?.has(data.site_id!));
    if (availableProfileIds) results = results.filter((r) => availableProfileIds!.has(r.id));

    if (data.sort === "name") {
      results.sort((a, b) => (a.teljes_nev ?? "").localeCompare(b.teljes_nev ?? "", "hu"));
    }
    return results;
  });

/** Authenticated patient: list active specialties for filter dropdown. */
export const listSpecialties = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async () => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data } = await supabaseAdmin
      .from("specialties")
      .select("id, nev, kod")
      .eq("aktiv", true)
      .order("nev");
    return data ?? [];
  });

/** Authenticated patient: list active sites (telephely) for filter dropdown. */
export const listSites = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async () => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data } = await supabaseAdmin
      .from("sites")
      .select("id, nev, cim")
      .eq("aktiv", true)
      .order("nev");
    return data ?? [];
  });
