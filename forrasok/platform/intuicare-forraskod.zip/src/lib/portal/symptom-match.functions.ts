import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { generateText, Output } from "ai";
import { createLovableAiGatewayProvider } from "@/lib/ai-gateway.server";

const Input = z.object({
  query: z.string().min(3).max(500),
});

export type SymptomMatchResult = {
  matches: {
    specialty_id: string;
    nev: string;
    kod: string;
    reason: string;
    keywords: string[];
  }[];
  urgency: "routine" | "soon" | "urgent" | "emergency";
  summary: string;
  disclaimer: string;
};

const SYSTEM = `Magyar nyelvű orvosi szakterület-ajánló asszisztens vagy egy klinikai rendszerben.
A beteg laikus megfogalmazással leírja a tüneteit, panaszait vagy érdeklődési körét.
A feladatod: a megadott specialty listából válaszd ki a legpontosabban illeszkedő 1-3 szakterületet.

Minden javaslathoz kötelezően add meg:
- reason: PONTOSAN EGY magyar mondat, konzisztens sablonnal: "A(z) <tünet(ek)> jellemzően a(z) <szakterület> hatáskörébe tartozik." (max 140 karakter, közérthető, orvosi zsargon nélkül, diagnózis nélkül).
- keywords: 1-4 rövid tünet-/panaszkulcsszó a beteg saját szövegéből idézve (pl. ["mellkasi fájdalom","nehézlégzés"]), amelyek alapján a szakterületet választottad. Csak olyan szavak, amelyek a beteg leírásában szerepelnek vagy annak nyilvánvaló szinonimái.

Sürgősség (urgency): routine (várhat), soon (1-2 hét), urgent (24-48 óra), emergency (azonnal 112 / sürgősségi).
Életveszélyes jelek (mellkasi szorító fájdalom + nehézlégzés, stroke-tünetek, súlyos vérzés, eszméletvesztés, anaphylaxia) esetén urgency=emergency és a summary hívja fel a figyelmet a 112-re.
Sose adj diagnózist vagy kezelési javaslatot. summary: 1-2 rövid magyar mondat.`;


export const matchSymptoms = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => Input.parse(d))
  .handler(async ({ data }): Promise<SymptomMatchResult> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: specs } = await supabaseAdmin
      .from("specialties")
      .select("id, nev, kod")
      .eq("aktiv", true)
      .order("nev");

    const list = (specs ?? []) as { id: string; nev: string; kod: string }[];
    if (!list.length) {
      return {
        matches: [],
        urgency: "routine",
        summary: "Nincsenek elérhető szakterületek a rendszerben.",
        disclaimer: "Ez az ajánlás nem helyettesíti az orvosi vizsgálatot.",
      };
    }

    const key = process.env.LOVABLE_API_KEY;
    if (!key) throw new Error("LOVABLE_API_KEY hiányzik");
    const gateway = createLovableAiGatewayProvider(key);

    const catalog = list.map((s) => `- ${s.kod} | ${s.nev}`).join("\n");
    const prompt = `Elérhető szakterületek (kód | név):\n${catalog}\n\nBeteg leírása:\n"""${data.query.trim()}"""\n\nVálaszd ki a legjobb 1-3 szakterületet a fenti listából (csakis kódot használj a listából).`;

    try {
      const { experimental_output: out } = await generateText({
        model: gateway("google/gemini-3-flash-preview"),
        system: SYSTEM,
        prompt,
        experimental_output: Output.object({
          schema: z.object({
            matches: z
              .array(
                z.object({
                  specialty_kod: z.string(),
                  reason: z.string(),
                  keywords: z.array(z.string()).min(1).max(4).optional(),
                }),
              )
              .min(1)
              .max(3),
            urgency: z.enum(["routine", "soon", "urgent", "emergency"]),
            summary: z.string(),
          }),
        }),
      });

      const byKod = new Map(list.map((s) => [s.kod.toLowerCase(), s] as const));
      const matches = (out.matches ?? [])
        .map((m) => {
          const sp = byKod.get(m.specialty_kod.toLowerCase());
          return sp
            ? {
                specialty_id: sp.id,
                nev: sp.nev,
                kod: sp.kod,
                reason: m.reason,
                keywords: (m.keywords ?? []).map((k) => k.trim()).filter(Boolean).slice(0, 4),
              }
            : null;
        })
        .filter((m): m is NonNullable<typeof m> => !!m);

      // ---- Feedback-based reranking ---------------------------------------
      // Aggregate community "Találat ez nekem" / "Nem találat" verdicts and
      // adjust the AI ranking so future queries benefit from prior signal.
      const { data: fb } = await supabaseAdmin
        .from("symptom_match_feedback")
        .select("specialty_id, verdict")
        .in(
          "specialty_id",
          [...matches.map((m) => m.specialty_id), ...list.map((s) => s.id)].slice(0, 500),
        );
      const scoreById = new Map<string, number>();
      for (const row of (fb ?? []) as { specialty_id: string; verdict: string }[]) {
        scoreById.set(
          row.specialty_id,
          (scoreById.get(row.specialty_id) ?? 0) + (row.verdict === "fit" ? 1 : -1),
        );
      }

      // 1) Reorder AI matches: relevance boost = -index (preserve AI order as tiebreaker) + score.
      const rescored = matches
        .map((m, idx) => ({ m, s: (scoreById.get(m.specialty_id) ?? 0) - idx * 0.5 }))
        .sort((a, b) => b.s - a.s)
        .map((x) => x.m);

      // 2) Drop suggestions with strongly negative community signal (≤ -3),
      //    but keep at least one.
      const filtered = rescored.filter(
        (m, i) => (scoreById.get(m.specialty_id) ?? 0) > -3 || i === 0,
      );

      return {
        matches: filtered,
        urgency: out.urgency,
        summary: out.summary,
        disclaimer:
          "Ez az ajánlás nem helyettesíti az orvosi vizsgálatot. Életveszély esetén hívja a 112-t.",
      };
    } catch (e: any) {
      const msg = String(e?.message ?? e);
      if (msg.includes("429")) throw new Error("Az AI szolgáltatás túlterhelt, próbáld újra rövidesen.");
      if (msg.includes("402")) throw new Error("Elfogytak a Lovable AI kreditek a workspace-en.");
      throw new Error(`AI hiba: ${msg}`);
    }
  });
