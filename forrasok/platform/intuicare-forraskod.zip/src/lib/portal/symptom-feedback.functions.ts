import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const Input = z.object({
  query: z.string().min(1).max(500),
  specialty_id: z.string().uuid(),
  verdict: z.enum(["fit", "miss"]),
  urgency: z.enum(["routine", "soon", "urgent", "emergency"]).optional(),
});

/**
 * Store patient feedback ("Találat ez nekem" / "Nem találat") about an AI
 * specialty suggestion. Aggregated later by `getSpecialtyFeedbackScores` to
 * reorder future AI suggestions.
 */
export const submitSymptomFeedback = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => Input.parse(d))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("symptom_match_feedback").insert({
      user_id: context.userId,
      query: data.query.slice(0, 500),
      specialty_id: data.specialty_id,
      verdict: data.verdict,
      urgency: data.urgency ?? null,
    });
    if (error) throw new Error(error.message);
    return { ok: true as const };
  });
