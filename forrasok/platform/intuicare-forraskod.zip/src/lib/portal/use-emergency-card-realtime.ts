import { useEffect, useRef, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import type { RealtimeChannel } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

export type RealtimeStatus =
  | "idle"
  | "connecting"
  | "subscribed"
  | "error"
  | "reconnecting"
  | "closed";

export type EmergencyCardRealtime = {
  status: RealtimeStatus;
  lastEventAt: Date | null;
  lastError: string | null;
  attempts: number;
};

/**
 * Subscribe to live changes on a patient's emergency card row.
 * Handles reconnects with exponential backoff and exposes connection state.
 * Invalidates every query key used across the portal SOS page, the portal
 * profile "Egészségügyi adatok" tab and the staff SOS panel.
 */
export function useEmergencyCardRealtime(patientId?: string | null): EmergencyCardRealtime {
  const qc = useQueryClient();
  const [status, setStatus] = useState<RealtimeStatus>("idle");
  const [lastEventAt, setLastEventAt] = useState<Date | null>(null);
  const [lastError, setLastError] = useState<string | null>(null);
  const [attempts, setAttempts] = useState(0);
  const attemptsRef = useRef(0);

  useEffect(() => {
    if (!patientId) {
      setStatus("idle");
      return;
    }
    let cancelled = false;
    let channel: RealtimeChannel | null = null;
    let retryTimer: ReturnType<typeof setTimeout> | null = null;

    const invalidate = () => {
      qc.invalidateQueries({ queryKey: ["portal", "sos", patientId] });
      qc.invalidateQueries({ queryKey: ["portal", "emergency-card", patientId] });
      qc.invalidateQueries({ queryKey: ["staff-sos-card", patientId] });
    };

    const scheduleReconnect = () => {
      if (cancelled) return;
      attemptsRef.current += 1;
      setAttempts(attemptsRef.current);
      const delay = Math.min(30_000, 1_000 * 2 ** Math.min(attemptsRef.current, 5));
      setStatus("reconnecting");
      retryTimer = setTimeout(() => {
        if (cancelled) return;
        if (channel) {
          supabase.removeChannel(channel);
          channel = null;
        }
        connect();
      }, delay);
    };

    const connect = () => {
      if (cancelled) return;
      setStatus(attemptsRef.current === 0 ? "connecting" : "reconnecting");
      channel = supabase
        .channel(`emergency-card:${patientId}:${Date.now()}`)
        .on(
          "postgres_changes",
          {
            event: "*",
            schema: "public",
            table: "patient_emergency_card",
            filter: `patient_id=eq.${patientId}`,
          },
          () => {
            setLastEventAt(new Date());
            invalidate();
          },
        )
        .subscribe((s, err) => {
          if (cancelled) return;
          if (s === "SUBSCRIBED") {
            attemptsRef.current = 0;
            setAttempts(0);
            setLastError(null);
            setStatus("subscribed");
            // catch any change that landed during the gap
            invalidate();
          } else if (s === "CHANNEL_ERROR" || s === "TIMED_OUT") {
            setLastError(err?.message ?? s);
            setStatus("error");
            scheduleReconnect();
          } else if (s === "CLOSED") {
            setStatus("closed");
          }
        });
    };

    connect();

    const onOnline = () => {
      if (status === "error" || status === "closed" || status === "reconnecting") {
        attemptsRef.current = 0;
        if (retryTimer) clearTimeout(retryTimer);
        if (channel) supabase.removeChannel(channel);
        connect();
      }
    };
    if (typeof window !== "undefined") window.addEventListener("online", onOnline);

    return () => {
      cancelled = true;
      if (retryTimer) clearTimeout(retryTimer);
      if (channel) supabase.removeChannel(channel);
      if (typeof window !== "undefined") window.removeEventListener("online", onOnline);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [patientId]);

  return { status, lastEventAt, lastError, attempts };
}
