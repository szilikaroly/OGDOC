import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const Input = z.object({
  patient_id: z.string().uuid(),
  observation_ids: z.array(z.string().uuid()).min(1).max(40),
  language: z.string().default("hu"),
});

export type LabExplanation = {
  summary: string;
  per_test: { code_display: string; status: "ok" | "watch" | "high" | "low"; layman: string }[];
  next_steps: string[];
  critical: boolean;
  suggested_specialty: { id: string; nev: string } | null;
};

/**
 * AI-magyarázat lab leletekhez. Lovable AI Gateway (gemini-3-flash).
 * - cache: patient_ai_explanations (24h)
 * - critical=true esetén szakterületet javasol
 */
export const explainLabResults = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => Input.parse(d))
  .handler(async ({ data, context }) => {
    const { userId } = context;
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // verify access
    const { data: link } = await supabaseAdmin
      .from("patient_users").select("patient_id")
      .eq("user_id", userId).eq("patient_id", data.patient_id).maybeSingle();
    if (!link) throw new Error("Nincs jogosultság.");

    const idsKey = [...data.observation_ids].sort().join(",");
    const promptHash = await sha1(`v1|${data.language}|${idsKey}`);

    // cache hit
    const { data: cached } = await supabaseAdmin
      .from("patient_ai_explanations")
      .select("explanation, critical_flags, suggested_specialty_id, expires_at")
      .eq("patient_id", data.patient_id)
      .eq("source_table", "clinical_observations")
      .eq("prompt_hash", promptHash)
      .gt("expires_at", new Date().toISOString())
      .maybeSingle();
    if (cached?.explanation) {
      const sp = cached.suggested_specialty_id
        ? (await supabaseAdmin.from("specialties").select("id, nev").eq("id", cached.suggested_specialty_id).maybeSingle()).data
        : null;
      return { ...(cached.explanation as any), suggested_specialty: sp } as LabExplanation;
    }

    // fetch observations — restrict to the verified patient to prevent IDOR.
    const { data: obs } = await supabaseAdmin
      .from("clinical_observations")
      .select("id, code_display, loinc_code, value_quantity, value_unit, value_string, interpretation, reference_range_low, reference_range_high, effective_ts")
      .in("id", data.observation_ids)
      .eq("patient_id", data.patient_id);

    if (!obs?.length) throw new Error("Nincsenek lekért leletek.");
    if (obs.length !== data.observation_ids.length) {
      throw new Error("Nincs jogosultság a kért lelet(ek)hez.");
    }

    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) throw new Error("AI gateway nincs konfigurálva.");

    const prompt = buildPrompt(obs as any[], data.language);
    const aiRes = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Lovable-API-Key": apiKey,
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user", content: prompt },
        ],
        response_format: { type: "json_object" },
      }),
    });

    if (aiRes.status === 429) throw new Error("AI túlterhelt, próbáld újra hamarosan.");
    if (aiRes.status === 402) throw new Error("AI kredit elfogyott. Kérjük, töltsd fel.");
    if (!aiRes.ok) throw new Error(`AI hiba: ${aiRes.status}`);

    const j = await aiRes.json();
    const content = j.choices?.[0]?.message?.content ?? "{}";
    let parsed: any = {};
    try { parsed = JSON.parse(content); } catch { parsed = { summary: content, per_test: [], next_steps: [], critical: false }; }

    // suggest specialty by keyword if critical
    let suggested_specialty: { id: string; nev: string } | null = null;
    if (parsed.critical && parsed.suggested_specialty_keyword) {
      const { data: sp } = await supabaseAdmin
        .from("specialties").select("id, nev")
        .ilike("nev", `%${parsed.suggested_specialty_keyword}%`).limit(1).maybeSingle();
      if (sp) suggested_specialty = sp as any;
    }

    const out: LabExplanation = {
      summary: String(parsed.summary ?? ""),
      per_test: Array.isArray(parsed.per_test) ? parsed.per_test : [],
      next_steps: Array.isArray(parsed.next_steps) ? parsed.next_steps : [],
      critical: !!parsed.critical,
      suggested_specialty,
    };

    await supabaseAdmin.from("patient_ai_explanations").insert({
      patient_id: data.patient_id,
      source_table: "clinical_observations",
      source_id: (obs as any[])[0].id,
      language: data.language,
      model: "google/gemini-2.5-flash",
      prompt_hash: promptHash,
      explanation: out,
      critical_flags: out.critical ? { keyword: parsed.suggested_specialty_keyword ?? null } : null,
      suggested_specialty_id: suggested_specialty?.id ?? null,
      expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
    });

    return out;
  });

const SYSTEM_PROMPT = `Magyar nyelvű egészségügyi laikus magyarázat. JSON formátum kötelező:
{
  "summary": "2-3 mondatos összefoglaló laikusnak (NEM diagnózis)",
  "per_test": [{ "code_display": "...", "status": "ok|watch|high|low", "layman": "1 mondat" }],
  "next_steps": ["javasolt lépés 1", "javasolt lépés 2"],
  "critical": true|false,
  "suggested_specialty_keyword": "pl. kardiológia | endokrinológia | nefrológia | hematológia"
}
Soha ne adj diagnózist. Soha ne írj gyógyszer-adagolást. Ha bármely érték kritikusan eltér a normális tartománytól, "critical": true és javasolj szakterületet. Mindig zárd a következővel: "Ez nem orvosi diagnózis – kérdéseiddel fordulj orvosodhoz."`;

function buildPrompt(obs: any[], lang: string) {
  const lines = obs.map((o) =>
    `- ${o.code_display}${o.loinc_code ? ` (LOINC ${o.loinc_code})` : ""}: ${o.value_quantity ?? o.value_string ?? "—"} ${o.value_unit ?? ""} ` +
    `[ref: ${o.reference_range_low ?? "?"}–${o.reference_range_high ?? "?"}] ` +
    `[int: ${o.interpretation ?? "—"}] (${new Date(o.effective_ts).toLocaleDateString("hu-HU")})`
  ).join("\n");
  return `Nyelv: ${lang}\n\nLab leletek:\n${lines}\n\nKérlek elemezd és add vissza a megadott JSON formátumban.`;
}

async function sha1(s: string): Promise<string> {
  const buf = new TextEncoder().encode(s);
  const hash = await crypto.subtle.digest("SHA-1", buf);
  return Array.from(new Uint8Array(hash)).map((b) => b.toString(16).padStart(2, "0")).join("");
}
