import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const TAJ_RE = /^\d{9}$/;

const LinkInput = z.object({
  taj: z.string().regex(TAJ_RE, "TAJ-szám 9 számjegy kell legyen"),
  szuletesi_datum: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Születési dátum formátum: ÉÉÉÉ-HH-NN"),
  kapcsolat: z.enum(["self", "szulo", "gyermek", "hazastars", "gondnok", "egyeb"]).default("self"),
});

/**
 * Securely link a patient record to the current auth user.
 * - Validates TAJ format (9 digits) + birth date match against the patient row
 * - Rate-limits: max 5 attempts / 10 minutes / user
 * - Writes an audit log entry on every attempt (success or failure)
 * - Prevents duplicate links
 */
export const linkPatientByTaj = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => LinkInput.parse(data))
  .handler(async ({ data, context }) => {
    const { userId } = context;
    const { taj, szuletesi_datum, kapcsolat } = data;
    // Admin client: client-side INSERT on patient_users is now blocked by RLS;
    // this server fn is the only path. Auth is already enforced by middleware,
    // and every branch writes to admin_audit_log.
    const { supabaseAdmin: supabase } = await import("@/integrations/supabase/client.server");

    // --- rate limit: count recent attempts in admin_audit_log ---
    const tenMinAgo = new Date(Date.now() - 10 * 60 * 1000).toISOString();
    const { count: recent } = await supabase
      .from("admin_audit_log")
      .select("id", { count: "exact", head: true })
      .eq("user_id", userId)
      .eq("action", "patient_link_attempt")
      .gte("created_at", tenMinAgo);

    if ((recent ?? 0) >= 5) {
      await supabase.from("admin_audit_log").insert({
        user_id: userId,
        action: "patient_link_attempt",
        table_name: "patient_users",
        summary: "rate_limited",
        reason: `>5 attempts in 10 min`,
      });
      throw new Error("Túl sok próbálkozás. Kérjük, próbálja újra 10 perc múlva.");
    }

    // --- look up patient strictly by TAJ + birth date ---
    const { data: pt, error: e1 } = await supabase
      .from("patients")
      .select("id, tenant_id, szuletesi_datum")
      .eq("taj", taj)
      .eq("szuletesi_datum", szuletesi_datum)
      .maybeSingle();

    if (e1) {
      await supabase.from("admin_audit_log").insert({
        user_id: userId,
        action: "patient_link_attempt",
        table_name: "patient_users",
        summary: "lookup_error",
        reason: e1.message,
      });
      throw new Error("Hiba a páciens keresése közben.");
    }

    if (!pt) {
      await supabase.from("admin_audit_log").insert({
        user_id: userId,
        action: "patient_link_attempt",
        table_name: "patient_users",
        summary: "no_match",
        reason: "TAJ + birth date nem egyezik",
      });
      throw new Error("Nem található páciens a megadott TAJ-számmal és születési dátummal.");
    }

    // --- duplicate guard ---
    const { data: existing } = await supabase
      .from("patient_users")
      .select("id")
      .eq("user_id", userId)
      .eq("patient_id", pt.id)
      .maybeSingle();

    if (existing) {
      await supabase.from("admin_audit_log").insert({
        user_id: userId,
        tenant_id: pt.tenant_id,
        action: "patient_link_attempt",
        table_name: "patient_users",
        record_id: pt.id,
        summary: "already_linked",
      });
      throw new Error("Ez a páciens rekord már össze van kapcsolva.");
    }

    // --- insert link ---
    const { data: inserted, error: e2 } = await supabase
      .from("patient_users")
      .insert({
        user_id: userId,
        patient_id: pt.id,
        tenant_id: pt.tenant_id,
        kapcsolat,
        verified_at: new Date().toISOString(),
      })
      .select("id")
      .single();

    if (e2) {
      await supabase.from("admin_audit_log").insert({
        user_id: userId,
        tenant_id: pt.tenant_id,
        action: "patient_link_attempt",
        table_name: "patient_users",
        record_id: pt.id,
        summary: "insert_failed",
        reason: e2.message,
      });
      throw new Error("Nem sikerült a kapcsolás: " + e2.message);
    }

    await supabase.from("admin_audit_log").insert({
      user_id: userId,
      tenant_id: pt.tenant_id,
      action: "patient_link_success",
      table_name: "patient_users",
      record_id: inserted.id,
      summary: `Linked patient (${kapcsolat})`,
    });

    return { ok: true as const, patient_id: pt.id };
  });
