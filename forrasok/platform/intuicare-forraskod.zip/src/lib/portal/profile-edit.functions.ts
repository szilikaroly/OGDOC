/**
 * Páciens profil / egészségügyi adatok szerkesztése a portálról.
 * - Csak az adott felhasználóhoz kapcsolt patient_id-kre engedélyezett (patient_users link).
 * - Csak biztonságos, nem-klinikai oszlopokat ír (kontakt + emergency card).
 * - Klinikai mezők (taj, fo_diagnozis, gondozo_orvos) NEM szerkeszthetők innen.
 */
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const ContactInput = z.object({
  patient_id: z.string().uuid(),
  telefon: z.string().max(40).nullable().optional(),
  email: z.string().email().max(255).nullable().or(z.literal("")).optional(),
  iranyitoszam: z.string().max(20).nullable().optional(),
  varos: z.string().max(120).nullable().optional(),
  cim: z.string().max(255).nullable().optional(),
  anyja_neve: z.string().max(255).nullable().optional(),
});

export const updatePatientContact = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => ContactInput.parse(d))
  .handler(async ({ data, context }) => {
    const { userId, supabase } = context;
    // verify link
    const { data: link } = await supabase
      .from("patient_users")
      .select("patient_id")
      .eq("user_id", userId)
      .eq("patient_id", data.patient_id)
      .maybeSingle();
    if (!link) throw new Error("Nincs jogosultság ehhez a páciens rekordhoz.");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const patch = {
      telefon: data.telefon ?? null,
      email: data.email === "" ? null : data.email ?? null,
      iranyitoszam: data.iranyitoszam ?? null,
      varos: data.varos ?? null,
      cim: data.cim ?? null,
      ...(data.anyja_neve !== undefined ? { anyja_neve: data.anyja_neve } : {}),
    };
    const { error } = await supabaseAdmin.from("patients").update(patch as any).eq("id", data.patient_id);
    if (error) throw new Error(error.message);
    return { ok: true as const };
  });

const EmergencyInput = z.object({
  patient_id: z.string().uuid(),
  vercsoport: z.string().max(10).nullable().optional(),
  allergiak: z.array(z.string().max(120)).max(50).optional(),
  kronikus_betegsegek: z.array(z.string().max(200)).max(50).optional(),
  gyogyszerek: z.array(z.string().max(200)).max(80).optional(),
  gyogyszer_erzekenyseg: z.array(z.string().max(200)).max(50).optional(),
  etrend: z.string().max(1000).nullable().optional(),
  sos_kontakt_nev: z.string().max(200).nullable().optional(),
  sos_kontakt_telefon: z.string().max(40).nullable().optional(),
  kapcsolt_orvos_telefon: z.string().max(40).nullable().optional(),
  egyeb_info: z.string().max(2000).nullable().optional(),
});

export const upsertEmergencyCard = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => EmergencyInput.parse(d))
  .handler(async ({ data, context }) => {
    const { userId, supabase } = context;
    const { data: link } = await supabase
      .from("patient_users")
      .select("patient_id")
      .eq("user_id", userId)
      .eq("patient_id", data.patient_id)
      .maybeSingle();
    if (!link) throw new Error("Nincs jogosultság ehhez a páciens rekordhoz.");

    const { error } = await supabase.from("patient_emergency_card").upsert(
      {
        patient_id: data.patient_id,
        vercsoport: data.vercsoport ?? null,
        allergiak: data.allergiak ?? [],
        kronikus_betegsegek: data.kronikus_betegsegek ?? [],
        gyogyszerek: data.gyogyszerek ?? [],
        gyogyszer_erzekenyseg: data.gyogyszer_erzekenyseg ?? [],
        etrend: data.etrend ?? null,
        sos_kontakt_nev: data.sos_kontakt_nev ?? null,
        sos_kontakt_telefon: data.sos_kontakt_telefon ?? null,
        kapcsolt_orvos_telefon: data.kapcsolt_orvos_telefon ?? null,
        egyeb_info: data.egyeb_info ?? null,
      } as any,
      { onConflict: "patient_id" },
    );
    if (error) throw new Error(error.message);
    return { ok: true as const };
  });

const UnlinkInput = z.object({ patient_id: z.string().uuid() });

export const unlinkPatient = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => UnlinkInput.parse(d))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("patient_users")
      .delete()
      .eq("user_id", context.userId)
      .eq("patient_id", data.patient_id);
    if (error) throw new Error(error.message);
    return { ok: true as const };
  });
