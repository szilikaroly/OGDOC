import type { UserClassification } from "./user-classification.functions";

export type RoleTarget = "/admin/szervezet" | "/iranyitopult" | "/portal" | "/";

/**
 * Egységes szerepkör → célútvonal döntés. Használja a `/`, `/auth` beforeLoad
 * és a sikeres bejelentkezés utáni navigáció is, így mindenki ugyanoda kerül.
 */
export function targetForClassification(cls: UserClassification | null | undefined): RoleTarget {
  if (!cls) return "/";
  if (cls.isAdmin) return "/admin/szervezet";
  if (cls.isStaff) return "/iranyitopult";
  if (cls.isPatient) return "/portal";
  return "/";
}
