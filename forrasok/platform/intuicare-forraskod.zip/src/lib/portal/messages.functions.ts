import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const StartInput = z.object({
  patient_id: z.string().uuid(),
  body: z.string().min(1).max(2000),
});

/**
 * Páciens új üzenet-szálat indít a gondozó orvosának.
 * Létrehozza a conversations + conversation_participants (páciens + orvos) sorokat,
 * majd elküldi az első üzenetet a páciens nevében.
 */
export const startConversationWithDoctor = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => StartInput.parse(d))
  .handler(async ({ data, context }) => {
    const { userId } = context;
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // 1) verify patient belongs to user
    const { data: link } = await supabaseAdmin
      .from("patient_users")
      .select("patient_id, tenant_id")
      .eq("user_id", userId)
      .eq("patient_id", data.patient_id)
      .maybeSingle();
    if (!link) throw new Error("Nincs jogosultság ehhez a pácienshez.");

    // 2) get patient + doctor
    const { data: pt } = await supabaseAdmin
      .from("patients")
      .select("id, tenant_id, gondozo_orvos_id, vezeteknev, keresztnev")
      .eq("id", data.patient_id)
      .maybeSingle();
    if (!pt) throw new Error("Páciens nem található.");
    if (!pt.gondozo_orvos_id) {
      throw new Error("Nincs hozzárendelt gondozó orvos. Kérjük, először keress orvost.");
    }

    // 3) create conversation
    const { data: conv, error: ec } = await supabaseAdmin
      .from("conversations")
      .insert({
        tenant_id: pt.tenant_id,
        kind: "patient_provider",
        title: `${pt.vezeteknev} ${pt.keresztnev}`.trim(),
        patient_id: pt.id,
        created_by: userId,
        last_message_at: new Date().toISOString(),
      })
      .select("id")
      .single();
    if (ec || !conv) throw new Error(ec?.message ?? "Beszélgetés létrehozása sikertelen.");

    // 4) participants: patient (this user) + doctor
    const { error: ep } = await supabaseAdmin.from("conversation_participants").insert([
      { conversation_id: conv.id, user_id: userId, patient_id: pt.id, role: "patient", auto_translate: false, muted: false },
      { conversation_id: conv.id, user_id: pt.gondozo_orvos_id, role: "provider", auto_translate: false, muted: false },
    ]);
    if (ep) throw new Error(ep.message);

    // 5) first message
    const { error: em } = await supabaseAdmin.from("messages").insert({
      conversation_id: conv.id,
      sender_user_id: userId,
      sender_patient_id: pt.id,
      sender_kind: "patient",
      body: data.body,
    });
    if (em) throw new Error(em.message);

    return { conversation_id: conv.id };
  });
