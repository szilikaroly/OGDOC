import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export type UserClassification = {
  isStaff: boolean;
  isPatient: boolean;
  isAdmin: boolean;
  isDoctor: boolean;
  patientCount: number;
  tenantCount: number;
};

/**
 * Classify the current user: do they have any staff role (user_roles row)
 * and/or any linked patient record (patient_users row). Also extracts
 * whether the staff member is an admin (tenant_admin / igazgato /
 * intezetvezeto) or a doctor (foorvos / szakorvos / rezidens / ...).
 */
export const classifyUser = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;

    const [rolesRes, patientRes] = await Promise.all([
      supabase
        .from("user_roles")
        .select("role_id, roles:role_id(kulcs)")
        .eq("user_id", userId),
      supabase
        .from("patient_users")
        .select("id", { count: "exact", head: true })
        .eq("user_id", userId),
    ]);

    const roleKeys = (rolesRes.data ?? [])
      .map((r: any) => r.roles?.kulcs as string | undefined)
      .filter(Boolean) as string[];

    const ADMIN_KEYS = new Set([
      "tenant_admin",
      "igazgato",
      "intezetvezeto",
      "telephelyvezeto",
    ]);
    const DOCTOR_KEYS = new Set([
      "foorvos",
      "szakorvos",
      "rezidens",
      "vezetorezidens",
      "szakgyakornok",
      "orvos",
    ]);

    const isAdmin = roleKeys.some((k) => ADMIN_KEYS.has(k));
    const isDoctor = roleKeys.some((k) => DOCTOR_KEYS.has(k));

    const result: UserClassification = {
      isStaff: roleKeys.length > 0,
      isPatient: (patientRes.count ?? 0) > 0,
      isAdmin,
      isDoctor,
      patientCount: patientRes.count ?? 0,
      tenantCount: roleKeys.length,
    };
    return result;
  });
