import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const exportMyData = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const out: any = {
      exported_at: new Date().toISOString(),
      user_id: userId,
    };

    const [{ data: profile }, { data: links }] = await Promise.all([
      supabase.from("profiles").select("*").eq("id", userId).maybeSingle(),
      supabase.from("patient_users").select("*").eq("user_id", userId),
    ]);
    out.profile = profile;
    out.patient_links = links ?? [];

    const patientIds = (links ?? []).map((l: any) => l.patient_id);
    if (patientIds.length > 0) {
      const [
        { data: patients },
        { data: appts },
        { data: meas },
        { data: obs },
        { data: assigns },
        { data: responses },
        { data: lifestyle },
        { data: referrals },
      ] = await Promise.all([
        supabase.from("patients").select("*").in("id", patientIds),
        supabase.from("appointments").select("*").in("patient_id", patientIds),
        supabase.from("measurements").select("*").in("patient_id", patientIds),
        supabase.from("clinical_observations").select("*").in("patient_id", patientIds),
        supabase.from("questionnaire_assignments").select("*").in("patient_id", patientIds),
        supabase.from("questionnaire_responses").select("*").in("patient_id", patientIds),
        supabase.from("patient_lifestyle_log").select("*").in("patient_id", patientIds),
        supabase.from("patient_referral_requests" as never).select("*").in("patient_id", patientIds),
      ]);
      out.patients = patients ?? [];
      out.appointments = appts ?? [];
      out.measurements = meas ?? [];
      out.observations = obs ?? [];
      out.questionnaire_assignments = assigns ?? [];
      out.questionnaire_responses = responses ?? [];
      out.lifestyle_log = lifestyle ?? [];
      out.referral_requests = referrals ?? [];
    }

    return out;
  });
