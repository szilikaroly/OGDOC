import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const TokenInput = z.object({ token: z.string().min(16).max(128) });
const PatientInput = z.object({ patient_id: z.string().uuid() });

/**
 * PUBLIC (no auth): fetches a patient's emergency card by qr_token.
 * Returns minimal, safe fields for first responders.
 */
export const getSosCardByToken = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) => TokenInput.parse(d))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: card } = await supabaseAdmin
      .from("patient_emergency_card")
      .select(
        "vercsoport, allergiak, kronikus_betegsegek, gyogyszerek, sos_kontakt_nev, sos_kontakt_telefon, egyeb_info, patient_id, updated_at",
      )
      .eq("qr_token", data.token)
      .maybeSingle();
    if (!card) return null;
    const { data: pt } = await supabaseAdmin
      .from("patients")
      .select("vezeteknev, keresztnev, szuletesi_datum, nem")
      .eq("id", (card as any).patient_id)
      .maybeSingle();
    return {
      ...card,
      patient: pt
        ? { nev: `${pt.vezeteknev ?? ""} ${pt.keresztnev ?? ""}`.trim(), szuletesi_datum: pt.szuletesi_datum, nem: pt.nem }
        : null,
    };
  });

/**
 * Authenticated: ensures the patient has a qr_token (creates one if missing) and returns it.
 * Only callable by a user linked to that patient (RLS-enforced).
 */
export const ensureSosToken = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => PatientInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { data: existing } = await supabase
      .from("patient_emergency_card")
      .select("qr_token")
      .eq("patient_id", data.patient_id)
      .maybeSingle();
    if (existing?.qr_token) return { token: existing.qr_token };

    const token = crypto.randomUUID().replace(/-/g, "") + crypto.randomUUID().replace(/-/g, "").slice(0, 8);
    const { error } = await supabase
      .from("patient_emergency_card")
      .upsert({ patient_id: data.patient_id, qr_token: token }, { onConflict: "patient_id" });
    if (error) throw new Error(error.message);
    return { token };
  });

/**
 * Authenticated: regenerates the token (invalidates previous QR codes).
 */
export const regenerateSosToken = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => PatientInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const token = crypto.randomUUID().replace(/-/g, "") + crypto.randomUUID().replace(/-/g, "").slice(0, 8);
    const { error } = await supabase
      .from("patient_emergency_card")
      .upsert({ patient_id: data.patient_id, qr_token: token }, { onConflict: "patient_id" });
    if (error) throw new Error(error.message);
    return { token };
  });
