import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const GATEWAY = "https://ai.gateway.lovable.dev/v1/chat/completions";
const MODEL = "google/gemini-2.5-flash";

async function aiCall(body: unknown): Promise<any> {
  const apiKey = process.env.LOVABLE_API_KEY;
  if (!apiKey) throw new Error("LOVABLE_API_KEY missing");
  const res = await fetch(GATEWAY, {
    method: "POST",
    headers: { "content-type": "application/json", authorization: `Bearer ${apiKey}` },
    body: JSON.stringify(body),
  });
  if (res.status === 429) throw new Error("AI rate limit — próbálja kicsit később.");
  if (res.status === 402) throw new Error("AI keret elfogyott. Töltse fel a Lovable workspace egyenleget.");
  if (!res.ok) throw new Error(`AI hiba: ${res.status} ${(await res.text()).slice(0, 200)}`);
  return res.json();
}

export type ParsedDemand = {
  days: number;
  shifts: Array<{
    kulcs: "nappal" | "ugyelet" | "keszenlet";
    kezd: string;
    veg: string;
    kategoria: "rendes" | "ugyelet" | "keszenlet";
    fo: number;
  }>;
  magyarazat: string;
};

export const parseDemandFromText = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { text: string }) => {
    if (!input?.text || input.text.length > 2000) throw new Error("text invalid");
    return { text: input.text };
  })
  .handler(async ({ data }): Promise<ParsedDemand> => {
    const json = await aiCall({
      model: MODEL,
      messages: [
        {
          role: "system",
          content: `Magyar nyelvű orvosi beosztó-rendszer igényértelmezője vagy. A felhasználó leírja, milyen műszakokat szeretne — alakítsd át strukturált sablonná. Mindig HH:MM formátumot adj, és csak a megadott enum-értékeket használd.`,
        },
        { role: "user", content: data.text },
      ],
      tools: [
        {
          type: "function",
          function: {
            name: "parse_demand",
            description: "Strukturált beosztás-igény visszaadása",
            parameters: {
              type: "object",
              additionalProperties: false,
              properties: {
                days: { type: "integer", minimum: 1, maximum: 31 },
                shifts: {
                  type: "array",
                  items: {
                    type: "object",
                    additionalProperties: false,
                    properties: {
                      kulcs: { type: "string", enum: ["nappal", "ugyelet", "keszenlet"] },
                      kezd: { type: "string" },
                      veg: { type: "string" },
                      kategoria: { type: "string", enum: ["rendes", "ugyelet", "keszenlet"] },
                      fo: { type: "integer", minimum: 1 },
                    },
                    required: ["kulcs", "kezd", "veg", "kategoria", "fo"],
                  },
                },
                magyarazat: { type: "string" },
              },
              required: ["days", "shifts", "magyarazat"],
            },
          },
        },
      ],
      tool_choice: { type: "function", function: { name: "parse_demand" } },
    });
    const call = json?.choices?.[0]?.message?.tool_calls?.[0];
    if (!call) throw new Error("AI nem adott vissza struktúrát");
    return JSON.parse(call.function.arguments) as ParsedDemand;
  });

export const summarizeSchedule = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { monthLabel: string; perPerson: Array<{ nev: string; rendes: number; ugyelet: number; keszenlet: number }> }) => {
    if (!input?.monthLabel) throw new Error("monthLabel required");
    return input;
  })
  .handler(async ({ data }): Promise<{ summary: string }> => {
    const json = await aiCall({
      model: MODEL,
      messages: [
        { role: "system", content: "Magyar nyelvű, tárgyilagos havi beosztás-összefoglalót írsz a vezetőnek. Max 4 mondat. Emeld ki az egyenlőtlenségeket és a leginkább leterhelt embereket." },
        { role: "user", content: `Hónap: ${data.monthLabel}\nMunkatársak összóra/kategória:\n${data.perPerson.map((p) => `- ${p.nev}: rendes=${p.rendes}h, ügyelet=${p.ugyelet}h, készenlét=${p.keszenlet}h`).join("\n")}` },
      ],
    });
    const summary = json?.choices?.[0]?.message?.content ?? "";
    return { summary: String(summary).trim() };
  });
