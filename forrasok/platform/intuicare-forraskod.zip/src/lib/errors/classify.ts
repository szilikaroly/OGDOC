export type AppErrorKind =
  | "missing_table"
  | "missing_column"
  | "permission_denied"
  | "unauthorized"
  | "not_found"
  | "network"
  | "unknown";

export type ClassifiedError = {
  kind: AppErrorKind;
  title: string;
  description: string;
  hint: string;
  technical: string;
  requestId: string | null;
};

const REQUEST_ID_RE = /\s*\[request_id=([^\]]+)\]\s*$/;

/** Extract `[request_id=…]` suffix injected by serverFnErrorLogger. */
export function extractRequestId(input: unknown): { requestId: string | null; cleanMessage: string } {
  const raw =
    typeof input === "string"
      ? input
      : input && typeof input === "object" && "message" in input && typeof (input as { message: unknown }).message === "string"
        ? ((input as { message: string }).message)
        : "";
  const match = raw.match(REQUEST_ID_RE);
  if (!match) return { requestId: null, cleanMessage: raw };
  return { requestId: match[1] ?? null, cleanMessage: raw.replace(REQUEST_ID_RE, "") };
}

type AnyErr = {
  message?: unknown;
  code?: unknown;
  status?: unknown;
  statusCode?: unknown;
  details?: unknown;
  hint?: unknown;
  name?: unknown;
  cause?: unknown;
} | null | undefined;

function pickString(...vals: unknown[]): string {
  for (const v of vals) {
    if (typeof v === "string" && v.length > 0) return v;
  }
  return "";
}

function extract(error: unknown): {
  message: string;
  code: string;
  status: number | null;
  raw: string;
} {
  if (!error) return { message: "", code: "", status: null, raw: "" };
  if (typeof error === "string") {
    return { message: error, code: "", status: null, raw: error };
  }
  const e = error as AnyErr;
  const message = pickString(e?.message, e?.details, e?.hint);
  const code = pickString(e?.code);
  const statusRaw = e?.status ?? e?.statusCode;
  const status =
    typeof statusRaw === "number"
      ? statusRaw
      : typeof statusRaw === "string" && /^\d+$/.test(statusRaw)
        ? Number(statusRaw)
        : null;
  let raw = message;
  try {
    raw = JSON.stringify(error, Object.getOwnPropertyNames(error as object));
  } catch {
    raw = message || String(error);
  }
  return { message, code, status, raw };
}

export function classifyError(error: unknown): ClassifiedError {
  const { requestId } = extractRequestId(error);
  const { message, code, status, raw } = extract(error);
  const msg = message.toLowerCase();

  const base = { requestId };

  // Postgres: 42P01 undefined_table, 42703 undefined_column, 42501 insufficient_privilege
  if (code === "42P01" || /relation\s+"?[\w.]+"?\s+does not exist/i.test(message)) {
    return {
      ...base,
      kind: "missing_table",
      title: "Adatbázis-séma elavult",
      description:
        "Egy hivatkozott adattábla nem található az adatbázisban. Ez általában migráció hiányára vagy elavult kliens-kódra utal.",
      hint: "Frissítse az oldalt (Ctrl/Cmd+R). Ha továbbra is fennáll, szóljon a rendszergazdának – migráció szükséges.",
      technical: raw || message,
    };
  }
  if (code === "42703" || /column\s+[\w."]+\s+does not exist/i.test(message)) {
    return {
      ...base,
      kind: "missing_column",
      title: "Adatbázis-séma elavult",
      description:
        "Egy hivatkozott oszlop nem létezik az adatbázisban. Valószínűleg egy migráció még nem futott le.",
      hint: "Frissítse az oldalt. Ha továbbra is fennáll, szóljon a rendszergazdának a hibakóddal együtt.",
      technical: raw || message,
    };
  }
  if (
    code === "42501" ||
    status === 403 ||
    /^forbidden\b|permission denied|row[- ]level security|rls|new row violates row-level security/i.test(
      msg,
    )
  ) {
    return {
      ...base,
      kind: "permission_denied",
      title: "Nincs jogosultsága",
      description: "A művelet végrehajtásához nincs megfelelő jogosultsága.",
      hint: "Lépjen kapcsolatba a rendszergazdával, ha úgy gondolja, hogy hozzáférést kellene kapnia.",
      technical: raw || message,
    };
  }
  if (
    status === 401 ||
    /unauthorized|no authorization header|jwt|invalid token|session.*expired/i.test(msg)
  ) {
    return {
      ...base,
      kind: "unauthorized",
      title: "Munkamenet lejárt",
      description: "Be kell jelentkeznie a folytatáshoz.",
      hint: "Jelentkezzen be újra a bejelentkezési oldalon.",
      technical: raw || message,
    };
  }
  if (status === 404 || code === "PGRST116" || /not found/i.test(msg)) {
    return {
      ...base,
      kind: "not_found",
      title: "Nem található",
      description: "A kért erőforrás nem létezik vagy törölve lett.",
      hint: "Ellenőrizze a hivatkozást, vagy térjen vissza a kezdőoldalra.",
      technical: raw || message,
    };
  }
  if (
    /failed to fetch|network ?error|networkrequestfailed|load failed|fetch failed/i.test(msg)
  ) {
    return {
      ...base,
      kind: "network",
      title: "Hálózati hiba",
      description: "Nem sikerült a szerverhez csatlakozni.",
      hint: "Ellenőrizze az internetkapcsolatát, majd próbálja újra.",
      technical: raw || message,
    };
  }
  return {
    ...base,
    kind: "unknown",
    title: "Az oldal nem töltődött be",
    description: "Váratlan hiba történt a művelet végrehajtása közben.",
    hint: "Próbálja újratölteni az oldalt, vagy térjen vissza a kezdőoldalra.",
    technical: raw || message || String(error),
  };
}

