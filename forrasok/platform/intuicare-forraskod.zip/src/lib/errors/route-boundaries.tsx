import { Link, useRouter } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { classifyError, type ClassifiedError } from "./classify";
import { reportLovableError } from "../lovable-error-reporting";
import { logClientError } from "./error-log.functions";

const AUTO_RETRY_KINDS = new Set(["missing_column", "missing_table", "network"]);
const MAX_AUTO_RETRIES = 3;

function ContextualActions({
  classified,
  onRetry,
}: {
  classified: ClassifiedError;
  onRetry: () => void;
}) {
  const buttons: Array<{ label: string; onClick?: () => void; href?: string; primary?: boolean }> = [];

  switch (classified.kind) {
    case "missing_table":
    case "missing_column":
      buttons.push(
        { label: "Oldal újratöltése", onClick: () => window.location.reload(), primary: true },
        { label: "Értesítés az adminnak", onClick: () => toast.info("A hiba automatikusan naplózva lett – az admin értesülni fog.") },
        { label: "Kezdőoldal", href: "/" },
      );
      break;
    case "permission_denied":
      buttons.push(
        { label: "Jogosultság ellenőrzése", href: "/admin/jogosultsagok", primary: true },
        { label: "Kezdőoldal", href: "/" },
      );
      break;
    case "unauthorized":
      buttons.push(
        { label: "Bejelentkezés", href: "/auth", primary: true },
        { label: "Kezdőoldal", href: "/" },
      );
      break;
    case "network":
      buttons.push(
        { label: "Újrapróbálás", onClick: onRetry, primary: true },
        { label: "Kezdőoldal", href: "/" },
      );
      break;
    case "not_found":
      buttons.push(
        { label: "Vissza", onClick: () => history.back(), primary: true },
        { label: "Kezdőoldal", href: "/" },
      );
      break;
    default:
      buttons.push(
        { label: "Újrapróbálás", onClick: onRetry, primary: true },
        { label: "Kezdőoldal", href: "/" },
      );
  }

  return (
    <div className="mt-6 flex flex-wrap justify-center gap-2">
      {buttons.map((b, i) => {
        const cls = b.primary
          ? "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          : "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent";
        if (b.href) {
          return (
            <Link key={i} to={b.href} className={cls}>
              {b.label}
            </Link>
          );
        }
        return (
          <button key={i} onClick={b.onClick} className={cls}>
            {b.label}
          </button>
        );
      })}
    </div>
  );
}

function ErrorBody({
  classified,
  onRetry,
  fullScreen,
  supportCode,
  retrying,
  retryAttempt,
}: {
  classified: ClassifiedError;
  onRetry: () => void;
  fullScreen?: boolean;
  supportCode: string | null;
  retrying: boolean;
  retryAttempt: number;
}) {
  const [copied, setCopied] = useState(false);
  const [codeCopied, setCodeCopied] = useState(false);

  const copy = async (text: string, setter: (b: boolean) => void) => {
    try {
      await navigator.clipboard.writeText(text);
      setter(true);
      toast.success("Vágólapra másolva");
      setTimeout(() => setter(false), 2000);
    } catch {
      toast.error("Nem sikerült másolni");
    }
  };

  return (
    <div
      className={
        fullScreen
          ? "flex min-h-screen items-center justify-center bg-background px-4"
          : "flex min-h-[40vh] items-center justify-center px-4 py-12"
      }
    >
      <div className="max-w-lg w-full text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          {classified.title}
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">{classified.description}</p>
        <p className="mt-3 text-sm text-foreground">{classified.hint}</p>

        {retrying ? (
          <div className="mt-4 rounded-md border border-border bg-muted/30 px-3 py-2 text-sm text-muted-foreground">
            Automatikus újrapróbálás… ({retryAttempt}/{MAX_AUTO_RETRIES})
            <div className="mt-2 h-1 w-full overflow-hidden rounded-full bg-muted">
              <div
                className="h-full bg-primary transition-all"
                style={{ width: `${(retryAttempt / MAX_AUTO_RETRIES) * 100}%` }}
              />
            </div>
          </div>
        ) : (
          <ContextualActions classified={classified} onRetry={onRetry} />
        )}

        {classified.requestId ? (
          <div className="mt-4 text-xs text-muted-foreground">
            Kérés azonosító:{" "}
            <button
              onClick={() => copy(classified.requestId!, setCodeCopied)}
              className="font-mono font-semibold text-foreground underline"
              title="Kattintson a másoláshoz"
            >
              {classified.requestId}
            </button>
            {codeCopied ? " ✓" : ""}
          </div>
        ) : supportCode ? (
          <div className="mt-4 text-xs text-muted-foreground">
            Támogatási hivatkozási kód:{" "}
            <button
              onClick={() => copy(supportCode, setCodeCopied)}
              className="font-mono font-semibold text-foreground underline"
              title="Kattintson a másoláshoz"
            >
              {supportCode}
            </button>
            {codeCopied ? " ✓" : ""}
          </div>
        ) : null}

        {classified.technical ? (
          <details className="mt-6 text-left rounded-md border border-border bg-muted/30 px-3 py-2">
            <summary className="cursor-pointer text-xs text-muted-foreground">
              Technikai részletek
            </summary>
            <pre className="mt-2 max-h-48 overflow-auto whitespace-pre-wrap break-all text-xs text-muted-foreground">
              {classified.technical}
            </pre>
            <button
              onClick={() => copy(classified.technical, setCopied)}
              className="mt-2 text-xs underline text-muted-foreground hover:text-foreground"
            >
              {copied ? "Másolva" : "Hibakód másolása"}
            </button>
          </details>
        ) : null}
      </div>
    </div>
  );
}

function useErrorTelemetry(error: Error, classified: ClassifiedError, boundary: string) {
  const [supportCode, setSupportCode] = useState<string | null>(null);
  const reported = useRef(false);
  useEffect(() => {
    if (reported.current) return;
    reported.current = true;
    reportLovableError(error, { boundary, kind: classified.kind });
    // Best-effort central logging
    const route =
      typeof window !== "undefined" ? window.location.pathname + window.location.search : null;
    const queryParams: Record<string, string> = {};
    if (typeof window !== "undefined") {
      new URLSearchParams(window.location.search).forEach((v, k) => {
        queryParams[k] = v;
      });
    }
    logClientError({
      data: {
        kind: classified.kind,
        title: classified.title,
        message: error.message ?? null,
        technical: classified.technical ?? null,
        route,
        queryParams,
        userAgent: typeof navigator !== "undefined" ? navigator.userAgent.slice(0, 500) : null,
      },
    })
      .then((r) => setSupportCode(r.code))
      .catch(() => {});
  }, [error, classified, boundary]);
  return supportCode;
}

function useAutoRetry(
  classified: ClassifiedError,
  onRetry: () => void,
): { retrying: boolean; attempt: number } {
  const [attempt, setAttempt] = useState(0);
  const [retrying, setRetrying] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (!AUTO_RETRY_KINDS.has(classified.kind)) return;
    if (attempt >= MAX_AUTO_RETRIES) {
      setRetrying(false);
      return;
    }
    setRetrying(true);
    const delay = Math.min(8000, 800 * Math.pow(2, attempt));
    timer.current = setTimeout(() => {
      setAttempt((a) => a + 1);
      onRetry();
    }, delay);
    return () => {
      if (timer.current) clearTimeout(timer.current);
    };
    // intentionally ignore onRetry identity changes
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [classified.kind, attempt]);

  return { retrying, attempt };
}

export function RouteErrorBoundary({
  error,
  reset,
}: {
  error: Error;
  reset: () => void;
}) {
  const router = useRouter();
  const classified = classifyError(error);
  const supportCode = useErrorTelemetry(error, classified, "tanstack_route_error_component");
  const doRetry = () => {
    router.invalidate();
    reset();
  };
  const { retrying, attempt } = useAutoRetry(classified, doRetry);

  return (
    <ErrorBody
      classified={classified}
      onRetry={doRetry}
      supportCode={supportCode}
      retrying={retrying}
      retryAttempt={attempt}
    />
  );
}

export function RootErrorBoundary({
  error,
  reset,
}: {
  error: Error;
  reset: () => void;
}) {
  const router = useRouter();
  const classified = classifyError(error);
  const supportCode = useErrorTelemetry(error, classified, "tanstack_root_error_component");
  const doRetry = () => {
    router.invalidate();
    reset();
  };
  const { retrying, attempt } = useAutoRetry(classified, doRetry);

  return (
    <ErrorBody
      fullScreen
      classified={classified}
      onRetry={doRetry}
      supportCode={supportCode}
      retrying={retrying}
      retryAttempt={attempt}
    />
  );
}
