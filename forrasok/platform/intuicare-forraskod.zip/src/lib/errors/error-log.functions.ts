import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const LogInput = z.object({
  kind: z.string().max(40),
  title: z.string().max(200).nullable().optional(),
  message: z.string().max(2000).nullable().optional(),
  technical: z.string().max(8000).nullable().optional(),
  route: z.string().max(500).nullable().optional(),
  queryParams: z.record(z.string(), z.unknown()).nullable().optional(),
  userAgent: z.string().max(500).nullable().optional(),
});

/**
 * Public logging endpoint. Anyone can insert; only admins can read.
 * Returns a short support code (ERR-XXXXXX) the user can reference.
 */
export const logClientError = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => LogInput.parse(d))
  .handler(async ({ data }) => {
    const { createClient } = await import("@supabase/supabase-js");
    const supabase = createClient(
      process.env.SUPABASE_URL!,
      process.env.SUPABASE_PUBLISHABLE_KEY!,
      { auth: { storage: undefined, persistSession: false, autoRefreshToken: false } },
    );

    // Best-effort userId from incoming Authorization header
    let userId: string | null = null;
    try {
      const { getRequestHeader } = await import("@tanstack/react-start/server");
      const auth = getRequestHeader("authorization") ?? "";
      const token = auth.toLowerCase().startsWith("bearer ") ? auth.slice(7) : null;
      if (token) {
        const { data: u } = await supabase.auth.getUser(token);
        userId = u.user?.id ?? null;
      }
    } catch {}

    const { data: inserted, error } = await supabase
      .from("error_log")
      .insert({
        kind: data.kind,
        title: data.title ?? null,
        message: data.message ?? null,
        technical: data.technical ?? null,
        route: data.route ?? null,
        query_params: data.queryParams ?? null,
        user_agent: data.userAgent ?? null,
        user_id: userId,
      })
      .select("code")
      .single();

    if (error) {
      // Don't crash the caller — return a deterministic fallback code
      return { code: `LOCAL-${Date.now().toString(36).toUpperCase().slice(-6)}`, persisted: false };
    }
    return { code: inserted.code as string, persisted: true };
  });

// ---------------- Admin reads ----------------

const ListInput = z.object({
  limit: z.number().int().min(1).max(200).default(50),
  kind: z.string().max(40).nullable().optional(),
});

export const listErrorLog = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => ListInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: isAdmin } = await supabase.rpc("has_role", {
      _user_id: userId,
      _role_kulcs: "tenant_admin",
    });
    if (!isAdmin) throw new Error("Nincs jogosultsága.");

    let q = supabase
      .from("error_log")
      .select("id, code, kind, title, message, technical, route, query_params, user_id, user_agent, ai_suggestion, ai_suggested_at, created_at")
      .order("created_at", { ascending: false })
      .limit(data.limit);
    if (data.kind) q = q.eq("kind", data.kind);

    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    return { rows: rows ?? [] };
  });

// ---------------- AI-assisted fix suggestion ----------------

const SuggestInput = z.object({
  errorId: z.string().uuid(),
});

export const suggestErrorFix = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => SuggestInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: isAdmin } = await supabase.rpc("has_role", {
      _user_id: userId,
      _role_kulcs: "tenant_admin",
    });
    if (!isAdmin) throw new Error("Nincs jogosultsága.");

    const { data: row, error: rowErr } = await supabase
      .from("error_log")
      .select("id, kind, title, message, technical, route, query_params")
      .eq("id", data.errorId)
      .maybeSingle();
    if (rowErr || !row) throw new Error("Hibanapló bejegyzés nem található.");

    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) throw new Error("AI gateway nincs konfigurálva.");

    const prompt = `Egy TanStack Start + Supabase (Postgres) alkalmazás futási hibája:

Típus: ${row.kind}
Útvonal: ${row.route ?? "(ismeretlen)"}
Cím: ${row.title ?? "-"}
Üzenet: ${row.message ?? "-"}
Query paraméterek: ${JSON.stringify(row.query_params ?? {})}
Technikai stack / részletek:
${(row.technical ?? "").slice(0, 4000)}

Adj rövid, gyakorlati hibajavítási javaslatot magyarul a fejlesztőnek:
1) Legvalószínűbb gyökérok 1-2 mondatban
2) Konkrét javítási lépések felsorolva (migration, kód, konfig)
3) Ha SQL javítás kell, add meg a SQL-t kódblokkban
Tömör, max 250 szó.`;

    const aiRes = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Lovable-API-Key": apiKey,
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          {
            role: "system",
            content:
              "Senior full-stack engineer vagy TanStack Start + Supabase szakértelemmel. Tömör, akcionálható válaszokat adsz magyarul.",
          },
          { role: "user", content: prompt },
        ],
      }),
    });

    if (aiRes.status === 429) throw new Error("AI túlterhelt, próbálja újra hamarosan.");
    if (aiRes.status === 402) throw new Error("AI kredit elfogyott.");
    if (!aiRes.ok) throw new Error(`AI hiba: ${aiRes.status}`);

    const j = await aiRes.json();
    const suggestion: string = j.choices?.[0]?.message?.content ?? "";

    await supabase
      .from("error_log")
      .update({ ai_suggestion: suggestion, ai_suggested_at: new Date().toISOString() })
      .eq("id", row.id);

    return { suggestion };
  });
