import { describe, it, expect } from "vitest";
import { classifyError } from "./classify";

describe("classifyError", () => {
  it("detects missing table by code 42P01", () => {
    expect(classifyError({ code: "42P01", message: "relation x" }).kind).toBe(
      "missing_table",
    );
  });
  it("detects missing column by message", () => {
    expect(
      classifyError(new Error('column st.megnevezes does not exist')).kind,
    ).toBe("missing_column");
  });
  it("detects permission denied", () => {
    expect(classifyError({ code: "42501", message: "permission denied" }).kind).toBe(
      "permission_denied",
    );
  });
  it("detects RLS error", () => {
    expect(
      classifyError(new Error("new row violates row-level security policy")).kind,
    ).toBe("permission_denied");
  });
  it("detects 401 unauthorized", () => {
    expect(classifyError({ status: 401, message: "Unauthorized" }).kind).toBe(
      "unauthorized",
    );
  });
  it("detects network errors", () => {
    expect(classifyError(new TypeError("Failed to fetch")).kind).toBe("network");
  });
  it("falls back to unknown", () => {
    expect(classifyError(new Error("boom")).kind).toBe("unknown");
  });
});
