/**
 * Képforrás-optimalizáló: Lovable Cloud Storage URL-eket (Supabase object endpoint)
 * a `render/image` transform endpoint-ra fordít, hogy WebP + méretezett változatot
 * kapjunk. Nem Cloud URL-eket változatlanul hagyjuk.
 */

const OBJECT_RE = /(\/storage\/v1\/)object(\/(?:public|sign)\/)/;

export type ImgFit = "cover" | "contain" | "fill";

export interface TransformOptions {
  width?: number;
  height?: number;
  quality?: number;
  format?: "origin" | "webp";
  resize?: ImgFit;
}

/**
 * Egy adott URL-hez transzformált Cloud Storage render URL-t készít.
 * Ha az URL nem Cloud Storage object endpoint, változatlanul visszaadja.
 */
export function imgSrc(url: string | null | undefined, opts: TransformOptions = {}): string {
  if (!url) return "";
  if (!OBJECT_RE.test(url)) return url;

  let base: URL;
  try {
    base = new URL(url);
  } catch {
    return url;
  }

  base.pathname = base.pathname.replace(OBJECT_RE, "$1render/image$2");

  const { width, height, quality = 80, format = "webp", resize = "cover" } = opts;
  if (width) base.searchParams.set("width", String(width));
  if (height) base.searchParams.set("height", String(height));
  if (quality) base.searchParams.set("quality", String(quality));
  if (format && format !== "origin") base.searchParams.set("format", format);
  if (resize) base.searchParams.set("resize", resize);

  return base.toString();
}

const DEFAULT_WIDTHS = [320, 480, 768, 1024, 1440];

/**
 * srcSet stringet épít (`url 320w, url 480w, …`). Nem-Cloud URL esetén üres string.
 */
export function buildSrcSet(
  url: string | null | undefined,
  widths: number[] = DEFAULT_WIDTHS,
  opts: Omit<TransformOptions, "width"> = {},
): string {
  if (!url || !OBJECT_RE.test(url)) return "";
  return widths.map((w) => `${imgSrc(url, { ...opts, width: w })} ${w}w`).join(", ");
}

export function isTransformable(url: string | null | undefined): boolean {
  return !!url && OBJECT_RE.test(url);
}

export type SizesPreset = "avatar" | "card" | "hero" | "thumb" | "full";

export const SIZES_PRESETS: Record<SizesPreset, string> = {
  avatar: "(max-width: 640px) 96px, 128px",
  card: "(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 380px",
  hero: "100vw",
  thumb: "(max-width: 640px) 50vw, 320px",
  full: "100vw",
};

const PRESET_MAX_WIDTH: Record<SizesPreset, number> = {
  avatar: 256,
  card: 800,
  hero: 1600,
  thumb: 640,
  full: 1600,
};

export function pickWidthsForPreset(preset: SizesPreset): number[] {
  const max = PRESET_MAX_WIDTH[preset];
  return DEFAULT_WIDTHS.filter((w) => w <= max * 1.2);
}
