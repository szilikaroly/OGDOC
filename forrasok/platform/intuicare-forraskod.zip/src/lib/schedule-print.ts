type Person = { id: string; teljes_nev: string; foglalkozas_tipus: string };
type Cell = { kategoria: string; ora: number; start: string };

function esc(s: string | null | undefined): string {
  return String(s ?? "").replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[c] as string));
}

const KAT_BG: Record<string, string> = {
  rendes: "#e0f2fe",
  ugyelet: "#ede9fe",
  keszenlet: "#fef3c7",
  rendkivuli: "#fee2e2",
  ovt: "#d1fae5",
  szabadnap: "#f3f4f6",
};

export function openSchedulePrint(opts: {
  monthLabel: string;
  days: Date[];
  people: Person[];
  cells: Map<string, Cell[]>; // key: `${userId}|YYYY-MM-DD`
  orgName?: string;
  aiSummary?: string;
}) {
  const { monthLabel, days, people, cells, orgName, aiSummary } = opts;

  const head = `<th>Munkatárs</th>` + days.map((d) => {
    const wd = d.getDay();
    const we = wd === 0 || wd === 6;
    return `<th class="${we ? "we" : ""}"><div>${d.getDate()}</div><div class="dn">${"VHKSCPS"[wd]}</div></th>`;
  }).join("");

  const body = people.map((p) => {
    const tds = days.map((d) => {
      const k = `${p.id}|${d.toISOString().slice(0, 10)}`;
      const arr = cells.get(k) ?? [];
      if (arr.length === 0) return `<td></td>`;
      const inner = arr.map((c) => {
        const bg = KAT_BG[c.kategoria] ?? "#fff";
        return `<div class="chip" style="background:${bg}"><b>${esc(c.start.slice(11, 16))}</b><span>${Number(c.ora).toFixed(0)}h</span></div>`;
      }).join("");
      return `<td>${inner}</td>`;
    }).join("");
    return `<tr><td class="who"><div>${esc(p.teljes_nev)}</div><div class="role">${esc(p.foglalkozas_tipus)}</div></td>${tds}</tr>`;
  }).join("");

  const totalsByKat: Record<string, number> = {};
  cells.forEach((arr) => arr.forEach((c) => { totalsByKat[c.kategoria] = (totalsByKat[c.kategoria] ?? 0) + Number(c.ora); }));
  const legend = Object.entries(totalsByKat).map(([k, h]) =>
    `<span class="legend"><span class="sw" style="background:${KAT_BG[k] ?? "#fff"}"></span>${esc(k)}: ${h.toFixed(0)}h</span>`,
  ).join("");

  const html = `<!doctype html><html lang="hu"><head><meta charset="utf-8" />
<title>Beosztás · ${esc(monthLabel)}</title>
<style>
  @page { size: A3 landscape; margin: 10mm; }
  body { font-family: -apple-system, system-ui, sans-serif; color: #111; margin: 0; }
  h1 { font-size: 16px; margin: 0 0 4px; }
  .meta { font-size: 10px; color: #555; display: flex; justify-content: space-between; }
  table { border-collapse: collapse; width: 100%; margin-top: 8px; font-size: 9px; }
  th, td { border: 1px solid #ccc; padding: 2px; vertical-align: top; text-align: center; }
  th { background: #f9f9f9; font-weight: 600; }
  th.we { background: #eef2ff; }
  th .dn { font-size: 8px; color: #666; }
  td.who { text-align: left; min-width: 120px; }
  td.who .role { font-size: 8px; color: #666; font-family: ui-monospace, Menlo, monospace; }
  .chip { font-size: 8px; padding: 1px 2px; margin: 1px 0; border-radius: 2px; font-family: ui-monospace, Menlo, monospace; display: flex; justify-content: space-between; gap: 2px; }
  .legend { display: inline-flex; align-items: center; gap: 3px; margin-right: 10px; font-size: 10px; }
  .sw { width: 10px; height: 10px; border: 1px solid #888; display: inline-block; }
  .foot { margin-top: 6px; font-size: 9px; }
  @media print { body { margin: 0; } }
</style></head><body>
<h1>Beosztás — ${esc(monthLabel)}${orgName ? " · " + esc(orgName) : ""}</h1>
<div class="meta"><span>${people.length} munkatárs · ${days.length} nap</span><span>Generálva: ${new Date().toLocaleString("hu-HU")}</span></div>
<table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>
${aiSummary ? `<div class="foot" style="margin-top:8px;padding:6px;border:1px solid #ddd;border-radius:4px;background:#fafafa;font-style:italic">AI összefoglaló: ${esc(aiSummary)}</div>` : ""}
<div class="foot">${legend}</div>
<script>setTimeout(() => window.print(), 250);</script>
</body></html>`;

  const w = window.open("", "_blank", "width=1200,height=900");
  if (!w) { alert("Engedélyezze a popup-ablakot a PDF-exporthoz."); return; }
  w.document.open(); w.document.write(html); w.document.close();
}
