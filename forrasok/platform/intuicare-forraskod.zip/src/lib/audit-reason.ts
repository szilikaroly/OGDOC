import { supabase } from "@/integrations/supabase/client";

/**
 * After a successful CRUD operation, attach an optional human-readable
 * "reason" to the most recent audit_log row for that record. The audit_log
 * RLS policy allows the user to update their own rows for 10 minutes.
 */
export async function applyReason(
  table: string,
  recordId: string | null | undefined,
  reason: string | null | undefined,
): Promise<void> {
  if (!reason || !reason.trim() || !recordId) return;
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return;
  const { data } = await supabase
    .from("admin_audit_log")
    .select("id")
    .eq("user_id", user.id)
    .eq("table_name", table)
    .eq("record_id", recordId)
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  if (!data?.id) return;
  await supabase
    .from("admin_audit_log")
    .update({ reason: reason.trim() })
    .eq("id", data.id);
}
