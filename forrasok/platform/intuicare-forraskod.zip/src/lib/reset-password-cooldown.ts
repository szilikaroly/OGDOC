// Client-side spam guard a jelszó-visszaállító link küldéséhez.
// Megjegyzés: ez csak UX-szintű védelem, nem helyettesít szerveroldali rate limitinget.

const STORAGE_KEY = "pw_reset_resend_attempts_v1";
export const MAX_ATTEMPTS = 3;
export const WINDOW_MS = 15 * 60 * 1000; // 15 perc
export const COOLDOWN_MS = 10 * 60 * 1000; // 10 perc tiltás MAX_ATTEMPTS után
export const RECOVERY_LINK_TTL_MIN = 60; // tájékoztató szöveg lejárathoz

type Store = Record<string, number[]>;

function readStore(): Store {
  if (typeof window === "undefined") return {};
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}") as Store;
  } catch {
    return {};
  }
}

function writeStore(store: Store) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(store));
  } catch {
    /* ignore quota */
  }
}

function normalize(email: string): string {
  return email.trim().toLowerCase();
}

function recentAttempts(email: string): number[] {
  const key = normalize(email);
  if (!key) return [];
  const all = readStore();
  const now = Date.now();
  return (all[key] || []).filter((t) => now - t < WINDOW_MS);
}

export function getCooldownRemainingMs(email: string): number {
  const attempts = recentAttempts(email);
  if (attempts.length < MAX_ATTEMPTS) return 0;
  const last = Math.max(...attempts);
  return Math.max(0, COOLDOWN_MS - (Date.now() - last));
}

export function getRemainingAttempts(email: string): number {
  return Math.max(0, MAX_ATTEMPTS - recentAttempts(email).length);
}

export function registerResendAttempt(email: string) {
  const key = normalize(email);
  if (!key) return;
  const all = readStore();
  const now = Date.now();
  const arr = (all[key] || []).filter((t) => now - t < WINDOW_MS);
  arr.push(now);
  all[key] = arr;
  writeStore(all);
}

export function formatRemaining(ms: number): string {
  const totalSec = Math.ceil(ms / 1000);
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  if (m <= 0) return `${s} mp`;
  return `${m} p ${s.toString().padStart(2, "0")} mp`;
}
