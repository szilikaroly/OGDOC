import { describe, expect, it } from "vitest";
import { computeMtLeaveDays } from "./mt-leave";

const Y = 2026;
const stichtag = `${Y}-12-31`;

describe("computeMtLeaveDays", () => {
  it("returns 20 days for a young employee with no children", () => {
    const r = computeMtLeaveDays({ birthDate: "2005-06-01", year: Y });
    expect(r.total).toBe(20);
    expect(r.ageBonus).toBe(0);
  });

  it("adds age bonus by Mt. 117.§ tiers", () => {
    expect(computeMtLeaveDays({ birthDate: `${Y - 25}-01-01`, year: Y }).ageBonus).toBe(1);
    expect(computeMtLeaveDays({ birthDate: `${Y - 28}-01-01`, year: Y }).ageBonus).toBe(2);
    expect(computeMtLeaveDays({ birthDate: `${Y - 33}-01-01`, year: Y }).ageBonus).toBe(4);
    expect(computeMtLeaveDays({ birthDate: `${Y - 45}-01-01`, year: Y }).ageBonus).toBe(10);
    expect(computeMtLeaveDays({ birthDate: `${Y - 60}-01-01`, year: Y }).ageBonus).toBe(10);
  });

  it("uses stichtag (Dec 31) for age — turning 25 on Dec 30 counts", () => {
    const r = computeMtLeaveDays({ birthDate: `${Y - 25}-12-30`, year: Y });
    expect(r.ageBonus).toBe(1);
  });

  it("adds child bonus only for children under 16 at stichtag", () => {
    const r = computeMtLeaveDays({
      birthDate: `${Y - 35}-01-01`,
      childrenBirths: [`${Y - 5}-03-10`, `${Y - 14}-06-01`, `${Y - 17}-01-01`],
      year: Y,
    });
    expect(r.eligibleChildren).toBe(2);
    expect(r.childBonus).toBe(4);
    expect(r.ageBonus).toBe(5);
    expect(r.total).toBe(20 + 5 + 4);
  });

  it("uses +7 days for 3+ children", () => {
    const r = computeMtLeaveDays({
      childrenBirths: [`${Y - 1}-01-01`, `${Y - 5}-01-01`, `${Y - 10}-01-01`, `${Y - 12}-01-01`],
      year: Y,
    });
    expect(r.childBonus).toBe(7);
  });

  it("adds +2 per disabled child on top of base child bonus", () => {
    const r = computeMtLeaveDays({
      childrenBirths: [`${Y - 3}-01-01`, `${Y - 8}-01-01`],
      childrenDisabled: [true, false],
      year: Y,
    });
    expect(r.childBonus).toBe(4);
    expect(r.disabledBonus).toBe(2);
    expect(r.total).toBe(20 + 4 + 2);
  });

  it("returns 0 when excluded", () => {
    expect(
      computeMtLeaveDays({ birthDate: "1980-01-01", excluded: true, year: Y }).total,
    ).toBe(0);
  });

  it("ignores missing birth date for age bonus", () => {
    const r = computeMtLeaveDays({ year: Y });
    expect(r.ageBonus).toBe(0);
    expect(r.total).toBe(20);
  });

  it("voidexample: 45y + 3 kids + 1 disabled = 20+10+7+2 = 39", () => {
    expect(
      computeMtLeaveDays({
        birthDate: `${Y - 45}-05-12`,
        childrenBirths: [`${Y - 2}-01-01`, `${Y - 6}-01-01`, `${Y - 11}-01-01`],
        childrenDisabled: [true, false, false],
        year: Y,
      }).total,
    ).toBe(39);
  });
});

// Make TS happy if the file is evaluated outside vitest
void stichtag;
