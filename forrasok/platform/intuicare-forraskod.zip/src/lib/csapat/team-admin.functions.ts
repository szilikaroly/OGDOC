/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * Team management server functions for the csapat (team) page:
 *   - listTeamOptions       — sites, org_units, roles for the current tenant
 *   - inviteTeamMember      — magic-link invite for new members
 *   - createTeamMember      — direct account creation with temporary password
 *   - bulkAssignRoles       — add/remove roles for multiple users
 *   - bulkAssignSite        — bulk update primary employment site
 *   - bulkAssignOrgUnit     — bulk update primary employment org_unit
 *   - bulkArchive / bulkRestore — bulk soft delete / restore
 *
 * All functions require manage_tenant permission and stay strictly tenant-scoped.
 */
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

// ---------------- Helpers ----------------

async function assertHrAccess(ctx: { supabase: any; userId: string }): Promise<void> {
  const { data, error } = await ctx.supabase.rpc("has_permission", {
    _user_id: ctx.userId,
    _perm: "manage_tenant",
  });
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Nincs jogosultság (manage_tenant szükséges).");
}

async function currentTenantId(supabase: any): Promise<string> {
  const { data, error } = await supabase.rpc("current_tenant_id");
  if (error || !data) throw new Error("Nincs aktív tenant.");
  return data as string;
}

/** Filters a list of user IDs to only those belonging to the current tenant. */
async function filterTenantUserIds(
  supabase: any,
  tenantId: string,
  userIds: string[],
): Promise<string[]> {
  if (!userIds.length) return [];
  const { data } = await supabase
    .from("profiles")
    .select("id")
    .eq("tenant_id", tenantId)
    .in("id", userIds);
  return (data ?? []).map((r: { id: string }) => r.id);
}

function makeTempPassword(): string {
  // 14-char password with mixed alphabet; cryptographically secure.
  const alphabet =
    "ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789!@#$%&*";
  const buf = new Uint32Array(14);
  crypto.getRandomValues(buf);
  let out = "";
  for (const n of buf) out += alphabet[n % alphabet.length];
  return out;
}

// ---------------- listTeamOptions ----------------

export const listTeamOptions = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertHrAccess(context);
    const tenantId = await currentTenantId(context.supabase);

    const [{ data: sites }, { data: orgUnits }, { data: roles }] = await Promise.all([
      context.supabase
        .from("sites")
        .select("id, nev, aktiv")
        .eq("tenant_id", tenantId)
        .eq("aktiv", true)
        .order("nev"),
      context.supabase
        .from("org_units")
        .select("id, nev, site_id, aktiv")
        .eq("tenant_id", tenantId)
        .eq("aktiv", true)
        .order("nev"),
      context.supabase
        .from("roles")
        .select("id, kulcs, megnevezes, kategoria, sorrend")
        .order("sorrend")
        .order("megnevezes"),
    ]);

    return {
      tenantId,
      sites: (sites ?? []) as Array<{ id: string; nev: string; aktiv: boolean }>,
      orgUnits: (orgUnits ?? []) as Array<{ id: string; nev: string; site_id: string; aktiv: boolean }>,
      roles: (roles ?? []) as Array<{ id: string; kulcs: string; megnevezes: string; kategoria: string; sorrend: number }>,
    };
  });

// ---------------- inviteTeamMember ----------------

const InviteInput = z.object({
  email: z.string().email().transform((s) => s.trim().toLowerCase()),
  teljes_nev: z.string().min(1).max(200),
  foglalkozas_tipus: z.enum(["orvos", "szakdolgozo", "egyeb"]),
  role_keys: z.array(z.string()).default([]),
  site_id: z.string().uuid().nullish(),
  org_unit_id: z.string().uuid().nullish(),
});

export const inviteTeamMember = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => InviteInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertHrAccess(context);
    const tenantId = await currentTenantId(context.supabase);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // Check for existing profile / user with this email
    const { data: existing } = await context.supabase
      .from("profiles")
      .select("id, tenant_id")
      .eq("email", data.email)
      .maybeSingle();
    if (existing && existing.tenant_id && existing.tenant_id !== tenantId) {
      throw new Error("Ez az email már egy másik szervezethez tartozik.");
    }

    let userId = existing?.id ?? null;
    if (!userId) {
      const { data: invited, error } = await supabaseAdmin.auth.admin.inviteUserByEmail(
        data.email,
        { data: { teljes_nev: data.teljes_nev, invited_to_tenant: tenantId } },
      );
      if (error || !invited?.user) {
        throw new Error(`Meghívó küldés sikertelen: ${error?.message ?? "ismeretlen hiba"}`);
      }
      userId = invited.user.id;
    }

    await supabaseAdmin
      .from("profiles")
      .upsert(
        {
          id: userId,
          tenant_id: tenantId,
          email: data.email,
          teljes_nev: data.teljes_nev,
          foglalkozas_tipus: data.foglalkozas_tipus,
          aktiv: true,
        },
        { onConflict: "id" },
      );

    await applyEmployment(supabaseAdmin, tenantId, userId, data.site_id ?? null, data.org_unit_id ?? null);
    await applyRoles(supabaseAdmin, tenantId, userId, data.role_keys, "add");

    await supabaseAdmin.from("admin_audit_log").insert({
      tenant_id: tenantId,
      user_id: context.userId,
      action: "staff_invite",
      table_name: "profiles",
      record_id: userId,
      summary: `Meghívó küldve: ${data.email}`,
    });

    return { ok: true, user_id: userId, mode: "invite" as const };
  });

// ---------------- createTeamMember ----------------

const CreateInput = InviteInput.extend({
  send_password_email: z.boolean().default(false),
});

export const createTeamMember = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => CreateInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertHrAccess(context);
    const tenantId = await currentTenantId(context.supabase);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: existing } = await context.supabase
      .from("profiles")
      .select("id, tenant_id")
      .eq("email", data.email)
      .maybeSingle();
    if (existing) {
      throw new Error("Ez az email már létezik a rendszerben.");
    }

    const tempPassword = makeTempPassword();
    const { data: created, error } = await supabaseAdmin.auth.admin.createUser({
      email: data.email,
      password: tempPassword,
      email_confirm: true,
      user_metadata: {
        teljes_nev: data.teljes_nev,
        created_by_admin: true,
        must_change_password: true,
      },
    });
    if (error || !created?.user) {
      throw new Error(`Fiók létrehozása sikertelen: ${error?.message ?? "ismeretlen hiba"}`);
    }
    const userId = created.user.id;

    await supabaseAdmin.from("profiles").upsert(
      {
        id: userId,
        tenant_id: tenantId,
        email: data.email,
        teljes_nev: data.teljes_nev,
        foglalkozas_tipus: data.foglalkozas_tipus,
        aktiv: true,
      },
      { onConflict: "id" },
    );

    await applyEmployment(supabaseAdmin, tenantId, userId, data.site_id ?? null, data.org_unit_id ?? null);
    await applyRoles(supabaseAdmin, tenantId, userId, data.role_keys, "add");

    await supabaseAdmin.from("admin_audit_log").insert({
      tenant_id: tenantId,
      user_id: context.userId,
      action: "staff_create",
      table_name: "profiles",
      record_id: userId,
      summary: `Új fiók: ${data.email}`,
    });

    return { ok: true, user_id: userId, mode: "create" as const, temp_password: tempPassword };
  });

// ---------------- Shared writers ----------------

async function applyEmployment(
  admin: any,
  tenantId: string,
  userId: string,
  siteId: string | null,
  orgUnitId: string | null,
): Promise<void> {
  const { data: existing } = await admin
    .from("profile_employment")
    .select("id")
    .eq("user_id", userId)
    .eq("elsodleges", true)
    .maybeSingle();
  if (existing?.id) {
    const patch: Record<string, unknown> = {};
    if (siteId !== null) patch.site_id = siteId;
    if (orgUnitId !== null) patch.org_unit_id = orgUnitId;
    if (Object.keys(patch).length) {
      await admin.from("profile_employment").update(patch).eq("id", existing.id);
    }
  } else {
    await admin.from("profile_employment").insert({
      tenant_id: tenantId,
      user_id: userId,
      elsodleges: true,
      jogviszony_tipus: "egeszsegugyi_szolgalati",
      fenntarto_tipus: "allami",
      munkaltato_nev: "—",
      site_id: siteId,
      org_unit_id: orgUnitId,
      ervenyes: true,
    });
  }
}

async function applyRoles(
  admin: any,
  tenantId: string,
  userId: string,
  roleKeys: string[],
  action: "add" | "remove",
): Promise<{ touched: number; skipped: string[] }> {
  const keys = roleKeys.map((k) => k.trim().toLowerCase()).filter(Boolean);
  if (!keys.length) return { touched: 0, skipped: [] };
  const { data: roles } = await admin.from("roles").select("id, kulcs").in("kulcs", keys);
  const map = new Map<string, string>((roles ?? []).map((r: any) => [r.kulcs, r.id]));
  const skipped = keys.filter((k) => !map.has(k));
  let touched = 0;
  for (const k of keys) {
    const roleId = map.get(k);
    if (!roleId) continue;
    if (action === "add") {
      const { error } = await admin.from("user_roles").upsert(
        { tenant_id: tenantId, user_id: userId, role_id: roleId },
        { onConflict: "tenant_id,user_id,role_id,site_id,org_unit_id", ignoreDuplicates: true },
      );
      if (!error) touched++;
    } else {
      const { error } = await admin
        .from("user_roles")
        .delete()
        .eq("tenant_id", tenantId)
        .eq("user_id", userId)
        .eq("role_id", roleId);
      if (!error) touched++;
    }
  }
  return { touched, skipped };
}

// ---------------- Bulk operations ----------------

const BulkRolesInput = z.object({
  user_ids: z.array(z.string().uuid()).min(1).max(500),
  role_keys: z.array(z.string()).min(1).max(50),
  action: z.enum(["add", "remove"]),
});

export const bulkAssignRoles = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => BulkRolesInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertHrAccess(context);
    const tenantId = await currentTenantId(context.supabase);
    const userIds = await filterTenantUserIds(context.supabase, tenantId, data.user_ids);
    if (!userIds.length) throw new Error("Egyik kijelölt tag sem ehhez a tenant-hez tartozik.");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    let totalTouched = 0;
    for (const uid of userIds) {
      const res = await applyRoles(supabaseAdmin, tenantId, uid, data.role_keys, data.action);
      totalTouched += res.touched;
    }

    await supabaseAdmin.from("admin_audit_log").insert({
      tenant_id: tenantId,
      user_id: context.userId,
      action: data.action === "add" ? "staff_bulk_role_add" : "staff_bulk_role_remove",
      table_name: "user_roles",
      summary: `${userIds.length} tag × ${data.role_keys.length} szerepkör (${data.action})`,
    });

    return { ok: true, users: userIds.length, role_writes: totalTouched };
  });

const BulkSiteInput = z.object({
  user_ids: z.array(z.string().uuid()).min(1).max(500),
  site_id: z.string().uuid().nullable(),
});

export const bulkAssignSite = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => BulkSiteInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertHrAccess(context);
    const tenantId = await currentTenantId(context.supabase);
    const userIds = await filterTenantUserIds(context.supabase, tenantId, data.user_ids);
    if (!userIds.length) throw new Error("Egyik kijelölt tag sem ehhez a tenant-hez tartozik.");
    if (data.site_id) {
      const { data: site } = await context.supabase
        .from("sites")
        .select("id")
        .eq("id", data.site_id)
        .eq("tenant_id", tenantId)
        .maybeSingle();
      if (!site) throw new Error("Telephely nem található.");
    }
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    for (const uid of userIds) {
      await applyEmployment(supabaseAdmin, tenantId, uid, data.site_id, null);
    }
    await supabaseAdmin.from("admin_audit_log").insert({
      tenant_id: tenantId,
      user_id: context.userId,
      action: "staff_bulk_site_assign",
      table_name: "profile_employment",
      summary: `${userIds.length} tag → telephely: ${data.site_id ?? "(törlés)"}`,
    });
    return { ok: true, users: userIds.length };
  });

const BulkOrgInput = z.object({
  user_ids: z.array(z.string().uuid()).min(1).max(500),
  org_unit_id: z.string().uuid().nullable(),
});

export const bulkAssignOrgUnit = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => BulkOrgInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertHrAccess(context);
    const tenantId = await currentTenantId(context.supabase);
    const userIds = await filterTenantUserIds(context.supabase, tenantId, data.user_ids);
    if (!userIds.length) throw new Error("Egyik kijelölt tag sem ehhez a tenant-hez tartozik.");
    if (data.org_unit_id) {
      const { data: org } = await context.supabase
        .from("org_units")
        .select("id")
        .eq("id", data.org_unit_id)
        .eq("tenant_id", tenantId)
        .maybeSingle();
      if (!org) throw new Error("Szervezeti egység nem található.");
    }
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    for (const uid of userIds) {
      await applyEmployment(supabaseAdmin, tenantId, uid, null, data.org_unit_id);
    }
    await supabaseAdmin.from("admin_audit_log").insert({
      tenant_id: tenantId,
      user_id: context.userId,
      action: "staff_bulk_org_assign",
      table_name: "profile_employment",
      summary: `${userIds.length} tag → szervezet: ${data.org_unit_id ?? "(törlés)"}`,
    });
    return { ok: true, users: userIds.length };
  });

const BulkArchiveInput = z.object({
  user_ids: z.array(z.string().uuid()).min(1).max(500),
  reason: z.string().max(500).optional(),
});

export const bulkArchive = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => BulkArchiveInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertHrAccess(context);
    const tenantId = await currentTenantId(context.supabase);
    const userIds = await filterTenantUserIds(context.supabase, tenantId, data.user_ids);
    if (!userIds.length) throw new Error("Nincs érvényes kijelölt tag.");
    // Refuse to archive the acting user themselves.
    const filtered = userIds.filter((u) => u !== context.userId);
    if (!filtered.length) throw new Error("Saját magadat nem archiválhatod.");
    const today = new Date().toISOString().slice(0, 10);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    await supabaseAdmin.from("profiles").update({ aktiv: false }).in("id", filtered);
    await supabaseAdmin
      .from("profile_employment")
      .update({ ervenyes: false, zaro_datum: today })
      .in("user_id", filtered)
      .eq("elsodleges", true);

    await supabaseAdmin.from("admin_audit_log").insert({
      tenant_id: tenantId,
      user_id: context.userId,
      action: "staff_bulk_archive",
      table_name: "profiles",
      reason: data.reason ?? null,
      summary: `${filtered.length} tag archiválva`,
    });

    return { ok: true, archived: filtered.length, skipped: userIds.length - filtered.length };
  });

const BulkRestoreInput = z.object({ user_ids: z.array(z.string().uuid()).min(1).max(500) });

export const bulkRestore = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => BulkRestoreInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertHrAccess(context);
    const tenantId = await currentTenantId(context.supabase);
    const userIds = await filterTenantUserIds(context.supabase, tenantId, data.user_ids);
    if (!userIds.length) throw new Error("Nincs érvényes kijelölt tag.");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    await supabaseAdmin.from("profiles").update({ aktiv: true }).in("id", userIds);
    await supabaseAdmin
      .from("profile_employment")
      .update({ ervenyes: true, zaro_datum: null })
      .in("user_id", userIds)
      .eq("elsodleges", true);

    await supabaseAdmin.from("admin_audit_log").insert({
      tenant_id: tenantId,
      user_id: context.userId,
      action: "staff_bulk_restore",
      table_name: "profiles",
      summary: `${userIds.length} tag visszaaktiválva`,
    });

    return { ok: true, restored: userIds.length };
  });
