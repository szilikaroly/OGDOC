/**
 * Magyar Munka Törvénykönyve szerinti éves szabadság-számítás.
 * Mt. 117.§ — alap (20) + életkor-pótlék
 * Mt. 118.§ — gyerek után járó pótszabadság (16. életévét még be nem töltött gyerek)
 *
 * Stichtag: a tárgyév december 31. (egész évre járó szabadság).
 */

export type MtLeaveInput = {
  birthDate?: string | Date | null;
  childrenBirths?: Array<string | Date | null | undefined>;
  childrenDisabled?: Array<boolean | undefined>;
  year?: number;
  excluded?: boolean;
};

export type MtLeaveBreakdown = {
  base: number;
  ageBonus: number;
  childBonus: number;
  disabledBonus: number;
  eligibleChildren: number;
  total: number;
  ageAtStichtag: number | null;
  year: number;
  excluded: boolean;
};

function toDate(d?: string | Date | null): Date | null {
  if (!d) return null;
  const dt = d instanceof Date ? d : new Date(d);
  return isNaN(dt.getTime()) ? null : dt;
}

function fullYearsBetween(from: Date, to: Date): number {
  let years = to.getFullYear() - from.getFullYear();
  const m = to.getMonth() - from.getMonth();
  if (m < 0 || (m === 0 && to.getDate() < from.getDate())) years--;
  return years;
}

export function computeMtLeaveDays(input: MtLeaveInput): MtLeaveBreakdown {
  const year = input.year ?? new Date().getFullYear();
  const stichtag = new Date(Date.UTC(year, 11, 31));

  if (input.excluded) {
    return {
      base: 0, ageBonus: 0, childBonus: 0, disabledBonus: 0,
      eligibleChildren: 0, total: 0, ageAtStichtag: null, year, excluded: true,
    };
  }

  const base = 20;
  const birth = toDate(input.birthDate);
  let ageBonus = 0;
  let age: number | null = null;
  if (birth) {
    age = fullYearsBetween(birth, stichtag);
    if (age >= 45) ageBonus = 10;
    else if (age >= 43) ageBonus = 9;
    else if (age >= 41) ageBonus = 8;
    else if (age >= 39) ageBonus = 7;
    else if (age >= 37) ageBonus = 6;
    else if (age >= 35) ageBonus = 5;
    else if (age >= 33) ageBonus = 4;
    else if (age >= 31) ageBonus = 3;
    else if (age >= 28) ageBonus = 2;
    else if (age >= 25) ageBonus = 1;
  }

  let eligibleChildren = 0;
  let disabledBonus = 0;
  const births = input.childrenBirths ?? [];
  const disabled = input.childrenDisabled ?? [];
  births.forEach((c, i) => {
    const cd = toDate(c);
    if (!cd) return;
    const cAge = fullYearsBetween(cd, stichtag);
    if (cAge < 16) {
      eligibleChildren++;
      if (disabled[i]) disabledBonus += 2;
    }
  });

  let childBonus = 0;
  if (eligibleChildren >= 3) childBonus = 7;
  else if (eligibleChildren === 2) childBonus = 4;
  else if (eligibleChildren === 1) childBonus = 2;

  return {
    base,
    ageBonus,
    childBonus,
    disabledBonus,
    eligibleChildren,
    total: base + ageBonus + childBonus + disabledBonus,
    ageAtStichtag: age,
    year,
    excluded: false,
  };
}
