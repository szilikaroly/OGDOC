/* eslint-disable @typescript-eslint/no-explicit-any */
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { computeMtLeaveDays } from "./mt-leave";

// ---------------- Schema for import rows ----------------

const Bool = z
  .union([z.boolean(), z.string(), z.number(), z.null(), z.undefined()])
  .transform((v) => {
    if (typeof v === "boolean") return v;
    if (typeof v === "number") return v !== 0;
    if (v == null) return false;
    const s = String(v).trim().toLowerCase();
    return ["1", "true", "yes", "y", "igen", "i", "x"].includes(s);
  });

const DateStr = z
  .union([z.string(), z.number(), z.date(), z.null(), z.undefined()])
  .transform((v) => {
    if (v == null || v === "") return null;
    if (v instanceof Date) return isNaN(v.getTime()) ? null : v.toISOString().slice(0, 10);
    if (typeof v === "number") {
      // Excel serial date
      const d = new Date(Date.UTC(1899, 11, 30) + v * 86_400_000);
      return isNaN(d.getTime()) ? null : d.toISOString().slice(0, 10);
    }
    const s = String(v).trim();
    if (!s) return null;
    const m = s.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})/);
    if (m) return `${m[1]}-${m[2].padStart(2, "0")}-${m[3].padStart(2, "0")}`;
    const d = new Date(s);
    return isNaN(d.getTime()) ? null : d.toISOString().slice(0, 10);
  });

export const ImportRowSchema = z.object({
  email: z.string().email().transform((s) => s.trim().toLowerCase()),
  teljes_nev: z.string().min(1).transform((s) => s.trim()),
  becenev: z.string().nullish().transform((s) => (s ? s.trim() : null)),
  nem: z
    .string()
    .nullish()
    .transform((s) => {
      const v = (s ?? "").toLowerCase().trim();
      if (["ferfi", "férfi", "m", "male"].includes(v)) return "ferfi";
      if (["no", "nő", "f", "female"].includes(v)) return "no";
      if (["egyeb", "egyéb", "other"].includes(v)) return "egyeb";
      if (!v) return null;
      return "nem_nyilatkozik";
    }),
  szuletesi_datum: DateStr,
  foglalkozas_tipus: z
    .string()
    .nullish()
    .transform((s) => {
      const v = (s ?? "").toLowerCase().trim();
      if (v === "orvos") return "orvos";
      if (v === "szakdolgozo" || v === "szakdolgozó") return "szakdolgozo";
      return "egyeb";
    }),
  locale: z.string().nullish().transform((s) => (s ? s.trim() : null)),

  belepes_datum: DateStr,
  kilepes_datum: DateStr,
  jogviszony_tipus: z.string().nullish(),
  fenntarto_tipus: z.string().nullish(),
  munkaltato_nev: z.string().nullish(),
  munkakor_megnevezes: z.string().nullish(),
  org_unit_nev: z.string().nullish(),
  site_nev: z.string().nullish(),
  fte_szazalek: z.coerce.number().int().min(0).max(200).nullish(),
  munkaido_keret: z.string().nullish(),
  keret_ora: z.coerce.number().nullish(),
  vezetoi_szint: z.string().nullish(),
  oktatoi_munkakor: Bool.nullish(),
  kjt_fizetesi_osztaly: z.string().nullish(),

  gyermek_1_szuletes: DateStr,
  gyermek_2_szuletes: DateStr,
  gyermek_3_szuletes: DateStr,
  gyermek_4_szuletes: DateStr,
  gyermek_5_szuletes: DateStr,
  gyermek_1_fogyatekos: Bool.nullish(),
  gyermek_2_fogyatekos: Bool.nullish(),
  gyermek_3_fogyatekos: Bool.nullish(),
  gyermek_4_fogyatekos: Bool.nullish(),
  gyermek_5_fogyatekos: Bool.nullish(),
  athozott_nap: z.coerce.number().nullish(),
  egyedi_potnap: z.coerce.number().nullish(),
  szabadsag_kizart: Bool.nullish(),

  role: z.string().nullish(),
});

export type ImportRow = z.infer<typeof ImportRowSchema>;

const TEMPLATE_COLUMNS: Array<{ key: keyof ImportRow; label: string; sample: string | number | null }> = [
  { key: "email", label: "email *", sample: "minta.peter@example.hu" },
  { key: "teljes_nev", label: "teljes_nev *", sample: "Minta Péter" },
  { key: "becenev", label: "becenev", sample: "Peti" },
  { key: "nem", label: "nem (ferfi/no/egyeb)", sample: "ferfi" },
  { key: "szuletesi_datum", label: "szuletesi_datum (YYYY-MM-DD)", sample: "1985-03-12" },
  { key: "foglalkozas_tipus", label: "foglalkozas_tipus (orvos/szakdolgozo/egyeb)", sample: "orvos" },
  { key: "locale", label: "locale (hu/en)", sample: "hu" },
  { key: "belepes_datum", label: "belepes_datum", sample: "2020-09-01" },
  { key: "kilepes_datum", label: "kilepes_datum", sample: "" },
  { key: "jogviszony_tipus", label: "jogviszony_tipus", sample: "egeszsegugyi_szolgalati" },
  { key: "fenntarto_tipus", label: "fenntarto_tipus", sample: "allami" },
  { key: "munkaltato_nev", label: "munkaltato_nev", sample: "Példa Kórház" },
  { key: "munkakor_megnevezes", label: "munkakor_megnevezes", sample: "belgyógyász szakorvos" },
  { key: "org_unit_nev", label: "org_unit_nev", sample: "Belgyógyászat" },
  { key: "site_nev", label: "site_nev", sample: "Központi telephely" },
  { key: "fte_szazalek", label: "fte_szazalek (0-200)", sample: 100 },
  { key: "munkaido_keret", label: "munkaido_keret (heti/havi/negyedeves/eves)", sample: "heti" },
  { key: "keret_ora", label: "keret_ora", sample: 40 },
  { key: "vezetoi_szint", label: "vezetoi_szint", sample: "" },
  { key: "oktatoi_munkakor", label: "oktatoi_munkakor (igen/nem)", sample: "nem" },
  { key: "kjt_fizetesi_osztaly", label: "kjt_fizetesi_osztaly", sample: "" },
  { key: "gyermek_1_szuletes", label: "gyermek_1_szuletes", sample: "2015-04-22" },
  { key: "gyermek_1_fogyatekos", label: "gyermek_1_fogyatekos", sample: "nem" },
  { key: "gyermek_2_szuletes", label: "gyermek_2_szuletes", sample: "" },
  { key: "gyermek_2_fogyatekos", label: "gyermek_2_fogyatekos", sample: "" },
  { key: "gyermek_3_szuletes", label: "gyermek_3_szuletes", sample: "" },
  { key: "gyermek_3_fogyatekos", label: "gyermek_3_fogyatekos", sample: "" },
  { key: "gyermek_4_szuletes", label: "gyermek_4_szuletes", sample: "" },
  { key: "gyermek_4_fogyatekos", label: "gyermek_4_fogyatekos", sample: "" },
  { key: "gyermek_5_szuletes", label: "gyermek_5_szuletes", sample: "" },
  { key: "gyermek_5_fogyatekos", label: "gyermek_5_fogyatekos", sample: "" },
  { key: "athozott_nap", label: "athozott_nap", sample: 0 },
  { key: "egyedi_potnap", label: "egyedi_potnap", sample: 0 },
  { key: "szabadsag_kizart", label: "szabadsag_kizart (igen/nem)", sample: "nem" },
  { key: "role", label: "role (vesszővel; pl. admin,orvos)", sample: "orvos" },
];

// ---------- Permission helper ----------

async function assertHrAccess(ctx: { supabase: any; userId: string }): Promise<void> {
  const { data, error } = await ctx.supabase.rpc("has_permission", {
    _user_id: ctx.userId,
    _perm: "manage_tenant",
  });
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Nincs jogosultság (manage_tenant szükséges).");
}

async function currentTenantId(supabase: any): Promise<string> {
  const { data, error } = await supabase.rpc("current_tenant_id");
  if (error || !data) throw new Error("Nincs aktív tenant.");
  return data as string;
}

// ---------- Template download ----------

export const downloadImportTemplate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertHrAccess(context);
    const XLSX = await import("xlsx");
    const headerRow = TEMPLATE_COLUMNS.map((c) => c.label);
    const sampleRow = TEMPLATE_COLUMNS.map((c) => c.sample ?? "");
    const ws = XLSX.utils.aoa_to_sheet([headerRow, sampleRow]);
    ws["!cols"] = TEMPLATE_COLUMNS.map((c) => ({ wch: Math.max(c.label.length + 2, 18) }));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Csapat");

    const help = [
      ["Útmutató — Csapat import sablon"],
      [""],
      ["• Egy sor = egy csapattag. Az email a kulcs (ha már létezik, frissítjük)."],
      ["• Dátumok: YYYY-MM-DD formátum (pl. 1990-05-20)."],
      ["• Logikai mezők: igen / nem (vagy true/false)."],
      ["• org_unit_nev és site_nev a szervezeti egység és telephely neve a saját tenant-ben."],
      ["• role: vesszővel elválasztott szerepkör-kulcsok (pl. admin,orvos,vezeto)."],
      ["• szabadsag_kizart=igen → 0 nap (pl. megbízási jogviszony)."],
      [""],
      ["Szabadság-számítás (magyar Mt.):"],
      ["• Alap: 20 munkanap (117.§)"],
      ["• Életkor-pótlék: 25/28/31/33/35/37/39/41/43/45 év → +1..+10 nap"],
      ["• Gyerek-pótlék (16 alatti): 1→+2, 2→+4, 3+→+7"],
      ["• Fogyatékos gyerek: +2 nap / fő"],
      ["• Stichtag: tárgyév december 31."],
    ];
    const wsHelp = XLSX.utils.aoa_to_sheet(help);
    wsHelp["!cols"] = [{ wch: 90 }];
    XLSX.utils.book_append_sheet(wb, wsHelp, "Útmutató");

    const buf = XLSX.write(wb, { type: "array", bookType: "xlsx" });
    const b64 = Buffer.from(buf).toString("base64");
    return { filename: "csapat-import-sablon.xlsx", base64: b64 };
  });

// ---------- Parse & validate ----------

type DryRowOk = {
  rowIndex: number;
  status: "new" | "update" | "unchanged";
  email: string;
  parsed: ImportRow;
  existingUserId: string | null;
  leaveDays: number;
  leaveBreakdown: ReturnType<typeof computeMtLeaveDays>;
  warnings: string[];
  resolved: {
    orgUnitId: string | null;
    siteId: string | null;
    roleIds: string[];
    unknownRoles: string[];
  };
};
type DryRowErr = { rowIndex: number; status: "error"; email: string | null; errors: string[] };
type DryRow = DryRowOk | DryRowErr;

function parseXlsxBase64(rowsBase64: string): Array<Record<string, unknown>> {
  // Server-only dynamic import; xlsx is pure JS so it loads in Worker.
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const XLSX = require("xlsx");
  const buf = Buffer.from(rowsBase64, "base64");
  const wb = XLSX.read(buf, { type: "buffer", cellDates: true });
  const sheetName = wb.SheetNames.find((n: string) => n !== "Útmutató") ?? wb.SheetNames[0];
  const ws = wb.Sheets[sheetName];
  // Read with header row 1; map by header (we accept either the label or the key prefix)
  const json = XLSX.utils.sheet_to_json(ws, { defval: null, raw: false }) as Array<Record<string, unknown>>;
  // Normalise keys (strip " *", whitespace, take first token before space/parenthesis)
  return json.map((row) => {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(row)) {
      const nk = k
        .replace(/\s*\*$/, "")
        .replace(/\s*\(.*\)$/, "")
        .trim();
      out[nk] = v;
    }
    return out;
  });
}

async function buildLookups(supabase: any, tenantId: string) {
  const [{ data: rolesData }, { data: orgs }, { data: sites }] = await Promise.all([
    supabase.from("roles").select("id, kulcs"),
    supabase.from("org_units").select("id, nev").eq("tenant_id", tenantId),
    supabase.from("sites").select("id, nev").eq("tenant_id", tenantId),
  ]);
  const roleByKey = new Map<string, string>(
    (rolesData ?? []).map((r: any) => [String(r.kulcs).toLowerCase(), r.id as string]),
  );
  const orgByName = new Map<string, string>(
    (orgs ?? []).map((r: any) => [String(r.nev).toLowerCase(), r.id as string]),
  );
  const siteByName = new Map<string, string>(
    (sites ?? []).map((r: any) => [String(r.nev).toLowerCase(), r.id as string]),
  );
  return { roleByKey, orgByName, siteByName };
}

export const dryRunImport = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { fileBase64: string }) => d)
  .handler(async ({ data, context }) => {
    await assertHrAccess(context);
    const tenantId = await currentTenantId(context.supabase);
    const raw = parseXlsxBase64(data.fileBase64);
    const lookups = await buildLookups(context.supabase, tenantId);

    // Pre-fetch existing profiles in this tenant by email
    const emails = raw
      .map((r) => String(r.email ?? "").trim().toLowerCase())
      .filter(Boolean);
    const { data: existing } = await context.supabase
      .from("profiles")
      .select("id, email, teljes_nev, foglalkozas_tipus, szuletesi_datum, aktiv")
      .in("email", emails);
    const byEmail = new Map<string, any>((existing ?? []).map((p: any) => [p.email.toLowerCase(), p]));

    const rows: DryRow[] = [];
    const seenEmail = new Set<string>();

    raw.forEach((r, i) => {
      const rowIndex = i + 2; // header is row 1
      const parsed = ImportRowSchema.safeParse(r);
      if (!parsed.success) {
        rows.push({
          rowIndex,
          status: "error",
          email: (r.email as string) ?? null,
          errors: parsed.error.issues.map((iss) => `${iss.path.join(".") || "?"}: ${iss.message}`),
        });
        return;
      }
      const p = parsed.data;
      if (seenEmail.has(p.email)) {
        rows.push({ rowIndex, status: "error", email: p.email, errors: ["Dupla email a fájlban."] });
        return;
      }
      seenEmail.add(p.email);

      // Resolve org_unit / site / roles
      const orgUnitId = p.org_unit_nev ? lookups.orgByName.get(p.org_unit_nev.toLowerCase()) ?? null : null;
      const siteId = p.site_nev ? lookups.siteByName.get(p.site_nev.toLowerCase()) ?? null : null;
      const roleKeys = (p.role ?? "")
        .split(/[,;]/)
        .map((s) => s.trim().toLowerCase())
        .filter(Boolean);
      const roleIds: string[] = [];
      const unknownRoles: string[] = [];
      for (const k of roleKeys) {
        const id = lookups.roleByKey.get(k);
        if (id) roleIds.push(id);
        else unknownRoles.push(k);
      }

      const warnings: string[] = [];
      if (p.org_unit_nev && !orgUnitId) warnings.push(`Ismeretlen szervezeti egység: "${p.org_unit_nev}"`);
      if (p.site_nev && !siteId) warnings.push(`Ismeretlen telephely: "${p.site_nev}"`);
      if (unknownRoles.length > 0) warnings.push(`Ismeretlen szerepkör(ök): ${unknownRoles.join(", ")}`);

      // Children
      const childrenBirths = [
        p.gyermek_1_szuletes, p.gyermek_2_szuletes, p.gyermek_3_szuletes,
        p.gyermek_4_szuletes, p.gyermek_5_szuletes,
      ];
      const childrenDisabled = [
        !!p.gyermek_1_fogyatekos, !!p.gyermek_2_fogyatekos, !!p.gyermek_3_fogyatekos,
        !!p.gyermek_4_fogyatekos, !!p.gyermek_5_fogyatekos,
      ];

      const breakdown = computeMtLeaveDays({
        birthDate: p.szuletesi_datum,
        childrenBirths,
        childrenDisabled,
        excluded: !!p.szabadsag_kizart,
      });

      const existingP = byEmail.get(p.email);
      let status: "new" | "update" | "unchanged" = existingP ? "update" : "new";
      if (existingP) {
        const same =
          existingP.teljes_nev === p.teljes_nev &&
          existingP.foglalkozas_tipus === p.foglalkozas_tipus &&
          (existingP.szuletesi_datum ?? null) === (p.szuletesi_datum ?? null);
        if (same) status = "unchanged";
      }

      rows.push({
        rowIndex,
        status,
        email: p.email,
        parsed: p,
        existingUserId: existingP?.id ?? null,
        leaveDays: breakdown.total,
        leaveBreakdown: breakdown,
        warnings,
        resolved: { orgUnitId, siteId, roleIds, unknownRoles },
      });
    });

    const summary = {
      total: rows.length,
      new: rows.filter((r) => r.status === "new").length,
      update: rows.filter((r) => r.status === "update").length,
      unchanged: rows.filter((r) => r.status === "unchanged").length,
      errors: rows.filter((r) => r.status === "error").length,
    };
    return { rows, summary, tenantId };
  });

// ---------- Commit ----------

export const commitImport = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { fileBase64: string; fileName?: string; skipRowIndexes?: number[] }) => d)
  .handler(async ({ data, context }) => {
    await assertHrAccess(context);
    const tenantId = await currentTenantId(context.supabase);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // Re-run dry to revalidate server-side
    const raw = parseXlsxBase64(data.fileBase64);
    const lookups = await buildLookups(context.supabase, tenantId);
    const emails = raw.map((r) => String(r.email ?? "").trim().toLowerCase()).filter(Boolean);
    const { data: existing } = await context.supabase
      .from("profiles")
      .select("id, email, gyermek_szamok")
      .in("email", emails);
    const byEmail = new Map<string, any>((existing ?? []).map((p: any) => [p.email.toLowerCase(), p]));

    const skip = new Set(data.skipRowIndexes ?? []);
    const year = new Date().getFullYear();
    let inserted = 0;
    let updated = 0;
    let skipped = 0;
    let errors = 0;
    const errorDetails: Array<{ row: number; email: string | null; error: string }> = [];

    for (let i = 0; i < raw.length; i++) {
      const rowIndex = i + 2;
      if (skip.has(rowIndex)) { skipped++; continue; }
      const parsed = ImportRowSchema.safeParse(raw[i]);
      if (!parsed.success) {
        errors++;
        errorDetails.push({ row: rowIndex, email: (raw[i].email as string) ?? null, error: parsed.error.issues[0]?.message ?? "validation" });
        continue;
      }
      const p = parsed.data;

      try {
        // 1) auth user: invite if new
        let userId = byEmail.get(p.email)?.id as string | undefined;
        if (!userId) {
          const { data: u, error: uErr } = await supabaseAdmin.auth.admin.createUser({
            email: p.email,
            email_confirm: false,
            user_metadata: { teljes_nev: p.teljes_nev, imported: true },
          });
          if (uErr || !u?.user) {
            errors++;
            errorDetails.push({ row: rowIndex, email: p.email, error: uErr?.message ?? "createUser failed" });
            continue;
          }
          userId = u.user.id;
        }

        // 2) children jsonb
        const children: Array<{ birth: string; disabled: boolean }> = [];
        const cb = [p.gyermek_1_szuletes, p.gyermek_2_szuletes, p.gyermek_3_szuletes, p.gyermek_4_szuletes, p.gyermek_5_szuletes];
        const cd = [p.gyermek_1_fogyatekos, p.gyermek_2_fogyatekos, p.gyermek_3_fogyatekos, p.gyermek_4_fogyatekos, p.gyermek_5_fogyatekos];
        cb.forEach((b, idx) => { if (b) children.push({ birth: b, disabled: !!cd[idx] }); });

        // 3) profiles upsert
        const profilePayload: Record<string, unknown> = {
          id: userId,
          tenant_id: tenantId,
          email: p.email,
          teljes_nev: p.teljes_nev,
          becenev: p.becenev ?? null,
          nem: p.nem ?? null,
          szuletesi_datum: p.szuletesi_datum ?? null,
          foglalkozas_tipus: p.foglalkozas_tipus,
          locale: p.locale ?? null,
          belepes_datum: p.belepes_datum ?? null,
          vezetoi_szint: p.vezetoi_szint ?? null,
          oktatoi_munkakor: !!p.oktatoi_munkakor,
          kjt_fizetesi_osztaly: p.kjt_fizetesi_osztaly ?? null,
          gyermek_szamok: children,
          aktiv: true,
        };
        const { error: pErr } = await supabaseAdmin.from("profiles").upsert(profilePayload as any, { onConflict: "id" });
        if (pErr) {
          errors++; errorDetails.push({ row: rowIndex, email: p.email, error: `profile: ${pErr.message}` }); continue;
        }

        // 4) profile_employment (elsődleges sor upsert)
        const orgUnitId = p.org_unit_nev ? lookups.orgByName.get(p.org_unit_nev.toLowerCase()) ?? null : null;
        const siteId = p.site_nev ? lookups.siteByName.get(p.site_nev.toLowerCase()) ?? null : null;
        const employmentPayload: Record<string, unknown> = {
          tenant_id: tenantId,
          user_id: userId,
          elsodleges: true,
          jogviszony_tipus: p.jogviszony_tipus ?? "egeszsegugyi_szolgalati",
          fenntarto_tipus: p.fenntarto_tipus ?? "allami",
          munkaltato_nev: p.munkaltato_nev ?? "—",
          munkakor_megnevezes: p.munkakor_megnevezes ?? null,
          org_unit_id: orgUnitId,
          site_id: siteId,
          kezdo_datum: p.belepes_datum ?? null,
          zaro_datum: p.kilepes_datum ?? null,
          munkaido_keret: p.munkaido_keret ?? "heti",
          keret_ora: p.keret_ora ?? null,
          fte_szazalek: p.fte_szazalek ?? 100,
          ervenyes: true,
          vezetoi_szint: p.vezetoi_szint ?? null,
        };
        // Try update primary, else insert
        const { data: existingEmp } = await supabaseAdmin
          .from("profile_employment")
          .select("id")
          .eq("user_id", userId)
          .eq("elsodleges", true)
          .maybeSingle();
        if (existingEmp?.id) {
          await supabaseAdmin.from("profile_employment").update(employmentPayload as any).eq("id", existingEmp.id);
        } else {
          await supabaseAdmin.from("profile_employment").insert(employmentPayload as any);
        }

        // 5) Roles (vesszővel) — csak adjuk hozzá, nem törlünk
        const roleKeys = (p.role ?? "").split(/[,;]/).map((s) => s.trim().toLowerCase()).filter(Boolean);
        for (const k of roleKeys) {
          const roleId = lookups.roleByKey.get(k);
          if (!roleId) continue;
          await supabaseAdmin.from("user_roles").upsert(
            { tenant_id: tenantId, user_id: userId, role_id: roleId },
            { onConflict: "tenant_id,user_id,role_id,site_id,org_unit_id", ignoreDuplicates: true },
          );
        }

        // 6) Leave entitlement
        const breakdown = computeMtLeaveDays({
          birthDate: p.szuletesi_datum,
          childrenBirths: cb,
          childrenDisabled: cd as boolean[],
          excluded: !!p.szabadsag_kizart,
          year,
        });
        await supabaseAdmin.from("leave_entitlement").upsert(
          {
            tenant_id: tenantId,
            user_id: userId,
            ev: year,
            jogcim: "alap",
            jaro_nap: breakdown.total,
            manual_korrekcio: p.egyedi_potnap ?? 0,
            athozott_nap: p.athozott_nap ?? 0,
            notes: p.szabadsag_kizart
              ? "Importálva: szabadság-kizárás aktív."
              : `Mt. szerint (alap ${breakdown.base} + életkor ${breakdown.ageBonus} + gyerek ${breakdown.childBonus} + fogyatékos ${breakdown.disabledBonus})`,
          },
          { onConflict: "tenant_id,user_id,ev,jogcim" },
        );

        if (byEmail.has(p.email)) updated++; else inserted++;
      } catch (e: any) {
        errors++;
        errorDetails.push({ row: rowIndex, email: p.email, error: e?.message ?? String(e) });
      }
    }

    // Audit
    await supabaseAdmin.from("staff_import_runs").insert({
      tenant_id: tenantId,
      imported_by: context.userId,
      file_name: data.fileName ?? null,
      file_hash: null,
      total_rows: raw.length,
      inserted_rows: inserted,
      updated_rows: updated,
      skipped_rows: skipped,
      error_rows: errors,
      summary: { errors: errorDetails.slice(0, 50) },
    });
    await supabaseAdmin.from("admin_audit_log").insert({
      tenant_id: tenantId,
      user_id: context.userId,
      action: "staff_import",
      table_name: "profiles",
      summary: `${inserted} új · ${updated} frissítve · ${errors} hiba`,
    });

    return { inserted, updated, skipped, errors, errorDetails };
  });

// ---------- Soft delete (archive) ----------

export const archiveTeamMember = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { userId: string; reason?: string }) => d)
  .handler(async ({ data, context }) => {
    await assertHrAccess(context);
    const tenantId = await currentTenantId(context.supabase);
    const today = new Date().toISOString().slice(0, 10);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // Verify target is in same tenant
    const { data: target } = await context.supabase
      .from("profiles").select("id, tenant_id, teljes_nev").eq("id", data.userId).maybeSingle();
    if (!target || target.tenant_id !== tenantId) throw new Error("Csapattag nem található.");

    await supabaseAdmin.from("profiles").update({ aktiv: false }).eq("id", data.userId);
    await supabaseAdmin
      .from("profile_employment")
      .update({ ervenyes: false, zaro_datum: today })
      .eq("user_id", data.userId)
      .eq("elsodleges", true);
    await supabaseAdmin.from("admin_audit_log").insert({
      tenant_id: tenantId,
      user_id: context.userId,
      action: "staff_archive",
      table_name: "profiles",
      record_id: data.userId,
      reason: data.reason ?? null,
      summary: `Archiválva: ${target.teljes_nev}`,
    });
    return { ok: true };
  });

export const restoreTeamMember = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { userId: string }) => d)
  .handler(async ({ data, context }) => {
    await assertHrAccess(context);
    const tenantId = await currentTenantId(context.supabase);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: target } = await context.supabase
      .from("profiles").select("id, tenant_id, teljes_nev").eq("id", data.userId).maybeSingle();
    if (!target || target.tenant_id !== tenantId) throw new Error("Csapattag nem található.");
    await supabaseAdmin.from("profiles").update({ aktiv: true }).eq("id", data.userId);
    await supabaseAdmin
      .from("profile_employment")
      .update({ ervenyes: true, zaro_datum: null })
      .eq("user_id", data.userId)
      .eq("elsodleges", true);
    await supabaseAdmin.from("admin_audit_log").insert({
      tenant_id: tenantId,
      user_id: context.userId,
      action: "staff_restore",
      table_name: "profiles",
      record_id: data.userId,
      summary: `Visszaaktiválva: ${target.teljes_nev}`,
    });
    return { ok: true };
  });

// ---------- Hard delete (admin only) ----------

export const hardDeleteTeamMember = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { userId: string; confirmName: string; reason: string }) => d)
  .handler(async ({ data, context }) => {
    // Require strict admin
    const { data: isAdmin } = await context.supabase.rpc("has_role", { _user_id: context.userId, _role_kulcs: "tenant_admin" });
    if (!isAdmin) throw new Error("Csak admin végezhet végleges törlést.");
    const tenantId = await currentTenantId(context.supabase);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: target } = await context.supabase
      .from("profiles").select("id, tenant_id, teljes_nev, aktiv").eq("id", data.userId).maybeSingle();
    if (!target || target.tenant_id !== tenantId) throw new Error("Csapattag nem található.");
    if (target.aktiv) throw new Error("Csak archivált csapattag törölhető. Előbb archiváld.");
    if (data.confirmName.trim() !== target.teljes_nev.trim()) {
      throw new Error("A megerősítő név nem egyezik.");
    }
    if (!data.reason || data.reason.trim().length < 5) {
      throw new Error("Indoklás kötelező (min. 5 karakter).");
    }

    // Audit BEFORE delete
    await supabaseAdmin.from("admin_audit_log").insert({
      tenant_id: tenantId,
      user_id: context.userId,
      action: "staff_hard_delete",
      table_name: "auth.users",
      record_id: data.userId,
      reason: data.reason,
      before_data: { teljes_nev: target.teljes_nev },
      summary: `Végleges törlés: ${target.teljes_nev}`,
    });

    const { error } = await supabaseAdmin.auth.admin.deleteUser(data.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// ---------- Saját szabadság előnézet (egy emberre) ----------

export const previewLeave = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { userId: string; year?: number }) => d)
  .handler(async ({ data, context }) => {
    await assertHrAccess(context);
    const { data: p } = await context.supabase
      .from("profiles").select("teljes_nev, szuletesi_datum, gyermek_szamok").eq("id", data.userId).maybeSingle();
    if (!p) throw new Error("Csapattag nem található.");
    const kids: Array<{ birth?: string; disabled?: boolean }> = Array.isArray(p.gyermek_szamok) ? (p.gyermek_szamok as unknown as Array<{ birth?: string; disabled?: boolean }>) : [];
    return computeMtLeaveDays({
      birthDate: p.szuletesi_datum,
      childrenBirths: kids.map((k) => k.birth ?? null),
      childrenDisabled: kids.map((k) => !!k.disabled),
      year: data.year,
    });
  });

// ---------- Archived listing ----------

export const listArchivedTeam = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertHrAccess(context);
    const tenantId = await currentTenantId(context.supabase);
    const { data, error } = await context.supabase
      .from("profiles")
      .select("id, teljes_nev, email, foglalkozas_tipus, updated_at")
      .eq("tenant_id", tenantId)
      .eq("aktiv", false)
      .order("updated_at", { ascending: false });
    if (error) throw new Error(error.message);
    return (data ?? []) as Array<{ id: string; teljes_nev: string; email: string; foglalkozas_tipus: string; updated_at: string }>;
  });
