/**
 * Heti összefoglaló futtatása egy tenantra.
 * Server-only modul — csak server fn / public hook hívja.
 */
import { createClient } from "@supabase/supabase-js";
import { sendEmail } from "./email/send.server";
import { renderWeeklyDigestHtml, type DigestData } from "./email-templates/weekly-digest";

type RunOptions = { force?: boolean };

function getAdminClient() {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) throw new Error("Missing Supabase server env");
  return createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
}

function localHourMatches(tz: string, dayOfWeek: number, hourLocal: number, now = new Date()): boolean {
  try {
    const fmt = new Intl.DateTimeFormat("en-GB", {
      timeZone: tz,
      hour: "2-digit",
      weekday: "short",
      hour12: false,
    });
    const parts = fmt.formatToParts(now);
    const wd = parts.find((p) => p.type === "weekday")?.value ?? "";
    const hh = Number(parts.find((p) => p.type === "hour")?.value ?? "-1");
    const dowMap: Record<string, number> = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
    return dowMap[wd] === dayOfWeek && hh === hourLocal;
  } catch {
    return false;
  }
}

async function collectDigestData(
  admin: ReturnType<typeof getAdminClient>,
  tenantId: string,
  sections: Record<string, boolean>,
): Promise<DigestData> {
  const since = new Date(Date.now() - 7 * 86400_000).toISOString();
  const data: DigestData = {
    weekStart: new Date(Date.now() - 7 * 86400_000).toISOString().slice(0, 10),
    weekEnd: new Date().toISOString().slice(0, 10),
    newPatients: 0,
    questionnaires: 0,
    criticalAlerts: 0,
    referrals: 0,
    eesztErrors: 0,
  };

  // Resolve this tenant's patient IDs once; clinical_critical_alerts has no
  // tenant_id column so we must filter by patient_id IN (...).
  const { data: tenantPatients } = await admin
    .from("patients")
    .select("id")
    .eq("tenant_id", tenantId);
  const tenantPatientIds = (tenantPatients ?? []).map((p: any) => p.id as string);

  const counts = await Promise.allSettled([
    sections.new_patients
      ? admin.from("patients").select("id", { count: "exact", head: true }).eq("tenant_id", tenantId).gte("created_at", since)
      : null,
    sections.questionnaires
      ? admin
          .from("questionnaire_responses")
          .select("id", { count: "exact", head: true })
          .eq("tenant_id", tenantId)
          .gte("created_at", since)
      : null,
    sections.critical_alerts && tenantPatientIds.length
      ? admin
          .from("clinical_critical_alerts")
          .select("id", { count: "exact", head: true })
          .in("patient_id", tenantPatientIds)
          .gte("created_at", since)
      : null,
    sections.referrals
      ? admin
          .from("patient_referral_requests")
          .select("id", { count: "exact", head: true })
          .eq("tenant_id", tenantId)
          .gte("created_at", since)
      : null,
  ]);

  const getCount = (r: PromiseSettledResult<any>): number =>
    r.status === "fulfilled" && r.value && typeof r.value.count === "number" ? r.value.count : 0;
  data.newPatients = getCount(counts[0]);
  data.questionnaires = getCount(counts[1]);
  data.criticalAlerts = sections.critical_alerts && tenantPatientIds.length ? getCount(counts[2]) : 0;
  data.referrals = getCount(counts[3]);

  return data;
}

export async function runWeeklyDigestForTenant(
  tenantId: string,
  opts: RunOptions = {},
): Promise<{ ok: boolean; recipients: number; skipped?: string }> {
  const admin = getAdminClient();

  const { data: settings } = await admin
    .from("email_digest_settings")
    .select("*")
    .eq("tenant_id", tenantId)
    .maybeSingle();

  if (!settings) return { ok: false, recipients: 0, skipped: "no_settings" };
  if (!settings.enabled && !opts.force) return { ok: false, recipients: 0, skipped: "disabled" };

  if (!opts.force) {
    if (!localHourMatches(settings.timezone, settings.day_of_week, settings.hour_local)) {
      return { ok: false, recipients: 0, skipped: "not_scheduled" };
    }
    if (settings.last_sent_at) {
      const last = new Date(settings.last_sent_at).getTime();
      if (Date.now() - last < 6 * 86400_000) {
        return { ok: false, recipients: 0, skipped: "already_sent_this_week" };
      }
    }
  }

  // Recipients: users with the listed role keys for this tenant
  const { data: roleRows } = await admin
    .from("roles")
    .select("id, kulcs")
    .in("kulcs", settings.recipient_roles ?? []);
  const roleIds = (roleRows ?? []).map((r: any) => r.id as string);

  let recipients: string[] = [];
  if (roleIds.length) {
    const { data: ur } = await admin
      .from("user_roles")
      .select("user_id")
      .eq("tenant_id", tenantId)
      .in("role_id", roleIds);
    const userIds = Array.from(new Set((ur ?? []).map((r: any) => r.user_id))).filter(Boolean);
    if (userIds.length) {
      // Fetch emails via auth admin
      const emails: string[] = [];
      for (const uid of userIds) {
        try {
          const { data: u } = await admin.auth.admin.getUserById(uid);
          if (u?.user?.email) emails.push(u.user.email);
        } catch {
          // skip
        }
      }
      recipients = Array.from(new Set(emails));
    }
  }

  if (!recipients.length) return { ok: false, recipients: 0, skipped: "no_recipients" };

  const digest = await collectDigestData(admin, tenantId, settings.include_sections ?? {});
  const html = renderWeeklyDigestHtml(digest);
  const subject = `Heti összefoglaló — ${digest.weekStart} – ${digest.weekEnd}`;

  const result = await sendEmail({ to: recipients, subject, html });

  if (result.ok) {
    await admin.from("email_digest_settings").update({ last_sent_at: new Date().toISOString() }).eq("tenant_id", tenantId);
    return { ok: true, recipients: recipients.length };
  }
  return {
    ok: false,
    recipients: recipients.length,
    skipped: "send_failed:" + ((result as any).error ?? (result as any).reason ?? "unknown"),
  };
}

export async function runWeeklyDigestForAllTenants(): Promise<{ processed: number; sent: number }> {
  const admin = getAdminClient();
  const { data: settings } = await admin
    .from("email_digest_settings")
    .select("tenant_id")
    .eq("enabled", true);

  let sent = 0;
  for (const s of (settings ?? []) as Array<{ tenant_id: string }>) {
    const r = await runWeeklyDigestForTenant(s.tenant_id);
    if (r.ok) sent++;
  }
  return { processed: settings?.length ?? 0, sent };
}
