/** Gyakori dekurzus-sablonok gyors-beszúráshoz. */
export type EncounterTemplate = {
  id: string;
  label: string;
  tipus?: "ambulans" | "fekvobeteg" | "muteti" | "konzilium" | "telemedicina" | "egyeb";
  szoveg: string;
  bno?: string[];
  oeno?: string[];
};

export const ENCOUNTER_TEMPLATES: EncounterTemplate[] = [
  {
    id: "amb-belgyo",
    label: "Ambuláns belgyógyászati vizsgálat",
    tipus: "ambulans",
    szoveg:
      "Anamnézis: \nStátusz: Compos mentis, orientált. Cor: tiszta szívhangok, ritmusos. Pulm: sympasycos légzés. Has: puha, betapintható, kp. tájékon nyomásérzékenység nincs.\nVérnyomás: \nDiagnózis: \nTerápia: \nKontroll: ",
  },
  {
    id: "amb-uj-felv",
    label: "Új beteg felvétel (anamnézis)",
    tipus: "ambulans",
    szoveg:
      "Panasz / felvétel oka: \nElőző kórtörténet: \nGyógyszerelés: \nAllergia: \nFizikális vizsgálat: \nLabor/Képalkotó:\nMunkadiagnózis: \nTerv: ",
  },
  {
    id: "akut-fekvo",
    label: "Akut fekvőbeteg felvétel",
    tipus: "fekvobeteg",
    szoveg:
      "Felvételi panaszok: \nKórelőzmény: \nFizikális státusz: \nLabor: \nKépalkotó: \nDiagnózis: \nKezelési terv: \nGondozási feladatok: ",
  },
  {
    id: "muteti-leiras",
    label: "Műtéti leírás (sablon)",
    tipus: "muteti",
    szoveg:
      "Műtét megnevezése: \nMűtő/asszisztencia: \nAnaesztézia típusa: \nLeírás:\n  - Behatolás:\n  - Feltárás:\n  - Beavatkozás:\n  - Vérzéscsillapítás:\n  - Rétegenkénti zárás:\nIntraoperatív szövődmény: nincs / \nPosztoperatív rendelés: ",
  },
  {
    id: "konzilium",
    label: "Konziliumi vélemény",
    tipus: "konzilium",
    szoveg:
      "Konzíliumkérő osztály: \nKérdés:\nAnamnézis és státusz röviden: \nVélemény: \nJavaslat: \nKövetkező lépés: ",
  },
  {
    id: "telem-kontroll",
    label: "Telemedicinális kontroll",
    tipus: "telemedicina",
    szoveg:
      "Kontroll formája: telefon/videó\nAktuális panaszok: \nGyógyszerelés egyeztetve: igen / módosítva\nÉrtékek (RR/pulzus/vércukor/INR stb.): \nDöntés: változatlan terápia / módosítás\nKövetkező kontroll: ",
  },
  {
    id: "zaroep",
    label: "Záró epikrízis",
    tipus: "fekvobeteg",
    szoveg:
      "Felvétel oka: \nKórlefolyás: \nElvégzett vizsgálatok: \nElvégzett beavatkozások: \nKibocsátási státusz: \nZárődiagnózis: \nGyógyszeres rendelés: \nKontroll: ",
  },
];
