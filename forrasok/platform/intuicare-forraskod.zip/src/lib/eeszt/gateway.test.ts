import { describe, it, expect } from "vitest";
import { NoopAdapter, EesztJirAdapter, getEesztGateway, setEesztGateway } from "./gateway";

describe("NoopAdapter", () => {
  it("minden hívásra ok=true, semmit nem küld kifelé", async () => {
    const g = new NoopAdapter();
    expect((await g.publishSlots([{ appointment_id: "a", resource_id: "r", kezdo_ts: "x", veg_ts: "y" }]))[0]).toMatchObject({ ok: true });
    expect(await g.bookExternal({ appointment_id: "a", resource_id: "r", kezdo_ts: "x", veg_ts: "y" }, {})).toMatchObject({ ok: true });
    expect(await g.cancelExternal("ref", "ok")).toMatchObject({ ok: true });
    expect(await g.pullRemoteChanges("2026-01-01")).toEqual([]);
  });
});

describe("EesztJirAdapter (disabled until configured)", () => {
  it("minden hívásra retryable állapotot ad, amíg nincs konfigurálva", async () => {
    const g = new EesztJirAdapter();
    expect(await g.bookExternal({ appointment_id: "a", resource_id: "r", kezdo_ts: "x", veg_ts: "y" }, {})).toMatchObject({ ok: false, retryable: true });
  });
});

describe("gateway szingleton", () => {
  it("cserélhető set/get-tel", () => {
    const before = getEesztGateway();
    const next = new EesztJirAdapter();
    setEesztGateway(next);
    expect(getEesztGateway()).toBe(next);
    setEesztGateway(before);
  });
});
