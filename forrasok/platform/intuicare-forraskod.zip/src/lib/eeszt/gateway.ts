/**
 * EESZT időpont-szinkron absztrakció.
 *
 * Az adapter mögé minden hívás feature flag (`eeszt_sync_enabled`) mögött
 * fut. A NoopAdapter alapértelmezett: csak naplóz, semmit nem küld kifelé.
 * A JirAdapter (későbbi fázis) a tényleges EESZT JIR-Időpont szolgáltatást
 * fogja hívni, amint a külső kapcsolat konfigurálva van.
 */

export type SlotRef = {
  appointment_id: string;
  resource_id: string;
  kezdo_ts: string;
  veg_ts: string;
};

export type SyncOutcome =
  | { ok: true; external_ref: string }
  | { ok: false; reason: string; retryable: boolean };

export interface EesztAppointmentGateway {
  publishSlots(slots: SlotRef[]): Promise<SyncOutcome[]>;
  bookExternal(slot: SlotRef, patientHint: { taj?: string; nev?: string }): Promise<SyncOutcome>;
  cancelExternal(externalRef: string, reason: string): Promise<SyncOutcome>;
  pullRemoteChanges(sinceIso: string): Promise<{ appointment_id: string; status: string }[]>;
}

export class NoopAdapter implements EesztAppointmentGateway {
  async publishSlots(slots: SlotRef[]): Promise<SyncOutcome[]> {
    return slots.map(() => ({ ok: true, external_ref: "noop" }));
  }
  async bookExternal(_slot: SlotRef, _patientHint: { taj?: string; nev?: string }): Promise<SyncOutcome> {
    return { ok: true, external_ref: "noop" };
  }
  async cancelExternal(_externalRef: string, _reason: string): Promise<SyncOutcome> {
    return { ok: true, external_ref: "noop" };
  }
  async pullRemoteChanges(_sinceIso: string): Promise<{ appointment_id: string; status: string }[]> {
    return [];
  }
}

/**
 * JIR-Időpont adapter — amíg a külső kapcsolat nincs konfigurálva,
 * nem hív hálózatot, hanem újrapróbálható állapotot jelez.
 */
export class EesztJirAdapter implements EesztAppointmentGateway {
  async publishSlots(slots: SlotRef[]): Promise<SyncOutcome[]> {
    return slots.map(() => ({ ok: false, reason: "JIR kapcsolat nincs konfigurálva", retryable: true }));
  }
  async bookExternal(_slot: SlotRef, _patientHint: { taj?: string; nev?: string }): Promise<SyncOutcome> {
    return { ok: false, reason: "JIR kapcsolat nincs konfigurálva", retryable: true };
  }
  async cancelExternal(_externalRef: string, _reason: string): Promise<SyncOutcome> {
    return { ok: false, reason: "JIR kapcsolat nincs konfigurálva", retryable: true };
  }
  async pullRemoteChanges(_sinceIso: string): Promise<{ appointment_id: string; status: string }[]> {
    return [];
  }
}

let _gateway: EesztAppointmentGateway = new NoopAdapter();

export function setEesztGateway(g: EesztAppointmentGateway): void {
  _gateway = g;
}
export function getEesztGateway(): EesztAppointmentGateway {
  return _gateway;
}
