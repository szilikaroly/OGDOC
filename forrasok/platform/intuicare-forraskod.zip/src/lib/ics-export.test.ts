import { describe, it, expect } from "vitest";
import { buildIcs } from "./ics-export";

describe("buildIcs", () => {
  it("creates a valid VCALENDAR with one VEVENT", () => {
    const ics = buildIcs([
      {
        uid: "abc-123",
        startUtc: new Date(Date.UTC(2026, 5, 19, 8, 0, 0)),
        endUtc: new Date(Date.UTC(2026, 5, 19, 16, 0, 0)),
        summary: "Nappali műszak",
        description: "Belgyógyászat",
        location: "A épület, 2. emelet",
      },
    ]);
    expect(ics).toContain("BEGIN:VCALENDAR");
    expect(ics).toContain("END:VCALENDAR");
    expect(ics).toContain("UID:abc-123");
    expect(ics).toContain("DTSTART:20260619T080000Z");
    expect(ics).toContain("DTEND:20260619T160000Z");
    expect(ics).toContain("SUMMARY:Nappali műszak");
  });

  it("escapes commas, semicolons and newlines", () => {
    const ics = buildIcs([
      {
        uid: "x",
        startUtc: new Date(Date.UTC(2026, 0, 1, 0, 0, 0)),
        endUtc: new Date(Date.UTC(2026, 0, 1, 1, 0, 0)),
        summary: "A, B; C\nD",
      },
    ]);
    expect(ics).toContain("SUMMARY:A\\, B\\; C\\nD");
  });

  it("uses CRLF line endings (RFC 5545)", () => {
    const ics = buildIcs([
      {
        uid: "x",
        startUtc: new Date(Date.UTC(2026, 0, 1)),
        endUtc: new Date(Date.UTC(2026, 0, 1, 1)),
        summary: "x",
      },
    ]);
    expect(ics.includes("\r\n")).toBe(true);
  });
});
