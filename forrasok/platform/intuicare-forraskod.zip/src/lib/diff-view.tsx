import { useMemo } from "react";

export type DiffEntry = {
  key: string;
  before: unknown;
  after: unknown;
  kind: "added" | "removed" | "changed" | "unchanged";
};

const IGNORED = new Set(["created_at", "updated_at"]);

function isObj(v: unknown): v is Record<string, unknown> {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}

function eq(a: unknown, b: unknown): boolean {
  if (a === b) return true;
  if (a == null && b == null) return true;
  if (typeof a !== typeof b) return false;
  if (Array.isArray(a) && Array.isArray(b)) {
    if (a.length !== b.length) return false;
    return a.every((v, i) => eq(v, b[i]));
  }
  if (isObj(a) && isObj(b)) {
    const ka = Object.keys(a);
    const kb = Object.keys(b);
    if (ka.length !== kb.length) return false;
    return ka.every((k) => eq(a[k], b[k]));
  }
  return false;
}

export function computeDiff(
  before: Record<string, unknown> | null | undefined,
  after: Record<string, unknown> | null | undefined,
): DiffEntry[] {
  const b = before ?? {};
  const a = after ?? {};
  const keys = Array.from(new Set([...Object.keys(b), ...Object.keys(a)])).sort();
  return keys
    .filter((k) => !IGNORED.has(k))
    .map<DiffEntry>((k) => {
      const bv = b[k];
      const av = a[k];
      if (!(k in b)) return { key: k, before: undefined, after: av, kind: "added" };
      if (!(k in a)) return { key: k, before: bv, after: undefined, kind: "removed" };
      if (eq(bv, av)) return { key: k, before: bv, after: av, kind: "unchanged" };
      return { key: k, before: bv, after: av, kind: "changed" };
    });
}

function fmt(v: unknown): string {
  if (v === null || v === undefined) return "—";
  if (typeof v === "string") return v;
  if (typeof v === "boolean") return v ? "✓" : "✗";
  if (typeof v === "number") return String(v);
  return JSON.stringify(v);
}

export function DiffView({
  before,
  after,
  showUnchanged = false,
}: {
  before: Record<string, unknown> | null | undefined;
  after: Record<string, unknown> | null | undefined;
  showUnchanged?: boolean;
}) {
  const entries = useMemo(() => computeDiff(before, after), [before, after]);
  const visible = showUnchanged ? entries : entries.filter((e) => e.kind !== "unchanged");

  if (visible.length === 0) {
    return <div className="text-xs text-muted-foreground italic">Nincs változás</div>;
  }

  return (
    <div className="rounded-md border border-border overflow-hidden">
      <table className="w-full text-xs font-mono">
        <thead className="bg-secondary text-[10px] uppercase tracking-wider text-muted-foreground">
          <tr>
            <th className="text-left px-2 py-1 w-40">Mező</th>
            <th className="text-left px-2 py-1">Előtte</th>
            <th className="text-left px-2 py-1">Utána</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-border">
          {visible.map((e) => {
            const rowCls =
              e.kind === "added"
                ? "bg-success/5"
                : e.kind === "removed"
                  ? "bg-destructive/5"
                  : e.kind === "changed"
                    ? "bg-warning/5"
                    : "";
            const badge =
              e.kind === "added"
                ? "+ új"
                : e.kind === "removed"
                  ? "− törölt"
                  : e.kind === "changed"
                    ? "~ mód."
                    : "=";
            const badgeCls =
              e.kind === "added"
                ? "bg-success/15 text-success"
                : e.kind === "removed"
                  ? "bg-destructive/15 text-destructive"
                  : e.kind === "changed"
                    ? "bg-warning/15 text-warning"
                    : "bg-muted text-muted-foreground";
            return (
              <tr key={e.key} className={rowCls}>
                <td className="px-2 py-1 align-top">
                  <div className="flex items-center gap-1.5">
                    <span className={`text-[9px] px-1 py-px rounded ${badgeCls}`}>{badge}</span>
                    <span className="font-semibold truncate">{e.key}</span>
                  </div>
                </td>
                <td className="px-2 py-1 align-top text-muted-foreground break-all">
                  {e.kind === "added" ? <span className="italic opacity-50">—</span> : fmt(e.before)}
                </td>
                <td className="px-2 py-1 align-top break-all">
                  {e.kind === "removed" ? <span className="italic opacity-50">—</span> : fmt(e.after)}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
