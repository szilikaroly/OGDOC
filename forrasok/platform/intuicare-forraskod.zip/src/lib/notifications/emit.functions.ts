import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/**
 * Unified patient-facing notification emitter.
 * Resolves patient_id -> linked user_id via patient_users, inserts into
 * notifications. Caller must be authenticated staff.
 */
const Input = z.object({
  patient_id: z.string().uuid().optional(),
  user_id: z.string().uuid().optional(),
  kind: z.enum([
    "new_lab",
    "appointment_scheduled",
    "appointment_cancelled",
    "critical_alert",
    "questionnaire_due",
    "discharge_ready",
    "referral_update",
    "info",
  ]),
  cim: z.string().min(1).max(200),
  uzenet: z.string().max(2000).optional(),
  link: z.string().max(500).optional(),
});

const KIND_TO_TYPE: Record<string, string> = {
  new_lab: "info",
  appointment_scheduled: "success",
  appointment_cancelled: "warning",
  critical_alert: "danger",
  questionnaire_due: "info",
  discharge_ready: "success",
  referral_update: "info",
  info: "info",
};

export const emitPatientNotification = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => Input.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    let userId = data.user_id ?? null;
    if (!userId && data.patient_id) {
      const { data: link } = await supabase
        .from("patient_users")
        .select("user_id")
        .eq("patient_id", data.patient_id)
        .limit(1)
        .maybeSingle();
      userId = link?.user_id ?? null;
    }
    if (!userId) return { ok: false, reason: "no_linked_user" as const };
    const { error } = await supabase.from("notifications").insert({
      user_id: userId,
      tipus: KIND_TO_TYPE[data.kind] ?? "info",
      cim: data.cim,
      uzenet: data.uzenet ?? null,
      link: data.link ?? null,
    });
    if (error) throw new Error(error.message);
    return { ok: true };
  });
