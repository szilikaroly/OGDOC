/**
 * Minimális Resend-alapú e-mail küldő. Csak akkor küld, ha RESEND_API_KEY és EMAIL_FROM
 * env változó be van állítva, különben no-op (skipped=true).
 * server-only modul (.server.ts) — csak edge / server kontextusból importálható.
 */
export type EmailPayload = {
  to: string | string[];
  subject: string;
  html: string;
  text?: string;
  replyTo?: string;
};

export type EmailResult =
  | { ok: true; id?: string; skipped?: false }
  | { ok: false; skipped: true; reason: string }
  | { ok: false; skipped?: false; error: string };

export async function sendEmail(payload: EmailPayload): Promise<EmailResult> {
  const apiKey = process.env.RESEND_API_KEY;
  const from = process.env.EMAIL_FROM;
  if (!apiKey || !from) {
    return { ok: false, skipped: true, reason: "RESEND_API_KEY vagy EMAIL_FROM nincs beállítva" };
  }
  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        from,
        to: Array.isArray(payload.to) ? payload.to : [payload.to],
        subject: payload.subject,
        html: payload.html,
        text: payload.text,
        reply_to: payload.replyTo,
      }),
    });
    if (!res.ok) {
      const t = await res.text().catch(() => "");
      return { ok: false, error: `Resend HTTP ${res.status}: ${t.slice(0, 200)}` };
    }
    const j = (await res.json().catch(() => null)) as { id?: string } | null;
    return { ok: true, id: j?.id };
  } catch (e) {
    return { ok: false, error: (e as Error).message };
  }
}
