/**
 * Global server-function middleware.
 *
 * - Generates a per-call request-id (uuid).
 * - Structured-logs every thrown error with: request_id, function_id, method,
 *   kind, message, stack, timestamp.
 * - Re-throws an Error whose message is suffixed with `[request_id=<uuid>]` so
 *   the client-side error boundary can surface the id without an out-of-band
 *   channel.
 *
 * Pair with `extractRequestId()` in `src/lib/errors/classify.ts` to render the id.
 */
import { createMiddleware } from "@tanstack/react-start";

function newRequestId(): string {
  try {
    if (typeof globalThis.crypto?.randomUUID === "function") {
      return globalThis.crypto.randomUUID();
    }
  } catch {}
  return `r_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
}

function classifyKind(message: string): "forbidden" | "unauthorized" | "error" {
  if (/^forbidden\b|\bpermission denied\b|insufficient_privilege/i.test(message)) {
    return "forbidden";
  }
  if (/^unauthorized\b|invalid token|no authorization header/i.test(message)) {
    return "unauthorized";
  }
  return "error";
}

export const serverFnErrorLogger = createMiddleware({ type: "function" }).server(
  async ({ next, serverFnMeta, method }) => {
    const requestId = newRequestId();
    const functionId = serverFnMeta?.id ?? "unknown";
    try {
      return await next();
    } catch (err) {
      const original = err instanceof Error ? err : new Error(String(err));
      const message = original.message ?? String(err);
      const kind = classifyKind(message);

      try {
        console.error(
          JSON.stringify({
            level: kind === "error" ? "error" : "warn",
            channel: "server_fn",
            request_id: requestId,
            function_id: functionId,
            method,
            kind,
            message,
            stack: original.stack,
            timestamp: new Date().toISOString(),
          }),
        );
      } catch {
        console.error(`[server_fn] ${requestId} ${functionId}: ${message}`);
      }

      if (!/\[request_id=/.test(message)) {
        try {
          original.message = `${message} [request_id=${requestId}]`;
        } catch {
          const wrapped = new Error(`${message} [request_id=${requestId}]`);
          wrapped.stack = original.stack;
          (wrapped as any).cause = original;
          throw wrapped;
        }
      }
      throw original;
    }
  },
);
