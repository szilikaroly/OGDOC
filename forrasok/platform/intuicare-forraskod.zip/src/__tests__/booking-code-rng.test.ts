import { describe, it, expect } from "vitest";
import { generateBookingCode } from "@/lib/booking/slots";

const ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";

describe("generateBookingCode", () => {
  it("produces 10-character codes from the unambiguous alphabet", () => {
    for (let i = 0; i < 100; i++) {
      const code = generateBookingCode();
      expect(code).toHaveLength(10);
      for (const ch of code) {
        expect(ALPHABET).toContain(ch);
      }
    }
  });

  it("excludes ambiguous glyphs (0, 1, I, L, O)", () => {
    for (let i = 0; i < 50; i++) {
      const code = generateBookingCode();
      expect(code).not.toMatch(/[01ILO]/);
    }
  });

  it("respects an injected deterministic rand for tests", () => {
    const code = generateBookingCode(() => 0);
    expect(code).toBe(ALPHABET[0].repeat(10));
  });

  it("has high uniqueness over 2000 samples (>99.5%)", () => {
    const seen = new Set<string>();
    for (let i = 0; i < 2000; i++) seen.add(generateBookingCode());
    expect(seen.size / 2000).toBeGreaterThan(0.995);
  });

  it("distribution is reasonably uniform across the alphabet", () => {
    const counts = new Map<string, number>();
    for (let i = 0; i < 500; i++) {
      for (const ch of generateBookingCode()) {
        counts.set(ch, (counts.get(ch) ?? 0) + 1);
      }
    }
    // 500 * 10 = 5000 characters across 31 letters → expected ≈ 161/letter.
    // Require each letter to appear at least a handful of times; this would
    // fail loudly if Math.random snuck back in with a constant seed.
    for (const ch of ALPHABET) {
      expect(counts.get(ch) ?? 0).toBeGreaterThan(20);
    }
  });
});
