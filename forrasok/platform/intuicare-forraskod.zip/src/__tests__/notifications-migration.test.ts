/**
 * Static verification of the questionnaire->critical-alert migration
 * and the patient-facing notification triggers. We assert the SQL
 * encodes the expected behavior so an accidental edit (removing a
 * branch, changing the destination link, etc.) fails CI.
 */
import { describe, it, expect } from "vitest";
import { readFileSync, readdirSync } from "node:fs";
import { join } from "node:path";

function readMigration(match: RegExp): string {
  const dir = "supabase/migrations";
  const file = readdirSync(dir)
    .filter((f) => f.endsWith(".sql"))
    .find((f) => match.test(readFileSync(join(dir, f), "utf8")));
  if (!file) throw new Error(`No migration matched ${match}`);
  return readFileSync(join(dir, file), "utf8");
}

describe("questionnaire_response → critical_alert migration", () => {
  const sql = readMigration(/evaluate_questionnaire_red_flag/);

  it("creates the trigger on questionnaire_responses (AFTER INSERT)", () => {
    expect(sql).toMatch(/create trigger\s+trg_questionnaire_response_red_flag/i);
    expect(sql).toMatch(/after insert on public\.questionnaire_responses/i);
  });

  it("evaluates both _red_flag and _score_critical flags", () => {
    expect(sql).toMatch(/_red_flag/);
    expect(sql).toMatch(/_score_critical/);
  });

  it("inserts into clinical_critical_alerts with patient_id and code", () => {
    expect(sql).toMatch(/insert into public\.clinical_critical_alerts/i);
    expect(sql).toMatch(/'questionnaire_red_flag'/);
    expect(sql).toMatch(/'patient_questionnaire'/);
  });

  it("escalates severity to 'high' when score is critical, else 'medium'", () => {
    expect(sql).toMatch(/v_score_critical\s+then\s+'high'\s+else\s+'medium'/i);
  });

  it("uses SECURITY DEFINER with explicit search_path", () => {
    expect(sql).toMatch(/security definer/i);
    expect(sql).toMatch(/set search_path = public/i);
  });
});

describe("patient notification routing", () => {
  const sql = readMigration(/notify_patient_user/);

  const cases: Array<{ name: string; trigger: RegExp; link: string; severity?: string }> = [
    {
      name: "critical alert",
      trigger: /trg_critical_alert_notify[\s\S]+?clinical_critical_alerts/i,
      link: "/portal/leletek",
      severity: "danger",
    },
    {
      name: "abnormal lab observation",
      trigger: /trg_observation_abnormal_notify[\s\S]+?clinical_observations/i,
      link: "/portal/leletek",
    },
    {
      name: "appointment booked",
      trigger: /trg_appointment_booked_notify[\s\S]+?appointments/i,
      link: "/portal/idopontok",
    },
    {
      name: "followup enrolled",
      trigger: /trg_followup_enrolled_notify[\s\S]+?followup_enrollments/i,
      link: "/portal",
    },
  ];

  for (const c of cases) {
    it(`wires the ${c.name} trigger to notify_patient_user with link ${c.link}`, () => {
      expect(sql).toMatch(c.trigger);
      expect(sql).toMatch(new RegExp(c.link.replace(/\//g, "\\/")));
    });
  }

  it("only escalates critical/high severities for critical alerts", () => {
    expect(sql).toMatch(/severity\s+IN\s*\(\s*'critical'\s*,\s*'high'\s*\)/i);
  });

  it("only escalates abnormal interpretations (H/HH/L/LL/A/AA)", () => {
    expect(sql).toMatch(/interpretation\s+IN\s*\(\s*'H'\s*,\s*'HH'\s*,\s*'L'\s*,\s*'LL'\s*,\s*'A'\s*,\s*'AA'\s*\)/i);
  });

  it("notify_patient_user looks up linked patient_users.user_id", () => {
    expect(sql).toMatch(/from public\.patient_users[\s\S]+?where patient_id = _patient_id/i);
  });
});
