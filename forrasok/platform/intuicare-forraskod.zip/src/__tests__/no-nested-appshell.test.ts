import { describe, it, expect } from "vitest";
import { readdirSync, readFileSync, statSync } from "node:fs";
import { join } from "node:path";

function walk(dir: string): string[] {
  const out: string[] = [];
  for (const entry of readdirSync(dir)) {
    const full = join(dir, entry);
    const st = statSync(full);
    if (st.isDirectory()) {
      out.push(...walk(full));
    } else if (/\.(tsx?|jsx?)$/.test(entry)) {
      out.push(full);
    }
  }
  return out;
}

describe("no nested AppShell under _authenticated", () => {
  it("only _authenticated/route.tsx may import or render <AppShell>", () => {
    const root = "src/routes/_authenticated";
    const allowed = join(root, "route.tsx").replace(/\\/g, "/");
    const offenders: string[] = [];

    for (const file of walk(root)) {
      const normalized = file.replace(/\\/g, "/");
      if (normalized === allowed) continue;
      const src = readFileSync(file, "utf8");
      const importsAppShell = /from\s+["']@\/components\/app-shell["']/.test(src);
      const rendersAppShell = /<AppShell[\s/>]/.test(src);
      if (importsAppShell || rendersAppShell) {
        offenders.push(normalized);
      }
    }

    expect(
      offenders,
      `Ezek a route fájlok újra becsomagolják az AppShell-t (dupla sidebar/fejléc/AiAssistant):\n${offenders.join("\n")}`,
    ).toEqual([]);
  });
});
