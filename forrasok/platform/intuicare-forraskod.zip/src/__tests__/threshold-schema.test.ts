import { describe, it, expect } from "vitest";
import { ThresholdFormSchema } from "@/lib/monitoring/threshold-schema";

describe("ThresholdFormSchema", () => {
  it("accepts a valid threshold", () => {
    const r = ThresholdFormSchema.safeParse({
      kulcs: "vernyomas_sys_max",
      ertek: 140,
      unit: "mmHg",
      megjegyzes: "alap",
      patient_id: null,
    });
    expect(r.success).toBe(true);
  });

  it("rejects a non-finite or out-of-range value", () => {
    const r = ThresholdFormSchema.safeParse({ kulcs: "pulzus_max", ertek: Number.NaN });
    expect(r.success).toBe(false);
    const r2 = ThresholdFormSchema.safeParse({ kulcs: "pulzus_max", ertek: 1_000_000 });
    expect(r2.success).toBe(false);
  });

  it("rejects an invalid kulcs (spaces / punctuation)", () => {
    const r = ThresholdFormSchema.safeParse({ kulcs: "vér nyomás!", ertek: 120 });
    expect(r.success).toBe(false);
  });

  it("rejects too short kulcs", () => {
    const r = ThresholdFormSchema.safeParse({ kulcs: "a", ertek: 1 });
    expect(r.success).toBe(false);
  });

  it("rejects an invalid patient_id UUID", () => {
    const r = ThresholdFormSchema.safeParse({ kulcs: "pulzus_max", ertek: 90, patient_id: "not-a-uuid" });
    expect(r.success).toBe(false);
  });

  it("allows empty patient_id and empty unit", () => {
    const r = ThresholdFormSchema.safeParse({ kulcs: "pulzus_max", ertek: 90, patient_id: "", unit: null });
    expect(r.success).toBe(true);
  });
});
