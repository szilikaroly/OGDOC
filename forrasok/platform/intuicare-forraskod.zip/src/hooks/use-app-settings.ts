/**
 * Publikus beállítások cliens hook — branding, megjelenés, modulkapcsolók.
 */
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getPublicSettings } from "@/lib/admin/settings.functions";
import { getSettingDef } from "@/lib/admin/settings-catalog";

export function useAppSettings() {
  const fetcher = useServerFn(getPublicSettings);
  return useQuery({
    queryKey: ["app-settings", "public"],
    queryFn: () => fetcher(),
    staleTime: 5 * 60 * 1000,
  });
}

export function useSetting<T = unknown>(namespace: string, key: string): T {
  const { data } = useAppSettings();
  const def = getSettingDef(namespace, key);
  const fallback = (def?.default ?? null) as T;
  const v = (data?.[`${namespace}.${key}`] as T | undefined);
  return (v ?? fallback) as T;
}
