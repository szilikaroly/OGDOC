import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

/**
 * Returns the count of unread (olvasott_at IS NULL) notifications for the current user.
 * Refetches every 60s and on window focus.
 */
export function useUnreadNotifications() {
  return useQuery({
    queryKey: ["portal", "notifications", "unread-count"],
    queryFn: async () => {
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) return 0;
      const { count } = await supabase
        .from("notifications")
        .select("id", { count: "exact", head: true })
        .eq("user_id", u.user.id)
        .is("olvasott_at", null);
      return count ?? 0;
    },
    refetchInterval: 60_000,
    refetchOnWindowFocus: true,
    staleTime: 30_000,
  });
}
