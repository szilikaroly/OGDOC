/**
 * Autosave hook for the CMS block inspector.
 *
 * - Persists every change into `localStorage` immediately (crash-safe draft).
 * - Debounces server saves (default 1500ms) once the value is a valid JSON.
 * - Exposes `status`: "idle" | "dirty" | "saving" | "saved" | "error".
 * - Provides `restoreLocalDraft()` and `clearLocalDraft()` helpers so the
 *   UI can offer the user to recover an unsaved draft after a page reload.
 */
import { useCallback, useEffect, useRef, useState } from "react";

type Status = "idle" | "dirty" | "saving" | "saved" | "error";

export function useAutosaveDraft({
  storageKey,
  value,
  parse,
  save,
  delay = 1500,
  enabled = true,
}: {
  storageKey: string;
  value: string;
  parse: (raw: string) => any;
  save: (parsed: any) => Promise<void>;
  delay?: number;
  enabled?: boolean;
}) {
  const [status, setStatus] = useState<Status>("idle");
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [lastSavedAt, setLastSavedAt] = useState<number | null>(null);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const initialRef = useRef<string>(value);
  const mountedRef = useRef(true);

  // Reset baseline when key changes (e.g. selecting another block)
  useEffect(() => {
    initialRef.current = value;
    setStatus("idle");
    setErrorMsg(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [storageKey]);

  useEffect(() => () => {
    mountedRef.current = false;
    if (timerRef.current) clearTimeout(timerRef.current);
  }, []);

  useEffect(() => {
    if (!enabled) return;
    if (value === initialRef.current) return;

    // 1) immediate local persist
    try {
      localStorage.setItem(storageKey, JSON.stringify({ v: value, t: Date.now() }));
    } catch { /* quota — ignore */ }

    setStatus("dirty");

    // 2) debounced remote save
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(async () => {
      let parsed: any;
      try {
        parsed = parse(value);
      } catch (e: any) {
        setStatus("error");
        setErrorMsg(e?.message ?? "Érvénytelen JSON");
        return;
      }
      setStatus("saving");
      try {
        await save(parsed);
        if (!mountedRef.current) return;
        setStatus("saved");
        setErrorMsg(null);
        setLastSavedAt(Date.now());
        initialRef.current = value;
      } catch (e: any) {
        if (!mountedRef.current) return;
        setStatus("error");
        setErrorMsg(e?.message?.slice(0, 200) ?? "Mentés sikertelen");
      }
    }, delay);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value, storageKey, enabled]);

  const restoreLocalDraft = useCallback((): { value: string; savedAt: number } | null => {
    try {
      const raw = localStorage.getItem(storageKey);
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      if (typeof parsed?.v !== "string") return null;
      return { value: parsed.v, savedAt: parsed.t ?? 0 };
    } catch {
      return null;
    }
  }, [storageKey]);

  const clearLocalDraft = useCallback(() => {
    try { localStorage.removeItem(storageKey); } catch { /* noop */ }
  }, [storageKey]);

  return { status, errorMsg, lastSavedAt, restoreLocalDraft, clearLocalDraft };
}
