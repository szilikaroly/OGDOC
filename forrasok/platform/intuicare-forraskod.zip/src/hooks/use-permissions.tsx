import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { useViewAs, VIEW_AS_PERMS } from "@/hooks/use-view-as";

export type PermissionKey =
  | "manage_tenant"
  | "manage_org"
  | "manage_roles"
  | "manage_schedule"
  | "manage_training"
  | "manage_patients"
  | "view_audit"
  | "view_team"
  | "view_or_board"
  | "manage_or_blocks"
  | "book_or_case"
  | "sign_off_or_case"
  | "trigger_or_emergency"
  | "manage_worktime"
  | "manage_eusztv";

const ALL_PERMISSIONS: PermissionKey[] = [
  "manage_tenant",
  "manage_org",
  "manage_roles",
  "manage_schedule",
  "manage_training",
  "manage_patients",
  "view_audit",
  "view_team",
  "view_or_board",
  "manage_or_blocks",
  "book_or_case",
  "sign_off_or_case",
  "trigger_or_emergency",
  "manage_worktime",
  "manage_eusztv",
];

export function usePermissions() {
  const { user, loading: authLoading } = useAuth();
  const { mode } = useViewAs();
  const [perms, setPerms] = useState<Record<PermissionKey, boolean> | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (authLoading) return;
    if (!user) {
      setPerms(null);
      setLoading(false);
      return;
    }
    let cancelled = false;
    (async () => {
      setLoading(true);
      const results = await Promise.all(
        ALL_PERMISSIONS.map((p) =>
          supabase
            .rpc("has_permission", { _user_id: user.id, _perm: p })
            .then(({ data }) => [p, Boolean(data)] as const),
        ),
      );
      if (cancelled) return;
      setPerms(Object.fromEntries(results) as Record<PermissionKey, boolean>);
      setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [user, authLoading]);

  // Real permission check (ignores view-as simulation).
  function canReal(p: PermissionKey): boolean {
    return Boolean(perms?.[p]);
  }

  // UI permission check — respects the admin's view-as simulation.
  // Simulation can only *hide* capabilities, never grant new ones.
  function can(p: PermissionKey): boolean {
    if (mode !== "self") {
      const allowed = VIEW_AS_PERMS[mode];
      return canReal(p) && allowed.includes(p);
    }
    return canReal(p);
  }

  return { perms, loading, can, canReal };
}
