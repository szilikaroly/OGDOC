import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { translateBatch, translateInline } from "@/lib/i18n/translate.functions";
import { supabase } from "@/integrations/supabase/client";

/**
 * Translate a single piece of free-text content (DB-sourced) to the current language.
 * Returns the original text until the translation arrives.
 */
export function useTranslatedText(text: string | null | undefined, namespace = "content"): string {
  const { i18n } = useTranslation();
  const lng = i18n.language?.split("-")[0] ?? "hu";
  const [out, setOut] = useState<string>(text ?? "");

  useEffect(() => {
    if (!text) {
      setOut("");
      return;
    }
    if (lng === "hu") {
      setOut(text);
      return;
    }
    let cancelled = false;
    setOut(text);
    (async () => {
      try {
        // translateBatch requires auth — skip on public pages when signed out.
        const { data: { session } } = await supabase.auth.getSession();
        if (!session?.access_token) return;
        const key = `${namespace}_${btoa(unescape(encodeURIComponent(text))).slice(0, 64)}`;
        const r = await translateBatch({
          data: {
            items: [{ key, source: text, namespace }],
            target_lang: lng,
            kind: "content",
          },
        });
        if (!cancelled && r[key]) setOut(r[key]);
      } catch {
        /* keep original */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [text, lng, namespace]);

  return out;
}

/**
 * One-shot inline translation, for buttons/popovers.
 */
export async function translateOnce(text: string, targetLang: string): Promise<string> {
  if (!text) return "";
  if (targetLang === "hu") return text;
  const { data: { session } } = await supabase.auth.getSession();
  if (!session?.access_token) return text;
  const r = await translateInline({ data: { text, target_lang: targetLang } });
  return r.translation;
}
