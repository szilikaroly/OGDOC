import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { classifyUser } from "@/lib/portal/user-classification.functions";
import { targetForClassification, type RoleTarget } from "@/lib/portal/role-target";

/**
 * Kliensoldali hook: visszaadja a jelenlegi user szerepkörének megfelelő
 * célútvonalat ÉS azt, hogy be van-e jelentkezve. Vendég → null.
 */
export function useCurrentUserTarget(): {
  isAuthenticated: boolean;
  target: RoleTarget | null;
  loading: boolean;
} {
  const [hasSession, setHasSession] = useState<boolean | null>(null);

  useEffect(() => {
    let mounted = true;
    supabase.auth.getSession().then(({ data }) => {
      if (mounted) setHasSession(!!data.session);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === "SIGNED_IN" || event === "SIGNED_OUT" || event === "USER_UPDATED") {
        setHasSession(!!session);
      }
    });
    return () => {
      mounted = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  const classify = useServerFn(classifyUser);
  const { data: cls, isLoading } = useQuery({
    queryKey: ["me", "target"],
    queryFn: () => classify(),
    staleTime: 60_000,
    enabled: hasSession === true,
  });

  if (hasSession === null) return { isAuthenticated: false, target: null, loading: true };
  if (!hasSession) return { isAuthenticated: false, target: null, loading: false };
  return {
    isAuthenticated: true,
    target: cls ? targetForClassification(cls) : null,
    loading: isLoading,
  };
}
