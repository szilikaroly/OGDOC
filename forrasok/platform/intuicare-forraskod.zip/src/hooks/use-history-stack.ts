/**
 * Simple undo/redo history for the visual editor.
 *
 * Stores inverse operations (thunks) that reverse the effect of a completed
 * mutation. Ctrl+Z pops from `undo`, runs the inverse, and pushes onto `redo`.
 * The caller is responsible for producing inverse thunks that call server fns.
 */
import { useCallback, useEffect, useRef, useState } from "react";

export type HistoryEntry = {
  label: string;
  undo: () => Promise<void> | void;
  redo: () => Promise<void> | void;
};

const MAX = 30;

export function useHistoryStack() {
  const [past, setPast] = useState<HistoryEntry[]>([]);
  const [future, setFuture] = useState<HistoryEntry[]>([]);
  const runningRef = useRef(false);

  const push = useCallback((entry: HistoryEntry) => {
    setPast((p) => [...p.slice(-MAX + 1), entry]);
    setFuture([]);
  }, []);

  const undo = useCallback(async () => {
    if (runningRef.current) return;
    const entry = past[past.length - 1];
    if (!entry) return;
    runningRef.current = true;
    try {
      await entry.undo();
      setPast((p) => p.slice(0, -1));
      setFuture((f) => [...f, entry]);
    } finally {
      runningRef.current = false;
    }
  }, [past]);

  const redo = useCallback(async () => {
    if (runningRef.current) return;
    const entry = future[future.length - 1];
    if (!entry) return;
    runningRef.current = true;
    try {
      await entry.redo();
      setFuture((f) => f.slice(0, -1));
      setPast((p) => [...p, entry]);
    } finally {
      runningRef.current = false;
    }
  }, [future]);

  const clear = useCallback(() => { setPast([]); setFuture([]); }, []);

  // Keyboard shortcuts
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      const tag = target?.tagName?.toLowerCase();
      // Allow undo/redo everywhere; skip only inside plain text fields where
      // the browser's native text undo is more useful.
      if (tag === "input" || tag === "textarea" || target?.isContentEditable) return;
      if (!(e.ctrlKey || e.metaKey)) return;
      if (e.key === "z" && !e.shiftKey) { e.preventDefault(); void undo(); }
      else if ((e.key === "z" && e.shiftKey) || e.key === "y") { e.preventDefault(); void redo(); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [undo, redo]);

  return {
    push, undo, redo, clear,
    canUndo: past.length > 0,
    canRedo: future.length > 0,
    undoLabel: past[past.length - 1]?.label ?? null,
    redoLabel: future[future.length - 1]?.label ?? null,
  };
}
