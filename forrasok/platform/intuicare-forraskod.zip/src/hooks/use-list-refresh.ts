import { useCallback } from "react";
import { useQueryClient, type QueryKey } from "@tanstack/react-query";

/**
 * Lista pull-to-refresh helper.
 * A megadott query key(ek)re invalidate-et hív, majd megvárja az aktív
 * refetch-eket — a Suspense boundary nem esik szét, a scroll megőrződik.
 * Prefix-match: a ["posts"] kulcs a ["posts", 1] cache-eket is frissíti.
 */
export function useListRefresh(keys: QueryKey[]) {
  const qc = useQueryClient();
  const serialized = JSON.stringify(keys);
  return useCallback(async () => {
    const parsed: QueryKey[] = JSON.parse(serialized);
    await Promise.all(parsed.map((k) => qc.invalidateQueries({ queryKey: k })));
    await qc.refetchQueries({
      type: "active",
      predicate: (q) => parsed.some((k) => isPrefix(q.queryKey, k)),
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [qc, serialized]);
}

function isPrefix(queryKey: readonly unknown[], prefix: QueryKey): boolean {
  if (!Array.isArray(prefix)) return false;
  if (prefix.length > queryKey.length) return false;
  for (let i = 0; i < prefix.length; i++) {
    if (JSON.stringify(queryKey[i]) !== JSON.stringify(prefix[i])) return false;
  }
  return true;
}
