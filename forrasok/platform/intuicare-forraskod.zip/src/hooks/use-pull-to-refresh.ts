import { useEffect, useRef, useState } from "react";

/**
 * Pull-to-refresh hook mobil lista oldalakhoz.
 * Csak touch-eszközökön aktív, csak akkor húz, ha a scroll a tetején van.
 *
 * Használat:
 *   const { bind, pulling, progress } = usePullToRefresh(async () => {
 *     await refetch();
 *   });
 *   return <div {...bind}>{pulling && <Indicator progress={progress} />}...</div>;
 */
export function usePullToRefresh(onRefresh: () => Promise<void> | void, threshold = 70) {
  const startY = useRef<number | null>(null);
  const [pulling, setPulling] = useState(false);
  const [progress, setProgress] = useState(0);
  const refreshingRef = useRef(false);

  function findScrollParent(node: HTMLElement | null): HTMLElement | null {
    let el: HTMLElement | null = node;
    while (el && el !== document.body) {
      const s = window.getComputedStyle(el);
      if (/(auto|scroll|overlay)/.test(s.overflowY) && el.scrollHeight > el.clientHeight) return el;
      el = el.parentElement;
    }
    return null;
  }

  function onTouchStart(e: React.TouchEvent) {
    if (refreshingRef.current) return;
    const el = e.currentTarget as HTMLElement;
    const scroller = findScrollParent(el);
    if (scroller) {
      if (scroller.scrollTop > 0) return;
    } else if (typeof window !== "undefined" && (window.scrollY || document.documentElement.scrollTop || 0) > 0) {
      return;
    }
    startY.current = e.touches[0].clientY;
  }
  function onTouchMove(e: React.TouchEvent) {
    if (startY.current == null || refreshingRef.current) return;
    const dy = e.touches[0].clientY - startY.current;
    if (dy <= 0) return;
    const p = Math.min(1, dy / (threshold * 1.5));
    setPulling(true);
    setProgress(p);
  }
  async function onTouchEnd() {
    if (refreshingRef.current) return;
    const trigger = progress >= 1 || progress >= threshold / (threshold * 1.5);
    startY.current = null;
    if (trigger && pulling) {
      refreshingRef.current = true;
      try {
        await onRefresh();
      } finally {
        refreshingRef.current = false;
        setPulling(false);
        setProgress(0);
      }
    } else {
      setPulling(false);
      setProgress(0);
    }
  }

  useEffect(() => () => { refreshingRef.current = false; }, []);

  return {
    pulling,
    progress,
    bind: { onTouchStart, onTouchMove, onTouchEnd, style: { overscrollBehaviorY: "contain" as const } },
  };
}
