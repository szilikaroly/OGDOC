import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import type { PermissionKey } from "@/hooks/use-permissions";

export type ViewAsMode = "self" | "orvos" | "noverkereszt" | "paciens";

export const VIEW_AS_LABELS: Record<ViewAsMode, string> = {
  self: "Saját nézet (admin)",
  orvos: "Orvos",
  noverkereszt: "Nővérkereszt / műszakvezető",
  paciens: "Páciens",
};

// UI-only permission masks per simulated role.
// "self" means: no override, use real permissions.
export const VIEW_AS_PERMS: Record<Exclude<ViewAsMode, "self">, PermissionKey[]> = {
  // Orvos: betegellátás + saját beosztás megtekintése (NEM generálhat / szerkeszthet beosztást)
  orvos: ["manage_patients", "view_team"],
  noverkereszt: ["manage_schedule", "view_team"],
  paciens: [],
};

type Ctx = {
  mode: ViewAsMode;
  setMode: (m: ViewAsMode) => void;
  isSimulating: boolean;
};

const ViewAsContext = createContext<Ctx>({
  mode: "self",
  setMode: () => {},
  isSimulating: false,
});

const STORAGE_KEY = "viewAsMode";

export function ViewAsProvider({ children }: { children: ReactNode }) {
  const [mode, setModeState] = useState<ViewAsMode>("self");

  useEffect(() => {
    if (typeof window === "undefined") return;
    const stored = sessionStorage.getItem(STORAGE_KEY) as ViewAsMode | null;
    if (stored && stored in VIEW_AS_LABELS) setModeState(stored);
  }, []);

  function setMode(m: ViewAsMode) {
    setModeState(m);
    if (typeof window !== "undefined") {
      if (m === "self") sessionStorage.removeItem(STORAGE_KEY);
      else sessionStorage.setItem(STORAGE_KEY, m);
    }
  }

  return (
    <ViewAsContext.Provider value={{ mode, setMode, isSimulating: mode !== "self" }}>
      {children}
    </ViewAsContext.Provider>
  );
}

export function useViewAs() {
  return useContext(ViewAsContext);
}
