/**
 * View Transitions API integráció TanStack Router-rel.
 *
 * A router `onBeforeNavigate` eseményén elindítunk egy view-transition-t, és
 * a callback promise-ét addig tartjuk nyitva, amíg a router `onResolved`
 * eseménye jelzi, hogy az új route ténylegesen kirenderelt. Így nem fut bele
 * a böngésző a "Transition was aborted because of timeout in DOM update"
 * hibába async loaderek esetén.
 *
 * Csak akkor aktív, ha a böngésző támogatja és nincs reduced motion.
 */
import { useEffect } from "react";
import { useRouter } from "@tanstack/react-router";

export function useViewTransitions() {
  const router = useRouter();
  useEffect(() => {
    if (typeof document === "undefined") return;
    const supports = typeof (document as any).startViewTransition === "function";
    if (!supports) return;
    const reduced = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
    if (reduced) return;

    let resolveDom: (() => void) | null = null;
    let safetyTimer: ReturnType<typeof setTimeout> | null = null;

    const finish = () => {
      if (safetyTimer) { clearTimeout(safetyTimer); safetyTimer = null; }
      const r = resolveDom;
      resolveDom = null;
      r?.();
    };

    const unsubBefore = router.subscribe("onBeforeNavigate", (e: any) => {
      if (e?.toLocation?.pathname === e?.fromLocation?.pathname) return;
      // Ha még fut egy előző átmenet, engedjük lezárulni azonnal.
      finish();
      const startVT = (document as any).startViewTransition?.bind(document);
      if (!startVT) return;
      const vt = startVT(
        () =>
          new Promise<void>((r) => {
            resolveDom = r;
            // Biztonsági időzítő – ha valami elakad, ne fagyjon be az UI.
            safetyTimer = setTimeout(() => finish(), 800);
          }),
      );
      // A böngésző abort-ját (pl. új navigáció) nem tekintjük hibának.
      vt?.finished?.catch?.(() => { /* silent */ });
      vt?.ready?.catch?.(() => { /* silent */ });
    });

    const unsubResolved = router.subscribe("onResolved", () => {
      // Egy frame múlva már biztosan kirenderelt a DOM.
      requestAnimationFrame(() => finish());
    });

    return () => {
      unsubBefore();
      unsubResolved();
      finish();
    };
  }, [router]);
}
