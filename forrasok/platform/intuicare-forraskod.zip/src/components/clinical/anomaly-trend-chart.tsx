import { useMemo } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, ReferenceDot, CartesianGrid } from "recharts";
import { detectAnomalies } from "@/lib/clinical/anomaly";

type Props = {
  series: { ts: string; value: number }[];
  label?: string;
  unit?: string;
  height?: number;
  threshold?: number;
};

/**
 * Mérési trendgrafikon median+MAD alapú anomália-jelöléssel.
 * A piros pontok |z| >= threshold (default 2) értékeket jelzik.
 */
export function AnomalyTrendChart({ series, label, unit, height = 220, threshold = 2 }: Props) {
  const data = useMemo(() => {
    const detected = detectAnomalies(series, { threshold });
    return detected.map((d) => ({
      ts: d.ts,
      tsLabel: new Date(d.ts).toLocaleDateString("hu-HU"),
      value: d.value,
      z: d.z,
      isAnomaly: d.isAnomaly,
    }));
  }, [series, threshold]);

  const anomalies = data.filter((d) => d.isAnomaly);

  if (data.length === 0) {
    return <div className="text-sm text-muted-foreground p-4">Nincs adat.</div>;
  }

  return (
    <div>
      {label && (
        <div className="flex items-center justify-between mb-2">
          <div className="text-sm font-medium">{label}</div>
          {anomalies.length > 0 && (
            <div className="text-xs text-destructive">
              {anomalies.length} anomália (|z|≥{threshold})
            </div>
          )}
        </div>
      )}
      <ResponsiveContainer width="100%" height={height}>
        <LineChart data={data} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
          <XAxis dataKey="tsLabel" tick={{ fontSize: 11 }} />
          <YAxis tick={{ fontSize: 11 }} unit={unit ? ` ${unit}` : undefined} />
          <Tooltip
            formatter={(v: any, _name, p: any) => [
              `${v}${unit ? " " + unit : ""}${p?.payload?.isAnomaly ? `  (z=${p.payload.z.toFixed(2)})` : ""}`,
              label ?? "Érték",
            ]}
          />
          <Line
            type="monotone"
            dataKey="value"
            stroke="hsl(var(--primary))"
            strokeWidth={2}
            dot={{ r: 3 }}
            activeDot={{ r: 5 }}
            isAnimationActive={false}
          />
          {anomalies.map((a) => (
            <ReferenceDot
              key={a.ts}
              x={a.tsLabel}
              y={a.value}
              r={5}
              fill="hsl(var(--destructive))"
              stroke="hsl(var(--destructive))"
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
