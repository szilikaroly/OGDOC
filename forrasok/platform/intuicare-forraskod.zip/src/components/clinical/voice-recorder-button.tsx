import { useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Mic, MicOff, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { transcribeClinicalAudio } from "@/lib/clinical/voice-intake.functions";

interface VoiceRecorderButtonProps {
  onResult: (text: string) => void;
  className?: string;
  title?: string;
  disabled?: boolean;
}

/**
 * Klinikai hang-alapú diktáláshoz: MediaRecorder → base64 → szerver STT.
 * Az `onResult` callbackben a magyar szöveg érkezik (fordítva, ha kellett).
 */
export function VoiceRecorderButton({ onResult, className, title, disabled }: VoiceRecorderButtonProps) {
  const transcribe = useServerFn(transcribeClinicalAudio);
  const [recording, setRecording] = useState(false);
  const [processing, setProcessing] = useState(false);
  const mediaRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  async function start() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const preferred = ["audio/webm;codecs=opus", "audio/webm", "audio/mp4"];
      const mime = preferred.find((m) => (window as any).MediaRecorder?.isTypeSupported?.(m)) ?? "";
      const recorder = mime ? new MediaRecorder(stream, { mimeType: mime }) : new MediaRecorder(stream);
      chunksRef.current = [];
      recorder.ondataavailable = (e) => { if (e.data.size > 0) chunksRef.current.push(e.data); };
      recorder.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        const type = recorder.mimeType || "audio/webm";
        const blob = new Blob(chunksRef.current, { type });
        await process(blob, type);
      };
      recorder.start();
      mediaRef.current = recorder;
      setRecording(true);
    } catch {
      toast.error("Nem sikerült megnyitni a mikrofont. Ellenőrizd a böngésző jogosultságokat.");
    }
  }

  function stop() {
    try { mediaRef.current?.stop(); } catch { /* noop */ }
    setRecording(false);
  }

  async function process(blob: Blob, mime: string) {
    if (blob.size < 2048) {
      toast.error("A felvétel túl rövid vagy néma. Próbáld újra.");
      return;
    }
    setProcessing(true);
    try {
      const b64 = await blobToBase64(blob);
      const res = await transcribe({ data: { audio_base64: b64, mime } });
      const text = (res.translated_text || res.original_text || "").trim();
      if (!text) toast.error("Nem sikerült átiratozni a felvételt.");
      else onResult(text);
    } catch (e: any) {
      toast.error(e?.message ?? "Átiratozási hiba");
    } finally {
      setProcessing(false);
    }
  }

  const base = "inline-flex items-center justify-center rounded-md border border-border min-h-11 min-w-11 p-2 text-sm transition disabled:opacity-50";
  if (processing) {
    return (
      <button type="button" disabled className={`${base} ${className ?? ""}`} title="Átiratozás…">
        <Loader2 className="h-4 w-4 animate-spin" />
      </button>
    );
  }
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={recording ? stop : start}
      className={`${base} ${recording ? "bg-destructive text-destructive-foreground border-destructive animate-pulse" : "bg-background hover:bg-accent"} ${className ?? ""}`}
      title={title ?? (recording ? "Felvétel leállítása" : "Hangdiktálás indítása")}
      aria-pressed={recording}
    >
      {recording ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
    </button>
  );
}

function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const s = String(reader.result ?? "");
      const comma = s.indexOf(",");
      resolve(comma >= 0 ? s.slice(comma + 1) : s);
    };
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(blob);
  });
}
