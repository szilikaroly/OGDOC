import { Link, useSearch } from "@tanstack/react-router";
import { useState, type ReactNode } from "react";
import { ArrowLeft, Save, Loader2, RotateCcw } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { toast } from "sonner";

export type SaveBundle = {
  calculator: string;
  inputs: unknown;
  outputs: unknown;
  interpretation_md: string;
};

export function CalculatorShell(props: {
  title: string;
  subtitle?: string;
  Icon: any;
  fromRoute: string;
  onReset: () => void;
  getSaveBundle: () => SaveBundle | null;
  children: ReactNode;
}) {
  const { user } = useAuth();
  const search = useSearch({ from: props.fromRoute as any }) as { encounterId?: string; patientId?: string };
  const { encounterId, patientId } = search;
  const [saving, setSaving] = useState(false);

  async function save() {
    const bundle = props.getSaveBundle();
    if (!bundle) {
      toast.error("Tölts ki minden szükséges mezőt");
      return;
    }
    if (!user || !encounterId || !patientId) {
      toast.error("Nincs aktív ellátási epizód");
      return;
    }
    setSaving(true);
    try {
      const { error } = await supabase.from("clinical_calculator_results").insert({
        encounter_id: encounterId,
        patient_id: patientId,
        calculator: bundle.calculator,
        inputs_json: bundle.inputs as any,
        outputs_json: bundle.outputs as any,
        interpretation_md: bundle.interpretation_md,
        created_by: user.id,
      });
      if (error) throw error;
      toast.success("Mentve a betegkartonhoz");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Mentés sikertelen");
    } finally {
      setSaving(false);
    }
  }

  const Icon = props.Icon;
  return (
    <div className="container max-w-6xl py-6 space-y-4">
      <header className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <Link to="/klinika/eszkozok" className="text-xs text-muted-foreground hover:underline flex items-center gap-1">
            <ArrowLeft className="h-3 w-3" /> Eszközök
          </Link>
          <h1 className="text-2xl font-semibold mt-1 flex items-center gap-2">
            <Icon className="h-6 w-6 text-primary" /> {props.title}
          </h1>
          {props.subtitle && <p className="text-sm text-muted-foreground">{props.subtitle}</p>}
        </div>
        <div className="flex items-center gap-2">
          <button onClick={props.onReset} className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-md border border-border hover:bg-accent">
            <RotateCcw className="h-3.5 w-3.5" /> Új
          </button>
          {encounterId && patientId && (
            <button
              onClick={save}
              disabled={saving}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-md bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
            >
              {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
              Mentés a betegkartonhoz
            </button>
          )}
        </div>
      </header>
      {props.children}
    </div>
  );
}

export function ScoreBadge({ score, label, tone }: { score: number | string; label?: string; tone?: "ok" | "warn" | "danger" }) {
  const cls =
    tone === "danger" ? "bg-red-100 text-red-800 border-red-300"
      : tone === "warn" ? "bg-amber-100 text-amber-800 border-amber-300"
      : "bg-emerald-50 text-emerald-800 border-emerald-200";
  return (
    <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full border text-sm font-semibold ${cls}`}>
      <span className="font-mono">{score}</span>
      {label && <span>{label}</span>}
    </div>
  );
}

export function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return (
    <label className="block">
      <span className="text-xs text-muted-foreground flex items-center justify-between">
        <span>{label}</span>
        {hint && <span className="text-[10px] opacity-70">{hint}</span>}
      </span>
      <div className="mt-1">{children}</div>
    </label>
  );
}

export function Card({ title, children, footer }: { title: string; children: ReactNode; footer?: ReactNode }) {
  return (
    <div className="rounded-xl border border-border bg-card">
      <div className="px-4 py-3 border-b border-border text-sm font-semibold">{title}</div>
      <div className="p-4 space-y-3">{children}</div>
      {footer && <div className="px-4 py-3 border-t border-border bg-muted/30 text-sm">{footer}</div>}
    </div>
  );
}

export function NumberInput({ value, onChange, step = 1, placeholder }: { value: number | undefined; onChange: (v: number | undefined) => void; step?: number; placeholder?: string }) {
  return (
    <input
      type="number"
      step={step}
      placeholder={placeholder}
      value={value ?? ""}
      onChange={(e) => onChange(e.target.value === "" ? undefined : Number(e.target.value))}
      className="w-full px-2 py-1.5 text-sm rounded-md border border-border bg-background font-mono"
    />
  );
}

export function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <label className="flex items-center gap-2 cursor-pointer p-2 rounded-md hover:bg-accent text-sm">
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} className="accent-primary" />
      <span>{label}</span>
    </label>
  );
}
