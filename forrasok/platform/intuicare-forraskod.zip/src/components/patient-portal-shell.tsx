import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { Activity, FileText, Calendar, CalendarClock, ClipboardList, MessageSquare, Search, HeartPulse, FileSignature, AlertOctagon, User as UserIcon, LogOut, Home, Bell, Menu, X, BookOpen, Pill, Target, Folder, Stethoscope } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";
import { useState, type ReactNode } from "react";
import { useTranslation } from "react-i18next";
import { useQueryClient } from "@tanstack/react-query";
import { PortalRealtime } from "@/components/portal/portal-realtime";
import { useUnreadNotifications } from "@/hooks/use-unread-notifications";

function UnreadBadge({ count }: { count: number }) {
  if (!count) return null;
  return (
    <span
      aria-label={`${count} olvasatlan`}
      className="ml-auto inline-flex items-center justify-center min-w-[20px] h-5 px-1.5 rounded-full bg-destructive text-destructive-foreground text-[10px] font-semibold"
    >
      {count > 99 ? "99+" : count}
    </span>
  );
}

type NavItem = { to: string; labelKey: string; icon: typeof Activity };
type NavGroup = { key: string; labelKey?: string; items: NavItem[] };

const OVERVIEW: NavItem = { to: "/portal", labelKey: "portal.nav.overview", icon: Home };

const GROUPS: NavGroup[] = [
  {
    key: "appointments",
    labelKey: "portal.nav.group_appointments",
    items: [
      { to: "/portal/idopontok", labelKey: "portal.nav.appointments", icon: Calendar },
      { to: "/portal/elojegyzes", labelKey: "portal.nav.booking", icon: ClipboardList },
      { to: "/portal/beutalok", labelKey: "portal.nav.referrals", icon: FileSignature },
      { to: "/portal/utokovetes", labelKey: "portal.nav.followup", icon: CalendarClock },
    ],
  },
  {
    key: "health",
    labelKey: "portal.nav.group_health",
    items: [
      { to: "/portal/leletek", labelKey: "portal.nav.labs", icon: Stethoscope },
      { to: "/portal/dokumentumok", labelKey: "portal.nav.documents", icon: Folder },
      { to: "/portal/zarojelentes", labelKey: "portal.nav.discharge", icon: FileSignature },
      { to: "/portal/meresek", labelKey: "portal.nav.measurements", icon: Activity },
      { to: "/portal/eletmod", labelKey: "portal.nav.health_log", icon: HeartPulse },
      { to: "/portal/egeszsegterv", labelKey: "portal.nav.health_plan", icon: Target },
      { to: "/portal/gyogyszer-keres", labelKey: "portal.nav.medication", icon: Pill },
    ],
  },
  {
    key: "communication",
    labelKey: "portal.nav.group_communication",
    items: [
      { to: "/portal/uzenetek", labelKey: "portal.nav.messages", icon: MessageSquare },
      { to: "/portal/ertesitesek", labelKey: "portal.nav.notifications", icon: Bell },
      { to: "/portal/orvos-kereso", labelKey: "portal.nav.doctor_search", icon: Search },
    ],
  },
  {
    key: "questionnaires",
    labelKey: "portal.nav.group_questionnaires",
    items: [
      { to: "/portal/kerdoivek", labelKey: "portal.nav.questionnaires", icon: ClipboardList },
    ],
  },
  {
    key: "info",
    labelKey: "portal.nav.group_info",
    items: [
      { to: "/portal/informaciok", labelKey: "portal.nav.info", icon: BookOpen },
      { to: "/portal/sos", labelKey: "portal.nav.sos", icon: AlertOctagon },
    ],
  },
  {
    key: "account",
    labelKey: "portal.nav.group_account",
    items: [
      { to: "/portal/profil", labelKey: "portal.nav.profile", icon: UserIcon },
    ],
  },
];

const BOTTOM_NAV: NavItem[] = [
  OVERVIEW,
  { to: "/portal/idopontok", labelKey: "portal.nav.appointments", icon: Calendar },
  { to: "/portal/uzenetek", labelKey: "portal.nav.messages", icon: MessageSquare },
  { to: "/portal/leletek", labelKey: "portal.nav.labs", icon: FileText },
  { to: "/portal/informaciok", labelKey: "portal.nav.info", icon: BookOpen },
];


export function PatientPortalShell({ children }: { children: ReactNode }) {
  const { t } = useTranslation();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [mobileOpen, setMobileOpen] = useState(false);
  const { data: unread = 0 } = useUnreadNotifications();

  const queryClient = useQueryClient();
  const navigate = useNavigate();
  async function handleSignOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  const sidebar = (onNav?: () => void) => (
    <>
      <div className="px-4 py-5 border-b border-border">
        <div className="text-xs font-mono uppercase tracking-widest text-muted-foreground">{t("portal.section_label")}</div>
        <div className="font-semibold mt-1">{t("portal.brand")}</div>
      </div>
      <nav className="flex-1 overflow-y-auto py-3" aria-label={t("portal.nav.main")}>
        {(() => {
          const renderItem = (n: NavItem) => {
            const active = pathname === n.to || (n.to !== "/portal" && pathname.startsWith(n.to));
            const Icon = n.icon;
            const isNotifications = n.to === "/portal/ertesitesek";
            return (
              <Link
                key={n.to}
                to={n.to}
                onClick={onNav}
                aria-current={active ? "page" : undefined}
                className={cn(
                  "flex items-center gap-3 px-4 py-2 text-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                  active
                    ? "bg-primary/10 text-primary border-r-2 border-primary font-medium"
                    : "text-foreground/80 hover:bg-muted"
                )}
              >
                <Icon className="h-4 w-4" aria-hidden="true" />
                <span className="flex-1">{t(n.labelKey)}</span>
                {isNotifications && <UnreadBadge count={unread} />}
              </Link>
            );
          };
          return (
            <>
              {renderItem(OVERVIEW)}
              {GROUPS.map((g) => (
                <div key={g.key} className="mt-3">
                  {g.labelKey && (
                    <div className="px-4 pt-2 pb-1 text-[10px] font-mono uppercase tracking-widest text-muted-foreground/70">
                      {t(g.labelKey)}
                    </div>
                  )}
                  {g.items.map(renderItem)}
                </div>
              ))}
            </>
          );
        })()}
      </nav>
      <div className="m-3 flex flex-col gap-1">
        <Link
          to="/"
          onClick={onNav}
          className="flex items-center gap-2 px-3 py-2 text-sm rounded-md hover:bg-muted text-foreground/80 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          <Home className="h-4 w-4" aria-hidden="true" /> Főoldal megtekintése
        </Link>
        <button
          onClick={handleSignOut}
          className="flex items-center gap-2 px-3 py-2 text-sm rounded-md hover:bg-muted text-foreground/80 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          <LogOut className="h-4 w-4" aria-hidden="true" /> {t("portal.nav.sign_out")}
        </button>
      </div>
    </>
  );

  return (
    <div className="min-h-screen flex bg-background">
      <aside className="hidden md:flex w-60 border-r border-border bg-card flex-col">
        {sidebar()}
      </aside>

      {mobileOpen && (
        <div className="md:hidden fixed inset-0 z-50 flex" role="dialog" aria-modal="true" aria-label={t("portal.nav.main")}>
          <div className="absolute inset-0 bg-background/80 backdrop-blur-sm" onClick={() => setMobileOpen(false)} />
          <aside className="relative w-64 border-r border-border bg-card flex flex-col animate-in slide-in-from-left duration-200">
            <button
              onClick={() => setMobileOpen(false)}
              aria-label={t("portal.nav.menu_close")}
              className="absolute top-3 right-3 p-1 rounded-md hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              <X className="h-4 w-4" />
            </button>
            {sidebar(() => setMobileOpen(false))}
          </aside>
        </div>
      )}

      <PortalRealtime />

      <main className="flex-1 overflow-y-auto pb-20 md:pb-0">
        <header className="md:hidden sticky top-0 z-30 bg-card border-b border-border flex items-center justify-between px-3 py-2">
          <button
            onClick={() => setMobileOpen(true)}
            aria-label={t("portal.nav.menu_open")}
            className="p-2 rounded-md hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            <Menu className="h-5 w-5" />
          </button>
          <div className="font-semibold text-sm">{t("portal.brand")} · {t("portal.section_label")}</div>
          <Link
            to="/portal/ertesitesek"
            aria-label={t("portal.nav.notifications") + (unread ? ` (${unread})` : "")}
            className="relative p-2 rounded-md hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            <Bell className="h-5 w-5" />
            {unread > 0 && (
              <span className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] px-1 rounded-full bg-destructive text-destructive-foreground text-[10px] font-semibold flex items-center justify-center">
                {unread > 99 ? "99+" : unread}
              </span>
            )}
          </Link>
        </header>
        <div className="max-w-6xl mx-auto p-4 md:p-6">{children}</div>
      </main>

      <nav
        aria-label={t("portal.nav.quick")}
        className="md:hidden fixed bottom-0 inset-x-0 z-40 bg-card border-t border-border grid grid-cols-5"
      >
        {BOTTOM_NAV.map((n) => {
          const active = pathname === n.to || (n.to !== "/portal" && pathname.startsWith(n.to));
          const Icon = n.icon;
          const label = t(n.labelKey);
          return (
            <Link
              key={n.to}
              to={n.to}
              aria-current={active ? "page" : undefined}
              aria-label={label}
              className={cn(
                "flex flex-col items-center justify-center py-2 text-[10px] gap-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                active ? "text-primary" : "text-muted-foreground"
              )}
            >
              <Icon className="h-5 w-5" aria-hidden="true" />
              <span className="truncate max-w-[64px]">{label}</span>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
