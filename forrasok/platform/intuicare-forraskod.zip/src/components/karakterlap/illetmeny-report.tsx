import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { FileDown, Loader2, Plus, Trash2, Calculator, Save, AlertTriangle, Info, XCircle, FileSpreadsheet, FileText } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { getIlletmeny, getGyakorlatiIdo } from "@/lib/eusztv/eusztv.functions";
import { saveIlletmenySnapshot } from "@/lib/eusztv/illetmeny.functions";
import { auditIlletmeny, aktivHivatkozasok } from "@/lib/eusztv/legal-references";
import { generateIlletmenyPdf } from "./illetmeny-pdf";

type Tetel = { cimke: string; osszeg: number };

const fmt = (n: number) => `${Math.round(n).toLocaleString("hu")} Ft`;

export function IlletmenyReport({
  userId,
  tenantId,
  name,
  externalOrakeret,
  preloadInput,
}: {
  userId: string;
  tenantId?: string;
  name?: string;
  /** Külső (időszakos keret-szerkesztő által adott) havi órakeret. */
  externalOrakeret?: number | null;
  /** Snapshot „Betöltés" gomb által beadott bemeneti paraméterek. */
  preloadInput?: Record<string, unknown> | null;
}) {
  const qc = useQueryClient();
  const iFn = useServerFn(getIlletmeny);
  const gFn = useServerFn(getGyakorlatiIdo);
  const saveFn = useServerFn(saveIlletmenySnapshot);

  const { data: illetmeny, isLoading } = useQuery({
    queryKey: ["illetmeny-report", userId],
    queryFn: () => iFn({ data: { userId } }),
  });
  const { data: gyak } = useQuery({
    queryKey: ["illetmeny-report-gy", userId],
    queryFn: () => gFn({ data: { userId } }),
  });

  const [orakeret, setOrakeret] = useState<number>(174);
  const [ugyHetkoznap, setUgyHetkoznap] = useState<number>(0);
  const [ugyHetvege, setUgyHetvege] = useState<number>(0);
  const [ugyUnnep, setUgyUnnep] = useState<number>(0);
  const [potHetkoznap, setPotHetkoznap] = useState<number>(50);
  const [potHetvege, setPotHetvege] = useState<number>(50);
  const [potUnnep, setPotUnnep] = useState<number>(100);
  const [keszenletOra, setKeszenletOra] = useState<number>(0);
  const [keszenletPot, setKeszenletPot] = useState<number>(25);
  const [egyebDijak, setEgyebDijak] = useState<Tetel[]>([{ cimke: "Béren kívüli juttatás", osszeg: 0 }]);
  const [korrekciok, setKorrekciok] = useState<Tetel[]>([]);
  const [snapCimke, setSnapCimke] = useState<string>("");

  // Külső órakeret rákényszerítése, ha érkezett.
  useEffect(() => {
    if (externalOrakeret != null && externalOrakeret > 0) setOrakeret(Math.round(externalOrakeret));
  }, [externalOrakeret]);

  // Snapshot betöltése.
  useEffect(() => {
    if (!preloadInput) return;
    const p = preloadInput as any;
    if (p.orakeret) setOrakeret(p.orakeret);
    if (p.ugyHetkoznap != null) setUgyHetkoznap(p.ugyHetkoznap);
    if (p.ugyHetvege != null) setUgyHetvege(p.ugyHetvege);
    if (p.ugyUnnep != null) setUgyUnnep(p.ugyUnnep);
    if (p.potHetkoznap != null) setPotHetkoznap(p.potHetkoznap);
    if (p.potHetvege != null) setPotHetvege(p.potHetvege);
    if (p.potUnnep != null) setPotUnnep(p.potUnnep);
    if (p.keszenletOra != null) setKeszenletOra(p.keszenletOra);
    if (p.keszenletPot != null) setKeszenletPot(p.keszenletPot);
    if (Array.isArray(p.egyebDijak)) setEgyebDijak(p.egyebDijak);
    if (Array.isArray(p.korrekciok)) setKorrekciok(p.korrekciok);
    toast.info("Snapshot betöltve a kalkulátorba.");
  }, [preloadInput]);

  const havi = illetmeny?.vegso_ft ?? 0;
  const oradij = orakeret > 0 ? havi / orakeret : 0;
  const ugyHetkoznapOsszeg = oradij * ugyHetkoznap * (1 + potHetkoznap / 100);
  const ugyHetvegeOsszeg = oradij * ugyHetvege * (1 + potHetvege / 100);
  const ugyUnnepOsszeg = oradij * ugyUnnep * (1 + potUnnep / 100);
  const keszenletOsszeg = oradij * keszenletOra * (keszenletPot / 100);
  const ugyOsszesen = ugyHetkoznapOsszeg + ugyHetvegeOsszeg + ugyUnnepOsszeg + keszenletOsszeg;
  const egyebOsszesen = egyebDijak.reduce((s, t) => s + (Number(t.osszeg) || 0), 0);
  const korrOsszesen = korrekciok.reduce((s, t) => s + (Number(t.osszeg) || 0), 0);
  const vegosszeg = havi + ugyOsszesen + egyebOsszesen + korrOsszesen;
  const vezetoiSzorzo = Number(illetmeny?.vezetoi_szorzo ?? 1);

  const auditInput = {
    havi, orakeret, oradij, vezetoiSzorzo,
    ugyHetkoznap, ugyHetvege, ugyUnnep, keszenletOra,
    egyebOsszesen, korrOsszesen,
  };
  const issues = auditIlletmeny(auditInput);
  const refs = aktivHivatkozasok(auditInput);

  const addTetel = (setter: typeof setEgyebDijak) => () => setter((p) => [...p, { cimke: "", osszeg: 0 }]);
  const updateTetel = (setter: typeof setEgyebDijak, idx: number, patch: Partial<Tetel>) =>
    setter((p) => p.map((t, i) => (i === idx ? { ...t, ...patch } : t)));
  const removeTetel = (setter: typeof setEgyebDijak, idx: number) =>
    setter((p) => p.filter((_, i) => i !== idx));

  const buildPayload = () => ({
    name,
    datum: new Date().toISOString().slice(0, 10),
    bemenet: {
      orakeret, ugyHetkoznap, ugyHetvege, ugyUnnep,
      potHetkoznap, potHetvege, potUnnep,
      keszenletOra, keszenletPot,
      egyebDijak, korrekciok,
      havi, oradij, vezetoiSzorzo,
      sav: illetmeny?.sav, alap_ft: illetmeny?.alap_ft,
      gyakorlatiEvek: gyak?.evek, gyakorlatiNapok: gyak?.napok,
      egyebOsszesen, korrOsszesen,
    },
    eredmeny: {
      ugyHetkoznapOsszeg, ugyHetvegeOsszeg, ugyUnnepOsszeg, keszenletOsszeg,
      ugyOsszesen, vegosszeg,
    },
    jogi_hivatkozasok: refs,
  });

  const generatePdf = async () => {
    await generateIlletmenyPdf(
      buildPayload(),
      `illetmeny-${(name ?? "munkavallalo").replace(/\s+/g, "_")}-${new Date().toISOString().slice(0, 10)}.pdf`,
    );
  };

  const saveSnap = useMutation({
    mutationFn: async () => {
      if (!tenantId) throw new Error("Hiányzik a tenant azonosító.");
      const p = buildPayload();
      return saveFn({
        data: {
          user_id: userId,
          tenant_id: tenantId,
          cimke: snapCimke || `Snapshot ${new Date().toLocaleDateString("hu")}`,
          vonatkozasi_datum: p.datum,
          bemenet: p.bemenet,
          eredmeny: p.eredmeny,
          vegosszeg_ft: vegosszeg,
          jogi_hivatkozasok: refs as any,
        } as any,
      });
    },
    onSuccess: () => {
      toast.success("Snapshot elmentve.");
      setSnapCimke("");
      qc.invalidateQueries({ queryKey: ["illetmeny-snaps", userId] });
    },
    onError: (e: any) => toast.error("Mentés sikertelen", { description: e.message }),
  });

  if (isLoading) {
    return (
      <div className="flex items-center gap-2 text-muted-foreground text-sm">
        <Loader2 className="h-4 w-4 animate-spin" /> Illetmény betöltése…
      </div>
    );
  }

  return (
    <Card className="p-4 space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <div className="flex items-center gap-2 font-medium"><Calculator className="h-4 w-4" /> Havi illetmény-kalkulátor és PDF riport</div>
          <div className="text-xs text-muted-foreground">
            Sáv: <b>{illetmeny?.sav ?? "—"}</b> · Vez. szorzó: {vezetoiSzorzo}× · Alap: {fmt(illetmeny?.alap_ft ?? 0)} · Korrigált: <b>{fmt(havi)}</b>
            {externalOrakeret != null && (
              <span className="ml-2"><Badge variant="outline">Időszakos keret: {orakeret} óra/hó</Badge></span>
            )}
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button onClick={generatePdf} disabled={!illetmeny}>
            <FileDown className="h-4 w-4 mr-2" /> PDF
          </Button>
        </div>
      </div>

      <Separator />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Field label="Havi munkaidő-keret (óra)" value={orakeret} onChange={setOrakeret} />
        <Field label="Óradíj (számított)" value={Math.round(oradij)} disabled />
        <Field label="Hétköznap ügyelet (óra)" value={ugyHetkoznap} onChange={setUgyHetkoznap} />
        <Field label="Hétköznap pótlék %" value={potHetkoznap} onChange={setPotHetkoznap} />
        <Field label="Hétvégi ügyelet (óra)" value={ugyHetvege} onChange={setUgyHetvege} />
        <Field label="Hétvégi pótlék %" value={potHetvege} onChange={setPotHetvege} />
        <Field label="Munkaszüneti ügyelet (óra)" value={ugyUnnep} onChange={setUgyUnnep} />
        <Field label="Munkaszüneti pótlék %" value={potUnnep} onChange={setPotUnnep} />
        <Field label="Készenlét (óra)" value={keszenletOra} onChange={setKeszenletOra} />
        <Field label="Készenlét pótlék %" value={keszenletPot} onChange={setKeszenletPot} />
      </div>

      <TetelList title="Egyéb díjak / juttatások" tetelek={egyebDijak}
        onAdd={addTetel(setEgyebDijak)} onUpdate={(i, p) => updateTetel(setEgyebDijak, i, p)} onRemove={(i) => removeTetel(setEgyebDijak, i)} />
      <TetelList title="Korrekciók (+/-)" tetelek={korrekciok}
        onAdd={addTetel(setKorrekciok)} onUpdate={(i, p) => updateTetel(setKorrekciok, i, p)} onRemove={(i) => removeTetel(setKorrekciok, i)} />

      <Separator />

      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 text-sm">
        <Summary label="Havi illetmény" value={havi} />
        <Summary label="Ügyelet / készenlét" value={ugyOsszesen} />
        <Summary label="Egyéb díjak" value={egyebOsszesen} />
        <Summary label="Korrekciók" value={korrOsszesen} />
        <Summary label="Végösszeg" value={vegosszeg} highlight />
      </div>

      {/* === Jogi hivatkozások audit === */}
      <Separator />
      <AuditPanel issues={issues} refs={refs} name={name} />

      {/* === Snapshot mentés === */}
      <Separator />
      <div className="flex flex-wrap gap-2 items-end">
        <div className="flex-1 min-w-[200px] space-y-1">
          <Label className="text-xs">Snapshot címkéje</Label>
          <Input
            placeholder={`pl. ${new Date().toLocaleDateString("hu", { year: "numeric", month: "long" })}`}
            value={snapCimke}
            onChange={(e) => setSnapCimke(e.target.value)}
            className="h-8"
          />
        </div>
        <Button
          variant="secondary"
          onClick={() => saveSnap.mutate()}
          disabled={!tenantId || saveSnap.isPending}
        >
          <Save className="h-4 w-4 mr-1" /> Mentés snapshotként
        </Button>
      </div>
    </Card>
  );
}

function AuditPanel({
  issues, refs, name,
}: {
  issues: ReturnType<typeof auditIlletmeny>;
  refs: ReturnType<typeof aktivHivatkozasok>;
  name?: string;
}) {
  const errors = issues.filter((i) => i.severity === "error");
  const warnings = issues.filter((i) => i.severity === "warning");
  const infos = issues.filter((i) => i.severity === "info");

  const handleExport = async (kind: "csv" | "docx") => {
    const { exportAuditCsv, exportAuditDocx } = await import("./illetmeny-audit-export");
    const meta = { name, datum: new Date().toISOString().slice(0, 10) };
    const base = `audit-${(name ?? "munkavallalo").replace(/\s+/g, "_")}-${meta.datum}`;
    try {
      if (kind === "csv") exportAuditCsv(issues, meta, `${base}.csv`);
      else await exportAuditDocx(issues, meta, `${base}.docx`);
      toast.success(`Audit-jelentés letöltve (${kind.toUpperCase()}).`);
    } catch (e: any) {
      toast.error("Export sikertelen", { description: e?.message });
    }
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2 flex-wrap text-sm font-medium">
        Jogi hivatkozások ellenőrzése
        {errors.length > 0 && <Badge variant="destructive">{errors.length} hiba</Badge>}
        {warnings.length > 0 && <Badge className="bg-yellow-600">{warnings.length} figyelm.</Badge>}
        {issues.length === 0 && <Badge variant="default">Teljes</Badge>}
        <div className="ml-auto flex gap-2">
          <Button size="sm" variant="outline" onClick={() => handleExport("csv")}>
            <FileSpreadsheet className="h-3.5 w-3.5 mr-1" /> Audit CSV
          </Button>
          <Button size="sm" variant="outline" onClick={() => handleExport("docx")}>
            <FileText className="h-3.5 w-3.5 mr-1" /> Audit DOCX
          </Button>
        </div>
      </div>

      {issues.length > 0 && (
        <ul className="space-y-1 text-xs">
          {issues.map((i, idx) => (
            <li key={idx} className="flex items-start gap-2">
              {i.severity === "error" && <XCircle className="h-3.5 w-3.5 text-destructive mt-0.5" />}
              {i.severity === "warning" && <AlertTriangle className="h-3.5 w-3.5 text-yellow-600 mt-0.5" />}
              {i.severity === "info" && <Info className="h-3.5 w-3.5 text-blue-600 mt-0.5" />}
              <span>
                <b>{i.cimke}:</b> {i.uzenet}
                {i.szukseges_hivatkozas && (
                  <span className="text-muted-foreground"> ({i.szukseges_hivatkozas.jogszabaly} — {i.szukseges_hivatkozas.szakasz})</span>
                )}
              </span>
            </li>
          ))}
        </ul>
      )}

      <details className="text-xs">
        <summary className="cursor-pointer text-muted-foreground">Aktív hivatkozások ({refs.length})</summary>
        <ul className="mt-2 space-y-0.5">
          {refs.map((r) => (
            <li key={r.szakasz} className="flex gap-2">
              <span className="font-mono text-muted-foreground shrink-0">{r.szakasz}</span>
              <span>{r.cimke} — {r.jogszabaly}</span>
            </li>
          ))}
        </ul>
      </details>
    </div>
  );
}

function Field({ label, value, onChange, disabled }: { label: string; value: number; onChange?: (n: number) => void; disabled?: boolean }) {
  return (
    <div className="space-y-1">
      <Label className="text-xs">{label}</Label>
      <Input type="number" value={value} disabled={disabled}
        onChange={(e) => onChange?.(Number(e.target.value) || 0)} className="h-8" />
    </div>
  );
}

function TetelList({
  title, tetelek, onAdd, onUpdate, onRemove,
}: {
  title: string;
  tetelek: Tetel[];
  onAdd: () => void;
  onUpdate: (idx: number, patch: Partial<Tetel>) => void;
  onRemove: (idx: number) => void;
}) {
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <Label className="text-sm font-medium">{title}</Label>
        <Button size="sm" variant="outline" onClick={onAdd}><Plus className="h-3 w-3 mr-1" /> Sor</Button>
      </div>
      {tetelek.length === 0 && <div className="text-xs text-muted-foreground">Nincs tétel.</div>}
      {tetelek.map((t, i) => (
        <div key={i} className="flex gap-2 items-center">
          <Input placeholder="Megnevezés" value={t.cimke} onChange={(e) => onUpdate(i, { cimke: e.target.value })} className="h-8 flex-1" />
          <Input type="number" value={t.osszeg} onChange={(e) => onUpdate(i, { osszeg: Number(e.target.value) || 0 })} className="h-8 w-32" />
          <Button size="icon" variant="ghost" onClick={() => onRemove(i)}><Trash2 className="h-4 w-4" /></Button>
        </div>
      ))}
    </div>
  );
}

function Summary({ label, value, highlight }: { label: string; value: number; highlight?: boolean }) {
  return (
    <div className={`border rounded-lg p-3 ${highlight ? "bg-primary/10 border-primary/40" : "bg-card"}`}>
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className={`font-bold ${highlight ? "text-lg" : ""}`}>{fmt(value)}</div>
    </div>
  );
}
