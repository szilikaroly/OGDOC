/**
 * Két mentett illetmény-snapshot vizuális összehasonlítása:
 *  - kártyás összegzés (végösszeg + Δ Ft + Δ%)
 *  - tételes sor-szintű diff: minden bemenet + eredmény mező
 *  - csak-változott / összes szűrő
 */
import { useMemo, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowDownRight, ArrowUpRight, Minus, GitCompareArrows } from "lucide-react";

type Snap = {
  id: string;
  version: number;
  cimke: string;
  vonatkozasi_datum: string;
  created_at: string;
  vegosszeg_ft: number | string;
  bemenet?: Record<string, unknown> | null;
  eredmeny?: Record<string, unknown> | null;
};

const fmtFt = (n: number) => `${Math.round(n).toLocaleString("hu")} Ft`;
const fmtSigned = (n: number) =>
  `${n > 0 ? "+" : n < 0 ? "−" : ""}${Math.abs(Math.round(n)).toLocaleString("hu")} Ft`;
const fmtNum = (n: number) =>
  Number.isInteger(n) ? n.toLocaleString("hu") : n.toLocaleString("hu", { maximumFractionDigits: 2 });

// Emberi olvasható címkék a snapshot mezőkhöz.
const LABELS: Record<string, string> = {
  // bemenet
  orakeret: "Havi órakeret",
  ugyHetkoznap: "Ügyelet — hétköznap (óra)",
  ugyHetvege: "Ügyelet — hétvége (óra)",
  ugyUnnep: "Ügyelet — ünnep (óra)",
  potHetkoznap: "Pótlék % — hétköznap",
  potHetvege: "Pótlék % — hétvége",
  potUnnep: "Pótlék % — ünnep",
  keszenletOra: "Készenlét (óra)",
  keszenletPot: "Készenlét pótlék %",
  havi: "Havi alapilletmény",
  oradij: "Órabér",
  vezetoiSzorzo: "Vezetői szorzó",
  sav: "Besorolási sáv",
  alap_ft: "Sáv alapösszeg",
  gyakorlatiEvek: "Gyakorlati évek",
  gyakorlatiNapok: "Gyakorlati napok",
  egyebOsszesen: "Egyéb díjak — összesen",
  korrOsszesen: "Korrekciók — összesen",
  // eredmeny
  ugyHetkoznapOsszeg: "Ügyeleti díj — hétköznap",
  ugyHetvegeOsszeg: "Ügyeleti díj — hétvége",
  ugyUnnepOsszeg: "Ügyeleti díj — ünnep",
  keszenletOsszeg: "Készenléti díj",
  ugyOsszesen: "Ügyelet + készenlét összesen",
  vegosszeg: "Végösszeg",
};

// Ft-egységben megjelenítendő mezők (a többit sima számként rendereljük).
const FT_KEYS = new Set([
  "havi",
  "oradij",
  "alap_ft",
  "egyebOsszesen",
  "korrOsszesen",
  "ugyHetkoznapOsszeg",
  "ugyHetvegeOsszeg",
  "ugyUnnepOsszeg",
  "keszenletOsszeg",
  "ugyOsszesen",
  "vegosszeg",
]);

type Row = {
  key: string;
  label: string;
  a: number | null;
  b: number | null;
  delta: number;
  isFt: boolean;
  group: "eredmeny" | "bemenet";
};

function toNumber(v: unknown): number | null {
  if (v === null || v === undefined || v === "") return null;
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? n : null;
}

function buildRows(a: Snap, b: Snap): Row[] {
  const rows: Row[] = [];
  const seen = new Set<string>();

  const push = (
    key: string,
    src: "bemenet" | "eredmeny",
    group: "eredmeny" | "bemenet",
  ) => {
    if (seen.has(key)) return;
    seen.add(key);
    const av = toNumber((a[src] as any)?.[key]);
    const bv = toNumber((b[src] as any)?.[key]);
    if (av === null && bv === null) return; // nem numerikus / mindkettőben üres
    rows.push({
      key,
      label: LABELS[key] ?? key,
      a: av,
      b: bv,
      delta: (bv ?? 0) - (av ?? 0),
      isFt: FT_KEYS.has(key),
      group,
    });
  };

  // eredmény mezők előre
  const eKeys = new Set<string>([
    ...Object.keys(a.eredmeny ?? {}),
    ...Object.keys(b.eredmeny ?? {}),
  ]);
  eKeys.forEach((k) => push(k, "eredmeny", "eredmeny"));

  const bKeys = new Set<string>([
    ...Object.keys(a.bemenet ?? {}),
    ...Object.keys(b.bemenet ?? {}),
  ]);
  bKeys.forEach((k) => push(k, "bemenet", "bemenet"));

  return rows;
}

export function IlletmenyDiffDialog({
  open,
  onOpenChange,
  older,
  newer,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  /** Régebbi snapshot (v_n) */
  older: Snap | null;
  /** Újabb snapshot (v_n+k) */
  newer: Snap | null;
}) {
  const [onlyChanged, setOnlyChanged] = useState(true);

  const rows = useMemo(() => {
    if (!older || !newer) return [];
    return buildRows(older, newer);
  }, [older, newer]);

  const visibleRows = useMemo(
    () => (onlyChanged ? rows.filter((r) => r.delta !== 0 || r.a !== r.b) : rows),
    [rows, onlyChanged],
  );

  const changedCount = rows.filter((r) => r.delta !== 0 || r.a !== r.b).length;

  const vegA = older ? Number(older.vegosszeg_ft) || 0 : 0;
  const vegB = newer ? Number(newer.vegosszeg_ft) || 0 : 0;
  const totalDelta = vegB - vegA;
  const totalPct = vegA !== 0 ? (totalDelta / vegA) * 100 : null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <GitCompareArrows className="h-5 w-5" />
            Illetmény-verziók összehasonlítása
          </DialogTitle>
          <DialogDescription>
            Ft-változások és módosított tételek verzióról verzióra.
          </DialogDescription>
        </DialogHeader>

        {!older || !newer ? (
          <div className="text-sm text-muted-foreground py-6 text-center">
            Válassz két snapshotot az összehasonlításhoz.
          </div>
        ) : (
          <div className="space-y-4">
            {/* Fejléc — két verzió + delta */}
            <div className="grid grid-cols-1 sm:grid-cols-[1fr_auto_1fr] gap-3 items-stretch">
              <SnapCard snap={older} label="Régebbi" />
              <div className="hidden sm:flex items-center justify-center">
                <div
                  className={`text-center px-3 py-2 rounded-md border ${
                    totalDelta > 0
                      ? "bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-900"
                      : totalDelta < 0
                        ? "bg-destructive/10 border-destructive/40"
                        : "bg-muted"
                  }`}
                >
                  <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
                    Δ végösszeg
                  </div>
                  <div className="font-bold flex items-center gap-1 justify-center">
                    {totalDelta > 0 ? (
                      <ArrowUpRight className="h-4 w-4" />
                    ) : totalDelta < 0 ? (
                      <ArrowDownRight className="h-4 w-4" />
                    ) : (
                      <Minus className="h-4 w-4" />
                    )}
                    {fmtSigned(totalDelta)}
                  </div>
                  {totalPct !== null && (
                    <div className="text-[11px] text-muted-foreground">
                      {totalPct > 0 ? "+" : ""}
                      {totalPct.toFixed(1)}%
                    </div>
                  )}
                </div>
              </div>
              <SnapCard snap={newer} label="Újabb" />
            </div>

            {/* Szűrő */}
            <div className="flex items-center justify-between text-xs">
              <div className="text-muted-foreground">
                {changedCount} változott / {rows.length} tétel
              </div>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => setOnlyChanged((v) => !v)}
                className="h-7"
              >
                {onlyChanged ? "Összes mutatása" : "Csak változott"}
              </Button>
            </div>

            {/* Diff tábla */}
            <div className="border rounded-md overflow-hidden">
              <table className="w-full text-sm">
                <thead className="bg-muted/50 text-xs">
                  <tr>
                    <th className="text-left px-3 py-2 font-medium">Tétel</th>
                    <th className="text-right px-3 py-2 font-medium">v{older.version}</th>
                    <th className="text-right px-3 py-2 font-medium">v{newer.version}</th>
                    <th className="text-right px-3 py-2 font-medium">Δ</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {visibleRows.length === 0 ? (
                    <tr>
                      <td
                        colSpan={4}
                        className="text-center text-xs text-muted-foreground py-4"
                      >
                        Nincs változás a két verzió között.
                      </td>
                    </tr>
                  ) : (
                    visibleRows.map((r) => {
                      const changed = r.delta !== 0 || r.a !== r.b;
                      const fmt = (v: number | null) =>
                        v === null ? "—" : r.isFt ? fmtFt(v) : fmtNum(v);
                      return (
                        <tr
                          key={r.key}
                          className={
                            changed
                              ? r.delta > 0
                                ? "bg-emerald-50/60 dark:bg-emerald-950/20"
                                : r.delta < 0
                                  ? "bg-destructive/5"
                                  : "bg-amber-50/60 dark:bg-amber-950/20"
                              : ""
                          }
                        >
                          <td className="px-3 py-1.5">
                            <div className="flex items-center gap-2">
                              <span className="truncate">{r.label}</span>
                              {r.group === "eredmeny" && (
                                <Badge
                                  variant="outline"
                                  className="text-[9px] px-1 py-0 h-4"
                                >
                                  eredmény
                                </Badge>
                              )}
                            </div>
                          </td>
                          <td className="px-3 py-1.5 text-right tabular-nums text-muted-foreground">
                            {fmt(r.a)}
                          </td>
                          <td className="px-3 py-1.5 text-right tabular-nums font-medium">
                            {fmt(r.b)}
                          </td>
                          <td
                            className={`px-3 py-1.5 text-right tabular-nums font-medium ${
                              r.delta > 0
                                ? "text-emerald-700 dark:text-emerald-400"
                                : r.delta < 0
                                  ? "text-destructive"
                                  : "text-muted-foreground"
                            }`}
                          >
                            {changed ? (r.isFt ? fmtSigned(r.delta) : (r.delta > 0 ? "+" : "") + fmtNum(r.delta)) : "—"}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

function SnapCard({ snap, label }: { snap: Snap; label: string }) {
  return (
    <div className="border rounded-md p-3 bg-card">
      <div className="flex items-center gap-2 mb-1">
        <Badge variant="secondary" className="font-mono text-[10px]">
          v{snap.version}
        </Badge>
        <span className="text-[10px] uppercase tracking-wide text-muted-foreground">
          {label}
        </span>
      </div>
      <div className="font-medium text-sm truncate" title={snap.cimke}>
        {snap.cimke}
      </div>
      <div className="text-[11px] text-muted-foreground">
        Vonatkozás: <b>{snap.vonatkozasi_datum}</b>
      </div>
      <div className="text-[11px] text-muted-foreground">
        Mentve: {new Date(snap.created_at).toLocaleString("hu-HU")}
      </div>
      <div className="mt-2 font-bold">{fmtFt(Number(snap.vegosszeg_ft) || 0)}</div>
    </div>
  );
}
