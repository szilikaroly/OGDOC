/**
 * Megosztott illetmény-PDF generátor (használja a kalkulátor és a snapshot-lista is).
 * A számolt értékek mellett kötelezően kiírja az aktív jogi hivatkozásokat,
 * és külön szekcióban listázza az audit által észlelt hiányosságokat.
 */
import { aktivHivatkozasok, auditIlletmeny, type AuditInput, type LegalRef } from "@/lib/eusztv/legal-references";

const fmt = (n: number) => `${Math.round(n).toLocaleString("hu")} Ft`;

export type Tetel = { cimke: string; osszeg: number };

export type SnapshotBemenet = AuditInput & {
  potHetkoznap: number;
  potHetvege: number;
  potUnnep: number;
  keszenletPot: number;
  ugyHetkoznapOsszeg: number;
  ugyHetvegeOsszeg: number;
  ugyUnnepOsszeg: number;
  keszenletOsszeg: number;
  ugyOsszesen: number;
  egyebDijak: Tetel[];
  korrekciok: Tetel[];
  vegosszeg: number;
  sav?: string;
  alap_ft?: number;
  vezetoiSzorzo: number;
  gyakorlatiEvek?: number;
  gyakorlatiNapok?: number;
};

export type SnapshotPayload = {
  name?: string;
  datum: string;
  bemenet: any;
  eredmeny: any;
  jogi_hivatkozasok: LegalRef[];
};

export async function generateIlletmenyPdf(
  payload: SnapshotPayload,
  filename: string,
) {
  const [{ default: jsPDF }, { default: autoTable }] = await Promise.all([
    import("jspdf"),
    import("jspdf-autotable"),
  ]);

  const b: SnapshotBemenet = { ...payload.bemenet, ...payload.eredmeny };
  const refs: LegalRef[] = (payload.jogi_hivatkozasok?.length
    ? payload.jogi_hivatkozasok
    : aktivHivatkozasok(b)) as LegalRef[];
  const issues = auditIlletmeny(b);

  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const margin = 14;
  let y = margin;

  doc.setFont("helvetica", "bold"); doc.setFontSize(16);
  doc.text("Illetmény riport", margin, y); y += 7;
  doc.setFontSize(10); doc.setFont("helvetica", "normal");
  doc.text(`Munkavállaló: ${payload.name ?? "—"}`, margin, y); y += 5;
  doc.text(`Vonatkozási nap: ${payload.datum}`, margin, y); y += 5;
  if (b.gyakorlatiEvek != null) {
    doc.text(`Gyakorlati idő: ${b.gyakorlatiEvek} év ${b.gyakorlatiNapok ?? 0} nap`, margin, y); y += 6;
  } else { y += 1; }

  autoTable(doc, {
    startY: y,
    head: [["Besorolás", "Érték"]],
    body: [
      ["Sáv", String(b.sav ?? "—")],
      ["Alap illetmény", fmt(b.alap_ft ?? 0)],
      ["Vezetői szorzó", `${b.vezetoiSzorzo ?? 1}×`],
      ["Korrigált havi illetmény", fmt(b.havi)],
      ["Havi munkaidő-keret", `${b.orakeret} óra`],
      ["Számított óradíj", `${Math.round(b.oradij).toLocaleString("hu")} Ft / óra`],
    ],
    styles: { fontSize: 9 }, headStyles: { fillColor: [40, 60, 90] },
  });
  y = (doc as any).lastAutoTable.finalY + 6;

  autoTable(doc, {
    startY: y,
    head: [["Ügyelet / készenlét", "Óra", "Pótlék %", "Összeg"]],
    body: [
      ["Hétköznapi ügyelet", String(b.ugyHetkoznap), `${b.potHetkoznap}%`, fmt(b.ugyHetkoznapOsszeg)],
      ["Hétvégi ügyelet", String(b.ugyHetvege), `${b.potHetvege}%`, fmt(b.ugyHetvegeOsszeg)],
      ["Munkaszüneti ügyelet", String(b.ugyUnnep), `${b.potUnnep}%`, fmt(b.ugyUnnepOsszeg)],
      ["Készenlét", String(b.keszenletOra), `${b.keszenletPot}%`, fmt(b.keszenletOsszeg)],
      [{ content: "Ügyelet összesen", colSpan: 3, styles: { fontStyle: "bold" } }, { content: fmt(b.ugyOsszesen), styles: { fontStyle: "bold" } }],
    ] as any,
    styles: { fontSize: 9 }, headStyles: { fillColor: [40, 60, 90] },
  });
  y = (doc as any).lastAutoTable.finalY + 6;

  if (b.egyebDijak?.length) {
    autoTable(doc, {
      startY: y,
      head: [["Egyéb díjak / juttatások", "Összeg"]],
      body: [
        ...b.egyebDijak.map((t: Tetel) => [t.cimke || "—", fmt(t.osszeg)]),
        [{ content: "Összesen", styles: { fontStyle: "bold" } }, { content: fmt(b.egyebOsszesen), styles: { fontStyle: "bold" } }],
      ] as any,
      styles: { fontSize: 9 }, headStyles: { fillColor: [40, 60, 90] },
    });
    y = (doc as any).lastAutoTable.finalY + 6;
  }

  if (b.korrekciok?.length) {
    autoTable(doc, {
      startY: y,
      head: [["Korrekció", "Összeg"]],
      body: [
        ...b.korrekciok.map((t: Tetel) => [t.cimke || "—", fmt(t.osszeg)]),
        [{ content: "Összesen", styles: { fontStyle: "bold" } }, { content: fmt(b.korrOsszesen), styles: { fontStyle: "bold" } }],
      ] as any,
      styles: { fontSize: 9 }, headStyles: { fillColor: [40, 60, 90] },
    });
    y = (doc as any).lastAutoTable.finalY + 6;
  }

  autoTable(doc, {
    startY: y,
    body: [
      ["Havi illetmény", fmt(b.havi)],
      ["+ Ügyelet / készenlét", fmt(b.ugyOsszesen)],
      ["+ Egyéb díjak", fmt(b.egyebOsszesen)],
      ["+/- Korrekciók", fmt(b.korrOsszesen)],
      [{ content: "VÉGÖSSZEG", styles: { fontStyle: "bold", fillColor: [220, 230, 245] } }, { content: fmt(b.vegosszeg), styles: { fontStyle: "bold", fillColor: [220, 230, 245] } }],
    ] as any,
    styles: { fontSize: 10 },
  });
  y = (doc as any).lastAutoTable.finalY + 8;

  // === Jogi hivatkozások (kötelező) ===
  autoTable(doc, {
    startY: y,
    head: [["Jogi alap", "Hivatkozás"]],
    body: refs.map((r) => [r.cimke, `${r.jogszabaly} — ${r.szakasz}`]),
    styles: { fontSize: 8 }, headStyles: { fillColor: [60, 80, 110] },
  });
  y = (doc as any).lastAutoTable.finalY + 4;

  // === Audit összefoglaló dedikált oldalon ===
  // A jogi hivatkozás-audit hibái / figyelmeztetései / infói egy pillantásra láthatók.
  doc.addPage();
  const pageW = doc.internal.pageSize.getWidth();
  let ay = margin;

  doc.setFont("helvetica", "bold");
  doc.setFontSize(14);
  doc.text("Jogi hivatkozás-audit — összefoglaló", margin, ay);
  ay += 6;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.setTextColor(100);
  doc.text(
    `Vonatkozás: ${payload.datum} · Munkavállaló: ${payload.name ?? "—"}`,
    margin,
    ay,
  );
  doc.setTextColor(0);
  ay += 6;

  // Számláló dobozok (Hibák / Figyelmeztetések / Információk)
  const errs = issues.filter((i) => i.severity === "error").length;
  const warns = issues.filter((i) => i.severity === "warning").length;
  const infos = issues.filter((i) => i.severity === "info").length;
  const boxW = (pageW - margin * 2 - 8) / 3;
  const boxH = 18;
  const boxes: Array<{ label: string; n: number; bg: [number, number, number]; fg: [number, number, number] }> = [
    { label: "Hibák", n: errs, bg: [250, 220, 220], fg: [150, 30, 30] },
    { label: "Figyelmeztetések", n: warns, bg: [255, 240, 200], fg: [150, 100, 20] },
    { label: "Információk", n: infos, bg: [220, 230, 245], fg: [40, 70, 130] },
  ];
  boxes.forEach((box, i) => {
    const x = margin + i * (boxW + 4);
    doc.setFillColor(box.bg[0], box.bg[1], box.bg[2]);
    doc.roundedRect(x, ay, boxW, boxH, 2, 2, "F");
    doc.setTextColor(box.fg[0], box.fg[1], box.fg[2]);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(18);
    doc.text(String(box.n), x + 4, ay + 10);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    doc.text(box.label, x + 4, ay + 15);
  });
  doc.setTextColor(0);
  ay += boxH + 6;

  if (issues.length === 0) {
    doc.setFillColor(220, 245, 225);
    doc.roundedRect(margin, ay, pageW - margin * 2, 14, 2, 2, "F");
    doc.setTextColor(30, 100, 50);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(11);
    doc.text("Nincs észlelt hiányosság — a számítás megfelel az aktív jogi hivatkozásoknak.", margin + 4, ay + 9);
    doc.setTextColor(0);
    doc.setFont("helvetica", "normal");
    ay += 18;
  } else {
    autoTable(doc, {
      startY: ay,
      head: [["Szint", "Tétel", "Üzenet", "Jogszabály"]],
      body: issues.map((i) => [
        i.severity === "error" ? "HIBA" : i.severity === "warning" ? "FIGYELM." : "INFO",
        i.cimke,
        i.uzenet,
        i.szukseges_hivatkozas
          ? `${i.szukseges_hivatkozas.jogszabaly} — ${i.szukseges_hivatkozas.szakasz}`
          : "—",
      ]),
      styles: { fontSize: 8, cellPadding: 2 },
      headStyles: { fillColor: [80, 80, 100] },
      columnStyles: {
        0: { cellWidth: 22, fontStyle: "bold" },
        3: { cellWidth: 40, textColor: [80, 80, 80] },
      },
      didParseCell: (data) => {
        if (data.section === "body" && data.column.index === 0) {
          const v = (data.cell.raw as string) ?? "";
          if (v === "HIBA") {
            data.cell.styles.fillColor = [250, 220, 220];
            data.cell.styles.textColor = [150, 30, 30];
          } else if (v === "FIGYELM.") {
            data.cell.styles.fillColor = [255, 240, 200];
            data.cell.styles.textColor = [150, 100, 20];
          } else if (v === "INFO") {
            data.cell.styles.fillColor = [220, 230, 245];
            data.cell.styles.textColor = [40, 70, 130];
          }
        }
      },
    });
    ay = (doc as any).lastAutoTable.finalY + 6;
  }

  doc.setFontSize(8);
  doc.setTextColor(100);
  doc.text(
    "Tájékoztató jellegű kalkuláció — a tényleges bér-elszámolás a HR feladata. Az audit a beállított jogi referenciák alapján fut.",
    margin,
    ay + 2,
  );

  doc.save(filename);
}
