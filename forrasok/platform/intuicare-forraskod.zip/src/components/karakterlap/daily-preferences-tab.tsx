import { useEffect, useMemo, useState } from "react";
import { Loader2, CalendarDays, Save, Settings2, Wand2, AlertTriangle, CheckCircle2, X, History, Clock } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { humanizeError } from "@/lib/humanize-error";
import { toast } from "sonner";
import { useTranslation } from "react-i18next";

type PrefStatus = "tervezett" | "jovahagyasra_var" | "jovahagyott" | "elutasitott";

type DailyPref = {
  id?: string;
  nap_iso: number;
  preferalt_kezd: string | null;
  preferalt_veg: string | null;
  kerult_kezd: string | null;
  kerult_veg: string | null;
  max_muszak_hossz_ora: number | null;
  ugyelet_vallal: boolean | null;
  keszenlet_vallal: boolean | null;
  megjegyzes: string | null;
  status?: PrefStatus;
  submitted_at?: string | null;
  jovahagyo_id?: string | null;
  jovahagyo_nev?: string | null;
  jovahagyas_at?: string | null;
  jovahagyas_indok?: string | null;
};

type PrefEvent = {
  id: string;
  action: string;
  from_status: string | null;
  to_status: string | null;
  actor_id: string | null;
  actor_nev?: string | null;
  indok: string | null;
  created_at: string;
  nap_iso: number | null;
};

const STATUS_LABEL: Record<PrefStatus, string> = {
  tervezett: "Tervezet",
  jovahagyasra_var: "Jóváhagyásra vár",
  jovahagyott: "Jóváhagyva",
  elutasitott: "Elutasítva",
};
const STATUS_CLASS: Record<PrefStatus, string> = {
  tervezett: "bg-muted text-muted-foreground",
  jovahagyasra_var: "bg-amber-100 text-amber-900",
  jovahagyott: "bg-emerald-100 text-emerald-900",
  elutasitott: "bg-red-100 text-red-900",
};
const ACTION_LABEL: Record<string, string> = {
  letrehozva: "Létrehozva",
  modositva: "Módosítva",
  beadva: "Beadva jóváhagyásra",
  jovahagyva: "Jóváhagyva",
  elutasitva: "Elutasítva",
  torolve: "Törölve",
};

function fmtDateTime(s: string | null | undefined) {
  if (!s) return "";
  try {
    return new Date(s).toLocaleString("hu-HU", { dateStyle: "short", timeStyle: "short" });
  } catch {
    return s;
  }
}

const NAPOK = ["Hétfő", "Kedd", "Szerda", "Csütörtök", "Péntek", "Szombat", "Vasárnap"];
const NAPOK_ROVID = ["H", "K", "Sze", "Cs", "P", "Szo", "V"];

type PresetKey =
  | "barmi"
  | "nem"
  | "nappal"
  | "16ba"
  | "24be"
  | "csak_ugyelet"
  | "csak_keszenlet"
  | "egyedi";

const PRESET_LABEL: Record<PresetKey, string> = {
  barmi: "Bármi belefér (nincs preferencia)",
  nem: "Nem szeretne dolgozni",
  nappal: "Csak nappal (07–15)",
  "16ba": "16-ig (07–16)",
  "24be": "24 órás ügyelet (07→07)",
  csak_ugyelet: "Csak ügyelni szeretne",
  csak_keszenlet: "Csak készenlétet vállal",
  egyedi: "Egyedi időablakok",
};

const PRESET_DESC: Record<PresetKey, string> = {
  barmi: "Nincs külön kérés erre a napra.",
  nem: "A motor kerüli, hogy erre a napra műszakot adjon.",
  nappal: "Nappali (07:00–15:00) műszakot preferál, ügyelet/készenlét nélkül.",
  "16ba": "Hosszított nappal 07:00–16:00, ügyelet nélkül.",
  "24be": "Teljes 24 órás ügyeletet vállal (07:00 → másnap 07:00).",
  csak_ugyelet: "Csak ügyeletes (éjszakai) műszakot szeretne, nappalit nem.",
  csak_keszenlet: "Csak hívható készenlétet vállal, fizikai jelenlétet nem.",
  egyedi: "Szabadon szerkeszthető idő-mezők (haladó).",
};

const PRESET_ORDER: PresetKey[] = [
  "barmi",
  "nappal",
  "16ba",
  "24be",
  "csak_ugyelet",
  "csak_keszenlet",
  "nem",
  "egyedi",
];

// Presets that imply a meaningful workload change → require supervisor approval
const APPROVAL_REQUIRED: PresetKey[] = ["nem", "24be", "csak_ugyelet", "csak_keszenlet"];

function detectPreset(r: DailyPref): PresetKey {
  const allNull =
    !r.preferalt_kezd &&
    !r.preferalt_veg &&
    !r.kerult_kezd &&
    !r.kerult_veg &&
    r.max_muszak_hossz_ora == null &&
    !r.ugyelet_vallal &&
    !r.keszenlet_vallal;
  if (allNull) return "barmi";

  if (r.max_muszak_hossz_ora === 0 && r.ugyelet_vallal === false && r.keszenlet_vallal === false)
    return "nem";

  const pk = r.preferalt_kezd;
  const pv = r.preferalt_veg;
  if (pk === "07:00" && pv === "15:00" && !r.ugyelet_vallal && !r.keszenlet_vallal) return "nappal";
  if (pk === "07:00" && pv === "16:00" && !r.ugyelet_vallal && !r.keszenlet_vallal) return "16ba";
  if (pk === "07:00" && pv === "07:00" && r.ugyelet_vallal) return "24be";

  if (r.ugyelet_vallal && !r.keszenlet_vallal && !r.preferalt_kezd && !r.preferalt_veg)
    return "csak_ugyelet";
  if (r.keszenlet_vallal && !r.ugyelet_vallal && !r.preferalt_kezd && !r.preferalt_veg)
    return "csak_keszenlet";

  return "egyedi";
}

function applyPreset(r: DailyPref, preset: PresetKey): DailyPref {
  const base: DailyPref = {
    ...r,
    preferalt_kezd: null,
    preferalt_veg: null,
    kerult_kezd: null,
    kerult_veg: null,
    max_muszak_hossz_ora: null,
    ugyelet_vallal: null,
    keszenlet_vallal: null,
  };
  switch (preset) {
    case "barmi":
      return base;
    case "nem":
      return { ...base, max_muszak_hossz_ora: 0, ugyelet_vallal: false, keszenlet_vallal: false };
    case "nappal":
      return {
        ...base,
        preferalt_kezd: "07:00",
        preferalt_veg: "15:00",
        max_muszak_hossz_ora: 8,
        ugyelet_vallal: false,
        keszenlet_vallal: false,
      };
    case "16ba":
      return {
        ...base,
        preferalt_kezd: "07:00",
        preferalt_veg: "16:00",
        max_muszak_hossz_ora: 9,
        ugyelet_vallal: false,
        keszenlet_vallal: false,
      };
    case "24be":
      return {
        ...base,
        preferalt_kezd: "07:00",
        preferalt_veg: "07:00",
        max_muszak_hossz_ora: 24,
        ugyelet_vallal: true,
        keszenlet_vallal: false,
      };
    case "csak_ugyelet":
      return { ...base, ugyelet_vallal: true, keszenlet_vallal: false };
    case "csak_keszenlet":
      return { ...base, ugyelet_vallal: false, keszenlet_vallal: true };
    case "egyedi":
      return { ...r };
  }
}

type DayGroupKey = "hetfo_pentek" | "hetvege" | "minden" | "egyedi";
const DAY_GROUPS: { key: DayGroupKey; label: string; days: number[] }[] = [
  { key: "hetfo_pentek", label: "Hétfő–Péntek", days: [1, 2, 3, 4, 5] },
  { key: "hetvege", label: "Hétvége (Szo–V)", days: [6, 7] },
  { key: "minden", label: "Minden nap", days: [1, 2, 3, 4, 5, 6, 7] },
];

type DiffEntry = { nap_iso: number; from: PresetKey; to: PresetKey };

export function DailyPreferencesTab({
  userId,
  tenantId,
}: {
  userId: string;
  tenantId: string | null;
}) {
  const { t } = useTranslation();
  const [rows, setRows] = useState<DailyPref[]>([]);
  const [baseline, setBaseline] = useState<Record<number, PresetKey>>({});
  const [loading, setLoading] = useState(true);
  const [savingAll, setSavingAll] = useState(false);
  const [advanced, setAdvanced] = useState<Record<number, boolean>>({});

  // Bulk apply UI
  const [bulkPreset, setBulkPreset] = useState<PresetKey>("nappal");
  const [bulkDays, setBulkDays] = useState<Set<number>>(new Set([1, 2, 3, 4, 5]));

  // Confirmation modal
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [confirmAck, setConfirmAck] = useState(false);

  // Post-save summary
  const [summary, setSummary] = useState<DiffEntry[] | null>(null);

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId]);

  async function load() {
    setLoading(true);
    const { data, error } = await supabase
      .from("profile_daily_preferences")
      .select(
        "id,nap_iso,preferalt_kezd,preferalt_veg,kerult_kezd,kerult_veg,max_muszak_hossz_ora,ugyelet_vallal,keszenlet_vallal,megjegyzes,status,submitted_at,jovahagyo_id,jovahagyas_at,jovahagyas_indok,jovahagyo:profiles!profile_daily_preferences_jovahagyo_id_fkey(teljes_nev)",
      )
      .eq("user_id", userId)
      .is("ervenyes_ig", null)
      .order("nap_iso");
    if (error) toast.error(humanizeError(error, t));
    const existing = ((data ?? []) as any[]).map((r) => ({
      ...r,
      jovahagyo_nev: r.jovahagyo?.teljes_nev ?? null,
    })) as DailyPref[];
    const map = new Map(existing.map((r) => [r.nap_iso, r]));
    const full: DailyPref[] = [];
    for (let i = 1; i <= 7; i++) {
      full.push(
        map.get(i) ?? {
          nap_iso: i,
          preferalt_kezd: null,
          preferalt_veg: null,
          kerult_kezd: null,
          kerult_veg: null,
          max_muszak_hossz_ora: null,
          ugyelet_vallal: null,
          keszenlet_vallal: null,
          megjegyzes: null,
          status: "tervezett",
        },
      );
    }
    setRows(full);
    const base: Record<number, PresetKey> = {};
    full.forEach((r) => (base[r.nap_iso] = detectPreset(r)));
    setBaseline(base);
    setLoading(false);
  }

  const diff: DiffEntry[] = useMemo(() => {
    return rows
      .map((r) => {
        const to = detectPreset(r);
        const from = baseline[r.nap_iso] ?? "barmi";
        return from === to ? null : { nap_iso: r.nap_iso, from, to };
      })
      .filter((x): x is DiffEntry => x !== null);
  }, [rows, baseline]);

  const approvalNeeded = diff.some((d) => APPROVAL_REQUIRED.includes(d.to));

  async function persistAll() {
    if (!tenantId) return;
    setSavingAll(true);
    const toSave = diff.map((d) => ({
      row: rows.find((r) => r.nap_iso === d.nap_iso)!,
      diff: d,
    }));
    let failed = 0;
    for (const { row, diff: d } of toSave) {
      const needsApproval = APPROVAL_REQUIRED.includes(d.to);
      const nextStatus: PrefStatus = needsApproval ? "jovahagyasra_var" : "tervezett";
      const payload: any = {
        tenant_id: tenantId,
        user_id: userId,
        nap_iso: row.nap_iso,
        preferalt_kezd: row.preferalt_kezd,
        preferalt_veg: row.preferalt_veg,
        kerult_kezd: row.kerult_kezd,
        kerult_veg: row.kerult_veg,
        max_muszak_hossz_ora: row.max_muszak_hossz_ora,
        ugyelet_vallal: row.ugyelet_vallal,
        keszenlet_vallal: row.keszenlet_vallal,
        megjegyzes: row.megjegyzes,
        status: nextStatus,
      };
      let error;
      if (row.id) {
        ({ error } = await (supabase.from("profile_daily_preferences") as any)
          .update(payload)
          .eq("id", row.id));
      } else {
        const res = await (supabase.from("profile_daily_preferences") as any)
          .insert(payload)
          .select("id")
          .single();
        error = res.error;
        if (!error) row.id = res.data.id;
      }
      if (error) {
        failed++;
        toast.error(`${NAPOK[row.nap_iso - 1]}: ${humanizeError(error, t)}`);
      } else {
        row.status = nextStatus;
        row.submitted_at = needsApproval ? new Date().toISOString() : null;
        row.jovahagyo_id = null;
        row.jovahagyo_nev = null;
        row.jovahagyas_at = null;
      }
    }
    setSavingAll(false);
    setConfirmOpen(false);
    setConfirmAck(false);
    if (failed === 0) {
      setSummary(diff);
      const newBase = { ...baseline };
      diff.forEach((d) => (newBase[d.nap_iso] = d.to));
      setBaseline(newBase);
      setRows([...rows]);
      toast.success(`${diff.length} nap mentve`);
    }
  }

  // Event log modal state
  const [historyOpen, setHistoryOpen] = useState<{ nap: number; prefId: string } | null>(null);
  const [historyRows, setHistoryRows] = useState<PrefEvent[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);

  async function openHistory(nap: number, prefId: string) {
    setHistoryOpen({ nap, prefId });
    setHistoryLoading(true);
    setHistoryRows([]);
    const { data, error } = await supabase
      .from("profile_daily_preferences_events")
      .select(
        "id,action,from_status,to_status,actor_id,indok,created_at,nap_iso,actor:profiles!profile_daily_preferences_events_actor_id_fkey(teljes_nev)",
      )
      .eq("pref_id", prefId)
      .order("created_at", { ascending: false });
    setHistoryLoading(false);
    if (error) {
      toast.error(humanizeError(error, t));
      return;
    }
    setHistoryRows(
      ((data ?? []) as any[]).map((r) => ({ ...r, actor_nev: r.actor?.teljes_nev ?? null })),
    );
  }


  function update(nap: number, patch: Partial<DailyPref>) {
    setRows(rows.map((r) => (r.nap_iso === nap ? { ...r, ...patch } : r)));
  }

  function setPreset(nap: number, preset: PresetKey) {
    setRows(rows.map((r) => (r.nap_iso === nap ? applyPreset(r, preset) : r)));
    if (preset === "egyedi") setAdvanced((a) => ({ ...a, [nap]: true }));
  }

  function applyBulk() {
    if (bulkDays.size === 0) {
      toast.error("Válasszon legalább egy napot.");
      return;
    }
    setRows(rows.map((r) => (bulkDays.has(r.nap_iso) ? applyPreset(r, bulkPreset) : r)));
    if (bulkPreset === "egyedi") {
      const next = { ...advanced };
      bulkDays.forEach((d) => (next[d] = true));
      setAdvanced(next);
    }
    toast.message(
      `„${PRESET_LABEL[bulkPreset]}” alkalmazva: ${[...bulkDays]
        .sort()
        .map((d) => NAPOK_ROVID[d - 1])
        .join(", ")}`,
    );
  }

  function selectGroup(key: DayGroupKey) {
    const grp = DAY_GROUPS.find((g) => g.key === key);
    if (grp) setBulkDays(new Set(grp.days));
  }

  function toggleBulkDay(d: number) {
    const next = new Set(bulkDays);
    if (next.has(d)) next.delete(d);
    else next.add(d);
    setBulkDays(next);
  }

  if (loading) {
    return (
      <div className="flex h-32 items-center justify-center">
        <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <div className="flex items-center gap-2">
          <CalendarDays className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-medium">Napi műszak-preferenciák</h2>
        </div>
        <button
          onClick={() => setConfirmOpen(true)}
          disabled={diff.length === 0 || savingAll}
          className="flex items-center gap-1 rounded bg-primary px-3 py-1.5 text-primary-foreground text-sm hover:opacity-90 disabled:opacity-40"
        >
          <Save className="h-4 w-4" />
          Mentés ({diff.length} változás)
        </button>
      </div>
      <p className="text-xs text-muted-foreground">
        Válassza ki naponta, milyen műszakot szeretne. A beosztómotor lágy szabályként veszi
        figyelembe. Részletes idő-ablakokhoz használja az „Egyedi” módot.
      </p>

      {/* Bulk apply panel */}
      <div className="rounded-lg border bg-muted/20 p-3 space-y-2">
        <div className="flex items-center gap-2 text-sm font-medium">
          <Wand2 className="h-4 w-4 text-primary" />
          Gyors alkalmazás több napra
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <select
            value={bulkPreset}
            onChange={(e) => setBulkPreset(e.target.value as PresetKey)}
            className="rounded border bg-background px-2 py-1.5 text-sm min-w-[220px]"
          >
            {PRESET_ORDER.map((p) => (
              <option key={p} value={p}>
                {PRESET_LABEL[p]}
              </option>
            ))}
          </select>
          <div className="flex gap-1">
            {DAY_GROUPS.map((g) => (
              <button
                key={g.key}
                type="button"
                onClick={() => selectGroup(g.key)}
                className="rounded border px-2 py-1.5 text-xs hover:bg-background"
              >
                {g.label}
              </button>
            ))}
          </div>
          <div className="flex gap-1">
            {NAPOK_ROVID.map((n, i) => {
              const d = i + 1;
              const active = bulkDays.has(d);
              return (
                <button
                  key={d}
                  type="button"
                  onClick={() => toggleBulkDay(d)}
                  className={`w-8 h-8 rounded border text-xs font-medium transition-colors ${
                    active
                      ? "bg-primary text-primary-foreground border-primary"
                      : "bg-background hover:bg-muted"
                  }`}
                  title={NAPOK[i]}
                >
                  {n}
                </button>
              );
            })}
          </div>
          <button
            onClick={applyBulk}
            className="ml-auto rounded bg-secondary px-3 py-1.5 text-sm hover:opacity-90"
          >
            Alkalmaz
          </button>
        </div>
        <p className="text-[11px] text-muted-foreground">
          A változás csak akkor véglegesül, ha a fenti „Mentés” gombra kattint.
        </p>
      </div>

      {/* Day cards */}
      <div className="space-y-3">
        {rows.map((r) => {
          const preset = detectPreset(r);
          const base = baseline[r.nap_iso];
          const changed = base !== undefined && base !== preset;
          const showAdvanced = advanced[r.nap_iso] ?? preset === "egyedi";
          return (
            <div
              key={r.nap_iso}
              className={`rounded-lg border p-3 space-y-2 ${
                changed ? "border-amber-400 bg-amber-50/30" : "bg-card"
              }`}
            >
              <div className="flex flex-wrap items-center gap-3">
                <div className="w-20 font-medium text-sm flex items-center gap-1">
                  {NAPOK[r.nap_iso - 1]}
                  {changed && (
                    <span className="text-[10px] rounded bg-amber-200 text-amber-900 px-1">
                      mód.
                    </span>
                  )}
                </div>
                <select
                  value={preset}
                  onChange={(e) => setPreset(r.nap_iso, e.target.value as PresetKey)}
                  className="flex-1 min-w-[220px] rounded border bg-background px-2 py-1.5 text-sm"
                >
                  {PRESET_ORDER.map((p) => (
                    <option key={p} value={p}>
                      {PRESET_LABEL[p]}
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={() =>
                    setAdvanced((a) => ({ ...a, [r.nap_iso]: !showAdvanced }))
                  }
                  className="flex items-center gap-1 rounded border px-2 py-1.5 text-xs hover:bg-muted/50"
                  title="Haladó beállítások"
                >
                  <Settings2 className="h-3.5 w-3.5" />
                  Haladó
                </button>
                {r.id && (
                  <button
                    type="button"
                    onClick={() => openHistory(r.nap_iso, r.id!)}
                    className="flex items-center gap-1 rounded border px-2 py-1.5 text-xs hover:bg-muted/50"
                    title="Eseménynapló"
                  >
                    <History className="h-3.5 w-3.5" />
                    Történet
                  </button>
                )}
              </div>
              <div className="flex flex-wrap items-center gap-2 pl-[5.5rem]">
                {r.status && (
                  <span className={`text-[10px] rounded px-1.5 py-0.5 ${STATUS_CLASS[r.status]}`}>
                    {STATUS_LABEL[r.status]}
                  </span>
                )}
                {r.status === "jovahagyott" && r.jovahagyo_nev && (
                  <span className="text-[11px] text-muted-foreground flex items-center gap-1">
                    <CheckCircle2 className="h-3 w-3 text-emerald-600" />
                    {r.jovahagyo_nev} · {fmtDateTime(r.jovahagyas_at)}
                  </span>
                )}
                {r.status === "elutasitott" && (
                  <span className="text-[11px] text-red-700 flex items-center gap-1">
                    <AlertTriangle className="h-3 w-3" />
                    {r.jovahagyo_nev ?? "Vezető"} · {fmtDateTime(r.jovahagyas_at)}
                    {r.jovahagyas_indok && ` – ${r.jovahagyas_indok}`}
                  </span>
                )}
                {r.status === "jovahagyasra_var" && r.submitted_at && (
                  <span className="text-[11px] text-muted-foreground flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    Beadva: {fmtDateTime(r.submitted_at)}
                  </span>
                )}
              </div>
              <p className="text-[11px] text-muted-foreground pl-[5.5rem]">
                {PRESET_DESC[preset]}
              </p>


              {showAdvanced && (
                <div className="mt-2 grid grid-cols-2 md:grid-cols-4 gap-2 rounded border bg-muted/20 p-2 text-xs">
                  <label className="flex flex-col gap-0.5">
                    <span className="text-muted-foreground">Preferált kezdés</span>
                    <input
                      type="time"
                      value={r.preferalt_kezd ?? ""}
                      onChange={(e) =>
                        update(r.nap_iso, { preferalt_kezd: e.target.value || null })
                      }
                      className="rounded border bg-background px-1.5 py-1"
                    />
                  </label>
                  <label className="flex flex-col gap-0.5">
                    <span className="text-muted-foreground">Preferált vég</span>
                    <input
                      type="time"
                      value={r.preferalt_veg ?? ""}
                      onChange={(e) =>
                        update(r.nap_iso, { preferalt_veg: e.target.value || null })
                      }
                      className="rounded border bg-background px-1.5 py-1"
                    />
                  </label>
                  <label className="flex flex-col gap-0.5">
                    <span className="text-muted-foreground">Került kezdés</span>
                    <input
                      type="time"
                      value={r.kerult_kezd ?? ""}
                      onChange={(e) =>
                        update(r.nap_iso, { kerult_kezd: e.target.value || null })
                      }
                      className="rounded border bg-background px-1.5 py-1"
                    />
                  </label>
                  <label className="flex flex-col gap-0.5">
                    <span className="text-muted-foreground">Került vég</span>
                    <input
                      type="time"
                      value={r.kerult_veg ?? ""}
                      onChange={(e) =>
                        update(r.nap_iso, { kerult_veg: e.target.value || null })
                      }
                      className="rounded border bg-background px-1.5 py-1"
                    />
                  </label>
                  <label className="flex flex-col gap-0.5">
                    <span className="text-muted-foreground">Max műszak (óra)</span>
                    <input
                      type="number"
                      step="0.5"
                      value={r.max_muszak_hossz_ora ?? ""}
                      onChange={(e) =>
                        update(r.nap_iso, {
                          max_muszak_hossz_ora: e.target.value ? Number(e.target.value) : null,
                        })
                      }
                      className="rounded border bg-background px-1.5 py-1"
                    />
                  </label>
                  <label className="flex items-center gap-2 mt-4">
                    <input
                      type="checkbox"
                      checked={r.ugyelet_vallal ?? false}
                      onChange={(e) => update(r.nap_iso, { ugyelet_vallal: e.target.checked })}
                    />
                    <span>Ügyeletet vállal</span>
                  </label>
                  <label className="flex items-center gap-2 mt-4">
                    <input
                      type="checkbox"
                      checked={r.keszenlet_vallal ?? false}
                      onChange={(e) => update(r.nap_iso, { keszenlet_vallal: e.target.checked })}
                    />
                    <span>Készenlétet vállal</span>
                  </label>
                  <label className="col-span-2 md:col-span-4 flex flex-col gap-0.5">
                    <span className="text-muted-foreground">Megjegyzés</span>
                    <input
                      type="text"
                      value={r.megjegyzes ?? ""}
                      onChange={(e) =>
                        update(r.nap_iso, { megjegyzes: e.target.value || null })
                      }
                      className="rounded border bg-background px-1.5 py-1"
                    />
                  </label>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Confirmation modal */}
      {confirmOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-card rounded-lg shadow-lg max-w-lg w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-4 border-b">
              <h3 className="font-medium">Változások megerősítése</h3>
              <button
                onClick={() => {
                  setConfirmOpen(false);
                  setConfirmAck(false);
                }}
                className="text-muted-foreground hover:text-foreground"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="p-4 space-y-3">
              <p className="text-sm text-muted-foreground">
                Az alábbi napokra mentődnek a preferencia-változások:
              </p>
              <ul className="space-y-1.5 text-sm">
                {diff.map((d) => {
                  const needs = APPROVAL_REQUIRED.includes(d.to);
                  return (
                    <li
                      key={d.nap_iso}
                      className="flex items-start gap-2 rounded border bg-muted/20 p-2"
                    >
                      <span className="font-medium w-20 shrink-0">
                        {NAPOK[d.nap_iso - 1]}
                      </span>
                      <span className="text-xs text-muted-foreground flex-1">
                        {PRESET_LABEL[d.from]} → <strong>{PRESET_LABEL[d.to]}</strong>
                      </span>
                      {needs && (
                        <span className="text-[10px] rounded bg-amber-200 text-amber-900 px-1.5 py-0.5">
                          jóváhagyás
                        </span>
                      )}
                    </li>
                  );
                })}
              </ul>

              {approvalNeeded && (
                <div className="flex gap-2 rounded border border-amber-300 bg-amber-50 p-3 text-sm">
                  <AlertTriangle className="h-4 w-4 text-amber-600 shrink-0 mt-0.5" />
                  <div className="space-y-2">
                    <p>
                      A jelölt napok beállítása <strong>vezetői jóváhagyást igényel</strong>{" "}
                      (ügyelet, készenlét vagy „nem dolgozik” preferencia). A mentés után a
                      vezető értesítést kap a kérelemről.
                    </p>
                    <label className="flex items-center gap-2 text-xs">
                      <input
                        type="checkbox"
                        checked={confirmAck}
                        onChange={(e) => setConfirmAck(e.target.checked)}
                      />
                      Tudomásul veszem, hogy a változtatás vezetői jóváhagyást igényel.
                    </label>
                  </div>
                </div>
              )}
            </div>
            <div className="flex justify-end gap-2 p-4 border-t">
              <button
                onClick={() => {
                  setConfirmOpen(false);
                  setConfirmAck(false);
                }}
                className="rounded border px-3 py-1.5 text-sm hover:bg-muted/50"
              >
                Mégse
              </button>
              <button
                onClick={persistAll}
                disabled={savingAll || (approvalNeeded && !confirmAck)}
                className="flex items-center gap-1 rounded bg-primary px-3 py-1.5 text-sm text-primary-foreground hover:opacity-90 disabled:opacity-40"
              >
                {savingAll ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Save className="h-4 w-4" />
                )}
                Megerősítés és mentés
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Post-save summary modal */}
      {summary && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-card rounded-lg shadow-lg max-w-md w-full">
            <div className="flex items-center justify-between p-4 border-b">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-5 w-5 text-emerald-600" />
                <h3 className="font-medium">Mentés sikeres</h3>
              </div>
              <button
                onClick={() => setSummary(null)}
                className="text-muted-foreground hover:text-foreground"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="p-4 space-y-2">
              <p className="text-sm text-muted-foreground">
                {summary.length} nap mentve. Összegzés:
              </p>
              <ul className="space-y-1 text-sm">
                {summary.map((d) => (
                  <li key={d.nap_iso} className="flex gap-2">
                    <span className="font-medium w-20">{NAPOK[d.nap_iso - 1]}</span>
                    <span className="text-muted-foreground">{PRESET_LABEL[d.to]}</span>
                  </li>
                ))}
              </ul>
              {summary.some((d) => APPROVAL_REQUIRED.includes(d.to)) && (
                <div className="flex gap-2 rounded border border-amber-300 bg-amber-50 p-2 text-xs mt-2">
                  <AlertTriangle className="h-4 w-4 text-amber-600 shrink-0" />
                  <span>A jóváhagyás-köteles napokról értesítettük a vezetőt.</span>
                </div>
              )}
            </div>
            <div className="flex justify-end p-4 border-t">
              <button
                onClick={() => setSummary(null)}
                className="rounded bg-primary px-3 py-1.5 text-sm text-primary-foreground hover:opacity-90"
              >
                Rendben
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Event log modal */}
      {historyOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-card rounded-lg shadow-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-4 border-b">
              <div className="flex items-center gap-2">
                <History className="h-5 w-5 text-primary" />
                <h3 className="font-medium">
                  {NAPOK[historyOpen.nap - 1]} – Eseménynapló
                </h3>
              </div>
              <button
                onClick={() => setHistoryOpen(null)}
                className="text-muted-foreground hover:text-foreground"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="p-4">
              {historyLoading ? (
                <div className="flex justify-center py-6">
                  <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                </div>
              ) : historyRows.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-6">
                  Még nincs naplóesemény.
                </p>
              ) : (
                <ol className="space-y-2">
                  {historyRows.map((e) => (
                    <li
                      key={e.id}
                      className="rounded border bg-muted/20 p-2 text-sm space-y-0.5"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-medium">
                          {ACTION_LABEL[e.action] ?? e.action}
                        </span>
                        <span className="text-[11px] text-muted-foreground">
                          {fmtDateTime(e.created_at)}
                        </span>
                      </div>
                      <div className="text-[11px] text-muted-foreground">
                        {e.actor_nev ?? "Rendszer"}
                        {e.from_status && e.to_status && e.from_status !== e.to_status && (
                          <>
                            {" · "}
                            {STATUS_LABEL[e.from_status as PrefStatus] ?? e.from_status} →{" "}
                            <strong>
                              {STATUS_LABEL[e.to_status as PrefStatus] ?? e.to_status}
                            </strong>
                          </>
                        )}
                      </div>
                      {e.indok && (
                        <div className="text-[11px] text-foreground/80 mt-1">
                          <strong>Indok:</strong> {e.indok}
                        </div>
                      )}
                    </li>
                  ))}
                </ol>
              )}
            </div>
            <div className="flex justify-end p-4 border-t">
              <button
                onClick={() => setHistoryOpen(null)}
                className="rounded bg-primary px-3 py-1.5 text-sm text-primary-foreground hover:opacity-90"
              >
                Bezár
              </button>
            </div>
          </div>
        </div>
      )}
    </div>

  );
}
