/**
 * Időszakos havi munkaidő-keret szerkesztő a karakterlapon.
 * Bemeneti validáció: tól<=ig, 1-744 óra/hó (max naptári óra), 1-200 % keret,
 * negatív értékek tiltva, irreális értékekre figyelmeztetés.
 * Mentés után meghívja az onChange callbacket, hogy az illetmény-kalkulátor
 * újraszámolhasson az új órakerettel.
 */
import { useMemo, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Plus, Trash2, Calendar as CalendarIcon, Loader2, AlertTriangle } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import {
  listWorkTimeFrames,
  upsertWorkTimeFrame,
  deleteWorkTimeFrame,
  getActiveWorkTimeFrame,
} from "@/lib/eusztv/illetmeny.functions";

type Frame = {
  id?: string;
  user_id: string;
  tenant_id: string;
  ervenyes_tol: string;
  ervenyes_ig: string | null;
  havi_orakeret: number | null;
  szazalek: number | null;
  indok: string | null;
};

const MAX_HAVI_ORA = 744; // 31 nap × 24 óra naptári maximum
const REALIS_HAVI_ORA_MAX = 250; // ennél nagyobb gyanús (kb. 30 nap × 8 óra ~ 240)
const MIN_PERC = 1;
const MAX_PERC = 200;

type ValidationIssue = { level: "error" | "warning"; uzenet: string };

function validateFrame(f: Frame): ValidationIssue[] {
  const out: ValidationIssue[] = [];
  if (!f.ervenyes_tol) out.push({ level: "error", uzenet: "Érvényes-tól kötelező." });
  if (f.ervenyes_ig && f.ervenyes_tol && f.ervenyes_ig < f.ervenyes_tol) {
    out.push({ level: "error", uzenet: "Az „Érvényes-ig” nem lehet korábbi, mint az „Érvényes-tól”." });
  }
  if (f.havi_orakeret == null && f.szazalek == null) {
    out.push({ level: "error", uzenet: "Legalább óra/hó vagy százalék megadása kötelező." });
  }
  if (f.havi_orakeret != null) {
    if (!Number.isFinite(f.havi_orakeret) || f.havi_orakeret <= 0) {
      out.push({ level: "error", uzenet: "Az óra/hó értéknek pozitívnak kell lennie." });
    } else if (f.havi_orakeret > MAX_HAVI_ORA) {
      out.push({ level: "error", uzenet: `Az óra/hó nem lehet több, mint ${MAX_HAVI_ORA} (naptári maximum).` });
    } else if (f.havi_orakeret > REALIS_HAVI_ORA_MAX) {
      out.push({ level: "warning", uzenet: `Szokatlanul magas órakeret (${f.havi_orakeret} óra/hó). Ellenőrizd.` });
    }
  }
  if (f.szazalek != null) {
    if (!Number.isFinite(f.szazalek) || f.szazalek < MIN_PERC) {
      out.push({ level: "error", uzenet: "A százalék értéknek pozitívnak kell lennie." });
    } else if (f.szazalek > MAX_PERC) {
      out.push({ level: "error", uzenet: `A százalék nem lehet több, mint ${MAX_PERC}%.` });
    } else if (f.szazalek > 100) {
      out.push({ level: "warning", uzenet: `100% feletti foglalkoztatás (${f.szazalek}%). Ellenőrizd.` });
    }
  }
  return out;
}

export function WorkTimeFrameEditor({
  userId,
  tenantId,
  onActiveFrameChange,
}: {
  userId: string;
  tenantId: string;
  onActiveFrameChange?: (orakeret: number | null) => void;
}) {
  const qc = useQueryClient();
  const listFn = useServerFn(listWorkTimeFrames);
  const upsertFn = useServerFn(upsertWorkTimeFrame);
  const deleteFn = useServerFn(deleteWorkTimeFrame);
  const activeFn = useServerFn(getActiveWorkTimeFrame);

  const { data: rows = [], isLoading } = useQuery({
    queryKey: ["wtf", userId],
    queryFn: () => listFn({ data: { userId } }),
  });

  const { data: active } = useQuery({
    queryKey: ["wtf-active", userId],
    queryFn: async () => {
      const r = await activeFn({ data: { userId } });
      const ora = r?.havi_orakeret ?? (r?.szazalek ? (174 * r.szazalek) / 100 : null);
      onActiveFrameChange?.(ora);
      return r;
    },
  });

  const [draft, setDraft] = useState<Frame>({
    user_id: userId,
    tenant_id: tenantId,
    ervenyes_tol: new Date().toISOString().slice(0, 10),
    ervenyes_ig: null,
    havi_orakeret: 174,
    szazalek: null,
    indok: "",
  });

  const issues = useMemo(() => validateFrame(draft), [draft]);
  const hasError = issues.some((i) => i.level === "error");
  const warnings = issues.filter((i) => i.level === "warning");

  const save = useMutation({
    mutationFn: async (f: Frame) => upsertFn({ data: f as any }),
    onSuccess: () => {
      toast.success("Munkaidő-keret mentve.");
      qc.invalidateQueries({ queryKey: ["wtf", userId] });
      qc.invalidateQueries({ queryKey: ["wtf-active", userId] });
    },
    onError: (e: any) => toast.error("Mentés sikertelen", { description: e.message }),
  });

  const del = useMutation({
    mutationFn: async (id: string) => deleteFn({ data: { id } }),
    onSuccess: () => {
      toast.success("Törölve.");
      qc.invalidateQueries({ queryKey: ["wtf", userId] });
      qc.invalidateQueries({ queryKey: ["wtf-active", userId] });
    },
  });

  const handleAdd = () => {
    const errs = issues.filter((i) => i.level === "error");
    if (errs.length) {
      toast.error("Érvénytelen bemenet", { description: errs.map((e) => e.uzenet).join(" · ") });
      return;
    }
    save.mutate(draft);
  };

  return (
    <Card className="p-4 space-y-3">
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2 font-medium">
            <CalendarIcon className="h-4 w-4" /> Időszakos munkaidő-keret
          </div>
          <div className="text-xs text-muted-foreground">
            {active
              ? `Aktív: ${active.ervenyes_tol} → ${active.ervenyes_ig ?? "—"} · ${
                  active.havi_orakeret ?? `${active.szazalek}%`
                } óra/hó`
              : "Nincs aktív keret — alapértelmezett 174 óra/hó."}
          </div>
        </div>
      </div>

      {/* Új sor */}
      <div className="grid grid-cols-1 md:grid-cols-6 gap-2 items-end border rounded-md p-3 bg-muted/30">
        <Field
          label="Érvényes-tól"
          type="date"
          value={draft.ervenyes_tol}
          onChange={(v) => setDraft({ ...draft, ervenyes_tol: v })}
          invalid={!draft.ervenyes_tol}
        />
        <Field
          label="Érvényes-ig"
          type="date"
          value={draft.ervenyes_ig ?? ""}
          onChange={(v) => setDraft({ ...draft, ervenyes_ig: v || null })}
          invalid={!!draft.ervenyes_ig && draft.ervenyes_ig < draft.ervenyes_tol}
        />
        <Field
          label={`Óra/hó (1–${MAX_HAVI_ORA})`}
          type="number"
          min={0}
          max={MAX_HAVI_ORA}
          value={draft.havi_orakeret?.toString() ?? ""}
          onChange={(v) => setDraft({ ...draft, havi_orakeret: v === "" ? null : Number(v) })}
          invalid={
            draft.havi_orakeret != null &&
            (draft.havi_orakeret <= 0 || draft.havi_orakeret > MAX_HAVI_ORA)
          }
          warn={draft.havi_orakeret != null && draft.havi_orakeret > REALIS_HAVI_ORA_MAX && draft.havi_orakeret <= MAX_HAVI_ORA}
        />
        <Field
          label={`Százalék % (1–${MAX_PERC})`}
          type="number"
          min={0}
          max={MAX_PERC}
          value={draft.szazalek?.toString() ?? ""}
          onChange={(v) => setDraft({ ...draft, szazalek: v === "" ? null : Number(v) })}
          invalid={draft.szazalek != null && (draft.szazalek < MIN_PERC || draft.szazalek > MAX_PERC)}
          warn={draft.szazalek != null && draft.szazalek > 100 && draft.szazalek <= MAX_PERC}
        />
        <Field
          label="Indok"
          type="text"
          value={draft.indok ?? ""}
          onChange={(v) => setDraft({ ...draft, indok: v })}
        />
        <Button size="sm" onClick={handleAdd} disabled={save.isPending || hasError}>
          <Plus className="h-3 w-3 mr-1" /> Hozzáad
        </Button>
      </div>

      {/* Validációs üzenetek */}
      {issues.length > 0 && (
        <div className="space-y-1">
          {issues.map((i, idx) => (
            <div
              key={idx}
              className={cn(
                "flex items-start gap-2 text-xs rounded-md px-2 py-1.5",
                i.level === "error"
                  ? "bg-destructive/10 text-destructive"
                  : "bg-yellow-500/10 text-yellow-700 dark:text-yellow-400",
              )}
              role="alert"
            >
              <AlertTriangle className="h-3.5 w-3.5 mt-0.5 shrink-0" />
              <span>{i.uzenet}</span>
            </div>
          ))}
        </div>
      )}
      {issues.length === 0 && warnings.length === 0 && (
        <div className="text-[10px] text-muted-foreground">
          Maximum {MAX_HAVI_ORA} óra/hó (naptári), 1–{MAX_PERC} % keret. Negatív és valószerűtlen értékeket a rendszer kiszűri.
        </div>
      )}

      {/* Lista */}
      {isLoading ? (
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Betöltés…
        </div>
      ) : rows.length === 0 ? (
        <div className="text-xs text-muted-foreground">Nincs rögzített időszak.</div>
      ) : (
        <div className="border rounded-md overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-xs">
              <tr>
                <th className="px-2 py-1 text-left">Érvényes-tól</th>
                <th className="px-2 py-1 text-left">Érvényes-ig</th>
                <th className="px-2 py-1 text-right">Óra/hó</th>
                <th className="px-2 py-1 text-right">%</th>
                <th className="px-2 py-1 text-left">Indok</th>
                <th className="px-2 py-1"></th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r: any) => (
                <tr key={r.id} className="border-t">
                  <td className="px-2 py-1">{r.ervenyes_tol}</td>
                  <td className="px-2 py-1">{r.ervenyes_ig ?? "—"}</td>
                  <td className="px-2 py-1 text-right">{r.havi_orakeret ?? "—"}</td>
                  <td className="px-2 py-1 text-right">{r.szazalek ?? "—"}</td>
                  <td className="px-2 py-1">{r.indok ?? ""}</td>
                  <td className="px-2 py-1 text-right">
                    <Button size="icon" variant="ghost" onClick={() => del.mutate(r.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Card>
  );
}

function Field({
  label,
  type,
  value,
  onChange,
  invalid,
  warn,
  min,
  max,
}: {
  label: string;
  type: "date" | "number" | "text";
  value: string;
  onChange: (v: string) => void;
  invalid?: boolean;
  warn?: boolean;
  min?: number;
  max?: number;
}) {
  return (
    <div className="space-y-1">
      <Label className="text-xs">{label}</Label>
      <Input
        type={type}
        value={value}
        min={min}
        max={max}
        aria-invalid={invalid || undefined}
        onChange={(e) => onChange(e.target.value)}
        className={cn(
          "h-8",
          invalid && "border-destructive focus-visible:ring-destructive",
          !invalid && warn && "border-yellow-500 focus-visible:ring-yellow-500",
        )}
      />
    </div>
  );
}

