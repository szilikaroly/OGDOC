import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Plus, Trash2, Building2, Save } from "lucide-react";
import { toast } from "sonner";

type Row = {
  id: string;
  ev: number;
  honap: number;
  ora: number;
  hely: string | null;
  jogviszony_tipus: string | null;
  megjegyzes: string | null;
};

const MONTHS = [
  "Jan", "Feb", "Már", "Ápr", "Máj", "Jún",
  "Júl", "Aug", "Szep", "Okt", "Nov", "Dec",
];

export function ExternalHoursTab({ userId, tenantId }: { userId: string; tenantId: string | null }) {
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [year, setYear] = useState(new Date().getFullYear());
  const [draft, setDraft] = useState({ hely: "", jogviszony_tipus: "", megjegyzes: "" });
  const [monthly, setMonthly] = useState<Record<number, string>>({});
  const [saving, setSaving] = useState(false);

  async function load() {
    setLoading(true);
    const { data, error } = await supabase
      .from("profile_external_hours")
      .select("id, ev, honap, ora, hely, jogviszony_tipus, megjegyzes")
      .eq("user_id", userId)
      .order("ev", { ascending: true })
      .order("honap", { ascending: true });
    if (error) toast.error(error.message);
    setRows((data as Row[]) ?? []);
    setLoading(false);
  }

  useEffect(() => {
    void load();
  }, [userId]);

  const byYear = useMemo(() => {
    const map: Record<number, Row[]> = {};
    rows.forEach((r) => {
      (map[r.ev] ??= []).push(r);
    });
    return map;
  }, [rows]);

  const totalForYear = (y: number) =>
    (byYear[y] ?? []).reduce((s, r) => s + Number(r.ora), 0);

  async function saveBatch() {
    const entries = Object.entries(monthly)
      .map(([m, v]) => ({ honap: Number(m), ora: parseFloat(v.replace(",", ".")) }))
      .filter((e) => Number.isFinite(e.ora) && e.ora > 0);
    if (entries.length === 0) {
      toast.error("Adj meg legalább egy órát.");
      return;
    }
    setSaving(true);
    const inserts = entries.map((e) => ({
      user_id: userId,
      tenant_id: tenantId,
      ev: year,
      honap: e.honap,
      ora: e.ora,
      hely: draft.hely.trim() || null,
      jogviszony_tipus: draft.jogviszony_tipus.trim() || null,
      megjegyzes: draft.megjegyzes.trim() || null,
    }));
    const { error } = await supabase
      .from("profile_external_hours")
      .insert(inserts);
    setSaving(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(`${entries.length} hónap mentve.`);
    setMonthly({});
    setDraft({ hely: "", jogviszony_tipus: "", megjegyzes: "" });
    void load();
  }

  async function removeRow(id: string) {
    if (!confirm("Törlöd ezt a bejegyzést?")) return;
    const { error } = await supabase.from("profile_external_hours").delete().eq("id", id);
    if (error) toast.error(error.message);
    else {
      toast.success("Törölve");
      void load();
    }
  }

  const years = Array.from(
    new Set([year, ...rows.map((r) => r.ev)]),
  ).sort((a, b) => b - a);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-semibold flex items-center gap-2">
          <Building2 className="size-5" /> Máshol töltött tervezett munkaórák
        </h2>
        <p className="text-sm text-muted-foreground">
          Második munkahely, oktatás, kutatás stb. – havi bontásban előre tervezve. Segít a beosztó-motornak elkerülni a 48 órás heti munkaidő-túllépést és az ütközéseket. Az adat csak vezetők (csapat-megtekintés, szervezet, beosztás) számára látható.
        </p>
      </div>

      <div className="rounded-lg border border-border bg-card p-4 space-y-4">
        <div className="flex flex-wrap items-end gap-3">
          <div>
            <Label htmlFor="exth-year">Év</Label>
            <Input
              id="exth-year"
              type="number"
              min={2020}
              max={2100}
              value={year}
              onChange={(e) => setYear(parseInt(e.target.value) || new Date().getFullYear())}
              className="w-24"
            />
          </div>
          <div className="flex-1 min-w-[160px]">
            <Label htmlFor="exth-hely">Hely / Intézmény</Label>
            <Input
              id="exth-hely"
              value={draft.hely}
              onChange={(e) => setDraft((d) => ({ ...d, hely: e.target.value }))}
              placeholder="pl. Semmelweis Egyetem"
            />
          </div>
          <div className="flex-1 min-w-[160px]">
            <Label htmlFor="exth-jog">Jogviszony típusa</Label>
            <Input
              id="exth-jog"
              value={draft.jogviszony_tipus}
              onChange={(e) => setDraft((d) => ({ ...d, jogviszony_tipus: e.target.value }))}
              placeholder="pl. megbízási, óraadói, közalkalmazotti"
            />
          </div>
        </div>
        <div>
          <Label>Havi tervezett óraszám {year}-ben</Label>
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2 mt-2">
            {MONTHS.map((label, i) => {
              const m = i + 1;
              return (
                <div key={m} className="flex flex-col">
                  <span className="text-[10px] uppercase font-mono text-muted-foreground">{label}</span>
                  <Input
                    type="number"
                    min={0}
                    step="0.5"
                    inputMode="decimal"
                    value={monthly[m] ?? ""}
                    onChange={(e) =>
                      setMonthly((mm) => ({ ...mm, [m]: e.target.value }))
                    }
                    placeholder="0"
                  />
                </div>
              );
            })}
          </div>
        </div>
        <div>
          <Label htmlFor="exth-mj">Megjegyzés</Label>
          <Input
            id="exth-mj"
            value={draft.megjegyzes}
            onChange={(e) => setDraft((d) => ({ ...d, megjegyzes: e.target.value }))}
            placeholder="opcionális"
          />
        </div>
        <div className="flex justify-end">
          <Button onClick={saveBatch} disabled={saving}>
            {saving ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
            Mentés
          </Button>
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
          Rögzített tervek
        </h3>
        {loading && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="size-4 animate-spin" /> Betöltés…
          </div>
        )}
        {!loading && rows.length === 0 && (
          <p className="text-sm text-muted-foreground">Még nincs rögzített máshol töltött munkaóra.</p>
        )}
        {years.filter((y) => byYear[y]?.length).map((y) => (
          <div key={y} className="rounded-lg border border-border">
            <div className="flex items-center justify-between px-3 py-2 border-b border-border bg-muted/40">
              <div className="font-semibold">{y}</div>
              <div className="text-xs text-muted-foreground">
                Összesen: <span className="font-mono font-semibold">{totalForYear(y).toFixed(1)} óra</span>
              </div>
            </div>
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs uppercase text-muted-foreground">
                  <th className="px-3 py-2">Hónap</th>
                  <th className="px-3 py-2">Hely</th>
                  <th className="px-3 py-2">Jogviszony</th>
                  <th className="px-3 py-2 text-right">Óra</th>
                  <th className="px-3 py-2">Megjegyzés</th>
                  <th className="px-3 py-2 w-10"></th>
                </tr>
              </thead>
              <tbody>
                {byYear[y].map((r) => (
                  <tr key={r.id} className="border-t border-border">
                    <td className="px-3 py-2 font-mono">{MONTHS[r.honap - 1]}</td>
                    <td className="px-3 py-2">{r.hely ?? "—"}</td>
                    <td className="px-3 py-2 text-muted-foreground">{r.jogviszony_tipus ?? "—"}</td>
                    <td className="px-3 py-2 text-right font-mono">{Number(r.ora).toFixed(1)}</td>
                    <td className="px-3 py-2 text-muted-foreground text-xs">{r.megjegyzes ?? ""}</td>
                    <td className="px-3 py-2">
                      <button
                        type="button"
                        onClick={() => removeRow(r.id)}
                        className="text-destructive hover:opacity-80"
                        title="Törlés"
                      >
                        <Trash2 className="size-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ))}
      </div>
    </div>
  );
}
