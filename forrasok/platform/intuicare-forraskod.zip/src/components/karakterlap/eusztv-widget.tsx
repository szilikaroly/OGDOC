import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Calculator, Award, Scale } from "lucide-react";
import { Loader2 } from "lucide-react";
import { getGyakorlatiIdo, getJubileumiIdo, getIlletmeny } from "@/lib/eusztv/eusztv.functions";

export function EusztvWidget({ userId }: { userId: string }) {
  const gFn = useServerFn(getGyakorlatiIdo);
  const jFn = useServerFn(getJubileumiIdo);
  const iFn = useServerFn(getIlletmeny);
  const { data: g, isLoading: lg } = useQuery({ queryKey: ["eusztv-g", userId], queryFn: () => gFn({ data: { userId } }) });
  const { data: j } = useQuery({ queryKey: ["eusztv-j", userId], queryFn: () => jFn({ data: { userId } }) });
  const { data: i } = useQuery({ queryKey: ["eusztv-i", userId], queryFn: () => iFn({ data: { userId } }) });

  if (lg) return <Loader2 className="h-5 w-5 animate-spin" />;

  return (
    <div className="space-y-3">
      <div className="text-sm font-medium text-muted-foreground">Eüsztv. (2020. C. tv.) — élő számítás</div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <Card icon={Calculator} label="Gyakorlati idő (8. §)" value={`${g?.evek ?? 0} év`} sub={`${g?.napok ?? 0} nap`} />
        <Card icon={Award} label="Jubileumi szolgálati idő (9. §)" value={`${j?.evek ?? 0} év`} sub={`${j?.napok ?? 0} nap`} />
        <Card icon={Scale} label="Aktuális illetmény (1. mell.)" value={`${(i?.vegso_ft ?? 0).toLocaleString("hu")} Ft`} sub={`${i?.sav ?? "—"} · vez. ${i?.vezetoi_szorzo ?? 1}x`} />
      </div>
      <p className="text-xs text-muted-foreground">
        A számítás a profile_employment és a HR által rögzített korábbi szolgálati előzmény (Eüsztv. szempontjából beszámítható) intervallumait összegzi, átfedés-mentesen.
      </p>
    </div>
  );
}

function Card({ icon: Icon, label, value, sub }: { icon: any; label: string; value: string; sub?: string }) {
  return (
    <div className="border rounded-lg p-4 bg-card">
      <div className="text-xs text-muted-foreground flex items-center gap-1"><Icon className="h-3.5 w-3.5" /> {label}</div>
      <div className="text-xl font-bold mt-1">{value}</div>
      {sub && <div className="text-xs text-muted-foreground">{sub}</div>}
    </div>
  );
}
