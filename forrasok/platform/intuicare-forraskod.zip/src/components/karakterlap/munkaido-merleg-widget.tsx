import { useEffect, useState } from "react";
import { Clock, Loader2, Shield } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";

type Rule = {
  jogviszony_tipus: string;
  fenntarto_tipus: string;
  napi_max_ora: number;
  napi_max_ora_ugyelettel: number;
  heti_max_ora: number;
  heti_max_ora_egeszsegugyi: number;
  heti_max_ora_ovt: number;
  napi_pihenes_min_ora: number;
  heti_egybefuggo_piheno_ora: number;
  havi_ugyelet_keszenlet_max: number;
  havi_keszenlet_max: number;
  eves_rendkivuli_max: number;
  eves_ugyelet_rendkivuli_max: number;
};

type Overtime = {
  ev: number | null;
  rendkivuli_ora: number | null;
  eves_rendkivuli_max: number | null;
  ugyelet_plus_rendkivuli_ora: number | null;
  eves_ugyelet_rendkivuli_max: number | null;
  rendkivuli_kihasznaltsag_szazalek: number | null;
  ugy_rend_kihasznaltsag_szazalek: number | null;
};

export function MunkaidoMerlegWidget() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [rule, setRule] = useState<Rule | null>(null);
  const [ot, setOt] = useState<Overtime | null>(null);

  useEffect(() => {
    if (!user) return;
    (async () => {
      setLoading(true);
      try {
        const { data: emp } = await supabase
          .from("profile_employment")
          .select("jogviszony_tipus, fenntarto_tipus")
          .eq("user_id", user.id)
          .eq("elsodleges", true)
          .maybeSingle();

        if (emp?.jogviszony_tipus && emp?.fenntarto_tipus) {
          const { data: r } = await supabase
            .from("work_time_rules")
            .select("*")
            .eq("jogviszony_tipus", emp.jogviszony_tipus as any)
            .eq("fenntarto_tipus", emp.fenntarto_tipus as any)
            .lte("ervenyes_tol", new Date().toISOString().slice(0, 10))
            .order("ervenyes_tol", { ascending: false })
            .limit(1)
            .maybeSingle();
          setRule(r as Rule | null);
        }

        const { data: o } = await supabase
          .from("v_overtime_ledger_yearly")
          .select("*")
          .eq("user_id", user.id)
          .eq("ev", new Date().getFullYear())
          .maybeSingle();
        setOt(o as Overtime | null);
      } finally {
        setLoading(false);
      }
    })();
  }, [user]);

  if (loading) return <Loader2 className="h-4 w-4 animate-spin" />;

  return (
    <div className="space-y-4">
      <header>
        <h3 className="font-semibold flex items-center gap-2">
          <Clock className="h-4 w-4" /> Munkaidő-mérleg
        </h3>
        <p className="text-xs text-muted-foreground">
          A jogviszony-szabály automatikusan a `work_time_rules` táblából töltődik.
        </p>
      </header>

      {rule ? (
        <div className="border rounded-lg p-4 space-y-2 text-sm">
          <div className="flex items-center gap-2 text-xs uppercase text-muted-foreground">
            <Shield className="h-3 w-3" />
            {rule.jogviszony_tipus} / {rule.fenntarto_tipus}
          </div>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <Row label="Napi max (ügy. nélkül)" v={`${rule.napi_max_ora} ó`} />
            <Row label="Napi max (ügyelettel)" v={`${rule.napi_max_ora_ugyelettel} ó`} />
            <Row label="Heti max" v={`${rule.heti_max_ora} ó`} />
            <Row label="Heti max ÖVT-vel" v={`${rule.heti_max_ora_ovt} ó`} />
            <Row label="Napi pihenő min" v={`${rule.napi_pihenes_min_ora} ó`} />
            <Row label="Heti egybefüggő pihenő" v={`${rule.heti_egybefuggo_piheno_ora} ó`} />
            <Row label="Éves rendkívüli" v={`${rule.eves_rendkivuli_max} ó`} />
            <Row label="Éves ügy.+rendk." v={`${rule.eves_ugyelet_rendkivuli_max} ó`} />
            <Row label="Havi ügy.+kész." v={`${rule.havi_ugyelet_keszenlet_max} ó`} />
            <Row label="Havi készenlét" v={`${rule.havi_keszenlet_max} ó`} />
          </div>
        </div>
      ) : (
        <div className="text-sm text-muted-foreground border rounded-lg p-4">
          Nincs elsődleges jogviszony rögzítve, vagy nincs hozzá szabálykészlet.
        </div>
      )}

      {ot && (
        <div className="border rounded-lg p-4 space-y-3">
          <h4 className="text-sm font-medium">Éves keret ({ot.ev})</h4>
          <Bar
            label="Rendkívüli"
            value={Number(ot.rendkivuli_ora ?? 0)}
            max={Number(ot.eves_rendkivuli_max ?? 250)}
            pct={Number(ot.rendkivuli_kihasznaltsag_szazalek ?? 0)}
          />
          <Bar
            label="Ügyelet + rendkívüli"
            value={Number(ot.ugyelet_plus_rendkivuli_ora ?? 0)}
            max={Number(ot.eves_ugyelet_rendkivuli_max ?? 416)}
            pct={Number(ot.ugy_rend_kihasznaltsag_szazalek ?? 0)}
          />
        </div>
      )}
    </div>
  );
}

function Row({ label, v }: { label: string; v: string }) {
  return (
    <div className="flex justify-between bg-muted/40 rounded px-2 py-1.5">
      <span className="text-muted-foreground">{label}</span>
      <strong>{v}</strong>
    </div>
  );
}

function Bar({ label, value, max, pct }: { label: string; value: number; max: number; pct: number }) {
  const safe = Math.min(100, Math.max(0, pct));
  const color = safe > 90 ? "bg-red-500" : safe > 70 ? "bg-amber-500" : "bg-emerald-500";
  return (
    <div>
      <div className="flex justify-between text-xs mb-1">
        <span>{label}</span>
        <span>
          {value.toFixed(1)} / {max} ó ({safe.toFixed(0)}%)
        </span>
      </div>
      <div className="h-2 bg-muted rounded overflow-hidden">
        <div className={`h-full ${color}`} style={{ width: `${safe}%` }} />
      </div>
    </div>
  );
}
