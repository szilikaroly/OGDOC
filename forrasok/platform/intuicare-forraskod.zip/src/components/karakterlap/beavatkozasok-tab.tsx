import { useEffect, useMemo, useState } from "react";
import { Loader2, Plus, Trash2, Search, Check, ShieldCheck, FileText, Save } from "lucide-react";
import { toast } from "sonner";
import { useTranslation } from "react-i18next";
import { supabase } from "@/integrations/supabase/client";
import { humanizeError } from "@/lib/humanize-error";
import { cn } from "@/lib/utils";

type Beavatkozas = {
  id: string;
  kod: string | null;
  nev: string;
  specialty_id: string | null;
  aktiv: boolean;
};

type ProfileBeavatkozas = {
  id: string;
  user_id: string;
  tenant_id: string;
  beavatkozas_id: string;
  alkalom: number;
  datum: string | null;
  megjegyzes: string | null;
  mentor_igazolt: boolean;
  mentor_user_id: string | null;
  bizonyitek_url: string | null;
};

type ProfileLite = { id: string; teljes_nev: string };

function FieldLabel({ children }: { children: React.ReactNode }) {
  return (
    <label className="text-[10px] font-mono uppercase text-muted-foreground tracking-wider">
      {children}
    </label>
  );
}

export function BeavatkozasokTab({
  userId,
  tenantId,
}: {
  userId: string;
  tenantId: string | null;
}) {
  const { t } = useTranslation();
  const [catalog, setCatalog] = useState<Beavatkozas[]>([]);
  const [rows, setRows] = useState<ProfileBeavatkozas[]>([]);
  const [mentors, setMentors] = useState<Record<string, ProfileLite>>({});
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);

  const [search, setSearch] = useState("");
  const [draft, setDraft] = useState({
    beavatkozas_id: "",
    alkalom: 1,
    datum: "",
    mentor_igazolt: false,
    mentor_user_id: "",
    bizonyitek_url: "",
    megjegyzes: "",
  });
  const [mentorSearch, setMentorSearch] = useState("");
  const [mentorOptions, setMentorOptions] = useState<ProfileLite[]>([]);

  // Load catalog + user rows
  useEffect(() => {
    (async () => {
      setLoading(true);
      const [cat, mine] = await Promise.all([
        supabase
          .from("beavatkozasok")
          .select("id, kod, nev, specialty_id, aktiv")
          .eq("aktiv", true)
          .order("nev", { ascending: true })
          .limit(500),
        supabase
          .from("profile_beavatkozasok" as never)
          .select("*")
          .eq("user_id", userId)
          .order("datum", { ascending: false, nullsFirst: false }),
      ]);
      setCatalog((cat.data ?? []) as Beavatkozas[]);
      const list = (mine.data ?? []) as unknown as ProfileBeavatkozas[];
      setRows(list);
      const mentorIds = Array.from(new Set(list.map((r) => r.mentor_user_id).filter(Boolean) as string[]));
      if (mentorIds.length > 0) {
        const { data: m } = await supabase
          .from("profiles")
          .select("id, teljes_nev")
          .in("id", mentorIds);
        const map: Record<string, ProfileLite> = {};
        (m ?? []).forEach((p) => { map[p.id] = p as ProfileLite; });
        setMentors(map);
      }
      setLoading(false);
    })();
  }, [userId]);

  // Mentor autocomplete (other people in same tenant)
  useEffect(() => {
    const q = mentorSearch.trim();
    if (q.length < 2) { setMentorOptions([]); return; }
    let cancelled = false;
    const handle = setTimeout(async () => {
      const query = supabase
        .from("profiles")
        .select("id, teljes_nev")
        .ilike("teljes_nev", `%${q}%`)
        .neq("id", userId)
        .limit(8);
      if (tenantId) query.eq("tenant_id", tenantId);
      const { data } = await query;
      if (!cancelled) setMentorOptions((data ?? []) as ProfileLite[]);
    }, 200);
    return () => { cancelled = true; clearTimeout(handle); };
  }, [mentorSearch, userId, tenantId]);

  const filteredCatalog = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return catalog.slice(0, 20);
    return catalog.filter((b) =>
      b.nev.toLowerCase().includes(q) || (b.kod ?? "").toLowerCase().includes(q),
    ).slice(0, 30);
  }, [catalog, search]);

  const catalogById = useMemo(() => {
    const m: Record<string, Beavatkozas> = {};
    catalog.forEach((b) => { m[b.id] = b; });
    return m;
  }, [catalog]);

  async function add() {
    if (!draft.beavatkozas_id) {
      toast.error("Válasszon beavatkozást.");
      return;
    }
    if (!tenantId) {
      toast.error("Hiányzó tenant.");
      return;
    }
    if (draft.alkalom < 1) {
      toast.error("Az esetszám legalább 1.");
      return;
    }
    setBusy("add");
    const payload = {
      user_id: userId,
      tenant_id: tenantId,
      beavatkozas_id: draft.beavatkozas_id,
      alkalom: draft.alkalom,
      datum: draft.datum || null,
      mentor_igazolt: draft.mentor_igazolt,
      mentor_user_id: draft.mentor_user_id || null,
      bizonyitek_url: draft.bizonyitek_url.trim() || null,
      megjegyzes: draft.megjegyzes.trim() || null,
    };
    const { data, error } = await supabase
      .from("profile_beavatkozasok" as never)
      .insert(payload as never)
      .select("*")
      .maybeSingle();
    setBusy(null);
    if (error) {
      toast.error(humanizeError(error, t));
      return;
    }
    if (data) {
      const row = data as unknown as ProfileBeavatkozas;
      setRows((p) => [row, ...p]);
      if (row.mentor_user_id && !mentors[row.mentor_user_id]) {
        const opt = mentorOptions.find((o) => o.id === row.mentor_user_id);
        if (opt) setMentors((m) => ({ ...m, [opt.id]: opt }));
      }
      setDraft({
        beavatkozas_id: "",
        alkalom: 1,
        datum: "",
        mentor_igazolt: false,
        mentor_user_id: "",
        bizonyitek_url: "",
        megjegyzes: "",
      });
      setMentorSearch("");
      setSearch("");
      toast.success("Beavatkozás rögzítve.");
    }
  }

  async function update(id: string, patch: Partial<ProfileBeavatkozas>) {
    setBusy(id);
    const { error } = await supabase
      .from("profile_beavatkozasok" as never)
      .update(patch as never)
      .eq("id", id);
    setBusy(null);
    if (error) {
      toast.error(humanizeError(error, t));
      return;
    }
    setRows((p) => p.map((r) => (r.id === id ? { ...r, ...patch } : r)));
  }

  async function remove(id: string) {
    if (!window.confirm("Biztosan törli ezt a bejegyzést?")) return;
    setBusy(id);
    const { error } = await supabase
      .from("profile_beavatkozasok" as never)
      .delete()
      .eq("id", id);
    setBusy(null);
    if (error) {
      toast.error(humanizeError(error, t));
      return;
    }
    setRows((p) => p.filter((r) => r.id !== id));
    toast.success("Törölve.");
  }

  if (loading) {
    return (
      <div className="p-4 flex items-center gap-2 text-sm text-muted-foreground">
        <Loader2 className="size-4 animate-spin" /> Betöltés…
      </div>
    );
  }

  const totalCases = rows.reduce((s, r) => s + (r.alkalom || 0), 0);
  const verifiedCases = rows.filter((r) => r.mentor_igazolt).reduce((s, r) => s + r.alkalom, 0);

  return (
    <div className="space-y-4 max-w-4xl">
      <div className="grid grid-cols-3 gap-3">
        <Stat label="Rögzített típusok" value={String(rows.length)} />
        <Stat label="Összes esetszám" value={String(totalCases)} />
        <Stat label="Mentor által igazolt" value={`${verifiedCases} / ${totalCases}`} />
      </div>

      <div className="rounded-lg border border-dashed border-border bg-card p-4 space-y-3">
        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Új beavatkozás rögzítése
        </div>

        <div className="space-y-1">
          <FieldLabel>Beavatkozás (keresés név / kód szerint)</FieldLabel>
          <div className="relative">
            <Search className="size-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="pl. laparoszkópos…"
              className="w-full pl-8 pr-3 py-2 rounded-md border border-input bg-background text-sm"
            />
          </div>
          {(search || !draft.beavatkozas_id) && (
            <div className="max-h-44 overflow-auto border border-border rounded-md bg-background mt-1 divide-y divide-border">
              {filteredCatalog.length === 0 && (
                <div className="px-3 py-2 text-xs text-muted-foreground">Nincs találat.</div>
              )}
              {filteredCatalog.map((b) => (
                <button
                  key={b.id}
                  type="button"
                  onClick={() => { setDraft((d) => ({ ...d, beavatkozas_id: b.id })); setSearch(b.nev); }}
                  className={cn(
                    "w-full text-left px-3 py-1.5 text-xs hover:bg-secondary flex items-center gap-2",
                    draft.beavatkozas_id === b.id && "bg-primary/10",
                  )}
                >
                  {draft.beavatkozas_id === b.id && <Check className="size-3 text-primary" />}
                  <span className="font-medium">{b.nev}</span>
                  {b.kod && <span className="font-mono text-[10px] text-muted-foreground">{b.kod}</span>}
                </button>
              ))}
            </div>
          )}
          {draft.beavatkozas_id && !search && (
            <div className="text-xs text-muted-foreground">
              Választott: <span className="font-semibold">{catalogById[draft.beavatkozas_id]?.nev}</span>
            </div>
          )}
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div>
            <FieldLabel>Esetszám</FieldLabel>
            <input
              type="number"
              min={1}
              value={draft.alkalom}
              onChange={(e) => setDraft({ ...draft, alkalom: Math.max(1, parseInt(e.target.value || "1", 10)) })}
              className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
            />
          </div>
          <div>
            <FieldLabel>Utolsó elvégzés</FieldLabel>
            <input
              type="date"
              value={draft.datum}
              onChange={(e) => setDraft({ ...draft, datum: e.target.value })}
              className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
            />
          </div>
          <div className="col-span-2 flex items-end">
            <label className="flex items-center gap-2 text-xs">
              <input
                type="checkbox"
                checked={draft.mentor_igazolt}
                onChange={(e) => setDraft({ ...draft, mentor_igazolt: e.target.checked })}
              />
              <ShieldCheck className="size-3.5 text-success" />
              Mentor által igazolt
            </label>
          </div>
        </div>

        {draft.mentor_igazolt && (
          <div>
            <FieldLabel>Mentor (keresés)</FieldLabel>
            <input
              value={mentorSearch}
              onChange={(e) => { setMentorSearch(e.target.value); setDraft({ ...draft, mentor_user_id: "" }); }}
              placeholder="legalább 2 betű…"
              className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
            />
            {mentorOptions.length > 0 && !draft.mentor_user_id && (
              <div className="border border-border rounded-md bg-background mt-1 divide-y divide-border max-h-40 overflow-auto">
                {mentorOptions.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => { setDraft({ ...draft, mentor_user_id: p.id }); setMentorSearch(p.teljes_nev); }}
                    className="w-full text-left px-3 py-1.5 text-xs hover:bg-secondary"
                  >
                    {p.teljes_nev}
                  </button>
                ))}
              </div>
            )}
            {draft.mentor_user_id && (
              <div className="text-[11px] text-success mt-1">
                ✓ Mentor kiválasztva: {mentorSearch}
              </div>
            )}
          </div>
        )}

        <div>
          <FieldLabel>Bizonyíték URL (műtéti napló kivonat, opc.)</FieldLabel>
          <input
            value={draft.bizonyitek_url}
            onChange={(e) => setDraft({ ...draft, bizonyitek_url: e.target.value.slice(0, 500) })}
            placeholder="https://…"
            className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm font-mono"
          />
        </div>

        <div>
          <FieldLabel>Megjegyzés (opc.)</FieldLabel>
          <textarea
            value={draft.megjegyzes}
            onChange={(e) => setDraft({ ...draft, megjegyzes: e.target.value.slice(0, 500) })}
            rows={2}
            className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
          />
        </div>

        <button
          type="button"
          onClick={add}
          disabled={busy === "add" || !draft.beavatkozas_id}
          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90 disabled:opacity-50"
        >
          {busy === "add" ? <Loader2 className="size-3.5 animate-spin" /> : <Plus className="size-3.5" />}
          Hozzáadás
        </button>
      </div>

      {rows.length === 0 ? (
        <div className="p-6 rounded-lg border border-dashed border-border text-sm text-muted-foreground text-center">
          Még nincs rögzített beavatkozás.
        </div>
      ) : (
        <div className="rounded-lg border border-border bg-card divide-y divide-border">
          {rows.map((r) => {
            const meta = catalogById[r.beavatkozas_id];
            const b = busy === r.id;
            const mentor = r.mentor_user_id ? mentors[r.mentor_user_id] : null;
            return (
              <div key={r.id} className="px-4 py-3 space-y-2">
                <div className="flex items-center gap-3 flex-wrap">
                  <div className="flex-1 min-w-[200px]">
                    <div className="text-sm font-semibold flex items-center gap-2 flex-wrap">
                      {meta?.nev ?? "(ismeretlen)"}
                      {meta?.kod && <span className="text-[10px] font-mono text-muted-foreground">{meta.kod}</span>}
                      {r.mentor_igazolt && (
                        <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-success/15 text-success uppercase inline-flex items-center gap-1">
                          <ShieldCheck className="size-3" /> igazolt
                        </span>
                      )}
                    </div>
                    <div className="text-xs font-mono text-muted-foreground flex items-center gap-3 flex-wrap mt-0.5">
                      <span>esetszám: <b>{r.alkalom}</b></span>
                      {r.datum && <span>utolsó: {r.datum}</span>}
                      {mentor && <span>mentor: {mentor.teljes_nev}</span>}
                      {r.bizonyitek_url && (
                        <a href={r.bizonyitek_url} target="_blank" rel="noopener noreferrer"
                          className="text-primary underline inline-flex items-center gap-1">
                          <FileText className="size-3" /> bizonyíték
                        </a>
                      )}
                    </div>
                    {r.megjegyzes && (
                      <div className="text-[11px] text-muted-foreground mt-1 italic">{r.megjegyzes}</div>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      min={1}
                      defaultValue={r.alkalom}
                      onBlur={(e) => {
                        const v = Math.max(1, parseInt(e.target.value || "1", 10));
                        if (v !== r.alkalom) update(r.id, { alkalom: v });
                      }}
                      className="w-20 px-2 py-1 rounded border border-input bg-background text-xs"
                      aria-label="Esetszám módosítása"
                      title="Esetszám módosítása (mentés a mező elhagyásakor)"
                    />
                    <button
                      type="button"
                      onClick={() => update(r.id, { mentor_igazolt: !r.mentor_igazolt })}
                      disabled={b}
                      className={cn(
                        "p-1.5 rounded hover:bg-secondary disabled:opacity-50",
                        r.mentor_igazolt ? "text-success" : "text-muted-foreground",
                      )}
                      aria-label="Mentor-igazolás kapcsolása"
                      title="Mentor-igazolás kapcsolása"
                    >
                      <ShieldCheck className="size-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => remove(r.id)}
                      disabled={b}
                      className="p-1.5 rounded text-destructive hover:bg-destructive/10 disabled:opacity-50"
                      aria-label="Törlés"
                    >
                      {b ? <Loader2 className="size-3.5 animate-spin" /> : <Trash2 className="size-3.5" />}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-border bg-card px-4 py-3">
      <div className="text-[10px] font-mono uppercase text-muted-foreground tracking-wider">{label}</div>
      <div className="text-xl font-bold mt-0.5">{value}</div>
    </div>
  );
}
