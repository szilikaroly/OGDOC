/**
 * Audit-jelentés export (CSV / DOCX) — a PDF audit szekcióval azonos tartalommal:
 * összefoglaló számok (hibák/figyelmeztetések/információk) + tételes tábla
 * (szint, tétel, üzenet, jogszabály).
 */
import type { auditIlletmeny } from "@/lib/eusztv/legal-references";

export type AuditIssues = ReturnType<typeof auditIlletmeny>;

export type AuditExportMeta = {
  name?: string;
  datum: string;
};

const severityLabel = (s: AuditIssues[number]["severity"]) =>
  s === "error" ? "HIBA" : s === "warning" ? "FIGYELMEZTETÉS" : "INFO";

function triggerDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function csvEscape(v: string) {
  const s = String(v ?? "");
  return /[",;\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

export function exportAuditCsv(
  issues: AuditIssues,
  meta: AuditExportMeta,
  filename: string,
) {
  const errs = issues.filter((i) => i.severity === "error").length;
  const warns = issues.filter((i) => i.severity === "warning").length;
  const infos = issues.filter((i) => i.severity === "info").length;

  const lines: string[] = [];
  lines.push(`Jogi hivatkozás-audit — összefoglaló`);
  lines.push(`Munkavállaló;${csvEscape(meta.name ?? "—")}`);
  lines.push(`Vonatkozás;${csvEscape(meta.datum)}`);
  lines.push(`Hibák;${errs}`);
  lines.push(`Figyelmeztetések;${warns}`);
  lines.push(`Információk;${infos}`);
  lines.push("");
  lines.push(["Szint", "Tétel", "Üzenet", "Jogszabály"].map(csvEscape).join(";"));

  if (issues.length === 0) {
    lines.push(
      csvEscape("—") +
        ";" +
        csvEscape("—") +
        ";" +
        csvEscape(
          "Nincs észlelt hiányosság — a számítás megfelel az aktív jogi hivatkozásoknak.",
        ) +
        ";" +
        csvEscape("—"),
    );
  } else {
    for (const i of issues) {
      const ref = i.szukseges_hivatkozas
        ? `${i.szukseges_hivatkozas.jogszabaly} — ${i.szukseges_hivatkozas.szakasz}`
        : "—";
      lines.push(
        [severityLabel(i.severity), i.cimke, i.uzenet, ref]
          .map(csvEscape)
          .join(";"),
      );
    }
  }

  // BOM az Excel Unicode felismeréshez
  const blob = new Blob(["\uFEFF" + lines.join("\r\n")], {
    type: "text/csv;charset=utf-8",
  });
  triggerDownload(blob, filename);
}

export async function exportAuditDocx(
  issues: AuditIssues,
  meta: AuditExportMeta,
  filename: string,
) {
  const {
    Document,
    Packer,
    Paragraph,
    HeadingLevel,
    TextRun,
    Table,
    TableRow,
    TableCell,
    WidthType,
    BorderStyle,
    ShadingType,
    AlignmentType,
  } = await import("docx");

  const errs = issues.filter((i) => i.severity === "error").length;
  const warns = issues.filter((i) => i.severity === "warning").length;
  const infos = issues.filter((i) => i.severity === "info").length;

  const cellBorder = { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" };
  const borders = {
    top: cellBorder,
    bottom: cellBorder,
    left: cellBorder,
    right: cellBorder,
  };
  const margins = { top: 80, bottom: 80, left: 120, right: 120 };

  const headerRow = new TableRow({
    tableHeader: true,
    children: ["Szint", "Tétel", "Üzenet", "Jogszabály"].map(
      (t, idx) =>
        new TableCell({
          borders,
          margins,
          width: {
            size: [1400, 2400, 4160, 1400][idx],
            type: WidthType.DXA,
          },
          shading: { fill: "50506E", type: ShadingType.CLEAR, color: "auto" },
          children: [
            new Paragraph({
              children: [
                new TextRun({ text: t, bold: true, color: "FFFFFF" }),
              ],
            }),
          ],
        }),
    ),
  });

  const bodyRows: InstanceType<typeof TableRow>[] =
    issues.length === 0
      ? [
          new TableRow({
            children: [
              "—",
              "—",
              "Nincs észlelt hiányosság — a számítás megfelel az aktív jogi hivatkozásoknak.",
              "—",
            ].map(
              (t, idx) =>
                new TableCell({
                  borders,
                  margins,
                  width: {
                    size: [1400, 2400, 4160, 1400][idx],
                    type: WidthType.DXA,
                  },
                  children: [new Paragraph({ children: [new TextRun(t)] })],
                }),
            ),
          }),
        ]
      : issues.map(
          (i) =>
            new TableRow({
              children: [
                (() => {
                  const label = severityLabel(i.severity);
                  const fill =
                    i.severity === "error"
                      ? "FADCDC"
                      : i.severity === "warning"
                        ? "FFF0C8"
                        : "DCE6F5";
                  const color =
                    i.severity === "error"
                      ? "961E1E"
                      : i.severity === "warning"
                        ? "966414"
                        : "284682";
                  return new TableCell({
                    borders,
                    margins,
                    width: { size: 1400, type: WidthType.DXA },
                    shading: {
                      fill,
                      type: ShadingType.CLEAR,
                      color: "auto",
                    },
                    children: [
                      new Paragraph({
                        children: [
                          new TextRun({ text: label, bold: true, color }),
                        ],
                      }),
                    ],
                  });
                })(),
                new TableCell({
                  borders,
                  margins,
                  width: { size: 2400, type: WidthType.DXA },
                  children: [new Paragraph(i.cimke ?? "")],
                }),
                new TableCell({
                  borders,
                  margins,
                  width: { size: 4160, type: WidthType.DXA },
                  children: [new Paragraph(i.uzenet ?? "")],
                }),
                new TableCell({
                  borders,
                  margins,
                  width: { size: 1400, type: WidthType.DXA },
                  children: [
                    new Paragraph(
                      i.szukseges_hivatkozas
                        ? `${i.szukseges_hivatkozas.jogszabaly} — ${i.szukseges_hivatkozas.szakasz}`
                        : "—",
                    ),
                  ],
                }),
              ],
            }),
        );

  const summaryRow = (label: string, n: number, fill: string, color: string) =>
    new TableRow({
      children: [
        new TableCell({
          borders,
          margins,
          width: { size: 3120, type: WidthType.DXA },
          shading: { fill, type: ShadingType.CLEAR, color: "auto" },
          children: [
            new Paragraph({
              children: [new TextRun({ text: label, bold: true, color })],
            }),
          ],
        }),
        new TableCell({
          borders,
          margins,
          width: { size: 3120, type: WidthType.DXA },
          shading: { fill, type: ShadingType.CLEAR, color: "auto" },
          children: [
            new Paragraph({
              alignment: AlignmentType.RIGHT,
              children: [
                new TextRun({ text: String(n), bold: true, color, size: 28 }),
              ],
            }),
          ],
        }),
      ],
    });

  const summaryTable = new Table({
    width: { size: 6240, type: WidthType.DXA },
    columnWidths: [3120, 3120],
    rows: [
      summaryRow("Hibák", errs, "FADCDC", "961E1E"),
      summaryRow("Figyelmeztetések", warns, "FFF0C8", "966414"),
      summaryRow("Információk", infos, "DCE6F5", "284682"),
    ],
  });

  const issuesTable = new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [1400, 2400, 4160, 1400],
    rows: [headerRow, ...bodyRows],
  });

  const doc = new Document({
    styles: {
      default: { document: { run: { font: "Arial", size: 20 } } },
    },
    sections: [
      {
        properties: {
          page: {
            size: { width: 12240, height: 15840 },
            margin: {
              top: 1440,
              right: 1440,
              bottom: 1440,
              left: 1440,
            },
          },
        },
        children: [
          new Paragraph({
            heading: HeadingLevel.HEADING_1,
            children: [
              new TextRun({
                text: "Jogi hivatkozás-audit — összefoglaló",
                bold: true,
              }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({
                text: `Munkavállaló: ${meta.name ?? "—"} · Vonatkozás: ${meta.datum}`,
                color: "666666",
              }),
            ],
          }),
          new Paragraph({ children: [new TextRun("")] }),
          summaryTable,
          new Paragraph({ children: [new TextRun("")] }),
          new Paragraph({
            heading: HeadingLevel.HEADING_2,
            children: [new TextRun({ text: "Tételes lista", bold: true })],
          }),
          issuesTable,
        ],
      },
    ],
  });

  const blob = await Packer.toBlob(doc);
  triggerDownload(blob, filename);
}
