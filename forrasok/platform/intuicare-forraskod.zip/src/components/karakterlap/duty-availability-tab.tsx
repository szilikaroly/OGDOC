import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { humanizeError } from "@/lib/humanize-error";
import { toast } from "sonner";
import { useTranslation } from "react-i18next";
import { Plus, Trash2, ShieldCheck, PhoneCall, HandHeart, Info, Loader2 } from "lucide-react";

type Tipus = "tartalekos" | "behivhato" | "szabad_vagyok";

type Row = {
  id: string;
  tipus: Tipus;
  napok: string[];
  kezd_ido: string | null;
  veg_ido: string | null;
  megjegyzes: string | null;
  ervenyes_tol: string;
  ervenyes_ig: string | null;
  visszavonva_at: string | null;
  site_id: string | null;
  duty_line_id: string | null;
};

type Site = { id: string; nev: string };
type DutyLine = { id: string; nev: string; site_id: string };

const TIPUS_META: Record<Tipus, { label: string; desc: string; icon: typeof ShieldCheck; cls: string }> = {
  tartalekos: {
    label: "Tartalékos",
    desc: "Adott napokon nem dolgozom, de baj esetén beosztható vagyok.",
    icon: ShieldCheck,
    cls: "bg-amber-100 text-amber-900 border-amber-300",
  },
  behivhato: {
    label: "Behívható",
    desc: "Otthon vagyok, de telefonra elérhető, X órán belül beérek.",
    icon: PhoneCall,
    cls: "bg-sky-100 text-sky-900 border-sky-300",
  },
  szabad_vagyok: {
    label: "Szabad vagyok / vállalok",
    desc: "Önként vállalok extra ügyeletet ezeken a napokon.",
    icon: HandHeart,
    cls: "bg-emerald-100 text-emerald-900 border-emerald-300",
  },
};

export function DutyAvailabilityTab(props: { userId: string; tenantId: string | null }) {
  const { t } = useTranslation();
  const [rows, setRows] = useState<Row[]>([]);
  const [sites, setSites] = useState<Site[]>([]);
  const [lines, setLines] = useState<DutyLine[]>([]);
  const [loading, setLoading] = useState(true);
  const [adding, setAdding] = useState<Tipus | null>(null);
  const [newRow, setNewRow] = useState<Partial<Row>>({});

  const load = useCallback(async () => {
    setLoading(true);
    const [r, s, dl] = await Promise.all([
      (supabase as any).from("duty_availability").select("*").eq("user_id", props.userId).order("ervenyes_tol", { ascending: false }),
      supabase.from("sites").select("id,nev").order("nev"),
      supabase.from("duty_lines").select("id,nev,site_id").eq("aktiv", true).order("nev"),
    ]);
    setRows((r.data ?? []) as Row[]);
    setSites((s.data ?? []) as Site[]);
    setLines((dl.data ?? []) as DutyLine[]);
    setLoading(false);
  }, [props.userId]);

  useEffect(() => { load(); }, [load]);

  async function save() {
    if (!adding || !newRow.napok || newRow.napok.length === 0) {
      toast.error("Adj meg legalább egy napot.");
      return;
    }
    const payload = {
      tenant_id: props.tenantId,
      user_id: props.userId,
      tipus: adding,
      napok: newRow.napok,
      site_id: newRow.site_id || null,
      duty_line_id: newRow.duty_line_id || null,
      kezd_ido: newRow.kezd_ido || null,
      veg_ido: newRow.veg_ido || null,
      megjegyzes: newRow.megjegyzes || null,
      ervenyes_tol: newRow.ervenyes_tol || new Date().toISOString().slice(0, 10),
      ervenyes_ig: newRow.ervenyes_ig || null,
    };
    const { error } = await (supabase as any).from("duty_availability").insert(payload);
    if (error) return toast.error(humanizeError(error, t));
    toast.success("Rendelkezésre állás rögzítve.");
    setAdding(null);
    setNewRow({});
    load();
  }

  async function withdraw(id: string) {
    const { error } = await (supabase as any).from("duty_availability")
      .update({ visszavonva_at: new Date().toISOString() }).eq("id", id);
    if (error) return toast.error(humanizeError(error, t));
    toast.success("Visszavonva.");
    load();
  }

  async function remove(id: string) {
    if (!confirm("Biztosan törlöd ezt a rekordot?")) return;
    const { error } = await (supabase as any).from("duty_availability").delete().eq("id", id);
    if (error) return toast.error(humanizeError(error, t));
    load();
  }

  if (loading) return <div className="p-6 flex items-center gap-2 text-sm text-muted-foreground"><Loader2 className="size-4 animate-spin" /> Betöltés…</div>;

  return (
    <div className="p-4 space-y-4">
      <div className="bg-card border rounded-2xl p-4">
        <div className="flex items-start gap-2 text-sm text-muted-foreground">
          <Info className="size-4 mt-0.5 shrink-0 text-primary" />
          <div>
            <p className="font-medium text-foreground mb-1">Önkéntes rendelkezésre állás</p>
            <p>
              Itt jelezheted, mely napokon vagy <b>tartalékos</b> (helyettesítésre beosztható), <b>behívható</b> (otthonról beérek), vagy önként <b>vállalsz</b> extra ügyeletet.
              A beosztómotor és a koordinátor ezt figyelembe veszi pótlásnál és az önkéntes ügyeleti igények kiosztásánál.
              Bármikor visszavonhatod.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
        {(Object.keys(TIPUS_META) as Tipus[]).map((k) => {
          const m = TIPUS_META[k];
          const Ic = m.icon;
          return (
            <button key={k} type="button" onClick={() => { setAdding(k); setNewRow({ napok: [] }); }}
              className={`text-left border-2 rounded-xl p-3 hover:border-primary transition ${adding === k ? "border-primary bg-primary/5" : "border-border bg-card"}`}>
              <div className="flex items-center gap-2 mb-1">
                <Ic className="size-4" />
                <span className="font-semibold text-sm">{m.label}</span>
                <Plus className="size-3.5 ml-auto" />
              </div>
              <p className="text-[11px] text-muted-foreground">{m.desc}</p>
            </button>
          );
        })}
      </div>

      {adding && (
        <div className="bg-card border-2 border-primary rounded-2xl p-4 space-y-3">
          <div className="text-sm font-bold flex items-center gap-2">
            Új „{TIPUS_META[adding].label}" bejegyzés
          </div>

          <Field label="Napok (koppintással válassz)">
            <DayChipPicker
              value={newRow.napok ?? []}
              onChange={(napok) => setNewRow((s) => ({ ...s, napok }))}
            />
          </Field>

          <div className="grid grid-cols-2 gap-2">
            <Field label="Idősáv kezdés (opcionális)"><input type="time" className="w-full px-2 py-1.5 rounded border bg-background text-sm" onChange={(e) => setNewRow((s) => ({ ...s, kezd_ido: e.target.value }))} /></Field>
            <Field label="Idősáv vég (opcionális)"><input type="time" className="w-full px-2 py-1.5 rounded border bg-background text-sm" onChange={(e) => setNewRow((s) => ({ ...s, veg_ido: e.target.value }))} /></Field>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <Field label="Telephely (opcionális)">
              <select className="w-full px-2 py-1.5 rounded border bg-background text-sm" onChange={(e) => setNewRow((s) => ({ ...s, site_id: e.target.value || null, duty_line_id: null }))}>
                <option value="">— bármelyik —</option>
                {sites.map((s) => <option key={s.id} value={s.id}>{s.nev}</option>)}
              </select>
            </Field>
            <Field label="Ügyeleti sor (opcionális)">
              <select className="w-full px-2 py-1.5 rounded border bg-background text-sm" onChange={(e) => setNewRow((s) => ({ ...s, duty_line_id: e.target.value || null }))}>
                <option value="">— bármelyik —</option>
                {lines.filter((l) => !newRow.site_id || l.site_id === newRow.site_id).map((l) => <option key={l.id} value={l.id}>{l.nev}</option>)}
              </select>
            </Field>
          </div>

          <Field label="Megjegyzés (opcionális)">
            <input type="text" className="w-full px-2 py-1.5 rounded border bg-background text-sm" placeholder="pl. csak 22:00-ig vállalom"
              onChange={(e) => setNewRow((s) => ({ ...s, megjegyzes: e.target.value }))} />
          </Field>

          <div className="flex gap-2 justify-end pt-1">
            <button type="button" className="px-3 py-1.5 rounded border text-sm" onClick={() => { setAdding(null); setNewRow({}); }}>Mégse</button>
            <button type="button" className="px-3 py-1.5 rounded bg-primary text-primary-foreground text-sm font-semibold" onClick={save}>Mentés</button>
          </div>
        </div>
      )}

      <div className="bg-card border rounded-2xl">
        <div className="px-4 py-2 border-b text-xs font-mono uppercase tracking-wider text-muted-foreground">Bejegyzéseim ({rows.length})</div>
        {rows.length === 0 ? (
          <div className="p-6 text-center text-sm text-muted-foreground">
            Még nincs bejegyzésed. Válassz fent egy típust a hozzáadáshoz.
          </div>
        ) : (
          <ul className="divide-y">
            {rows.map((r) => {
              const m = TIPUS_META[r.tipus];
              const Ic = m.icon;
              const site = sites.find((s) => s.id === r.site_id);
              const line = lines.find((l) => l.id === r.duty_line_id);
              return (
                <li key={r.id} className={`px-4 py-2.5 text-sm flex items-start gap-3 ${r.visszavonva_at ? "opacity-50" : ""}`}>
                  <span className={`px-2 py-0.5 rounded border text-[11px] font-medium flex items-center gap-1 shrink-0 ${m.cls}`}>
                    <Ic className="size-3" /> {m.label}
                  </span>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium">{r.napok.join(", ")}</div>
                    <div className="text-[11px] text-muted-foreground space-x-2">
                      {(r.kezd_ido || r.veg_ido) && <span>{r.kezd_ido ?? "—"}–{r.veg_ido ?? "—"}</span>}
                      {site && <span>· {site.nev}</span>}
                      {line && <span>· {line.nev}</span>}
                      {r.megjegyzes && <span>· {r.megjegyzes}</span>}
                      {r.visszavonva_at && <span className="text-warning">· VISSZAVONVA</span>}
                    </div>
                  </div>
                  {!r.visszavonva_at && (
                    <button type="button" onClick={() => withdraw(r.id)} className="text-[11px] px-2 py-1 rounded border hover:bg-secondary">Visszavonom</button>
                  )}
                  <button type="button" onClick={() => remove(r.id)} className="text-muted-foreground hover:text-warning">
                    <Trash2 className="size-3.5" />
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}

function Field(props: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="block text-[11px] font-mono uppercase tracking-wider text-muted-foreground mb-1">{props.label}</span>
      {props.children}
    </label>
  );
}

const HUN_DOW = ["V", "H", "K", "Sz", "Cs", "P", "Sz"];

function DayChipPicker(props: { value: string[]; onChange: (v: string[]) => void }) {
  const [customDate, setCustomDate] = useState("");
  const today = new Date();
  const days: { iso: string; label: string; dow: string; isWeekend: boolean }[] = [];
  for (let i = 0; i < 14; i++) {
    const d = new Date(today);
    d.setDate(today.getDate() + i);
    const iso = d.toISOString().slice(0, 10);
    const dow = d.getDay();
    days.push({
      iso,
      label: `${d.getMonth() + 1}.${d.getDate()}`,
      dow: HUN_DOW[dow],
      isWeekend: dow === 0 || dow === 6,
    });
  }
  const selected = new Set(props.value);

  function toggle(iso: string) {
    const next = new Set(selected);
    if (next.has(iso)) next.delete(iso); else next.add(iso);
    props.onChange(Array.from(next).sort());
  }

  function addCustom() {
    if (!customDate) return;
    const next = new Set(selected);
    next.add(customDate);
    props.onChange(Array.from(next).sort());
    setCustomDate("");
  }

  return (
    <div className="space-y-2">
      <div className="grid grid-cols-7 gap-1.5">
        {days.map((d) => {
          const isSel = selected.has(d.iso);
          return (
            <button
              key={d.iso}
              type="button"
              onClick={() => toggle(d.iso)}
              className={`min-h-[52px] rounded-lg border-2 px-1 py-1.5 text-center transition active:scale-95 ${
                isSel
                  ? "border-primary bg-primary text-primary-foreground"
                  : d.isWeekend
                    ? "border-border bg-secondary/40"
                    : "border-border bg-background"
              }`}
            >
              <div className="text-[10px] font-mono uppercase opacity-70">{d.dow}</div>
              <div className="text-xs font-semibold leading-tight">{d.label}</div>
            </button>
          );
        })}
      </div>
      <div className="flex items-center gap-2">
        <input
          type="date"
          value={customDate}
          onChange={(e) => setCustomDate(e.target.value)}
          className="flex-1 px-2 py-1.5 rounded border bg-background text-sm"
        />
        <button type="button" onClick={addCustom} className="px-3 py-1.5 rounded border text-sm">
          + Hozzáad
        </button>
      </div>
      {props.value.length > 0 && (
        <div className="flex flex-wrap gap-1.5 pt-1">
          {props.value.map((iso) => (
            <span
              key={iso}
              className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-primary/10 border border-primary/30 text-[11px]"
            >
              {iso}
              <button type="button" onClick={() => toggle(iso)} className="hover:text-warning">
                ×
              </button>
            </span>
          ))}
        </div>
      )}
    </div>
  );
}
