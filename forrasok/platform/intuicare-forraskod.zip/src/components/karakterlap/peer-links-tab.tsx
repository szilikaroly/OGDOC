import { useEffect, useMemo, useState } from "react";
import { Loader2, Plus, Trash2, Users, Heart, UserX, GraduationCap, UserCog, Check, X, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { useTranslation } from "react-i18next";
import { supabase } from "@/integrations/supabase/client";
import { humanizeError } from "@/lib/humanize-error";
import { applyReason } from "@/lib/audit-reason";
import { ReasonInput } from "@/components/reason-input";
import { cn } from "@/lib/utils";

type PeerTipus = "szivesen_dolgozik_vele" | "nem_dolgozik_vele" | "mentor" | "mentee";
type PeerStatus = "aktiv" | "jovahagyasra_var" | "jovahagyott" | "elutasitott";

type PeerLink = {
  id: string;
  tenant_id: string | null;
  from_user_id: string;
  to_user_id: string;
  tipus: PeerTipus;
  suly: number | null;
  indoklas: string | null;
  status: PeerStatus;
  jovahagyo_id: string | null;
  jovahagyas_at: string | null;
  jovahagyas_indok: string | null;
};

type ProfileLite = { id: string; teljes_nev: string };

const TYPE_META: Record<PeerTipus, { label: string; short: string; icon: typeof Heart; cls: string; needsApproval?: boolean }> = {
  szivesen_dolgozik_vele: { label: "Szívesen dolgozik vele", short: "szívesen", icon: Heart, cls: "text-success bg-success/10" },
  nem_dolgozik_vele: { label: "Nem dolgozik vele", short: "nem szívesen", icon: UserX, cls: "text-destructive bg-destructive/10", needsApproval: true },
  mentor: { label: "Mentorom", short: "mentor", icon: GraduationCap, cls: "text-primary bg-primary/10" },
  mentee: { label: "Tanítványom", short: "tanítvány", icon: UserCog, cls: "text-accent-foreground bg-accent" },
};

const STATUS_META: Record<PeerStatus, { label: string; cls: string }> = {
  aktiv: { label: "aktív", cls: "bg-success/15 text-success" },
  jovahagyasra_var: { label: "jóváhagyásra vár", cls: "bg-warning/15 text-warning" },
  jovahagyott: { label: "jóváhagyott", cls: "bg-success/15 text-success" },
  elutasitott: { label: "elutasított", cls: "bg-destructive/15 text-destructive" },
};

export function PeerLinksTab({
  userId,
  tenantId,
  isHr,
}: {
  userId: string;
  tenantId: string | null;
  isHr: boolean;
}) {
  const { t } = useTranslation();
  const [links, setLinks] = useState<PeerLink[]>([]);
  const [profilesMap, setProfilesMap] = useState<Record<string, ProfileLite>>({});
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);

  const [search, setSearch] = useState("");
  const [options, setOptions] = useState<ProfileLite[]>([]);
  const [draft, setDraft] = useState({
    to_user_id: "",
    to_user_name: "",
    tipus: "szivesen_dolgozik_vele" as PeerTipus,
    suly: 3,
    indoklas: "",
  });
  const [reason, setReason] = useState("");

  // Load links involving the user (both directions)
  async function load() {
    setLoading(true);
    const { data } = await supabase
      .from("profile_peer_links" as never)
      .select("*")
      .or(`from_user_id.eq.${userId},to_user_id.eq.${userId}`)
      .order("created_at", { ascending: false });
    const list = (data ?? []) as unknown as PeerLink[];
    setLinks(list);
    const otherIds = Array.from(new Set(
      list.flatMap((l) => [l.from_user_id, l.to_user_id]).filter((id) => id !== userId),
    ));
    if (otherIds.length > 0) {
      const { data: profs } = await supabase
        .from("profiles")
        .select("id, teljes_nev")
        .in("id", otherIds);
      const map: Record<string, ProfileLite> = {};
      (profs ?? []).forEach((p) => { map[p.id] = p as ProfileLite; });
      setProfilesMap(map);
    }
    setLoading(false);
  }
  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId]);

  // Profile search
  useEffect(() => {
    const q = search.trim();
    if (q.length < 2) { setOptions([]); return; }
    let cancelled = false;
    const h = setTimeout(async () => {
      const query = supabase
        .from("profiles")
        .select("id, teljes_nev")
        .ilike("teljes_nev", `%${q}%`)
        .neq("id", userId)
        .limit(8);
      if (tenantId) query.eq("tenant_id", tenantId);
      const { data } = await query;
      if (!cancelled) setOptions((data ?? []) as ProfileLite[]);
    }, 200);
    return () => { cancelled = true; clearTimeout(h); };
  }, [search, userId, tenantId]);

  // Group: outgoing links from this user
  const outgoing = useMemo(() => links.filter((l) => l.from_user_id === userId), [links, userId]);
  const incoming = useMemo(() => links.filter((l) => l.to_user_id === userId), [links, userId]);

  // Compute reciprocity for szivesen
  function isReciprocal(link: PeerLink): boolean {
    if (link.tipus !== "szivesen_dolgozik_vele") return false;
    return links.some((l) =>
      l.tipus === "szivesen_dolgozik_vele"
      && ((l.from_user_id === link.to_user_id && l.to_user_id === link.from_user_id))
    );
  }

  async function add() {
    if (!draft.to_user_id) {
      toast.error("Válasszon kollégát.");
      return;
    }
    if (draft.tipus === "nem_dolgozik_vele" && !draft.indoklas.trim()) {
      toast.error("A „nem dolgozik vele” kapcsolathoz indoklás kötelező.");
      return;
    }
    setBusy("add");
    const payload = {
      tenant_id: tenantId,
      from_user_id: userId,
      to_user_id: draft.to_user_id,
      tipus: draft.tipus,
      suly: draft.tipus === "szivesen_dolgozik_vele" ? draft.suly : null,
      indoklas: draft.indoklas.trim() || null,
    };
    const { data, error } = await supabase
      .from("profile_peer_links" as never)
      .insert(payload as never)
      .select("*")
      .maybeSingle();
    setBusy(null);
    if (error) {
      toast.error(humanizeError(error, t));
      return;
    }
    if (data) {
      const row = data as unknown as PeerLink;
      if (reason.trim()) await applyReason("profile_peer_links", row.id, reason);
      setLinks((p) => [row, ...p]);
      if (!profilesMap[draft.to_user_id]) {
        setProfilesMap((m) => ({ ...m, [draft.to_user_id]: { id: draft.to_user_id, teljes_nev: draft.to_user_name } }));
      }
      setDraft({ to_user_id: "", to_user_name: "", tipus: "szivesen_dolgozik_vele", suly: 3, indoklas: "" });
      setSearch("");
      setReason("");
      toast.success(
        draft.tipus === "nem_dolgozik_vele"
          ? "Rögzítve — HR-jóváhagyásra vár."
          : "Kapcsolat rögzítve.",
      );
    }
  }

  async function remove(id: string) {
    if (!window.confirm("Biztosan törli ezt a kapcsolatot?")) return;
    setBusy(id);
    const { error } = await supabase
      .from("profile_peer_links" as never)
      .delete()
      .eq("id", id);
    setBusy(null);
    if (error) {
      toast.error(humanizeError(error, t));
      return;
    }
    if (reason.trim()) await applyReason("profile_peer_links", id, reason);
    setLinks((p) => p.filter((l) => l.id !== id));
    setReason("");
    toast.success("Törölve.");
  }

  async function decide(link: PeerLink, status: "jovahagyott" | "elutasitott") {
    let indok = "";
    if (status === "elutasitott") {
      indok = window.prompt("Elutasítás indoka (kötelező):") ?? "";
      if (!indok.trim()) {
        toast.error("Elutasításhoz indoklás szükséges.");
        return;
      }
    }
    setBusy(link.id);
    const { error } = await supabase
      .from("profile_peer_links" as never)
      .update({ status, jovahagyas_indok: indok || null } as never)
      .eq("id", link.id);
    setBusy(null);
    if (error) {
      toast.error(humanizeError(error, t));
      return;
    }
    setLinks((p) => p.map((l) => (l.id === link.id ? { ...l, status, jovahagyas_indok: indok || null } : l)));
    toast.success(status === "jovahagyott" ? "Jóváhagyva." : "Elutasítva.");
  }

  if (loading) {
    return (
      <div className="p-4 flex items-center gap-2 text-sm text-muted-foreground">
        <Loader2 className="size-4 animate-spin" /> Betöltés…
      </div>
    );
  }

  const sections: Array<{ tipus: PeerTipus; data: PeerLink[]; incoming?: PeerLink[] }> = [
    { tipus: "szivesen_dolgozik_vele", data: outgoing.filter((l) => l.tipus === "szivesen_dolgozik_vele") },
    { tipus: "nem_dolgozik_vele", data: outgoing.filter((l) => l.tipus === "nem_dolgozik_vele") },
    { tipus: "mentor", data: outgoing.filter((l) => l.tipus === "mentor") },
    { tipus: "mentee", data: outgoing.filter((l) => l.tipus === "mentee") },
  ];

  // Incoming non-szivesen: people who marked YOU as mentor/mentee/etc.
  const incomingNotice = incoming.filter((l) => l.tipus !== "szivesen_dolgozik_vele");

  return (
    <div className="space-y-4 max-w-4xl">
      <div className="rounded-md border border-primary/20 bg-primary/5 px-3 py-2 text-xs text-muted-foreground">
        A kapcsolati háló a beosztó-motort segíti a kompatibilis párok kiválasztásában.
        A „nem dolgozik vele" kapcsolat HR-jóváhagyásra vár, és csak jóváhagyás után veszi figyelembe a rendszer.
      </div>

      <div className="rounded-lg border border-dashed border-border bg-card p-4 space-y-3">
        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Új kapcsolat
        </div>

        <div>
          <label className="text-[10px] font-mono uppercase text-muted-foreground tracking-wider">Kolléga</label>
          <input
            value={search}
            onChange={(e) => { setSearch(e.target.value); setDraft({ ...draft, to_user_id: "", to_user_name: "" }); }}
            placeholder="legalább 2 betű…"
            className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm mt-1"
          />
          {options.length > 0 && !draft.to_user_id && (
            <div className="border border-border rounded-md bg-background mt-1 divide-y divide-border max-h-40 overflow-auto">
              {options.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => { setDraft({ ...draft, to_user_id: p.id, to_user_name: p.teljes_nev }); setSearch(p.teljes_nev); }}
                  className="w-full text-left px-3 py-1.5 text-xs hover:bg-secondary"
                >
                  {p.teljes_nev}
                </button>
              ))}
            </div>
          )}
          {draft.to_user_id && (
            <div className="text-[11px] text-success mt-1">✓ Kiválasztva: {draft.to_user_name}</div>
          )}
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-[10px] font-mono uppercase text-muted-foreground tracking-wider">Kapcsolat típusa</label>
            <select
              value={draft.tipus}
              onChange={(e) => setDraft({ ...draft, tipus: e.target.value as PeerTipus })}
              className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm mt-1"
            >
              {(Object.keys(TYPE_META) as PeerTipus[]).map((k) => (
                <option key={k} value={k}>{TYPE_META[k].label}</option>
              ))}
            </select>
          </div>
          {draft.tipus === "szivesen_dolgozik_vele" && (
            <div>
              <label className="text-[10px] font-mono uppercase text-muted-foreground tracking-wider">Súly (1–5)</label>
              <input
                type="range" min={1} max={5} value={draft.suly}
                onChange={(e) => setDraft({ ...draft, suly: parseInt(e.target.value, 10) })}
                className="w-full mt-3"
              />
              <div className="text-xs font-mono text-center">{draft.suly}</div>
            </div>
          )}
        </div>

        <div>
          <label className="text-[10px] font-mono uppercase text-muted-foreground tracking-wider">
            Indoklás {draft.tipus === "nem_dolgozik_vele" && <span className="text-destructive">*kötelező</span>}
          </label>
          <textarea
            value={draft.indoklas}
            onChange={(e) => setDraft({ ...draft, indoklas: e.target.value.slice(0, 500) })}
            rows={2}
            className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm mt-1"
          />
        </div>

        <ReasonInput value={reason} onChange={setReason} placeholder="Indoklás az audit-naplóba (opcionális)" />

        <button
          type="button"
          onClick={add}
          disabled={busy === "add" || !draft.to_user_id || (draft.tipus === "nem_dolgozik_vele" && !draft.indoklas.trim())}
          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90 disabled:opacity-50"
        >
          {busy === "add" ? <Loader2 className="size-3.5 animate-spin" /> : <Plus className="size-3.5" />}
          Hozzáadás
        </button>
      </div>

      {incomingNotice.length > 0 && (
        <div className="rounded-lg border border-border bg-card p-3 space-y-2">
          <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground flex items-center gap-1">
            <Users className="size-3" /> Mások által rögzített kapcsolatok Önnel
          </div>
          <ul className="divide-y divide-border">
            {incomingNotice.map((l) => {
              const meta = TYPE_META[l.tipus];
              const Icon = meta.icon;
              const other = profilesMap[l.from_user_id];
              return (
                <li key={l.id} className="py-1.5 text-xs flex items-center gap-2">
                  <span className={cn("inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] uppercase font-mono", meta.cls)}>
                    <Icon className="size-3" /> {meta.short}
                  </span>
                  <span>{other?.teljes_nev ?? l.from_user_id.slice(0, 8)}</span>
                  <span className={cn("ml-auto text-[10px] font-mono px-1.5 py-0.5 rounded uppercase", STATUS_META[l.status].cls)}>
                    {STATUS_META[l.status].label}
                  </span>
                </li>
              );
            })}
          </ul>
        </div>
      )}

      {sections.map((sec) => {
        const meta = TYPE_META[sec.tipus];
        const Icon = meta.icon;
        return (
          <div key={sec.tipus} className="rounded-lg border border-border bg-card">
            <div className="px-4 py-2 border-b border-border flex items-center gap-2">
              <Icon className={cn("size-4", meta.cls.split(" ")[0])} />
              <h3 className="text-sm font-semibold">{meta.label}</h3>
              <span className="text-[11px] text-muted-foreground font-mono">({sec.data.length})</span>
            </div>
            {sec.data.length === 0 ? (
              <div className="px-4 py-3 text-xs text-muted-foreground">Nincs ilyen kapcsolat.</div>
            ) : (
              <ul className="divide-y divide-border">
                {sec.data.map((l) => {
                  const other = profilesMap[l.to_user_id];
                  const reciprocal = isReciprocal(l);
                  const b = busy === l.id;
                  const canDecide = isHr && l.status === "jovahagyasra_var";
                  return (
                    <li key={l.id} className="px-4 py-2 flex items-center gap-3 flex-wrap">
                      <div className="flex-1 min-w-[180px]">
                        <div className="text-sm font-medium flex items-center gap-2 flex-wrap">
                          {other?.teljes_nev ?? l.to_user_id.slice(0, 8)}
                          {reciprocal && (
                            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-success/15 text-success uppercase">
                              kölcsönös
                            </span>
                          )}
                          {l.suly != null && (
                            <span className="text-[10px] font-mono text-muted-foreground">súly: {l.suly}</span>
                          )}
                          <span className={cn("text-[10px] font-mono px-1.5 py-0.5 rounded uppercase", STATUS_META[l.status].cls)}>
                            {STATUS_META[l.status].label}
                          </span>
                        </div>
                        {l.indoklas && (
                          <div className="text-[11px] text-muted-foreground italic mt-0.5">„{l.indoklas}"</div>
                        )}
                        {l.jovahagyas_indok && (
                          <div className="text-[11px] text-warning mt-0.5">HR: „{l.jovahagyas_indok}"</div>
                        )}
                      </div>
                      {canDecide && (
                        <>
                          <button type="button" onClick={() => decide(l, "jovahagyott")} disabled={b}
                            className="inline-flex items-center gap-1 text-[11px] px-2 py-1 rounded bg-success/15 text-success hover:bg-success/25 disabled:opacity-50">
                            <Check className="size-3" /> Jóváhagy
                          </button>
                          <button type="button" onClick={() => decide(l, "elutasitott")} disabled={b}
                            className="inline-flex items-center gap-1 text-[11px] px-2 py-1 rounded bg-destructive/15 text-destructive hover:bg-destructive/25 disabled:opacity-50">
                            <X className="size-3" /> Elutasít
                          </button>
                        </>
                      )}
                      <button
                        type="button"
                        onClick={() => remove(l.id)}
                        disabled={b}
                        className="p-1.5 rounded text-destructive hover:bg-destructive/10 disabled:opacity-50"
                        aria-label="Törlés"
                      >
                        {b ? <Loader2 className="size-3.5 animate-spin" /> : <Trash2 className="size-3.5" />}
                      </button>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>
        );
      })}

      {isHr && (
        <div className="text-[11px] text-muted-foreground flex items-center gap-1 italic">
          <ShieldCheck className="size-3" /> HR-jogosultsággal lát mindent és bírálhat el negatív kapcsolatokat.
        </div>
      )}
    </div>
  );
}
