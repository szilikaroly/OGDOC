import { useEffect, useMemo, useState } from "react";
import { Loader2, Plus, Trash2, AlertTriangle, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { humanizeError } from "@/lib/humanize-error";
import { useTranslation } from "react-i18next";
import { cn } from "@/lib/utils";

type Domain = { id: string; nev: string; kulcs: string; specialty_id: string | null };
type Level = { id: string; nev: string; kulcs: string; sorrend: number; felugyeleti_kuszob: boolean };
type Accred = {
  id: string;
  domain_id: string;
  level_id: string;
  ervenyes_tol: string;
  ervenyes_ig: string | null;
  igazolas_hivatkozas: string | null;
  megjegyzes: string | null;
  jovahagyo_id: string | null;
};

export function AkkreditaciokTab({
  userId,
  tenantId,
  isHr,
}: {
  userId: string;
  tenantId: string | null;
  isHr: boolean;
}) {
  const { t } = useTranslation();
  const [loading, setLoading] = useState(true);
  const [domains, setDomains] = useState<Domain[]>([]);
  const [levels, setLevels] = useState<Level[]>([]);
  const [rows, setRows] = useState<Accred[]>([]);
  const [adding, setAdding] = useState(false);
  const [newDomain, setNewDomain] = useState("");
  const [newLevel, setNewLevel] = useState("");
  const [newTol, setNewTol] = useState(new Date().toISOString().slice(0, 10));
  const [newIg, setNewIg] = useState("");
  const [newHiv, setNewHiv] = useState("");

  useEffect(() => {
    if (!tenantId) return;
    (async () => {
      const [d, l, r] = await Promise.all([
        supabase.from("competency_domains").select("id,nev,kulcs,specialty_id").eq("tenant_id", tenantId).eq("ervenyes", true).order("nev"),
        supabase.from("competency_levels").select("id,nev,kulcs,sorrend,felugyeleti_kuszob").order("sorrend"),
        supabase.from("person_accreditations").select("*").eq("user_id", userId).order("ervenyes_tol", { ascending: false }),
      ]);
      setDomains((d.data ?? []) as Domain[]);
      setLevels((l.data ?? []) as Level[]);
      setRows((r.data ?? []) as Accred[]);
      setLoading(false);
    })();
  }, [userId, tenantId]);

  const today = new Date();
  const in60 = new Date(today.getTime() + 60 * 24 * 3600 * 1000);
  const expiring = useMemo(
    () =>
      rows.filter((r) => {
        if (!r.ervenyes_ig) return false;
        const d = new Date(r.ervenyes_ig);
        return d >= today && d <= in60;
      }),
    [rows],
  );
  const expired = useMemo(
    () => rows.filter((r) => r.ervenyes_ig && new Date(r.ervenyes_ig) < today),
    [rows],
  );

  async function addRow() {
    if (!tenantId || !newDomain || !newLevel) {
      toast.error("Válassz domaint és szintet");
      return;
    }
    setAdding(true);
    const { data, error } = await supabase
      .from("person_accreditations")
      .insert({
        user_id: userId,
        tenant_id: tenantId,
        domain_id: newDomain,
        level_id: newLevel,
        ervenyes_tol: newTol,
        ervenyes_ig: newIg || null,
        igazolas_hivatkozas: newHiv.trim() || null,
      })
      .select()
      .single();
    setAdding(false);
    if (error) {
      toast.error(humanizeError(error, t));
      return;
    }
    setRows([data as Accred, ...rows]);
    setNewDomain("");
    setNewLevel("");
    setNewIg("");
    setNewHiv("");
    toast.success("Akkreditáció rögzítve");
  }

  async function removeRow(id: string) {
    const { error } = await supabase.from("person_accreditations").delete().eq("id", id);
    if (error) {
      toast.error(humanizeError(error, t));
      return;
    }
    setRows(rows.filter((r) => r.id !== id));
  }

  if (loading) {
    return (
      <div className="rounded-lg border border-border bg-card p-6 text-sm text-muted-foreground flex items-center gap-2">
        <Loader2 className="size-4 animate-spin" /> Betöltés…
      </div>
    );
  }

  const domainById = new Map(domains.map((d) => [d.id, d]));
  const levelById = new Map(levels.map((l) => [l.id, l]));

  return (
    <div className="space-y-4">
      {(expired.length > 0 || expiring.length > 0) && (
        <div className="rounded-lg border border-border bg-card p-4 space-y-2">
          {expired.length > 0 && (
            <div className="flex items-start gap-2 text-sm text-destructive">
              <AlertTriangle className="size-4 mt-0.5 shrink-0" />
              <div>
                <strong>{expired.length}</strong> akkreditáció lejárt — sürgős megújítás szükséges.
              </div>
            </div>
          )}
          {expiring.length > 0 && (
            <div className="flex items-start gap-2 text-sm text-amber-600 dark:text-amber-400">
              <AlertTriangle className="size-4 mt-0.5 shrink-0" />
              <div>
                <strong>{expiring.length}</strong> akkreditáció 60 napon belül lejár.
              </div>
            </div>
          )}
        </div>
      )}

      <div className="rounded-lg border border-border bg-card p-4 space-y-3">
        <div className="text-xs font-mono uppercase text-muted-foreground tracking-wider">
          Új akkreditáció
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <select
            value={newDomain}
            onChange={(e) => setNewDomain(e.target.value)}
            className="px-3 py-2 rounded-md border border-input bg-background text-sm"
          >
            <option value="">— Kompetencia-domain —</option>
            {domains.map((d) => (
              <option key={d.id} value={d.id}>
                {d.nev}
              </option>
            ))}
          </select>
          <select
            value={newLevel}
            onChange={(e) => setNewLevel(e.target.value)}
            className="px-3 py-2 rounded-md border border-input bg-background text-sm"
          >
            <option value="">— Szint —</option>
            {levels.map((l) => (
              <option key={l.id} value={l.id}>
                {l.nev}
                {l.felugyeleti_kuszob ? " (felügyeleti küszöb)" : ""}
              </option>
            ))}
          </select>
          <label className="text-xs space-y-1">
            <span className="text-muted-foreground">Érvényes -tól</span>
            <input
              type="date"
              value={newTol}
              onChange={(e) => setNewTol(e.target.value)}
              className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
            />
          </label>
          <label className="text-xs space-y-1">
            <span className="text-muted-foreground">Érvényes -ig (opcionális)</span>
            <input
              type="date"
              value={newIg}
              onChange={(e) => setNewIg(e.target.value)}
              className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
            />
          </label>
          <input
            value={newHiv}
            onChange={(e) => setNewHiv(e.target.value)}
            placeholder="Igazolás hivatkozás (URL / iktató szám)"
            className="md:col-span-2 px-3 py-2 rounded-md border border-input bg-background text-sm"
          />
        </div>
        <button
          type="button"
          onClick={addRow}
          disabled={adding}
          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90 disabled:opacity-50"
        >
          {adding ? <Loader2 className="size-3.5 animate-spin" /> : <Plus className="size-3.5" />}
          Hozzáadás
        </button>
        {!isHr && (
          <p className="text-[11px] text-muted-foreground">
            Jóváhagyásig a beosztó-motor nem veszi figyelembe. HR/jóváhagyó: <code>jovahagyo_id</code>.
          </p>
        )}
      </div>

      <div className="rounded-lg border border-border bg-card">
        <div className="p-3 border-b border-border text-xs font-mono uppercase text-muted-foreground tracking-wider flex items-center gap-2">
          <ShieldCheck className="size-3.5" /> Saját akkreditációk ({rows.length})
        </div>
        {rows.length === 0 ? (
          <div className="p-6 text-sm text-muted-foreground">Még nincs rögzített akkreditáció.</div>
        ) : (
          <ul className="divide-y divide-border">
            {rows.map((r) => {
              const isExpired = r.ervenyes_ig && new Date(r.ervenyes_ig) < today;
              const isExpiring = r.ervenyes_ig && !isExpired && new Date(r.ervenyes_ig) <= in60;
              return (
                <li key={r.id} className="p-3 flex items-start justify-between gap-3 text-sm">
                  <div className="space-y-0.5">
                    <div className="font-medium">
                      {domainById.get(r.domain_id)?.nev ?? "?"} ·{" "}
                      <span className="text-muted-foreground">{levelById.get(r.level_id)?.nev ?? "?"}</span>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {r.ervenyes_tol} → {r.ervenyes_ig ?? "∞"}
                      {r.jovahagyo_id ? " · jóváhagyva" : " · jóváhagyásra vár"}
                    </div>
                    {r.igazolas_hivatkozas && (
                      <div className="text-xs font-mono text-muted-foreground truncate max-w-md">
                        {r.igazolas_hivatkozas}
                      </div>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    {isExpired && (
                      <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded-full bg-destructive/10 text-destructive">
                        Lejárt
                      </span>
                    )}
                    {isExpiring && (
                      <span className={cn("text-[10px] font-semibold uppercase px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-600 dark:text-amber-400")}>
                        Hamarosan lejár
                      </span>
                    )}
                    <button
                      type="button"
                      onClick={() => removeRow(r.id)}
                      className="p-1.5 rounded-md hover:bg-secondary text-muted-foreground hover:text-destructive"
                      aria-label="Törlés"
                    >
                      <Trash2 className="size-3.5" />
                    </button>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
