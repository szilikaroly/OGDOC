import { useEffect, useState } from "react";
import { Loader2, Plus, Trash2, Zap, AlertTriangle } from "lucide-react";
import { toast } from "sonner";
import { useTranslation } from "react-i18next";
import { supabase } from "@/integrations/supabase/client";
import { humanizeError } from "@/lib/humanize-error";
import { useAuth } from "@/hooks/use-auth";

type Pref = {
  id: string;
  ervenyes_tol: string;
  ervenyes_ig: string | null;
  max_ora_havi: number | null;
  napok: number[];
  muszakok: string[];
  csak_sajat_osztaly: boolean;
  megjegyzes: string | null;
  status: "aktiv" | "visszavont" | "lejart";
};

type Order = {
  id: string;
  kezdo_idopont: string;
  zaro_idopont: string;
  ora: number;
  kategoria: string;
  indok: string;
  irasos_hivatkozas: string | null;
  status: string;
  elrendelo_id: string;
  elrendeles_at: string;
};

const NAP_LABELS = ["H", "K", "Sze", "Cs", "P", "Szo", "V"];
const MUSAK = ["nappal", "delutan", "ejszaka", "huszonnegy"];

export function OvertimeTab({
  userId,
  tenantId,
  isHr,
}: {
  userId: string;
  tenantId: string | null;
  isHr: boolean;
}) {
  const { t } = useTranslation();
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [pref, setPref] = useState<Pref | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [saving, setSaving] = useState(false);

  // Saját preferencia szerkesztő mezők
  const [vallal, setVallal] = useState(false);
  const [maxOra, setMaxOra] = useState<string>("");
  const [napok, setNapok] = useState<number[]>([]);
  const [muszakok, setMuszakok] = useState<string[]>([]);
  const [csakSajat, setCsakSajat] = useState(false);
  const [megjegyzes, setMegjegyzes] = useState("");

  // HR elrendelés űrlap
  const [oKezdo, setOKezdo] = useState("");
  const [oZaro, setOZaro] = useState("");
  const [oKat, setOKat] = useState("rendkivuli");
  const [oIndok, setOIndok] = useState("");
  const [oHiv, setOHiv] = useState("");
  const [ordering, setOrdering] = useState(false);

  useEffect(() => {
    (async () => {
      const [p, o] = await Promise.all([
        supabase
          .from("overtime_preferences")
          .select("*")
          .eq("user_id", userId)
          .eq("status", "aktiv")
          .order("ervenyes_tol", { ascending: false })
          .limit(1)
          .maybeSingle(),
        supabase
          .from("overtime_orders")
          .select("*")
          .eq("user_id", userId)
          .order("kezdo_idopont", { ascending: false })
          .limit(20),
      ]);
      const pr = (p.data as Pref | null) ?? null;
      setPref(pr);
      if (pr) {
        setVallal(true);
        setMaxOra(pr.max_ora_havi?.toString() ?? "");
        setNapok(pr.napok ?? []);
        setMuszakok(pr.muszakok ?? []);
        setCsakSajat(pr.csak_sajat_osztaly);
        setMegjegyzes(pr.megjegyzes ?? "");
      }
      setOrders((o.data ?? []) as Order[]);
      setLoading(false);
    })();
  }, [userId]);

  async function savePref() {
    if (!tenantId) return;
    setSaving(true);
    if (!vallal) {
      if (pref) {
        const { error } = await supabase
          .from("overtime_preferences")
          .update({ status: "visszavont", ervenyes_ig: new Date().toISOString().slice(0, 10) })
          .eq("id", pref.id);
        if (error) toast.error(humanizeError(error, t));
        else {
          toast.success("Túlóra-vállalás visszavonva");
          setPref(null);
        }
      }
      setSaving(false);
      return;
    }
    const payload = {
      user_id: userId,
      tenant_id: tenantId,
      ervenyes_tol: new Date().toISOString().slice(0, 10),
      max_ora_havi: maxOra ? Number(maxOra) : null,
      napok,
      muszakok,
      csak_sajat_osztaly: csakSajat,
      megjegyzes: megjegyzes.trim() || null,
      status: "aktiv" as const,
    };
    if (pref) {
      const { data, error } = await supabase
        .from("overtime_preferences")
        .update(payload)
        .eq("id", pref.id)
        .select()
        .single();
      if (error) toast.error(humanizeError(error, t));
      else {
        setPref(data as Pref);
        toast.success("Mentve");
      }
    } else {
      const { data, error } = await supabase
        .from("overtime_preferences")
        .insert(payload)
        .select()
        .single();
      if (error) toast.error(humanizeError(error, t));
      else {
        setPref(data as Pref);
        toast.success("Túlóra-vállalás rögzítve");
      }
    }
    setSaving(false);
  }

  async function submitOrder() {
    if (!tenantId || !user) return;
    if (!oKezdo || !oZaro || !oIndok.trim()) {
      toast.error("Kezdő, záró és indok kötelező");
      return;
    }
    const kez = new Date(oKezdo);
    const zar = new Date(oZaro);
    if (zar <= kez) {
      toast.error("A záró időpont a kezdő után legyen");
      return;
    }
    const ora = Math.round(((zar.getTime() - kez.getTime()) / 3600000) * 100) / 100;
    setOrdering(true);
    const { data, error } = await supabase
      .from("overtime_orders")
      .insert({
        user_id: userId,
        tenant_id: tenantId,
        kezdo_idopont: kez.toISOString(),
        zaro_idopont: zar.toISOString(),
        ora,
        kategoria: oKat,
        indok: oIndok.trim(),
        irasos_hivatkozas: oHiv.trim() || null,
        elrendelo_id: user.id,
        status: "elrendelt",
      })
      .select()
      .single();
    setOrdering(false);
    if (error) {
      toast.error(humanizeError(error, t));
      return;
    }
    setOrders([data as Order, ...orders]);
    setOKezdo("");
    setOZaro("");
    setOIndok("");
    setOHiv("");
    toast.success("Túlóra elrendelve");
  }

  function toggleNap(d: number) {
    setNapok((arr) => (arr.includes(d) ? arr.filter((x) => x !== d) : [...arr, d].sort()));
  }
  function toggleMusak(m: string) {
    setMuszakok((arr) => (arr.includes(m) ? arr.filter((x) => x !== m) : [...arr, m]));
  }

  if (loading) {
    return (
      <div className="rounded-lg border border-border bg-card p-6 text-sm text-muted-foreground flex items-center gap-2">
        <Loader2 className="size-4 animate-spin" /> Betöltés…
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="rounded-lg border border-border bg-card p-4 space-y-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h3 className="font-semibold flex items-center gap-2">
              <Zap className="size-4" /> Túlórát vállalok
            </h3>
            <p className="text-xs text-muted-foreground mt-1">
              Az ÖVT (Eütev. 12/B §) külön kérdőíven kezelendő. Ez a beosztó-motor számára szól.
            </p>
          </div>
          <label className="inline-flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={vallal}
              onChange={(e) => setVallal(e.target.checked)}
              className="size-4"
            />
            <span className="text-sm font-semibold">{vallal ? "Igen" : "Nem"}</span>
          </label>
        </div>

        {vallal && (
          <div className="space-y-3 pt-2 border-t border-border">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <label className="text-xs space-y-1">
                <span className="text-muted-foreground">Havi maximum (óra)</span>
                <input
                  type="number"
                  step="0.5"
                  value={maxOra}
                  onChange={(e) => setMaxOra(e.target.value)}
                  className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
                  placeholder="pl. 40"
                />
              </label>
              <label className="text-xs flex items-center gap-2 self-end pb-2">
                <input
                  type="checkbox"
                  checked={csakSajat}
                  onChange={(e) => setCsakSajat(e.target.checked)}
                  className="size-4"
                />
                <span>Csak saját osztályon</span>
              </label>
            </div>
            <div>
              <div className="text-xs text-muted-foreground mb-1">Vállalt napok</div>
              <div className="flex flex-wrap gap-1">
                {NAP_LABELS.map((lab, i) => {
                  const d = i + 1;
                  const on = napok.includes(d);
                  return (
                    <button
                      key={d}
                      type="button"
                      onClick={() => toggleNap(d)}
                      className={`px-3 py-1 rounded-full text-xs font-semibold ${on ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"}`}
                    >
                      {lab}
                    </button>
                  );
                })}
              </div>
            </div>
            <div>
              <div className="text-xs text-muted-foreground mb-1">Vállalt műszakok</div>
              <div className="flex flex-wrap gap-1">
                {MUSAK.map((m) => {
                  const on = muszakok.includes(m);
                  return (
                    <button
                      key={m}
                      type="button"
                      onClick={() => toggleMusak(m)}
                      className={`px-3 py-1 rounded-full text-xs font-semibold ${on ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"}`}
                    >
                      {m}
                    </button>
                  );
                })}
              </div>
            </div>
            <label className="text-xs space-y-1 block">
              <span className="text-muted-foreground">Megjegyzés</span>
              <textarea
                value={megjegyzes}
                onChange={(e) => setMegjegyzes(e.target.value.slice(0, 500))}
                rows={2}
                className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
              />
            </label>
          </div>
        )}

        <button
          type="button"
          onClick={savePref}
          disabled={saving}
          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90 disabled:opacity-50"
        >
          {saving && <Loader2 className="size-3.5 animate-spin" />}
          Mentés
        </button>
      </div>

      {isHr && (
        <div className="rounded-lg border border-amber-500/30 bg-amber-500/5 p-4 space-y-3">
          <h3 className="font-semibold flex items-center gap-2 text-sm">
            <AlertTriangle className="size-4 text-amber-500" /> Túlóra elrendelése (HR)
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <label className="text-xs space-y-1">
              <span className="text-muted-foreground">Kezdő</span>
              <input
                type="datetime-local"
                value={oKezdo}
                onChange={(e) => setOKezdo(e.target.value)}
                className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
              />
            </label>
            <label className="text-xs space-y-1">
              <span className="text-muted-foreground">Záró</span>
              <input
                type="datetime-local"
                value={oZaro}
                onChange={(e) => setOZaro(e.target.value)}
                className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
              />
            </label>
            <label className="text-xs space-y-1">
              <span className="text-muted-foreground">Kategória</span>
              <select
                value={oKat}
                onChange={(e) => setOKat(e.target.value)}
                className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
              >
                <option value="rendkivuli">rendkívüli</option>
                <option value="ugyelet">ügyelet</option>
                <option value="keszenlet">készenlét</option>
                <option value="ovt">ÖVT</option>
              </select>
            </label>
            <input
              value={oHiv}
              onChange={(e) => setOHiv(e.target.value)}
              placeholder="Írásos hivatkozás (iktatószám / URL)"
              className="px-3 py-2 rounded-md border border-input bg-background text-sm self-end"
            />
          </div>
          <textarea
            value={oIndok}
            onChange={(e) => setOIndok(e.target.value.slice(0, 1000))}
            rows={2}
            placeholder="Indok (kötelező) — Eütev. 12/A § szerinti igazolás"
            className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm"
          />
          <button
            type="button"
            onClick={submitOrder}
            disabled={ordering}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md bg-amber-600 text-white text-xs font-semibold hover:opacity-90 disabled:opacity-50"
          >
            {ordering ? <Loader2 className="size-3.5 animate-spin" /> : <Plus className="size-3.5" />}
            Elrendelés
          </button>
        </div>
      )}

      <div className="rounded-lg border border-border bg-card">
        <div className="p-3 border-b border-border text-xs font-mono uppercase text-muted-foreground tracking-wider">
          Túlóra elrendelések ({orders.length})
        </div>
        {orders.length === 0 ? (
          <div className="p-6 text-sm text-muted-foreground">Nincs elrendelt túlóra.</div>
        ) : (
          <ul className="divide-y divide-border">
            {orders.map((o) => (
              <li key={o.id} className="p-3 text-sm flex items-start justify-between gap-3">
                <div>
                  <div className="font-medium">
                    {new Date(o.kezdo_idopont).toLocaleString("hu")} →{" "}
                    {new Date(o.zaro_idopont).toLocaleString("hu")} ·{" "}
                    <span className="text-muted-foreground">{Number(o.ora).toFixed(1)} ó · {o.kategoria}</span>
                  </div>
                  <div className="text-xs text-muted-foreground">{o.indok}</div>
                  {o.irasos_hivatkozas && (
                    <div className="text-[11px] font-mono text-muted-foreground truncate max-w-md">
                      {o.irasos_hivatkozas}
                    </div>
                  )}
                </div>
                <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded-full bg-secondary self-start">
                  {o.status}
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
