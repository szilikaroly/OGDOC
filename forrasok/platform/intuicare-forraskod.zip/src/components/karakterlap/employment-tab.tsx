import { useEffect, useMemo, useState } from "react";
import {
  Loader2,
  Plus,
  Trash2,
  Briefcase,
  Star,
  StarOff,
  Save,
  ShieldAlert,
  History,
  AlertTriangle,
  Check,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { useTranslation } from "react-i18next";
import { supabase } from "@/integrations/supabase/client";
import { humanizeError } from "@/lib/humanize-error";
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const sb = supabase as any;
import { cn } from "@/lib/utils";

// ============================================================
// Types
// ============================================================
type JogviszonyTipus =
  | "kjt_kozalkalmazott"
  | "egeszsegugyi_szolgalati"
  | "munka_tv_kv"
  | "megbizasi"
  | "egyeni_vallalkozo"
  | "tarsas_vallalkozo"
  | "kozalkalmazotti_tovabbi"
  | "rezidens_kepzes"
  | "oszintszerzodes"
  | "egyeb";

type FenntartoTipus =
  | "allami"
  | "onkormanyzati"
  | "egyhazi"
  | "egyetemi_klinika"
  | "maganszektor"
  | "egyeb";

type KeretTipus = "heti" | "havi" | "negyedeves" | "eves" | "egyedi";

type Employment = {
  id: string;
  tenant_id: string;
  user_id: string;
  elsodleges: boolean;
  jogviszony_tipus: JogviszonyTipus;
  fenntarto_tipus: FenntartoTipus;
  munkaltato_nev: string;
  munkakor_megnevezes: string | null;
  munkakor_kod: string | null;
  org_unit_id: string | null;
  site_id: string | null;
  kezdo_datum: string | null;
  zaro_datum: string | null;
  munkaido_keret: KeretTipus;
  keret_ora: number | null;
  fte_szazalek: number;
  tobbes_jogviszony: boolean;
  opt_out_ovt: boolean;
  opt_out_kezdete: string | null;
  opt_out_visszavonas: string | null;
  ovt_max_evi_ora: number | null;
  osszeferhetetlenseg_megjegyzes: string | null;
  ervenyes: boolean;
};

type OptoutLog = {
  id: string;
  employment_id: string;
  action: "opt_in" | "opt_out" | "revoke" | "keret_modositas";
  effective_date: string;
  ovt_max_evi_ora: number | null;
  indok: string | null;
  decided_by: string | null;
  created_at: string;
};

type OrgUnit = { id: string; nev: string };
type Site = { id: string; nev: string };

// ============================================================
// Labels
// ============================================================
const JOGVISZONY_LABEL: Record<JogviszonyTipus, string> = {
  kjt_kozalkalmazott: "KJT közalkalmazotti",
  egeszsegugyi_szolgalati: "Egészségügyi szolgálati",
  munka_tv_kv: "Munka törvénykönyve",
  megbizasi: "Megbízási",
  egyeni_vallalkozo: "Egyéni vállalkozó",
  tarsas_vallalkozo: "Társas vállalkozó",
  kozalkalmazotti_tovabbi: "Közalk. további jogv.",
  rezidens_kepzes: "Rezidens / képzési",
  oszintszerzodes: "Ösztöndíj-szerződés",
  egyeb: "Egyéb",
};

const FENNTARTO_LABEL: Record<FenntartoTipus, string> = {
  allami: "Állami",
  onkormanyzati: "Önkormányzati",
  egyhazi: "Egyházi",
  egyetemi_klinika: "Egyetemi klinika",
  maganszektor: "Magán",
  egyeb: "Egyéb",
};

const KERET_LABEL: Record<KeretTipus, string> = {
  heti: "Heti",
  havi: "Havi",
  negyedeves: "Negyedéves",
  eves: "Éves",
  egyedi: "Egyedi",
};

const OPTOUT_ACTION_LABEL: Record<OptoutLog["action"], string> = {
  opt_in: "Csatlakozott OVT-hez",
  opt_out: "Kilépés (opt-out) bejelentve",
  revoke: "Visszavonás",
  keret_modositas: "Keret módosítva",
};

// Default OVT annual hours per Mt. szabályai
const DEFAULT_OVT_MAX = 416;
const STANDARD_OVT_MAX = 250;

// ============================================================
// Helpers
// ============================================================
function emptyEmployment(userId: string, tenantId: string): Omit<Employment, "id"> {
  return {
    tenant_id: tenantId,
    user_id: userId,
    elsodleges: false,
    jogviszony_tipus: "egeszsegugyi_szolgalati",
    fenntarto_tipus: "allami",
    munkaltato_nev: "",
    munkakor_megnevezes: null,
    munkakor_kod: null,
    org_unit_id: null,
    site_id: null,
    kezdo_datum: null,
    zaro_datum: null,
    munkaido_keret: "heti",
    keret_ora: 40,
    fte_szazalek: 100,
    tobbes_jogviszony: false,
    opt_out_ovt: false,
    opt_out_kezdete: null,
    opt_out_visszavonas: null,
    ovt_max_evi_ora: STANDARD_OVT_MAX,
    osszeferhetetlenseg_megjegyzes: null,
    ervenyes: true,
  };
}

// ============================================================
// Tab
// ============================================================
export function EmploymentTab({
  userId,
  tenantId,
  isHr,
}: {
  userId: string;
  tenantId: string | null;
  isHr: boolean;
}) {
  const { t } = useTranslation();
  const [rows, setRows] = useState<Employment[]>([]);
  const [loading, setLoading] = useState(true);
  const [orgUnits, setOrgUnits] = useState<OrgUnit[]>([]);
  const [sites, setSites] = useState<Site[]>([]);
  const [creating, setCreating] = useState(false);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    const { data, error } = await sb.from("profile_employment")
      .select("*")
      .eq("user_id", userId)
      .order("elsodleges", { ascending: false })
      .order("kezdo_datum", { ascending: false, nullsFirst: false });
    if (error) toast.error(humanizeError(error, t));
    setRows((data ?? []) as Employment[]);
    setLoading(false);
  }

  useEffect(() => {
    if (!tenantId) return;
    load();
    supabase
      .from("org_units")
      .select("id, nev")
      .eq("tenant_id", tenantId)
      .order("nev")
      .then(({ data }) => setOrgUnits((data ?? []) as OrgUnit[]));
    supabase
      .from("sites")
      .select("id, nev")
      .eq("tenant_id", tenantId)
      .order("nev")
      .then(({ data }) => setSites((data ?? []) as Site[]));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId, tenantId]);

  async function addEmployment() {
    if (!tenantId) return;
    setCreating(true);
    const payload = {
      ...emptyEmployment(userId, tenantId),
      munkaltato_nev: "Új munkáltató",
      elsodleges: rows.length === 0,
    };
    const { data, error } = await sb.from("profile_employment")
      .insert(payload)
      .select()
      .single();
    setCreating(false);
    if (error) {
      toast.error(humanizeError(error, t));
      return;
    }
    setExpandedId((data as Employment).id);
    await load();
  }

  async function remove(id: string) {
    if (!window.confirm("Biztosan törli a jogviszonyt?")) return;
    const { error } = await sb.from("profile_employment").delete().eq("id", id);
    if (error) {
      toast.error(humanizeError(error, t));
      return;
    }
    await load();
  }

  if (!tenantId) {
    return <div className="text-sm text-muted-foreground">Nincs tenant.</div>;
  }
  if (loading) {
    return (
      <div className="flex items-center gap-2 text-muted-foreground text-sm py-6">
        <Loader2 className="size-4 animate-spin" /> Betöltés…
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <header className="flex items-start justify-between gap-3">
        <div>
          <h2 className="text-base font-semibold flex items-center gap-2">
            <Briefcase className="size-4" /> Jogviszony
          </h2>
          <p className="text-xs text-muted-foreground mt-0.5">
            Jogviszony típusa, fenntartó, munkaidő-keret, FTE, többes jogviszony és OVT (önként vállalt többletmunka) opt-out beállítása. A beosztó motor ezeket veszi alapul.
          </p>
        </div>
        <button
          type="button"
          onClick={addEmployment}
          disabled={creating}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-primary text-primary-foreground text-xs font-semibold disabled:opacity-50"
        >
          {creating ? <Loader2 className="size-3.5 animate-spin" /> : <Plus className="size-3.5" />}
          Új jogviszony
        </button>
      </header>

      {rows.length === 0 ? (
        <div className="rounded-lg border border-dashed border-border bg-secondary/30 p-6 text-center text-sm text-muted-foreground">
          Még nincs rögzített jogviszony.
        </div>
      ) : (
        <div className="space-y-3">
          {rows.map((emp) => (
            <EmploymentCard
              key={emp.id}
              emp={emp}
              orgUnits={orgUnits}
              sites={sites}
              expanded={expandedId === emp.id}
              onExpand={() => setExpandedId((prev) => (prev === emp.id ? null : emp.id))}
              onRemove={() => remove(emp.id)}
              onSaved={load}
              isHr={isHr}
            />
          ))}
        </div>
      )}
    </div>
  );
}

// ============================================================
// Card
// ============================================================
function EmploymentCard({
  emp,
  orgUnits,
  sites,
  expanded,
  onExpand,
  onRemove,
  onSaved,
  isHr,
}: {
  emp: Employment;
  orgUnits: OrgUnit[];
  sites: Site[];
  expanded: boolean;
  onExpand: () => void;
  onRemove: () => void;
  onSaved: () => void;
  isHr: boolean;
}) {
  const { t } = useTranslation();
  const [form, setForm] = useState<Employment>(emp);
  const [saving, setSaving] = useState(false);
  const [logs, setLogs] = useState<OptoutLog[]>([]);
  const [logsLoading, setLogsLoading] = useState(false);
  const dirty = useMemo(() => JSON.stringify(emp) !== JSON.stringify(form), [emp, form]);

  useEffect(() => {
    setForm(emp);
  }, [emp]);

  async function loadLogs() {
    setLogsLoading(true);
    const { data } = await sb.from("profile_employment_optout_log")
      .select("*")
      .eq("employment_id", emp.id)
      .order("created_at", { ascending: false });
    setLogs((data ?? []) as OptoutLog[]);
    setLogsLoading(false);
  }

  useEffect(() => {
    if (expanded) loadLogs();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [expanded]);

  async function save() {
    setSaving(true);
    const { error } = await sb.from("profile_employment")
      .update({
        elsodleges: form.elsodleges,
        jogviszony_tipus: form.jogviszony_tipus,
        fenntarto_tipus: form.fenntarto_tipus,
        munkaltato_nev: form.munkaltato_nev.trim() || "Munkáltató",
        munkakor_megnevezes: form.munkakor_megnevezes,
        munkakor_kod: form.munkakor_kod,
        org_unit_id: form.org_unit_id,
        site_id: form.site_id,
        kezdo_datum: form.kezdo_datum,
        zaro_datum: form.zaro_datum,
        munkaido_keret: form.munkaido_keret,
        keret_ora: form.keret_ora,
        fte_szazalek: form.fte_szazalek,
        tobbes_jogviszony: form.tobbes_jogviszony,
        osszeferhetetlenseg_megjegyzes: form.osszeferhetetlenseg_megjegyzes,
        ervenyes: form.ervenyes,
      })
      .eq("id", emp.id);
    setSaving(false);
    if (error) {
      toast.error(humanizeError(error, t));
      return;
    }
    toast.success("Mentve.");
    onSaved();
  }

  async function setPrimary() {
    const { error } = await sb.from("profile_employment")
      .update({ elsodleges: !emp.elsodleges })
      .eq("id", emp.id);
    if (error) {
      toast.error(humanizeError(error, t));
      return;
    }
    onSaved();
  }

  async function submitOptoutChange(
    action: OptoutLog["action"],
    payload: { effective_date: string; ovt_max_evi_ora: number | null; indok: string },
  ) {
    // 1) log
    const { error: logErr } = await sb.from("profile_employment_optout_log")
      .insert({
        tenant_id: emp.tenant_id,
        employment_id: emp.id,
        user_id: emp.user_id,
        action,
        effective_date: payload.effective_date,
        ovt_max_evi_ora: payload.ovt_max_evi_ora,
        indok: payload.indok || null,
      });
    if (logErr) {
      toast.error(humanizeError(logErr, t));
      return;
    }
    // 2) employment frissítése
    const patch: Partial<Employment> = {};
    if (action === "opt_out") {
      patch.opt_out_ovt = true;
      patch.opt_out_kezdete = payload.effective_date;
      patch.ovt_max_evi_ora = payload.ovt_max_evi_ora ?? DEFAULT_OVT_MAX;
    } else if (action === "opt_in") {
      patch.opt_out_ovt = false;
      patch.opt_out_kezdete = null;
      patch.opt_out_visszavonas = null;
      patch.ovt_max_evi_ora = STANDARD_OVT_MAX;
    } else if (action === "revoke") {
      patch.opt_out_visszavonas = payload.effective_date;
    } else if (action === "keret_modositas") {
      patch.ovt_max_evi_ora = payload.ovt_max_evi_ora;
    }
    const { error: updErr } = await sb.from("profile_employment")
      .update(patch)
      .eq("id", emp.id);
    if (updErr) {
      toast.error(humanizeError(updErr, t));
      return;
    }
    toast.success("OVT állapot frissítve.");
    loadLogs();
    onSaved();
  }

  const optoutAktiv = emp.opt_out_ovt && (!emp.opt_out_visszavonas || emp.opt_out_visszavonas > new Date().toISOString().slice(0, 10));

  return (
    <div className="rounded-lg border border-border bg-card overflow-hidden">
      {/* Header */}
      <div className="px-4 py-3 flex items-center justify-between gap-3 bg-secondary/20">
        <button type="button" onClick={onExpand} className="flex items-center gap-2 min-w-0 flex-1 text-left hover:text-primary transition-colors">
          {emp.elsodleges ? (
            <Star className="size-4 text-warning fill-warning shrink-0" />
          ) : (
            <Briefcase className="size-4 text-muted-foreground shrink-0" />
          )}
          <div className="min-w-0">
            <div className="font-semibold text-sm truncate">{emp.munkaltato_nev || "—"}</div>
            <div className="text-[11px] font-mono text-muted-foreground truncate">
              {JOGVISZONY_LABEL[emp.jogviszony_tipus]} · {FENNTARTO_LABEL[emp.fenntarto_tipus]} · {emp.fte_szazalek}% FTE
              {emp.tobbes_jogviszony && <> · többes jogv.</>}
              {optoutAktiv && <> · <span className="text-warning">OVT opt-out</span></>}
              {!emp.ervenyes && <> · <span className="text-destructive">érvénytelen</span></>}
            </div>
          </div>
        </button>
        <div className="flex items-center gap-1 shrink-0">
          <button
            type="button"
            onClick={setPrimary}
            title={emp.elsodleges ? "Elsődleges leszedése" : "Elsődleges-re állítás"}
            className="p-1.5 text-muted-foreground hover:text-warning transition-colors"
          >
            {emp.elsodleges ? <StarOff className="size-3.5" /> : <Star className="size-3.5" />}
          </button>
          <button
            type="button"
            onClick={onRemove}
            className="p-1.5 text-muted-foreground hover:text-destructive transition-colors"
          >
            <Trash2 className="size-3.5" />
          </button>
        </div>
      </div>

      {expanded && (
        <div className="p-4 space-y-5 border-t border-border">
          {/* Alap */}
          <Section title="Alapadatok">
            <div className="grid sm:grid-cols-2 gap-3">
              <Field label="Munkáltató neve *">
                <input
                  value={form.munkaltato_nev}
                  onChange={(e) => setForm({ ...form, munkaltato_nev: e.target.value })}
                  className={inputCls}
                />
              </Field>
              <Field label="Munkakör megnevezése">
                <input
                  value={form.munkakor_megnevezes ?? ""}
                  onChange={(e) => setForm({ ...form, munkakor_megnevezes: e.target.value || null })}
                  className={inputCls}
                />
              </Field>
              <Field label="Jogviszony típusa">
                <select
                  value={form.jogviszony_tipus}
                  onChange={(e) => setForm({ ...form, jogviszony_tipus: e.target.value as JogviszonyTipus })}
                  className={inputCls}
                >
                  {Object.entries(JOGVISZONY_LABEL).map(([k, v]) => (
                    <option key={k} value={k}>{v}</option>
                  ))}
                </select>
              </Field>
              <Field label="Fenntartó típusa">
                <select
                  value={form.fenntarto_tipus}
                  onChange={(e) => setForm({ ...form, fenntarto_tipus: e.target.value as FenntartoTipus })}
                  className={inputCls}
                >
                  {Object.entries(FENNTARTO_LABEL).map(([k, v]) => (
                    <option key={k} value={k}>{v}</option>
                  ))}
                </select>
              </Field>
              <Field label="Munkakör-kód (FEOR)">
                <input
                  value={form.munkakor_kod ?? ""}
                  onChange={(e) => setForm({ ...form, munkakor_kod: e.target.value || null })}
                  className={inputCls}
                />
              </Field>
              <Field label="Telephely">
                <select
                  value={form.site_id ?? ""}
                  onChange={(e) => setForm({ ...form, site_id: e.target.value || null })}
                  className={inputCls}
                >
                  <option value="">—</option>
                  {sites.map((s) => (
                    <option key={s.id} value={s.id}>{s.nev}</option>
                  ))}
                </select>
              </Field>
              <Field label="Szervezeti egység">
                <select
                  value={form.org_unit_id ?? ""}
                  onChange={(e) => setForm({ ...form, org_unit_id: e.target.value || null })}
                  className={inputCls}
                >
                  <option value="">—</option>
                  {orgUnits.map((o) => (
                    <option key={o.id} value={o.id}>{o.nev}</option>
                  ))}
                </select>
              </Field>
              <Field label="Érvényesség">
                <div className="flex items-center gap-2">
                  <input
                    type="date"
                    value={form.kezdo_datum ?? ""}
                    onChange={(e) => setForm({ ...form, kezdo_datum: e.target.value || null })}
                    className={inputCls}
                  />
                  <span className="text-muted-foreground">→</span>
                  <input
                    type="date"
                    value={form.zaro_datum ?? ""}
                    onChange={(e) => setForm({ ...form, zaro_datum: e.target.value || null })}
                    className={inputCls}
                  />
                </div>
              </Field>
            </div>
          </Section>

          {/* Munkaidő */}
          <Section title="Munkaidő-keret">
            <div className="grid sm:grid-cols-3 gap-3">
              <Field label="Keret típus">
                <select
                  value={form.munkaido_keret}
                  onChange={(e) => setForm({ ...form, munkaido_keret: e.target.value as KeretTipus })}
                  className={inputCls}
                >
                  {Object.entries(KERET_LABEL).map(([k, v]) => (
                    <option key={k} value={k}>{v}</option>
                  ))}
                </select>
              </Field>
              <Field label="Keret óraszám">
                <input
                  type="number"
                  step="0.5"
                  value={form.keret_ora ?? ""}
                  onChange={(e) => setForm({ ...form, keret_ora: e.target.value ? Number(e.target.value) : null })}
                  className={inputCls}
                />
              </Field>
              <Field label="FTE (%)">
                <input
                  type="number"
                  min={0}
                  max={200}
                  value={form.fte_szazalek}
                  onChange={(e) => setForm({ ...form, fte_szazalek: Number(e.target.value) })}
                  className={inputCls}
                />
              </Field>
            </div>
            <label className="flex items-center gap-2 text-xs mt-2">
              <input
                type="checkbox"
                checked={form.tobbes_jogviszony}
                onChange={(e) => setForm({ ...form, tobbes_jogviszony: e.target.checked })}
                className="size-3.5"
              />
              <span>Többes jogviszonyban áll (másik foglalkoztatónál is dolgozik)</span>
            </label>
            <label className="flex items-center gap-2 text-xs mt-1">
              <input
                type="checkbox"
                checked={form.ervenyes}
                onChange={(e) => setForm({ ...form, ervenyes: e.target.checked })}
                className="size-3.5"
              />
              <span>Érvényes / hatályos jogviszony</span>
            </label>
          </Section>

          {/* Összeférhetetlenség */}
          <Section title="Összeférhetetlenség">
            <Field label="Megjegyzés / nyilatkozat">
              <textarea
                value={form.osszeferhetetlenseg_megjegyzes ?? ""}
                onChange={(e) => setForm({ ...form, osszeferhetetlenseg_megjegyzes: e.target.value || null })}
                rows={3}
                placeholder="pl. konkurens intézményi tilalmak, etikai kötöttségek, COI-bejelentések"
                className={cn(inputCls, "font-mono text-xs")}
              />
            </Field>
          </Section>

          {/* Save */}
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setForm(emp)}
              disabled={!dirty || saving}
              className="px-3 py-1.5 rounded-md text-xs font-semibold bg-secondary text-secondary-foreground disabled:opacity-50"
            >
              Mégse
            </button>
            <button
              type="button"
              onClick={save}
              disabled={!dirty || saving}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-primary text-primary-foreground text-xs font-semibold disabled:opacity-50"
            >
              {saving ? <Loader2 className="size-3.5 animate-spin" /> : <Save className="size-3.5" />}
              Mentés
            </button>
          </div>

          {/* OVT panel */}
          <OvtPanel
            emp={emp}
            isHr={isHr}
            onSubmit={submitOptoutChange}
            logs={logs}
            logsLoading={logsLoading}
          />
        </div>
      )}
    </div>
  );
}

// ============================================================
// OVT panel
// ============================================================
function OvtPanel({
  emp,
  isHr,
  onSubmit,
  logs,
  logsLoading,
}: {
  emp: Employment;
  isHr: boolean;
  onSubmit: (action: OptoutLog["action"], payload: { effective_date: string; ovt_max_evi_ora: number | null; indok: string }) => void;
  logs: OptoutLog[];
  logsLoading: boolean;
}) {
  const today = new Date().toISOString().slice(0, 10);
  const [date, setDate] = useState(today);
  const [keret, setKeret] = useState<number | "">(emp.ovt_max_evi_ora ?? DEFAULT_OVT_MAX);
  const [indok, setIndok] = useState("");

  const aktiv = emp.opt_out_ovt && (!emp.opt_out_visszavonas || emp.opt_out_visszavonas > today);

  return (
    <Section title="OVT – Önként vállalt többletmunka">
      <div
        className={cn(
          "rounded-md border p-3 text-xs flex items-start gap-2",
          aktiv ? "border-warning/40 bg-warning/5" : "border-border bg-secondary/30",
        )}
      >
        {aktiv ? (
          <AlertTriangle className="size-4 text-warning shrink-0 mt-0.5" />
        ) : (
          <ShieldAlert className="size-4 text-muted-foreground shrink-0 mt-0.5" />
        )}
        <div className="flex-1 space-y-0.5">
          <div className="font-semibold">
            {aktiv ? "Aktív opt-out (kiterjesztett éves OVT keret)" : "Nem vállal opt-out keretet"}
          </div>
          <div className="text-muted-foreground">
            {aktiv ? (
              <>
                Kezdete: <b>{emp.opt_out_kezdete ?? "—"}</b>
                {emp.opt_out_visszavonas && (
                  <> · Visszavonás: <b>{emp.opt_out_visszavonas}</b></>
                )}
                {" · Éves max: "}
                <b>{emp.ovt_max_evi_ora ?? DEFAULT_OVT_MAX} óra</b>
              </>
            ) : (
              <>Éves OVT keret: <b>{emp.ovt_max_evi_ora ?? STANDARD_OVT_MAX} óra</b> (törvényi alap)</>
            )}
          </div>
        </div>
      </div>

      <div className="grid sm:grid-cols-3 gap-3 mt-3">
        <Field label="Hatálybalépés">
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className={inputCls}
          />
        </Field>
        <Field label="Éves OVT keret (óra)">
          <input
            type="number"
            min={0}
            value={keret}
            onChange={(e) => setKeret(e.target.value ? Number(e.target.value) : "")}
            className={inputCls}
          />
        </Field>
        <Field label="Indok">
          <input
            value={indok}
            onChange={(e) => setIndok(e.target.value)}
            placeholder="pl. szülészeti ügyeleti kötelezettség"
            className={inputCls}
          />
        </Field>
      </div>

      <div className="flex flex-wrap gap-2 mt-3">
        {!aktiv ? (
          <button
            type="button"
            onClick={() => onSubmit("opt_out", { effective_date: date, ovt_max_evi_ora: keret === "" ? DEFAULT_OVT_MAX : keret, indok })}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-warning/10 text-warning border border-warning/40 text-xs font-semibold hover:bg-warning/20 transition-colors"
          >
            <Check className="size-3.5" /> Opt-out bejelentése
          </button>
        ) : (
          <>
            <button
              type="button"
              onClick={() => onSubmit("revoke", { effective_date: date, ovt_max_evi_ora: emp.ovt_max_evi_ora, indok })}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-secondary text-secondary-foreground text-xs font-semibold hover:bg-secondary/80 transition-colors"
            >
              <X className="size-3.5" /> Visszavonás benyújtása
            </button>
            <button
              type="button"
              disabled={!isHr}
              onClick={() => onSubmit("opt_in", { effective_date: date, ovt_max_evi_ora: STANDARD_OVT_MAX, indok })}
              title={isHr ? "" : "Csak HR jóváhagyhatja az azonnali opt-in-t"}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-success/10 text-success border border-success/40 text-xs font-semibold disabled:opacity-50 hover:bg-success/20 transition-colors"
            >
              <Check className="size-3.5" /> Opt-in / törvényi keret
            </button>
            <button
              type="button"
              disabled={!isHr}
              onClick={() => onSubmit("keret_modositas", { effective_date: date, ovt_max_evi_ora: keret === "" ? null : keret, indok })}
              title={isHr ? "" : "Csak HR módosíthatja a keretet"}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-primary/10 text-primary border border-primary/40 text-xs font-semibold disabled:opacity-50 hover:bg-primary/20 transition-colors"
            >
              <Save className="size-3.5" /> Keret módosítása
            </button>
          </>
        )}
      </div>

      {/* Log */}
      <div className="mt-4">
        <div className="text-[10px] font-mono uppercase text-muted-foreground tracking-wider mb-2 flex items-center gap-1">
          <History className="size-3" /> OVT-napló
        </div>
        {logsLoading ? (
          <div className="text-xs text-muted-foreground flex items-center gap-2">
            <Loader2 className="size-3 animate-spin" /> Betöltés…
          </div>
        ) : logs.length === 0 ? (
          <div className="text-xs text-muted-foreground">Nincs naplóbejegyzés.</div>
        ) : (
          <div className="divide-y divide-border rounded-md border border-border overflow-hidden">
            {logs.map((l) => (
              <div key={l.id} className="px-3 py-2 text-xs flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="font-semibold">{OPTOUT_ACTION_LABEL[l.action]}</div>
                  <div className="text-muted-foreground text-[11px]">
                    Hatály: {l.effective_date}
                    {l.ovt_max_evi_ora != null && <> · keret: {l.ovt_max_evi_ora} ó</>}
                    {l.indok && <> · {l.indok}</>}
                  </div>
                </div>
                <div className="text-[10px] font-mono text-muted-foreground shrink-0">
                  {new Date(l.created_at).toLocaleString("hu-HU")}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </Section>
  );
}

// ============================================================
// Misc
// ============================================================
const inputCls = "w-full px-2 py-1.5 text-xs rounded-md border border-input bg-background";

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <div className="text-[10px] font-mono uppercase text-muted-foreground tracking-wider mb-1">
        {label}
      </div>
      {children}
    </label>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="space-y-2">
      <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground">{title}</h3>
      {children}
    </section>
  );
}
