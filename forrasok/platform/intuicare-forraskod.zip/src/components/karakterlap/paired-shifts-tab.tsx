import { useEffect, useState } from "react";
import { Loader2, Users2, Plus, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { humanizeError } from "@/lib/humanize-error";
import { toast } from "sonner";
import { useTranslation } from "react-i18next";

type Pair = {
  id: string;
  partner_id: string;
  tipus: "egyutt_kivant" | "egyutt_kerult";
  muszak_kulcs: string | null;
  napok: number[];
  suly: number;
  indoklas: string | null;
  partner?: { teljes_nev: string } | null;
};

type Person = { id: string; teljes_nev: string };

const NAP_LABEL = ["H", "K", "Sze", "Cs", "P", "Szo", "V"];

export function PairedShiftsTab({ userId, tenantId }: { userId: string; tenantId: string | null }) {
  const { t } = useTranslation();
  const [rows, setRows] = useState<Pair[]>([]);
  const [people, setPeople] = useState<Person[]>([]);
  const [loading, setLoading] = useState(true);
  const [newPartner, setNewPartner] = useState("");
  const [newTipus, setNewTipus] = useState<"egyutt_kivant" | "egyutt_kerult">("egyutt_kivant");
  const [newIndok, setNewIndok] = useState("");
  const [newSuly, setNewSuly] = useState(50);

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId]);

  async function load() {
    setLoading(true);
    const [{ data: pairs, error }, { data: pp }] = await Promise.all([
      supabase
        .from("profile_paired_shifts")
        .select("id,partner_id,tipus,muszak_kulcs,napok,suly,indoklas,partner:profiles!profile_paired_shifts_partner_id_fkey(teljes_nev)")
        .eq("user_id", userId),
      supabase.from("profiles").select("id,teljes_nev").neq("id", userId).order("teljes_nev"),
    ]);
    if (error) toast.error(humanizeError(error, t));
    else setRows((pairs ?? []) as Pair[]);
    setPeople((pp ?? []) as Person[]);
    setLoading(false);
  }

  async function add() {
    if (!tenantId || !newPartner) return;
    const { data, error } = await (supabase.from("profile_paired_shifts") as any)
      .insert({
        tenant_id: tenantId,
        user_id: userId,
        partner_id: newPartner,
        tipus: newTipus,
        suly: newSuly,
        indoklas: newIndok || null,
        napok: [],
      })
      .select("id,partner_id,tipus,muszak_kulcs,napok,suly,indoklas,partner:profiles!profile_paired_shifts_partner_id_fkey(teljes_nev)")
      .single();
    if (error) return toast.error(humanizeError(error, t));
    setRows([data as Pair, ...rows]);
    setNewPartner("");
    setNewIndok("");
    toast.success("Páros preferencia hozzáadva");
  }

  async function remove(id: string) {
    const { error } = await supabase.from("profile_paired_shifts").delete().eq("id", id);
    if (error) return toast.error(humanizeError(error, t));
    setRows(rows.filter((r) => r.id !== id));
  }

  if (loading) {
    return (
      <div className="flex h-32 items-center justify-center">
        <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Users2 className="h-5 w-5 text-primary" />
        <h2 className="text-lg font-medium">Páros műszak-preferenciák</h2>
      </div>
      <p className="text-xs text-muted-foreground">
        Kivel szeretne / nem szeretne együtt műszakot. A beosztómotor súlyozott lágy szabályként veszi figyelembe.
      </p>

      <div className="rounded-lg border bg-card p-3 grid grid-cols-1 sm:grid-cols-5 gap-2 items-end">
        <div className="sm:col-span-2">
          <label className="text-[10px] uppercase font-mono text-muted-foreground">Partner</label>
          <select value={newPartner} onChange={(e) => setNewPartner(e.target.value)} className="w-full rounded border bg-background px-2 py-1.5 text-sm">
            <option value="">— válasszon —</option>
            {people.map((p) => (
              <option key={p.id} value={p.id}>{p.teljes_nev}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="text-[10px] uppercase font-mono text-muted-foreground">Típus</label>
          <select value={newTipus} onChange={(e) => setNewTipus(e.target.value as any)} className="w-full rounded border bg-background px-2 py-1.5 text-sm">
            <option value="egyutt_kivant">együtt kívánt</option>
            <option value="egyutt_kerult">együtt került</option>
          </select>
        </div>
        <div>
          <label className="text-[10px] uppercase font-mono text-muted-foreground">Súly (0–100)</label>
          <input type="number" min={0} max={100} value={newSuly} onChange={(e) => setNewSuly(Number(e.target.value))} className="w-full rounded border bg-background px-2 py-1.5 text-sm" />
        </div>
        <div>
          <button onClick={add} disabled={!newPartner} className="w-full flex items-center justify-center gap-1 rounded bg-primary px-3 py-1.5 text-sm text-primary-foreground hover:opacity-90 disabled:opacity-40">
            <Plus className="h-4 w-4" /> Hozzáad
          </button>
        </div>
        <div className="sm:col-span-5">
          <input value={newIndok} onChange={(e) => setNewIndok(e.target.value)} placeholder="Indoklás (opcionális)" className="w-full rounded border bg-background px-2 py-1.5 text-sm" />
        </div>
      </div>

      <div className="rounded-lg border bg-card divide-y">
        {rows.length === 0 && <div className="p-4 text-sm text-muted-foreground italic">Nincs páros preferencia</div>}
        {rows.map((r) => (
          <div key={r.id} className="p-3 flex items-center gap-3">
            <span className={r.tipus === "egyutt_kivant" ? "px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 text-xs font-mono" : "px-2 py-0.5 rounded bg-rose-500/10 text-rose-700 dark:text-rose-400 text-xs font-mono"}>
              {r.tipus === "egyutt_kivant" ? "kívánt" : "került"}
            </span>
            <div className="flex-1">
              <div className="text-sm font-medium">{r.partner?.teljes_nev}</div>
              {r.indoklas && <div className="text-xs text-muted-foreground">{r.indoklas}</div>}
            </div>
            <span className="text-xs font-mono text-muted-foreground">súly: {r.suly}</span>
            <button onClick={() => remove(r.id)} className="text-rose-600 hover:text-rose-700">
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
