import { useEffect, useState, useCallback, useRef } from "react";
import { Bell, BellOff, Loader2, Trash2, Send, ExternalLink, CheckCircle2, AlertTriangle, XCircle } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { VAPID_PUBLIC_KEY, urlBase64ToUint8Array } from "@/lib/push/vapid";
import { cn } from "@/lib/utils";

type Sub = {
  id: string;
  endpoint: string;
  user_agent: string | null;
  created_at: string;
  last_used_at: string | null;
};

type SwState =
  | { kind: "unsupported" }
  | { kind: "none" }
  | { kind: "registering" }
  | { kind: "active"; scope: string }
  | { kind: "error"; message: string };

function providerName(endpoint: string): string {
  try {
    const host = new URL(endpoint).hostname;
    if (host.includes("fcm.googleapis.com") || host.includes("android.googleapis.com")) return "Google FCM";
    if (host.includes("push.services.mozilla.com")) return "Mozilla autopush";
    if (host.includes("notify.windows.com") || host.includes("wns2-")) return "Windows WNS";
    if (host.includes("web.push.apple.com")) return "Apple Push";
    return host;
  } catch {
    return "Ismeretlen szolgáltató";
  }
}

function describeError(e: unknown): string {
  if (!e) return "Ismeretlen hiba.";
  if (e instanceof DOMException) {
    const map: Record<string, string> = {
      NotAllowedError: "A böngésző megtagadta az engedélyt (lakat ikon → Értesítések → Engedélyezés).",
      AbortError: "A feliratkozást a böngésző megszakította (lehet, hogy nincs hálózat vagy nincs push szolgáltató).",
      InvalidStateError: "A service worker nem aktív. Frissítsd az oldalt és próbáld újra.",
      NotSupportedError: "Ez a böngésző nem támogatja a push feliratkozást ezen a domainen.",
      SecurityError: "Biztonsági kontextus hiba — csak HTTPS-en (vagy localhost) és top-level ablakban működik.",
    };
    return `${map[e.name] ?? e.message} (${e.name})`;
  }
  if (e instanceof Error) return e.message;
  return String(e);
}

export function NotificationSettings({ userId }: { userId: string }) {
  const [emailEnabled, setEmailEnabled] = useState(true);
  const [pushEnabled, setPushEnabled] = useState(true);
  const [supported, setSupported] = useState(false);
  const [inIframe, setInIframe] = useState(false);
  const [secureCtx, setSecureCtx] = useState(true);
  const [permission, setPermission] = useState<NotificationPermission>("default");
  const [swState, setSwState] = useState<SwState>({ kind: "none" });
  const [subs, setSubs] = useState<Sub[]>([]);
  const [busy, setBusy] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [lastError, setLastError] = useState<string | null>(null);
  const prevPermission = useRef<NotificationPermission>(permission);
  const prevSwKind = useRef<string>(swState.kind);

  const refreshSwState = useCallback(async () => {
    if (typeof navigator === "undefined" || !("serviceWorker" in navigator)) {
      setSwState({ kind: "unsupported" });
      return;
    }
    try {
      const regs = await navigator.serviceWorker.getRegistrations();
      const ours = regs.find((r) => r.active?.scriptURL.endsWith("/sw.js"));
      if (ours?.active) setSwState({ kind: "active", scope: ours.scope });
      else if (ours) setSwState({ kind: "registering" });
      else setSwState({ kind: "none" });
    } catch (e) {
      setSwState({ kind: "error", message: describeError(e) });
    }
  }, []);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const sup =
      "serviceWorker" in navigator &&
      "PushManager" in window &&
      typeof Notification !== "undefined";
    setSupported(sup);
    setSecureCtx(typeof window.isSecureContext === "boolean" ? window.isSecureContext : true);
    try {
      setInIframe(window.self !== window.top);
    } catch {
      setInIframe(true);
    }
    if (typeof Notification !== "undefined") setPermission(Notification.permission);
    refreshSwState();
  }, [refreshSwState]);

  // Periodic background refresh for permission + SW state so badges stay live
  // even when the user toggles browser permissions in another tab/settings.
  useEffect(() => {
    if (typeof window === "undefined") return;
    let cancelled = false;

    const tick = () => {
      if (cancelled) return;
      if (typeof Notification !== "undefined") {
        setPermission((prev) => (prev === Notification.permission ? prev : Notification.permission));
      }
      void refreshSwState();
    };

    // Poll while visible; pause when tab hidden to save resources.
    let interval: ReturnType<typeof setInterval> | null = null;
    const start = () => {
      if (interval) return;
      tick();
      interval = setInterval(tick, 5000);
    };
    const stop = () => {
      if (interval) {
        clearInterval(interval);
        interval = null;
      }
    };
    const onVisibility = () => {
      if (document.visibilityState === "visible") start();
      else stop();
    };
    const onFocus = () => tick();

    if (document.visibilityState === "visible") start();
    document.addEventListener("visibilitychange", onVisibility);
    window.addEventListener("focus", onFocus);

    // Permissions API: live updates when the user changes the permission.
    let permStatus: PermissionStatus | null = null;
    const permListener = () => tick();
    if (typeof navigator !== "undefined" && navigator.permissions?.query) {
      navigator.permissions
        .query({ name: "notifications" as PermissionName })
        .then((status) => {
          if (cancelled) return;
          permStatus = status;
          status.addEventListener("change", permListener);
        })
        .catch(() => {
          /* unsupported — polling covers it */
        });
    }

    // Service worker lifecycle events → instant refresh.
    const sw = typeof navigator !== "undefined" ? navigator.serviceWorker : undefined;
    const onSwChange = () => tick();
    sw?.addEventListener?.("controllerchange", onSwChange);

    return () => {
      cancelled = true;
      stop();
      document.removeEventListener("visibilitychange", onVisibility);
      window.removeEventListener("focus", onFocus);
      permStatus?.removeEventListener("change", permListener);
      sw?.removeEventListener?.("controllerchange", onSwChange);
    };
  }, [refreshSwState]);

  // Surface permission / SW changes as toasts so the user notices them immediately.
  useEffect(() => {
    if (prevPermission.current === permission) return;
    if (permission === "granted") {
      toast.success("Értesítések engedélyezve");
    } else if (permission === "denied") {
      toast.error("Értesítések letiltva a böngészőben");
    } else {
      toast.info("Értesítési engedély visszaállítva");
    }
    prevPermission.current = permission;
  }, [permission]);

  useEffect(() => {
    if (prevSwKind.current === swState.kind) return;
    if (swState.kind === "active") {
      toast.success("Service Worker aktív");
    } else if (swState.kind === "registering") {
      toast.info("Service Worker regisztrálása folyamatban");
    } else if (swState.kind === "error") {
      toast.error("Service Worker hiba");
    } else if (swState.kind === "unsupported") {
      toast.error("Push értesítés nem támogatott");
    } else if (swState.kind === "none") {
      toast.info("Service Worker leállt / nincs telepítve");
    }
    prevSwKind.current = swState.kind;
  }, [swState.kind]);

  const load = useCallback(async () => {
    setLoading(true);
    const [{ data: prof }, { data: list }] = await Promise.all([
      supabase.from("profiles").select("reminder_email_enabled, reminder_push_enabled").eq("id", userId).maybeSingle(),
      supabase
        .from("push_subscriptions" as never)
        .select("id, endpoint, user_agent, created_at, last_used_at")
        .eq("user_id", userId)
        .order("created_at", { ascending: false }),
    ]);
    if (prof) {
      setEmailEnabled((prof as { reminder_email_enabled?: boolean }).reminder_email_enabled ?? true);
      setPushEnabled((prof as { reminder_push_enabled?: boolean }).reminder_push_enabled ?? true);
    }
    setSubs((list ?? []) as unknown as Sub[]);
    setLoading(false);
  }, [userId]);

  useEffect(() => {
    load();
  }, [load]);

  // Auto-resume the permission flow when the user lands here from an iframe
  // via the "Megnyitás új lapon" handoff (URL marker: ?push=enable).
  const [autoResumed, setAutoResumed] = useState(false);
  useEffect(() => {
    if (autoResumed || loading || typeof window === "undefined") return;
    const params = new URLSearchParams(window.location.search);
    if (params.get("push") !== "enable") return;
    if (inIframe || !supported || !secureCtx) return;
    setAutoResumed(true);
    // Clean the marker so a refresh doesn't loop the prompt, but keep any
    // unrelated query params untouched.
    params.delete("push");
    params.delete("push_return");
    const qs = params.toString();
    window.history.replaceState(
      null,
      "",
      window.location.pathname + (qs ? `?${qs}` : "") + "#push-settings",
    );
    if (permission !== "granted") {
      void subscribePush();
    }
    // Smooth-scroll to the section
    setTimeout(() => {
      document.getElementById("push-settings")?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 50);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loading, inIframe, supported, secureCtx, permission, autoResumed]);

  async function togglePref(field: "reminder_email_enabled" | "reminder_push_enabled", value: boolean) {
    setBusy(field);
    const { error } = await supabase.from("profiles").update({ [field]: value } as never).eq("id", userId);
    setBusy(null);
    if (error) {
      toast.error("Mentés sikertelen");
      return;
    }
    if (field === "reminder_email_enabled") setEmailEnabled(value);
    else setPushEnabled(value);
    toast.success("Mentve");
  }

  function openInNewTab() {
    // Preserve current path + add a marker so the new tab auto-resumes the flow
    // and restores focus on this section after permission is granted.
    const params = new URLSearchParams(window.location.search);
    params.set("push", "enable");
    params.set("push_return", window.location.pathname + window.location.hash);
    const url = `${window.location.origin}${window.location.pathname}?${params.toString()}#push-settings`;
    window.open(url, "_blank", "noopener,noreferrer");
  }

  async function subscribePush() {
    setLastError(null);
    if (!supported) {
      const m = "A böngésző nem támogatja a push értesítéseket.";
      setLastError(m);
      toast.error(m);
      return;
    }
    if (!secureCtx) {
      const m = "Csak HTTPS-en működik (nem biztonságos kontextus).";
      setLastError(m);
      toast.error(m);
      return;
    }
    if (inIframe) {
      toast.message("Új lapon nyitom meg, ott engedélyezd a push-t.");
      openInNewTab();
      return;
    }
    setBusy("subscribe");
    try {
      let perm: NotificationPermission;
      try {
        perm = await Notification.requestPermission();
      } catch (e) {
        throw new Error(`Engedélykérés sikertelen: ${describeError(e)}`);
      }
      setPermission(perm);
      if (perm !== "granted") {
        throw new Error(
          perm === "denied"
            ? "A böngészőben tiltva van az értesítés. Engedélyezd a címsor melletti lakat-ikonnál."
            : "Az értesítés engedélye nem lett megadva.",
        );
      }
      setSwState({ kind: "registering" });
      const reg = await navigator.serviceWorker.register("/sw.js").catch((e) => {
        throw new Error(`Service worker regisztráció hiba: ${describeError(e)}`);
      });
      await navigator.serviceWorker.ready;
      setSwState({ kind: "active", scope: reg.scope });

      const existing = await reg.pushManager.getSubscription();
      const sub =
        existing ??
        (await reg.pushManager
          .subscribe({
            userVisibleOnly: true,
            applicationServerKey: urlBase64ToUint8Array(VAPID_PUBLIC_KEY) as BufferSource,
          })
          .catch((e) => {
            throw new Error(`pushManager.subscribe: ${describeError(e)}`);
          }));
      const json = sub.toJSON();
      const p256dh = json.keys?.p256dh ?? "";
      const auth = json.keys?.auth ?? "";
      if (!sub.endpoint || !p256dh || !auth) throw new Error("Hiányos feliratkozási adat a böngészőtől.");
      const { error } = await supabase
        .from("push_subscriptions" as never)
        .upsert(
          {
            user_id: userId,
            endpoint: sub.endpoint,
            p256dh,
            auth,
            user_agent: navigator.userAgent.slice(0, 200),
          } as never,
          { onConflict: "endpoint" },
        );
      if (error) throw new Error(`Mentés hiba: ${error.message}`);
      toast.success("Eszköz feliratkoztatva.");
      load();
    } catch (e) {
      const msg = describeError(e);
      console.error("[push] subscribe failed", e);
      setLastError(msg);
      toast.error("Feliratkozás sikertelen: " + msg);
    } finally {
      setBusy(null);
      refreshSwState();
    }
  }

  async function removeSub(id: string, endpoint: string) {
    setBusy(id);
    const { error } = await supabase.from("push_subscriptions" as never).delete().eq("id", id);
    if (error) {
      setBusy(null);
      toast.error("Eltávolítás sikertelen: " + error.message);
      return;
    }
    try {
      const reg = await navigator.serviceWorker.getRegistration();
      const existing = await reg?.pushManager.getSubscription();
      if (existing && existing.endpoint === endpoint) await existing.unsubscribe();
    } catch (e) {
      console.warn("[push] browser unsubscribe failed", e);
    }
    setBusy(null);
    toast.success("Eszköz eltávolítva");
    load();
  }

  async function testPush() {
    setBusy("test");
    try {
      const res = await fetch("/api/push/test", { method: "POST" });
      if (!res.ok) throw new Error(await res.text());
      toast.success("Próba-üzenet elküldve.");
    } catch (e) {
      const msg = describeError(e);
      setLastError(msg);
      toast.error("Próba sikertelen: " + msg);
    } finally {
      setBusy(null);
    }
  }

  if (loading) return <div className="text-sm text-muted-foreground">Betöltés…</div>;

  const permBadge =
    permission === "granted"
      ? { icon: CheckCircle2, color: "text-success", label: "engedélyezve" }
      : permission === "denied"
        ? { icon: XCircle, color: "text-destructive", label: "tiltva" }
        : { icon: AlertTriangle, color: "text-warning", label: "nincs megadva" };

  const swBadge =
    swState.kind === "active"
      ? { icon: CheckCircle2, color: "text-success", label: "aktív" }
      : swState.kind === "registering"
        ? { icon: Loader2, color: "text-muted-foreground animate-spin", label: "regisztrál…" }
        : swState.kind === "unsupported"
          ? { icon: XCircle, color: "text-destructive", label: "nem támogatott" }
          : swState.kind === "error"
            ? { icon: XCircle, color: "text-destructive", label: "hiba" }
            : { icon: AlertTriangle, color: "text-warning", label: "nincs telepítve" };

  const PermIcon = permBadge.icon;
  const SwIcon = swBadge.icon;

  const canSubscribe = supported && secureCtx && permission !== "denied";

  return (
    <div className="space-y-4 max-w-2xl">
      <div className="rounded-lg border border-border bg-card p-4 space-y-3">
        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Műszak-emlékeztetők (24 órával és 2 órával a műszak előtt)
        </div>

        <label className="flex items-center justify-between gap-3 py-2">
          <div>
            <div className="text-sm font-semibold">E-mail emlékeztető</div>
            <div className="text-xs text-muted-foreground">A regisztrált címedre küldjük.</div>
          </div>
          <input
            type="checkbox"
            checked={emailEnabled}
            disabled={busy === "reminder_email_enabled"}
            onChange={(e) => togglePref("reminder_email_enabled", e.target.checked)}
            className="size-5"
          />
        </label>

        <label className="flex items-center justify-between gap-3 py-2 border-t border-border">
          <div>
            <div className="text-sm font-semibold">Böngésző push értesítés</div>
            <div className="text-xs text-muted-foreground">Felugró értesítés azon eszközökön, ahol engedélyezted.</div>
          </div>
          <input
            type="checkbox"
            checked={pushEnabled}
            disabled={busy === "reminder_push_enabled"}
            onChange={(e) => togglePref("reminder_push_enabled", e.target.checked)}
            className="size-5"
          />
        </label>
      </div>

      <div id="push-settings" className="rounded-lg border border-border bg-card p-4 space-y-3 scroll-mt-20">

        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Push-eszközök ({subs.length})
          </div>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={subscribePush}
              disabled={busy === "subscribe" || (!inIframe && !canSubscribe)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90 disabled:opacity-50"
            >
              {busy === "subscribe" ? (
                <Loader2 className="size-3.5 animate-spin" />
              ) : inIframe ? (
                <ExternalLink className="size-3.5" />
              ) : (
                <Bell className="size-3.5" />
              )}
              {inIframe ? "Megnyitás új lapon" : "Ezen az eszközön engedélyezem"}
            </button>
            {subs.length > 0 && (
              <button
                type="button"
                onClick={testPush}
                disabled={busy === "test"}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-border text-xs font-semibold hover:bg-secondary disabled:opacity-50"
              >
                {busy === "test" ? <Loader2 className="size-3.5 animate-spin" /> : <Send className="size-3.5" />}
                Próba
              </button>
            )}
          </div>
        </div>

        {/* Diagnostic status */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
          <div className="flex items-center gap-2 rounded border border-border px-2 py-1.5">
            <PermIcon className={cn("size-4 shrink-0", permBadge.color)} />
            <div>
              <div className="font-medium">Értesítési engedély</div>
              <div className="text-muted-foreground">{permBadge.label} ({permission})</div>
            </div>
          </div>
          <div className="flex items-center gap-2 rounded border border-border px-2 py-1.5">
            <SwIcon className={cn("size-4 shrink-0", swBadge.color)} />
            <div>
              <div className="font-medium">Service worker</div>
              <div className="text-muted-foreground truncate">
                {swBadge.label}
                {swState.kind === "active" && ` · ${new URL(swState.scope).pathname}`}
                {swState.kind === "error" && ` · ${swState.message}`}
              </div>
            </div>
          </div>
        </div>

        {inIframe && (
          <div className="text-xs text-warning rounded border border-warning/30 bg-warning/5 px-2 py-1.5">
            Beágyazott (preview) nézetben futsz — a böngésző a push engedélyt csak top-level ablakban adja meg.
            Az „Engedélyezem” gomb automatikusan új lapot nyit ugyanezen az oldalon.
          </div>
        )}
        {!secureCtx && (
          <div className="text-xs text-destructive">Nem biztonságos kontextus — a push csak HTTPS-en működik.</div>
        )}
        {!supported && (
          <div className="text-xs text-warning">A böngésző nem támogatja a push értesítéseket (pl. iOS Safari csak telepített PWA-ként).</div>
        )}
        {permission === "denied" && (
          <div className="text-xs text-destructive">
            A böngészőben tiltva van az értesítés. Címsor → lakat ikon → Értesítések → Engedélyezés, majd frissítés.
          </div>
        )}
        {lastError && (
          <div className="text-xs text-destructive rounded border border-destructive/30 bg-destructive/5 px-2 py-1.5 break-words">
            <div className="font-semibold mb-0.5">Utolsó hiba</div>
            {lastError}
          </div>
        )}

        {subs.length === 0 ? (
          <div className="text-xs text-muted-foreground py-3 text-center">
            <BellOff className="inline size-4 mr-1" /> Még nincs feliratkozott eszköz.
          </div>
        ) : (
          <div className="divide-y divide-border">
            {subs.map((s) => (
              <div key={s.id} className="py-2 flex items-center gap-3">
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium truncate flex items-center gap-2">
                    <span className="inline-flex items-center rounded bg-secondary px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider">
                      {providerName(s.endpoint)}
                    </span>
                    <span className="truncate">{s.user_agent ?? "Ismeretlen eszköz"}</span>
                  </div>
                  <div className="text-[11px] font-mono text-muted-foreground truncate">{s.endpoint}</div>
                  <div className="text-[11px] text-muted-foreground">
                    Hozzáadva: {new Date(s.created_at).toLocaleString("hu-HU")}
                    {s.last_used_at && ` · Utolsó használat: ${new Date(s.last_used_at).toLocaleString("hu-HU")}`}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => removeSub(s.id, s.endpoint)}
                  disabled={busy === s.id}
                  className={cn(
                    "inline-flex items-center gap-1 px-2 py-1 rounded text-xs text-destructive border border-destructive/30 hover:bg-destructive/10",
                    busy === s.id && "opacity-50",
                  )}
                  aria-label="Letiltás"
                >
                  {busy === s.id ? <Loader2 className="size-3.5 animate-spin" /> : <Trash2 className="size-3.5" />}
                  Letiltás
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
