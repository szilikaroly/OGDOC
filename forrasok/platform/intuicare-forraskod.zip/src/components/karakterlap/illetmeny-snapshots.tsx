/**
 * Mentett havi illetmény-számítások listája a karakterlapon.
 * Verziószámmal (v1 = legrégebbi), dátum-szűrővel, és előző verzióhoz képesti
 * delta-jelzéssel. Minden snapshot újraszámolható vagy a PDF újra letölthető.
 */
import { useMemo, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  FileDown,
  RefreshCcw,
  Trash2,
  History,
  Loader2,
  ArrowDownRight,
  ArrowUpRight,
  Minus,
  Filter,
  X,
  GitCompareArrows,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { listIlletmenySnapshots, deleteIlletmenySnapshot } from "@/lib/eusztv/illetmeny.functions";
import { getIlletmeny, getGyakorlatiIdo } from "@/lib/eusztv/eusztv.functions";
import { generateIlletmenyPdf, type SnapshotPayload } from "./illetmeny-pdf";
import { IlletmenyDiffDialog } from "./illetmeny-diff-dialog";

const fmt = (n: number) => `${Math.round(n).toLocaleString("hu")} Ft`;
const fmtSigned = (n: number) =>
  `${n > 0 ? "+" : n < 0 ? "−" : ""}${Math.abs(Math.round(n)).toLocaleString("hu")} Ft`;

type Snap = {
  id: string;
  cimke: string;
  vonatkozasi_datum: string;
  created_at: string;
  vegosszeg_ft: number | string;
  bemenet?: Record<string, unknown> | null;
  eredmeny?: Record<string, unknown> | null;
  jogi_hivatkozasok?: unknown[] | null;
};

export function IlletmenySnapshots({
  userId,
  name,
  onLoad,
}: {
  userId: string;
  name?: string;
  /** Snapshot bemenetét visszatölti az aktív kalkulátorba. */
  onLoad?: (input: Record<string, unknown>) => void;
}) {
  const qc = useQueryClient();
  const listFn = useServerFn(listIlletmenySnapshots);
  const delFn = useServerFn(deleteIlletmenySnapshot);
  const iFn = useServerFn(getIlletmeny);
  const gFn = useServerFn(getGyakorlatiIdo);

  const { data: rows = [], isLoading } = useQuery({
    queryKey: ["illetmeny-snaps", userId],
    queryFn: () => listFn({ data: { userId } }) as Promise<Snap[]>,
  });

  const del = useMutation({
    mutationFn: async (id: string) => delFn({ data: { id } }),
    onSuccess: () => {
      toast.success("Snapshot törölve.");
      qc.invalidateQueries({ queryKey: ["illetmeny-snaps", userId] });
    },
  });

  const recompute = useMutation({
    mutationFn: async (snap: Snap) => {
      const [illetmeny] = await Promise.all([
        iFn({ data: { userId } }),
        gFn({ data: { userId } }),
      ]);
      return { snap, illetmeny };
    },
    onSuccess: ({ snap, illetmeny }) => {
      const havi = (snap.bemenet as any)?.havi ?? 0;
      const elteres = (illetmeny.vegso_ft ?? 0) - havi;
      toast.success(
        elteres === 0
          ? "Az aktuális számolt érték azonos a mentett snapshot havi illetményével."
          : `Frissített havi alap: ${fmt(illetmeny.vegso_ft)} (${fmtSigned(elteres)})`,
      );
    },
  });

  const reDownload = (snap: Snap) => {
    const payload: SnapshotPayload = {
      name,
      datum: snap.vonatkozasi_datum,
      bemenet: snap.bemenet ?? {},
      eredmeny: snap.eredmeny ?? {},
      jogi_hivatkozasok: (snap.jogi_hivatkozasok ?? []) as any,
    };
    generateIlletmenyPdf(payload, `illetmeny-${snap.cimke.replace(/\s+/g, "_")}-${snap.vonatkozasi_datum}.pdf`);
  };

  // === Verziószámozás (created_at ASC alapján v1, v2, ...) ===
  // A lista DESC-ben jön, ezért hossz - index = verziószám.
  const indexed = useMemo(() => {
    const total = rows.length;
    return rows.map((s, i) => {
      const version = total - i;
      // Az előző (időben korábbi) snapshot a DESC listában s[i+1].
      const prev = rows[i + 1] ?? null;
      const delta = prev ? Number(s.vegosszeg_ft) - Number(prev.vegosszeg_ft) : null;
      return { ...s, version, prev, delta };
    });
  }, [rows]);

  // === Dátumszűrő ===
  const [dateFrom, setDateFrom] = useState<string>("");
  const [dateTo, setDateTo] = useState<string>("");
  const [yearFilter, setYearFilter] = useState<string>("");

  const availableYears = useMemo(() => {
    const ys = new Set<string>();
    rows.forEach((r) => ys.add(r.vonatkozasi_datum.slice(0, 4)));
    return Array.from(ys).sort((a, b) => b.localeCompare(a));
  }, [rows]);

  const filtered = useMemo(() => {
    return indexed.filter((s) => {
      const d = s.vonatkozasi_datum;
      if (dateFrom && d < dateFrom) return false;
      if (dateTo && d > dateTo) return false;
      if (yearFilter && !d.startsWith(yearFilter)) return false;
      return true;
    });
  }, [indexed, dateFrom, dateTo, yearFilter]);

  const hasFilter = !!(dateFrom || dateTo || yearFilter);
  const clearFilters = () => {
    setDateFrom("");
    setDateTo("");
    setYearFilter("");
  };

  // === Diff kiválasztás (max 2 snapshot) ===
  const [selected, setSelected] = useState<string[]>([]);
  const [diffOpen, setDiffOpen] = useState(false);
  const toggleSelect = (id: string) => {
    setSelected((prev) => {
      if (prev.includes(id)) return prev.filter((x) => x !== id);
      if (prev.length >= 2) return [prev[1], id]; // FIFO: legrégebbi kiesik
      return [...prev, id];
    });
  };
  const selectedSnaps = selected
    .map((id) => indexed.find((s) => s.id === id))
    .filter(Boolean) as typeof indexed;
  // Diff mindig régebbi → újabb sorrendben
  const [olderSnap, newerSnap] =
    selectedSnaps.length === 2
      ? selectedSnaps[0].version < selectedSnaps[1].version
        ? [selectedSnaps[0], selectedSnaps[1]]
        : [selectedSnaps[1], selectedSnaps[0]]
      : [null, null];

  const openDiffWithPrev = (id: string) => {
    const idx = indexed.findIndex((s) => s.id === id);
    if (idx < 0) return;
    const cur = indexed[idx];
    const prev = indexed[idx + 1]; // DESC lista: következő index = régebbi verzió
    if (!prev) {
      toast.info("Ez a legrégebbi mentés — nincs mihez hasonlítani.");
      return;
    }
    setSelected([prev.id, cur.id]);
    setDiffOpen(true);
  };

  return (
    <Card className="p-4 space-y-3">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2 font-medium">
          <History className="h-4 w-4" /> Mentett illetmény-számítások
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {selected.length > 0 && (
            <Badge variant="secondary" className="font-mono text-[10px]">
              {selected.length}/2 kijelölve
            </Badge>
          )}
          <Button
            size="sm"
            variant={selected.length === 2 ? "default" : "outline"}
            disabled={selected.length !== 2}
            onClick={() => setDiffOpen(true)}
            className="h-8"
          >
            <GitCompareArrows className="h-3.5 w-3.5 mr-1" />
            Összehasonlítás
          </Button>
          {selected.length > 0 && (
            <Button size="sm" variant="ghost" onClick={() => setSelected([])} className="h-8">
              <X className="h-3 w-3" />
            </Button>
          )}
          <Badge variant="outline">
            {filtered.length} / {rows.length} snapshot
          </Badge>
        </div>
      </div>

      {/* === Dátum szűrő === */}
      {rows.length > 0 && (
        <div className="border rounded-md p-3 bg-muted/30 flex flex-wrap items-end gap-2 text-xs">
          <div className="flex items-center gap-1 text-muted-foreground font-medium pr-2">
            <Filter className="h-3.5 w-3.5" /> Verziók szűrése
          </div>
          <div className="space-y-1">
            <Label className="text-[10px]">Vonatkozás-tól</Label>
            <Input
              type="date"
              value={dateFrom}
              onChange={(e) => setDateFrom(e.target.value)}
              className="h-8 w-[140px]"
            />
          </div>
          <div className="space-y-1">
            <Label className="text-[10px]">Vonatkozás-ig</Label>
            <Input
              type="date"
              value={dateTo}
              onChange={(e) => setDateTo(e.target.value)}
              className="h-8 w-[140px]"
            />
          </div>
          {availableYears.length > 1 && (
            <div className="space-y-1">
              <Label className="text-[10px]">Év</Label>
              <select
                value={yearFilter}
                onChange={(e) => setYearFilter(e.target.value)}
                className="h-8 w-[100px] px-2 border rounded bg-background text-sm"
              >
                <option value="">Mind</option>
                {availableYears.map((y) => (
                  <option key={y} value={y}>
                    {y}
                  </option>
                ))}
              </select>
            </div>
          )}
          {hasFilter && (
            <Button size="sm" variant="ghost" onClick={clearFilters} className="h-8">
              <X className="h-3 w-3 mr-1" /> Szűrő törlése
            </Button>
          )}
        </div>
      )}

      {isLoading ? (
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Betöltés…
        </div>
      ) : rows.length === 0 ? (
        <div className="text-xs text-muted-foreground">
          Még nincs mentett snapshot. A kalkulátorban kattints a „Mentés snapshotként" gombra.
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-xs text-muted-foreground py-4 text-center border rounded-md">
          A megadott szűrőre nincs találat.
        </div>
      ) : (
        <div className="border rounded-md divide-y">
          {filtered.map((s) => {
            const isSelected = selected.includes(s.id);
            return (
            <div
              key={s.id}
              className={`p-3 flex items-center justify-between gap-2 flex-wrap ${
                isSelected ? "bg-primary/5" : ""
              }`}
            >
              <div className="min-w-0 flex-1 flex items-start gap-2">
                <Checkbox
                  checked={isSelected}
                  onCheckedChange={() => toggleSelect(s.id)}
                  aria-label={`v${s.version} kiválasztása diffhez`}
                  className="mt-1"
                />
                <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <Badge variant="secondary" className="font-mono text-[10px] shrink-0">
                    v{s.version}
                  </Badge>
                  <div className="font-medium truncate">{s.cimke}</div>
                </div>
                <div className="text-xs text-muted-foreground mt-0.5">
                  Mentve: {new Date(s.created_at).toLocaleString("hu-HU")} · vonatkozás:{" "}
                  <b>{s.vonatkozasi_datum}</b>
                </div>
                </div>
              </div>
              <div className="flex items-center gap-3 flex-wrap justify-end">
                <div className="text-right">
                  <div className="text-xs text-muted-foreground">Végösszeg</div>
                  <div className="font-bold">{fmt(Number(s.vegosszeg_ft) || 0)}</div>
                  {s.delta !== null && (
                    <div
                      className={`text-[11px] flex items-center justify-end gap-0.5 ${
                        s.delta > 0
                          ? "text-emerald-600 dark:text-emerald-400"
                          : s.delta < 0
                            ? "text-destructive"
                            : "text-muted-foreground"
                      }`}
                      title={`Eltérés v${s.version - 1}-hez képest`}
                    >
                      {s.delta > 0 ? (
                        <ArrowUpRight className="h-3 w-3" />
                      ) : s.delta < 0 ? (
                        <ArrowDownRight className="h-3 w-3" />
                      ) : (
                        <Minus className="h-3 w-3" />
                      )}
                      {fmtSigned(s.delta)}
                    </div>
                  )}
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => recompute.mutate(s)}
                  disabled={recompute.isPending}
                >
                  <RefreshCcw className="h-3 w-3 mr-1" /> Újraszámol
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => openDiffWithPrev(s.id)}
                  title="Összehasonlítás az előző verzióval"
                >
                  <GitCompareArrows className="h-3 w-3 mr-1" /> Diff
                </Button>
                {onLoad && (
                  <Button size="sm" variant="outline" onClick={() => onLoad((s.bemenet ?? {}) as any)}>
                    Betölt
                  </Button>
                )}
                <Button size="sm" variant="outline" onClick={() => reDownload(s)}>
                  <FileDown className="h-3 w-3 mr-1" /> PDF
                </Button>
                <Button size="icon" variant="ghost" onClick={() => del.mutate(s.id)}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
            );
          })}
        </div>
      )}

      <IlletmenyDiffDialog
        open={diffOpen}
        onOpenChange={setDiffOpen}
        older={olderSnap}
        newer={newerSnap}
      />
    </Card>
  );
}
