import { useEffect, useState, useCallback } from "react";
import { Loader2, History, RefreshCw } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";

export type AuditEntry = {
  id: string;
  created_at: string;
  user_id: string | null;
  action: string;
  table_name: string;
  record_id: string;
  before_data: Record<string, unknown> | null;
  after_data: Record<string, unknown> | null;
};

const ACTION_BADGE: Record<string, { label: string; cls: string }> = {
  INSERT: { label: "létrehozás", cls: "bg-success/15 text-success" },
  UPDATE: { label: "módosítás", cls: "bg-primary/15 text-primary" },
  DELETE: { label: "törlés", cls: "bg-destructive/15 text-destructive" },
  FORBIDDEN_WRITE_HR_NOTE: { label: "tiltott HR-írás", cls: "bg-destructive/25 text-destructive" },
  FORBIDDEN_APPROVAL: { label: "tiltott jóváhagyás", cls: "bg-destructive/25 text-destructive" },
};

function badgeFor(action: string) {
  return ACTION_BADGE[action] ?? { label: action.toLowerCase(), cls: "bg-secondary text-muted-foreground" };
}

function statusDiff(entry: AuditEntry): string | null {
  const before = entry.before_data?.["status"];
  const after = entry.after_data?.["status"];
  if (before === after) return null;
  if (before == null && after != null) return `→ ${String(after)}`;
  if (before != null && after == null) return `${String(before)} →`;
  return `${String(before)} → ${String(after)}`;
}

function hrNoteDiff(entry: AuditEntry): string | null {
  const beforeNote = (entry.before_data?.["hr_megjegyzes"] ?? null) as string | null;
  const afterNote = (entry.after_data?.["hr_megjegyzes"] ?? entry.after_data?.["attempted_hr_megjegyzes"] ?? null) as string | null;
  if (beforeNote === afterNote) return null;
  return `HR-megjegyzés: ${beforeNote ? "[korábbi]" : "(üres)"} → ${afterNote ? "[új]" : "(üres)"}`;
}

export function useRecordAudit(tableName: string, recordId: string | null) {
  const [rows, setRows] = useState<AuditEntry[]>([]);
  const [loading, setLoading] = useState(false);

  const load = useCallback(async () => {
    if (!recordId) return;
    setLoading(true);
    const { data } = await supabase
      .from("admin_audit_log")
      .select("id, created_at, user_id, action, table_name, record_id, before_data, after_data")
      .eq("table_name", tableName)
      .eq("record_id", recordId)
      .order("created_at", { ascending: false })
      .limit(50);
    setRows((data ?? []) as unknown as AuditEntry[]);
    setLoading(false);
  }, [tableName, recordId]);

  useEffect(() => {
    load();
  }, [load]);

  return { rows, loading, reload: load };
}

export function RecordHistory({ tableName, recordId }: { tableName: string; recordId: string }) {
  const { rows, loading, reload } = useRecordAudit(tableName, recordId);

  if (loading) {
    return (
      <div className="flex items-center gap-2 text-xs text-muted-foreground py-2">
        <Loader2 className="size-3 animate-spin" /> Előzmények betöltése…
      </div>
    );
  }
  if (rows.length === 0) {
    return <div className="text-xs text-muted-foreground py-2">Nincs audit-bejegyzés ehhez a rekordhoz.</div>;
  }

  return (
    <div className="space-y-1.5 py-2">
      <div className="flex items-center justify-between">
        <div className="text-[10px] font-mono uppercase text-muted-foreground flex items-center gap-1">
          <History className="size-3" /> Előzmények ({rows.length})
        </div>
        <button
          type="button"
          onClick={reload}
          className="text-[10px] text-muted-foreground hover:text-foreground inline-flex items-center gap-1"
        >
          <RefreshCw className="size-3" /> frissítés
        </button>
      </div>
      <ul className="space-y-1 max-h-60 overflow-auto pr-1">
        {rows.map((r) => {
          const b = badgeFor(r.action);
          const sd = statusDiff(r);
          const hd = hrNoteDiff(r);
          return (
            <li key={r.id} className="text-[11px] flex items-start gap-2 border border-border/60 rounded px-2 py-1 bg-background">
              <span className={cn("text-[9px] font-mono uppercase px-1.5 py-0.5 rounded", b.cls)}>{b.label}</span>
              <div className="flex-1 min-w-0">
                <div className="font-mono text-muted-foreground">
                  {new Date(r.created_at).toLocaleString("hu-HU")}
                </div>
                {sd && <div>állapot: <span className="font-mono">{sd}</span></div>}
                {hd && <div className="italic">{hd}</div>}
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

export function SchedulingActivityFeed({
  userId,
  tableNames,
}: {
  userId: string;
  tableNames: string[];
}) {
  const [rows, setRows] = useState<AuditEntry[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    // pull recent entries for the affected tables; user_id on the audit row is the actor,
    // and the record may belong to the current user OR be an action on the current user.
    // We filter to actions touching this user's records via user_id present in before/after_data.
    const { data } = await supabase
      .from("admin_audit_log")
      .select("id, created_at, user_id, action, table_name, record_id, before_data, after_data")
      .in("table_name", tableNames)
      .order("created_at", { ascending: false })
      .limit(100);
    const filtered = (data ?? []).filter((e) => {
      const ownerBefore = (e.before_data as Record<string, unknown> | null)?.["user_id"];
      const ownerAfter = (e.after_data as Record<string, unknown> | null)?.["user_id"];
      return ownerBefore === userId || ownerAfter === userId || e.user_id === userId;
    });
    setRows(filtered as unknown as AuditEntry[]);
    setLoading(false);
  }, [userId, tableNames]);

  useEffect(() => {
    load();
  }, [load]);

  if (loading) {
    return (
      <div className="flex items-center gap-2 text-sm text-muted-foreground p-4">
        <Loader2 className="size-4 animate-spin" /> Előzmények betöltése…
      </div>
    );
  }
  if (rows.length === 0) {
    return (
      <div className="p-6 rounded-lg border border-dashed border-border text-sm text-muted-foreground text-center">
        Még nincs naplózott esemény a beosztás-folyamatokhoz.
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Időrendi előzmények ({rows.length})
        </div>
        <button
          type="button"
          onClick={load}
          className="text-xs text-muted-foreground hover:text-foreground inline-flex items-center gap-1"
        >
          <RefreshCw className="size-3" /> Frissítés
        </button>
      </div>
      <ul className="rounded-lg border border-border bg-card divide-y divide-border">
        {rows.map((r) => {
          const b = badgeFor(r.action);
          const sd = statusDiff(r);
          const hd = hrNoteDiff(r);
          const tableLabel = r.table_name === "profile_unavailability" ? "Távollét" : "Korlátozó tényező";
          return (
            <li key={r.id} className="px-3 py-2 flex items-start gap-3 text-sm">
              <span className={cn("text-[10px] font-mono uppercase px-1.5 py-0.5 rounded shrink-0", b.cls)}>
                {b.label}
              </span>
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-xs">{tableLabel}</div>
                <div className="text-[11px] font-mono text-muted-foreground">
                  {new Date(r.created_at).toLocaleString("hu-HU")} · rekord: {r.record_id.slice(0, 8)}
                </div>
                {sd && (
                  <div className="text-xs">
                    állapot: <span className="font-mono">{sd}</span>
                  </div>
                )}
                {hd && <div className="text-xs italic">{hd}</div>}
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
