import { WifiOff } from "lucide-react";
import { useOnlineStatus } from "@/hooks/use-online-status";

/**
 * Diszkrét, fixen pozicionált jelző: offline módban mutatja,
 * hogy a felhasználó a mentett tartalmat látja.
 */
export function OfflineBadge() {
  const online = useOnlineStatus();
  if (online) return null;

  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed left-1/2 z-[90] flex -translate-x-1/2 items-center gap-2 rounded-full border border-border bg-background/95 px-3 py-1.5 text-xs font-medium text-foreground shadow-lg backdrop-blur"
      style={{
        bottom: "calc(env(safe-area-inset-bottom) + 12px)",
      }}
    >
      <WifiOff className="h-3.5 w-3.5 text-muted-foreground" aria-hidden="true" />
      <span>Offline mód — a mentett tartalom látszik</span>
    </div>
  );
}
