/**
 * Munkatárs publikus láthatóság kapcsoló – beilleszthető profil-oldalra.
 */
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { toast } from "sonner";
import { Eye, Loader2 } from "lucide-react";
import { getMyStaffVisibility, updateMyStaffVisibility } from "@/lib/cms/staff-public.functions";

const FIELDS: Array<{ key: string; label: string }> = [
  { key: "title", label: "Beosztás / titulus" },
  { key: "photo_url", label: "Fénykép" },
  { key: "bio", label: "Rövid bemutatkozás" },
  { key: "specialties", label: "Szakterületek" },
  { key: "languages", label: "Nyelvek" },
  { key: "publications", label: "Publikációk" },
  { key: "publish_schedule", label: "Rendelési idők" },
];

export function PublicVisibilityCard() {
  const qc = useQueryClient();
  const getFn = useServerFn(getMyStaffVisibility);
  const updFn = useServerFn(updateMyStaffVisibility);

  const q = useQuery({ queryKey: ["my-staff-vis"], queryFn: () => getFn() });

  const [pub, setPub] = useState(false);
  const [vis, setVis] = useState<"private" | "partial" | "full">("private");
  const [fields, setFields] = useState<Record<string, boolean>>({});

  useEffect(() => {
    if (q.data) {
      setPub(!!q.data.is_published);
      setVis((q.data.public_visibility ?? "private") as any);
      setFields((q.data.public_fields ?? {}) as Record<string, boolean>);
    }
  }, [q.data]);

  const save = useMutation({
    mutationFn: () => updFn({ data: { is_published: pub, public_visibility: vis, public_fields: fields } }),
    onSuccess: () => {
      toast.success("Beállítások mentve.");
      qc.invalidateQueries({ queryKey: ["my-staff-vis"] });
    },
    onError: (e: any) => toast.error(e?.message ?? "Hiba"),
  });

  if (q.isLoading) return <Card><CardContent className="p-6 text-sm text-muted-foreground">Betöltés…</CardContent></Card>;
  if (!q.data) {
    return (
      <Card>
        <CardContent className="p-6 text-sm text-muted-foreground">
          Még nincs hozzád rendelt CMS munkatárs-profil. Kérd egy adminisztrátortól, hogy hozza létre.
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <Eye className="size-4" /> Publikus megjelenés
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between gap-3">
          <Label htmlFor="pub" className="flex-1">
            <div className="font-medium">Megjelenjek a /munkatarsak listában</div>
            <div className="text-xs text-muted-foreground">Ki/be kapcsolja a publikus megjelenést.</div>
          </Label>
          <Switch id="pub" checked={pub} onCheckedChange={setPub} />
        </div>

        <div>
          <Label className="block mb-2">Mit jelenjen meg?</Label>
          <RadioGroup value={vis} onValueChange={(v) => setVis(v as any)} className="space-y-1.5">
            <Label className="flex items-center gap-2 cursor-pointer">
              <RadioGroupItem value="private" /> <span className="text-sm">Privát (csak admin lát)</span>
            </Label>
            <Label className="flex items-center gap-2 cursor-pointer">
              <RadioGroupItem value="partial" /> <span className="text-sm">Részleges (alább kijelölt mezők)</span>
            </Label>
            <Label className="flex items-center gap-2 cursor-pointer">
              <RadioGroupItem value="full" /> <span className="text-sm">Teljes (minden adat)</span>
            </Label>
          </RadioGroup>
        </div>

        {vis === "partial" && (
          <div className="space-y-2 pl-4 border-l-2 border-muted">
            <div className="text-xs text-muted-foreground">A neved mindig látszik.</div>
            {FIELDS.map((f) => (
              <Label key={f.key} className="flex items-center justify-between cursor-pointer">
                <span className="text-sm">{f.label}</span>
                <Switch
                  checked={!!fields[f.key]}
                  onCheckedChange={(v) => setFields((p) => ({ ...p, [f.key]: v }))}
                />
              </Label>
            ))}
          </div>
        )}

        <Button onClick={() => save.mutate()} disabled={save.isPending} className="w-full">
          {save.isPending && <Loader2 className="size-4 animate-spin mr-1" />}
          Mentés
        </Button>
      </CardContent>
    </Card>
  );
}
