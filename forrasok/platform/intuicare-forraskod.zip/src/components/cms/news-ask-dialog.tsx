import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MessageCircle, Send, Loader2 } from "lucide-react";
import { askNewsQuestion } from "@/lib/cms/news.functions";
import { toast } from "sonner";

type Msg = { role: "user" | "assistant"; content: string };

export function NewsAskDialog({ slug, title }: { slug: string; title: string }) {
  const ask = useServerFn(askNewsQuestion);
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const q = input.trim();
    if (!q || loading) return;
    const next: Msg[] = [...messages, { role: "user", content: q }];
    setMessages(next);
    setInput("");
    setLoading(true);
    try {
      const res = await ask({ data: { slug, question: q, history: messages } });
      setMessages([...next, { role: "assistant", content: res.reply }]);
    } catch (e: any) {
      toast.error(e?.message ?? "AI hiba");
      setMessages(next);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="min-h-11 gap-2">
          <MessageCircle className="h-4 w-4" /> Kérdezni szeretnék
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg flex flex-col h-[80vh] sm:h-[600px] p-0">
        <DialogHeader className="px-4 sm:px-6 pt-4 sm:pt-6 pb-2 border-b">
          <DialogTitle className="text-base sm:text-lg">Kérdés a cikkről</DialogTitle>
          <p className="text-xs text-muted-foreground line-clamp-1">{title}</p>
        </DialogHeader>
        <div className="flex-1 overflow-y-auto px-4 sm:px-6 py-3 space-y-3 text-sm">
          {messages.length === 0 && (
            <div className="text-muted-foreground text-center py-8">
              Kérdezz bármit a cikk tartalmáról — az asszisztens segít értelmezni.
              <p className="text-xs mt-2 italic">A válasz nem helyettesíti az orvosi konzultációt.</p>
            </div>
          )}
          {messages.map((m, i) => (
            <div key={i} className={m.role === "user" ? "text-right" : "text-left"}>
              <div className={`inline-block rounded-lg px-3 py-2 max-w-[85%] break-words ${m.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted"}`}>
                {m.content}
              </div>
            </div>
          ))}
          {loading && (
            <div className="text-left">
              <div className="inline-block rounded-lg px-3 py-2 bg-muted text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin inline" />
              </div>
            </div>
          )}
        </div>
        <form onSubmit={submit} className="flex gap-2 p-3 border-t pb-safe">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Írd be a kérdésed…"
            className="min-h-11"
            disabled={loading}
          />
          <Button type="submit" disabled={loading || !input.trim()} className="min-h-11" size="icon">
            <Send className="h-4 w-4" />
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
