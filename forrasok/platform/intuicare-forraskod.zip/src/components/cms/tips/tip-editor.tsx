/**
 * Tanács szerkesztő: metaadat-panel + nyelvi tabok + Tiptap.
 */
import { useEffect, useMemo, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Save, Loader2, Trash2, Sparkles, Wand2, Search, ImageIcon } from "lucide-react";
import { TiptapEditor } from "@/components/cms/tiptap-editor";
import { MediaPicker } from "@/components/cms/media-picker";
import { TipAiSourceDialog, type TipDraft } from "./tip-ai-source-dialog";
import { TipLanguageMatrix } from "./tip-language-matrix";
import { TipVersionsDrawer } from "./tip-versions-drawer";
import { SUPPORTED_LANGUAGES } from "@/i18n/languages";
import {
  adminGetTip, adminUpsertTip, adminUpsertTipTranslation, adminDeleteTip, adminPublishTip,
  listTipCategories, listTipTags, listTipAudiences,
} from "@/lib/cms/tips.functions";
import { aiImproveTipText, aiSuggestTipSeo } from "@/lib/cms/tips-ai.functions";

type Translation = {
  locale: string;
  title: string;
  lead: string;
  body_html: string;
  seo_title: string | null;
  seo_description: string | null;
  og_image: string | null;
  ai_generated: boolean;
  ai_source_lang: string | null;
  translation_status: "manual" | "ai" | "reviewed";
};

const emptyTr = (locale: string): Translation => ({
  locale, title: "", lead: "", body_html: "", seo_title: null,
  seo_description: null, og_image: null, ai_generated: false, ai_source_lang: null, translation_status: "manual",
});

interface Props {
  tipId: string | null; // null = new
  onClose: () => void;
}

export function TipEditor({ tipId, onClose }: Props) {
  const qc = useQueryClient();
  const getFn = useServerFn(adminGetTip);
  const upsertFn = useServerFn(adminUpsertTip);
  const upsertTrFn = useServerFn(adminUpsertTipTranslation);
  const deleteFn = useServerFn(adminDeleteTip);
  const publishFn = useServerFn(adminPublishTip);
  const improveFn = useServerFn(aiImproveTipText);
  const seoFn = useServerFn(aiSuggestTipSeo);

  const catsFn = useServerFn(listTipCategories);
  const tagsFn = useServerFn(listTipTags);
  const audsFn = useServerFn(listTipAudiences);
  const { data: cats = [] } = useQuery({ queryKey: ["tip-cats"], queryFn: () => catsFn() });
  const { data: tags = [] } = useQuery({ queryKey: ["tip-tags"], queryFn: () => tagsFn() });
  const { data: auds = [] } = useQuery({ queryKey: ["tip-auds"], queryFn: () => audsFn() });

  const { data: existing, isLoading } = useQuery({
    queryKey: ["cms-tip", tipId],
    queryFn: () => tipId ? getFn({ data: { id: tipId } }) : Promise.resolve(null),
    enabled: !!tipId,
  });

  const [meta, setMeta] = useState({
    slug: "",
    category_id: null as string | null,
    cover_url: "",
    status: "draft" as "draft" | "published" | "archived",
    featured: false,
    reading_minutes: 0,
    audience_ids: [] as string[],
    tag_ids: [] as string[],
  });
  const [trs, setTrs] = useState<Record<string, Translation>>({ hu: emptyTr("hu") });
  const [activeLocale, setActiveLocale] = useState("hu");
  const [saving, setSaving] = useState(false);
  const [savedAt, setSavedAt] = useState<number | null>(null);
  const [improveBusy, setImproveBusy] = useState(false);
  const [improveInstr, setImproveInstr] = useState("");

  useEffect(() => {
    if (!existing) return;
    const e: any = existing;
    setMeta({
      slug: e.slug ?? "",
      category_id: e.category_id ?? null,
      cover_url: e.cover_url ?? "",
      status: e.status ?? "draft",
      featured: !!e.featured,
      reading_minutes: e.reading_minutes ?? 0,
      audience_ids: (e.cms_tip_audience_map ?? []).map((m: any) => m.audience_id),
      tag_ids: (e.cms_tip_tag_map ?? []).map((m: any) => m.tag_id),
    });
    const map: Record<string, Translation> = {};
    for (const t of e.cms_tip_translations ?? []) {
      map[t.locale] = {
        locale: t.locale, title: t.title ?? "", lead: t.lead ?? "", body_html: t.body_html ?? "",
        seo_title: t.seo_title, seo_description: t.seo_description, og_image: t.og_image,
        ai_generated: !!t.ai_generated, ai_source_lang: t.ai_source_lang, translation_status: t.translation_status ?? "manual",
      };
    }
    if (!map.hu) map.hu = emptyTr("hu");
    setTrs(map);
  }, [existing]);

  const tr = trs[activeLocale] ?? emptyTr(activeLocale);
  const updateTr = (patch: Partial<Translation>) => {
    setTrs((prev) => ({ ...prev, [activeLocale]: { ...(prev[activeLocale] ?? emptyTr(activeLocale)), ...patch, locale: activeLocale } }));
  };

  const localizedName = (i18n: any) => (i18n?.[activeLocale] ?? i18n?.hu ?? Object.values(i18n ?? {})[0] ?? "—") as string;

  const slugify = (s: string) => s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "").slice(0, 80);

  const saveAll = async (opts?: { silent?: boolean }) => {
    if (!meta.slug.trim()) { toast.error("Slug kötelező"); return null; }
    setSaving(true);
    try {
      const { id } = await upsertFn({ data: meta as any });
      // upsert each non-empty translation
      for (const t of Object.values(trs)) {
        if (!t.title.trim() && !t.body_html.trim()) continue;
        await upsertTrFn({ data: { ...t, tip_id: id! } as any });
      }
      setSavedAt(Date.now());
      qc.invalidateQueries({ queryKey: ["cms-tips"] });
      qc.invalidateQueries({ queryKey: ["cms-tip", id] });
      if (!opts?.silent) toast.success("Mentve");
      return id;
    } catch (e: any) {
      toast.error(e?.message ?? "Mentési hiba");
      return null;
    } finally {
      setSaving(false);
    }
  };

  const remove = async () => {
    if (!tipId || !confirm("Tényleg törlöd ezt a tanácsot?")) return;
    try { await deleteFn({ data: { id: tipId } }); toast.success("Törölve"); qc.invalidateQueries({ queryKey: ["cms-tips"] }); onClose(); }
    catch (e: any) { toast.error(e?.message ?? "Hiba"); }
  };

  const togglePublish = async () => {
    if (!tipId) { toast.error("Először mentsd el"); return; }
    const publish = meta.status !== "published";
    try {
      await publishFn({ data: { id: tipId, publish } });
      setMeta((m) => ({ ...m, status: publish ? "published" : "draft" }));
      qc.invalidateQueries({ queryKey: ["cms-tips"] });
      toast.success(publish ? "Publikálva" : "Vázlatra állítva");
    } catch (e: any) { toast.error(e?.message ?? "Hiba"); }
  };

  const handleAiDraft = (d: TipDraft) => {
    updateTr({
      title: d.title ?? tr.title,
      lead: d.lead ?? tr.lead,
      body_html: d.body_html ?? tr.body_html,
      ai_generated: true,
      translation_status: "ai",
    });
    if (!meta.slug && d.suggested_slug) setMeta((m) => ({ ...m, slug: slugify(d.suggested_slug!) }));
    if (d.reading_minutes && !meta.reading_minutes) setMeta((m) => ({ ...m, reading_minutes: d.reading_minutes! }));
  };

  const runImprove = async () => {
    if (!improveInstr.trim() || !tr.body_html.trim()) return;
    setImproveBusy(true);
    try {
      const res = await improveFn({ data: { html: tr.body_html, instruction: improveInstr, locale: activeLocale } });
      updateTr({ body_html: res.html });
      toast.success("AI átírta");
    } catch (e: any) { toast.error(e?.message ?? "Hiba"); }
    finally { setImproveBusy(false); }
  };

  const runSeo = async () => {
    try {
      const r: any = await seoFn({ data: { title: tr.title, lead: tr.lead, body_html: tr.body_html, locale: activeLocale } });
      updateTr({ seo_title: r.seo_title ?? tr.seo_title, seo_description: r.seo_description ?? tr.seo_description });
      toast.success("SEO javasolva");
    } catch (e: any) { toast.error(e?.message ?? "Hiba"); }
  };

  if (tipId && isLoading) return <div className="p-6 text-center"><Loader2 className="size-6 animate-spin inline" /></div>;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[300px_1fr] gap-4">
      {/* META PANEL */}
      <Card>
        <CardContent className="p-3 space-y-3">
          <div>
            <Label className="text-xs">Slug *</Label>
            <Input value={meta.slug} onChange={(e) => setMeta((m) => ({ ...m, slug: slugify(e.target.value) }))} placeholder="taplálkozás-terhesseg-alatt" className="min-h-11" />
          </div>
          <div>
            <Label className="text-xs">Kategória</Label>
            <Select value={meta.category_id ?? ""} onValueChange={(v) => setMeta((m) => ({ ...m, category_id: v || null }))}>
              <SelectTrigger className="min-h-11"><SelectValue placeholder="—" /></SelectTrigger>
              <SelectContent>
                {(cats as any[]).map((c) => <SelectItem key={c.id} value={c.id}>{localizedName(c.name_i18n)}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">Borítókép URL</Label>
            <Input value={meta.cover_url} onChange={(e) => setMeta((m) => ({ ...m, cover_url: e.target.value }))} placeholder="https://..." className="min-h-11" />
            {meta.cover_url && <img src={meta.cover_url} alt="" className="mt-2 rounded w-full aspect-video object-cover" />}
          </div>
          <div>
            <Label className="text-xs">Olvasási idő (perc)</Label>
            <Input type="number" min={0} value={meta.reading_minutes} onChange={(e) => setMeta((m) => ({ ...m, reading_minutes: Number(e.target.value) || 0 }))} className="min-h-11" />
          </div>
          <div className="flex items-center justify-between gap-2">
            <Label className="text-xs">Kiemelt</Label>
            <Switch checked={meta.featured} onCheckedChange={(v) => setMeta((m) => ({ ...m, featured: v }))} />
          </div>
          <div>
            <Label className="text-xs">Célközönség</Label>
            <div className="flex flex-wrap gap-1 mt-1">
              {(auds as any[]).map((a) => {
                const on = meta.audience_ids.includes(a.id);
                return (
                  <Badge key={a.id} variant={on ? "default" : "outline"} className="cursor-pointer min-h-7" onClick={() =>
                    setMeta((m) => ({ ...m, audience_ids: on ? m.audience_ids.filter((x) => x !== a.id) : [...m.audience_ids, a.id] }))
                  }>
                    {localizedName(a.name_i18n)}
                  </Badge>
                );
              })}
            </div>
          </div>
          <div>
            <Label className="text-xs">Címkék</Label>
            <div className="flex flex-wrap gap-1 mt-1">
              {(tags as any[]).map((t) => {
                const on = meta.tag_ids.includes(t.id);
                return (
                  <Badge key={t.id} variant={on ? "default" : "outline"} className="cursor-pointer min-h-7" onClick={() =>
                    setMeta((m) => ({ ...m, tag_ids: on ? m.tag_ids.filter((x) => x !== t.id) : [...m.tag_ids, t.id] }))
                  }>{localizedName(t.name_i18n) || t.slug}</Badge>
                );
              })}
              {(tags as any[]).length === 0 && <p className="text-xs text-muted-foreground">Nincs címke. (Hozz létre a Címkék fülön.)</p>}
            </div>
          </div>
          <div className="pt-2 border-t space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs">Státusz:</span>
              <Badge variant={meta.status === "published" ? "default" : meta.status === "archived" ? "secondary" : "outline"}>{meta.status}</Badge>
            </div>
            <Button onClick={togglePublish} variant={meta.status === "published" ? "outline" : "default"} className="w-full min-h-11" disabled={!tipId}>
              {meta.status === "published" ? "Vázlatra állít" : "Publikálás"}
            </Button>
            {tipId && <TipVersionsDrawer tipId={tipId} />}
            {tipId && (
              <Button onClick={remove} variant="ghost" className="w-full text-destructive min-h-11 gap-2"><Trash2 className="size-4" />Törlés</Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* TRANSLATIONS PANEL */}
      <div className="space-y-3">
        {tipId && (
          <Card><CardContent className="p-3">
            <TipLanguageMatrix
              tipId={tipId}
              sourceLocale="hu"
              existing={Object.values(trs).filter((t) => t.title || t.body_html).map((t) => ({ locale: t.locale, translation_status: t.translation_status }))}
              onDone={() => qc.invalidateQueries({ queryKey: ["cms-tip", tipId] })}
            />
          </CardContent></Card>
        )}

        <Tabs value={activeLocale} onValueChange={setActiveLocale}>
          <div className="-mx-3 sm:mx-0 overflow-x-auto">
            <TabsList className="mx-3 sm:mx-0 inline-flex w-max">
              {SUPPORTED_LANGUAGES.map((l) => {
                const t = trs[l.code];
                const hasContent = !!(t?.title || t?.body_html);
                return (
                  <TabsTrigger key={l.code} value={l.code} className="min-h-11 gap-1">
                    <span>{l.flag}</span>
                    <span className="hidden sm:inline">{l.code.toUpperCase()}</span>
                    {hasContent && <span className={`w-1.5 h-1.5 rounded-full ${t?.translation_status === "ai" ? "bg-amber-500" : t?.translation_status === "reviewed" ? "bg-green-500" : "bg-primary"}`} />}
                  </TabsTrigger>
                );
              })}
            </TabsList>
          </div>

          <TabsContent value={activeLocale} className="space-y-3 mt-3">
            <div className="flex flex-wrap gap-2">
              <TipAiSourceDialog locale={activeLocale} onDraft={handleAiDraft} />
              <div className="flex items-center gap-1 flex-1 min-w-[200px]">
                <Input value={improveInstr} onChange={(e) => setImproveInstr(e.target.value)} placeholder="AI: 'tedd közérthetőbbé', 'rövidítsd 30%-kal'…" className="min-h-11" />
                <Button onClick={runImprove} disabled={improveBusy || !improveInstr || !tr.body_html} variant="outline" className="gap-1 min-h-11"><Wand2 className="size-4" />Javítsd</Button>
              </div>
              <Button onClick={runSeo} variant="outline" className="gap-1 min-h-11"><Search className="size-4" />AI SEO</Button>
            </div>

            <div>
              <Label className="text-xs">Cím *</Label>
              <Input value={tr.title} onChange={(e) => updateTr({ title: e.target.value })} className="min-h-11 text-lg" />
            </div>
            <div>
              <Label className="text-xs">Lead (1-2 mondat)</Label>
              <Textarea value={tr.lead ?? ""} onChange={(e) => updateTr({ lead: e.target.value })} rows={2} />
            </div>
            <div>
              <Label className="text-xs">Tartalom</Label>
              <TiptapEditor value={tr.body_html} onChange={(html) => updateTr({ body_html: html })} placeholder="Írj egy tanácsot…" />
            </div>

            <Accordion type="single" collapsible>
              <AccordionItem value="seo">
                <AccordionTrigger className="text-sm">SEO ({activeLocale.toUpperCase()})</AccordionTrigger>
                <AccordionContent className="space-y-3">
                  <div>
                    <Label className="text-xs">SEO Cím <span className="text-muted-foreground">({(tr.seo_title ?? "").length}/60)</span></Label>
                    <Input value={tr.seo_title ?? ""} onChange={(e) => updateTr({ seo_title: e.target.value })} maxLength={70} className="min-h-11" />
                    <p className="text-[11px] text-muted-foreground mt-1">Ha üres: „{tr.title || "(cím)"}"</p>
                  </div>
                  <div>
                    <Label className="text-xs">SEO Leírás <span className="text-muted-foreground">({(tr.seo_description ?? "").length}/160)</span></Label>
                    <Textarea value={tr.seo_description ?? ""} onChange={(e) => updateTr({ seo_description: e.target.value })} maxLength={180} rows={2} />
                    <p className="text-[11px] text-muted-foreground mt-1">Ha üres: a lead első ~155 karaktere.</p>
                  </div>
                  <div>
                    <Label className="text-xs">OG kép URL (megosztási preview)</Label>
                    <div className="flex gap-2">
                      <Input value={tr.og_image ?? ""} onChange={(e) => updateTr({ og_image: e.target.value })} placeholder="https://…" className="min-h-11" inputMode="url" autoCapitalize="none" />
                      <MediaPicker
                        trigger={<Button type="button" variant="outline" size="icon" className="min-h-11" title="Médiatárból"><ImageIcon className="h-4 w-4" /></Button>}
                        onSelect={(m) => updateTr({ og_image: m.url })}
                      />
                    </div>
                    <p className="text-[11px] text-muted-foreground mt-1">Ha üres: a borítókép → alapértelmezett site OG kép.</p>
                  </div>
                </AccordionContent>
              </AccordionItem>
            </Accordion>

            {tr.ai_generated && (
              <Badge variant="secondary" className="gap-1"><Sparkles className="size-3" />AI generált — kérlek lektoráld</Badge>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* sticky save bar */}
      <div className="lg:col-span-2 sticky bottom-0 -mx-3 sm:mx-0 bg-background border-t pt-3 pb-safe flex items-center justify-between gap-2 px-3 sm:px-0">
        <div className="text-xs text-muted-foreground">
          {saving ? "Mentés…" : savedAt ? `Mentve ${Math.round((Date.now() - savedAt) / 1000)} mp-e` : ""}
        </div>
        <div className="flex gap-2">
          <Button variant="ghost" onClick={onClose} className="min-h-11">Bezár</Button>
          <Button onClick={() => saveAll()} disabled={saving} className="gap-2 min-h-11">
            {saving ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
            Mentés
          </Button>
        </div>
      </div>
    </div>
  );
}
