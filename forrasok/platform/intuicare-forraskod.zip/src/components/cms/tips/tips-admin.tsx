/**
 * Tanácsok admin lista + taxonómia-kezelés.
 */
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Search, Pencil, Trash2, Star } from "lucide-react";
import { CardGridSkeleton } from "@/components/ui/list-skeletons";
import { TipEditor } from "./tip-editor";
import {
  adminListTips, listTipCategories, listTipTags, listTipAudiences,
  adminUpsertTipCategory, adminDeleteTipCategory,
  adminUpsertTipTag, adminDeleteTipTag,
  adminUpsertTipAudience, adminDeleteTipAudience,
} from "@/lib/cms/tips.functions";
import { SUPPORTED_LANGUAGES } from "@/i18n/languages";

export function TipsAdmin() {
  const [tab, setTab] = useState("list");
  return (
    <div className="space-y-4">
      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="list" className="min-h-11">Tanácsok</TabsTrigger>
          <TabsTrigger value="categories" className="min-h-11">Kategóriák</TabsTrigger>
          <TabsTrigger value="tags" className="min-h-11">Címkék</TabsTrigger>
          <TabsTrigger value="audiences" className="min-h-11">Célközönség</TabsTrigger>
        </TabsList>
        <TabsContent value="list"><TipsList /></TabsContent>
        <TabsContent value="categories"><TaxAdmin kind="category" /></TabsContent>
        <TabsContent value="tags"><TaxAdmin kind="tag" /></TabsContent>
        <TabsContent value="audiences"><TaxAdmin kind="audience" /></TabsContent>
      </Tabs>
    </div>
  );
}

function TipsList() {
  const listFn = useServerFn(adminListTips);
  const [search, setSearch] = useState("");
  const [openId, setOpenId] = useState<string | null | undefined>(undefined); // undefined=closed, null=new
  const { data: rows = [], isLoading } = useQuery({
    queryKey: ["cms-tips", search],
    queryFn: () => listFn({ data: { search: search || undefined } }),
  });

  return (
    <>
      <div className="flex flex-wrap gap-2 mb-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="size-4 absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Keresés cím/slug…" className="pl-8 min-h-11" />
        </div>
        <Button onClick={() => setOpenId(null)} className="gap-2 min-h-11"><Plus className="size-4" />Új tanács</Button>
      </div>

      {isLoading ? <CardGridSkeleton cards={6} /> : (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {(rows as any[]).map((r) => {
          const huTr = (r.cms_tip_translations ?? []).find((t: any) => t.locale === "hu");
          const title = huTr?.title || r.slug;
          const cats = r.cms_tip_categories?.name_i18n?.hu ?? r.cms_tip_categories?.slug ?? null;
          return (
            <Card key={r.id} className="cursor-pointer hover:border-primary transition" onClick={() => setOpenId(r.id)}>
              <CardContent className="p-3">
                {r.cover_url && <img src={r.cover_url} alt="" className="rounded w-full aspect-video object-cover mb-2" />}
                <div className="flex items-start gap-2">
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate flex items-center gap-1">{r.featured && <Star className="size-3 fill-amber-500 text-amber-500" />}{title}</p>
                    <p className="text-xs text-muted-foreground truncate">/{r.slug}</p>
                  </div>
                  <Badge variant={r.status === "published" ? "default" : r.status === "archived" ? "secondary" : "outline"} className="shrink-0">{r.status}</Badge>
                </div>
                <div className="flex flex-wrap gap-1 mt-2">
                  {cats && <Badge variant="outline" className="text-[10px]">{cats}</Badge>}
                  {SUPPORTED_LANGUAGES.map((l) => {
                    const t = (r.cms_tip_translations ?? []).find((x: any) => x.locale === l.code);
                    if (!t) return null;
                    return <span key={l.code} title={`${l.label} · ${t.translation_status}`} className={`text-[10px] ${t.translation_status === "ai" ? "opacity-60" : ""}`}>{l.flag}</span>;
                  })}
                </div>
              </CardContent>
            </Card>
          );
        })}
        {(rows as any[]).length === 0 && <p className="text-sm text-muted-foreground col-span-full">Még nincs tanács. Kattints az „Új tanács" gombra.</p>}
      </div>
      )}

      <Dialog open={openId !== undefined} onOpenChange={(o) => { if (!o) setOpenId(undefined); }}>
        <DialogContent className="max-w-6xl max-h-[95vh] overflow-y-auto p-3 sm:p-6">
          <DialogHeader><DialogTitle>{openId ? "Tanács szerkesztése" : "Új tanács"}</DialogTitle></DialogHeader>
          {openId !== undefined && <TipEditor tipId={openId} onClose={() => setOpenId(undefined)} />}
        </DialogContent>
      </Dialog>
    </>
  );
}

function TaxAdmin({ kind }: { kind: "category" | "tag" | "audience" }) {
  const qc = useQueryClient();
  const listMap = { category: listTipCategories, tag: listTipTags, audience: listTipAudiences };
  const upsertMap = { category: adminUpsertTipCategory, tag: adminUpsertTipTag, audience: adminUpsertTipAudience };
  const deleteMap = { category: adminDeleteTipCategory, tag: adminDeleteTipTag, audience: adminDeleteTipAudience };
  const queryKey = `tip-${kind}s`;

  const listFn = useServerFn(listMap[kind]);
  const upsertFn = useServerFn(upsertMap[kind]);
  const deleteFn = useServerFn(deleteMap[kind]);

  const { data: rows = [] } = useQuery({ queryKey: [queryKey], queryFn: () => listFn() });
  const [editing, setEditing] = useState<any | null>(null);

  const save = async () => {
    if (!editing?.slug) return;
    try {
      await upsertFn({ data: editing });
      qc.invalidateQueries({ queryKey: [queryKey] });
      qc.invalidateQueries({ queryKey: ["tip-cats"] });
      qc.invalidateQueries({ queryKey: ["tip-tags"] });
      qc.invalidateQueries({ queryKey: ["tip-auds"] });
      toast.success("Mentve");
      setEditing(null);
    } catch (e: any) { toast.error(e?.message ?? "Hiba"); }
  };
  const remove = async (id: string) => {
    if (!confirm("Törlöd?")) return;
    try { await deleteFn({ data: { id } }); qc.invalidateQueries({ queryKey: [queryKey] }); toast.success("Törölve"); }
    catch (e: any) { toast.error(e?.message ?? "Hiba"); }
  };

  return (
    <div className="space-y-3">
      <Button onClick={() => setEditing({ slug: "", name_i18n: { hu: "", en: "" }, sort_order: 0 })} className="gap-2 min-h-11"><Plus className="size-4" />Új</Button>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
        {(rows as any[]).map((r) => (
          <Card key={r.id}><CardContent className="p-3 flex items-center gap-2">
            <div className="flex-1 min-w-0">
              <p className="font-medium truncate">{r.name_i18n?.hu ?? r.slug}</p>
              <p className="text-xs text-muted-foreground truncate">/{r.slug}</p>
            </div>
            <Button size="sm" variant="ghost" onClick={() => setEditing(r)}><Pencil className="size-4" /></Button>
            <Button size="sm" variant="ghost" onClick={() => remove(r.id)} className="text-destructive"><Trash2 className="size-4" /></Button>
          </CardContent></Card>
        ))}
      </div>

      <Dialog open={!!editing} onOpenChange={(o) => { if (!o) setEditing(null); }}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editing?.id ? "Szerkesztés" : "Új"}</DialogTitle></DialogHeader>
          {editing && (
            <div className="space-y-2">
              <div><label className="text-xs">Slug</label><Input value={editing.slug} onChange={(e) => setEditing({ ...editing, slug: e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, "-") })} className="min-h-11" /></div>
              {SUPPORTED_LANGUAGES.map((l) => (
                <div key={l.code}>
                  <label className="text-xs">{l.flag} Név ({l.code.toUpperCase()})</label>
                  <Input value={editing.name_i18n?.[l.code] ?? ""} onChange={(e) => setEditing({ ...editing, name_i18n: { ...(editing.name_i18n ?? {}), [l.code]: e.target.value } })} className="min-h-11" />
                </div>
              ))}
              <div><label className="text-xs">Sorrend</label><Input type="number" value={editing.sort_order ?? 0} onChange={(e) => setEditing({ ...editing, sort_order: Number(e.target.value) || 0 })} className="min-h-11" /></div>
              <Button onClick={save} className="w-full min-h-11">Mentés</Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
