/**
 * Fordítás-mátrix és batch AI fordítás minden hiányzó nyelvre.
 */
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Languages, Loader2 } from "lucide-react";
import { SUPPORTED_LANGUAGES } from "@/i18n/languages";
import { aiTranslateTipToLocale } from "@/lib/cms/tips-ai.functions";

interface Props {
  tipId: string;
  sourceLocale: string;
  existing: Array<{ locale: string; translation_status: string }>;
  onDone: () => void;
}

export function TipLanguageMatrix({ tipId, sourceLocale, existing, onDone }: Props) {
  const fn = useServerFn(aiTranslateTipToLocale);
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState<string | null>(null);

  const byLocale = new Map(existing.map((t) => [t.locale, t]));
  const missing = SUPPORTED_LANGUAGES.filter((l) => l.code !== sourceLocale && !byLocale.has(l.code));

  const translateAll = async () => {
    if (!missing.length) {
      toast.info("Minden nyelv le van fordítva.");
      return;
    }
    setBusy(true);
    let done = 0;
    for (const lng of missing) {
      setProgress(`${lng.flag} ${lng.label} (${done + 1}/${missing.length})`);
      try {
        await fn({ data: { tip_id: tipId, source_locale: sourceLocale, target_locale: lng.code } });
        done++;
      } catch (e: any) {
        toast.error(`${lng.label}: ${e?.message ?? "hiba"}`);
      }
    }
    setBusy(false);
    setProgress(null);
    toast.success(`Lefordítva ${done}/${missing.length} nyelvre`);
    onDone();
  };

  return (
    <div className="space-y-2">
      <div className="flex flex-wrap gap-1.5">
        {SUPPORTED_LANGUAGES.map((l) => {
          const t = byLocale.get(l.code);
          const variant = !t ? "outline" : t.translation_status === "ai" ? "secondary" : t.translation_status === "reviewed" ? "default" : "default";
          return (
            <Badge key={l.code} variant={variant as any} className="gap-1">
              <span>{l.flag}</span>
              <span>{l.code.toUpperCase()}</span>
              {t && <span className="text-[10px] opacity-70">·{t.translation_status === "ai" ? "AI" : t.translation_status === "reviewed" ? "✓" : "kézi"}</span>}
            </Badge>
          );
        })}
      </div>
      <div className="flex gap-2 items-center">
        <Button onClick={translateAll} disabled={busy || !missing.length} variant="outline" size="sm" className="gap-2 min-h-11">
          {busy ? <Loader2 className="size-4 animate-spin" /> : <Languages className="size-4" />}
          AI fordítás minden hiányzó nyelvre ({missing.length})
        </Button>
        {progress && <span className="text-xs text-muted-foreground">{progress}</span>}
      </div>
    </div>
  );
}
