/**
 * Verzió-historia drawer Tanácsokhoz. Újrahasználja a VersionDiffDialog-ot
 * két snapshot összehasonlítására.
 */
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { History, RotateCcw, GitCompare, Loader2 } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { adminListTipVersions, adminRestoreTipVersion } from "@/lib/cms/tips.functions";
import { VersionDiffDialog } from "@/components/cms/version-diff-dialog";

interface Props { tipId: string; }

export function TipVersionsDrawer({ tipId }: Props) {
  const qc = useQueryClient();
  const listFn = useServerFn(adminListTipVersions);
  const restoreFn = useServerFn(adminRestoreTipVersion);
  const [open, setOpen] = useState(false);
  const [selA, setSelA] = useState<string | null>(null);
  const [selB, setSelB] = useState<string | null>(null);
  const [diffOpen, setDiffOpen] = useState(false);
  const [restoring, setRestoring] = useState<string | null>(null);

  const { data: rows = [] } = useQuery({
    queryKey: ["cms-tip-versions", tipId],
    queryFn: () => listFn({ data: { tip_id: tipId } }),
    enabled: open,
  });

  const toggleSel = (id: string) => {
    if (selA === id) { setSelA(null); return; }
    if (selB === id) { setSelB(null); return; }
    if (!selA) setSelA(id);
    else if (!selB) setSelB(id);
    else { setSelB(selA); setSelA(id); }
  };

  const rowA = (rows as any[]).find((r) => r.id === selA);
  const rowB = (rows as any[]).find((r) => r.id === selB);

  const restore = async (id: string) => {
    if (!confirm("Visszaállítod erre a verzióra? Az aktuális állapot új verziókónt mentésre kerül.")) return;
    setRestoring(id);
    try {
      await restoreFn({ data: { version_id: id } });
      toast.success("Visszaállítva");
      qc.invalidateQueries({ queryKey: ["cms-tip-versions", tipId] });
      qc.invalidateQueries({ queryKey: ["cms-tip", tipId] });
    } catch (e: any) {
      toast.error(e?.message ?? "Hiba");
    } finally { setRestoring(null); }
  };

  return (
    <>
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetTrigger asChild>
          <Button variant="outline" size="sm" className="gap-2 min-h-11"><History className="size-4" />Verziók</Button>
        </SheetTrigger>
        <SheetContent className="w-full sm:max-w-md overflow-y-auto">
          <SheetHeader><SheetTitle>Verziótörténet</SheetTitle></SheetHeader>
          <div className="mt-4 space-y-2">
            {selA && selB && (
              <div className="flex items-center justify-between gap-2 p-2 bg-muted rounded">
                <span className="text-xs">A: v{rowA?.version} · B: v{rowB?.version}</span>
                <div className="flex gap-1">
                  <Button size="sm" variant="outline" onClick={() => setDiffOpen(true)} className="gap-1"><GitCompare className="size-3" />Diff</Button>
                  <Button size="sm" variant="ghost" onClick={() => { setSelA(null); setSelB(null); }}>Töröl</Button>
                </div>
              </div>
            )}
            {(rows as any[]).length === 0 && <p className="text-sm text-muted-foreground">Még nincs verzió.</p>}
            {(rows as any[]).map((r) => (
              <div key={r.id} className="border rounded p-2 flex items-start gap-2">
                <Checkbox checked={selA === r.id || selB === r.id} onCheckedChange={() => toggleSel(r.id)} className="mt-1" />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <Badge>v{r.version}</Badge>
                    {r.note && <span className="text-xs text-muted-foreground truncate">{r.note}</span>}
                  </div>
                  <p className="text-[11px] text-muted-foreground mt-1">{new Date(r.created_at).toLocaleString("hu-HU")}</p>
                </div>
                <Button size="sm" variant="ghost" onClick={() => restore(r.id)} disabled={!!restoring} title="Visszaállítás" className="shrink-0">
                  {restoring === r.id ? <Loader2 className="size-3 animate-spin" /> : <RotateCcw className="size-3" />}
                </Button>
              </div>
            ))}
          </div>
        </SheetContent>
      </Sheet>
      <VersionDiffDialog
        open={diffOpen}
        onOpenChange={setDiffOpen}
        a={rowA?.snapshot ?? null}
        b={rowB?.snapshot ?? null}
        labelA={rowA ? `v${rowA.version}` : "A"}
        labelB={rowB ? `v${rowB.version}` : "B"}
      />
    </>
  );
}
