/**
 * AI forrás-dialógus: szöveg / hang / dokumentum -> draft tanács.
 */
import { useState, useRef } from "react";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Sparkles, Mic, FileText, Loader2, Square } from "lucide-react";
import { aiDraftTipFromText, aiDraftTipFromAudio, aiDraftTipFromDocument } from "@/lib/cms/tips-ai.functions";

export type TipDraft = {
  title?: string;
  lead?: string;
  body_html?: string;
  suggested_slug?: string;
  suggested_tags?: string[];
  reading_minutes?: number;
};

interface Props {
  locale?: string;
  onDraft: (draft: TipDraft) => void;
  trigger?: React.ReactNode;
}

export function TipAiSourceDialog({ locale = "hu", onDraft, trigger }: Props) {
  const [open, setOpen] = useState(false);
  const [tab, setTab] = useState("text");
  const [busy, setBusy] = useState(false);
  const [text, setText] = useState("");
  const [audience, setAudience] = useState("");

  // audio
  const [recording, setRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const mediaRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  // document
  const [file, setFile] = useState<File | null>(null);

  const fnText = useServerFn(aiDraftTipFromText);
  const fnAudio = useServerFn(aiDraftTipFromAudio);
  const fnDoc = useServerFn(aiDraftTipFromDocument);

  const startRec = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const rec = new MediaRecorder(stream);
      chunksRef.current = [];
      rec.ondataavailable = (e) => { if (e.data.size > 0) chunksRef.current.push(e.data); };
      rec.onstop = () => {
        const b = new Blob(chunksRef.current, { type: rec.mimeType || "audio/webm" });
        setAudioBlob(b);
        stream.getTracks().forEach((t) => t.stop());
      };
      rec.start();
      mediaRef.current = rec;
      setRecording(true);
    } catch (e: any) {
      toast.error("Mikrofon nem elérhető: " + (e?.message ?? e));
    }
  };
  const stopRec = () => { mediaRef.current?.stop(); setRecording(false); };

  const fileToBase64 = (f: File | Blob): Promise<string> => new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => {
      const s = String(r.result ?? "");
      resolve(s.split(",")[1] ?? "");
    };
    r.onerror = reject;
    r.readAsDataURL(f);
  });

  const run = async () => {
    setBusy(true);
    try {
      let draft: TipDraft;
      if (tab === "text") {
        if (text.trim().length < 20) throw new Error("Adj meg legalább 20 karakteres forrást.");
        draft = await fnText({ data: { source_text: text, locale, audience: audience || undefined } });
      } else if (tab === "audio") {
        if (!audioBlob) throw new Error("Vegyél fel vagy tölts fel egy hangfelvételt.");
        const b64 = await fileToBase64(audioBlob);
        const fmt = audioBlob.type.includes("mp4") ? "m4a" : audioBlob.type.includes("mp3") ? "mp3" : audioBlob.type.includes("wav") ? "wav" : "webm";
        draft = await fnAudio({ data: { audio_base64: b64, format: fmt as any, locale, audience: audience || undefined } });
      } else {
        if (!file) throw new Error("Válassz egy fájlt (PDF/DOCX/MD).");
        const b64 = await fileToBase64(file);
        draft = await fnDoc({ data: { file_base64: b64, mime: file.type || "application/pdf", filename: file.name, locale, audience: audience || undefined } });
      }
      onDraft(draft);
      toast.success("AI vázlat elkészült");
      setOpen(false);
      setText(""); setAudioBlob(null); setFile(null);
    } catch (e: any) {
      toast.error(e?.message ?? "AI hiba");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger ?? <Button variant="outline" className="gap-2 min-h-11"><Sparkles className="size-4" />AI vázlat</Button>}
      </DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader><DialogTitle>AI tartalom-vázlat ({locale.toUpperCase()})</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div>
            <Label className="text-xs">Célközönség (opcionális)</Label>
            <Input value={audience} onChange={(e) => setAudience(e.target.value)} placeholder="pl. várandós, idős, cukorbeteg" className="min-h-11" />
          </div>
          <Tabs value={tab} onValueChange={setTab}>
            <TabsList className="w-full">
              <TabsTrigger value="text" className="flex-1 min-h-11"><FileText className="size-4 mr-1" />Szöveg</TabsTrigger>
              <TabsTrigger value="audio" className="flex-1 min-h-11"><Mic className="size-4 mr-1" />Hang</TabsTrigger>
              <TabsTrigger value="document" className="flex-1 min-h-11"><FileText className="size-4 mr-1" />Dokumentum</TabsTrigger>
            </TabsList>
            <TabsContent value="text" className="space-y-2 pt-3">
              <Textarea value={text} onChange={(e) => setText(e.target.value)} rows={10} placeholder="Vázlat, jegyzetek, kutatási anyag, link kivonat..." />
              <p className="text-xs text-muted-foreground">{text.length} karakter</p>
            </TabsContent>
            <TabsContent value="audio" className="space-y-2 pt-3">
              <div className="flex flex-wrap gap-2 items-center">
                {!recording ? (
                  <Button onClick={startRec} variant="outline" className="gap-2 min-h-11"><Mic className="size-4" />Felvétel indítása</Button>
                ) : (
                  <Button onClick={stopRec} variant="destructive" className="gap-2 min-h-11"><Square className="size-4" />Felvétel leállítása</Button>
                )}
                <span className="text-sm text-muted-foreground">vagy</span>
                <Input type="file" accept="audio/*" onChange={(e) => setAudioBlob(e.target.files?.[0] ?? null)} className="max-w-xs" />
              </div>
              {audioBlob && (
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">{Math.round(audioBlob.size / 1024)} kB • {audioBlob.type}</p>
                  <audio src={URL.createObjectURL(audioBlob)} controls className="w-full" />
                </div>
              )}
            </TabsContent>
            <TabsContent value="document" className="space-y-2 pt-3">
              <Input type="file" accept=".pdf,.docx,.md,.txt,application/pdf" onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
              {file && <p className="text-xs text-muted-foreground">{file.name} • {Math.round(file.size / 1024)} kB</p>}
              <p className="text-xs text-muted-foreground">PDF, DOCX, MD vagy TXT.</p>
            </TabsContent>
          </Tabs>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => setOpen(false)} disabled={busy} className="min-h-11">Mégse</Button>
          <Button onClick={run} disabled={busy} className="gap-2 min-h-11">
            {busy ? <Loader2 className="size-4 animate-spin" /> : <Sparkles className="size-4" />}
            Generálás
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
