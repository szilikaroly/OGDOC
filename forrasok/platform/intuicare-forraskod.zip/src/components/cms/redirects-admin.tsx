import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { listRedirects, saveRedirect, deleteRedirect } from "@/lib/cms/cms.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Plus, Trash2, Pencil, Search, ArrowRight } from "lucide-react";
import { toast } from "sonner";
import { ListSkeleton } from "@/components/ui/list-skeletons";
import { haptic } from "@/lib/query/optimistic";

export function RedirectsAdmin() {
  const qc = useQueryClient();
  const listFn = useServerFn(listRedirects);
  const saveFn = useServerFn(saveRedirect);
  const delFn = useServerFn(deleteRedirect);
  const { data: items = [], isLoading } = useQuery({ queryKey: ["cms-redirects"], queryFn: () => listFn() });
  const [editing, setEditing] = useState<any>(null);
  const [search, setSearch] = useState("");

  const newItem = () => setEditing({ source_path: "", target_path: "", status_code: 301, is_active: true });

  const save = async (r: any) => {
    try {
      await saveFn({ data: r });
      setEditing(null);
      qc.invalidateQueries({ queryKey: ["cms-redirects"] });
      toast.success("Mentve");
    } catch (e: any) { toast.error(e.message); }
  };

  const remove = async (id: string) => {
    if (!confirm("Törlöd?")) return;
    try {
      await delFn({ data: { id } });
      qc.invalidateQueries({ queryKey: ["cms-redirects"] });
      toast.success("Törölve");
    } catch (e: any) { toast.error(e.message); }
  };

  const filtered = (items as any[]).filter(r =>
    !search.trim() ||
    r.source_path?.toLowerCase().includes(search.toLowerCase()) ||
    r.target_path?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-3 mt-4">
      <p className="text-sm text-muted-foreground">Régi → új URL átirányítások (a régi SZTE oldal linkjeihez).</p>
      <div className="grid grid-cols-[minmax(0,1fr)_auto] sm:flex items-center gap-2">
        <div className="relative min-w-0">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
          <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Keresés útvonalban…" className="pl-8 min-h-11" inputMode="search" />
        </div>
        <Button onClick={() => { haptic(8); newItem(); }} className="min-h-11 shrink-0" aria-label="Új átirányítás">
          <Plus className="h-4 w-4 sm:mr-1" /><span className="hidden sm:inline">Új átirányítás</span>
        </Button>
      </div>

      {isLoading ? <ListSkeleton rows={5} /> : (
        <div className="space-y-2" style={{ contentVisibility: "auto" as any, containIntrinsicSize: "600px" as any }}>
          {filtered.map((r: any) => (
            <Card key={r.id} className="p-3 grid grid-cols-[minmax(0,1fr)_auto] items-center gap-2">
              <div className="min-w-0">
                <div className="font-mono text-sm truncate flex items-center gap-1.5">
                  <span className="truncate">{r.source_path}</span>
                  <ArrowRight className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                  <span className="truncate text-muted-foreground">{r.target_path}</span>
                </div>
                <div className="flex flex-wrap gap-1 mt-1">
                  <Badge variant="outline" className="text-[10px]">{r.status_code}</Badge>
                  <Badge variant={r.is_active ? "default" : "secondary"} className="text-[10px]">{r.is_active ? "aktív" : "inaktív"}</Badge>
                  {r.note && <span className="text-[10px] text-muted-foreground self-center">· {r.note}</span>}
                </div>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                <Button size="icon" variant="ghost" className="min-h-11 min-w-11" onClick={() => setEditing(r)} aria-label="Szerkeszt"><Pencil className="h-4 w-4" /></Button>
                <Button size="icon" variant="ghost" className="min-h-11 min-w-11" onClick={() => remove(r.id)} aria-label="Törlés"><Trash2 className="h-4 w-4 text-destructive" /></Button>
              </div>
            </Card>
          ))}
          {!filtered.length && <div className="text-sm text-muted-foreground p-4 text-center">Nincs átirányítás.</div>}
        </div>
      )}

      {editing && (
        <Dialog open onOpenChange={() => setEditing(null)}>
          <DialogContent className="max-h-[92vh] overflow-y-auto">
            <DialogHeader><DialogTitle>Átirányítás</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div><Label>Forrás útvonal</Label><Input className="min-h-11" value={editing.source_path} onChange={e => setEditing({ ...editing, source_path: e.target.value })} placeholder="/egyeb-info" inputMode="url" autoCapitalize="none" /></div>
              <div><Label>Cél útvonal</Label><Input className="min-h-11" value={editing.target_path} onChange={e => setEditing({ ...editing, target_path: e.target.value })} placeholder="/o/egyeb-info" inputMode="url" autoCapitalize="none" /></div>
              <div>
                <Label>HTTP státuszkód</Label>
                <Select value={String(editing.status_code)} onValueChange={v => setEditing({ ...editing, status_code: parseInt(v) })}>
                  <SelectTrigger className="min-h-11"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="301">301 (állandó)</SelectItem>
                    <SelectItem value="302">302 (ideiglenes)</SelectItem>
                    <SelectItem value="307">307</SelectItem>
                    <SelectItem value="308">308</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div><Label>Megjegyzés</Label><Input className="min-h-11" value={editing.note ?? ""} onChange={e => setEditing({ ...editing, note: e.target.value })} /></div>
              <div className="flex items-center gap-2"><Switch checked={editing.is_active} onCheckedChange={v => setEditing({ ...editing, is_active: v })} /><Label>Aktív</Label></div>
            </div>
            <DialogFooter className="flex-col-reverse sm:flex-row gap-2">
              <Button variant="ghost" className="min-h-11 w-full sm:w-auto" onClick={() => setEditing(null)}>Mégse</Button>
              <Button className="min-h-11 w-full sm:w-auto" onClick={() => { haptic(8); save(editing); }}>Mentés</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
