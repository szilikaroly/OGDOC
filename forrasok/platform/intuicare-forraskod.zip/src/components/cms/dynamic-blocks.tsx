/**
 * CMS Dinamikus blokkok – publikus oldalra renderelve élő adatokkal.
 * Híd a meglévő modulokhoz: beosztás, foglalás, üzenetek, kérdőívek, telephelyek.
 *
 * Mind kliens-oldali (a /o/[slug] route ssr: false) – TanStack Query-vel hidratálódik.
 */
import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation } from "@tanstack/react-query";
import {
  getPublicStaffProfile,
  listPublicStaff,
  listPublicFaqs,
  getDoctorSchedule,
  submitContactMessage,
  getOrgUnit,
  getPublicSiteSettings,
} from "@/lib/cms/dynamic.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { AlertTriangle, Calendar, MapPin, Phone, Mail, Stethoscope, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { SmartImage } from "@/components/ui/smart-image";

/* =========================================================
 *  Helpers
 * =========================================================*/
function FieldError({ children }: { children?: React.ReactNode }) {
  if (!children) return null;
  return <p className="text-sm text-destructive mt-1">{children}</p>;
}

function formatDayHun(iso: string) {
  const d = new Date(iso);
  return d.toLocaleDateString("hu-HU", { weekday: "short", month: "short", day: "numeric" });
}
function formatTimeHun(iso: string) {
  const d = new Date(iso);
  return d.toLocaleTimeString("hu-HU", { hour: "2-digit", minute: "2-digit" });
}

/* =========================================================
 *  <DoctorCard slug=… />
 * =========================================================*/
export function DoctorCardBlock({ slug, locale = "hu" }: { slug: string; locale?: string }) {
  const fn = useServerFn(getPublicStaffProfile);
  const { data, isLoading } = useQuery({
    queryKey: ["cms-doctor", slug, locale],
    queryFn: () => fn({ data: { slug, locale } }),
    staleTime: 60_000,
  });
  if (isLoading) {
    return <Card className="my-6 p-4 flex gap-4"><Skeleton className="h-24 w-24 rounded-full" /><div className="flex-1 space-y-2"><Skeleton className="h-5 w-1/2" /><Skeleton className="h-3 w-full" /><Skeleton className="h-3 w-3/4" /></div></Card>;
  }
  if (!data) return null;
  return (
    <Card className="my-6 p-4 flex flex-col sm:flex-row gap-4 items-start">
      {data.photo_url && (
        <SmartImage src={data.photo_url} alt={data.display_name} sizesPreset="avatar" className="h-24 w-24 sm:h-32 sm:w-32 rounded-full object-cover shrink-0" />
      )}
      <div className="flex-1 min-w-0">
        <h3 className="text-xl font-bold">{data.display_name}</h3>
        {data.title && <div className="text-sm text-muted-foreground">{data.title}</div>}
        {!!(data.specialties as string[])?.length && (
          <div className="flex flex-wrap gap-1 mt-2">
            {(data.specialties as string[]).map((s) => (
              <span key={s} className="text-xs px-2 py-0.5 rounded-full bg-secondary text-secondary-foreground">{s}</span>
            ))}
          </div>
        )}
        {data.bio && <p className="text-sm mt-3 whitespace-pre-line">{data.bio}</p>}
        <Link to="/o/$slug" params={{ slug: `munkatarsak/${data.slug}` }} className="inline-block mt-3 text-sm text-primary hover:underline">
          Részletes profil →
        </Link>
      </div>
    </Card>
  );
}

/* =========================================================
 *  <DoctorScheduleBlock doctor_id?  specialty_id?  org_unit_id?  days? />
 *  Élő szabad slotok a beosztásból.
 * =========================================================*/
export function DoctorScheduleBlock(props: {
  doctor_id?: string;
  specialty_id?: string;
  org_unit_id?: string;
  days?: number;
  title?: string;
}) {
  const fn = useServerFn(getDoctorSchedule);
  const days = props.days ?? 14;
  const { data, isLoading } = useQuery({
    queryKey: ["cms-doctor-schedule", props.doctor_id, props.specialty_id, props.org_unit_id, days],
    queryFn: () =>
      fn({
        data: {
          doctor_id: props.doctor_id,
          specialty_id: props.specialty_id,
          org_unit_id: props.org_unit_id,
          days,
        },
      }),
    staleTime: 60_000,
  });

  const grouped: Record<string, any[]> = {};
  for (const s of data?.slots ?? []) {
    const day = (s.kezdo_ts as string).slice(0, 10);
    (grouped[day] ||= []).push(s);
  }
  const days_keys = Object.keys(grouped).sort();

  return (
    <Card className="my-6 p-4">
      <h3 className="text-lg font-bold flex items-center gap-2 mb-3">
        <Calendar className="h-5 w-5" />
        {props.title ?? "Foglalható időpontok"}
      </h3>
      {isLoading ? (
        <div className="space-y-2"><Skeleton className="h-5 w-1/3" /><Skeleton className="h-8 w-full" /><Skeleton className="h-8 w-full" /></div>
      ) : !days_keys.length ? (
        <div className="text-sm text-muted-foreground py-2">A következő {days} napban nincs szabad időpont. <Link to="/foglalas/uj" className="text-primary hover:underline">Foglalás más időpontra</Link></div>
      ) : (
        <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
          {days_keys.slice(0, 7).map((day) => (
            <div key={day}>
              <div className="text-sm font-semibold mb-1">{formatDayHun(day + "T00:00:00")}</div>
              <div className="flex flex-wrap gap-2">
                {grouped[day].slice(0, 16).map((s: any) => (
                  <Link
                    key={s.id}
                    to="/foglalas/uj"
                    search={{ slot_id: s.id } as any}
                    className="text-xs px-3 py-2 rounded-md border border-border bg-card hover:bg-primary hover:text-primary-foreground transition-colors min-h-11 inline-flex items-center"
                  >
                    {formatTimeHun(s.kezdo_ts)}
                  </Link>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
      <div className="mt-3 pt-3 border-t flex items-center justify-between gap-2 flex-wrap">
        <span className="text-xs text-muted-foreground">{data?.resources?.length ?? 0} rendelés</span>
        <Link to="/foglalas/uj" className="text-sm text-primary hover:underline">Összes szabad időpont →</Link>
      </div>
    </Card>
  );
}

/* =========================================================
 *  <AppointmentBookingWidgetBlock specialty_id? doctor_id? />
 *  Egy-lépéses inline foglalás (átirányít a /foglalas/uj-ra)
 * =========================================================*/
export function AppointmentBookingWidgetBlock(props: {
  specialty_id?: string;
  doctor_id?: string;
  org_unit_id?: string;
  cta_label?: string;
}) {
  return (
    <Card className="my-6 p-6 bg-gradient-to-br from-primary/5 to-secondary/10 border-primary/20">
      <div className="flex items-start gap-4 flex-col sm:flex-row">
        <div className="grid h-12 w-12 place-items-center rounded-full bg-primary text-primary-foreground shrink-0">
          <Calendar className="h-6 w-6" />
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="text-lg font-bold">Időpontfoglalás</h3>
          <p className="text-sm text-muted-foreground mt-1">Válassz időpontot az elérhetők közül – a foglalás 1 percig tart.</p>
          <Link
            to="/foglalas/uj"
            search={
              {
                ...(props.specialty_id ? { szakma_id: props.specialty_id } : {}),
                ...(props.doctor_id ? { orvos_id: props.doctor_id } : {}),
                ...(props.org_unit_id ? { org_unit_id: props.org_unit_id } : {}),
              } as any
            }
            className="inline-flex mt-3 min-h-11 items-center px-4 rounded-md bg-primary text-primary-foreground font-medium hover:bg-primary/90"
          >
            {props.cta_label ?? "Foglalás indítása"} →
          </Link>
        </div>
      </div>
    </Card>
  );
}

/* =========================================================
 *  <ContactFormBlock org_unit_id? source_page_slug? />
 * =========================================================*/
export function ContactFormBlock(props: { org_unit_id?: string; source_page_slug?: string; title?: string }) {
  const submitFn = useServerFn(submitContactMessage);
  const [form, setForm] = useState({ name: "", email: "", phone: "", subject: "", body: "", hp: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const mut = useMutation({
    mutationFn: () =>
      submitFn({
        data: {
          org_unit_id: props.org_unit_id ?? null,
          source_page_slug: props.source_page_slug ?? null,
          sender_name: form.name,
          sender_email: form.email,
          sender_phone: form.phone || null,
          subject: form.subject || null,
          body: form.body,
          locale: "hu",
          hp: form.hp,
        },
      }),
    onSuccess: () => {
      toast.success("Köszönjük az üzenetet! Hamarosan jelentkezünk.");
      setForm({ name: "", email: "", phone: "", subject: "", body: "", hp: "" });
      setErrors({});
    },
    onError: (e: any) => toast.error(e?.message ?? "Hiba történt a küldés során."),
  });

  const validate = () => {
    const e: Record<string, string> = {};
    if (form.name.trim().length < 2) e.name = "Adja meg a nevét.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = "Érvényes e-mail cím szükséges.";
    if (form.body.trim().length < 5) e.body = "Pár szóval írja le, miben segíthetünk.";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  return (
    <Card className="my-6 p-4 sm:p-6">
      <h3 className="text-lg font-bold flex items-center gap-2 mb-3"><Mail className="h-5 w-5" /> {props.title ?? "Kapcsolatfelvétel"}</h3>
      <form
        className="space-y-3"
        onSubmit={(e) => {
          e.preventDefault();
          if (validate()) mut.mutate();
        }}
      >
        {/* honeypot – látható nem, botoknak igen */}
        <div className="hidden" aria-hidden>
          <Label>Ne töltsd ki</Label>
          <Input value={form.hp} onChange={(e) => setForm({ ...form, hp: e.target.value })} tabIndex={-1} autoComplete="off" />
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <Label htmlFor="cf-name">Név *</Label>
            <Input id="cf-name" className="min-h-11" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} autoComplete="name" enterKeyHint="next" />
            <FieldError>{errors.name}</FieldError>
          </div>
          <div>
            <Label htmlFor="cf-email">E-mail *</Label>
            <Input id="cf-email" type="email" className="min-h-11" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} inputMode="email" autoComplete="email" enterKeyHint="next" />
            <FieldError>{errors.email}</FieldError>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <Label htmlFor="cf-phone">Telefon</Label>
            <Input id="cf-phone" className="min-h-11" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} inputMode="tel" autoComplete="tel" enterKeyHint="next" />
          </div>
          <div>
            <Label htmlFor="cf-subject">Tárgy</Label>
            <Input id="cf-subject" className="min-h-11" value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} enterKeyHint="next" />
          </div>
        </div>
        <div>
          <Label htmlFor="cf-body">Üzenet *</Label>
          <Textarea id="cf-body" rows={5} value={form.body} onChange={(e) => setForm({ ...form, body: e.target.value })} />
          <FieldError>{errors.body}</FieldError>
        </div>
        <Button type="submit" className="min-h-11 w-full sm:w-auto" disabled={mut.isPending}>
          {mut.isPending ? "Küldés…" : "Üzenet küldése"}
        </Button>
        <p className="text-xs text-muted-foreground">Az üzeneted bizalmasan kezeljük, az osztály felelőséhez juttatjuk el.</p>
      </form>
    </Card>
  );
}

/* =========================================================
 *  <DepartmentInfoBlock unit_id />
 * =========================================================*/
export function DepartmentInfoBlock({ unit_id }: { unit_id: string }) {
  const fn = useServerFn(getOrgUnit);
  const { data, isLoading } = useQuery({
    queryKey: ["cms-org-unit", unit_id],
    queryFn: () => fn({ data: { id: unit_id } }),
    staleTime: 60_000,
  });
  if (isLoading) return <Card className="my-6 p-4"><Skeleton className="h-5 w-1/3" /><Skeleton className="h-4 w-2/3 mt-2" /></Card>;
  if (!data) return null;
  return (
    <Card className="my-6 p-4">
      <h3 className="text-lg font-bold flex items-center gap-2"><MapPin className="h-5 w-5" /> {data.nev}</h3>
      {data.cim && <div className="text-sm text-muted-foreground mt-1">{data.cim}</div>}
      <div className="flex flex-wrap gap-4 mt-3 text-sm">
        {data.telefon && <a href={`tel:${data.telefon}`} className="inline-flex items-center gap-1 min-h-11"><Phone className="h-4 w-4" /> {data.telefon}</a>}
        {data.email && <a href={`mailto:${data.email}`} className="inline-flex items-center gap-1 min-h-11"><Mail className="h-4 w-4" /> {data.email}</a>}
      </div>
    </Card>
  );
}

/* =========================================================
 *  <FaqBlock tag? limit? />  +  FAQPage JSON-LD
 * =========================================================*/
export function FaqBlock({ tag, limit = 10, locale = "hu" }: { tag?: string; limit?: number; locale?: string }) {
  const fn = useServerFn(listPublicFaqs);
  const { data, isLoading } = useQuery({
    queryKey: ["cms-faqs", tag ?? "all", locale, limit],
    queryFn: () => fn({ data: { tag, locale, limit } }),
    staleTime: 60_000,
  });
  const items = data ?? [];
  const jsonld = items.length
    ? {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        mainEntity: items.map((i: any) => ({
          "@type": "Question",
          name: i.question,
          acceptedAnswer: { "@type": "Answer", text: i.answer },
        })),
      }
    : null;
  return (
    <div className="my-6 space-y-3">
      {jsonld && (
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonld) }} />
      )}
      {isLoading ? <Skeleton className="h-6 w-full" /> :
        items.map((f: any) => (
          <details key={f.id} className="border border-border rounded-md p-3 bg-card group">
            <summary className="font-medium cursor-pointer min-h-11 flex items-center">{f.question}</summary>
            <div className="text-sm mt-2 whitespace-pre-line text-muted-foreground">{f.answer}</div>
          </details>
        ))}
      {!isLoading && !items.length && <div className="text-sm text-muted-foreground">Nincs kérdés a választott témában.</div>}
    </div>
  );
}

/* =========================================================
 *  <RelatedPostsBlock slugs?  limit?  /> – egyszerű link-lista
 * =========================================================*/
export function RelatedPostsBlock({ slugs }: { slugs?: string[] }) {
  if (!slugs?.length) return null;
  return (
    <Card className="my-6 p-4">
      <h3 className="text-lg font-bold flex items-center gap-2 mb-3"><Sparkles className="h-5 w-5" /> Kapcsolódó tartalmak</h3>
      <ul className="space-y-2">
        {slugs.map((s) => (
          <li key={s}>
            <Link to="/o/$slug" params={{ slug: s }} className="text-primary hover:underline">/{s}</Link>
          </li>
        ))}
      </ul>
    </Card>
  );
}

/* =========================================================
 *  <StaffListBlock specialty? />  – publikált munkatársak grid-je
 * =========================================================*/
export function StaffListBlock({ specialty, locale = "hu" }: { specialty?: string; locale?: string }) {
  const fn = useServerFn(listPublicStaff);
  const { data, isLoading } = useQuery({
    queryKey: ["cms-staff-list", specialty ?? "all", locale],
    queryFn: () => fn({ data: { specialty, locale } }),
    staleTime: 60_000,
  });
  if (isLoading) {
    return <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 my-6">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-32" />)}</div>;
  }
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 my-6">
      {(data ?? []).map((s: any) => (
        <Link key={s.id} to="/o/$slug" params={{ slug: `munkatarsak/${s.slug}` }} className="block">
          <Card className="p-3 hover:bg-accent transition-colors h-full">
            {s.photo_url && <SmartImage src={s.photo_url} alt={s.display_name} sizesPreset="card" className="h-32 w-full rounded-md object-cover mb-2" />}
            <div className="font-semibold flex items-center gap-1"><Stethoscope className="h-4 w-4 shrink-0" /> {s.display_name}</div>
            {s.title && <div className="text-xs text-muted-foreground">{s.title}</div>}
          </Card>
        </Link>
      ))}
      {!data?.length && <div className="text-sm text-muted-foreground">Nincs publikált munkatárs.</div>}
    </div>
  );
}

/* =========================================================
 *  <SosBannerBlock /> – globális SOS, a layout-ban hívva (NEM blokk-szinten kell)
 * =========================================================*/
export function SosBanner() {
  const fn = useServerFn(getPublicSiteSettings);
  const { data } = useQuery({
    queryKey: ["cms-site-settings"],
    queryFn: () => fn(),
    staleTime: 30_000,
  });
  if (!data?.sos_active) return null;
  return (
    <div className="bg-destructive text-destructive-foreground px-4 py-2 text-sm flex items-center gap-2 justify-center sticky top-0 z-50">
      <AlertTriangle className="h-4 w-4 shrink-0" />
      <span className="font-medium">{data.sos_message ?? "Sürgősségi mód aktív."}</span>
      <a href="/portal/sos" className="underline ml-2 min-h-8">Tovább a SOS oldalra →</a>
    </div>
  );
}
