/**
 * CMS media picker dialog.
 *
 * - Lists existing cms_media items as thumbnails (signed URLs).
 * - Inline upload (reuses supabase.storage upload + registerMedia server fn).
 * - Optional WebP conversion on upload (same as MediaAdmin).
 * - Returns a public/signed URL through onSelect().
 *
 * Used by RichTextEditor to insert images without leaving the block inspector.
 */
import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { listMedia, registerMedia, signMediaUrl } from "@/lib/cms/cms.functions";
import { convertToWebp, shouldConvertImage } from "@/lib/cms/image-convert";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogDescription,
} from "@/components/ui/dialog";
import { Loader2, Upload, ImageIcon, Search, Check } from "lucide-react";
import { toast } from "sonner";

type Props = {
  trigger: React.ReactNode;
  onSelect: (item: { url: string; alt?: string; file_name?: string }) => void;
  accept?: string;
  title?: string;
};

export function MediaPicker({ trigger, onSelect, accept = "image/*", title = "Kép választása" }: Props) {
  const qc = useQueryClient();
  const listFn = useServerFn(listMedia);
  const regFn = useServerFn(registerMedia);
  const signFn = useServerFn(signMediaUrl);

  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [uploading, setUploading] = useState(false);
  const [selected, setSelected] = useState<string | null>(null);
  const [urls, setUrls] = useState<Record<string, string>>({});
  const fileRef = useRef<HTMLInputElement>(null);

  const { data: media = [], isLoading } = useQuery({
    queryKey: ["cms-media"],
    queryFn: () => listFn(),
    enabled: open,
  });

  // Only image mimes when accept starts with image/
  const items = (media as any[]).filter((m) => {
    if (accept === "image/*" && !String(m.mime_type ?? "").startsWith("image/")) return false;
    if (!query.trim()) return true;
    return String(m.file_name ?? "").toLowerCase().includes(query.trim().toLowerCase());
  });

  // Lazy-resolve signed URLs for visible thumbnails
  useEffect(() => {
    if (!open) return;
    (async () => {
      const missing = items.filter((m) => !urls[m.storage_path]).slice(0, 40);
      if (missing.length === 0) return;
      const pairs = await Promise.all(
        missing.map(async (m) => {
          try { const r = await signFn({ data: { path: m.storage_path } }); return [m.storage_path, r.url ?? ""] as const; }
          catch { return [m.storage_path, ""] as const; }
        }),
      );
      setUrls((prev) => {
        const next = { ...prev };
        for (const [k, v] of pairs) if (v) next[k] = v;
        return next;
      });
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, media, query]);

  const handleUpload = async (files: FileList | null) => {
    if (!files?.length) return;
    setUploading(true);
    try {
      let lastPath = "";
      let lastAlt = "";
      for (const original of Array.from(files)) {
        let file = original;
        if (shouldConvertImage(original)) {
          const conv = await convertToWebp(original, { maxWidth: 2000, quality: 0.85 });
          if (conv !== original) file = conv;
        }
        const path = `${Date.now()}-${file.name.replace(/[^a-zA-Z0-9.-]/g, "_")}`;
        const { error: upErr } = await supabase.storage.from("cms-media").upload(path, file);
        if (upErr) throw upErr;
        await regFn({
          data: { storage_path: path, file_name: file.name, mime_type: file.type, size_bytes: file.size },
        });
        lastPath = path;
        lastAlt = file.name;
      }
      toast.success("Feltöltve");
      qc.invalidateQueries({ queryKey: ["cms-media"] });
      // Auto-select the uploaded file and resolve its URL
      if (lastPath) {
        const r = await signFn({ data: { path: lastPath } });
        if (r.url) {
          setUrls((p) => ({ ...p, [lastPath]: r.url! }));
          setSelected(lastPath);
          onSelect({ url: r.url, alt: lastAlt, file_name: lastAlt });
          setOpen(false);
        }
      }
    } catch (e: any) {
      toast.error("Feltöltés sikertelen", { description: e?.message?.slice(0, 200) });
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const confirmSelect = async () => {
    if (!selected) return;
    const m = items.find((x) => x.storage_path === selected);
    const url = urls[selected] ?? (await signFn({ data: { path: selected } })).url ?? "";
    if (!url) { toast.error("Nem sikerült URL-t generálni"); return; }
    onSelect({ url, alt: m?.alt_text ?? m?.file_name, file_name: m?.file_name });
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) setSelected(null); }}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="max-w-3xl max-h-[85vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>Válassz a CMS médiatárból, vagy tölts fel újat.</DialogDescription>
        </DialogHeader>

        <div className="flex flex-wrap items-center gap-2">
          <div className="relative flex-1 min-w-[180px]">
            <Search className="absolute left-2 top-1/2 -translate-y-1/2 size-3.5 text-muted-foreground" />
            <Input
              placeholder="Keresés név szerint…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="pl-8 h-9"
            />
          </div>
          <input
            ref={fileRef}
            type="file"
            accept={accept}
            multiple
            className="hidden"
            onChange={(e) => handleUpload(e.target.files)}
          />
          <Button
            variant="outline"
            size="sm"
            disabled={uploading}
            onClick={() => fileRef.current?.click()}
            className="gap-1"
          >
            {uploading ? <Loader2 className="size-4 animate-spin" /> : <Upload className="size-4" />}
            Új feltöltése
          </Button>
        </div>

        <div className="flex-1 overflow-y-auto -mx-2 px-2">
          {isLoading ? (
            <div className="flex items-center gap-2 text-sm text-muted-foreground p-6">
              <Loader2 className="size-4 animate-spin" />Médiatár betöltése…
            </div>
          ) : items.length === 0 ? (
            <div className="p-6 text-center text-sm text-muted-foreground">
              <ImageIcon className="size-8 mx-auto opacity-40 mb-2" />
              Nincs találat. Tölts fel egy új képet fentről.
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
              {items.map((m) => {
                const src = urls[m.storage_path];
                const active = selected === m.storage_path;
                return (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => setSelected(m.storage_path)}
                    onDoubleClick={() => { setSelected(m.storage_path); void confirmSelect(); }}
                    className={`group relative border rounded-md overflow-hidden text-left hover:border-primary transition ${
                      active ? "border-primary ring-2 ring-primary/30" : ""
                    }`}
                    title={m.file_name}
                  >
                    <div className="aspect-video bg-muted flex items-center justify-center">
                      {src
                        ? <img src={src} alt={m.alt_text ?? m.file_name} className="w-full h-full object-cover" loading="lazy" />
                        : <Loader2 className="size-4 animate-spin text-muted-foreground" />}
                    </div>
                    {active && (
                      <div className="absolute top-1 right-1 bg-primary text-primary-foreground rounded-full p-0.5">
                        <Check className="size-3" />
                      </div>
                    )}
                    <div className="p-1.5 text-[10px] truncate">{m.file_name}</div>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={() => setOpen(false)}>Mégse</Button>
          <Button onClick={confirmSelect} disabled={!selected}>Beszúrás</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
