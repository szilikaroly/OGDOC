/**
 * Compact AI auto-translate widget for the CMS admin.
 * - Shows a per-language count of missing UI/content keys.
 * - "AI auto-fordítás" button iterates all languages and calls
 *   processMissingKeys, which auto-saves results into i18n_translations.
 */
import { useMemo, useState } from "react";
import { useQueries, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sparkles, RefreshCw, Languages, ArrowRight } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { SUPPORTED_LANGUAGES } from "@/i18n/languages";
import { listMissingKeys, processMissingKeys } from "@/lib/i18n/admin.functions";

export function I18nAutoTranslateWidget() {
  const qc = useQueryClient();
  const targets = useMemo(() => SUPPORTED_LANGUAGES.filter((l) => l.code !== "hu"), []);
  const [running, setRunning] = useState<null | { lang: string; done: number; total: number }>(null);

  const queries = useQueries({
    queries: targets.map((l) => ({
      queryKey: ["i18n-missing", l.code],
      queryFn: () => listMissingKeys({ data: { lang: l.code, limit: 1000 } }),
      staleTime: 60_000,
    })),
  });

  const counts = targets.map((l, i) => ({
    code: l.code,
    label: l.label,
    flag: l.flag,
    count: (queries[i].data ?? []).length,
    loading: queries[i].isLoading,
  }));
  const total = counts.reduce((s, x) => s + x.count, 0);

  async function runOne(lang: string): Promise<void> {
    // Loop batches of 100 until this language is empty
    let remaining = Infinity;
    while (remaining > 0) {
      const res = await processMissingKeys({ data: { lang, batch_size: 100 } });
      remaining = res.remaining;
      if (res.processed === 0) break;
    }
  }

  async function runAll() {
    const pending = counts.filter((c) => c.count > 0);
    if (pending.length === 0) {
      toast.success("Nincs hiányzó kulcs egyik nyelven sem 🎉");
      return;
    }
    let done = 0;
    for (const c of pending) {
      setRunning({ lang: c.code, done, total: pending.length });
      try {
        await runOne(c.code);
      } catch (e: any) {
        toast.error(`${c.code}: ${e?.message ?? "Fordítás sikertelen"}`);
      }
      done++;
    }
    setRunning(null);
    toast.success(`AI auto-fordítás kész (${pending.length} nyelv)`);
    qc.invalidateQueries({ queryKey: ["i18n-missing"] });
    qc.invalidateQueries({ queryKey: ["i18n-translations"] });
  }

  return (
    <Card>
      <CardHeader className="pb-3 flex flex-row items-center justify-between gap-2 space-y-0">
        <CardTitle className="text-base flex items-center gap-2">
          <Languages className="size-4" /> AI auto-fordítás
        </CardTitle>
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            className="min-h-9"
            onClick={() => qc.invalidateQueries({ queryKey: ["i18n-missing"] })}
            disabled={!!running}
          >
            <RefreshCw className="size-4" />
          </Button>
          <Button asChild variant="outline" size="sm" className="min-h-9">
            <Link to="/admin/forditasok" className="gap-1">
              Kezelő <ArrowRight className="size-3.5" />
            </Link>
          </Button>
          <Button size="sm" className="min-h-9" onClick={runAll} disabled={!!running || total === 0}>
            <Sparkles className="size-4 mr-1.5" />
            {running ? `Fordítás… (${running.done}/${running.total})` : `Auto-fordítás (${total})`}
          </Button>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <p className="text-xs text-muted-foreground mb-2">
          A hiányzó UI- és tartalom-kulcsokat AI-val fordítja és automatikusan menti a fordítás-cache-be.
        </p>
        <div className="flex flex-wrap gap-1.5">
          {counts.map((c) => (
            <Badge
              key={c.code}
              variant={c.count === 0 ? "outline" : "secondary"}
              className={running?.lang === c.code ? "ring-2 ring-primary" : ""}
            >
              {c.flag} {c.code.toUpperCase()}{" "}
              <span className={c.count === 0 ? "text-muted-foreground ml-1" : "ml-1 font-semibold"}>
                {c.loading ? "…" : c.count}
              </span>
            </Badge>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
