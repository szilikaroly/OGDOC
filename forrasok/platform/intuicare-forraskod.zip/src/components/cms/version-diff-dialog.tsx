import { useMemo } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";

type Snapshot = Record<string, any> | null | undefined;

type DiffEntry = {
  path: string;
  kind: "added" | "removed" | "changed";
  a?: unknown;
  b?: unknown;
};

const SKIP_KEYS = new Set([
  "id", "created_at", "updated_at",
  "submitted_for_review_at", "submitted_by",
  "approved_at", "approved_by",
  "rejected_at", "rejected_by", "rejection_reason",
]);

function isObj(v: unknown): v is Record<string, any> {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

function deepDiff(a: any, b: any, path = ""): DiffEntry[] {
  if (Object.is(a, b)) return [];
  if (JSON.stringify(a) === JSON.stringify(b)) return [];

  if (isObj(a) && isObj(b)) {
    const out: DiffEntry[] = [];
    const keys = new Set([...Object.keys(a), ...Object.keys(b)]);
    for (const k of keys) {
      if (SKIP_KEYS.has(k) && path === "") continue;
      const p = path ? `${path}.${k}` : k;
      if (!(k in a)) out.push({ path: p, kind: "added", b: b[k] });
      else if (!(k in b)) out.push({ path: p, kind: "removed", a: a[k] });
      else out.push(...deepDiff(a[k], b[k], p));
    }
    return out;
  }

  if (Array.isArray(a) && Array.isArray(b)) {
    const out: DiffEntry[] = [];
    const max = Math.max(a.length, b.length);
    for (let i = 0; i < max; i++) {
      const p = `${path}[${i}]`;
      if (i >= a.length) out.push({ path: p, kind: "added", b: b[i] });
      else if (i >= b.length) out.push({ path: p, kind: "removed", a: a[i] });
      else out.push(...deepDiff(a[i], b[i], p));
    }
    return out;
  }

  return [{ path: path || "(root)", kind: "changed", a, b }];
}

function fmt(v: unknown): string {
  if (v === undefined) return "—";
  if (typeof v === "string") return v.length > 200 ? v.slice(0, 200) + "…" : v;
  try { return JSON.stringify(v, null, 2); } catch { return String(v); }
}

export function VersionDiffDialog({
  open, onOpenChange, a, b, labelA, labelB,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  a: Snapshot;
  b: Snapshot;
  labelA: string;
  labelB: string;
}) {
  const diff = useMemo(() => deepDiff(a ?? {}, b ?? {}), [a, b]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <DialogTitle>Verzió-összehasonlítás</DialogTitle>
          <DialogDescription className="flex flex-wrap gap-2 items-center">
            <Badge variant="outline">A: {labelA}</Badge>
            <span className="text-xs">→</span>
            <Badge variant="outline">B: {labelB}</Badge>
            <span className="text-xs text-muted-foreground ml-2">
              {diff.length === 0 ? "Nincs eltérés" : `${diff.length} eltérés`}
            </span>
          </DialogDescription>
        </DialogHeader>

        {diff.length === 0 ? (
          <p className="text-sm text-muted-foreground py-8 text-center">
            A két verzió tartalmilag azonos.
          </p>
        ) : (
          <ScrollArea className="max-h-[60vh] pr-3">
            <ul className="space-y-3">
              {diff.map((d, i) => (
                <li key={i} className="border rounded-md p-3 text-xs">
                  <div className="flex items-center gap-2 mb-2">
                    <Badge
                      variant={
                        d.kind === "added" ? "default"
                          : d.kind === "removed" ? "destructive"
                            : "secondary"
                      }
                    >
                      {d.kind === "added" ? "új" : d.kind === "removed" ? "törölt" : "változott"}
                    </Badge>
                    <code className="font-mono break-all">{d.path}</code>
                  </div>
                  {d.kind !== "added" && (
                    <pre className="bg-destructive/10 text-destructive border-l-2 border-destructive p-2 rounded whitespace-pre-wrap break-all font-mono mb-1">
                      {fmt(d.a)}
                    </pre>
                  )}
                  {d.kind !== "removed" && (
                    <pre className="bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border-l-2 border-emerald-500 p-2 rounded whitespace-pre-wrap break-all font-mono">
                      {fmt(d.b)}
                    </pre>
                  )}
                </li>
              ))}
            </ul>
          </ScrollArea>
        )}
      </DialogContent>
    </Dialog>
  );
}
