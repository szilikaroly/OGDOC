import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { getPageViewStats } from "@/lib/cms/cms.functions";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

export function PageViewsDialog({ pageId, open, onOpenChange }: { pageId: string; open: boolean; onOpenChange: (v: boolean) => void }) {
  const fn = useServerFn(getPageViewStats);
  const { data, isLoading } = useQuery({
    queryKey: ["cms-page-views", pageId],
    queryFn: () => fn({ data: { pageId, days: 30 } }),
    enabled: open,
    staleTime: 30_000,
  });

  // Fill missing days with 0 for chart continuity
  const chart = (() => {
    if (!data) return [] as { day: string; views: number }[];
    const map = new Map((data.daily ?? []).map((d: any) => [d.day, d.views]));
    const out: { day: string; views: number }[] = [];
    const today = new Date();
    for (let i = data.days - 1; i >= 0; i--) {
      const d = new Date(today.getTime() - i * 86400_000);
      const key = d.toISOString().slice(0, 10);
      out.push({ day: key, views: Number(map.get(key) ?? 0) });
    }
    return out;
  })();
  const maxVal = Math.max(1, ...chart.map(c => c.views));

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle>Megtekintések</DialogTitle>
        </DialogHeader>
        {isLoading ? (
          <div className="text-sm text-muted-foreground py-8 text-center">Betöltés…</div>
        ) : data ? (
          <div className="space-y-4">
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-center text-xs">
              <Stat label="Össz" v={data.page?.view_count ?? 0} />
              <Stat label={`${data.days} napos`} v={data.windowTotal} />
              <Stat label="Utoljára" v={data.page?.last_viewed_at ? new Date(data.page.last_viewed_at).toLocaleDateString("hu-HU") : "—"} />
            </div>
            <div>
              <div className="text-xs text-muted-foreground mb-2">Napi megtekintések (utolsó {data.days} nap)</div>
              <div className="flex items-end gap-[2px] h-32 border rounded p-2 bg-muted/20">
                {chart.map((c, i) => (
                  <div
                    key={i}
                    title={`${c.day}: ${c.views}`}
                    className="flex-1 bg-primary/70 hover:bg-primary rounded-sm transition-colors"
                    style={{ height: `${(c.views / maxVal) * 100}%`, minHeight: "2px" }}
                  />
                ))}
              </div>
              <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
                <span>{chart[0]?.day}</span>
                <span>{chart[chart.length - 1]?.day}</span>
              </div>
            </div>
          </div>
        ) : null}
        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)} className="min-h-11">Bezár</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function Stat({ label, v }: { label: string; v: number | string }) {
  return (
    <div className="border rounded p-2">
      <div className="text-lg font-semibold">{v}</div>
      <div className="text-[10px] uppercase tracking-wide text-muted-foreground">{label}</div>
    </div>
  );
}
