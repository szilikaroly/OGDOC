/**
 * Visual CMS editor: page/region picker, drag&drop block list, JSON content
 * editor with autosave, device-switched iframe preview.
 *
 * For the MVP the per-block form is a guarded JSON textarea — schema-driven
 * forms can be layered on later without touching the persistence path.
 */
import { useEffect, useMemo, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  DndContext, closestCenter, KeyboardSensor, PointerSensor,
  useSensor, useSensors, useDroppable, type DragEndEvent,
} from "@dnd-kit/core";
import {
  arrayMove, SortableContext, sortableKeyboardCoordinates,
  useSortable, verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import {
  GripVertical, Trash2, Plus, Smartphone, Tablet, Monitor, RefreshCw, Save,
  ExternalLink, Loader2, Sparkles, LayoutTemplate,
} from "lucide-react";
import { toast } from "sonner";
import { listPages } from "@/lib/cms/cms.functions";
import {
  listPageBlocks, upsertLayoutBlock, deleteLayoutBlock, reorderLayoutBlocks,
  listGlobalRegions, saveGlobalRegion, type LayoutBlock, type GlobalRegion,
} from "@/lib/cms/layout-blocks.functions";
import { generateBlockContent, generatePageDraft } from "@/lib/cms/ai-blocks.functions";
import { BLOCK_TEMPLATES } from "@/lib/cms/block-templates";
import { BLOCK_CATALOG, REGION_KEYS, REGION_META, type RegionKey } from "@/lib/cms/block-schema";
import { BlockLinkEditor } from "./block-link-editor";
import { BlockPalette } from "./visual/block-palette";
import { BlockFormEditor } from "./visual/block-form-editor";
import {
  usePreviewDevice, PreviewToolbar, PreviewFrame,
} from "./visual/preview-toolbar";
import { TransferBlocksDialog } from "./transfer-blocks-dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { ArrowRightLeft } from "lucide-react";

type Target =
  | { kind: "page"; pageId: string; slug: string | null; isHome: boolean; title: string }
  | { kind: "region"; regionKey: RegionKey };

export function VisualEditor() {
  const qc = useQueryClient();
  const listPagesFn = useServerFn(listPages);
  const pagesQ = useQuery({ queryKey: ["cms-pages-all"], queryFn: () => listPagesFn() });

  const [target, setTarget] = useState<Target | null>(null);
  const [device, setDevice] = usePreviewDevice();
  const [previewNonce, setPreviewNonce] = useState(0);

  // Auto-select home page first time
  useEffect(() => {
    if (!target && pagesQ.data?.length) {
      const home = (pagesQ.data as any[]).find((p) => p.is_home && p.status === "published");
      if (home) setTarget({ kind: "page", pageId: home.id, slug: home.slug, isHome: true, title: home.title });
    }
  }, [pagesQ.data, target]);

  const previewUrl = useMemo(() => {
    if (!target) return "/";
    if (target.kind === "region") return "/";
    if (target.isHome) return "/";
    return target.slug ? `/o/${target.slug}` : "/";
  }, [target]);

  // Automatikus frissítés: minden tartalom-változás és céloldal-váltás után.
  const reloadTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const refreshPreview = () => {
    if (reloadTimer.current) clearTimeout(reloadTimer.current);
    reloadTimer.current = setTimeout(() => setPreviewNonce((n) => n + 1), 350);
  };
  useEffect(() => () => { if (reloadTimer.current) clearTimeout(reloadTimer.current); }, []);
  useEffect(() => { setPreviewNonce((n) => n + 1); }, [previewUrl]);

  return (
    <div className="flex flex-col xl:flex-row gap-4 h-[calc(100vh-9rem)]">
      <aside className="w-full xl:w-72 shrink-0 space-y-3 overflow-y-auto">
        <Card>
          <CardContent className="p-3 space-y-2">
            <div className="text-xs font-semibold uppercase text-muted-foreground">Oldalak</div>
            {pagesQ.isLoading && <div className="text-sm text-muted-foreground">Betöltés…</div>}
            <div className="space-y-1">
              {(pagesQ.data ?? []).map((p: any) => (
                <button
                  key={p.id}
                  onClick={() => setTarget({ kind: "page", pageId: p.id, slug: p.slug, isHome: !!p.is_home, title: p.title })}
                  className={`w-full text-left text-sm px-2 py-1.5 rounded hover:bg-accent ${
                    target?.kind === "page" && target.pageId === p.id ? "bg-accent" : ""
                  }`}
                >
                  <div className="flex items-center gap-2">
                    {p.is_home && <Badge variant="secondary" className="text-[10px]">Főoldal</Badge>}
                    <span className="truncate">{p.title}</span>
                  </div>
                  <div className="text-[11px] text-muted-foreground">/{p.is_home ? "" : `o/${p.slug}`} · {p.status}</div>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-3 space-y-2">
            <div className="text-xs font-semibold uppercase text-muted-foreground">Globális régiók</div>
            {REGION_KEYS.map((k) => (
              <button
                key={k}
                onClick={() => setTarget({ kind: "region", regionKey: k })}
                className={`w-full text-left text-sm px-2 py-1.5 rounded hover:bg-accent ${
                  target?.kind === "region" && target.regionKey === k ? "bg-accent" : ""
                }`}
              >
                <div className="font-medium">{REGION_META[k].label}</div>
                <div className="text-[11px] text-muted-foreground">{REGION_META[k].description}</div>
              </button>
            ))}
          </CardContent>
        </Card>
      </aside>

      <section className="flex-1 min-w-0 flex flex-col">
        <div className="flex flex-wrap items-center gap-2 mb-2">
          <div className="text-xs text-muted-foreground truncate">{previewUrl}</div>
          <PreviewToolbar
            className="ml-auto"
            device={device}
            onDeviceChange={setDevice}
            onRefresh={() => setPreviewNonce((n) => n + 1)}
            externalUrl={previewUrl}
          />
        </div>
        <div className="flex-1 border rounded-lg bg-muted/30 overflow-auto">
          <PreviewFrame
            device={device}
            src={`${previewUrl}${previewUrl.includes("?") ? "&" : "?"}_=${previewNonce}`}
            frameKey={previewNonce}
            title="Előnézet"
            className="h-full"
          />
        </div>
      </section>

      <aside className="w-full xl:w-96 shrink-0 overflow-y-auto">
        {target?.kind === "page" && <PageBlocksPanel target={target} onChanged={refreshPreview} qc={qc} />}
        {target?.kind === "region" && <RegionPanel regionKey={target.regionKey} onChanged={refreshPreview} qc={qc} />}
        {!target && <div className="text-sm text-muted-foreground p-4">Válassz oldalt vagy régiót.</div>}
      </aside>
    </div>
  );
}

// ─── Page blocks panel (drag&drop + autosave) ────────────────────────────
function PageBlocksPanel({
  target, onChanged, qc,
}: {
  target: Extract<Target, { kind: "page" }>;
  onChanged: () => void;
  qc: ReturnType<typeof useQueryClient>;
}) {
  const listFn = useServerFn(listPageBlocks);
  const upsertFn = useServerFn(upsertLayoutBlock);
  const deleteFn = useServerFn(deleteLayoutBlock);
  const reorderFn = useServerFn(reorderLayoutBlocks);

  const blocksQ = useQuery({
    queryKey: ["cms-page-blocks", target.pageId],
    queryFn: () => listFn({ data: { pageId: target.pageId } }),
  });
  const blocks = (blocksQ.data ?? []) as LayoutBlock[];

  const invalidate = () => qc.invalidateQueries({ queryKey: ["cms-page-blocks", target.pageId] });

  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [transferOpen, setTransferOpen] = useState(false);
  const toggleSel = (id: string) => setSelected(prev => {
    const next = new Set(prev);
    if (next.has(id)) next.delete(id); else next.add(id);
    return next;
  });

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 6 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  );
  const handleDragEnd = async (e: DragEndEvent) => {
    if (!e.over) return;
    const palette = e.active.data.current as
      | { palette?: boolean; type?: string; defaults?: Record<string, unknown> }
      | undefined;
    if (palette?.palette && palette.type) {
      const overId = String(e.over.id);
      const idx = overId === "visual-editor-end"
        ? blocks.length
        : Math.max(0, blocks.findIndex((b) => b.id === overId));
      await addBlock(palette.type, palette.defaults ?? {}, idx);
      return;
    }
    if (e.active.id === e.over.id) return;
    const oldIdx = blocks.findIndex((b) => b.id === e.active.id);
    const newIdx = blocks.findIndex((b) => b.id === e.over!.id);
    if (oldIdx < 0 || newIdx < 0) return;
    const next = arrayMove(blocks, oldIdx, newIdx);
    qc.setQueryData(["cms-page-blocks", target.pageId], next);
    await reorderFn({ data: { items: next.map((b, i) => ({ id: b.id, position: i })) } });
    invalidate(); onChanged();
  };

  const addBlock = async (type: string, content: Record<string, unknown> = {}, index?: number) => {
    const pos = index ?? blocks.length;
    await upsertFn({
      data: {
        page_id: target.pageId, region_key: null,
        position: pos, block_type: type,
        content, style: {}, locale: "hu", status: "published",
      } as any,
    });
    // A beszúrási pont utáni blokkokat eggyel lejjebb toljuk.
    if (index != null && index < blocks.length) {
      const after = blocks.slice(index);
      await reorderFn({
        data: { items: after.map((b, i) => ({ id: b.id, position: pos + 1 + i })) },
      });
    }
    toast.success("Blokk hozzáadva");
    invalidate(); onChanged();
  };

  const delBlock = async (id: string) => {
    await deleteFn({ data: { id } });
    toast.success("Blokk törölve");
    invalidate(); onChanged();
  };

  const saveContent = async (b: LayoutBlock, content: any) => {
    await upsertFn({ data: { ...b, content } as any });
    invalidate(); onChanged();
  };

  return (
    <Card>
      <CardContent className="p-3 space-y-3">
        <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
        <div>
          <div className="text-xs font-semibold uppercase text-muted-foreground">Blokkok</div>
          <div className="text-sm font-medium">{target.title}</div>
        </div>
        <AddBlockMenu onAdd={(t) => addBlock(t)} />
        <details className="border rounded">
          <summary className="cursor-pointer px-2 py-1.5 text-xs font-semibold uppercase text-muted-foreground">
            Blokk-paletta (húzd a listára)
          </summary>
          <BlockPalette onInsert={(t, d) => addBlock(t, d)} />
        </details>
        <TemplateGalleryButton onInsert={(tpl) => addBlock(tpl.block_type, tpl.content)} />
        <AiPageDraftButton
          startPosition={blocks.length}
          pageId={target.pageId}
          onDone={() => { invalidate(); onChanged(); }}
        />
        {selected.size > 0 && (
          <div className="flex items-center justify-between gap-2 border rounded p-2 bg-muted/40">
            <div className="text-xs">{selected.size} blokk kijelölve</div>
            <div className="flex gap-1">
              <Button size="sm" variant="outline" onClick={() => setSelected(new Set())}>Mégse</Button>
              <Button size="sm" onClick={() => setTransferOpen(true)} className="gap-1">
                <ArrowRightLeft className="size-3.5" />Áthelyez / Másol
              </Button>
            </div>
          </div>
        )}
        {blocksQ.isLoading && <div className="text-sm text-muted-foreground">Betöltés…</div>}
          <SortableContext items={blocks.map((b) => b.id)} strategy={verticalListSortingStrategy}>
            <div className="space-y-2">
              {blocks.map((b) => (
                <SortableBlockRow
                  key={b.id}
                  block={b}
                  selected={selected.has(b.id)}
                  onToggleSelect={() => toggleSel(b.id)}
                  onDelete={() => delBlock(b.id)}
                  onSave={(c) => saveContent(b, c)}
                />
              ))}
              {blocks.length === 0 && !blocksQ.isLoading && (
                <div className="text-sm text-muted-foreground p-2">Még nincs blokk. Adj hozzá egyet fent.</div>
              )}
              <EndDropZone />
            </div>
          </SortableContext>
        </DndContext>
        <TransferBlocksDialog
          open={transferOpen}
          onOpenChange={setTransferOpen}
          selectedIds={Array.from(selected)}
          sourcePageId={target.pageId}
          onDone={() => { setSelected(new Set()); invalidate(); onChanged(); }}
        />
      </CardContent>
    </Card>
  );
}

function EndDropZone() {
  const { setNodeRef, isOver } = useDroppable({ id: "visual-editor-end" });
  return (
    <div
      ref={setNodeRef}
      className={`rounded border-2 border-dashed p-3 text-center text-[11px] transition ${
        isOver ? "border-primary bg-primary/5 text-primary" : "border-border/60 text-muted-foreground"
      }`}
    >
      Húzz ide egy blokkot a palettáról
    </div>
  );
}

function AddBlockMenu({ onAdd }: { onAdd: (type: string) => void }) {
  const [type, setType] = useState<string>("");
  return (
    <div className="flex gap-2">
      <Select value={type} onValueChange={setType}>
        <SelectTrigger className="flex-1"><SelectValue placeholder="Blokk típusa…" /></SelectTrigger>
        <SelectContent>
          {BLOCK_CATALOG.filter((b) => !b.regions?.length).map((b) => (
            <SelectItem key={b.type} value={b.type}>{b.label}</SelectItem>
          ))}
        </SelectContent>
      </Select>
      <Button size="sm" disabled={!type} onClick={() => { onAdd(type); setType(""); }} className="gap-1">
        <Plus className="size-4" />Hozzáad
      </Button>
    </div>
  );
}

function SortableBlockRow({
  block, onDelete, onSave, selected, onToggleSelect,
}: { block: LayoutBlock; onDelete: () => void; onSave: (content: any) => Promise<void>; selected?: boolean; onToggleSelect?: () => void }) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: block.id });
  const style = { transform: CSS.Transform.toString(transform), transition, opacity: isDragging ? 0.5 : 1 };
  const meta = BLOCK_CATALOG.find((b) => b.type === block.block_type);
  const [open, setOpen] = useState(false);
  const [mode, setMode] = useState<"form" | "json">("form");
  const [text, setText] = useState(() => JSON.stringify(block.content ?? {}, null, 2));
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const tRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Autosave on text change (1.2s debounce)
  useEffect(() => {
    if (!open) return;
    if (tRef.current) clearTimeout(tRef.current);
    tRef.current = setTimeout(async () => {
      try {
        const parsed = JSON.parse(text);
        setErr(null); setSaving(true);
        await onSave(parsed);
      } catch (e: any) {
        setErr(e.message ?? "Hibás JSON");
      } finally {
        setSaving(false);
      }
    }, 1200);
    return () => { if (tRef.current) clearTimeout(tRef.current); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [text]);

  return (
    <div ref={setNodeRef} style={style} className="border rounded bg-card">
      <div className="flex items-center gap-1 p-2">
        {onToggleSelect && (
          <Checkbox checked={!!selected} onCheckedChange={onToggleSelect} aria-label="Kijelölés" />
        )}
        <button {...attributes} {...listeners} className="cursor-grab p-1" aria-label="Húzd a sorrend változtatásához">
          <GripVertical className="size-4 text-muted-foreground" />
        </button>
        <button onClick={() => setOpen((v) => !v)} className="flex-1 text-left">
          <div className="text-sm font-medium">{meta?.label ?? block.block_type}</div>
          <div className="text-[11px] text-muted-foreground">{block.block_type} · pos {block.position}</div>
        </button>
        {saving && <Loader2 className="size-3 animate-spin text-muted-foreground" />}
        <Button variant="ghost" size="icon" className="size-7" onClick={onDelete}>
          <Trash2 className="size-3.5" />
        </Button>
      </div>
      {open && (
        <div className="px-2 pb-2 space-y-2">
          <BlockLinkEditor
            content={(() => { try { return JSON.parse(text); } catch { return null; } })()}
            onChange={(next) => setText(JSON.stringify(next, null, 2))}
            locale={(block as any).locale ?? "hu"}
          />
          <Tabs value={mode} onValueChange={(v) => setMode(v as "form" | "json")}>
            <TabsList className="h-8">
              <TabsTrigger value="form" className="text-xs">WYSIWYG</TabsTrigger>
              <TabsTrigger value="json" className="text-xs">JSON</TabsTrigger>
            </TabsList>
          </Tabs>
          {mode === "form" ? (
            (() => {
              let parsed: Record<string, unknown> | null = null;
              try { parsed = JSON.parse(text); } catch { parsed = null; }
              if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
                return <div className="text-xs text-destructive">Hibás JSON — javítsd a JSON nézetben.</div>;
              }
              return (
                <BlockFormEditor
                  content={parsed}
                  blockType={block.block_type}
                  onChange={(next) => setText(JSON.stringify(next, null, 2))}
                />
              );
            })()
          ) : (
            <Textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              rows={10}
              className="font-mono text-xs"
            />
          )}
          {err && <div className="text-xs text-destructive">{err}</div>}
          <div className="flex items-center justify-between gap-2">
            <div className="text-[11px] text-muted-foreground flex items-center gap-1">
              <Save className="size-3" /> Automatikus mentés 1.2 mp után.
            </div>
            <AiGenerateButton
              blockType={block.block_type}
              onResult={(content) => setText(JSON.stringify(content, null, 2))}
            />
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Global region panel ─────────────────────────────────────────────────
function RegionPanel({
  regionKey, onChanged, qc,
}: { regionKey: RegionKey; onChanged: () => void; qc: ReturnType<typeof useQueryClient> }) {
  const listFn = useServerFn(listGlobalRegions);
  const saveFn = useServerFn(saveGlobalRegion);
  const regionsQ = useQuery({ queryKey: ["cms-global-regions"], queryFn: () => listFn() });
  const region = (regionsQ.data ?? []).find((r: any) => r.region_key === regionKey) as GlobalRegion | undefined;
  const blocks = region?.blocks ?? [];

  const [text, setText] = useState<string>("");
  useEffect(() => { setText(JSON.stringify(blocks, null, 2)); /* eslint-disable-next-line */ }, [regionsQ.data, regionKey]);

  const [err, setErr] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const tRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    if (tRef.current) clearTimeout(tRef.current);
    tRef.current = setTimeout(async () => {
      try {
        const parsed = JSON.parse(text);
        if (!Array.isArray(parsed)) throw new Error("Tömböt vártam");
        setErr(null); setSaving(true);
        await saveFn({ data: { region_key: regionKey, blocks: parsed } });
        qc.invalidateQueries({ queryKey: ["cms-global-regions"] });
        onChanged();
      } catch (e: any) {
        setErr(e.message ?? "Hibás JSON");
      } finally {
        setSaving(false);
      }
    }, 1500);
    return () => { if (tRef.current) clearTimeout(tRef.current); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [text]);

  const allowed = BLOCK_CATALOG.filter((b) => !b.regions || b.regions.includes(regionKey));

  return (
    <Card>
      <CardContent className="p-3 space-y-3">
        <div>
          <div className="text-xs font-semibold uppercase text-muted-foreground">Régió</div>
          <div className="text-sm font-medium">{REGION_META[regionKey].label}</div>
          <div className="text-xs text-muted-foreground">{REGION_META[regionKey].description}</div>
        </div>
        <div className="text-[11px] text-muted-foreground">
          Engedélyezett blokktípusok: {allowed.map((b) => b.type).join(", ") || "—"}
        </div>
        <Textarea value={text} onChange={(e) => setText(e.target.value)} rows={20} className="font-mono text-xs" />
        {err && <div className="text-xs text-destructive">{err}</div>}
        <div className="text-[11px] text-muted-foreground flex items-center gap-1">
          {saving ? <Loader2 className="size-3 animate-spin" /> : <Save className="size-3" />}
          Automatikus mentés 1.5 mp után.
        </div>
      </CardContent>
    </Card>
  );
}

// ─── Sablon-galéria gomb ─────────────────────────────────────────────────
function TemplateGalleryButton({
  onInsert,
}: { onInsert: (tpl: (typeof BLOCK_TEMPLATES)[number]) => void }) {
  const [open, setOpen] = useState(false);
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="w-full gap-1">
          <LayoutTemplate className="size-4" /> Sablonok galériája
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Blokk-sablonok</DialogTitle>
        </DialogHeader>
        <div className="grid sm:grid-cols-2 gap-2">
          {BLOCK_TEMPLATES.map((tpl) => (
            <button
              key={tpl.id}
              type="button"
              onClick={() => { onInsert(tpl); setOpen(false); toast.success(`Sablon beszúrva: ${tpl.label}`); }}
              className="text-left border rounded p-3 hover:bg-accent transition"
            >
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="text-[10px] uppercase">{tpl.category}</Badge>
                <span className="text-sm font-medium">{tpl.label}</span>
              </div>
              <div className="text-xs text-muted-foreground mt-1">{tpl.description}</div>
              <div className="text-[11px] text-muted-foreground mt-1 font-mono">{tpl.block_type}</div>
            </button>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ─── AI tartalom-generátor egy adott blokkhoz ────────────────────────────
function AiGenerateButton({
  blockType, onResult,
}: { blockType: string; onResult: (content: any) => void }) {
  const generateFn = useServerFn(generateBlockContent);
  const [open, setOpen] = useState(false);
  const [prompt, setPrompt] = useState("");
  const [busy, setBusy] = useState(false);

  const run = async () => {
    if (prompt.trim().length < 3) return;
    setBusy(true);
    try {
      const res: any = await generateFn({ data: { blockType, prompt, locale: "hu" } });
      onResult(res?.content ?? {});
      toast.success("AI tartalom beillesztve");
      setOpen(false);
      setPrompt("");
    } catch (e: any) {
      toast.error(e?.message ?? "AI hiba");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-1 h-7">
          <Sparkles className="size-3.5" /> AI írás
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Írj egy szekciót — {blockType}</DialogTitle>
        </DialogHeader>
        <div className="space-y-2">
          <div className="text-xs text-muted-foreground">
            Add meg, miről szóljon a blokk. Az AI a típusnak megfelelő JSON-t ad vissza, amit
            a szerkesztő automatikusan beilleszt és elmenti.
          </div>
          <Input
            placeholder="Pl. Kardiológiai szakambulancia, célközönség: 40+ férfiak"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter" && !busy) run(); }}
          />
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => setOpen(false)} disabled={busy}>Mégse</Button>
          <Button onClick={run} disabled={busy || prompt.trim().length < 3} className="gap-1">
            {busy ? <Loader2 className="size-4 animate-spin" /> : <Sparkles className="size-4" />}
            Generálás
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ─── AI „write me a page" — több blokkot egyszerre szúr be ──────────────
function AiPageDraftButton({
  pageId, startPosition, onDone,
}: { pageId: string; startPosition: number; onDone: () => void }) {
  const draftFn = useServerFn(generatePageDraft);
  const upsertFn = useServerFn(upsertLayoutBlock);
  const [open, setOpen] = useState(false);
  const [prompt, setPrompt] = useState("");
  const [maxBlocks, setMaxBlocks] = useState(6);
  const [busy, setBusy] = useState(false);

  // Csak oldal-szintű (nem régió-specifikus) típusokat engedünk.
  const allowedTypes = useMemo(
    () => BLOCK_CATALOG.filter((b) => !b.regions || b.regions.length === 0).map((b) => b.type),
    [],
  );

  const run = async () => {
    if (prompt.trim().length < 3) return;
    setBusy(true);
    try {
      const res: any = await draftFn({
        data: { prompt, locale: "hu", allowedTypes, maxBlocks },
      });
      const blocks: Array<{ block_type: string; content: any }> = res?.blocks ?? [];
      let pos = startPosition;
      for (const b of blocks) {
        await upsertFn({
          data: {
            page_id: pageId, region_key: null,
            position: pos++, block_type: b.block_type,
            content: b.content ?? {}, style: {}, locale: "hu", status: "published",
          } as any,
        });
      }
      toast.success(`${blocks.length} blokk hozzáadva`);
      setOpen(false); setPrompt("");
      onDone();
    } catch (e: any) {
      toast.error(e?.message ?? "AI hiba");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="w-full gap-1">
          <Sparkles className="size-3.5" /> AI: teljes oldal-vázlat
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Generálj egy komplett aloldalt</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="text-xs text-muted-foreground">
            Add meg, miről szóljon az oldal. Az AI több, egymásra épülő szekciót generál
            (hero → bemutatás → részletek → CTA), és sorban beilleszti őket.
          </div>
          <Textarea
            placeholder="Pl. Diabétesz centrum aloldal — bemutatkozás, szolgáltatások, csapat, GYIK, kapcsolat."
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            rows={4}
          />
          <div className="flex items-center gap-2 text-xs">
            <label className="text-muted-foreground">Max. blokk:</label>
            <Input
              type="number" min={2} max={12}
              value={maxBlocks}
              onChange={(e) => setMaxBlocks(Math.max(2, Math.min(12, Number(e.target.value) || 6)))}
              className="w-20 h-8"
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => setOpen(false)} disabled={busy}>Mégse</Button>
          <Button onClick={run} disabled={busy || prompt.trim().length < 3} className="gap-1">
            {busy ? <Loader2 className="size-4 animate-spin" /> : <Sparkles className="size-4" />}
            Generálás
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
