/**
 * Egységes WYSIWYG szerkesztő (kompatibilitási wrapper).
 *
 * A korábbi külön TipTap példány helyett a közös RichTextEditor motort
 * használja, így minden szerkesztőben ugyanaz a képességkészlet érhető el:
 * kép (médiatár + drag&drop/paste feltöltés, átméretezés, igazítás),
 * táblázat, videó/GIF, beágyazások (YouTube, TikTok, Instagram, X, térkép),
 * linkek és HTML forrás nézet.
 */
import { RichTextEditor } from "@/components/cms/visual/rich-text-editor";

interface TiptapEditorProps {
  value: string;
  onChange: (html: string) => void;
  placeholder?: string;
  /** @deprecated a médiatár közvetlenül a szerkesztő eszköztárából érhető el */
  onInsertMedia?: () => Promise<string | null>;
  minRows?: number;
}

export function TiptapEditor({ value, onChange, placeholder, minRows = 12 }: TiptapEditorProps) {
  return (
    <RichTextEditor
      value={value}
      onChange={onChange}
      placeholder={placeholder ?? "Kezdj el írni…"}
      minRows={minRows}
    />
  );
}
