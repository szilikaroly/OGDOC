/**
 * Admin-only debug overlay: az aktuális oldalon melyik CMS blokk melyik
 * A/B kísérlet-variantot kapta. Csak akkor jelenik meg, ha:
 *   - a URL-ben `?expdebug=1` szerepel (vagy sessionStorage.expdebug === "1"), ÉS
 *   - a bejelentkezett usernek van `manage_tenant` jogosultsága (admin).
 *
 * Bejegyzéseket a `useExperiment` hook publikál a debug store-ba.
 */
import { useEffect, useMemo, useState } from "react";
import { X, FlaskConical, Copy, ChevronDown, ChevronUp } from "lucide-react";
import { usePermissions } from "@/hooks/use-permissions";
import { useExperimentDebugEntries } from "@/lib/cms/experiment-debug";
import { toast } from "sonner";

function useDebugEnabled(): [boolean, (v: boolean) => void] {
  const [on, setOn] = useState(false);
  useEffect(() => {
    if (typeof window === "undefined") return;
    const check = () => {
      const p = new URLSearchParams(window.location.search);
      const fromUrl = p.get("expdebug") === "1";
      const fromStorage = window.sessionStorage.getItem("expdebug") === "1";
      if (fromUrl) window.sessionStorage.setItem("expdebug", "1");
      setOn(fromUrl || fromStorage);
    };
    check();
    window.addEventListener("popstate", check);
    return () => window.removeEventListener("popstate", check);
  }, []);
  const setter = (v: boolean) => {
    if (typeof window === "undefined") return;
    if (v) window.sessionStorage.setItem("expdebug", "1");
    else window.sessionStorage.removeItem("expdebug");
    setOn(v);
  };
  return [on, setter];
}

export function ExperimentDebugOverlay() {
  const { canReal, loading: permLoading } = usePermissions();
  const [enabled, setEnabled] = useDebugEnabled();
  const [minimized, setMinimized] = useState(false);
  const entries = useExperimentDebugEntries();

  const isAdmin = !permLoading && canReal("manage_tenant");
  const visible = enabled && isAdmin;

  const grouped = useMemo(() => {
    const byBlock = new Map<string, typeof entries>();
    for (const e of entries) {
      const arr = byBlock.get(e.blockId) ?? [];
      arr.push(e);
      byBlock.set(e.blockId, arr);
    }
    return Array.from(byBlock.entries());
  }, [entries]);

  if (!visible) return null;

  const copyAll = async () => {
    const payload = entries.map((e) => ({
      block: `${e.blockKind}:${e.blockId}`,
      block_type: e.blockType,
      experiment: e.experimentName ?? e.experimentId,
      variant: e.variantKey,
    }));
    try {
      await navigator.clipboard.writeText(JSON.stringify(payload, null, 2));
      toast.success("Debug JSON másolva");
    } catch {
      toast.error("Másolás sikertelen");
    }
  };

  return (
    <div
      className="fixed z-[9999] bottom-3 right-3 max-w-[380px] w-[calc(100vw-1.5rem)] rounded-lg border border-border bg-background shadow-2xl text-xs"
      role="complementary"
      aria-label="A/B kísérlet debug"
    >
      <div className="flex items-center gap-2 px-3 py-2 border-b border-border bg-muted/40 rounded-t-lg">
        <FlaskConical className="h-3.5 w-3.5 text-primary" />
        <div className="font-semibold flex-1">A/B debug · {entries.length}</div>
        <button
          onClick={() => setMinimized((m) => !m)}
          className="p-1 rounded hover:bg-accent"
          aria-label={minimized ? "Kinyitás" : "Összecsukás"}
        >
          {minimized ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
        </button>
        <button
          onClick={copyAll}
          className="p-1 rounded hover:bg-accent"
          aria-label="JSON másolása"
          title="JSON másolása"
        >
          <Copy className="h-3.5 w-3.5" />
        </button>
        <button
          onClick={() => setEnabled(false)}
          className="p-1 rounded hover:bg-accent"
          aria-label="Bezárás"
          title="Bezárás (session-re)"
        >
          <X className="h-3.5 w-3.5" />
        </button>
      </div>

      {!minimized && (
        <div className="max-h-[50vh] overflow-y-auto p-2 space-y-2">
          {entries.length === 0 ? (
            <p className="text-muted-foreground italic px-1 py-2">
              Ezen az oldalon nincs aktív A/B kísérlet.
            </p>
          ) : (
            grouped.map(([blockId, list]) => (
              <div key={blockId} className="border border-border rounded p-2 bg-card">
                <div className="font-mono text-[10px] text-muted-foreground truncate" title={blockId}>
                  {list[0]?.blockKind === "layout_block" ? "layout" : "block"}
                  {list[0]?.blockType ? ` · ${list[0].blockType}` : ""}
                  {list[0]?.blockLabel ? ` · ${list[0].blockLabel}` : ""}
                </div>
                <div className="font-mono text-[10px] text-muted-foreground/70 truncate mb-1">{blockId}</div>
                <ul className="space-y-1">
                  {list.map((e) => (
                    <li key={e.key} className="flex items-center gap-2">
                      <span
                        className={
                          "inline-flex items-center rounded px-1.5 py-0.5 text-[10px] font-semibold " +
                          (e.isControl
                            ? "bg-muted text-foreground"
                            : "bg-primary/15 text-primary")
                        }
                      >
                        {e.variantKey}{e.isControl ? " (control)" : ""}
                      </span>
                      <span className="truncate" title={e.experimentName ?? e.experimentId}>
                        {e.experimentName ?? e.experimentId}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            ))
          )}
        </div>
      )}

      <div className="px-3 py-1.5 border-t border-border text-[10px] text-muted-foreground rounded-b-lg">
        <code>?expdebug=1</code> · session-scope · csak admin
      </div>
    </div>
  );
}
