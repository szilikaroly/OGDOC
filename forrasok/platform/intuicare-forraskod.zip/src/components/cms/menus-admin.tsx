import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { listMenus, getMenuItems, saveMenuItem, deleteMenuItem } from "@/lib/cms/cms.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Plus, Trash2, Pencil, ExternalLink } from "lucide-react";
import { toast } from "sonner";
import { LinkPicker } from "./link-picker";
import { ListSkeleton } from "@/components/ui/list-skeletons";
import { haptic } from "@/lib/query/optimistic";

export function MenusAdmin() {
  const listMenusFn = useServerFn(listMenus);
  const { data: menus = [], isLoading } = useQuery({ queryKey: ["cms-menus"], queryFn: () => listMenusFn() });
  const [selected, setSelected] = useState<string | null>(null);

  return (
    <div className="space-y-4 mt-4">
      <div className="grid grid-cols-[auto_minmax(0,1fr)] items-center gap-2">
        <Label className="shrink-0">Menü:</Label>
        <Select value={selected ?? ""} onValueChange={setSelected}>
          <SelectTrigger className="min-h-11 w-full sm:w-64"><SelectValue placeholder="Válassz menüt..." /></SelectTrigger>
          <SelectContent>
            {menus.map((m: any) => <SelectItem key={m.id} value={m.id}>{m.name} ({m.key})</SelectItem>)}
          </SelectContent>
        </Select>
      </div>
      {isLoading && <ListSkeleton rows={3} />}
      {selected && <MenuItemsList menuId={selected} />}
    </div>
  );
}

function MenuItemsList({ menuId }: { menuId: string }) {
  const qc = useQueryClient();
  const itemsFn = useServerFn(getMenuItems);
  const saveFn = useServerFn(saveMenuItem);
  const delFn = useServerFn(deleteMenuItem);
  const { data: items = [], isLoading } = useQuery({ queryKey: ["menu-items", menuId], queryFn: () => itemsFn({ data: { menuId } }) });
  const [editing, setEditing] = useState<any>(null);

  const newItem = () => setEditing({ menu_id: menuId, label: "", url: "", locale: "hu", position: items.length, open_in_new_tab: false });

  const save = async (it: any) => {
    try {
      await saveFn({ data: it });
      setEditing(null);
      qc.invalidateQueries({ queryKey: ["menu-items", menuId] });
      toast.success("Mentve");
    } catch (e: any) { toast.error(e.message); }
  };

  const remove = async (id: string) => {
    if (!confirm("Törlöd?")) return;
    try {
      await delFn({ data: { id } });
      qc.invalidateQueries({ queryKey: ["menu-items", menuId] });
      toast.success("Törölve");
    } catch (e: any) { toast.error(e.message); }
  };

  return (
    <div className="space-y-2">
      <div className="flex justify-end">
        <Button onClick={() => { haptic(8); newItem(); }} className="min-h-11" aria-label="Új menüpont">
          <Plus className="h-4 w-4 sm:mr-1" /><span className="hidden sm:inline">Új menüpont</span>
        </Button>
      </div>
      {isLoading ? <ListSkeleton rows={4} /> : (
        <div className="space-y-2" style={{ contentVisibility: "auto" as any, containIntrinsicSize: "500px" as any }}>
          {items.map((it: any) => (
            <Card key={it.id} className="p-3 grid grid-cols-[minmax(0,1fr)_auto] items-center gap-2">
              <div className="min-w-0">
                <div className="font-medium truncate">{it.label}</div>
                <div className="text-xs text-muted-foreground truncate flex items-center gap-1">
                  <span className="truncate">{it.url || (it.page_id ? "→ aloldal" : "")}</span>
                  <Badge variant="outline" className="text-[10px] shrink-0">{it.locale}</Badge>
                  {it.open_in_new_tab && <ExternalLink className="h-3 w-3 text-muted-foreground shrink-0" />}
                </div>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                <Button size="icon" variant="ghost" className="min-h-11 min-w-11" onClick={() => setEditing(it)} aria-label="Szerkeszt"><Pencil className="h-4 w-4" /></Button>
                <Button size="icon" variant="ghost" className="min-h-11 min-w-11" onClick={() => remove(it.id)} aria-label="Törlés"><Trash2 className="h-4 w-4 text-destructive" /></Button>
              </div>
            </Card>
          ))}
          {!items.length && <div className="text-sm text-muted-foreground p-4 text-center">Még nincs menüpont.</div>}
        </div>
      )}
      {editing && (
        <Dialog open onOpenChange={() => setEditing(null)}>
          <DialogContent className="max-w-lg max-h-[92vh] overflow-y-auto">
            <DialogHeader><DialogTitle>Menüpont</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div><Label>Felirat</Label><Input className="min-h-11" value={editing.label} onChange={e => setEditing({ ...editing, label: e.target.value })} /></div>
              <LinkPicker
                value={{ url: editing.url, page_id: editing.page_id, open_in_new_tab: editing.open_in_new_tab }}
                onChange={v => setEditing({ ...editing, url: v.url ?? null, page_id: v.page_id ?? null, open_in_new_tab: !!v.open_in_new_tab })}
                locale={editing.locale}
              />
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Pozíció</Label><Input className="min-h-11" type="number" inputMode="numeric" value={editing.position} onChange={e => setEditing({ ...editing, position: parseInt(e.target.value) || 0 })} /></div>
                <div><Label>Nyelv</Label><Input className="min-h-11" value={editing.locale} onChange={e => setEditing({ ...editing, locale: e.target.value })} autoCapitalize="none" /></div>
              </div>
            </div>
            <DialogFooter className="flex-col-reverse sm:flex-row gap-2">
              <Button variant="ghost" className="min-h-11 w-full sm:w-auto" onClick={() => setEditing(null)}>Mégse</Button>
              <Button className="min-h-11 w-full sm:w-auto" onClick={() => { haptic(8); save(editing); }}>Mentés</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
