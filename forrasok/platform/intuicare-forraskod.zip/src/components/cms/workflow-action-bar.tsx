import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  submitForReview, approveContent, rejectContent,
  publishContent, unpublishContent, type WorkflowEntity,
} from "@/lib/cms/workflow.functions";
import { Button } from "@/components/ui/button";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Send, CheckCircle2, XCircle, Globe, EyeOff } from "lucide-react";

interface Props {
  entity_type: WorkflowEntity;
  entity_id: string;
  state?: string | null;
  /** Ha a felhasználó jogosultsága ismert (klienssel jött): szűrhetők a gombok. Ha hiányzik, mindet mutatjuk. */
  capabilities?: { editor?: boolean; reviewer?: boolean; publisher?: boolean };
  onChanged?: () => void;
}

export function WorkflowActionBar({ entity_type, entity_id, state, capabilities, onChanged }: Props) {
  const qc = useQueryClient();
  const submitFn = useServerFn(submitForReview);
  const approveFn = useServerFn(approveContent);
  const rejectFn = useServerFn(rejectContent);
  const publishFn = useServerFn(publishContent);
  const unpublishFn = useServerFn(unpublishContent);

  const [rejectOpen, setRejectOpen] = useState(false);
  const [rejectReason, setRejectReason] = useState("");

  const mut = (fn: (input: any) => Promise<any>, action: string) =>
    useMutation({
      mutationFn: (input: any) => fn(input),
      onSuccess: () => {
        toast.success(`${action} ✓`);
        qc.invalidateQueries();
        onChanged?.();
      },
      onError: (e: any) => toast.error(e?.message ?? "Hiba"),
    });

  const submitM = mut(submitFn, "Beküldve véleményezésre");
  const approveM = mut(approveFn, "Jóváhagyva");
  const rejectM = mut(rejectFn, "Elutasítva");
  const publishM = mut(publishFn, "Publikálva");
  const unpublishM = mut(unpublishFn, "Visszavonva");

  const canEditor = capabilities?.editor ?? true;
  const canReviewer = capabilities?.reviewer ?? true;
  const canPublisher = capabilities?.publisher ?? true;

  const s = (state ?? "draft");

  return (
    <div className="flex flex-wrap items-center gap-2">
      {(s === "draft" || s === "rejected") && canEditor && (
        <Button size="sm" variant="secondary" className="min-h-9 gap-1.5"
          disabled={submitM.isPending}
          onClick={() => submitM.mutate({ data: { entity_type, entity_id } })}>
          <Send className="h-3.5 w-3.5" /> Beküldés véleményezésre
        </Button>
      )}

      {s === "in_review" && canReviewer && (
        <>
          <Button size="sm" variant="default" className="min-h-9 gap-1.5"
            disabled={approveM.isPending}
            onClick={() => approveM.mutate({ data: { entity_type, entity_id } })}>
            <CheckCircle2 className="h-3.5 w-3.5" /> Jóváhagyás
          </Button>
          <Button size="sm" variant="destructive" className="min-h-9 gap-1.5"
            onClick={() => setRejectOpen(true)}>
            <XCircle className="h-3.5 w-3.5" /> Elutasítás
          </Button>
        </>
      )}

      {(s === "approved" || s === "in_review") && canPublisher && (
        <Button size="sm" variant="default" className="min-h-9 gap-1.5"
          disabled={publishM.isPending}
          onClick={() => publishM.mutate({ data: { entity_type, entity_id } })}>
          <Globe className="h-3.5 w-3.5" /> Publikálás
        </Button>
      )}

      {s === "published" && canPublisher && (
        <Button size="sm" variant="outline" className="min-h-9 gap-1.5"
          disabled={unpublishM.isPending}
          onClick={() => unpublishM.mutate({ data: { entity_type, entity_id } })}>
          <EyeOff className="h-3.5 w-3.5" /> Visszavonás
        </Button>
      )}

      <Dialog open={rejectOpen} onOpenChange={setRejectOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Elutasítás indoka</DialogTitle>
          </DialogHeader>
          <Textarea value={rejectReason} onChange={(e) => setRejectReason(e.target.value)}
            placeholder="Mi a probléma a tartalommal? Mit kell javítani?" rows={5} />
          <DialogFooter>
            <Button variant="outline" onClick={() => setRejectOpen(false)}>Mégse</Button>
            <Button variant="destructive"
              disabled={rejectReason.trim().length < 2 || rejectM.isPending}
              onClick={() => {
                rejectM.mutate(
                  { data: { entity_type, entity_id, reason: rejectReason.trim() } },
                  { onSuccess: () => { setRejectOpen(false); setRejectReason(""); } },
                );
              }}>
              Elutasítás küldése
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
