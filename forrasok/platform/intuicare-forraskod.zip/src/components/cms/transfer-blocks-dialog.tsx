import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { listPages } from "@/lib/cms/cms.functions";
import { transferBlocks } from "@/lib/cms/layout-blocks.functions";
import { toast } from "sonner";
import { Copy, ArrowRightLeft } from "lucide-react";

type Props = {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  selectedIds: string[];
  sourcePageId: string;
  onDone: () => void;
};

export function TransferBlocksDialog({ open, onOpenChange, selectedIds, sourcePageId, onDone }: Props) {
  const pagesFn = useServerFn(listPages);
  const transferFn = useServerFn(transferBlocks);
  const { data: pages = [] } = useQuery({ queryKey: ["cms-pages-transfer"], queryFn: () => pagesFn(), enabled: open });

  const [target, setTarget] = useState<string>("");
  const [mode, setMode] = useState<"copy" | "move">("copy");
  const [busy, setBusy] = useState(false);

  const others = (pages as any[]).filter(p => p.id !== sourcePageId);

  const submit = async () => {
    if (!target) return;
    setBusy(true);
    try {
      const res = await transferFn({ data: { blockIds: selectedIds, targetPageId: target, mode } });
      toast.success(`${res.inserted} blokk ${mode === "copy" ? "másolva" : "áthelyezve"}`);
      onOpenChange(false);
      onDone();
    } catch (e: any) {
      toast.error(e.message ?? "Sikertelen művelet");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{selectedIds.length} blokk áthelyezése / másolása</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div>
            <Label className="text-xs">Cél-oldal</Label>
            <Select value={target} onValueChange={setTarget}>
              <SelectTrigger><SelectValue placeholder="Válassz oldalt…" /></SelectTrigger>
              <SelectContent>
                {others.map(p => (
                  <SelectItem key={p.id} value={p.id}>{p.title} · /{p.slug} ({p.locale})</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">Művelet</Label>
            <RadioGroup value={mode} onValueChange={(v) => setMode(v as "copy" | "move")} className="mt-1">
              <div className="flex items-center gap-2 border rounded p-2">
                <RadioGroupItem value="copy" id="m-copy" />
                <Label htmlFor="m-copy" className="flex items-center gap-1 cursor-pointer">
                  <Copy className="h-3.5 w-3.5" /> Másolás (az eredeti marad)
                </Label>
              </div>
              <div className="flex items-center gap-2 border rounded p-2">
                <RadioGroupItem value="move" id="m-move" />
                <Label htmlFor="m-move" className="flex items-center gap-1 cursor-pointer">
                  <ArrowRightLeft className="h-3.5 w-3.5" /> Áthelyezés (eredeti törlődik)
                </Label>
              </div>
            </RadioGroup>
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)} disabled={busy}>Mégse</Button>
          <Button onClick={submit} disabled={!target || busy}>
            {busy ? "Folyamatban…" : "Végrehajtás"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
