import { useMemo, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { listPages } from "@/lib/cms/cms.functions";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Search, Link as LinkIcon, FileText, Hash, Mail, Phone, ExternalLink } from "lucide-react";

export type LinkPickerValue = {
  url?: string | null;
  page_id?: string | null;
  open_in_new_tab?: boolean;
};

type Props = {
  value: LinkPickerValue;
  onChange: (v: LinkPickerValue) => void;
  locale?: string;
  showNewTab?: boolean;
  className?: string;
};

/**
 * Újrahasználható link-választó: külső URL / CMS aloldal / horgony / mailto / tel.
 * Bárhol használható (menük, blokk-szerkesztő, CTA, FAQ stb.).
 */
export function LinkPicker({ value, onChange, locale, showNewTab = true, className }: Props) {
  const pagesFn = useServerFn(listPages);
  const { data: pages = [] } = useQuery({ queryKey: ["cms-pages-picker"], queryFn: () => pagesFn() });
  const [search, setSearch] = useState("");

  const initialTab = useMemo(() => {
    if (value.page_id) return "page";
    const u = value.url ?? "";
    if (u.startsWith("mailto:")) return "mail";
    if (u.startsWith("tel:")) return "tel";
    if (u.startsWith("#")) return "anchor";
    return "url";
  }, [value.page_id, value.url]);

  const filteredPages = useMemo(() => {
    const list = (pages as any[]).filter(p => !locale || p.locale === locale);
    if (!search.trim()) return list.slice(0, 50);
    const q = search.toLowerCase();
    return list.filter(p => p.title?.toLowerCase().includes(q) || p.slug?.toLowerCase().includes(q)).slice(0, 50);
  }, [pages, search, locale]);

  const setUrl = (url: string) => onChange({ ...value, url, page_id: null });
  const setPage = (id: string | null) => onChange({ ...value, page_id: id, url: null });

  const validation = useMemo(() => {
    if (value.page_id) return null;
    const u = (value.url ?? "").trim();
    if (!u) return null;
    if (u.startsWith("http://") || u.startsWith("https://")) {
      try { new URL(u); return { ok: true, label: "Külső URL" }; }
      catch { return { ok: false, label: "Érvénytelen URL" }; }
    }
    if (u.startsWith("/")) return { ok: true, label: "Belső útvonal" };
    if (u.startsWith("mailto:")) return { ok: u.length > 7, label: "E-mail" };
    if (u.startsWith("tel:")) return { ok: u.length > 4, label: "Telefon" };
    if (u.startsWith("#")) return { ok: true, label: "Horgony" };
    return { ok: false, label: "Adj meg /, http(s)://, mailto:, tel: vagy # kezdetű értéket" };
  }, [value.url, value.page_id]);

  return (
    <div className={className}>
      <Tabs defaultValue={initialTab}>
        <TabsList className="grid grid-cols-5 w-full">
          <TabsTrigger value="url"><LinkIcon className="h-3 w-3 mr-1" />URL</TabsTrigger>
          <TabsTrigger value="page"><FileText className="h-3 w-3 mr-1" />Aloldal</TabsTrigger>
          <TabsTrigger value="anchor"><Hash className="h-3 w-3 mr-1" />Horgony</TabsTrigger>
          <TabsTrigger value="mail"><Mail className="h-3 w-3 mr-1" />E-mail</TabsTrigger>
          <TabsTrigger value="tel"><Phone className="h-3 w-3 mr-1" />Tel</TabsTrigger>
        </TabsList>

        <TabsContent value="url" className="space-y-2 mt-3">
          <Label>URL (külső vagy belső, pl. /o/bemutatkozas)</Label>
          <Input
            value={value.url ?? ""}
            onChange={e => setUrl(e.target.value)}
            placeholder="https://example.com vagy /o/oldal"
          />
        </TabsContent>

        <TabsContent value="page" className="space-y-2 mt-3">
          <div className="relative">
            <Search className="h-4 w-4 absolute left-2 top-2.5 text-muted-foreground" />
            <Input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Keresés cím vagy slug alapján..."
              className="pl-8"
            />
          </div>
          <div className="max-h-60 overflow-y-auto border rounded-md divide-y">
            {filteredPages.length === 0 && (
              <div className="p-3 text-sm text-muted-foreground">Nincs találat</div>
            )}
            {filteredPages.map((p: any) => (
              <button
                key={p.id}
                type="button"
                onClick={() => setPage(p.id)}
                className={`w-full text-left p-2 min-h-11 hover:bg-accent flex items-center justify-between gap-2 ${value.page_id === p.id ? "bg-accent" : ""}`}
              >
                <div className="min-w-0">
                  <div className="font-medium text-sm truncate">{p.title}</div>
                  <div className="text-xs text-muted-foreground truncate">/o/{p.slug} · {p.locale}</div>
                </div>
                {p.status && <Badge variant="outline" className="shrink-0">{p.status}</Badge>}
              </button>
            ))}
          </div>
          {value.page_id && (
            <Button type="button" size="sm" variant="ghost" onClick={() => setPage(null)}>
              Kiválasztás törlése
            </Button>
          )}
        </TabsContent>

        <TabsContent value="anchor" className="space-y-2 mt-3">
          <Label>Horgony (# kezdjen)</Label>
          <Input
            value={value.url?.startsWith("#") ? value.url : ""}
            onChange={e => setUrl(e.target.value.startsWith("#") ? e.target.value : `#${e.target.value}`)}
            placeholder="#szekcio-id"
          />
        </TabsContent>

        <TabsContent value="mail" className="space-y-2 mt-3">
          <Label>E-mail cím</Label>
          <Input
            type="email"
            value={value.url?.replace(/^mailto:/, "") ?? ""}
            onChange={e => setUrl(e.target.value ? `mailto:${e.target.value}` : "")}
            placeholder="info@example.com"
          />
        </TabsContent>

        <TabsContent value="tel" className="space-y-2 mt-3">
          <Label>Telefonszám</Label>
          <Input
            type="tel"
            value={value.url?.replace(/^tel:/, "") ?? ""}
            onChange={e => setUrl(e.target.value ? `tel:${e.target.value.replace(/\s+/g, "")}` : "")}
            placeholder="+36 1 234 5678"
          />
        </TabsContent>
      </Tabs>

      {validation && (
        <div className={`text-xs mt-2 flex items-center gap-1 ${validation.ok ? "text-muted-foreground" : "text-destructive"}`}>
          <ExternalLink className="h-3 w-3" />
          {validation.label}
        </div>
      )}

      {showNewTab && (
        <div className="flex items-center gap-2 mt-3">
          <Switch
            checked={!!value.open_in_new_tab}
            onCheckedChange={v => onChange({ ...value, open_in_new_tab: v })}
          />
          <Label className="cursor-pointer">Új lapon nyíljon</Label>
        </div>
      )}
    </div>
  );
}
