import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  adminListPosts, adminGetPost, adminUpsertPost, adminDeletePost,
  adminListCategories, adminUpsertCategory, adminDeleteCategory,
  adminListTags, adminUpsertTag, adminDeleteTag,
  adminListAuthors, adminUpsertAuthor, adminDeleteAuthor,
  adminFetchVideoMeta,
} from "@/lib/cms/news.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Trash2, Edit, ExternalLink, Link2 } from "lucide-react";
import { ListSkeleton } from "@/components/ui/list-skeletons";
import { toast } from "sonner";
import { TiptapEditor } from "./tiptap-editor";
import { NewsLivePreview } from "./news-live-preview";
import { MediaPicker } from "./media-picker";
import { ImageIcon } from "lucide-react";

function slugify(s: string) {
  return s.toLowerCase()
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9\s-]/g, "")
    .trim().replace(/\s+/g, "-").replace(/-+/g, "-");
}

export function NewsAdmin() {
  return (
    <Tabs defaultValue="posts" className="mt-4">
      <TabsList>
        <TabsTrigger value="posts" className="min-h-11">Hírek</TabsTrigger>
        <TabsTrigger value="categories" className="min-h-11">Kategóriák</TabsTrigger>
        <TabsTrigger value="tags" className="min-h-11">Címkék</TabsTrigger>
        <TabsTrigger value="authors" className="min-h-11">Szerzők</TabsTrigger>
      </TabsList>
      <TabsContent value="posts"><PostsTab /></TabsContent>
      <TabsContent value="categories"><CategoriesTab /></TabsContent>
      <TabsContent value="tags"><TagsTab /></TabsContent>
      <TabsContent value="authors"><AuthorsTab /></TabsContent>
    </Tabs>
  );
}

// ---------------- Posts ----------------
function PostsTab() {
  const qc = useQueryClient();
  const listFn = useServerFn(adminListPosts);
  const getFn = useServerFn(adminGetPost);
  const saveFn = useServerFn(adminUpsertPost);
  const delFn = useServerFn(adminDeletePost);
  const catsFn = useServerFn(adminListCategories);
  const tagsFn = useServerFn(adminListTags);
  const authorsFn = useServerFn(adminListAuthors);
  const fetchVideoMetaFn = useServerFn(adminFetchVideoMeta);
  const [videoMetaLoading, setVideoMetaLoading] = useState(false);

  const { data: posts = [], isLoading } = useQuery({ queryKey: ["adm-news-posts"], queryFn: () => listFn() });
  const { data: cats = [] } = useQuery({ queryKey: ["adm-news-cats"], queryFn: () => catsFn() });
  const { data: tags = [] } = useQuery({ queryKey: ["adm-news-tags"], queryFn: () => tagsFn() });
  const { data: authors = [] } = useQuery({ queryKey: ["adm-news-authors"], queryFn: () => authorsFn() });

  const [editing, setEditing] = useState<any>(null);
  const [loadingEdit, setLoadingEdit] = useState(false);

  const openNew = () => setEditing({
    slug: "", locale: "hu", title: "", excerpt: "", body_html: "",
    featured_image_url: "", featured_image_alt: "",
    author_id: null, category_id: null,
    status: "draft", published_at: "",
    seo_title: "", seo_description: "", og_image_url: "",
    tag_ids: [],
    post_type: "blog",
    video_provider: null, video_url: "", video_embed_url: "",
    video_thumbnail_url: "", video_duration_seconds: null,
    video_width: null, video_height: null, video_transcript: "",
  });

  const openEdit = async (id: string) => {
    setLoadingEdit(true);
    try {
      const p: any = await getFn({ data: { id } });
      setEditing({
        ...p,
        body_html: (p.body as any)?.html ?? "",
        published_at: p.published_at ? new Date(p.published_at).toISOString().slice(0, 16) : "",
        tag_ids: (p.cms_news_post_tags ?? []).map((t: any) => t.tag_id),
        post_type: p.post_type ?? "blog",
      });
    } catch (e: any) { toast.error(e.message); }
    finally { setLoadingEdit(false); }
  };


  const save = async () => {
    try {
      const payload: any = { ...editing };
      if (!payload.slug && payload.title) payload.slug = slugify(payload.title);
      if (payload.published_at) payload.published_at = new Date(payload.published_at).toISOString();
      else payload.published_at = null;
      // strip joined fields
      delete payload.cms_news_post_tags; delete payload.cms_news_categories; delete payload.cms_news_authors;
      delete payload.body; delete payload.created_by; delete payload.updated_by;
      delete payload.created_at; delete payload.updated_at; delete payload.view_count;
      await saveFn({ data: payload });
      toast.success("Mentve");
      setEditing(null);
      qc.invalidateQueries({ queryKey: ["adm-news-posts"] });
    } catch (e: any) { toast.error(e.message); }
  };

  const remove = async (id: string) => {
    if (!confirm("Biztosan törlöd?")) return;
    try { await delFn({ data: { id } }); toast.success("Törölve"); qc.invalidateQueries({ queryKey: ["adm-news-posts"] }); }
    catch (e: any) { toast.error(e.message); }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="font-semibold">Hírek ({posts.length})</h2>
        <Button onClick={openNew} className="min-h-11"><Plus className="h-4 w-4 mr-1" /> Új hír</Button>
      </div>
      {isLoading ? <ListSkeleton rows={6} /> : (
        <div className="space-y-2">
          {posts.map((p: any) => (
            <Card key={p.id} className="p-3 flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-medium truncate">{p.title}</span>
                  <Badge variant={p.post_type === "vlog" ? "default" : "outline"} className="text-xs uppercase">
                    {p.post_type === "vlog" ? "Vlog" : "Blog"}
                  </Badge>
                  <Badge variant={p.status === "published" ? "default" : p.status === "scheduled" ? "secondary" : "outline"} className="text-xs">{p.status}</Badge>
                </div>
                <div className="text-xs text-muted-foreground truncate">
                  /{p.post_type === "vlog" ? "vlog" : "blog"}/{p.slug} · {p.cms_news_categories?.name ?? "—"} · {p.cms_news_authors?.display_name ?? "—"} · {p.published_at ? new Date(p.published_at).toLocaleString("hu-HU") : "—"}
                </div>
              </div>
              <div className="flex gap-1 shrink-0">
                {p.status === "published" && (
                  <Button asChild variant="ghost" size="icon" className="min-h-11 min-w-11" title="Publikus oldal megnyitása">
                    <a href={`/${p.post_type === "vlog" ? "vlog" : "blog"}/${p.slug}`} target="_blank" rel="noreferrer"><ExternalLink className="h-4 w-4" /></a>
                  </Button>
                )}
                {p.preview_token && (
                  <Button
                    variant="ghost"
                    size="icon"
                    className="min-h-11 min-w-11"
                    title="Vázlat előnézeti link másolása"
                    onClick={async () => {
                      const path = `/${p.post_type === "vlog" ? "vlog" : "blog"}/${p.slug}?preview=${p.preview_token}`;
                      const url = typeof window !== "undefined" ? `${window.location.origin}${path}` : path;
                      try {
                        await navigator.clipboard.writeText(url);
                        toast.success("Előnézeti link a vágólapra másolva", { description: url });
                      } catch {
                        toast.error("Nem sikerült a vágólapra másolni", { description: url });
                      }
                    }}
                  ><Link2 className="h-4 w-4" /></Button>
                )}
                <Button variant="ghost" size="icon" className="min-h-11 min-w-11" onClick={() => openEdit(p.id)}><Edit className="h-4 w-4" /></Button>
                <Button variant="ghost" size="icon" className="min-h-11 min-w-11 text-destructive" onClick={() => remove(p.id)}><Trash2 className="h-4 w-4" /></Button>
              </div>

            </Card>
          ))}
          {posts.length === 0 && <p className="text-sm text-muted-foreground">Nincs még hír.</p>}
        </div>
      )}

      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="max-w-3xl max-h-[92vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editing?.id ? "Hír szerkesztése" : "Új hír"}</DialogTitle></DialogHeader>
          {loadingEdit ? <p>Betöltés…</p> : editing && (
            <div className="space-y-3">
              <div>
                <Label>Típus *</Label>
                <Select value={editing.post_type ?? "blog"} onValueChange={(v) => setEditing({ ...editing, post_type: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="blog">Blog – szöveges cikk</SelectItem>
                    <SelectItem value="vlog">Vlog – videós bejegyzés</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground mt-1">
                  Publikus elérés: <code>/{editing.post_type === "vlog" ? "vlog" : "blog"}/{editing.slug || "<slug>"}</code>
                </p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <Label>Tárgy *</Label>
                  <Input value={editing.title}
                    onChange={(e) => setEditing({ ...editing, title: e.target.value, slug: editing.slug || slugify(e.target.value) })} />
                </div>
                <div>
                  <Label>Slug *</Label>
                  <Input value={editing.slug} onChange={(e) => setEditing({ ...editing, slug: slugify(e.target.value) })} />
                </div>
              </div>

              <div>
                <Label>Kivonat</Label>
                <Textarea rows={2} value={editing.excerpt ?? ""} onChange={(e) => setEditing({ ...editing, excerpt: e.target.value })} />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <Label>Kiemelt kép URL</Label>
                  <Input value={editing.featured_image_url ?? ""} onChange={(e) => setEditing({ ...editing, featured_image_url: e.target.value })} />
                </div>
                <div>
                  <Label>Kép alt szöveg</Label>
                  <Input value={editing.featured_image_alt ?? ""} onChange={(e) => setEditing({ ...editing, featured_image_alt: e.target.value })} />
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <Label>Szerző</Label>
                  <Select value={editing.author_id ?? "none"} onValueChange={(v) => setEditing({ ...editing, author_id: v === "none" ? null : v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">—</SelectItem>
                      {authors.map((a: any) => <SelectItem key={a.id} value={a.id}>{a.display_name}{a.is_guest ? " (vendég)" : ""}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Kategória</Label>
                  <Select value={editing.category_id ?? "none"} onValueChange={(v) => setEditing({ ...editing, category_id: v === "none" ? null : v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">—</SelectItem>
                      {cats.map((c: any) => <SelectItem key={c.id} value={c.id}>{c.parent_id ? "› " : ""}{c.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Státusz</Label>
                  <Select value={editing.status} onValueChange={(v) => setEditing({ ...editing, status: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="draft">Vázlat</SelectItem>
                      <SelectItem value="scheduled">Ütemezett</SelectItem>
                      <SelectItem value="published">Publikált</SelectItem>
                      <SelectItem value="archived">Archivált</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label>Publikálás dátuma</Label>
                <Input type="datetime-local" value={editing.published_at ?? ""} onChange={(e) => setEditing({ ...editing, published_at: e.target.value })} />
                <p className="text-xs text-muted-foreground mt-1">Jövőbeli dátum → automatikusan ütemezett.</p>
              </div>
              <div>
                <Label>Címkék</Label>
                <div className="flex flex-wrap gap-1.5">
                  {tags.map((t: any) => {
                    const sel = editing.tag_ids.includes(t.id);
                    return (
                      <button key={t.id} type="button"
                        onClick={() => setEditing({
                          ...editing,
                          tag_ids: sel ? editing.tag_ids.filter((x: string) => x !== t.id) : [...editing.tag_ids, t.id],
                        })}
                        className={`text-xs px-2 py-1 rounded-full border ${sel ? "bg-primary text-primary-foreground border-primary" : "bg-background"}`}
                      >#{t.name}</button>
                    );
                  })}
                  {tags.length === 0 && <span className="text-xs text-muted-foreground">Nincs még címke — hozd létre a Címkék fülön.</span>}
                </div>
              </div>
              <div>
                <Label>Tartalom</Label>
                <div className="grid gap-3 lg:grid-cols-2">
                  <TiptapEditor value={editing.body_html} onChange={(html) => setEditing({ ...editing, body_html: html })} />
                  <NewsLivePreview
                    title={editing.title}
                    excerpt={editing.excerpt}
                    coverUrl={editing.cover_url}
                    bodyHtml={editing.body_html}
                    siteUrl={
                      editing.slug
                        ? `/${editing.post_type === "vlog" ? "vlog" : "blog"}/${editing.slug}${editing.preview_token ? `?preview=${editing.preview_token}` : ""}`
                        : null
                    }
                  />
                </div>
              </div>

              {editing.post_type === "vlog" && (
                <div className="border rounded p-3 space-y-3 bg-muted/30">
                  <div className="font-medium text-sm">Videó beállítások</div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <Label>Szolgáltató</Label>
                      <Select
                        value={editing.video_provider ?? "auto"}
                        onValueChange={(v) => setEditing({ ...editing, video_provider: v === "auto" ? null : v })}
                      >
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="auto">Automatikus</SelectItem>
                          <SelectItem value="youtube">YouTube</SelectItem>
                          <SelectItem value="vimeo">Vimeo</SelectItem>
                          <SelectItem value="file">Önállóan tárolt fájl</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="sm:col-span-2">
                      <Label>Videó URL *</Label>
                      <div className="flex gap-2">
                        <Input
                          value={editing.video_url ?? ""}
                          placeholder="https://www.youtube.com/watch?v=…"
                          onChange={(e) => setEditing({ ...editing, video_url: e.target.value, video_embed_url: "", video_thumbnail_url: "" })}
                        />
                        <Button
                          type="button"
                          variant="outline"
                          disabled={!editing.video_url || videoMetaLoading}
                          onClick={async () => {
                            if (!editing.video_url) return;
                            setVideoMetaLoading(true);
                            try {
                              const r: any = await fetchVideoMetaFn({ data: { url: editing.video_url } });
                              if (!r?.ok) { toast.error(r?.error ?? "Nem sikerült lekérni a metaadatokat"); return; }
                              setEditing((prev: any) => ({
                                ...prev,
                                video_provider: r.provider,
                                video_embed_url: r.embed_url ?? prev.video_embed_url ?? "",
                                video_thumbnail_url: prev.video_thumbnail_url || r.thumbnail_url || "",
                                video_width: r.width ?? prev.video_width ?? null,
                                video_height: r.height ?? prev.video_height ?? null,
                                video_duration_seconds: prev.video_duration_seconds ?? r.duration_seconds ?? null,
                              }));
                              toast.success("Videó paraméterek frissítve");
                            } catch (e: any) {
                              toast.error(e?.message ?? "Hiba");
                            } finally {
                              setVideoMetaLoading(false);
                            }
                          }}
                        >
                          {videoMetaLoading ? "…" : "Auto lekérés"}
                        </Button>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">YouTube/Vimeo esetén letölti a posztert, szélességet, magasságot (Vimeo hosszot is).</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                    <div className="sm:col-span-2">
                      <Label>Saját borítókép URL (opcionális)</Label>
                      <Input value={editing.video_thumbnail_url ?? ""} onChange={(e) => setEditing({ ...editing, video_thumbnail_url: e.target.value })} />
                    </div>
                    <div>
                      <Label>Hossz (mp)</Label>
                      <Input type="number" min={0} value={editing.video_duration_seconds ?? ""} onChange={(e) => setEditing({ ...editing, video_duration_seconds: e.target.value ? parseInt(e.target.value) : null })} />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <Label>Szélesség</Label>
                        <Input type="number" min={0} value={editing.video_width ?? ""} onChange={(e) => setEditing({ ...editing, video_width: e.target.value ? parseInt(e.target.value) : null })} />
                      </div>
                      <div>
                        <Label>Magasság</Label>
                        <Input type="number" min={0} value={editing.video_height ?? ""} onChange={(e) => setEditing({ ...editing, video_height: e.target.value ? parseInt(e.target.value) : null })} />
                      </div>
                    </div>
                  </div>
                  <div>
                    <Label>Átirat (transcript)</Label>
                    <Textarea rows={4} value={editing.video_transcript ?? ""} onChange={(e) => setEditing({ ...editing, video_transcript: e.target.value })} placeholder="A videó szöveges átirata, SEO és akadálymentesség céljából." />
                  </div>
                </div>
              )}
              <details className="border rounded p-3">
                <summary className="cursor-pointer font-medium text-sm">SEO mezők</summary>
                <div className="space-y-3 mt-3">
                  <div>
                    <Label>SEO cím <span className="text-xs text-muted-foreground">({(editing.seo_title ?? "").length}/60)</span></Label>
                    <Input value={editing.seo_title ?? ""} maxLength={70} onChange={(e) => setEditing({ ...editing, seo_title: e.target.value })} />
                    <p className="text-xs text-muted-foreground mt-1">Ha üres: „{editing.title || "(cím)"}" jelenik meg megosztáskor.</p>
                  </div>
                  <div>
                    <Label>SEO leírás <span className="text-xs text-muted-foreground">({(editing.seo_description ?? "").length}/160)</span></Label>
                    <Textarea rows={2} maxLength={200} value={editing.seo_description ?? ""} onChange={(e) => setEditing({ ...editing, seo_description: e.target.value })} />
                    <p className="text-xs text-muted-foreground mt-1">Ha üres: a lead/kivonat első ~155 karaktere.</p>
                  </div>
                  <div>
                    <Label>OG kép URL</Label>
                    <div className="flex gap-2">
                      <Input value={editing.og_image_url ?? ""} onChange={(e) => setEditing({ ...editing, og_image_url: e.target.value })} placeholder="https://…" inputMode="url" autoCapitalize="none" />
                      <MediaPicker
                        trigger={<Button type="button" variant="outline" size="icon" title="Médiatárból"><ImageIcon className="h-4 w-4" /></Button>}
                        onSelect={(m) => setEditing({ ...editing, og_image_url: m.url })}
                      />
                      {editing.featured_image_url && (
                        <Button type="button" variant="outline" size="sm" onClick={() => setEditing({ ...editing, og_image_url: editing.featured_image_url })}>Kiemelt kép</Button>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">Ha üres: kiemelt kép → alapértelmezett site OG kép.</p>
                  </div>
                </div>
              </details>
            </div>

          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditing(null)}>Mégsem</Button>
            <Button onClick={save}>Mentés</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ---------------- Categories ----------------
function CategoriesTab() {
  const qc = useQueryClient();
  const listFn = useServerFn(adminListCategories);
  const saveFn = useServerFn(adminUpsertCategory);
  const delFn = useServerFn(adminDeleteCategory);
  const { data: cats = [] } = useQuery({ queryKey: ["adm-news-cats"], queryFn: () => listFn() });
  const [editing, setEditing] = useState<any>(null);

  const save = async () => {
    try {
      const p = { ...editing, slug: slugify(editing.slug || editing.name) };
      await saveFn({ data: p });
      toast.success("Mentve"); setEditing(null);
      qc.invalidateQueries({ queryKey: ["adm-news-cats"] });
    } catch (e: any) { toast.error(e.message); }
  };
  const remove = async (id: string) => {
    if (!confirm("Törlöd?")) return;
    try { await delFn({ data: { id } }); qc.invalidateQueries({ queryKey: ["adm-news-cats"] }); }
    catch (e: any) { toast.error(e.message); }
  };

  return (
    <div className="space-y-3">
      <div className="flex justify-between items-center">
        <h2 className="font-semibold">Kategóriák</h2>
        <Button onClick={() => setEditing({ name: "", slug: "", parent_id: null, sort_order: 0, is_active: true })} className="min-h-11">
          <Plus className="h-4 w-4 mr-1" /> Új
        </Button>
      </div>
      <div className="space-y-1">
        {cats.map((c: any) => (
          <Card key={c.id} className="p-3 flex items-center gap-2">
            <span className="flex-1">{c.parent_id ? "› " : ""}<strong>{c.name}</strong> <span className="text-xs text-muted-foreground">/{c.slug}</span></span>
            <Button variant="ghost" size="icon" className="min-h-11 min-w-11" onClick={() => setEditing(c)}><Edit className="h-4 w-4" /></Button>
            <Button variant="ghost" size="icon" className="min-h-11 min-w-11 text-destructive" onClick={() => remove(c.id)}><Trash2 className="h-4 w-4" /></Button>
          </Card>
        ))}
      </div>
      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editing?.id ? "Kategória" : "Új kategória"}</DialogTitle></DialogHeader>
          {editing && (
            <div className="space-y-3">
              <div><Label>Név</Label><Input value={editing.name} onChange={(e) => setEditing({ ...editing, name: e.target.value })} /></div>
              <div><Label>Slug</Label><Input value={editing.slug} onChange={(e) => setEditing({ ...editing, slug: slugify(e.target.value) })} /></div>
              <div>
                <Label>Szülő kategória</Label>
                <Select value={editing.parent_id ?? "none"} onValueChange={(v) => setEditing({ ...editing, parent_id: v === "none" ? null : v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">— (főkategória)</SelectItem>
                    {cats.filter((c: any) => !c.parent_id && c.id !== editing.id).map((c: any) => (
                      <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div><Label>Leírás</Label><Textarea rows={2} value={editing.description ?? ""} onChange={(e) => setEditing({ ...editing, description: e.target.value })} /></div>
              <div className="flex items-center gap-2"><Switch checked={editing.is_active} onCheckedChange={(v) => setEditing({ ...editing, is_active: v })} /><Label>Aktív</Label></div>
              <div><Label>Sorrend</Label><Input type="number" value={editing.sort_order ?? 0} onChange={(e) => setEditing({ ...editing, sort_order: parseInt(e.target.value) || 0 })} /></div>
            </div>
          )}
          <DialogFooter><Button variant="outline" onClick={() => setEditing(null)}>Mégsem</Button><Button onClick={save}>Mentés</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ---------------- Tags ----------------
function TagsTab() {
  const qc = useQueryClient();
  const listFn = useServerFn(adminListTags);
  const saveFn = useServerFn(adminUpsertTag);
  const delFn = useServerFn(adminDeleteTag);
  const { data: tags = [] } = useQuery({ queryKey: ["adm-news-tags"], queryFn: () => listFn() });
  const [editing, setEditing] = useState<any>(null);

  const save = async () => {
    try {
      await saveFn({ data: { ...editing, slug: slugify(editing.slug || editing.name) } });
      toast.success("Mentve"); setEditing(null);
      qc.invalidateQueries({ queryKey: ["adm-news-tags"] });
    } catch (e: any) { toast.error(e.message); }
  };
  const remove = async (id: string) => {
    if (!confirm("Törlöd?")) return;
    try { await delFn({ data: { id } }); qc.invalidateQueries({ queryKey: ["adm-news-tags"] }); }
    catch (e: any) { toast.error(e.message); }
  };

  return (
    <div className="space-y-3">
      <div className="flex justify-between items-center">
        <h2 className="font-semibold">Címkék</h2>
        <Button onClick={() => setEditing({ name: "", slug: "" })} className="min-h-11"><Plus className="h-4 w-4 mr-1" /> Új</Button>
      </div>
      <div className="flex flex-wrap gap-2">
        {tags.map((t: any) => (
          <div key={t.id} className="flex items-center gap-1 px-2 py-1 rounded-full border text-sm">
            #{t.name}
            <button className="text-muted-foreground hover:text-primary" onClick={() => setEditing(t)}><Edit className="h-3 w-3" /></button>
            <button className="text-muted-foreground hover:text-destructive" onClick={() => remove(t.id)}><Trash2 className="h-3 w-3" /></button>
          </div>
        ))}
      </div>
      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editing?.id ? "Címke" : "Új címke"}</DialogTitle></DialogHeader>
          {editing && (
            <div className="space-y-3">
              <div><Label>Név</Label><Input value={editing.name} onChange={(e) => setEditing({ ...editing, name: e.target.value })} /></div>
              <div><Label>Slug</Label><Input value={editing.slug} onChange={(e) => setEditing({ ...editing, slug: slugify(e.target.value) })} /></div>
            </div>
          )}
          <DialogFooter><Button variant="outline" onClick={() => setEditing(null)}>Mégsem</Button><Button onClick={save}>Mentés</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ---------------- Authors ----------------
function AuthorsTab() {
  const qc = useQueryClient();
  const listFn = useServerFn(adminListAuthors);
  const saveFn = useServerFn(adminUpsertAuthor);
  const delFn = useServerFn(adminDeleteAuthor);
  const { data: authors = [] } = useQuery({ queryKey: ["adm-news-authors"], queryFn: () => listFn() });
  const [editing, setEditing] = useState<any>(null);

  const save = async () => {
    try {
      const payload: any = { ...editing };
      if (!payload.email) delete payload.email;
      await saveFn({ data: payload });
      toast.success("Mentve"); setEditing(null);
      qc.invalidateQueries({ queryKey: ["adm-news-authors"] });
    } catch (e: any) { toast.error(e.message); }
  };
  const remove = async (id: string) => {
    if (!confirm("Törlöd?")) return;
    try { await delFn({ data: { id } }); qc.invalidateQueries({ queryKey: ["adm-news-authors"] }); }
    catch (e: any) { toast.error(e.message); }
  };

  return (
    <div className="space-y-3">
      <div className="flex justify-between items-center">
        <h2 className="font-semibold">Szerzők</h2>
        <Button onClick={() => setEditing({ display_name: "", bio: "", avatar_url: "", email: "", is_guest: true })} className="min-h-11">
          <Plus className="h-4 w-4 mr-1" /> Új szerző
        </Button>
      </div>
      <div className="space-y-1">
        {authors.map((a: any) => (
          <Card key={a.id} className="p-3 flex items-center gap-2">
            {a.avatar_url && <img src={a.avatar_url} alt="" className="w-8 h-8 rounded-full object-cover" />}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2"><strong>{a.display_name}</strong>{a.is_guest && <Badge variant="outline" className="text-xs">vendég</Badge>}</div>
              {a.bio && <p className="text-xs text-muted-foreground truncate">{a.bio}</p>}
            </div>
            <Button variant="ghost" size="icon" className="min-h-11 min-w-11" onClick={() => setEditing(a)}><Edit className="h-4 w-4" /></Button>
            <Button variant="ghost" size="icon" className="min-h-11 min-w-11 text-destructive" onClick={() => remove(a.id)}><Trash2 className="h-4 w-4" /></Button>
          </Card>
        ))}
      </div>
      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editing?.id ? "Szerző" : "Új szerző"}</DialogTitle></DialogHeader>
          {editing && (
            <div className="space-y-3">
              <div><Label>Megjelenítendő név</Label><Input value={editing.display_name} onChange={(e) => setEditing({ ...editing, display_name: e.target.value })} /></div>
              <div><Label>Bio</Label><Textarea rows={3} value={editing.bio ?? ""} onChange={(e) => setEditing({ ...editing, bio: e.target.value })} /></div>
              <div><Label>Avatar URL</Label><Input value={editing.avatar_url ?? ""} onChange={(e) => setEditing({ ...editing, avatar_url: e.target.value })} /></div>
              <div><Label>Email</Label><Input type="email" value={editing.email ?? ""} onChange={(e) => setEditing({ ...editing, email: e.target.value })} /></div>
              <div className="flex items-center gap-2"><Switch checked={editing.is_guest} onCheckedChange={(v) => setEditing({ ...editing, is_guest: v })} /><Label>Vendég szerző</Label></div>
            </div>
          )}
          <DialogFooter><Button variant="outline" onClick={() => setEditing(null)}>Mégsem</Button><Button onClick={save}>Mentés</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
