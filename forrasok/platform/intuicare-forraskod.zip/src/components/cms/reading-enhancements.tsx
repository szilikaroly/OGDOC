/**
 * Olvasói UX kiegészítők publikus CMS oldalra.
 * – ReadingProgress: vékony progress sáv az oldal tetején (scroll szerint).
 * – BackToTop: lebegő gomb mobilon a könnyű visszanavigáláshoz.
 * – ShareButton: natív Web Share API-t használ, fallback másolásra.
 * Mind kliens-oldali, a11y- és mobil-optimalizált (≥44px tap target).
 */
import { useEffect, useState } from "react";
import { ArrowUp, Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export function ReadingProgress() {
  const [pct, setPct] = useState(0);
  useEffect(() => {
    let raf = 0;
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const h = document.documentElement;
        const scrolled = h.scrollTop;
        const max = h.scrollHeight - h.clientHeight;
        setPct(max > 0 ? Math.min(100, (scrolled / max) * 100) : 0);
      });
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, []);
  return (
    <div
      className="fixed left-0 right-0 top-0 z-40 h-1 bg-transparent pointer-events-none"
      aria-hidden
    >
      <div
        className="h-full bg-primary transition-[width] duration-150 ease-out"
        style={{ width: `${pct}%` }}
      />
    </div>
  );
}

export function BackToTop() {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 600);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  if (!visible) return null;
  return (
    <Button
      size="icon"
      aria-label="Vissza az oldal tetejére"
      onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
      className="fixed bottom-20 right-4 z-40 h-12 w-12 rounded-full shadow-lg sm:bottom-6"
    >
      <ArrowUp className="h-5 w-5" />
    </Button>
  );
}

export function ShareButton({ title }: { title: string }) {
  const handle = async () => {
    const url = typeof window !== "undefined" ? window.location.href : "";
    try {
      if (typeof navigator !== "undefined" && (navigator as any).share) {
        await (navigator as any).share({ title, url });
      } else {
        await navigator.clipboard.writeText(url);
        toast.success("Link a vágólapra másolva");
      }
    } catch {
      /* user cancelled */
    }
  };
  return (
    <Button
      variant="outline"
      size="sm"
      onClick={handle}
      className="min-h-11 gap-2"
      aria-label="Oldal megosztása"
    >
      <Share2 className="h-4 w-4" /> Megosztás
    </Button>
  );
}
