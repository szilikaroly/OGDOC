/**
 * CMS blokk renderer: dyn_tips_list — paraméterezhető Tanács-lista.
 */
import { Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock } from "lucide-react";
import { listPublishedTips } from "@/lib/cms/tips.functions";
import { SmartImage } from "@/components/ui/smart-image";

interface Props {
  category?: string;
  audience?: string;
  tag?: string;
  featured_only?: boolean;
  limit?: number;
  locale?: string;
  title?: string;
}

export function TipsListBlock({ category, audience, tag, featured_only, limit = 6, locale = "hu", title }: Props) {
  const fn = useServerFn(listPublishedTips);
  const { data } = useQuery({
    queryKey: ["block-tips", category, audience, tag, featured_only, limit, locale],
    queryFn: () => fn({ data: { category, audience, tag, featured_only: !!featured_only, limit, locale } }),
    staleTime: 60_000,
  });
  const rows = (data?.tips ?? []) as any[];
  const localizedName = (i18nObj: any) => (i18nObj?.[locale] ?? i18nObj?.hu ?? "—") as string;

  return (
    <section className="my-8">
      {title && <h2 className="text-2xl font-bold mb-4">{title}</h2>}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {rows.map((t) => {
          const tr = (t.cms_tip_translations ?? [])[0];
          return (
            <Link key={t.id} to="/tanacsok/$slug" params={{ slug: t.slug }} className="block">
              <Card className="h-full hover:border-primary transition overflow-hidden">
                {t.cover_url && <SmartImage src={t.cover_url} alt="" sizesPreset="card" className="w-full aspect-video object-cover" />}
                <CardContent className="p-4">
                  <h3 className="font-semibold leading-tight">{tr?.title ?? t.slug}</h3>
                  {tr?.lead && <p className="text-sm text-muted-foreground mt-2 line-clamp-2">{tr.lead}</p>}
                  <div className="flex items-center gap-2 mt-3 text-xs text-muted-foreground">
                    {t.cms_tip_categories && <Badge variant="outline" className="text-[10px]">{localizedName(t.cms_tip_categories.name_i18n)}</Badge>}
                    {t.reading_minutes ? <span className="inline-flex items-center gap-1"><Clock className="size-3" />{t.reading_minutes}p</span> : null}
                  </div>
                </CardContent>
              </Card>
            </Link>
          );
        })}
        {!rows.length && <p className="text-sm text-muted-foreground col-span-full text-center py-4">Nincs megjeleníthető tanács.</p>}
      </div>
    </section>
  );
}
