/**
 * nav_menu blokk: cms_menus + cms_menu_items publikus lekérdezés render.
 * Variants: horizontal (alapértelmezett), vertical, footer-columns.
 */
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getPublicMenu } from "@/lib/cms/cms.functions";

type Props = {
  slug?: string;
  locale?: string;
  variant?: "horizontal" | "vertical" | "footer";
  className?: string;
};

export function NavMenuBlock({ slug = "main", locale = "hu", variant = "horizontal", className }: Props) {
  const fn = useServerFn(getPublicMenu);
  const { data } = useQuery({
    queryKey: ["public-menu", slug, locale],
    queryFn: () => fn({ data: { slug, locale } }),
    staleTime: 5 * 60_000,
  });
  const items = (data?.items ?? []) as Array<{
    id: string;
    parent_id: string | null;
    label: string;
    href: string;
    open_in_new_tab?: boolean;
    icon?: string | null;
  }>;
  if (!items.length) return null;

  const top = items.filter((i) => !i.parent_id);
  const childrenOf = (id: string) => items.filter((i) => i.parent_id === id);

  if (variant === "footer") {
    return (
      <nav className={`grid grid-cols-2 md:grid-cols-4 gap-6 my-6 ${className ?? ""}`}>
        {top.map((p) => (
          <div key={p.id}>
            <div className="text-sm font-semibold mb-2">{p.label}</div>
            <ul className="space-y-1 text-sm text-muted-foreground">
              {childrenOf(p.id).map((c) => (
                <li key={c.id}>
                  <a href={c.href} target={c.open_in_new_tab ? "_blank" : undefined} rel="noreferrer" className="hover:text-foreground">
                    {c.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </nav>
    );
  }

  if (variant === "vertical") {
    return (
      <nav className={`flex flex-col gap-1 my-4 ${className ?? ""}`}>
        {top.map((p) => (
          <a key={p.id} href={p.href} target={p.open_in_new_tab ? "_blank" : undefined} rel="noreferrer"
             className="px-3 py-2 rounded hover:bg-accent text-sm">{p.label}</a>
        ))}
      </nav>
    );
  }

  return (
    <nav className={`flex flex-wrap items-center gap-1 my-4 ${className ?? ""}`}>
      {top.map((p) => (
        <a key={p.id} href={p.href} target={p.open_in_new_tab ? "_blank" : undefined} rel="noreferrer"
           className="px-3 py-2 rounded hover:bg-accent text-sm font-medium">{p.label}</a>
      ))}
    </nav>
  );
}
