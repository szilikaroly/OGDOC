/**
 * Renderers for klinika_* block types — data-driven equivalents of the
 * sections that lived in klinika-landing.tsx. The SZTE brand colors
 * (#0f1b3d, #c9a84c, #1e3a5f) are deliberate, see memory note.
 */
import { Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import {
  ArrowRight, CalendarCheck, Phone, Mail, MapPin, Newspaper, ExternalLink,
  HeartPulse, Baby, Stethoscope, FileText, Clock, ShieldCheck, Users,
  GraduationCap, Briefcase, FlaskConical, Award, Activity, Search,
  Facebook, Youtube, Linkedin, Instagram,
} from "lucide-react";
import { useCurrentUserTarget } from "@/hooks/use-current-user-target";
import { getActiveMenu } from "@/lib/cms/cms.functions";
import { SmartImage } from "@/components/ui/smart-image";
import { sanitizeCmsHtml } from "@/lib/cms/sanitize-html";

type NavItem = { label: string; href: string };
function useMenuItems(menuKey: string | undefined, fallback: NavItem[]): NavItem[] {
  const fn = useServerFn(getActiveMenu);
  const { data } = useQuery({
    queryKey: ["cms-menu", menuKey ?? null],
    queryFn: () => fn({ data: { key: menuKey!, locale: "hu" } }),
    enabled: !!menuKey,
    staleTime: 60_000,
  });
  if (!menuKey) return fallback;
  const items = (data?.items ?? []) as Array<{ label: string; url: string | null; page_id: string | null }>;
  if (!items.length) return fallback;
  return items.map((it) => ({ label: it.label, href: it.url ?? "#" }));
}

type Block = { type: string; content?: Record<string, any>; style?: Record<string, any> };

const ICONS: Record<string, any> = {
  HeartPulse, Baby, Stethoscope, FileText, Clock, ShieldCheck, Users,
  GraduationCap, Briefcase, FlaskConical, Award, Activity, Search,
  Newspaper, MapPin, Phone, Mail, ExternalLink, CalendarCheck, ArrowRight,
  Facebook, Youtube, Linkedin, Instagram,
};
function Icon({ name, className }: { name?: string; className?: string }) {
  if (!name) return null;
  const Cmp = ICONS[name] ?? null;
  return Cmp ? <Cmp className={className} aria-hidden="true" /> : null;
}

function AccountLink({ className, label }: { className?: string; label?: string }) {
  const { isAuthenticated, target } = useCurrentUserTarget();
  const to = isAuthenticated && target ? target : "/auth";
  const text = isAuthenticated && target ? (label ?? "Saját fiók") : (label ?? "Belépés");
  return (
    <Link to={to} className={className}>
      {text} <ArrowRight className="size-4" />
    </Link>
  );
}

/** Smart link: internal route -> <Link>, external/tel/mailto -> <a>. */
function SmartLink({ to, className, children, target }: { to?: string; className?: string; children: React.ReactNode; target?: string }) {
  if (!to) return <span className={className}>{children}</span>;
  const isExternal = /^(https?:|tel:|mailto:|#)/.test(to);
  if (isExternal) {
    return (
      <a href={to} className={className} target={target} rel={target === "_blank" ? "noopener noreferrer" : undefined}>
        {children}
      </a>
    );
  }
  return <Link to={to} className={className}>{children}</Link>;
}

function SectionTitle({ kicker, title, lead, darkText }: { kicker?: string; title?: string; lead?: string; darkText?: boolean }) {
  if (!kicker && !title && !lead) return null;
  const titleColor = darkText ? "text-white" : "text-[#0f1b3d]";
  return (
    <div className="max-w-3xl mb-8 sm:mb-12">
      {kicker && (
        <div className="text-[10px] sm:text-[11px] font-mono uppercase tracking-[0.2em] sm:tracking-[0.25em] text-[#c9a84c] mb-2 sm:mb-3">
          {kicker}
        </div>
      )}
      {title && <h2 className={`font-serif text-2xl sm:text-3xl md:text-4xl ${titleColor} leading-tight`}>{title}</h2>}
      {lead && <p className={`mt-3 sm:mt-4 text-base sm:text-lg leading-relaxed ${darkText ? "text-white/80" : "text-muted-foreground"}`}>{lead}</p>}
    </div>
  );
}

function Section({ id, tone = "light", children }: { id?: string; tone?: "light" | "soft" | "dark"; children: React.ReactNode }) {
  const bg = tone === "dark" ? "bg-[#0f1b3d] text-white" : tone === "soft" ? "bg-[#f3f4f8]" : "bg-white";
  return (
    <section id={id} className={`${bg} py-14 sm:py-20 md:py-24 scroll-mt-16`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6">{children}</div>
    </section>
  );
}

/* =====================  REGION BLOCKS  ===================== */

export function KlinikaTopBar({ content }: { content: any }) {
  const links: Array<{ label: string; href: string; visibleAt?: string }> = content.links ?? [];
  return (
    <div className="bg-[#0a1530] text-white/70 text-[11px]">
      <div className="max-w-7xl mx-auto px-3 sm:px-4 py-1.5 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3 sm:gap-4 overflow-x-auto scrollbar-none min-w-0">
          {links.map((l) => (
            <a key={l.label} href={l.href} target={/^https?:/.test(l.href) ? "_blank" : undefined} rel="noopener" className={`hover:text-white whitespace-nowrap ${l.visibleAt ?? ""}`}>
              {l.label}
            </a>
          ))}
        </div>
        <div className="flex items-center gap-2 sm:gap-3 whitespace-nowrap shrink-0">
          {content.contrastLabel && <button className="hidden sm:inline hover:text-white" aria-label={content.contrastLabel}>{content.contrastLabel}</button>}
          {content.langLabel && (<><span className="hidden sm:inline opacity-30">|</span><a href={content.langHref ?? "#"} className="hover:text-white">{content.langLabel}</a></>)}
        </div>
      </div>
    </div>
  );
}

export function KlinikaSiteHeader({ content }: { content: any }) {
  return (
    <header className="bg-[#0f1b3d] text-white">
      <div className="max-w-7xl mx-auto px-3 sm:px-4 py-4 sm:py-6 grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4">
        <div className="flex min-w-0 items-center gap-3 sm:gap-5">
          <div className="shrink-0">
            <svg viewBox="0 0 64 80" className="w-10 h-12 sm:w-14 sm:h-16" aria-hidden="true">
              <path d="M32 2 L60 12 L60 40 C60 60 46 72 32 78 C18 72 4 60 4 40 L4 12 Z" fill="none" stroke="#c9a84c" strokeWidth="2" />
              <text x="32" y="46" textAnchor="middle" fill="#c9a84c" fontSize="9" fontFamily="serif">{content.crestText ?? "VVL"}</text>
            </svg>
          </div>
          <div className="min-w-0">
            {content.eyebrow && (
              <div className="text-[10px] sm:text-[11px] font-mono uppercase tracking-[0.18em] sm:tracking-[0.2em] text-[#c9a84c] truncate">{content.eyebrow}</div>
            )}
            {content.title && (
              <h1 className="font-serif text-lg sm:text-2xl md:text-3xl leading-tight mt-0.5 sm:mt-1">{content.title}</h1>
            )}
          </div>
        </div>
        <AccountLink className="hidden md:inline-flex items-center gap-2 px-4 py-2 rounded border border-[#c9a84c]/60 text-[#c9a84c] text-sm font-semibold hover:bg-[#c9a84c] hover:text-[#0f1b3d] transition-colors min-h-11" />
      </div>
    </header>
  );
}

export function KlinikaMainNav({ content }: { content: any }) {
  const staticItems: Array<{ label: string; href: string }> = content.items ?? [];
  const items = useMenuItems(content.menu_key, staticItems);
  return (
    <nav className="sticky top-0 z-30 bg-[#1e3a5f] text-white shadow-md">
      <div className="max-w-7xl mx-auto px-2 sm:px-4 flex items-center gap-0.5 sm:gap-1 overflow-x-auto scrollbar-none snap-x snap-mandatory">
        {items.map((n) => (
          <a key={n.href + n.label} href={n.href} className="snap-start px-3 sm:px-4 py-3 min-h-11 inline-flex items-center text-[11px] sm:text-xs font-semibold uppercase tracking-wider hover:bg-[#0f1b3d] whitespace-nowrap transition-colors">
            {n.label}
          </a>
        ))}
        <AccountLink className="md:hidden ml-auto px-3 sm:px-4 py-3 min-h-11 inline-flex items-center gap-1 text-[11px] sm:text-xs font-semibold uppercase tracking-wider text-[#c9a84c]" />
      </div>
    </nav>
  );
}

/* =====================  PAGE BLOCKS  ===================== */

export function KlinikaHero({ content }: { content: any }) {
  const ctas: Array<{ label: string; to: string; variant?: "primary" | "ghost"; icon?: string }> = content.ctas ?? [];
  return (
    <section className="relative overflow-hidden">
      <div className="absolute inset-0">
        {content.image && (
          <SmartImage src={content.image} alt={content.imageAlt ?? ""} sizesPreset="hero" priority className="w-full h-full object-cover" />
        )}
        <div className="absolute inset-0 bg-linear-to-r from-[#0f1b3d]/95 via-[#0f1b3d]/80 to-[#0f1b3d]/30 sm:via-[#0f1b3d]/70 sm:to-transparent" />
      </div>
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 py-16 sm:py-24 md:py-36 text-white">
        <div className="max-w-2xl">
          {content.kicker && (
            <div className="text-[10px] sm:text-[11px] font-mono uppercase tracking-[0.2em] sm:tracking-[0.25em] text-[#c9a84c] mb-3 sm:mb-4">{content.kicker}</div>
          )}
          {content.title && <h2 className="font-serif text-3xl sm:text-4xl md:text-6xl leading-[1.1] sm:leading-tight">{content.title}</h2>}
          {content.lead && <p className="mt-4 sm:mt-6 text-base sm:text-lg text-white/85 max-w-xl">{content.lead}</p>}
          {ctas.length > 0 && (
            <div className="mt-6 sm:mt-8 flex flex-col sm:flex-row flex-wrap gap-3">
              {ctas.map((c) => (
                <SmartLink key={c.label} to={c.to}
                  className={c.variant === "ghost"
                    ? "inline-flex items-center justify-center gap-2 px-5 py-3 min-h-12 border border-white/40 rounded font-semibold hover:bg-white/10 transition-colors"
                    : "inline-flex items-center justify-center gap-2 px-5 py-3 min-h-12 bg-[#c9a84c] text-[#0f1b3d] rounded font-semibold hover:bg-[#d8b961] transition-colors"}>
                  <Icon name={c.icon} className="size-4" /> {c.label}
                </SmartLink>
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

export function KlinikaIntroGrid({ content }: { content: any }) {
  const cards: Array<{ title: string; body: string }> = content.cards ?? [];
  return (
    <Section id={content.id} tone={content.tone ?? "light"}>
      <SectionTitle kicker={content.kicker} title={content.title} lead={content.lead} />
      <div className="grid md:grid-cols-3 gap-6">
        {cards.map((c) => (
          <div key={c.title} className="bg-[#f3f4f8] border-l-4 border-[#c9a84c] p-6">
            <h3 className="font-serif text-xl text-[#0f1b3d] mb-2">{c.title}</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">{c.body}</p>
          </div>
        ))}
      </div>
    </Section>
  );
}

export function KlinikaStats({ content }: { content: any }) {
  const items: Array<{ icon?: string; value: string; label: string }> = content.items ?? [];
  return (
    <section className="bg-[#1e3a5f] text-white py-12 md:py-14 border-y border-[#c9a84c]/20">
      <div className="max-w-7xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-10">
        {items.map((s) => (
          <div key={s.label} className="text-center">
            <Icon name={s.icon} className="size-7 mx-auto text-[#c9a84c] mb-2" />
            <div className="font-serif text-3xl md:text-4xl">{s.value}</div>
            <div className="text-[11px] md:text-xs uppercase tracking-wider text-white/70 mt-1">{s.label}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

export function KlinikaIconGrid({ content }: { content: any }) {
  const items: Array<{ icon?: string; title: string; body: string }> = content.items ?? [];
  return (
    <Section id={content.id} tone={content.tone ?? "dark"}>
      <SectionTitle kicker={content.kicker} title={content.title} lead={content.lead} darkText={(content.tone ?? "dark") === "dark"} />
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {items.map((it) => (
          <div key={it.title} className="group bg-white/5 border border-white/10 p-6 hover:border-[#c9a84c]/60 transition-colors">
            <Icon name={it.icon} className="size-7 text-[#c9a84c] mb-4" />
            <h3 className="font-serif text-lg mb-2">{it.title}</h3>
            <p className="text-sm text-white/70 leading-relaxed">{it.body}</p>
          </div>
        ))}
      </div>
    </Section>
  );
}

export function KlinikaScheduleTable({ content }: { content: any }) {
  const rows: Array<{ name: string; time: string }> = content.rows ?? [];
  const sideCards: Array<{ icon?: string; title: string; body: string }> = content.sideCards ?? [];
  const ctas: Array<{ label: string; to: string; variant?: "primary" | "ghost"; icon?: string }> = content.ctas ?? [];
  return (
    <Section id={content.id} tone={content.tone ?? "light"}>
      <SectionTitle kicker={content.kicker} title={content.title} lead={content.lead} />
      <div className="grid md:grid-cols-2 gap-8">
        <div className="border border-border rounded-md overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-[#0f1b3d] text-white">
              <tr>
                <th className="text-left px-4 py-3 font-semibold">{content.colName ?? "Szakrendelés"}</th>
                <th className="text-left px-4 py-3 font-semibold">{content.colTime ?? "Rendelési idő"}</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => (
                <tr key={r.name} className={i % 2 ? "bg-[#f3f4f8]" : "bg-white"}>
                  <td className="px-4 py-3">{r.name}</td>
                  <td className="px-4 py-3 font-mono text-xs text-muted-foreground">{r.time}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="space-y-4">
          {sideCards.map((c) => (
            <div key={c.title} className="flex gap-4 p-4 bg-[#f3f4f8] rounded-md">
              <Icon name={c.icon} className="size-6 text-[#0f1b3d] shrink-0 mt-0.5" />
              <div>
                <h4 className="font-semibold text-[#0f1b3d]">{c.title}</h4>
                <p className="text-sm text-muted-foreground mt-1">{c.body}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
      {ctas.length > 0 && (
        <div className="mt-10 flex flex-wrap items-center gap-3">
          {ctas.map((c) => (
            <SmartLink key={c.label} to={c.to}
              className={c.variant === "ghost"
                ? "inline-flex items-center gap-2 px-5 py-3 border border-[#0f1b3d]/30 text-[#0f1b3d] rounded font-semibold hover:bg-[#0f1b3d]/5 transition-colors"
                : "inline-flex items-center gap-2 px-5 py-3 bg-[#0f1b3d] text-white rounded font-semibold hover:bg-[#1e3a5f] transition-colors"}>
              <Icon name={c.icon} className="size-4" /> {c.label}
            </SmartLink>
          ))}
        </div>
      )}
    </Section>
  );
}

export function KlinikaTeam({ content }: { content: any }) {
  const people: Array<{ name: string; role: string }> = content.people ?? [];
  return (
    <Section id={content.id} tone={content.tone ?? "soft"}>
      <SectionTitle kicker={content.kicker} title={content.title} lead={content.lead} />
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {people.map((p) => (
          <div key={p.name} className="bg-white border border-border p-6 flex items-start gap-4">
            <div className="size-14 rounded-full bg-[#0f1b3d] text-[#c9a84c] font-serif text-xl flex items-center justify-center shrink-0">
              {p.name.split(" ").slice(-1)[0].slice(0, 2).toUpperCase()}
            </div>
            <div>
              <div className="font-semibold text-[#0f1b3d]">{p.name}</div>
              <div className="text-xs text-muted-foreground mt-1">{p.role}</div>
            </div>
          </div>
        ))}
      </div>
      {content.footerLink && (
        <div className="mt-8 text-center">
          <SmartLink to={content.footerLink.to} className="text-sm font-semibold text-[#1e3a5f] hover:underline inline-flex items-center gap-1">
            <Icon name={content.footerLink.icon ?? "Search"} className="size-4" /> {content.footerLink.label} <ArrowRight className="size-4" />
          </SmartLink>
        </div>
      )}
    </Section>
  );
}

export function Klinika3ColFeatures({ content }: { content: any }) {
  const items: Array<{ icon?: string; title: string; body: string }> = content.items ?? [];
  return (
    <Section id={content.id} tone={content.tone ?? "light"}>
      <SectionTitle kicker={content.kicker} title={content.title} lead={content.lead} />
      <div className="grid md:grid-cols-3 gap-6">
        {items.map((it) => (
          <div key={it.title} className="p-6 border-t-4 border-[#c9a84c] bg-[#f3f4f8]">
            <Icon name={it.icon} className="size-7 text-[#0f1b3d] mb-3" />
            <h3 className="font-serif text-xl text-[#0f1b3d] mb-2">{it.title}</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">{it.body}</p>
          </div>
        ))}
      </div>
    </Section>
  );
}

export function KlinikaNews({ content }: { content: any }) {
  const items: Array<{ tag: string; date: string; title: string; excerpt: string; href?: string }> = content.items ?? [];
  return (
    <Section id={content.id} tone={content.tone ?? "soft"}>
      <SectionTitle kicker={content.kicker} title={content.title} lead={content.lead} />
      <div className="grid md:grid-cols-3 gap-6">
        {items.map((h) => (
          <article key={h.title} className="bg-white border border-border flex flex-col">
            <div className="aspect-[16/10] bg-gradient-to-br from-[#1e3a5f] to-[#0f1b3d] flex items-center justify-center">
              <Newspaper className="size-12 text-[#c9a84c]/70" />
            </div>
            <div className="p-5 flex flex-col flex-1">
              <div className="text-[11px] font-mono uppercase tracking-wider text-[#c9a84c]">{h.tag}</div>
              <div className="text-xs text-muted-foreground mt-1">{h.date}</div>
              <h3 className="font-serif text-lg text-[#0f1b3d] mt-3 leading-snug">{h.title}</h3>
              <p className="text-sm text-muted-foreground mt-2 flex-1">{h.excerpt}</p>
              <a href={h.href ?? "#"} className="mt-4 text-sm font-semibold text-[#1e3a5f] hover:underline inline-flex items-center gap-1">
                {content.readMoreLabel ?? "Tovább a teljes cikkhez"} <ArrowRight className="size-4" />
              </a>
            </div>
          </article>
        ))}
      </div>
    </Section>
  );
}

export function KlinikaLogoGrid({ content }: { content: any }) {
  const items: string[] = content.items ?? [];
  return (
    <Section id={content.id} tone={content.tone ?? "light"}>
      <SectionTitle kicker={content.kicker} title={content.title} lead={content.lead} />
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {items.map((p) => (
          <div key={p} className="aspect-[5/2] border border-border bg-[#f3f4f8] flex items-center justify-center font-serif text-[#0f1b3d] text-sm md:text-base">{p}</div>
        ))}
      </div>
    </Section>
  );
}

export function KlinikaJobs({ content }: { content: any }) {
  const jobs: Array<{ title: string; meta?: string }> = content.jobs ?? [];
  return (
    <section className="bg-[#0f1b3d] text-white py-14 sm:py-20 scroll-mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 grid md:grid-cols-2 gap-8 sm:gap-10 items-center">
        <div>
          {content.kicker && (
            <div className="text-[10px] sm:text-[11px] font-mono uppercase tracking-[0.2em] sm:tracking-[0.25em] text-[#c9a84c] mb-2 sm:mb-3">{content.kicker}</div>
          )}
          {content.title && <h2 className="font-serif text-2xl sm:text-3xl md:text-4xl mb-3 sm:mb-4 leading-tight">{content.title}</h2>}
          {content.lead && <p className="text-white/75 mb-5 sm:mb-6 max-w-lg text-sm sm:text-base">{content.lead}</p>}
          {content.ctaLabel && (
            <SmartLink to={content.ctaHref ?? "#"} className="inline-flex items-center justify-center gap-2 px-5 py-3 min-h-12 bg-[#c9a84c] text-[#0f1b3d] rounded font-semibold hover:bg-[#d8b961] transition-colors">
              {content.ctaLabel} <ArrowRight className="size-4" />
            </SmartLink>
          )}
        </div>
        <ul className="grid sm:grid-cols-2 gap-3">
          {jobs.map((j) => (
            <li key={j.title} className="bg-white/5 border border-white/10 p-4 hover:border-[#c9a84c]/60 transition-colors">
              <Briefcase className="size-5 text-[#c9a84c] mb-2" aria-hidden="true" />
              <div className="font-semibold text-sm">{j.title}</div>
              {j.meta && <div className="text-xs text-white/60 mt-1">{j.meta}</div>}
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

export function KlinikaLinksGrid({ content }: { content: any }) {
  const items: Array<{ label: string; href: string }> = content.items ?? [];
  return (
    <Section id={content.id} tone={content.tone ?? "soft"}>
      <SectionTitle kicker={content.kicker} title={content.title} lead={content.lead} />
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
        {items.map((l) => (
          <a key={l.label} href={l.href} className="group flex items-center justify-between gap-2 p-3 sm:p-4 min-h-12 bg-white border border-border hover:border-[#c9a84c] transition-colors">
            <span className="text-sm leading-tight">{l.label}</span>
            <ExternalLink className="size-4 shrink-0 text-muted-foreground group-hover:text-[#c9a84c]" aria-hidden="true" />
          </a>
        ))}
      </div>
    </Section>
  );
}

export function KlinikaFaq({ content }: { content: any }) {
  const items: Array<{ q: string; a: string }> = content.items ?? [];
  return (
    <Section id={content.id} tone={content.tone ?? "soft"}>
      <SectionTitle kicker={content.kicker} title={content.title} lead={content.lead} />
      <div className="max-w-3xl mx-auto space-y-3">
        {items.map((it) => (
          <details key={it.q} className="group bg-white border border-border rounded-md p-4 md:p-5 open:border-[#c9a84c]">
            <summary className="cursor-pointer font-semibold text-[#0f1b3d] list-none flex items-center justify-between gap-3">
              <span>{it.q}</span>
              <ArrowRight className="size-4 shrink-0 text-[#c9a84c] transition-transform group-open:rotate-90" />
            </summary>
            <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{it.a}</p>
          </details>
        ))}
      </div>
    </Section>
  );
}

export function KlinikaContact({ content }: { content: any }) {
  const rows: Array<{ icon?: string; label: string; value: string; href?: string; external?: boolean }> = content.rows ?? [];
  return (
    <Section id={content.id} tone={content.tone ?? "light"}>
      <SectionTitle kicker={content.kicker} title={content.title} />
      <div className="grid md:grid-cols-3 gap-5 sm:gap-6">
        <div className="md:col-span-2 aspect-[4/3] sm:aspect-[16/10] md:aspect-[16/9] bg-[#f3f4f8] border border-border overflow-hidden">
          {content.mapSrc && (
            <iframe title={content.mapTitle ?? "Térkép"} src={content.mapSrc} className="w-full h-full border-0" loading="lazy" referrerPolicy="no-referrer-when-downgrade" />
          )}
        </div>
        <div className="space-y-4">
          {rows.map((r) => {
            const body = (
              <>
                <Icon name={r.icon} className="size-5 text-[#0f1b3d] mt-0.5 shrink-0" />
                <div className="min-w-0">
                  <div className="text-[11px] font-mono uppercase tracking-wider text-muted-foreground">{r.label}</div>
                  <div className="text-sm font-semibold text-[#0f1b3d] break-words">{r.value}</div>
                </div>
              </>
            );
            const cls = "flex items-start gap-3 p-3 border-l-2 border-[#c9a84c]";
            return r.href ? (
              <a key={r.label} href={r.href} className={`${cls} hover:bg-[#f3f4f8] transition-colors`} {...(r.external ? { target: "_blank", rel: "noopener noreferrer" } : {})}>{body}</a>
            ) : (
              <div key={r.label} className={cls}>{body}</div>
            );
          })}
          {content.bookCtaLabel && (
            <SmartLink to={content.bookCtaHref ?? "/foglalas/uj"} className="mt-2 inline-flex items-center justify-center gap-2 w-full py-3 bg-[#c9a84c] text-[#0f1b3d] rounded font-semibold hover:bg-[#d8b961] transition-colors">
              <CalendarCheck className="size-4" /> {content.bookCtaLabel}
            </SmartLink>
          )}
          {content.accountCtaLabel && (
            <AccountLink className="inline-flex items-center justify-center gap-2 w-full py-3 bg-[#0f1b3d] text-white rounded font-semibold hover:bg-[#1e3a5f] transition-colors" label={content.accountCtaLabel} />
          )}
        </div>
      </div>
    </Section>
  );
}

export function KlinikaFooter({ content }: { content: any }) {
  const cols: Array<{ title: string; links: Array<{ label: string; href: string }> }> = content.columns ?? [];
  const socials: Array<{ icon: string; href: string; label: string }> = content.socials ?? [];
  const legal: Array<{ label: string; href: string }> = content.legal ?? [];
  const address: string[] = content.address ?? [];
  return (
    <footer className="bg-[#0a1530] text-white/80 pb-safe">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10 sm:py-14 grid grid-cols-2 md:grid-cols-4 gap-8 sm:gap-10 text-sm">
        {cols.map((c) => (
          <div key={c.title}>
            <h4 className="font-serif text-base text-white mb-3 pb-2 border-b border-[#c9a84c]/40">{c.title}</h4>
            <div className="text-xs text-white/70">
              {c.links.map((l) => (
                <a key={l.label} href={l.href} className="block hover:text-[#c9a84c] py-1">{l.label}</a>
              ))}
            </div>
          </div>
        ))}
        {(socials.length > 0 || address.length > 0) && (
          <div>
            <h4 className="font-serif text-base text-white mb-3 pb-2 border-b border-[#c9a84c]/40">{content.socialTitle ?? "Kövess minket"}</h4>
            <div className="flex flex-wrap gap-2 sm:gap-3 mt-2">
              {socials.map((s) => (
                <a key={s.label} href={s.href} aria-label={s.label} className="size-11 rounded-full bg-white/10 hover:bg-[#c9a84c] hover:text-[#0f1b3d] flex items-center justify-center transition-colors">
                  <Icon name={s.icon} className="size-4" />
                </a>
              ))}
            </div>
            {address.length > 0 && (
              <div className="mt-5 sm:mt-6 text-xs text-white/60 space-y-1">
                {address.map((a, i) => <div key={i} dangerouslySetInnerHTML={{ __html: sanitizeCmsHtml(a) }} />)}
              </div>
            )}
          </div>
        )}
      </div>
      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 text-[11px] text-white/50 flex flex-col sm:flex-row sm:flex-wrap sm:items-center sm:justify-between gap-2">
          <div>{(content.copyright ?? "© {year}").replace("{year}", String(new Date().getFullYear()))}</div>
          <div className="flex flex-wrap gap-4">
            {legal.map((l) => (<a key={l.label} href={l.href} className="hover:text-white">{l.label}</a>))}
            <Link to="/auth" className="hover:text-[#c9a84c]">{content.loginLabel ?? "Belépés"}</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}

/* =====================  REGISTRY  ===================== */

import { DynDoctorCard, DynFaqList, DynContactForm, DynDoctorSchedule, DynBookingWidget } from "./dynamic-data-blocks";

export const BLOCK_RENDERERS: Record<string, React.FC<{ content: any; style?: any }>> = {
  klinika_top_bar: KlinikaTopBar,
  klinika_site_header: KlinikaSiteHeader,
  klinika_main_nav: KlinikaMainNav,
  klinika_hero: KlinikaHero,
  klinika_intro_grid: KlinikaIntroGrid,
  klinika_stats: KlinikaStats,
  klinika_icon_grid: KlinikaIconGrid,
  klinika_schedule_table: KlinikaScheduleTable,
  klinika_team: KlinikaTeam,
  klinika_3col_features: Klinika3ColFeatures,
  klinika_news: KlinikaNews,
  klinika_logo_grid: KlinikaLogoGrid,
  klinika_jobs: KlinikaJobs,
  klinika_links_grid: KlinikaLinksGrid,
  klinika_faq: KlinikaFaq,
  klinika_contact: KlinikaContact,
  klinika_footer: KlinikaFooter,
  // Dinamikus (élő DB) blokkok
  dyn_doctor_card: DynDoctorCard,
  dyn_faq: DynFaqList,
  dyn_contact_form: DynContactForm,
  dyn_doctor_schedule: DynDoctorSchedule,
  dyn_booking_widget: DynBookingWidget,
};

export function CmsBlock({ type, content, style }: { type: string; content?: any; style?: any }) {
  const Comp = BLOCK_RENDERERS[type];
  if (!Comp) {
    if (import.meta.env.DEV) {
      return <div className="px-4 py-2 text-xs text-muted-foreground border border-dashed">Ismeretlen blokk: {type}</div>;
    }
    return null;
  }
  return <Comp content={content ?? {}} style={style ?? {}} />;
}
