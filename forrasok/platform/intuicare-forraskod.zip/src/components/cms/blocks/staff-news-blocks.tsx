/**
 * Dinamikus blokkok: dolgozói rács + hírlista.
 * Anon-safe public reads.
 */
import { Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { listPublishedStaff } from "@/lib/cms/staff-public.functions";
import { listPublishedNews } from "@/lib/cms/news.functions";
import { SmartImage } from "@/components/ui/smart-image";

export function StaffGridBlock({
  locale = "hu", specialty, limit = 12, title,
}: { locale?: string; specialty?: string; limit?: number; title?: string }) {
  const fn = useServerFn(listPublishedStaff);
  const q = useQuery({
    queryKey: ["dyn-staff", locale, specialty, limit],
    queryFn: () => fn({ data: { locale, specialty, limit } }),
    staleTime: 60_000,
  });
  const rows = (q.data ?? []) as any[];

  return (
    <section className="max-w-6xl mx-auto px-3 sm:px-6 lg:px-8 my-10">
      {title && <h2 className="text-2xl sm:text-3xl font-semibold mb-6 text-center">{title}</h2>}
      {q.isLoading && <div className="text-sm text-muted-foreground text-center">Betöltés…</div>}
      {!q.isLoading && rows.length === 0 && (
        <div className="text-sm text-muted-foreground text-center">Nincs megjeleníthető munkatárs.</div>
      )}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {rows.map((s) => (
          <Card key={s.id} className="overflow-hidden hover:border-primary transition">
            {s.photo_url && <SmartImage src={s.photo_url} alt={s.display_name} sizesPreset="card" className="w-full aspect-[4/3] object-cover" />}
            <CardContent className="p-4">
              <div className="font-semibold">{s.display_name}</div>
              {s.title && <div className="text-sm text-muted-foreground">{s.title}</div>}
              {Array.isArray(s.specialties) && s.specialties.length > 0 && (
                <div className="mt-2 flex flex-wrap gap-1">
                  {s.specialties.slice(0, 4).map((sp: string) => (
                    <Badge key={sp} variant="outline" className="text-[10px]">{sp}</Badge>
                  ))}
                </div>
              )}
              {s.bio && <p className="mt-2 text-sm line-clamp-3">{s.bio}</p>}
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
}

export function NewsListBlock({
  locale = "hu", limit = 6, category, title,
}: { locale?: string; limit?: number; category?: string; title?: string }) {
  const fn = useServerFn(listPublishedNews as any);
  const q = useQuery({
    queryKey: ["dyn-news", locale, category, limit],
    queryFn: () => (fn as any)({ data: { locale, limit, category } }),
    staleTime: 60_000,
  });
  const rows = ((q.data as any)?.posts ?? q.data ?? []) as any[];

  return (
    <section className="max-w-6xl mx-auto px-3 sm:px-6 lg:px-8 my-10">
      {title && <h2 className="text-2xl sm:text-3xl font-semibold mb-6 text-center">{title}</h2>}
      {q.isLoading && <div className="text-sm text-muted-foreground text-center">Betöltés…</div>}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {rows.slice(0, limit).map((p: any) => {
          const tr = (p.cms_news_post_translations ?? p.translations ?? [])[0] ?? p;
          return (
            <Link key={p.id} to="/hirek/$slug" params={{ slug: p.slug }} className="block">
              <Card className="h-full hover:border-primary transition overflow-hidden">
                {(p.cover_url || p.hero_image_url) && (
                  <SmartImage src={p.cover_url || p.hero_image_url} alt="" sizesPreset="card" className="w-full aspect-video object-cover" />
                )}
                <CardContent className="p-4">
                  <h3 className="font-semibold leading-tight">{tr?.title ?? p.title ?? p.slug}</h3>
                  {(tr?.lead || tr?.excerpt) && (
                    <p className="text-sm text-muted-foreground mt-2 line-clamp-3">{tr?.lead || tr?.excerpt}</p>
                  )}
                  {p.published_at && (
                    <div className="text-xs text-muted-foreground mt-3">
                      {new Date(p.published_at).toLocaleDateString("hu-HU")}
                    </div>
                  )}
                </CardContent>
              </Card>
            </Link>
          );
        })}
        {!q.isLoading && !rows.length && (
          <div className="text-sm text-muted-foreground col-span-full text-center py-6">Nincs publikált hír.</div>
        )}
      </div>
    </section>
  );
}
