/**
 * Dinamikus adat-blokkok: élő DB-tartalom (orvos kártya, FAQ tag-szűrt,
 * kapcsolatfelvételi űrlap). A meglévő public server fn-eket használják
 * (dynamic.functions.ts) — anon olvasással, RLS érvényesül.
 */
import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Mail, Phone, ChevronDown, CalendarCheck } from "lucide-react";
import {
  getPublicStaffProfile,
  listPublicFaqs,
  submitContactMessage,
  getDoctorSchedule,
} from "@/lib/cms/dynamic.functions";
import { SmartImage } from "@/components/ui/smart-image";

/* ---------------- Orvos kártya ---------------- */

export function DynDoctorCard({ content }: { content: any }) {
  const slug = String(content?.slug ?? "");
  const locale = String(content?.locale ?? "hu");
  const fn = useServerFn(getPublicStaffProfile);
  const q = useQuery({
    queryKey: ["dyn-doctor", slug, locale],
    queryFn: () => fn({ data: { slug, locale } }),
    enabled: !!slug,
    staleTime: 60_000,
  });

  if (!slug) {
    return <div className="px-4 py-2 text-xs text-muted-foreground border border-dashed">Adj meg egy orvos slug-ot a `slug` mezőben.</div>;
  }
  if (q.isLoading) return <DoctorSkeleton />;
  const d: any = q.data;
  if (!d) return null;

  return (
    <section className="max-w-3xl mx-auto px-4 sm:px-6 my-6">
      <article className="border rounded-lg p-4 sm:p-6 bg-card flex flex-col sm:flex-row gap-4">
        {d.photo_url ? (
          <SmartImage src={d.photo_url} alt={d.display_name} sizesPreset="avatar" className="size-24 sm:size-32 rounded-full object-cover shrink-0" />
        ) : (
          <div className="size-24 sm:size-32 rounded-full bg-muted shrink-0" />
        )}
        <div className="flex-1 min-w-0">
          <h3 className="text-lg sm:text-xl font-semibold">{d.display_name}</h3>
          {d.title && <div className="text-sm text-muted-foreground">{d.title}</div>}
          {Array.isArray(d.specialties) && d.specialties.length > 0 && (
            <div className="mt-1 flex flex-wrap gap-1">
              {d.specialties.map((s: string) => (
                <span key={s} className="text-[11px] px-2 py-0.5 rounded bg-muted">{s}</span>
              ))}
            </div>
          )}
          {d.bio && <p className="mt-2 text-sm leading-relaxed whitespace-pre-line">{d.bio}</p>}
          <div className="mt-3 flex flex-wrap gap-2">
            <Button asChild size="sm">
              <Link to="/foglalas/uj">Időpontfoglalás</Link>
            </Button>
            <Button asChild size="sm" variant="outline">
              <Link to="/portal/orvos-kereso">Más orvos</Link>
            </Button>
          </div>
        </div>
      </article>
    </section>
  );
}

function DoctorSkeleton() {
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 my-6">
      <div className="border rounded-lg p-4 sm:p-6 flex gap-4 animate-pulse">
        <div className="size-24 sm:size-32 rounded-full bg-muted shrink-0" />
        <div className="flex-1 space-y-2">
          <div className="h-5 w-2/3 bg-muted rounded" />
          <div className="h-4 w-1/3 bg-muted rounded" />
          <div className="h-3 w-full bg-muted rounded" />
          <div className="h-3 w-5/6 bg-muted rounded" />
        </div>
      </div>
    </div>
  );
}

/* ---------------- Dinamikus FAQ (tag szűrt) ---------------- */

export function DynFaqList({ content }: { content: any }) {
  const fn = useServerFn(listPublicFaqs);
  const tag = content?.tag ? String(content.tag) : undefined;
  const locale = String(content?.locale ?? "hu");
  const limit = Number(content?.limit ?? 20);

  const q = useQuery({
    queryKey: ["dyn-faqs", locale, tag, limit],
    queryFn: () => fn({ data: { locale, tag, limit } }),
    staleTime: 60_000,
  });

  const items = (q.data ?? []) as Array<{ id: string; question: string; answer: string }>;

  return (
    <section className="max-w-3xl mx-auto px-4 sm:px-6 my-8">
      {content?.title && <h2 className="text-2xl font-semibold mb-4">{content.title}</h2>}
      {q.isLoading && <div className="text-sm text-muted-foreground">Betöltés…</div>}
      {!q.isLoading && items.length === 0 && (
        <div className="text-sm text-muted-foreground">Nincs megjeleníthető kérdés.</div>
      )}
      <ul className="divide-y border rounded-lg">
        {items.map((f) => <FaqItem key={f.id} q={f.question} a={f.answer} />)}
      </ul>
    </section>
  );
}

function FaqItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false);
  return (
    <li>
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="w-full text-left px-4 py-3 flex items-center justify-between gap-3 hover:bg-accent/40 min-h-11"
        aria-expanded={open}
      >
        <span className="font-medium text-sm">{q}</span>
        <ChevronDown className={`size-4 transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      {open && <div className="px-4 pb-4 text-sm text-muted-foreground whitespace-pre-line">{a}</div>}
    </li>
  );
}

/* ---------------- Kapcsolatfelvételi űrlap (anon insert) ---------------- */

export function DynContactForm({ content }: { content: any }) {
  const fn = useServerFn(submitContactMessage);
  const [form, setForm] = useState({
    sender_name: "", sender_email: "", sender_phone: "", subject: "", body: "", hp: "",
  });
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);

  const orgUnitId = content?.org_unit_id ?? null;
  const sourceSlug = typeof window !== "undefined" ? window.location.pathname : null;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    try {
      await fn({
        data: {
          org_unit_id: orgUnitId,
          source_page_slug: sourceSlug,
          sender_name: form.sender_name,
          sender_email: form.sender_email,
          sender_phone: form.sender_phone || null,
          subject: form.subject || null,
          body: form.body,
          locale: "hu",
          hp: form.hp,
        },
      });
      setDone(true);
      toast.success("Üzenet elküldve, hamarosan válaszolunk.");
    } catch (err: any) {
      toast.error(err?.message ?? "Küldési hiba");
    } finally {
      setBusy(false);
    }
  };

  if (done) {
    return (
      <section className="max-w-2xl mx-auto px-4 sm:px-6 my-8">
        <div className="border rounded-lg p-6 text-center bg-card">
          <Mail className="size-8 mx-auto text-primary mb-2" />
          <h3 className="font-semibold">Köszönjük!</h3>
          <p className="text-sm text-muted-foreground">Üzenetét megkaptuk, munkatársunk hamarosan válaszol.</p>
        </div>
      </section>
    );
  }

  return (
    <section className="max-w-2xl mx-auto px-4 sm:px-6 my-8">
      {content?.title && <h2 className="text-2xl font-semibold mb-4">{content.title}</h2>}
      {content?.lead && <p className="text-sm text-muted-foreground mb-4">{content.lead}</p>}
      <form onSubmit={submit} className="space-y-3 border rounded-lg p-4 bg-card">
        <Input required minLength={2} placeholder="Az Ön neve *" value={form.sender_name}
               onChange={(e) => setForm({ ...form, sender_name: e.target.value })} />
        <Input required type="email" placeholder="E-mail cím *" value={form.sender_email}
               onChange={(e) => setForm({ ...form, sender_email: e.target.value })} />
        <Input type="tel" placeholder="Telefonszám (opcionális)" value={form.sender_phone}
               onChange={(e) => setForm({ ...form, sender_phone: e.target.value })} />
        <Input placeholder="Tárgy" value={form.subject}
               onChange={(e) => setForm({ ...form, subject: e.target.value })} />
        <Textarea required minLength={5} rows={5} placeholder="Üzenete *" value={form.body}
                  onChange={(e) => setForm({ ...form, body: e.target.value })} />
        {/* honeypot — láthatatlan input, ha kitöltik = bot */}
        <input
          type="text" tabIndex={-1} autoComplete="off"
          aria-hidden="true" className="hidden"
          value={form.hp} onChange={(e) => setForm({ ...form, hp: e.target.value })}
        />
        <div className="flex items-center justify-between gap-2">
          <div className="text-[11px] text-muted-foreground flex items-center gap-1">
            <Phone className="size-3" /> Sürgős esetben hívja a központi számot.
          </div>
          <Button type="submit" disabled={busy} className="gap-1 min-h-11">
            {busy && <Loader2 className="size-4 animate-spin" />}
            Küldés
          </Button>
        </div>
      </form>
    </section>
  );
}

/* ---------------- Orvos rendelési idők (élő) ---------------- */

export function DynDoctorSchedule({ content }: { content: any }) {
  const fn = useServerFn(getDoctorSchedule);
  const params = {
    doctor_id: content?.doctor_id || undefined,
    specialty_id: content?.specialty_id || undefined,
    org_unit_id: content?.org_unit_id || undefined,
    days: Number(content?.days ?? 14),
  };
  const hasFilter = !!(params.doctor_id || params.specialty_id || params.org_unit_id);

  const q = useQuery({
    queryKey: ["dyn-doctor-schedule", params],
    queryFn: () => fn({ data: params as any }),
    enabled: hasFilter,
    staleTime: 60_000,
  });

  if (!hasFilter) {
    return (
      <div className="px-4 py-2 text-xs text-muted-foreground border border-dashed">
        Adj meg legalább egy szűrőt: <code>doctor_id</code>, <code>specialty_id</code> vagy <code>org_unit_id</code>.
      </div>
    );
  }
  if (q.isLoading) return <div className="max-w-3xl mx-auto px-4 my-6 text-sm text-muted-foreground">Időpontok betöltése…</div>;

  const slots = ((q.data as any)?.slots ?? []) as Array<{ id: string; kezdo_ts: string; veg_ts: string }>;
  const byDay = new Map<string, typeof slots>();
  for (const s of slots) {
    const day = new Date(s.kezdo_ts).toLocaleDateString("hu-HU", { weekday: "short", month: "short", day: "numeric" });
    if (!byDay.has(day)) byDay.set(day, []);
    byDay.get(day)!.push(s);
  }

  return (
    <section className="max-w-3xl mx-auto px-4 sm:px-6 my-8">
      {content?.title && <h2 className="text-2xl font-semibold mb-4">{content.title}</h2>}
      {slots.length === 0 ? (
        <div className="text-sm text-muted-foreground border rounded-lg p-4 bg-card">
          A következő {params.days} napban nincs szabad időpont.
        </div>
      ) : (
        <div className="space-y-3">
          {[...byDay.entries()].slice(0, 7).map(([day, items]) => (
            <div key={day} className="border rounded-lg p-3 bg-card">
              <div className="text-sm font-medium mb-2">{day}</div>
              <div className="flex flex-wrap gap-1.5">
                {items.slice(0, 12).map((s) => (
                  <Link
                    key={s.id}
                    to="/foglalas/uj"
                    className="text-xs px-2 py-1.5 rounded border bg-background hover:bg-accent min-h-9 inline-flex items-center"
                  >
                    {new Date(s.kezdo_ts).toLocaleTimeString("hu-HU", { hour: "2-digit", minute: "2-digit" })}
                  </Link>
                ))}
                {items.length > 12 && <span className="text-xs text-muted-foreground self-center">+{items.length - 12}</span>}
              </div>
            </div>
          ))}
        </div>
      )}
      <div className="mt-4">
        <Button asChild className="gap-1 min-h-11">
          <Link to="/foglalas/uj"><CalendarCheck className="size-4" /> Időpontfoglalás</Link>
        </Button>
      </div>
    </section>
  );
}

/* ---------------- Foglalási widget (mini-slotok + prefill CTA) ---------------- */

export function DynBookingWidget({ content }: { content: any }) {
  const fn = useServerFn(getDoctorSchedule);
  const params = {
    doctor_id: content?.doctor_id || undefined,
    specialty_id: content?.specialty_id || undefined,
    org_unit_id: content?.org_unit_id || undefined,
    days: Number(content?.days ?? 7),
  };
  const hasFilter = !!(params.doctor_id || params.specialty_id || params.org_unit_id);
  const maxSlots = Math.max(1, Math.min(12, Number(content?.max_slots ?? 6)));

  const q = useQuery({
    queryKey: ["dyn-booking-widget", params],
    queryFn: () => fn({ data: params as any }),
    enabled: hasFilter,
    staleTime: 60_000,
  });

  // Prefill search a listaoldalhoz
  const listSearch: Record<string, string> = {};
  if (params.doctor_id) listSearch.orvos_id = params.doctor_id;
  if (params.specialty_id) listSearch.szakma_id = params.specialty_id;
  if (params.org_unit_id) listSearch.org_unit_id = params.org_unit_id;

  const slots = ((q.data as any)?.slots ?? []) as Array<{ id: string; kezdo_ts: string }>;
  const upcoming = slots.slice(0, maxSlots);

  const title = content?.title || "Foglaljon időpontot";
  const lead = content?.lead || "Válasszon a következő szabad időpontok közül, vagy nézze meg az összeset.";

  return (
    <section className="max-w-3xl mx-auto px-4 sm:px-6 my-8">
      <div className="border rounded-xl p-4 sm:p-6 bg-card shadow-sm">
        <div className="flex items-start justify-between gap-3 mb-3 flex-wrap">
          <div className="min-w-0">
            <h2 className="text-xl sm:text-2xl font-semibold">{title}</h2>
            {lead && <p className="text-sm text-muted-foreground mt-1">{lead}</p>}
          </div>
          <Button asChild className="gap-1 min-h-11">
            <Link to="/foglalas" search={listSearch as any}>
              <CalendarCheck className="size-4" /> Összes időpont
            </Link>
          </Button>
        </div>

        {!hasFilter && (
          <div className="text-xs text-muted-foreground border border-dashed rounded p-3">
            Adj meg <code>doctor_id</code>, <code>specialty_id</code> vagy <code>org_unit_id</code> értéket.
          </div>
        )}

        {hasFilter && q.isLoading && (
          <div className="text-sm text-muted-foreground">Következő szabad időpontok betöltése…</div>
        )}

        {hasFilter && !q.isLoading && upcoming.length === 0 && (
          <div className="text-sm text-muted-foreground border rounded-lg p-4 bg-background">
            A következő {params.days} napban nincs szabad időpont.{" "}
            <Link to="/foglalas" search={listSearch as any} className="text-primary hover:underline">
              Nézze meg később
            </Link>
            .
          </div>
        )}

        {upcoming.length > 0 && (
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {upcoming.map((s) => {
              const d = new Date(s.kezdo_ts);
              const dateLabel = d.toLocaleDateString("hu-HU", { month: "short", day: "numeric", weekday: "short" });
              const timeLabel = d.toLocaleTimeString("hu-HU", { hour: "2-digit", minute: "2-digit" });
              return (
                <Link
                  key={s.id}
                  to="/foglalas/uj"
                  search={{ slot_id: s.id }}
                  className="border rounded-lg p-3 bg-background hover:bg-accent transition-colors min-h-16 flex flex-col justify-center"
                >
                  <span className="text-xs text-muted-foreground">{dateLabel}</span>
                  <span className="text-base font-semibold">{timeLabel}</span>
                </Link>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
}
