/**
 * Hír-specifikus dinamikus blokkok: hero, kapcsolódó cikkek, megosztó sáv.
 * Anon-safe: a listázást és metadata-t a meglévő public server functionök adják.
 */
import { Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ShareButton } from "@/components/cms/reading-enhancements";
import { SmartImage } from "@/components/ui/smart-image";
import { listPublishedNews, getPublishedNewsBySlug } from "@/lib/cms/news.functions";
import { Calendar, User } from "lucide-react";

function formatDate(iso?: string | null) {
  if (!iso) return "";
  try { return new Date(iso).toLocaleDateString("hu-HU", { year: "numeric", month: "long", day: "numeric" }); }
  catch { return ""; }
}

/**
 * News hero — nagy borító + cím + kivonat + metaadatok.
 * Ha `post_slug` van megadva, kiegészíti a friss kategória/szerző/dátum adattal.
 */
export function NewsHeroBlock({
  title, excerpt, cover, cover_alt, post_slug, locale = "hu",
}: { title?: string; excerpt?: string; cover?: string; cover_alt?: string; post_slug?: string; locale?: string }) {
  const fn = useServerFn(getPublishedNewsBySlug);
  const q = useQuery({
    queryKey: ["news-hero-meta", post_slug, locale],
    queryFn: () => fn({ data: { slug: post_slug!, locale } }),
    enabled: !!post_slug,
    staleTime: 60_000,
  });
  const post: any = q.data ?? null;
  const displayCover = cover || post?.featured_image_url;
  const displayTitle = title || post?.title;
  const displayExcerpt = excerpt || post?.excerpt;

  return (
    <section className="mb-6 sm:mb-8">
      {displayCover && (
        <div className="aspect-[16/9] rounded-lg overflow-hidden mb-6 bg-muted">
          <SmartImage src={displayCover} alt={cover_alt ?? displayTitle ?? ""}
            sizesPreset="hero" priority className="w-full h-full object-cover" />
        </div>
      )}
      <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground mb-3">
        {post?.cms_news_categories?.name && (
          <Badge variant="secondary">{post.cms_news_categories.name}</Badge>
        )}
        {post?.published_at && (
          <span className="inline-flex items-center gap-1"><Calendar className="h-3 w-3" /> {formatDate(post.published_at)}</span>
        )}
        {post?.cms_news_authors?.display_name && (
          <span className="inline-flex items-center gap-1"><User className="h-3 w-3" /> {post.cms_news_authors.display_name}</span>
        )}
      </div>
      {displayTitle && (
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-serif font-bold mb-3 break-words">{displayTitle}</h1>
      )}
      {displayExcerpt && (
        <p className="text-base sm:text-lg text-muted-foreground leading-relaxed">{displayExcerpt}</p>
      )}
    </section>
  );
}

/**
 * Megosztó sáv — natív Share API-t vagy vágólap fallback-et használ.
 */
export function ShareBarBlock({ title }: { title?: string }) {
  return (
    <div className="flex flex-wrap items-center gap-2 my-4 py-3 border-y">
      <span className="text-sm text-muted-foreground mr-2">Megosztás:</span>
      <ShareButton title={title ?? ""} />
    </div>
  );
}

/**
 * Kapcsolódó hírek — a poszt kategóriája alapján legfrissebb N másik cikk.
 */
export function NewsRelatedBlock({
  title = "Kapcsolódó cikkek", post_slug, limit = 3, locale = "hu",
}: { title?: string; post_slug?: string; limit?: number; locale?: string }) {
  const bySlug = useServerFn(getPublishedNewsBySlug);
  const listFn = useServerFn(listPublishedNews);

  const postQ = useQuery({
    queryKey: ["news-related-post", post_slug, locale],
    queryFn: () => bySlug({ data: { slug: post_slug!, locale } }),
    enabled: !!post_slug,
    staleTime: 60_000,
  });
  const post: any = postQ.data ?? null;
  const category = post?.cms_news_categories?.slug;

  const listQ = useQuery({
    queryKey: ["news-related-list", category, locale, limit],
    queryFn: () => listFn({ data: { locale, limit: limit + 1, category } }),
    enabled: !!category,
    staleTime: 60_000,
  });
  const related = ((listQ.data as any)?.posts ?? [])
    .filter((p: any) => p.slug !== post_slug)
    .slice(0, limit);

  if (!related.length) return null;

  return (
    <section className="mt-12 pt-8 border-t">
      {title && <h2 className="text-xl font-serif font-semibold mb-4">{title}</h2>}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {related.map((p: any) => (
          <Link
            key={p.id}
            to="/hirek/$slug"
            params={{ slug: p.slug }}
            className="group block rounded-lg border bg-card overflow-hidden hover:shadow-md transition-shadow"
          >
            {p.featured_image_url && (
              <div className="aspect-[16/9] bg-muted overflow-hidden">
                <SmartImage src={p.featured_image_url} alt={p.featured_image_alt ?? p.title}
                  sizesPreset="card" className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
              </div>
            )}
            <div className="p-3">
              <h3 className="font-semibold text-sm group-hover:text-primary leading-snug line-clamp-2">{p.title}</h3>
              <div className="text-xs text-muted-foreground mt-1">{formatDate(p.published_at)}</div>
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
}
