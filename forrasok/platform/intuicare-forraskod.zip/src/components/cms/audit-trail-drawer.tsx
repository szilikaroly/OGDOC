import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { useMemo, useState } from "react";
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { listAuditTrail, revertToVersion, type WorkflowEntity } from "@/lib/cms/workflow.functions";
import { History, RotateCcw, ChevronDown, GitCompare } from "lucide-react";
import { VersionDiffDialog } from "./version-diff-dialog";

const ACTION_LABEL: Record<string, string> = {
  create: "Létrehozás",
  update: "Módosítás",
  delete: "Törlés",
  submit_review: "Beküldés véleményezésre",
  approve: "Jóváhagyás",
  reject: "Elutasítás",
  publish: "Publikálás",
  unpublish: "Visszavonás",
  revert: "Visszaállítás",
  restore: "Helyreállítás",
};

export function AuditTrailDrawer({
  entity_type, entity_id, trigger,
}: {
  entity_type: WorkflowEntity;
  entity_id: string;
  trigger?: React.ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const [selA, setSelA] = useState<string | null>(null);
  const [selB, setSelB] = useState<string | null>(null);
  const [diffOpen, setDiffOpen] = useState(false);
  const listFn = useServerFn(listAuditTrail);
  const revertFn = useServerFn(revertToVersion);
  const qc = useQueryClient();

  const { data, isLoading } = useQuery({
    queryKey: ["audit-trail", entity_type, entity_id, open],
    queryFn: () => listFn({ data: { entity_type, entity_id, limit: 100, offset: 0 } }),
    enabled: open,
  });

  const rows = (data?.rows ?? []) as any[];
  const rowA = useMemo(() => rows.find((r) => r.id === selA), [rows, selA]);
  const rowB = useMemo(() => rows.find((r) => r.id === selB), [rows, selB]);

  function toggleSel(id: string) {
    if (selA === id) { setSelA(selB); setSelB(null); return; }
    if (selB === id) { setSelB(null); return; }
    if (!selA) { setSelA(id); return; }
    if (!selB) { setSelB(id); return; }
    // mindkettő foglalt — B-t cseréljük
    setSelB(id);
  }

  const revertM = useMutation({
    mutationFn: (input: any) => revertFn(input),
    onSuccess: () => {
      toast.success("Visszaállítva");
      qc.invalidateQueries();
    },
    onError: (e: any) => toast.error(e?.message ?? "Hiba"),
  });

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        {trigger ?? (
          <Button size="sm" variant="outline" className="min-h-9 gap-1.5">
            <History className="h-3.5 w-3.5" /> Napló
          </Button>
        )}
      </SheetTrigger>
      <SheetContent className="w-full sm:max-w-xl overflow-y-auto">
        <SheetHeader>
          <SheetTitle>Audit napló</SheetTitle>
        </SheetHeader>

        {(selA || selB) && (
          <div className="mt-3 flex items-center gap-2 rounded-md border border-primary/40 bg-primary/5 p-2 text-xs">
            <span className="font-medium">Kiválasztott verziók:</span>
            <Badge variant="outline">A: {selA ? "✓" : "—"}</Badge>
            <Badge variant="outline">B: {selB ? "✓" : "—"}</Badge>
            <Button
              size="sm" variant="default" className="ml-auto gap-1.5"
              disabled={!selA || !selB}
              onClick={() => setDiffOpen(true)}
            >
              <GitCompare className="h-3 w-3" /> Összehasonlít
            </Button>
            <Button size="sm" variant="ghost" onClick={() => { setSelA(null); setSelB(null); }}>
              Töröl
            </Button>
          </div>
        )}

        {isLoading ? (
          <p className="text-muted-foreground mt-4">Betöltés…</p>
        ) : rows.length === 0 ? (
          <p className="text-muted-foreground mt-4">Nincs naplóbejegyzés.</p>
        ) : (
          <ol className="mt-4 space-y-3">
            {rows.map((r: any) => (
              <li key={r.id} className={`border rounded-lg p-3 ${selA === r.id || selB === r.id ? "border-primary bg-primary/5" : ""}`}>
                <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                  {r.before && (
                    <Checkbox
                      checked={selA === r.id || selB === r.id}
                      onCheckedChange={() => toggleSel(r.id)}
                      aria-label="Verzió kiválasztása összehasonlításhoz"
                    />
                  )}
                  <Badge variant="secondary">{ACTION_LABEL[r.action] ?? r.action}</Badge>
                  <span>{new Date(r.created_at).toLocaleString("hu-HU")}</span>
                  <span>· {r.actor_email ?? r.actor_id ?? "rendszer"}</span>
                </div>
                {r.comment && (
                  <p className="text-sm mt-2 italic">„{r.comment}"</p>
                )}
                {r.diff && Object.keys(r.diff).length > 0 && (
                  <details className="mt-2">
                    <summary className="cursor-pointer text-xs text-primary inline-flex items-center gap-1">
                      <ChevronDown className="h-3 w-3" /> Változott mezők ({Object.keys(r.diff).length})
                    </summary>
                    <div className="mt-2 space-y-1 text-xs font-mono">
                      {Object.entries(r.diff).map(([k, v]) => (
                        <div key={k} className="border-l-2 border-primary pl-2">
                          <div className="font-semibold not-italic font-sans">{k}</div>
                          <div className="text-destructive line-through whitespace-pre-wrap break-all opacity-70">
                            {JSON.stringify((r.before ?? {})[k])}
                          </div>
                          <div className="text-emerald-700 dark:text-emerald-400 whitespace-pre-wrap break-all">
                            {JSON.stringify(v)}
                          </div>
                        </div>
                      ))}
                    </div>
                  </details>
                )}
                {r.before && (r.action === "update" || r.action === "publish" || r.action === "revert") && (
                  <div className="mt-2 flex gap-2">
                    <Button size="sm" variant="outline" className="gap-1.5"
                      disabled={revertM.isPending}
                      onClick={() => {
                        if (confirm("Visszaállítod a tartalmat erre az állapotra? Az aktuális verzió felülíródik (vázlatként).")) {
                          revertM.mutate({ data: { entity_type, entity_id, audit_log_id: r.id, mode: "full" } });
                        }
                      }}>
                      <RotateCcw className="h-3 w-3" /> Visszaállítás (teljes)
                    </Button>
                    {r.diff && Object.keys(r.diff).length > 0 && (
                      <Button size="sm" variant="ghost" className="gap-1.5"
                        disabled={revertM.isPending}
                        onClick={() => {
                          if (confirm("Csak az ezen a lépésen változott mezőket állítom vissza. OK?")) {
                            revertM.mutate({ data: { entity_type, entity_id, audit_log_id: r.id, mode: "diff" } });
                          }
                        }}>
                        <RotateCcw className="h-3 w-3" /> Csak a változások
                      </Button>
                    )}
                  </div>
                )}
              </li>
            ))}
          </ol>
        )}
      </SheetContent>
      <VersionDiffDialog
        open={diffOpen}
        onOpenChange={setDiffOpen}
        a={rowA?.before ?? rowA?.after ?? null}
        b={rowB?.before ?? rowB?.after ?? null}
        labelA={rowA ? `${ACTION_LABEL[rowA.action] ?? rowA.action} · ${new Date(rowA.created_at).toLocaleString("hu-HU")}` : "—"}
        labelB={rowB ? `${ACTION_LABEL[rowB.action] ?? rowB.action} · ${new Date(rowB.created_at).toLocaleString("hu-HU")}` : "—"}
      />
    </Sheet>
  );
}
