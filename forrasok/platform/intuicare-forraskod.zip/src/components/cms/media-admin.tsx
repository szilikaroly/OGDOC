import { useState, useRef } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { listMedia, registerMedia, deleteMedia, signMediaUrl } from "@/lib/cms/cms.functions";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Upload, Trash2, Copy } from "lucide-react";
import { toast } from "sonner";
import { convertToWebp, shouldConvertImage } from "@/lib/cms/image-convert";
import { CardGridSkeleton } from "@/components/ui/list-skeletons";
import { haptic } from "@/lib/query/optimistic";

export function MediaAdmin() {
  const qc = useQueryClient();
  const listFn = useServerFn(listMedia);
  const regFn = useServerFn(registerMedia);
  const delFn = useServerFn(deleteMedia);
  const signFn = useServerFn(signMediaUrl);
  const { data: media = [], isLoading } = useQuery({ queryKey: ["cms-media"], queryFn: () => listFn() });
  const fileRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [webpOn, setWebpOn] = useState(true);

  const handleUpload = async (files: FileList | null) => {
    if (!files?.length) return;
    setUploading(true);
    let savedBytes = 0;
    try {
      for (const original of Array.from(files)) {
        let file = original;
        if (webpOn && shouldConvertImage(original)) {
          const converted = await convertToWebp(original, { maxWidth: 2000, quality: 0.85 });
          if (converted !== original) {
            savedBytes += original.size - converted.size;
            file = converted;
          }
        }
        const path = `${Date.now()}-${file.name.replace(/[^a-zA-Z0-9.-]/g, "_")}`;
        const { error: upErr } = await supabase.storage.from("cms-media").upload(path, file);
        if (upErr) throw upErr;
        await regFn({ data: { storage_path: path, file_name: file.name, mime_type: file.type, size_bytes: file.size } });
      }
      const saved = savedBytes > 0 ? ` (–${(savedBytes / 1024).toFixed(0)} KB megtakarítva)` : "";
      toast.success(`Feltöltve${saved}`);
      qc.invalidateQueries({ queryKey: ["cms-media"] });
    } catch (e: any) { toast.error(e.message); }
    finally { setUploading(false); if (fileRef.current) fileRef.current.value = ""; }
  };

  const copyUrl = async (path: string) => {
    const r = await signFn({ data: { path } });
    if (r.url) { navigator.clipboard.writeText(r.url); toast.success("URL másolva"); }
  };

  const remove = async (m: any) => {
    if (!confirm(`Töröljük: ${m.file_name}?`)) return;
    await delFn({ data: { id: m.id, storage_path: m.storage_path } });
    qc.invalidateQueries({ queryKey: ["cms-media"] });
  };

  return (
    <div className="space-y-4 mt-4">
      <div className="grid grid-cols-1 sm:flex sm:flex-wrap sm:items-center gap-2 sm:gap-3">
        <Input ref={fileRef} type="file" multiple onChange={e => handleUpload(e.target.files)} disabled={uploading} className="min-h-11 sm:max-w-md" />
        <Button disabled={uploading} className="min-h-11" onClick={() => { haptic(8); fileRef.current?.click(); }}><Upload className="h-4 w-4 sm:mr-1" /><span className="hidden sm:inline">Feltöltés</span></Button>
        <label className="flex items-center gap-2 text-xs text-muted-foreground cursor-pointer min-h-11">
          <Checkbox checked={webpOn} onCheckedChange={(v) => setWebpOn(v === true)} />
          WebP konverzió + max 2000px (kisebb fájl)
        </label>
      </div>
      {isLoading ? <CardGridSkeleton cards={8} /> : (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3" style={{ contentVisibility: "auto" as any, containIntrinsicSize: "600px" as any }}>
          {media.map((m: any) => (
            <Card key={m.id} className="p-3 space-y-2">
              <div className="text-xs truncate font-medium">{m.file_name}</div>
              <div className="text-[10px] text-muted-foreground">{m.mime_type} · {(m.size_bytes / 1024).toFixed(0)} KB</div>
              <div className="flex gap-1">
                <Button size="sm" variant="ghost" className="flex-1 min-h-11" onClick={() => copyUrl(m.storage_path)} aria-label="URL másolása"><Copy className="h-4 w-4" /></Button>
                <Button size="sm" variant="ghost" className="min-h-11 min-w-11" onClick={() => remove(m)} aria-label="Törlés"><Trash2 className="h-4 w-4 text-destructive" /></Button>
              </div>
            </Card>
          ))}
          {!media.length && <div className="text-sm text-muted-foreground p-4 col-span-full text-center">Még nincs feltöltött fájl.</div>}
        </div>
      )}
    </div>
  );
}
