import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { getCmsGlobalStats } from "@/lib/cms/cms.functions";
import { Card } from "@/components/ui/card";
import { Eye, FileText, CheckCircle2, FileEdit } from "lucide-react";
import { Link } from "@tanstack/react-router";

export function CmsAnalytics() {
  const fn = useServerFn(getCmsGlobalStats);
  const { data, isLoading } = useQuery({
    queryKey: ["cms-global-stats", 30],
    queryFn: () => fn({ data: { days: 30 } }),
    staleTime: 60_000,
  });

  if (isLoading) {
    return <div className="text-sm text-muted-foreground py-8 text-center">Statisztikák betöltése…</div>;
  }
  if (!data) return null;

  const maxVal = Math.max(1, ...data.series.map((s: any) => s.views));

  return (
    <div className="space-y-4 mt-4">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard icon={<FileText className="h-4 w-4" />} label="Összes oldal" value={data.totalPages} />
        <KpiCard icon={<CheckCircle2 className="h-4 w-4 text-green-600" />} label="Publikálva" value={data.publishedPages} />
        <KpiCard icon={<FileEdit className="h-4 w-4 text-yellow-600" />} label="Piszkozat" value={data.draftPages} />
        <KpiCard icon={<Eye className="h-4 w-4 text-primary" />} label={`${data.days} napos megtekintés`} value={data.totalWindow.toLocaleString("hu-HU")} hint={`Összes idő: ${data.totalAllTime.toLocaleString("hu-HU")}`} />
      </div>

      <Card className="p-3 sm:p-4">
        <div className="text-sm font-semibold mb-2">Napi megtekintések (utolsó {data.days} nap)</div>
        <div className="flex items-end gap-[2px] h-32 border rounded p-2 bg-muted/20">
          {data.series.map((c: any, i: number) => (
            <div
              key={i}
              title={`${c.day}: ${c.views}`}
              className="flex-1 bg-primary/70 hover:bg-primary rounded-sm transition-colors"
              style={{ height: `${(c.views / maxVal) * 100}%`, minHeight: "2px" }}
            />
          ))}
        </div>
        <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
          <span>{data.series[0]?.day}</span>
          <span>{data.series[data.series.length - 1]?.day}</span>
        </div>
      </Card>

      <Card className="p-3 sm:p-4">
        <div className="text-sm font-semibold mb-3">Top 10 oldal — utolsó {data.days} nap</div>
        {data.top.length === 0 || data.top.every((t: any) => t.windowViews === 0) ? (
          <div className="text-sm text-muted-foreground py-4 text-center">Még nincs megtekintési adat ebben az időszakban.</div>
        ) : (
          <div className="space-y-1.5">
            {data.top.map((p: any, idx: number) => {
              const max = Math.max(1, data.top[0].windowViews);
              const pct = (p.windowViews / max) * 100;
              return (
                <div key={p.id} className="grid grid-cols-[20px_minmax(0,1fr)_auto] items-center gap-2 text-sm">
                  <span className="text-xs text-muted-foreground tabular-nums">{idx + 1}.</span>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <Link
                        to="/o/$slug"
                        params={{ slug: p.slug }}
                        target="_blank"
                        className="font-medium truncate hover:underline"
                      >
                        {p.title}
                      </Link>
                      <span className="text-[10px] uppercase font-semibold px-1.5 py-0.5 rounded-full bg-secondary text-secondary-foreground shrink-0">{p.locale}</span>
                    </div>
                    <div className="relative h-1 bg-muted rounded overflow-hidden mt-1">
                      <div className="absolute inset-y-0 left-0 bg-primary" style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-semibold tabular-nums">{p.windowViews.toLocaleString("hu-HU")}</div>
                    <div className="text-[10px] text-muted-foreground tabular-nums">össz: {(p.view_count ?? 0).toLocaleString("hu-HU")}</div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </Card>
    </div>
  );
}

function KpiCard({ icon, label, value, hint }: { icon: React.ReactNode; label: string; value: number | string; hint?: string }) {
  return (
    <Card className="p-3">
      <div className="flex items-center gap-2 text-xs text-muted-foreground">{icon}{label}</div>
      <div className="text-2xl font-bold mt-1 tabular-nums">{value}</div>
      {hint && <div className="text-[10px] text-muted-foreground mt-0.5">{hint}</div>}
    </Card>
  );
}
