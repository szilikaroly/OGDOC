/**
 * Élő, in-site előnézet a hír/blog/vlog szerkesztőhöz.
 * A nem mentett tartalmat azonnal mutatja iframe-ben (srcDoc),
 * mobil/tablet/desktop nézetváltóval. Ha van mentett preview-link,
 * az „Oldalon megnyitás” gomb a valódi oldalra visz.
 */
import { useMemo, useState } from "react";
import { sanitizeCmsHtml } from "@/lib/cms/sanitize-html";
import { usePreviewDevice, PreviewToolbar, PreviewFrame } from "@/components/cms/visual/preview-toolbar";

export function NewsLivePreview({
  title,
  excerpt,
  coverUrl,
  bodyHtml,
  siteUrl,
}: {
  title?: string;
  excerpt?: string | null;
  coverUrl?: string | null;
  bodyHtml?: string;
  siteUrl?: string | null;
}) {
  const [device, setDevice] = usePreviewDevice();
  const [nonce, setNonce] = useState(0);

  const srcDoc = useMemo(() => {
    const safe = sanitizeCmsHtml(bodyHtml ?? "");
    return `<!doctype html><html lang="hu"><head><meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<style>
  :root { color-scheme: light; }
  body { margin:0; padding:24px; font-family: ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif; line-height:1.65; color:#1f2937; background:#fff; }
  img, video, iframe { max-width:100%; border-radius:10px; }
  h1 { font-size:2rem; line-height:1.2; margin:0 0 .5rem; }
  .excerpt { color:#6b7280; margin-bottom:1.5rem; }
  table { width:100%; border-collapse:collapse; }
  td, th { border:1px solid #e5e7eb; padding:.5rem; }
  blockquote { border-left:3px solid #d1d5db; margin:1rem 0; padding-left:1rem; color:#4b5563; }
</style></head><body>
${coverUrl ? `<img src="${coverUrl}" alt="" style="width:100%;margin-bottom:1rem" />` : ""}
<h1>${escapeHtml(title ?? "Cím nélkül")}</h1>
${excerpt ? `<p class="excerpt">${escapeHtml(excerpt)}</p>` : ""}
${safe}
</body></html>`;
  }, [title, excerpt, coverUrl, bodyHtml]);

  return (
    <div className="border rounded-lg overflow-hidden bg-muted/30 flex flex-col min-h-[420px]">
      <div className="flex items-center gap-2 border-b bg-background px-2 py-1.5">
        <span className="text-xs font-semibold text-muted-foreground">ÉLŐ ELŐNÉZET</span>
        <PreviewToolbar
          className="ml-auto"
          size="sm"
          device={device}
          onDeviceChange={setDevice}
          onRefresh={() => setNonce((n) => n + 1)}
          externalUrl={siteUrl ?? undefined}
        />
      </div>
      <div className="flex-1 overflow-auto">
        <PreviewFrame
          device={device}
          srcDoc={srcDoc}
          frameKey={nonce}
          sandbox="allow-same-origin"
          title="Bejegyzés élő előnézet"
        />
      </div>
    </div>
  );
}

function escapeHtml(s: string) {
  return s.replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c] ?? c,
  );
}
