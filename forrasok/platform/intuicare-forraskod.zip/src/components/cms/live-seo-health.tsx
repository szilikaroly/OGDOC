/**
 * Live SEO health panel — client-side, reactive to the form state in the
 * page editor. Shows score, per-issue list, effective title/description
 * previews and the derived canonical URL. Compact enough to embed inside
 * the PageEditor dialog next to the SEO fields.
 */
import { useMemo } from "react";
import { AlertCircle, AlertTriangle, Info, CheckCircle2 } from "lucide-react";
import { lintPageSeo, type SeoLintInput } from "@/lib/cms/seo-lint";

export function LiveSeoHealth({ page }: { page: SeoLintInput }) {
  const result = useMemo(() => lintPageSeo(page), [page]);
  const { score, issues, effectiveTitle, effectiveDescription, canonical } = result;
  const scoreColor = score >= 85 ? "text-green-600" : score >= 60 ? "text-yellow-600" : "text-destructive";
  const ring = score >= 85 ? "ring-green-600/30" : score >= 60 ? "ring-yellow-600/30" : "ring-destructive/30";

  return (
    <div className={`rounded-lg border ring-1 ${ring} p-3 space-y-3 bg-muted/20`}>
      <div className="flex items-center gap-3">
        <div className={`text-2xl font-bold tabular-nums ${scoreColor}`}>{score}</div>
        <div className="text-xs">
          <div className="font-semibold">SEO health (élő)</div>
          <div className="text-muted-foreground">
            {issues.filter(i => i.level === "error").length} hiba · {issues.filter(i => i.level === "warn").length} figyelm. · {issues.filter(i => i.level === "info").length} tipp
          </div>
        </div>
      </div>

      {/* SERP preview */}
      <div className="rounded border bg-background p-2 space-y-0.5">
        <div className="text-[11px] text-muted-foreground truncate">{canonical || "/"}</div>
        <div className="text-sm text-primary truncate">{effectiveTitle || <em className="text-muted-foreground">(nincs cím)</em>}</div>
        <div className="text-xs text-muted-foreground line-clamp-2">
          {effectiveDescription || <em>(nincs leírás)</em>}
        </div>
      </div>

      <div className="space-y-1">
        {issues.length === 0 ? (
          <div className="flex items-center gap-2 text-xs text-green-600">
            <CheckCircle2 className="h-3.5 w-3.5" /> Minden rendben.
          </div>
        ) : (
          issues.slice(0, 6).map((i, idx) => (
            <div key={idx} className="flex items-start gap-2 text-xs">
              {i.level === "error" && <AlertCircle className="h-3.5 w-3.5 text-destructive shrink-0 mt-0.5" />}
              {i.level === "warn" && <AlertTriangle className="h-3.5 w-3.5 text-yellow-600 shrink-0 mt-0.5" />}
              {i.level === "info" && <Info className="h-3.5 w-3.5 text-muted-foreground shrink-0 mt-0.5" />}
              <span>{i.msg}</span>
            </div>
          ))
        )}
        {issues.length > 6 && (
          <div className="text-[11px] text-muted-foreground">+{issues.length - 6} további…</div>
        )}
      </div>
    </div>
  );
}
