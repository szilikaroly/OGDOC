/**
 * Auto-generated form editor for a block's `content` object.
 *
 * - Enumerates top-level string / number / boolean fields.
 * - Strings that look like rich text (see isRichTextField) → RichTextEditor.
 * - Short strings → Input.
 * - Multi-line but plain strings → Textarea.
 * - Arrays of objects / nested objects → editable JSON textarea per field.
 *
 * Emits a new content object on every change. The caller (BlockInspector)
 * pipes this through the same autosave path that the JSON view uses.
 */
import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RichTextEditor, isRichTextField } from "./rich-text-editor";
import { LinkPicker, isLinkField } from "./link-picker";
import { listMenus } from "@/lib/cms/cms.functions";

type Content = Record<string, unknown>;

export function BlockFormEditor({
  content,
  onChange,
  blockType,
}: {
  content: Content;
  onChange: (next: Content) => void;
  blockType?: string;
}) {
  const keys = useMemo(
    () => Object.keys(content ?? {}).sort((a, b) => rank(a) - rank(b)),
    [content],
  );

  const patch = (key: string, value: unknown) => {
    onChange({ ...(content ?? {}), [key]: value });
  };

  if (keys.length === 0) {
    return (
      <div className="text-xs text-muted-foreground border rounded-md p-3">
        Ez a blokk üres tartalommal jött. Válts át a JSON nézetre és adj hozzá mezőket.
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {keys.map((k) => {
        const v = (content as any)[k];
        const override = blockType === "nav_menu" ? renderNavMenuField(k, v, (nv) => patch(k, nv)) : null;
        return (
          <div key={k} className="space-y-1">
            <Label className="text-xs font-medium capitalize">{humanize(k)}</Label>
            {override ?? renderField(k, v, (nv) => patch(k, nv))}
          </div>
        );
      })}
    </div>
  );
}

/**
 * nav_menu block: turn free-text `slug`, `variant`, `locale` into selects
 * populated from cms_menus so admins pick the actual menu, not type slugs.
 */
function renderNavMenuField(key: string, value: unknown, onChange: (v: unknown) => void) {
  if (key === "slug") return <MenuSlugSelect value={String(value ?? "")} onChange={(v) => onChange(v)} />;
  if (key === "variant") {
    return (
      <Select value={String(value ?? "horizontal")} onValueChange={onChange as (s: string) => void}>
        <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
        <SelectContent>
          <SelectItem value="horizontal">Vízszintes</SelectItem>
          <SelectItem value="vertical">Függőleges</SelectItem>
          <SelectItem value="footer">Footer (oszlopok)</SelectItem>
        </SelectContent>
      </Select>
    );
  }
  if (key === "locale") {
    return (
      <Select value={String(value ?? "hu")} onValueChange={onChange as (s: string) => void}>
        <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
        <SelectContent>
          <SelectItem value="hu">Magyar (hu)</SelectItem>
          <SelectItem value="en">English (en)</SelectItem>
          <SelectItem value="de">Deutsch (de)</SelectItem>
        </SelectContent>
      </Select>
    );
  }
  return null;
}

function MenuSlugSelect({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const fn = useServerFn(listMenus);
  const { data, isLoading } = useQuery({
    queryKey: ["cms-menus-list"],
    queryFn: () => fn(),
    staleTime: 60_000,
  });
  const menus = (data ?? []) as Array<{ id: string; key: string; name: string }>;
  const known = menus.some((m) => m.key === value);
  return (
    <div className="space-y-1">
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger className="h-9">
          <SelectValue placeholder={isLoading ? "Menük betöltése…" : "Válassz menüt"} />
        </SelectTrigger>
        <SelectContent>
          {menus.map((m) => (
            <SelectItem key={m.id} value={m.key}>
              {m.name} <span className="text-muted-foreground">({m.key})</span>
            </SelectItem>
          ))}
          {!isLoading && menus.length === 0 && (
            <div className="px-2 py-1.5 text-xs text-muted-foreground">Nincs menü. Vedd fel a /admin/cms alatt.</div>
          )}
        </SelectContent>
      </Select>
      {value && !known && !isLoading && (
        <div className="text-[11px] text-amber-600">
          A megadott „{value}" slug nem található a cms_menus táblában.
        </div>
      )}
    </div>
  );
}


function renderField(key: string, value: unknown, onChange: (v: unknown) => void) {
  // boolean
  if (typeof value === "boolean") {
    return (
      <div className="flex items-center gap-2">
        <Switch checked={value} onCheckedChange={onChange} />
        <span className="text-xs text-muted-foreground">{value ? "Igen" : "Nem"}</span>
      </div>
    );
  }
  // number
  if (typeof value === "number") {
    return (
      <Input
        type="number"
        value={value}
        onChange={(e) => onChange(e.target.value === "" ? 0 : Number(e.target.value))}
      />
    );
  }
  // string
  if (typeof value === "string") {
    if (isLinkField(key)) {
      return <LinkPicker value={value} onChange={onChange as (h: string) => void} />;
    }
    if (isRichTextField(key, value)) {
      return <RichTextEditor value={value} onChange={onChange as (h: string) => void} />;
    }
    if (value.includes("\n") || value.length > 80) {
      return (
        <Textarea
          value={value}
          onChange={(e) => onChange(e.target.value)}
          rows={3}
        />
      );
    }
    return <Input value={value} onChange={(e) => onChange(e.target.value)} />;
  }
  // null / undefined
  if (value == null) {
    return (
      <Input
        placeholder="(üres)"
        value=""
        onChange={(e) => onChange(e.target.value)}
      />
    );
  }
  // arrays / objects → JSON textarea
  return (
    <Textarea
      value={JSON.stringify(value, null, 2)}
      onChange={(e) => {
        try { onChange(JSON.parse(e.target.value)); } catch { /* ignore until valid */ }
      }}
      rows={6}
      className="font-mono text-xs"
    />
  );
}

function humanize(k: string): string {
  return k.replace(/[_-]+/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}

// Show title-like fields first, then body-like, then everything else
function rank(k: string): number {
  const l = k.toLowerCase();
  if (["title", "heading", "name"].includes(l)) return 0;
  if (["subtitle", "eyebrow", "kicker"].includes(l)) return 1;
  if (["description", "body", "content", "text", "html"].includes(l)) return 2;
  if (l.startsWith("cta") || l.includes("button")) return 3;
  return 5;
}
