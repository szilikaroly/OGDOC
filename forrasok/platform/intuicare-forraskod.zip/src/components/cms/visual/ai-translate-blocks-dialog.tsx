/**
 * AI-fordítás párbeszédablak a vizuális szerkesztőben.
 *
 * Két funkció:
 *  1. "Kiválasztott blokk fordítása" — a jelenleg kijelölt blokk `content`
 *     szöveges mezőit lefordítja a kijelölt célnyelvekre (kiegészítő blokkokat
 *     hoz létre `locale` szerint).
 *  2. "Hiányzó UI-kulcsok kitöltése" — a `processMissingKeys` szerverhívást
 *     futtatja nyelvenként (a t()-alapú hiányzó kulcsokhoz).
 */
import { useMemo, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
  DialogFooter, DialogTrigger,
} from "@/components/ui/dialog";
import { Loader2, Languages } from "lucide-react";
import { toast } from "sonner";
import { SUPPORTED_LANGUAGES } from "@/i18n/languages";
import { translateBlocks } from "@/lib/cms/i18n-blocks.functions";
import { processMissingKeys } from "@/lib/i18n/admin.functions";

type Props = {
  selectedBlockId: string | null;
  onDone?: () => void;
};

export function AiTranslateBlocksDialog({ selectedBlockId, onDone }: Props) {
  const translateFn = useServerFn(translateBlocks);
  const missingFn = useServerFn(processMissingKeys);

  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [overwrite, setOverwrite] = useState(false);
  const defaultTargets = useMemo(
    () => SUPPORTED_LANGUAGES.filter((l) => l.code !== "hu").map((l) => l.code) as string[],
    [],
  );
  const [targets, setTargets] = useState<string[]>(["en", "de", "ro"]);

  const toggle = (code: string) =>
    setTargets((prev) => (prev.includes(code) ? prev.filter((c) => c !== code) : [...prev, code]));

  const runBlockTranslate = async () => {
    if (!selectedBlockId) {
      toast.error("Nincs kijelölt blokk");
      return;
    }
    if (!targets.length) {
      toast.error("Válassz legalább egy célnyelvet");
      return;
    }
    setBusy(true);
    try {
      const res: any = await translateFn({
        data: {
          block_ids: [selectedBlockId],
          target_langs: targets as any,
          source_lang: "hu",
          overwrite_edited: overwrite,
        },
      });
      const skipped = (res.summary ?? []).filter((s: any) => s.error === "skipped (exists)").length;
      toast.success(`Fordítás kész: ${res.translated} nyelvre`, {
        description: skipped ? `${skipped} nyelv kihagyva (már létezik – kapcsold be a felülírást)` : undefined,
      });
      onDone?.();
      setOpen(false);
    } catch (e: any) {
      toast.error("AI fordítás sikertelen", { description: e?.message?.slice(0, 200) });
    } finally {
      setBusy(false);
    }
  };

  const runMissingKeys = async () => {
    if (!targets.length) {
      toast.error("Válassz legalább egy célnyelvet");
      return;
    }
    setBusy(true);
    try {
      let total = 0;
      for (const lang of targets) {
        const res: any = await missingFn({ data: { lang, batch_size: 200 } });
        total += res?.processed ?? 0;
      }
      toast.success(`Hiányzó kulcsok kitöltve: ${total} db`);
    } catch (e: any) {
      toast.error("Hiányzó kulcsok feldolgozása sikertelen", { description: e?.message?.slice(0, 200) });
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-1" title="AI-fordítás célnyelvekre">
          <Languages className="size-4" />AI fordítás
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>AI fordítás</DialogTitle>
          <DialogDescription>
            Válaszd ki a célnyelveket, majd fordítsd le a kiválasztott blokkot, vagy
            töltsd ki a hiányzó UI-kulcsokat AI-jal.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <div className="text-xs font-semibold uppercase text-muted-foreground mb-2">Célnyelvek</div>
            <div className="flex flex-wrap gap-2">
              {SUPPORTED_LANGUAGES.filter((l) => l.code !== "hu").map((l) => {
                const active = targets.includes(l.code);
                return (
                  <button
                    key={l.code}
                    type="button"
                    onClick={() => toggle(l.code)}
                    className={`px-2.5 py-1 rounded border text-sm min-h-9 flex items-center gap-1 transition ${
                      active ? "bg-primary text-primary-foreground border-primary" : "bg-background hover:bg-accent"
                    }`}
                  >
                    <span>{l.flag}</span><span>{l.label}</span>
                  </button>
                );
              })}
            </div>
            <div className="flex gap-2 mt-2 text-xs">
              <button type="button" className="underline text-muted-foreground" onClick={() => setTargets(defaultTargets)}>Mind</button>
              <button type="button" className="underline text-muted-foreground" onClick={() => setTargets([])}>Egyik sem</button>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Checkbox id="overwrite" checked={overwrite} onCheckedChange={(v) => setOverwrite(Boolean(v))} />
            <Label htmlFor="overwrite" className="text-sm cursor-pointer">
              Meglévő fordítások felülírása
            </Label>
          </div>

          <div className="rounded-md border p-3 bg-muted/30 text-xs space-y-1">
            {selectedBlockId ? (
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="text-[10px]">Blokk kiválasztva</Badge>
                <span className="text-muted-foreground truncate font-mono">{selectedBlockId.slice(0, 8)}…</span>
              </div>
            ) : (
              <div className="text-muted-foreground">Nincs kijelölt blokk – a blokk-fordítás inaktív. A hiányzó UI-kulcsok kitöltése továbbra is elérhető.</div>
            )}
          </div>
        </div>

        <DialogFooter className="gap-2 sm:gap-2 flex-col sm:flex-row">
          <Button variant="outline" onClick={runMissingKeys} disabled={busy || !targets.length}>
            {busy ? <Loader2 className="size-4 animate-spin mr-1" /> : null}
            Hiányzó UI-kulcsok kitöltése
          </Button>
          <Button onClick={runBlockTranslate} disabled={busy || !selectedBlockId || !targets.length} className="gap-1">
            {busy ? <Loader2 className="size-4 animate-spin" /> : <Languages className="size-4" />}
            Kiválasztott blokk fordítása
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
