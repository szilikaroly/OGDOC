/**
 * Right-side drawer listing every pending block draft for the current page.
 * Publishers can approve/reject per block or bulk-approve all.
 */
import { useMemo, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { ClipboardCheck, Check, X, Loader2 } from "lucide-react";
import { toast } from "sonner";
import {
  listPendingDraftsForPage,
  approveBlockDraft,
  rejectBlockDraft,
  bulkApproveDrafts,
} from "@/lib/cms/block-drafts.functions";

export function PendingChangesDrawer({ pageId, onApplied }: { pageId: string; onApplied: () => void }) {
  const qc = useQueryClient();
  const listFn = useServerFn(listPendingDraftsForPage);
  const approveFn = useServerFn(approveBlockDraft);
  const rejectFn = useServerFn(rejectBlockDraft);
  const bulkFn = useServerFn(bulkApproveDrafts);

  const q = useQuery({
    queryKey: ["cms-pending-drafts", pageId],
    queryFn: () => listFn({ data: { pageId } }),
  });
  const drafts = (q.data ?? []) as any[];
  const [note, setNote] = useState("");

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ["cms-pending-drafts", pageId] });
    onApplied();
  };

  const approve = useMutation({
    mutationFn: async (id: string) => approveFn({ data: { blockId: id, note: note || null } }),
    onSuccess: () => { toast.success("Jóváhagyva"); refresh(); },
    onError: (e: any) => toast.error(e.message ?? "Hiba"),
  });
  const reject = useMutation({
    mutationFn: async (id: string) => rejectFn({ data: { blockId: id, note: note || null } }),
    onSuccess: () => { toast.success("Elutasítva"); refresh(); },
  });
  const bulk = useMutation({
    mutationFn: async () => bulkFn({ data: { blockIds: drafts.map((d) => d.id), note: note || null } }),
    onSuccess: (r: any) => { toast.success(`${r.approved} blokk jóváhagyva`); refresh(); },
  });

  const count = drafts.length;
  const title = useMemo(() => (count > 0 ? `Függő módosítások (${count})` : "Függő módosítások"), [count]);

  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant={count > 0 ? "default" : "outline"} className="gap-1 relative">
          <ClipboardCheck className="size-4" />
          Jóváhagyásra vár
          {count > 0 && (
            <Badge className="ml-1 bg-amber-500 text-white">{count}</Badge>
          )}
        </Button>
      </SheetTrigger>
      <SheetContent side="right" className="w-[min(560px,100vw)] sm:max-w-none overflow-y-auto">
        <SheetHeader>
          <SheetTitle>{title}</SheetTitle>
        </SheetHeader>
        <div className="space-y-3 py-3">
          <Textarea
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="Megjegyzés a jóváhagyáshoz / elutasításhoz (opcionális)"
            rows={2}
          />
          <div className="flex gap-2">
            <Button onClick={() => bulk.mutate()} disabled={!count || bulk.isPending} className="gap-1">
              {bulk.isPending ? <Loader2 className="size-4 animate-spin" /> : <Check className="size-4" />}
              Mind jóváhagy
            </Button>
          </div>

          {q.isLoading && <div className="text-sm text-muted-foreground">Betöltés…</div>}
          {!q.isLoading && drafts.length === 0 && (
            <div className="text-sm text-muted-foreground p-4 border rounded bg-muted/30">
              Nincs függő blokk-módosítás ezen az oldalon.
            </div>
          )}

          <div className="space-y-3">
            {drafts.map((d) => (
              <DraftDiffCard
                key={d.id}
                draft={d}
                onApprove={() => approve.mutate(d.id)}
                onReject={() => reject.mutate(d.id)}
                disabled={approve.isPending || reject.isPending}
              />
            ))}
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}

function DraftDiffCard({
  draft,
  onApprove,
  onReject,
  disabled,
}: {
  draft: any;
  onApprove: () => void;
  onReject: () => void;
  disabled: boolean;
}) {
  return (
    <div className="border rounded-md p-3 bg-card space-y-2">
      <div className="flex items-center justify-between gap-2">
        <div>
          <div className="text-sm font-semibold">{draft.block_type}</div>
          <div className="text-[11px] text-muted-foreground">
            pos {draft.position} · módosítva {new Date(draft.draft_updated_at).toLocaleString("hu")}
          </div>
        </div>
        <div className="flex gap-1">
          <Button size="sm" variant="outline" onClick={onReject} disabled={disabled} className="gap-1">
            <X className="size-3.5" />Elvet
          </Button>
          <Button size="sm" onClick={onApprove} disabled={disabled} className="gap-1">
            <Check className="size-3.5" />Jóváhagy
          </Button>
        </div>
      </div>
      {draft.draft_note && (
        <div className="text-xs italic text-muted-foreground">„{draft.draft_note}"</div>
      )}
      <div className="grid grid-cols-2 gap-2 text-[11px]">
        <div>
          <div className="font-medium mb-1">Élő (jelenleg)</div>
          <pre className="bg-muted/40 rounded p-2 overflow-auto max-h-48 whitespace-pre-wrap break-all">
            {JSON.stringify(draft.content ?? {}, null, 2)}
          </pre>
        </div>
        <div>
          <div className="font-medium mb-1 text-amber-700">Vázlat (jóváhagyás után)</div>
          <pre className="bg-amber-50 border border-amber-200 rounded p-2 overflow-auto max-h-48 whitespace-pre-wrap break-all">
            {JSON.stringify(draft.draft_content ?? {}, null, 2)}
          </pre>
        </div>
      </div>
    </div>
  );
}
