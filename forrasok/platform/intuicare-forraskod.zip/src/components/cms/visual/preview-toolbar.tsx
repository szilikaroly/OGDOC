/**
 * Egységes előnézet-eszköztár minden CMS szerkesztőhöz.
 *
 * - `usePreviewDevice()` — megosztott (localStorage + eseményszinkron) mobil/tablet/desktop állapot,
 *   így bármelyik szerkesztőben váltasz, mindenhol ugyanaz marad.
 * - `PreviewDeviceSwitcher` — a közös eszközváltó gombsor.
 * - `PreviewToolbar` — eszközváltó + frissítés + előnézet ki/be + új lapon megnyitás.
 * - `PreviewFrame` — középre igazított, eszközszélességre méretezett iframe.
 */
import { useCallback, useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Smartphone, Tablet, Monitor, RefreshCw, ExternalLink, Eye, EyeOff } from "lucide-react";
import { cn } from "@/lib/utils";

export type PreviewDevice = "mobile" | "tablet" | "desktop";

export const PREVIEW_DEVICE_WIDTH: Record<PreviewDevice, number> = {
  mobile: 390,
  tablet: 820,
  desktop: 1280,
};

const STORAGE_KEY = "cms:preview-device";
const EVENT = "cms:preview-device-change";

function readDevice(): PreviewDevice {
  if (typeof window === "undefined") return "desktop";
  const v = window.localStorage.getItem(STORAGE_KEY);
  return v === "mobile" || v === "tablet" || v === "desktop" ? v : "desktop";
}

/** Megosztott eszköz-állapot az összes szerkesztő preview paneljéhez. */
export function usePreviewDevice(): [PreviewDevice, (d: PreviewDevice) => void] {
  const [device, setDeviceState] = useState<PreviewDevice>("desktop");

  useEffect(() => {
    setDeviceState(readDevice());
    const onChange = () => setDeviceState(readDevice());
    window.addEventListener(EVENT, onChange);
    window.addEventListener("storage", onChange);
    return () => {
      window.removeEventListener(EVENT, onChange);
      window.removeEventListener("storage", onChange);
    };
  }, []);

  const setDevice = useCallback((d: PreviewDevice) => {
    setDeviceState(d);
    try {
      window.localStorage.setItem(STORAGE_KEY, d);
    } catch {
      /* private mode */
    }
    window.dispatchEvent(new Event(EVENT));
  }, []);

  return [device, setDevice];
}

export function PreviewDeviceSwitcher({
  value,
  onChange,
  size = "md",
  className,
}: {
  value: PreviewDevice;
  onChange: (d: PreviewDevice) => void;
  size?: "sm" | "md";
  className?: string;
}) {
  const icon = size === "sm" ? "size-3.5" : "size-4";
  return (
    <Tabs value={value} onValueChange={(v) => onChange(v as PreviewDevice)} className={className}>
      <TabsList className={size === "sm" ? "h-8" : "h-9"}>
        <TabsTrigger value="mobile" className="px-2" title="Mobil (390px)" aria-label="Mobil nézet">
          <Smartphone className={icon} />
        </TabsTrigger>
        <TabsTrigger value="tablet" className="px-2" title="Tablet (820px)" aria-label="Tablet nézet">
          <Tablet className={icon} />
        </TabsTrigger>
        <TabsTrigger value="desktop" className="px-2" title="Desktop (1280px)" aria-label="Desktop nézet">
          <Monitor className={icon} />
        </TabsTrigger>
      </TabsList>
    </Tabs>
  );
}

export function PreviewToolbar({
  device,
  onDeviceChange,
  onRefresh,
  showPreview,
  onTogglePreview,
  externalUrl,
  size = "md",
  extra,
  className,
}: {
  device: PreviewDevice;
  onDeviceChange: (d: PreviewDevice) => void;
  onRefresh?: () => void;
  showPreview?: boolean;
  onTogglePreview?: () => void;
  externalUrl?: string | null;
  size?: "sm" | "md";
  extra?: React.ReactNode;
  className?: string;
}) {
  const btn = size === "sm" ? "h-8" : "h-9";
  return (
    <div className={cn("flex items-center gap-1.5", className)}>
      {extra}
      <PreviewDeviceSwitcher value={device} onChange={onDeviceChange} size={size} />
      {onRefresh && (
        <Button size="sm" variant="outline" className={btn} onClick={onRefresh} title="Előnézet frissítése" aria-label="Előnézet frissítése">
          <RefreshCw className="size-4" />
        </Button>
      )}
      {onTogglePreview && (
        <Button size="sm" variant="outline" className={btn} onClick={onTogglePreview}>
          {showPreview ? <EyeOff className="size-4 mr-1" /> : <Eye className="size-4 mr-1" />}
          Előnézet
        </Button>
      )}
      {externalUrl && (
        <Button size="sm" variant="ghost" className={btn} asChild>
          <a href={externalUrl} target="_blank" rel="noreferrer" title="Megnyitás új lapon" aria-label="Megnyitás új lapon">
            <ExternalLink className="size-4" />
          </a>
        </Button>
      )}
    </div>
  );
}

export function PreviewFrame({
  device,
  src,
  srcDoc,
  title = "Élő előnézet",
  frameKey,
  sandbox,
  className,
}: {
  device: PreviewDevice;
  src?: string;
  srcDoc?: string;
  title?: string;
  frameKey?: string | number;
  sandbox?: string;
  className?: string;
}) {
  return (
    <div className="h-full overflow-auto flex justify-center p-3">
      <iframe
        key={frameKey}
        title={title}
        src={src}
        srcDoc={srcDoc}
        sandbox={sandbox}
        style={{ width: PREVIEW_DEVICE_WIDTH[device], maxWidth: "100%" }}
        className={cn("h-full min-h-[380px] rounded-md border bg-background shadow-sm transition-all", className)}
      />
    </div>
  );
}
