/**
 * TipTap-based WYSIWYG editor used inside the CMS block inspector.
 *
 * - HTML in, HTML out (stored as string on the block's content field).
 * - Minimal toolbar: bold/italic, headings, list, link, undo/redo, source.
 * - Drag & drop / paste images → auto-upload into CMS media library.
 * - Selected image → floating resize handle (drag to change width %).
 * - Toolbar shows image controls when an image is selected:
 *   align left/center/right + width presets (25/50/75/100%).
 * - Click on an inserted image to open the alt/link edit dialog.
 */
import { useEditor, EditorContent } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Link from "@tiptap/extension-link";
import Placeholder from "@tiptap/extension-placeholder";
import Image from "@tiptap/extension-image";
import { Table } from "@tiptap/extension-table";
import { TableRow } from "@tiptap/extension-table-row";
import { TableCell } from "@tiptap/extension-table-cell";
import { TableHeader } from "@tiptap/extension-table-header";
import TextAlign from "@tiptap/extension-text-align";
import { Embed, detectProvider } from "./embed-extension";
import { NodeSelection } from "@tiptap/pm/state";

import { useEffect, useRef, useState, useCallback } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from "@/components/ui/dialog";
import {
  Bold, Italic, Heading1, Heading2, Heading3, List, ListOrdered,
  Link as LinkIcon, Unlink, Undo2, Redo2, Code2, Image as ImageIcon, Loader2,
  AlignLeft, AlignCenter, AlignRight, AlignJustify, Table as TableIcon, Film, Quote,
} from "lucide-react";

import { cn } from "@/lib/utils";
import { MediaPicker } from "@/components/cms/media-picker";
import { supabase } from "@/integrations/supabase/client";
import { registerMedia, signMediaUrl } from "@/lib/cms/cms.functions";
import { convertToWebp, shouldConvertImage } from "@/lib/cms/image-convert";
import { toast } from "sonner";
import { LinkPicker } from "./link-picker";

type Align = "left" | "center" | "right" | null;

// Custom Image extension: adds optional wrapping link + align + width attributes.
const LinkedImage = Image.extend({
  addAttributes() {
    return {
      ...this.parent?.(),
      href: {
        default: null,
        parseHTML: (el) => el.getAttribute("data-href"),
        renderHTML: (attrs) => (attrs.href ? { "data-href": attrs.href } : {}),
      },
      hrefTarget: {
        default: null,
        parseHTML: (el) => el.getAttribute("data-href-target"),
        renderHTML: (attrs) => (attrs.hrefTarget ? { "data-href-target": attrs.hrefTarget } : {}),
      },
      align: {
        default: null,
        parseHTML: (el) => el.getAttribute("data-align"),
        renderHTML: (attrs) => (attrs.align ? { "data-align": attrs.align } : {}),
      },
      width: {
        default: null,
        parseHTML: (el) => {
          const s = (el as HTMLElement).style?.width;
          if (s) return s;
          const w = el.getAttribute("width");
          return w ? (w.endsWith("%") || w.endsWith("px") ? w : `${w}px`) : null;
        },
        renderHTML: () => ({}),
      },
    };
  },
  renderHTML({ HTMLAttributes, node }) {
    const align: Align = node.attrs.align ?? null;
    const width: string | null = node.attrs.width ?? null;
    const styles: string[] = [];
    if (width) styles.push(`width:${width}`);
    if (align === "left") styles.push("float:left", "margin:0 1rem 1rem 0");
    else if (align === "right") styles.push("float:right", "margin:0 0 1rem 1rem");
    else if (align === "center") styles.push("display:block", "margin-left:auto", "margin-right:auto");
    const prev = (HTMLAttributes as any).style ? String((HTMLAttributes as any).style).replace(/;?\s*$/, ";") : "";
    return ["img", { ...HTMLAttributes, style: (prev + styles.join(";")) || undefined }];
  },
});

export function RichTextEditor({
  value,
  onChange,
  placeholder,
  minRows = 6,
}: {
  value: string;
  onChange: (html: string) => void;
  placeholder?: string;
  minRows?: number;
}) {
  const regFn = useServerFn(registerMedia);
  const signFn = useServerFn(signMediaUrl);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const [sourceMode, setSourceMode] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [imageSelected, setImageSelected] = useState(false);
  const [handleRect, setHandleRect] = useState<{ left: number; top: number; width: number; height: number } | null>(null);
  const [linkDialog, setLinkDialog] = useState<{ open: boolean; href: string; newTab: boolean }>({
    open: false, href: "", newTab: false,
  });
  const [embedDialog, setEmbedDialog] = useState<{ open: boolean; url: string; title: string }>({
    open: false, url: "", title: "",
  });
  const [imgDialog, setImgDialog] = useState<{ open: boolean; src: string; alt: string; href: string; newTab: boolean; align: Align; width: string }>({

    open: false, src: "", alt: "", href: "", newTab: false, align: null, width: "",
  });

  const uploadFile = useCallback(async (file: File): Promise<{ url: string; alt: string } | null> => {
    try {
      let f = file;
      if (shouldConvertImage(f)) {
        const conv = await convertToWebp(f, { maxWidth: 2000, quality: 0.85 });
        if (conv !== f) f = conv;
      }
      const path = `${Date.now()}-${f.name.replace(/[^a-zA-Z0-9.-]/g, "_")}`;
      const { error: upErr } = await supabase.storage.from("cms-media").upload(path, f);
      if (upErr) throw upErr;
      await regFn({ data: { storage_path: path, file_name: f.name, mime_type: f.type, size_bytes: f.size } });
      const r = await signFn({ data: { path } });
      if (!r.url) throw new Error("Nem sikerült URL-t generálni");
      return { url: r.url, alt: f.name };
    } catch (e: any) {
      toast.error("Kép feltöltés sikertelen", { description: e?.message?.slice(0, 200) });
      return null;
    }
  }, [regFn, signFn]);

  const uploadAndInsert = useCallback(async (files: File[], editor: any, pos?: number) => {
    const images = files.filter((f) => f.type.startsWith("image/"));
    if (!images.length) return;
    setUploading(true);
    const toastId = toast.loading(`${images.length} kép feltöltése…`);
    try {
      for (const file of images) {
        const res = await uploadFile(file);
        if (!res) continue;
        const chain = editor.chain().focus();
        if (typeof pos === "number") chain.setTextSelection(pos);
        chain.setImage({ src: res.url, alt: res.alt }).run();
      }
      toast.success("Kép beszúrva", { id: toastId });
    } finally {
      setUploading(false);
      toast.dismiss(toastId);
    }
  }, [uploadFile]);

  const editor = useEditor({
    extensions: [
      StarterKit.configure({ heading: { levels: [1, 2, 3] } }),
      Link.configure({ openOnClick: false, autolink: true, HTMLAttributes: { rel: "noopener noreferrer" } }),
      Placeholder.configure({ placeholder: placeholder ?? "Írj ide…" }),
      LinkedImage.configure({ inline: false, allowBase64: false, HTMLAttributes: { class: "rounded-md cms-rte-img" } }),
      Table.configure({ resizable: true, HTMLAttributes: { class: "cms-rte-table w-full border-collapse" } }),
      TableRow,
      TableHeader,
      TableCell,
      TextAlign.configure({ types: ["heading", "paragraph"] }),
      Embed,

    ],
    content: value || "",
    editorProps: {
      attributes: {
        class: cn(
          "prose prose-sm dark:prose-invert max-w-none focus:outline-none",
          "min-h-[6rem] px-3 py-2",
        ),
        style: `min-height:${minRows * 1.5}rem`,
      },
    },
    onUpdate: ({ editor }) => onChange(editor.getHTML()),
  });

  // Drop / paste image uploads
  useEffect(() => {
    if (!editor) return;
    const dom = editor.view.dom as HTMLElement;
    const onDrop = (event: DragEvent) => {
      const files = Array.from(event.dataTransfer?.files ?? []).filter((f) => f.type.startsWith("image/"));
      if (!files.length) return;
      event.preventDefault();
      const coords = editor.view.posAtCoords({ left: event.clientX, top: event.clientY });
      void uploadAndInsert(files, editor, coords?.pos);
    };
    const onDragOver = (event: DragEvent) => {
      if (event.dataTransfer?.types?.includes("Files")) event.preventDefault();
    };
    const onPaste = (event: ClipboardEvent) => {
      const files = Array.from(event.clipboardData?.files ?? []).filter((f) => f.type.startsWith("image/"));
      if (!files.length) return;
      event.preventDefault();
      void uploadAndInsert(files, editor);
    };
    dom.addEventListener("drop", onDrop);
    dom.addEventListener("dragover", onDragOver);
    dom.addEventListener("paste", onPaste);
    return () => {
      dom.removeEventListener("drop", onDrop);
      dom.removeEventListener("dragover", onDragOver);
      dom.removeEventListener("paste", onPaste);
    };
  }, [editor, uploadAndInsert]);

  // External value sync
  useEffect(() => {
    if (!editor) return;
    const current = editor.getHTML();
    if (value !== current) editor.commands.setContent(value || "", { emitUpdate: false });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value, editor]);

  // Track selected image; recompute handle position
  const recomputeHandle = useCallback(() => {
    if (!editor || !containerRef.current) return;
    const { selection } = editor.state;
    const isImg = selection instanceof NodeSelection && (selection as NodeSelection).node.type.name === "image";
    if (!isImg) { setImageSelected(false); setHandleRect(null); return; }
    const dom = editor.view.nodeDOM((selection as NodeSelection).from) as HTMLElement | null;
    if (!dom) { setImageSelected(false); setHandleRect(null); return; }
    const cRect = containerRef.current.getBoundingClientRect();
    const iRect = dom.getBoundingClientRect();
    setImageSelected(true);
    setHandleRect({
      left: iRect.left - cRect.left,
      top: iRect.top - cRect.top,
      width: iRect.width,
      height: iRect.height,
    });
  }, [editor]);

  useEffect(() => {
    if (!editor) return;
    const on = () => recomputeHandle();
    editor.on("selectionUpdate", on);
    editor.on("transaction", on);
    window.addEventListener("resize", on);
    window.addEventListener("scroll", on, true);
    return () => {
      editor.off("selectionUpdate", on);
      editor.off("transaction", on);
      window.removeEventListener("resize", on);
      window.removeEventListener("scroll", on, true);
    };
  }, [editor, recomputeHandle]);

  // Click on image → select it (also opens dialog on double-click)
  useEffect(() => {
    if (!editor) return;
    const dom = editor.view.dom;
    const onClick = (e: MouseEvent) => {
      const t = e.target as HTMLElement;
      if (t?.tagName !== "IMG") return;
      e.preventDefault();
      const pos = editor.view.posAtDOM(t, 0);
      if (pos == null) return;
      const tr = editor.state.tr.setSelection(NodeSelection.create(editor.state.doc, pos));
      editor.view.dispatch(tr);
      editor.view.focus();
    };
    const onDblClick = (e: MouseEvent) => {
      const t = e.target as HTMLElement;
      if (t?.tagName !== "IMG") return;
      e.preventDefault();
      const attrs = editor.getAttributes("image");
      setImgDialog({
        open: true,
        src: (attrs.src as string) ?? (t as HTMLImageElement).src,
        alt: (attrs.alt as string) ?? (t as HTMLImageElement).alt ?? "",
        href: (attrs.href as string) ?? "",
        newTab: attrs.hrefTarget === "_blank",
        align: (attrs.align as Align) ?? null,
        width: (attrs.width as string) ?? "",
      });
    };
    dom.addEventListener("click", onClick);
    dom.addEventListener("dblclick", onDblClick);
    return () => {
      dom.removeEventListener("click", onClick);
      dom.removeEventListener("dblclick", onDblClick);
    };
  }, [editor]);

  // Drag-to-resize handle
  const onHandleMouseDown = (e: React.MouseEvent) => {
    if (!editor || !containerRef.current) return;
    e.preventDefault(); e.stopPropagation();
    const startX = e.clientX;
    const editorDom = editor.view.dom as HTMLElement;
    const editorWidth = editorDom.clientWidth;
    const { selection } = editor.state;
    if (!(selection instanceof NodeSelection)) return;
    const dom = editor.view.nodeDOM(selection.from) as HTMLElement | null;
    if (!dom) return;
    const startW = dom.getBoundingClientRect().width;

    const onMove = (ev: MouseEvent) => {
      const dx = ev.clientX - startX;
      const newPx = Math.max(48, startW + dx);
      const pct = Math.max(10, Math.min(100, Math.round((newPx / editorWidth) * 100)));
      editor.chain().updateAttributes("image", { width: `${pct}%` }).run();
    };
    const onUp = () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
    };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
  };

  const setImageAlign = (align: Align) => {
    if (!editor) return;
    editor.chain().focus().updateAttributes("image", { align }).run();
  };
  const setImageWidth = (width: string | null) => {
    if (!editor) return;
    editor.chain().focus().updateAttributes("image", { width }).run();
  };

  if (!editor) return null;

  const btn = (active: boolean) =>
    cn(
      "shrink-0 inline-flex items-center justify-center gap-1 rounded hover:bg-accent active:bg-accent/70 transition-colors",
      "min-h-11 min-w-11 px-2 text-sm sm:min-h-7 sm:min-w-0 sm:h-7 sm:px-2 sm:text-xs",
      active && "bg-accent text-accent-foreground",
    );

  const openLinkDialog = () => {
    const attrs = editor.getAttributes("link");
    setLinkDialog({ open: true, href: (attrs.href as string) ?? "", newTab: attrs.target === "_blank" });
  };

  const applyLink = () => {
    const href = linkDialog.href.trim();
    if (!href) editor.chain().focus().extendMarkRange("link").unsetLink().run();
    else editor.chain().focus().extendMarkRange("link").setLink({ href, target: linkDialog.newTab ? "_blank" : null }).run();
    setLinkDialog((d) => ({ ...d, open: false }));
  };

  const insertImage = (url: string, alt?: string) => {
    editor.chain().focus().setImage({ src: url, alt: alt ?? "" }).run();
  };

  const insertEmbedUrl = (url: string, title?: string) => {
    const trimmed = url.trim();
    if (!trimmed) return;
    editor
      .chain()
      .focus()
      .insertContent({
        type: "embed",
        attrs: { src: trimmed, provider: detectProvider(trimmed), title: title ?? null },
      })
      .run();
  };


  const applyImageEdit = () => {
    if (!editor.isActive("image")) { setImgDialog((d) => ({ ...d, open: false })); return; }
    const href = imgDialog.href.trim();
    const width = imgDialog.width.trim();
    editor.chain().focus().updateAttributes("image", {
      alt: imgDialog.alt,
      href: href || null,
      hrefTarget: href && imgDialog.newTab ? "_blank" : null,
      align: imgDialog.align,
      width: width || null,
    }).run();
    setImgDialog((d) => ({ ...d, open: false }));
  };

  const removeImage = () => {
    editor.chain().focus().deleteSelection().run();
    setImgDialog((d) => ({ ...d, open: false }));
  };

  const curAlign: Align = (editor.getAttributes("image")?.align as Align) ?? null;
  const curWidth: string = (editor.getAttributes("image")?.width as string) ?? "";

  return (
    <div ref={containerRef} className="border rounded-md bg-background relative">
      {uploading && (
        <div className="absolute top-1 right-1 z-10 flex items-center gap-1 text-xs bg-background/80 border rounded px-2 py-0.5">
          <Loader2 className="size-3 animate-spin" /> Feltöltés…
        </div>
      )}
      <div
        className={cn(
          "sticky top-0 z-20 bg-background/95 supports-[backdrop-filter]:bg-background/75 backdrop-blur border-b rounded-t-md",
          // Mobile: single horizontally scrollable row so it doesn't wrap and eat vertical space.
          // Desktop: standard wrapping toolbar.
          "flex items-center gap-0.5 p-1 overflow-x-auto sm:overflow-visible sm:flex-wrap",
          "[scrollbar-width:none] [&::-webkit-scrollbar]:hidden",
        )}
      >
        <button type="button" className={btn(editor.isActive("bold"))}
          onClick={() => editor.chain().focus().toggleBold().run()} title="Bold"><Bold className="size-3.5" /></button>
        <button type="button" className={btn(editor.isActive("italic"))}
          onClick={() => editor.chain().focus().toggleItalic().run()} title="Italic"><Italic className="size-3.5" /></button>
        <div className="w-px h-4 bg-border mx-1" />
        <button type="button" className={btn(editor.isActive("heading", { level: 1 }))}
          onClick={() => editor.chain().focus().toggleHeading({ level: 1 }).run()} title="H1"><Heading1 className="size-3.5" /></button>
        <button type="button" className={btn(editor.isActive("heading", { level: 2 }))}
          onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()} title="H2"><Heading2 className="size-3.5" /></button>
        <button type="button" className={btn(editor.isActive("heading", { level: 3 }))}
          onClick={() => editor.chain().focus().toggleHeading({ level: 3 }).run()} title="H3"><Heading3 className="size-3.5" /></button>
        <div className="w-px h-4 bg-border mx-1" />
        <button type="button" className={btn(editor.isActive("bulletList"))}
          onClick={() => editor.chain().focus().toggleBulletList().run()} title="Bullet list"><List className="size-3.5" /></button>
        <button type="button" className={btn(editor.isActive("orderedList"))}
          onClick={() => editor.chain().focus().toggleOrderedList().run()} title="Ordered list"><ListOrdered className="size-3.5" /></button>
        <div className="w-px h-4 bg-border mx-1" />
        <button type="button" className={btn(editor.isActive("link"))}
          onClick={openLinkDialog} title="Link beszúrása / szerkesztése"><LinkIcon className="size-3.5" /></button>
        {editor.isActive("link") && (
          <button type="button" className={btn(false)}
            onClick={() => editor.chain().focus().unsetLink().run()} title="Link eltávolítása"><Unlink className="size-3.5" /></button>
        )}
        <MediaPicker
          trigger={
            <button type="button" className={btn(false)} title="Kép beszúrása a médiatárból (vagy húzd/paste-eld ide)">
              <ImageIcon className="size-3.5" />
            </button>
          }
          onSelect={({ url, alt }) => insertImage(url, alt)}
        />
        <MediaPicker
          accept="image/gif,video/*"
          title="GIF / videó választása"
          trigger={
            <button type="button" className={btn(false)} title="GIF vagy videó beszúrása a médiatárból">
              <Film className="size-3.5" />
            </button>
          }
          onSelect={({ url, alt }) => insertEmbedUrl(url, alt)}
        />
        <button type="button" className={btn(false)} onClick={() => setEmbedDialog({ open: true, url: "", title: "" })}
          title="Beágyazás (YouTube, TikTok, Instagram, X, térkép…)"><Quote className="size-3.5" /></button>
        <button type="button" className={btn(editor.isActive("table"))}
          onClick={() => editor.chain().focus().insertTable({ rows: 3, cols: 3, withHeaderRow: true }).run()}
          title="Táblázat beszúrása"><TableIcon className="size-3.5" /></button>
        {editor.isActive("table") && (
          <>
            <button type="button" className={btn(false)} onClick={() => editor.chain().focus().addRowAfter().run()} title="Sor hozzáadása">
              <span className="text-[10px] font-mono">+sor</span></button>
            <button type="button" className={btn(false)} onClick={() => editor.chain().focus().addColumnAfter().run()} title="Oszlop hozzáadása">
              <span className="text-[10px] font-mono">+oszl</span></button>
            <button type="button" className={btn(false)} onClick={() => editor.chain().focus().deleteTable().run()} title="Táblázat törlése">
              <span className="text-[10px] font-mono">×tábl</span></button>
          </>
        )}


        {imageSelected && (
          <>
            <div className="w-px h-4 bg-border mx-1" />
            <button type="button" className={btn(curAlign === "left")}
              onClick={() => setImageAlign(curAlign === "left" ? null : "left")} title="Balra igazítás"><AlignLeft className="size-3.5" /></button>
            <button type="button" className={btn(curAlign === "center")}
              onClick={() => setImageAlign(curAlign === "center" ? null : "center")} title="Középre"><AlignCenter className="size-3.5" /></button>
            <button type="button" className={btn(curAlign === "right")}
              onClick={() => setImageAlign(curAlign === "right" ? null : "right")} title="Jobbra igazítás"><AlignRight className="size-3.5" /></button>
            <div className="w-px h-4 bg-border mx-1" />
            {(["25%", "50%", "75%", "100%"] as const).map((w) => (
              <button key={w} type="button" className={btn(curWidth === w)}
                onClick={() => setImageWidth(curWidth === w ? null : w)} title={`Szélesség ${w}`}>
                <span className="text-[10px] font-mono">{w}</span>
              </button>
            ))}
            <button type="button" className={btn(false)} onClick={() => setImageWidth(null)} title="Eredeti méret">
              <AlignJustify className="size-3.5" />
            </button>
          </>
        )}

        <div className="ml-auto flex items-center gap-0.5">
          <button type="button" className={btn(false)}
            onClick={() => editor.chain().focus().undo().run()} title="Visszavon"><Undo2 className="size-3.5" /></button>
          <button type="button" className={btn(false)}
            onClick={() => editor.chain().focus().redo().run()} title="Ismét"><Redo2 className="size-3.5" /></button>
          <button type="button" className={btn(sourceMode)}
            onClick={() => setSourceMode((v) => !v)} title="HTML forrás"><Code2 className="size-3.5" /></button>
        </div>
      </div>
      {sourceMode ? (
        <Textarea
          value={value}
          onChange={(e) => onChange(e.target.value)}
          rows={Math.max(minRows, 8)}
          className="font-mono text-xs border-0 rounded-none rounded-b-md focus-visible:ring-0"
        />
      ) : (
        <div className="relative">
          <EditorContent editor={editor} />
          {imageSelected && handleRect && (
            <>
              {/* selection outline */}
              <div
                className="pointer-events-none absolute border-2 border-primary/60 rounded"
                style={{
                  left: handleRect.left - 2,
                  top: handleRect.top - 2,
                  width: handleRect.width + 4,
                  height: handleRect.height + 4,
                }}
              />
              {/* resize handle (bottom-right) */}
              <div
                role="slider"
                aria-label="Kép átméretezése"
                onMouseDown={onHandleMouseDown}
                className="absolute size-3 rounded-sm bg-primary border-2 border-background cursor-nwse-resize shadow"
                style={{
                  left: handleRect.left + handleRect.width - 6,
                  top: handleRect.top + handleRect.height - 6,
                }}
                title="Húzd az átméretezéshez"
              />
              {/* edit button */}
              <button
                type="button"
                onClick={() => {
                  const attrs = editor.getAttributes("image");
                  setImgDialog({
                    open: true,
                    src: (attrs.src as string) ?? "",
                    alt: (attrs.alt as string) ?? "",
                    href: (attrs.href as string) ?? "",
                    newTab: attrs.hrefTarget === "_blank",
                    align: (attrs.align as Align) ?? null,
                    width: (attrs.width as string) ?? "",
                  });
                }}
                className="absolute text-[10px] px-2 py-0.5 rounded bg-primary text-primary-foreground shadow hover:opacity-90"
                style={{
                  left: handleRect.left + 4,
                  top: handleRect.top + 4,
                }}
              >
                Szerkeszt
              </button>
            </>
          )}
        </div>
      )}

      <Dialog open={embedDialog.open} onOpenChange={(v) => setEmbedDialog((d) => ({ ...d, open: v }))}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Beágyazás</DialogTitle>
            <DialogDescription>
              YouTube, Vimeo, TikTok, Instagram, Facebook, X, Spotify, Google Maps link vagy közvetlen videó/GIF URL.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <Input autoFocus value={embedDialog.url} placeholder="https://…"
              onChange={(e) => setEmbedDialog((d) => ({ ...d, url: e.target.value }))} />
            <Input value={embedDialog.title} placeholder="Cím / hozzáférhetőségi leírás (opcionális)"
              onChange={(e) => setEmbedDialog((d) => ({ ...d, title: e.target.value }))} />
            {embedDialog.url && (
              <p className="text-xs text-muted-foreground">Felismert forrás: <b>{detectProvider(embedDialog.url)}</b></p>
            )}
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setEmbedDialog((d) => ({ ...d, open: false }))}>Mégse</Button>
            <Button
              disabled={!embedDialog.url.trim()}
              onClick={() => { insertEmbedUrl(embedDialog.url, embedDialog.title || undefined); setEmbedDialog({ open: false, url: "", title: "" }); }}
            >Beszúrás</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={linkDialog.open} onOpenChange={(v) => setLinkDialog((d) => ({ ...d, open: v }))}>

        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Link beszúrása</DialogTitle>
            <DialogDescription>Külső URL, belső útvonal (pl. <code>/o/kontakt</code>), <code>mailto:</code> vagy <code>tel:</code>.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <LinkPicker
              value={linkDialog.href}
              onChange={(href) => setLinkDialog((d) => ({ ...d, href }))}
              placeholder="https://…  vagy  /o/aloldal  vagy  mailto:info@…"
            />
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={linkDialog.newTab}
                onChange={(e) => setLinkDialog((d) => ({ ...d, newTab: e.target.checked }))} />
              Új lapon nyíljon meg
            </label>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setLinkDialog((d) => ({ ...d, open: false }))}>Mégse</Button>
            {linkDialog.href && (
              <Button variant="outline"
                onClick={() => { editor.chain().focus().extendMarkRange("link").unsetLink().run(); setLinkDialog((d) => ({ ...d, open: false })); }}
              >Link eltávolítása</Button>
            )}
            <Button onClick={applyLink}>Alkalmaz</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={imgDialog.open} onOpenChange={(v) => setImgDialog((d) => ({ ...d, open: v }))}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Kép szerkesztése</DialogTitle>
            <DialogDescription>Alt szöveg, opcionális link cél, igazítás és szélesség.</DialogDescription>
          </DialogHeader>
          {imgDialog.src && (
            <div className="rounded-md border overflow-hidden bg-muted flex items-center justify-center max-h-40">
              <img src={imgDialog.src} alt="" className="max-h-40 object-contain" />
            </div>
          )}
          <div className="space-y-3">
            <div>
              <label className="text-xs font-medium">Alt szöveg</label>
              <Input autoFocus value={imgDialog.alt}
                onChange={(e) => setImgDialog((d) => ({ ...d, alt: e.target.value }))}
                placeholder="Rövid leírás a képről…" />
            </div>
            <div>
              <label className="text-xs font-medium">Linkelt cél (opcionális)</label>
              <LinkPicker
                value={imgDialog.href}
                onChange={(href) => setImgDialog((d) => ({ ...d, href }))}
              />
            </div>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={imgDialog.newTab}
                onChange={(e) => setImgDialog((d) => ({ ...d, newTab: e.target.checked }))} />
              Új lapon nyíljon meg
            </label>
            <div>
              <label className="text-xs font-medium block mb-1">Igazítás</label>
              <div className="flex gap-1">
                {([
                  { v: null, label: "Alap", Icon: AlignJustify },
                  { v: "left" as const, label: "Balra", Icon: AlignLeft },
                  { v: "center" as const, label: "Középre", Icon: AlignCenter },
                  { v: "right" as const, label: "Jobbra", Icon: AlignRight },
                ]).map(({ v, label, Icon }) => (
                  <button key={label} type="button"
                    onClick={() => setImgDialog((d) => ({ ...d, align: v }))}
                    className={cn("flex-1 h-8 border rounded flex items-center justify-center gap-1 text-xs",
                      imgDialog.align === v && "bg-accent border-primary")}>
                    <Icon className="size-3.5" /> {label}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="text-xs font-medium">Szélesség (pl. <code>50%</code> vagy <code>400px</code>)</label>
              <div className="flex gap-1">
                <Input value={imgDialog.width}
                  onChange={(e) => setImgDialog((d) => ({ ...d, width: e.target.value }))}
                  placeholder="Üres = eredeti" />
                {["25%", "50%", "75%", "100%"].map((w) => (
                  <button key={w} type="button"
                    onClick={() => setImgDialog((d) => ({ ...d, width: w }))}
                    className="px-2 text-xs border rounded hover:bg-accent">{w}</button>
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setImgDialog((d) => ({ ...d, open: false }))}>Mégse</Button>
            <Button variant="outline" onClick={removeImage}>Kép törlése</Button>
            <Button onClick={applyImageEdit}>Mentés</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

/** Heuristic: does this field look like it holds rich HTML / long prose? */
export function isRichTextField(key: string, value: unknown): boolean {
  if (typeof value !== "string") return false;
  const k = key.toLowerCase();
  if (k === "html" || k.endsWith("_html") || k === "content" || k === "body") return true;
  if (k === "description" || k === "text" || k === "richtext" || k === "rich_text") return true;
  // További rich-text mezőnevek — minden szerkesztőben WYSIWYG-ként jelennek meg.
  if (["excerpt", "summary", "intro", "lead", "caption", "answer", "quote", "bio", "abstract", "note", "details"].includes(k)) return true;
  if (k.endsWith("_text") || k.endsWith("_body") || k.endsWith("_description") || k.endsWith("_content")) return true;
  if (/<[a-z][\s\S]*>/i.test(value)) return true;
  if (value.length > 140 || value.includes("\n\n")) return true;
  return false;
}

