/**
 * Reusable link picker input for the visual CMS editor.
 *
 * - "Belső oldal" tab: searches `cms_pages` via listPages, filters by
 *   title/slug/locale, and inserts the canonical URL:
 *     home page   → "/"
 *     any other   → "/o/{slug}"
 * - "Külső URL" tab: free-text input + quick mailto:/tel: helpers.
 *
 * Emits the final href string via onChange so callers (rich text editor,
 * block form editor) can drop it into Tiptap or a block content field.
 */
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Loader2, Globe, FileText, Mail, Phone, Home } from "lucide-react";
import { listPages } from "@/lib/cms/cms.functions";

type CmsPageRow = {
  id: string;
  slug: string;
  title: string;
  locale: string;
  is_home?: boolean | null;
  status?: string | null;
};

export function LinkPicker({
  value,
  onChange,
  placeholder,
}: {
  value: string;
  onChange: (href: string) => void;
  placeholder?: string;
}) {
  const looksInternal = value.startsWith("/") || value === "";
  const [tab, setTab] = useState<"page" | "url">(looksInternal ? "page" : "url");
  const [q, setQ] = useState("");

  const fn = useServerFn(listPages);
  const { data, isLoading } = useQuery({
    queryKey: ["link-picker-pages"],
    queryFn: () => fn(),
    staleTime: 60_000,
  });
  const pages = (data ?? []) as CmsPageRow[];

  const filtered = useMemo(() => {
    const term = q.trim().toLowerCase();
    const rows = term
      ? pages.filter(
          (p) =>
            p.title?.toLowerCase().includes(term) ||
            p.slug?.toLowerCase().includes(term),
        )
      : pages;
    return rows.slice(0, 40);
  }, [pages, q]);

  const activeHref = value;

  return (
    <div className="space-y-2">
      <Tabs value={tab} onValueChange={(v) => setTab(v as any)} className="w-full">
        <TabsList className="h-8">
          <TabsTrigger value="page" className="gap-1 text-xs h-6">
            <FileText className="size-3" /> CMS oldal
          </TabsTrigger>
          <TabsTrigger value="url" className="gap-1 text-xs h-6">
            <Globe className="size-3" /> Külső URL
          </TabsTrigger>
        </TabsList>

        <TabsContent value="page" className="mt-2 space-y-2">
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Keresés cím vagy slug alapján…"
            className="h-8 text-sm"
          />
          <div className="max-h-56 overflow-auto rounded-md border">
            {isLoading && (
              <div className="p-3 text-xs text-muted-foreground flex items-center gap-2">
                <Loader2 className="size-3 animate-spin" /> Oldalak betöltése…
              </div>
            )}
            {!isLoading && filtered.length === 0 && (
              <div className="p-3 text-xs text-muted-foreground">Nincs találat.</div>
            )}
            {filtered.map((p) => {
              const href = p.is_home ? "/" : `/o/${p.slug}`;
              const selected = href === activeHref;
              return (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => onChange(href)}
                  className={`flex w-full items-start gap-2 px-2 py-1.5 text-left text-xs hover:bg-accent border-b last:border-b-0 ${
                    selected ? "bg-accent" : ""
                  }`}
                >
                  {p.is_home ? (
                    <Home className="size-3.5 mt-0.5 text-primary shrink-0" />
                  ) : (
                    <FileText className="size-3.5 mt-0.5 text-muted-foreground shrink-0" />
                  )}
                  <div className="flex-1 min-w-0">
                    <div className="font-medium truncate">{p.title || p.slug}</div>
                    <div className="text-muted-foreground font-mono truncate">{href}</div>
                  </div>
                  <Badge variant="outline" className="text-[10px] uppercase h-4 px-1">
                    {p.locale}
                  </Badge>
                  {p.status && p.status !== "published" && (
                    <Badge variant="secondary" className="text-[10px] h-4 px-1">{p.status}</Badge>
                  )}
                </button>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="url" className="mt-2 space-y-2">
          <Input
            value={value}
            onChange={(e) => onChange(e.target.value)}
            placeholder={placeholder ?? "https://…  vagy  mailto:…  vagy  tel:…"}
            className="h-8 text-sm"
          />
          <div className="flex flex-wrap gap-1">
            <QuickBtn onClick={() => onChange("https://")} icon={<Globe className="size-3" />}>https://</QuickBtn>
            <QuickBtn onClick={() => onChange("mailto:")} icon={<Mail className="size-3" />}>mailto:</QuickBtn>
            <QuickBtn onClick={() => onChange("tel:+36")} icon={<Phone className="size-3" />}>tel:</QuickBtn>
          </div>
        </TabsContent>
      </Tabs>

      {activeHref && (
        <div className="text-[11px] text-muted-foreground truncate">
          Kiválasztva: <span className="font-mono">{activeHref}</span>
        </div>
      )}
    </div>
  );
}

function QuickBtn({
  onClick, children, icon,
}: { onClick: () => void; children: React.ReactNode; icon: React.ReactNode }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="text-[11px] px-2 py-1 rounded border hover:bg-accent flex items-center gap-1"
    >
      {icon}
      {children}
    </button>
  );
}

/** Heuristic: does a block-content key look like a link/URL field? */
export function isLinkField(key: string): boolean {
  const k = key.toLowerCase();
  if (k === "href" || k === "url" || k === "link") return true;
  if (k.endsWith("_href") || k.endsWith("_url") || k.endsWith("_link")) return true;
  if (k === "cta" || k.startsWith("cta_")) return k.includes("href") || k.includes("url") || k.includes("link");
  return false;
}
