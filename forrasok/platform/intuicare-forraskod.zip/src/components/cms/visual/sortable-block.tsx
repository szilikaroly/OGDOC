/**
 * Sortable wrapper for a single block in the LiveEditor canvas.
 *
 * Uses @dnd-kit/sortable. The drag handle is a small grip badge anchored to
 * the left edge of the block (visible on hover); clicks on the handle are
 * stopped from bubbling so they don't select the block.
 */
import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { GripVertical } from "lucide-react";
import { cn } from "@/lib/utils";

export function SortableBlock({ id, children }: { id: string; children: React.ReactNode }) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging, isOver } =
    useSortable({ id });

  const style: React.CSSProperties = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={cn(
        "relative group/sortable",
        isDragging && "opacity-60 z-40",
        isOver && "ring-2 ring-primary/40 rounded",
      )}
    >
      <button
        type="button"
        aria-label="Blokk áthelyezése (húzd, vagy Enter + nyilak)"
        className={cn(
          "absolute left-1 top-2 z-30 size-7 rounded-md bg-secondary text-secondary-foreground shadow-sm",
          "flex items-center justify-center cursor-grab active:cursor-grabbing",
          "opacity-0 group-hover/sortable:opacity-100 focus:opacity-100 transition-opacity",
        )}
        onClick={(e) => e.stopPropagation()}
        {...attributes}
        {...listeners}
      >
        <GripVertical className="size-4" />
      </button>
      {children}
    </div>
  );
}
