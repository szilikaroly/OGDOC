/**
 * In-place inline text editing for CMS blocks.
 *
 * When enabled, the hook scans the rendered block DOM and matches every
 * short string field of the block content against the deepest element whose
 * text equals that value. Those elements become contentEditable, so the admin
 * can type directly on the rendered page instead of using the inspector form.
 *
 * Commit: blur or Enter (Shift+Enter inserts a newline). Escape reverts.
 */
import { useEffect, type RefObject } from "react";

const MAX_LEN = 400;
const CANDIDATE_SELECTOR =
  "h1,h2,h3,h4,h5,h6,p,span,a,li,button,strong,em,figcaption,label,dt,dd,td,th,div";

/** Collect editable string fields (top-level + one nested level in arrays). */
function stringFields(content: Record<string, any> | undefined | null) {
  const out: Array<{ path: (string | number)[]; value: string }> = [];
  if (!content || typeof content !== "object") return out;
  const push = (path: (string | number)[], v: any) => {
    if (typeof v !== "string") return;
    const t = v.trim();
    if (!t || t.length > MAX_LEN || t.includes("<")) return;
    if (/^(https?:|\/|#|data:)/i.test(t)) return; // links / urls stay in the inspector
    out.push({ path, value: v });
  };
  for (const [k, v] of Object.entries(content)) {
    if (typeof v === "string") push([k], v);
    else if (Array.isArray(v)) {
      v.forEach((item, i) => {
        if (typeof item === "string") push([k, i], item);
        else if (item && typeof item === "object") {
          for (const [k2, v2] of Object.entries(item)) push([k, i, k2], v2);
        }
      });
    } else if (v && typeof v === "object") {
      for (const [k2, v2] of Object.entries(v)) push([k, k2], v2);
    }
  }
  return out;
}

/** Deepest element whose trimmed text equals `value`. */
function findTarget(root: HTMLElement, value: string, used: Set<Element>) {
  const needle = value.trim();
  const nodes = Array.from(root.querySelectorAll<HTMLElement>(CANDIDATE_SELECTOR));
  let best: HTMLElement | null = null;
  for (const el of nodes) {
    if (used.has(el)) continue;
    if (el.closest("[data-inline-skip]")) continue;
    if ((el.textContent ?? "").trim() !== needle) continue;
    if (!best || el.contains(best) === false) best = el.contains(best!) ? best : el;
    best = el; // later nodes in document order are deeper/last match
  }
  return best;
}

export function setAtPath(obj: any, path: (string | number)[], value: any) {
  const next = Array.isArray(obj) ? [...obj] : { ...(obj ?? {}) };
  let cur: any = next;
  for (let i = 0; i < path.length - 1; i++) {
    const k = path[i];
    const child = cur[k];
    cur[k] = Array.isArray(child) ? [...child] : { ...(child ?? {}) };
    cur = cur[k];
  }
  cur[path[path.length - 1]] = value;
  return next;
}

export function useInlineEdit({
  enabled,
  content,
  containerRef,
  onCommit,
}: {
  enabled: boolean;
  content: Record<string, any> | undefined | null;
  containerRef: RefObject<HTMLElement | null>;
  onCommit: (path: (string | number)[], value: string) => void;
}) {
  useEffect(() => {
    const root = containerRef.current;
    if (!enabled || !root) return;

    const used = new Set<Element>();
    const cleanups: Array<() => void> = [];

    for (const field of stringFields(content)) {
      const el = findTarget(root, field.value, used);
      if (!el) continue;
      used.add(el);

      const original = field.value;
      el.setAttribute("contenteditable", "plaintext-only");
      el.setAttribute("spellcheck", "false");
      el.dataset.cmsField = field.path.join(".");
      el.classList.add("cms-inline-editable");

      const stop = (e: Event) => e.stopPropagation();
      const onBlur = () => {
        const val = (el.innerText ?? "").replace(/\u00a0/g, " ").trim();
        if (val !== original.trim()) onCommit(field.path, val);
      };
      const onKeyDown = (e: KeyboardEvent) => {
        e.stopPropagation();
        if (e.key === "Escape") {
          el.innerText = original;
          el.blur();
        } else if (e.key === "Enter" && !e.shiftKey) {
          e.preventDefault();
          el.blur();
        }
      };

      el.addEventListener("click", stop);
      el.addEventListener("pointerdown", stop);
      el.addEventListener("blur", onBlur);
      el.addEventListener("keydown", onKeyDown);

      cleanups.push(() => {
        el.removeEventListener("click", stop);
        el.removeEventListener("pointerdown", stop);
        el.removeEventListener("blur", onBlur);
        el.removeEventListener("keydown", onKeyDown);
        el.removeAttribute("contenteditable");
        el.removeAttribute("spellcheck");
        delete el.dataset.cmsField;
        el.classList.remove("cms-inline-editable");
      });
    }

    return () => cleanups.forEach((fn) => fn());
  }, [enabled, content, containerRef, onCommit]);
}
