/**
 * Nav preview panel a LiveEditor bal sávjában.
 *
 * A `cms_menus` publikus lekérdezésével (getPublicMenu) mutatja az
 * aktuálisan élő menülinkeket (label + href), így az admin azonnal látja,
 * mit rendel majd a shell `main_nav` régió az iframe előnézetben.
 * A menüpontra kattintva új lapon megnyitja a linket; a "Szerkesztés"
 * gomb a /admin/cms/menus oldalra visz.
 */
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, Loader2, RefreshCw, Menu as MenuIcon } from "lucide-react";
import { getPublicMenu } from "@/lib/cms/cms.functions";
import { SUPPORTED_LANGUAGES } from "@/i18n/languages";

type Item = {
  id: string;
  parent_id: string | null;
  label: string;
  href: string;
  open_in_new_tab?: boolean;
};

export function NavigationPreviewPanel({
  onOpenInIframe,
  defaultSlug = "main",
}: {
  onOpenInIframe?: (href: string) => void;
  defaultSlug?: string;
}) {
  const fn = useServerFn(getPublicMenu);
  const [slug, setSlug] = useState(defaultSlug);
  const [locale, setLocale] = useState<string>("hu");

  const q = useQuery({
    queryKey: ["cms-nav-preview", slug, locale],
    queryFn: () => fn({ data: { slug, locale } }),
    staleTime: 30_000,
  });

  const items = ((q.data as any)?.items ?? []) as Item[];
  const top = items.filter((i) => !i.parent_id);
  const childrenOf = (id: string) => items.filter((i) => i.parent_id === id);

  return (
    <Card>
      <CardContent className="p-3 space-y-2">
        <div className="flex items-center justify-between">
          <div className="text-xs font-semibold uppercase text-muted-foreground flex items-center gap-1">
            <MenuIcon className="size-3.5" /> Navigáció előnézete
          </div>
          <Button
            size="icon" variant="ghost" className="h-6 w-6"
            onClick={() => q.refetch()}
            aria-label="Frissítés"
            title="Frissítés"
          >
            {q.isFetching ? <Loader2 className="size-3 animate-spin" /> : <RefreshCw className="size-3" />}
          </Button>
        </div>

        <div className="flex gap-1">
          <input
            value={slug}
            onChange={(e) => setSlug(e.target.value)}
            className="flex-1 text-xs px-2 py-1 rounded border bg-background"
            placeholder="menü slug (main)"
            aria-label="Menü slug"
          />
          <select
            value={locale}
            onChange={(e) => setLocale(e.target.value)}
            className="text-xs px-1.5 py-1 rounded border bg-background"
            aria-label="Nyelv"
          >
            {SUPPORTED_LANGUAGES.map((l) => (
              <option key={l.code} value={l.code}>{l.code}</option>
            ))}
          </select>
        </div>

        {q.isLoading ? (
          <div className="text-xs text-muted-foreground flex items-center gap-1">
            <Loader2 className="size-3 animate-spin" /> betöltés…
          </div>
        ) : !top.length ? (
          <div className="text-xs text-muted-foreground">
            Nincs menüpont a <code>{slug}</code> / <code>{locale}</code> menühöz.
          </div>
        ) : (
          <ul className="space-y-1">
            {top.map((p) => {
              const kids = childrenOf(p.id);
              return (
                <li key={p.id} className="rounded border bg-muted/30 p-1.5">
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      className="flex-1 text-left text-xs font-medium truncate hover:underline"
                      title={p.href}
                      onClick={() => onOpenInIframe?.(p.href)}
                    >
                      {p.label}
                    </button>
                    <Badge variant="secondary" className="text-[10px] font-mono max-w-[9rem] truncate" title={p.href}>
                      {p.href}
                    </Badge>
                    <a
                      href={p.href}
                      target="_blank"
                      rel="noreferrer"
                      className="text-muted-foreground hover:text-foreground"
                      aria-label="Megnyitás új lapon"
                      title="Megnyitás új lapon"
                    >
                      <ExternalLink className="size-3" />
                    </a>
                  </div>
                  {kids.length > 0 && (
                    <ul className="mt-1 ml-2 border-l pl-2 space-y-0.5">
                      {kids.map((c) => (
                        <li key={c.id} className="flex items-center gap-1">
                          <button
                            type="button"
                            className="flex-1 text-left text-[11px] truncate hover:underline"
                            title={c.href}
                            onClick={() => onOpenInIframe?.(c.href)}
                          >
                            {c.label}
                          </button>
                          <a
                            href={c.href}
                            target="_blank"
                            rel="noreferrer"
                            className="text-muted-foreground hover:text-foreground"
                            aria-label="Megnyitás új lapon"
                          >
                            <ExternalLink className="size-3" />
                          </a>
                        </li>
                      ))}
                    </ul>
                  )}
                </li>
              );
            })}
          </ul>
        )}

        <p className="text-[10px] text-muted-foreground">
          A menü elemeit a <code>cms_menus</code> / <code>cms_menu_items</code> táblákon lehet szerkeszteni;
          a shell <code>main_nav</code> régiójában lévő <code>nav_menu</code> blokk ezt renderli az iframe előnézetben.
        </p>
      </CardContent>
    </Card>
  );
}
