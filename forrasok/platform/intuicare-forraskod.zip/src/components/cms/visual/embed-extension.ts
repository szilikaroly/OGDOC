/**
 * Universal embed node for the CMS rich editors.
 *
 * Stores `<div data-embed data-src="…" data-provider="…">` in the HTML and
 * renders a responsive 16:9 iframe. Supports YouTube, Vimeo, TikTok,
 * Instagram, Facebook, X/Twitter, Spotify, Google Maps, generic iframes and
 * direct video/GIF files.
 */
import { Node, mergeAttributes } from "@tiptap/core";

export type EmbedProvider =
  | "youtube" | "vimeo" | "tiktok" | "instagram" | "facebook"
  | "twitter" | "spotify" | "map" | "video" | "gif" | "iframe";

export function detectProvider(url: string): EmbedProvider {
  const u = url.toLowerCase();
  if (/youtu\.be|youtube\.com/.test(u)) return "youtube";
  if (/vimeo\.com/.test(u)) return "vimeo";
  if (/tiktok\.com/.test(u)) return "tiktok";
  if (/instagram\.com/.test(u)) return "instagram";
  if (/facebook\.com|fb\.watch/.test(u)) return "facebook";
  if (/twitter\.com|x\.com/.test(u)) return "twitter";
  if (/spotify\.com/.test(u)) return "spotify";
  if (/google\.[a-z.]+\/maps|maps\.app\.goo\.gl/.test(u)) return "map";
  if (/\.(mp4|webm|ogg)(\?|$)/.test(u)) return "video";
  if (/\.gif(\?|$)/.test(u)) return "gif";
  return "iframe";
}

/** Convert a public URL into an embeddable iframe src. */
export function toEmbedSrc(url: string, provider: EmbedProvider = detectProvider(url)): string {
  try {
    const u = new URL(url);
    switch (provider) {
      case "youtube": {
        const id = u.hostname.includes("youtu.be")
          ? u.pathname.slice(1)
          : u.searchParams.get("v") ?? u.pathname.split("/").filter(Boolean).pop();
        return id ? `https://www.youtube-nocookie.com/embed/${id}` : url;
      }
      case "vimeo": {
        const id = u.pathname.split("/").filter(Boolean).pop();
        return id ? `https://player.vimeo.com/video/${id}` : url;
      }
      case "spotify":
        return url.replace("/track/", "/embed/track/").replace("/episode/", "/embed/episode/");
      case "twitter":
      case "instagram":
      case "facebook":
      case "tiktok":
        // Rendered through the platform embed page (no script injection needed).
        return provider === "facebook" || provider === "tiktok" || provider === "instagram"
          ? `https://www.facebook.com/plugins/post.php?href=${encodeURIComponent(url)}`
          : url;
      default:
        return url;
    }
  } catch {
    return url;
  }
}

export const Embed = Node.create({
  name: "embed",
  group: "block",
  atom: true,
  draggable: true,

  addAttributes() {
    return {
      src: { default: null, parseHTML: (el) => el.getAttribute("data-src") },
      provider: { default: "iframe", parseHTML: (el) => el.getAttribute("data-provider") },
      title: { default: null, parseHTML: (el) => el.getAttribute("data-title") },
    };
  },

  parseHTML() {
    return [{ tag: "div[data-embed]" }];
  },

  renderHTML({ HTMLAttributes, node }) {
    const provider = (node.attrs.provider ?? "iframe") as EmbedProvider;
    const src = String(node.attrs.src ?? "");
    const wrapper = mergeAttributes(
      {
        "data-embed": "",
        "data-src": src,
        "data-provider": provider,
        "data-title": node.attrs.title ?? undefined,
        class: "cms-embed my-4",
      },
      HTMLAttributes,
    );
    if (provider === "gif") {
      return ["div", wrapper, ["img", { src, alt: node.attrs.title ?? "", loading: "lazy", class: "rounded-md max-w-full h-auto" }]];
    }
    if (provider === "video") {
      return ["div", wrapper, ["video", { src, controls: "true", playsinline: "true", class: "rounded-md w-full" }]];
    }
    return [
      "div",
      wrapper,
      [
        "div",
        { class: "relative w-full overflow-hidden rounded-md", style: "aspect-ratio:16/9" },
        [
          "iframe",
          {
            src: toEmbedSrc(src, provider),
            title: node.attrs.title ?? "Beágyazott tartalom",
            loading: "lazy",
            allow: "accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share",
            allowfullscreen: "true",
            referrerpolicy: "strict-origin-when-cross-origin",
            class: "absolute inset-0 w-full h-full border-0",
          },
        ],
      ],
    ];
  },
});
