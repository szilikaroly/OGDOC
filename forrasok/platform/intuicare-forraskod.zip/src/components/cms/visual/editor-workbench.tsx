/**
 * EditorWorkbench — közös, újrahasznosítható szerkesztő motor.
 *
 * Minden CMS-szerkesztő (landing, régiók, hírek, oldalak) ezt használja,
 * hogy egységes élményt adjon:
 *   - bal oldalt paletta (kattintásra vagy drag&drop-pal beszúrható elemek)
 *   - középen sorbarendezhető (drag&drop) elemlista / vászon
 *   - jobb oldalt inspector (WYSIWYG mezőszerkesztés)
 *   - jobb szélen élő, in-site előnézet iframe-ben (mobil/tablet/desktop)
 *
 * A komponens teljesen adat-agnosztikus: az adapter propokon keresztül
 * kapja meg, hogyan listázzon, szúrjon be, rendezzen át és töröljön.
 */
import { useCallback, useEffect, useRef, useState } from "react";
import {
  DndContext, closestCenter, PointerSensor, KeyboardSensor,
  useSensor, useSensors, useDroppable, type DragEndEvent,
} from "@dnd-kit/core";
import {
  SortableContext, verticalListSortingStrategy, sortableKeyboardCoordinates, arrayMove,
} from "@dnd-kit/sortable";
import { ResizablePanelGroup, ResizablePanel, ResizableHandle } from "@/components/ui/resizable";
import { Badge } from "@/components/ui/badge";
import { Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { SortableBlock } from "./sortable-block";
import {
  usePreviewDevice, PreviewToolbar, PreviewFrame,
  PREVIEW_DEVICE_WIDTH as DEVICE_WIDTH, type PreviewDevice as WorkbenchDeviceType,
} from "./preview-toolbar";

export type WorkbenchItem = {
  id: string;
  /** Elem típusa (blokk típus) — a listában címkeként jelenik meg. */
  type: string;
  /** Másodlagos sor a listában (pl. cím). */
  subtitle?: string;
};

export type WorkbenchDevice = WorkbenchDeviceType;

export type EditorWorkbenchProps = {
  /** Fejléc bal oldali tartalma (cím, státusz, gombok). */
  toolbar?: React.ReactNode;
  /** Paletta panel (pl. <BlockPalette onInsert=… />). */
  palette?: React.ReactNode;
  items: WorkbenchItem[];
  loading?: boolean;
  selectedId: string | null;
  onSelect: (id: string | null) => void;
  /** Sorrend megváltozott — az új sorrendben lévő id lista. */
  onReorder: (ids: string[]) => void | Promise<void>;
  /** Palettáról érkező elem beszúrása adott indexre. */
  onInsertAt?: (payload: { type: string; defaults: Record<string, unknown>; index: number }) => void | Promise<void>;
  /** Egy elem vászon-renderelése. Ha nincs, a lista-nézet jelenik meg. */
  renderItem?: (item: WorkbenchItem, index: number) => React.ReactNode;
  /** Inspector panel a kiválasztott elemhez. */
  inspector?: React.ReactNode;
  /** In-site élő előnézet URL-je (iframe src). */
  previewUrl?: string | null;
  /** Vagy közvetlen HTML (pl. e-mail sablonhoz). */
  previewSrcDoc?: string | null;
  /** Külső jel az előnézet frissítésére (növekvő szám). */
  previewNonce?: number;
};

export function EditorWorkbench({
  toolbar, palette, items, loading, selectedId, onSelect, onReorder, onInsertAt,
  renderItem, inspector, previewUrl, previewSrcDoc, previewNonce = 0,
}: EditorWorkbenchProps) {
  const [device, setDevice] = usePreviewDevice();
  const [showPreview, setShowPreview] = useState(true);
  const [nonce, setNonce] = useState(0);
  const lastNonce = useRef(previewNonce);

  useEffect(() => {
    if (previewNonce !== lastNonce.current) {
      lastNonce.current = previewNonce;
      setNonce((n) => n + 1);
    }
  }, [previewNonce]);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 6 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  );

  const handleDragEnd = useCallback(
    async (e: DragEndEvent) => {
      const { active, over } = e;
      if (!over) return;
      const paletteData = active.data.current as { palette?: boolean; type?: string; defaults?: Record<string, unknown> } | undefined;

      if (paletteData?.palette && paletteData.type) {
        const overId = String(over.id);
        const index = overId === "workbench-end" ? items.length : Math.max(0, items.findIndex((i) => i.id === overId));
        await onInsertAt?.({ type: paletteData.type, defaults: paletteData.defaults ?? {}, index });
        return;
      }

      if (active.id === over.id) return;
      const from = items.findIndex((i) => i.id === active.id);
      const to = items.findIndex((i) => i.id === over.id);
      if (from < 0 || to < 0) return;
      await onReorder(arrayMove(items, from, to).map((i) => i.id));
    },
    [items, onInsertAt, onReorder],
  );

  const previewSrc = previewUrl ? `${previewUrl}${previewUrl.includes("?") ? "&" : "?"}_n=${nonce}` : undefined;

  return (
    <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
      <div className="flex h-[calc(100vh-3.5rem)] flex-col">
        <div className="flex flex-wrap items-center gap-2 border-b px-3 py-2">
          {toolbar}
          <PreviewToolbar
            className="ml-auto"
            device={device}
            onDeviceChange={setDevice}
            onRefresh={() => setNonce((n) => n + 1)}
            showPreview={showPreview}
            onTogglePreview={() => setShowPreview((v) => !v)}
            externalUrl={previewUrl ?? undefined}
          />
        </div>

        <ResizablePanelGroup orientation="horizontal" className="flex-1">
          {palette && (
            <>
              <ResizablePanel defaultSize={18} minSize={12} className="overflow-y-auto bg-muted/30">
                {palette}
              </ResizablePanel>
              <ResizableHandle withHandle />
            </>
          )}

          <ResizablePanel defaultSize={showPreview ? 34 : 58} minSize={20} className="overflow-y-auto">
            <div className="p-3 space-y-2">
              {loading && (
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Loader2 className="size-3 animate-spin" /> Betöltés…
                </div>
              )}
              <SortableContext items={items.map((i) => i.id)} strategy={verticalListSortingStrategy}>
                {items.map((item, i) => (
                  <SortableBlock key={item.id} id={item.id}>
                    <button
                      type="button"
                      onClick={() => onSelect(item.id)}
                      className={cn(
                        "w-full text-left rounded border p-2 pl-9 transition min-h-11",
                        selectedId === item.id ? "border-primary bg-accent" : "border-border/60 hover:bg-accent/50",
                      )}
                    >
                      {renderItem ? (
                        renderItem(item, i)
                      ) : (
                        <>
                          <div className="flex items-center gap-2">
                            <Badge variant="secondary" className="text-[10px]">{item.type}</Badge>
                          </div>
                          {item.subtitle && (
                            <div className="text-[11px] text-muted-foreground truncate mt-0.5">{item.subtitle}</div>
                          )}
                        </>
                      )}
                    </button>
                  </SortableBlock>
                ))}
              </SortableContext>
              <WorkbenchEndDropZone enabled={!!onInsertAt} />
            </div>
          </ResizablePanel>

          {inspector && (
            <>
              <ResizableHandle withHandle />
              <ResizablePanel defaultSize={26} minSize={16} className="overflow-y-auto border-l">
                {inspector}
              </ResizablePanel>
            </>
          )}

          {showPreview && (previewSrc || previewSrcDoc) && (
            <>
              <ResizableHandle withHandle />
              <ResizablePanel defaultSize={36} minSize={20} className="bg-muted/40">
                <PreviewFrame
                  device={device}
                  src={previewSrc}
                  srcDoc={previewSrcDoc ?? undefined}
                  frameKey={`${nonce}-${previewSrcDoc ? "doc" : "url"}`}
                  className="h-full min-h-[400px]"
                />
              </ResizablePanel>
            </>
          )}
        </ResizablePanelGroup>
      </div>
    </DndContext>
  );
}

function WorkbenchEndDropZone({ enabled }: { enabled: boolean }) {
  const { setNodeRef, isOver } = useDroppable({ id: "workbench-end" });
  if (!enabled) return null;
  return (
    <div
      ref={setNodeRef}
      className={cn(
        "rounded border-2 border-dashed p-4 text-center text-xs text-muted-foreground transition",
        isOver ? "border-primary bg-primary/5 text-primary" : "border-border/60",
      )}
    >
      Húzz ide egy elemet a paletáról a végére szúráshoz
    </div>
  );
}
