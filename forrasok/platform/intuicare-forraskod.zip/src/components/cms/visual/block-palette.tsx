/**
 * Compact block palette — categorized buttons that insert a new block (with
 * default content from the catalog). Items are also draggable: dropping one
 * on a block in the canvas inserts it at that exact position.
 */
import { useState } from "react";
import { useDraggable } from "@dnd-kit/core";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Plus, GripVertical } from "lucide-react";
import { BLOCK_CATALOG, type BlockCategory } from "@/lib/cms/block-schema";

const CATEGORIES: { key: BlockCategory; label: string }[] = [
  { key: "klinika", label: "Klinika" },
  { key: "hero", label: "Hero" },
  { key: "content", label: "Tartalom" },
  { key: "list", label: "Lista" },
  { key: "cta", label: "CTA" },
  { key: "media", label: "Média" },
  { key: "layout", label: "Layout" },
];

function PaletteItem({
  type, label, description, defaults, onInsert,
}: {
  type: string;
  label: string;
  description?: string;
  defaults: Record<string, unknown>;
  onInsert: (type: string, defaults: Record<string, unknown>) => void;
}) {
  const { attributes, listeners, setNodeRef, isDragging } = useDraggable({
    id: `palette:${type}`,
    data: { palette: true, type, defaults },
  });
  return (
    <div
      ref={setNodeRef}
      className={`w-full flex items-start gap-1 p-2 rounded border hover:bg-accent transition ${isDragging ? "opacity-50" : ""}`}
    >
      <button
        type="button"
        className="mt-0.5 cursor-grab active:cursor-grabbing text-muted-foreground touch-none"
        aria-label={`${label} húzása a vászonra`}
        {...attributes}
        {...listeners}
      >
        <GripVertical className="size-3.5" />
      </button>
      <button type="button" onClick={() => onInsert(type, defaults)} className="flex-1 text-left">
        <div className="text-sm font-medium flex items-center gap-2">
          <Plus className="size-3.5 text-muted-foreground" />
          {label}
        </div>
        <div className="text-[11px] text-muted-foreground">{description}</div>
      </button>
    </div>
  );
}

export function BlockPalette({ onInsert }: { onInsert: (type: string, defaults: Record<string, unknown>) => void }) {
  const [q, setQ] = useState("");
  const insertable = BLOCK_CATALOG.filter((b) => !b.regions?.length);
  const filtered = insertable.filter(
    (b) =>
      !q ||
      b.label.toLowerCase().includes(q.toLowerCase()) ||
      b.type.toLowerCase().includes(q.toLowerCase()),
  );

  return (
    <div className="p-3 space-y-3">
      <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Blokk keresése…" className="h-9" />
      <p className="text-[11px] text-muted-foreground">Kattints a beszúráshoz, vagy húzd a vászon kívánt pontjára.</p>
      <Tabs defaultValue="klinika">
        <TabsList className="flex flex-wrap h-auto">
          {CATEGORIES.map((c) => (
            <TabsTrigger key={c.key} value={c.key} className="text-xs">{c.label}</TabsTrigger>
          ))}
        </TabsList>
        {CATEGORIES.map((c) => {
          const items = filtered.filter((b) => b.category === c.key);
          return (
            <TabsContent key={c.key} value={c.key} className="space-y-1">
              {items.length === 0 && <div className="text-xs text-muted-foreground p-2">Nincs találat.</div>}
              {items.map((b) => (
                <PaletteItem
                  key={b.type}
                  type={b.type}
                  label={b.label}
                  description={b.description}
                  defaults={b.defaults ?? {}}
                  onInsert={onInsert}
                />
              ))}
            </TabsContent>
          );
        })}
      </Tabs>
    </div>
  );
}
