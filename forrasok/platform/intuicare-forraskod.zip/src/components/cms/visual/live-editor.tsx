/**
 * Live in-place CMS editor.
 *
 * Renders the actual page (via CmsPageRenderer) inside a width-constrained
 * canvas. Every block is wrapped with EditableBlockWrapper for hover-based
 * actions + selection. The right panel inspects the selected block; the
 * left panel lets you pick page or insert new blocks.
 *
 * Featues:
 *  - Undo/Redo history (Ctrl+Z / Ctrl+Shift+Z) — see useHistoryStack.
 *  - AI preview + approval step — generated blocks are shown in a modal
 *    (editable JSON) and only inserted after the user clicks "Beszúrás".
 *  - Autosave + local draft rescue in the inspector (BlockInspector).
 *  - Error toasts on every failed mutation.
 */
import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  DndContext,
  closestCenter,
  PointerSensor,
  KeyboardSensor,
  useSensor,
  useSensors,
  useDroppable,
  type DragEndEvent,
} from "@dnd-kit/core";
import {
  SortableContext,
  verticalListSortingStrategy,
  sortableKeyboardCoordinates,
  arrayMove,
} from "@dnd-kit/sortable";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger, DialogDescription,
} from "@/components/ui/dialog";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Eye, EyeOff, ExternalLink, Loader2,
  LayoutTemplate, Sparkles, Wand2, Undo2, Redo2, PanelRightOpen, RefreshCw, X, SlidersHorizontal, TextCursorInput,
} from "lucide-react";
import { toast } from "sonner";

import { listPages, getPagePreviewLink } from "@/lib/cms/cms.functions";
import { SUPPORTED_LANGUAGES } from "@/i18n/languages";

import {
  listPageBlocks,
  upsertLayoutBlock,
  deleteLayoutBlock,
  reorderLayoutBlocks,
  type LayoutBlock,
} from "@/lib/cms/layout-blocks.functions";
import {
  generateBlockContent,
  generatePageDraft,
  generateContextualBlock,
} from "@/lib/cms/ai-blocks.functions";
import { BLOCK_TEMPLATES } from "@/lib/cms/block-templates";
import { BLOCK_CATALOG } from "@/lib/cms/block-schema";

import { CmsPageRenderer } from "@/components/cms/cms-renderer";
import { EditableBlockWrapper } from "@/components/cms/visual/editable-block-wrapper";
import { BlockInspector } from "@/components/cms/visual/block-inspector";
import { BlockPalette } from "@/components/cms/visual/block-palette";
import { PendingChangesDrawer } from "@/components/cms/visual/pending-changes-drawer";
import { SortableBlock } from "@/components/cms/visual/sortable-block";
import { setAtPath } from "@/components/cms/visual/use-inline-edit";
import { RegionEditorDialog } from "@/components/cms/visual/region-editor";
import { AiTranslateBlocksDialog } from "@/components/cms/visual/ai-translate-blocks-dialog";
import { NavigationPreviewPanel } from "@/components/cms/visual/navigation-preview-panel";
import { VersionHistoryDialog } from "@/components/cms/visual/version-history-dialog";
import { useHistoryStack } from "@/hooks/use-history-stack";
import { ResizablePanelGroup, ResizablePanel, ResizableHandle } from "@/components/ui/resizable";

import {
  usePreviewDevice, PreviewDeviceSwitcher,
  PREVIEW_DEVICE_WIDTH as DEVICE_WIDTH, type PreviewDevice as Device,
} from "./preview-toolbar";

export function LiveEditor() {
  const qc = useQueryClient();
  const listPagesFn = useServerFn(listPages);
  const listBlocksFn = useServerFn(listPageBlocks);
  const upsertFn = useServerFn(upsertLayoutBlock);
  const deleteFn = useServerFn(deleteLayoutBlock);
  const reorderFn = useServerFn(reorderLayoutBlocks);

  const pagesQ = useQuery({ queryKey: ["cms-pages-all"], queryFn: () => listPagesFn() });
  const [pageId, setPageId] = useState<string | null>(null);
  const [device, setDevice] = usePreviewDevice();
  const [showDraft, setShowDraft] = useState(true);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [showIframe, setShowIframe] = useState(false);
  const [iframeNonce, setIframeNonce] = useState(0);
  const iframeDevice = device;
  const setIframeDevice = setDevice;
  // Többnyelvű előnézet: egy vagy több locale-t választhatunk. Alapból csak `hu`.
  const [previewLocales, setPreviewLocales] = useState<string[]>(["hu"]);
  // Navigációs előnézet: ha az admin a nav-panelen egy menüpontra kattint,
  // az iframe erre az URL-re ugrik (fallback: az aktuális oldal previewUrl-je).
  const [iframeNavOverride, setIframeNavOverride] = useState<string | null>(null);


  const history = useHistoryStack();

  useEffect(() => {
    if (!pageId && pagesQ.data?.length) {
      const home = (pagesQ.data as any[]).find((p) => p.is_home && p.status === "published");
      setPageId((home ?? (pagesQ.data as any[])[0]).id);
    }
  }, [pagesQ.data, pageId]);

  // Clear history when switching pages
  useEffect(() => { history.clear(); /* eslint-disable-next-line */ }, [pageId]);

  const blocksQ = useQuery({
    queryKey: ["cms-page-blocks", pageId],
    enabled: !!pageId,
    queryFn: () => listBlocksFn({ data: { pageId: pageId! } }),
  });
  const blocks = (blocksQ.data ?? []) as (LayoutBlock & {
    draft_content?: any;
    draft_status?: "none" | "pending" | "approved" | "rejected" | null;
    draft_note?: string | null;
  })[];

  const selected = useMemo(() => blocks.find((b) => b.id === selectedId) ?? null, [blocks, selectedId]);

  // ── Preview vs Published state derivations ────────────────────────────
  const currentPage = useMemo<any | null>(
    () => (pagesQ.data as any[] | undefined)?.find((p) => p.id === pageId) ?? null,
    [pagesQ.data, pageId]
  );
  const lastSaved = useMemo<Date | null>(() => {
    const times: number[] = [];
    if (currentPage?.updated_at) times.push(new Date(currentPage.updated_at).getTime());
    for (const b of blocks) {
      if ((b as any).updated_at) times.push(new Date((b as any).updated_at).getTime());
    }
    const max = times.length ? Math.max(...times) : NaN;
    return Number.isFinite(max) ? new Date(max) : null;
  }, [currentPage, blocks]);
  const publishedAt = currentPage?.published_at ? new Date(currentPage.published_at) : null;
  const pendingDraftCount = blocks.filter((b) => b.draft_status === "pending").length;
  const hasUnpublishedChanges =
    !!currentPage &&
    (currentPage.status !== "published" ||
      pendingDraftCount > 0 ||
      (publishedAt && lastSaved ? lastSaved.getTime() > publishedAt.getTime() : !publishedAt));

  // Debounced iframe reload so autosave + rapid mutations coalesce into one
  // preview refresh (~400ms) instead of flashing on every keystroke-save.
  const iframeReloadTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const scheduleIframeReload = () => {
    if (iframeReloadTimer.current) clearTimeout(iframeReloadTimer.current);
    iframeReloadTimer.current = setTimeout(() => setIframeNonce((n) => n + 1), 400);
  };
  useEffect(() => () => { if (iframeReloadTimer.current) clearTimeout(iframeReloadTimer.current); }, []);

  // Esc: kijelölés megszüntetése (a sidebar/sheet zárul)
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && selectedId) {
        const tag = (e.target as HTMLElement | null)?.tagName;
        if (tag === "INPUT" || tag === "TEXTAREA" || (e.target as HTMLElement)?.isContentEditable) return;
        setSelectedId(null);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [selectedId]);

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ["cms-page-blocks", pageId] });
    qc.invalidateQueries({ queryKey: ["cms-pending-drafts", pageId] });
    qc.invalidateQueries({ queryKey: ["cms-pages-all"] });
    scheduleIframeReload();
  };

  // ── Insert helper — returns the newly created block id (so callers can
  //    push a proper inverse into the history stack).
  const insertBlockAt = async ({
    type, content, index,
  }: { type: string; content: any; index?: number }): Promise<string | null> => {
    if (!pageId) return null;
    const at = typeof index === "number" ? Math.max(0, Math.min(index, blocks.length)) : blocks.length;
    try {
      const created: any = await upsertFn({
        data: {
          page_id: pageId,
          region_key: null,
          position: at,
          block_type: type,
          content: content ?? {},
          style: {},
          locale: "hu",
          status: "published",
        } as any,
      });
      if (at < blocks.length) {
        const before = blocks.slice(0, at);
        const after = blocks.slice(at);
        const items = [...before, { id: "__new__" }, ...after].map((b, i) => ({
          id: (b as any).id,
          position: i,
        })).filter((x) => x.id !== "__new__");
        await reorderFn({ data: { items } });
      }
      invalidate();
      return created?.id ?? null;
    } catch (e: any) {
      toast.error("Blokk beszúrása sikertelen", { description: e?.message?.slice(0, 200) });
      throw e;
    }
  };

  // Recreate a previously-deleted block (used by undo)
  const recreateBlock = async (b: LayoutBlock, atPosition: number): Promise<string | null> => {
    const created: any = await upsertFn({
      data: {
        page_id: b.page_id, region_key: b.region_key,
        position: atPosition, block_type: b.block_type,
        content: b.content, style: b.style, locale: b.locale, status: b.status,
      } as any,
    });
    invalidate();
    return created?.id ?? null;
  };

  // ── Add / delete / move ─────────────────────────────────────────────────
  const addBlock = useMutation({
    mutationFn: async ({ type, defaults, index }: { type: string; defaults: any; index?: number }) => {
      const id = await insertBlockAt({ type, content: defaults ?? {}, index });
      return { id, type, defaults, index: index ?? blocks.length };
    },
    onSuccess: (res) => {
      toast.success("Blokk hozzáadva");
      if (!res?.id) return;
      let currentId = res.id;
      history.push({
        label: "Blokk hozzáadása",
        undo: async () => {
          try { await deleteFn({ data: { id: currentId } }); invalidate(); }
          catch (e: any) { toast.error("Visszavonás sikertelen", { description: e?.message?.slice(0, 200) }); }
        },
        redo: async () => {
          try {
            const newId = await insertBlockAt({ type: res.type, content: res.defaults, index: res.index });
            if (newId) currentId = newId;
          } catch (e: any) { toast.error("Újraalkalmazás sikertelen", { description: e?.message?.slice(0, 200) }); }
        },
      });
    },
    onError: (e: any) => toast.error("Hozzáadás sikertelen", { description: e?.message?.slice(0, 200) }),
  });

  const persistOrder = async (reordered: typeof blocks) => {
    qc.setQueryData(["cms-page-blocks", pageId], reordered);
    try {
      await reorderFn({ data: { items: reordered.map((b, i) => ({ id: b.id, position: i })) } });
      invalidate();
    } catch (e: any) {
      toast.error(e?.message ?? "Az átrendezés nem mentődött");
      invalidate();
    }
  };

  const moveBlock = async (id: string, dir: -1 | 1) => {
    const idx = blocks.findIndex((b) => b.id === id);
    const next = idx + dir;
    if (idx < 0 || next < 0 || next >= blocks.length) return;
    const prevOrder = blocks.map((b) => b.id);
    const reordered = [...blocks];
    const [m] = reordered.splice(idx, 1);
    reordered.splice(next, 0, m);
    const newOrder = reordered.map((b) => b.id);
    await persistOrder(reordered);
    history.push({
      label: "Blokk mozgatása",
      undo: async () => {
        try {
          await reorderFn({ data: { items: prevOrder.map((bid, i) => ({ id: bid, position: i })) } });
          invalidate();
        } catch (e: any) { toast.error("Mozgatás visszavonása sikertelen", { description: e?.message?.slice(0, 200) }); }
      },
      redo: async () => {
        try {
          await reorderFn({ data: { items: newOrder.map((bid, i) => ({ id: bid, position: i })) } });
          invalidate();
        } catch (e: any) { toast.error("Újraalkalmazás sikertelen", { description: e?.message?.slice(0, 200) }); }
      },
    });
  };

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 4 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  );

  const handleDragEnd = async (e: DragEndEvent) => {
    const { active, over } = e;
    if (!over) return;

    // Palettáról húzott új blokk → a cél blokk helyére szúrjuk be.
    const paletteData = active.data.current as any;
    if (paletteData?.palette) {
      const overIdx = blocks.findIndex((b) => b.id === over.id);
      const index = over.id === "canvas-end" || overIdx < 0 ? blocks.length : overIdx;
      addBlock.mutate({ type: paletteData.type, defaults: paletteData.defaults ?? {}, index });
      return;
    }

    if (active.id === over.id) return;
    const oldIdx = blocks.findIndex((b) => b.id === active.id);
    const newIdx = over.id === "canvas-end" ? blocks.length - 1 : blocks.findIndex((b) => b.id === over.id);
    if (oldIdx < 0 || newIdx < 0) return;
    const prevOrder = blocks.map((b) => b.id);
    const reordered = arrayMove(blocks, oldIdx, newIdx);
    const newOrder = reordered.map((b) => b.id);
    toast.success("Sorrend frissítve");
    await persistOrder(reordered);
    history.push({
      label: "Sorrend módosítása",
      undo: async () => { await reorderFn({ data: { items: prevOrder.map((bid, i) => ({ id: bid, position: i })) } }); invalidate(); },
      redo: async () => { await reorderFn({ data: { items: newOrder.map((bid, i) => ({ id: bid, position: i })) } }); invalidate(); },
    });
  };

  // ── In-place (inline) szövegszerkesztés ────────────────────────────────
  const [inlineEdit, setInlineEdit] = useState(false);
  const commitInline = async (block: LayoutBlock, path: (string | number)[], value: string) => {
    const prevContent = block.content ?? {};
    const nextContent = setAtPath(prevContent, path, value);
    const save = async (content: any) => {
      await upsertFn({ data: { ...(block as any), content } as any });
      invalidate();
    };
    try {
      await save(nextContent);
      toast.success("Szöveg mentve");
      history.push({
        label: "Inline szerkesztés",
        undo: async () => { try { await save(prevContent); } catch (e: any) { toast.error("Visszavonás sikertelen", { description: e?.message?.slice(0, 200) }); } },
        redo: async () => { try { await save(nextContent); } catch (e: any) { toast.error("Újraalkalmazás sikertelen", { description: e?.message?.slice(0, 200) }); } },
      });
    } catch (e: any) {
      toast.error("A szöveg mentése sikertelen", { description: e?.message?.slice(0, 200) });
    }
  };


  const duplicateBlock = async (b: LayoutBlock) => {
    try {
      const created: any = await upsertFn({
        data: {
          page_id: b.page_id, region_key: b.region_key,
          position: blocks.length, block_type: b.block_type,
          content: b.content, style: b.style, locale: b.locale, status: b.status,
        } as any,
      });
      toast.success("Blokk duplikálva");
      invalidate();
      if (created?.id) {
        let currentId = created.id as string;
        history.push({
          label: "Duplikálás",
          undo: async () => { await deleteFn({ data: { id: currentId } }); invalidate(); },
          redo: async () => {
            const again = await recreateBlock(b, blocks.length);
            if (again) currentId = again;
          },
        });
      }
    } catch (e: any) {
      toast.error("Duplikálás sikertelen", { description: e?.message?.slice(0, 200) });
    }
  };

  const removeBlock = async (id: string) => {
    const snapshot = blocks.find((b) => b.id === id);
    const position = blocks.findIndex((b) => b.id === id);
    try {
      await deleteFn({ data: { id } });
      if (selectedId === id) setSelectedId(null);
      toast.success("Blokk törölve");
      invalidate();
      if (snapshot) {
        let currentId = id;
        history.push({
          label: "Blokk törlése",
          undo: async () => {
            const newId = await recreateBlock(snapshot as any, Math.max(0, position));
            if (newId) currentId = newId;
          },
          redo: async () => { await deleteFn({ data: { id: currentId } }); invalidate(); },
        });
      }
    } catch (e: any) {
      toast.error("Törlés sikertelen", { description: e?.message?.slice(0, 200) });
    }
  };

  const previewLinkFn = useServerFn(getPagePreviewLink);
  const previewLinkQ = useQuery({
    queryKey: ["cms-page-preview-link", pageId],
    queryFn: () => previewLinkFn({ data: { pageId: pageId! } }),
    enabled: !!pageId,
    staleTime: 5 * 60_000,
  });
  // Nested slugok (`hirek/<child>`, `blog/<child>`, `vlog/<child>`) a saját
  // route-jukon élnek, nem a /o/$slug single-segment matchen — az `/o/hirek/x`
  // 404-et adna. A többi (single-segment) publikus slug marad `/o/<slug>`.
  const buildPreviewPath = (slug: string | null | undefined, token: string | null | undefined, isHome: boolean) => {
    if (isHome) return "/";
    const s = (slug ?? "").replace(/^\/+/, "");
    if (!s) return "/";
    const qs = token ? `?preview=${token}` : "";
    const nested = ["hirek/", "blog/", "vlog/"].find((p) => s.startsWith(p));
    if (nested) {
      const child = s.slice(nested.length);
      return `/${nested}${child}${qs}`;
    }
    return `/o/${s}${qs}`;
  };
  const previewUrl = buildPreviewPath(
    previewLinkQ.data?.slug ?? currentPage?.slug ?? null,
    previewLinkQ.data?.token ?? null,
    !!currentPage?.is_home,
  );
  const pendingCount = blocks.filter((b) => b.draft_status === "pending").length;

  return (
    <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
    <div className="flex flex-col xl:flex-row gap-3 h-[calc(100vh-9rem)]">
      {/* ── Left: page picker + palette ───────────────────────────────── */}
      <aside className="w-full xl:w-72 shrink-0 space-y-3 overflow-y-auto">
        <Card>
          <CardContent className="p-3 space-y-2">
            <div className="text-xs font-semibold uppercase text-muted-foreground">Oldalak</div>
            {pagesQ.isLoading && <div className="text-sm text-muted-foreground">Betöltés…</div>}
            <div className="space-y-1">
              {(pagesQ.data ?? []).map((p: any) => (
                <button
                  key={p.id}
                  onClick={() => { setPageId(p.id); setSelectedId(null); }}
                  className={`w-full text-left text-sm px-2 py-1.5 rounded hover:bg-accent ${
                    pageId === p.id ? "bg-accent" : ""
                  }`}
                >
                  <div className="flex items-center gap-2">
                    {p.is_home && <Badge variant="secondary" className="text-[10px]">Főoldal</Badge>}
                    <span className="truncate">{p.title}</span>
                  </div>
                  <div className="text-[11px] text-muted-foreground">/{p.is_home ? "" : `o/${p.slug}`} · {p.status}</div>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-0">
            <BlockPalette
              onInsert={(type, defaults) => addBlock.mutate({ type, defaults })}
            />
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-3 space-y-2">
            <div className="text-xs font-semibold uppercase text-muted-foreground">Sablonok & AI</div>
            <TemplateGalleryButton
              onInsert={(tpl) => addBlock.mutate({ type: tpl.block_type, defaults: tpl.content })}
            />
            {pageId && (
              <AiContextualBlockButton
                pageId={pageId}
                totalBlocks={blocks.length}
                onApprove={async ({ block_type, content, insert_position, rationale }) => {
                  await addBlock.mutateAsync({ type: block_type, defaults: content, index: insert_position });
                  if (rationale) toast.message("AI: miért ez a blokk?", { description: rationale });
                }}
              />
            )}
            {pageId && (
              <AiPageDraftButton
                pageId={pageId}
                startPosition={blocks.length}
                onApprove={async (blks) => {
                  for (let i = 0; i < blks.length; i++) {
                    await addBlock.mutateAsync({ type: blks[i].block_type, defaults: blks[i].content });
                  }
                }}
              />
            )}
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-3 space-y-2">
            <div className="text-xs font-semibold uppercase text-muted-foreground">Globális régiók</div>
            <RegionEditorDialog onSaved={() => scheduleIframeReload()} />
          </CardContent>
        </Card>
        <NavigationPreviewPanel
          onOpenInIframe={(href) => {
            setShowIframe(true);
            setIframeNavOverride(href);
            setIframeNonce((n) => n + 1);
          }}
        />

      </aside>

      {/* ── Middle: live editable canvas ──────────────────────────────── */}
      <section className="flex-1 min-w-0 flex flex-col">
        <div className="flex flex-wrap items-center gap-2 mb-2">
          <PreviewDeviceSwitcher value={device} onChange={setDevice} />
          <Button variant="outline" size="sm" onClick={() => setShowDraft((v) => !v)} className="gap-1">
            {showDraft ? <Eye className="size-4" /> : <EyeOff className="size-4" />}
            {showDraft ? "Vázlatokkal" : "Csak publikált"}
          </Button>
          <Button
            variant={inlineEdit ? "default" : "outline"}
            size="sm"
            className="gap-1"
            onClick={() => setInlineEdit((v) => !v)}
            title="Szövegek közvetlen szerkesztése az előnézetben (Enter = mentés, Esc = elvetés)"
          >
            <TextCursorInput className="size-4" />
            {inlineEdit ? "Inline szerkesztés BE" : "Inline szerkesztés"}
          </Button>

          <div className="flex items-center gap-1">
            <Button
              variant="outline" size="sm" className="gap-1"
              disabled={!history.canUndo}
              onClick={() => history.undo()}
              title={history.undoLabel ? `Visszavon: ${history.undoLabel} (Ctrl+Z)` : "Nincs mit visszavonni"}
            >
              <Undo2 className="size-4" />Vissza
            </Button>
            <Button
              variant="outline" size="sm" className="gap-1"
              disabled={!history.canRedo}
              onClick={() => history.redo()}
              title={history.redoLabel ? `Ismét: ${history.redoLabel} (Ctrl+Shift+Z)` : "Nincs mit újra elvégezni"}
            >
              <Redo2 className="size-4" />Előre
            </Button>
          </div>
          {pageId && (
            <PendingChangesDrawer pageId={pageId} onApplied={invalidate} />
          )}
          <AiTranslateBlocksDialog selectedBlockId={selectedId} onDone={invalidate} />
          <VersionHistoryDialog pageId={pageId} onRestored={invalidate} />

          {pendingCount > 0 && (
            <Badge className="bg-amber-500 text-white">{pendingCount} függő</Badge>
          )}
          <Button
            variant={showIframe ? "default" : "outline"}
            size="sm"
            onClick={() => setShowIframe((v) => !v)}
            className="gap-1"
            title="Élő iframe előnézet a valós publikus oldalról"
          >
            <PanelRightOpen className="size-4" />Live előnézet
          </Button>
          {showIframe && (
            <Button
              variant="outline" size="sm" onClick={() => setIframeNonce((n) => n + 1)}
              className="gap-1" title="Iframe újratöltése"
            >
              <RefreshCw className="size-4" />
            </Button>
          )}
          <Button variant="outline" size="sm" asChild>
            <a href={previewUrl} target="_blank" rel="noreferrer" className="gap-1">
              <ExternalLink className="size-4" />Publikus nézet
            </a>
          </Button>
          <div className="ml-auto text-xs text-muted-foreground">{previewUrl}</div>
        </div>

        {/* ── Preview vs Published status bar ────────────────────────── */}
        {currentPage && (
          <div className="flex flex-wrap items-center gap-2 rounded-md border bg-muted/40 px-3 py-1.5 text-xs">
            {currentPage.status === "published" ? (
              <Badge className="bg-emerald-500 text-white gap-1">● Publikált</Badge>
            ) : currentPage.status === "draft" ? (
              <Badge variant="secondary" className="gap-1">● Vázlat</Badge>
            ) : (
              <Badge variant="outline" className="gap-1">● {currentPage.status}</Badge>
            )}
            {hasUnpublishedChanges && (
              <Badge className="bg-amber-500 text-white gap-1" title="A szerkesztőben lévő állapot még nem publikált">
                ● Nem publikált változás
              </Badge>
            )}
            {pendingDraftCount > 0 && (
              <Badge variant="outline" className="border-amber-400 text-amber-700 dark:text-amber-300">
                {pendingDraftCount} függő blokk-vázlat
              </Badge>
            )}
            <span className="text-muted-foreground">
              Utolsó mentés:{" "}
              <span className="font-medium text-foreground">
                {lastSaved ? lastSaved.toLocaleString("hu-HU", { dateStyle: "short", timeStyle: "short" }) : "—"}
              </span>
            </span>
            <span className="text-muted-foreground">
              · Publikálva:{" "}
              <span className="font-medium text-foreground">
                {publishedAt ? publishedAt.toLocaleString("hu-HU", { dateStyle: "short", timeStyle: "short" }) : "még soha"}
              </span>
            </span>
          </div>
        )}



        <div className="flex-1 min-h-0">
          {(() => {
            const canvas = (
              <div className="border rounded-lg bg-muted/30 overflow-auto p-3 flex justify-center h-full">
                {blocksQ.isLoading ? (
                  <div className="flex items-center gap-2 text-muted-foreground"><Loader2 className="size-4 animate-spin" />Betöltés…</div>
                ) : (
                  <div
                    className="bg-background rounded shadow-sm transition-all w-full"
                    style={{ maxWidth: DEVICE_WIDTH[device] }}
                    onClick={() => setSelectedId(null)}
                  >
                    <SortableContext items={blocks.map((b) => b.id)} strategy={verticalListSortingStrategy}>
                      <CmsPageRenderer
                        blocks={blocks as any}
                        editMode={{
                          selectedId,
                          showDraft,
                          renderWrapper: (b, child) => (
                            <EditableBlockWrapper
                              block={b as any}
                              selected={selectedId === b.id}
                              onSelect={() => setSelectedId(b.id)}
                              onMoveUp={() => moveBlock(b.id, -1)}
                              onMoveDown={() => moveBlock(b.id, 1)}
                              onDuplicate={() => duplicateBlock(b as any)}
                              onDelete={() => removeBlock(b.id)}
                              inlineEdit={inlineEdit}
                              content={(b as any).content ?? {}}
                              onInlineCommit={(path, value) => commitInline(b as any, path, value)}
                            >
                              {child}
                            </EditableBlockWrapper>
                          ),
                          renderItem: (b, child) => <SortableBlock id={b.id}>{child}</SortableBlock>,
                        }}
                      />
                    </SortableContext>
                    <CanvasEndDropZone hasBlocks={blocks.length > 0} />

                  </div>
                )}
              </div>
            );

            if (!showIframe) return canvas;

            const activePreviewUrl = iframeNavOverride ?? previewUrl;
            const buildLocaleUrl = (loc: string) => {
              const base = `${activePreviewUrl}${activePreviewUrl.includes("?") ? "&" : "?"}_cms=${iframeNonce}`;
              return loc === "hu" ? base : `${base}&lang=${loc}`;
            };
            const locales = previewLocales.length > 0 ? previewLocales : ["hu"];

            const iframePanel = (
              <div className="border rounded-lg bg-muted/30 overflow-hidden flex flex-col h-full">
                <div className="text-[11px] px-2 py-1 border-b bg-background flex items-center gap-2 flex-wrap">
                  {hasUnpublishedChanges ? (
                    <Badge className="bg-amber-500 text-white text-[10px] h-5">Nem publikált</Badge>
                  ) : (
                    <Badge className="bg-emerald-500 text-white text-[10px] h-5">Publikált</Badge>
                  )}
                  <span className="text-muted-foreground truncate flex-1 min-w-[120px]">
                    {activePreviewUrl}
                    {lastSaved && (
                      <> · mentve: {lastSaved.toLocaleTimeString("hu-HU", { hour: "2-digit", minute: "2-digit" })}</>
                    )}
                  </span>
                  {iframeNavOverride && (
                    <Button
                      size="sm" variant="ghost" className="h-6 px-2 text-[11px]"
                      onClick={() => setIframeNavOverride(null)}
                      title="Vissza az aktuális oldal előnézetére"
                    >Vissza az oldalra</Button>
                  )}
                  {/* Többnyelvű előnézet-választó */}
                  <div className="flex items-center gap-0.5 border rounded p-0.5" title="Nyelvi előnézet — kattints többre, hogy egymás mellett lásd">
                    {SUPPORTED_LANGUAGES.map((l) => {
                      const active = locales.includes(l.code);
                      return (
                        <button
                          key={l.code}
                          type="button"
                          onClick={() => setPreviewLocales((prev) => {
                            const s = new Set(prev);
                            if (s.has(l.code)) s.delete(l.code); else s.add(l.code);
                            const next = Array.from(s);
                            return next.length === 0 ? ["hu"] : next;
                          })}
                          className={`h-5 min-w-[22px] px-1 text-[10px] rounded ${active ? "bg-primary text-primary-foreground" : "hover:bg-accent"}`}
                          title={l.label}
                        >
                          {l.flag} {l.code}
                        </button>
                      );
                    })}
                  </div>
                  <PreviewDeviceSwitcher value={iframeDevice} onChange={setIframeDevice} size="sm" />
                  <span className="text-muted-foreground text-[10px]">#{iframeNonce}</span>
                </div>
                <div className="flex-1 min-h-0 overflow-auto bg-background flex gap-2 p-2">
                  {locales.map((loc) => {
                    const meta = SUPPORTED_LANGUAGES.find((l) => l.code === loc);
                    return (
                      <div key={loc} className="flex-1 min-w-0 flex flex-col border rounded overflow-hidden">
                        <div className="text-[10px] px-2 py-1 border-b bg-muted/50 flex items-center gap-1">
                          <span>{meta?.flag}</span>
                          <span className="font-medium">{meta?.label ?? loc}</span>
                          <span className="text-muted-foreground uppercase">{loc}</span>
                        </div>
                        <div className="flex-1 min-h-0 flex justify-center overflow-auto bg-background">
                          <iframe
                            key={`${iframeNonce}-${loc}`}
                            src={buildLocaleUrl(loc)}
                            title={`CMS live preview (${loc})`}
                            className="w-full h-full bg-background border-0"
                            style={{
                              maxWidth: iframeDevice === "desktop" ? "100%" : DEVICE_WIDTH[iframeDevice],
                            }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );


            return (
              <ResizablePanelGroup
                orientation="horizontal"
                className="gap-2"
              >
                <ResizablePanel defaultSize={55} minSize={25}>{canvas}</ResizablePanel>
                <ResizableHandle withHandle className="mx-1 bg-transparent" />
                <ResizablePanel defaultSize={45} minSize={20}>{iframePanel}</ResizablePanel>
              </ResizablePanelGroup>
            );
          })()}
        </div>
      </section>

      {/* ── Right: inspector (xl+ mindig látszik; kisebb kijelzőn Sheet nyílik) ── */}
      <aside className="hidden xl:flex xl:w-96 shrink-0 overflow-hidden border rounded-lg bg-card flex-col">
        <InspectorHeader
          selected={selected}
          onClose={() => setSelectedId(null)}
        />
        <div className="flex-1 overflow-y-auto">
          <BlockInspector
            block={selected as any}
            onChanged={invalidate}
            onDeleted={() => { setSelectedId(null); invalidate(); }}
          />
        </div>
      </aside>

      {/* Lebegő gomb kisebb kijelzőn a szerkesztő megnyitásához, ha épp nincs kijelölés */}
      {!selected && (
        <Button
          size="sm"
          variant="secondary"
          className="xl:hidden fixed bottom-4 right-4 z-40 shadow-lg gap-1"
          onClick={() => {
            const first = blocks[0]?.id;
            if (first) setSelectedId(first);
            else toast.message("Nincs blokk", { description: "Adj hozzá blokkot a bal oldali palettáról." });
          }}
        >
          <SlidersHorizontal className="size-4" /> Blokk tulajdonságok
        </Button>
      )}

      <Sheet
        open={!!selected}
        onOpenChange={(o) => { if (!o) setSelectedId(null); }}
      >
        <SheetContent side="right" className="w-full sm:max-w-md p-0 xl:hidden flex flex-col">
          <SheetHeader className="px-4 py-3 border-b">
            <SheetTitle className="text-sm">
              {selected ? (BLOCK_CATALOG.find((b) => b.type === selected.block_type)?.label ?? selected.block_type) : "Blokk tulajdonságok"}
            </SheetTitle>
          </SheetHeader>
          <div className="flex-1 overflow-y-auto">
            <BlockInspector
              block={selected as any}
              onChanged={invalidate}
              onDeleted={() => { setSelectedId(null); invalidate(); }}
            />
          </div>
        </SheetContent>
      </Sheet>
    </div>
    </DndContext>
  );
}

function InspectorHeader({
  selected,
  onClose,
}: { selected: any; onClose: () => void }) {
  const label = selected
    ? (BLOCK_CATALOG.find((b) => b.type === selected.block_type)?.label ?? selected.block_type)
    : null;
  return (
    <div className="flex items-center justify-between px-3 py-2 border-b bg-muted/40">
      <div className="min-w-0">
        <div className="text-[11px] uppercase tracking-wide text-muted-foreground">Tulajdonságok</div>
        <div className="text-sm font-medium truncate">
          {label ?? "Válassz egy blokkot a canvason"}
        </div>
      </div>
      {selected && (
        <Button
          size="icon"
          variant="ghost"
          className="h-7 w-7"
          onClick={onClose}
          aria-label="Kijelölés megszüntetése"
          title="Kijelölés megszüntetése (Esc)"
        >
          <X className="size-4" />
        </Button>
      )}
    </div>
  );
}

// ─── Sablon-galéria ──────────────────────────────────────────────────────
function TemplateGalleryButton({
  onInsert,
}: { onInsert: (tpl: (typeof BLOCK_TEMPLATES)[number]) => void }) {
  const [open, setOpen] = useState(false);
  const cats = Array.from(new Set(BLOCK_TEMPLATES.map((t) => t.category)));
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="w-full gap-1">
          <LayoutTemplate className="size-4" /> Sablonok galériája
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Blokk-sablonok</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          {cats.map((cat) => (
            <div key={cat}>
              <div className="text-xs uppercase font-semibold text-muted-foreground mb-2">{cat}</div>
              <div className="grid sm:grid-cols-2 gap-2">
                {BLOCK_TEMPLATES.filter((t) => t.category === cat).map((tpl) => (
                  <button
                    key={tpl.id}
                    type="button"
                    onClick={() => {
                      try {
                        onInsert(tpl);
                        setOpen(false);
                      } catch (e: any) {
                        toast.error("Sablon beszúrása sikertelen", { description: e?.message?.slice(0, 200) });
                      }
                    }}
                    className="text-left border rounded p-3 hover:bg-accent transition"
                  >
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary" className="text-[10px] uppercase">{tpl.category}</Badge>
                      <span className="text-sm font-medium">{tpl.label}</span>
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">{tpl.description}</div>
                    <div className="text-[11px] text-muted-foreground mt-1 font-mono">{tpl.block_type}</div>
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ─── AI kontextus-tudatos blokk generálás — előnézettel + jóváhagyással ─
type AiPreview = {
  block_type: string;
  content: any;
  insert_position: number;
  rationale: string;
};

function AiContextualBlockButton({
  pageId, totalBlocks, onApprove,
}: {
  pageId: string;
  totalBlocks: number;
  onApprove: (res: AiPreview) => Promise<void> | void;
}) {
  const generateFn = useServerFn(generateContextualBlock);
  const [open, setOpen] = useState(false);
  const [prompt, setPrompt] = useState("");
  const [busy, setBusy] = useState(false);
  const [preview, setPreview] = useState<AiPreview | null>(null);
  const [previewJson, setPreviewJson] = useState<string>("");
  const [jsonErr, setJsonErr] = useState<string | null>(null);

  const allowedTypes = useMemo(
    () => BLOCK_CATALOG.filter((b) => !b.regions || b.regions.length === 0).map((b) => b.type),
    [],
  );

  const run = async () => {
    if (prompt.trim().length < 3) return;
    setBusy(true);
    try {
      const res: any = await generateFn({
        data: { pageId, prompt, locale: "hu", allowedTypes },
      });
      const clean: AiPreview = {
        block_type: res.block_type,
        content: res.content ?? {},
        insert_position: typeof res.insert_position === "number" ? res.insert_position : totalBlocks,
        rationale: res.rationale ?? "",
      };
      setPreview(clean);
      setPreviewJson(JSON.stringify(clean.content, null, 2));
      setJsonErr(null);
    } catch (e: any) {
      toast.error("AI hiba", { description: e?.message?.slice(0, 200) });
    } finally {
      setBusy(false);
    }
  };

  const approve = async () => {
    if (!preview) return;
    let parsed: any;
    try { parsed = JSON.parse(previewJson); }
    catch (e: any) { setJsonErr(e?.message ?? "Érvénytelen JSON"); return; }
    setBusy(true);
    try {
      await onApprove({ ...preview, content: parsed });
      reset();
      setOpen(false);
    } catch (e: any) {
      toast.error("Beszúrás sikertelen", { description: e?.message?.slice(0, 200) });
    } finally {
      setBusy(false);
    }
  };

  const reset = () => { setPrompt(""); setPreview(null); setPreviewJson(""); setJsonErr(null); };

  return (
    <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) reset(); }}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="w-full gap-1">
          <Wand2 className="size-4" /> AI blokk (kontextussal)
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>AI: adj hozzá egy szekciót</DialogTitle>
          <DialogDescription>
            {preview
              ? "Nézd át a generált blokkot. Szerkesztheted a JSON-t is beszúrás előtt."
              : `Az AI látja az oldal jelenlegi blokkjait (${totalBlocks} db) és a kontextushoz illeszkedő új blokkot javasol.`}
          </DialogDescription>
        </DialogHeader>

        {!preview ? (
          <div className="space-y-2">
            <Textarea
              placeholder='Pl. "Szeretnék egy gombot ami az oldal aljára mutat és időpontfoglalásra visz."'
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              rows={4}
            />
          </div>
        ) : (
          <div className="space-y-3">
            <div className="rounded-md border p-3 bg-muted/30 text-xs space-y-1">
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="uppercase text-[10px]">{preview.block_type}</Badge>
                <span className="text-muted-foreground">helye: {preview.insert_position}. pozíció</span>
              </div>
              {preview.rationale && (
                <div className="text-muted-foreground italic">„{preview.rationale}"</div>
              )}
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium">Előnézet – tartalom (szerkeszthető JSON)</label>
              <Textarea
                value={previewJson}
                onChange={(e) => { setPreviewJson(e.target.value); setJsonErr(null); }}
                rows={12}
                className="font-mono text-xs"
              />
              {jsonErr && <div className="text-xs text-destructive">{jsonErr}</div>}
            </div>
          </div>
        )}

        <DialogFooter className="gap-2 sm:gap-2">
          {preview ? (
            <>
              <Button variant="ghost" onClick={reset} disabled={busy}>Új prompt</Button>
              <Button onClick={approve} disabled={busy} className="gap-1">
                {busy ? <Loader2 className="size-4 animate-spin" /> : <Wand2 className="size-4" />}
                Beszúrás
              </Button>
            </>
          ) : (
            <>
              <Button variant="ghost" onClick={() => setOpen(false)} disabled={busy}>Mégse</Button>
              <Button onClick={run} disabled={busy || prompt.trim().length < 3} className="gap-1">
                {busy ? <Loader2 className="size-4 animate-spin" /> : <Wand2 className="size-4" />}
                Előnézet generálása
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ─── AI teljes oldal-vázlat — előnézettel + jóváhagyással ────────────────
type AiDraftBlock = { block_type: string; content: any };

function AiPageDraftButton({
  pageId: _pageId, startPosition: _startPos, onApprove,
}: { pageId: string; startPosition: number; onApprove: (blocks: AiDraftBlock[]) => Promise<void> | void }) {
  const draftFn = useServerFn(generatePageDraft);
  const [open, setOpen] = useState(false);
  const [prompt, setPrompt] = useState("");
  const [maxBlocks, setMaxBlocks] = useState(6);
  const [busy, setBusy] = useState(false);
  const [preview, setPreview] = useState<AiDraftBlock[] | null>(null);
  const [previewJson, setPreviewJson] = useState<string>("");
  const [jsonErr, setJsonErr] = useState<string | null>(null);

  const allowedTypes = useMemo(
    () => BLOCK_CATALOG.filter((b) => !b.regions || b.regions.length === 0).map((b) => b.type),
    [],
  );

  const run = async () => {
    if (prompt.trim().length < 3) return;
    setBusy(true);
    try {
      const res: any = await draftFn({
        data: { prompt, locale: "hu", allowedTypes, maxBlocks },
      });
      const blks: AiDraftBlock[] = res?.blocks ?? [];
      setPreview(blks);
      setPreviewJson(JSON.stringify(blks, null, 2));
      setJsonErr(null);
    } catch (e: any) {
      toast.error("AI oldalvázlat hiba", { description: e?.message?.slice(0, 200) });
    } finally {
      setBusy(false);
    }
  };

  const approve = async () => {
    let parsed: AiDraftBlock[];
    try {
      parsed = JSON.parse(previewJson);
      if (!Array.isArray(parsed)) throw new Error("A JSON-nak tömbnek kell lennie");
    } catch (e: any) {
      setJsonErr(e?.message ?? "Érvénytelen JSON"); return;
    }
    setBusy(true);
    try {
      await onApprove(parsed);
      toast.success(`${parsed.length} blokk hozzáadva`);
      reset();
      setOpen(false);
    } catch (e: any) {
      toast.error("Beszúrás sikertelen", { description: e?.message?.slice(0, 200) });
    } finally {
      setBusy(false);
    }
  };

  const reset = () => { setPrompt(""); setPreview(null); setPreviewJson(""); setJsonErr(null); };

  return (
    <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) reset(); }}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="w-full gap-1">
          <Sparkles className="size-4" /> AI teljes oldal-vázlat
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Generálj egy komplett aloldalt</DialogTitle>
          <DialogDescription>
            {preview
              ? `${preview.length} blokk generálva. Nézd át, majd szúrd be az oldal végére.`
              : "Az AI több szekciót generál (hero → bemutatás → részletek → CTA)."}
          </DialogDescription>
        </DialogHeader>

        {!preview ? (
          <div className="space-y-3">
            <Textarea
              placeholder="Pl. Diabétesz centrum aloldal — bemutatkozás, szolgáltatások, csapat, GYIK, kapcsolat."
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              rows={4}
            />
            <div className="flex items-center gap-2 text-xs">
              <label className="text-muted-foreground">Max. blokk:</label>
              <Input
                type="number" min={2} max={12}
                value={maxBlocks}
                onChange={(e) => setMaxBlocks(Math.max(2, Math.min(12, Number(e.target.value) || 6)))}
                className="w-20 h-8"
              />
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            <div className="rounded-md border p-3 bg-muted/30 text-xs space-y-1 max-h-40 overflow-y-auto">
              <div className="font-medium mb-1">Blokk-lista:</div>
              <ol className="list-decimal list-inside space-y-0.5">
                {preview.map((b, i) => (
                  <li key={i}><Badge variant="secondary" className="text-[10px] uppercase mr-1">{b.block_type}</Badge></li>
                ))}
              </ol>
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium">Előnézet (szerkeszthető JSON)</label>
              <Textarea
                value={previewJson}
                onChange={(e) => { setPreviewJson(e.target.value); setJsonErr(null); }}
                rows={12}
                className="font-mono text-xs"
              />
              {jsonErr && <div className="text-xs text-destructive">{jsonErr}</div>}
            </div>
          </div>
        )}

        <DialogFooter className="gap-2 sm:gap-2">
          {preview ? (
            <>
              <Button variant="ghost" onClick={reset} disabled={busy}>Új prompt</Button>
              <Button onClick={approve} disabled={busy} className="gap-1">
                {busy ? <Loader2 className="size-4 animate-spin" /> : <Sparkles className="size-4" />}
                Beszúrás az oldal végére
              </Button>
            </>
          ) : (
            <>
              <Button variant="ghost" onClick={() => setOpen(false)} disabled={busy}>Mégse</Button>
              <Button onClick={run} disabled={busy || prompt.trim().length < 3} className="gap-1">
                {busy ? <Loader2 className="size-4 animate-spin" /> : <Sparkles className="size-4" />}
                Előnézet generálása
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// keep the unused symbol imported so tree-shaking doesn't drop for future use
void generateBlockContent;

/** Ejtési zóna a vászon alján — palettáról ide húzva a lap végére szúr be. */
function CanvasEndDropZone({ hasBlocks }: { hasBlocks: boolean }) {
  const { setNodeRef, isOver } = useDroppable({ id: "canvas-end" });
  return (
    <div
      ref={setNodeRef}
      className={`m-3 rounded-md border-2 border-dashed p-6 text-center text-sm transition ${
        isOver ? "border-primary bg-primary/5 text-primary" : "border-muted-foreground/25 text-muted-foreground"
      }`}
    >
      {hasBlocks
        ? "Húzz ide egy blokkot a paletta bal oldaláról — az oldal végére kerül."
        : "Nincs blokk ezen az oldalon. Kattints vagy húzz ide egyet a palettáról."}
    </div>
  );
}
