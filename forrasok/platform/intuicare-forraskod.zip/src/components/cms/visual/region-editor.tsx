/**
 * Global region editor (header / footer / top bar / main nav).
 *
 * Regions live in `cms_global_regions.blocks` as a JSON array, so the whole
 * array is edited locally and saved wholesale via saveGlobalRegion.
 * Supports reorder (drag handles via up/down), add from the region-aware
 * catalog, delete and per-block form editing.
 */
import { useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger,
} from "@/components/ui/dialog";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Trash2, Plus, Save, Loader2, PanelTop, GripVertical } from "lucide-react";
import { useDraggable } from "@dnd-kit/core";
import { EditorWorkbench, type WorkbenchItem } from "@/components/cms/visual/editor-workbench";
import { BLOCK_CATALOG } from "@/lib/cms/block-schema";
import { listGlobalRegions, saveGlobalRegion, type GlobalRegion } from "@/lib/cms/layout-blocks.functions";
import { BlockFormEditor } from "@/components/cms/visual/block-form-editor";

const REGIONS = [
  { key: "top_bar", label: "Felső sáv" },
  { key: "header", label: "Fejléc" },
  { key: "main_nav", label: "Fő navigáció" },
  { key: "footer", label: "Lábléc" },
];

type RegionBlock = GlobalRegion["blocks"][number];

export function RegionEditorDialog({ onSaved }: { onSaved?: () => void }) {
  const qc = useQueryClient();
  const listFn = useServerFn(listGlobalRegions);
  const saveFn = useServerFn(saveGlobalRegion);

  const [open, setOpen] = useState(false);
  const [regionKey, setRegionKey] = useState("header");
  const [draft, setDraft] = useState<RegionBlock[]>([]);
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const [openIdx, setOpenIdx] = useState<number | null>(0);

  const regionsQ = useQuery({
    queryKey: ["cms-global-regions", "hu"],
    queryFn: () => listFn({ data: { locale: "hu" } }),
    enabled: open,
  });

  const current = useMemo(
    () => (regionsQ.data ?? []).find((r: any) => r.region_key === regionKey) ?? null,
    [regionsQ.data, regionKey],
  );

  useEffect(() => {
    setDraft(Array.isArray(current?.blocks) ? (current!.blocks as RegionBlock[]) : []);
    setDirty(false);
    setOpenIdx(0);
  }, [current, regionKey]);

  const addable = BLOCK_CATALOG.filter((b) => b.regions?.includes(regionKey));

  const mutate = (next: RegionBlock[]) => { setDraft(next); setDirty(true); };

  const save = async () => {
    setSaving(true);
    try {
      await saveFn({ data: { region_key: regionKey, locale: "hu", blocks: draft } });
      toast.success("Régió mentve", { description: REGIONS.find((r) => r.key === regionKey)?.label });
      setDirty(false);
      qc.invalidateQueries({ queryKey: ["cms-global-regions"] });
      onSaved?.();
    } catch (e: any) {
      toast.error("A régió mentése sikertelen", { description: e?.message?.slice(0, 200) });
    } finally {
      setSaving(false);
    }
  };

  const items = draft.map((b, i) => ({
    id: `rb-${i}`,
    type: b.type,
    subtitle: String((b.content as any)?.title ?? (b.content as any)?.label ?? "—"),
  }));
  const selectedIdx = openIdx;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="w-full gap-1">
          <PanelTop className="size-4" />Fejléc / lábléc szerkesztése
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-[98vw] w-[98vw] h-[92vh] p-0 overflow-hidden flex flex-col">
        <DialogHeader className="px-4 pt-4">
          <DialogTitle>Globális régiók</DialogTitle>
          <DialogDescription>
            Ezek a blokkok minden oldalon megjelennek. A mentés azonnal publikál.
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 min-h-0">
          <EditorWorkbench
            toolbar={
              <div className="flex flex-wrap items-center gap-2">
                <Tabs value={regionKey} onValueChange={(v) => setRegionKey(v)}>
                  <TabsList className="flex flex-wrap h-auto">
                    {REGIONS.map((r) => (
                      <TabsTrigger key={r.key} value={r.key} className="text-xs">{r.label}</TabsTrigger>
                    ))}
                  </TabsList>
                </Tabs>
                {dirty && <span className="text-xs text-amber-600">Nem mentett módosítás</span>}
                <Button size="sm" onClick={save} disabled={!dirty || saving} className="gap-1">
                  {saving ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}Mentés
                </Button>
              </div>
            }
            palette={
              <div className="p-3 space-y-1">
                <div className="text-xs font-semibold uppercase text-muted-foreground">Blokk hozzáadása</div>
                {addable.length === 0 && (
                  <div className="text-xs text-muted-foreground">Ehhez a régióhoz nincs elérhető blokktípus.</div>
                )}
                {addable.map((b) => (
                  <RegionPaletteItem
                    key={b.type}
                    type={b.type}
                    label={b.label}
                    description={b.description}
                    defaults={(b.defaults ?? {}) as Record<string, unknown>}
                    onInsert={() => {
                      mutate([...draft, { type: b.type, content: { ...(b.defaults ?? {}) } as any, style: {} }]);
                      setOpenIdx(draft.length);
                    }}
                  />
                ))}
              </div>
            }
            items={items}
            loading={regionsQ.isLoading}
            selectedId={selectedIdx !== null && items[selectedIdx] ? items[selectedIdx].id : null}
            onSelect={(id: string | null) => setOpenIdx(id ? items.findIndex((i) => i.id === id) : null)}
            onReorder={(ids: string[]) => {
              const next = ids.map((id: string) => draft[Number(id.replace("rb-", ""))]).filter(Boolean);
              mutate(next);
              setOpenIdx(null);
            }}
            onInsertAt={({ type, defaults, index }: { type: string; defaults: Record<string, unknown>; index: number }) => {
              const next = [...draft];
              next.splice(index, 0, { type, content: { ...defaults } as any, style: {} } as RegionBlock);
              mutate(next);
              setOpenIdx(index);
            }}
            renderItem={(item: WorkbenchItem, i: number) => (
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="text-[10px]">{item.type}</Badge>
                <span className="flex-1 text-[11px] text-muted-foreground truncate">{item.subtitle}</span>
                <span
                  role="button"
                  tabIndex={0}
                  aria-label="Törlés"
                  className="p-1 text-destructive"
                  onClick={(e) => { e.stopPropagation(); mutate(draft.filter((_, k) => k !== i)); setOpenIdx(null); }}
                  onKeyDown={(e) => { if (e.key === "Enter") { e.stopPropagation(); mutate(draft.filter((_, k) => k !== i)); } }}
                >
                  <Trash2 className="size-3.5" />
                </span>
              </div>
            )}
            inspector={
              selectedIdx !== null && draft[selectedIdx] ? (
                <div className="p-3">
                  <BlockFormEditor
                    blockType={draft[selectedIdx].type}
                    content={(draft[selectedIdx].content ?? {}) as Record<string, unknown>}
                    onChange={(next) =>
                      mutate(draft.map((x, k) => (k === selectedIdx ? { ...x, content: next as any } : x)))
                    }
                  />
                </div>
              ) : (
                <div className="p-6 text-xs text-muted-foreground text-center">
                  Válassz egy blokkot, vagy húzz be újat a palettáról.
                </div>
              )
            }
            previewUrl="/"
            previewNonce={draft.length}
          />
        </div>
      </DialogContent>
    </Dialog>
  );
}

function RegionPaletteItem({
  type, label, description, defaults, onInsert,
}: { type: string; label: string; description?: string; defaults: Record<string, unknown>; onInsert: () => void }) {
  const { attributes, listeners, setNodeRef, isDragging } = useDraggable({
    id: `palette:${type}`,
    data: { palette: true, type, defaults },
  });
  return (
    <div ref={setNodeRef} className={`flex items-start gap-1 rounded border p-2 hover:bg-accent transition ${isDragging ? "opacity-50" : ""}`}>
      <button type="button" className="cursor-grab active:cursor-grabbing text-muted-foreground touch-none mt-0.5"
        aria-label={`${label} húzása`} {...attributes} {...listeners}>
        <GripVertical className="size-3.5" />
      </button>
      <button type="button" className="flex-1 text-left" onClick={onInsert}>
        <div className="text-sm font-medium flex items-center gap-2">
          <Plus className="size-3.5 text-muted-foreground" />{label}
        </div>
        {description && <div className="text-[11px] text-muted-foreground">{description}</div>}
      </button>
    </div>
  );
}

