/**
 * Right-panel inspector for the live CMS editor.
 *
 * - Autosaves the JSON draft (debounced 1.5s) into `draft_content` via
 *   saveBlockDraft, so a crash or accidental close does not lose work.
 * - Mirrors every keystroke to localStorage — on reopening the same block,
 *   we offer to restore the local copy if it is newer than the server draft.
 * - "Vázlat mentése" gomb marad: azonnali kézi mentés + jóváhagyói jegyzet.
 */
import { useEffect, useMemo, useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Loader2, Send, Undo2, Trash2, CheckCircle2, AlertCircle, Cloud, Wand2, Braces } from "lucide-react";
import { toast } from "sonner";
import { saveBlockDraft, discardBlockDraft } from "@/lib/cms/block-drafts.functions";
import { deleteLayoutBlock } from "@/lib/cms/layout-blocks.functions";
import { BLOCK_CATALOG } from "@/lib/cms/block-schema";
import { useAutosaveDraft } from "@/hooks/use-autosave-draft";
import { BlockFormEditor } from "./block-form-editor";

export type InspectorBlock = {
  id: string;
  block_type: string;
  content: any;
  draft_content: any;
  draft_status?: "none" | "pending" | "approved" | "rejected" | null;
  draft_note?: string | null;
};

export function BlockInspector({
  block,
  onChanged,
  onDeleted,
}: {
  block: InspectorBlock | null;
  onChanged: () => void;
  onDeleted: () => void;
}) {
  const saveFn = useServerFn(saveBlockDraft);
  const discardFn = useServerFn(discardBlockDraft);
  const delFn = useServerFn(deleteLayoutBlock);

  const initial = block?.draft_content ?? block?.content ?? {};
  const [text, setText] = useState(() => JSON.stringify(initial, null, 2));
  const [note, setNote] = useState(block?.draft_note ?? "");
  const [err, setErr] = useState<string | null>(null);
  const [restorePrompt, setRestorePrompt] = useState<{ value: string; savedAt: number } | null>(null);

  const storageKey = useMemo(
    () => (block ? `cms-block-draft:${block.id}` : "cms-block-draft:none"),
    [block?.id],
  );

  // Reset editor when a different block is selected + check localStorage
  useEffect(() => {
    const serverText = JSON.stringify(block?.draft_content ?? block?.content ?? {}, null, 2);
    setText(serverText);
    setNote(block?.draft_note ?? "");
    setErr(null);
    setRestorePrompt(null);

    if (!block) return;
    try {
      const raw = localStorage.getItem(`cms-block-draft:${block.id}`);
      if (!raw) return;
      const parsed = JSON.parse(raw);
      if (typeof parsed?.v === "string" && parsed.v !== serverText) {
        setRestorePrompt({ value: parsed.v, savedAt: parsed.t ?? 0 });
      }
    } catch { /* noop */ }
  }, [block?.id]);

  const autosave = useAutosaveDraft({
    storageKey,
    value: text,
    enabled: !!block,
    parse: (raw) => JSON.parse(raw),
    save: async (parsed) => {
      if (!block) return;
      await saveFn({ data: { blockId: block.id, content: parsed, note: note || null } });
      onChanged();
    },
  });

  const save = useMutation({
    mutationFn: async () => {
      if (!block) return;
      let parsed: any;
      try { parsed = JSON.parse(text); } catch (e: any) {
        setErr(e.message ?? "Hibás JSON"); throw e;
      }
      setErr(null);
      await saveFn({ data: { blockId: block.id, content: parsed, note: note || null } });
    },
    onSuccess: () => {
      toast.success("Vázlat mentve – vár jóváhagyásra");
      autosave.clearLocalDraft();
      onChanged();
    },
    onError: (e: any) => toast.error(e.message ?? "Mentés sikertelen"),
  });

  const discard = useMutation({
    mutationFn: async () => { if (block) await discardFn({ data: { blockId: block.id } }); },
    onSuccess: () => {
      toast.success("Vázlat elvetve");
      autosave.clearLocalDraft();
      onChanged();
    },
  });

  const remove = useMutation({
    mutationFn: async () => { if (block) await delFn({ data: { id: block.id } }); },
    onSuccess: () => {
      toast.success("Blokk törölve");
      autosave.clearLocalDraft();
      onDeleted();
    },
  });

  if (!block) {
    return (
      <div className="p-4 text-sm text-muted-foreground">
        Válassz egy blokkot a lapon a szerkesztéshez. Hover-kor megjelennek a sorrend és törlés gombok; kattintásra itt jelenik meg a tartalomszerkesztő.
      </div>
    );
  }

  const meta = BLOCK_CATALOG.find((b) => b.type === block.block_type);
  const pending = block.draft_status === "pending";

  return (
    <div className="p-3 space-y-3">
      <div>
        <div className="text-xs uppercase text-muted-foreground">Kiválasztott blokk</div>
        <div className="font-semibold">{meta?.label ?? block.block_type}</div>
        <div className="text-[11px] text-muted-foreground">{block.block_type}</div>
      </div>
      {pending && (
        <div className="text-xs flex items-center gap-2">
          <Badge className="bg-amber-500 text-white">függő vázlat</Badge>
          <span className="text-muted-foreground">jóváhagyásra vár</span>
        </div>
      )}

      {restorePrompt && (
        <div className="rounded-md border border-amber-400/50 bg-amber-50 dark:bg-amber-950/30 p-2 text-xs space-y-2">
          <div className="font-medium">Helyileg mentett, el nem küldött vázlat található.</div>
          <div className="text-muted-foreground">
            {new Date(restorePrompt.savedAt).toLocaleString("hu-HU")} — vissza szeretnéd állítani?
          </div>
          <div className="flex gap-2">
            <Button
              size="sm" variant="outline"
              onClick={() => { setText(restorePrompt.value); setRestorePrompt(null); }}
            >Visszaállítás</Button>
            <Button
              size="sm" variant="ghost"
              onClick={() => { autosave.clearLocalDraft(); setRestorePrompt(null); }}
            >Elvetés</Button>
          </div>
        </div>
      )}

      <div className="space-y-1">
        <div className="flex items-center justify-between">
          <label className="text-xs font-medium">Tartalom (vázlat)</label>
          <AutosaveStatus status={autosave.status} errorMsg={autosave.errorMsg} lastSavedAt={autosave.lastSavedAt} />
        </div>
        <Tabs defaultValue="form" className="w-full">
          <TabsList className="h-8">
            <TabsTrigger value="form" className="gap-1 text-xs h-6"><Wand2 className="size-3" />WYSIWYG</TabsTrigger>
            <TabsTrigger value="json" className="gap-1 text-xs h-6"><Braces className="size-3" />JSON</TabsTrigger>
          </TabsList>
          <TabsContent value="form" className="mt-2">
            <FormPane text={text} setText={setText} setErr={setErr} blockType={block.block_type} />
          </TabsContent>
          <TabsContent value="json" className="mt-2">
            <Textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              rows={16}
              className="font-mono text-xs"
            />
          </TabsContent>
        </Tabs>
        {err && <div className="text-xs text-destructive">{err}</div>}
        <p className="text-[11px] text-muted-foreground">
          Az autosave 1,5 mp után automatikusan menti a vázlatot. A publikus oldalon csak jóváhagyás után jelenik meg.
        </p>
      </div>

      <div className="space-y-1">
        <label className="text-xs font-medium">Megjegyzés a jóváhagyónak (opcionális)</label>
        <Input value={note} onChange={(e) => setNote(e.target.value)} placeholder="Pl. új cím a kampányhoz" />
      </div>

      <div className="flex flex-wrap gap-2">
        <Button onClick={() => save.mutate()} disabled={save.isPending} className="gap-1">
          {save.isPending ? <Loader2 className="size-4 animate-spin" /> : <Send className="size-4" />}
          Vázlat mentése most
        </Button>
        {pending && (
          <Button variant="outline" onClick={() => discard.mutate()} disabled={discard.isPending} className="gap-1">
            <Undo2 className="size-4" />Vázlat elvetése
          </Button>
        )}
        <Button variant="destructive" onClick={() => remove.mutate()} disabled={remove.isPending} className="gap-1 ml-auto">
          <Trash2 className="size-4" />Blokk törlése
        </Button>
      </div>
    </div>
  );
}

function AutosaveStatus({
  status, errorMsg, lastSavedAt,
}: { status: "idle" | "dirty" | "saving" | "saved" | "error"; errorMsg: string | null; lastSavedAt: number | null }) {
  if (status === "saving") return <span className="text-[11px] flex items-center gap-1 text-muted-foreground"><Loader2 className="size-3 animate-spin" />mentés…</span>;
  if (status === "saved") return <span className="text-[11px] flex items-center gap-1 text-emerald-600"><CheckCircle2 className="size-3" />mentve {lastSavedAt ? new Date(lastSavedAt).toLocaleTimeString("hu-HU") : ""}</span>;
  if (status === "dirty") return <span className="text-[11px] flex items-center gap-1 text-muted-foreground"><Cloud className="size-3" />vár mentésre…</span>;
  if (status === "error") return <span className="text-[11px] flex items-center gap-1 text-destructive" title={errorMsg ?? ""}><AlertCircle className="size-3" />mentés hiba</span>;
  return null;
}

/**
 * Bridges the JSON-text state used by autosave with the object-based
 * BlockFormEditor. Parses on mount, re-serializes on every change.
 */
function FormPane({
  text,
  setText,
  setErr,
  blockType,
}: {
  text: string;
  setText: (v: string) => void;
  setErr: (e: string | null) => void;
  blockType?: string;
}) {
  let parsed: Record<string, unknown> = {};
  let parseError: string | null = null;
  try { parsed = JSON.parse(text || "{}"); if (parsed == null || typeof parsed !== "object" || Array.isArray(parsed)) { parsed = {}; parseError = "A tartalomnak objektumnak kell lennie."; } }
  catch (e: any) { parseError = e?.message ?? "Hibás JSON"; }

  if (parseError) {
    return (
      <div className="text-xs border rounded-md p-3 bg-muted/40 space-y-2">
        <div className="text-destructive">A vázlat JSON-je jelenleg érvénytelen, a WYSIWYG nem tudja megjeleníteni:</div>
        <div className="font-mono">{parseError}</div>
        <div className="text-muted-foreground">Javítsd a JSON nézetben, aztán térj vissza ide.</div>
      </div>
    );
  }

  return (
    <BlockFormEditor
      content={parsed}
      blockType={blockType}
      onChange={(next) => { setErr(null); setText(JSON.stringify(next, null, 2)); }}
    />
  );
}
