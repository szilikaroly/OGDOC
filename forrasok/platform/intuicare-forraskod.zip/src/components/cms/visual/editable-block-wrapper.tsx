/**
 * Editable wrapper around a single block — hover outline, action toolbar,
 * pending-draft badge, click-to-select for the right-panel inspector.
 * When `inlineEdit` is on, the rendered text of the block becomes directly
 * editable in place (see use-inline-edit).
 */
import { useRef } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ChevronUp, ChevronDown, Trash2, Copy, Pencil } from "lucide-react";
import { cn } from "@/lib/utils";
import { useInlineEdit } from "@/components/cms/visual/use-inline-edit";

export type BlockSummary = {
  id: string;
  block_type: string;
  position: number;
  draft_status?: "none" | "pending" | "approved" | "rejected" | null;
};

export function EditableBlockWrapper({
  block,
  selected,
  onSelect,
  onMoveUp,
  onMoveDown,
  onDuplicate,
  onDelete,
  inlineEdit = false,
  content,
  onInlineCommit,
  children,
}: {
  block: BlockSummary;
  selected: boolean;
  onSelect: () => void;
  onMoveUp?: () => void;
  onMoveDown?: () => void;
  onDuplicate?: () => void;
  onDelete?: () => void;
  inlineEdit?: boolean;
  content?: Record<string, any> | null;
  onInlineCommit?: (path: (string | number)[], value: string) => void;
  children: React.ReactNode;
}) {
  const pending = block.draft_status === "pending";
  const bodyRef = useRef<HTMLDivElement | null>(null);
  useInlineEdit({
    enabled: inlineEdit && !!onInlineCommit,
    content,
    containerRef: bodyRef,
    onCommit: (path, value) => onInlineCommit?.(path, value),
  });

  return (
    <div
      role="button"
      tabIndex={0}
      onClick={(e) => {
        e.stopPropagation();
        onSelect();
      }}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          onSelect();
        }
      }}
      className={cn(
        "group relative outline outline-1 outline-transparent transition-all cursor-pointer",
        "hover:outline-primary/40",
        selected && "outline-2 outline-primary",
        pending && "outline-amber-400",
      )}
      data-block-id={block.id}
    >
      {/* Top-left label */}
      <div
        className={cn(
          "pointer-events-none absolute -top-3 left-2 z-20 flex items-center gap-1 opacity-0 transition-opacity",
          "group-hover:opacity-100",
          selected && "opacity-100",
        )}
      >
        <Badge variant="secondary" className="text-[10px] shadow-sm">
          {block.block_type}
        </Badge>
        {pending && (
          <Badge className="text-[10px] bg-amber-500 text-white shadow-sm">függő módosítás</Badge>
        )}
      </div>

      {/* Top-right toolbar */}
      <div
        className={cn(
          "absolute -top-3 right-2 z-20 flex items-center gap-1 opacity-0 transition-opacity",
          "group-hover:opacity-100",
          selected && "opacity-100",
        )}
        onClick={(e) => e.stopPropagation()}
      >
        <Button size="icon" variant="secondary" className="size-7 shadow-sm" onClick={onSelect} aria-label="Szerkesztés">
          <Pencil className="size-3.5" />
        </Button>
        {onMoveUp && (
          <Button size="icon" variant="secondary" className="size-7 shadow-sm" onClick={onMoveUp} aria-label="Fel">
            <ChevronUp className="size-3.5" />
          </Button>
        )}
        {onMoveDown && (
          <Button size="icon" variant="secondary" className="size-7 shadow-sm" onClick={onMoveDown} aria-label="Le">
            <ChevronDown className="size-3.5" />
          </Button>
        )}
        {onDuplicate && (
          <Button size="icon" variant="secondary" className="size-7 shadow-sm" onClick={onDuplicate} aria-label="Duplikálás">
            <Copy className="size-3.5" />
          </Button>
        )}
        {onDelete && (
          <Button size="icon" variant="destructive" className="size-7 shadow-sm" onClick={onDelete} aria-label="Törlés">
            <Trash2 className="size-3.5" />
          </Button>
        )}
      </div>

      <div ref={bodyRef} className={cn(pending && "ring-1 ring-amber-300/40")}>{children}</div>
    </div>
  );
}
