/**
 * Version history dialog for the CMS Live Editor.
 * - Lists persisted page snapshots (cms_page_versions).
 * - Lets the editor create a new "draft" snapshot on demand.
 * - Lets the editor roll back the page to any previous snapshot.
 */
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { History, Loader2, Save, RotateCcw, CheckCircle2 } from "lucide-react";

import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

import {
  listPageVersions,
  snapshotPageVersion,
  rollbackPageVersion,
} from "@/lib/cms/cms.functions";

type Props = {
  pageId: string | null;
  onRestored?: () => void;
};

function fmtDate(iso: string) {
  try {
    return new Date(iso).toLocaleString("hu-HU", {
      year: "numeric", month: "2-digit", day: "2-digit",
      hour: "2-digit", minute: "2-digit",
    });
  } catch { return iso; }
}

export function VersionHistoryDialog({ pageId, onRestored }: Props) {
  const [open, setOpen] = useState(false);
  const qc = useQueryClient();

  const listFn = useServerFn(listPageVersions);
  const snapFn = useServerFn(snapshotPageVersion);
  const rollbackFn = useServerFn(rollbackPageVersion);

  const q = useQuery({
    queryKey: ["cms-page-versions", pageId],
    queryFn: () => listFn({ data: { pageId: pageId! } }),
    enabled: !!pageId && open,
  });

  const snap = useMutation({
    mutationFn: () => snapFn({ data: { pageId: pageId! } }),
    onSuccess: (r) => {
      toast.success(`Vázlat mentve — v${r.version}`);
      qc.invalidateQueries({ queryKey: ["cms-page-versions", pageId] });
    },
    onError: (e: any) => toast.error(e?.message ?? "Mentés sikertelen"),
  });

  const rollback = useMutation({
    mutationFn: (versionId: string) =>
      rollbackFn({ data: { pageId: pageId!, versionId } }),
    onSuccess: (r) => {
      toast.success(`Visszaállítva — v${r.restoredFromVersion} → új v${r.newVersion}`);
      qc.invalidateQueries({ queryKey: ["cms-page-versions", pageId] });
      onRestored?.();
    },
    onError: (e: any) => toast.error(e?.message ?? "Visszaállítás sikertelen"),
  });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-1" disabled={!pageId} title="Verziótörténet">
          <History className="size-4" />Verziók
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <History className="size-4" />Verziótörténet
          </DialogTitle>
        </DialogHeader>

        <div className="flex items-center justify-between gap-2">
          <p className="text-sm text-muted-foreground">
            Mentsd el az aktuális állapotot vázlatként, vagy állíts vissza egy korábbi verziót.
          </p>
          <Button
            size="sm"
            onClick={() => snap.mutate()}
            disabled={!pageId || snap.isPending}
            className="gap-1"
          >
            {snap.isPending ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
            Vázlat mentése
          </Button>
        </div>

        <ScrollArea className="h-[420px] rounded-md border">
          {q.isLoading ? (
            <div className="flex items-center justify-center py-8 text-sm text-muted-foreground">
              <Loader2 className="mr-2 size-4 animate-spin" />Verziók betöltése…
            </div>
          ) : q.isError ? (
            <div className="p-4 text-sm text-destructive">
              Hiba: {(q.error as any)?.message ?? "ismeretlen"}
            </div>
          ) : !q.data?.length ? (
            <div className="p-6 text-center text-sm text-muted-foreground">
              Még nincs mentett verzió. A publikálás automatikusan snapshotot készít, illetve a „Vázlat mentése” gombbal manuálisan is menthetsz.
            </div>
          ) : (
            <ul className="divide-y">
              {q.data.map((v: any) => (
                <li key={v.id} className="flex items-center justify-between gap-3 p-3">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-medium">v{v.version}</span>
                      {v.is_published ? (
                        <Badge className="bg-emerald-500 text-white gap-1">
                          <CheckCircle2 className="size-3" />publikált
                        </Badge>
                      ) : (
                        <Badge variant="outline">vázlat</Badge>
                      )}
                    </div>
                    <div className="text-xs text-muted-foreground truncate">
                      {fmtDate(v.created_at)}
                    </div>
                  </div>

                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button
                        variant="outline"
                        size="sm"
                        className="gap-1"
                        disabled={rollback.isPending}
                      >
                        <RotateCcw className="size-4" />Visszaállít
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Visszaállítás v{v.version} verzióra?</AlertDialogTitle>
                        <AlertDialogDescription>
                          Az oldal jelenlegi blokkjai lecserélődnek a mentett snapshotra. A művelet új verzióként rögzül, így később visszavonható.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Mégse</AlertDialogCancel>
                        <AlertDialogAction onClick={() => rollback.mutate(v.id)}>
                          Visszaállítás
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </li>
              ))}
            </ul>
          )}
        </ScrollArea>

        <DialogFooter>
          <Button variant="ghost" onClick={() => setOpen(false)}>Bezár</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
