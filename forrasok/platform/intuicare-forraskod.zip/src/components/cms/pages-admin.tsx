import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { listPages, savePage, deletePage, getPageWithBlocks, saveBlock, deleteBlock, publishPageSnapshot, aiTranslate, listPageVersions, rollbackPageVersion, getPagePreviewLink, publishPage, unpublishPage, schedulePagePublish } from "@/lib/cms/cms.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Plus, Trash2, Edit, ExternalLink, Languages, Sparkles, History, List, Network, Gauge, Eye, ImageIcon, Send, Undo2, CalendarClock } from "lucide-react";
import { toast } from "sonner";
import { TiptapEditor } from "./tiptap-editor";
import { TableSkeleton } from "@/components/ui/list-skeletons";
import { haptic } from "@/lib/query/optimistic";
import { PageTree } from "./page-tree";
import { SeoAuditDialog } from "./seo-audit-dialog";
import { PageViewsDialog } from "./page-views-dialog";
import { MediaPicker } from "./media-picker";
import { LiveSeoHealth } from "./live-seo-health";
import { lintPageSeo, toastSeoOnSave } from "@/lib/cms/seo-lint";

const LOCALES = [
  { code: "hu", label: "Magyar" },
  { code: "en", label: "Angol" },
  { code: "de", label: "Német" },
  { code: "zh", label: "Kínai" },
  { code: "fil", label: "Filipino" },
  { code: "sr", label: "Szerb" },
  { code: "ro", label: "Román" },
];

export function PagesAdmin() {
  const qc = useQueryClient();
  const listFn = useServerFn(listPages);
  const saveFn = useServerFn(savePage);
  const delFn = useServerFn(deletePage);
  const publishFn = useServerFn(publishPage);
  const unpublishFn = useServerFn(unpublishPage);
  const scheduleFn = useServerFn(schedulePagePublish);
  const { data: pages = [], isLoading } = useQuery({ queryKey: ["cms-pages"], queryFn: () => listFn() });
  const [editing, setEditing] = useState<any>(null);
  const [editingBlocks, setEditingBlocks] = useState<string | null>(null);
  const [filter, setFilter] = useState("hu");
  const [view, setView] = useState<"list" | "tree">("list");
  const [seoPageId, setSeoPageId] = useState<string | null>(null);
  const [viewsPageId, setViewsPageId] = useState<string | null>(null);
  const [schedulingPage, setSchedulingPage] = useState<any>(null);

  const newPage = () => setEditing({
    slug: "", locale: filter, title: "", description: "", status: "draft",
    sort_order: 0, show_in_sitemap: true, template: "default",
  });

  const handleSave = async (p: any) => {
    const seo = lintPageSeo(p);
    toastSeoOnSave(seo, toast);
    try {
      const res: any = await saveFn({ data: p });
      toast.success("Oldal mentve");
      if (res?.slugChanged) {
        toast.info("301 átirányítás létrehozva a régi URL-ről az újra.");
      }
      setEditing(null);
      qc.invalidateQueries({ queryKey: ["cms-pages"] });
    } catch (e: any) { toast.error(e.message); }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Biztosan törlöd?")) return;
    await delFn({ data: { id } });
    qc.invalidateQueries({ queryKey: ["cms-pages"] });
  };

  const handlePublish = async (id: string) => {
    try {
      await publishFn({ data: { pageId: id } });
      toast.success("Oldal publikálva");
      qc.invalidateQueries({ queryKey: ["cms-pages"] });
    } catch (e: any) { toast.error(e.message); }
  };

  const handleUnpublish = async (id: string) => {
    if (!confirm("Biztosan visszavonod (piszkozatra állítod)?")) return;
    try {
      await unpublishFn({ data: { pageId: id } });
      toast.success("Publikálás visszavonva");
      qc.invalidateQueries({ queryKey: ["cms-pages"] });
    } catch (e: any) { toast.error(e.message); }
  };


  const filtered = pages.filter((p: any) => p.locale === filter);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-[minmax(0,1fr)_auto] sm:flex items-center gap-2 sm:gap-3 mt-4">
        <Select value={filter} onValueChange={setFilter}>
          <SelectTrigger className="min-h-11 w-full sm:w-40"><SelectValue /></SelectTrigger>
          <SelectContent>{LOCALES.map(l => <SelectItem key={l.code} value={l.code}>{l.label}</SelectItem>)}</SelectContent>
        </Select>
        <div className="flex gap-1 sm:ml-auto">
          <Button variant={view === "list" ? "default" : "outline"} size="sm" className="min-h-11" onClick={() => setView("list")} aria-label="Lista nézet">
            <List className="h-4 w-4 sm:mr-1" /><span className="hidden sm:inline">Lista</span>
          </Button>
          <Button variant={view === "tree" ? "default" : "outline"} size="sm" className="min-h-11" onClick={() => setView("tree")} aria-label="Fa nézet">
            <Network className="h-4 w-4 sm:mr-1" /><span className="hidden sm:inline">Fa</span>
          </Button>
        </div>
        <Button onClick={() => { haptic(8); newPage(); }} className="min-h-11" aria-label="Új oldal">
          <Plus className="h-4 w-4 sm:mr-1" /><span className="hidden sm:inline">Új oldal</span>
        </Button>
      </div>

      {isLoading ? <TableSkeleton rows={5} cols={3} /> : view === "tree" ? (
        <PageTree pages={pages} locale={filter} onEdit={setEditing} />
      ) : (
        <div className="grid gap-2">
          {filtered.map((p: any) => (
            <Card key={p.id} className="p-3 sm:p-4">
              <div className="grid grid-cols-[minmax(0,1fr)_auto] sm:flex items-center gap-2 sm:gap-3">
                <div className="min-w-0">
                  <div className="font-medium truncate">{p.title}</div>
                  <div className="text-xs text-muted-foreground truncate">/{p.slug}</div>
                  <div className="flex flex-wrap gap-1 mt-1">
                    <span className={`text-[10px] uppercase font-semibold inline-block px-2 py-0.5 rounded-full ${
                      p.status === "published" ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400" :
                      p.status === "scheduled" ? "bg-amber-500/15 text-amber-700 dark:text-amber-400" :
                      p.status === "archived" ? "bg-muted text-muted-foreground" :
                      "bg-secondary text-secondary-foreground"
                    }`}>{p.status} · {p.locale}</span>
                    {p.status === "scheduled" && p.scheduled_publish_at && (
                      <span className="text-[10px] inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-700 dark:text-amber-400">
                        <CalendarClock className="h-3 w-3" />
                        {new Date(p.scheduled_publish_at).toLocaleString("hu-HU", { dateStyle: "short", timeStyle: "short" })}
                      </span>
                    )}
                    {typeof p.view_count === "number" && p.view_count > 0 && (
                      <span className="text-[10px] inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-primary/10 text-primary"><Eye className="h-3 w-3" />{p.view_count}</span>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-1 shrink-0 col-start-2 row-span-2 sm:row-span-1">
                  <Button size="sm" variant="ghost" className="min-h-11 min-w-11" onClick={() => setEditingBlocks(p.id)} aria-label="Tartalom"><Edit className="h-4 w-4" /><span className="hidden lg:inline ml-1">Tartalom</span></Button>
                  <Button size="sm" variant="ghost" className="min-h-11 hidden sm:inline-flex" onClick={() => setEditing(p)}>Beállítások</Button>
                  <Button size="sm" variant="ghost" className="min-h-11 min-w-11 sm:hidden" onClick={() => setEditing(p)} aria-label="Beállítások"><Languages className="h-4 w-4" /></Button>
                  {p.status !== "published" ? (
                    <Button size="sm" variant="ghost" className="min-h-11 min-w-11 text-emerald-600" onClick={() => { haptic(8); handlePublish(p.id); }} aria-label="Publikálás" title="Azonnali publikálás"><Send className="h-4 w-4" /></Button>
                  ) : (
                    <Button size="sm" variant="ghost" className="min-h-11 min-w-11" onClick={() => { haptic(8); handleUnpublish(p.id); }} aria-label="Visszavonás" title="Publikálás visszavonása"><Undo2 className="h-4 w-4" /></Button>
                  )}
                  <Button size="sm" variant="ghost" className="min-h-11 min-w-11" onClick={() => setSchedulingPage(p)} aria-label="Ütemezés" title="Publikálás ütemezése"><CalendarClock className="h-4 w-4" /></Button>
                  {p.status === "published" && (
                    <a href={`/o/${p.slug}`} target="_blank" rel="noreferrer">
                      <Button size="sm" variant="ghost" className="min-h-11 min-w-11" aria-label="Megnyitás új lapon"><ExternalLink className="h-4 w-4" /></Button>
                    </a>
                  )}
                  <Button size="sm" variant="ghost" className="min-h-11 min-w-11" onClick={() => setViewsPageId(p.id)} aria-label="Megtekintések" title="Megtekintések"><Eye className="h-4 w-4" /></Button>
                  <Button size="sm" variant="ghost" className="min-h-11 min-w-11" onClick={() => setSeoPageId(p.id)} aria-label="SEO ellenőrzés" title="SEO ellenőrzés"><Gauge className="h-4 w-4" /></Button>
                  <Button size="sm" variant="ghost" className="min-h-11 min-w-11" onClick={() => handleDelete(p.id)} aria-label="Törlés"><Trash2 className="h-4 w-4 text-destructive" /></Button>
                </div>

              </div>
            </Card>
          ))}
          {!filtered.length && <div className="text-sm text-muted-foreground p-4">Még nincs oldal ezen a nyelven.</div>}
        </div>
      )}

      {editing && <PageEditor page={editing} pages={pages} onSave={handleSave} onClose={() => setEditing(null)} />}
      {editingBlocks && <BlocksEditor pageId={editingBlocks} onClose={() => setEditingBlocks(null)} />}
      {seoPageId && <SeoAuditDialog pageId={seoPageId} open onOpenChange={(v) => !v && setSeoPageId(null)} />}
      {viewsPageId && <PageViewsDialog pageId={viewsPageId} open onOpenChange={(v) => !v && setViewsPageId(null)} />}
      {schedulingPage && (
        <ScheduleDialog
          page={schedulingPage}
          onClose={() => setSchedulingPage(null)}
          onSubmit={async (whenIso) => {
            try {
              await scheduleFn({ data: { pageId: schedulingPage.id, when: whenIso } });
              toast.success(whenIso ? "Ütemezett publikálás beállítva" : "Ütemezés visszavonva");
              setSchedulingPage(null);
              qc.invalidateQueries({ queryKey: ["cms-pages"] });
            } catch (e: any) { toast.error(e.message); }
          }}
        />
      )}
    </div>
  );
}

function PageEditor({ page, pages, onSave, onClose }: { page: any; pages: any[]; onSave: (p: any) => void; onClose: () => void }) {
  const [p, setP] = useState(page);
  const parentCandidates = pages.filter(o => o.locale === p.locale && o.id !== p.id);
  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader><DialogTitle>{p.id ? "Oldal szerkesztése" : "Új oldal"}</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div><Label>Cím</Label><Input className="min-h-11" value={p.title} onChange={e => setP({ ...p, title: e.target.value })} /></div>
            <div><Label>URL slug</Label><Input className="min-h-11" value={p.slug} onChange={e => setP({ ...p, slug: e.target.value })} placeholder="pl. bemutatkozas" inputMode="url" autoCapitalize="none" /></div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div><Label>Nyelv</Label>
              <Select value={p.locale} onValueChange={v => setP({ ...p, locale: v })}>
                <SelectTrigger className="min-h-11"><SelectValue /></SelectTrigger>
                <SelectContent>{LOCALES.map(l => <SelectItem key={l.code} value={l.code}>{l.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>Állapot</Label>
              <Select value={p.status} onValueChange={v => setP({ ...p, status: v })}>
                <SelectTrigger className="min-h-11"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="draft">Piszkozat</SelectItem>
                  <SelectItem value="scheduled">Ütemezett</SelectItem>
                  <SelectItem value="published">Közzétéve</SelectItem>
                  <SelectItem value="archived">Archivált</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div><Label>Sorrend</Label><Input className="min-h-11" type="number" inputMode="numeric" value={p.sort_order} onChange={e => setP({ ...p, sort_order: parseInt(e.target.value) || 0 })} /></div>
          </div>
          <div>
            <Label>Szülő oldal</Label>
            <Select value={p.parent_id ?? "__root"} onValueChange={v => setP({ ...p, parent_id: v === "__root" ? null : v })}>
              <SelectTrigger className="min-h-11"><SelectValue placeholder="— Gyökér —" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="__root">— Gyökér (nincs szülő) —</SelectItem>
                {parentCandidates.map(o => <SelectItem key={o.id} value={o.id}>{o.title}</SelectItem>)}
              </SelectContent>
            </Select>
            <p className="text-[11px] text-muted-foreground mt-1">Az oldal-fa szerkezetét határozza meg (breadcrumb, sitemap, navigáció).</p>
          </div>
          {p.status === "scheduled" && (
            <div>
              <Label>Ütemezett közzététel</Label>
              <Input
                type="datetime-local"
                className="min-h-11"
                value={p.scheduled_publish_at ? p.scheduled_publish_at.slice(0, 16) : ""}
                onChange={e => setP({ ...p, scheduled_publish_at: e.target.value ? new Date(e.target.value).toISOString() : null })}
              />
              <p className="text-xs text-muted-foreground mt-1">Az oldal automatikusan élesedik a megadott időpontban.</p>
            </div>
          )}
          <div><Label>Rövid leírás</Label><Textarea value={p.description ?? ""} onChange={e => setP({ ...p, description: e.target.value })} /></div>
          <div className="border-t pt-3">
            <Label className="text-sm font-semibold">SEO & közösségi megosztás</Label>
            <div className="space-y-3 mt-2">
              <div>
                <Input className="min-h-11" placeholder="SEO cím" maxLength={70} value={p.seo_title ?? ""} onChange={e => setP({ ...p, seo_title: e.target.value })} />
                <p className="text-xs text-muted-foreground mt-1">
                  {(p.seo_title ?? "").length}/60 — ha üres: „{p.title || "(cím)"}"
                </p>
              </div>
              <div>
                <Textarea placeholder="SEO leírás" maxLength={200} value={p.seo_description ?? ""} onChange={e => setP({ ...p, seo_description: e.target.value })} />
                <p className="text-xs text-muted-foreground mt-1">
                  {(p.seo_description ?? "").length}/160 — ha üres: az oldal rövid leírása.
                </p>
              </div>
              <div>
                <div className="flex gap-2">
                  <Input className="min-h-11" placeholder="OG kép URL (megosztási preview)" value={p.og_image_url ?? ""} onChange={e => setP({ ...p, og_image_url: e.target.value })} inputMode="url" autoCapitalize="none" />
                  <MediaPicker
                    trigger={<Button type="button" variant="outline" size="icon" className="min-h-11" title="Médiatárból"><ImageIcon className="h-4 w-4" /></Button>}
                    onSelect={(m) => setP({ ...p, og_image_url: m.url })}
                  />
                </div>
                <p className="text-xs text-muted-foreground mt-1">Ha üres: az alapértelmezett site OG kép jelenik meg megosztáskor.</p>
              </div>
              <div>
                <Label className="text-xs">Schema.org típus (JSON-LD)</Label>
                <Select
                  value={p.schema_type ?? "auto"}
                  onValueChange={(v) => setP({ ...p, schema_type: v })}
                >
                  <SelectTrigger className="min-h-11"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="auto">Automatikus (tartalom alapján)</SelectItem>
                    <SelectItem value="webpage">WebPage – általános oldal</SelectItem>
                    <SelectItem value="article">Article – cikk / hír / blog</SelectItem>
                    <SelectItem value="faqpage">FAQPage – GYIK oldal</SelectItem>
                    <SelectItem value="contactpage">ContactPage – kapcsolat</SelectItem>
                    <SelectItem value="aboutpage">AboutPage – rólunk</SelectItem>
                    <SelectItem value="service">Service – szolgáltatás</SelectItem>
                    <SelectItem value="organization">Organization – szervezet</SelectItem>
                    <SelectItem value="localbusiness">LocalBusiness / MedicalOrganization</SelectItem>
                    <SelectItem value="collectionpage">CollectionPage – gyűjtemény/lista</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground mt-1">
                  Ez határozza meg a strukturált adat fő típusát. „Automatikus" a slug és a blokkok alapján dönt (pl. FAQ blokk → FAQPage).
                </p>
              </div>
            </div>
          </div>
          <LiveSeoHealth page={p} />
          <div className="flex items-center gap-2">
            <Switch checked={p.show_in_sitemap} onCheckedChange={v => setP({ ...p, show_in_sitemap: v })} />
            <Label>Megjelenjen a sitemap-ben</Label>
          </div>
          <div className="flex items-center gap-2">
            <Switch checked={!!p.noindex} onCheckedChange={v => setP({ ...p, noindex: v })} />
            <Label>Keresőmotorok ne indexeljék (noindex)</Label>
          </div>
          {p.id && <PreviewLinkRow pageId={p.id} />}
        </div>
        <DialogFooter className="flex-col-reverse sm:flex-row gap-2">
          <Button variant="ghost" onClick={onClose} className="min-h-11 w-full sm:w-auto">Mégse</Button>
          <Button onClick={() => { haptic(8); onSave(p); }} className="min-h-11 w-full sm:w-auto">Mentés</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function BlocksEditor({ pageId, onClose }: { pageId: string; onClose: () => void }) {
  const qc = useQueryClient();
  const getFn = useServerFn(getPageWithBlocks);
  const saveBlockFn = useServerFn(saveBlock);
  const delBlockFn = useServerFn(deleteBlock);
  const publishFn = useServerFn(publishPageSnapshot);
  const translateFn = useServerFn(aiTranslate);
  const { data, isLoading } = useQuery({ queryKey: ["cms-page-blocks", pageId], queryFn: () => getFn({ data: { id: pageId } }) });

  const addBlock = async (type: string) => {
    const pos = (data?.blocks?.length ?? 0);
    const def: any =
      type === "richtext" ? { html: "<p>Új szöveg...</p>" } :
      type === "heading" ? { text: "Új címsor" } :
      type === "image" ? { src: "", alt: "" } :
      type === "youtube" ? { src: "", title: "" } :
      type === "callout" ? { title: "", text: "" } :
      type === "doctor_card" ? { slug: "", locale: "hu" } :
      type === "doctor_schedule" ? { doctor_id: "", specialty_id: "", org_unit_id: "", days: 14, title: "" } :
      type === "booking_widget" ? { specialty_id: "", doctor_id: "", org_unit_id: "", cta_label: "Foglalás indítása" } :
      type === "contact_form" ? { org_unit_id: "", title: "Kapcsolatfelvétel" } :
      type === "department_info" ? { unit_id: "" } :
      type === "faq" ? { tag: "", limit: 10, locale: "hu" } :
      type === "related_posts" ? { slugs: [] } :
      type === "staff_list" ? { specialty: "", locale: "hu" } :
      {};
    await saveBlockFn({ data: { page_id: pageId, block_type: type, position: pos, locale: "hu", content: def, variant: "default", is_published: true } });
    qc.invalidateQueries({ queryKey: ["cms-page-blocks", pageId] });
  };

  const updateBlock = async (b: any, content: any) => {
    await saveBlockFn({ data: { id: b.id, page_id: pageId, block_type: b.block_type, position: b.position, locale: b.locale, content, variant: b.variant, is_published: b.is_published } });
    qc.invalidateQueries({ queryKey: ["cms-page-blocks", pageId] });
  };

  const removeBlock = async (id: string) => {
    if (!confirm("Blokk törlése?")) return;
    await delBlockFn({ data: { id } });
    qc.invalidateQueries({ queryKey: ["cms-page-blocks", pageId] });
  };

  const publish = async () => {
    await publishFn({ data: { pageId } });
    toast.success("Oldal közzétéve");
    qc.invalidateQueries({ queryKey: ["cms-pages"] });
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-5xl max-h-[95vh] overflow-y-auto p-4 sm:p-6">
        <DialogHeader>
          <DialogTitle className="text-base sm:text-lg">Tartalom: {data?.page?.title}</DialogTitle>
        </DialogHeader>
        {isLoading ? <TableSkeleton rows={4} cols={2} /> : (
          <div className="space-y-4">
            {/* Mobil: vízszintesen scrollozható blokk-hozzáadó sáv */}
            <div className="-mx-4 sm:mx-0 overflow-x-auto">
              <div className="flex gap-2 p-2 bg-muted/30 sm:rounded mx-4 sm:mx-0 w-max sm:w-auto sm:flex-wrap">
                <Button size="sm" variant="outline" className="min-h-11 shrink-0" onClick={() => addBlock("richtext")}>+ Szöveg</Button>
                <Button size="sm" variant="outline" className="min-h-11 shrink-0" onClick={() => addBlock("heading")}>+ Címsor</Button>
                <Button size="sm" variant="outline" className="min-h-11 shrink-0" onClick={() => addBlock("image")}>+ Kép</Button>
                <Button size="sm" variant="outline" className="min-h-11 shrink-0" onClick={() => addBlock("youtube")}>+ Videó</Button>
                <Button size="sm" variant="outline" className="min-h-11 shrink-0" onClick={() => addBlock("callout")}>+ Kiemelt</Button>
              </div>
            </div>
            {/* Dinamikus / hídak a meglévő modulokhoz */}
            <div className="-mx-4 sm:mx-0 overflow-x-auto">
              <div className="flex gap-2 p-2 bg-primary/5 border border-primary/20 sm:rounded mx-4 sm:mx-0 w-max sm:w-auto sm:flex-wrap">
                <span className="text-xs font-semibold text-primary self-center px-2 hidden sm:inline">Dinamikus:</span>
                <Button size="sm" variant="outline" className="min-h-11 shrink-0" onClick={() => addBlock("doctor_card")}>+ Orvos kártya</Button>
                <Button size="sm" variant="outline" className="min-h-11 shrink-0" onClick={() => addBlock("doctor_schedule")}>+ Rendelési idő</Button>
                <Button size="sm" variant="outline" className="min-h-11 shrink-0" onClick={() => addBlock("booking_widget")}>+ Foglalás CTA</Button>
                <Button size="sm" variant="outline" className="min-h-11 shrink-0" onClick={() => addBlock("contact_form")}>+ Kapcsolat űrlap</Button>
                <Button size="sm" variant="outline" className="min-h-11 shrink-0" onClick={() => addBlock("department_info")}>+ Osztály info</Button>
                <Button size="sm" variant="outline" className="min-h-11 shrink-0" onClick={() => addBlock("faq")}>+ GYIK</Button>
                <Button size="sm" variant="outline" className="min-h-11 shrink-0" onClick={() => addBlock("staff_list")}>+ Munkatársak</Button>
                <Button size="sm" variant="outline" className="min-h-11 shrink-0" onClick={() => addBlock("related_posts")}>+ Kapcsolódó</Button>
              </div>
            </div>
            {(data?.blocks ?? []).map((b: any) => (
              <Card key={b.id} className="p-3 sm:p-4">
                <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-2 mb-2">
                  <div className="text-sm font-medium truncate">{b.block_type} <span className="text-xs text-muted-foreground">#{b.position}</span></div>
                  <div className="flex gap-1 shrink-0">
                    {b.block_type === "richtext" && (
                      <Button size="sm" variant="ghost" className="min-h-11 min-w-11" aria-label="Fordítás AI-val" title="Fordítás AI-val"
                        onClick={async () => {
                          const target = prompt("Cél nyelvkód (en, de, zh, fil, sr, ro):", "en");
                          if (!target) return;
                          const r = await translateFn({ data: { text: String(b.content?.html ?? ""), source_locale: b.locale, target_locale: target } });
                          toast.success(`Fordítás kész (${target}). Vágólapra másolva.`);
                          navigator.clipboard.writeText(r.text);
                        }}><Sparkles className="h-4 w-4" /></Button>
                    )}
                    <Button size="sm" variant="ghost" className="min-h-11 min-w-11" aria-label="Blokk törlése" onClick={() => removeBlock(b.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                  </div>
                </div>
                <BlockEditor block={b} onChange={(c) => updateBlock(b, c)} />
              </Card>
            ))}
          </div>
        )}
        <DialogFooter className="flex-col-reverse sm:flex-row gap-2">
          <Button variant="ghost" onClick={onClose} className="min-h-11 w-full sm:w-auto">Bezár</Button>
          <VersionsButton pageId={pageId} onRestored={() => qc.invalidateQueries({ queryKey: ["cms-page-blocks", pageId] })} />
          <Button onClick={() => { haptic(12); publish(); }} className="min-h-11 w-full sm:w-auto">Közzététel</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function BlockEditor({ block, onChange }: { block: any; onChange: (c: any) => void }) {
  const c = block.content ?? {};
  const set = (patch: any) => onChange({ ...c, ...patch });
  switch (block.block_type) {
    case "richtext":
      return <TiptapEditor value={String(c.html ?? "")} onChange={html => set({ html })} />;
    case "heading":
      return <Input value={String(c.text ?? "")} onChange={e => set({ text: e.target.value })} placeholder="Címsor szöveg" />;
    case "image":
      return (
        <div className="space-y-2">
          <Input value={c.src ?? ""} onChange={e => set({ src: e.target.value })} placeholder="Kép URL" />
          <Input value={c.alt ?? ""} onChange={e => set({ alt: e.target.value })} placeholder="Alt szöveg" />
          <Input value={c.caption ?? ""} onChange={e => set({ caption: e.target.value })} placeholder="Felirat (opcionális)" />
        </div>
      );
    case "youtube":
      return (
        <div className="space-y-2">
          <Input value={c.src ?? ""} onChange={e => set({ src: e.target.value })} placeholder="YouTube/Vimeo embed URL" />
          <Input value={c.title ?? ""} onChange={e => set({ title: e.target.value })} placeholder="Cím" />
        </div>
      );
    case "callout":
      return (
        <div className="space-y-2">
          <Input value={c.title ?? ""} onChange={e => set({ title: e.target.value })} placeholder="Cím" />
          <Textarea value={c.text ?? ""} onChange={e => set({ text: e.target.value })} placeholder="Szöveg" />
        </div>
      );
    /* ---------- Dinamikus blokk paraméter-űrlapok ---------- */
    case "doctor_card":
      return (
        <div className="space-y-2">
          <Input value={c.slug ?? ""} onChange={e => set({ slug: e.target.value })} placeholder="Munkatárs slug (pl. dr-kovacs-anna)" />
          <p className="text-xs text-muted-foreground">A munkatárs slug-ját az admin → Munkatársak listából másold.</p>
        </div>
      );
    case "doctor_schedule":
      return (
        <div className="space-y-2">
          <Input value={c.title ?? ""} onChange={e => set({ title: e.target.value })} placeholder='Szakasz címe (pl. "Foglalható időpontok")' />
          <Input value={c.doctor_id ?? ""} onChange={e => set({ doctor_id: e.target.value })} placeholder="Orvos UUID (opcionális)" />
          <Input value={c.specialty_id ?? ""} onChange={e => set({ specialty_id: e.target.value })} placeholder="Szakma UUID (opcionális)" />
          <Input value={c.org_unit_id ?? ""} onChange={e => set({ org_unit_id: e.target.value })} placeholder="Osztály UUID (opcionális)" />
          <Input type="number" inputMode="numeric" min={1} max={60} value={c.days ?? 14} onChange={e => set({ days: parseInt(e.target.value) || 14 })} placeholder="Hány napra előre (1-60)" />
          <p className="text-xs text-muted-foreground">Élő szabad slotok az erőforrás-beosztásból.</p>
        </div>
      );
    case "booking_widget":
      return (
        <div className="space-y-2">
          <Input value={c.cta_label ?? ""} onChange={e => set({ cta_label: e.target.value })} placeholder='Gomb felirata (alapért. "Foglalás indítása")' />
          <Input value={c.specialty_id ?? ""} onChange={e => set({ specialty_id: e.target.value })} placeholder="Szakma UUID (előre kitöltéshez)" />
          <Input value={c.doctor_id ?? ""} onChange={e => set({ doctor_id: e.target.value })} placeholder="Orvos UUID (előre kitöltéshez)" />
          <Input value={c.org_unit_id ?? ""} onChange={e => set({ org_unit_id: e.target.value })} placeholder="Osztály UUID (előre kitöltéshez)" />
        </div>
      );
    case "contact_form":
      return (
        <div className="space-y-2">
          <Input value={c.title ?? ""} onChange={e => set({ title: e.target.value })} placeholder="Szakasz címe" />
          <Input value={c.org_unit_id ?? ""} onChange={e => set({ org_unit_id: e.target.value })} placeholder="Osztály UUID (üzenet ehhez az osztályhoz)" />
          <p className="text-xs text-muted-foreground">A beérkező üzenetek az admin → Üzenetek alatt jelennek meg.</p>
        </div>
      );
    case "department_info":
      return (
        <div className="space-y-2">
          <Input value={c.unit_id ?? ""} onChange={e => set({ unit_id: e.target.value })} placeholder="Osztály UUID" />
          <p className="text-xs text-muted-foreground">Az osztály élő kontakt-adatait jeleníti meg.</p>
        </div>
      );
    case "faq":
      return (
        <div className="space-y-2">
          <Input value={c.tag ?? ""} onChange={e => set({ tag: e.target.value })} placeholder="Tag szűrő (üres = minden GYIK)" />
          <Input type="number" inputMode="numeric" min={1} max={50} value={c.limit ?? 10} onChange={e => set({ limit: parseInt(e.target.value) || 10 })} placeholder="Max db (1-50)" />
        </div>
      );
    case "related_posts":
      return (
        <div className="space-y-2">
          <Textarea
            value={(c.slugs ?? []).join("\n")}
            onChange={e => set({ slugs: e.target.value.split("\n").map(s => s.trim()).filter(Boolean) })}
            placeholder="Egy slug soronként (pl. szakmak/szuleszet)"
            rows={4}
          />
        </div>
      );
    case "staff_list":
      return (
        <div className="space-y-2">
          <Input value={c.specialty ?? ""} onChange={e => set({ specialty: e.target.value })} placeholder='Szakterület szűrő (opcionális, pl. "kardiológia")' />
        </div>
      );
    default:
      return <div className="text-xs text-muted-foreground">Nincs szerkesztő ehhez a blokkhoz.</div>;
  }
}


function VersionsButton({ pageId, onRestored }: { pageId: string; onRestored: () => void }) {
  const [open, setOpen] = useState(false);
  const listFn = useServerFn(listPageVersions);
  const rollbackFn = useServerFn(rollbackPageVersion);
  const { data: versions = [], refetch } = useQuery({
    queryKey: ["cms-page-versions", pageId],
    queryFn: () => listFn({ data: { pageId } }),
    enabled: open,
  });
  const restore = async (versionId: string) => {
    if (!confirm("Visszaállítod ezt a verziót? Az aktuális tartalom felülíródik.")) return;
    try {
      await rollbackFn({ data: { pageId, versionId } });
      toast.success("Verzió visszaállítva");
      setOpen(false);
      onRestored();
    } catch (e: any) { toast.error(e.message); }
  };
  return (
    <>
      <Button variant="outline" className="min-h-11 w-full sm:w-auto" onClick={() => setOpen(true)}>
        <History className="h-4 w-4 mr-2" />Verziók
      </Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Verziótörténet</DialogTitle></DialogHeader>
          <div className="space-y-2 max-h-[60vh] overflow-y-auto">
            {versions.length === 0 && <p className="text-sm text-muted-foreground">Még nincs mentett verzió.</p>}
            {versions.map((v: any) => (
              <div key={v.id} className="flex items-center justify-between border rounded p-2">
                <div className="text-sm">
                  <div className="font-medium">v{v.version} {v.is_published && <span className="text-xs text-green-600">(publikált)</span>}</div>
                  <div className="text-xs text-muted-foreground">{new Date(v.created_at).toLocaleString("hu-HU")}</div>
                </div>
                <Button size="sm" variant="outline" className="min-h-9" onClick={() => restore(v.id)}>Visszaállítás</Button>
              </div>
            ))}
          </div>
          <DialogFooter><Button variant="ghost" onClick={() => { refetch(); }}>Frissítés</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}


function PreviewLinkRow({ pageId }: { pageId: string }) {
  const fn = useServerFn(getPagePreviewLink);
  const { data } = useQuery({
    queryKey: ["cms-page-preview", pageId],
    queryFn: () => fn({ data: { pageId } }),
    staleTime: 60_000,
  });
  if (!data) return null;
  const url = `${window.location.origin}/o/${data.slug}?preview=${data.token}`;
  return (
    <div className="border-t pt-3">
      <Label className="text-sm font-semibold">Vázlat előnézet</Label>
      <div className="flex gap-2 mt-2">
        <Input readOnly value={url} className="min-h-11 font-mono text-xs" />
        <Button
          type="button"
          variant="outline"
          className="min-h-11 shrink-0"
          onClick={() => { navigator.clipboard.writeText(url); toast.success("Link másolva"); }}
        >
          Másol
        </Button>
        <Button type="button" variant="outline" className="min-h-11 shrink-0" asChild>
          <a href={url} target="_blank" rel="noreferrer"><ExternalLink className="h-4 w-4" /></a>
        </Button>
      </div>
      <p className="text-xs text-muted-foreground mt-1">
        Ezzel a linkkel a piszkozat is megtekinthető — a tartalom <code>noindex</code> marad.
      </p>
    </div>
  );
}

function ScheduleDialog({ page, onClose, onSubmit }: { page: any; onClose: () => void; onSubmit: (whenIso: string | null) => void | Promise<void> }) {
  const initial = page.scheduled_publish_at ? page.scheduled_publish_at.slice(0, 16) : "";
  const [when, setWhen] = useState<string>(initial);
  const isScheduled = page.status === "scheduled" && !!page.scheduled_publish_at;
  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Publikálás ütemezése</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="text-sm text-muted-foreground">
            <span className="font-medium text-foreground">{page.title}</span> — {page.slug || "/"}
          </div>
          <div>
            <Label>Publikálás időpontja</Label>
            <Input
              type="datetime-local"
              className="min-h-11"
              value={when}
              min={new Date(Date.now() + 60_000).toISOString().slice(0, 16)}
              onChange={(e) => setWhen(e.target.value)}
            />
            <p className="text-xs text-muted-foreground mt-1">
              A rendszer percenként ellenőrzi az ütemezett oldalakat és automatikusan publikálja őket a megadott időpontban.
            </p>
          </div>
        </div>
        <DialogFooter className="flex-col-reverse sm:flex-row gap-2">
          {isScheduled && (
            <Button
              variant="outline"
              className="min-h-11 w-full sm:w-auto sm:mr-auto"
              onClick={() => onSubmit(null)}
            >
              Ütemezés visszavonása
            </Button>
          )}
          <Button variant="ghost" onClick={onClose} className="min-h-11 w-full sm:w-auto">Mégse</Button>
          <Button
            className="min-h-11 w-full sm:w-auto"
            disabled={!when}
            onClick={() => onSubmit(new Date(when).toISOString())}
          >
            Ütemezés mentése
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
