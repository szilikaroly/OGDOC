/**
 * Tanács-részletoldal lájk + komment szekciója.
 */
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Heart, Eye, MessageCircle, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";
import { Link } from "@tanstack/react-router";
import {
  recordTipView, getTipEngagement, toggleTipLike, isTipLiked,
  listTipComments, postTipComment,
} from "@/lib/cms/tips-engagement.functions";
import { supabase } from "@/integrations/supabase/client";

export function TipEngagement({ tipId, locale }: { tipId: string; locale?: string }) {
  const qc = useQueryClient();
  const recordFn = useServerFn(recordTipView);
  const engFn = useServerFn(getTipEngagement);
  const toggleFn = useServerFn(toggleTipLike);
  const isLikedFn = useServerFn(isTipLiked);
  const listCommentsFn = useServerFn(listTipComments);
  const postCommentFn = useServerFn(postTipComment);

  const [authed, setAuthed] = useState(false);
  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setAuthed(!!data.user));
  }, []);

  // Megtekintés log (1×/session/cikk)
  useEffect(() => {
    const key = `tip-view-${tipId}`;
    if (typeof window === "undefined" || sessionStorage.getItem(key)) return;
    sessionStorage.setItem(key, "1");
    recordFn({ data: { tipId, locale } }).catch(() => {});
  }, [tipId]); // eslint-disable-line

  const engQ = useQuery({
    queryKey: ["tip-eng", tipId],
    queryFn: () => engFn({ data: { tipId } }),
  });
  const likedQ = useQuery({
    queryKey: ["tip-liked", tipId, authed],
    queryFn: () => (authed ? isLikedFn({ data: { tipId } }) : Promise.resolve({ liked: false })),
    enabled: authed,
  });
  const commentsQ = useQuery({
    queryKey: ["tip-comments", tipId],
    queryFn: () => listCommentsFn({ data: { tipId } }),
  });

  const toggleLike = useMutation({
    mutationFn: () => toggleFn({ data: { tipId } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["tip-eng", tipId] });
      qc.invalidateQueries({ queryKey: ["tip-liked", tipId] });
    },
  });

  const [body, setBody] = useState("");
  const post = useMutation({
    mutationFn: () => postCommentFn({ data: { tipId, body } }),
    onSuccess: () => {
      setBody("");
      toast.success("Köszönjük! Moderálás után jelenik meg.");
      qc.invalidateQueries({ queryKey: ["tip-comments", tipId] });
    },
    onError: (e: any) => toast.error(e?.message ?? "Hiba"),
  });

  const eng = engQ.data ?? { views: 0, likes: 0, comments: 0 };

  return (
    <section className="mt-10 pt-6 border-t space-y-6">
      <div className="flex flex-wrap items-center gap-3 text-sm">
        <Button
          variant={likedQ.data?.liked ? "default" : "outline"}
          size="sm"
          disabled={!authed || toggleLike.isPending}
          onClick={() => toggleLike.mutate()}
          className="gap-1.5 min-h-9"
        >
          <Heart className={`size-4 ${likedQ.data?.liked ? "fill-current" : ""}`} />
          {eng.likes}
        </Button>
        <span className="inline-flex items-center gap-1.5 text-muted-foreground"><Eye className="size-4" />{eng.views}</span>
        <span className="inline-flex items-center gap-1.5 text-muted-foreground"><MessageCircle className="size-4" />{eng.comments}</span>
        {!authed && <span className="text-xs text-muted-foreground">A lájkoláshoz <Link to="/auth" className="underline">jelentkezz be</Link>.</span>}
      </div>

      <div>
        <h3 className="font-semibold mb-3">Hozzászólások</h3>
        {authed ? (
          <Card>
            <CardContent className="p-3 space-y-2">
              <Textarea
                rows={3}
                placeholder="Írj egy hozzászólást… (moderálás után jelenik meg)"
                value={body}
                onChange={(e) => setBody(e.target.value)}
              />
              <div className="flex justify-end">
                <Button size="sm" disabled={body.trim().length < 2 || post.isPending} onClick={() => post.mutate()}>
                  {post.isPending && <Loader2 className="size-4 animate-spin mr-1" />}
                  Küldés
                </Button>
              </div>
            </CardContent>
          </Card>
        ) : (
          <p className="text-sm text-muted-foreground">A hozzászóláshoz <Link to="/auth" className="underline">jelentkezz be</Link>.</p>
        )}

        <ul className="mt-4 space-y-3">
          {(commentsQ.data ?? []).map((c: any) => (
            <li key={c.id} className="border rounded-lg p-3 bg-card">
              <div className="text-xs text-muted-foreground mb-1">{new Date(c.created_at).toLocaleString("hu-HU")}</div>
              <div className="text-sm whitespace-pre-line">{c.body}</div>
            </li>
          ))}
          {!commentsQ.data?.length && <li className="text-sm text-muted-foreground">Legyél te az első hozzászóló!</li>}
        </ul>
      </div>
    </section>
  );
}
