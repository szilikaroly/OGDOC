import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  adminListExperiments, adminGetExperiment, adminUpsertExperiment,
  adminUpsertVariant, adminDeleteVariant, adminSetExperimentStatus,
  adminGetExperimentStats, adminGetExperimentDailyStats,
} from "@/lib/cms/experiments.functions";
import type { ConversionEventDef, ConversionEventField, FieldType } from "@/lib/cms/conversion-events";
import { twoProportionPValue } from "@/lib/cms/experiments";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Plus, Play, Pause, Trophy, Trash2, FlaskConical, Download } from "lucide-react";
import { ListSkeleton } from "@/components/ui/list-skeletons";

const STATUS_LABEL: Record<string, string> = {
  draft: "Vázlat", running: "Fut", paused: "Szünetel", completed: "Lezárva",
};

export function ExperimentsAdmin() {
  const listFn = useServerFn(adminListExperiments);
  const { data: list = [], isLoading } = useQuery({
    queryKey: ["cms-experiments"],
    queryFn: () => listFn(),
  });
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[320px_1fr] gap-4">
      <div className="border rounded-lg p-3">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-semibold flex items-center gap-2"><FlaskConical className="h-4 w-4" /> Kísérletek</h3>
          <Button size="sm" onClick={() => setCreating(true)}><Plus className="h-3 w-3 mr-1" />Új</Button>
        </div>
        {isLoading ? <ListSkeleton rows={4} />
          : list.length === 0 ? <p className="text-sm text-muted-foreground">Nincs még kísérlet.</p>
          : (
            <ul className="space-y-1">
              {list.map((e: any) => (
                <li key={e.id}>
                  <button
                    onClick={() => setSelectedId(e.id)}
                    className={`w-full text-left px-2 py-2 rounded text-sm hover:bg-muted ${selectedId === e.id ? "bg-muted" : ""}`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="truncate font-medium">{e.name}</span>
                      <Badge variant={e.status === "running" ? "default" : "outline"} className="text-[10px]">{STATUS_LABEL[e.status]}</Badge>
                    </div>
                    <div className="text-xs text-muted-foreground truncate">cél: {e.goal_event} · variants: {e.cms_experiment_variants?.length ?? 0}</div>
                  </button>
                </li>
              ))}
            </ul>
          )}
      </div>

      <div className="border rounded-lg p-4">
        {selectedId ? (
          <ExperimentEditor id={selectedId} onDeleted={() => setSelectedId(null)} />
        ) : (
          <p className="text-sm text-muted-foreground">Válassz vagy hozz létre kísérletet.</p>
        )}
      </div>

      {creating && <CreateExperimentDialog onClose={(id) => { setCreating(false); if (id) setSelectedId(id); }} />}
    </div>
  );
}

function CreateExperimentDialog({ onClose }: { onClose: (id?: string) => void }) {
  const upsert = useServerFn(adminUpsertExperiment);
  const qc = useQueryClient();
  const [name, setName] = useState("");
  const [blockId, setBlockId] = useState("");
  const [layoutBlockId, setLayoutBlockId] = useState("");
  const [goal, setGoal] = useState("cta_click");

  const m = useMutation({
    mutationFn: () => upsert({ data: {
      name, block_id: blockId || null, layout_block_id: layoutBlockId || null,
      status: "draft", traffic_allocation: 1, goal_event: goal,
    } as any }),
    onSuccess: (r: any) => {
      toast.success("Kísérlet létrehozva");
      qc.invalidateQueries({ queryKey: ["cms-experiments"] });
      onClose(r?.id);
    },
    onError: (e: any) => toast.error(e?.message ?? "Hiba"),
  });

  return (
    <Dialog open onOpenChange={() => onClose()}>
      <DialogContent>
        <DialogHeader><DialogTitle>Új kísérlet</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div><Label>Név</Label><Input value={name} onChange={(e) => setName(e.target.value)} /></div>
          <div className="grid grid-cols-2 gap-2">
            <div><Label className="text-xs">block_id (cms_blocks)</Label><Input value={blockId} onChange={(e) => setBlockId(e.target.value)} placeholder="uuid…" /></div>
            <div><Label className="text-xs">layout_block_id</Label><Input value={layoutBlockId} onChange={(e) => setLayoutBlockId(e.target.value)} placeholder="uuid…" /></div>
          </div>
          <p className="text-xs text-muted-foreground">Pontosan az egyiket add meg.</p>
          <div><Label>Conversion cél (goal_event)</Label><Input value={goal} onChange={(e) => setGoal(e.target.value)} placeholder="cta_click, form_submit, appointment_book…" /></div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onClose()}>Mégse</Button>
          <Button disabled={!name || m.isPending} onClick={() => m.mutate()}>Létrehozás</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function ExperimentEditor({ id, onDeleted }: { id: string; onDeleted: () => void }) {
  const getFn = useServerFn(adminGetExperiment);
  const upsertVariant = useServerFn(adminUpsertVariant);
  const deleteVariant = useServerFn(adminDeleteVariant);
  const setStatus = useServerFn(adminSetExperimentStatus);
  const statsFn = useServerFn(adminGetExperimentStats);
  const qc = useQueryClient();

  const { data: exp } = useQuery({
    queryKey: ["cms-experiment", id],
    queryFn: () => getFn({ data: { id } }),
  });
  const { data: stats = [] } = useQuery({
    queryKey: ["cms-experiment-stats", id],
    queryFn: () => statsFn({ data: { id, days: 30 } }),
  });

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ["cms-experiment", id] });
    qc.invalidateQueries({ queryKey: ["cms-experiments"] });
    qc.invalidateQueries({ queryKey: ["cms-experiment-stats", id] });
  };

  const setM = useMutation({
    mutationFn: (status: any) => setStatus({ data: { id, status } as any }),
    onSuccess: () => { toast.success("Állapot frissítve"); refresh(); },
    onError: (e: any) => toast.error(e?.message ?? "Hiba"),
  });

  if (!exp) return <p className="text-sm text-muted-foreground">Betöltés…</p>;
  const variants: any[] = exp.cms_experiment_variants ?? [];
  const control = variants.find((v) => v.is_control);
  const statsMap = new Map((stats as any[]).map((s) => [s.variant_id, s]));
  const controlStats = control ? statsMap.get(control.id) : null;

  return (
    <div className="space-y-5">
      <header className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 className="text-lg font-semibold">{exp.name}</h3>
          <p className="text-xs text-muted-foreground">cél: <code>{exp.goal_event}</code> · állapot: {STATUS_LABEL[exp.status]} · traffic {Math.round((exp.traffic_allocation ?? 1) * 100)}%</p>
        </div>
        <div className="flex flex-wrap gap-2">
          {exp.status !== "running" && (
            <Button size="sm" variant="default" onClick={() => setM.mutate("running")}><Play className="h-3 w-3 mr-1" />Indítás</Button>
          )}
          {exp.status === "running" && (
            <Button size="sm" variant="outline" onClick={() => setM.mutate("paused")}><Pause className="h-3 w-3 mr-1" />Szünet</Button>
          )}
          {exp.status !== "completed" && (
            <Button size="sm" variant="outline" onClick={() => setM.mutate("completed")}><Trophy className="h-3 w-3 mr-1" />Lezárás</Button>
          )}
        </div>
      </header>

      <CsvExportPanel experimentId={id} experimentName={exp.name} />

      <ConversionEventsPanel
        experimentId={id}
        initial={Array.isArray((exp as any).conversion_events) ? ((exp as any).conversion_events as unknown as ConversionEventDef[]) : []}
        experiment={exp}
        onSaved={refresh}
      />




      <div>
        <div className="flex items-center justify-between mb-2">
          <h4 className="font-semibold text-sm">Variánsok</h4>
          <Button size="sm" variant="outline" onClick={() => {
            const key = String.fromCharCode(65 + variants.length); // A,B,C…
            upsertVariant({ data: { experiment_id: id, key, weight: 1, is_control: variants.length === 0, content: {} } as any })
              .then(() => { toast.success("Variant hozzáadva"); refresh(); })
              .catch((e: any) => toast.error(e?.message ?? "Hiba"));
          }}><Plus className="h-3 w-3 mr-1" />Új variant</Button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {variants.map((v) => {
            const s = statsMap.get(v.id) ?? { views: 0, goals: 0, conversion_rate: 0 };
            const p = controlStats && controlStats.variant_id !== v.id
              ? twoProportionPValue(controlStats.goals, controlStats.views, s.goals, s.views)
              : null;
            return <VariantCard key={v.id} variant={v} stats={s} pValue={p}
              onSave={(patch: any) => upsertVariant({ data: { ...v, ...patch } as any })
                .then(() => { toast.success("Mentve"); refresh(); })
                .catch((e: any) => toast.error(e?.message ?? "Hiba"))}
              onDelete={() => {
                if (!confirm("Biztos törlöd?")) return;
                deleteVariant({ data: { id: v.id } })
                  .then(() => { toast.success("Törölve"); refresh(); })
                  .catch((e: any) => toast.error(e?.message ?? "Hiba"));
              }}
            />;
          })}
        </div>
      </div>
    </div>
  );
}

function VariantCard({ variant, stats, pValue, onSave, onDelete }: any) {
  const [name, setName] = useState(variant.name ?? "");
  const [weight, setWeight] = useState(variant.weight ?? 1);
  const [isControl, setIsControl] = useState(variant.is_control ?? false);
  const [content, setContent] = useState(JSON.stringify(variant.content ?? {}, null, 2));

  return (
    <div className="border rounded-lg p-3 space-y-2">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Badge variant="secondary">{variant.key}</Badge>
          {isControl && <Badge variant="outline" className="text-[10px]">control</Badge>}
        </div>
        <Button size="icon" variant="ghost" onClick={onDelete}><Trash2 className="h-3.5 w-3.5" /></Button>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <div><Label className="text-xs">Név</Label><Input value={name} onChange={(e) => setName(e.target.value)} /></div>
        <div><Label className="text-xs">Súly</Label><Input type="number" step="0.1" min="0" value={weight} onChange={(e) => setWeight(Number(e.target.value))} /></div>
      </div>
      <label className="flex items-center gap-2 text-xs">
        <input type="checkbox" checked={isControl} onChange={(e) => setIsControl(e.target.checked)} /> Control
      </label>
      <div>
        <Label className="text-xs">Tartalom (JSON)</Label>
        <Textarea value={content} onChange={(e) => setContent(e.target.value)} rows={6} className="font-mono text-xs" />
      </div>
      <div className="flex items-center justify-between text-xs">
        <div className="text-muted-foreground">
          {stats.views} megjelenés · {stats.goals} cél · CR <span className="font-mono">{(stats.conversion_rate * 100).toFixed(2)}%</span>
          {pValue !== null && <> · p=<span className={pValue < 0.05 ? "text-emerald-600 font-semibold" : ""}>{pValue.toFixed(3)}</span></>}
        </div>
        <Button size="sm" onClick={() => {
          let parsed: any = {};
          try { parsed = JSON.parse(content || "{}"); } catch { toast.error("JSON hibás"); return; }
          onSave({ name, weight, is_control: isControl, content: parsed });
        }}>Mentés</Button>
      </div>
    </div>
  );
}

function toCsv(rows: any[]): string {
  const headers = ["date", "variant_key", "variant_name", "variant_id", "views", "goals", "conversion_rate"];
  const esc = (v: any) => {
    const s = v == null ? "" : String(v);
    return /[",\n;]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const lines = [headers.join(",")];
  for (const r of rows) {
    lines.push(headers.map((h) => h === "conversion_rate" ? (r[h] as number).toFixed(4) : esc(r[h])).join(","));
  }
  return lines.join("\n");
}

function todayIso(offsetDays = 0): string {
  const d = new Date(Date.now() + offsetDays * 86400 * 1000);
  return d.toISOString().slice(0, 10);
}

function CsvExportPanel({ experimentId, experimentName }: { experimentId: string; experimentName: string }) {
  const dailyFn = useServerFn(adminGetExperimentDailyStats);
  const [from, setFrom] = useState(todayIso(-29));
  const [to, setTo] = useState(todayIso(0));
  const [loading, setLoading] = useState(false);

  const download = async () => {
    if (from > to) { toast.error("A kezdő dátum nem lehet későbbi, mint a záró."); return; }
    setLoading(true);
    try {
      const res: any = await dailyFn({ data: { id: experimentId, from, to } });
      const rows = res?.rows ?? [];
      if (rows.length === 0) { toast.warning("Nincs adat a megadott időszakban."); return; }
      const csv = toCsv(rows);
      const blob = new Blob([`\uFEFF${csv}`], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      const safe = experimentName.replace(/[^\w.-]+/g, "_").slice(0, 60) || "kiserlet";
      a.href = url;
      a.download = `${safe}_${from}_${to}.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast.success(`CSV exportálva (${rows.length} sor)`);
    } catch (e: any) {
      toast.error(e?.message ?? "Export hiba");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="border rounded-lg p-3 bg-muted/30 flex flex-wrap items-end gap-3">
      <div>
        <Label className="text-xs">Napi export – kezdet</Label>
        <Input type="date" value={from} max={to} onChange={(e) => setFrom(e.target.value)} className="h-9 w-[10rem]" />
      </div>
      <div>
        <Label className="text-xs">Vég</Label>
        <Input type="date" value={to} min={from} max={todayIso(0)} onChange={(e) => setTo(e.target.value)} className="h-9 w-[10rem]" />
      </div>
      <Button size="sm" onClick={download} disabled={loading}>
        <Download className="h-3 w-3 mr-1" />{loading ? "Exportálás…" : "CSV letöltése"}
      </Button>
      <p className="text-xs text-muted-foreground basis-full">Variansonként × naponta bontva (views, goals, conversion_rate).</p>
    </div>
  );
}

// ============================================================
// Konverziós események (név + paraméter séma) — admin szerkesztő
// ============================================================
const FIELD_TYPES: FieldType[] = ["string", "number", "boolean", "url"];

function ConversionEventsPanel({
  experimentId, initial, experiment, onSaved,
}: {
  experimentId: string;
  initial: ConversionEventDef[];
  experiment: any;
  onSaved: () => void;
}) {
  const upsert = useServerFn(adminUpsertExperiment);
  const [defs, setDefs] = useState<ConversionEventDef[]>(initial);
  const [dirty, setDirty] = useState(false);

  const patch = (i: number, next: Partial<ConversionEventDef>) => {
    setDefs((prev) => prev.map((d, idx) => idx === i ? { ...d, ...next } : d));
    setDirty(true);
  };
  const patchField = (i: number, fi: number, next: Partial<ConversionEventField>) => {
    setDefs((prev) => prev.map((d, idx) => idx === i
      ? { ...d, fields: d.fields.map((f, fx) => fx === fi ? { ...f, ...next } : f) }
      : d));
    setDirty(true);
  };
  const addEvent = () => {
    setDefs((prev) => [...prev, { name: `event_${prev.length + 1}`, fields: [] }]);
    setDirty(true);
  };
  const removeEvent = (i: number) => {
    setDefs((prev) => prev.filter((_, idx) => idx !== i));
    setDirty(true);
  };
  const addField = (i: number) => {
    setDefs((prev) => prev.map((d, idx) => idx === i
      ? { ...d, fields: [...d.fields, { name: "param", type: "string" }] }
      : d));
    setDirty(true);
  };
  const removeField = (i: number, fi: number) => {
    setDefs((prev) => prev.map((d, idx) => idx === i
      ? { ...d, fields: d.fields.filter((_, fx) => fx !== fi) }
      : d));
    setDirty(true);
  };

  const save = async () => {
    // deduplikáció / gyors kliens validáció
    const names = new Set<string>();
    for (const d of defs) {
      if (names.has(d.name)) { toast.error(`Ismétlődő esemény név: ${d.name}`); return; }
      names.add(d.name);
      const fn = new Set<string>();
      for (const f of d.fields) {
        if (fn.has(f.name)) { toast.error(`${d.name}: ismétlődő mező ${f.name}`); return; }
        fn.add(f.name);
      }
    }
    try {
      await upsert({ data: {
        id: experimentId,
        name: experiment.name,
        block_id: experiment.block_id ?? null,
        layout_block_id: experiment.layout_block_id ?? null,
        status: experiment.status,
        traffic_allocation: Number(experiment.traffic_allocation ?? 1),
        goal_event: experiment.goal_event,
        conversion_events: defs,
      } as any });
      toast.success("Konverziós események mentve");
      setDirty(false);
      onSaved();
    } catch (e: any) {
      toast.error(e?.message ?? "Mentési hiba");
    }
  };

  return (
    <div className="border rounded-lg p-3 space-y-3">
      <div className="flex items-center justify-between">
        <div>
          <h4 className="font-semibold text-sm">Konverziós események</h4>
          <p className="text-xs text-muted-foreground">
            Név + paraméter séma. Automatikus tracking: <code className="text-[10px]">data-track="név"</code> vagy <code className="text-[10px]">window.lovableTrack("név", &#123;…&#125;)</code>.
          </p>
        </div>
        <div className="flex gap-2">
          <Button size="sm" variant="outline" onClick={addEvent}><Plus className="h-3 w-3 mr-1" />Új esemény</Button>
          <Button size="sm" onClick={save} disabled={!dirty}>Mentés</Button>
        </div>
      </div>

      {defs.length === 0 ? (
        <p className="text-xs text-muted-foreground">Még nincs definiálva esemény.</p>
      ) : (
        <div className="space-y-3">
          {defs.map((d, i) => (
            <div key={i} className="border rounded p-2 space-y-2 bg-muted/20">
              <div className="grid grid-cols-1 md:grid-cols-[1fr_2fr_auto] gap-2 items-end">
                <div>
                  <Label className="text-xs">Név</Label>
                  <Input value={d.name} onChange={(e) => patch(i, { name: e.target.value })} className="h-8 font-mono text-xs" />
                </div>
                <div>
                  <Label className="text-xs">Leírás</Label>
                  <Input value={d.description ?? ""} onChange={(e) => patch(i, { description: e.target.value })} className="h-8 text-xs" />
                </div>
                <Button size="icon" variant="ghost" onClick={() => removeEvent(i)}><Trash2 className="h-3.5 w-3.5" /></Button>
              </div>

              <div className="pl-2 border-l-2 border-muted space-y-1">
                {d.fields.length === 0 && <p className="text-[11px] text-muted-foreground">Nincsenek paraméterek.</p>}
                {d.fields.map((f, fi) => (
                  <div key={fi} className="grid grid-cols-[1fr_100px_auto_auto] gap-2 items-center">
                    <Input value={f.name} onChange={(e) => patchField(i, fi, { name: e.target.value })} placeholder="mező név" className="h-7 text-xs font-mono" />
                    <select
                      value={f.type}
                      onChange={(e) => patchField(i, fi, { type: e.target.value as FieldType })}
                      className="h-7 text-xs border rounded px-1 bg-background"
                    >
                      {FIELD_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
                    </select>
                    <label className="text-[11px] flex items-center gap-1">
                      <input type="checkbox" checked={!!f.required} onChange={(e) => patchField(i, fi, { required: e.target.checked })} />
                      kötelező
                    </label>
                    <Button size="icon" variant="ghost" onClick={() => removeField(i, fi)}><Trash2 className="h-3 w-3" /></Button>
                  </div>
                ))}
                <Button size="sm" variant="ghost" onClick={() => addField(i)} className="h-7 text-xs">
                  <Plus className="h-3 w-3 mr-1" />Mező
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
