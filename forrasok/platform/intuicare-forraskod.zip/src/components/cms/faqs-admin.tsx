import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { listFaqs, saveFaq, deleteFaq } from "@/lib/cms/faqs.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Plus, Trash2, Pencil, Search } from "lucide-react";
import { toast } from "sonner";
import { ListSkeleton } from "@/components/ui/list-skeletons";
import { haptic } from "@/lib/query/optimistic";

type Faq = {
  id?: string;
  locale: string;
  question: string;
  answer: string;
  tags: string[];
  sort_order: number;
  is_published: boolean;
};

const empty = (): Faq => ({ locale: "hu", question: "", answer: "", tags: [], sort_order: 0, is_published: true });

export function FaqsAdmin() {
  const qc = useQueryClient();
  const listFn = useServerFn(listFaqs);
  const saveFn = useServerFn(saveFaq);
  const delFn = useServerFn(deleteFaq);

  const { data: faqs = [], isLoading } = useQuery({ queryKey: ["cms-faqs"], queryFn: () => listFn() });
  const [editing, setEditing] = useState<Faq | null>(null);
  const [search, setSearch] = useState("");
  const [locale, setLocale] = useState<string>("hu");

  const filtered = (faqs as Faq[]).filter(f =>
    f.locale === locale && (
      !search.trim() ||
      f.question.toLowerCase().includes(search.toLowerCase()) ||
      (f.tags ?? []).some(t => t.toLowerCase().includes(search.toLowerCase()))
    )
  );

  const save = async (f: Faq) => {
    try {
      await saveFn({ data: f as any });
      setEditing(null);
      qc.invalidateQueries({ queryKey: ["cms-faqs"] });
      toast.success("Mentve");
    } catch (e: any) {
      toast.error(e.message ?? "Sikertelen mentés");
    }
  };

  const remove = async (id: string) => {
    if (!confirm("Biztosan törlöd?")) return;
    try {
      await delFn({ data: { id } });
      qc.invalidateQueries({ queryKey: ["cms-faqs"] });
      toast.success("Törölve");
    } catch (e: any) { toast.error(e.message); }
  };

  return (
    <div className="space-y-3 mt-4">
      <div className="grid grid-cols-[minmax(0,1fr)_auto] sm:flex sm:flex-wrap gap-2 items-center">
        <div className="relative min-w-0 sm:flex-1 sm:min-w-[200px]">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
          <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Keresés…" className="pl-8 min-h-11" inputMode="search" />
        </div>
        <Button size="sm" onClick={() => { haptic(8); setEditing(empty()); }} className="min-h-11 shrink-0" aria-label="Új GYIK">
          <Plus className="h-4 w-4 sm:mr-1" /><span className="hidden sm:inline">Új GYIK</span>
        </Button>
        <div className="col-span-2 sm:col-auto flex gap-1 -mx-1 sm:mx-0 overflow-x-auto">
          {["hu", "en", "de"].map(l => (
            <Button key={l} size="sm" variant={locale === l ? "default" : "outline"} className="min-h-11 shrink-0" onClick={() => setLocale(l)}>{l.toUpperCase()}</Button>
          ))}
        </div>
      </div>

      {isLoading ? <ListSkeleton rows={5} /> : (
      <div className="space-y-2" style={{ contentVisibility: "auto" as any, containIntrinsicSize: "600px" as any }}>
        {filtered.length === 0 && <div className="text-sm text-muted-foreground p-4 text-center">Nincs találat.</div>}
        {filtered.map(f => (
          <Card key={f.id} className="p-3">
            <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-2">
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <div className="font-medium">{f.question}</div>
                  {!f.is_published && <Badge variant="outline">vázlat</Badge>}
                  {(f.tags ?? []).map(t => <Badge key={t} variant="secondary" className="text-xs">{t}</Badge>)}
                </div>
                <div className="text-xs text-muted-foreground mt-1 line-clamp-2">{f.answer}</div>
              </div>
              <div className="flex gap-1 shrink-0">
                <Button size="icon" variant="ghost" className="min-h-11 min-w-11" onClick={() => setEditing(f)} aria-label="Szerkeszt"><Pencil className="h-4 w-4" /></Button>
                <Button size="icon" variant="ghost" className="min-h-11 min-w-11" onClick={() => f.id && remove(f.id)} aria-label="Törlés"><Trash2 className="h-4 w-4 text-destructive" /></Button>
              </div>
            </div>
          </Card>
        ))}
      </div>
      )}

      {editing && (
        <Dialog open onOpenChange={() => setEditing(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader><DialogTitle>{editing.id ? "GYIK szerkesztése" : "Új GYIK"}</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div>
                <Label>Kérdés</Label>
                <Input value={editing.question} onChange={e => setEditing({ ...editing, question: e.target.value })} />
              </div>
              <div>
                <Label>Válasz</Label>
                <Textarea rows={6} value={editing.answer} onChange={e => setEditing({ ...editing, answer: e.target.value })} />
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <Label>Nyelv</Label>
                  <Input value={editing.locale} onChange={e => setEditing({ ...editing, locale: e.target.value })} />
                </div>
                <div>
                  <Label>Sorrend</Label>
                  <Input type="number" value={editing.sort_order} onChange={e => setEditing({ ...editing, sort_order: parseInt(e.target.value) || 0 })} />
                </div>
                <div className="flex items-end gap-2">
                  <Switch checked={editing.is_published} onCheckedChange={v => setEditing({ ...editing, is_published: v })} />
                  <Label>Publikus</Label>
                </div>
              </div>
              <div>
                <Label>Címkék (vesszővel)</Label>
                <Input
                  value={(editing.tags ?? []).join(", ")}
                  onChange={e => setEditing({ ...editing, tags: e.target.value.split(",").map(t => t.trim()).filter(Boolean) })}
                  placeholder="foglalas, idopont, parkolas"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="ghost" onClick={() => setEditing(null)}>Mégse</Button>
              <Button onClick={() => save(editing)}>Mentés</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
