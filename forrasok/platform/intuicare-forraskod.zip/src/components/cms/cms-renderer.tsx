import DOMPurify from "dompurify";
import {
  DoctorCardBlock,
  DoctorScheduleBlock,
  AppointmentBookingWidgetBlock,
  ContactFormBlock,
  DepartmentInfoBlock,
  FaqBlock,
  RelatedPostsBlock,
  StaffListBlock,
} from "./dynamic-blocks";
import { NavMenuBlock } from "./blocks/nav-menu-block";
import { TipsListBlock } from "./blocks/tips-blocks";
import { StaffGridBlock, NewsListBlock } from "./blocks/staff-news-blocks";
import { NewsHeroBlock, NewsRelatedBlock, ShareBarBlock } from "./blocks/news-blocks";
import { SmartImage } from "@/components/ui/smart-image";
import { normalizeVideoMeta } from "@/lib/cms/video";
import { useExperiment } from "@/lib/cms/use-experiment";


interface CmsBlock {
  id: string;
  block_type: string;
  position: number;
  content: any;
  variant?: string;
  /** Optional pending draft payload (admin edit mode). */
  draft_content?: any;
  draft_status?: "none" | "pending" | "approved" | "rejected" | null;
}

export type EditModeProps = {
  /** Currently selected block id (for outline highlight). */
  selectedId?: string | null;
  /** Render the draft payload when present, instead of the live content. */
  showDraft?: boolean;
  /** Wrap each block. If returned, replaces the wrapper UI; otherwise raw. */
  renderWrapper?: (block: CmsBlock, child: React.ReactNode) => React.ReactNode;
  /** Wrap the outer list item (used by drag&drop in the live editor). */
  renderItem?: (block: CmsBlock, child: React.ReactNode) => React.ReactNode;
};

function sanitize(html: string): string {
  if (typeof window === "undefined") return html;
  return DOMPurify.sanitize(html, {
    ADD_TAGS: ["iframe"],
    ADD_ATTR: ["allow", "allowfullscreen", "frameborder", "scrolling", "target"],
  });
}

export function CmsBlockRenderer({ block, showDraft }: { block: CmsBlock; showDraft?: boolean }) {
  // Publikus A/B override — admin/draft nézetben kikapcsolva, hogy a szerkesztő
  // mindig a valódi block.content-et lássa.
  const { variantContent } = useExperiment(block.id, {
    enabled: !showDraft,
    blockType: block.block_type,
    blockLabel: (block as any).name ?? undefined,
  });
  const base = (showDraft && block.draft_content != null ? block.draft_content : block.content) ?? {};
  const c = variantContent ? { ...base, ...variantContent } : base;
  switch (block.block_type) {
    case "richtext":
    case "html":
      return (
        <div
          className="prose prose-lg max-w-none my-6"
          dangerouslySetInnerHTML={{ __html: sanitize(String(c.html ?? "")) }}
        />
      );
    case "heading":
      return <h2 className="text-3xl font-serif font-bold my-6">{String(c.text ?? "")}</h2>;
    case "image":
      return (
        <figure className="my-6">
          <SmartImage src={String(c.src ?? "")} alt={String(c.alt ?? "")} sizesPreset="hero" className="rounded-md w-full" />
          {c.caption && <figcaption className="text-sm text-muted-foreground mt-2 text-center">{String(c.caption)}</figcaption>}
        </figure>
      );
    case "video":
    case "youtube": {
      // Accept both the legacy `{ src }` shape and the unified video fields
      // (`video_url`, `video_provider`, `video_thumbnail_url`, …).
      const meta = normalizeVideoMeta({
        video_provider: c.video_provider ?? null,
        video_url: c.video_url ?? c.src ?? null,
        video_embed_url: c.video_embed_url ?? (c.src && !c.video_url ? c.src : null),
        video_thumbnail_url: c.video_thumbnail_url ?? c.poster ?? null,
        video_duration_seconds: c.video_duration_seconds ?? null,
        video_width: c.video_width ?? null,
        video_height: c.video_height ?? null,
      });
      if (!meta.isPlayable) return null;
      const title = String(c.title ?? "Videó");
      return (
        <figure className="my-6">
          <div
            className="w-full rounded-md overflow-hidden bg-foreground"
            style={{ aspectRatio: meta.aspectRatio }}
          >
            {meta.isFile ? (
              <video
                src={meta.embedUrl!}
                poster={meta.poster ?? undefined}
                controls
                preload="metadata"
                width={meta.width ?? undefined}
                height={meta.height ?? undefined}
                className="w-full h-full"
              />
            ) : (
              <iframe
                src={meta.embedUrl!}
                title={title}
                width={meta.width ?? undefined}
                height={meta.height ?? undefined}
                loading="lazy"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowFullScreen
                className="w-full h-full border-0"
              />
            )}
          </div>
          {c.caption && (
            <figcaption className="text-sm text-muted-foreground mt-2 text-center">
              {String(c.caption)}
            </figcaption>
          )}
        </figure>
      );
    }
    case "gallery":
      return (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 my-6">
          {(c.items ?? []).map((it: any, i: number) => (
            <SmartImage key={i} src={it.src} alt={it.alt ?? ""} sizesPreset="card" className="rounded-md w-full h-48 object-cover" />
          ))}
        </div>
      );
    case "callout":
      return (
        <div className="border-l-4 border-primary bg-primary/5 p-4 my-6 rounded">
          {c.title && <div className="font-semibold mb-1">{String(c.title)}</div>}
          <div className="text-sm">{String(c.text ?? "")}</div>
        </div>
      );
    case "file":
      return (
        <a href={String(c.url ?? "")} download className="inline-flex items-center gap-2 text-primary hover:underline my-2">
          📎 {String(c.label ?? c.file_name ?? "Letöltés")}
        </a>
      );
    /* ---------- Dinamikus blokkok (hidak a meglévő modulokhoz) ---------- */
    case "doctor_card":
      return c.slug ? <DoctorCardBlock slug={String(c.slug)} locale={c.locale} /> : null;
    case "doctor_schedule":
      return (
        <DoctorScheduleBlock
          doctor_id={c.doctor_id}
          specialty_id={c.specialty_id}
          org_unit_id={c.org_unit_id}
          days={c.days}
          title={c.title}
        />
      );
    case "booking_widget":
      return (
        <AppointmentBookingWidgetBlock
          specialty_id={c.specialty_id}
          doctor_id={c.doctor_id}
          org_unit_id={c.org_unit_id}
          cta_label={c.cta_label}
        />
      );
    case "contact_form":
      return <ContactFormBlock org_unit_id={c.org_unit_id} source_page_slug={c.source_page_slug} title={c.title} />;
    case "department_info":
      return c.unit_id ? <DepartmentInfoBlock unit_id={String(c.unit_id)} /> : null;
    case "faq":
      return <FaqBlock tag={c.tag} limit={c.limit ?? 10} locale={c.locale ?? "hu"} />;
    case "related_posts":
      return <RelatedPostsBlock slugs={Array.isArray(c.slugs) ? c.slugs : []} />;
    case "staff_list":
      return <StaffListBlock specialty={c.specialty} locale={c.locale ?? "hu"} />;
    case "nav_menu":
      return <NavMenuBlock slug={c.slug ?? "main"} locale={c.locale ?? "hu"} variant={c.variant ?? "horizontal"} />;
    case "dyn_tips_list":
    case "tips_list":
      return <TipsListBlock category={c.category} audience={c.audience} tag={c.tag} featured_only={c.featured_only} limit={c.limit ?? 6} locale={c.locale ?? "hu"} title={c.title} />;
    case "dyn_staff_grid":
    case "staff_grid":
      return <StaffGridBlock locale={c.locale ?? "hu"} specialty={c.specialty} limit={c.limit ?? 12} title={c.title} />;
    case "dyn_news_list":
    case "news_list":
      return <NewsListBlock locale={c.locale ?? "hu"} category={c.category} limit={c.limit ?? 6} title={c.title} />;
    case "dyn_news_hero":
    case "news_hero":
      return <NewsHeroBlock title={c.title} excerpt={c.excerpt} cover={c.cover} cover_alt={c.cover_alt} post_slug={c.post_slug} locale={c.locale ?? "hu"} />;
    case "dyn_news_related":
    case "news_related":
      return <NewsRelatedBlock title={c.title} post_slug={c.post_slug} limit={c.limit ?? 3} locale={c.locale ?? "hu"} />;
    case "dyn_share_bar":
    case "share_bar":
      return <ShareBarBlock title={c.title} />;


    default:
      return (
        <div className="my-4 p-4 border border-dashed text-sm text-muted-foreground">
          Ismeretlen blokk típus: {block.block_type}
        </div>
      );
  }
}

export function CmsPageRenderer({ blocks, editMode }: { blocks: CmsBlock[]; editMode?: EditModeProps }) {
  const sorted = [...blocks].sort((a, b) => a.position - b.position);
  return (
    <div className="cms-content">
      {sorted.map((b) => {
        const child = <CmsBlockRenderer block={b} showDraft={editMode?.showDraft} />;
        const wrapped = editMode?.renderWrapper ? editMode.renderWrapper(b, child) : child;
        if (editMode?.renderItem) {
          return <div key={b.id}>{editMode.renderItem(b, wrapped)}</div>;
        }
        return <div key={b.id}>{wrapped}</div>;
      })}
    </div>
  );
}
