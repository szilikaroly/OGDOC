/**
 * Egyszerű e-mail feliratkozó űrlap (anon, beilleszthető bárhova).
 */
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Mail, Loader2, CheckCircle2 } from "lucide-react";
import { subscribeNewsletter } from "@/lib/cms/newsletter.functions";

export function NewsletterSubscribe({ source = "tanacsok", title }: { source?: string; title?: string }) {
  const fn = useServerFn(subscribeNewsletter);
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (busy || !email) return;
    setBusy(true);
    try {
      await fn({ data: { email, source } });
      setDone(true);
    } finally { setBusy(false); }
  };

  if (done) {
    return (
      <div className="border rounded-lg p-4 bg-primary/5 flex items-center gap-2 text-sm">
        <CheckCircle2 className="size-5 text-primary" />
        Köszönjük a feliratkozást! Hamarosan kapsz üdvözlő e-mailt.
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="border rounded-lg p-4 bg-card space-y-3">
      <div className="flex items-center gap-2 text-sm font-medium">
        <Mail className="size-4" /> {title ?? "Iratkozz fel a hírlevélre"}
      </div>
      <div className="flex gap-2">
        <Input
          type="email" required placeholder="E-mail cím"
          value={email} onChange={(e) => setEmail(e.target.value)}
          className="min-h-11"
        />
        <Button type="submit" disabled={busy} className="min-h-11">
          {busy ? <Loader2 className="size-4 animate-spin" /> : "Feliratkozom"}
        </Button>
      </div>
    </form>
  );
}
