import { Badge } from "@/components/ui/badge";
import { CircleDashed, Eye, CheckCircle2, Globe, XCircle, Archive } from "lucide-react";

export type WorkflowState =
  | "draft" | "in_review" | "approved" | "published" | "rejected" | "archived";

const LABELS: Record<WorkflowState, string> = {
  draft: "Vázlat",
  in_review: "Véleményezés alatt",
  approved: "Jóváhagyva",
  published: "Publikálva",
  rejected: "Elutasítva",
  archived: "Archiválva",
};

const ICONS: Record<WorkflowState, React.ComponentType<{ className?: string }>> = {
  draft: CircleDashed,
  in_review: Eye,
  approved: CheckCircle2,
  published: Globe,
  rejected: XCircle,
  archived: Archive,
};

// Csak semantikus tokeneket használunk; a vizuális megkülönböztetést variantokkal érjük el.
const VARIANT: Record<WorkflowState, "secondary" | "default" | "destructive" | "outline"> = {
  draft: "outline",
  in_review: "secondary",
  approved: "secondary",
  published: "default",
  rejected: "destructive",
  archived: "outline",
};

export function WorkflowStateBadge({ state, className }: { state?: WorkflowState | string | null; className?: string }) {
  const s = (state ?? "draft") as WorkflowState;
  const Icon = ICONS[s] ?? CircleDashed;
  return (
    <Badge variant={VARIANT[s] ?? "outline"} className={`gap-1 ${className ?? ""}`}>
      <Icon className="h-3 w-3" />
      {LABELS[s] ?? s}
    </Badge>
  );
}
