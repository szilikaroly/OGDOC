import { useMemo, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { reorderPages } from "@/lib/cms/cms.functions";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import { ChevronRight, ChevronDown, Settings, GripVertical, CornerDownRight } from "lucide-react";
import { toast } from "sonner";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  TouchSensor,
  useSensor,
  useSensors,
  useDroppable,
  type DragEndEvent,
  type DragStartEvent,
} from "@dnd-kit/core";
import {
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
  arrayMove,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

type Page = {
  id: string;
  slug: string;
  title: string;
  status: string;
  locale: string;
  parent_id: string | null;
  sort_order: number;
};

type Node = Page & { children: Node[]; depth: number };

function buildTree(pages: Page[]): Node[] {
  const byId = new Map<string, Node>();
  pages.forEach(p => byId.set(p.id, { ...p, children: [], depth: 0 }));
  const roots: Node[] = [];
  byId.forEach(n => {
    if (n.parent_id && byId.has(n.parent_id)) {
      byId.get(n.parent_id)!.children.push(n);
    } else {
      roots.push(n);
    }
  });
  const sortRec = (arr: Node[]) => {
    arr.sort((a, b) => a.sort_order - b.sort_order || a.title.localeCompare(b.title));
    arr.forEach(n => sortRec(n.children));
  };
  sortRec(roots);
  const setDepth = (arr: Node[], d: number) => {
    arr.forEach(n => { n.depth = d; setDepth(n.children, d + 1); });
  };
  setDepth(roots, 0);
  return roots;
}

/** Lapított, sorrendi lista az éppen látható csomópontokról (összecsukás-tudatosan). */
function flatten(nodes: Node[], expanded: Set<string>, out: Node[] = []): Node[] {
  for (const n of nodes) {
    out.push(n);
    if (expanded.has(n.id) && n.children.length) flatten(n.children, expanded, out);
  }
  return out;
}

export function PageTree({
  pages,
  onEdit,
  locale,
}: {
  pages: Page[];
  onEdit: (p: Page) => void;
  locale: string;
}) {
  const qc = useQueryClient();
  const reorderFn = useServerFn(reorderPages);
  const [expanded, setExpanded] = useState<Set<string>>(() => new Set(pages.map(p => p.id)));
  const [dragging, setDragging] = useState<string | null>(null);

  const filtered = useMemo(() => pages.filter(p => p.locale === locale), [pages, locale]);
  const tree = useMemo(() => buildTree(filtered), [filtered]);
  const visible = useMemo(() => flatten(tree, expanded), [tree, expanded]);

  const mut = useMutation({
    mutationFn: (updates: { id: string; parent_id: string | null; sort_order: number }[]) =>
      reorderFn({ data: { updates } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["cms-pages"] }),
    onError: (e: any) => toast.error(e.message ?? "Mentés sikertelen"),
  });

  const setParent = (node: Node, newParentId: string | null) => {
    if (newParentId === node.id) return;
    if (newParentId && isDescendantFlat(filtered, newParentId, node.id)) {
      toast.error("Nem lehet leszármazott alá tenni.");
      return;
    }
    const newSiblings = (newParentId
      ? findNode(tree, newParentId)?.children ?? []
      : tree).filter(s => s.id !== node.id);
    mut.mutate([{ id: node.id, parent_id: newParentId, sort_order: newSiblings.length }]);
  };

  const toggle = (id: string) => {
    setExpanded(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } }),
    useSensor(TouchSensor, { activationConstraint: { delay: 200, tolerance: 5 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  );

  const handleDragStart = (e: DragStartEvent) => setDragging(String(e.active.id));
  const handleDragCancel = () => setDragging(null);

  const handleDragEnd = (e: DragEndEvent) => {
    setDragging(null);
    const { active, over } = e;
    if (!over) return;
    const activeId = String(active.id);
    const overId = String(over.id);
    if (activeId === overId) return;

    const activeNode = findNode(tree, activeId);
    if (!activeNode) return;

    // 1) "Gyermekké tétel" drop zóna: id = "child:<parentId>"
    if (overId.startsWith("child:")) {
      const newParentId = overId.slice("child:".length);
      if (newParentId === activeId) return;
      if (isDescendantFlat(filtered, newParentId, activeId)) {
        toast.error("Nem lehet leszármazott alá tenni.");
        return;
      }
      setParent(activeNode, newParentId);
      return;
    }

    // 2) Normál sorrend-csere — testvérek között VAGY másik szülő alá testvérnek
    const overNode = findNode(tree, overId);
    if (!overNode) return;

    if (activeNode.parent_id === overNode.parent_id) {
      // testvérek átrendezése
      const siblings = activeNode.parent_id
        ? findNode(tree, activeNode.parent_id)?.children ?? []
        : tree;
      const oldIndex = siblings.findIndex(s => s.id === activeId);
      const newIndex = siblings.findIndex(s => s.id === overId);
      if (oldIndex < 0 || newIndex < 0) return;
      const next = arrayMove(siblings, oldIndex, newIndex);
      mut.mutate(next.map((s, i) => ({ id: s.id, parent_id: activeNode.parent_id, sort_order: i })));
      return;
    }

    // cross-parent reorder: az `overNode` testvérei közé szúrjuk
    if (isDescendantFlat(filtered, overNode.parent_id ?? "", activeId)) {
      toast.error("Nem lehet leszármazott alá tenni.");
      return;
    }
    const targetSiblings = (overNode.parent_id
      ? findNode(tree, overNode.parent_id)?.children ?? []
      : tree).filter(s => s.id !== activeId);
    const insertAt = targetSiblings.findIndex(s => s.id === overId);
    const newOrder = [...targetSiblings];
    newOrder.splice(insertAt >= 0 ? insertAt : newOrder.length, 0, activeNode);
    mut.mutate(newOrder.map((s, i) => ({ id: s.id, parent_id: overNode.parent_id, sort_order: i })));
  };

  if (!tree.length) {
    return <div className="text-sm text-muted-foreground p-4">Nincs oldal ezen a nyelven.</div>;
  }

  return (
    <Card className="p-2 sm:p-3">
      <div className="text-xs text-muted-foreground px-2 pb-2">
        Húzd a <GripVertical className="inline h-3 w-3" /> ikont a sorrendhez. Dobd egy másik szülő testvére mellé, vagy a „↳ alá" zónába, hogy gyermekké tedd.
      </div>
      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragStart={handleDragStart}
        onDragEnd={handleDragEnd}
        onDragCancel={handleDragCancel}
      >
        <SortableContext items={visible.map(n => n.id)} strategy={verticalListSortingStrategy}>
          <div className="space-y-px">
            {visible.map(node => (
              <SortableRow
                key={node.id}
                node={node}
                expanded={expanded}
                toggle={toggle}
                onEdit={onEdit}
                setParent={setParent}
                allPages={filtered}
                isDragging={dragging !== null && dragging !== node.id}
              />
            ))}
          </div>
        </SortableContext>
      </DndContext>
    </Card>
  );
}

function SortableRow({
  node,
  expanded,
  toggle,
  onEdit,
  setParent,
  allPages,
  isDragging: othersDragging,
}: {
  node: Node;
  expanded: Set<string>;
  toggle: (id: string) => void;
  onEdit: (p: Page) => void;
  setParent: (node: Node, newParentId: string | null) => void;
  allPages: Page[];
  isDragging: boolean;
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: node.id });
  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  const { setNodeRef: setChildRef, isOver: childIsOver } = useDroppable({ id: `child:${node.id}` });

  return (
    <div ref={setNodeRef} style={style}>
      <div
        className="flex items-center gap-1 sm:gap-2 py-1.5 border-b last:border-b-0"
        style={{ paddingLeft: `${node.depth * 16 + 4}px` }}
      >
        <button
          {...attributes}
          {...listeners}
          className="p-1 hover:bg-muted rounded shrink-0 cursor-grab active:cursor-grabbing touch-none"
          aria-label="Mozgatás"
        >
          <GripVertical className="h-4 w-4 text-muted-foreground" />
        </button>
        {node.children.length ? (
          <button onClick={() => toggle(node.id)} className="p-1 hover:bg-muted rounded shrink-0" aria-label="Kibont/összecsuk">
            {expanded.has(node.id) ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
          </button>
        ) : (
          <span className="w-6 shrink-0" />
        )}
        <div className="min-w-0 flex-1">
          <div className="text-sm font-medium truncate">{node.title}</div>
          <div className="text-[11px] text-muted-foreground truncate">/{node.slug} · {node.status}</div>
        </div>
        <div className="flex items-center gap-1 shrink-0">
          {othersDragging && (
            <div
              ref={setChildRef}
              className={`h-8 px-2 text-xs border rounded flex items-center gap-1 transition-colors ${
                childIsOver ? "bg-primary text-primary-foreground border-primary" : "border-dashed text-muted-foreground"
              }`}
              aria-label="Tedd ide gyermekként"
            >
              <CornerDownRight className="h-3 w-3" /> alá
            </div>
          )}
          <Select
            value={node.parent_id ?? "__root"}
            onValueChange={v => setParent(node, v === "__root" ? null : v)}
          >
            <SelectTrigger className="h-8 w-[110px] text-xs" aria-label="Szülő">
              <SelectValue placeholder="Áthelyez…" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="__root">— Gyökér —</SelectItem>
              {allPages
                .filter(p => p.id !== node.id && !isDescendantFlat(allPages, p.id, node.id))
                .map(p => (
                  <SelectItem key={p.id} value={p.id}>{p.title}</SelectItem>
                ))}
            </SelectContent>
          </Select>
          <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => onEdit(node)} aria-label="Beállítások">
            <Settings className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}

function findNode(nodes: Node[], id: string): Node | null {
  for (const n of nodes) {
    if (n.id === id) return n;
    const f = findNode(n.children, id);
    if (f) return f;
  }
  return null;
}

function isDescendantFlat(all: Page[], candidateId: string, nodeId: string): boolean {
  let cur: string | null = candidateId;
  const seen = new Set<string>();
  while (cur) {
    if (seen.has(cur)) return false;
    seen.add(cur);
    if (cur === nodeId) return true;
    const p = all.find(x => x.id === cur);
    cur = p?.parent_id ?? null;
  }
  return false;
}
