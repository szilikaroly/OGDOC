import { useMemo } from "react";
import { LinkPicker, type LinkPickerValue } from "./link-picker";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Plus, Trash2 } from "lucide-react";

/**
 * Konvenció-alapú link-mező felismerő:
 *  - top-level kulcsok (`url`, `href`, `button_url`, `cta_url`, `ctaHref`, `langHref`)
 *  - tömbök: `ctas`, `links`, `buttons`, `items`, `legal`, `socials`, `rows`, `to`-mezős tömbök
 *  - elemenként `url` VAGY `href` VAGY `to` link mező + opcionális `label` és `open_in_new_tab`
 */

const TOP_LEVEL_LINK_KEYS = ["url", "href", "to", "button_url", "cta_url", "ctaHref", "langHref"] as const;
const ARRAY_LINK_KEYS = ["ctas", "links", "buttons", "items", "legal", "socials", "rows"] as const;

type Props = {
  content: any;
  onChange: (next: any) => void;
  locale?: string;
};

/** Megőrzi az eredeti kulcsot (`url`/`href`/`to`), csak az értéket cseréli. */
function pickLinkKey(item: any): "url" | "href" | "to" {
  if ("href" in (item ?? {})) return "href";
  if ("to" in (item ?? {})) return "to";
  return "url";
}

function getLinkValue(item: any): string | null {
  if (!item) return null;
  return item.url ?? item.href ?? item.to ?? null;
}

export function BlockLinkEditor({ content, onChange, locale }: Props) {
  const obj = useMemo(() => (content && typeof content === "object" ? content : {}), [content]);

  const topLinks = TOP_LEVEL_LINK_KEYS.filter((k) => k in obj);
  const arrayLinks = ARRAY_LINK_KEYS.filter((k) => Array.isArray(obj[k]) && (obj[k] as any[]).every(it => it && typeof it === "object"));

  if (topLinks.length === 0 && arrayLinks.length === 0) return null;

  const setTop = (key: string, v: LinkPickerValue) => {
    onChange({
      ...obj,
      [key]: v.url ?? null,
      ...(v.page_id !== undefined ? { page_id: v.page_id } : {}),
      ...(v.open_in_new_tab !== undefined ? { open_in_new_tab: v.open_in_new_tab } : {}),
    });
  };

  const setArrayItem = (arrKey: string, idx: number, patch: any) => {
    const next = [...(obj[arrKey] as any[])];
    next[idx] = { ...next[idx], ...patch };
    onChange({ ...obj, [arrKey]: next });
  };

  const addArrayItem = (arrKey: string) => {
    const arr = obj[arrKey] as any[];
    const linkKey = arr.length > 0 ? pickLinkKey(arr[0]) : "url";
    const seed: any = { label: "Új elem", [linkKey]: "" };
    onChange({ ...obj, [arrKey]: [...arr, seed] });
  };

  const removeArrayItem = (arrKey: string, idx: number) => {
    const next = (obj[arrKey] as any[]).filter((_, i) => i !== idx);
    onChange({ ...obj, [arrKey]: next });
  };

  return (
    <div className="space-y-4 border rounded p-3 bg-muted/30">
      <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Linkek</div>

      {topLinks.map((key) => (
        <div key={key} className="space-y-1">
          <Label className="text-xs">{key}</Label>
          <LinkPicker
            value={{
              url: obj[key],
              page_id: obj.page_id ?? null,
              open_in_new_tab: obj.open_in_new_tab,
            }}
            onChange={(v) => setTop(key, v)}
            locale={locale}
          />
        </div>
      ))}

      {arrayLinks.map((arrKey) => (
        <div key={arrKey} className="space-y-2">
          <div className="flex items-center justify-between">
            <Label className="text-xs">{arrKey} ({(obj[arrKey] as any[]).length})</Label>
            <Button type="button" size="sm" variant="ghost" onClick={() => addArrayItem(arrKey)}>
              <Plus className="h-3 w-3 mr-1" />Új
            </Button>
          </div>
          {(obj[arrKey] as any[]).map((item, idx) => {
            const linkKey = pickLinkKey(item);
            const linkVal = getLinkValue(item);
            return (
              <div key={idx} className="border rounded p-2 space-y-2 bg-background">
                <div className="flex items-center gap-2">
                  <Input
                    value={item.label ?? item.title ?? item.name ?? ""}
                    onChange={(e) => setArrayItem(arrKey, idx, { label: e.target.value })}
                    placeholder="Felirat"
                    className="h-8"
                  />
                  <Button type="button" size="icon" variant="ghost" className="h-8 w-8" onClick={() => removeArrayItem(arrKey, idx)}>
                    <Trash2 className="h-3.5 w-3.5 text-destructive" />
                  </Button>
                </div>
                <LinkPicker
                  value={{
                    url: linkVal,
                    page_id: item.page_id ?? null,
                    open_in_new_tab: item.open_in_new_tab ?? (item.external as boolean | undefined),
                  }}
                  onChange={(v) => setArrayItem(arrKey, idx, {
                    [linkKey]: v.url ?? null,
                    page_id: v.page_id ?? null,
                    open_in_new_tab: v.open_in_new_tab,
                  })}
                  locale={locale}
                />
              </div>
            );
          })}
        </div>
      ))}
    </div>
  );
}
