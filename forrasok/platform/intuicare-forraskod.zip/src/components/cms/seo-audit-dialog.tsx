import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { pageSeoAudit } from "@/lib/cms/cms.functions";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { AlertCircle, AlertTriangle, Info, CheckCircle2 } from "lucide-react";

export function SeoAuditDialog({ pageId, open, onOpenChange }: { pageId: string; open: boolean; onOpenChange: (v: boolean) => void }) {
  const fn = useServerFn(pageSeoAudit);
  const { data, isLoading, refetch, isFetching } = useQuery({
    queryKey: ["cms-seo-audit", pageId],
    queryFn: () => fn({ data: { pageId } }),
    enabled: open,
    staleTime: 30_000,
  });

  const score = data?.score ?? 0;
  const scoreColor = score >= 85 ? "text-green-600" : score >= 60 ? "text-yellow-600" : "text-destructive";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>SEO ellenőrzés</DialogTitle>
        </DialogHeader>
        {isLoading ? (
          <div className="text-sm text-muted-foreground py-8 text-center">Elemzés…</div>
        ) : data ? (
          <div className="space-y-4">
            <div className="flex items-center gap-4 border rounded-lg p-4">
              <div className={`text-4xl font-bold ${scoreColor}`}>{score}</div>
              <div className="text-xs text-muted-foreground">
                <div>{data.page.title || <em>(nincs cím)</em>}</div>
                <div>/{data.page.slug} · {data.page.locale} · {data.page.status}</div>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-2 text-center text-xs">
              <Stat label="Blokk" v={data.stats.blocks} />
              <Stat label="Szó" v={data.stats.wordCount} />
              <Stat label="H1" v={data.stats.h1Count} good={data.stats.h1Count === 1} />
              <Stat label="Kép" v={data.stats.totalImages} />
              <Stat label="Alt nélkül" v={data.stats.imagesWithoutAlt} good={data.stats.imagesWithoutAlt === 0} />
              <Stat label="Belső link" v={data.stats.internalLinks} />
            </div>
            <div className="space-y-1.5">
              {data.issues.length === 0 ? (
                <div className="flex items-center gap-2 text-sm text-green-600">
                  <CheckCircle2 className="h-4 w-4" /> Nincsenek észlelt problémák.
                </div>
              ) : (
                data.issues.map((i, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-sm border rounded p-2">
                    {i.level === "error" && <AlertCircle className="h-4 w-4 text-destructive shrink-0 mt-0.5" />}
                    {i.level === "warn" && <AlertTriangle className="h-4 w-4 text-yellow-600 shrink-0 mt-0.5" />}
                    {i.level === "info" && <Info className="h-4 w-4 text-muted-foreground shrink-0 mt-0.5" />}
                    <span>{i.msg}</span>
                  </div>
                ))
              )}
            </div>
          </div>
        ) : null}
        <DialogFooter className="flex-col-reverse sm:flex-row gap-2">
          <Button variant="ghost" onClick={() => onOpenChange(false)} className="min-h-11">Bezár</Button>
          <Button variant="outline" onClick={() => refetch()} disabled={isFetching} className="min-h-11">
            {isFetching ? "Frissítés…" : "Újraellenőrzés"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function Stat({ label, v, good }: { label: string; v: number; good?: boolean }) {
  return (
    <div className="border rounded p-2">
      <div className={`text-lg font-semibold ${good === true ? "text-green-600" : good === false ? "text-destructive" : ""}`}>{v}</div>
      <div className="text-[10px] uppercase tracking-wide text-muted-foreground">{label}</div>
    </div>
  );
}
