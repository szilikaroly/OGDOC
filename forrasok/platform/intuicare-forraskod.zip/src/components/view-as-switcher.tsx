import { Eye } from "lucide-react";
import { useViewAs, VIEW_AS_LABELS, type ViewAsMode } from "@/hooks/use-view-as";
import { usePermissions } from "@/hooks/use-permissions";
import { cn } from "@/lib/utils";

const MODES: ViewAsMode[] = ["self", "orvos", "noverkereszt", "paciens"];

export function ViewAsSwitcher() {
  const { mode, setMode, isSimulating } = useViewAs();
  const { canReal, loading } = usePermissions();

  // Only admins (tenant or higher) can switch UI views.
  if (loading) return null;
  if (!canReal("manage_tenant")) return null;

  return (
    <div className="flex items-center gap-2">
      <Eye
        className={cn(
          "size-3.5 shrink-0",
          isSimulating ? "text-warning" : "text-muted-foreground",
        )}
      />
      <select
        value={mode}
        onChange={(e) => setMode(e.target.value as ViewAsMode)}
        title="Nézet váltása (csak UI szimuláció)"
        className={cn(
          "h-8 text-xs font-medium bg-card border border-border rounded-md px-2 focus:outline-none focus:ring-1 focus:ring-primary",
          isSimulating && "border-warning text-warning",
        )}
      >
        {MODES.map((m) => (
          <option key={m} value={m}>
            {VIEW_AS_LABELS[m]}
          </option>
        ))}
      </select>
    </div>
  );
}
