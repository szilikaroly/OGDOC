import { useCallback, useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { humanizeError } from "@/lib/humanize-error";
import { useTranslation } from "react-i18next";
import { Plus, Trash2, ChevronDown, ChevronRight, Layers, Shield, Info, Copy } from "lucide-react";
import { cn } from "@/lib/utils";
import { DutyLineEligibility } from "./duty-line-eligibility";

type Floor = { id: string; site_id: string; tenant_id: string; szint: string; megnevezes: string | null; sorrend: number; aktiv: boolean };

type DutyLine = {
  id: string;
  tenant_id: string;
  site_id: string;
  nev: string;
  kod: string | null;
  szerep_tipus: "nappali_ugyelet" | "ejszakai_ugyelet" | "hatter_ugyelet" | "keszenlet" | "muteti_ugyelet" | "egyeb";
  primary_org_unit_id: string | null;
  letszam: number;
  napok: number[];
  kezd_ido: string | null;
  veg_ido: string | null;
  unnepnap_uzemel: boolean;
  aktiv: boolean;
  sorrend: number;
};

type DutyCoverage = { duty_line_id: string; org_unit_id: string; kotelezo: boolean };

const SZEREP_OPTIONS: Array<{ value: DutyLine["szerep_tipus"]; label: string }> = [
  { value: "nappali_ugyelet", label: "Nappali ügyelet" },
  { value: "ejszakai_ugyelet", label: "Éjszakai ügyelet" },
  { value: "hatter_ugyelet", label: "Háttér-ügyelet" },
  { value: "keszenlet", label: "Készenlét" },
  { value: "muteti_ugyelet", label: "Műtéti ügyelet" },
  { value: "egyeb", label: "Egyéb" },
];

const NAPOK = [
  { v: 1, n: "H" }, { v: 2, n: "K" }, { v: 3, n: "Sze" },
  { v: 4, n: "Cs" }, { v: 5, n: "P" }, { v: 6, n: "Szo" }, { v: 7, n: "V" },
];

export function SiteDutyPanel(props: {
  siteId: string;
  tenantId: string;
  isAdmin: boolean;
  orgUnits: Array<{ id: string; nev: string; tipus: string }>;
}) {
  const { t } = useTranslation();
  const { siteId, tenantId, isAdmin, orgUnits } = props;
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [lines, setLines] = useState<DutyLine[]>([]);
  const [floors, setFloors] = useState<Floor[]>([]);
  const [coverage, setCoverage] = useState<DutyCoverage[]>([]);
  const [expandedLineId, setExpandedLineId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const [dl, fl, cov] = await Promise.all([
      supabase.from("duty_lines").select("*").eq("site_id", siteId).order("sorrend").order("nev"),
      supabase.from("floors").select("*").eq("site_id", siteId).order("sorrend").order("szint"),
      supabase.from("duty_line_coverage").select("*"),
    ]);
    setLines((dl.data ?? []) as DutyLine[]);
    setFloors((fl.data ?? []) as Floor[]);
    setCoverage((cov.data ?? []) as DutyCoverage[]);
    setLoading(false);
  }, [siteId]);

  useEffect(() => { if (open) load(); }, [open, load]);

  // ---------- floors ----------
  async function addFloor() {
    const szint = window.prompt("Szint megnevezése (pl. -1, 0, 1, tetőtér)") ?? "";
    if (!szint.trim()) return;
    const meg = window.prompt("Leírás (opcionális, pl. Sürgősségi szint)") ?? "";
    const { error } = await supabase.from("floors").insert({
      tenant_id: tenantId, site_id: siteId, szint: szint.trim(),
      megnevezes: meg.trim() || null, sorrend: floors.length,
    });
    if (error) return toast.error(humanizeError(error, t, { perm: "manage_org" }));
    load();
  }
  async function deleteFloor(f: Floor) {
    if (!window.confirm(`Törlöd: ${f.szint}?`)) return;
    const { error } = await supabase.from("floors").delete().eq("id", f.id);
    if (error) return toast.error(humanizeError(error, t, { perm: "manage_org" }));
    load();
  }

  // ---------- duty lines ----------
  async function addLine() {
    const nev = window.prompt("Ügyeleti sor neve (pl. Belgyógyászat nappali I.)") ?? "";
    if (!nev.trim()) return;
    const { error } = await supabase.from("duty_lines").insert({
      tenant_id: tenantId, site_id: siteId, nev: nev.trim(),
      szerep_tipus: "nappali_ugyelet", letszam: 1,
      napok: [1, 2, 3, 4, 5, 6, 7], unnepnap_uzemel: true, sorrend: lines.length,
    });
    if (error) return toast.error(humanizeError(error, t, { perm: "manage_schedule" }));
    load();
  }
  async function updateLine(id: string, patch: Partial<DutyLine>) {
    const { error } = await supabase.from("duty_lines").update(patch).eq("id", id);
    if (error) return toast.error(humanizeError(error, t, { perm: "manage_schedule" }));
    load();
  }
  async function deleteLine(l: DutyLine) {
    if (!window.confirm(`Törlöd: ${l.nev}?`)) return;
    const { error } = await supabase.from("duty_lines").delete().eq("id", l.id);
    if (error) return toast.error(humanizeError(error, t, { perm: "manage_schedule" }));
    load();
  }
  async function duplicateLine(l: DutyLine) {
    const { id, ...rest } = l as any;
    const payload = {
      ...rest,
      nev: `${l.nev} (másolat)`,
      kod: l.kod ? `${l.kod}_COPY` : null,
      sorrend: lines.length,
    };
    delete payload.created_at;
    delete payload.updated_at;
    const { data: newLine, error } = await supabase.from("duty_lines").insert(payload).select("id").maybeSingle();
    if (error || !newLine) return toast.error(humanizeError(error, t, { perm: "manage_schedule" }));
    // coverage másolása
    const { data: covs } = await supabase.from("duty_line_coverage").select("org_unit_id,kotelezo,tenant_id").eq("duty_line_id", l.id);
    if (covs && covs.length > 0) {
      await supabase.from("duty_line_coverage").insert(
        covs.map((c: any) => ({ ...c, duty_line_id: newLine.id }))
      );
    }
    toast.success(`Másolva: ${l.nev}`);
    load();
  }
  async function toggleCoverage(lineId: string, unitId: string, present: boolean) {
    if (present) {
      const { error } = await supabase.from("duty_line_coverage")
        .delete().eq("duty_line_id", lineId).eq("org_unit_id", unitId);
      if (error) return toast.error(humanizeError(error, t, { perm: "manage_schedule" }));
    } else {
      const { error } = await supabase.from("duty_line_coverage").insert({
        tenant_id: tenantId, duty_line_id: lineId, org_unit_id: unitId, kotelezo: true,
      });
      if (error) return toast.error(humanizeError(error, t, { perm: "manage_schedule" }));
    }
    load();
  }

  const coverageByLine = useMemo(() => {
    const m = new Map<string, Set<string>>();
    coverage.forEach(c => {
      if (!m.has(c.duty_line_id)) m.set(c.duty_line_id, new Set());
      m.get(c.duty_line_id)!.add(c.org_unit_id);
    });
    return m;
  }, [coverage]);

  return (
    <div className="mt-2 border-t border-border pt-2">
      <button type="button"
        onClick={() => setOpen(!open)}
        className="flex items-center gap-1.5 text-xs font-mono font-semibold uppercase text-muted-foreground hover:text-foreground">
        {open ? <ChevronDown className="size-3.5" /> : <ChevronRight className="size-3.5" />}
        <Shield className="size-3.5" />
        Ügyeleti sorok & szintek
      </button>
      {open && (
        <div className="mt-2 space-y-3">
          <div className="text-[10px] text-muted-foreground flex items-start gap-1 bg-secondary/30 rounded p-1.5">
            <Info className="size-3 mt-0.5 shrink-0" />
            <span>Telephely-szintű ügyeleti pozíciók. Példa: nappali 2 fő (osztály), éjjel 1 fő, plusz 1 hívható háttér a műtőhöz. Részletek: <a href="/admin/szervezet-sugo" className="underline">kézikönyv</a>.</span>
          </div>
          {loading && <div className="text-xs text-muted-foreground">Betöltés…</div>}

          {/* Floors */}
          <div className="rounded-lg border bg-secondary/20 p-2">
            <div className="flex items-center justify-between mb-1">
              <div className="text-xs font-semibold flex items-center gap-1.5">
                <Layers className="size-3.5" /> Szintek / emeletek
              </div>
              {isAdmin && (
                <button type="button" onClick={addFloor}
                  className="text-xs px-2 py-0.5 rounded bg-primary text-primary-foreground inline-flex items-center gap-1">
                  <Plus className="size-3" /> Új szint
                </button>
              )}
            </div>
            {floors.length === 0 ? (
              <div className="text-xs text-muted-foreground italic">Nincs szint rögzítve.</div>
            ) : (
              <ul className="space-y-1">
                {floors.map(f => (
                  <li key={f.id} className="flex items-center justify-between text-xs bg-card rounded px-2 py-1">
                    <span><b>{f.szint}</b>{f.megnevezes ? ` · ${f.megnevezes}` : ""}</span>
                    {isAdmin && (
                      <button type="button" onClick={() => deleteFloor(f)}
                        aria-label="Törlés" className="text-muted-foreground hover:text-warning">
                        <Trash2 className="size-3" />
                      </button>
                    )}
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* Duty lines */}
          <div className="rounded-lg border bg-secondary/20 p-2">
            <div className="flex items-center justify-between mb-1">
              <div className="text-xs font-semibold flex items-center gap-1.5">
                <Shield className="size-3.5" /> Ügyeleti sorok
              </div>
              {isAdmin && (
                <button type="button" onClick={addLine}
                  className="text-xs px-2 py-0.5 rounded bg-primary text-primary-foreground inline-flex items-center gap-1">
                  <Plus className="size-3" /> Új sor
                </button>
              )}
            </div>
            {lines.length === 0 ? (
              <div className="text-xs text-muted-foreground italic">
                Nincs ügyeleti sor. Pl. „nappali (2 fő)", „éjszakai (1 fő)", „telephelyi háttér (1 fő)".
              </div>
            ) : (
              <ul className="space-y-1.5">
                {lines.map(l => {
                  const expanded = expandedLineId === l.id;
                  const covSet = coverageByLine.get(l.id) ?? new Set<string>();
                  return (
                    <li key={l.id} className="bg-card rounded border border-border">
                      <div className="flex items-center gap-2 p-2 text-xs">
                        <button type="button" onClick={() => setExpandedLineId(expanded ? null : l.id)}>
                          {expanded ? <ChevronDown className="size-3.5" /> : <ChevronRight className="size-3.5" />}
                        </button>
                        <input className="flex-1 bg-transparent font-medium" value={l.nev} readOnly={!isAdmin}
                          onChange={(e) => setLines(prev => prev.map(x => x.id === l.id ? { ...x, nev: e.target.value } : x))}
                          onBlur={() => updateLine(l.id, { nev: l.nev })} />
                        <select className="px-1.5 py-0.5 rounded border bg-background text-xs"
                          value={l.szerep_tipus} disabled={!isAdmin}
                          onChange={(e) => updateLine(l.id, { szerep_tipus: e.target.value as DutyLine["szerep_tipus"] })}>
                          {SZEREP_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                        </select>
                        <label className="flex items-center gap-1 whitespace-nowrap">
                          fő
                          <input type="number" min={1} max={20} value={l.letszam} disabled={!isAdmin}
                            onChange={(e) => updateLine(l.id, { letszam: Number(e.target.value) })}
                            className="w-12 px-1 py-0.5 rounded border bg-background" />
                        </label>
                        {isAdmin && (
                          <>
                            <button type="button" onClick={() => duplicateLine(l)}
                              className="text-muted-foreground hover:text-primary" aria-label="Duplikálás" title="Sor másolása (coverage-kel)">
                              <Copy className="size-3.5" />
                            </button>
                            <button type="button" onClick={() => deleteLine(l)}
                              className="text-muted-foreground hover:text-warning" aria-label="Törlés">
                              <Trash2 className="size-3.5" />
                            </button>
                          </>
                        )}
                      </div>
                      {expanded && (
                        <div className="px-2 pb-2 space-y-2 text-xs">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-muted-foreground">Napok:</span>
                            {NAPOK.map(d => {
                              const on = l.napok.includes(d.v);
                              return (
                                <button key={d.v} type="button" disabled={!isAdmin}
                                  onClick={() => updateLine(l.id, {
                                    napok: on ? l.napok.filter(x => x !== d.v) : [...l.napok, d.v].sort()
                                  })}
                                  className={cn("px-2 py-0.5 rounded border text-[10px] font-mono",
                                    on ? "bg-primary text-primary-foreground border-primary" : "bg-secondary")}>
                                  {d.n}
                                </button>
                              );
                            })}
                          </div>
                          <div className="flex items-center gap-3 flex-wrap">
                            <label className="flex items-center gap-1">
                              Kezdés:
                              <input type="time" value={l.kezd_ido ?? ""} disabled={!isAdmin}
                                onChange={(e) => updateLine(l.id, { kezd_ido: e.target.value || null })}
                                className="px-1.5 py-0.5 rounded border bg-background" />
                            </label>
                            <label className="flex items-center gap-1">
                              Vége:
                              <input type="time" value={l.veg_ido ?? ""} disabled={!isAdmin}
                                onChange={(e) => updateLine(l.id, { veg_ido: e.target.value || null })}
                                className="px-1.5 py-0.5 rounded border bg-background" />
                            </label>
                            <label className="flex items-center gap-1">
                              <input type="checkbox" checked={l.unnepnap_uzemel} disabled={!isAdmin}
                                onChange={(e) => updateLine(l.id, { unnepnap_uzemel: e.target.checked })} />
                              Ünnepnapon él
                            </label>
                            <label className="flex items-center gap-1">
                              <input type="checkbox" checked={l.aktiv} disabled={!isAdmin}
                                onChange={(e) => updateLine(l.id, { aktiv: e.target.checked })} />
                              Aktív
                            </label>
                          </div>
                          <div>
                            <div className="text-muted-foreground mb-1">Lefedett ellátóhelyek (felelősségi kör):</div>
                            {orgUnits.length === 0 ? (
                              <div className="italic text-muted-foreground">Nincs ellátóhely a telephelyen.</div>
                            ) : (
                              <div className="flex flex-wrap gap-1">
                                {orgUnits.map(u => {
                                  const on = covSet.has(u.id);
                                  return (
                                    <button key={u.id} type="button" disabled={!isAdmin}
                                      onClick={() => toggleCoverage(l.id, u.id, on)}
                                      className={cn("px-2 py-0.5 rounded-full border text-[10px]",
                                        on ? "bg-primary text-primary-foreground border-primary" : "bg-secondary")}>
                                      {u.nev}
                                    </button>
                                  );
                                })}
                              </div>
                            )}
                          </div>
                          <DutyLineEligibility dutyLineId={l.id} tenantId={tenantId} isAdmin={isAdmin} />
                        </div>
                      )}
                    </li>
                  );
                })}
              </ul>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
