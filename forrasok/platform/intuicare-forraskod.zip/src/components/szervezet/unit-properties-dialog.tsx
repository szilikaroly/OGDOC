import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { humanizeError } from "@/lib/humanize-error";
import { useTranslation } from "react-i18next";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from "@/components/ui/dialog";
import { Info } from "lucide-react";

export type UnitTipus =
  | "fekvobeteg_osztaly" | "rendelo" | "ambulancia" | "muto" | "kismuto"
  | "ito" | "pito" | "egynapos" | "egyeb";

export type Uzemmod = "folyamatos_24_7" | "rendelesi_ido" | "programozott_nappali" | "muteti_blokk";

const TIPUS_OPTIONS: Array<{ value: UnitTipus; label: string; hint: string }> = [
  { value: "fekvobeteg_osztaly", label: "Fekvőbeteg osztály", hint: "24/7 működés, ágyszám releváns." },
  { value: "ambulancia", label: "Ambulancia", hint: "Rendelési időben üzemel." },
  { value: "rendelo", label: "Rendelő", hint: "Heti rendelési óra szerint." },
  { value: "muto", label: "Műtő", hint: "Műtéti blokkokban; egy műtőt több klinika is használhat." },
  { value: "kismuto", label: "Kisműtő", hint: "Kisebb beavatkozások; blokk-perc tervezhető." },
  { value: "ito", label: "ITO", hint: "Intenzív osztály – folyamatos ügyelet kötelező." },
  { value: "pito", label: "PITO", hint: "Posztoperatív intenzív – 24/7." },
  { value: "egynapos", label: "1-napos sebészet", hint: "Programozott nappali." },
  { value: "egyeb", label: "Egyéb", hint: "Egyedi konfig." },
];

const UZEMMOD_OPTIONS: Array<{ value: Uzemmod; label: string }> = [
  { value: "folyamatos_24_7", label: "Folyamatos 24/7" },
  { value: "rendelesi_ido", label: "Rendelési idő" },
  { value: "programozott_nappali", label: "Programozott nappali" },
  { value: "muteti_blokk", label: "Műtéti blokk" },
];

type Clinic = { id: string; nev: string };
type SharedClinic = { clinic_id: string; szerep: "mukodteto" | "hasznalo" };

export function UnitPropertiesDialog(props: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  mode: "create" | "edit";
  initial: {
    id?: string;
    site_id: string;
    parent_id: string | null;
    tenant_id: string;
    nev?: string;
    tipus?: UnitTipus;
    uzemmod?: Uzemmod | null;
    unnepnap_uzemel?: boolean;
    agyszam?: number | null;
    muto_blokk_perc?: number | null;
    floor_id?: string | null;
  };
  floors: Array<{ id: string; szint: string; megnevezes: string | null }>;
  onSaved: () => void;
}) {
  const { t } = useTranslation();
  const [nev, setNev] = useState(props.initial.nev ?? "");
  const [tipus, setTipus] = useState<UnitTipus>(props.initial.tipus ?? "fekvobeteg_osztaly");
  const [uzemmod, setUzemmod] = useState<Uzemmod | "">((props.initial.uzemmod ?? "") as Uzemmod | "");
  const [unnepnap, setUnnepnap] = useState<boolean>(props.initial.unnepnap_uzemel ?? false);
  const [agyszam, setAgyszam] = useState<string>(props.initial.agyszam?.toString() ?? "");
  const [mutoBlokk, setMutoBlokk] = useState<string>(props.initial.muto_blokk_perc?.toString() ?? "");
  const [floorId, setFloorId] = useState<string>(props.initial.floor_id ?? "");
  const [saving, setSaving] = useState(false);
  const [clinics, setClinics] = useState<Clinic[]>([]);
  const [shared, setShared] = useState<SharedClinic[]>([]);

  useEffect(() => {
    if (!props.open) return;
    setNev(props.initial.nev ?? "");
    setTipus(props.initial.tipus ?? "fekvobeteg_osztaly");
    setUzemmod((props.initial.uzemmod ?? "") as Uzemmod | "");
    setUnnepnap(props.initial.unnepnap_uzemel ?? false);
    setAgyszam(props.initial.agyszam?.toString() ?? "");
    setMutoBlokk(props.initial.muto_blokk_perc?.toString() ?? "");
    setFloorId(props.initial.floor_id ?? "");

    (async () => {
      const { data: c } = await supabase.from("clinics").select("id,nev").order("nev");
      setClinics((c ?? []) as Clinic[]);
      if (props.mode === "edit" && props.initial.id) {
        const { data: d } = await supabase.from("org_unit_departments")
          .select("clinic_id,szerep").eq("org_unit_id", props.initial.id);
        setShared((d ?? []) as SharedClinic[]);
      } else {
        setShared([]);
      }
    })();
  }, [props.open, props.initial, props.mode]);

  const isShareable = tipus === "muto" || tipus === "kismuto" || tipus === "egynapos" || tipus === "ito" || tipus === "pito";

  function toggleShared(clinic_id: string) {
    setShared((prev) => {
      const ex = prev.find(s => s.clinic_id === clinic_id);
      return ex ? prev.filter(s => s.clinic_id !== clinic_id)
                : [...prev, { clinic_id, szerep: "hasznalo" }];
    });
  }
  function setSzerep(clinic_id: string, szerep: SharedClinic["szerep"]) {
    setShared((prev) => prev.map(s => s.clinic_id === clinic_id ? { ...s, szerep } : s));
  }

  async function save() {
    if (!nev.trim()) return toast.error("Adj nevet az ellátóhelynek.");
    setSaving(true);
    const payload = {
      tenant_id: props.initial.tenant_id,
      site_id: props.initial.site_id,
      parent_id: props.initial.parent_id,
      nev: nev.trim(),
      tipus,
      uzemmod: uzemmod || null,
      unnepnap_uzemel: unnepnap,
      agyszam: agyszam ? Number(agyszam) : null,
      muto_blokk_perc: mutoBlokk ? Number(mutoBlokk) : null,
      floor_id: floorId || null,
    };
    const res = props.mode === "create"
      ? await supabase.from("org_units").insert(payload).select("id").maybeSingle()
      : await supabase.from("org_units").update(payload).eq("id", props.initial.id!).select("id").maybeSingle();
    if (res.error) { setSaving(false); return toast.error(humanizeError(res.error, t, { perm: "manage_org" })); }
    const unitId = res.data?.id ?? props.initial.id!;

    // Sync shared clinics
    if (isShareable) {
      await supabase.from("org_unit_departments").delete().eq("org_unit_id", unitId);
      if (shared.length > 0) {
        const rows = shared.map(s => ({
          tenant_id: props.initial.tenant_id, org_unit_id: unitId,
          clinic_id: s.clinic_id, szerep: s.szerep,
        }));
        const { error } = await supabase.from("org_unit_departments").insert(rows);
        if (error) { setSaving(false); return toast.error(humanizeError(error, t, { perm: "manage_org" })); }
      }
    }

    setSaving(false);
    toast.success("Mentve.");
    props.onSaved();
    props.onOpenChange(false);
  }

  const tipusHint = TIPUS_OPTIONS.find(o => o.value === tipus)?.hint;

  return (
    <Dialog open={props.open} onOpenChange={props.onOpenChange}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{props.mode === "create" ? "Új ellátóhely" : "Ellátóhely szerkesztése"}</DialogTitle>
          <DialogDescription className="text-xs">
            Itt állítható be az ellátóhely típusa, üzemmódja és — ha több klinika közösen használja (pl. műtő) — a megosztás.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div>
            <label className="text-xs font-medium">Név</label>
            <input className="w-full mt-1 px-2 py-1.5 rounded-md border bg-background text-sm"
              value={nev} onChange={(e) => setNev(e.target.value)} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium">Típus</label>
              <select className="w-full mt-1 px-2 py-1.5 rounded-md border bg-background text-sm"
                value={tipus} onChange={(e) => setTipus(e.target.value as UnitTipus)}>
                {TIPUS_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
              </select>
              {tipusHint && (
                <div className="mt-1 text-[10px] text-muted-foreground flex items-start gap-1">
                  <Info className="size-3 mt-0.5 shrink-0" />{tipusHint}
                </div>
              )}
            </div>
            <div>
              <label className="text-xs font-medium">Üzemmód</label>
              <select className="w-full mt-1 px-2 py-1.5 rounded-md border bg-background text-sm"
                value={uzemmod} onChange={(e) => setUzemmod(e.target.value as Uzemmod | "")}>
                <option value="">(típusból automatikusan)</option>
                {UZEMMOD_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label className="text-xs font-medium">Szint / emelet</label>
            <select className="w-full mt-1 px-2 py-1.5 rounded-md border bg-background text-sm"
              value={floorId} onChange={(e) => setFloorId(e.target.value)}>
              <option value="">(besorolatlan)</option>
              {props.floors.map(f => (
                <option key={f.id} value={f.id}>
                  {f.szint}{f.megnevezes ? ` – ${f.megnevezes}` : ""}
                </option>
              ))}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium">Ágyszám</label>
              <input type="number" min={0} className="w-full mt-1 px-2 py-1.5 rounded-md border bg-background text-sm"
                value={agyszam} onChange={(e) => setAgyszam(e.target.value)} />
            </div>
            <div>
              <label className="text-xs font-medium">Műtéti blokk (perc)</label>
              <input type="number" min={0} className="w-full mt-1 px-2 py-1.5 rounded-md border bg-background text-sm"
                value={mutoBlokk} onChange={(e) => setMutoBlokk(e.target.value)} />
            </div>
          </div>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={unnepnap} onChange={(e) => setUnnepnap(e.target.checked)} />
            Ünnepnapon üzemel
          </label>

          {isShareable && (
            <div className="border-t pt-3">
              <div className="text-xs font-medium mb-1">Megosztó klinikák</div>
              <div className="text-[10px] text-muted-foreground mb-2 flex items-start gap-1">
                <Info className="size-3 mt-0.5 shrink-0" />
                Egy ellátóhelyet (pl. közös műtő) több klinika is használhat. Jelöld be, ki használja, és kinek a működtetésében van.
              </div>
              {clinics.length === 0 ? (
                <div className="text-xs text-muted-foreground italic">Nincs klinika.</div>
              ) : (
                <ul className="space-y-1 max-h-40 overflow-y-auto">
                  {clinics.map(c => {
                    const ex = shared.find(s => s.clinic_id === c.id);
                    return (
                      <li key={c.id} className="flex items-center justify-between gap-2 text-xs bg-secondary/30 rounded px-2 py-1">
                        <label className="flex items-center gap-2 flex-1">
                          <input type="checkbox" checked={!!ex} onChange={() => toggleShared(c.id)} />
                          {c.nev}
                        </label>
                        {ex && (
                          <select value={ex.szerep} onChange={(e) => setSzerep(c.id, e.target.value as SharedClinic["szerep"])}
                            className="px-1.5 py-0.5 rounded border bg-background text-[11px]">
                            <option value="mukodteto">Működtető</option>
                            <option value="hasznalo">Használó</option>
                          </select>
                        )}
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          )}
        </div>
        <DialogFooter>
          <button type="button" className="px-3 py-1.5 text-sm rounded-md border"
            onClick={() => props.onOpenChange(false)} disabled={saving}>Mégse</button>
          <button type="button" className="px-3 py-1.5 text-sm rounded-md bg-primary text-primary-foreground"
            onClick={save} disabled={saving}>{saving ? "Mentés…" : "Mentés"}</button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
