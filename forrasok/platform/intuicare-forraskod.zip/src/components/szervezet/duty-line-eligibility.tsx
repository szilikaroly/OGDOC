import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { humanizeError } from "@/lib/humanize-error";
import { useTranslation } from "react-i18next";
import { Plus, Trash2, UserCheck, Info } from "lucide-react";

type FoglalkozasTipus = "orvos" | "szakdolgozo" | "egyeb";
type Row = {
  id: string;
  duty_line_id: string;
  user_id: string | null;
  foglalkozas_tipus: FoglalkozasTipus | null;
  staff_role_id: string | null;
  prioritas: number;
};
type Profile = { id: string; teljes_nev: string; foglalkozas_tipus: string | null };
type StaffRole = { id: string; nev: string };

const FOGLALKOZAS_OPTIONS: Array<{ v: FoglalkozasTipus; l: string }> = [
  { v: "orvos", l: "Orvos" },
  { v: "szakdolgozo", l: "Szakdolgozó" },
  { v: "egyeb", l: "Egyéb" },
];

export function DutyLineEligibility(props: {
  dutyLineId: string;
  tenantId: string;
  isAdmin: boolean;
}) {
  const { t } = useTranslation();
  const [rows, setRows] = useState<Row[]>([]);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [roles, setRoles] = useState<StaffRole[]>([]);
  const [loading, setLoading] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    const [r, p, sr] = await Promise.all([
      supabase.from("duty_line_eligibility").select("*").eq("duty_line_id", props.dutyLineId).order("prioritas"),
      supabase.from("profiles").select("id,teljes_nev,foglalkozas_tipus").order("teljes_nev"),
      supabase.from("staff_roles").select("id,nev").order("sorrend"),
    ]);
    setRows((r.data ?? []) as Row[]);
    setProfiles((p.data ?? []) as Profile[]);
    setRoles((sr.data ?? []) as StaffRole[]);
    setLoading(false);
  }, [props.dutyLineId]);

  useEffect(() => { load(); }, [load]);

  async function addRow(kind: "user" | "foglalkozas" | "role") {
    const payload = {
      tenant_id: props.tenantId,
      duty_line_id: props.dutyLineId,
      prioritas: rows.length,
      user_id: kind === "user" ? profiles[0]?.id ?? null : null,
      foglalkozas_tipus: kind === "foglalkozas" ? ("orvos" as FoglalkozasTipus) : null,
      staff_role_id: kind === "role" ? roles[0]?.id ?? null : null,
    };
    const { error } = await supabase.from("duty_line_eligibility").insert(payload);
    if (error) return toast.error(humanizeError(error, t, { perm: "manage_schedule" }));
    load();
  }
  async function updateRow(id: string, patch: Partial<Row>) {
    const { error } = await supabase.from("duty_line_eligibility").update(patch).eq("id", id);
    if (error) return toast.error(humanizeError(error, t, { perm: "manage_schedule" }));
    load();
  }
  async function deleteRow(id: string) {
    const { error } = await supabase.from("duty_line_eligibility").delete().eq("id", id);
    if (error) return toast.error(humanizeError(error, t, { perm: "manage_schedule" }));
    load();
  }

  return (
    <div className="border-t pt-2 mt-2">
      <div className="flex items-center justify-between mb-1">
        <div className="text-[11px] font-semibold flex items-center gap-1.5">
          <UserCheck className="size-3.5" /> Ki ügyelhet (eligibility)
        </div>
        {props.isAdmin && (
          <div className="flex gap-1">
            <button type="button" onClick={() => addRow("foglalkozas")}
              className="text-[10px] px-1.5 py-0.5 rounded bg-secondary hover:bg-secondary/70">
              <Plus className="size-2.5 inline" /> foglalkozás
            </button>
            <button type="button" onClick={() => addRow("role")}
              className="text-[10px] px-1.5 py-0.5 rounded bg-secondary hover:bg-secondary/70">
              <Plus className="size-2.5 inline" /> munkakör
            </button>
            <button type="button" onClick={() => addRow("user")}
              className="text-[10px] px-1.5 py-0.5 rounded bg-secondary hover:bg-secondary/70">
              <Plus className="size-2.5 inline" /> személy
            </button>
          </div>
        )}
      </div>
      <div className="text-[10px] text-muted-foreground mb-1 flex items-start gap-1">
        <Info className="size-3 mt-0.5 shrink-0" />
        Az alacsonyabb prioritás-érték előbb kerül kiosztásra. Ha üres a lista, a beosztómotor a coverage szerinti összes alkalmast figyelembe veszi.
      </div>
      {loading ? <div className="text-[10px] text-muted-foreground">Betöltés…</div> :
        rows.length === 0 ? (
          <div className="text-[10px] text-muted-foreground italic">Nincs szűkítés (mindenki alkalmas).</div>
        ) : (
          <ul className="space-y-1">
            {rows.map(r => (
              <li key={r.id} className="flex items-center gap-1 text-[11px] bg-background rounded border px-1.5 py-0.5">
                {r.foglalkozas_tipus !== null && (
                  <select disabled={!props.isAdmin} value={r.foglalkozas_tipus}
                    onChange={(e) => updateRow(r.id, { foglalkozas_tipus: e.target.value as FoglalkozasTipus })}
                    className="px-1 py-0.5 rounded border bg-background text-[11px]">
                    {FOGLALKOZAS_OPTIONS.map(o => <option key={o.v} value={o.v}>{o.l}</option>)}
                  </select>
                )}
                {r.staff_role_id !== null && (
                  <select disabled={!props.isAdmin} value={r.staff_role_id}
                    onChange={(e) => updateRow(r.id, { staff_role_id: e.target.value })}
                    className="px-1 py-0.5 rounded border bg-background text-[11px]">
                    {roles.map(o => <option key={o.id} value={o.id}>{o.nev}</option>)}
                  </select>
                )}
                {r.user_id !== null && (
                  <select disabled={!props.isAdmin} value={r.user_id}
                    onChange={(e) => updateRow(r.id, { user_id: e.target.value })}
                    className="px-1 py-0.5 rounded border bg-background text-[11px] flex-1">
                    {profiles.map(p => <option key={p.id} value={p.id}>{p.teljes_nev}</option>)}
                  </select>
                )}
                <label className="flex items-center gap-0.5 ml-auto whitespace-nowrap">
                  prio
                  <input type="number" min={0} value={r.prioritas} disabled={!props.isAdmin}
                    onChange={(e) => updateRow(r.id, { prioritas: Number(e.target.value) })}
                    className="w-10 px-1 py-0.5 rounded border bg-background text-[11px]" />
                </label>
                {props.isAdmin && (
                  <button type="button" onClick={() => deleteRow(r.id)}
                    className="text-muted-foreground hover:text-warning">
                    <Trash2 className="size-3" />
                  </button>
                )}
              </li>
            ))}
          </ul>
        )
      }
    </div>
  );
}
