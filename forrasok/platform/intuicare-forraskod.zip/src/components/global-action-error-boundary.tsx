/**
 * Globális kattintás- és futásidejű hibafigyelő.
 *
 * Feladatai:
 *  1. Ha egy `<a>` linknek nincs értelmes href-je (üres, "#", "javascript:")
 *     és nincs saját onClick handler-e, kattintáskor egy toast jelzi, hogy
 *     a link jelenleg nem működik. Így a felhasználó láthatja, hogy miért
 *     nem történt semmi.
 *  2. window `error` és `unhandledrejection` eseményekre toast.error hívást ad,
 *     kivéve a fejlesztői-zaj (ResizeObserver stb.) hibákat.
 */
import { useEffect } from "react";
import { toast } from "sonner";

const IGNORED_ERROR_PATTERNS = [
  /ResizeObserver loop/i,
  /Non-Error promise rejection captured/i,
  /Loading chunk \d+ failed/i, // külön kezeljük lentebb
];

function isIgnored(msg: string) {
  return IGNORED_ERROR_PATTERNS.some((r) => r.test(msg));
}

function describeTarget(el: Element | null): string {
  if (!el) return "elem";
  const label =
    el.getAttribute("aria-label") ||
    el.getAttribute("title") ||
    (el.textContent ?? "").trim().slice(0, 40);
  return label || el.tagName.toLowerCase();
}

export function GlobalActionErrorBoundary() {
  useEffect(() => {
    // ── 1. Click-delegáció hibás linkekre ──────────────────────────────
    const onClickCapture = (e: MouseEvent) => {
      const target = e.target as Element | null;
      const anchor = target?.closest?.("a") as HTMLAnchorElement | null;
      if (!anchor) return;

      // Ha van szabályos href és nem a "#" placeholder → hagyjuk.
      const rawHref = anchor.getAttribute("href");
      const hasOnClick =
        anchor.hasAttribute("data-has-handler") ||
        (anchor.onclick != null);

      const isPlaceholder =
        !rawHref ||
        rawHref.trim() === "" ||
        rawHref.trim() === "#" ||
        rawHref.trim().toLowerCase().startsWith("javascript:");

      if (isPlaceholder && !hasOnClick) {
        e.preventDefault();
        toast.error(
          `Ez a link jelenleg nem működik: „${describeTarget(anchor)}"`,
          { description: "Nincs hozzárendelt cél. Szólj a szerkesztőnek." },
        );
      }
    };

    // ── 2. Gombok, amikre kattintáskor kivétel dobódik ─────────────────
    const onError = (e: ErrorEvent) => {
      const msg = e.message || e.error?.message || "Ismeretlen hiba";
      if (isIgnored(msg)) return;
      // dinamikus import chunk hiba → külön üzenet
      if (/Failed to fetch dynamically imported module/i.test(msg)) {
        toast.error("Új verzió elérhető", {
          description: "Frissítsd az oldalt (Ctrl/Cmd+R).",
        });
        return;
      }
      toast.error("Hiba történt", { description: msg.slice(0, 200) });
    };

    const onRejection = (e: PromiseRejectionEvent) => {
      const reason: any = e.reason;
      const msg =
        typeof reason === "string"
          ? reason
          : reason?.message || "Ismeretlen hiba (promise)";
      if (isIgnored(msg)) return;
      toast.error("Művelet sikertelen", { description: msg.slice(0, 200) });
    };

    document.addEventListener("click", onClickCapture, true);
    window.addEventListener("error", onError);
    window.addEventListener("unhandledrejection", onRejection);

    return () => {
      document.removeEventListener("click", onClickCapture, true);
      window.removeEventListener("error", onError);
      window.removeEventListener("unhandledrejection", onRejection);
    };
  }, []);

  return null;
}
