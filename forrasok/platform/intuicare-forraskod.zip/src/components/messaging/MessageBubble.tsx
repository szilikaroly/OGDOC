import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { translateMessage } from "@/lib/messaging/ai.functions";
import { format } from "date-fns";
import { Bot, Languages, Check, CheckCheck } from "lucide-react";
import { AttachmentCard } from "./AttachmentCard";

type Att = {
  id: string;
  kind: string;
  mime: string;
  size_bytes: number;
  original_name: string;
  ai_summary: string | null;
  ai_summary_status: string;
  transcript: string | null;
  duration_ms: number | null;
};
type Msg = {
  id: string;
  body: string | null;
  source_lang: string | null;
  sender_kind: string;
  sender_user_id: string | null;
  sender_name: string | null;
  sender_avatar: string | null;
  created_at: string;
  edited_at: string | null;
  deleted_at: string | null;
  attachments: Att[];
  translations: Record<string, string>;
  read_by?: string[];
};

export function MessageBubble({
  message,
  mine,
  autoTranslate,
  viewerLang,
}: {
  message: Msg;
  mine: boolean;
  autoTranslate: boolean;
  viewerLang: string;
}) {
  const tr = useServerFn(translateMessage);
  const needsTr = autoTranslate && viewerLang !== "hu" && (message.source_lang ?? "hu") !== viewerLang;
  const [translated, setTranslated] = useState<string | null>(message.translations[viewerLang] ?? null);
  const [showOriginal, setShowOriginal] = useState(false);

  useEffect(() => {
    if (!needsTr || translated || !message.body) return;
    let cancelled = false;
    tr({ data: { message_id: message.id, target_lang: viewerLang } })
      .then((r) => { if (!cancelled && r.translation) setTranslated(r.translation); })
      .catch(() => {});
    return () => { cancelled = true; };
  }, [needsTr, translated, message.id, message.body, viewerLang, tr]);

  const isAi = message.sender_kind === "ai";
  const displayBody = message.deleted_at
    ? <span className="italic opacity-70">(törölt üzenet)</span>
    : (translated && !showOriginal) ? translated : message.body;

  return (
    <div className={`flex gap-2 ${mine ? "flex-row-reverse" : ""}`}>
      <div className={`size-8 rounded-full shrink-0 flex items-center justify-center text-[10px] font-bold ${isAi ? "bg-primary text-primary-foreground" : "bg-secondary"}`}>
        {isAi ? <Bot className="size-4" /> : (message.sender_name?.[0] ?? "?")}
      </div>
      <div className={`max-w-[70%] ${mine ? "items-end" : "items-start"} flex flex-col gap-1`}>
        {!mine && (
          <div className="text-[10px] font-semibold text-muted-foreground px-1">
            {isAi ? "AI asszisztens" : message.sender_name}
          </div>
        )}
        {message.body && (
          <div className={`px-3 py-2 rounded-2xl text-sm whitespace-pre-wrap break-words ${
            mine ? "bg-primary text-primary-foreground rounded-br-sm" : isAi ? "bg-primary/10 text-foreground rounded-bl-sm" : "bg-card border border-border rounded-bl-sm"
          }`}>
            {displayBody}
            {translated && (
              <button
                type="button"
                onClick={() => setShowOriginal((v) => !v)}
                className="block mt-1 text-[10px] opacity-70 hover:opacity-100 underline"
              >
                <Languages className="size-3 inline mr-1" />
                {showOriginal ? "Lefordított nézet" : "Eredeti megjelenítése"}
              </button>
            )}
          </div>
        )}
        {message.attachments.map((a) => (
          <AttachmentCard key={a.id} attachment={a} />
        ))}
        <div className="text-[10px] text-muted-foreground px-1 flex items-center gap-1">
          <span>{format(new Date(message.created_at), "HH:mm")}</span>
          {message.edited_at && <span>· szerkesztve</span>}
          {mine && (
            (message.read_by?.length ?? 0) > 0
              ? <CheckCheck className="size-3 text-primary" aria-label="Olvasva" />
              : <Check className="size-3" aria-label="Elküldve" />
          )}
        </div>
      </div>
    </div>
  );
}
