import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { getAttachmentUrl, requestUploadUrl as _ignore } from "@/lib/messaging/attachments.functions";
import { summarizeAttachment, transcribeAttachment } from "@/lib/messaging/ai.functions";
import { FileText, FileSpreadsheet, FileAudio, FileIcon, Sparkles, Loader2, Play, Pause } from "lucide-react";
// keep _ignore reference to retain bundle path (no-op)
void _ignore;

type Att = {
  id: string;
  kind: string;
  mime: string;
  size_bytes: number;
  original_name: string;
  ai_summary: string | null;
  ai_summary_status: string;
  transcript: string | null;
  duration_ms: number | null;
};

function fmtSize(n: number) {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}

export function AttachmentCard({ attachment }: { attachment: Att }) {
  const getUrl = useServerFn(getAttachmentUrl);
  const summarize = useServerFn(summarizeAttachment);
  const transcribe = useServerFn(transcribeAttachment);

  const [url, setUrl] = useState<string | null>(null);
  const [summary, setSummary] = useState<string | null>(attachment.ai_summary);
  const [summaryLoading, setSummaryLoading] = useState(false);
  const [transcript, setTranscript] = useState<string | null>(attachment.transcript);
  const [transcribing, setTranscribing] = useState(false);
  const [showSummary, setShowSummary] = useState(false);

  useEffect(() => {
    getUrl({ data: { attachment_id: attachment.id } }).then((r) => setUrl(r.url)).catch(() => {});
  }, [attachment.id, getUrl]);

  // Auto-summary trigger for PDF/Excel
  useEffect(() => {
    if (summary || summaryLoading) return;
    if (attachment.kind !== "pdf" && attachment.kind !== "spreadsheet") return;
    if (attachment.ai_summary_status === "failed") return;
    setSummaryLoading(true);
    summarize({ data: { attachment_id: attachment.id } })
      .then((r) => r.summary && setSummary(r.summary))
      .catch(() => {})
      .finally(() => setSummaryLoading(false));
  }, [attachment.id, attachment.kind, attachment.ai_summary_status, summary, summaryLoading, summarize]);

  // Auto-transcribe audio
  useEffect(() => {
    if (transcript || transcribing) return;
    if (attachment.kind !== "audio") return;
    setTranscribing(true);
    transcribe({ data: { attachment_id: attachment.id } })
      .then((r) => r.transcript && setTranscript(r.transcript))
      .catch(() => {})
      .finally(() => setTranscribing(false));
  }, [attachment.id, attachment.kind, transcript, transcribing, transcribe]);

  if (attachment.kind === "image") {
    return (
      <a href={url ?? "#"} target="_blank" rel="noreferrer" className="block max-w-xs">
        {url ? (
          <img src={url} alt={attachment.original_name} className="rounded-lg max-h-72 object-cover" />
        ) : (
          <div className="size-40 rounded-lg bg-secondary animate-pulse" />
        )}
      </a>
    );
  }

  if (attachment.kind === "audio") {
    return (
      <div className="bg-card border border-border rounded-lg p-3 max-w-md">
        {url ? <audio controls src={url} className="w-full" /> : <div className="h-10 bg-secondary rounded animate-pulse" />}
        <div className="mt-2 text-xs">
          {transcribing && <span className="inline-flex items-center gap-1 text-muted-foreground"><Loader2 className="size-3 animate-spin" /> Átirat készül…</span>}
          {transcript && (
            <div className="bg-secondary/40 rounded px-2 py-1.5 text-foreground/90 whitespace-pre-wrap">
              {transcript}
            </div>
          )}
        </div>
      </div>
    );
  }

  const Icon = attachment.kind === "pdf" ? FileText : attachment.kind === "spreadsheet" ? FileSpreadsheet : FileIcon;
  return (
    <div className="bg-card border border-border rounded-lg p-3 max-w-md">
      <a href={url ?? "#"} target="_blank" rel="noreferrer" className="flex items-center gap-3 hover:opacity-80">
        <Icon className="size-8 text-primary shrink-0" />
        <div className="flex-1 min-w-0">
          <div className="font-medium text-sm truncate">{attachment.original_name}</div>
          <div className="text-[10px] text-muted-foreground uppercase">
            {attachment.mime.split("/").pop()} · {fmtSize(attachment.size_bytes)}
          </div>
        </div>
      </a>
      {(attachment.kind === "pdf" || attachment.kind === "spreadsheet") && (
        <div className="mt-2 border-t border-border pt-2">
          <button
            type="button"
            onClick={() => setShowSummary((v) => !v)}
            className="flex items-center gap-1.5 text-xs font-semibold text-primary"
          >
            <Sparkles className="size-3" />
            {summaryLoading ? "AI összefoglaló készül…" : summary ? (showSummary ? "AI összefoglaló elrejtése" : "AI összefoglaló") : "AI összefoglaló nem érhető el"}
            {summaryLoading && <Loader2 className="size-3 animate-spin" />}
          </button>
          {showSummary && summary && (
            <div className="mt-2 text-xs whitespace-pre-wrap text-foreground/90 bg-primary/5 rounded p-2">
              {summary}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
