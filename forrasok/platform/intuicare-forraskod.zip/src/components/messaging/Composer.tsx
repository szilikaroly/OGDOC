import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { requestUploadUrl, finalizeAttachment } from "@/lib/messaging/attachments.functions";
import { Paperclip, Mic, Send, Loader2, Square, Languages } from "lucide-react";
import { haptic } from "@/lib/query/optimistic";

export function Composer({
  conversationId,
  onSend,
  pending,
  aiMode,
  value,
  onValueChange,
}: {
  conversationId: string;
  onSend: (args: { body?: string; attachment_ids?: string[] }) => void;
  pending: boolean;
  aiMode: boolean;
  value?: string;
  onValueChange?: (v: string) => void;
}) {
  const [internalBody, setInternalBody] = useState("");
  const body = value ?? internalBody;
  const setBody = (next: string | ((cur: string) => string)) => {
    if (onValueChange) {
      const resolved = typeof next === "function" ? (next as (cur: string) => string)(value ?? "") : next;
      onValueChange(resolved);
    } else {
      setInternalBody(next as any);
    }
  };
  const [pendingAtts, setPendingAtts] = useState<Array<{ id: string; name: string; kind: string }>>([]);
  const [uploading, setUploading] = useState(false);
  const [recording, setRecording] = useState(false);
  const [dictating, setDictating] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const taRef = useRef<HTMLTextAreaElement>(null);
  const mediaRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const dictateRef = useRef<{ recorder: MediaRecorder; stream: MediaStream } | null>(null);

  // Auto-grow textarea – max ~5 sor (line-height 1.25rem × 5 + padding).
  useEffect(() => {
    const el = taRef.current;
    if (!el) return;
    el.style.height = "auto";
    const max = 160; // ~5 line + padding
    el.style.height = Math.min(el.scrollHeight, max) + "px";
  }, [body]);

  const reqUrl = useServerFn(requestUploadUrl);
  const fin = useServerFn(finalizeAttachment);

  async function uploadFile(file: File) {
    setUploading(true);
    try {
      const sig = await reqUrl({
        data: { conversation_id: conversationId, filename: file.name, mime: file.type || "application/octet-stream", size_bytes: file.size },
      });
      const put = await fetch(sig.upload_url, { method: "PUT", headers: { "Content-Type": file.type || "application/octet-stream" }, body: file });
      if (!put.ok) throw new Error(`Feltöltés sikertelen: ${put.status}`);
      const att = await fin({
        data: { conversation_id: conversationId, object_path: sig.object_path, filename: file.name, mime: file.type || "application/octet-stream", size_bytes: file.size },
      });
      setPendingAtts((prev) => [...prev, { id: att.id, name: file.name, kind: att.kind }]);
    } catch (e) {
      alert((e as Error).message);
    } finally {
      setUploading(false);
    }
  }

  async function onFiles(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files ?? []);
    for (const f of files) await uploadFile(f);
    if (fileRef.current) fileRef.current.value = "";
  }

  async function startVoiceMessage() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mt = ["audio/webm", "audio/mp4"].find((t) => MediaRecorder.isTypeSupported(t));
      if (!mt) { alert("A böngésző nem támogat hangrögzítést."); stream.getTracks().forEach((t) => t.stop()); return; }
      const rec = new MediaRecorder(stream, { mimeType: mt });
      chunksRef.current = [];
      rec.ondataavailable = (e) => e.data.size > 0 && chunksRef.current.push(e.data);
      rec.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(chunksRef.current, { type: rec.mimeType });
        if (blob.size < 1024) { alert("A felvétel túl rövid."); return; }
        const ext = rec.mimeType.includes("mp4") ? "m4a" : "webm";
        const file = new File([blob], `hangzenet-${Date.now()}.${ext}`, { type: rec.mimeType });
        await uploadFile(file);
      };
      mediaRef.current = rec;
      rec.start();
      setRecording(true);
      // auto-stop at 5 min
      setTimeout(() => { if (mediaRef.current?.state === "recording") stopVoiceMessage(); }, 5 * 60 * 1000);
    } catch (e) {
      alert("Mikrofon hozzáférés szükséges: " + (e as Error).message);
    }
  }

  function stopVoiceMessage() {
    mediaRef.current?.stop();
    setRecording(false);
  }

  async function startDictation() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mt = ["audio/webm", "audio/mp4"].find((t) => MediaRecorder.isTypeSupported(t));
      if (!mt) { alert("A böngésző nem támogat hangrögzítést."); stream.getTracks().forEach((t) => t.stop()); return; }
      const rec = new MediaRecorder(stream, { mimeType: mt });
      const chunks: Blob[] = [];
      rec.ondataavailable = (e) => e.data.size > 0 && chunks.push(e.data);
      rec.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(chunks, { type: rec.mimeType });
        if (blob.size < 1024) return;
        const ext = rec.mimeType.includes("mp4") ? "m4a" : "webm";
        const file = new File([blob], `dictation.${ext}`, { type: rec.mimeType });
        const form = new FormData();
        form.append("file", file);
        const resp = await fetch("/api/dictate", { method: "POST", body: form });
        if (!resp.ok || !resp.body) { alert("Diktálás hiba: " + resp.status); return; }
        // parse SSE
        const reader = resp.body.getReader();
        const dec = new TextDecoder();
        let buf = "";
        let acc = "";
        for (;;) {
          const { value, done } = await reader.read();
          if (done) break;
          buf += dec.decode(value, { stream: true });
          const lines = buf.split("\n");
          buf = lines.pop() ?? "";
          for (const ln of lines) {
            const l = ln.trim();
            if (!l.startsWith("data:")) continue;
            const payload = l.slice(5).trim();
            if (!payload || payload === "[DONE]") continue;
            try {
              const ev = JSON.parse(payload);
              if (ev.type === "transcript.text.delta" && typeof ev.delta === "string") {
                acc += ev.delta;
                setBody((cur) => cur + ev.delta);
              } else if (ev.type === "transcript.text.done" && typeof ev.text === "string") {
                // nothing extra; deltas already appended
              }
            } catch { /* ignore */ }
          }
        }
        void acc;
      };
      dictateRef.current = { recorder: rec, stream };
      rec.start();
      setDictating(true);
    } catch (e) {
      alert("Mikrofon hozzáférés szükséges: " + (e as Error).message);
    }
  }

  function stopDictation() {
    dictateRef.current?.recorder.stop();
    setDictating(false);
  }

  function submit() {
    if (!body.trim() && pendingAtts.length === 0) return;
    haptic(10);
    onSend({ body: body.trim() || undefined, attachment_ids: pendingAtts.map((a) => a.id) });
    setBody("");
    setPendingAtts([]);
  }

  return (
    <div
      className="border-t border-border bg-card p-2 sm:p-3"
      style={{ paddingBottom: "max(env(safe-area-inset-bottom), 0.5rem)" }}
    >
      {pendingAtts.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-2">
          {pendingAtts.map((a) => (
            <div key={a.id} className="inline-flex items-center gap-1.5 px-2 py-1 bg-secondary rounded-md text-xs">
              <Paperclip className="size-3" /> {a.name}
              <button
                type="button"
                aria-label={`${a.name} eltávolítása`}
                onClick={() => setPendingAtts((p) => p.filter((x) => x.id !== a.id))}
                className="opacity-60 hover:opacity-100 min-w-6"
              >×</button>
            </div>
          ))}
        </div>
      )}
      <div className="flex items-end gap-1.5 sm:gap-2">
        <input ref={fileRef} type="file" hidden multiple onChange={onFiles}
               accept="image/*,application/pdf,.xlsx,.xls,text/csv,text/plain,audio/*" />
        <button type="button" disabled={uploading} onClick={() => fileRef.current?.click()}
                aria-label="Csatolmány hozzáadása"
                className="inline-flex items-center justify-center min-h-11 min-w-11 rounded-md hover:bg-secondary active:bg-secondary/80 text-muted-foreground">
          {uploading ? <Loader2 className="size-5 animate-spin" /> : <Paperclip className="size-5" />}
        </button>
        <button type="button" onClick={recording ? stopVoiceMessage : startVoiceMessage}
                aria-label={recording ? "Hangrögzítés leállítása" : "Hangüzenet"}
                aria-pressed={recording}
                className={`inline-flex items-center justify-center min-h-11 min-w-11 rounded-md ${recording ? "bg-destructive text-destructive-foreground" : "hover:bg-secondary active:bg-secondary/80 text-muted-foreground"}`}>
          {recording ? <Square className="size-5" /> : <Mic className="size-5" />}
        </button>
        <button type="button" onClick={dictating ? stopDictation : startDictation}
                aria-label={dictating ? "Diktálás leállítása" : "Élő diktálás"}
                aria-pressed={dictating}
                className={`hidden sm:inline-flex items-center justify-center min-h-11 min-w-11 rounded-md ${dictating ? "bg-primary text-primary-foreground" : "hover:bg-secondary active:bg-secondary/80 text-muted-foreground"}`}>
          <Languages className="size-5" />
        </button>
        <textarea
          ref={taRef}
          value={body}
          onChange={(e) => setBody(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing) { e.preventDefault(); submit(); } }}
          placeholder={aiMode ? "Kérdezz az AI asszisztenstől…" : "Írj üzenetet…"}
          rows={1}
          enterKeyHint="send"
          inputMode="text"
          autoComplete="off"
          autoCapitalize="sentences"
          aria-label="Üzenet szövege"
          className="flex-1 min-w-0 px-3 py-2 min-h-11 rounded-md border border-border bg-background text-sm resize-none leading-5 overflow-y-auto"
          style={{ maxHeight: 160 }}
        />
        <button type="button" onClick={submit} disabled={pending}
                aria-label="Küldés"
                className="inline-flex items-center justify-center min-h-11 min-w-11 rounded-md bg-primary text-primary-foreground disabled:opacity-50 active:scale-95 transition-transform">
          {pending ? <Loader2 className="size-5 animate-spin" /> : <Send className="size-5" />}
        </button>
      </div>
      {recording && <div className="text-[10px] text-destructive mt-1 animate-pulse">● Felvétel… (max 5 perc)</div>}
      {dictating && <div className="text-[10px] text-primary mt-1 animate-pulse">● Diktálás… állítsd meg, ha kész</div>}
    </div>
  );
}
