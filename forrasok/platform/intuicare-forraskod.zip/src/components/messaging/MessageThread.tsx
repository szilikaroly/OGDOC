import { useEffect, useRef, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { listMessages, sendMessage, sendReadReceipts } from "@/lib/messaging/messages.functions";
import { markRead, setAutoTranslate } from "@/lib/messaging/conversations.functions";
import { askAssistant } from "@/lib/messaging/assistant.functions";
import { supabase } from "@/integrations/supabase/client";
import { useTranslation } from "react-i18next";
import { Composer } from "./Composer";
import { MessageBubble } from "./MessageBubble";
import { AiTriagePanel } from "./AiTriagePanel";
import { AssistantSuggestionsPanel } from "./AssistantSuggestionsPanel";
import { PushOptInButton } from "./PushOptInButton";
import { Languages, Bot } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

export function MessageThread({ conversationId }: { conversationId: string }) {
  const { i18n } = useTranslation();
  const { user } = useAuth();
  const qc = useQueryClient();
  const lm = useServerFn(listMessages);
  const send = useServerFn(sendMessage);
  const mr = useServerFn(markRead);
  const setAt = useServerFn(setAutoTranslate);
  const recv = useServerFn(sendReadReceipts);
  const ask = useServerFn(askAssistant);


  const { data: messages } = useQuery({
    queryKey: ["messaging", "thread", conversationId],
    queryFn: () => lm({ data: { conversation_id: conversationId, limit: 100 } }),
  });

  const [autoTr, setAutoTr] = useState(true);
  const [aiMode, setAiMode] = useState(false);
  const [draft, setDraft] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  const lastIncoming = messages?.slice().reverse().find(
    (m) => m.sender_user_id !== user?.id && m.sender_kind !== "ai" && m.sender_kind !== "system" && !m.deleted_at,
  );
  const showTriage = !aiMode && !!lastIncoming;

  // detect AI assistant conversation
  useEffect(() => {
    const aiMsg = messages?.find((m) => m.sender_kind === "ai");
    if (aiMsg) setAiMode(true);
  }, [messages]);

  // mark read + receipts on view
  useEffect(() => {
    if (!messages?.length) return;
    mr({ data: { conversation_id: conversationId } });
    const ids = messages.filter((m) => m.sender_user_id !== user?.id).map((m) => m.id);
    if (ids.length) recv({ data: { message_ids: ids } });
  }, [messages, conversationId, mr, recv, user?.id]);

  // realtime: új üzenet ebben a szálban
  useEffect(() => {
    const ch = supabase
      .channel(`thread-${conversationId}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "messages", filter: `conversation_id=eq.${conversationId}` },
        () => qc.invalidateQueries({ queryKey: ["messaging", "thread", conversationId] }),
      )
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "message_attachments" },
        () => qc.invalidateQueries({ queryKey: ["messaging", "thread", conversationId] }),
      )
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [conversationId, qc]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages?.length]);

  const sendM = useMutation({
    mutationFn: async (vars: { body?: string; attachment_ids?: string[] }) => {
      if (aiMode && vars.body) {
        await send({
          data: { conversation_id: conversationId, body: vars.body, source_lang: i18n.language?.split("-")[0] },
        });
        await ask({ data: { conversation_id: conversationId, question: vars.body } });
      } else {
        await send({
          data: {
            conversation_id: conversationId,
            body: vars.body,
            attachment_ids: vars.attachment_ids ?? [],
            source_lang: i18n.language?.split("-")[0],
          },
        });
      }
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["messaging", "thread", conversationId] }),
  });


  return (
    <div className="flex-1 flex flex-col min-h-0">
      <div className="px-6 py-3 border-b border-border bg-card flex items-center justify-between">
        <div className="flex items-center gap-2">
          {aiMode && <Bot className="size-4 text-primary" />}
          <h2 className="font-semibold text-sm">{aiMode ? "AI asszisztens" : "Beszélgetés"}</h2>
        </div>
        <div className="flex items-center gap-2">
          <PushOptInButton />
          <label className="flex items-center gap-2 text-xs cursor-pointer">
            <Languages className="size-3.5 text-muted-foreground" />
            <input
              type="checkbox"
              checked={autoTr}
              onChange={(e) => {
                setAutoTr(e.target.checked);
                setAt({ data: { conversation_id: conversationId, auto_translate: e.target.checked } });
              }}
            />
            Auto-fordítás
          </label>
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 sm:px-6 py-4 space-y-3">
        {groupByDay(messages ?? []).map((group) => (
          <div key={group.key} className="space-y-3">
            <div className="sticky top-0 z-10 flex justify-center pointer-events-none">
              <span className="pointer-events-auto rounded-full bg-background/80 backdrop-blur-md border border-border px-3 py-1 text-[11px] font-medium text-muted-foreground shadow-sm">
                {group.label}
              </span>
            </div>
            {group.items.map((m) => (
              <MessageBubble
                key={m.id}
                message={m}
                mine={m.sender_user_id === user?.id}
                autoTranslate={autoTr}
                viewerLang={(i18n.language?.split("-")[0] ?? "hu") as string}
              />
            ))}
          </div>
        ))}
      </div>


      {showTriage && (
        <AiTriagePanel
          conversationId={conversationId}
          lastIncomingMessageId={lastIncoming?.id ?? null}
          onPickReply={(t) => setDraft((cur) => (cur ? `${cur}\n${t}` : t))}
        />
      )}

      {aiMode && <AssistantSuggestionsPanel conversationId={conversationId} />}

      <Composer
        conversationId={conversationId}
        onSend={(args) => { sendM.mutate(args); setDraft(""); }}
        pending={sendM.isPending}
        aiMode={aiMode}
        value={draft}
        onValueChange={setDraft}
      />
    </div>
  );
}

function groupByDay<T extends { created_at?: string | null; id: string }>(items: T[]): Array<{ key: string; label: string; items: T[] }> {
  const groups = new Map<string, T[]>();
  for (const item of items) {
    const d = item.created_at ? new Date(item.created_at) : new Date();
    const key = `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key)!.push(item);
  }
  const today = new Date();
  const yesterday = new Date(); yesterday.setDate(today.getDate() - 1);
  const sameDay = (a: Date, b: Date) =>
    a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
  return Array.from(groups.entries()).map(([key, list]) => {
    const d = list[0].created_at ? new Date(list[0].created_at) : new Date();
    let label: string;
    if (sameDay(d, today)) label = "Ma";
    else if (sameDay(d, yesterday)) label = "Tegnap";
    else label = d.toLocaleDateString("hu-HU", { year: "numeric", month: "long", day: "numeric" });
    return { key, label, items: list };
  });
}
