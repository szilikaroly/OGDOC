import { useEffect, useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Bell, X, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { savePushSubscription, getVapidPublicKey } from "@/lib/push/push.functions";

const DISMISS_KEY = "push-prompt-dismissed-at";
const DISMISS_DAYS = 14;

function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const raw = atob(base64);
  const out = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
  return out;
}

/**
 * Diszkrét, mobil-first felugró sáv: engedélyt kér a web-push értesítésekhez,
 * ha a felhasználó push-t bekapcsolva hagyta a profilban, a böngésző támogatja,
 * és nincs még aktív subscription vagy engedély.
 */
export function PushPermissionPrompt() {
  const [visible, setVisible] = useState(false);
  const save = useServerFn(savePushSubscription);
  const getKey = useServerFn(getVapidPublicKey);

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (!("serviceWorker" in navigator) || !("PushManager" in window) || !("Notification" in window)) return;
    // Respect dismiss cooldown
    const dismissedAt = Number(localStorage.getItem(DISMISS_KEY) ?? "0");
    if (dismissedAt && Date.now() - dismissedAt < DISMISS_DAYS * 86_400_000) return;
    if (Notification.permission === "denied") return;

    let cancelled = false;
    (async () => {
      try {
        // Only prompt for authenticated users
        const { data: sess } = await supabase.auth.getSession();
        if (!sess.session) return;
        // Respect the user's stored preference
        const { data: profile } = await supabase
          .from("profiles")
          .select("reminder_push_enabled")
          .eq("id", sess.session.user.id)
          .maybeSingle();
        if (profile && (profile as { reminder_push_enabled: boolean }).reminder_push_enabled === false) return;

        const reg = await navigator.serviceWorker.ready;
        const existing = await reg.pushManager.getSubscription();
        if (cancelled) return;
        if (existing && Notification.permission === "granted") return;
        setVisible(true);
      } catch {
        // silent
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const enable = useMutation({
    mutationFn: async () => {
      const { publicKey } = await getKey();
      if (!publicKey) throw new Error("A push szolgáltatás nincs beállítva.");
      const perm = await Notification.requestPermission();
      if (perm !== "granted") throw new Error("Engedély megtagadva.");
      const reg = await navigator.serviceWorker.ready;
      const sub =
        (await reg.pushManager.getSubscription()) ??
        (await reg.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: urlBase64ToUint8Array(publicKey) as unknown as BufferSource,
        }));
      const json = sub.toJSON() as { endpoint: string; keys: { p256dh: string; auth: string } };
      await save({
        data: {
          endpoint: json.endpoint,
          p256dh: json.keys.p256dh,
          auth: json.keys.auth,
          user_agent: navigator.userAgent.slice(0, 200),
        },
      });
    },
    onSuccess: () => {
      toast.success("Push értesítések bekapcsolva");
      setVisible(false);
    },
    onError: (e: Error) => {
      toast.error(e.message ?? "Push engedélyezés hiba");
    },
  });

  function dismiss() {
    try {
      localStorage.setItem(DISMISS_KEY, String(Date.now()));
    } catch {
      // ignore
    }
    setVisible(false);
  }

  if (!visible) return null;

  return (
    <div className="mb-3 flex flex-col sm:flex-row sm:items-center gap-2 rounded-lg border border-border bg-card px-3 py-2 shadow-sm">
      <div className="flex items-start gap-2 flex-1 min-w-0">
        <Bell className="size-4 mt-0.5 shrink-0 text-primary" />
        <div className="text-sm text-foreground">
          <span className="font-medium">Push értesítések</span>
          <span className="text-muted-foreground"> — kapj azonnali jelzést, ha a beosztásod változik vagy műszak-emlékeztető érkezik.</span>
        </div>
      </div>
      <div className="flex items-center gap-2 sm:shrink-0">
        <button
          type="button"
          onClick={() => enable.mutate()}
          disabled={enable.isPending}
          className="inline-flex items-center gap-1.5 rounded-md bg-primary text-primary-foreground px-3 min-h-11 sm:min-h-9 text-sm font-medium hover:opacity-90 disabled:opacity-50"
        >
          {enable.isPending ? <Loader2 className="size-3.5 animate-spin" /> : <Bell className="size-3.5" />}
          Engedélyezés
        </button>
        <button
          type="button"
          onClick={dismiss}
          aria-label="Elrejtés"
          className="inline-flex items-center justify-center rounded-md border border-border px-2 min-h-11 sm:min-h-9 text-muted-foreground hover:bg-secondary"
        >
          <X className="size-4" />
        </button>
      </div>
    </div>
  );
}
