import { Link, useParams } from "@tanstack/react-router";
import { formatDistanceToNow } from "date-fns";
import { hu } from "date-fns/locale";
import { Users, User, Bot, Stethoscope, BellOff } from "lucide-react";

type Conv = {
  id: string;
  kind: string;
  title: string | null;
  last_message_at: string;
  last_message: { body: string | null; created_at: string; sender_user_id: string | null } | null;
  unread_count: number;
  muted: boolean;
  members: Array<{ user_id: string | null; name: string | null; avatar_url: string | null }>;
};

function kindIcon(kind: string) {
  switch (kind) {
    case "group": return Users;
    case "ai_assistant": return Bot;
    case "patient_team":
    case "patient_provider": return Stethoscope;
    default: return User;
  }
}

export function ConversationList({ items }: { items: Conv[] }) {
  const params = useParams({ strict: false }) as { conversationId?: string };

  if (items.length === 0) {
    return (
      <div className="p-6 text-xs text-muted-foreground">
        Még nincs beszélgetésed. Kattints az „Új” gombra.
      </div>
    );
  }
  return (
    <div className="flex-1 overflow-y-auto">
      {items.map((c) => {
        const Icon = kindIcon(c.kind);
        const active = params.conversationId === c.id;
        const otherName = c.members.find((m) => m.name)?.name ?? "Beszélgetés";
        const title = c.title?.trim() || (c.kind === "ai_assistant" ? "AI asszisztens" : otherName);
        return (
          <Link
            key={c.id}
            to="/uzenetek/$conversationId"
            params={{ conversationId: c.id }}
            className={`block px-4 py-3 border-b border-border hover:bg-secondary/40 transition-colors ${active ? "bg-secondary" : ""}`}
          >
            <div className="flex items-start gap-3">
              <div className="size-9 rounded-full bg-secondary flex items-center justify-center shrink-0">
                <Icon className="size-4" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <div className="font-semibold text-sm truncate">{title}</div>
                  <div className="text-[10px] text-muted-foreground shrink-0">
                    {formatDistanceToNow(new Date(c.last_message_at), { addSuffix: false, locale: hu })}
                  </div>
                </div>
                <div className="flex items-center justify-between gap-2 mt-0.5">
                  <div className="text-xs text-muted-foreground truncate">
                    {c.last_message?.body?.slice(0, 80) ?? <span className="italic">Nincs üzenet még</span>}
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    {c.muted && <BellOff className="size-3 text-muted-foreground" />}
                    {c.unread_count > 0 && (
                      <span className="px-1.5 py-0.5 rounded-full bg-primary text-primary-foreground text-[10px] font-bold min-w-5 text-center">
                        {c.unread_count}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </Link>
        );
      })}
    </div>
  );
}
