import { useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { bookAssistantSlot } from "@/lib/messaging/assistant.functions";
import { supabase } from "@/integrations/supabase/client";
import { Calendar, Loader2 } from "lucide-react";
import { toast } from "sonner";

type Slot = { id: string; starts_at: string; provider_name: string | null };
type AssistantResult = {
  suggested_provider_id?: string | null;
  slot_count?: number;
  message_id?: string | null;
};
type AssistantPayload = { patient_id?: string | null };

export function AssistantSuggestionsPanel({ conversationId }: { conversationId: string }) {
  const qc = useQueryClient();
  const book = useServerFn(bookAssistantSlot);

  const { data: latest } = useQuery({
    queryKey: ["assistant", "latest", conversationId],
    queryFn: async () => {
      const { data } = await supabase
        .from("ai_assistant_actions")
        .select("id, kind, payload, result, created_at")
        .eq("conversation_id", conversationId)
        .eq("kind", "lookup_history")
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      return data;
    },
  });

  useEffect(() => {
    const ch = supabase
      .channel(`assistant-${conversationId}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "ai_assistant_actions",
          filter: `conversation_id=eq.${conversationId}`,
        },
        () => qc.invalidateQueries({ queryKey: ["assistant", "latest", conversationId] }),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [conversationId, qc]);

  const bookM = useMutation({
    mutationFn: (vars: { slot_id: string; patient_id: string }) =>
      book({ data: { conversation_id: conversationId, ...vars } }),
    onSuccess: (r) => {
      toast.success(`Időpont foglalva: ${r.when}`);
      qc.invalidateQueries({ queryKey: ["messaging", "thread", conversationId] });
      qc.invalidateQueries({ queryKey: ["assistant", "latest", conversationId] });
    },
    onError: (e: any) => toast.error(e?.message ?? "Foglalás hiba"),
  });

  if (!latest) return null;
  const payload = (latest.payload ?? {}) as AssistantPayload;
  const result = (latest.result ?? {}) as AssistantResult & { slots?: Slot[] };
  // A korábbi askAssistant verziók nem mentették a slots-ot a result-ba — ezért a panel
  // most azt használja, amit utólag eltett a kliens; fallback: a result.slot_count > 0 esetén
  // is megjelenítjük az infót, de gombok csak teljes slot-listával jönnek.
  const slots: Slot[] = Array.isArray(result.slots) ? result.slots : [];
  const patientId = payload.patient_id ?? null;

  if (!patientId || slots.length === 0) return null;

  return (
    <div className="border-t border-border bg-muted/30 px-4 py-2 space-y-1">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold flex items-center gap-1">
        <Calendar className="size-3" /> Javasolt időpontok (megerősítés szükséges)
      </div>
      <div className="flex flex-wrap gap-1.5">
        {slots.map((s) => (
          <button
            key={s.id}
            type="button"
            disabled={bookM.isPending}
            onClick={() => bookM.mutate({ slot_id: s.id, patient_id: patientId })}
            className="text-[11px] px-2 py-1 rounded-md bg-primary text-primary-foreground hover:opacity-90 disabled:opacity-50 inline-flex items-center gap-1"
          >
            {bookM.isPending && bookM.variables?.slot_id === s.id && (
              <Loader2 className="size-3 animate-spin" />
            )}
            {new Date(s.starts_at).toLocaleString("hu-HU", {
              month: "short",
              day: "numeric",
              hour: "2-digit",
              minute: "2-digit",
            })}
            {s.provider_name ? ` · ${s.provider_name}` : ""}
          </button>
        ))}
      </div>
    </div>
  );
}
