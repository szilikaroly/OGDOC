import { useEffect, useRef, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { aiTriageMessage, bookTriageSlot, type TriageResult, type TriageUrgency } from "@/lib/messaging/triage.functions";
import { StatusBadge, type StatusTone } from "@/components/ui/status-badge";
import { Sparkles, RefreshCw, Calendar, Loader2, BellRing } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

const URGENCY_TONE: Record<TriageUrgency, StatusTone> = {
  routine: "neutral",
  soon: "info",
  urgent: "warn",
  emergency: "bad",
};
const URGENCY_LABEL: Record<TriageUrgency, string> = {
  routine: "Rutin",
  soon: "Hamarosan",
  urgent: "Sürgős",
  emergency: "Vészhelyzet",
};

export function AiTriagePanel({
  conversationId,
  lastIncomingMessageId,
  autoRun = true,
  onPickReply,
}: {
  conversationId: string;
  lastIncomingMessageId?: string | null;
  autoRun?: boolean;
  onPickReply: (text: string) => void;
}) {
  const qc = useQueryClient();
  const triage = useServerFn(aiTriageMessage);
  const book = useServerFn(bookTriageSlot);
  const [result, setResult] = useState<TriageResult | null>(null);
  const [open, setOpen] = useState(false);
  const [fresh, setFresh] = useState(false);
  const lastRanFor = useRef<string | null>(null);

  const run = useMutation({
    mutationFn: (force: boolean) => triage({ data: { conversation_id: conversationId, force } }),
    onSuccess: (r) => {
      setResult(r as TriageResult);
      setOpen(true);
      if (!(r as TriageResult).cached) {
        setFresh(true);
        if ((r as TriageResult).urgency === "urgent" || (r as TriageResult).urgency === "emergency") {
          toast.warning(`Új AI triage: ${URGENCY_LABEL[(r as TriageResult).urgency]}`, {
            description: (r as TriageResult).summary?.slice(0, 140),
          });
        }
      }
    },
    onError: (e: any) => toast.error(e?.message ?? "AI triage hiba"),
  });

  // Auto-run when a new incoming patient message arrives (cache hit if already analyzed).
  useEffect(() => {
    if (!autoRun || !lastIncomingMessageId) return;
    if (lastRanFor.current === lastIncomingMessageId) return;
    lastRanFor.current = lastIncomingMessageId;
    run.mutate(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lastIncomingMessageId, autoRun]);

  // Realtime: másik dolgozó által generált triage javaslat azonnali megjelenítése.
  useEffect(() => {
    const ch = supabase
      .channel(`triage-${conversationId}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "ai_assistant_actions", filter: `conversation_id=eq.${conversationId}` },
        (payload: any) => {
          const row = payload?.new;
          if (!row || row.kind !== "triage") return;
          const r = row.result as TriageResult | null;
          if (!r) return;
          setResult({ ...r, cached: false });
          setOpen(true);
          setFresh(true);
          toast.info("Új AI triage javaslat érkezett", {
            description: `${URGENCY_LABEL[r.urgency] ?? "—"} · ${r.category ?? ""}`.trim(),
          });
        },
      )
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [conversationId]);

  const bookM = useMutation({
    mutationFn: (slotId: string) =>
      book({ data: { conversation_id: conversationId, slot_id: slotId, patient_id: result!.patient_id!, ok: result?.summary?.slice(0, 200) } }),
    onSuccess: (r) => {
      toast.success(`Időpont foglalva: ${r.when}`);
      qc.invalidateQueries({ queryKey: ["messaging", "thread", conversationId] });
      setResult((prev) => (prev ? { ...prev, slots: [] } : prev));
    },
    onError: (e: any) => toast.error(e?.message ?? "Foglalás hiba"),
  });

  return (
    <div className="border-t border-border bg-muted/30 px-4 py-2">
      {!open || !result ? (
        <button
          type="button"
          onClick={() => run.mutate(false)}
          disabled={run.isPending}
          className="inline-flex items-center gap-2 text-xs font-medium text-primary hover:underline disabled:opacity-50"
        >
          {run.isPending ? <Loader2 className="size-3.5 animate-spin" /> : <Sparkles className="size-3.5" />}
          AI triage és válaszjavaslat
        </button>
      ) : (
        <div className="space-y-2">
          <div className="flex items-start justify-between gap-2">
            <div className="flex items-center gap-2 flex-wrap">
              <StatusBadge tone={URGENCY_TONE[result.urgency]} pill>
                {URGENCY_LABEL[result.urgency]}
              </StatusBadge>
              <StatusBadge tone="neutral" pill>{result.category}</StatusBadge>
              {result.cached && <span className="text-[10px] text-muted-foreground">cache</span>}
              {fresh && !result.cached && (
                <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-primary animate-pulse">
                  <BellRing className="size-3" /> új
                </span>
              )}
            </div>
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => run.mutate(true)}
                disabled={run.isPending}
                className="p-1 rounded hover:bg-secondary text-muted-foreground"
                title="Újra futtatás"
              >
                {run.isPending ? <Loader2 className="size-3.5 animate-spin" /> : <RefreshCw className="size-3.5" />}
              </button>
              <button
                type="button"
                onClick={() => { setOpen(false); setFresh(false); }}
                className="text-[11px] text-muted-foreground hover:text-foreground"
              >
                Bezár
              </button>
            </div>
          </div>

          <p className="text-xs text-foreground/80 whitespace-pre-wrap leading-relaxed">{result.summary}</p>

          {result.suggested_replies.length > 0 && (
            <div className="space-y-1">
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">Válaszjavaslatok</div>
              <div className="flex flex-col gap-1.5">
                {result.suggested_replies.map((r, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => onPickReply(r)}
                    className="text-left text-xs px-2.5 py-1.5 rounded-md bg-card border border-border hover:bg-secondary transition-colors"
                  >
                    {r}
                  </button>
                ))}
              </div>
            </div>
          )}

          {result.book_appointment.recommended && result.patient_id && (
            <div className="space-y-1">
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold flex items-center gap-1">
                <Calendar className="size-3" /> Időpontfoglalás javasolt
              </div>
              <p className="text-[11px] text-muted-foreground">{result.book_appointment.reason}</p>
              {result.slots.length === 0 ? (
                <p className="text-[11px] italic text-muted-foreground">Nincs szabad slot a javasolt orvosnál.</p>
              ) : (
                <div className="flex flex-wrap gap-1.5">
                  {result.slots.map((s) => (
                    <button
                      key={s.id}
                      type="button"
                      disabled={bookM.isPending}
                      onClick={() => bookM.mutate(s.id)}
                      className="text-[11px] px-2 py-1 rounded-md bg-primary text-primary-foreground hover:opacity-90 disabled:opacity-50"
                    >
                      {new Date(s.starts_at).toLocaleString("hu-HU", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
                      {s.provider_name ? ` · ${s.provider_name}` : ""}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
