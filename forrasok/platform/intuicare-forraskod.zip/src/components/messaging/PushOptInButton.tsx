import { useEffect, useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { savePushSubscription, deletePushSubscription, getVapidPublicKey } from "@/lib/push/push.functions";
import { Bell, BellOff, Loader2 } from "lucide-react";
import { toast } from "sonner";

function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const raw = atob(base64);
  const out = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
  return out;
}

/**
 * Staff push-értesítések opt-in/opt-out kapcsolója.
 * Csak böngészőben (typeof window) használható.
 */
export function PushOptInButton() {
  const save = useServerFn(savePushSubscription);
  const del = useServerFn(deletePushSubscription);
  const getKey = useServerFn(getVapidPublicKey);
  const [subscribed, setSubscribed] = useState(false);
  const [unsupported, setUnsupported] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (!("serviceWorker" in navigator) || !("PushManager" in window)) {
      setUnsupported(true);
      return;
    }
    navigator.serviceWorker.ready
      .then((reg) => reg.pushManager.getSubscription())
      .then((s) => setSubscribed(!!s))
      .catch(() => {});
  }, []);

  const subscribe = useMutation({
    mutationFn: async () => {
      const { publicKey } = await getKey();
      if (!publicKey) throw new Error("Push szolgáltatás nincs konfigurálva (VAPID kulcs hiányzik).");
      const perm = await Notification.requestPermission();
      if (perm !== "granted") throw new Error("Az értesítési engedély megtagadva.");
      const reg = await navigator.serviceWorker.ready;
      const sub = await reg.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(publicKey) as unknown as BufferSource,
      });
      const json = sub.toJSON() as { endpoint: string; keys: { p256dh: string; auth: string } };
      await save({
        data: {
          endpoint: json.endpoint,
          p256dh: json.keys.p256dh,
          auth: json.keys.auth,
          user_agent: navigator.userAgent.slice(0, 200),
        },
      });
    },
    onSuccess: () => { setSubscribed(true); toast.success("Push értesítések bekapcsolva"); },
    onError: (e: any) => toast.error(e?.message ?? "Push feliratkozás hiba"),
  });

  const unsubscribe = useMutation({
    mutationFn: async () => {
      const reg = await navigator.serviceWorker.ready;
      const sub = await reg.pushManager.getSubscription();
      if (!sub) return;
      await del({ data: { endpoint: sub.endpoint } });
      await sub.unsubscribe();
    },
    onSuccess: () => { setSubscribed(false); toast.message("Push értesítések kikapcsolva"); },
    onError: (e: any) => toast.error(e?.message ?? "Push leiratkozás hiba"),
  });

  if (unsupported) return null;
  const pending = subscribe.isPending || unsubscribe.isPending;

  return (
    <button
      type="button"
      onClick={() => (subscribed ? unsubscribe.mutate() : subscribe.mutate())}
      disabled={pending}
      className="inline-flex items-center gap-1.5 text-xs rounded-md border border-border px-2 py-1 hover:bg-secondary disabled:opacity-50"
      aria-label={subscribed ? "Push értesítések kikapcsolása" : "Push értesítések bekapcsolása"}
      title={subscribed ? "Kikapcsolás" : "Bekapcsolás"}
    >
      {pending ? <Loader2 className="size-3.5 animate-spin" /> : subscribed ? <Bell className="size-3.5" /> : <BellOff className="size-3.5 text-muted-foreground" />}
      {subscribed ? "Push aktív" : "Push"}
    </button>
  );
}
