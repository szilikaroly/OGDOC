import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";

type Prefs = {
  push_lab_results: boolean;
  push_messages: boolean;
  push_appointments: boolean;
  push_critical_alerts: boolean;
  push_questionnaire_reminders: boolean;
  push_lifestyle_tips: boolean;
  email_weekly_summary: boolean;
  quiet_hours_start: string | null;
  quiet_hours_end: string | null;
};

const DEFAULTS: Prefs = {
  push_lab_results: true,
  push_messages: true,
  push_appointments: true,
  push_critical_alerts: true,
  push_questionnaire_reminders: true,
  push_lifestyle_tips: false,
  email_weekly_summary: true,
  quiet_hours_start: null,
  quiet_hours_end: null,
};

const TOGGLES: { key: keyof Prefs; label: string; help?: string }[] = [
  { key: "push_critical_alerts", label: "Kritikus riasztások", help: "Sürgős, kórházi figyelmeztetések — javasolt bekapcsolva tartani." },
  { key: "push_lab_results", label: "Új laboreredmény" },
  { key: "push_appointments", label: "Időpont változás / emlékeztető" },
  { key: "push_messages", label: "Új üzenet" },
  { key: "push_questionnaire_reminders", label: "Kérdőív emlékeztető" },
  { key: "push_lifestyle_tips", label: "Életmód tippek (AI)" },
  { key: "email_weekly_summary", label: "Heti email összefoglaló" },
];

export function NotificationPreferences() {
  const [prefs, setPrefs] = useState<Prefs>(DEFAULTS);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) return;
      const { data } = await supabase
        .from("notification_preferences" as never)
        .select("*")
        .eq("user_id", u.user.id)
        .maybeSingle();
      if (data) setPrefs({ ...DEFAULTS, ...(data as any) });
      setLoading(false);
    })();
  }, []);

  async function save() {
    setSaving(true);
    const { data: u } = await supabase.auth.getUser();
    const { error } = await supabase
      .from("notification_preferences" as never)
      .upsert({ user_id: u.user!.id, ...prefs } as never, { onConflict: "user_id" });
    setSaving(false);
    if (error) toast.error(error.message);
    else toast.success("Beállítások mentve.");
  }

  if (loading) return <div className="flex items-center gap-2 text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> Betöltés…</div>;

  return (
    <div className="space-y-3">
      {TOGGLES.map((t) => (
        <div key={t.key} className="flex items-start justify-between gap-3 py-1">
          <div className="flex-1">
            <Label htmlFor={`pref-${t.key}`} className="cursor-pointer">{t.label}</Label>
            {t.help && <p className="text-xs text-muted-foreground mt-0.5">{t.help}</p>}
          </div>
          <Switch
            id={`pref-${t.key}`}
            checked={!!prefs[t.key]}
            onCheckedChange={(v) => setPrefs({ ...prefs, [t.key]: v })}
          />
        </div>
      ))}
      <Card className="p-3 bg-muted/40">
        <div className="text-sm font-medium mb-2">Csendes órák</div>
        <div className="flex gap-2 items-center">
          <Input
            type="time"
            aria-label="Csendes órák kezdete"
            value={prefs.quiet_hours_start ?? ""}
            onChange={(e) => setPrefs({ ...prefs, quiet_hours_start: e.target.value || null })}
            className="w-32"
          />
          <span className="text-muted-foreground">–</span>
          <Input
            type="time"
            aria-label="Csendes órák vége"
            value={prefs.quiet_hours_end ?? ""}
            onChange={(e) => setPrefs({ ...prefs, quiet_hours_end: e.target.value || null })}
            className="w-32"
          />
        </div>
        <p className="text-xs text-muted-foreground mt-2">A csendes órák alatt csak a kritikus riasztások jönnek át.</p>
      </Card>
      <Button onClick={save} disabled={saving}>
        {saving ? "Mentés…" : "Mentés"}
      </Button>
    </div>
  );
}
