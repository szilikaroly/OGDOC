import { Wifi, WifiOff, Loader2, AlertTriangle, RefreshCw } from "lucide-react";
import type { EmergencyCardRealtime } from "@/lib/portal/use-emergency-card-realtime";
import { cn } from "@/lib/utils";

/**
 * Compact connection-state pill for the SOS / emergency-card realtime channel.
 * Renders the live link status plus the most recent remote change time.
 */
export function RealtimeStatusPill({
  rt,
  className,
  showLastEvent = true,
}: {
  rt: EmergencyCardRealtime;
  className?: string;
  showLastEvent?: boolean;
}) {
  const { status, lastEventAt, attempts } = rt;
  const map = {
    idle: { label: "Inaktív", Icon: WifiOff, tone: "text-muted-foreground bg-muted" },
    connecting: { label: "Kapcsolódás…", Icon: Loader2, tone: "text-amber-700 bg-amber-500/15", spin: true },
    reconnecting: {
      label: `Újrakapcsolódás${attempts ? ` (${attempts}.)` : ""}…`,
      Icon: RefreshCw,
      tone: "text-amber-700 bg-amber-500/15",
      spin: true,
    },
    subscribed: { label: "Élő szinkron", Icon: Wifi, tone: "text-emerald-700 bg-emerald-500/15" },
    error: { label: "Kapcsolat megszakadt", Icon: AlertTriangle, tone: "text-destructive bg-destructive/10" },
    closed: { label: "Lezárva", Icon: WifiOff, tone: "text-muted-foreground bg-muted" },
  } as const;
  const m = map[status];
  const Icon = m.Icon;
  return (
    <div
      role="status"
      aria-live="polite"
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[11px] font-medium",
        m.tone,
        className,
      )}
      title={rt.lastError ?? undefined}
    >
      <Icon className={cn("h-3 w-3", (m as any).spin && "animate-spin")} />
      <span>{m.label}</span>
      {showLastEvent && lastEventAt && (
        <span className="text-muted-foreground/80 font-normal">
          · frissült {lastEventAt.toLocaleTimeString("hu-HU", { hour: "2-digit", minute: "2-digit" })}
        </span>
      )}
    </div>
  );
}
