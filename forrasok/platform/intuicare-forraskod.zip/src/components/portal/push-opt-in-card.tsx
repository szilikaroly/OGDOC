import { useEffect, useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Bell, BellOff, Loader2, AlertTriangle, CheckCircle2, RefreshCw, ShieldAlert } from "lucide-react";
import { toast } from "sonner";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/ui/status-badge";
import { savePushSubscription, deletePushSubscription, getVapidPublicKey } from "@/lib/push/push.functions";
import { haptic } from "@/lib/query/optimistic";

function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const raw = atob(base64);
  const out = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
  return out;
}

type State =
  | { kind: "loading" }
  | { kind: "unsupported"; reason: string }
  | { kind: "denied" }
  | { kind: "idle"; subscribed: boolean; endpoint: string | null };

/**
 * Push opt-in kártya a /portal/ertesitesek oldalra. Kiemelt CTA, állapotjelzés
 * (támogatott / engedélyezve / letiltva / feliratkozva), és hiba esetén
 * visszaállítás (subscription törlés + újrapróbálás).
 */
export function PushOptInCard() {
  const [state, setState] = useState<State>({ kind: "loading" });
  const [error, setError] = useState<string | null>(null);
  const save = useServerFn(savePushSubscription);
  const remove = useServerFn(deletePushSubscription);
  const getKey = useServerFn(getVapidPublicKey);

  const refreshState = async () => {
    setError(null);
    if (typeof window === "undefined") return;
    if (!("serviceWorker" in navigator) || !("PushManager" in window) || !("Notification" in window)) {
      setState({ kind: "unsupported", reason: "A böngésződ nem támogatja a web push értesítéseket." });
      return;
    }
    if (Notification.permission === "denied") {
      setState({ kind: "denied" });
      return;
    }
    try {
      const reg = await navigator.serviceWorker.ready;
      const sub = await reg.pushManager.getSubscription();
      setState({ kind: "idle", subscribed: !!sub, endpoint: sub?.endpoint ?? null });
    } catch (e) {
      setState({ kind: "idle", subscribed: false, endpoint: null });
      setError((e as Error).message);
    }
  };

  useEffect(() => {
    void refreshState();
  }, []);

  const enable = useMutation({
    mutationFn: async () => {
      haptic(10);
      const { publicKey } = await getKey();
      if (!publicKey) throw new Error("A push szolgáltatás nincs beállítva (hiányzó VAPID kulcs).");
      const perm = await Notification.requestPermission();
      if (perm !== "granted") throw new Error("Engedély megtagadva. Engedélyezd a böngésző beállításaiban.");
      const reg = await navigator.serviceWorker.ready;
      const sub =
        (await reg.pushManager.getSubscription()) ??
        (await reg.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: urlBase64ToUint8Array(publicKey) as unknown as BufferSource,
        }));
      const json = sub.toJSON() as { endpoint: string; keys: { p256dh: string; auth: string } };
      await save({
        data: {
          endpoint: json.endpoint,
          p256dh: json.keys.p256dh,
          auth: json.keys.auth,
          user_agent: navigator.userAgent.slice(0, 200),
        },
      });
    },
    onSuccess: async () => {
      haptic([8, 30, 8]);
      toast.success("Push értesítések bekapcsolva");
      await refreshState();
    },
    onError: (e: Error) => {
      haptic([20, 40, 20]);
      setError(e.message ?? "Ismeretlen hiba");
      toast.error(e.message ?? "Push engedélyezés hiba");
    },
  });

  const disable = useMutation({
    mutationFn: async () => {
      haptic(8);
      const reg = await navigator.serviceWorker.ready;
      const sub = await reg.pushManager.getSubscription();
      if (sub) {
        const endpoint = sub.endpoint;
        await sub.unsubscribe();
        try {
          await remove({ data: { endpoint } });
        } catch {
          // szerveroldali törlés hibája nem blokkoló
        }
      }
    },
    onSuccess: async () => {
      toast.success("Push értesítések kikapcsolva");
      await refreshState();
    },
    onError: (e: Error) => {
      haptic([20, 40, 20]);
      setError(e.message ?? "Ismeretlen hiba");
      toast.error(e.message ?? "Push kikapcsolás hiba");
    },
  });

  // Hiba esetén "visszaállítás": lokális subscription törlése + friss subscribe
  const reset = useMutation({
    mutationFn: async () => {
      haptic(12);
      const reg = await navigator.serviceWorker.ready;
      const existing = await reg.pushManager.getSubscription();
      if (existing) {
        try {
          await remove({ data: { endpoint: existing.endpoint } });
        } catch {
          // ignore
        }
        await existing.unsubscribe();
      }
      setError(null);
      await refreshState();
    },
    onSuccess: () => {
      toast.success("Állapot visszaállítva. Kérlek próbáld újra az engedélyezést.");
    },
    onError: (e: Error) => toast.error(e.message ?? "Nem sikerült visszaállítani"),
  });

  const busy = enable.isPending || disable.isPending || reset.isPending;

  return (
    <Card className="p-4 sm:p-5 border-primary/30 bg-primary/[0.03]">
      <div className="flex flex-col sm:flex-row sm:items-start gap-3 sm:gap-4">
        <div className="shrink-0 size-10 rounded-full bg-primary/10 text-primary flex items-center justify-center">
          {state.kind === "idle" && state.subscribed ? <CheckCircle2 className="size-5" /> : <Bell className="size-5" />}
        </div>
        <div className="flex-1 min-w-0 space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            <h2 className="text-base sm:text-lg font-semibold">Web push értesítések</h2>
            <StatusIndicator state={state} />
          </div>
          <p className="text-sm text-muted-foreground">
            Kapj azonnali jelzést új leletekről, időpont-változásról és üzenetekről — akkor is, ha az oldal éppen nincs nyitva.
          </p>

          {error && (
            <div className="flex items-start gap-2 text-xs bg-destructive/10 text-destructive p-2 rounded">
              <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
              <div className="min-w-0 break-words flex-1">{error}</div>
              <Button
                variant="outline"
                size="sm"
                className="ml-2 shrink-0 min-h-9"
                disabled={busy}
                onClick={() => reset.mutate()}
              >
                {reset.isPending ? <Loader2 className="size-3.5 animate-spin" /> : <RefreshCw className="size-3.5 mr-1" />}
                Visszaállítás
              </Button>
            </div>
          )}

          {state.kind === "denied" && (
            <div className="flex items-start gap-2 text-xs bg-warning/10 text-foreground p-2 rounded border border-warning/30">
              <ShieldAlert className="h-4 w-4 shrink-0 mt-0.5 text-warning-foreground" />
              <span>
                A böngésző letiltotta a push engedélyt ehhez az oldalhoz. Nyisd meg a címsor melletti lakat ikont, és állítsd
                „Engedélyezve” értékre, majd frissíts.
              </span>
            </div>
          )}

          <div className="flex flex-wrap gap-2 pt-1">
            {state.kind === "loading" && (
              <Button disabled className="min-h-11">
                <Loader2 className="size-4 animate-spin mr-1.5" /> Állapot betöltése…
              </Button>
            )}

            {state.kind === "idle" && !state.subscribed && (
              <Button
                onClick={() => enable.mutate()}
                disabled={busy}
                className="min-h-11 gap-1.5"
              >
                {enable.isPending ? <Loader2 className="size-4 animate-spin" /> : <Bell className="size-4" />}
                Engedélyezés bekapcsolása
              </Button>
            )}

            {state.kind === "idle" && state.subscribed && (
              <>
                <Button
                  variant="outline"
                  onClick={() => disable.mutate()}
                  disabled={busy}
                  className="min-h-11 gap-1.5"
                >
                  {disable.isPending ? <Loader2 className="size-4 animate-spin" /> : <BellOff className="size-4" />}
                  Kikapcsolás
                </Button>
                <Button
                  variant="ghost"
                  onClick={() => reset.mutate()}
                  disabled={busy}
                  className="min-h-11 gap-1.5"
                  aria-label="Visszaállítás"
                  title="Törli és újra létrehozza a feliratkozást"
                >
                  {reset.isPending ? <Loader2 className="size-4 animate-spin" /> : <RefreshCw className="size-4" />}
                  Visszaállítás
                </Button>
              </>
            )}

            {state.kind === "denied" && (
              <Button
                variant="outline"
                onClick={() => void refreshState()}
                className="min-h-11 gap-1.5"
              >
                <RefreshCw className="size-4" /> Állapot ellenőrzése
              </Button>
            )}

            {state.kind === "unsupported" && (
              <span className="text-xs text-muted-foreground">{state.reason}</span>
            )}
          </div>
        </div>
      </div>
    </Card>
  );
}

function StatusIndicator({ state }: { state: State }) {
  if (state.kind === "loading") return <StatusBadge tone="neutral" size="xs" pill>Ellenőrzés…</StatusBadge>;
  if (state.kind === "unsupported") return <StatusBadge tone="neutral" size="xs" pill>Nem támogatott</StatusBadge>;
  if (state.kind === "denied") return <StatusBadge tone="bad" size="xs" pill>Letiltva</StatusBadge>;
  if (state.subscribed) return <StatusBadge tone="ok" size="xs" pill>Aktív</StatusBadge>;
  return <StatusBadge tone="warn" size="xs" pill>Nincs bekapcsolva</StatusBadge>;
}
