import { useMemo, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, ArrowRight, GitMerge, Check } from "lucide-react";

export type CardRow = {
  vercsoport?: string | null;
  allergiak?: string[] | null;
  kronikus_betegsegek?: string[] | null;
  gyogyszerek?: string[] | null;
  gyogyszer_erzekenyseg?: string[] | null;
  etrend?: string | null;
  sos_kontakt_nev?: string | null;
  sos_kontakt_telefon?: string | null;
  kapcsolt_orvos_telefon?: string | null;
  egyeb_info?: string | null;
};

type Choice = "mine" | "theirs" | "merge";

type FieldDef = { key: keyof CardRow; label: string; kind: "string" | "array" };

const FIELDS: FieldDef[] = [
  { key: "vercsoport", label: "Vércsoport", kind: "string" },
  { key: "etrend", label: "Étrend / diéta", kind: "string" },
  { key: "allergiak", label: "Allergiák", kind: "array" },
  { key: "gyogyszer_erzekenyseg", label: "Gyógyszerérzékenységek", kind: "array" },
  { key: "kronikus_betegsegek", label: "Krónikus betegségek", kind: "array" },
  { key: "gyogyszerek", label: "Rendszeres gyógyszerek", kind: "array" },
  { key: "sos_kontakt_nev", label: "SOS kontakt neve", kind: "string" },
  { key: "sos_kontakt_telefon", label: "SOS kontakt telefon", kind: "string" },
  { key: "kapcsolt_orvos_telefon", label: "Háziorvos / kezelőorvos telefon", kind: "string" },
  { key: "egyeb_info", label: "Egyéb információ", kind: "string" },
];

function asArr(v: unknown): string[] {
  return Array.isArray(v) ? (v as string[]).filter(Boolean) : [];
}
function asStr(v: unknown): string {
  return v == null ? "" : String(v);
}
function arrEq(a: string[], b: string[]) {
  if (a.length !== b.length) return false;
  const sa = [...a].sort();
  const sb = [...b].sort();
  return sa.every((x, i) => x === sb[i]);
}

export function EmergencyCardDiffDialog({
  open,
  onOpenChange,
  mine,
  theirs,
  onApply,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  mine: CardRow;
  theirs: CardRow;
  onApply: (merged: CardRow) => void;
}) {
  type Diff = FieldDef & { mineVal: string | string[]; theirsVal: string | string[] };
  const diffs = useMemo<Diff[]>(() => {
    const out: Diff[] = [];
    for (const f of FIELDS) {
      if (f.kind === "array") {
        const a = asArr(mine[f.key]);
        const b = asArr(theirs[f.key]);
        if (!arrEq(a, b)) out.push({ ...f, mineVal: a, theirsVal: b });
      } else {
        const a = asStr(mine[f.key]);
        const b = asStr(theirs[f.key]);
        if (a !== b) out.push({ ...f, mineVal: a, theirsVal: b });
      }
    }
    return out;
  }, [mine, theirs]);

  const [choices, setChoices] = useState<Record<string, Choice>>(() =>
    Object.fromEntries(diffs.map((d) => [d.key, d.kind === "array" ? "merge" : "theirs"])),
  );

  // Reset choices when diffs identity changes (new remote update)
  useMemo(() => {
    setChoices(Object.fromEntries(diffs.map((d) => [d.key, d.kind === "array" ? "merge" : "theirs"])));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [diffs.length, diffs.map((d) => d.key).join("|")]);

  function setAll(c: Choice) {
    setChoices(Object.fromEntries(diffs.map((d) => [d.key, d.kind === "array" || c !== "merge" ? c : "theirs"])));
  }

  function apply() {
    const merged: CardRow = { ...mine };
    for (const d of diffs) {
      const c = choices[d.key];
      if (d.kind === "array") {
        if (c === "mine") (merged as any)[d.key] = d.mineVal;
        else if (c === "theirs") (merged as any)[d.key] = d.theirsVal;
        else (merged as any)[d.key] = Array.from(new Set([...d.mineVal, ...d.theirsVal]));
      } else {
        (merged as any)[d.key] = c === "mine" ? d.mineVal : d.theirsVal;
      }
    }
    onApply(merged);
    onOpenChange(false);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <GitMerge className="h-4 w-4" /> SOS kártya — beérkező változások
          </DialogTitle>
          <DialogDescription>
            Egy másik felületen frissítették az adatokat. Válaszd ki mezőnként, melyik értéket tartsd meg, vagy egyesítsd a két verziót.
          </DialogDescription>
        </DialogHeader>

        {diffs.length === 0 ? (
          <p className="text-sm text-muted-foreground">Nincs eltérés — a verziók azonosak.</p>
        ) : (
          <>
            <div className="flex flex-wrap gap-2 text-xs">
              <Button size="sm" variant="outline" onClick={() => setAll("mine")}>
                <ArrowLeft className="h-3 w-3 mr-1" /> Mindenhol az enyém
              </Button>
              <Button size="sm" variant="outline" onClick={() => setAll("theirs")}>
                <ArrowRight className="h-3 w-3 mr-1" /> Mindenhol az új
              </Button>
              <Button size="sm" variant="outline" onClick={() => setAll("merge")}>
                <GitMerge className="h-3 w-3 mr-1" /> Listáknál egyesítés
              </Button>
            </div>

            <div className="divide-y rounded border">
              {diffs.map((d) => (
                <div key={d.key} className="p-3 space-y-2">
                  <div className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{d.label}</div>
                  <div className="grid sm:grid-cols-2 gap-2">
                    <ValueCard
                      title="Az ön verziója"
                      kind={d.kind}
                      value={d.kind === "array" ? d.mineVal : d.mineVal}
                      selected={choices[d.key] === "mine"}
                      onClick={() => setChoices({ ...choices, [d.key]: "mine" })}
                    />
                    <ValueCard
                      title="Beérkezett verzió"
                      kind={d.kind}
                      value={d.kind === "array" ? d.theirsVal : d.theirsVal}
                      selected={choices[d.key] === "theirs"}
                      onClick={() => setChoices({ ...choices, [d.key]: "theirs" })}
                    />
                  </div>
                  {d.kind === "array" && (
                    <button
                      onClick={() => setChoices({ ...choices, [d.key]: "merge" })}
                      className={
                        "w-full text-left rounded border px-3 py-2 text-xs " +
                        (choices[d.key] === "merge"
                          ? "border-primary bg-primary/5"
                          : "border-dashed border-border hover:bg-accent/30")
                      }
                    >
                      <div className="flex items-center gap-1 font-medium mb-1">
                        <GitMerge className="h-3 w-3" /> Egyesítés (mindkét lista együtt, duplikátumok nélkül)
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {Array.from(new Set([...(d.mineVal as string[]), ...(d.theirsVal as string[])])).map((v) => (
                          <Badge key={v} variant="secondary">{v}</Badge>
                        ))}
                      </div>
                    </button>
                  )}
                </div>
              ))}
            </div>
          </>
        )}

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>Mégse (saját verzió marad)</Button>
          <Button onClick={apply} disabled={diffs.length === 0}>
            <Check className="h-4 w-4 mr-1" /> Választás alkalmazása
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function ValueCard({
  title,
  kind,
  value,
  selected,
  onClick,
}: {
  title: string;
  kind: "string" | "array";
  value: string | string[];
  selected: boolean;
  onClick: () => void;
}) {
  const empty = kind === "array" ? !(value as string[]).length : !value;
  return (
    <button
      onClick={onClick}
      className={
        "text-left rounded border px-3 py-2 text-xs transition " +
        (selected ? "border-primary bg-primary/5" : "border-border hover:bg-accent/30")
      }
    >
      <div className="font-medium mb-1">{title}</div>
      {empty ? (
        <span className="italic text-muted-foreground">— üres —</span>
      ) : kind === "array" ? (
        <div className="flex flex-wrap gap-1">
          {(value as string[]).map((v) => (
            <Badge key={v} variant="outline">{v}</Badge>
          ))}
        </div>
      ) : (
        <span className="break-words">{value as string}</span>
      )}
    </button>
  );
}
