import { useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useMyPatients } from "@/lib/portal/patient-context";

/**
 * Globális realtime feliratkozás a portál belül: új lelet / üzenet / kritikus riasztás / értesítés.
 * Mount-olva a PatientPortalShell-be — egyszer él, függetlenül az aktív route-tól.
 */
export function PortalRealtime() {
  const qc = useQueryClient();
  const { data: patients } = useMyPatients();
  const patientIds = (patients ?? []).map((p) => p.id);

  useEffect(() => {
    if (patientIds.length === 0) return;
    const filter = `patient_id=in.(${patientIds.join(",")})`;
    const ch = supabase
      .channel("portal-realtime")
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "clinical_observations", filter }, () => {
        toast.info("Új lelet érkezett.");
        qc.invalidateQueries({ queryKey: ["portal", "obs"] });
        qc.invalidateQueries({ queryKey: ["portal", "recent-obs"] });
      })
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "clinical_critical_alerts", filter }, () => {
        toast.warning("Új kritikus riasztás!");
        qc.invalidateQueries({ queryKey: ["portal", "alerts"] });
      })
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "appointments", filter }, () => {
        qc.invalidateQueries({ queryKey: ["portal"] });
      })
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [patientIds.join(","), qc]);

  useEffect(() => {
    let userId: string | null = null;
    let ch: ReturnType<typeof supabase.channel> | null = null;
    (async () => {
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) return;
      userId = u.user.id;
      // azon beszélgetések, ahol a user résztvevő
      const { data: parts } = await supabase
        .from("conversation_participants")
        .select("conversation_id")
        .eq("user_id", userId);
      const convIds = (parts ?? []).map((p: any) => p.conversation_id);
      const convFilter = convIds.length > 0 ? `conversation_id=in.(${convIds.join(",")})` : null;

      const channel = supabase.channel(`portal-user-${userId}`);
      channel.on("postgres_changes", { event: "INSERT", schema: "public", table: "notifications", filter: `user_id=eq.${userId}` }, (payload: any) => {
        toast.info(payload.new?.cim ?? "Új értesítés");
        qc.invalidateQueries({ queryKey: ["portal", "notifications"] });
      });
      if (convFilter) {
        channel.on("postgres_changes", { event: "INSERT", schema: "public", table: "messages", filter: convFilter }, () => {
          qc.invalidateQueries({ queryKey: ["portal", "messages"] });
          qc.invalidateQueries({ queryKey: ["portal", "conversations"] });
        });
      }
      channel.subscribe();
      ch = channel;
    })();
    return () => {
      if (ch) supabase.removeChannel(ch);
    };
  }, [qc]);

  return null;
}
