/**
 * PWA "Telepítés a kezdőképernyőre" banner.
 *
 * – Csak production-ben, csak mobil viewport-on, csak ha még nem dismisselt
 *   (localStorage flag), és csak ha a böngésző tényleg küld
 *   `beforeinstallprompt` eseményt (Chromium-alapú Android).
 * – iOS Safari: külön egyszerű hint (mert ott nincs prompt API).
 * – Sticky alul, `pb-safe`, 7 napos dismissal.
 */
import { useEffect, useState } from "react";
import { Download, X, Share } from "lucide-react";
import { Button } from "@/components/ui/button";

type BIPEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

const STORAGE_KEY = "pwa-install-dismissed-at";
const SEVEN_DAYS = 7 * 24 * 60 * 60 * 1000;

function isDismissed() {
  try {
    const v = localStorage.getItem(STORAGE_KEY);
    if (!v) return false;
    return Date.now() - Number(v) < SEVEN_DAYS;
  } catch {
    return false;
  }
}

function isStandalone() {
  if (typeof window === "undefined") return false;
  return (
    window.matchMedia?.("(display-mode: standalone)").matches ||
    (window.navigator as any).standalone === true
  );
}

function isIos() {
  if (typeof navigator === "undefined") return false;
  return /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream;
}

export function PwaInstallPrompt() {
  const [deferred, setDeferred] = useState<BIPEvent | null>(null);
  const [iosHint, setIosHint] = useState(false);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (!import.meta.env.PROD) return;
    if (isStandalone() || isDismissed()) return;
    if (window.innerWidth > 768) return;

    function onPrompt(e: Event) {
      e.preventDefault();
      setDeferred(e as BIPEvent);
      setVisible(true);
    }
    window.addEventListener("beforeinstallprompt", onPrompt);

    // iOS fallback – nincs prompt API, csak instrukció
    if (isIos()) {
      const t = setTimeout(() => {
        setIosHint(true);
        setVisible(true);
      }, 4000);
      return () => {
        clearTimeout(t);
        window.removeEventListener("beforeinstallprompt", onPrompt);
      };
    }
    return () => window.removeEventListener("beforeinstallprompt", onPrompt);
  }, []);

  function dismiss() {
    try {
      localStorage.setItem(STORAGE_KEY, String(Date.now()));
    } catch {}
    setVisible(false);
  }

  async function install() {
    if (!deferred) return;
    try {
      await deferred.prompt();
      await deferred.userChoice;
    } catch {
      /* ignore */
    } finally {
      setDeferred(null);
      dismiss();
    }
  }

  if (!visible) return null;

  return (
    <div
      role="dialog"
      aria-label="Alkalmazás telepítése"
      className="fixed inset-x-2 bottom-2 z-40 lg:hidden bg-card border border-border rounded-xl shadow-lg pb-safe animate-in slide-in-from-bottom-4"
      style={{ marginBottom: "calc(env(safe-area-inset-bottom) + 4rem)" }}
    >
      <div className="p-3 flex items-start gap-3">
        <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/10 text-primary shrink-0">
          <Download className="h-5 w-5" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="font-semibold text-sm">Telepítsd a kezdőképernyőre</div>
          {iosHint ? (
            <p className="text-xs text-muted-foreground mt-1">
              Koppints a <Share className="inline h-3 w-3 mx-0.5" /> Megosztás gombra, majd
              "Hozzáadás a kezdőképernyőhöz".
            </p>
          ) : (
            <p className="text-xs text-muted-foreground mt-1">
              Egy koppintással elérhető lesz, gyorsabban indul, és push értesítést is kaphatsz.
            </p>
          )}
          {!iosHint && deferred && (
            <Button size="sm" className="mt-2 min-h-10" onClick={install}>
              Telepítés
            </Button>
          )}
        </div>
        <button
          type="button"
          onClick={dismiss}
          aria-label="Bezárás"
          className="text-muted-foreground hover:text-foreground min-h-11 min-w-11 -mt-1 -mr-1 flex items-center justify-center rounded-md"
        >
          <X className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}
