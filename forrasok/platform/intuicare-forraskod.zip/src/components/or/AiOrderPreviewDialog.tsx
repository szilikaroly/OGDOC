import { ArrowRight, Sparkles, Loader2, AlertTriangle, CheckCircle2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export type PreviewCase = {
  id: string;
  becsult_idotartam_perc: number | null;
  prioritas: string | null;
};

type Props = {
  open: boolean;
  loading: boolean;
  applying: boolean;
  blockStart?: string | null; // "HH:MM[:SS]"
  blockEnd?: string | null;
  turnoverMin?: number;
  currentCases: PreviewCase[];
  proposedOrder: string[]; // case ids
  rationale: string;
  onCancel: () => void;
  onApply: () => void;
};

function hmToMin(s?: string | null) {
  if (!s) return 0;
  const [h, m] = s.split(":");
  return parseInt(h) * 60 + parseInt(m);
}

function projectOverflow(cases: PreviewCase[], blockStart?: string | null, blockEnd?: string | null, turnover = 15) {
  const startM = hmToMin(blockStart);
  const endM = hmToMin(blockEnd);
  const windowMin = Math.max(0, endM - startM);
  let cursor = 0;
  let overflowMin = 0;
  let overflowCount = 0;
  for (const c of cases) {
    const dur = c.becsult_idotartam_perc ?? 60;
    const caseEnd = cursor + dur;
    if (caseEnd > windowMin) {
      overflowCount += 1;
      overflowMin += caseEnd - Math.max(cursor, windowMin);
    }
    cursor = caseEnd + turnover;
  }
  return { overflowCount, overflowMin };
}

const PRIO_RANK: Record<string, number> = { azonnali: 0, sürgos: 1, elektiv: 2 };

function priorityViolations(cases: PreviewCase[]) {
  // count adjacent pairs where a lower-priority case precedes a higher-priority one
  let v = 0;
  for (let i = 1; i < cases.length; i++) {
    const prev = PRIO_RANK[cases[i - 1].prioritas ?? "elektiv"] ?? 2;
    const cur = PRIO_RANK[cases[i].prioritas ?? "elektiv"] ?? 2;
    if (prev > cur) v++;
  }
  return v;
}

export function AiOrderPreviewDialog({
  open,
  loading,
  applying,
  blockStart,
  blockEnd,
  turnoverMin = 15,
  currentCases,
  proposedOrder,
  rationale,
  onCancel,
  onApply,
}: Props) {
  const byId = new Map(currentCases.map((c) => [c.id, c]));
  const proposed: PreviewCase[] = proposedOrder
    .map((id) => byId.get(id))
    .filter((c): c is PreviewCase => !!c);

  const before = projectOverflow(currentCases, blockStart, blockEnd, turnoverMin);
  const after = projectOverflow(proposed, blockStart, blockEnd, turnoverMin);
  const prioBefore = priorityViolations(currentCases);
  const prioAfter = priorityViolations(proposed);
  const overflowDelta = before.overflowMin - after.overflowMin;
  const prioDelta = prioBefore - prioAfter;

  const positions = new Map(currentCases.map((c, i) => [c.id, i]));

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onCancel()}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="size-4 text-primary" /> AI rendezés előnézet
          </DialogTitle>
          <DialogDescription>
            Tekintsd át a javasolt sorrendet, mielőtt alkalmazod. {blockStart?.slice(0, 5)}–{blockEnd?.slice(0, 5)} blokk · forduló {turnoverMin}p
          </DialogDescription>
        </DialogHeader>

        {loading ? (
          <div className="flex items-center justify-center py-12 text-sm text-muted-foreground">
            <Loader2 className="size-4 animate-spin mr-2" /> AI elemzi a blokkot…
          </div>
        ) : (
          <div className="space-y-4">
            {/* Impact metrics */}
            <div className="grid grid-cols-2 gap-2">
              <MetricCard
                label="Blokkból kifutó idő"
                beforeText={`${before.overflowMin}p (${before.overflowCount} eset)`}
                afterText={`${after.overflowMin}p (${after.overflowCount} eset)`}
                deltaMin={overflowDelta}
                unit="p"
              />
              <MetricCard
                label="Prioritás-szabálysértés"
                beforeText={`${prioBefore} hely`}
                afterText={`${prioAfter} hely`}
                deltaMin={prioDelta}
                unit=""
              />
            </div>

            {/* Rationale */}
            {rationale && (
              <div className="rounded-md border border-border bg-muted/30 p-3 text-xs">
                <div className="font-mono uppercase tracking-wider text-[10px] text-muted-foreground mb-1">
                  AI indoklás
                </div>
                <p>{rationale}</p>
              </div>
            )}

            {/* Side-by-side order */}
            <div className="grid grid-cols-2 gap-3">
              <OrderColumn title="Jelenleg" cases={currentCases} />
              <OrderColumn
                title="Javasolt"
                cases={proposed}
                originalPositions={positions}
              />
            </div>
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={onCancel} disabled={applying}>
            Mégse
          </Button>
          <Button onClick={onApply} disabled={loading || applying || proposed.length === 0}>
            {applying ? <Loader2 className="size-4 animate-spin mr-2" /> : <Sparkles className="size-4 mr-2" />}
            Sorrend alkalmazása
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function MetricCard({
  label,
  beforeText,
  afterText,
  deltaMin,
  unit,
}: {
  label: string;
  beforeText: string;
  afterText: string;
  deltaMin: number;
  unit: string;
}) {
  const improved = deltaMin > 0;
  const same = deltaMin === 0;
  return (
    <div className="rounded-md border border-border p-2.5 text-xs">
      <div className="font-mono uppercase tracking-wider text-[10px] text-muted-foreground">{label}</div>
      <div className="flex items-center gap-1.5 mt-1">
        <span className="text-muted-foreground line-through">{beforeText}</span>
        <ArrowRight className="size-3" />
        <span className="font-semibold">{afterText}</span>
      </div>
      <div
        className={cn(
          "mt-1 flex items-center gap-1 text-[11px] font-semibold",
          improved && "text-emerald-600",
          same && "text-muted-foreground",
          !improved && !same && "text-destructive",
        )}
      >
        {improved && <CheckCircle2 className="size-3" />}
        {!improved && !same && <AlertTriangle className="size-3" />}
        {same ? "változatlan" : improved ? `−${deltaMin}${unit} javulás` : `+${Math.abs(deltaMin)}${unit} romlás`}
      </div>
    </div>
  );
}

function OrderColumn({
  title,
  cases,
  originalPositions,
}: {
  title: string;
  cases: PreviewCase[];
  originalPositions?: Map<string, number>;
}) {
  return (
    <div>
      <div className="font-mono uppercase tracking-wider text-[10px] text-muted-foreground mb-1.5">{title}</div>
      <ol className="space-y-1">
        {cases.map((c, i) => {
          const origIdx = originalPositions?.get(c.id);
          const moved = origIdx !== undefined && origIdx !== i;
          const movedUp = moved && origIdx! > i;
          return (
            <li
              key={c.id}
              className={cn(
                "flex items-center justify-between gap-2 rounded border border-border bg-card px-2 py-1.5 text-xs",
                moved && (movedUp ? "border-emerald-500/40 bg-emerald-500/5" : "border-amber-500/40 bg-amber-500/5"),
                c.prioritas === "azonnali" && "border-destructive ring-1 ring-destructive/30",
              )}
            >
              <div className="flex items-center gap-1.5 min-w-0">
                <span className="text-[10px] font-mono text-muted-foreground">#{i + 1}</span>
                <span className="font-semibold truncate">#{c.id.slice(0, 6)}</span>
                {moved && (
                  <span
                    className={cn(
                      "text-[10px] font-mono",
                      movedUp ? "text-emerald-600" : "text-amber-600",
                    )}
                  >
                    {movedUp ? `↑${origIdx! - i}` : `↓${i - origIdx!}`}
                  </span>
                )}
              </div>
              <span className="text-[10px] font-mono text-muted-foreground shrink-0">
                {c.becsult_idotartam_perc}p · {c.prioritas ?? "elektiv"}
              </span>
            </li>
          );
        })}
      </ol>
    </div>
  );
}
