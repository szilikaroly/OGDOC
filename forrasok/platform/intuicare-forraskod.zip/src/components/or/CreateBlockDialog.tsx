import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { createBlock, listOrOrgUnits, listSpecialties } from "@/lib/or/board.functions";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";

type Props = {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  date: string;
  onCreated?: (blockId: string) => void;
};

export function CreateBlockDialog({ open, onOpenChange, date, onCreated }: Props) {
  const qc = useQueryClient();
  const listUnits = useServerFn(listOrOrgUnits);
  const listSpec = useServerFn(listSpecialties);
  const create = useServerFn(createBlock);

  const { data: units = [] } = useQuery({
    queryKey: ["or-org-units"],
    queryFn: () => listUnits(),
    enabled: open,
  });
  const { data: specialties = [] } = useQuery({
    queryKey: ["specialties"],
    queryFn: () => listSpec(),
    enabled: open,
  });

  const [orgUnitId, setOrgUnitId] = useState<string>("");
  const [specialtyId, setSpecialtyId] = useState<string>("");
  const [start, setStart] = useState("08:00");
  const [end, setEnd] = useState("14:00");
  const [note, setNote] = useState("");

  useEffect(() => {
    if (open && !orgUnitId && units.length) setOrgUnitId(units[0].id);
  }, [open, units, orgUnitId]);

  const mut = useMutation({
    mutationFn: () =>
      create({
        data: {
          org_unit_id: orgUnitId,
          datum: date,
          kezdo_ido: start,
          veg_ido: end,
          specialty_id: specialtyId || null,
          megjegyzes: note || null,
        },
      }),
    onSuccess: (res) => {
      toast.success("Blokk létrehozva");
      qc.invalidateQueries({ queryKey: ["or-board", date] });
      onOpenChange(false);
      onCreated?.(res.id);
      setNote("");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const canSubmit = !!orgUnitId && start < end && !mut.isPending;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Új műtéti blokk</DialogTitle>
          <DialogDescription>Töltse ki a kötelező mezőket — műtő és idősáv.</DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="cb-date">Dátum</Label>
            <Input id="cb-date" value={date} disabled />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="cb-room">Műtő *</Label>
            <select
              id="cb-room"
              value={orgUnitId}
              onChange={(e) => setOrgUnitId(e.target.value)}
              className="h-9 w-full rounded-md border border-border bg-background px-3 text-sm"
            >
              <option value="">— Válasszon —</option>
              {units.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.nev}
                </option>
              ))}
            </select>
            {units.length === 0 && (
              <p className="text-xs text-muted-foreground">Nincs aktív műtő-profil. Először hozzon létre egy műtőt.</p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="cb-start">Kezdés *</Label>
              <Input id="cb-start" type="time" value={start} onChange={(e) => setStart(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="cb-end">Vége *</Label>
              <Input id="cb-end" type="time" value={end} onChange={(e) => setEnd(e.target.value)} />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="cb-spec">Szakterület (csapat)</Label>
            <select
              id="cb-spec"
              value={specialtyId}
              onChange={(e) => setSpecialtyId(e.target.value)}
              className="h-9 w-full rounded-md border border-border bg-background px-3 text-sm"
            >
              <option value="">— Bármelyik —</option>
              {specialties.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.nev}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="cb-note">Megjegyzés</Label>
            <Textarea id="cb-note" value={note} onChange={(e) => setNote(e.target.value)} rows={2} />
          </div>
        </div>

        <DialogFooter>
          <button
            type="button"
            onClick={() => onOpenChange(false)}
            className="h-9 rounded-md border border-border px-3 text-sm hover:bg-muted"
          >
            Mégse
          </button>
          <button
            type="button"
            onClick={() => mut.mutate()}
            disabled={!canSubmit}
            className="h-9 inline-flex items-center gap-2 rounded-md bg-primary px-3 text-sm font-semibold text-primary-foreground hover:opacity-90 disabled:opacity-50"
          >
            {mut.isPending && <Loader2 className="size-4 animate-spin" />}
            Létrehozás
          </button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
