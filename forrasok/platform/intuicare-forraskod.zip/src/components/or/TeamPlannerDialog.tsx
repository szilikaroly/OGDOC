import { useMemo, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  aiGenerateTeamPlan,
  applyTeamPlan,
  type TeamPlanResult,
  type TeamPlanItem,
  type EligiblePerson,
} from "@/lib/or/team.functions";
import { toast } from "sonner";
import { AlertTriangle, ArrowLeftRight, GraduationCap, Loader2, Shield, Sparkles, Star, Users, Wand2 } from "lucide-react";
import { cn } from "@/lib/utils";


type Props = {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  date: string;
};

const SZEREP_LABEL: Record<string, string> = {
  operator: "Operatőr",
  asszisztens: "Asszisztens",
  felugyelo: "Felügyelet",
};
const SZEREP_TONE: Record<string, string> = {
  operator: "bg-primary/15 text-primary",
  asszisztens: "bg-blue-500/15 text-blue-600",
  felugyelo: "bg-amber-500/15 text-amber-700",
};

function capacityLabel(p: EligiblePerson): string {
  const next = p.next_assignments.length
    ? ` · Köv: ${p.next_assignments.map((n) => `${n.date.slice(5)} ${n.type_name}`).join(" / ")}`
    : "";
  return `Napi ${p.daily_used}/${p.daily_cap} · Heti ${p.weekly_hours_used}h${next}`;
}

export function TeamPlannerDialog({ open, onOpenChange, date }: Props) {
  const qc = useQueryClient();
  const gen = useServerFn(aiGenerateTeamPlan);
  const apply = useServerFn(applyTeamPlan);

  const [plan, setPlan] = useState<TeamPlanResult | null>(null);
  const [overrides, setOverrides] = useState<Record<string, Record<string, string>>>({});

  const genMut = useMutation({
    mutationFn: () => gen({ data: { date } }),
    onSuccess: (res) => {
      setPlan(res);
      setOverrides({});
      if (res.rows.length === 0) toast.info("Nincs eset erre a napra");
      else toast.success(`${res.rows.length} esethez generált javaslat`);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const applyMut = useMutation({
    mutationFn: () => {
      if (!plan) throw new Error("Nincs javaslat");
      const assignments = plan.rows.map((row) => {
        const merged: TeamPlanItem[] = row.items.map((it) => {
          const replaced = overrides[row.case_id]?.[it.szerep];
          if (replaced && replaced !== it.user_id) {
            const swapTo = plan.eligible.find((e) => e.user_id === replaced);
            return {
              ...it,
              user_id: replaced,
              user_name: swapTo?.teljes_nev ?? it.user_name,
              indok: `Kézi módosítás: ${it.indok}`,
            };
          }
          return it;
        });
        return {
          case_id: row.case_id,
          items: merged.map((m) => ({ user_id: m.user_id, szerep: m.szerep, indok: m.indok })),
        };
      });
      return apply({ data: { date, assignments } });
    },
    onSuccess: (res) => {
      toast.success(`${res.inserted} csapat-bejegyzés elmentve`);
      qc.invalidateQueries({ queryKey: ["or-board", date] });
      onOpenChange(false);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const eligibleByCat = useMemo(() => {
    if (!plan) return { senior: [] as EligiblePerson[], junior: [] as EligiblePerson[], all: [] as EligiblePerson[] };
    return {
      senior: plan.eligible.filter((e) => e.seniority === "senior"),
      junior: plan.eligible.filter((e) => e.seniority === "junior"),
      all: plan.eligible,
    };
  }, [plan]);

  const eligibleById = useMemo(() => {
    if (!plan) return new Map<string, EligiblePerson>();
    return new Map(plan.eligible.map((e) => [e.user_id, e]));
  }, [plan]);

  function setOverride(caseId: string, szerep: string, userId: string) {
    setOverrides((prev) => ({
      ...prev,
      [caseId]: { ...(prev[caseId] ?? {}), [szerep]: userId },
    }));
  }

  function swapRoles(caseId: string, a: string, b: string) {
    const row = plan?.rows.find((r) => r.case_id === caseId);
    if (!row) return;
    const itemA = row.items.find((i) => i.szerep === a);
    const itemB = row.items.find((i) => i.szerep === b);
    if (!itemA || !itemB) return;
    const curA = overrides[caseId]?.[a] ?? itemA.user_id;
    const curB = overrides[caseId]?.[b] ?? itemB.user_id;
    setOverrides((prev) => ({
      ...prev,
      [caseId]: { ...(prev[caseId] ?? {}), [a]: curB, [b]: curA },
    }));
  }

  // Live load including overrides
  const liveLoad = useMemo(() => {
    if (!plan) return new Map<string, number>();
    const m = new Map<string, number>();
    for (const row of plan.rows) {
      for (const it of row.items) {
        const uid = overrides[row.case_id]?.[it.szerep] ?? it.user_id;
        m.set(uid, (m.get(uid) ?? 0) + 1);
      }
    }
    return m;
  }, [plan, overrides]);

  // Row-level realtime conflicts
  type RowConflict = { kind: "overload" | "missing" | "duplicate"; msg: string; userId?: string; szerep?: string };
  const rowConflicts = useMemo(() => {
    const out: Record<string, RowConflict[]> = {};
    if (!plan) return out;
    for (const row of plan.rows) {
      const list: RowConflict[] = [];
      if (row.items.length === 0) list.push({ kind: "missing", msg: "Nincs csapat összeállítva" });
      const seenRoles = new Map<string, string>();
      for (const it of row.items) {
        const uid = overrides[row.case_id]?.[it.szerep] ?? it.user_id;
        const ep = eligibleById.get(uid);
        const dailyTotal = (ep?.daily_used ?? 0) + (liveLoad.get(uid) ?? 0) - (
          // subtract own-current-row contribution counted in liveLoad
          0
        );
        if (ep && dailyTotal > ep.daily_cap) {
          list.push({
            kind: "overload",
            userId: uid,
            szerep: it.szerep,
            msg: `${ep.teljes_nev}: ${dailyTotal}/${ep.daily_cap} napi limit túllépve`,
          });
        }
        // duplicate role on same case
        const prev = seenRoles.get(uid);
        if (prev) {
          list.push({ kind: "duplicate", userId: uid, msg: `Ugyanaz a személy két szerepben (${prev} + ${it.szerep})` });
        }
        seenRoles.set(uid, it.szerep);
      }
      out[row.case_id] = list;
    }
    return out;
  }, [plan, overrides, eligibleById, liveLoad]);

  // Auto-fix: for an overloaded slot, find least-loaded eligible of same seniority not already in the row.
  function autoFix(caseId: string, szerep: string) {
    if (!plan) return;
    const row = plan.rows.find((r) => r.case_id === caseId);
    if (!row) return;
    const it = row.items.find((i) => i.szerep === szerep);
    if (!it) return;
    const currentIds = new Set(row.items.map((i) => overrides[caseId]?.[i.szerep] ?? i.user_id));
    const pool =
      it.seniority === "senior" ? eligibleByCat.senior :
      it.seniority === "junior" ? eligibleByCat.junior :
      eligibleByCat.all;
    const ranked = pool
      .filter((p) => !currentIds.has(p.user_id))
      .map((p) => ({
        p,
        score: (p.daily_used + (liveLoad.get(p.user_id) ?? 0)) * 1000 + p.weekly_hours_used,
        capLeft: p.daily_cap - p.daily_used - (liveLoad.get(p.user_id) ?? 0),
      }))
      .filter((x) => x.capLeft > 0)
      .sort((a, b) => a.score - b.score);
    const winner = ranked[0];
    if (!winner) {
      toast.warning("Nincs megfelelő alternatíva (szabad kapacitás).");
      return;
    }
    setOverride(caseId, szerep, winner.p.user_id);
    toast.success(`${SZEREP_LABEL[szerep] ?? szerep}: ${winner.p.teljes_nev}`);
  }

  const totalConflicts = useMemo(
    () => Object.values(rowConflicts).reduce((s, arr) => s + arr.length, 0),
    [rowConflicts],
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Users className="size-5" /> Csapat beosztás — {date}
          </DialogTitle>
          <DialogDescription>
            Egyenletes terhelés (napi/heti/havi). ≥3 asszisztálás után a rezidens/szakgyakornok operatőri besorolást
            kap, szakorvosi asszisztálás és felügyelet mellett. Kiemelt műtéteknél szenior operatőr.
          </DialogDescription>
        </DialogHeader>

        <div className="flex items-center gap-3 flex-wrap">
          <button
            type="button"
            onClick={() => genMut.mutate()}
            disabled={genMut.isPending}
            className="h-9 inline-flex items-center gap-2 rounded-md bg-primary px-3 text-sm font-semibold text-primary-foreground hover:opacity-90 disabled:opacity-50"
          >
            {genMut.isPending ? <Loader2 className="size-4 animate-spin" /> : <Sparkles className="size-4" />}
            Javaslat generálása
          </button>
          {plan && (
            <div className="text-xs text-muted-foreground flex items-center gap-3 flex-wrap">
              <span><strong>{plan.summary.cases}</strong> eset</span>
              <span><Star className="size-3 inline text-amber-500" /> {plan.summary.kiemelt} kiemelt</span>
              <span><GraduationCap className="size-3 inline text-primary" /> {plan.summary.juniorPromoted} promóció</span>
              {totalConflicts > 0 && (
                <span className="text-destructive font-semibold">
                  <AlertTriangle className="size-3 inline" /> {totalConflicts} konfliktus
                </span>
              )}
              <span className="ml-2 opacity-70">
                Elérhető: {eligibleByCat.senior.length} szenior · {eligibleByCat.junior.length} junior
              </span>
            </div>
          )}
        </div>

        <div className="flex-1 overflow-y-auto -mx-6 px-6">
          {!plan && (
            <div className="text-sm text-muted-foreground italic py-12 text-center">
              Kattintson a „Javaslat generálása" gombra a csapat-összeállításhoz.
            </div>
          )}
          {plan && plan.rows.length === 0 && (
            <div className="text-sm text-muted-foreground italic py-12 text-center">
              Nincs aktív eset erre a napra.
            </div>
          )}
          {plan && plan.rows.length > 0 && (
            <table className="w-full text-sm">
              <thead className="bg-secondary/40 text-[10px] font-mono uppercase tracking-wider text-muted-foreground sticky top-0">
                <tr>
                  <th className="text-left px-2 py-2">Páciens / Beavatkozás</th>
                  <th className="text-left px-2 py-2">Idő</th>
                  <th className="text-left px-2 py-2">Csapat</th>
                </tr>
              </thead>
              <tbody>
                {plan.rows.map((row) => {
                  const conflicts = rowConflicts[row.case_id] ?? [];
                  return (
                    <tr key={row.case_id} className={cn("border-t border-border align-top", conflicts.length > 0 && "bg-destructive/5")}>
                      <td className="px-2 py-3">
                        <div className="font-semibold flex items-center gap-1.5">
                          {row.patient_name}
                          {row.kiemelt && (
                            <span className="inline-flex items-center gap-0.5 text-[9px] font-mono uppercase bg-amber-500/20 text-amber-700 rounded px-1.5 py-0.5">
                              <Star className="size-2.5" /> Kiemelt
                            </span>
                          )}
                          {conflicts.length > 0 && (
                            <span
                              title={conflicts.map((c) => c.msg).join("\n")}
                              className="inline-flex items-center gap-0.5 text-[9px] font-mono uppercase bg-destructive/20 text-destructive rounded px-1.5 py-0.5"
                            >
                              <AlertTriangle className="size-2.5" /> {conflicts.length}
                            </span>
                          )}
                        </div>
                        <div className="text-xs text-muted-foreground">{row.type_name}</div>
                        {row.prior_assist_count > 0 && (
                          <div className="text-[10px] font-mono text-muted-foreground mt-1">
                            Junior asszisztálás: {row.prior_assist_count}
                          </div>
                        )}
                      </td>
                      <td className="px-2 py-3 font-mono text-xs whitespace-nowrap">{row.time_label}</td>
                      <td className="px-2 py-3">
                        <div className="space-y-1.5">
                          {row.items.map((it) => {
                            const pool =
                              it.szerep === "operator"
                                ? it.seniority === "junior"
                                  ? eligibleByCat.junior
                                  : eligibleByCat.senior
                                : it.szerep === "asszisztens"
                                  ? it.seniority === "senior"
                                    ? eligibleByCat.senior
                                    : eligibleByCat.junior
                                  : eligibleByCat.senior;
                            const currentId = overrides[row.case_id]?.[it.szerep] ?? it.user_id;
                            const ep = eligibleById.get(currentId);
                            const cap = ep ? `${ep.daily_used + (liveLoad.get(currentId) ?? 0)}/${ep.daily_cap}` : "–";
                            const tooltip = ep ? capacityLabel(ep) : "";
                            const slotConflict = conflicts.find((c) => c.userId === currentId && c.szerep === it.szerep);
                            return (
                              <div key={it.szerep} className="flex items-center gap-2 flex-wrap">
                                <span
                                  className={cn(
                                    "text-[10px] font-mono uppercase rounded px-1.5 py-0.5 min-w-[80px] inline-flex items-center gap-1",
                                    SZEREP_TONE[it.szerep] ?? "bg-secondary",
                                  )}
                                >
                                  {it.szerep === "felugyelo" && <Shield className="size-2.5" />}
                                  {SZEREP_LABEL[it.szerep] ?? it.szerep}
                                </span>
                                <select
                                  value={currentId}
                                  onChange={(e) => setOverride(row.case_id, it.szerep, e.target.value)}
                                  title={tooltip}
                                  className={cn(
                                    "h-7 text-xs rounded-md border bg-background px-2 min-w-[200px]",
                                    slotConflict ? "border-destructive" : "border-border",
                                  )}
                                >
                                  {pool.map((p) => (
                                    <option key={p.user_id} value={p.user_id}>
                                      {p.teljes_nev} — {p.daily_used}/{p.daily_cap}d · {p.weekly_hours_used}h
                                    </option>
                                  ))}
                                  {!pool.some((p) => p.user_id === currentId) && (
                                    <option value={currentId}>{it.user_name}</option>
                                  )}
                                </select>
                                <span
                                  title={tooltip}
                                  className={cn(
                                    "text-[10px] font-mono rounded px-1 py-0.5 cursor-help",
                                    slotConflict ? "bg-destructive/15 text-destructive" : "bg-secondary text-muted-foreground",
                                  )}
                                >
                                  {cap}
                                </span>
                                {slotConflict && (
                                  <button
                                    type="button"
                                    onClick={() => autoFix(row.case_id, it.szerep)}
                                    title="Automatikus csere szabad kapacitású személyre"
                                    className="h-6 inline-flex items-center gap-1 px-1.5 rounded border border-destructive/40 bg-destructive/10 text-destructive text-[10px] font-semibold hover:bg-destructive hover:text-destructive-foreground"
                                  >
                                    <Wand2 className="size-3" /> Auto-fix
                                  </button>
                                )}
                                {it.szerep === "operator" && row.items.some((x) => x.szerep === "asszisztens") && (
                                  <button
                                    type="button"
                                    title="Csere az asszisztenssel"
                                    onClick={() => swapRoles(row.case_id, "operator", "asszisztens")}
                                    className="h-6 w-6 inline-flex items-center justify-center rounded border border-border text-muted-foreground hover:text-foreground hover:bg-secondary"
                                  >
                                    <ArrowLeftRight className="size-3" />
                                  </button>
                                )}
                              </div>
                            );
                          })}
                          {row.warnings.map((w, i) => (
                            <div key={i} className="flex items-center gap-1.5 text-[10px] text-warning-foreground bg-warning/15 rounded px-1.5 py-0.5">
                              <AlertTriangle className="size-3 text-warning" /> {w}
                            </div>
                          ))}
                          {conflicts.map((c, i) => (
                            <div key={`c${i}`} className="flex items-center gap-1.5 text-[10px] text-destructive bg-destructive/10 rounded px-1.5 py-0.5">
                              <AlertTriangle className="size-3" /> {c.msg}
                            </div>
                          ))}
                          {row.items.length === 0 && (
                            <div className="text-xs text-destructive italic">Nem sikerült csapatot összeállítani.</div>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>

        <DialogFooter>
          <button
            type="button"
            onClick={() => onOpenChange(false)}
            className="h-9 rounded-md border border-border px-3 text-sm hover:bg-muted"
          >
            Mégse
          </button>
          <button
            type="button"
            onClick={() => applyMut.mutate()}
            disabled={!plan || plan.rows.length === 0 || applyMut.isPending}
            className="h-9 inline-flex items-center gap-2 rounded-md bg-primary px-3 text-sm font-semibold text-primary-foreground hover:opacity-90 disabled:opacity-50"
          >
            {applyMut.isPending && <Loader2 className="size-4 animate-spin" />}
            Alkalmaz {totalConflicts > 0 && `(${totalConflicts} konfliktussal)`}
          </button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
