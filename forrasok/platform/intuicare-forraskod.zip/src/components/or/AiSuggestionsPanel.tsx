import { useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Sparkles, AlertTriangle, Clock, Unlock, ArrowRightLeft, Loader2 } from "lucide-react";
import { aiSuggestSchedule, type OrAiSuggestion } from "@/lib/or/ai-suggest.functions";
import { bookCaseToBlock, releaseBlock } from "@/lib/or/board.functions";
import { toast } from "sonner";
import { useState } from "react";
import { cn } from "@/lib/utils";

type Props = {
  date: string;
  canBook: boolean;
  canManage: boolean;
  onApplied: () => void;
};

export function AiSuggestionsPanel({ date, canBook, canManage, onApplied }: Props) {
  const suggest = useServerFn(aiSuggestSchedule);
  const book = useServerFn(bookCaseToBlock);
  const release = useServerFn(releaseBlock);
  const [data, setData] = useState<OrAiSuggestion | null>(null);

  const runMut = useMutation({
    mutationFn: () => suggest({ data: { date } }),
    onSuccess: (d) => setData(d),
    onError: (e: Error) => toast.error(e.message),
  });

  const applyMatch = useMutation({
    mutationFn: (m: OrAiSuggestion["matches"][number]) =>
      book({ data: { caseId: m.caseId, blockId: m.blockId, tervezettKezdoIdo: m.tervezettKezdoIdo } }),
    onSuccess: () => {
      toast.success("Javaslat alkalmazva");
      onApplied();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const applyRelease = useMutation({
    mutationFn: (blockId: string) => release({ data: { blockId } }),
    onSuccess: () => {
      toast.success("Blokk felszabadítva");
      onApplied();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <aside className="w-80 shrink-0 border border-border rounded-lg bg-card flex flex-col">
      <header className="p-3 border-b border-border flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 text-sm font-bold">
          <Sparkles className="size-4 text-primary" /> AI javaslatok
        </div>
        <button
          type="button"
          onClick={() => runMut.mutate()}
          disabled={runMut.isPending}
          className="text-[10px] font-mono uppercase tracking-wider px-2 py-1 rounded bg-primary text-primary-foreground hover:opacity-90 disabled:opacity-50 inline-flex items-center gap-1"
        >
          {runMut.isPending ? <Loader2 className="size-3 animate-spin" /> : "Futtat"}
        </button>
      </header>

      <div className="flex-1 overflow-y-auto p-3 space-y-4 text-xs">
        {!data && !runMut.isPending && (
          <p className="text-muted-foreground italic">
            Indítsd el a futtatást, hogy az AI javaslatokat adjon a napi blokkokra.
          </p>
        )}

        {data && (
          <>
            <Section
              icon={<Sparkles className="size-3.5" />}
              title={`Várólista párosítás (${data.matches.length})`}
            >
              {data.matches.map((m, i) => (
                <Card key={i}>
                  <div className="font-mono text-[10px] text-muted-foreground">
                    #{m.caseId.slice(0, 6)} → blokk #{m.blockId.slice(0, 6)}
                  </div>
                  <div>{m.indok}</div>
                  <button
                    type="button"
                    disabled={!canBook || applyMatch.isPending}
                    onClick={() => applyMatch.mutate(m)}
                    className={cn(
                      "mt-1.5 text-[10px] font-bold uppercase px-2 py-1 rounded",
                      canBook
                        ? "bg-primary text-primary-foreground hover:opacity-90"
                        : "bg-secondary text-muted-foreground cursor-not-allowed",
                    )}
                  >
                    {canBook ? "Elfogadom" : "Nincs jog"}
                  </button>
                </Card>
              ))}
              {data.matches.length === 0 && <Empty />}
            </Section>

            <Section
              icon={<Unlock className="size-3.5" />}
              title={`Felszabadítás javaslat (${data.releases.length})`}
            >
              {data.releases.map((r, i) => (
                <Card key={i}>
                  <div className="font-mono text-[10px] text-muted-foreground">
                    Blokk #{r.blockId.slice(0, 6)}
                  </div>
                  <div>{r.indok}</div>
                  <button
                    type="button"
                    disabled={!canManage || applyRelease.isPending}
                    onClick={() => applyRelease.mutate(r.blockId)}
                    className={cn(
                      "mt-1.5 text-[10px] font-bold uppercase px-2 py-1 rounded",
                      canManage
                        ? "bg-warning/20 text-warning-foreground hover:bg-warning/30"
                        : "bg-secondary text-muted-foreground cursor-not-allowed",
                    )}
                  >
                    Felszabadít
                  </button>
                </Card>
              ))}
              {data.releases.length === 0 && <Empty />}
            </Section>

            <Section
              icon={<ArrowRightLeft className="size-3.5" />}
              title={`Sürgősségi átrendezés (${data.rearrangements.length})`}
            >
              {data.rearrangements.map((r, i) => (
                <Card key={i}>
                  <div className="font-mono text-[10px] text-muted-foreground">
                    #{r.caseId.slice(0, 6)}
                  </div>
                  <div className="font-semibold">{r.javaslat}</div>
                  <div className="text-muted-foreground">{r.indok}</div>
                </Card>
              ))}
              {data.rearrangements.length === 0 && <Empty />}
            </Section>

            <Section
              icon={<Clock className="size-3.5" />}
              title={`Késett műtétek (${data.delays.length})`}
              warn={data.delays.length > 0}
            >
              {data.delays.map((d, i) => (
                <Card key={i} warn>
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono text-[10px]">#{d.caseId.slice(0, 6)}</span>
                    <span className="text-[10px] font-bold text-destructive">
                      +{d.kesesPerc} p
                    </span>
                  </div>
                  <div className="flex items-start gap-1 mt-0.5">
                    <AlertTriangle className="size-3 text-destructive shrink-0 mt-0.5" />
                    <span>{d.indok}</span>
                  </div>
                </Card>
              ))}
              {data.delays.length === 0 && <Empty />}
            </Section>
          </>
        )}
      </div>
    </aside>
  );
}

function Section({
  icon,
  title,
  children,
  warn,
}: {
  icon: React.ReactNode;
  title: string;
  children: React.ReactNode;
  warn?: boolean;
}) {
  return (
    <div className="space-y-1.5">
      <div
        className={cn(
          "flex items-center gap-1.5 text-[10px] font-mono uppercase tracking-wider",
          warn ? "text-destructive" : "text-muted-foreground",
        )}
      >
        {icon} {title}
      </div>
      <div className="space-y-1.5">{children}</div>
    </div>
  );
}

function Card({ children, warn }: { children: React.ReactNode; warn?: boolean }) {
  return (
    <div
      className={cn(
        "rounded-md border p-2 space-y-0.5",
        warn ? "border-destructive/40 bg-destructive/5" : "border-border bg-background",
      )}
    >
      {children}
    </div>
  );
}

function Empty() {
  return <div className="text-[11px] italic text-muted-foreground/70">Nincs javaslat.</div>;
}
