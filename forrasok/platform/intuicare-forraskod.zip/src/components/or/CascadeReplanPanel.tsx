import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, Zap, AlertTriangle, ArrowRightLeft, UserCog, Unlock, Clock, Check, X } from "lucide-react";
import {
  cascadeReplan,
  applyCascadePlan,
  type CascadePlan,
  type CascadeStepT,
} from "@/lib/or/ai-suggest.functions";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type Props = {
  date: string;
  canApply: boolean;
  onApplied: () => void;
  /** Opcionális trigger: pl. egy késő eset kattintással átadható ide. */
  initialTriggerCaseId?: string | null;
};

const RISK_COLOR: Record<CascadePlan["cascadeRisk"], string> = {
  alacsony: "text-emerald-600 border-emerald-500/40 bg-emerald-500/10",
  kozepes: "text-amber-600 border-amber-500/40 bg-amber-500/10",
  magas: "text-destructive border-destructive/40 bg-destructive/10",
};

const STEP_ICON: Record<CascadeStepT["type"], React.ComponentType<{ className?: string }>> = {
  move: ArrowRightLeft,
  swap: ArrowRightLeft,
  substitute_staff: UserCog,
  release: Unlock,
  defer: Clock,
};

const STEP_LABEL: Record<CascadeStepT["type"], string> = {
  move: "Áthelyezés",
  swap: "Csere",
  substitute_staff: "Helyettesítés",
  release: "Felszabadítás",
  defer: "Halasztás",
};

export function CascadeReplanPanel({ date, canApply, onApplied, initialTriggerCaseId }: Props) {
  const replan = useServerFn(cascadeReplan);
  const apply = useServerFn(applyCascadePlan);
  const [plan, setPlan] = useState<CascadePlan | null>(null);
  const [triggerCaseId, setTriggerCaseId] = useState<string>(initialTriggerCaseId ?? "");
  const [delayMinutes, setDelayMinutes] = useState<string>("30");
  const [unavailableIds, setUnavailableIds] = useState<string>("");
  const [reason, setReason] = useState<string>("");
  const [accepted, setAccepted] = useState<Set<number>>(new Set());

  const runMut = useMutation({
    mutationFn: () =>
      replan({
        data: {
          date,
          triggerCaseId: triggerCaseId.trim() || null,
          delayMinutes: Number(delayMinutes) || 0,
          unavailableUserIds: unavailableIds
            .split(",")
            .map((s) => s.trim())
            .filter(Boolean),
          reason: reason.trim() || undefined,
        },
      }),
    onSuccess: (p) => {
      setPlan(p);
      setAccepted(new Set(p.steps.map((_, i) => i)));
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const applyMut = useMutation({
    mutationFn: () => {
      if (!plan) throw new Error("Nincs terv.");
      const steps = plan.steps.filter((_, i) => accepted.has(i));
      return apply({ data: { steps } });
    },
    onSuccess: (r) => {
      toast.success(`${r.applied} lépés alkalmazva, ${r.failed} hiba.`);
      if (r.failed > 0) {
        for (const fail of r.results.filter((x) => !x.ok)) {
          toast.error(`${STEP_LABEL[fail.step.type]}: ${fail.error}`);
        }
      }
      onApplied();
      setPlan(null);
      setAccepted(new Set());
    },
    onError: (e: Error) => toast.error(e.message),
  });

  function toggle(i: number) {
    setAccepted((prev) => {
      const next = new Set(prev);
      if (next.has(i)) next.delete(i);
      else next.add(i);
      return next;
    });
  }

  return (
    <aside className="w-80 shrink-0 border border-border rounded-lg bg-card flex flex-col">
      <header className="p-3 border-b border-border">
        <div className="flex items-center gap-2 text-sm font-bold">
          <Zap className="size-4 text-amber-500" /> Domino újratervezés
        </div>
        <p className="text-[10px] text-muted-foreground mt-1">
          Több műtét összehangolása csúszás vagy sebészhiány esetén — AI cserét, helyettesítést, halasztást javasol.
        </p>
      </header>

      <div className="p-3 border-b border-border space-y-2 text-xs">
        <label className="block">
          <span className="text-[10px] font-mono uppercase text-muted-foreground">Trigger eset ID</span>
          <input
            value={triggerCaseId}
            onChange={(e) => setTriggerCaseId(e.target.value)}
            placeholder="uuid (opcionális)"
            className="mt-0.5 w-full rounded border bg-background px-2 py-1 font-mono text-[11px]"
          />
        </label>
        <div className="grid grid-cols-2 gap-2">
          <label className="block">
            <span className="text-[10px] font-mono uppercase text-muted-foreground">Késés (p)</span>
            <input
              type="number"
              min={0}
              value={delayMinutes}
              onChange={(e) => setDelayMinutes(e.target.value)}
              className="mt-0.5 w-full rounded border bg-background px-2 py-1 font-mono text-[11px]"
            />
          </label>
          <label className="block">
            <span className="text-[10px] font-mono uppercase text-muted-foreground">Hiányzó sebészek</span>
            <input
              value={unavailableIds}
              onChange={(e) => setUnavailableIds(e.target.value)}
              placeholder="uuid, uuid"
              className="mt-0.5 w-full rounded border bg-background px-2 py-1 font-mono text-[11px]"
            />
          </label>
        </div>
        <label className="block">
          <span className="text-[10px] font-mono uppercase text-muted-foreground">Indok</span>
          <input
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            placeholder="pl. sebész elakadt, eszközfertőtlenítés…"
            className="mt-0.5 w-full rounded border bg-background px-2 py-1 text-[11px]"
          />
        </label>
        <button
          type="button"
          onClick={() => runMut.mutate()}
          disabled={runMut.isPending}
          className="w-full rounded bg-primary px-2 py-1.5 text-[11px] font-bold uppercase text-primary-foreground disabled:opacity-50 inline-flex items-center justify-center gap-1"
        >
          {runMut.isPending ? <Loader2 className="size-3 animate-spin" /> : <Zap className="size-3" />}
          Optimalizáció futtatása
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-3 space-y-2 text-xs">
        {!plan && !runMut.isPending && (
          <p className="text-muted-foreground italic">
            Add meg a trigger esetet és késést, majd futtasd az optimalizációt.
          </p>
        )}

        {plan && (
          <>
            <div className={cn("rounded border px-2 py-1.5", RISK_COLOR[plan.cascadeRisk])}>
              <div className="flex items-center justify-between text-[10px] font-mono uppercase">
                <span>Kaszkád kockázat: {plan.cascadeRisk}</span>
                <span>~{plan.estimatedSavedMinutes} p megspórolva</span>
              </div>
              <div className="mt-0.5 text-[11px]">{plan.triggerSummary}</div>
            </div>

            {plan.warnings.length > 0 && (
              <div className="rounded border border-amber-500/40 bg-amber-500/5 px-2 py-1.5 space-y-0.5">
                {plan.warnings.map((w, i) => (
                  <div key={i} className="flex items-start gap-1 text-[10px]">
                    <AlertTriangle className="size-3 text-amber-600 shrink-0 mt-0.5" />
                    <span>{w}</span>
                  </div>
                ))}
              </div>
            )}

            {plan.steps.map((step, i) => {
              const Icon = STEP_ICON[step.type];
              const isOn = accepted.has(i);
              return (
                <div
                  key={i}
                  className={cn(
                    "rounded border px-2 py-1.5 space-y-1",
                    isOn ? "border-primary/50 bg-primary/5" : "border-border bg-muted/30 opacity-60",
                  )}
                >
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1.5 text-[10px] font-mono uppercase">
                      <Icon className="size-3" /> {i + 1}. {STEP_LABEL[step.type]}
                    </div>
                    <button
                      type="button"
                      onClick={() => toggle(i)}
                      className={cn(
                        "rounded p-0.5",
                        isOn ? "text-emerald-600 hover:bg-emerald-500/10" : "text-muted-foreground hover:bg-accent",
                      )}
                      title={isOn ? "Kihagyom" : "Elfogadom"}
                    >
                      {isOn ? <Check className="size-3.5" /> : <X className="size-3.5" />}
                    </button>
                  </div>
                  <div className="font-mono text-[10px] text-muted-foreground break-all">
                    {step.type === "move" &&
                      `#${step.caseId.slice(0, 6)} → blokk #${step.toBlockId.slice(0, 6)}${step.newStart ? ` @ ${step.newStart.slice(11, 16)}` : ""}`}
                    {step.type === "swap" &&
                      `#${step.caseAId.slice(0, 6)} ↔ #${step.caseBId.slice(0, 6)}`}
                    {step.type === "substitute_staff" &&
                      `Blokk #${step.blockId.slice(0, 6)} sebész → ${step.toUserId.slice(0, 6)}`}
                    {step.type === "release" && `Blokk #${step.blockId.slice(0, 6)}`}
                    {step.type === "defer" && `#${step.caseId.slice(0, 6)} → várólista`}
                  </div>
                  <div className="text-[11px]">{step.indok}</div>
                </div>
              );
            })}

            {plan.steps.length === 0 && (
              <p className="italic text-muted-foreground">Nincs javasolt lépés.</p>
            )}

            {plan.steps.length > 0 && (
              <button
                type="button"
                onClick={() => applyMut.mutate()}
                disabled={!canApply || applyMut.isPending || accepted.size === 0}
                className="w-full rounded bg-emerald-600 px-2 py-1.5 text-[11px] font-bold uppercase text-white disabled:opacity-50 inline-flex items-center justify-center gap-1"
              >
                {applyMut.isPending ? <Loader2 className="size-3 animate-spin" /> : <Check className="size-3" />}
                {canApply ? `Kijelölt (${accepted.size}) lépés alkalmazása` : "Nincs jog"}
              </button>
            )}
          </>
        )}
      </div>
    </aside>
  );
}
