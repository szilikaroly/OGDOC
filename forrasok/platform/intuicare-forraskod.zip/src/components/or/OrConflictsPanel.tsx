import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { AlertOctagon, AlertTriangle, CheckCircle2, ChevronRight, RefreshCw } from "lucide-react";
import { useState } from "react";
import { listOrConflicts, type OrConflict } from "@/lib/or/conflicts.functions";
import { cn } from "@/lib/utils";

export function OrConflictsPanel({
  date,
  onFocusBlock,
}: {
  date: string;
  onFocusBlock?: (blockId: string) => void;
}) {
  const list = useServerFn(listOrConflicts);
  const { data, isLoading, refetch, isFetching } = useQuery({
    queryKey: ["or-conflicts", date],
    queryFn: () => list({ data: { date } }),
    refetchInterval: 60_000,
  });

  const [expanded, setExpanded] = useState<string | null>(null);
  const conflicts = data?.conflicts ?? [];
  const critical = conflicts.filter((c) => c.severity === "critical").length;
  const warnings = conflicts.length - critical;

  return (
    <section className="rounded-lg border border-border bg-card">
      <header className="flex items-center justify-between px-3 py-2 border-b border-border">
        <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider">
          {conflicts.length === 0 ? (
            <CheckCircle2 className="size-3.5 text-emerald-500" />
          ) : critical > 0 ? (
            <AlertOctagon className="size-3.5 text-destructive" />
          ) : (
            <AlertTriangle className="size-3.5 text-warning" />
          )}
          <span>Ütközés-ellenőrzés</span>
          {conflicts.length > 0 && (
            <span className="text-[10px] font-mono normal-case text-muted-foreground">
              {critical > 0 && <span className="text-destructive">{critical} kritikus</span>}
              {critical > 0 && warnings > 0 && " · "}
              {warnings > 0 && <span className="text-warning">{warnings} figyelmeztetés</span>}
            </span>
          )}
        </div>
        <button
          type="button"
          onClick={() => refetch()}
          className="text-muted-foreground hover:text-foreground"
          title="Újraellenőrzés"
        >
          <RefreshCw className={cn("size-3.5", isFetching && "animate-spin")} />
        </button>
      </header>

      <div className="p-2 space-y-1.5 max-h-72 overflow-y-auto">
        {isLoading && <div className="text-xs text-muted-foreground px-2 py-3">Ellenőrzés…</div>}
        {!isLoading && conflicts.length === 0 && (
          <div className="text-xs text-emerald-700 dark:text-emerald-400 px-2 py-3 italic">
            Nincs ütközés ezen a napon. ✓
          </div>
        )}
        {conflicts.map((c) => (
          <ConflictRow
            key={c.id}
            c={c}
            isOpen={expanded === c.id}
            onToggle={() => setExpanded((e) => (e === c.id ? null : c.id))}
            onFocus={onFocusBlock}
          />
        ))}
      </div>
    </section>
  );
}

function ConflictRow({
  c,
  isOpen,
  onToggle,
  onFocus,
}: {
  c: OrConflict;
  isOpen: boolean;
  onToggle: () => void;
  onFocus?: (blockId: string) => void;
}) {
  const Icon = c.severity === "critical" ? AlertOctagon : AlertTriangle;
  return (
    <div
      className={cn(
        "rounded-md border text-xs",
        c.severity === "critical"
          ? "border-destructive/40 bg-destructive/5"
          : "border-warning/40 bg-warning/5",
      )}
    >
      <button
        type="button"
        onClick={onToggle}
        className="w-full flex items-start gap-2 px-2.5 py-2 text-left hover:bg-background/40"
      >
        <Icon
          className={cn(
            "size-3.5 shrink-0 mt-0.5",
            c.severity === "critical" ? "text-destructive" : "text-warning",
          )}
        />
        <div className="flex-1 min-w-0">
          <div className="font-semibold truncate">{c.title}</div>
          {!isOpen && (
            <div className="text-[11px] text-muted-foreground truncate">{c.reason}</div>
          )}
        </div>
        <ChevronRight
          className={cn(
            "size-3.5 text-muted-foreground transition-transform shrink-0 mt-0.5",
            isOpen && "rotate-90",
          )}
        />
      </button>
      {isOpen && (
        <div className="px-2.5 pb-2.5 space-y-1.5 text-[11px]">
          <div>
            <span className="font-mono uppercase text-muted-foreground">Ok: </span>
            {c.reason}
          </div>
          <div>
            <span className="font-mono uppercase text-muted-foreground">Javaslat: </span>
            {c.suggestion}
          </div>
          {c.caseIds.length > 0 && (
            <div className="text-muted-foreground">
              Érintett esetek: {c.caseIds.map((id) => `#${id.slice(0, 6)}`).join(", ")}
            </div>
          )}
          {c.blockId && onFocus && (
            <button
              type="button"
              onClick={() => onFocus(c.blockId!)}
              className="inline-flex items-center gap-1 text-[10px] font-mono uppercase font-bold text-primary hover:underline"
            >
              Ugrás a blokkhoz →
            </button>
          )}
        </div>
      )}
    </div>
  );
}
