import { useEffect, useRef, useState } from "react";
import { X, FileSignature, ShieldCheck, Loader2, Search, Plus, Sparkles, Printer } from "lucide-react";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useTranslation } from "react-i18next";
import { humanizeError } from "@/lib/humanize-error";
import { cn } from "@/lib/utils";
import { BNO_SEED, OENO_SEED, searchCodes, type CodeEntry } from "@/lib/medical-codes";
import { suggestMedicalCodes, type CodeSuggestion } from "@/lib/ai-medical.functions";
import { openEncounterPrint } from "@/lib/encounter-print";
import { ENCOUNTER_TEMPLATES, type EncounterTemplate } from "@/lib/encounter-templates";
import { FileText } from "lucide-react";

export type EncounterRow = {
  id: string;
  patient_id: string;
  ellatas_kezdete: string;
  ellatas_vege: string | null;
  tipus: string;
  status: string;
  bno_kodok: string[] | null;
  oeno_kodok: string[] | null;
  beavatkozas_ids: string[] | null;
  osszefoglalo: string | null;
  intezmenyi_azonosito: string | null;
  szerzo_id: string | null;
  szerzo_alairas_at: string | null;
  ellenjegyzo_id: string | null;
  ellenjegyzo_alairas_at: string | null;
};

const TIPUSOK = ["ambulans", "fekvobeteg", "muteti", "konzilium", "telemedicina", "egyeb"] as const;

export function EncounterEditor({
  tenantId,
  userId,
  patientId,
  encounter,
  onClose,
  onSaved,
}: {
  tenantId: string;
  userId: string;
  patientId: string;
  encounter: EncounterRow | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const { t } = useTranslation();
  const initial = encounter ?? ({
    id: "",
    patient_id: patientId,
    ellatas_kezdete: new Date().toISOString().slice(0, 16),
    ellatas_vege: null,
    tipus: "ambulans",
    status: "piszkozat",
    bno_kodok: [],
    oeno_kodok: [],
    beavatkozas_ids: [],
    osszefoglalo: "",
    intezmenyi_azonosito: null,
    szerzo_id: null,
    szerzo_alairas_at: null,
    ellenjegyzo_id: null,
    ellenjegyzo_alairas_at: null,
  } as EncounterRow);
  const [form, setForm] = useState<EncounterRow>(initial);
  const [saving, setSaving] = useState(false);
  const [beavatkozasok, setBeavatkozasok] = useState<Array<{ id: string; kod: string; nev: string }>>([]);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiResult, setAiResult] = useState<CodeSuggestion | null>(null);
  const callAi = useServerFn(suggestMedicalCodes);

  useEffect(() => {
    void (async () => {
      const { data } = await supabase.from("beavatkozasok").select("id,kod,nev").eq("aktiv", true).order("kod");
      setBeavatkozasok((data ?? []) as Array<{ id: string; kod: string; nev: string }>);
    })();
  }, []);

  async function runAi() {
    if (!form.osszefoglalo || form.osszefoglalo.trim().length < 20) {
      return toast.error("Írjon legalább 20 karaktert a dekurzusba az AI-javaslathoz.");
    }
    setAiLoading(true);
    try {
      const r = await callAi({ data: { text: form.osszefoglalo } });
      setAiResult(r);
      toast.success(`AI: ${r.bno.length} BNO + ${r.oeno.length} OENO javaslat`);
    } catch (e: any) {
      toast.error(e?.message ?? "AI hiba");
    } finally {
      setAiLoading(false);
    }
  }

  const locked = form.status === "ellenjegyezve";
  const signed = !!form.szerzo_alairas_at;
  const countersigned = !!form.ellenjegyzo_alairas_at;

  function applyTemplate(tpl: EncounterTemplate) {
    if (locked) return;
    const existing = (form.osszefoglalo ?? "").trim();
    const sep = existing ? "\n\n" : "";
    setForm({
      ...form,
      tipus: tpl.tipus ?? form.tipus,
      osszefoglalo: existing + sep + tpl.szoveg,
      bno_kodok: Array.from(new Set([...(form.bno_kodok ?? []), ...(tpl.bno ?? [])])),
      oeno_kodok: Array.from(new Set([...(form.oeno_kodok ?? []), ...(tpl.oeno ?? [])])),
    });
    toast.success(`Sablon beszúrva: ${tpl.label}`);
  }

  async function save() {
    if (locked) return toast.error("Lezárt ellátás nem módosítható.");
    setSaving(true);
    const payload: any = {
      tenant_id: tenantId,
      patient_id: form.patient_id,
      ellatas_kezdete: new Date(form.ellatas_kezdete).toISOString(),
      ellatas_vege: form.ellatas_vege ? new Date(form.ellatas_vege).toISOString() : null,
      tipus: form.tipus,
      status: form.status,
      bno_kodok: form.bno_kodok ?? [],
      oeno_kodok: form.oeno_kodok ?? [],
      beavatkozas_ids: form.beavatkozas_ids ?? [],
      osszefoglalo: form.osszefoglalo,
      intezmenyi_azonosito: form.intezmenyi_azonosito,
    };
    const q = form.id
      ? (supabase.from("patient_encounters") as any).update(payload).eq("id", form.id)
      : (supabase.from("patient_encounters") as any).insert(payload).select().single();
    const { data, error } = await q;
    setSaving(false);
    if (error) return toast.error(humanizeError(error, t));
    if (!form.id && data) setForm({ ...form, id: data.id });
    toast.success("Ellátás mentve");
    onSaved();
  }

  async function sign() {
    if (!form.id) return toast.error("Először mentse az ellátást.");
    if (signed) return;
    const { error } = await (supabase.from("patient_encounters") as any)
      .update({ szerzo_id: userId, szerzo_alairas_at: new Date().toISOString(), status: "alairva" })
      .eq("id", form.id);
    if (error) return toast.error(humanizeError(error, t));
    toast.success("Aláírva");
    setForm({ ...form, szerzo_id: userId, szerzo_alairas_at: new Date().toISOString(), status: "alairva" });
    onSaved();
  }

  async function countersign() {
    if (!form.id || !signed) return;
    if (form.szerzo_id === userId) return toast.error("Saját aláírást nem ellenjegyezhet.");
    const { error } = await (supabase.from("patient_encounters") as any)
      .update({ ellenjegyzo_id: userId, ellenjegyzo_alairas_at: new Date().toISOString(), status: "ellenjegyezve" })
      .eq("id", form.id);
    if (error) return toast.error(humanizeError(error, t));
    toast.success("Ellenjegyezve és lezárva");
    setForm({ ...form, ellenjegyzo_id: userId, ellenjegyzo_alairas_at: new Date().toISOString(), status: "ellenjegyezve" });
    onSaved();
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-card border rounded-lg p-4 w-full max-w-3xl space-y-3 max-h-[90vh] overflow-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between">
          <h3 className="font-semibold flex items-center gap-2">
            <FileSignature className="h-5 w-5 text-primary" />
            {form.id ? "Ellátás szerkesztése" : "Új ellátás"}
            <StatusBadge status={form.status} />
          </h3>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X className="h-4 w-4" /></button>
        </div>

        {locked && (
          <div className="rounded border border-amber-500/40 bg-amber-500/10 p-2 text-xs text-amber-800">
            🔒 Az ellátás <b>ellenjegyezve</b> — a tartalmi mezők zárolva.
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
          <label>Típus
            <select disabled={locked} value={form.tipus} onChange={(e) => setForm({ ...form, tipus: e.target.value })} className="w-full rounded border bg-background px-2 py-1.5 mt-1">
              {TIPUSOK.map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
          </label>
          <label>Kezdés
            <input disabled={locked} type="datetime-local" value={form.ellatas_kezdete.slice(0, 16)} onChange={(e) => setForm({ ...form, ellatas_kezdete: e.target.value })} className="w-full rounded border bg-background px-2 py-1.5 mt-1" />
          </label>
          <label>Vége
            <input disabled={locked} type="datetime-local" value={form.ellatas_vege?.slice(0, 16) ?? ""} onChange={(e) => setForm({ ...form, ellatas_vege: e.target.value || null })} className="w-full rounded border bg-background px-2 py-1.5 mt-1" />
          </label>
          <label className="sm:col-span-3">Intézményi azonosító
            <input disabled={locked} value={form.intezmenyi_azonosito ?? ""} onChange={(e) => setForm({ ...form, intezmenyi_azonosito: e.target.value || null })} className="w-full rounded border bg-background px-2 py-1.5 mt-1" />
          </label>
        </div>

        <CodeMultiSelect label="BNO-10 diagnózisok" seed={BNO_SEED} values={form.bno_kodok ?? []}
          onChange={(v) => setForm({ ...form, bno_kodok: v })} disabled={locked} />
        <CodeMultiSelect label="OENO beavatkozás-kódok" seed={OENO_SEED} values={form.oeno_kodok ?? []}
          onChange={(v) => setForm({ ...form, oeno_kodok: v })} disabled={locked} />

        <div>
          <div className="text-xs font-medium mb-1">Belső beavatkozás-katalógus</div>
          <div className="rounded border bg-background p-2 max-h-32 overflow-auto text-xs space-y-0.5">
            {beavatkozasok.length === 0 && <div className="italic text-muted-foreground">Nincs aktív katalógus-tétel</div>}
            {beavatkozasok.map((b) => (
              <label key={b.id} className="flex items-center gap-2">
                <input type="checkbox" disabled={locked}
                  checked={(form.beavatkozas_ids ?? []).includes(b.id)}
                  onChange={(e) => {
                    const cur = new Set(form.beavatkozas_ids ?? []);
                    if (e.target.checked) cur.add(b.id); else cur.delete(b.id);
                    setForm({ ...form, beavatkozas_ids: Array.from(cur) });
                  }} />
                <span className="font-mono">{b.kod}</span>
                <span>{b.nev}</span>
              </label>
            ))}
          </div>
        </div>

        <label className="text-xs block">Összefoglaló / dekurzus
          {!locked && (
            <div className="mt-1 mb-1 flex flex-wrap items-center gap-1">
              <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                <FileText className="h-3 w-3" /> Sablonok:
              </span>
              {ENCOUNTER_TEMPLATES.map((tpl) => (
                <button
                  key={tpl.id}
                  type="button"
                  onClick={() => applyTemplate(tpl)}
                  className="rounded border bg-background px-1.5 py-0.5 text-[10px] hover:bg-accent"
                  title={`Beszúrja: „${tpl.label}". A típust is átállítja (${tpl.tipus ?? "nem változik"}).`}
                >
                  {tpl.label}
                </button>
              ))}
            </div>
          )}
          <textarea disabled={locked} value={form.osszefoglalo ?? ""} onChange={(e) => setForm({ ...form, osszefoglalo: e.target.value })}
            rows={6} className="w-full rounded border bg-background px-2 py-1.5 mt-1" />
        </label>

        {!locked && (
          <div className="rounded border border-primary/30 bg-primary/5 p-2 text-xs space-y-2">
            <div className="flex items-center justify-between">
              <div className="font-medium flex items-center gap-2"><Sparkles className="h-4 w-4 text-primary" /> AI kódjavaslat dekurzusból</div>
              <button onClick={runAi} disabled={aiLoading} type="button"
                className="flex items-center gap-1 rounded bg-primary px-2 py-1 text-[11px] text-primary-foreground hover:opacity-90 disabled:opacity-50">
                {aiLoading ? <Loader2 className="h-3 w-3 animate-spin" /> : <Sparkles className="h-3 w-3" />} Javaslat
              </button>
            </div>
            {aiResult && (
              <div className="space-y-1">
                {aiResult.osszefoglalo && (
                  <div className="italic text-muted-foreground">„{aiResult.osszefoglalo}"
                    <button type="button" onClick={() => setForm({ ...form, osszefoglalo: aiResult.osszefoglalo })}
                      className="ml-2 underline">összefoglaló átvétele</button>
                  </div>
                )}
                {aiResult.bno.length > 0 && (
                  <div>
                    <span className="font-medium">BNO:</span>{" "}
                    {aiResult.bno.map((b) => (
                      <button key={b.kod} type="button"
                        onClick={() => setForm({ ...form, bno_kodok: Array.from(new Set([...(form.bno_kodok ?? []), b.kod])) })}
                        className="mr-1 mb-1 inline-flex rounded border bg-background px-1.5 py-0.5 font-mono hover:bg-accent">
                        + {b.kod} <span className="ml-1 font-sans text-muted-foreground">{b.nev}</span>
                      </button>
                    ))}
                  </div>
                )}
                {aiResult.oeno.length > 0 && (
                  <div>
                    <span className="font-medium">OENO:</span>{" "}
                    {aiResult.oeno.map((b) => (
                      <button key={b.kod} type="button"
                        onClick={() => setForm({ ...form, oeno_kodok: Array.from(new Set([...(form.oeno_kodok ?? []), b.kod])) })}
                        className="mr-1 mb-1 inline-flex rounded border bg-background px-1.5 py-0.5 font-mono hover:bg-accent">
                        + {b.kod} <span className="ml-1 font-sans text-muted-foreground">{b.nev}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        <div className="rounded border bg-muted/30 p-2 text-xs space-y-1">
          <div className="font-medium flex items-center gap-2"><ShieldCheck className="h-4 w-4 text-primary" /> Aláírás-folyamat</div>
          <div>Szerző: {form.szerzo_alairas_at
            ? <span className="font-mono">{form.szerzo_id?.slice(0, 8)} · {new Date(form.szerzo_alairas_at).toLocaleString("hu-HU")}</span>
            : <span className="italic text-muted-foreground">nincs aláírás</span>}</div>
          <div>Ellenjegyző: {form.ellenjegyzo_alairas_at
            ? <span className="font-mono">{form.ellenjegyzo_id?.slice(0, 8)} · {new Date(form.ellenjegyzo_alairas_at).toLocaleString("hu-HU")}</span>
            : <span className="italic text-muted-foreground">nincs ellenjegyzés</span>}</div>
        </div>

        <div className="flex justify-end gap-2 pt-2 border-t">
          <button onClick={onClose} className="rounded border px-3 py-1.5 text-sm hover:bg-accent">Bezár</button>
          {form.id && (
            <button onClick={async () => {
              const { data: p } = await supabase.from("patients").select("vezeteknev,keresztnev,taj,szuletesi_datum").eq("id", form.patient_id).maybeSingle();
              const pn = p ? `${(p as any).vezeteknev} ${(p as any).keresztnev}` : "";
              await openEncounterPrint({
                encounter: form,
                patientName: pn,
                patientTaj: (p as any)?.taj ?? null,
                patientBirth: (p as any)?.szuletesi_datum ?? null,
                beavatkozasok,
              });
            }} className="flex items-center gap-1 rounded border px-3 py-1.5 text-sm hover:bg-accent">
              <Printer className="h-3 w-3" /> PDF
            </button>
          )}
          {!locked && (
            <button onClick={save} disabled={saving}
              className="flex items-center gap-1 rounded bg-primary px-3 py-1.5 text-sm text-primary-foreground hover:opacity-90 disabled:opacity-50">
              {saving ? <Loader2 className="h-3 w-3 animate-spin" /> : <Plus className="h-3 w-3" />} Mentés
            </button>
          )}
          {form.id && !signed && !locked && (
            <button onClick={sign} className="flex items-center gap-1 rounded border border-primary px-3 py-1.5 text-sm text-primary hover:bg-primary/10">
              <FileSignature className="h-3 w-3" /> Aláírom
            </button>
          )}
          {form.id && signed && !countersigned && form.szerzo_id !== userId && (
            <button onClick={countersign} className="flex items-center gap-1 rounded bg-emerald-600 px-3 py-1.5 text-sm text-white hover:opacity-90">
              <ShieldCheck className="h-3 w-3" /> Ellenjegyzem és lezárom
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const colors: Record<string, string> = {
    piszkozat: "bg-muted text-muted-foreground",
    alairva: "bg-amber-500/15 text-amber-700 dark:text-amber-300",
    ellenjegyezve: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300",
  };
  return <span className={cn("ml-2 px-2 py-0.5 rounded text-[10px] font-mono", colors[status] ?? "bg-muted")}>{status}</span>;
}

function CodeMultiSelect({ label, seed, values, onChange, disabled }: {
  label: string;
  seed: CodeEntry[];
  values: string[];
  onChange: (v: string[]) => void;
  disabled?: boolean;
}) {
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const h = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false); };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);
  const results = searchCodes(seed, q);

  function add(k: string) {
    if (!values.includes(k)) onChange([...values, k]);
    setQ("");
  }

  return (
    <div ref={ref} className="text-xs">
      <div className="font-medium mb-1">{label}</div>
      <div className="flex flex-wrap gap-1 mb-1">
        {values.length === 0 && <span className="italic text-muted-foreground">—</span>}
        {values.map((k) => {
          const entry = seed.find((e) => e.kod === k);
          return (
            <span key={k} className="rounded border bg-muted px-1.5 py-0.5 font-mono text-[10px] flex items-center gap-1">
              {k}{entry && <span className="text-muted-foreground font-sans">· {entry.nev}</span>}
              {!disabled && <button onClick={() => onChange(values.filter((v) => v !== k))}><X className="h-2.5 w-2.5" /></button>}
            </span>
          );
        })}
      </div>
      {!disabled && (
        <div className="relative">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-3 w-3 text-muted-foreground" />
          <input value={q} onChange={(e) => { setQ(e.target.value); setOpen(true); }} onFocus={() => setOpen(true)}
            placeholder="Kód vagy név…" className="w-full pl-7 pr-2 py-1.5 rounded border bg-background" />
          {open && results.length > 0 && (
            <div className="absolute z-10 left-0 right-0 mt-1 max-h-48 overflow-auto rounded border bg-popover shadow">
              {results.map((r) => (
                <button key={r.kod} onClick={() => add(r.kod)} type="button"
                  className="w-full text-left px-2 py-1 hover:bg-accent flex gap-2">
                  <span className="font-mono">{r.kod}</span>
                  <span className="text-muted-foreground">{r.nev}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
