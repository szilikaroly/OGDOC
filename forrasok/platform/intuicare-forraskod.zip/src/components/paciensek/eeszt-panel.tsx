import { useEffect, useState } from "react";
import { Cable, Loader2, RefreshCcw, X, Check } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

type EeesztLink = {
  id: string;
  eeszt_page_id: string | null;
  eeszt_org_oid: string | null;
  hozzajarulas_status: string;
  hozzajarulas_at: string | null;
  utolso_szinkron_at: string | null;
  megjegyzes: string | null;
};

export function EesztPanel({ tenantId, patientId }: { tenantId: string; patientId: string }) {
  const [link, setLink] = useState<EeesztLink | null>(null);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);

  async function load() {
    setLoading(true);
    const { data } = await supabase
      .from("eeszt_patient_links")
      .select("id,eeszt_page_id,eeszt_org_oid,hozzajarulas_status,hozzajarulas_at,utolso_szinkron_at,megjegyzes")
      .eq("patient_id", patientId)
      .maybeSingle();
    setLink((data as EeesztLink | null) ?? null);
    setLoading(false);
  }
  useEffect(() => { void load(); }, [patientId]);

  async function mockSync() {
    setSyncing(true);
    try {
      // Mock: nincs valós EESZT — szimuláljuk a hívást
      await new Promise((r) => setTimeout(r, 700));
      const mockPageId = link?.eeszt_page_id ?? `PAGE-${Math.random().toString(36).slice(2, 8).toUpperCase()}`;
      const mockOrgOid = link?.eeszt_org_oid ?? "1.2.276.0.7.10.1.2.1.0";
      const now = new Date().toISOString();
      const payload = {
        tenant_id: tenantId,
        patient_id: patientId,
        eeszt_page_id: mockPageId,
        eeszt_org_oid: mockOrgOid,
        hozzajarulas_status: link?.hozzajarulas_status ?? "ervenyes",
        hozzajarulas_at: link?.hozzajarulas_at ?? now,
        utolso_szinkron_at: now,
        megjegyzes: "Mock szinkron — fejlesztői környezet",
      };
      const q = link?.id
        ? (supabase.from("eeszt_patient_links") as any).update(payload).eq("id", link.id)
        : (supabase.from("eeszt_patient_links") as any).insert(payload);
      const { error } = await q;
      if (error) throw error;
      toast.success("EESZT mock szinkron sikeres");
      await load();
    } catch (e: any) {
      toast.error(e?.message ?? "EESZT hiba");
    } finally {
      setSyncing(false);
    }
  }

  async function setConsent(status: "ervenyes" | "visszavont") {
    if (!link?.id) return;
    const { error } = await (supabase.from("eeszt_patient_links") as any)
      .update({
        hozzajarulas_status: status,
        hozzajarulas_at: new Date().toISOString(),
      })
      .eq("id", link.id);
    if (error) return toast.error(error.message);
    toast.success(status === "ervenyes" ? "Hozzájárulás rögzítve" : "Hozzájárulás visszavonva");
    await load();
  }

  if (loading) return <div className="text-xs text-muted-foreground"><Loader2 className="h-3 w-3 animate-spin inline" /> EESZT…</div>;

  return (
    <div className="rounded border bg-muted/20 p-2 text-xs space-y-2">
      <div className="flex items-center justify-between">
        <div className="font-medium flex items-center gap-2"><Cable className="h-4 w-4 text-primary" /> EESZT kapcsolat <span className="text-[10px] text-amber-700 dark:text-amber-300">(mock)</span></div>
        <button onClick={mockSync} disabled={syncing} className="flex items-center gap-1 rounded border px-2 py-0.5 hover:bg-accent disabled:opacity-50">
          {syncing ? <Loader2 className="h-3 w-3 animate-spin" /> : <RefreshCcw className="h-3 w-3" />} Szinkron
        </button>
      </div>
      {link ? (
        <div className="grid grid-cols-2 gap-x-3 gap-y-0.5 font-mono">
          <div>Page-ID: <span className="text-muted-foreground">{link.eeszt_page_id ?? "—"}</span></div>
          <div>OID: <span className="text-muted-foreground">{link.eeszt_org_oid ?? "—"}</span></div>
          <div>Hozzájárulás:
            <span className={"ml-1 " + (link.hozzajarulas_status === "ervenyes" ? "text-emerald-600" : "text-rose-600")}>
              {link.hozzajarulas_status}
            </span>
          </div>
          <div>Utolsó szinkron: <span className="text-muted-foreground">{link.utolso_szinkron_at ? new Date(link.utolso_szinkron_at).toLocaleString("hu-HU") : "—"}</span></div>
          <div className="col-span-2 flex gap-1 mt-1">
            {link.hozzajarulas_status !== "ervenyes" && (
              <button onClick={() => setConsent("ervenyes")} className="flex items-center gap-1 rounded bg-emerald-600 text-white px-2 py-0.5 hover:opacity-90">
                <Check className="h-3 w-3" /> Hozzájárulás aktiválása
              </button>
            )}
            {link.hozzajarulas_status === "ervenyes" && (
              <button onClick={() => setConsent("visszavont")} className="flex items-center gap-1 rounded border border-rose-500 text-rose-600 px-2 py-0.5 hover:bg-rose-500/10">
                <X className="h-3 w-3" /> Visszavonás
              </button>
            )}
          </div>
        </div>
      ) : (
        <div className="text-muted-foreground italic">Nincs EESZT-link. Indítsa el a szinkront a létrehozáshoz.</div>
      )}
    </div>
  );
}
