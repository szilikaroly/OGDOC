import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Siren, Phone, Loader2 } from "lucide-react";
import { getStaffSosCard } from "@/lib/portal/sos-staff.functions";
import { useEmergencyCardRealtime } from "@/lib/portal/use-emergency-card-realtime";
import { RealtimeStatusPill } from "@/components/portal/realtime-status";

export function StaffSosPanel({ patientId }: { patientId: string }) {
  const fn = useServerFn(getStaffSosCard);
  const rt = useEmergencyCardRealtime(patientId);
  const { data, isLoading, isError } = useQuery({
    queryKey: ["staff-sos-card", patientId],
    queryFn: () => fn({ data: { patient_id: patientId } }),
  });

  return (
    <Card className="border-destructive/30">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between gap-2 text-base">
          <span className="flex items-center gap-2">
            <Siren className="h-4 w-4 text-destructive" />
            SOS kártya
          </span>
          <RealtimeStatusPill rt={rt} showLastEvent={false} />
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3 text-sm">
        {isLoading && (
          <p className="text-muted-foreground flex items-center gap-2">
            <Loader2 className="h-4 w-4 animate-spin" /> Betöltés…
          </p>
        )}
        {isError && <p className="text-destructive">Nem sikerült betölteni.</p>}
        {!isLoading && !isError && !data && (
          <p className="text-muted-foreground">A páciens még nem töltött ki SOS kártyát.</p>
        )}
        {data && (
          <>
            {data.vercsoport && (
              <div>
                <span className="text-muted-foreground">Vércsoport:</span>{" "}
                <Badge variant="outline">{data.vercsoport}</Badge>
              </div>
            )}
            {data.allergiak?.length ? (
              <div>
                <div className="text-muted-foreground mb-1">Allergiák</div>
                <div className="flex flex-wrap gap-1">
                  {data.allergiak.map((a: string, i: number) => (
                    <Badge key={i} variant="destructive">{a}</Badge>
                  ))}
                </div>
              </div>
            ) : null}
            {data.kronikus_betegsegek?.length ? (
              <div>
                <div className="text-muted-foreground mb-1">Krónikus betegségek</div>
                <ul className="list-disc list-inside text-xs">
                  {data.kronikus_betegsegek.map((c: string, i: number) => <li key={i}>{c}</li>)}
                </ul>
              </div>
            ) : null}
            {data.gyogyszerek?.length ? (
              <div>
                <div className="text-muted-foreground mb-1">Gyógyszerek</div>
                <ul className="list-disc list-inside text-xs">
                  {data.gyogyszerek.map((g: string, i: number) => <li key={i}>{g}</li>)}
                </ul>
              </div>
            ) : null}
            {(data.sos_kontakt_nev || data.sos_kontakt_telefon) && (
              <div className="rounded-md bg-muted/40 px-3 py-2 flex items-center gap-2">
                <Phone className="h-3.5 w-3.5" />
                <span>
                  {data.sos_kontakt_nev ?? "—"}
                  {data.sos_kontakt_telefon && (
                    <a className="ml-1 underline" href={`tel:${data.sos_kontakt_telefon}`}>
                      {data.sos_kontakt_telefon}
                    </a>
                  )}
                </span>
              </div>
            )}
            {data.egyeb_info && (
              <p className="text-xs text-muted-foreground italic">{data.egyeb_info}</p>
            )}
            {data.updated_at && (
              <p className="text-[10px] text-muted-foreground">
                Frissítve: {new Date(data.updated_at).toLocaleString("hu-HU")}
              </p>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}
