import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Loader2, Sparkles, AlertTriangle, X, Filter } from "lucide-react";

import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";

type Row = {
  id: string;
  source_table: string;
  source_id: string;
  language: string;
  model: string | null;
  explanation: any;
  critical_flags: any;
  suggested_specialty_id: string | null;
  expires_at: string | null;
  created_at: string;
};

/**
 * Staff audit panel for AI explanations shown to the patient on the portal.
 * Shows what the patient saw, when, and whether it was flagged critical.
 */
export function PatientAiExplanationsPanel({
  patientId,
  onClose,
}: {
  patientId: string;
  onClose: () => void;
}) {
  const { data, isLoading } = useQuery({
    queryKey: ["paciens-360", "ai-explanations", patientId],
    queryFn: async (): Promise<Row[]> => {
      const { data, error } = await supabase
        .from("patient_ai_explanations")
        .select("id, source_table, source_id, language, model, explanation, critical_flags, suggested_specialty_id, expires_at, created_at")
        .eq("patient_id", patientId)
        .order("created_at", { ascending: false })
        .limit(50);
      if (error) throw new Error(error.message);
      return (data ?? []) as Row[];
    },
  });

  const [modelFilter, setModelFilter] = useState<string>("__all__");
  const [sinceDays, setSinceDays] = useState<string>("30");
  const [criticalOnly, setCriticalOnly] = useState(false);

  const availableModels = useMemo(() => {
    const set = new Set<string>();
    (data ?? []).forEach((r) => { if (r.model) set.add(r.model); });
    return Array.from(set).sort();
  }, [data]);

  const filtered = useMemo(() => {
    const sinceMs = sinceDays === "all" ? 0 : Date.now() - Number(sinceDays) * 86400000;
    return (data ?? []).filter((r) => {
      if (sinceMs && new Date(r.created_at).getTime() < sinceMs) return false;
      if (modelFilter !== "__all__" && r.model !== modelFilter) return false;
      if (criticalOnly) {
        const exp = r.explanation ?? {};
        const critical = Array.isArray(r.critical_flags) ? r.critical_flags.length > 0 : !!exp?.critical;
        if (!critical) return false;
      }
      return true;
    });
  }, [data, modelFilter, sinceDays, criticalOnly]);

  return (
    <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-card border border-border rounded-xl w-full max-w-3xl max-h-[85vh] flex flex-col">
        <header className="p-4 border-b border-border flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-primary" /> AI lelet-magyarázatok (páciens-nézet)
            </h3>
            <p className="text-xs text-muted-foreground mt-1">
              Amit a páciens a portálon látott. Csak ellenőrzéshez — az AI által generált tartalom nem orvosi tanács.
            </p>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-md hover:bg-muted">
            <X className="h-4 w-4" />
          </button>
        </header>
        <div className="px-4 py-2 border-b border-border flex flex-wrap items-center gap-2 text-xs">
          <Filter className="h-3 w-3 text-muted-foreground" />
          <Select value={sinceDays} onValueChange={setSinceDays}>
            <SelectTrigger className="h-7 w-[140px] text-xs"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="7">Utolsó 7 nap</SelectItem>
              <SelectItem value="30">Utolsó 30 nap</SelectItem>
              <SelectItem value="90">Utolsó 90 nap</SelectItem>
              <SelectItem value="all">Összes</SelectItem>
            </SelectContent>
          </Select>
          <Select value={modelFilter} onValueChange={setModelFilter}>
            <SelectTrigger className="h-7 w-[180px] text-xs"><SelectValue placeholder="Modell" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="__all__">Összes modell</SelectItem>
              {availableModels.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}
            </SelectContent>
          </Select>
          <label className="inline-flex items-center gap-1 text-xs cursor-pointer select-none">
            <input
              type="checkbox"
              className="h-3 w-3"
              checked={criticalOnly}
              onChange={(e) => setCriticalOnly(e.target.checked)}
            />
            Csak kritikus
          </label>
          <span className="ml-auto text-muted-foreground">{filtered.length} / {(data ?? []).length}</span>
        </div>
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {isLoading && (
            <div className="text-sm text-muted-foreground flex items-center gap-2">
              <Loader2 className="h-4 w-4 animate-spin" /> Betöltés…
            </div>
          )}
          {!isLoading && filtered.length === 0 && (
            <div className="text-sm text-muted-foreground">
              {(data ?? []).length === 0
                ? "A páciens még nem kért AI-magyarázatot."
                : "Az aktuális szűrőre nincs találat."}
            </div>
          )}
          {filtered.map((r) => {
            const exp = r.explanation ?? {};
            const critical = Array.isArray(r.critical_flags) ? r.critical_flags.length > 0 : !!exp?.critical;
            return (
              <article
                key={r.id}
                className={`rounded-md border p-3 ${critical ? "border-destructive/50 bg-destructive/5" : "border-border bg-background"}`}
              >
                <header className="flex items-center justify-between gap-2 mb-2">
                  <div className="text-xs font-mono uppercase text-muted-foreground">
                    {new Date(r.created_at).toLocaleString("hu-HU")} · {r.source_table} · {r.language?.toUpperCase()}
                    {r.model && ` · ${r.model}`}
                  </div>
                  {critical && (
                    <span className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full bg-destructive/10 text-destructive border border-destructive/30 font-semibold">
                      <AlertTriangle className="h-3 w-3" /> KRITIKUS
                    </span>
                  )}
                </header>
                {exp.summary && <p className="text-sm mb-2">{exp.summary}</p>}
                {Array.isArray(exp.per_test) && exp.per_test.length > 0 && (
                  <ul className="text-xs space-y-0.5 mb-2">
                    {exp.per_test.map((t: any, i: number) => (
                      <li key={i}>
                        <strong>{t.code_display}</strong> ({t.status}): {t.layman}
                      </li>
                    ))}
                  </ul>
                )}
                {Array.isArray(exp.next_steps) && exp.next_steps.length > 0 && (
                  <div className="text-xs">
                    <div className="font-medium mb-0.5">Javasolt lépések:</div>
                    <ul className="list-disc pl-4 space-y-0.5">
                      {exp.next_steps.map((s: string, i: number) => <li key={i}>{s}</li>)}
                    </ul>
                  </div>
                )}
              </article>
            );
          })}
        </div>
      </div>
    </div>
  );
}
