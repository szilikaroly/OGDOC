import type { ElementType } from "react";
import { useTranslatedText } from "@/hooks/useTranslatedText";

interface TProps {
  text: string | null | undefined;
  namespace?: string;
  as?: ElementType;
  className?: string;
}

/**
 * Automatically translates DB-sourced content text to the current UI language.
 * Falls back to the original text while the translation is loading.
 */
export function T({ text, namespace = "content", as: As = "span", className }: TProps) {
  const translated = useTranslatedText(text, namespace);
  const Tag = As as any;
  return <Tag className={className}>{translated || text || ""}</Tag>;
}
