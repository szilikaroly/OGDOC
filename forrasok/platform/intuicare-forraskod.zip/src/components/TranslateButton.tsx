import { useState } from "react";
import { useTranslation } from "react-i18next";
import { Languages, Copy, Loader2, AlertTriangle, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { SUPPORTED_LANGUAGES } from "@/i18n/languages";
import { translateOnce } from "@/hooks/useTranslatedText";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

interface TranslateButtonProps {
  text: string;
  className?: string;
  size?: "sm" | "icon";
  label?: string;
}

/**
 * One-tap AI translation for any text block.
 * Opens a popover with language picker and renders the result.
 */
export function TranslateButton({ text, className, size = "icon", label }: TranslateButtonProps) {
  const { i18n, t } = useTranslation();
  const initial = i18n.language?.split("-")[0] ?? "en";
  const [target, setTarget] = useState(initial === "hu" ? "en" : initial);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function run(lang: string) {
    if (!text?.trim()) return;
    setTarget(lang);
    setLoading(true);
    setError(null);
    try {
      const r = await translateOnce(text, lang);
      setResult(r);
    } catch (e: any) {
      const msg = String(e?.message ?? e ?? "");
      let friendly: string;
      if (msg.includes("429")) friendly = t("translate.rate_limited", "Túl sok kérés – várj kicsit");
      else if (msg.includes("402")) friendly = t("translate.credits", "Elfogytak az AI kreditek");
      else friendly = t("translate.failed", "Fordítás sikertelen");
      setError(friendly);
      toast.error(friendly);
    } finally {
      setLoading(false);
    }
  }

  function copy() {
    if (!result) return;
    navigator.clipboard.writeText(result);
    toast.success(t("translate.copied", "Másolva"));
  }

  return (
    <Popover
      onOpenChange={(o) => {
        if (o && !result && !loading) run(target);
      }}
    >
      <PopoverTrigger asChild>
        {size === "icon" ? (
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className={cn("h-7 w-7", className)}
            title={t("translate.translate", "Fordítás")}
          >
            <Languages className="h-4 w-4" />
          </Button>
        ) : (
          <Button type="button" variant="ghost" size="sm" className={className}>
            <Languages className="h-4 w-4 mr-1.5" />
            {label ?? t("translate.translate", "Fordítás")}
          </Button>
        )}
      </PopoverTrigger>
      <PopoverContent className="w-80" align="end">
        <div className="space-y-3">
          <div className="text-xs font-semibold text-muted-foreground">
            {t("translate.target_lang", "Célnyelv")}
          </div>
          <div className="flex flex-wrap gap-1">
            {SUPPORTED_LANGUAGES.map((l) => (
              <button
                key={l.code}
                type="button"
                onClick={() => run(l.code)}
                className={cn(
                  "px-2 py-1 text-xs rounded border transition-colors",
                  target === l.code
                    ? "bg-primary text-primary-foreground border-primary"
                    : "bg-background hover:bg-muted",
                )}
                disabled={loading}
              >
                {l.flag} {l.code.toUpperCase()}
              </button>
            ))}
          </div>
          <div className="border-t pt-3">
            {loading ? (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" />
                {t("translate.translating", "Fordítás folyamatban…")}
              </div>
            ) : error ? (
              <div className="space-y-2">
                <div className="flex items-start gap-2 text-sm text-destructive">
                  <AlertTriangle className="h-4 w-4 mt-0.5" />
                  <span>{error}</span>
                </div>
                <Button type="button" variant="outline" size="sm" onClick={() => run(target)} className="w-full">
                  <RotateCcw className="h-3.5 w-3.5 mr-1.5" />
                  {t("translate.retry", "Próbáld újra")}
                </Button>
              </div>
            ) : result ? (
              <div className="space-y-2">
                <div className="text-sm whitespace-pre-wrap max-h-60 overflow-auto rounded bg-muted p-2">
                  {result}
                </div>
                <div className="flex gap-2">
                  <Button type="button" variant="outline" size="sm" onClick={copy} className="flex-1">
                    <Copy className="h-3.5 w-3.5 mr-1.5" />
                    {t("translate.copy", "Másolás")}
                  </Button>
                  <Button type="button" variant="ghost" size="sm" onClick={() => run(target)}>
                    <RotateCcw className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            ) : (
              <div className="text-xs text-muted-foreground">
                {t("translate.pick_lang", "Válassz célnyelvet")}
              </div>
            )}
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}
