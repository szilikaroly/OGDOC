/**
 * Eüsztv. lefedettségi mátrix admin komponens.
 * Megmutatja, hogy a feltöltött szabályok melyik Eüsztv. szakaszokat fedik le,
 * és kiemeli a hiányzókat. Lefedettségi statisztika + CSV export.
 */
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { CheckCircle2, AlertTriangle, XCircle, Download, Loader2, ShieldCheck } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { getEusztvCoverage } from "@/lib/eusztv/illetmeny.functions";
import { HianypotlasExportDialog } from "./hianypotlas-export-dialog";

export function EusztvCoverageMatrix() {
  const fn = useServerFn(getEusztvCoverage);
  const { data, isLoading, refetch, isRefetching } = useQuery({
    queryKey: ["eusztv-coverage"],
    queryFn: () => fn(),
  });

  if (isLoading) {
    return (
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <Loader2 className="h-4 w-4 animate-spin" /> Lefedettség lekérése…
      </div>
    );
  }
  if (!data) return null;

  const downloadCsv = () => {
    const rows = [
      ["Eüsztv. szakasz", "Cím", "Tábla", "Szükséges", "Megvan", "Státusz"],
      ...data.tetelek.map((t) => [t.szakasz, t.cim, t.tabla, t.szukseges, t.megvan, t.status]),
    ];
    const csv = rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `eusztv-lefedettseg-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const hianyzok = data.tetelek.filter((t) => t.status !== "ok");

  return (
    <div className="space-y-4">
      <Card className="p-4 space-y-3">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div>
            <div className="flex items-center gap-2 font-medium">
              <ShieldCheck className="h-4 w-4" /> Eüsztv. lefedettségi mátrix
            </div>
            <div className="text-xs text-muted-foreground">
              Generálva: {new Date(data.generalt).toLocaleString("hu-HU")}
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button size="sm" variant="outline" onClick={() => refetch()} disabled={isRefetching}>
              Frissítés
            </Button>
            <Button size="sm" variant="outline" onClick={downloadCsv}>
              <Download className="h-4 w-4 mr-1" /> CSV
            </Button>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex-1">
            <Progress value={data.szazalek} />
          </div>
          <Badge variant={data.szazalek === 100 ? "default" : "outline"}>
            {data.lefedett} / {data.osszesen} ({data.szazalek}%)
          </Badge>
        </div>
      </Card>

      <Card className="p-0 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-xs">
            <tr>
              <th className="text-left px-3 py-2">Eüsztv. szakasz</th>
              <th className="text-left px-3 py-2">Cím</th>
              <th className="text-left px-3 py-2">Adattábla</th>
              <th className="text-right px-3 py-2">Szükséges</th>
              <th className="text-right px-3 py-2">Megvan</th>
              <th className="text-center px-3 py-2">Státusz</th>
            </tr>
          </thead>
          <tbody>
            {data.tetelek.map((t) => (
              <tr
                key={`${t.szakasz}-${t.tabla}`}
                className={`border-t ${
                  t.status === "hianyzik"
                    ? "bg-destructive/5"
                    : t.status === "reszleges"
                      ? "bg-yellow-500/5"
                      : ""
                }`}
              >
                <td className="px-3 py-2 font-mono text-xs">{t.szakasz}</td>
                <td className="px-3 py-2">{t.cim}</td>
                <td className="px-3 py-2 text-xs text-muted-foreground">{t.tabla}</td>
                <td className="px-3 py-2 text-right">{t.szukseges}</td>
                <td className="px-3 py-2 text-right font-medium">{t.megvan}</td>
                <td className="px-3 py-2 text-center">
                  {t.status === "ok" && (
                    <span className="inline-flex items-center gap-1 text-green-700 dark:text-green-400">
                      <CheckCircle2 className="h-4 w-4" /> rendben
                    </span>
                  )}
                  {t.status === "reszleges" && (
                    <span className="inline-flex items-center gap-1 text-yellow-700 dark:text-yellow-400">
                      <AlertTriangle className="h-4 w-4" /> részleges
                    </span>
                  )}
                  {t.status === "hianyzik" && (
                    <span className="inline-flex items-center gap-1 text-destructive">
                      <XCircle className="h-4 w-4" /> hiányzik
                    </span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      {hianyzok.length > 0 && (
        <Card className="p-4 border-destructive/30 bg-destructive/5 space-y-3">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="font-medium flex items-center gap-2">
              <AlertTriangle className="h-4 w-4" /> Hiánypótlás szükséges
              <Badge variant="outline">{hianyzok.length} tétel</Badge>
            </div>
            <div className="flex items-center gap-2">
              <HianypotlasExportDialog
                items={hianyzok}
                szazalek={data.szazalek}
                lefedett={data.lefedett}
                osszesen={data.osszesen}
              />
            </div>
          </div>
          <ul className="text-sm space-y-1 list-disc list-inside">
            {hianyzok.map((h) => (
              <li key={`${h.szakasz}-${h.tabla}`}>
                <span className="font-mono text-xs">{h.szakasz}</span> — {h.cim}
                {h.status === "reszleges" ? " (részleges adat)" : ""}
              </li>
            ))}
          </ul>
          <p className="text-xs text-muted-foreground">
            Az export tartalmazza a szakaszt, címet, adattáblát, hiányzó/megvan értékeket és a státuszt — külső egyeztetéshez használható.
          </p>
        </Card>
      )}
    </div>
  );
}


