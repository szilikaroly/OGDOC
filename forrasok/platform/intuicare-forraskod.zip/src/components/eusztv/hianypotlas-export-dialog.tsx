/**
 * Hiánypótlási lista exportáló dialógus: dátumtartomány + oszlopválasztás,
 * CSV vagy PDF kimenettel. A dátumtartomány a riport fejlécében jelenik meg
 * (a "meddig érvényes / mely időszakra vonatkozik" jelöléshez), és bekerül
 * a fájlnévbe is.
 */
import { useMemo, useState } from "react";
import { Download, FileText, FileSpreadsheet } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { toast } from "sonner";

export type HianyItem = {
  szakasz: string;
  cim: string;
  tabla: string;
  szukseges: number;
  megvan: number;
  status: string;
};

type ColumnKey =
  | "szakasz"
  | "cim"
  | "tabla"
  | "szukseges"
  | "megvan"
  | "hianyzo"
  | "status";

const COLUMNS: { key: ColumnKey; label: string; align?: "left" | "right" | "center" }[] = [
  { key: "szakasz", label: "Eüsztv. szakasz" },
  { key: "cim", label: "Cím" },
  { key: "tabla", label: "Adattábla" },
  { key: "szukseges", label: "Szükséges", align: "right" },
  { key: "megvan", label: "Megvan", align: "right" },
  { key: "hianyzo", label: "Hiányzó", align: "right" },
  { key: "status", label: "Státusz", align: "center" },
];

function valueFor(item: HianyItem, key: ColumnKey): string | number {
  switch (key) {
    case "szakasz":
      return item.szakasz;
    case "cim":
      return item.cim;
    case "tabla":
      return item.tabla;
    case "szukseges":
      return item.szukseges;
    case "megvan":
      return item.megvan;
    case "hianyzo":
      return Math.max(0, item.szukseges - item.megvan);
    case "status":
      return item.status === "hianyzik"
        ? "hiányzik"
        : item.status === "reszleges"
          ? "részleges"
          : item.status;
  }
}

function downloadFile(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export function HianypotlasExportDialog({
  items,
  szazalek,
  lefedett,
  osszesen,
}: {
  items: HianyItem[];
  szazalek: number;
  lefedett: number;
  osszesen: number;
}) {
  const today = new Date().toISOString().slice(0, 10);
  const monthAgo = useMemo(() => {
    const d = new Date();
    d.setMonth(d.getMonth() - 1);
    return d.toISOString().slice(0, 10);
  }, []);

  const [open, setOpen] = useState(false);
  const [from, setFrom] = useState(monthAgo);
  const [to, setTo] = useState(today);
  const [selected, setSelected] = useState<Record<ColumnKey, boolean>>({
    szakasz: true,
    cim: true,
    tabla: true,
    szukseges: true,
    megvan: true,
    hianyzo: true,
    status: true,
  });
  const [format, setFormat] = useState<"csv" | "pdf">("csv");
  const [busy, setBusy] = useState(false);

  const activeCols = COLUMNS.filter((c) => selected[c.key]);
  const canExport = activeCols.length > 0 && from <= to;

  const toggle = (k: ColumnKey) =>
    setSelected((prev) => ({ ...prev, [k]: !prev[k] }));

  const runExport = async () => {
    if (!canExport) {
      toast.error(
        activeCols.length === 0
          ? "Válassz legalább egy oszlopot."
          : "A kezdő dátum nem lehet későbbi, mint a záró dátum.",
      );
      return;
    }
    setBusy(true);
    try {
      if (format === "csv") {
        exportCsv();
      } else {
        await exportPdf();
      }
      toast.success(`Export kész (${format.toUpperCase()}, ${items.length} tétel)`);
      setOpen(false);
    } catch (e: any) {
      toast.error(`Export sikertelen: ${e?.message ?? "ismeretlen hiba"}`);
    } finally {
      setBusy(false);
    }
  };

  const dateSuffix = `${from}_${to}`;

  const exportCsv = () => {
    const header = activeCols.map((c) => c.label);
    const meta = [
      [`Riport időszak: ${from} — ${to}`],
      [`Lefedettség: ${lefedett}/${osszesen} (${szazalek}%) — ${items.length} hiánypótlási tétel`],
      [],
    ];
    const body = items.map((it) => activeCols.map((c) => valueFor(it, c.key)));
    const rows = [...meta, header, ...body];
    const csv = rows
      .map((r) =>
        r.map((c) => `"${String(c ?? "").replace(/"/g, '""')}"`).join(","),
      )
      .join("\n");
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8" });
    downloadFile(blob, `eusztv-hianypotlas-${dateSuffix}.csv`);
  };

  const exportPdf = async () => {
    const [{ default: jsPDF }, { default: autoTable }] = await Promise.all([
      import("jspdf"),
      import("jspdf-autotable"),
    ]);
    const doc = new jsPDF({ unit: "mm", format: "a4" });
    const margin = 14;
    let y = margin;

    doc.setFont("helvetica", "bold");
    doc.setFontSize(16);
    doc.text("Eüsztv. lefedettség — Hiánypótlási lista", margin, y);
    y += 7;
    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    doc.text(`Riport időszak: ${from} — ${to}`, margin, y);
    y += 5;
    doc.text(`Generálva: ${new Date().toLocaleString("hu-HU")}`, margin, y);
    y += 5;
    doc.text(
      `Lefedettség: ${lefedett} / ${osszesen} szakasz (${szazalek}%) — ${items.length} tétel hiánypótlásra vár`,
      margin,
      y,
    );
    y += 6;

    const statusColIdx = activeCols.findIndex((c) => c.key === "status");

    autoTable(doc, {
      startY: y,
      head: [activeCols.map((c) => c.label)],
      body: items.map((it) => activeCols.map((c) => String(valueFor(it, c.key)))),
      styles: { fontSize: 9 },
      headStyles: { fillColor: [180, 60, 60] },
      didParseCell: (data) => {
        if (
          data.section === "body" &&
          statusColIdx >= 0 &&
          data.column.index === statusColIdx
        ) {
          const v = (data.cell.raw as string) ?? "";
          if (v === "hiányzik") data.cell.styles.fillColor = [250, 220, 220];
          else if (v === "részleges") data.cell.styles.fillColor = [255, 240, 200];
        }
      },
    });

    const finalY = (doc as any).lastAutoTable.finalY + 6;
    doc.setFontSize(8);
    doc.setTextColor(100);
    doc.text(
      "A lista a 2020. évi C. törvény (Eüsztv.) szakaszait fedi le. Külső egyeztetésre, hiánypótlás dokumentálására használható.",
      margin,
      finalY,
    );

    doc.save(`eusztv-hianypotlas-${dateSuffix}.pdf`);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm" variant="outline">
          <Download className="h-4 w-4 mr-1" /> Export…
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Hiánypótlási lista exportja</DialogTitle>
          <DialogDescription>
            Válaszd ki a riport időszakát, az exportálandó oszlopokat és a formátumot.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label htmlFor="export-from" className="text-xs">Időszak kezdete</Label>
              <Input
                id="export-from"
                type="date"
                value={from}
                onChange={(e) => setFrom(e.target.value)}
                max={to}
                className="min-h-11"
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="export-to" className="text-xs">Időszak vége</Label>
              <Input
                id="export-to"
                type="date"
                value={to}
                onChange={(e) => setTo(e.target.value)}
                min={from}
                max={today}
                className="min-h-11"
              />
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="text-xs">Oszlopok ({activeCols.length}/{COLUMNS.length})</Label>
              <div className="flex gap-1">
                <button
                  type="button"
                  className="text-[11px] text-primary hover:underline"
                  onClick={() =>
                    setSelected(
                      Object.fromEntries(COLUMNS.map((c) => [c.key, true])) as Record<ColumnKey, boolean>,
                    )
                  }
                >
                  Mind
                </button>
                <span className="text-[11px] text-muted-foreground">·</span>
                <button
                  type="button"
                  className="text-[11px] text-primary hover:underline"
                  onClick={() =>
                    setSelected(
                      Object.fromEntries(COLUMNS.map((c) => [c.key, false])) as Record<ColumnKey, boolean>,
                    )
                  }
                >
                  Egyik sem
                </button>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2 rounded-md border border-border p-2">
              {COLUMNS.map((c) => (
                <label
                  key={c.key}
                  className="flex items-center gap-2 min-h-9 px-1 text-sm cursor-pointer"
                >
                  <Checkbox
                    checked={selected[c.key]}
                    onCheckedChange={() => toggle(c.key)}
                  />
                  <span>{c.label}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-xs">Formátum</Label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setFormat("csv")}
                className={`flex items-center gap-2 min-h-11 rounded-md border px-3 text-sm transition ${
                  format === "csv"
                    ? "border-primary bg-primary/5 text-foreground"
                    : "border-border bg-card hover:bg-accent"
                }`}
              >
                <FileSpreadsheet className="h-4 w-4" /> CSV
              </button>
              <button
                type="button"
                onClick={() => setFormat("pdf")}
                className={`flex items-center gap-2 min-h-11 rounded-md border px-3 text-sm transition ${
                  format === "pdf"
                    ? "border-primary bg-primary/5 text-foreground"
                    : "border-border bg-card hover:bg-accent"
                }`}
              >
                <FileText className="h-4 w-4" /> PDF
              </button>
            </div>
          </div>
        </div>

        <DialogFooter className="gap-2 sm:gap-2">
          <Button
            variant="ghost"
            onClick={() => setOpen(false)}
            className="min-h-11"
          >
            Mégse
          </Button>
          <Button
            onClick={runExport}
            disabled={!canExport || busy}
            className="min-h-11"
          >
            <Download className="h-4 w-4 mr-1" />
            {busy ? "Exportálás…" : `Exportálás (${items.length} tétel)`}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
