import { useRef, useState } from "react";
import { Upload, Loader2, Check, X } from "lucide-react";
import { toast } from "sonner";

type ParsedRow = {
  selected: boolean;
  munkaltato_nev: string;
  jogviszony: string;
  kezdo_datum: string; // ISO
  zaro_datum: string;
  napok: number;
  munkakor: string;
  fenntarto_tipus: string;
  beszamithato_eusztv: boolean;
  beszamithato_jubileum: boolean;
};

function toIso(d: string): string {
  // "2008.11.01." -> "2008-11-01"
  const m = d.match(/(\d{4})\.(\d{2})\.(\d{2})\./);
  return m ? `${m[1]}-${m[2]}-${m[3]}` : "";
}

function guessFenntarto(munkaltato: string): string {
  const u = munkaltato.toUpperCase();
  if (/EGYETEM|KLINIKA|KÓRHÁZ|MINISZTÉRIUM|ÁLLAM|HONVÉD|KORMÁNY/.test(u)) return "allami";
  if (/ÖNKORMÁNYZ|VÁROS|MEGYEI/.test(u)) return "onkormanyzati";
  if (/EGYHÁZ|REFORMÁTUS|KATOLIKUS|EVANGÉLIKUS/.test(u)) return "egyhazi";
  if (/KFT|BT|ZRT|RT\b|NYRT/.test(u)) return "magan";
  return "egyeb";
}

async function extractText(file: File): Promise<string> {
  const pdfjs: any = await import("pdfjs-dist/legacy/build/pdf.mjs");
  // Disable worker — runs on main thread, simpler & avoids worker URL issues.
  pdfjs.GlobalWorkerOptions.workerSrc = "";
  const buf = await file.arrayBuffer();
  const doc = await pdfjs.getDocument({ data: buf, disableWorker: true, isEvalSupported: false }).promise;
  let all = "";
  for (let p = 1; p <= doc.numPages; p++) {
    const page = await doc.getPage(p);
    const tc = await page.getTextContent();
    // Sort by y desc, then x asc to preserve reading order
    const items = (tc.items as any[]).slice().sort((a, b) => {
      const ay = a.transform[5], by = b.transform[5];
      if (Math.abs(ay - by) > 4) return by - ay;
      return a.transform[4] - b.transform[4];
    });
    let lastY = 1e9;
    for (const it of items) {
      const y = it.transform[5];
      if (lastY - y > 4) all += "\n";
      all += " " + (it.str || "");
      lastY = y;
    }
    all += "\n\n";
  }
  return all;
}

function parseRows(text: string): ParsedRow[] {
  // Match: <Sorszám int> <YYYY.MM.DD.> <YYYY.MM.DD.> <napok int> <... payload ...> until next row or end
  const re = /(?:^|\s)(\d{1,3})\s+(\d{4}\.\d{2}\.\d{2}\.)\s+(\d{4}\.\d{2}\.\d{2}\.)\s+(\d{1,4})\s+([\s\S]*?)(?=(?:\s\d{1,3}\s+\d{4}\.\d{2}\.\d{2}\.\s+\d{4}\.\d{2}\.\d{2}\.\s+\d{1,4})|$)/g;
  const rows: ParsedRow[] = [];
  let m: RegExpExecArray | null;
  const seen = new Set<string>();
  while ((m = re.exec(text)) !== null) {
    const [, , k, v, n, payload] = m;
    const cleaned = payload.replace(/\s+/g, " ").trim();
    // Extract jogviszony keyword
    const jogM = cleaned.match(/(munkaviszony jellegű jogviszony[^]*?szolgálati viszony|közalkalmazotti jogviszony|egészségügyi szolgálati jogviszony|megbízási jogviszony|munkaviszony|közszolgálati jogviszony|kormányzati szolgálati jogviszony|bírósági.*?jogviszony|hivatásos.*?jogviszony)/i);
    const jogviszony = jogM ? jogM[0].slice(0, 60) : "";
    // Employer = text up to jogviszony match
    let employer = jogM ? cleaned.slice(0, jogM.index).trim() : cleaned.slice(0, 60).trim();
    employer = employer.replace(/\s*\d{4}\s*$/, "").slice(0, 120).trim();
    // Munkakör = after FEOR code (4 digits) we often have UPPERCASE job title
    const mkM = cleaned.match(/\b\d{4}\b\s+([A-ZÁÉÍÓÖŐÚÜŰ ,]+?)(?:\s+[RM]\s+\d{1,3}|\s*$)/);
    const munkakor = mkM ? mkM[1].trim().replace(/\s+/g, " ").slice(0, 80) : "";

    const kezdo = toIso(k);
    const zaro = toIso(v);
    const key = `${employer}|${kezdo}|${zaro}`;
    if (seen.has(key)) continue;
    seen.add(key);

    const isEusztvEligible = /klinika|kórház|egyetem|egészségügy|gyógy|szakorvos/i.test(employer + " " + munkakor);

    rows.push({
      selected: true,
      munkaltato_nev: employer || "Ismeretlen munkáltató",
      jogviszony,
      kezdo_datum: kezdo,
      zaro_datum: zaro,
      napok: Number(n),
      munkakor,
      fenntarto_tipus: guessFenntarto(employer),
      beszamithato_eusztv: isEusztvEligible,
      beszamithato_jubileum: true,
    });
  }
  return rows;
}

export function ServiceHistoryPdfImport({
  onImport,
}: {
  onImport: (rows: Array<Omit<ParsedRow, "selected" | "jogviszony" | "napok">>) => Promise<void> | void;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [parsing, setParsing] = useState(false);
  const [rows, setRows] = useState<ParsedRow[]>([]);
  const [importing, setImporting] = useState(false);

  async function onFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setParsing(true);
    setRows([]);
    try {
      const text = await extractText(file);
      const parsed = parseRows(text);
      if (parsed.length === 0) {
        toast.error("Nem találtam felismerhető jogviszony-sort a PDF-ben.");
      } else {
        setRows(parsed);
        toast.success(`${parsed.length} sor felismerve. Ellenőrizd, majd importálj.`);
      }
    } catch (err: any) {
      toast.error("PDF-feldolgozási hiba: " + (err?.message ?? err));
    } finally {
      setParsing(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  }

  async function doImport() {
    const selected = rows.filter((r) => r.selected);
    if (!selected.length) return;
    setImporting(true);
    try {
      await onImport(
        selected.map((r) => ({
          munkaltato_nev: r.munkaltato_nev,
          munkakor: r.munkakor,
          kezdo_datum: r.kezdo_datum,
          zaro_datum: r.zaro_datum,
          fenntarto_tipus: r.fenntarto_tipus,
          beszamithato_eusztv: r.beszamithato_eusztv,
          beszamithato_jubileum: r.beszamithato_jubileum,
        })),
      );
      setRows([]);
    } finally {
      setImporting(false);
    }
  }

  return (
    <div className="border rounded-lg p-4 bg-muted/20 space-y-3">
      <div className="flex items-center gap-3 flex-wrap">
        <h4 className="font-medium text-sm">PDF importálás (NYUFIG / Államkincstár kivonat)</h4>
        <button
          onClick={() => inputRef.current?.click()}
          disabled={parsing}
          className="inline-flex items-center gap-2 px-3 py-1.5 bg-primary text-primary-foreground rounded text-sm hover:opacity-90 disabled:opacity-50"
        >
          {parsing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
          PDF kiválasztása
        </button>
        <input ref={inputRef} type="file" accept="application/pdf" hidden onChange={onFile} />
        <span className="text-xs text-muted-foreground">A nyugdíjbiztosítási kivonatból automatikusan kinyeri a jogviszonyokat.</span>
      </div>

      {rows.length > 0 && (
        <>
          <div className="overflow-auto max-h-[400px] border rounded bg-background">
            <table className="w-full text-xs">
              <thead className="bg-muted sticky top-0">
                <tr>
                  <th className="p-1.5 text-center w-8"><input type="checkbox" checked={rows.every((r) => r.selected)} onChange={(e) => setRows(rows.map((r) => ({ ...r, selected: e.target.checked })))} /></th>
                  <th className="p-1.5 text-left">Munkáltató</th>
                  <th className="p-1.5 text-left">Munkakör</th>
                  <th className="p-1.5 text-left">Tól</th>
                  <th className="p-1.5 text-left">Ig</th>
                  <th className="p-1.5 text-left">Fenntartó</th>
                  <th className="p-1.5 text-center">Eüsztv.</th>
                  <th className="p-1.5 text-center">Jub.</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r, idx) => (
                  <tr key={idx} className="border-t">
                    <td className="p-1 text-center"><input type="checkbox" checked={r.selected} onChange={(e) => setRows(rows.map((x, i) => i === idx ? { ...x, selected: e.target.checked } : x))} /></td>
                    <td className="p-1"><input className="w-full px-1.5 py-1 border rounded bg-background" value={r.munkaltato_nev} onChange={(e) => setRows(rows.map((x, i) => i === idx ? { ...x, munkaltato_nev: e.target.value } : x))} /></td>
                    <td className="p-1"><input className="w-full px-1.5 py-1 border rounded bg-background" value={r.munkakor} onChange={(e) => setRows(rows.map((x, i) => i === idx ? { ...x, munkakor: e.target.value } : x))} /></td>
                    <td className="p-1"><input type="date" className="px-1.5 py-1 border rounded bg-background" value={r.kezdo_datum} onChange={(e) => setRows(rows.map((x, i) => i === idx ? { ...x, kezdo_datum: e.target.value } : x))} /></td>
                    <td className="p-1"><input type="date" className="px-1.5 py-1 border rounded bg-background" value={r.zaro_datum} onChange={(e) => setRows(rows.map((x, i) => i === idx ? { ...x, zaro_datum: e.target.value } : x))} /></td>
                    <td className="p-1">
                      <select className="px-1.5 py-1 border rounded bg-background" value={r.fenntarto_tipus} onChange={(e) => setRows(rows.map((x, i) => i === idx ? { ...x, fenntarto_tipus: e.target.value } : x))}>
                        {["allami", "onkormanyzati", "egyhazi", "magan", "kulfoldi", "egyeb"].map((x) => <option key={x} value={x}>{x}</option>)}
                      </select>
                    </td>
                    <td className="p-1 text-center"><input type="checkbox" checked={r.beszamithato_eusztv} onChange={(e) => setRows(rows.map((x, i) => i === idx ? { ...x, beszamithato_eusztv: e.target.checked } : x))} /></td>
                    <td className="p-1 text-center"><input type="checkbox" checked={r.beszamithato_jubileum} onChange={(e) => setRows(rows.map((x, i) => i === idx ? { ...x, beszamithato_jubileum: e.target.checked } : x))} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="flex gap-2 items-center">
            <button
              disabled={importing}
              onClick={doImport}
              className="inline-flex items-center gap-2 px-3 py-1.5 bg-primary text-primary-foreground rounded text-sm hover:opacity-90 disabled:opacity-50"
            >
              {importing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
              Kiválasztottak importálása ({rows.filter((r) => r.selected).length})
            </button>
            <button onClick={() => setRows([])} className="inline-flex items-center gap-1 px-3 py-1.5 border rounded text-sm">
              <X className="h-4 w-4" /> Elvetés
            </button>
            <span className="text-xs text-muted-foreground">A „forrás” mező automatikusan <code>dokumentum</code> lesz.</span>
          </div>
        </>
      )}
    </div>
  );
}
