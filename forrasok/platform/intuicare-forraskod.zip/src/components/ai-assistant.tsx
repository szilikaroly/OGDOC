import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport, type UIMessage } from "ai";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Bot, Send, Sparkles, Trash2, X, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { useServerFn } from "@tanstack/react-start";
import { loadChatHistory, saveChatMessage, clearChatHistory } from "@/lib/chat.functions";
import { useAuth } from "@/hooks/use-auth";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type StoredMessage = {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  parts: unknown;
};

function rowToUIMessage(row: StoredMessage): UIMessage | null {
  if (row.role === "system") return null;
  return {
    id: row.id,
    role: row.role,
    parts: [{ type: "text", text: row.content }],
  } as UIMessage;
}

export function AiAssistant() {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const [initial, setInitial] = useState<UIMessage[] | null>(null);
  const [loadingHistory, setLoadingHistory] = useState(false);
  const [input, setInput] = useState("");
  const [authToken, setAuthToken] = useState<string | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const loadFn = useServerFn(loadChatHistory);
  const saveFn = useServerFn(saveChatMessage);
  const clearFn = useServerFn(clearChatHistory);

  // Token frissítése a stream-hívásokhoz
  useEffect(() => {
    let mounted = true;
    const refresh = async () => {
      const { data } = await supabase.auth.getSession();
      if (mounted) setAuthToken(data.session?.access_token ?? null);
    };
    refresh();
    const { data: sub } = supabase.auth.onAuthStateChange(() => refresh());
    return () => {
      mounted = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  // Beszélgetés betöltése első nyitáskor
  useEffect(() => {
    if (!open || initial !== null || !user) return;
    setLoadingHistory(true);
    loadFn()
      .then((rows) => {
        const msgs = (rows as StoredMessage[])
          .map(rowToUIMessage)
          .filter((m): m is UIMessage => m !== null);
        setInitial(msgs);
      })
      .catch((e) => {
        console.error(e);
        toast.error("Nem sikerült betölteni a beszélgetést");
        setInitial([]);
      })
      .finally(() => setLoadingHistory(false));
  }, [open, initial, user, loadFn]);

  const transport = useMemo(
    () =>
      new DefaultChatTransport({
        api: "/api/chat",
        headers: (): Record<string, string> =>
          authToken ? { Authorization: `Bearer ${authToken}` } : {},
      }),
    [authToken],
  );

  const lastSavedRef = useRef<Set<string>>(new Set());
  const { messages, sendMessage, status, error, setMessages } = useChat({
    id: user?.id ?? "anon",
    messages: initial ?? [],
    transport,
    onError: (e) => {
      console.error("[ai-assistant]", e);
      toast.error(e.message || "AI hiba");
    },
    onFinish: ({ message }) => {
      // Mentés DB-be befejezéskor
      const text = (message.parts ?? [])
        .map((p) => (p.type === "text" ? p.text : ""))
        .join("");
      if (text && !lastSavedRef.current.has(message.id)) {
        lastSavedRef.current.add(message.id);
        void saveFn({ data: { role: "assistant", content: text } }).catch(() => {});
      }
    },
  });

  // Initial üzenetek átemelése amint betöltődnek (chat id változatlan, így csak setMessages)
  useEffect(() => {
    if (initial && messages.length === 0 && initial.length > 0) {
      setMessages(initial);
      initial.forEach((m) => lastSavedRef.current.add(m.id));
    }
  }, [initial, messages.length, setMessages]);

  // Görgetés aljára
  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages, status]);

  // Fókusz vissza a textarea-ra
  useEffect(() => {
    if (open) textareaRef.current?.focus();
  }, [open, status]);

  const isBusy = status === "submitted" || status === "streaming";

  const handleSend = useCallback(async () => {
    const trimmed = input.trim();
    if (!trimmed || isBusy) return;
    setInput("");
    // Felhasználói üzenet mentése
    void saveFn({ data: { role: "user", content: trimmed } }).catch(() => {});
    await sendMessage({ text: trimmed });
  }, [input, isBusy, sendMessage, saveFn]);

  const handleClear = useCallback(async () => {
    if (!confirm("Biztosan törlöd a teljes beszélgetést?")) return;
    try {
      await clearFn();
      setMessages([]);
      lastSavedRef.current.clear();
      toast.success("Beszélgetés törölve");
    } catch {
      toast.error("Törlés sikertelen");
    }
  }, [clearFn, setMessages]);

  if (!user) return null;

  return (
    <>
      {/* Lebegő gomb */}
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className={cn(
          "fixed bottom-6 right-6 z-40 h-14 w-14 rounded-full bg-primary text-primary-foreground shadow-lg flex items-center justify-center hover:scale-105 transition-transform",
          open && "scale-95",
        )}
        aria-label="AI asszisztens"
      >
        {open ? <X className="h-6 w-6" /> : <Sparkles className="h-6 w-6" />}
      </button>

      {/* Panel */}
      {open && (
        <div className="fixed bottom-24 right-6 z-40 w-[min(420px,calc(100vw-2rem))] h-[min(620px,calc(100vh-8rem))] bg-card border border-border rounded-2xl shadow-2xl flex flex-col overflow-hidden">
          <div className="flex items-center justify-between px-4 py-3 border-b border-border bg-muted/40">
            <div className="flex items-center gap-2">
              <Bot className="h-5 w-5 text-primary" />
              <div>
                <div className="font-semibold text-sm">Segítő asszisztens</div>
                <div className="text-[11px] text-muted-foreground">Karakterlap, súgó, jogi háttér</div>
              </div>
            </div>
            <Button variant="ghost" size="icon" onClick={handleClear} title="Beszélgetés törlése">
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>

          <ScrollArea className="flex-1">
            <div ref={scrollRef} className="p-4 space-y-3">
              {loadingHistory && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin" /> Beszélgetés betöltése…
                </div>
              )}
              {!loadingHistory && messages.length === 0 && (
                <div className="text-sm text-muted-foreground space-y-2">
                  <p>Szia! Miben segíthetek?</p>
                  <ul className="list-disc list-inside text-xs space-y-1">
                    <li>Karakterlap mezők értelmezése</li>
                    <li>Hol találom a beosztást/pótlást/túlórát?</li>
                    <li>528/2020 ügyeleti szabályok röviden</li>
                  </ul>
                </div>
              )}
              {messages.map((m) => {
                const text = (m.parts ?? [])
                  .map((p) => (p.type === "text" ? p.text : ""))
                  .join("");
                return (
                  <div
                    key={m.id}
                    className={cn(
                      "flex",
                      m.role === "user" ? "justify-end" : "justify-start",
                    )}
                  >
                    <div
                      className={cn(
                        "max-w-[85%] text-sm whitespace-pre-wrap leading-relaxed",
                        m.role === "user"
                          ? "bg-primary text-primary-foreground rounded-2xl rounded-br-sm px-3 py-2"
                          : "text-foreground",
                      )}
                    >
                      {text || (status === "streaming" && m.role === "assistant" ? "…" : "")}
                    </div>
                  </div>
                );
              })}
              {status === "submitted" && (
                <div className="text-xs text-muted-foreground italic">Gondolkodik…</div>
              )}
              {error && (
                <div className="text-xs text-destructive">{error.message}</div>
              )}
            </div>
          </ScrollArea>

          <div className="border-t border-border p-3 space-y-2 bg-background">
            <Textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  void handleSend();
                }
              }}
              placeholder="Írd be a kérdésed… (Enter = küldés)"
              rows={2}
              className="resize-none text-sm"
              disabled={isBusy}
            />
            <div className="flex items-center justify-between">
              <div className="text-[10px] text-muted-foreground">
                Az asszisztens általános segítséget ad – nem jogi tanácsadás.
              </div>
              <Button size="sm" onClick={handleSend} disabled={isBusy || !input.trim()}>
                {isBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
