import { useState, type ImgHTMLAttributes } from "react";
import { buildSrcSet, imgSrc, isTransformable, pickWidthsForPreset, SIZES_PRESETS, type SizesPreset } from "@/lib/images/img-src";
import { cn } from "@/lib/utils";

type NativeImg = Omit<ImgHTMLAttributes<HTMLImageElement>, "src" | "loading" | "srcSet" | "sizes">;

export interface SmartImageProps extends NativeImg {
  src: string | null | undefined;
  alt: string;
  /** sizes preset — `card` az alapértelmezés kártyákhoz/listákhoz. */
  sizesPreset?: SizesPreset;
  /** Explicit sizes attribútum, felülírja a preset-et. */
  sizes?: string;
  /** LCP kép: eager + fetchpriority=high. */
  priority?: boolean;
  /** Explicit szélesség hint (px) a fő src-hez. */
  width?: number;
  /** Rögzített aspect ratio wrapper (pl. "16/9"). Ha megadott, `<div>` wrapper kerül köré. */
  aspect?: string;
  /** Wrapper className, ha aspect meg van adva. */
  wrapperClassName?: string;
}

/**
 * Reszponzív, lazy-loaded képkomponens Cloud Storage transform támogatással.
 * Nem-Cloud URL-eknél a natív `<img>` viselkedést hozza, csak `loading="lazy"` +
 * `decoding="async"` marad.
 */
export function SmartImage({
  src,
  alt,
  sizesPreset = "card",
  sizes,
  priority = false,
  width,
  aspect,
  wrapperClassName,
  className,
  onError,
  ...rest
}: SmartImageProps) {
  const [failed, setFailed] = useState(false);

  if (!src) return null;

  const canTransform = isTransformable(src) && !failed;
  const widths = pickWidthsForPreset(sizesPreset);
  const finalSizes = sizes ?? SIZES_PRESETS[sizesPreset];
  const mainWidth = width ?? widths[widths.length - 1];

  const finalSrc = canTransform ? imgSrc(src, { width: mainWidth }) : src;
  const finalSrcSet = canTransform ? buildSrcSet(src, widths) : undefined;

  const img = (
    <img
      {...rest}
      src={finalSrc}
      srcSet={finalSrcSet}
      sizes={finalSrcSet ? finalSizes : undefined}
      alt={alt}
      loading={priority ? "eager" : "lazy"}
      decoding="async"
      // @ts-expect-error fetchpriority is valid HTML but not in React DOM types across versions
      fetchpriority={priority ? "high" : undefined}
      className={className}
      onError={(e) => {
        if (canTransform && !failed) {
          setFailed(true);
        }
        onError?.(e);
      }}
    />
  );

  if (!aspect) return img;

  return (
    <div className={cn("overflow-hidden bg-muted", wrapperClassName)} style={{ aspectRatio: aspect }}>
      {img}
    </div>
  );
}
