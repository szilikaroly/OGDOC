import { cn } from "@/lib/utils";

/**
 * Skeleton – soft-shimmer betöltő placeholder.
 * Linear-gradient shimmer animációval (a `shimmer` keyframe a src/styles.css-ben).
 * prefers-reduced-motion alatt visszaesik egyszerű pulse-ra.
 */
function Skeleton({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-md bg-primary/10",
        "before:absolute before:inset-0 before:-translate-x-full",
        "before:bg-[linear-gradient(90deg,transparent,color-mix(in_oklab,var(--foreground)_8%,transparent),transparent)]",
        "before:animate-[shimmer_1.6s_infinite] motion-reduce:before:hidden motion-reduce:animate-pulse",
        className,
      )}
      aria-hidden
      {...props}
    />
  );
}

export { Skeleton };

