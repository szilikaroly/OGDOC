/**
 * Újrafelhasználható lista-szintű mobil interakciók.
 *
 *  - <PullToRefreshScroll onRefresh={…}>…</PullToRefreshScroll>
 *      Egységes pull-to-refresh wrapper a usePullToRefresh hook felett,
 *      konzisztens indikátorral (RefreshCw + szöveg).
 *
 *  - <SwipeAction leftAction={…} rightAction={…}>…</SwipeAction>
 *      Vízszintes touch-swipe egy sor felett. Bal irányba húzás → "right" akció
 *      (pl. törlés), jobbra húzás → "left" akció (pl. olvasottnak jelölés).
 *      Egér / desktop: tap target gombokra esik vissza (a children körüli akciók
 *      sm:flex-en megjelennek). prefers-reduced-motion alatt animáció kikapcsol.
 */
import { useRef, useState, type ReactNode } from "react";
import { RefreshCw } from "lucide-react";
import { cn } from "@/lib/utils";
import { usePullToRefresh } from "@/hooks/use-pull-to-refresh";

export function PullToRefreshScroll({
  onRefresh,
  children,
  className,
  hint = "Húzd lejjebb a frissítéshez…",
  release = "Engedd el a frissítéshez",
}: {
  onRefresh: () => Promise<void> | void;
  children: ReactNode;
  className?: string;
  hint?: string;
  release?: string;
}) {
  const { bind, pulling, progress } = usePullToRefresh(async () => {
    await onRefresh();
  });
  return (
    <div className={cn("relative overflow-y-auto h-full", className)} {...bind}>
      {pulling && (
        <div
          aria-live="polite"
          className="absolute inset-x-0 top-0 z-10 flex items-center justify-center text-xs text-muted-foreground bg-muted/70 backdrop-blur-sm"
          style={{ height: `${Math.round(progress * 44)}px`, opacity: progress }}
        >
          <RefreshCw className={cn("size-3.5 mr-2", progress >= 1 && "animate-spin")} />
          {progress >= 1 ? release : hint}
        </div>
      )}
      {children}
    </div>
  );
}

/**
 * PullToRefreshPage — page-szintű PTR wrapper natív window-scrollhoz.
 * Nem hoz létre belső overflow konténert, így nem törik el a normál oldal-scroll.
 * A frissítés jelző fixen az oldal tetejére kerül.
 */
export function PullToRefreshPage({
  onRefresh,
  children,
  className,
  hint = "Húzd lejjebb a frissítéshez…",
  release = "Engedd el a frissítéshez",
}: {
  onRefresh: () => Promise<void> | void;
  children: ReactNode;
  className?: string;
  hint?: string;
  release?: string;
}) {
  const { bind, pulling, progress } = usePullToRefresh(async () => {
    await onRefresh();
  });
  return (
    <div className={cn("relative", className)} {...bind}>
      {pulling && (
        <div
          aria-live="polite"
          className="fixed inset-x-0 top-0 z-40 flex items-center justify-center text-xs text-muted-foreground bg-muted/80 backdrop-blur-sm pointer-events-none"
          style={{ height: `${Math.round(progress * 44)}px`, opacity: progress }}
        >
          <RefreshCw className={cn("size-3.5 mr-2", progress >= 1 && "animate-spin")} />
          {progress >= 1 ? release : hint}
        </div>
      )}
      {children}
    </div>
  );
}

type SwipeActionConfig = {
  label: string;
  icon?: ReactNode;
  onAction: () => void;
  /** Tailwind bg-* utility, alapértelmezett: bg-primary / bg-destructive */
  tone?: "primary" | "destructive" | "muted";
};

const toneClasses: Record<NonNullable<SwipeActionConfig["tone"]>, string> = {
  primary: "bg-primary text-primary-foreground",
  destructive: "bg-destructive text-destructive-foreground",
  muted: "bg-muted text-foreground",
};

export function SwipeAction({
  children,
  leftAction,
  rightAction,
  threshold = 72,
  className,
}: {
  children: ReactNode;
  leftAction?: SwipeActionConfig;
  rightAction?: SwipeActionConfig;
  threshold?: number;
  className?: string;
}) {
  const [dx, setDx] = useState(0);
  const startX = useRef<number | null>(null);
  const startY = useRef<number | null>(null);
  const locked = useRef<"x" | "y" | null>(null);

  function onTouchStart(e: React.TouchEvent) {
    startX.current = e.touches[0].clientX;
    startY.current = e.touches[0].clientY;
    locked.current = null;
  }
  function onTouchMove(e: React.TouchEvent) {
    if (startX.current == null || startY.current == null) return;
    const x = e.touches[0].clientX - startX.current;
    const y = e.touches[0].clientY - startY.current;
    if (!locked.current) {
      if (Math.abs(x) > 8 || Math.abs(y) > 8) {
        locked.current = Math.abs(x) > Math.abs(y) ? "x" : "y";
      }
    }
    if (locked.current !== "x") return;
    // korlátozzuk +- 1.5x threshold-ra
    const max = threshold * 1.5;
    let next = x;
    if (next > max) next = max;
    if (next < -max) next = -max;
    if (!leftAction && next > 0) next = 0;
    if (!rightAction && next < 0) next = 0;
    setDx(next);
  }
  function onTouchEnd() {
    if (locked.current === "x") {
      if (dx > threshold && leftAction) leftAction.onAction();
      else if (dx < -threshold && rightAction) rightAction.onAction();
    }
    startX.current = null;
    startY.current = null;
    locked.current = null;
    setDx(0);
  }

  const reducedMotion =
    typeof window !== "undefined" && window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;

  return (
    <div className={cn("relative overflow-hidden", className)}>
      {leftAction && (
        <div
          className={cn(
            "absolute inset-y-0 left-0 flex items-center px-4 gap-2 text-sm font-medium",
            toneClasses[leftAction.tone ?? "primary"],
          )}
          style={{ width: Math.max(0, dx) }}
          aria-hidden
        >
          {leftAction.icon}
          {dx > threshold * 0.6 && <span className="truncate">{leftAction.label}</span>}
        </div>
      )}
      {rightAction && (
        <div
          className={cn(
            "absolute inset-y-0 right-0 flex items-center justify-end px-4 gap-2 text-sm font-medium",
            toneClasses[rightAction.tone ?? "destructive"],
          )}
          style={{ width: Math.max(0, -dx) }}
          aria-hidden
        >
          {dx < -threshold * 0.6 && <span className="truncate">{rightAction.label}</span>}
          {rightAction.icon}
        </div>
      )}
      <div
        onTouchStart={onTouchStart}
        onTouchMove={onTouchMove}
        onTouchEnd={onTouchEnd}
        style={{
          transform: `translateX(${dx}px)`,
          transition: dx === 0 && !reducedMotion ? "transform 180ms ease-out" : undefined,
        }}
        className="bg-card relative"
      >
        {children}
      </div>
    </div>
  );
}
