/**
 * ProgressiveLoader — skeleton helyett szakaszos, animált progress-jelző.
 * Fake, de kalibrált előrehaladás: gyors indulás, lassuló közelítés 90%-ig,
 * majd a `done` állapotra ugrik 100%-ra. Rövid szöveges státusszal jelzi,
 * hol tart a betöltés — mobilon jobb élményt ad, mint a statikus skeleton.
 */
import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";
import { Loader2 } from "lucide-react";

type Props = {
  done?: boolean;
  label?: string;
  stages?: string[];
  className?: string;
};

export function ProgressiveLoader({
  done = false,
  label,
  stages = ["Kapcsolódás…", "Adatok lekérése…", "Rendezés és csoportosítás…", "Majdnem kész…"],
  className,
}: Props) {
  const [pct, setPct] = useState(4);
  const [stageIdx, setStageIdx] = useState(0);

  useEffect(() => {
    if (done) {
      setPct(100);
      return;
    }
    let raf = 0;
    let start = performance.now();
    const step = (t: number) => {
      const elapsed = t - start;
      // Aszimptotikusan közelít 90%-hoz ~2s alatt.
      const next = Math.min(90, 4 + 86 * (1 - Math.exp(-elapsed / 900)));
      setPct(next);
      setStageIdx(Math.min(stages.length - 1, Math.floor(elapsed / 500)));
      raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [done, stages.length]);

  return (
    <div
      className={cn("space-y-2", className)}
      role="status"
      aria-live="polite"
      aria-busy={!done}
    >
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <Loader2 className={cn("size-3.5", !done && "animate-spin")} />
        <span className="truncate">{label ?? stages[stageIdx]}</span>
        <span className="ml-auto tabular-nums">{Math.round(pct)}%</span>
      </div>
      <div className="h-1.5 rounded-full bg-muted overflow-hidden">
        <div
          className="h-full bg-primary transition-[width] duration-200 ease-out"
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}
