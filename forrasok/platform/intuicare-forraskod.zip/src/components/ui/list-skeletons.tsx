import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

/**
 * Egységes vázlat-komponensek lista- és kártya-nézetekhez.
 * Használat:
 *   {isLoading ? <ListSkeleton rows={5} /> : <RealList />}
 */

export function ListSkeleton({ rows = 5, className }: { rows?: number; className?: string }) {
  return (
    <div className={cn("space-y-2", className)} aria-busy="true" aria-live="polite">
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="flex items-center gap-3 p-3 rounded-md border border-border bg-card">
          <Skeleton className="size-10 rounded-full shrink-0" />
          <div className="flex-1 min-w-0 space-y-2">
            <Skeleton className="h-3.5 w-2/3" />
            <Skeleton className="h-3 w-1/3" />
          </div>
          <Skeleton className="h-6 w-16 rounded-md shrink-0 hidden sm:block" />
        </div>
      ))}
    </div>
  );
}

export function CardGridSkeleton({ cards = 6, className }: { cards?: number; className?: string }) {
  return (
    <div
      className={cn("grid gap-3 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3", className)}
      aria-busy="true"
      aria-live="polite"
    >
      {Array.from({ length: cards }).map((_, i) => (
        <div key={i} className="p-4 rounded-lg border border-border bg-card space-y-3">
          <Skeleton className="h-4 w-1/2" />
          <Skeleton className="h-3 w-full" />
          <Skeleton className="h-3 w-4/5" />
          <Skeleton className="h-8 w-24 mt-2" />
        </div>
      ))}
    </div>
  );
}

export function TableSkeleton({ rows = 6, cols = 4, className }: { rows?: number; cols?: number; className?: string }) {
  return (
    <div className={cn("border border-border rounded-md overflow-hidden", className)} aria-busy="true">
      <div className="grid bg-muted/40 px-3 py-2 gap-3" style={{ gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))` }}>
        {Array.from({ length: cols }).map((_, i) => (
          <Skeleton key={i} className="h-3" />
        ))}
      </div>
      <div className="divide-y divide-border">
        {Array.from({ length: rows }).map((_, r) => (
          <div key={r} className="grid px-3 py-3 gap-3" style={{ gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))` }}>
            {Array.from({ length: cols }).map((_, c) => (
              <Skeleton key={c} className="h-3.5" />
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}
