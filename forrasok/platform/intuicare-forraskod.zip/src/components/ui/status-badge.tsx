import { cn } from "@/lib/utils";
import type { ReactNode } from "react";

export type StatusTone = "ok" | "warn" | "bad" | "info" | "neutral";

const TONE_CLASSES: Record<StatusTone, string> = {
  ok: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400",
  warn: "bg-amber-500/15 text-amber-700 dark:text-amber-400",
  bad: "bg-destructive/15 text-destructive dark:text-red-400",
  info: "bg-primary/15 text-primary",
  neutral: "bg-muted text-muted-foreground",
};

type Props = {
  tone: StatusTone;
  children: ReactNode;
  className?: string;
  size?: "xs" | "sm";
  pill?: boolean;
  icon?: ReactNode;
};

/**
 * Egységesített, dark-mode-kompatibilis és WCAG-konform státusz-badge.
 * Tone-okhoz semantic tokeneket használ, nem kemény-kódolt színeket.
 */
export function StatusBadge({ tone, children, className, size = "xs", pill = false, icon }: Props) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 font-medium",
        size === "xs" ? "text-[11px] px-1.5 py-0.5" : "text-xs px-2 py-1",
        pill ? "rounded-full" : "rounded",
        TONE_CLASSES[tone],
        className,
      )}
    >
      {icon}
      {children}
    </span>
  );
}
