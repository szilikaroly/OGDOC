/**
 * Egységes üres-állapot komponens lista oldalakhoz.
 *
 * Konzisztens vizuál: ikon kör, cím, leírás, opcionális CTA.
 * Mobil-first: tap target ≥44px, középre igazítva.
 *
 * Használat:
 *   <EmptyState
 *     icon={Bell}
 *     title="Nincs új értesítés"
 *     description="Itt jelennek meg az új események."
 *     action={{ label: "Beállítások", to: "/portal/profil" }}
 *   />
 */
import { Link } from "@tanstack/react-router";
import type { LucideIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

type Action =
  | { label: string; to: string; onClick?: never }
  | { label: string; onClick: () => void; to?: never };

export function EmptyState({
  icon: Icon,
  title,
  description,
  action,
  className,
}: {
  icon?: LucideIcon;
  title: string;
  description?: string;
  action?: Action;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex flex-col items-center justify-center text-center px-4 py-10 sm:py-16",
        className,
      )}
      aria-live="polite"
    >
      {Icon && (
        <div className="mb-4 grid h-14 w-14 place-items-center rounded-full bg-primary/10 text-primary">
          <Icon className="h-7 w-7" />
        </div>
      )}
      <h3 className="text-base sm:text-lg font-semibold">{title}</h3>
      {description && (
        <p className="mt-1 text-sm text-muted-foreground max-w-sm">{description}</p>
      )}
      {action && (
        <div className="mt-5">
          {"to" in action && action.to ? (
            <Button asChild className="min-h-11">
              <Link to={action.to}>{action.label}</Link>
            </Button>
          ) : (
            <Button className="min-h-11" onClick={action.onClick}>
              {action.label}
            </Button>
          )}
        </div>
      )}
    </div>
  );
}
