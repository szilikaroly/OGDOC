/* eslint-disable @typescript-eslint/no-explicit-any */
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import {
  Archive, ArchiveRestore, Download, FileSpreadsheet, Loader2, Trash2, Upload, X,
  AlertTriangle, CheckCircle2, Sparkles, UserPlus,
} from "lucide-react";
import { NewMemberDialog } from "@/components/csapat/team-admin-dialogs";
import {
  downloadImportTemplate,
  dryRunImport,
  commitImport,
  archiveTeamMember,
  restoreTeamMember,
  hardDeleteTeamMember,
  listArchivedTeam,
  previewLeave,
} from "@/lib/csapat/csapat.functions";

function b64ToBlob(b64: string, mime: string): Blob {
  const bin = atob(b64);
  const arr = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
  return new Blob([arr], { type: mime });
}
async function fileToB64(file: File): Promise<string> {
  const buf = new Uint8Array(await file.arrayBuffer());
  let bin = "";
  for (let i = 0; i < buf.length; i++) bin += String.fromCharCode(buf[i]);
  return btoa(bin);
}

// =========================================================
// Header bar with the three management buttons
// =========================================================

export function TeamManagementToolbar({
  isAdmin, onChanged,
}: { isAdmin: boolean; onChanged: () => void }) {
  const [importOpen, setImportOpen] = useState(false);
  const [archiveOpen, setArchiveOpen] = useState(false);
  const [newOpen, setNewOpen] = useState(false);
  const dlTemplate = useServerFn(downloadImportTemplate);
  const [busy, setBusy] = useState(false);

  const handleTemplate = async () => {
    setBusy(true);
    try {
      const { filename, base64 } = await dlTemplate();
      const url = URL.createObjectURL(b64ToBlob(base64, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"));
      const a = document.createElement("a");
      a.href = url; a.download = filename; a.click();
      URL.revokeObjectURL(url);
    } catch (e: any) { toast.error(e?.message ?? "Hiba"); }
    finally { setBusy(false); }
  };

  return (
    <>
      <div className="inline-flex items-center gap-2 flex-wrap">
        <button onClick={() => setNewOpen(true)}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-md bg-primary text-primary-foreground hover:bg-primary/90"
          aria-label="Új csapattag hozzáadása">
          <UserPlus className="h-3.5 w-3.5" /> Új tag
        </button>
        <button onClick={handleTemplate} disabled={busy}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-md border border-border bg-card hover:bg-accent disabled:opacity-50">
          {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Download className="h-3.5 w-3.5" />}
          Excel sablon
        </button>
        <button onClick={() => setImportOpen(true)}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-md border border-border bg-card hover:bg-accent">
          <Upload className="h-3.5 w-3.5" /> Import
        </button>
        <button onClick={() => setArchiveOpen(true)}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-md border border-border bg-card hover:bg-accent">
          <Archive className="h-3.5 w-3.5" /> Archivált csapattagok
        </button>
      </div>
      {newOpen && (
        <NewMemberDialog onClose={() => setNewOpen(false)} onCreated={onChanged} />
      )}
      {importOpen && (
        <ImportDialog onClose={() => { setImportOpen(false); onChanged(); }} />
      )}
      {archiveOpen && (
        <ArchivedDialog isAdmin={isAdmin} onClose={() => { setArchiveOpen(false); onChanged(); }} />
      )}
    </>
  );
}

// =========================================================
// Import dialog: file → dry-run preview → commit
// =========================================================

type DryRunResult = Awaited<ReturnType<ReturnType<typeof useServerFn<typeof dryRunImport>>>>;

function ImportDialog({ onClose }: { onClose: () => void }) {
  const dry = useServerFn(dryRunImport);
  const commit = useServerFn(commitImport);
  const [file, setFile] = useState<File | null>(null);
  const [base64, setBase64] = useState<string | null>(null);
  const [result, setResult] = useState<DryRunResult | null>(null);
  const [busy, setBusy] = useState(false);
  const [skipSet, setSkipSet] = useState<Set<number>>(new Set());
  const [commitResult, setCommitResult] = useState<{ inserted: number; updated: number; skipped: number; errors: number; errorDetails: Array<{ row: number; email: string | null; error: string }> } | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);

  const choose = async (f: File) => {
    setFile(f);
    setResult(null);
    setCommitResult(null);
    setSkipSet(new Set());
    setBusy(true);
    try {
      const b = await fileToB64(f);
      setBase64(b);
      const r = await dry({ data: { fileBase64: b } });
      setResult(r);
    } catch (e: any) {
      toast.error(e?.message ?? "Hiba az olvasáskor");
    } finally { setBusy(false); }
  };

  const toggleSkip = (i: number) => setSkipSet((s) => {
    const n = new Set(s); if (n.has(i)) n.delete(i); else n.add(i); return n;
  });

  const doCommit = async () => {
    if (!base64) return;
    setBusy(true);
    try {
      const r = await commit({ data: { fileBase64: base64, fileName: file?.name ?? undefined, skipRowIndexes: [...skipSet] } });
      setCommitResult(r);
      if (r.errors === 0) toast.success(`Import kész: ${r.inserted} új, ${r.updated} frissítve`);
      else toast.warning(`Import részben sikerült: ${r.errors} hiba`);
    } catch (e: any) { toast.error(e?.message ?? "Hiba"); }
    finally { setBusy(false); }
  };

  return (
    <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm flex items-start justify-center overflow-auto p-4">
      <div className="bg-card border border-border rounded-xl w-full max-w-5xl shadow-xl">
        <header className="p-4 border-b border-border flex items-center gap-2">
          <FileSpreadsheet className="h-5 w-5 text-primary" />
          <h2 className="font-semibold">Csapat import — Excel</h2>
          <button onClick={onClose} className="ml-auto p-1.5 rounded hover:bg-accent"><X className="h-4 w-4" /></button>
        </header>
        <div className="p-4 space-y-4">
          {!result && !commitResult && (
            <div
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => { e.preventDefault(); const f = e.dataTransfer.files?.[0]; if (f) void choose(f); }}
              className="border-2 border-dashed border-border rounded-xl p-8 text-center"
            >
              <Upload className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
              <div className="text-sm">Húzd ide az <b>.xlsx</b> fájlt vagy</div>
              <button onClick={() => inputRef.current?.click()}
                className="mt-3 inline-flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-md border border-border hover:bg-accent">
                Tallózás
              </button>
              <input ref={inputRef} type="file" accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" hidden
                onChange={(e) => { const f = e.target.files?.[0]; if (f) void choose(f); }} />
              <div className="mt-3 text-xs text-muted-foreground">A sablon fejlécei az „Excel sablon" gombbal letölthetők.</div>
            </div>
          )}

          {busy && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> Feldolgozás…</div>
          )}

          {result && !commitResult && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-sm">
                <Pill label="Összes" value={result.summary.total} />
                <Pill label="Új" value={result.summary.new} tone="emerald" />
                <Pill label="Frissítés" value={result.summary.update} tone="sky" />
                <Pill label="Változatlan" value={result.summary.unchanged} tone="muted" />
                <Pill label="Hiba" value={result.summary.errors} tone="rose" />
              </div>

              <div className="overflow-auto max-h-[55vh] border border-border rounded-lg">
                <table className="w-full text-xs">
                  <thead className="bg-muted/50 sticky top-0">
                    <tr className="text-left">
                      <th className="p-2 w-10">#</th>
                      <th className="p-2">Email</th>
                      <th className="p-2">Név</th>
                      <th className="p-2">Státusz</th>
                      <th className="p-2">Szabadság (nap)</th>
                      <th className="p-2">Figyelmeztetés / hiba</th>
                      <th className="p-2 w-20">Kihagy</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {result.rows.map((row) => {
                      const skipped = skipSet.has(row.rowIndex);
                      if (row.status === "error") {
                        return (
                          <tr key={row.rowIndex} className="bg-rose-500/5">
                            <td className="p-2 font-mono">{row.rowIndex}</td>
                            <td className="p-2">{row.email ?? "—"}</td>
                            <td className="p-2 text-muted-foreground">—</td>
                            <td className="p-2"><span className="px-1.5 py-0.5 rounded text-[10px] bg-rose-500/15 text-rose-700">HIBA</span></td>
                            <td className="p-2">—</td>
                            <td className="p-2 text-rose-700 dark:text-rose-300">{row.errors.join(" · ")}</td>
                            <td className="p-2"><span className="text-muted-foreground">auto</span></td>
                          </tr>
                        );
                      }
                      const toneCls =
                        row.status === "new" ? "bg-emerald-500/5" :
                        row.status === "update" ? "bg-sky-500/5" : "bg-amber-500/5";
                      const badge =
                        row.status === "new" ? "bg-emerald-500/15 text-emerald-700" :
                        row.status === "update" ? "bg-sky-500/15 text-sky-700" : "bg-amber-500/15 text-amber-700";
                      return (
                        <tr key={row.rowIndex} className={(skipped ? "opacity-40 line-through " : "") + toneCls}>
                          <td className="p-2 font-mono">{row.rowIndex}</td>
                          <td className="p-2">{row.email}</td>
                          <td className="p-2">{row.parsed.teljes_nev}</td>
                          <td className="p-2"><span className={"px-1.5 py-0.5 rounded text-[10px] " + badge}>{row.status}</span></td>
                          <td className="p-2 font-mono" title={`alap ${row.leaveBreakdown.base} + életkor ${row.leaveBreakdown.ageBonus} + gyerek ${row.leaveBreakdown.childBonus} + fogyatékos ${row.leaveBreakdown.disabledBonus}`}>
                            {row.leaveDays}
                          </td>
                          <td className="p-2 text-amber-700 dark:text-amber-300">{row.warnings.join(" · ") || "—"}</td>
                          <td className="p-2">
                            <input type="checkbox" checked={skipped} onChange={() => toggleSkip(row.rowIndex)} className="h-4 w-4" />
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {commitResult && (
            <div className="rounded-xl border border-border p-4 space-y-2">
              <div className="flex items-center gap-2 font-semibold">
                <CheckCircle2 className="h-5 w-5 text-emerald-600" /> Import lefutott
              </div>
              <div className="grid grid-cols-4 gap-2 text-sm">
                <Pill label="Új" value={commitResult.inserted} tone="emerald" />
                <Pill label="Frissítve" value={commitResult.updated} tone="sky" />
                <Pill label="Kihagyva" value={commitResult.skipped} tone="muted" />
                <Pill label="Hiba" value={commitResult.errors} tone={commitResult.errors ? "rose" : "muted"} />
              </div>
              {commitResult.errorDetails.length > 0 && (
                <details className="text-xs">
                  <summary className="cursor-pointer text-rose-700">Hibák részletei</summary>
                  <ul className="mt-2 space-y-1">
                    {commitResult.errorDetails.map((e, i) => (
                      <li key={i} className="font-mono">#{e.row} · {e.email ?? ""} · {e.error}</li>
                    ))}
                  </ul>
                </details>
              )}
            </div>
          )}
        </div>
        <footer className="p-3 border-t border-border flex justify-end gap-2">
          <button onClick={onClose} className="text-sm px-3 py-1.5 rounded-md border border-border hover:bg-accent">Bezár</button>
          {result && !commitResult && (
            <button onClick={doCommit} disabled={busy} className="text-sm px-3 py-1.5 rounded-md bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50 inline-flex items-center gap-1.5">
              {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Sparkles className="h-3.5 w-3.5" />}
              Import indítása ({result.summary.total - skipSet.size - result.summary.errors})
            </button>
          )}
        </footer>
      </div>
    </div>
  );
}

function Pill({ label, value, tone = "default" }: { label: string; value: number; tone?: "default" | "emerald" | "sky" | "rose" | "muted" }) {
  const map: Record<string, string> = {
    default: "bg-card border-border",
    emerald: "bg-emerald-500/10 border-emerald-500/30 text-emerald-700",
    sky: "bg-sky-500/10 border-sky-500/30 text-sky-700",
    rose: "bg-rose-500/10 border-rose-500/30 text-rose-700",
    muted: "bg-muted/50 border-border text-muted-foreground",
  };
  return (
    <div className={"rounded-lg border px-3 py-2 " + map[tone]}>
      <div className="text-[10px] uppercase tracking-wide opacity-80">{label}</div>
      <div className="text-xl font-mono font-semibold">{value}</div>
    </div>
  );
}

// =========================================================
// Archived tab dialog
// =========================================================

type Archived = Awaited<ReturnType<ReturnType<typeof useServerFn<typeof listArchivedTeam>>>>;

function ArchivedDialog({ isAdmin, onClose }: { isAdmin: boolean; onClose: () => void }) {
  const list = useServerFn(listArchivedTeam);
  const restore = useServerFn(restoreTeamMember);
  const hardDel = useServerFn(hardDeleteTeamMember);
  const [rows, setRows] = useState<Archived>([]);
  const [loading, setLoading] = useState(true);
  const [pending, setPending] = useState<string | null>(null);
  const [deleteFor, setDeleteFor] = useState<{ id: string; name: string } | null>(null);

  const refresh = useCallback(async () => {
    setLoading(true);
    try { setRows(await list()); } finally { setLoading(false); }
  }, [list]);
  useEffect(() => { void refresh(); }, [refresh]);

  const onRestore = async (id: string) => {
    setPending(id);
    try { await restore({ data: { userId: id } }); toast.success("Visszaaktiválva"); await refresh(); }
    catch (e: any) { toast.error(e?.message ?? "Hiba"); }
    finally { setPending(null); }
  };

  return (
    <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm flex items-start justify-center overflow-auto p-4">
      <div className="bg-card border border-border rounded-xl w-full max-w-3xl shadow-xl">
        <header className="p-4 border-b border-border flex items-center gap-2">
          <Archive className="h-5 w-5 text-primary" />
          <h2 className="font-semibold">Archivált csapattagok</h2>
          <button onClick={onClose} className="ml-auto p-1.5 rounded hover:bg-accent"><X className="h-4 w-4" /></button>
        </header>
        <div className="p-4">
          {loading ? (
            <div className="flex items-center gap-2 text-sm text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> Betöltés…</div>
          ) : rows.length === 0 ? (
            <div className="text-sm text-muted-foreground">Nincs archivált csapattag.</div>
          ) : (
            <div className="overflow-auto border border-border rounded-lg max-h-[55vh]">
              <table className="w-full text-sm">
                <thead className="bg-muted/50 text-xs uppercase">
                  <tr className="text-left"><th className="p-2">Név</th><th className="p-2">Email</th><th className="p-2">Típus</th><th className="p-2">Archiválva</th><th className="p-2 w-48">Művelet</th></tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {rows.map((r) => (
                    <tr key={r.id}>
                      <td className="p-2">{r.teljes_nev}</td>
                      <td className="p-2 text-muted-foreground">{r.email}</td>
                      <td className="p-2">{r.foglalkozas_tipus}</td>
                      <td className="p-2 font-mono text-xs">{new Date(r.updated_at).toLocaleDateString("hu-HU")}</td>
                      <td className="p-2">
                        <div className="flex gap-1">
                          <button onClick={() => onRestore(r.id)} disabled={pending === r.id}
                            className="text-xs px-2 py-1 rounded border border-border hover:bg-accent inline-flex items-center gap-1 disabled:opacity-50">
                            {pending === r.id ? <Loader2 className="h-3 w-3 animate-spin" /> : <ArchiveRestore className="h-3 w-3" />}
                            Visszaaktivál
                          </button>
                          {isAdmin && (
                            <button onClick={() => setDeleteFor({ id: r.id, name: r.teljes_nev })}
                              className="text-xs px-2 py-1 rounded border border-rose-500/40 bg-rose-500/10 text-rose-700 hover:bg-rose-500/20 inline-flex items-center gap-1">
                              <Trash2 className="h-3 w-3" /> Végleges törlés
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
      {deleteFor && (
        <HardDeleteDialog
          name={deleteFor.name}
          onClose={() => setDeleteFor(null)}
          onConfirm={async (confirmName, reason) => {
            try {
              await hardDel({ data: { userId: deleteFor.id, confirmName, reason } });
              toast.success("Véglegesen törölve");
              setDeleteFor(null); await refresh();
            } catch (e: any) { toast.error(e?.message ?? "Hiba"); }
          }}
        />
      )}
    </div>
  );
}

function HardDeleteDialog({ name, onConfirm, onClose }: { name: string; onConfirm: (confirmName: string, reason: string) => Promise<void>; onClose: () => void }) {
  const [n, setN] = useState("");
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);
  return (
    <div className="fixed inset-0 z-[60] bg-background/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-card border border-rose-500/40 rounded-xl w-full max-w-md shadow-xl">
        <header className="p-4 border-b border-border flex items-center gap-2">
          <AlertTriangle className="h-5 w-5 text-rose-600" />
          <h3 className="font-semibold">Végleges törlés</h3>
          <button onClick={onClose} className="ml-auto p-1.5 rounded hover:bg-accent"><X className="h-4 w-4" /></button>
        </header>
        <div className="p-4 space-y-3 text-sm">
          <p>Visszavonhatatlan művelet. Az auth fiók és minden kapcsolt adat (profile, beosztások, szabadság) törlődik. Audit nyom megmarad.</p>
          <div>
            <label className="text-xs text-muted-foreground">Gépeld be a nevet a megerősítéshez: <b>{name}</b></label>
            <input value={n} onChange={(e) => setN(e.target.value)}
              className="mt-1 w-full px-2 py-1.5 rounded-md border border-border bg-background text-sm" />
          </div>
          <div>
            <label className="text-xs text-muted-foreground">Indoklás (min. 5 karakter, audit)</label>
            <textarea value={reason} onChange={(e) => setReason(e.target.value)} rows={3}
              className="mt-1 w-full px-2 py-1.5 rounded-md border border-border bg-background text-sm" />
          </div>
        </div>
        <footer className="p-3 border-t border-border flex justify-end gap-2">
          <button onClick={onClose} className="text-sm px-3 py-1.5 rounded-md border border-border hover:bg-accent">Mégse</button>
          <button
            disabled={busy || n.trim() !== name.trim() || reason.trim().length < 5}
            onClick={async () => { setBusy(true); try { await onConfirm(n, reason); } finally { setBusy(false); } }}
            className="text-sm px-3 py-1.5 rounded-md bg-rose-600 text-white hover:bg-rose-700 disabled:opacity-50 inline-flex items-center gap-1.5">
            {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Trash2 className="h-3.5 w-3.5" />}
            Végleges törlés
          </button>
        </footer>
      </div>
    </div>
  );
}

// =========================================================
// Per-row archive action (used in the table)
// =========================================================

export function RowArchiveAction({ userId, name, onChanged }: { userId: string; name: string; onChanged: () => void }) {
  const archive = useServerFn(archiveTeamMember);
  const preview = useServerFn(previewLeave);
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [lv, setLv] = useState<Awaited<ReturnType<typeof preview>> | null>(null);

  const onArchive = async () => {
    if (!confirm(`Archiválod: ${name}?`)) return;
    setBusy(true);
    try { await archive({ data: { userId } }); toast.success("Archiválva"); onChanged(); }
    catch (e: any) { toast.error(e?.message ?? "Hiba"); }
    finally { setBusy(false); }
  };
  const onPreview = async () => {
    setBusy(true); setOpen(true);
    try { setLv(await preview({ data: { userId } })); }
    catch (e: any) { toast.error(e?.message ?? "Hiba"); }
    finally { setBusy(false); }
  };
  return (
    <>
      <div className="inline-flex items-center gap-1">
        <button onClick={onPreview} className="text-[11px] px-1.5 py-0.5 rounded border border-border hover:bg-accent">
          Szabadság
        </button>
        <button onClick={onArchive} disabled={busy} className="text-[11px] px-1.5 py-0.5 rounded border border-border hover:bg-accent inline-flex items-center gap-1 disabled:opacity-50">
          {busy ? <Loader2 className="h-3 w-3 animate-spin" /> : <Archive className="h-3 w-3" />} Archivál
        </button>
      </div>
      {open && (
        <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-card border border-border rounded-xl w-full max-w-md shadow-xl">
            <header className="p-3 border-b border-border flex items-center gap-2">
              <h3 className="font-semibold text-sm">Szabadság előnézet — {name}</h3>
              <button onClick={() => setOpen(false)} className="ml-auto p-1.5 rounded hover:bg-accent"><X className="h-4 w-4" /></button>
            </header>
            <div className="p-4 text-sm space-y-2">
              {!lv ? (
                <div className="flex items-center gap-2 text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> Számolás…</div>
              ) : (
                <>
                  <div className="text-lg font-mono">{lv.total} nap <span className="text-xs text-muted-foreground">({lv.year})</span></div>
                  <ul className="text-xs space-y-0.5 text-muted-foreground">
                    <li>Alap: {lv.base}</li>
                    <li>Életkor-pótlék (Mt. 117): {lv.ageBonus}{lv.ageAtStichtag != null ? ` · ${lv.ageAtStichtag} év` : ""}</li>
                    <li>Gyerek-pótlék (Mt. 118): {lv.childBonus} · {lv.eligibleChildren} jogosító gyermek</li>
                    <li>Fogyatékos gyerek-pótlék: {lv.disabledBonus}</li>
                  </ul>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
