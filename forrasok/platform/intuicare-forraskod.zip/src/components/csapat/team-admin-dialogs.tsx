/* eslint-disable @typescript-eslint/no-explicit-any */
import { useEffect, useMemo, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import {
  Loader2, X, UserPlus, Mail, KeyRound, ShieldCheck, Building2, MapPin,
  Archive, ArchiveRestore, AlertTriangle, Copy, Check,
} from "lucide-react";
import {
  listTeamOptions,
  inviteTeamMember,
  createTeamMember,
  bulkAssignRoles,
  bulkAssignSite,
  bulkAssignOrgUnit,
  bulkArchive,
  bulkRestore,
} from "@/lib/csapat/team-admin.functions";

type Options = Awaited<ReturnType<ReturnType<typeof useServerFn<typeof listTeamOptions>>>>;

function useOptions(open: boolean): { options: Options | null; loading: boolean } {
  const list = useServerFn(listTeamOptions);
  const [options, setOptions] = useState<Options | null>(null);
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    if (!open || options) return;
    setLoading(true);
    list()
      .then(setOptions)
      .catch((e: any) => toast.error(e?.message ?? "Hiba"))
      .finally(() => setLoading(false));
  }, [open, options, list]);
  return { options, loading };
}

function Modal({ title, icon: Icon, onClose, children, footer, wide = false }: {
  title: string; icon: any; onClose: () => void; children: React.ReactNode; footer?: React.ReactNode; wide?: boolean;
}) {
  return (
    <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm flex items-start justify-center overflow-auto p-4"
      role="dialog" aria-modal="true" aria-label={title}>
      <div className={"bg-card border border-border rounded-xl w-full shadow-xl " + (wide ? "max-w-3xl" : "max-w-xl")}>
        <header className="p-4 border-b border-border flex items-center gap-2">
          <Icon className="h-5 w-5 text-primary" />
          <h2 className="font-semibold">{title}</h2>
          <button onClick={onClose} aria-label="Bezárás" className="ml-auto p-1.5 rounded hover:bg-accent"><X className="h-4 w-4" /></button>
        </header>
        <div className="p-4 space-y-4">{children}</div>
        {footer && <footer className="p-3 border-t border-border flex justify-end gap-2">{footer}</footer>}
      </div>
    </div>
  );
}

// =========================================================
// New member dialog (invite | direct create)
// =========================================================

export function NewMemberDialog({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const { options, loading: optLoading } = useOptions(true);
  const invite = useServerFn(inviteTeamMember);
  const create = useServerFn(createTeamMember);
  const [mode, setMode] = useState<"invite" | "create">("invite");
  const [email, setEmail] = useState("");
  const [nev, setNev] = useState("");
  const [tipus, setTipus] = useState<"orvos" | "szakdolgozo" | "egyeb">("orvos");
  const [roleKeys, setRoleKeys] = useState<string[]>([]);
  const [siteId, setSiteId] = useState<string>("");
  const [orgUnitId, setOrgUnitId] = useState<string>("");
  const [busy, setBusy] = useState(false);
  const [resultPw, setResultPw] = useState<{ email: string; password: string } | null>(null);
  const [copied, setCopied] = useState(false);

  const filteredOrgs = useMemo(
    () => (options?.orgUnits ?? []).filter((o) => !siteId || o.site_id === siteId),
    [options, siteId],
  );

  const submit = async () => {
    if (!email.trim() || !nev.trim()) {
      toast.error("Email és név kötelező");
      return;
    }
    setBusy(true);
    try {
      const payload = {
        email: email.trim(),
        teljes_nev: nev.trim(),
        foglalkozas_tipus: tipus,
        role_keys: roleKeys,
        site_id: siteId || null,
        org_unit_id: orgUnitId || null,
      };
      if (mode === "invite") {
        await invite({ data: payload });
        toast.success(`Meghívó elküldve: ${email}`);
        onCreated();
        onClose();
      } else {
        const r = await create({ data: { ...payload, send_password_email: false } });
        setResultPw({ email, password: r.temp_password });
        onCreated();
      }
    } catch (e: any) {
      toast.error(e?.message ?? "Hiba");
    } finally {
      setBusy(false);
    }
  };

  const copyPw = async () => {
    if (!resultPw) return;
    await navigator.clipboard.writeText(resultPw.password);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  if (resultPw) {
    return (
      <Modal title="Fiók létrehozva" icon={KeyRound} onClose={onClose}
        footer={<button onClick={onClose} className="text-sm px-3 py-1.5 rounded-md bg-primary text-primary-foreground hover:bg-primary/90">Bezár</button>}>
        <div className="space-y-3">
          <div className="rounded-lg border border-amber-500/40 bg-amber-500/10 p-3 text-sm flex items-start gap-2">
            <AlertTriangle className="h-4 w-4 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-medium text-amber-900 dark:text-amber-200">Ideiglenes jelszó — másold le most.</p>
              <p className="text-xs text-amber-800/80 dark:text-amber-200/80 mt-0.5">Ez az ablak bezárása után már nem jelenik meg újra. Add át biztonságos csatornán a felhasználónak; az első bejelentkezéskor jelszót cserél.</p>
            </div>
          </div>
          <div className="text-sm">
            <div className="text-muted-foreground">Email</div>
            <div className="font-mono">{resultPw.email}</div>
          </div>
          <div className="text-sm">
            <div className="text-muted-foreground">Ideiglenes jelszó</div>
            <div className="flex items-center gap-2">
              <code className="flex-1 px-2 py-1.5 rounded border border-border bg-muted/30 font-mono text-sm break-all">{resultPw.password}</code>
              <button onClick={copyPw} className="inline-flex items-center gap-1 px-2 py-1.5 rounded-md border border-border hover:bg-accent text-xs">
                {copied ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                {copied ? "Másolva" : "Másol"}
              </button>
            </div>
          </div>
        </div>
      </Modal>
    );
  }

  return (
    <Modal title="Új csapattag" icon={UserPlus} onClose={onClose} wide
      footer={
        <>
          <button onClick={onClose} className="text-sm px-3 py-1.5 rounded-md border border-border hover:bg-accent">Mégse</button>
          <button onClick={submit} disabled={busy || optLoading}
            className="text-sm px-3 py-1.5 rounded-md bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50 inline-flex items-center gap-1.5">
            {busy && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
            {mode === "invite" ? "Meghívó küldése" : "Fiók létrehozása"}
          </button>
        </>
      }>
      <div className="flex gap-1 border-b border-border">
        {(["invite", "create"] as const).map((m) => {
          const Icon = m === "invite" ? Mail : KeyRound;
          return (
            <button key={m} type="button" onClick={() => setMode(m)}
              className={"inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium border-b-2 -mb-px " +
                (mode === m ? "border-primary text-foreground" : "border-transparent text-muted-foreground hover:text-foreground")}>
              <Icon className="h-3.5 w-3.5" />
              {m === "invite" ? "Meghívó email" : "Közvetlen létrehozás"}
            </button>
          );
        })}
      </div>

      <p className="text-xs text-muted-foreground">
        {mode === "invite"
          ? "A felhasználó email-ben kap egy meghívó linket. A regisztráció után automatikusan a tenant tagja lesz a kiválasztott szerepkörökkel."
          : "Azonnal létrejön a fiók egy ideiglenes jelszóval, amit az ablakban kapsz meg. A felhasználónak első bejelentkezéskor jelszót kell cserélnie."}
      </p>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <label className="text-sm space-y-1">
          <span className="text-muted-foreground">Email *</span>
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)}
            className="w-full px-2 py-1.5 rounded-md border border-border bg-background" required aria-required="true" />
        </label>
        <label className="text-sm space-y-1">
          <span className="text-muted-foreground">Teljes név *</span>
          <input type="text" value={nev} onChange={(e) => setNev(e.target.value)}
            className="w-full px-2 py-1.5 rounded-md border border-border bg-background" required aria-required="true" />
        </label>
        <label className="text-sm space-y-1">
          <span className="text-muted-foreground">Foglalkozás típus</span>
          <select value={tipus} onChange={(e) => setTipus(e.target.value as typeof tipus)}
            className="w-full px-2 py-1.5 rounded-md border border-border bg-background">
            <option value="orvos">Orvos</option>
            <option value="szakdolgozo">Szakdolgozó</option>
            <option value="egyeb">Egyéb</option>
          </select>
        </label>
        <label className="text-sm space-y-1">
          <span className="text-muted-foreground">Telephely</span>
          <select value={siteId} onChange={(e) => { setSiteId(e.target.value); setOrgUnitId(""); }}
            className="w-full px-2 py-1.5 rounded-md border border-border bg-background">
            <option value="">— Nincs —</option>
            {(options?.sites ?? []).map((s) => <option key={s.id} value={s.id}>{s.nev}</option>)}
          </select>
        </label>
        <label className="text-sm space-y-1 sm:col-span-2">
          <span className="text-muted-foreground">Szervezeti egység</span>
          <select value={orgUnitId} onChange={(e) => setOrgUnitId(e.target.value)}
            className="w-full px-2 py-1.5 rounded-md border border-border bg-background">
            <option value="">— Nincs —</option>
            {filteredOrgs.map((o) => <option key={o.id} value={o.id}>{o.nev}</option>)}
          </select>
        </label>
      </div>

      <fieldset className="space-y-2">
        <legend className="text-sm text-muted-foreground">Szerepkörök</legend>
        <div className="flex flex-wrap gap-1.5 max-h-44 overflow-auto p-2 rounded-md border border-border bg-muted/20">
          {optLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : (options?.roles ?? []).map((r) => {
            const on = roleKeys.includes(r.kulcs);
            return (
              <button key={r.id} type="button"
                onClick={() => setRoleKeys((rs) => on ? rs.filter((k) => k !== r.kulcs) : [...rs, r.kulcs])}
                aria-pressed={on}
                className={"inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs border " +
                  (on ? "bg-primary text-primary-foreground border-primary" : "border-border bg-card hover:bg-accent")}>
                {r.megnevezes}
              </button>
            );
          })}
        </div>
      </fieldset>
    </Modal>
  );
}

// =========================================================
// Bulk actions bar (floating)
// =========================================================

export function BulkActionsBar({ selectedIds, onClear, onChanged }: {
  selectedIds: string[]; onClear: () => void; onChanged: () => void;
}) {
  const [dlg, setDlg] = useState<"roles" | "site" | "org" | "archive" | "restore" | null>(null);
  if (selectedIds.length === 0) return null;
  return (
    <>
      <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-40 bg-card border border-border rounded-full shadow-lg px-3 py-2 flex items-center gap-1.5"
        role="region" aria-label="Csoportos műveletek">
        <span className="text-sm font-medium px-2"><strong>{selectedIds.length}</strong> kijelölve</span>
        <div className="w-px h-5 bg-border" />
        <BulkBtn icon={ShieldCheck} label="Szerepkör" onClick={() => setDlg("roles")} />
        <BulkBtn icon={MapPin} label="Telephely" onClick={() => setDlg("site")} />
        <BulkBtn icon={Building2} label="Szervezet" onClick={() => setDlg("org")} />
        <BulkBtn icon={Archive} label="Archivál" onClick={() => setDlg("archive")} tone="danger" />
        <BulkBtn icon={ArchiveRestore} label="Visszaaktivál" onClick={() => setDlg("restore")} />
        <div className="w-px h-5 bg-border" />
        <button onClick={onClear} aria-label="Kijelölés törlése"
          className="p-1.5 rounded-full hover:bg-accent"><X className="h-4 w-4" /></button>
      </div>
      {dlg === "roles" && <BulkRolesDialog userIds={selectedIds} onClose={() => setDlg(null)} onDone={() => { setDlg(null); onChanged(); }} />}
      {dlg === "site" && <BulkSiteDialog userIds={selectedIds} onClose={() => setDlg(null)} onDone={() => { setDlg(null); onChanged(); }} />}
      {dlg === "org" && <BulkOrgDialog userIds={selectedIds} onClose={() => setDlg(null)} onDone={() => { setDlg(null); onChanged(); }} />}
      {dlg === "archive" && <BulkArchiveDialog userIds={selectedIds} onClose={() => setDlg(null)} onDone={() => { setDlg(null); onClear(); onChanged(); }} />}
      {dlg === "restore" && <BulkRestoreDialog userIds={selectedIds} onClose={() => setDlg(null)} onDone={() => { setDlg(null); onClear(); onChanged(); }} />}
    </>
  );
}

function BulkBtn({ icon: Icon, label, onClick, tone = "default" }: { icon: any; label: string; onClick: () => void; tone?: "default" | "danger" }) {
  const cls = tone === "danger"
    ? "text-rose-700 hover:bg-rose-500/10"
    : "hover:bg-accent";
  return (
    <button onClick={onClick}
      className={"inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium " + cls}>
      <Icon className="h-3.5 w-3.5" />
      {label}
    </button>
  );
}

// ---------------- Bulk dialogs ----------------

function BulkRolesDialog({ userIds, onClose, onDone }: { userIds: string[]; onClose: () => void; onDone: () => void }) {
  const { options, loading } = useOptions(true);
  const run = useServerFn(bulkAssignRoles);
  const [keys, setKeys] = useState<string[]>([]);
  const [action, setAction] = useState<"add" | "remove">("add");
  const [busy, setBusy] = useState(false);
  const submit = async () => {
    if (!keys.length) { toast.error("Válassz legalább egy szerepkört."); return; }
    setBusy(true);
    try {
      const r = await run({ data: { user_ids: userIds, role_keys: keys, action } });
      toast.success(`${r.users} tag · ${r.role_writes} szerepkör-művelet`);
      onDone();
    } catch (e: any) { toast.error(e?.message ?? "Hiba"); }
    finally { setBusy(false); }
  };
  return (
    <Modal title={`Szerepkör (${userIds.length} tag)`} icon={ShieldCheck} onClose={onClose} wide
      footer={<>
        <button onClick={onClose} className="text-sm px-3 py-1.5 rounded-md border border-border hover:bg-accent">Mégse</button>
        <button onClick={submit} disabled={busy} className="text-sm px-3 py-1.5 rounded-md bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50 inline-flex items-center gap-1.5">
          {busy && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
          {action === "add" ? "Hozzáadás" : "Eltávolítás"}
        </button>
      </>}>
      <fieldset className="flex gap-3 text-sm">
        <label className="inline-flex items-center gap-1.5">
          <input type="radio" name="bulkact" checked={action === "add"} onChange={() => setAction("add")} /> Hozzáadás
        </label>
        <label className="inline-flex items-center gap-1.5">
          <input type="radio" name="bulkact" checked={action === "remove"} onChange={() => setAction("remove")} /> Eltávolítás
        </label>
      </fieldset>
      <div className="flex flex-wrap gap-1.5 max-h-60 overflow-auto p-2 rounded-md border border-border bg-muted/20">
        {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : (options?.roles ?? []).map((r) => {
          const on = keys.includes(r.kulcs);
          return (
            <button key={r.id} type="button" aria-pressed={on}
              onClick={() => setKeys((ks) => on ? ks.filter((k) => k !== r.kulcs) : [...ks, r.kulcs])}
              className={"inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs border " +
                (on ? "bg-primary text-primary-foreground border-primary" : "border-border bg-card hover:bg-accent")}>
              {r.megnevezes}
            </button>
          );
        })}
      </div>
    </Modal>
  );
}

function BulkSiteDialog({ userIds, onClose, onDone }: { userIds: string[]; onClose: () => void; onDone: () => void }) {
  const { options, loading } = useOptions(true);
  const run = useServerFn(bulkAssignSite);
  const [siteId, setSiteId] = useState<string>("");
  const [busy, setBusy] = useState(false);
  const submit = async () => {
    setBusy(true);
    try {
      await run({ data: { user_ids: userIds, site_id: siteId || null } });
      toast.success(`${userIds.length} tag telephelye frissítve`);
      onDone();
    } catch (e: any) { toast.error(e?.message ?? "Hiba"); }
    finally { setBusy(false); }
  };
  return (
    <Modal title={`Telephely hozzárendelés (${userIds.length} tag)`} icon={MapPin} onClose={onClose}
      footer={<>
        <button onClick={onClose} className="text-sm px-3 py-1.5 rounded-md border border-border hover:bg-accent">Mégse</button>
        <button onClick={submit} disabled={busy} className="text-sm px-3 py-1.5 rounded-md bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50">
          Alkalmaz
        </button>
      </>}>
      <p className="text-xs text-muted-foreground">A kijelölt tagok elsődleges jogviszonyán frissül a telephely.</p>
      {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : (
        <select value={siteId} onChange={(e) => setSiteId(e.target.value)}
          className="w-full px-2 py-1.5 rounded-md border border-border bg-background text-sm">
          <option value="">— Telephely törlése —</option>
          {(options?.sites ?? []).map((s) => <option key={s.id} value={s.id}>{s.nev}</option>)}
        </select>
      )}
    </Modal>
  );
}

function BulkOrgDialog({ userIds, onClose, onDone }: { userIds: string[]; onClose: () => void; onDone: () => void }) {
  const { options, loading } = useOptions(true);
  const run = useServerFn(bulkAssignOrgUnit);
  const [orgId, setOrgId] = useState<string>("");
  const [busy, setBusy] = useState(false);
  const submit = async () => {
    setBusy(true);
    try {
      await run({ data: { user_ids: userIds, org_unit_id: orgId || null } });
      toast.success(`${userIds.length} tag szervezeti egysége frissítve`);
      onDone();
    } catch (e: any) { toast.error(e?.message ?? "Hiba"); }
    finally { setBusy(false); }
  };
  return (
    <Modal title={`Szervezeti egység (${userIds.length} tag)`} icon={Building2} onClose={onClose}
      footer={<>
        <button onClick={onClose} className="text-sm px-3 py-1.5 rounded-md border border-border hover:bg-accent">Mégse</button>
        <button onClick={submit} disabled={busy} className="text-sm px-3 py-1.5 rounded-md bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50">
          Alkalmaz
        </button>
      </>}>
      {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : (
        <select value={orgId} onChange={(e) => setOrgId(e.target.value)}
          className="w-full px-2 py-1.5 rounded-md border border-border bg-background text-sm">
          <option value="">— Szervezeti egység törlése —</option>
          {(options?.orgUnits ?? []).map((o) => <option key={o.id} value={o.id}>{o.nev}</option>)}
        </select>
      )}
    </Modal>
  );
}

function BulkArchiveDialog({ userIds, onClose, onDone }: { userIds: string[]; onClose: () => void; onDone: () => void }) {
  const run = useServerFn(bulkArchive);
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);
  const submit = async () => {
    setBusy(true);
    try {
      const r = await run({ data: { user_ids: userIds, reason: reason || undefined } });
      toast.success(`${r.archived} tag archiválva${r.skipped ? ` (${r.skipped} kihagyva)` : ""}`);
      onDone();
    } catch (e: any) { toast.error(e?.message ?? "Hiba"); }
    finally { setBusy(false); }
  };
  return (
    <Modal title={`Archiválás (${userIds.length} tag)`} icon={Archive} onClose={onClose}
      footer={<>
        <button onClick={onClose} className="text-sm px-3 py-1.5 rounded-md border border-border hover:bg-accent">Mégse</button>
        <button onClick={submit} disabled={busy}
          className="text-sm px-3 py-1.5 rounded-md bg-rose-600 text-white hover:bg-rose-700 disabled:opacity-50 inline-flex items-center gap-1.5">
          {busy && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
          Archiválás
        </button>
      </>}>
      <div className="rounded-lg border border-amber-500/40 bg-amber-500/10 p-3 text-sm">
        Az archivált tagok inaktívvá válnak, de az adataik megmaradnak. Az „Archivált csapattagok" felületen visszaaktiválhatók.
      </div>
      <label className="text-sm space-y-1 block">
        <span className="text-muted-foreground">Indoklás (opcionális)</span>
        <textarea value={reason} onChange={(e) => setReason(e.target.value.slice(0, 500))} rows={3}
          className="w-full px-2 py-1.5 rounded-md border border-border bg-background" />
      </label>
    </Modal>
  );
}

function BulkRestoreDialog({ userIds, onClose, onDone }: { userIds: string[]; onClose: () => void; onDone: () => void }) {
  const run = useServerFn(bulkRestore);
  const [busy, setBusy] = useState(false);
  const submit = async () => {
    setBusy(true);
    try {
      const r = await run({ data: { user_ids: userIds } });
      toast.success(`${r.restored} tag visszaaktiválva`);
      onDone();
    } catch (e: any) { toast.error(e?.message ?? "Hiba"); }
    finally { setBusy(false); }
  };
  return (
    <Modal title={`Visszaaktiválás (${userIds.length} tag)`} icon={ArchiveRestore} onClose={onClose}
      footer={<>
        <button onClick={onClose} className="text-sm px-3 py-1.5 rounded-md border border-border hover:bg-accent">Mégse</button>
        <button onClick={submit} disabled={busy}
          className="text-sm px-3 py-1.5 rounded-md bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50 inline-flex items-center gap-1.5">
          {busy && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
          Visszaaktivál
        </button>
      </>}>
      <p className="text-sm">A kijelölt tagok visszakerülnek aktív állapotba és a jogviszonyuk záró dátuma törlődik.</p>
    </Modal>
  );
}
