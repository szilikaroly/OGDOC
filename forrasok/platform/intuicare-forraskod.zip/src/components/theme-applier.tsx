/**
 * Globális téma-alkalmazó: a publikus `appearance.*` beállítások + a
 * `cms_design_tokens` tábla alapján CSS változókat injektál a :root-ra.
 * Nem zavarja a sötét/világos váltást — csak token-szintű felülírásokat tesz.
 */
import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useAppSettings } from "@/hooks/use-app-settings";
import { listPublicDesignTokens } from "@/lib/cms/design-tokens.functions";

function hexToHsl(hex: string): string | null {
  const m = hex.trim().match(/^#?([0-9a-f]{6})$/i);
  if (!m) return null;
  const n = parseInt(m[1], 16);
  const r = ((n >> 16) & 255) / 255;
  const g = ((n >> 8) & 255) / 255;
  const b = (n & 255) / 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  const l = (max + min) / 2;
  let h = 0, s = 0;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r: h = ((g - b) / d + (g < b ? 6 : 0)); break;
      case g: h = ((b - r) / d + 2); break;
      case b: h = ((r - g) / d + 4); break;
    }
    h *= 60;
  }
  return `${Math.round(h)} ${Math.round(s * 100)}% ${Math.round(l * 100)}%`;
}

export function ThemeApplier() {
  const { data } = useAppSettings();
  const tokensFn = useServerFn(listPublicDesignTokens);
  const { data: tokens } = useQuery({
    queryKey: ["cms-design-tokens"],
    queryFn: () => tokensFn(),
    staleTime: 5 * 60_000,
  });

  useEffect(() => {
    const root = document.documentElement;

    // 1) CMS design tokens (token_key like "brand.primary" → --brand-primary).
    if (tokens && tokens.length) {
      for (const t of tokens) {
        const cssVar = `--${String(t.token_key).replace(/[._]/g, "-")}`;
        const raw = t.value && typeof t.value === "object" && "value" in (t.value as any)
          ? (t.value as any).value
          : t.value;
        if (raw == null) continue;
        const str = typeof raw === "string" ? raw : String(raw);
        if (/^#?[0-9a-f]{6}$/i.test(str.trim())) {
          const h = hexToHsl(str.startsWith("#") ? str : `#${str}`);
          if (h) root.style.setProperty(cssVar, h);
        } else {
          root.style.setProperty(cssVar, str);
        }
      }
    }

    if (!data) return;
    const primary = data["appearance.primary_color"] as string | undefined;
    const accent = data["appearance.accent_color"] as string | undefined;
    const sidebar = data["appearance.sidebar_color"] as string | undefined;
    const radius = data["appearance.radius"] as number | undefined;

    if (typeof primary === "string") {
      const h = hexToHsl(primary);
      if (h) root.style.setProperty("--primary", h);
    }
    if (typeof accent === "string") {
      const h = hexToHsl(accent);
      if (h) root.style.setProperty("--accent", h);
    }
    if (typeof sidebar === "string") {
      const h = hexToHsl(sidebar);
      if (h) root.style.setProperty("--sidebar-background", h);
    }
    if (typeof radius === "number") {
      root.style.setProperty("--radius", `${radius}rem`);
    }

    const brand = data["general.brand_name"] as string | undefined;
    if (typeof brand === "string" && brand && !document.title.includes(brand)) {
      if (!document.title || document.title === "Vite + React + TS") {
        document.title = brand;
      }
    }
  }, [data, tokens]);

  return null;
}
