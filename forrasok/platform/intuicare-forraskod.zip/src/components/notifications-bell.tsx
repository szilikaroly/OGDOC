import { useEffect, useRef, useState } from "react";
import { Bell, Loader2, CheckCheck } from "lucide-react";
import { useNavigate } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { cn } from "@/lib/utils";

type Notification = {
  id: string;
  tipus: string;
  cim: string;
  uzenet: string | null;
  link: string | null;
  olvasott_at: string | null;
  created_at: string;
};

export function NotificationsBell() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(false);
  const wrapRef = useRef<HTMLDivElement>(null);

  const unread = items.filter((n) => !n.olvasott_at).length;

  useEffect(() => {
    function onDoc(e: MouseEvent) {
      if (!wrapRef.current?.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);

  useEffect(() => {
    if (!user) return;
    void load();
    // Realtime: új értesítés érkezése — egyedi csatornanév mountonként (StrictMode-biztos)
    const channelName = `notif-${user.id}-${Math.random().toString(36).slice(2, 10)}`;
    const ch = supabase.channel(channelName);
    ch.on(
      "postgres_changes",
      {
        event: "INSERT",
        schema: "public",
        table: "notifications",
        filter: `user_id=eq.${user.id}`,
      },
      (payload) => {
        setItems((prev) => [payload.new as Notification, ...prev].slice(0, 30));
      },
    ).subscribe();
    // Időnként újratölt (másik eszközről jelölt olvasottság)
    const iv = setInterval(() => void load(), 60_000);
    return () => {
      void supabase.removeChannel(ch);
      clearInterval(iv);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  async function load() {
    if (!user) return;
    setLoading(true);
    const { data } = await supabase
      .from("notifications")
      .select("id,tipus,cim,uzenet,link,olvasott_at,created_at")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(30);
    setItems((data ?? []) as Notification[]);
    setLoading(false);
  }

  async function markAllRead() {
    if (!user || unread === 0) return;
    const now = new Date().toISOString();
    await supabase
      .from("notifications")
      .update({ olvasott_at: now })
      .eq("user_id", user.id)
      .is("olvasott_at", null);
    setItems((prev) => prev.map((n) => (n.olvasott_at ? n : { ...n, olvasott_at: now })));
  }

  async function openItem(n: Notification) {
    if (!n.olvasott_at) {
      const now = new Date().toISOString();
      await supabase.from("notifications").update({ olvasott_at: now }).eq("id", n.id);
      setItems((prev) => prev.map((x) => (x.id === n.id ? { ...x, olvasott_at: now } : x)));
    }
    setOpen(false);
    if (n.link) navigate({ to: n.link });
  }

  if (!user) return null;

  return (
    <div ref={wrapRef} className="relative">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="relative inline-flex items-center justify-center size-9 rounded-md hover:bg-secondary transition-colors"
        aria-label="Értesítések"
      >
        <Bell className="size-4 text-muted-foreground" />
        {unread > 0 && (
          <span className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] px-1 rounded-full bg-destructive text-destructive-foreground text-[10px] font-bold flex items-center justify-center">
            {unread > 99 ? "99+" : unread}
          </span>
        )}
      </button>
      {open && (
        <div className="absolute right-0 mt-1 w-80 bg-card border border-border rounded-md shadow-lg z-50 overflow-hidden">
          <div className="flex items-center justify-between px-3 py-2 border-b border-border">
            <div className="text-xs font-bold uppercase tracking-wider">Értesítések</div>
            <button
              type="button"
              onClick={markAllRead}
              disabled={unread === 0}
              className="text-[10px] font-semibold text-muted-foreground hover:text-foreground disabled:opacity-40 inline-flex items-center gap-1"
            >
              <CheckCheck className="size-3" /> Mind olvasott
            </button>
          </div>
          <div className="max-h-96 overflow-y-auto">
            {loading ? (
              <div className="p-6 flex justify-center">
                <Loader2 className="size-4 animate-spin text-muted-foreground" />
              </div>
            ) : items.length === 0 ? (
              <div className="p-6 text-center text-xs text-muted-foreground">
                Nincs értesítés.
              </div>
            ) : (
              items.map((n) => (
                <button
                  key={n.id}
                  type="button"
                  onClick={() => openItem(n)}
                  className={cn(
                    "w-full text-left px-3 py-2 border-b border-border last:border-0 hover:bg-secondary/60 transition-colors",
                    !n.olvasott_at && "bg-primary/5",
                  )}
                >
                  <div className="flex items-start gap-2">
                    {!n.olvasott_at && (
                      <span className="mt-1.5 size-1.5 rounded-full bg-primary shrink-0" />
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-semibold truncate">{n.cim}</div>
                      {n.uzenet && (
                        <div className="text-[11px] text-muted-foreground line-clamp-2">
                          {n.uzenet}
                        </div>
                      )}
                      <div className="text-[10px] text-muted-foreground font-mono mt-0.5">
                        {new Date(n.created_at).toLocaleString("hu-HU")}
                      </div>
                    </div>
                  </div>
                </button>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
