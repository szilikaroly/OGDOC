import { useEffect, useRef, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Search, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { usePermissions } from "@/hooks/use-permissions";
import { cn } from "@/lib/utils";

type Hit = {
  id: string;
  taj: string | null;
  vezeteknev: string | null;
  keresztnev: string | null;
  szuletesi_datum: string | null;
  nem: string | null;
  fo_diagnozis_bno: string | null;
  score: number;
};

export function PatientSearch() {
  const { can } = usePermissions();
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [hits, setHits] = useState<Hit[]>([]);
  const [active, setActive] = useState(0);
  const wrapRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    function onDoc(e: MouseEvent) {
      if (!wrapRef.current?.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);

  // Globális ⌘K / Ctrl+K rövidbillentyű
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        inputRef.current?.focus();
        inputRef.current?.select();
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);


  useEffect(() => {
    const term = q.trim();
    if (term.length < 2) {
      setHits([]);
      return;
    }
    let cancelled = false;
    setLoading(true);
    const handle = setTimeout(async () => {
      const { data, error } = await supabase.rpc("search_patients", {
        _q: term,
        _limit: 8,
      });
      if (cancelled) return;
      setLoading(false);
      if (!error && data) {
        setHits(data as Hit[]);
        setActive(0);
        setOpen(true);
      }
    }, 220);
    return () => {
      cancelled = true;
      clearTimeout(handle);
    };
  }, [q]);

  if (!can("manage_patients")) return null;

  function go(id: string) {
    setOpen(false);
    setQ("");
    navigate({ to: "/paciensek", search: { id } as never });
  }

  return (
    <div ref={wrapRef} className="relative w-72">
      <div className="flex items-center gap-2 px-3 h-9 rounded-md border border-border bg-background">
        <Search className="size-3.5 text-muted-foreground shrink-0" />
        <input
          ref={inputRef}
          type="text"

          value={q}
          onChange={(e) => setQ(e.target.value)}
          onFocus={() => hits.length && setOpen(true)}
          onKeyDown={(e) => {
            if (e.key === "ArrowDown") {
              e.preventDefault();
              setActive((a) => Math.min(a + 1, hits.length - 1));
            } else if (e.key === "ArrowUp") {
              e.preventDefault();
              setActive((a) => Math.max(a - 1, 0));
            } else if (e.key === "Enter" && hits[active]) {
              e.preventDefault();
              go(hits[active].id);
            } else if (e.key === "Escape") {
              setOpen(false);
            }
          }}
          placeholder="Páciens keresés (név / TAJ)…"
          className="flex-1 bg-transparent outline-none text-xs placeholder:text-muted-foreground"
        />
        {loading ? (
          <Loader2 className="size-3.5 animate-spin text-muted-foreground" />
        ) : (
          <kbd className="hidden md:inline-flex items-center px-1.5 h-5 rounded border border-border bg-muted text-[10px] font-mono text-muted-foreground">
            ⌘K
          </kbd>
        )}
      </div>
      {open && hits.length > 0 && (
        <div className="absolute left-0 right-0 mt-1 bg-card border border-border rounded-md shadow-lg z-50 overflow-hidden">
          {hits.map((h, i) => (
            <button
              key={h.id}
              type="button"
              onMouseEnter={() => setActive(i)}
              onClick={() => go(h.id)}
              className={cn(
                "w-full text-left px-3 py-2 text-xs border-b border-border last:border-0",
                i === active ? "bg-secondary" : "hover:bg-secondary/60",
              )}
            >
              <div className="font-semibold">
                {h.vezeteknev} {h.keresztnev}
              </div>
              <div className="text-[10px] text-muted-foreground font-mono">
                {h.taj ?? "—"} · {h.szuletesi_datum ?? "—"}
                {h.fo_diagnozis_bno ? ` · ${h.fo_diagnozis_bno}` : ""}
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
