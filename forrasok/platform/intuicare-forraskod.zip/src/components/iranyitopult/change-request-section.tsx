import { useEffect, useState } from "react";
import { Ban, ArrowLeftRight, Check, X, AlertCircle, Clock } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from "@/components/ui/select";
import { toast } from "sonner";

type ChangeRequest = {
  id: string;
  request_type: "cancel" | "swap";
  status: "pending" | "approved" | "rejected" | "cancelled";
  reason: string | null;
  target_user_id: string | null;
  target_name: string | null;
  decided_by: string | null;
  decider_name: string | null;
  decided_at: string | null;
  decision_note: string | null;
  created_at: string;
  requester_id: string;
};

type EligibleTarget = {
  user_id: string;
  display_name: string;
  last_worked: string;
};

const STATUS_BADGE: Record<string, { label: string; cls: string }> = {
  pending:   { label: "Függőben",  cls: "bg-amber-100 text-amber-800 border-amber-200" },
  approved:  { label: "Jóváhagyva", cls: "bg-emerald-100 text-emerald-800 border-emerald-200" },
  rejected:  { label: "Elutasítva", cls: "bg-rose-100 text-rose-800 border-rose-200" },
  cancelled: { label: "Visszavonva", cls: "bg-muted text-muted-foreground border-border" },
};

const fmtTs = (s: string) =>
  new Intl.DateTimeFormat("hu-HU", { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }).format(new Date(s));

export function ChangeRequestSection({
  assignmentId,
  ownerUserId,
  isManager,
  feladatkorId = null,
  feladatkorNev = null,
}: {
  assignmentId: string;
  ownerUserId: string;
  isManager: boolean;
  feladatkorId?: string | null;
  feladatkorNev?: string | null;
}) {
  const { user } = useAuth();
  const isOwner = user?.id === ownerUserId;


  const [requests, setRequests] = useState<ChangeRequest[]>([]);
  const [loading, setLoading] = useState(true);

  // Cancel dialog state
  const [cancelOpen, setCancelOpen] = useState(false);
  const [cancelReason, setCancelReason] = useState("");
  const [submitting, setSubmitting] = useState(false);

  // Swap dialog state
  const [swapOpen, setSwapOpen] = useState(false);
  const [swapReason, setSwapReason] = useState("");
  const [swapTarget, setSwapTarget] = useState<string>("");
  const [eligible, setEligible] = useState<EligibleTarget[]>([]);
  const [loadingEligible, setLoadingEligible] = useState(false);

  // Decide dialog (manager)
  const [decideTarget, setDecideTarget] = useState<{ req: ChangeRequest; outcome: "approved" | "rejected" } | null>(null);
  const [decisionNote, setDecisionNote] = useState("");

  async function reload() {
    setLoading(true);
    const { data, error } = await supabase
      .from("schedule_change_requests")
      .select(`
        id, request_type, status, reason, target_user_id, decided_by, decided_at, decision_note, created_at, requester_id,
        target:profiles!schedule_change_requests_target_user_id_fkey(teljes_nev, email),
        decider:profiles!schedule_change_requests_decided_by_fkey(teljes_nev, email)
      `)
      .eq("assignment_id", assignmentId)
      .order("created_at", { ascending: false });
    if (error) {
      toast.error("Nem sikerült betölteni a kéréseket", { description: error.message });
      setRequests([]);
    } else {
      setRequests((data ?? []).map((r: any) => ({
        ...r,
        target_name: r.target?.teljes_nev || r.target?.email || null,
        decider_name: r.decider?.teljes_nev || r.decider?.email || null,
      })));
    }
    setLoading(false);
  }


  useEffect(() => {
    void reload();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [assignmentId]);

  const hasPending = requests.some(r => r.status === "pending");

  // ---------- Submit cancel ----------
  async function submitCancel() {
    if (!user) return;
    setSubmitting(true);
    const { error } = await supabase.from("schedule_change_requests").insert({
      tenant_id: (await supabase.rpc("current_tenant_id")).data,
      assignment_id: assignmentId,
      requester_id: user.id,
      request_type: "cancel",
      reason: cancelReason.trim() || null,
    } as any);
    setSubmitting(false);
    if (error) {
      toast.error("Lemondási kérés sikertelen", { description: error.message });
      return;
    }
    toast.success("Lemondási kérés elküldve", { description: "Vezetői jóváhagyásra vár." });
    setCancelOpen(false);
    setCancelReason("");
    void reload();
  }

  // ---------- Load eligible targets ----------
  async function openSwap() {
    setSwapOpen(true);
    setLoadingEligible(true);
    const { data, error } = await supabase.rpc("eligible_swap_targets", { _assignment_id: assignmentId });
    setLoadingEligible(false);
    if (error) {
      toast.error("Nem sikerült a célfelhasználók betöltése", { description: error.message });
      setEligible([]);
    } else {
      setEligible((data ?? []) as EligibleTarget[]);
    }
  }

  // ---------- Submit swap ----------
  async function submitSwap() {
    if (!user || !swapTarget) return;
    setSubmitting(true);
    const tenantRes = await supabase.rpc("current_tenant_id");
    const { error } = await supabase.from("schedule_change_requests").insert({
      tenant_id: tenantRes.data,
      assignment_id: assignmentId,
      requester_id: user.id,
      request_type: "swap",
      target_user_id: swapTarget,
      reason: swapReason.trim() || null,
    } as any);
    setSubmitting(false);
    if (error) {
      toast.error("Csere kérés sikertelen", { description: error.message });
      return;
    }
    toast.success("Cserekérés elküldve", { description: "Vezetői jóváhagyásra vár." });
    setSwapOpen(false);
    setSwapReason("");
    setSwapTarget("");
    void reload();
  }

  // ---------- Owner cancels own pending request ----------
  async function withdrawRequest(id: string) {
    const { error } = await supabase.from("schedule_change_requests")
      .update({ status: "cancelled" } as any).eq("id", id);
    if (error) {
      toast.error("Visszavonás sikertelen", { description: error.message });
      return;
    }
    toast.success("Kérés visszavonva");
    void reload();
  }

  // ---------- Manager decides ----------
  async function submitDecision() {
    if (!decideTarget) return;
    const note = decisionNote.trim();
    if (note.length < 5) {
      toast.error("Indoklás kötelező", { description: "Legalább 5 karaktert írj a döntéshez (audithoz szükséges)." });
      return;
    }
    if (note.length > 1000) {
      toast.error("Az indoklás túl hosszú", { description: "Maximum 1000 karakter." });
      return;
    }
    setSubmitting(true);
    const { error } = await supabase.from("schedule_change_requests")
      .update({
        status: decideTarget.outcome,
        decision_note: note,
      } as any)
      .eq("id", decideTarget.req.id);
    setSubmitting(false);
    if (error) {
      toast.error("Döntés mentése sikertelen", { description: error.message });
      return;
    }
    toast.success(decideTarget.outcome === "approved" ? "Kérés jóváhagyva" : "Kérés elutasítva");
    setDecideTarget(null);
    setDecisionNote("");
    void reload();
  }


  return (
    <div className="space-y-2 pt-2 border-t">
      {/* Action buttons – only owner can request changes */}
      {isOwner && (
        <div className="flex flex-wrap gap-2">
          <Button
            variant="outline"
            size="sm"
            className="h-7"
            disabled={hasPending}
            onClick={() => setCancelOpen(true)}
          >
            <Ban className="h-3 w-3 mr-1" /> Lemondás kérése
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="h-7"
            disabled={hasPending}
            onClick={openSwap}
          >
            <ArrowLeftRight className="h-3 w-3 mr-1" /> Csere kérése
          </Button>
          {hasPending && (
            <span className="text-[10px] text-muted-foreground self-center">
              Már van függőben lévő kérés.
            </span>
          )}
        </div>
      )}

      {/* History */}
      <div>
        <p className="text-[10px] uppercase text-muted-foreground mb-1">Kérelmek története</p>
        {loading ? (
          <p className="text-xs text-muted-foreground">Betöltés…</p>
        ) : requests.length === 0 ? (
          <p className="text-xs text-muted-foreground italic">Még nincs kérés.</p>
        ) : (
          <ul className="space-y-1.5">
            {requests.map(r => {
              const s = STATUS_BADGE[r.status];
              return (
                <li key={r.id} className="rounded border p-2 text-xs space-y-1 bg-muted/20">
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <div className="flex items-center gap-1.5">
                      {r.request_type === "cancel"
                        ? <Ban className="h-3 w-3 text-rose-600" />
                        : <ArrowLeftRight className="h-3 w-3 text-blue-600" />}
                      <span className="font-medium">
                        {r.request_type === "cancel" ? "Lemondás" : "Csere"}
                        {r.request_type === "swap" && r.target_name ? ` → ${r.target_name}` : ""}
                      </span>
                      <Badge variant="outline" className={s.cls}>{s.label}</Badge>
                    </div>
                    <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                      <Clock className="h-3 w-3" /> {fmtTs(r.created_at)}
                    </span>
                  </div>
                  {r.reason && (
                    <p className="text-muted-foreground"><span className="font-medium">Indok:</span> {r.reason}</p>
                  )}
                  {r.decided_at && (
                    <p className="text-muted-foreground">
                      <span className="font-medium">Döntés:</span> {fmtTs(r.decided_at)}
                      {r.decider_name ? ` – ${r.decider_name}` : ""}
                      {r.decision_note ? ` (${r.decision_note})` : ""}
                    </p>
                  )}

                  {/* Owner withdraw */}
                  {isOwner && r.status === "pending" && (
                    <Button
                      variant="ghost" size="sm" className="h-6 px-2 text-[11px]"
                      onClick={() => withdrawRequest(r.id)}
                    >
                      <X className="h-3 w-3 mr-1" /> Kérés visszavonása
                    </Button>
                  )}

                  {/* Manager decide */}
                  {isManager && r.status === "pending" && (
                    <div className="flex gap-1 pt-1">
                      <Button
                        size="sm" className="h-6 px-2 text-[11px]"
                        onClick={() => { setDecideTarget({ req: r, outcome: "approved" }); setDecisionNote(""); }}
                      >
                        <Check className="h-3 w-3 mr-1" /> Jóváhagy
                      </Button>
                      <Button
                        variant="outline" size="sm" className="h-6 px-2 text-[11px]"
                        onClick={() => { setDecideTarget({ req: r, outcome: "rejected" }); setDecisionNote(""); }}
                      >
                        <X className="h-3 w-3 mr-1" /> Elutasít
                      </Button>
                    </div>
                  )}
                </li>
              );
            })}
          </ul>
        )}
      </div>

      {/* ===== Cancel dialog ===== */}
      <Dialog open={cancelOpen} onOpenChange={(o) => !o && setCancelOpen(false)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Lemondási kérés</DialogTitle>
            <DialogDescription>
              A műszak lemondását vezető hagyja jóvá. Add meg az indokot.
            </DialogDescription>
          </DialogHeader>
          <Textarea
            value={cancelReason}
            onChange={(e) => setCancelReason(e.target.value)}
            placeholder="Pl. családi ok, betegség…"
            rows={4}
          />
          <DialogFooter>
            <Button variant="ghost" onClick={() => setCancelOpen(false)} disabled={submitting}>Mégse</Button>
            <Button onClick={submitCancel} disabled={submitting}>
              {submitting ? "Küldés…" : "Kérés elküldése"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ===== Swap dialog ===== */}
      <Dialog open={swapOpen} onOpenChange={(o) => !o && setSwapOpen(false)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Csere kérése</DialogTitle>
            <DialogDescription>
              Csak olyan kollégát választhatsz, aki az elmúlt 12 hónapban dolgozott ezzel a feladatkörrel. A csere vezetői jóváhagyás után lép életbe.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <label className="text-xs font-medium mb-1 block">Cserepartner</label>
              {loadingEligible ? (
                <p className="text-sm text-muted-foreground">Betöltés…</p>
              ) : eligible.length === 0 ? (
                <div className="flex items-start gap-2 rounded border border-amber-300 bg-amber-50 p-3 text-xs text-amber-900">
                  <AlertCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <p className="font-semibold">Nem található alkalmas cserepartner.</p>
                    {!feladatkorId ? (
                      <p>Ehhez a műszakhoz <span className="font-medium">nincs feladatkör rendelve</span>, ezért önkiszolgáló csere nem lehetséges. Kérlek egyeztess a vezetőddel.</p>
                    ) : (
                      <>
                        <p>
                          Egyetlen kollégád sem dolgozott az elmúlt 12 hónapban a következő feladatkörrel:
                          {feladatkorNev ? <span className="font-medium"> „{feladatkorNev}"</span> : ""}.
                        </p>
                        <p className="text-amber-800/80">
                          Lehetséges okok: nincs azonos képzettségű kolléga az adott szervezeti egységben, vagy még senki nem dolgozta le a megfelelő tapasztalati időt. Vezetői egyeztetést követően a vezető manuálisan is végrehajthatja a cserét.
                        </p>
                      </>
                    )}
                  </div>
                </div>
              ) : (
                <Select value={swapTarget} onValueChange={setSwapTarget}>
                  <SelectTrigger>
                    <SelectValue placeholder="Válassz cserepartnert…" />
                  </SelectTrigger>
                  <SelectContent>
                    {eligible.map(e => (
                      <SelectItem key={e.user_id} value={e.user_id}>
                        {e.display_name}
                        <span className="text-muted-foreground ml-2 text-[10px]">
                          utoljára: {new Date(e.last_worked).toLocaleDateString("hu-HU")}
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>

            <div>
              <label className="text-xs font-medium mb-1 block">Indok (opcionális)</label>
              <Textarea
                value={swapReason}
                onChange={(e) => setSwapReason(e.target.value)}
                placeholder="Pl. saját kérés, családi program…"
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setSwapOpen(false)} disabled={submitting}>Mégse</Button>
            <Button onClick={submitSwap} disabled={submitting || !swapTarget || eligible.length === 0}>
              {submitting ? "Küldés…" : "Kérés elküldése"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ===== Decide dialog (manager) ===== */}
      <Dialog open={!!decideTarget} onOpenChange={(o) => { if (!o) { setDecideTarget(null); setDecisionNote(""); } }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {decideTarget?.outcome === "approved" ? "Kérés jóváhagyása" : "Kérés elutasítása"}
            </DialogTitle>
            <DialogDescription>
              A döntés bekerül az audit-naplóba és értesítést küld a kérelmezőnek.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-1">
            <label className="text-xs font-medium">
              Indoklás <span className="text-rose-600">*</span>
              <span className="ml-1 text-muted-foreground font-normal">(audithoz szükséges, min. 5 karakter)</span>
            </label>
            <Textarea
              value={decisionNote}
              onChange={(e) => setDecisionNote(e.target.value)}
              placeholder="Pl. szervezeti egyeztetés alapján jóváhagyva / nem teljesíthető, mert…"
              rows={3}
              maxLength={1000}
              required
            />
            <p className="text-[10px] text-muted-foreground text-right">
              {decisionNote.trim().length}/1000
            </p>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setDecideTarget(null)} disabled={submitting}>Mégse</Button>
            <Button
              onClick={submitDecision}
              disabled={submitting || decisionNote.trim().length < 5}
              variant={decideTarget?.outcome === "rejected" ? "destructive" : "default"}
            >
              {submitting ? "Mentés…" : decideTarget?.outcome === "approved" ? "Jóváhagy" : "Elutasít"}
            </Button>
          </DialogFooter>

        </DialogContent>
      </Dialog>
    </div>
  );
}
