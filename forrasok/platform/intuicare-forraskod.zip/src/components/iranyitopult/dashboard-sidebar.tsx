import { useEffect, useState } from "react";
import { GripVertical, Settings2, RotateCcw, ChevronLeft, ChevronRight } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { WIDGET_CATALOG } from "./widgets";
import { toast } from "sonner";

export type WidgetSize = "sm" | "md" | "lg" | "xl";
export type WidgetConfig = { id: string; enabled: boolean; size: WidgetSize };
export type DashboardConfig = { widgets: WidgetConfig[]; sidebarCollapsed?: boolean };

const DEFAULT: DashboardConfig = {
  widgets: WIDGET_CATALOG.map(w => ({ id: w.id, enabled: true, size: w.defaultSize })),
};

export function useDashboardConfig() {
  const { user } = useAuth();
  const [config, setConfig] = useState<DashboardConfig>(DEFAULT);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    if (!user) return;
    void (async () => {
      const { data } = await supabase.from("dashboard_widget_prefs")
        .select("config").eq("user_id", user.id).maybeSingle();
      if (data?.config) {
        const cfg = data.config as DashboardConfig;
        // merge: add new widgets that exist in catalog but not in saved config
        const known = new Set(cfg.widgets.map(w => w.id));
        const merged = [
          ...cfg.widgets.filter(w => WIDGET_CATALOG.some(c => c.id === w.id)),
          ...WIDGET_CATALOG.filter(c => !known.has(c.id)).map(c => ({ id: c.id, enabled: true, size: c.defaultSize })),
        ];
        setConfig({ ...cfg, widgets: merged });
      }
      setLoaded(true);
    })();
  }, [user]);

  async function save(next: DashboardConfig) {
    setConfig(next);
    if (!user) return;
    const { error } = await supabase.from("dashboard_widget_prefs")
      .upsert({ user_id: user.id, config: next as any });
    if (error) toast.error("Mentés sikertelen: " + error.message);
  }

  return { config, setConfig: save, loaded, reset: () => save(DEFAULT) };
}

export function DashboardSidebar({ config, setConfig }: { config: DashboardConfig; setConfig: (c: DashboardConfig) => void }) {
  const [collapsed, setCollapsed] = useState(config.sidebarCollapsed ?? false);

  function toggleEnabled(id: string) {
    setConfig({ ...config, widgets: config.widgets.map(w => w.id === id ? { ...w, enabled: !w.enabled } : w) });
  }
  function setSize(id: string, size: WidgetSize) {
    setConfig({ ...config, widgets: config.widgets.map(w => w.id === id ? { ...w, size } : w) });
  }
  function move(idx: number, dir: -1 | 1) {
    const next = [...config.widgets];
    const t = idx + dir; if (t < 0 || t >= next.length) return;
    [next[idx], next[t]] = [next[t], next[idx]];
    setConfig({ ...config, widgets: next });
  }

  if (collapsed) {
    return (
      <aside className="w-12 shrink-0 border-l bg-card flex flex-col items-center py-3 gap-2">
        <Button variant="ghost" size="icon" onClick={() => { setCollapsed(false); setConfig({ ...config, sidebarCollapsed: false }); }}>
          <ChevronLeft className="h-4 w-4" />
        </Button>
        <Settings2 className="h-4 w-4 text-muted-foreground mt-2" />
      </aside>
    );
  }

  return (
    <aside className="w-80 shrink-0 border-l bg-card flex flex-col">
      <div className="flex items-center justify-between p-3 border-b">
        <div className="flex items-center gap-2"><Settings2 className="h-4 w-4" /><h2 className="font-semibold text-sm">Testreszabás</h2></div>
        <div className="flex gap-1">
          <Button variant="ghost" size="icon" onClick={() => setConfig({ ...DEFAULT })} title="Visszaállítás"><RotateCcw className="h-4 w-4" /></Button>
          <Button variant="ghost" size="icon" onClick={() => { setCollapsed(true); setConfig({ ...config, sidebarCollapsed: true }); }}><ChevronRight className="h-4 w-4" /></Button>
        </div>
      </div>
      <ScrollArea className="flex-1">
        <div className="p-3 space-y-3">
          <p className="text-xs text-muted-foreground">Húzd át a widgeteket a sorrend változtatásához, vagy állítsd be méretüket és láthatóságukat.</p>
          {config.widgets.map((w, i) => {
            const meta = WIDGET_CATALOG.find(c => c.id === w.id);
            if (!meta) return null;
            return (
              <div key={w.id} className="rounded-lg border bg-background p-2.5 space-y-2">
                <div className="flex items-center gap-2">
                  <div className="flex flex-col">
                    <button onClick={() => move(i, -1)} disabled={i === 0} className="text-muted-foreground hover:text-foreground disabled:opacity-30"><ChevronLeft className="h-3 w-3 rotate-90" /></button>
                    <button onClick={() => move(i, +1)} disabled={i === config.widgets.length - 1} className="text-muted-foreground hover:text-foreground disabled:opacity-30"><ChevronRight className="h-3 w-3 rotate-90" /></button>
                  </div>
                  <GripVertical className="h-4 w-4 text-muted-foreground" />
                  <span className="flex-1 text-sm font-medium">{meta.label}</span>
                  <Switch checked={w.enabled} onCheckedChange={() => toggleEnabled(w.id)} />
                </div>
                {w.enabled && (
                  <div className="flex items-center gap-2 pl-10">
                    <span className="text-xs text-muted-foreground">Méret:</span>
                    <Select value={w.size} onValueChange={v => setSize(w.id, v as WidgetSize)}>
                      <SelectTrigger className="h-7 text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="sm">Kicsi (1/4)</SelectItem>
                        <SelectItem value="md">Közepes (1/2)</SelectItem>
                        <SelectItem value="lg">Nagy (3/4)</SelectItem>
                        <SelectItem value="xl">Teljes (1/1)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </ScrollArea>
    </aside>
  );
}

export const SIZE_COL: Record<WidgetSize, string> = {
  sm: "md:col-span-3",
  md: "md:col-span-6",
  lg: "md:col-span-9",
  xl: "md:col-span-12",
};
