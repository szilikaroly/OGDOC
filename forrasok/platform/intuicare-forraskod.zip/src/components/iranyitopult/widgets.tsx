import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import {
  CalendarClock, CalendarHeart, Clock, TrendingUp, Bell, MessageSquare,
  Megaphone, Calendar, Activity, AlertCircle, ChevronRight, Stethoscope,
  CalendarDays, ChevronLeft, Pencil, Check, X,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { ChangeRequestSection } from "./change-request-section";
import { toast } from "sonner";

// Status filter chip definitions (maps DB enum -> Hungarian label)
const STATUS_OPTIONS: { value: string; label: string; cls: string }[] = [
  { value: "tervezett",     label: "Tervezett",     cls: "bg-blue-100 text-blue-800 border-blue-200" },
  { value: "veglegesitett", label: "Jóváhagyott",   cls: "bg-emerald-100 text-emerald-800 border-emerald-200" },
  { value: "tenyleges",     label: "Kész",          cls: "bg-violet-100 text-violet-800 border-violet-200" },
  { value: "torolt",        label: "Lemondva",      cls: "bg-rose-100 text-rose-800 border-rose-200" },
];
const STATUS_LABEL = Object.fromEntries(STATUS_OPTIONS.map(s => [s.value, s.label]));
const STATUS_CLS   = Object.fromEntries(STATUS_OPTIONS.map(s => [s.value, s.cls]));


const fmtDate = (s: string | Date) =>
  new Intl.DateTimeFormat("hu-HU", { weekday: "short", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }).format(new Date(s));
const fmtDay = (s: string | Date) =>
  new Intl.DateTimeFormat("hu-HU", { year: "numeric", month: "long", day: "numeric" }).format(new Date(s));

function WidgetShell({ icon: Icon, title, action, children }: { icon: any; title: string; action?: React.ReactNode; children: React.ReactNode }) {
  return (
    <Card className="h-full">
      <CardHeader className="flex flex-row items-center justify-between pb-3">
        <CardTitle className="flex items-center gap-2 text-base">
          <Icon className="h-4 w-4 text-primary" /> {title}
        </CardTitle>
        {action}
      </CardHeader>
      <CardContent>{children}</CardContent>
    </Card>
  );
}

export function NextShiftWidget() {
  const { user } = useAuth();
  const [row, setRow] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    if (!user) return;
    void (async () => {
      const { data } = await supabase
        .from("schedule_assignments")
        .select("kezdo_idopont, zaro_idopont, ora, kategoria, org_unit_id, feladatkor_id")
        .eq("user_id", user.id)
        .gte("kezdo_idopont", new Date().toISOString())
        .order("kezdo_idopont", { ascending: true })
        .limit(1)
        .maybeSingle();
      setRow(data);
      setLoading(false);
    })();
  }, [user]);
  return (
    <WidgetShell icon={CalendarClock} title="Következő munkanap"
      action={<Link to="/beosztas"><Button variant="ghost" size="sm">Teljes beosztás <ChevronRight className="h-3 w-3" /></Button></Link>}>
      {loading ? <p className="text-sm text-muted-foreground">Betöltés…</p>
        : row ? (
          <div className="space-y-1">
            <p className="text-2xl font-semibold">{fmtDate(row.kezdo_idopont)}</p>
            <p className="text-sm text-muted-foreground">{fmtDate(row.zaro_idopont)} • {row.ora} óra • {row.kategoria}</p>
          </div>
        ) : <p className="text-sm text-muted-foreground">Nincs ütemezett műszak.</p>}
    </WidgetShell>
  );
}

export function NextLeaveWidget() {
  const { user } = useAuth();
  const [row, setRow] = useState<any>(null);
  useEffect(() => {
    if (!user) return;
    void (async () => {
      const { data } = await supabase
        .from("profile_unavailability")
        .select("kezdo_datum, zaro_datum, tipus, status, nap_szam")
        .eq("user_id", user.id)
        .eq("tipus", "szabadsag")
        .gte("zaro_datum", new Date().toISOString().slice(0, 10))
        .order("kezdo_datum", { ascending: true })
        .limit(1)
        .maybeSingle();
      setRow(data);
    })();
  }, [user]);
  return (
    <WidgetShell icon={CalendarHeart} title="Következő szabadság"
      action={<Link to="/szabadsag"><Button variant="ghost" size="sm">Szabadságok <ChevronRight className="h-3 w-3" /></Button></Link>}>
      {row ? (
        <div className="space-y-1">
          <p className="text-2xl font-semibold">{fmtDay(row.kezdo_datum)}</p>
          <p className="text-sm text-muted-foreground">– {fmtDay(row.zaro_datum)} • {row.nap_szam ?? "?"} nap • <Badge variant="outline">{row.status}</Badge></p>
        </div>
      ) : <p className="text-sm text-muted-foreground">Nincs tervezett szabadság.</p>}
    </WidgetShell>
  );
}

export function MonthlyHoursWidget() {
  const { user } = useAuth();
  const [stats, setStats] = useState({ total: 0, overtime: 0, count: 0 });
  useEffect(() => {
    if (!user) return;
    void (async () => {
      const start = new Date(); start.setDate(1); start.setHours(0, 0, 0, 0);
      const end = new Date(start); end.setMonth(end.getMonth() + 1);
      const { data } = await supabase
        .from("schedule_assignments")
        .select("ora, kategoria")
        .eq("user_id", user.id)
        .gte("kezdo_idopont", start.toISOString())
        .lt("kezdo_idopont", end.toISOString());
      const total = (data ?? []).reduce((s, r: any) => s + Number(r.ora || 0), 0);
      const overtime = (data ?? []).filter((r: any) => r.kategoria !== "rendes").reduce((s, r: any) => s + Number(r.ora || 0), 0);
      setStats({ total, overtime, count: data?.length ?? 0 });
    })();
  }, [user]);
  return (
    <WidgetShell icon={Clock} title="Havi órák">
      <div className="grid grid-cols-3 gap-3">
        <div><p className="text-2xl font-semibold">{stats.total.toFixed(1)}</p><p className="text-xs text-muted-foreground">összes óra</p></div>
        <div><p className="text-2xl font-semibold">{stats.overtime.toFixed(1)}</p><p className="text-xs text-muted-foreground">túlóra</p></div>
        <div><p className="text-2xl font-semibold">{stats.count}</p><p className="text-xs text-muted-foreground">műszak</p></div>
      </div>
    </WidgetShell>
  );
}

export function OvertimeBudgetWidget() {
  const { user } = useAuth();
  const [stats, setStats] = useState({ yearly: 0, voluntary: 0 });
  useEffect(() => {
    if (!user) return;
    void (async () => {
      const start = new Date(new Date().getFullYear(), 0, 1).toISOString().slice(0, 10);
      const { data } = await supabase
        .from("work_time_ledger")
        .select("ora, kategoria")
        .eq("user_id", user.id)
        .gte("datum", start);
      const yearly = (data ?? []).filter((r: any) => r.kategoria !== "rendes").reduce((s, r: any) => s + Number(r.ora || 0), 0);
      const voluntary = (data ?? []).filter((r: any) => r.kategoria === "ovt" || r.kategoria === "rendkivuli").reduce((s, r: any) => s + Number(r.ora || 0), 0);
      setStats({ yearly, voluntary });
    })();
  }, [user]);
  const remaining = Math.max(0, 250 - stats.yearly);
  return (
    <WidgetShell icon={TrendingUp} title="Éves túlóra-keret">
      <div className="space-y-2">
        <div className="flex items-baseline justify-between">
          <span className="text-2xl font-semibold">{remaining.toFixed(1)}</span>
          <span className="text-xs text-muted-foreground">óra fennmaradt (250-ből)</span>
        </div>
        <div className="h-2 rounded-full bg-muted overflow-hidden">
          <div className="h-full bg-primary" style={{ width: `${Math.min(100, (stats.yearly / 250) * 100)}%` }} />
        </div>
        <p className="text-xs text-muted-foreground">Önkéntvállalt túlmunka: <span className="font-medium text-foreground">{stats.voluntary.toFixed(1)} ó</span></p>
      </div>
    </WidgetShell>
  );
}

export function SickReportWidget() {
  const { user } = useAuth();
  const [busy, setBusy] = useState(false);
  async function reportSick() {
    if (!user) return;
    if (!confirm("Megerősíted, hogy ma betegszabadságra jelenkezel?")) return;
    setBusy(true);
    try {
      const today = new Date().toISOString().slice(0, 10);
      const { data: prof } = await supabase.from("profiles").select("tenant_id").eq("id", user.id).maybeSingle();
      const { error } = await supabase.from("profile_unavailability").insert({
        user_id: user.id, tenant_id: prof?.tenant_id ?? null,
        tipus: "betegszabadsag", kezdo_datum: today, zaro_datum: today,
        status: "tervezett", akut: true, leiras: "Beteget jelentett az irányítópultról",
      } as any);
      if (error) throw error;
      toast.success("Betegjelentés rögzítve. A vezető értesítést kap.");
    } catch (e: any) { toast.error("Hiba: " + (e?.message ?? "ismeretlen")); }
    finally { setBusy(false); }
  }
  return (
    <WidgetShell icon={AlertCircle} title="Beteget jelentek">
      <p className="text-sm text-muted-foreground mb-3">Egyetlen kattintással rögzítheted a mai betegszabadságot.</p>
      <Button onClick={reportSick} disabled={busy} variant="destructive" className="w-full">
        <Stethoscope className="h-4 w-4 mr-2" /> {busy ? "Mentés…" : "Mai napra beteg jelentés"}
      </Button>
    </WidgetShell>
  );
}

export function NotificationsWidget() {
  const { user } = useAuth();
  const [rows, setRows] = useState<any[]>([]);
  useEffect(() => {
    if (!user) return;
    void (async () => {
      const { data } = await supabase.from("notifications")
        .select("id, cim, uzenet, tipus, link, created_at, olvasott_at")
        .eq("user_id", user.id).order("created_at", { ascending: false }).limit(8);
      setRows(data ?? []);
    })();
  }, [user]);
  const unread = rows.filter(r => !r.olvasott_at).length;
  return (
    <WidgetShell icon={Bell} title={`Értesítések${unread ? ` (${unread})` : ""}`}>
      <ScrollArea className="h-56">
        {rows.length === 0 ? <p className="text-sm text-muted-foreground">Nincs értesítés.</p> :
          <ul className="space-y-2">
            {rows.map(r => (
              <li key={r.id} className={`rounded border p-2 text-sm ${r.olvasott_at ? "" : "bg-primary/5 border-primary/30"}`}>
                <p className="font-medium">{r.cim}</p>
                {r.uzenet && <p className="text-xs text-muted-foreground">{r.uzenet}</p>}
                <p className="text-[10px] text-muted-foreground mt-1">{fmtDate(r.created_at)}</p>
              </li>
            ))}
          </ul>}
      </ScrollArea>
    </WidgetShell>
  );
}

export function MessagesWidget() {
  const { user } = useAuth();
  const [rows, setRows] = useState<any[]>([]);
  useEffect(() => {
    if (!user) return;
    void (async () => {
      const { data } = await supabase.from("messages")
        .select("id, body, created_at, sender_user_id, conversation_id")
        .neq("sender_user_id", user.id).order("created_at", { ascending: false }).limit(6);
      setRows(data ?? []);
    })();
  }, [user]);
  return (
    <WidgetShell icon={MessageSquare} title="Üzenetek"
      action={<Link to="/uzenetek"><Button variant="ghost" size="sm">Megnyit <ChevronRight className="h-3 w-3" /></Button></Link>}>
      <ScrollArea className="h-56">
        {rows.length === 0 ? <p className="text-sm text-muted-foreground">Nincs új üzenet.</p> :
          <ul className="space-y-2">
            {rows.map(r => (
              <li key={r.id} className="rounded border p-2 text-sm">
                <p className="line-clamp-2">{r.body}</p>
                <p className="text-[10px] text-muted-foreground mt-1">{fmtDate(r.created_at)}</p>
              </li>
            ))}
          </ul>}
      </ScrollArea>
    </WidgetShell>
  );
}

export function AnnouncementsWidget({ kategoria }: { kategoria?: "hir" | "hirdetmeny" | "esemeny" | "figyelmeztetes" }) {
  const [rows, setRows] = useState<any[]>([]);
  useEffect(() => {
    void (async () => {
      let q = supabase.from("announcements")
        .select("id, cim, tartalom, prioritas, kategoria, link, publikalva_tol, rogzitett")
        .order("rogzitett", { ascending: false }).order("publikalva_tol", { ascending: false }).limit(8);
      if (kategoria) q = q.eq("kategoria", kategoria);
      const { data } = await q;
      setRows(data ?? []);
    })();
  }, [kategoria]);
  const title = kategoria === "esemeny" ? "Események" : kategoria === "hirdetmeny" ? "Hírdetmények" : "Hírfolyam";
  const Icon = kategoria === "esemeny" ? Calendar : kategoria === "hirdetmeny" ? Megaphone : Activity;
  const priColor = (p: string) => p === "critical" ? "destructive" : p === "warning" ? "secondary" : p === "success" ? "default" : "outline";
  return (
    <WidgetShell icon={Icon} title={title}>
      <ScrollArea className="h-72">
        {rows.length === 0 ? <p className="text-sm text-muted-foreground">Nincs bejegyzés.</p> :
          <ul className="space-y-3">
            {rows.map(r => (
              <li key={r.id} className="border-l-2 border-primary/40 pl-3">
                <div className="flex items-center gap-2">
                  <Badge variant={priColor(r.prioritas) as any} className="text-[10px]">{r.prioritas}</Badge>
                  <p className="font-medium text-sm">{r.cim}</p>
                </div>
                <p className="text-xs text-muted-foreground mt-1 line-clamp-3">{r.tartalom}</p>
                <p className="text-[10px] text-muted-foreground mt-1">{fmtDate(r.publikalva_tol)}</p>
              </li>
            ))}
          </ul>}
      </ScrollArea>
    </WidgetShell>
  );
}

const KAT_COLOR: Record<string, string> = {
  rendes: "bg-sky-100 text-sky-900 dark:bg-sky-950 dark:text-sky-200",
  ugyelet: "bg-violet-100 text-violet-900 dark:bg-violet-950 dark:text-violet-200",
  keszenlet: "bg-amber-100 text-amber-900 dark:bg-amber-950 dark:text-amber-200",
  rendkivuli: "bg-rose-100 text-rose-900 dark:bg-rose-950 dark:text-rose-200",
  ovt: "bg-emerald-100 text-emerald-900 dark:bg-emerald-950 dark:text-emerald-200",
  szabadnap: "bg-muted text-muted-foreground",
};

type ScheduleItem = {
  id: string;
  kezdo_idopont: string;
  zaro_idopont: string;
  ora: number;
  kategoria: string;
  status: string;
  megjegyzes: string | null;
  org_unit_id: string | null;
  site_id: string | null;
  feladatkor_id: string | null;
  org_units?: { nev: string | null } | null;
  sites?: { nev: string | null } | null;
  feladat_korok?: { nev: string | null } | null;
};

export function MyMonthlyScheduleWidget() {
  const { user } = useAuth();
  const [cursor, setCursor] = useState(() => { const d = new Date(); d.setDate(1); return d; });
  const [allCells, setAllCells] = useState<Map<string, ScheduleItem[]>>(new Map());
  const [loading, setLoading] = useState(true);
  const [dlg, setDlg] = useState<{ date: string; items: ScheduleItem[] } | null>(null);
  const [statusFilter, setStatusFilter] = useState<Set<string>>(() => new Set(STATUS_OPTIONS.map(s => s.value)));
  const [isManager, setIsManager] = useState(false);

  useEffect(() => {
    if (!user) return;
    void (async () => {
      const { data: a } = await supabase.rpc("has_permission", { _user_id: user.id, _perm: "manage_schedule" });
      const { data: b } = await supabase.rpc("has_permission", { _user_id: user.id, _perm: "manage_tenant" });
      setIsManager(Boolean(a || b));
    })();
  }, [user]);


  // Edit-mode state per-assignment (id -> draft note)
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editDraft, setEditDraft] = useState("");
  const [saving, setSaving] = useState(false);

  async function reload() {
    if (!user) return;
    const start = new Date(cursor);
    const end = new Date(cursor); end.setMonth(end.getMonth() + 1);
    const { data } = await supabase
      .from("schedule_assignments")
      .select("id, kezdo_idopont, zaro_idopont, ora, kategoria, status, megjegyzes, org_unit_id, site_id, feladatkor_id, org_units(nev), sites(nev), feladat_korok(nev)")
      .eq("user_id", user.id)
      .gte("kezdo_idopont", start.toISOString())
      .lt("kezdo_idopont", end.toISOString())
      .order("kezdo_idopont", { ascending: true });
    const m = new Map<string, ScheduleItem[]>();
    (data ?? []).forEach((r: any) => {
      const key = r.kezdo_idopont.slice(0, 10);
      if (!m.has(key)) m.set(key, []);
      m.get(key)!.push(r as ScheduleItem);
    });
    setAllCells(m);
  }

  useEffect(() => {
    if (!user) return;
    setLoading(true);
    void reload().finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, cursor]);

  // Apply status filter
  const cells = (() => {
    const out = new Map<string, ScheduleItem[]>();
    allCells.forEach((arr, key) => {
      const filtered = arr.filter(it => statusFilter.has(it.status));
      if (filtered.length) out.set(key, filtered);
    });
    return out;
  })();

  function toggleStatus(v: string) {
    setStatusFilter(prev => {
      const next = new Set(prev);
      if (next.has(v)) next.delete(v); else next.add(v);
      return next;
    });
  }

  const monthLabel = new Intl.DateTimeFormat("hu-HU", { year: "numeric", month: "long" }).format(cursor);
  const daysInMonth = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0).getDate();
  const firstWeekday = (new Date(cursor.getFullYear(), cursor.getMonth(), 1).getDay() + 6) % 7;
  const cellsArr: (number | null)[] = [
    ...Array(firstWeekday).fill(null),
    ...Array.from({ length: daysInMonth }, (_, i) => i + 1),
  ];
  while (cellsArr.length % 7 !== 0) cellsArr.push(null);

  let totalHours = 0;
  cells.forEach(arr => arr.forEach(r => { totalHours += Number(r.ora || 0); }));

  function shift(delta: number) {
    const d = new Date(cursor); d.setMonth(d.getMonth() + delta); setCursor(d);
  }

  const dlgDateLabel = dlg ? new Intl.DateTimeFormat("hu-HU", { weekday: "long", year: "numeric", month: "long", day: "numeric" }).format(new Date(dlg.date)) : "";

  function startEdit(it: ScheduleItem) {
    setEditingId(it.id);
    setEditDraft(it.megjegyzes ?? "");
  }
  function cancelEdit() {
    setEditingId(null);
    setEditDraft("");
  }
  async function saveEdit(id: string) {
    setSaving(true);
    const { error } = await supabase
      .from("schedule_assignments")
      .update({ megjegyzes: editDraft.trim() || null })
      .eq("id", id);
    setSaving(false);
    if (error) {
      toast.error("Mentés sikertelen", { description: error.message });
      return;
    }
    toast.success("Megjegyzés mentve");
    // Update local state & dialog state
    setAllCells(prev => {
      const next = new Map(prev);
      next.forEach((arr, k) => {
        next.set(k, arr.map(x => x.id === id ? { ...x, megjegyzes: editDraft.trim() || null } : x));
      });
      return next;
    });
    setDlg(d => d ? { ...d, items: d.items.map(x => x.id === id ? { ...x, megjegyzes: editDraft.trim() || null } : x) } : d);
    cancelEdit();
  }

  return (
    <>
      <WidgetShell
        icon={CalendarDays}
        title="Saját havi beosztás"
        action={
          <div className="flex items-center gap-1">
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => shift(-1)}><ChevronLeft className="h-3 w-3" /></Button>
            <span className="text-xs font-medium min-w-[120px] text-center capitalize">{monthLabel}</span>
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => shift(1)}><ChevronRight className="h-3 w-3" /></Button>
          </div>
        }
      >
        {loading ? <p className="text-sm text-muted-foreground">Betöltés…</p> : (
          <div className="space-y-2">
            {/* Status filter chips */}
            <div className="flex flex-wrap gap-1">
              {STATUS_OPTIONS.map(s => {
                const active = statusFilter.has(s.value);
                return (
                  <button
                    key={s.value}
                    type="button"
                    onClick={() => toggleStatus(s.value)}
                    aria-pressed={active}
                    className={`text-[10px] px-2 py-0.5 rounded-full border transition ${active ? s.cls : "bg-muted/40 text-muted-foreground border-transparent opacity-60 hover:opacity-100"}`}
                  >
                    {s.label}
                  </button>
                );
              })}
            </div>
            <div className="grid grid-cols-7 gap-1 text-[10px] text-muted-foreground text-center font-medium">
              {["H", "K", "Sze", "Cs", "P", "Szo", "V"].map(d => <div key={d}>{d}</div>)}
            </div>
            <div className="grid grid-cols-7 gap-1">
              {cellsArr.map((day, i) => {
                if (day === null) return <div key={i} />;
                const dateStr = `${cursor.getFullYear()}-${String(cursor.getMonth() + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
                const items = cells.get(dateStr) ?? [];
                const isToday = dateStr === new Date().toISOString().slice(0, 10);
                const isWeekend = i % 7 >= 5;
                const hasItems = items.length > 0;
                return (
                  <button
                    key={i}
                    type="button"
                    disabled={!hasItems}
                    onClick={() => hasItems && setDlg({ date: dateStr, items })}
                    className={`min-h-[52px] rounded border p-1 text-[10px] text-left transition ${isToday ? "border-primary" : "border-border"} ${isWeekend ? "bg-muted/30" : ""} ${hasItems ? "hover:bg-accent hover:border-primary/50 cursor-pointer" : "cursor-default opacity-70"}`}
                  >
                    <div className={`font-medium ${isToday ? "text-primary" : ""}`}>{day}</div>
                    <div className="space-y-0.5 mt-0.5">
                      {items.slice(0, 2).map((it, idx) => (
                        <div key={idx} className={`px-1 py-0.5 rounded text-[9px] truncate ${KAT_COLOR[it.kategoria] ?? "bg-muted"}`} title={`${STATUS_LABEL[it.status] ?? it.status} • ${it.kategoria} • ${it.ora}ó`}>
                          {it.kezdo_idopont.slice(11, 16)} {Number(it.ora).toFixed(0)}h
                        </div>
                      ))}
                      {items.length > 2 && <div className="text-[9px] text-muted-foreground">+{items.length - 2}</div>}
                    </div>
                  </button>
                );
              })}
            </div>
            <div className="flex items-center justify-between pt-1 text-xs text-muted-foreground border-t">
              <span>Szűrt: <span className="font-semibold text-foreground">{totalHours.toFixed(1)} ó</span></span>
              <Link to="/beosztas"><Button variant="ghost" size="sm" className="h-6">Teljes beosztás <ChevronRight className="h-3 w-3" /></Button></Link>
            </div>
          </div>
        )}
      </WidgetShell>

      <Dialog open={!!dlg} onOpenChange={(o) => { if (!o) { setDlg(null); cancelEdit(); } }}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="capitalize">{dlgDateLabel}</DialogTitle>
            <DialogDescription>
              {dlg?.items.length ?? 0} bejegyzés • összesen {(dlg?.items.reduce((s, i) => s + Number(i.ora || 0), 0) ?? 0).toFixed(1)} óra
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 max-h-[60vh] overflow-auto">
            {dlg?.items.map((it) => {
              const isEditing = editingId === it.id;
              return (
                <div key={it.id} className="rounded-lg border p-3 space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 flex-wrap">
                      <Badge className={KAT_COLOR[it.kategoria] ?? ""} variant="outline">{it.kategoria}</Badge>
                      <Badge variant="outline" className={STATUS_CLS[it.status] ?? ""}>{STATUS_LABEL[it.status] ?? it.status}</Badge>
                    </div>
                    <span className="text-sm font-semibold">{Number(it.ora).toFixed(1)} ó</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <p className="text-[10px] uppercase text-muted-foreground">Kezdés</p>
                      <p className="font-medium">{fmtDate(it.kezdo_idopont)}</p>
                    </div>
                    <div>
                      <p className="text-[10px] uppercase text-muted-foreground">Befejezés</p>
                      <p className="font-medium">{fmtDate(it.zaro_idopont)}</p>
                    </div>
                  </div>
                  {(it.org_units?.nev || it.sites?.nev) && (
                    <div>
                      <p className="text-[10px] uppercase text-muted-foreground">Helyszín</p>
                      <p className="text-sm">{[it.sites?.nev, it.org_units?.nev].filter(Boolean).join(" · ")}</p>
                    </div>
                  )}
                  {it.feladat_korok?.nev && (
                    <div>
                      <p className="text-[10px] uppercase text-muted-foreground">Feladatkör</p>
                      <p className="text-sm">{it.feladat_korok.nev}</p>
                    </div>
                  )}
                  <div>
                    <div className="flex items-center justify-between">
                      <p className="text-[10px] uppercase text-muted-foreground">Megjegyzés</p>
                      {!isEditing && (
                        <Button variant="ghost" size="sm" className="h-6 px-2" onClick={() => startEdit(it)}>
                          <Pencil className="h-3 w-3 mr-1" /> Szerkesztés
                        </Button>
                      )}
                    </div>
                    {isEditing ? (
                      <div className="space-y-2 mt-1">
                        <Textarea
                          value={editDraft}
                          onChange={(e) => setEditDraft(e.target.value)}
                          placeholder="Saját megjegyzés…"
                          rows={3}
                          className="text-sm"
                        />
                        <div className="flex justify-end gap-1">
                          <Button variant="ghost" size="sm" className="h-7" onClick={cancelEdit} disabled={saving}>
                            <X className="h-3 w-3 mr-1" /> Mégse
                          </Button>
                          <Button size="sm" className="h-7" onClick={() => saveEdit(it.id)} disabled={saving}>
                            <Check className="h-3 w-3 mr-1" /> {saving ? "Mentés…" : "Mentés"}
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <p className="text-sm whitespace-pre-wrap mt-1 text-muted-foreground">
                        {it.megjegyzes || <span className="italic">Nincs megjegyzés</span>}
                      </p>
                    )}
                  </div>

                  {user && (
                    <ChangeRequestSection
                      assignmentId={it.id}
                      ownerUserId={user.id}
                      isManager={isManager}
                      feladatkorId={it.feladatkor_id}
                      feladatkorNev={it.feladat_korok?.nev ?? null}
                    />
                  )}

                </div>

              );
            })}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}



export const WIDGET_CATALOG = [
  { id: "next_shift", label: "Következő munkanap", component: NextShiftWidget, defaultSize: "md" as const },
  { id: "my_monthly_schedule", label: "Saját havi beosztás", component: MyMonthlyScheduleWidget, defaultSize: "xl" as const },
  { id: "next_leave", label: "Következő szabadság", component: NextLeaveWidget, defaultSize: "md" as const },
  { id: "monthly_hours", label: "Havi órák", component: MonthlyHoursWidget, defaultSize: "md" as const },
  { id: "overtime", label: "Éves túlóra-keret", component: OvertimeBudgetWidget, defaultSize: "md" as const },
  { id: "sick_report", label: "Beteget jelentek", component: SickReportWidget, defaultSize: "sm" as const },
  { id: "notifications", label: "Értesítések", component: NotificationsWidget, defaultSize: "md" as const },
  { id: "messages", label: "Üzenetek", component: MessagesWidget, defaultSize: "md" as const },
  { id: "news", label: "Hírfolyam", component: () => <AnnouncementsWidget />, defaultSize: "lg" as const },
  { id: "events", label: "Események", component: () => <AnnouncementsWidget kategoria="esemeny" />, defaultSize: "md" as const },
  { id: "bulletins", label: "Hírdetmények", component: () => <AnnouncementsWidget kategoria="hirdetmeny" />, defaultSize: "md" as const },
];
export type WidgetId = (typeof WIDGET_CATALOG)[number]["id"];
