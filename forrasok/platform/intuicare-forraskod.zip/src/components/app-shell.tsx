import { Link, useRouterState } from "@tanstack/react-router";
import { useTranslation } from "react-i18next";
import { SUPPORTED_LANGUAGES } from "@/i18n/languages";
import {
  LayoutDashboard,
  User as UserIcon,
  CalendarRange,
  Users,
  GraduationCap,
  Stethoscope,
  Scissors,
  Building2,
  ShieldCheck,
  Clock,
  MapPin,
  AlertTriangle,
  BarChart3,
  Activity,
  LogOut,
  BookOpen,
  Languages,
  MessageSquare,
  Palmtree,
  ClipboardList,
  Settings,
  Palette,
  FileText,
  Home,
} from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { usePermissions, type PermissionKey } from "@/hooks/use-permissions";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { classifyUser } from "@/lib/portal/user-classification.functions";
import { useEffect, useState, type ReactNode } from "react";
import { cn } from "@/lib/utils";
import { PatientSearch } from "@/components/patient-search";
import { NotificationsBell } from "@/components/notifications-bell";
import { AiAssistant } from "@/components/ai-assistant";
import { ViewAsProvider, useViewAs } from "@/hooks/use-view-as";
import { ViewAsSwitcher } from "@/components/view-as-switcher";
import { HelpButton } from "@/components/help/HelpButton";
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from "@/components/ui/sheet";
import { Menu } from "lucide-react";
import { MobileBottomNav } from "@/components/mobile-bottom-nav";



type NavItem = {
  to: string;
  label: string;
  icon: typeof LayoutDashboard;
  requires?: PermissionKey;
};

function useNav(): NavItem[] {
  const { t } = useTranslation();
  return [
    { to: "/dashboard", label: t("nav.dashboard"), icon: LayoutDashboard },
    { to: "/uzenetek", label: "Üzenetek", icon: MessageSquare },
    { to: "/karakterlap", label: t("nav.karakterlap"), icon: UserIcon },
    { to: "/beosztas", label: t("nav.beosztas"), icon: CalendarRange, requires: "manage_schedule" },
    { to: "/vezeto/keresek", label: "Beosztás-kérelmek", icon: ShieldCheck, requires: "manage_schedule" },
    { to: "/munkaido", label: t("nav.munkaido"), icon: Clock },
    { to: "/jelenlet", label: t("nav.jelenlet"), icon: MapPin },
    { to: "/szabadsag", label: "Szabadság", icon: Palmtree },
    { to: "/csapat", label: t("nav.csapat"), icon: Users, requires: "view_team" },
    { to: "/csapat-mutatok", label: "Csapat-mutatók", icon: BarChart3, requires: "view_team" },
    { to: "/kepzes", label: t("nav.kepzes"), icon: GraduationCap, requires: "manage_training" },
    { to: "/paciensek", label: t("nav.paciensek"), icon: Stethoscope, requires: "manage_patients" },
    { to: "/klinika", label: "Klinika", icon: Activity, requires: "manage_patients" },
    { to: "/muteti-terv", label: t("nav.muteti_terv"), icon: Scissors, requires: "view_or_board" },
    { to: "/admin/mutet-szabalyok", label: "Műtéti típus-szabályok", icon: Scissors, requires: "manage_or_blocks" },
    { to: "/admin/paciens-kerelmek", label: "Páciens-kérelmek", icon: ClipboardList, requires: "manage_patients" },
    { to: "/admin/monitoring-szabalyok", label: "Monitoring szabályok", icon: Activity, requires: "manage_patients" },
    { to: "/admin/followup", label: "Utánkövetési protokollok", icon: CalendarRange, requires: "manage_patients" },
    { to: "/admin/szervezet", label: t("nav.admin_szervezet"), icon: Building2, requires: "manage_org" },
    { to: "/admin/letszam-igeny", label: "Létszámigény-sablonok", icon: Users, requires: "manage_org" },
    { to: "/admin/szerepkorok", label: t("nav.admin_szerepkorok"), icon: ShieldCheck, requires: "manage_roles" },
    { to: "/admin/jogosultsagok", label: t("nav.admin_jogosultsagok"), icon: ShieldCheck, requires: "manage_tenant" },
    { to: "/admin/munkaido-szabalyok", label: t("nav.admin_munkaido"), icon: Clock, requires: "manage_tenant" },
    { to: "/admin/eusztv", label: "Eüsztv. (2020. C. tv.)", icon: ShieldCheck, requires: "manage_eusztv" },
    { to: "/admin/jelenlet-horgonyok", label: t("nav.admin_jelenlet"), icon: MapPin, requires: "manage_tenant" },
    { to: "/admin/jelenlet-anomaliak", label: t("nav.admin_jelenlet_anomaliak"), icon: AlertTriangle, requires: "manage_schedule" },
    { to: "/admin/kotelezo-ugyelet", label: "Kötelező ügyelet", icon: AlertTriangle, requires: "manage_schedule" },
    { to: "/admin/potlas", label: "Pótlás (helyettesítés)", icon: UserIcon, requires: "manage_schedule" },
    { to: "/admin/tulora-pool", label: "Túlóra-pool", icon: Clock, requires: "manage_schedule" },
    { to: "/admin/szabadsag-felugyelet", label: "Szabadság-felügyelet", icon: Palmtree, requires: "manage_schedule" },
    { to: "/admin/szabadsag-szabalyzat", label: "Szabadság-szabályzat", icon: Palmtree, requires: "manage_tenant" },
    { to: "/admin/szervezet-sugo", label: "Szervezet kézikönyv", icon: BookOpen, requires: "manage_org" },
    { to: "/admin/forditasok", label: "Fordításkezelő", icon: Languages, requires: "manage_tenant" },
    { to: "/admin/portal-analitika", label: "Portál analitika", icon: BarChart3, requires: "manage_tenant" },
    { to: "/admin/beallitasok", label: "Rendszerbeállítások", icon: Settings, requires: "manage_tenant" },
    { to: "/admin/landing", label: "Landing szerkesztő", icon: Palette, requires: "manage_tenant" },
    { to: "/admin/cms", label: "Tartalomkezelő (CMS)", icon: FileText, requires: "manage_tenant" },
    { to: "/audit", label: t("nav.audit"), icon: ShieldCheck, requires: "view_audit" },
  ];
}

function LanguageSwitch() {
  const { i18n, t } = useTranslation();
  const current = (i18n.language?.split("-")[0] ?? "hu") as string;
  return (
    <div>
      <div className="px-3 mb-2 text-[10px] font-mono font-medium uppercase tracking-widest text-muted-foreground flex items-center justify-between">
        <span>{t("nav.language")}</span>
        <span className="text-[9px] opacity-70">AI</span>
      </div>
      <div className="grid grid-cols-5 gap-1 bg-secondary rounded-lg p-1">
        {SUPPORTED_LANGUAGES.map((l) => (
          <button
            key={l.code}
            type="button"
            onClick={() => i18n.changeLanguage(l.code)}
            title={l.label}
            className={cn(
              "py-1 text-[10px] font-semibold rounded transition-colors flex flex-col items-center leading-tight",
              current === l.code
                ? "bg-card shadow-sm text-foreground"
                : "text-muted-foreground hover:text-foreground",
            )}
          >
            <span className="text-sm leading-none">{l.flag}</span>
            <span className="mt-0.5">{l.code.toUpperCase()}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

function SidebarContent({ onNavigate }: { onNavigate?: () => void }) {
  const items = useNav();
  const { can, loading: permLoading } = usePermissions();
  const classify = useServerFn(classifyUser);
  const { data: cls, isLoading: clsLoading } = useQuery({
    queryKey: ["user-classification"],
    queryFn: () => classify(),
    staleTime: 5 * 60_000,
  });
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  const stillLoading = permLoading || clsLoading;
  const visible = stillLoading
    ? []
    : items.filter((i) => {
        if (i.to.startsWith("/admin")) {
          if (!cls?.isAdmin) return false;
        }
        if (i.requires && !can(i.requires)) return false;
        return true;
      });

  return (
    <>
      <div className="p-6 flex items-center gap-3">
        <div className="size-9 bg-primary rounded-lg flex items-center justify-center text-primary-foreground font-bold">
          M
        </div>
        <div className="leading-tight">
          <div className="font-bold text-base tracking-tight uppercase">MedRoster</div>
          <div className="text-[10px] font-mono text-muted-foreground uppercase">Suite</div>
        </div>
      </div>

      <div className="flex-1 px-3 space-y-0.5 overflow-y-auto pb-4">
        {stillLoading && (
          <div className="px-3 py-2 text-xs text-muted-foreground">Menü betöltése…</div>
        )}
        {visible.map(({ to, label, icon: Icon }) => {
          const active = pathname === to || (to !== "/" && pathname.startsWith(to));
          return (
            <Link
              key={to}
              to={to}
              onClick={onNavigate}
              className={cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors min-h-11",
                active
                  ? "bg-secondary text-foreground"
                  : "text-muted-foreground hover:bg-secondary/60 hover:text-foreground active:bg-secondary",
              )}
            >
              <Icon className="size-4 shrink-0" />
              <span className="truncate">{label}</span>
            </Link>
          );
        })}
      </div>

      <div className="p-4 border-t border-border space-y-3">
        <LanguageSwitch />
      </div>
    </>
  );
}

function Sidebar() {
  return (
    <nav className="hidden lg:flex w-64 shrink-0 border-r border-border bg-sidebar flex-col sticky top-0 h-screen">
      <SidebarContent />
    </nav>
  );
}

function MobileNav() {
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const handler = () => setOpen(true);
    window.addEventListener("medroster:open-mobile-nav", handler);
    return () => window.removeEventListener("medroster:open-mobile-nav", handler);
  }, []);
  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <button
          type="button"
          aria-label="Menü megnyitása"
          className="lg:hidden inline-flex items-center justify-center size-11 rounded-md hover:bg-secondary active:bg-secondary/80 transition-colors"
        >
          <Menu className="size-5" />
        </button>
      </SheetTrigger>
      <SheetContent side="left" className="p-0 w-72 flex flex-col bg-sidebar">
        <SheetTitle className="sr-only">Navigáció</SheetTitle>
        <SidebarContent onNavigate={() => setOpen(false)} />
      </SheetContent>
    </Sheet>
  );
}

function Header() {
  const { user } = useAuth();
  const { t } = useTranslation();
  const [profileName, setProfileName] = useState<string>("");
  useEffect(() => {
    if (!user) return;
    supabase
      .from("profiles")
      .select("teljes_nev")
      .eq("id", user.id)
      .maybeSingle()
      .then(({ data }) => data && setProfileName(data.teljes_nev));
  }, [user]);

  const queryClient = useQueryClient();
  const navigate = useNavigate();
  async function signOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  return (
    <header className="h-16 border-b border-border bg-card flex items-center justify-between px-3 sm:px-6 lg:px-8 sticky top-0 z-10 gap-2 sm:gap-4">
      <div className="flex items-center gap-2 shrink-0">
        <MobileNav />
        <span className="px-2 py-1 bg-success/10 text-success text-[10px] font-bold rounded-full border border-success/20 hidden sm:inline">
          LIVE
        </span>
        <span className="text-sm text-muted-foreground font-mono uppercase tracking-wider hidden md:inline">
          MedRoster Suite
        </span>
      </div>
      <div className="flex-1 min-w-0 hidden sm:block">
        <PatientSearch />
      </div>
      <div className="flex items-center gap-2 sm:gap-4 shrink-0">
        <div className="hidden md:block"><ViewAsSwitcher /></div>
        <HelpButton />
        <NotificationsBell />
        <Link
          to="/"
          aria-label="Főoldal megtekintése"
          title="Főoldal megtekintése"
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-muted-foreground hover:text-foreground transition-colors min-h-11 min-w-11 justify-center sm:min-w-0"
        >
          <Home className="size-4 sm:size-3.5" />
          <span className="hidden lg:inline">Főoldal</span>
        </Link>
        <Link
          to="/fiok"
          aria-label="Fiók-összekapcsolás"
          title="Fiók-összekapcsolás"
          className="text-right hidden sm:block min-w-0 hover:opacity-80 transition-opacity"
        >
          <div className="text-xs font-bold truncate max-w-[160px]">{profileName || user?.email}</div>
          <div className="text-[10px] text-muted-foreground font-mono truncate max-w-[160px]">{user?.email}</div>
        </Link>
        <button
          type="button"
          onClick={signOut}
          aria-label={t("nav.signout")}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-muted-foreground hover:text-foreground transition-colors min-h-11 min-w-11 justify-center sm:min-w-0"
        >
          <LogOut className="size-4 sm:size-3.5" />
          <span className="hidden sm:inline">{t("nav.signout")}</span>
        </button>
      </div>
    </header>
  );
}

function ViewAsBanner() {
  const { mode, setMode, isSimulating } = useViewAs();
  if (!isSimulating) return null;
  const label = mode === "orvos" ? "Orvos" : mode === "noverkereszt" ? "Nővérkereszt" : "Páciens";
  return (
    <div className="bg-warning/15 border-b border-warning/30 px-6 py-2 flex items-center justify-between text-xs">
      <span className="font-medium text-warning-foreground">
        🔍 Admin szimuláció: <strong>{label}</strong> nézet (csak UI – a jogosultságok nem változnak)
      </span>
      <button
        type="button"
        onClick={() => setMode("self")}
        className="text-xs font-semibold underline hover:no-underline"
      >
        Vissza saját nézetre
      </button>
    </div>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <ViewAsProvider>
      <div className="min-h-screen bg-background text-foreground flex w-full">
        <Sidebar />
        <main className="flex-1 flex flex-col min-w-0">
          <Header />
          <ViewAsBanner />
          <div className="flex-1 pb-16 lg:pb-0">{children}</div>
        </main>
        <AiAssistant />
        <MobileBottomNav
          onOpenMenu={() => window.dispatchEvent(new Event("medroster:open-mobile-nav"))}
        />
      </div>
    </ViewAsProvider>
  );
}

