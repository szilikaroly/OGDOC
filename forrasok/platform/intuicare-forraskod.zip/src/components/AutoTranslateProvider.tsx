/**
 * Auto-translates every visible Hungarian text node in the DOM to the
 * currently selected i18n language. Uses MutationObserver + batched
 * server calls + cache. Skips inputs, editable areas, scripts, code blocks,
 * and elements marked `data-no-translate`.
 *
 * This is the "make everything translatable" runtime layer that frees us
 * from refactoring every JSX literal into i18n keys.
 */
import { useEffect } from "react";
import { useTranslation } from "react-i18next";
import { translateBatch } from "@/lib/i18n/translate.functions";
import { recordTranslationError } from "@/lib/i18n/translation-errors";
import { supabase } from "@/integrations/supabase/client";

const HU_HINT = /[áéíóöőúüűÁÉÍÓÖŐÚÜŰ]/;
const SKIP_TAGS = new Set([
  "SCRIPT", "STYLE", "CODE", "PRE", "TEXTAREA", "INPUT", "NOSCRIPT", "SVG", "PATH",
]);

const processed = new WeakSet<Text>();
const sourceMap = new WeakMap<Text, string>();

function shouldSkip(node: Text): boolean {
  const parent = node.parentElement;
  if (!parent) return true;
  if (SKIP_TAGS.has(parent.tagName)) return true;
  if (parent.closest("[data-no-translate]")) return true;
  if (parent.closest("[contenteditable='true']")) return true;
  return false;
}

function isTranslatable(text: string): boolean {
  const t = text.trim();
  if (t.length < 2) return false;
  if (/^[\d\s\W]+$/.test(t)) return false;
  // Only Hungarian-ish content. Accept ASCII words too if there are multiple words,
  // but lean on the diacritic hint to keep noise low.
  return HU_HINT.test(t) || /[A-Za-z].*[A-Za-z]/.test(t);
}

function collectNodes(root: Node, out: Text[]) {
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  let n: Node | null;
  while ((n = walker.nextNode())) {
    const tn = n as Text;
    if (processed.has(tn)) continue;
    if (shouldSkip(tn)) continue;
    const text = tn.nodeValue ?? "";
    if (!isTranslatable(text)) continue;
    out.push(tn);
  }
}

export function AutoTranslateProvider() {
  const { i18n } = useTranslation();
  const lang = (i18n.language?.split("-")[0] ?? "hu");

  useEffect(() => {
    if (lang === "hu") return;
    if (typeof window === "undefined") return;

    let queue: Text[] = [];
    let timer: ReturnType<typeof setTimeout> | null = null;
    let mutating = false;

    async function flush() {
      timer = null;
      if (queue.length === 0) return;
      const batch = queue.slice(0, 100);
      queue = queue.slice(100);
      if (queue.length > 0) schedule();

      // Deduplicate by trimmed text
      const items: Array<{ key: string; source: string; namespace: string }> = [];
      const seen = new Map<string, Text[]>();
      for (const node of batch) {
        const raw = node.nodeValue ?? "";
        const trimmed = raw.trim();
        if (!trimmed) continue;
        sourceMap.set(node, raw);
        if (!seen.has(trimmed)) {
          seen.set(trimmed, []);
          items.push({ key: `txt_${hashString(trimmed)}`, source: trimmed, namespace: "auto" });
        }
        seen.get(trimmed)!.push(node);
      }
      if (items.length === 0) return;

      // Auto-translation requires an authenticated session (the server fn is
      // gated by requireSupabaseAuth). Silently skip on public/landing pages.
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) return;

      try {
        const result = await translateBatch({
          data: { items, target_lang: lang, kind: "ui", db_only: true },
        });

        mutating = true;
        for (const it of items) {
          const translation = (result as Record<string, string>)[it.key];
          if (!translation) continue;
          const nodes = seen.get(it.source) ?? [];
          for (const node of nodes) {
            try {
              const raw = node.nodeValue ?? "";
              const leading = raw.match(/^\s*/)?.[0] ?? "";
              const trailing = raw.match(/\s*$/)?.[0] ?? "";
              node.nodeValue = leading + translation + trailing;
              processed.add(node);
            } catch {
              /* ignore */
            }
          }
        }
        // Allow mutations after a tick so observer doesn't loop
        setTimeout(() => { mutating = false; }, 0);
      } catch (err: any) {
        recordTranslationError({
          lang,
          namespace: "auto",
          items,
          message: String(err?.message ?? err ?? "Ismeretlen hiba"),
        });
        mutating = false;
      }
    }

    function schedule() {
      if (timer) return;
      timer = setTimeout(flush, 400);
    }

    function enqueue(node: Node) {
      const buf: Text[] = [];
      collectNodes(node, buf);
      if (buf.length === 0) return;
      queue.push(...buf);
      schedule();
    }

    // Initial scan
    enqueue(document.body);

    const observer = new MutationObserver((mutations) => {
      if (mutating) return;
      for (const m of mutations) {
        if (m.type === "childList") {
          m.addedNodes.forEach((n) => enqueue(n));
        } else if (m.type === "characterData") {
          const t = m.target as Text;
          if (processed.has(t)) {
            // React re-rendered → invalidate so we retranslate the new content.
            processed.delete(t);
          }
          enqueue(t);
        }
      }
    });
    observer.observe(document.body, {
      subtree: true,
      childList: true,
      characterData: true,
    });

    return () => {
      observer.disconnect();
      if (timer) clearTimeout(timer);
    };
  }, [lang]);

  return null;
}

function hashString(s: string) {
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = ((h << 5) + h) ^ s.charCodeAt(i);
  return ((h >>> 0).toString(16) + s.length.toString(16)).slice(0, 16);
}
