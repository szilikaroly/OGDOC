import { useEffect, useState } from "react";
import { X, Plus, Trash2, Wand2, Loader2, FlaskConical, Sparkles, LayoutTemplate } from "lucide-react";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import type { DailyDemand } from "@/lib/scheduling/generate";
import { parseDemandFromText } from "@/lib/ai-schedule.functions";
import { ConflictHeatmap } from "./conflict-heatmap";
import { supabase } from "@/integrations/supabase/client";

type ShiftTemplate = {
  kulcs: "nappal" | "ugyelet" | "keszenlet";
  kezd: string;
  veg: string;
  kategoria: "rendes" | "ugyelet" | "keszenlet";
  fo: number;
};

const DEFAULT: ShiftTemplate[] = [
  { kulcs: "nappal", kezd: "08:00", veg: "16:00", kategoria: "rendes", fo: 2 },
  { kulcs: "ugyelet", kezd: "16:00", veg: "08:00", kategoria: "ugyelet", fo: 1 },
];

export function DemandEditor({
  weekStart,
  onClose,
  onGenerate,
  onDryRun,
  generating,
  tenantId,
  totalPeople,
}: {
  weekStart: string;
  onClose: () => void;
  onGenerate: (demand: DailyDemand[]) => Promise<void>;
  onDryRun?: (demand: DailyDemand[]) => Promise<{ inserted: number; hardViolations: number }>;
  generating: boolean;
  tenantId?: string | null;
  totalPeople?: number;
}) {
  const [tpl, setTpl] = useState<ShiftTemplate[]>(DEFAULT);
  const [days, setDays] = useState(7);
  const [preview, setPreview] = useState<{ inserted: number; hardViolations: number } | null>(null);
  const [previewing, setPreviewing] = useState(false);
  const [nl, setNl] = useState("");
  const [aiLoading, setAiLoading] = useState(false);
  const [aiHint, setAiHint] = useState<string | null>(null);
  const callAi = useServerFn(parseDemandFromText);
  const [orgUnits, setOrgUnits] = useState<Array<{ id: string; nev: string }>>([]);
  const [orgUnitId, setOrgUnitId] = useState<string>("");
  const [tplLoading, setTplLoading] = useState(false);
  const [loadedDemand, setLoadedDemand] = useState<DailyDemand[] | null>(null);

  useEffect(() => {
    if (!tenantId) return;
    void (async () => {
      const { data } = await supabase
        .from("org_units").select("id,nev").eq("tenant_id", tenantId).eq("aktiv", true).order("nev");
      setOrgUnits((data ?? []) as Array<{ id: string; nev: string }>);
    })();
  }, [tenantId]);

  async function loadFromTemplate() {
    if (!orgUnitId) return toast.error("Válasszon szervezeti egységet.");
    setTplLoading(true);
    try {
      const from = weekStart;
      const to = new Date(weekStart);
      to.setDate(to.getDate() + days - 1);
      const { data, error } = await (supabase as any).rpc("generate_demand_for_period", {
        _org_unit_id: orgUnitId,
        _from: from,
        _to: to.toISOString().slice(0, 10),
      });
      if (error) throw error;
      const rows = (data ?? []) as Array<{
        datum: string; kezd_ido: string; veg_ido: string; kategoria: string; min_letszam: number;
      }>;
      if (rows.length === 0) {
        toast.error("Az időszakra nincs sablon-igény. Hozzon létre sablont a Létszám-igény menüben.");
        setLoadedDemand(null);
        return;
      }
      // Aggregate by date+shift (sum min_letszam → fő)
      const byKey = new Map<string, { date: string; kezd: string; veg: string; kategoria: string; fo: number }>();
      for (const r of rows) {
        const kezd = String(r.kezd_ido).slice(0, 5);
        const veg = String(r.veg_ido).slice(0, 5);
        const k = `${r.datum}|${kezd}|${veg}|${r.kategoria}`;
        const cur = byKey.get(k);
        if (cur) cur.fo += Number(r.min_letszam || 0);
        else byKey.set(k, { date: r.datum, kezd, veg, kategoria: r.kategoria, fo: Number(r.min_letszam || 0) });
      }
      const byDate = new Map<string, DailyDemand>();
      for (const v of byKey.values()) {
        const d = byDate.get(v.date) ?? { date: v.date, shifts: [] };
        const kulcs: "nappal" | "ugyelet" | "keszenlet" =
          v.kategoria === "ugyelet" ? "ugyelet" : v.kategoria === "keszenlet" ? "keszenlet" : "nappal";
        d.shifts.push({ kulcs, kezd: v.kezd, veg: v.veg, kategoria: v.kategoria as any, fo: Math.max(1, v.fo) });
        byDate.set(v.date, d);
      }
      const demand = Array.from(byDate.values()).sort((a, b) => a.date.localeCompare(b.date));
      setLoadedDemand(demand);
      toast.success(`Sablon betöltve: ${demand.length} nap · ${rows.length} igény-sor`);
    } catch (e: any) {
      toast.error(e?.message ?? "Sablon betöltési hiba");
    } finally {
      setTplLoading(false);
    }
  }


  function update(i: number, patch: Partial<ShiftTemplate>) {
    setTpl((arr) => arr.map((x, idx) => (idx === i ? { ...x, ...patch } : x)));
  }

  async function runNlImport() {
    if (nl.trim().length < 10) return toast.error("Írjon legalább 10 karakteres leírást.");
    setAiLoading(true);
    try {
      const r = await callAi({ data: { text: nl } });
      setTpl(r.shifts);
      setDays(r.days);
      setAiHint(r.magyarazat);
      toast.success(`AI: ${r.shifts.length} műszak, ${r.days} nap`);
    } catch (e: any) {
      toast.error(e?.message ?? "AI hiba");
    } finally {
      setAiLoading(false);
    }
  }

  function buildDemand(): DailyDemand[] {
    if (loadedDemand && loadedDemand.length > 0) return loadedDemand;
    const demand: DailyDemand[] = [];
    const ws = new Date(weekStart);
    for (let i = 0; i < days; i++) {
      const d = new Date(ws); d.setDate(ws.getDate() + i);
      demand.push({ date: d.toISOString().slice(0, 10), shifts: tpl });
    }
    return demand;
  }

  async function generate() {
    setPreview(null);
    await onGenerate(buildDemand());
  }

  async function dryRun() {
    if (!onDryRun) return;
    setPreviewing(true);
    try {
      const r = await onDryRun(buildDemand());
      setPreview(r);
    } finally {
      setPreviewing(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-card border rounded-lg p-4 w-full max-w-2xl space-y-3" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between">
          <h3 className="font-semibold">Igény-szerkesztő · {weekStart}-tól</h3>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X className="h-4 w-4" /></button>
        </div>

        <div className="rounded border border-primary/30 bg-primary/5 p-2 space-y-1.5">
          <div className="text-xs font-medium flex items-center gap-2"><Sparkles className="h-3 w-3 text-primary" /> Természetes nyelvű igény → sablon</div>
          <textarea value={nl} onChange={(e) => setNl(e.target.value)} rows={2}
            placeholder='pl. "Hétfőtől péntekig 2 nappalos műszak 8-tól 16-ig, és minden nap 1 ügyelet 16-tól 8-ig."'
            className="w-full rounded border bg-background px-2 py-1 text-xs" />
          <div className="flex items-center gap-2">
            <button onClick={runNlImport} disabled={aiLoading} type="button"
              className="flex items-center gap-1 rounded bg-primary px-2 py-1 text-[11px] text-primary-foreground hover:opacity-90 disabled:opacity-50">
              {aiLoading ? <Loader2 className="h-3 w-3 animate-spin" /> : <Sparkles className="h-3 w-3" />} Értelmezés
            </button>
            {aiHint && <span className="text-[10px] text-muted-foreground italic">„{aiHint}"</span>}
          </div>
        </div>

        <div className="rounded border border-emerald-500/30 bg-emerald-500/5 p-2 space-y-1.5">
          <div className="text-xs font-medium flex items-center gap-2">
            <LayoutTemplate className="h-3 w-3 text-emerald-600" /> Igények sablonból (létszám-igény szerkesztő)
          </div>
          <div className="flex items-center gap-2">
            <select
              value={orgUnitId}
              onChange={(e) => setOrgUnitId(e.target.value)}
              className="rounded border bg-background px-2 py-1 text-xs flex-1"
            >
              <option value="">— Szervezeti egység —</option>
              {orgUnits.map((u) => <option key={u.id} value={u.id}>{u.nev}</option>)}
            </select>
            <button onClick={loadFromTemplate} disabled={tplLoading || !orgUnitId} type="button"
              className="flex items-center gap-1 rounded bg-emerald-600 px-2 py-1 text-[11px] text-white hover:opacity-90 disabled:opacity-50">
              {tplLoading ? <Loader2 className="h-3 w-3 animate-spin" /> : <LayoutTemplate className="h-3 w-3" />} Betöltés
            </button>
            {loadedDemand && (
              <button onClick={() => setLoadedDemand(null)} type="button"
                className="text-[10px] underline text-muted-foreground hover:text-foreground">
                Visszaállítás (sablon törlése)
              </button>
            )}
          </div>
          {loadedDemand && (
            <div className="text-[10px] text-emerald-700 dark:text-emerald-300">
              ✓ Sablon-igény aktív: {loadedDemand.length} nap ·{" "}
              {loadedDemand.reduce((s, d) => s + d.shifts.reduce((x, sh) => x + sh.fo, 0), 0)} fő-műszak.
              A lenti kézi sablon átmenetileg figyelmen kívül marad.
            </div>
          )}
        </div>


        <label className="text-xs block">Napok száma
          <input type="number" min={1} max={31} value={days} onChange={(e) => setDays(Math.max(1, Math.min(31, parseInt(e.target.value) || 1)))} className="ml-2 w-20 rounded border bg-background px-2 py-1 text-sm" />
        </label>

        <div className="space-y-2">
          <div className="text-xs font-medium text-muted-foreground">Napi műszak-sablon (minden napra érvényes)</div>
          {tpl.map((s, i) => (
            <div key={i} className="grid grid-cols-6 gap-1 items-end">
              <label className="text-[10px]">Kulcs
                <select value={s.kulcs} onChange={(e) => update(i, { kulcs: e.target.value as any })} className="w-full rounded border bg-background px-1 py-1 text-xs">
                  <option value="nappal">nappal</option>
                  <option value="ugyelet">ugyelet</option>
                  <option value="keszenlet">keszenlet</option>
                </select>
              </label>
              <label className="text-[10px]">Kezdés
                <input type="time" value={s.kezd} onChange={(e) => update(i, { kezd: e.target.value })} className="w-full rounded border bg-background px-1 py-1 text-xs" />
              </label>
              <label className="text-[10px]">Vég
                <input type="time" value={s.veg} onChange={(e) => update(i, { veg: e.target.value })} className="w-full rounded border bg-background px-1 py-1 text-xs" />
              </label>
              <label className="text-[10px]">Kategória
                <select value={s.kategoria} onChange={(e) => update(i, { kategoria: e.target.value as any })} className="w-full rounded border bg-background px-1 py-1 text-xs">
                  <option value="rendes">rendes</option>
                  <option value="ugyelet">ugyelet</option>
                  <option value="keszenlet">keszenlet</option>
                </select>
              </label>
              <label className="text-[10px]">Fő
                <input type="number" min={1} value={s.fo} onChange={(e) => update(i, { fo: Math.max(1, parseInt(e.target.value) || 1) })} className="w-full rounded border bg-background px-1 py-1 text-xs" />
              </label>
              <button onClick={() => setTpl((arr) => arr.filter((_, idx) => idx !== i))} className="rounded border px-1 py-1 text-rose-600 hover:bg-background">
                <Trash2 className="h-3 w-3" />
              </button>
            </div>
          ))}
          <button onClick={() => setTpl((arr) => [...arr, { kulcs: "nappal", kezd: "08:00", veg: "16:00", kategoria: "rendes", fo: 1 }])}
            className="text-xs flex items-center gap-1 rounded border px-2 py-1 hover:bg-accent">
            <Plus className="h-3 w-3" /> Műszak hozzáadása
          </button>
        </div>

        {tenantId && totalPeople !== undefined && (
          <ConflictHeatmap
            tenantId={tenantId}
            weekStart={weekStart}
            days={days}
            shifts={tpl}
            totalPeople={totalPeople}
          />
        )}

        {preview && (
          <div className="rounded border bg-muted/40 px-2 py-1.5 text-xs flex items-center gap-3">
            <FlaskConical className="h-3 w-3 text-primary" />
            <span>Próbafuttatás eredménye:</span>
            <span className="font-mono">{preview.inserted} műszak</span>
            <span className={preview.hardViolations > 0 ? "text-rose-600 font-semibold" : "text-emerald-600"}>
              ⚠ {preview.hardViolations} sértés
            </span>
          </div>
        )}

        <div className="flex justify-end gap-2 pt-2 border-t">
          <button onClick={onClose} className="rounded border px-3 py-1.5 text-sm hover:bg-accent">Mégse</button>
          {onDryRun && (
            <button onClick={dryRun} disabled={previewing || generating || tpl.length === 0}
              className="flex items-center gap-1 rounded border px-3 py-1.5 text-sm hover:bg-accent disabled:opacity-50">
              {previewing ? <Loader2 className="h-3 w-3 animate-spin" /> : <FlaskConical className="h-3 w-3" />} Próba
            </button>
          )}
          <button onClick={generate} disabled={generating || tpl.length === 0}
            className="flex items-center gap-1 rounded bg-primary px-3 py-1.5 text-sm text-primary-foreground hover:opacity-90 disabled:opacity-50">
            {generating ? <Loader2 className="h-3 w-3 animate-spin" /> : <Wand2 className="h-3 w-3" />} Generálás
          </button>
        </div>

      </div>
    </div>
  );
}
