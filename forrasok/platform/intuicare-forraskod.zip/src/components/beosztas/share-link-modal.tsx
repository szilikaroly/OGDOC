import { useEffect, useState } from "react";
import { Link2, X, Copy, Trash2, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

type Token = {
  id: string;
  token: string;
  scope_month: string;
  expires_at: string;
  created_at: string;
  revoked_at: string | null;
};

function randomToken(): string {
  const arr = new Uint8Array(24);
  crypto.getRandomValues(arr);
  return Array.from(arr).map((b) => b.toString(36).padStart(2, "0")).join("").slice(0, 32);
}

export function ShareLinkModal({
  tenantId,
  userId,
  monthStart,
  onClose,
}: {
  tenantId: string;
  userId: string;
  monthStart: Date;
  onClose: () => void;
}) {
  const [tokens, setTokens] = useState<Token[]>([]);
  const [loading, setLoading] = useState(true);
  const [days, setDays] = useState<number>(7);
  const [creating, setCreating] = useState(false);
  const monthIso = `${monthStart.getFullYear()}-${String(monthStart.getMonth() + 1).padStart(2, "0")}-01`;

  async function load() {
    setLoading(true);
    const { data } = await supabase
      .from("schedule_share_tokens")
      .select("id,token,scope_month,expires_at,created_at,revoked_at")
      .eq("scope_month", monthIso)
      .order("created_at", { ascending: false });
    setTokens((data ?? []) as Token[]);
    setLoading(false);
  }

  useEffect(() => { void load(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [monthIso]);

  async function createLink() {
    setCreating(true);
    const token = randomToken();
    const expires = new Date(Date.now() + days * 24 * 60 * 60 * 1000).toISOString();
    const { error } = await (supabase.from("schedule_share_tokens") as any).insert({
      tenant_id: tenantId,
      token,
      scope_month: monthIso,
      expires_at: expires,
      created_by: userId,
    });
    setCreating(false);
    if (error) { toast.error(error.message); return; }
    toast.success("Megosztó link létrehozva");
    await load();
  }

  async function revoke(id: string) {
    const { error } = await (supabase.from("schedule_share_tokens") as any)
      .update({ revoked_at: new Date().toISOString() })
      .eq("id", id);
    if (error) { toast.error(error.message); return; }
    toast.success("Visszavonva");
    await load();
  }

  function copyUrl(token: string) {
    const url = `${window.location.origin}/share/schedule/${token}`;
    navigator.clipboard.writeText(url);
    toast.success("URL vágólapra másolva");
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={onClose}>
      <div className="bg-card border rounded-lg max-w-2xl w-full max-h-[80vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="p-4 border-b flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Link2 className="h-5 w-5 text-primary" />
            <h2 className="font-semibold">Beosztás megosztása · {monthStart.toLocaleString("hu-HU", { year: "numeric", month: "long" })}</h2>
          </div>
          <button onClick={onClose}><X className="h-4 w-4" /></button>
        </div>

        <div className="p-4 space-y-4">
          <div className="rounded border bg-muted/40 p-3 text-xs text-muted-foreground">
            A megosztott link csak olvasható, csak ezt a hónapot tartalmazza, és nem tartalmaz személyes/azonosító adatot (TAJ, email, telefon).
          </div>

          <div className="flex items-end gap-2">
            <div>
              <label className="text-xs text-muted-foreground">Érvényesség</label>
              <select
                value={days}
                onChange={(e) => setDays(Number(e.target.value))}
                className="block rounded border bg-background px-2 py-1.5 text-sm"
              >
                <option value={1}>1 nap</option>
                <option value={7}>7 nap</option>
                <option value={30}>30 nap</option>
              </select>
            </div>
            <button
              onClick={createLink}
              disabled={creating}
              className="rounded bg-primary px-3 py-1.5 text-sm text-primary-foreground hover:opacity-90 disabled:opacity-50"
            >
              {creating ? "..." : "Új link létrehozása"}
            </button>
          </div>

          <div>
            <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Aktív és korábbi linkek</h3>
            {loading ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : tokens.length === 0 ? (
              <div className="text-sm text-muted-foreground italic">Nincs még megosztott link erre a hónapra.</div>
            ) : (
              <ul className="space-y-2">
                {tokens.map((t) => {
                  const expired = new Date(t.expires_at).getTime() < Date.now();
                  const active = !t.revoked_at && !expired;
                  return (
                    <li key={t.id} className="rounded border p-2 flex items-center justify-between text-xs">
                      <div className="space-y-0.5 min-w-0">
                        <div className="font-mono truncate max-w-md">{`${window.location.origin}/share/schedule/${t.token}`}</div>
                        <div className="text-muted-foreground">
                          Létrehozva: {new Date(t.created_at).toLocaleString("hu-HU")} · Lejár: {new Date(t.expires_at).toLocaleString("hu-HU")}
                          {t.revoked_at && <span className="ml-2 text-rose-600">visszavonva</span>}
                          {expired && !t.revoked_at && <span className="ml-2 text-rose-600">lejárt</span>}
                          {active && <span className="ml-2 text-emerald-600">aktív</span>}
                        </div>
                      </div>
                      <div className="flex items-center gap-1 ml-2 shrink-0">
                        <button onClick={() => copyUrl(t.token)} className="p-1 rounded hover:bg-accent" title="URL másolása">
                          <Copy className="h-3.5 w-3.5" />
                        </button>
                        {active && (
                          <button onClick={() => revoke(t.id)} className="p-1 rounded hover:bg-accent text-rose-600" title="Visszavonás">
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        )}
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
