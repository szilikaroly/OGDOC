import { useEffect, useState } from "react";
import { Loader2, Trash2, History, RefreshCcw, X, BarChart3, Send } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { humanizeError } from "@/lib/humanize-error";
import { useTranslation } from "react-i18next";
import { cn } from "@/lib/utils";

type Run = {
  id: string;
  idoszak_kezdet: string;
  idoszak_veg: string;
  solver: string;
  status: string;
  hard_sertes_szam: number;
  lagy_pontszam: number;
  created_at: string;
};

type PublishSummary = {
  runId: string;
  notified: number;
  assignments: number;
  uniqueUsers: number;
  period: string;
};

export function RunsPanel({ tenantId, canEdit, onChanged }: { tenantId: string; canEdit: boolean; onChanged: () => void }) {
  const { t } = useTranslation();
  const [runs, setRuns] = useState<Run[]>([]);
  const [loading, setLoading] = useState(true);
  const [openRun, setOpenRun] = useState<Run | null>(null);
  const [publishSummary, setPublishSummary] = useState<PublishSummary | null>(null);

  async function load() {
    setLoading(true);
    const { data, error } = await supabase
      .from("schedule_runs")
      .select("id,idoszak_kezdet,idoszak_veg,solver,status,hard_sertes_szam,lagy_pontszam,created_at")
      .eq("tenant_id", tenantId)
      .order("created_at", { ascending: false })
      .limit(10);
    if (error) toast.error(humanizeError(error, t));
    setRuns((data ?? []) as Run[]);
    setLoading(false);
  }

  useEffect(() => { void load(); }, [tenantId]);

  async function rollback(id: string) {
    if (!confirm("Visszavonja ezt a futtatást? A kapcsolódó (nem pinnelt) beosztások törlődnek.")) return;
    const { error: e1 } = await supabase.from("schedule_assignments").delete().eq("run_id", id).eq("pin", false);
    if (e1) return toast.error(humanizeError(e1, t));
    const { error: e2 } = await (supabase.from("schedule_runs") as any).update({ status: "elvetett" }).eq("id", id);
    if (e2) return toast.error(humanizeError(e2, t));
    toast.success("Visszavonva");
    void load();
    onChanged();
  }

  async function publish(id: string) {
    if (!confirm("Közzéteszi a beosztást? Minden érintett munkatárs értesítést kap.")) return;
    // Pre-fetch assignment stats so we can show what was affected
    const { data: aRows, error: aErr } = await supabase
      .from("schedule_assignments")
      .select("user_id")
      .eq("run_id", id);
    if (aErr) return toast.error(humanizeError(aErr, t));
    const assignments = aRows?.length ?? 0;
    const uniqueUsers = new Set((aRows ?? []).map((r: any) => r.user_id).filter(Boolean)).size;

    const { data, error } = await (supabase as any).rpc("publish_schedule_run", { _run_id: id });
    if (error) return toast.error(humanizeError(error, t));
    const row = Array.isArray(data) ? data[0] : data;
    const notified = Number(row?.notified_count ?? 0);
    const run = runs.find((r) => r.id === id);
    const period = run ? `${run.idoszak_kezdet} → ${run.idoszak_veg}` : "";

    if (notified !== uniqueUsers) {
      toast.warning(
        `Eltérés: ${uniqueUsers} egyedi user az assignment-ekben, de ${notified} értesítés ment ki.`
      );
    } else {
      toast.success(`Közzétéve · ${notified} értesítés / ${assignments} beosztás`);
    }
    setPublishSummary({ runId: id, notified, assignments, uniqueUsers, period });
    void load();
    onChanged();
  }

  return (
    <div className="rounded-lg border bg-card p-3 space-y-2">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-sm font-semibold"><History className="h-4 w-4" /> Solver futtatások</div>
        <button onClick={load} className="p-1 rounded hover:bg-accent"><RefreshCcw className="h-3 w-3" /></button>
      </div>
      {loading ? (
        <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
      ) : runs.length === 0 ? (
        <div className="text-xs text-muted-foreground italic">Még nincs futtatás.</div>
      ) : (
        <ul className="space-y-1 text-xs">
          {runs.map((r) => (
            <li key={r.id} className="flex items-center gap-2 rounded border px-2 py-1 hover:bg-accent/30 cursor-pointer"
                onClick={() => setOpenRun(r)}>
              <span className={cn("font-mono px-1.5 rounded text-[10px]",
                r.status === "kesz" && "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300",
                r.status === "publikalt" && "bg-primary/15 text-primary",
                r.status === "elvetett" && "bg-muted text-muted-foreground line-through",
                r.status === "hibas" && "bg-rose-500/15 text-rose-700")}>{r.status}</span>
              <span className="font-mono">{r.idoszak_kezdet}→{r.idoszak_veg}</span>
              <span className="text-muted-foreground">{r.solver}</span>
              <span className="ml-auto">⚠ {r.hard_sertes_szam} · ∑{Number(r.lagy_pontszam).toFixed(0)}h</span>
              {canEdit && r.status === "kesz" && (
                <>
                  <button onClick={(e) => { e.stopPropagation(); publish(r.id); }} className="p-1 rounded hover:bg-background text-primary" title="Közzététel (értesítések kiküldése)">
                    <Send className="h-3 w-3" />
                  </button>
                  <button onClick={(e) => { e.stopPropagation(); rollback(r.id); }} className="p-1 rounded hover:bg-background text-rose-600" title="Visszavonás">
                    <Trash2 className="h-3 w-3" />
                  </button>
                </>
              )}
            </li>
          ))}
        </ul>
      )}
      {openRun && <RunDetailsModal run={openRun} onClose={() => setOpenRun(null)} />}
      {publishSummary && <PublishSummaryModal s={publishSummary} onClose={() => setPublishSummary(null)} />}
    </div>
  );
}

function PublishSummaryModal({ s, onClose }: { s: PublishSummary; onClose: () => void }) {
  const mismatch = s.notified !== s.uniqueUsers;
  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-card border rounded-lg p-4 w-full max-w-md space-y-3" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between">
          <h3 className="font-semibold flex items-center gap-2"><Send className="h-4 w-4 text-primary" /> Közzététel összesítő</h3>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X className="h-4 w-4" /></button>
        </div>
        {s.period && <div className="text-xs text-muted-foreground font-mono">{s.period}</div>}
        <div className="grid grid-cols-3 gap-2 text-xs">
          <div className="rounded border p-2 bg-muted/30">
            <div className="text-muted-foreground">Beosztások</div>
            <div className="text-lg font-mono font-semibold">{s.assignments}</div>
          </div>
          <div className="rounded border p-2 bg-muted/30">
            <div className="text-muted-foreground">Érintett user</div>
            <div className="text-lg font-mono font-semibold">{s.uniqueUsers}</div>
          </div>
          <div className={cn("rounded border p-2", mismatch ? "border-amber-500/50 bg-amber-500/10" : "border-emerald-500/40 bg-emerald-500/10")}>
            <div className="text-muted-foreground">Értesítés</div>
            <div className="text-lg font-mono font-semibold">{s.notified}</div>
          </div>
        </div>
        {mismatch ? (
          <div className="text-xs rounded border border-amber-500/50 bg-amber-500/10 p-2">
            ⚠ Eltérés: az érintett egyedi user-ek száma ({s.uniqueUsers}) nem egyezik a kiküldött értesítésekkel ({s.notified}). Ellenőrizd a futás assignment-jeit.
          </div>
        ) : (
          <div className="text-xs rounded border border-emerald-500/40 bg-emerald-500/10 p-2">
            ✓ Minden érintett munkatárs egy-egy értesítést kapott, duplikáció nélkül.
          </div>
        )}
        <button onClick={onClose} className="w-full text-xs rounded border px-3 py-1.5 hover:bg-accent">Bezárás</button>
      </div>
    </div>
  );
}

function RunDetailsModal({ run, onClose }: { run: Run; onClose: () => void }) {
  const [agg, setAgg] = useState<Array<{ szint: string; kulcs: string; count: number; sample: string }>>([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("schedule_explanations")
        .select("szint,kulcs,szoveg")
        .eq("run_id", run.id);
      const m = new Map<string, { szint: string; kulcs: string; count: number; sample: string }>();
      for (const e of (data ?? []) as Array<{ szint: string; kulcs: string; szoveg: string }>) {
        const k = `${e.szint}|${e.kulcs}`;
        const cur = m.get(k);
        if (cur) cur.count++;
        else m.set(k, { szint: e.szint, kulcs: e.kulcs, count: 1, sample: e.szoveg });
      }
      setAgg(Array.from(m.values()).sort((a, b) =>
        a.szint === b.szint ? b.count - a.count :
        (a.szint === "sertes" ? -1 : a.szint === "figyelmeztetes" ? 0 : 1) -
        (b.szint === "sertes" ? -1 : b.szint === "figyelmeztetes" ? 0 : 1)
      ));
      setLoading(false);
    })();
  }, [run.id]);

  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-card border rounded-lg p-4 w-full max-w-xl space-y-3 max-h-[80vh] overflow-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between">
          <h3 className="font-semibold flex items-center gap-2">
            <BarChart3 className="h-4 w-4" /> Futtatás részletek · {run.idoszak_kezdet}→{run.idoszak_veg}
          </h3>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X className="h-4 w-4" /></button>
        </div>
        <div className="text-xs grid grid-cols-3 gap-2 border rounded p-2 bg-muted/30">
          <div><div className="text-muted-foreground">Solver</div><div className="font-mono">{run.solver}</div></div>
          <div><div className="text-muted-foreground">Hard sértés</div><div className="font-mono text-rose-600">{run.hard_sertes_szam}</div></div>
          <div><div className="text-muted-foreground">∑ óra</div><div className="font-mono">{Number(run.lagy_pontszam).toFixed(1)}h</div></div>
        </div>
        {loading ? (
          <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
        ) : agg.length === 0 ? (
          <div className="text-xs italic text-muted-foreground">Nincs rögzített magyarázat.</div>
        ) : (
          <ul className="space-y-1 text-xs">
            {agg.map((e) => (
              <li key={`${e.szint}|${e.kulcs}`} className={cn("rounded border px-2 py-1.5",
                e.szint === "sertes" && "border-rose-500/40 bg-rose-500/10",
                e.szint === "figyelmeztetes" && "border-amber-500/40 bg-amber-500/10",
                e.szint === "info" && "border-muted bg-muted/30")}>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-[10px] opacity-70">{e.szint}</span>
                  <span className="font-mono text-[10px]">{e.kulcs}</span>
                  <span className="ml-auto font-mono font-semibold">×{e.count}</span>
                </div>
                <div className="text-muted-foreground italic mt-0.5">{e.sample}</div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

export function CellExplanations({ userId, date }: { userId: string; date: string }) {
  const [items, setItems] = useState<Array<{ id: string; szint: string; kulcs: string; szoveg: string; created_at: string }>>([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    let on = true;
    (async () => {
      setLoading(true);
      const { data } = await supabase
        .from("schedule_explanations")
        .select("id,szint,kulcs,szoveg,created_at")
        .eq("user_id", userId)
        .eq("datum", date)
        .order("created_at", { ascending: false })
        .limit(20);
      if (on) {
        setItems((data ?? []) as any);
        setLoading(false);
      }
    })();
    return () => { on = false; };
  }, [userId, date]);

  if (loading) return <Loader2 className="h-3 w-3 animate-spin text-muted-foreground" />;
  if (items.length === 0) return <div className="text-xs italic text-muted-foreground">Nincs magyarázat erre a napra.</div>;
  return (
    <ul className="space-y-1 text-xs max-h-40 overflow-auto">
      {items.map((e) => (
        <li key={e.id} className={cn("rounded border px-2 py-1",
          e.szint === "sertes" && "border-rose-500/40 bg-rose-500/10",
          e.szint === "figyelmeztetes" && "border-amber-500/40 bg-amber-500/10",
          e.szint === "info" && "border-muted bg-muted/30")}>
          <span className="font-mono text-[10px] mr-1 opacity-70">{e.kulcs}</span>
          {e.szoveg}
        </li>
      ))}
    </ul>
  );
}
