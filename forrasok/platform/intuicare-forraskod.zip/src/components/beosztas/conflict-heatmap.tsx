import { useEffect, useMemo, useState } from "react";
import { Loader2, Activity } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";

type ShiftTpl = { fo: number; kategoria: string };

/**
 * Pre-flight heatmap: minden napra megjeleníti
 *   - szükséges fő (igény-sablonból)
 *   - elérhető fő = aktív munkatársak − jóváhagyott/elbírálatlan távollévők
 *   - státusz: zöld (bőven), sárga (épp elég), piros (alulterhelt)
 */
export function ConflictHeatmap({
  tenantId,
  weekStart,
  days,
  shifts,
  totalPeople,
}: {
  tenantId: string;
  weekStart: string;
  days: number;
  shifts: ShiftTpl[];
  totalPeople: number;
}) {
  const [loading, setLoading] = useState(true);
  const [unavailByDay, setUnavailByDay] = useState<Map<string, number>>(new Map());

  const dateList = useMemo(() => {
    const out: string[] = [];
    const ws = new Date(weekStart);
    for (let i = 0; i < days; i++) {
      const d = new Date(ws);
      d.setDate(ws.getDate() + i);
      out.push(d.toISOString().slice(0, 10));
    }
    return out;
  }, [weekStart, days]);

  const demandPerDay = useMemo(
    () => shifts.reduce((s, x) => s + Number(x.fo || 0), 0),
    [shifts],
  );

  useEffect(() => {
    let cancelled = false;
    async function load() {
      setLoading(true);
      const first = dateList[0];
      const last = dateList[dateList.length - 1];
      const { data } = await supabase
        .from("profile_unavailability")
        .select("user_id,kezdo_datum,zaro_datum,status")
        .eq("tenant_id", tenantId)
        .in("status", ["jovahagyott", "jovahagyasra_var"])
        .lte("kezdo_datum", last)
        .gte("zaro_datum", first);
      if (cancelled) return;
      const m = new Map<string, Set<string>>();
      for (const d of dateList) m.set(d, new Set());
      for (const u of (data ?? []) as Array<{ user_id: string; kezdo_datum: string; zaro_datum: string }>) {
        for (const d of dateList) {
          if (d >= u.kezdo_datum && d <= u.zaro_datum) m.get(d)!.add(u.user_id);
        }
      }
      const counts = new Map<string, number>();
      m.forEach((s, k) => counts.set(k, s.size));
      setUnavailByDay(counts);
      setLoading(false);
    }
    void load();
    return () => { cancelled = true; };
  }, [tenantId, dateList]);

  if (loading) {
    return (
      <div className="rounded border bg-muted/40 p-2 text-xs flex items-center gap-2">
        <Loader2 className="h-3 w-3 animate-spin" /> Konfliktus-elemzés…
      </div>
    );
  }

  return (
    <div className="rounded border bg-muted/30 p-2 space-y-1.5">
      <div className="text-xs font-medium flex items-center gap-1.5">
        <Activity className="h-3 w-3 text-primary" />
        Konfliktus-előrejelzés ({demandPerDay} fő/nap igény · {totalPeople} aktív munkatárs)
      </div>
      <div className="grid gap-0.5" style={{ gridTemplateColumns: `repeat(${dateList.length}, minmax(0, 1fr))` }}>
        {dateList.map((d) => {
          const dt = new Date(d);
          const unavail = unavailByDay.get(d) ?? 0;
          const avail = Math.max(0, totalPeople - unavail);
          const ratio = demandPerDay === 0 ? 0 : avail / demandPerDay;
          const status =
            avail < demandPerDay ? "bg-rose-500/60 text-white" :
            ratio < 1.3 ? "bg-amber-500/60 text-white" :
            "bg-emerald-500/40 text-emerald-950 dark:text-emerald-50";
          const dow = dt.getDay();
          return (
            <div
              key={d}
              className={cn("rounded p-1 text-center text-[10px] leading-tight", status, (dow === 0 || dow === 6) && "ring-1 ring-inset ring-foreground/10")}
              title={`${d}: ${avail} elérhető / ${demandPerDay} kell · ${unavail} távol`}
            >
              <div className="font-mono">{dt.getDate()}</div>
              <div className="font-mono">{avail}/{demandPerDay}</div>
              {unavail > 0 && <div className="text-[9px] opacity-80">−{unavail}</div>}
            </div>
          );
        })}
      </div>
      <div className="text-[10px] text-muted-foreground flex items-center gap-3">
        <span className="flex items-center gap-1"><span className="inline-block w-2 h-2 rounded bg-emerald-500/60" /> bőven</span>
        <span className="flex items-center gap-1"><span className="inline-block w-2 h-2 rounded bg-amber-500/60" /> szoros</span>
        <span className="flex items-center gap-1"><span className="inline-block w-2 h-2 rounded bg-rose-500/60" /> alulterhelt</span>
      </div>
    </div>
  );
}
