/**
 * Lightweight geofence visualization using OpenStreetMap embed (no extra deps).
 * Shows a marker for the anchor center; the circle radius is conveyed in the caption.
 */
export function AnchorMap({
  lat,
  lng,
  radiusM,
  label,
}: {
  lat: number;
  lng: number;
  radiusM: number | null;
  label?: string;
}) {
  // Compute a reasonable bbox roughly covering 2× the radius (fallback 300m).
  const r = Math.max(radiusM ?? 100, 100) * 2;
  const dLat = r / 111_320;
  const dLng = r / (111_320 * Math.cos((lat * Math.PI) / 180) || 1);
  const bbox = [lng - dLng, lat - dLat, lng + dLng, lat + dLat].join("%2C");
  const src = `https://www.openstreetmap.org/export/embed.html?bbox=${bbox}&layer=mapnik&marker=${lat}%2C${lng}`;
  return (
    <div className="space-y-1">
      <iframe
        title={label ?? "Geofence térkép"}
        src={src}
        className="w-full h-48 rounded border bg-muted"
        loading="lazy"
      />
      <div className="text-[10px] text-muted-foreground font-mono">
        {lat.toFixed(6)}, {lng.toFixed(6)} · sugár ~{radiusM ?? 0} m
      </div>
    </div>
  );
}
