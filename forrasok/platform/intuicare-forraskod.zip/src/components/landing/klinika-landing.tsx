/**
 * Klinika landing page – SZTE Szülészeti és Nőgyógyászati Klinika mintájára.
 * Statikus, magyar nyelvű, scrollozható egyoldalas bemutató.
 * A bejelentkezés kizárólag a /auth oldalon történik.
 */
import { Link } from "@tanstack/react-router";
import { useCurrentUserTarget } from "@/hooks/use-current-user-target";
import {
  ArrowRight,
  Phone,
  MapPin,
  Mail,
  Clock,
  GraduationCap,
  Stethoscope,
  Baby,
  HeartPulse,
  FlaskConical,
  // Building2 reserved for future use
  Newspaper,
  Briefcase,
  ShieldCheck,
  ExternalLink,
  Facebook,
  Youtube,
  Linkedin,
  Instagram,
  FileText,
  Users,
  CalendarCheck,
  Search,
  Award,
  Activity,
} from "lucide-react";
import { SmartImage } from "@/components/ui/smart-image";

import heroImg from "@/assets/klinika-hero.jpg";

const EMERGENCY_TEL = "+3662545486";
const SWITCHBOARD_TEL = "+3662545499";

const NAV = [
  { label: "Bemutatkozás", href: "#bemutatkozas" },
  { label: "Betegellátás", href: "#betegellatas" },
  { label: "Foeto-Maternalis", href: "#foeto" },
  { label: "Munkatársak", href: "#munkatarsak" },
  { label: "Oktatás", href: "#oktatas" },
  { label: "Hírek", href: "#hirek" },
  { label: "GYIK", href: "#gyik" },
  { label: "Kapcsolat", href: "#kapcsolat" },
];

/**
 * Szerepkör-érzékeny "Belépés / Saját fiók" link. Vendégnek /auth-ra,
 * bejelentkezettnek a szerepkörének megfelelő dashboardra navigál.
 */
function AccountLink({ className, label }: { className?: string; label?: string }) {
  const { isAuthenticated, target } = useCurrentUserTarget();
  if (isAuthenticated && target) {
    return (
      <Link to={target} className={className}>
        {label ?? "Saját fiók"} <ArrowRight className="size-4" />
      </Link>
    );
  }
  return (
    <Link to="/auth" className={className}>
      {label ?? "Belépés"} <ArrowRight className="size-4" />
    </Link>
  );
}

export function KlinikaLanding() {
  return (
    <div className="min-h-screen bg-background text-foreground font-sans">
      <TopUtilityBar />
      <SiteHeader />
      <MainNav />
      <main>
        <Hero />
        <Bemutatkozas />
        <Szamok />
        <FoetoMaternalis />
        <Betegellatas />
        <Munkatarsak />
        <OktatasKutatas />
        <Hirek />
        <Projektek />
        <Allas />
        <HasznosLinkek />
        <Gyik />
        <Kapcsolat />
      </main>
      <SiteFooter />
    </div>
  );
}

/* ---------- top bar ---------- */
function TopUtilityBar() {
  return (
    <div className="bg-[#0a1530] text-white/70 text-[11px]">
      <div className="max-w-7xl mx-auto px-3 sm:px-4 py-1.5 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3 sm:gap-4 overflow-x-auto scrollbar-none min-w-0">
          <a href="https://u-szeged.hu" target="_blank" rel="noopener" className="hover:text-white whitespace-nowrap">SZTE főoldal</a>
          <a href="#" className="hover:text-white whitespace-nowrap">Neptun</a>
          <a href="#" className="hover:text-white whitespace-nowrap">CooSpace</a>
          <a href="#" className="hidden sm:inline hover:text-white whitespace-nowrap">Telefonkönyv</a>
          <a href="#" className="hidden sm:inline hover:text-white whitespace-nowrap">Adatvédelem</a>
          <a href="#" className="hidden md:inline hover:text-white whitespace-nowrap">Közérdekű adatok</a>
        </div>
        <div className="flex items-center gap-2 sm:gap-3 whitespace-nowrap shrink-0">
          <button className="hidden sm:inline hover:text-white" aria-label="Nagy kontraszt mód">Nagy kontraszt</button>
          <span className="hidden sm:inline opacity-30">|</span>
          <a href="#" className="hover:text-white" aria-label="English version">EN</a>
        </div>
      </div>
    </div>
  );
}

/* ---------- header with crest ---------- */
function SiteHeader() {
  return (
    <header className="bg-[#0f1b3d] text-white">
      <div className="max-w-7xl mx-auto px-3 sm:px-4 py-4 sm:py-6 grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4">
        <div className="flex min-w-0 items-center gap-3 sm:gap-5">
          {/* Címer – egyszerű SVG pajzs */}
          <div className="shrink-0">
            <svg viewBox="0 0 64 80" className="w-10 h-12 sm:w-14 sm:h-16" aria-hidden="true">
              <path
                d="M32 2 L60 12 L60 40 C60 60 46 72 32 78 C18 72 4 60 4 40 L4 12 Z"
                fill="none"
                stroke="#c9a84c"
                strokeWidth="2"
              />
              <text x="32" y="46" textAnchor="middle" fill="#c9a84c" fontSize="9" fontFamily="serif">
                VVL
              </text>
            </svg>
          </div>
          <div className="min-w-0">
            <div className="text-[10px] sm:text-[11px] font-mono uppercase tracking-[0.18em] sm:tracking-[0.2em] text-[#c9a84c] truncate">
              Szent-Györgyi Albert Klinikai Központ
            </div>
            <h1 className="font-serif text-lg sm:text-2xl md:text-3xl leading-tight mt-0.5 sm:mt-1">
              Szülészeti és Nőgyógyászati Klinika
            </h1>
          </div>
        </div>
        <AccountLink className="hidden md:inline-flex items-center gap-2 px-4 py-2 rounded border border-[#c9a84c]/60 text-[#c9a84c] text-sm font-semibold hover:bg-[#c9a84c] hover:text-[#0f1b3d] transition-colors min-h-11" />
      </div>
    </header>
  );
}

/* ---------- main sticky nav ---------- */
function MainNav() {
  return (
    <nav className="sticky top-0 z-30 bg-[#1e3a5f] text-white shadow-md">
      <div className="max-w-7xl mx-auto px-2 sm:px-4 flex items-center gap-0.5 sm:gap-1 overflow-x-auto scrollbar-none snap-x snap-mandatory">
        {NAV.map((n) => (
          <a
            key={n.href}
            href={n.href}
            className="snap-start px-3 sm:px-4 py-3 min-h-11 inline-flex items-center text-[11px] sm:text-xs font-semibold uppercase tracking-wider hover:bg-[#0f1b3d] whitespace-nowrap transition-colors"
          >
            {n.label}
          </a>
        ))}
        <AccountLink
          className="md:hidden ml-auto px-3 sm:px-4 py-3 min-h-11 inline-flex items-center gap-1 text-[11px] sm:text-xs font-semibold uppercase tracking-wider text-[#c9a84c]"
        />
      </div>
    </nav>
  );
}

/* ---------- hero ---------- */
function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div className="absolute inset-0">
        <SmartImage
          src={heroImg}
          alt="A klinika épülete naplementekor"
          width={1920}
          height={1280}
          priority
          sizesPreset="hero"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-linear-to-r from-[#0f1b3d]/95 via-[#0f1b3d]/80 to-[#0f1b3d]/30 sm:via-[#0f1b3d]/70 sm:to-transparent" />
      </div>
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 py-16 sm:py-24 md:py-36 text-white">
        <div className="max-w-2xl">
          <div className="text-[10px] sm:text-[11px] font-mono uppercase tracking-[0.2em] sm:tracking-[0.25em] text-[#c9a84c] mb-3 sm:mb-4">
            Veritas · Virtus · Libertas
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-6xl leading-[1.1] sm:leading-tight">
            Európai szintű ellátás, otthonos környezet.
          </h2>
          <p className="mt-4 sm:mt-6 text-base sm:text-lg text-white/85 max-w-xl">
            Klinikánk a régió szülészeti, nőgyógyászati és perinatális ellátásának vezető
            intézménye – oktatás, kutatás és betegellátás egy fedél alatt.
          </p>
          <div className="mt-6 sm:mt-8 flex flex-col sm:flex-row flex-wrap gap-3">
            <Link
              to="/foglalas/uj"
              className="inline-flex items-center justify-center gap-2 px-5 py-3 min-h-12 bg-[#c9a84c] text-[#0f1b3d] rounded font-semibold hover:bg-[#d8b961] transition-colors"
            >
              <CalendarCheck className="size-4" /> Időpontfoglalás
            </Link>
            <a
              href={`tel:${EMERGENCY_TEL}`}
              className="inline-flex items-center justify-center gap-2 px-5 py-3 min-h-12 border border-white/40 rounded font-semibold hover:bg-white/10 transition-colors"
            >
              <Phone className="size-4" /> Sürgősségi ügyelet · 24/7
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------- section helpers ---------- */
function SectionTitle({ kicker, title, lead }: { kicker?: string; title: string; lead?: string }) {
  return (
    <div className="max-w-3xl mb-8 sm:mb-12">
      {kicker && (
        <div className="text-[10px] sm:text-[11px] font-mono uppercase tracking-[0.2em] sm:tracking-[0.25em] text-[#c9a84c] mb-2 sm:mb-3">
          {kicker}
        </div>
      )}
      <h2 className="font-serif text-2xl sm:text-3xl md:text-4xl text-[#0f1b3d] leading-tight">{title}</h2>
      {lead && <p className="mt-3 sm:mt-4 text-muted-foreground text-base sm:text-lg leading-relaxed">{lead}</p>}
    </div>
  );
}

function Section({
  id,
  children,
  tone = "light",
}: {
  id: string;
  children: React.ReactNode;
  tone?: "light" | "soft" | "dark";
}) {
  const bg =
    tone === "dark"
      ? "bg-[#0f1b3d] text-white"
      : tone === "soft"
        ? "bg-[#f3f4f8]"
        : "bg-white";
  return (
    <section id={id} className={`${bg} py-14 sm:py-20 md:py-24 scroll-mt-16`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6">{children}</div>
    </section>
  );
}

/* ---------- bemutatkozás ---------- */
function Bemutatkozas() {
  return (
    <Section id="bemutatkozas" tone="light">
      <SectionTitle
        kicker="Bemutatkozás"
        title="A szegedi nőgyógyászati hagyomány több mint száz éve"
        lead="Klinikánk a Szegedi Tudományegyetem Szent-Györgyi Albert Orvostudományi Karának részeként
          a Dél-Alföld nőgyógyászati és perinatális ellátásának központja. Célunk a nemzetközi
          szintekre emelt szakmai munka és a vonzó, fenntartható szülész-szakmai utánpótlás."
      />
      <div className="grid md:grid-cols-3 gap-6">
        {[
          { title: "Klinika története", body: "1921 óta szolgáljuk a régió édesanyáit és családjait, a magyar nőgyógyászat egyik bölcsőjeként." },
          { title: "Intézetvezetők", body: "Tudományos kiválósággal és klinikai tapasztalattal bíró vezetőkből álló csapat irányítja a részlegeket." },
          { title: "Veritas · Virtus · Libertas", body: "Az SZTE jelmondatát képviseljük: igazság, helytállás és szabadság a betegágy mellett és a tanteremben." },
        ].map((c) => (
          <div key={c.title} className="bg-[#f3f4f8] border-l-4 border-[#c9a84c] p-6">
            <h3 className="font-serif text-xl text-[#0f1b3d] mb-2">{c.title}</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">{c.body}</p>
          </div>
        ))}
      </div>
    </Section>
  );
}

/* ---------- foeto-maternalis centrum ---------- */
function FoetoMaternalis() {
  const items = [
    { icon: HeartPulse, title: "Centrum bemutatása", body: "A magas kockázatú terhességek központja Dél-Magyarországon." },
    { icon: Baby, title: "Terhesdiagnosztika", body: "Várandósgondozás, ultrahang-szűrések és genetikai konzultáció." },
    { icon: Stethoscope, title: "Magzati Orvostudomány", body: "Intrauterin diagnosztika és terápia, magzati kardiológia." },
    { icon: FileText, title: "Dokumentumok", body: "Tájékoztatók, beleegyező nyilatkozatok, letölthető űrlapok." },
  ];
  return (
    <Section id="foeto" tone="dark">
      <SectionTitle
        kicker="Foeto-Maternalis Centrum"
        title="A magzat és az édesanya együtt – egy csapatban"
      />
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {items.map(({ icon: Icon, title, body }) => (
          <div
            key={title}
            className="group bg-white/5 border border-white/10 p-6 hover:border-[#c9a84c]/60 transition-colors"
          >
            <Icon className="size-7 text-[#c9a84c] mb-4" />
            <h3 className="font-serif text-lg mb-2">{title}</h3>
            <p className="text-sm text-white/70 leading-relaxed">{body}</p>
          </div>
        ))}
      </div>
    </Section>
  );
}

/* ---------- betegellátás ---------- */
function Betegellatas() {
  const rendelesek = [
    { name: "Általános nőgyógyászati rendelés", time: "H–P · 08:00–14:00" },
    { name: "Terhesgondozás", time: "H, Sze, P · 08:00–12:00" },
    { name: "Onkológiai szakrendelés", time: "K, Cs · 09:00–13:00" },
    { name: "Meddőségi (IVF) szakrendelés", time: "K, Cs · 08:00–14:00" },
    { name: "Urogynekológia", time: "Sze · 13:00–16:00" },
    { name: "Sürgősségi ügyelet", time: "0–24 órás folyamatos" },
  ];
  return (
    <Section id="betegellatas" tone="light">
      <SectionTitle
        kicker="Betegellátás"
        title="Szakrendeléseink és rendelési időink"
        lead="Időpontot a klinika központi rendelőjén keresztül vagy a bejelentkezést követően online is foglalhat."
      />
      <div className="grid md:grid-cols-2 gap-8">
        <div className="border border-border rounded-md overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-[#0f1b3d] text-white">
              <tr>
                <th className="text-left px-4 py-3 font-semibold">Szakrendelés</th>
                <th className="text-left px-4 py-3 font-semibold">Rendelési idő</th>
              </tr>
            </thead>
            <tbody>
              {rendelesek.map((r, i) => (
                <tr key={r.name} className={i % 2 ? "bg-[#f3f4f8]" : "bg-white"}>
                  <td className="px-4 py-3">{r.name}</td>
                  <td className="px-4 py-3 font-mono text-xs text-muted-foreground">{r.time}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="space-y-4">
          {[
            { icon: Clock, title: "Várólista-tájékoztatás", body: "Tervezhető beavatkozásaink aktuális várakozási idejéről bejelentkezés után tájékozódhat." },
            { icon: ShieldCheck, title: "Betegjogi képviselő", body: "Független képviselőnk segíti Önt panaszával, kérdésével – elérhetőségét a recepción kérheti." },
            { icon: Users, title: "Védőnői alapellátás", body: "Várandós- és csecsemőgondozás a területileg illetékes védőnői körzetekben." },
          ].map(({ icon: Icon, title, body }) => (
            <div key={title} className="flex gap-4 p-4 bg-[#f3f4f8] rounded-md">
              <Icon className="size-6 text-[#0f1b3d] shrink-0 mt-0.5" />
              <div>
                <h4 className="font-semibold text-[#0f1b3d]">{title}</h4>
                <p className="text-sm text-muted-foreground mt-1">{body}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
      <div className="mt-10 flex flex-wrap items-center gap-3">
        <Link
          to="/foglalas/uj"
          className="inline-flex items-center gap-2 px-5 py-3 bg-[#0f1b3d] text-white rounded font-semibold hover:bg-[#1e3a5f] transition-colors"
        >
          <CalendarCheck className="size-4" /> Online időpontfoglalás
        </Link>
        <a
          href={`tel:${SWITCHBOARD_TEL}`}
          className="inline-flex items-center gap-2 px-5 py-3 border border-[#0f1b3d]/30 text-[#0f1b3d] rounded font-semibold hover:bg-[#0f1b3d]/5 transition-colors"
        >
          <Phone className="size-4" /> Központ hívása
        </a>
      </div>
    </Section>
  );
}

/* ---------- munkatársak ---------- */
function Munkatarsak() {
  const team = [
    { name: "Prof. Dr. Klinikavezető", role: "Igazgató, intézetvezető egyetemi tanár" },
    { name: "Dr. Igazgatóhelyettes", role: "Általános igazgatóhelyettes" },
    { name: "Dr. Centrumvezető", role: "Foeto-Maternalis Centrum vezetője" },
    { name: "Dr. Oktatási felelős", role: "Oktatási és továbbképzési igazgatóhelyettes" },
    { name: "Dr. Onkológus", role: "Nőgyógyászati onkológiai részleg" },
    { name: "Vezető szülésznő", role: "Szakdolgozói vezető" },
  ];
  return (
    <Section id="munkatarsak" tone="soft">
      <SectionTitle
        kicker="Munkatársak"
        title="Orvosi és szakdolgozói csapatunk"
        lead="Tapasztalt orvosok, rezidensek, szülésznők és nővérek dolgoznak együtt a Klinika napi működésében."
      />
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {team.map((p) => (
          <div key={p.name} className="bg-white border border-border p-6 flex items-start gap-4">
            <div className="size-14 rounded-full bg-[#0f1b3d] text-[#c9a84c] font-serif text-xl flex items-center justify-center shrink-0">
              {p.name.split(" ").slice(-1)[0].slice(0, 2).toUpperCase()}
            </div>
            <div>
              <div className="font-semibold text-[#0f1b3d]">{p.name}</div>
              <div className="text-xs text-muted-foreground mt-1">{p.role}</div>
            </div>
          </div>
        ))}
      </div>
      <div className="mt-8 text-center">
        <Link
          to="/portal/orvos-kereso"
          className="text-sm font-semibold text-[#1e3a5f] hover:underline inline-flex items-center gap-1"
        >
          <Search className="size-4" /> Orvoskereső – tünetalapú szakember-ajánló <ArrowRight className="size-4" />
        </Link>
      </div>
    </Section>
  );
}

/* ---------- oktatás & kutatás ---------- */
function OktatasKutatas() {
  return (
    <Section id="oktatas" tone="light">
      <SectionTitle
        kicker="Oktatás és kutatás"
        title="Magyar és angol nyelvű képzés, PhD program, publikációk"
      />
      <div className="grid md:grid-cols-3 gap-6">
        {[
          { icon: GraduationCap, title: "Graduális képzés", body: "Általános orvos és fogorvos képzés magyar, angol és német nyelven." },
          { icon: Briefcase, title: "Szakképzés", body: "Szülész-nőgyógyász szakorvos és sub-specializációk akkreditált képzőhelye." },
          { icon: FlaskConical, title: "Tudományos közlemények", body: "2019–2022 közötti közlemények jegyzéke, doktori (PhD) iskola publikációi." },
        ].map(({ icon: Icon, title, body }) => (
          <div key={title} className="p-6 border-t-4 border-[#c9a84c] bg-[#f3f4f8]">
            <Icon className="size-7 text-[#0f1b3d] mb-3" />
            <h3 className="font-serif text-xl text-[#0f1b3d] mb-2">{title}</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">{body}</p>
          </div>
        ))}
      </div>
    </Section>
  );
}

/* ---------- friss hírek ---------- */
function Hirek() {
  const hirek = [
    {
      tag: "Sajtó · Délmagyarország",
      date: "2025.07.03.",
      title: "Nemzetközi szintekre emelné a nőgyógyászati klinikát a Klinika új vezetője",
      excerpt: "Új stratégiai irány: vonzóvá tenni a szülész szakmát a fiatal orvosok számára a szegedi klinikán.",
    },
    {
      tag: "Beavatkozás",
      date: "2011.11.21.",
      title: "Új műtéti eljárás a női klinikán",
      excerpt: "Az egész országban csak néhány helyen végzett méheltávolítás hasfalátvágás nélkül a szegedi klinikán is elérhető.",
    },
    {
      tag: "Projekt · ACTIF",
      date: "2019.02.15.",
      title: "Aktív határmenti együttműködés a női infertilitás kezelésében",
      excerpt: "Közel 79 ezer euró értékű műszer beszerzése a szegedi és temesvári klinika együttműködésében.",
    },
  ];
  return (
    <Section id="hirek" tone="soft">
      <SectionTitle kicker="Friss hírek" title="Hírek a klinikáról" />
      <div className="grid md:grid-cols-3 gap-6">
        {hirek.map((h) => (
          <article key={h.title} className="bg-white border border-border flex flex-col">
            <div className="aspect-[16/10] bg-gradient-to-br from-[#1e3a5f] to-[#0f1b3d] flex items-center justify-center">
              <Newspaper className="size-12 text-[#c9a84c]/70" />
            </div>
            <div className="p-5 flex flex-col flex-1">
              <div className="text-[11px] font-mono uppercase tracking-wider text-[#c9a84c]">{h.tag}</div>
              <div className="text-xs text-muted-foreground mt-1">{h.date}</div>
              <h3 className="font-serif text-lg text-[#0f1b3d] mt-3 leading-snug">{h.title}</h3>
              <p className="text-sm text-muted-foreground mt-2 flex-1">{h.excerpt}</p>
              <a href="#" className="mt-4 text-sm font-semibold text-[#1e3a5f] hover:underline inline-flex items-center gap-1">
                Tovább a teljes cikkhez <ArrowRight className="size-4" />
              </a>
            </div>
          </article>
        ))}
      </div>
    </Section>
  );
}

/* ---------- projektek ---------- */
function Projektek() {
  const items = ["BABYROHU", "ACTIF", "Interreg", "Horizon 2020", "NKFI alap", "Széchenyi 2020"];
  return (
    <Section id="projektek" tone="light">
      <SectionTitle kicker="Fejlesztési projektek" title="Hazai és határon átnyúló együttműködéseink" />
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {items.map((p) => (
          <div
            key={p}
            className="aspect-[5/2] border border-border bg-[#f3f4f8] flex items-center justify-center font-serif text-[#0f1b3d] text-sm md:text-base"
          >
            {p}
          </div>
        ))}
      </div>
    </Section>
  );
}

/* ---------- álláslehetőségek ---------- */
function Allas() {
  return (
    <section className="bg-[#0f1b3d] text-white py-14 sm:py-20 scroll-mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 grid md:grid-cols-2 gap-8 sm:gap-10 items-center">
        <div>
          <div className="text-[10px] sm:text-[11px] font-mono uppercase tracking-[0.2em] sm:tracking-[0.25em] text-[#c9a84c] mb-2 sm:mb-3">
            Álláslehetőségeink
          </div>
          <h2 className="font-serif text-2xl sm:text-3xl md:text-4xl mb-3 sm:mb-4 leading-tight">
            Csatlakozzon orvosi vagy szakdolgozói csapatunkhoz
          </h2>
          <p className="text-white/75 mb-5 sm:mb-6 max-w-lg text-sm sm:text-base">
            Folyamatosan keresünk rezidenseket, szakorvosokat, szülésznőket és nővéreket
            támogató, oktatás-orientált munkakörnyezetbe.
          </p>
          <a
            href="#"
            className="inline-flex items-center justify-center gap-2 px-5 py-3 min-h-12 bg-[#c9a84c] text-[#0f1b3d] rounded font-semibold hover:bg-[#d8b961] transition-colors"
          >
            Nyitott pozíciók <ArrowRight className="size-4" />
          </a>
        </div>
        <ul className="grid sm:grid-cols-2 gap-3">
          {["Rezidens szülész-nőgyógyász", "Szakorvos – Onkológia", "Szülésznő (műszakos)", "Asszisztens IVF labor"].map((j) => (
            <li key={j} className="bg-white/5 border border-white/10 p-4 hover:border-[#c9a84c]/60 transition-colors">
              <Briefcase className="size-5 text-[#c9a84c] mb-2" aria-hidden="true" />
              <div className="font-semibold text-sm">{j}</div>
              <div className="text-xs text-white/60 mt-1">Szeged · Teljes munkaidő</div>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

/* ---------- hasznos linkek ---------- */
function HasznosLinkek() {
  const links = [
    "Klinikai ügyeletek",
    "Szent-Györgyi Albert Klinikai Központ",
    "Klebelsberg Könyvtár",
    "József Attila TIK",
    "EHÖK",
    "Térkép",
    "Karrier – Pályázatok",
    "Pontkalkulátor",
  ];
  return (
    <Section id="linkek" tone="soft">
      <SectionTitle kicker="Hasznos linkek" title="Kapcsolódó oldalak" />
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
        {links.map((l) => (
          <a
            key={l}
            href="#"
            className="group flex items-center justify-between gap-2 p-3 sm:p-4 min-h-12 bg-white border border-border hover:border-[#c9a84c] transition-colors"
          >
            <span className="text-sm leading-tight">{l}</span>
            <ExternalLink className="size-4 shrink-0 text-muted-foreground group-hover:text-[#c9a84c]" aria-hidden="true" />
          </a>
        ))}
      </div>
    </Section>
  );
}

/* ---------- kapcsolat ---------- */
function Kapcsolat() {
  return (
    <Section id="kapcsolat" tone="light">
      <SectionTitle kicker="Kapcsolat" title="Hol talál meg minket" />
      <div className="grid md:grid-cols-3 gap-5 sm:gap-6">
        <div className="md:col-span-2 aspect-[4/3] sm:aspect-[16/10] md:aspect-[16/9] bg-[#f3f4f8] border border-border overflow-hidden">
          <iframe
            title="Szülészeti és Nőgyógyászati Klinika – térkép"
            src="https://www.openstreetmap.org/export/embed.html?bbox=20.1410%2C46.2470%2C20.1530%2C46.2530&amp;layer=mapnik&amp;marker=46.2500%2C20.1470"
            className="w-full h-full border-0"
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>
        <div className="space-y-4">
          <ContactRow icon={MapPin} label="Cím" value="6725 Szeged, Semmelweis u. 1." href="https://www.openstreetmap.org/?mlat=46.2500&mlon=20.1470#map=18/46.2500/20.1470" external />
          <ContactRow icon={Phone} label="Központ" value="(+36-62) 545-499" href={`tel:${SWITCHBOARD_TEL}`} />
          <ContactRow icon={Phone} label="Sürgősségi ügyelet · 24/7" value="(+36-62) 545-486" href={`tel:${EMERGENCY_TEL}`} />
          <ContactRow icon={Mail} label="E-mail" value="obgyn@med.u-szeged.hu" href="mailto:obgyn@med.u-szeged.hu" />
          <Link
            to="/foglalas/uj"
            className="mt-2 inline-flex items-center justify-center gap-2 w-full py-3 bg-[#c9a84c] text-[#0f1b3d] rounded font-semibold hover:bg-[#d8b961] transition-colors"
          >
            <CalendarCheck className="size-4" /> Online időpontfoglalás
          </Link>
          <AccountLink
            className="inline-flex items-center justify-center gap-2 w-full py-3 bg-[#0f1b3d] text-white rounded font-semibold hover:bg-[#1e3a5f] transition-colors"
            label="Belépés a klinikai rendszerbe"
          />
        </div>
      </div>
    </Section>
  );
}

function ContactRow({
  icon: Icon,
  label,
  value,
  href,
  external,
}: {
  icon: typeof Phone;
  label: string;
  value: string;
  href?: string;
  external?: boolean;
}) {
  const body = (
    <>
      <Icon className="size-5 text-[#0f1b3d] mt-0.5 shrink-0" aria-hidden="true" />
      <div className="min-w-0">
        <div className="text-[11px] font-mono uppercase tracking-wider text-muted-foreground">{label}</div>
        <div className="text-sm font-semibold text-[#0f1b3d] break-words">{value}</div>
      </div>
    </>
  );
  const base = "flex items-start gap-3 p-3 border-l-2 border-[#c9a84c]";
  if (href) {
    return (
      <a
        href={href}
        className={`${base} hover:bg-[#f3f4f8] transition-colors`}
        {...(external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
      >
        {body}
      </a>
    );
  }
  return <div className={base}>{body}</div>;
}

/* ---------- footer ---------- */
function SiteFooter() {
  return (
    <footer className="bg-[#0a1530] text-white/80 pb-safe">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10 sm:py-14 grid grid-cols-2 md:grid-cols-4 gap-8 sm:gap-10 text-sm">
        <FooterCol title="Karok">
          {["ÁJTK", "BBMK", "BTK", "ETSZK", "FOK", "GTK", "GYTK", "JGYPK", "MK", "MGK", "SZAOK", "TTIK"].map((k) => (
            <a key={k} href="#" className="block hover:text-[#c9a84c] py-1">{k}</a>
          ))}
        </FooterCol>
        <FooterCol title="Felvételi">
          {["Felvételi információk", "Képzések", "Miért az SZTE?", "Nyílt napok", "Pontkalkulátor"].map((k) => (
            <a key={k} href="#" className="block hover:text-[#c9a84c] py-1">{k}</a>
          ))}
        </FooterCol>
        <FooterCol title="Az egyetemről">
          {["Rektori köszöntő", "Bemutatkozás", "Szervezeti felépítés", "Közérdekű adatok", "Szabályzatok", "Esélyegyenlőség"].map((k) => (
            <a key={k} href="#" className="block hover:text-[#c9a84c] py-1">{k}</a>
          ))}
        </FooterCol>
        <FooterCol title="Kövess minket">
          <div className="flex flex-wrap gap-2 sm:gap-3 mt-2">
            <a href="#" aria-label="Facebook" className="size-11 rounded-full bg-white/10 hover:bg-[#c9a84c] hover:text-[#0f1b3d] flex items-center justify-center transition-colors"><Facebook className="size-4" /></a>
            <a href="#" aria-label="YouTube" className="size-11 rounded-full bg-white/10 hover:bg-[#c9a84c] hover:text-[#0f1b3d] flex items-center justify-center transition-colors"><Youtube className="size-4" /></a>
            <a href="#" aria-label="LinkedIn" className="size-11 rounded-full bg-white/10 hover:bg-[#c9a84c] hover:text-[#0f1b3d] flex items-center justify-center transition-colors"><Linkedin className="size-4" /></a>
            <a href="#" aria-label="Instagram" className="size-11 rounded-full bg-white/10 hover:bg-[#c9a84c] hover:text-[#0f1b3d] flex items-center justify-center transition-colors"><Instagram className="size-4" /></a>
          </div>
          <div className="mt-5 sm:mt-6 text-xs text-white/60 space-y-1">
            <div>Szegedi Tudományegyetem</div>
            <div>6720 Szeged, Dugonics tér 13.</div>
            <div>
              Központi telefon:{" "}
              <a href="tel:+3662544000" className="hover:text-white">(+36-62) 544-000</a>
            </div>
          </div>
        </FooterCol>
      </div>
      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 text-[11px] text-white/50 flex flex-col sm:flex-row sm:flex-wrap sm:items-center sm:justify-between gap-2">
          <div>© {new Date().getFullYear()} Szegedi Tudományegyetem – Szülészeti és Nőgyógyászati Klinika</div>
          <div className="flex flex-wrap gap-4">
            <a href="#" className="hover:text-white">Adatvédelem</a>
            <a href="#" className="hover:text-white">Közérdekű adatok</a>
            <Link to="/auth" className="hover:text-[#c9a84c]">Belépés</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}

function FooterCol({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h4 className="font-serif text-base text-white mb-3 pb-2 border-b border-[#c9a84c]/40">{title}</h4>
      <div className="text-xs text-white/70">{children}</div>
    </div>
  );
}

/* ---------- számok / impact band ---------- */
function Szamok() {
  const stats = [
    { icon: Award, value: "100+", label: "év szakmai hagyomány" },
    { icon: Baby, value: "2 400", label: "szülés évente" },
    { icon: Stethoscope, value: "50+", label: "szülész-nőgyógyász szakorvos" },
    { icon: Activity, value: "24/7", label: "sürgősségi ügyelet" },
  ];
  return (
    <section className="bg-[#1e3a5f] text-white py-12 md:py-14 border-y border-[#c9a84c]/20">
      <div className="max-w-7xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-10">
        {stats.map(({ icon: Icon, value, label }) => (
          <div key={label} className="text-center">
            <Icon className="size-7 mx-auto text-[#c9a84c] mb-2" aria-hidden="true" />
            <div className="font-serif text-3xl md:text-4xl">{value}</div>
            <div className="text-[11px] md:text-xs uppercase tracking-wider text-white/70 mt-1">
              {label}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

/* ---------- gyakori kérdések ---------- */
function Gyik() {
  const items = [
    {
      q: "Hogyan tudok időpontot foglalni?",
      a: "Bejelentkezést követően online is foglalhat időpontot a betegportálon, vagy hívja a központi számot munkanapokon 08:00 és 16:00 között. Sürgős esetben a 24/7 ügyelet áll rendelkezésére.",
    },
    {
      q: "Mit hozzak magammal az első vizsgálatra?",
      a: "TAJ-kártyát, személyi igazolványt, lakcímkártyát, beutalót (ha van), és a korábbi leleteit, illetve aktuálisan szedett gyógyszerei listáját.",
    },
    {
      q: "Hol parkolhatok a klinikánál?",
      a: "A klinika környékén fizetős városi parkolóhelyek érhetők el; mozgáskorlátozottaknak külön kijelölt parkolók állnak rendelkezésre a főbejáratnál.",
    },
    {
      q: "Hogyan érhetem el a leleteimet?",
      a: "A leletek a vizsgálatot követő 3–7 munkanapon belül elérhetők a betegportál Leletek menüpontjában, illetve az EESZT-ben.",
    },
    {
      q: "Mit tegyek sürgős, életveszélyes helyzetben?",
      a: "Életveszély esetén azonnal hívja a 112-es egységes segélyhívót. A klinika 24/7 szülészeti ügyelete a (+36-62) 545-486 számon érhető el.",
    },
  ];
  return (
    <Section id="gyik" tone="soft">
      <SectionTitle
        kicker="Gyakori kérdések"
        title="Amit a betegeink leggyakrabban kérdeznek"
        lead="Ha kérdése nem szerepel a listában, vegye fel velünk a kapcsolatot a Kapcsolat szakaszban található elérhetőségeken."
      />
      <div className="max-w-3xl mx-auto space-y-3">
        {items.map((it) => (
          <details
            key={it.q}
            className="group bg-white border border-border rounded-md p-4 md:p-5 open:border-[#c9a84c]"
          >
            <summary className="cursor-pointer font-semibold text-[#0f1b3d] list-none flex items-center justify-between gap-3">
              <span>{it.q}</span>
              <ArrowRight className="size-4 shrink-0 text-[#c9a84c] transition-transform group-open:rotate-90" />
            </summary>
            <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{it.a}</p>
          </details>
        ))}
      </div>
    </Section>
  );
}
