import { Link } from "@tanstack/react-router";

export function KlinikaHeader() {
  return (
    <header className="border-b bg-background sticky top-0 z-40">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link to="/" className="font-serif text-xl font-bold">Szülészeti és Nőgyógyászati Klinika</Link>
        <nav className="hidden md:flex gap-6 text-sm">
          <Link to="/" className="hover:text-primary">Főoldal</Link>
          <a href="/o/bemutatkozas" className="hover:text-primary">Bemutatkozás</a>
          <a href="/o/betegellatas" className="hover:text-primary">Betegellátás</a>
          <Link to="/hirek" className="hover:text-primary">Hírek</Link>
          <a href="/o/kapcsolat" className="hover:text-primary">Kapcsolat</a>
          <Link to="/auth" className="hover:text-primary">Bejelentkezés</Link>
        </nav>
      </div>
    </header>
  );
}

export function KlinikaFooter() {
  return (
    <footer className="border-t bg-muted/30 mt-12">
      <div className="container mx-auto px-4 py-8 text-sm text-muted-foreground">
        © {new Date().getFullYear()} Szülészeti és Nőgyógyászati Klinika
      </div>
    </footer>
  );
}
