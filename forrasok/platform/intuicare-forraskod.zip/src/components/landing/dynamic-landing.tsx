/**
 * Adatvezérelt landing oldal — publikált blokkokat renderel.
 */
import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { SmartImage } from "@/components/ui/smart-image";
import DOMPurify from "dompurify";
import { useExperiment } from "@/lib/cms/use-experiment";


type Block = {
  id: string;
  block_type: string;
  content: Record<string, any>;
};

export function DynamicLanding({ blocks, brandName }: { blocks: Block[]; brandName: string }) {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="border-b border-border/60 backdrop-blur-sm sticky top-0 z-10 bg-background/80">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="text-sm font-semibold tracking-tight">{brandName}</div>
          <Link to="/auth" className="text-xs font-semibold px-3 py-1.5 rounded-md border border-border hover:bg-secondary transition-colors">
            Belépés
          </Link>
        </div>
      </header>
      <main>
        {blocks.map((b) => <BlockRenderer key={b.id} block={b} />)}
      </main>
      <footer className="border-t border-border/60 mt-12 py-6 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} {brandName}
      </footer>
    </div>
  );
}

function BlockRenderer({ block }: { block: Block }) {
  const { variantContent } = useExperiment(block.id, {
    kind: "layout_block",
    blockType: block.block_type,
  });
  const base = block.content ?? {};
  const c = variantContent ? { ...base, ...variantContent } : base;
  switch (block.block_type) {
    case "hero":
      return (
        <section className="py-20 px-4 text-center bg-gradient-to-b from-primary/10 to-transparent">
          <div className="max-w-3xl mx-auto space-y-4">
            <h1 className="text-4xl md:text-5xl font-bold tracking-tight">{c.title}</h1>
            {c.subtitle && <p className="text-lg text-muted-foreground">{c.subtitle}</p>}
            {c.cta_label && (
              <Button asChild size="lg">
                <Link to={c.cta_to || "/auth"}>{c.cta_label}</Link>
              </Button>
            )}
          </div>
        </section>
      );
    case "feature_grid":
      return (
        <section className="py-16 px-4">
          <div className="max-w-5xl mx-auto">
            {c.title && <h2 className="text-3xl font-bold text-center mb-10">{c.title}</h2>}
            <div className="grid md:grid-cols-3 gap-6">
              {(c.items ?? []).map((it: any, i: number) => (
                <div key={i} className="p-5 rounded-lg border bg-card">
                  <h3 className="font-semibold mb-2">{it.title}</h3>
                  <p className="text-sm text-muted-foreground">{it.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      );
    case "stats":
      return (
        <section className="py-12 px-4 bg-muted/30">
          <div className="max-w-4xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            {(c.items ?? []).map((it: any, i: number) => (
              <div key={i}>
                <div className="text-3xl font-bold text-primary">{it.value}</div>
                <div className="text-xs text-muted-foreground mt-1">{it.label}</div>
              </div>
            ))}
          </div>
        </section>
      );
    case "cta_band":
      return (
        <section className="py-12 px-4 bg-primary text-primary-foreground text-center">
          <div className="max-w-2xl mx-auto space-y-3">
            <h2 className="text-2xl font-bold">{c.title}</h2>
            {c.subtitle && <p className="opacity-90">{c.subtitle}</p>}
            {c.cta_label && (
              <Button asChild variant="secondary" size="lg">
                <Link to={c.cta_to || "/auth"}>{c.cta_label}</Link>
              </Button>
            )}
          </div>
        </section>
      );
    case "faq":
      return (
        <section className="py-16 px-4">
          <div className="max-w-3xl mx-auto">
            {c.title && <h2 className="text-3xl font-bold text-center mb-8">{c.title}</h2>}
            <div className="space-y-3">
              {(c.items ?? []).map((it: any, i: number) => (
                <details key={i} className="p-4 border rounded-lg bg-card">
                  <summary className="font-medium cursor-pointer">{it.q}</summary>
                  <p className="text-sm text-muted-foreground mt-2">{it.a}</p>
                </details>
              ))}
            </div>
          </div>
        </section>
      );
    case "image_text":
      return (
        <section className="py-16 px-4">
          <div className="max-w-5xl mx-auto grid md:grid-cols-2 gap-8 items-center">
            {c.image_url && <SmartImage src={c.image_url} alt={c.image_alt ?? ""} className="rounded-lg" width={800} height={450} />}
            <div>
              <h2 className="text-2xl font-bold mb-3">{c.title}</h2>
              <p className="text-muted-foreground">{c.body}</p>
            </div>
          </div>
        </section>
      );
    case "custom_html":
      // Stored HTML from CMS admin — sanitized with DOMPurify to prevent
      // stored XSS if an admin account is ever compromised.
      return (
        <section
          className="py-8 px-4"
          dangerouslySetInnerHTML={{
            __html: DOMPurify.sanitize(String(c.html ?? ""), {
              FORBID_TAGS: ["script", "style", "iframe", "object", "embed", "form"],
              FORBID_ATTR: ["onerror", "onload", "onclick", "onmouseover", "onfocus", "onblur", "onchange", "onsubmit", "formaction"],
            }),
          }}
        />
      );
    default:
      return null;
  }
}
