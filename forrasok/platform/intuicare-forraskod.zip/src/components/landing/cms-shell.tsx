/**
 * Shared CMS-driven shell: top_bar / header / main_nav / footer global
 * regions wrap arbitrary children. Falls back to KlinikaHeader/KlinikaFooter
 * when a region has no blocks yet, so subpages keep working during the
 * migration period.
 */
import type { GlobalRegion } from "@/lib/cms/layout-blocks.functions";
import { CmsBlock } from "@/components/cms/blocks/klinika-blocks";
import { KlinikaHeader, KlinikaFooter } from "@/components/landing/klinika-header";

function regionBlocks(regions: GlobalRegion[], key: string) {
  return regions.find((r) => r.region_key === key)?.blocks ?? [];
}

export function CmsShell({
  regions,
  children,
}: {
  regions: GlobalRegion[];
  children: React.ReactNode;
}) {
  const topBar = regionBlocks(regions, "top_bar");
  const header = regionBlocks(regions, "header");
  const mainNav = regionBlocks(regions, "main_nav");
  const footer = regionBlocks(regions, "footer");

  const hasHeader = topBar.length + header.length + mainNav.length > 0;
  const hasFooter = footer.length > 0;

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      {hasHeader ? (
        <>
          {topBar.map((b, i) => <CmsBlock key={`tb-${i}`} type={b.type} content={b.content} style={b.style} />)}
          {header.map((b, i) => <CmsBlock key={`h-${i}`} type={b.type} content={b.content} style={b.style} />)}
          {mainNav.map((b, i) => <CmsBlock key={`mn-${i}`} type={b.type} content={b.content} style={b.style} />)}
        </>
      ) : (
        <KlinikaHeader />
      )}
      <div className="flex-1">{children}</div>
      {hasFooter ? (
        footer.map((b, i) => <CmsBlock key={`f-${i}`} type={b.type} content={b.content} style={b.style} />)
      ) : (
        <KlinikaFooter />
      )}
    </div>
  );
}
