/**
 * CMS-driven landing: delegates header/footer regions to CmsShell so the
 * subpages and the homepage share the exact same global-region renderer.
 */
import type { HomeLayout } from "@/lib/cms/layout-blocks.functions";
import { CmsBlock } from "@/components/cms/blocks/klinika-blocks";
import { CmsShell } from "@/components/landing/cms-shell";
import { useExperiment } from "@/lib/cms/use-experiment";

/** Egy layout blokk A/B variant-content override-dal + automatikus view trackeléssel. */
function ExperimentalCmsBlock({ block }: { block: HomeLayout["blocks"][number] }) {
  const { variantContent } = useExperiment(block.id, {
    kind: "layout_block",
    blockType: block.block_type,
  });
  const content = variantContent ? { ...(block.content ?? {}), ...variantContent } : block.content;
  return <CmsBlock type={block.block_type} content={content} style={block.style} />;
}

export function KlinikaCmsLanding({ layout }: { layout: HomeLayout }) {
  return (
    <CmsShell regions={layout.regions}>
      <main>
        {layout.blocks.map((b) => (
          <ExperimentalCmsBlock key={b.id} block={b} />
        ))}
      </main>
    </CmsShell>
  );
}

