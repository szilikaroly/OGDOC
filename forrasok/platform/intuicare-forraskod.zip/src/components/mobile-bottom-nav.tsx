import { Link, useRouterState } from "@tanstack/react-router";
import { LayoutDashboard, MessageSquare, User as UserIcon, CalendarRange, Menu } from "lucide-react";
import { cn } from "@/lib/utils";

type Item = { to: string; label: string; icon: typeof LayoutDashboard };

const items: Item[] = [
  { to: "/dashboard", label: "Kezdő", icon: LayoutDashboard },
  { to: "/uzenetek", label: "Üzenet", icon: MessageSquare },
  { to: "/karakterlap", label: "Profil", icon: UserIcon },
  { to: "/beosztas", label: "Beosztás", icon: CalendarRange },
];

export function MobileBottomNav({ onOpenMenu }: { onOpenMenu?: () => void }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  return (
    <nav
      aria-label="Fő navigáció"
      className="lg:hidden fixed bottom-0 inset-x-0 z-30 border-t border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/80 pb-safe"
    >

      <ul className="grid grid-cols-5">
        {items.map(({ to, label, icon: Icon }) => {
          const active = pathname === to || (to !== "/" && pathname.startsWith(to));
          return (
            <li key={to}>
              <Link
                to={to}
                onClick={() => { try { (navigator as any).vibrate?.(8); } catch {} }}
                aria-current={active ? "page" : undefined}
                className={cn(
                  "flex flex-col items-center justify-center gap-0.5 min-h-14 text-[10px] font-medium transition-colors relative",
                  active
                    ? "text-primary after:absolute after:top-0 after:left-1/2 after:-translate-x-1/2 after:h-0.5 after:w-8 after:rounded-full after:bg-primary"
                    : "text-muted-foreground hover:text-foreground",
                )}
              >
                <Icon className="size-5" />
                <span className="truncate max-w-full px-1">{label}</span>
              </Link>
            </li>
          );
        })}
        <li>
          <button
            type="button"
            onClick={onOpenMenu}
            aria-label="Több menüpont"
            className="w-full flex flex-col items-center justify-center gap-0.5 min-h-14 text-[10px] font-medium text-muted-foreground hover:text-foreground transition-colors"
          >
            <Menu className="size-5" />
            <span>Több</span>
          </button>
        </li>
      </ul>
    </nav>
  );
}
