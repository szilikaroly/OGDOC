/**
 * Fordító Stúdió – komplex, Gemini alapú fordítómodul admin felülete.
 * 1) Szövegtár: minden hard-coded felirat DB-ben, részletes magyarázattal.
 * 2) AI magyarázat generálás (kontextus a fordításhoz és dokumentáció).
 * 3) Fordítás futtatás: nyelvenként külön vagy minden nyelvre egyben,
 *    „csak hiányzó” vagy „teljes újrafordítás” módban.
 */
import { useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Sparkles, RefreshCw, Save, Database, Languages } from "lucide-react";
import { hu as huLocale } from "@/i18n/locales/hu";
import { SUPPORTED_LANGUAGES, LANG_CODES } from "@/i18n/languages";
import {
  syncSourceStrings,
  listSourceStrings,
  updateSourceString,
  generateDescriptions,
  runTranslationBatch,
  startTranslationJob,
  finishTranslationJob,
  getCoverage,
  listTranslationJobs,
} from "@/lib/i18n/registry.functions";

type AnyDict = Record<string, unknown>;
function flatten(obj: AnyDict, prefix = ""): Record<string, string> {
  const out: Record<string, string> = {};
  for (const [k, v] of Object.entries(obj)) {
    const p = prefix ? `${prefix}.${k}` : k;
    if (v && typeof v === "object" && !Array.isArray(v)) Object.assign(out, flatten(v as AnyDict, p));
    else if (typeof v === "string") out[p] = v;
  }
  return out;
}

const TARGETS = LANG_CODES.filter((c) => c !== "hu");

export function TranslationStudio() {
  const qc = useQueryClient();
  const huFlat = useMemo(() => flatten(huLocale as unknown as AnyDict), []);
  const sourceCount = Object.keys(huFlat).length;

  const [busy, setBusy] = useState<string | null>(null);
  const [progress, setProgress] = useState<{ label: string; done: number; total: number } | null>(null);
  const [log, setLog] = useState<string[]>([]);

  const coverage = useQuery({ queryKey: ["i18n-coverage"], queryFn: () => getCoverage({ data: {} }) });
  const jobs = useQuery({ queryKey: ["i18n-jobs"], queryFn: () => listTranslationJobs() });

  function addLog(line: string) {
    setLog((l) => [`${new Date().toLocaleTimeString("hu-HU")} · ${line}`, ...l].slice(0, 60));
  }

  /** 1) Hard-coded feliratok szinkronizálása a DB szövegtárba. */
  async function handleSync() {
    setBusy("sync");
    setProgress({ label: "Szövegtár szinkron", done: 0, total: sourceCount });
    try {
      const entries = Object.entries(huFlat);
      let inserted = 0;
      let updated = 0;
      const CHUNK = 400;
      for (let i = 0; i < entries.length; i += CHUNK) {
        const items = entries.slice(i, i + CHUNK).map(([key, source_text]) => ({
          namespace: "ui",
          key,
          source_text,
        }));
        const res: any = await syncSourceStrings({ data: { items } });
        inserted += res.inserted;
        updated += res.updated;
        setProgress({ label: "Szövegtár szinkron", done: Math.min(i + CHUNK, entries.length), total: entries.length });
      }
      addLog(`Szövegtár frissítve: ${inserted} új, ${updated} módosult felirat.`);
      toast.success(`Szövegtár kész — ${inserted} új, ${updated} frissített`);
      qc.invalidateQueries({ queryKey: ["i18n-coverage"] });
      qc.invalidateQueries({ queryKey: ["i18n-source-strings"] });
    } catch (e: any) {
      toast.error(e?.message ?? "Szinkron hiba");
      addLog(`HIBA (szinkron): ${e?.message ?? e}`);
    } finally {
      setBusy(null);
      setProgress(null);
    }
  }

  /** 2) AI magyarázatok generálása minden magyarázat nélküli felirathoz. */
  async function handleDescribe() {
    setBusy("describe");
    try {
      let guard = 0;
      let describedTotal = 0;
      // eslint-disable-next-line no-constant-condition
      while (guard++ < 200) {
        const res: any = await generateDescriptions({ data: { limit: 30 } });
        describedTotal += res.described;
        setProgress({
          label: "AI magyarázatok",
          done: describedTotal,
          total: describedTotal + (res.remaining ?? 0),
        });
        if (res.described === 0 || res.remaining === 0) break;
      }
      addLog(`AI magyarázat generálva: ${describedTotal} felirathoz.`);
      toast.success(`Kész — ${describedTotal} magyarázat`);
      qc.invalidateQueries({ queryKey: ["i18n-coverage"] });
      qc.invalidateQueries({ queryKey: ["i18n-source-strings"] });
    } catch (e: any) {
      toast.error(e?.message ?? "AI magyarázat hiba");
      addLog(`HIBA (magyarázat): ${e?.message ?? e}`);
    } finally {
      setBusy(null);
      setProgress(null);
    }
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Database className="h-4 w-4" /> Szövegtár & lefedettség
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid gap-3 sm:grid-cols-3">
            <Stat label="Kódban lévő feliratok" value={sourceCount} />
            <Stat label="Adatbázisban" value={coverage.data?.total ?? 0} />
            <Stat
              label="Magyarázattal"
              value={`${coverage.data?.described ?? 0} / ${coverage.data?.total ?? 0}`}
            />
          </div>

          <div className="flex flex-wrap gap-2">
            <Button onClick={handleSync} disabled={!!busy} className="min-h-11">
              <RefreshCw className="h-4 w-4 mr-1.5" />
              {busy === "sync" ? "Szinkron…" : "Feliratok DB-be szinkronizálása"}
            </Button>
            <Button variant="secondary" onClick={handleDescribe} disabled={!!busy} className="min-h-11">
              <Sparkles className="h-4 w-4 mr-1.5" />
              {busy === "describe" ? "Magyarázatok…" : "AI részletes magyarázatok"}
            </Button>
          </div>

          {progress && (
            <div className="text-sm">
              <span className="text-muted-foreground">{progress.label}: </span>
              {progress.done} / {progress.total || "?"}
              <div className="mt-1 h-2 bg-muted rounded overflow-hidden">
                <div
                  className="h-full bg-primary transition-all"
                  style={{ width: `${progress.total ? (progress.done / progress.total) * 100 : 0}%` }}
                />
              </div>
            </div>
          )}

          <div className="flex flex-wrap gap-1.5">
            {TARGETS.map((code) => {
              const lang = SUPPORTED_LANGUAGES.find((l) => l.code === code)!;
              const done = coverage.data?.per_lang.find((p: any) => p.lang === code)?.done ?? 0;
              const total = coverage.data?.total ?? 0;
              const pct = total ? Math.round((done / total) * 100) : 0;
              return (
                <Badge key={code} variant={pct >= 99 ? "default" : "outline"}>
                  {lang.flag} {lang.label}: {pct}%
                </Badge>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <TranslationRunner
        busy={busy}
        setBusy={setBusy}
        setProgress={setProgress}
        addLog={addLog}
        onDone={() => {
          qc.invalidateQueries({ queryKey: ["i18n-coverage"] });
          qc.invalidateQueries({ queryKey: ["i18n-jobs"] });
        }}
      />

      <SourceStringsTable />

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Futtatások</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {(jobs.data ?? []).length === 0 && (
            <p className="text-sm text-muted-foreground">Még nem futott fordítás.</p>
          )}
          {(jobs.data ?? []).map((j: any) => (
            <div key={j.id} className="flex flex-wrap items-center gap-2 text-sm border-b pb-2">
              <Badge variant={j.status === "done" ? "default" : j.status === "failed" ? "destructive" : "outline"}>
                {j.status}
              </Badge>
              <span>{j.langs.join(", ")}</span>
              <span className="text-muted-foreground">
                {j.mode === "full" ? "teljes" : "csak hiányzó"} · {j.translated} lefordítva
                {j.failed > 0 ? ` · ${j.failed} hiba` : ""}
              </span>
              <span className="text-muted-foreground ml-auto">
                {new Date(j.started_at).toLocaleString("hu-HU")}
              </span>
            </div>
          ))}
          {log.length > 0 && (
            <pre className="mt-2 max-h-40 overflow-auto rounded bg-muted p-2 text-xs whitespace-pre-wrap">
              {log.join("\n")}
            </pre>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-lg border p-3">
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="text-xl font-semibold">{value}</div>
    </div>
  );
}

function TranslationRunner({
  busy,
  setBusy,
  setProgress,
  addLog,
  onDone,
}: {
  busy: string | null;
  setBusy: (v: string | null) => void;
  setProgress: (v: { label: string; done: number; total: number } | null) => void;
  addLog: (s: string) => void;
  onDone: () => void;
}) {
  const [selected, setSelected] = useState<string[]>(["en"]);
  const [mode, setMode] = useState<"missing" | "full">("missing");

  function toggle(code: string) {
    setSelected((s) => (s.includes(code) ? s.filter((x) => x !== code) : [...s, code]));
  }

  async function run(langs: string[]) {
    if (langs.length === 0) {
      toast.error("Válassz legalább egy nyelvet");
      return;
    }
    setBusy("translate");
    let translated = 0;
    let failed = 0;
    let jobId: string | undefined;
    try {
      const started: any = await startTranslationJob({ data: { langs, mode } });
      jobId = started.job_id;
      let offset = 0;
      let guard = 0;
      while (guard++ < 500) {
        let res: any;
        try {
          res = await runTranslationBatch({ data: { langs, mode, offset, limit: 40 } });
        } catch (e: any) {
          failed += 40;
          addLog(`HIBA @${offset}: ${e?.message ?? e}`);
          offset += 40;
          continue;
        }
        translated += res.translated;
        setProgress({
          label: `Fordítás (${langs.join(", ")})`,
          done: Math.min(offset + res.processed, res.total),
          total: res.total,
        });
        if (res.next_offset == null) break;
        offset = res.next_offset;
      }
      await finishTranslationJob({ data: { job_id: jobId!, translated, failed } });
      addLog(`Fordítás kész: ${translated} bejegyzés (${langs.join(", ")}).`);
      toast.success(`Fordítás kész — ${translated} bejegyzés`);
    } catch (e: any) {
      if (jobId)
        await finishTranslationJob({
          data: { job_id: jobId, translated, failed, error: String(e?.message ?? e) },
        }).catch(() => {});
      toast.error(e?.message ?? "Fordítási hiba");
      addLog(`HIBA: ${e?.message ?? e}`);
    } finally {
      setBusy(null);
      setProgress(null);
      onDone();
    }
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <Languages className="h-4 w-4" /> Fordítás futtatása (Gemini, kontextussal)
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <p className="text-sm text-muted-foreground">
          A fordító minden felirathoz megkapja a részletes magyarázatot, az elem típusát és a képernyőt,
          így pontos, UI-ba illő szöveget ad. Kézzel szerkesztett fordításokat soha nem ír felül.
        </p>

        <div className="flex flex-wrap gap-2">
          {TARGETS.map((code) => {
            const lang = SUPPORTED_LANGUAGES.find((l) => l.code === code)!;
            const active = selected.includes(code);
            return (
              <Button
                key={code}
                size="sm"
                variant={active ? "default" : "outline"}
                onClick={() => toggle(code)}
                className="min-h-11"
              >
                {lang.flag} {lang.label}
              </Button>
            );
          })}
          <Button size="sm" variant="ghost" onClick={() => setSelected([...TARGETS])} className="min-h-11">
            Mind
          </Button>
          <Button size="sm" variant="ghost" onClick={() => setSelected([])} className="min-h-11">
            Egyik se
          </Button>
        </div>

        <div className="flex flex-wrap items-end gap-3">
          <div className="space-y-1">
            <Label className="text-xs">Mód</Label>
            <Select value={mode} onValueChange={(v) => setMode(v as "missing" | "full")}>
              <SelectTrigger className="w-56 min-h-11">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="missing">Csak a hiányzók / változottak</SelectItem>
                <SelectItem value="full">Teljes újrafordítás</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button onClick={() => run(selected)} disabled={!!busy} className="min-h-11">
            <Sparkles className="h-4 w-4 mr-1.5" />
            {busy === "translate" ? "Fordítás folyamatban…" : `Kiválasztott nyelvek (${selected.length})`}
          </Button>
          <Button
            variant="secondary"
            onClick={() => run([...TARGETS])}
            disabled={!!busy}
            className="min-h-11"
          >
            <Sparkles className="h-4 w-4 mr-1.5" />
            Teljes fordítás minden nyelvre ({TARGETS.length})
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

function SourceStringsTable() {
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [onlyMissing, setOnlyMissing] = useState(false);
  const [page, setPage] = useState(0);
  const LIMIT = 25;

  const q = useQuery({
    queryKey: ["i18n-source-strings", search, onlyMissing, page],
    queryFn: () =>
      listSourceStrings({
        data: { search: search || undefined, only_missing_description: onlyMissing, limit: LIMIT, offset: page * LIMIT },
      }),
  });

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base">Feliratok és magyarázatok</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex flex-wrap gap-2">
          <Input
            placeholder="Keresés kulcs / szöveg / magyarázat…"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(0);
            }}
            className="max-w-sm min-h-11"
          />
          <Button
            variant={onlyMissing ? "default" : "outline"}
            onClick={() => {
              setOnlyMissing((v) => !v);
              setPage(0);
            }}
            className="min-h-11"
          >
            Csak magyarázat nélküliek
          </Button>
        </div>

        <div className="space-y-2">
          {(q.data?.rows ?? []).map((row: any) => (
            <SourceStringRow key={row.id} row={row} onSaved={() => qc.invalidateQueries({ queryKey: ["i18n-source-strings"] })} />
          ))}
          {q.data && q.data.rows.length === 0 && (
            <p className="text-sm text-muted-foreground">Nincs találat. Futtasd a szinkront!</p>
          )}
        </div>

        <div className="flex items-center gap-2 text-sm">
          <Button variant="outline" size="sm" disabled={page === 0} onClick={() => setPage((p) => p - 1)}>
            Előző
          </Button>
          <span className="text-muted-foreground">
            {page * LIMIT + 1}–{Math.min((page + 1) * LIMIT, q.data?.count ?? 0)} / {q.data?.count ?? 0}
          </span>
          <Button
            variant="outline"
            size="sm"
            disabled={(page + 1) * LIMIT >= (q.data?.count ?? 0)}
            onClick={() => setPage((p) => p + 1)}
          >
            Következő
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

function SourceStringRow({ row, onSaved }: { row: any; onSaved: () => void }) {
  const [description, setDescription] = useState<string>(row.description ?? "");
  const [note, setNote] = useState<string>(row.translator_note ?? "");
  const [saving, setSaving] = useState(false);

  const dirty = description !== (row.description ?? "") || note !== (row.translator_note ?? "");

  async function save() {
    setSaving(true);
    try {
      await updateSourceString({
        data: { id: row.id, description: description || null, translator_note: note || null },
      });
      toast.success("Mentve");
      onSaved();
    } catch (e: any) {
      toast.error(e?.message ?? "Mentési hiba");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="rounded-lg border p-3 space-y-2">
      <div className="flex flex-wrap items-center gap-2">
        <code className="text-xs bg-muted px-1.5 py-0.5 rounded">{row.key}</code>
        <Badge variant="outline">{row.element_type}</Badge>
        {row.ai_described && <Badge variant="secondary">AI leírás</Badge>}
        {row.screen && <span className="text-xs text-muted-foreground">{row.screen}</span>}
      </div>
      <p className="text-sm font-medium">{row.source_text}</p>
      <div className="grid gap-2 sm:grid-cols-2">
        <div className="space-y-1">
          <Label className="text-xs">Részletes magyarázat</Label>
          <Textarea
            rows={2}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Mit jelent, hol jelenik meg, mire figyeljen a fordító…"
          />
        </div>
        <div className="space-y-1">
          <Label className="text-xs">Fordítói megjegyzés</Label>
          <Textarea rows={2} value={note} onChange={(e) => setNote(e.target.value)} placeholder="Pl. max 20 karakter, gomb felirat" />
        </div>
      </div>
      {dirty && (
        <Button size="sm" onClick={save} disabled={saving} className="min-h-11">
          <Save className="h-4 w-4 mr-1.5" />
          Mentés
        </Button>
      )}
    </div>
  );
}
