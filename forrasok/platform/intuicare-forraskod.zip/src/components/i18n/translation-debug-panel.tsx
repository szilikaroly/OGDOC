/**
 * TranslationDebugPanel — QA/admin overlay a hiányzó fordítási kulcsok
 * gyors felderítéséhez és újrafordíttatásához.
 *
 * Megjelenés:
 *   - Csak akkor renderelődik, ha `?tdebug=1` van a URL-ben, VAGY
 *     `localStorage.i18n_debug === "1"` (a widget kis fogaskerekével togglelhető).
 *   - Kis lebegő gomb bal-lent, badge-el a hiányzó kulcsok darabszámával.
 *   - Kattintásra kinyílik egy panel: aktuális nyelv, hiányzó kulcsok listája,
 *     „AI-fordítás most” gomb (translateBatch, force refresh), per-item retry.
 *
 * Miért kliens-oldali store? A missingKeyHandler már gyűjti a hiányzókat,
 * de a szerver-oldali `cms_missing_keys` tábla csak periodikusan frissül —
 * a kliens store azonnal (250ms debounce) mutatja, amit épp látunk a lapon.
 */
import { useEffect, useState, useSyncExternalStore } from "react";
import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Languages, RefreshCw, X, Sparkles, Trash2, ChevronDown, ChevronUp } from "lucide-react";
import { toast } from "sonner";
import { missingKeysStore } from "@/lib/i18n/missing-keys-store";
import { translateBatchSafe } from "@/lib/i18n/translate.functions";
import i18n from "@/i18n";

function useEnabled() {
  const [enabled, setEnabled] = useState(false);
  useEffect(() => {
    const check = () => {
      try {
        const url = new URL(window.location.href);
        const fromUrl = url.searchParams.get("tdebug") === "1";
        const fromLs = window.localStorage.getItem("i18n_debug") === "1";
        if (fromUrl) window.localStorage.setItem("i18n_debug", "1");
        setEnabled(fromUrl || fromLs);
      } catch { setEnabled(false); }
    };
    check();
    window.addEventListener("storage", check);
    return () => window.removeEventListener("storage", check);
  }, []);
  return [enabled, setEnabled] as const;
}

function useMissingKeys(lang: string) {
  return useSyncExternalStore(
    (cb) => missingKeysStore.subscribe(cb),
    () => missingKeysStore.list(lang),
    () => [],
  );
}

export function TranslationDebugPanel() {
  const [enabled, setEnabled] = useEnabled();
  const [open, setOpen] = useState(false);
  const { i18n: i18nInst } = useTranslation();
  const lang = i18nInst.language ?? "hu";
  const missing = useMissingKeys(lang);
  const [busy, setBusy] = useState(false);

  if (!enabled) return null;

  const disable = () => {
    try { window.localStorage.setItem("i18n_debug", "0"); } catch {/*ignore*/}
    setEnabled(false);
  };

  const retranslate = async (items: Array<{ key: string; source: string }>) => {
    if (lang === "hu") {
      toast.info("HU forrásnyelv — nincs mit fordítani");
      return;
    }
    if (items.length === 0) return;
    setBusy(true);
    try {
      const merged = await translateBatchSafe({
        items: items.map((i) => ({ key: i.key, source: i.source, namespace: "ui" })),
        target_lang: lang,
        kind: "ui",
        db_only: false, // force refresh — figyelmen kívül hagyja a cache-t
      });
      // Beépítjük az i18n-be
      const bundle: Record<string, any> = {};
      for (const [dotKey, value] of Object.entries(merged)) {
        const parts = dotKey.split(".");
        let cur: any = bundle;
        for (let i = 0; i < parts.length - 1; i++) {
          cur[parts[i]] = cur[parts[i]] ?? {};
          cur = cur[parts[i]];
        }
        cur[parts[parts.length - 1]] = value;
      }
      i18n.addResourceBundle(lang, "translation", bundle, true, true);
      // Sikeres kulcsok eltávolítása a store-ból
      for (const it of items) missingKeysStore.clearKey(lang, it.key);
      // Trigger UI re-render
      i18n.changeLanguage(lang);
      toast.success(`Újrafordítva: ${Object.keys(merged).length} kulcs`);
    } catch (e: any) {
      toast.error("Fordítás sikertelen", {
        description: e?.message?.slice(0, 200) ?? "Lehet, hogy nem vagy bejelentkezve.",
      });
    } finally {
      setBusy(false);
    }
  };

  const totalHits = missing.reduce((s, m) => s + m.hits, 0);

  return (
    <div className="fixed bottom-3 left-3 z-[90] max-w-[92vw]" style={{ pointerEvents: "auto" }}>
      {!open ? (
        <button
          onClick={() => setOpen(true)}
          className="inline-flex items-center gap-2 rounded-full bg-amber-500 text-white px-3 py-2 shadow-lg hover:bg-amber-600 min-h-11"
          title="i18n debug — hiányzó fordítási kulcsok"
        >
          <Languages className="size-4" />
          <span className="text-xs font-mono uppercase">{lang}</span>
          {missing.length > 0 && (
            <Badge className="bg-white text-amber-700 text-[10px] h-5">{missing.length}</Badge>
          )}
        </button>
      ) : (
        <Card className="w-[380px] max-w-[92vw] shadow-2xl border-amber-400">
          <CardHeader className="p-3 pb-2 flex flex-row items-center gap-2 space-y-0">
            <Languages className="size-4 text-amber-600" />
            <CardTitle className="text-sm flex-1">
              i18n hiányzó kulcsok <span className="font-mono uppercase text-xs">({lang})</span>
            </CardTitle>
            <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => setOpen(false)} title="Bezárás">
              <ChevronDown className="size-4" />
            </Button>
            <Button size="icon" variant="ghost" className="h-7 w-7" onClick={disable} title="Debug mód kikapcsolása">
              <X className="size-4" />
            </Button>
          </CardHeader>
          <CardContent className="p-3 pt-0 space-y-2">
            {missing.length === 0 ? (
              <p className="text-xs text-muted-foreground py-6 text-center">
                Nincs hiányzó kulcs ezen a nyelven a mostani nézetben 🎉
                <br />
                Navigálj az oldalak között — a hiányzókat automatikusan gyűjtjük.
              </p>
            ) : (
              <>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>{missing.length} egyedi kulcs · {totalHits} render</span>
                  <span>fordítás cache-elt DB-ből</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  <Button
                    size="sm" className="gap-1 min-h-9"
                    disabled={busy || lang === "hu"}
                    onClick={() => retranslate(missing.map((m) => ({ key: m.key, source: m.source })))}
                  >
                    {busy ? <RefreshCw className="size-3.5 animate-spin" /> : <Sparkles className="size-3.5" />}
                    AI újrafordítás ({missing.length})
                  </Button>
                  <Button
                    size="sm" variant="outline" className="gap-1 min-h-9"
                    onClick={() => missingKeysStore.clear(lang)}
                    title="Csak a lista ürítése — DB nem változik"
                  >
                    <Trash2 className="size-3.5" />Lista ürítése
                  </Button>
                </div>
                <div className="max-h-72 overflow-y-auto rounded border divide-y">
                  {missing.map((m) => (
                    <MissingRow
                      key={m.key}
                      entry={m}
                      busy={busy}
                      lang={lang}
                      onRetry={() => retranslate([{ key: m.key, source: m.source }])}
                    />
                  ))}
                </div>
              </>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function MissingRow({
  entry, busy, lang, onRetry,
}: {
  entry: { key: string; source: string; hits: number };
  busy: boolean;
  lang: string;
  onRetry: () => void;
}) {
  const [expanded, setExpanded] = useState(false);
  return (
    <div className="p-2 text-xs">
      <div className="flex items-center gap-1">
        <button
          onClick={() => setExpanded((v) => !v)}
          className="flex-1 text-left font-mono truncate hover:text-primary"
          title={entry.key}
        >
          {entry.key}
        </button>
        <Badge variant="outline" className="text-[10px] h-4 px-1">{entry.hits}×</Badge>
        <Button
          size="icon" variant="ghost" className="h-7 w-7"
          disabled={busy || lang === "hu"}
          onClick={onRetry}
          title={`Újrafordítás (${lang})`}
        >
          <Sparkles className="size-3.5" />
        </Button>
      </div>
      {expanded && (
        <div className="mt-1 pl-2 border-l-2 border-amber-300 text-muted-foreground whitespace-pre-wrap break-words">
          <span className="text-[10px] uppercase text-amber-700 font-semibold">HU forrás:</span>{" "}
          {entry.source}
        </div>
      )}
    </div>
  );
}
