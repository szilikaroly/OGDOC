/**
 * AI-fordító menü — nyitható popover bármely label vagy érték mellé.
 * 9 nyelv (en, hu, ro, sr, zh, fil, de, uk, ru), tenant-szintű cache.
 */
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Popover, PopoverTrigger, PopoverContent } from "@/components/ui/popover";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Languages, Sparkles, Save, AlertCircle, CheckCircle2 } from "lucide-react";
import {
  getTranslationsForKey,
  translateText,
  saveTranslation,
  SUPPORTED_LANGS,
  LANG_LABELS,
  type Lang,
} from "@/lib/i18n/translator.functions";

type Props = {
  /** Modul/csoport — pl. "questionnaires.items", "roles.label" */
  namespace: string;
  /** Stabil azonosító — pl. "phq9.item.1" vagy "role.szakorvos" */
  itemKey: string;
  /** Forrásszöveg (általában magyarul) */
  sourceText: string;
  sourceLang?: Lang;
  /** Trigger label (ha nincs, csak az ikon látszik) */
  label?: string;
  size?: "sm" | "icon";
};

export function TranslatorMenu({ namespace, itemKey, sourceText, sourceLang = "hu", label, size = "icon" }: Props) {
  const [open, setOpen] = useState(false);
  const [activeLang, setActiveLang] = useState<Lang>("en");
  const [drafts, setDrafts] = useState<Record<string, string>>({});

  const getFn = useServerFn(getTranslationsForKey);
  const translateFn = useServerFn(translateText);
  const saveFn = useServerFn(saveTranslation);
  const qc = useQueryClient();

  const queryKey = ["i18n", namespace, itemKey];

  const q = useQuery({
    queryKey,
    queryFn: () => getFn({ data: { namespace, key: itemKey } }),
    enabled: open,
  });

  const translateMut = useMutation({
    mutationFn: (target_langs: Lang[]) =>
      translateFn({
        data: {
          namespace,
          key: itemKey,
          source_text: sourceText,
          source_lang: sourceLang,
          target_langs,
          overwrite_edited: false,
        },
      }),
    onSuccess: () => qc.invalidateQueries({ queryKey }),
  });

  const saveMut = useMutation({
    mutationFn: ({ lang, value }: { lang: Lang; value: string }) =>
      saveFn({ data: { namespace, key: itemKey, source_text: sourceText, lang, value } }),
    onSuccess: (_d, vars) => {
      setDrafts((prev) => {
        const cp = { ...prev };
        delete cp[vars.lang];
        return cp;
      });
      qc.invalidateQueries({ queryKey });
    },
  });

  const cached = q.data ?? {};
  const missingLangs = SUPPORTED_LANGS.filter((l) => l !== sourceLang && !cached[l]);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          size={size === "icon" ? "icon" : "sm"}
          className="h-7 w-7 text-muted-foreground hover:text-foreground"
          title="Fordítások (AI)"
          aria-label="Fordítások"
        >
          <Languages className="h-4 w-4" />
          {label && size !== "icon" && <span className="ml-1 text-xs">{label}</span>}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[420px] p-0" align="end">
        <div className="border-b p-3">
          <div className="flex items-center justify-between gap-2">
            <div className="text-xs text-muted-foreground">
              <span className="font-medium text-foreground">{namespace}</span> · {itemKey}
            </div>
            <Button
              size="sm"
              variant="secondary"
              disabled={translateMut.isPending || missingLangs.length === 0}
              onClick={() => translateMut.mutate(missingLangs)}
            >
              <Sparkles className="mr-1 h-3 w-3" />
              {translateMut.isPending ? "Fordítás…" : `Hiányzók (${missingLangs.length})`}
            </Button>
          </div>
          <p className="mt-2 line-clamp-2 text-xs italic text-muted-foreground">"{sourceText}"</p>
          {translateMut.isError && (
            <p className="mt-2 flex items-center gap-1 text-xs text-destructive">
              <AlertCircle className="h-3 w-3" /> {(translateMut.error as Error).message}
            </p>
          )}
        </div>

        <Tabs value={activeLang} onValueChange={(v) => setActiveLang(v as Lang)}>
          <TabsList className="m-2 grid grid-cols-9 gap-0.5">
            {SUPPORTED_LANGS.map((l) => {
              const has = !!cached[l] || l === sourceLang;
              return (
                <TabsTrigger key={l} value={l} className="px-1 text-xs" title={LANG_LABELS[l]}>
                  <span className="relative">
                    {l.toUpperCase()}
                    {has && <span className="absolute -right-1 -top-1 h-1.5 w-1.5 rounded-full bg-emerald-500" />}
                  </span>
                </TabsTrigger>
              );
            })}
          </TabsList>

          {SUPPORTED_LANGS.map((l) => {
            const row = cached[l];
            const isSource = l === sourceLang;
            const currentValue = drafts[l] ?? row?.value ?? "";
            return (
              <TabsContent key={l} value={l} className="space-y-2 p-3 pt-1">
                <div className="flex items-center justify-between">
                  <div className="text-sm font-medium">{LANG_LABELS[l]}</div>
                  <div className="flex items-center gap-1.5">
                    {isSource && <Badge variant="outline" className="text-[10px]">forrás</Badge>}
                    {row?.edited_by_user && <Badge variant="secondary" className="text-[10px]">kézi</Badge>}
                    {row && !row.edited_by_user && <Badge variant="secondary" className="text-[10px]">AI</Badge>}
                  </div>
                </div>

                {isSource ? (
                  <Textarea value={sourceText} readOnly rows={3} className="text-sm" />
                ) : (
                  <>
                    <Textarea
                      value={currentValue}
                      onChange={(e) => setDrafts((p) => ({ ...p, [l]: e.target.value }))}
                      placeholder={row ? "" : "Még nincs fordítás — generálj vagy írd be."}
                      rows={3}
                      className="text-sm"
                    />
                    <div className="flex items-center justify-between gap-2">
                      <Button
                        size="sm"
                        variant="ghost"
                        disabled={translateMut.isPending}
                        onClick={() => translateMut.mutate([l])}
                      >
                        <Sparkles className="mr-1 h-3 w-3" />
                        {row ? "Újragenerálás" : "AI fordítás"}
                      </Button>
                      <Button
                        size="sm"
                        disabled={!drafts[l] || saveMut.isPending}
                        onClick={() => drafts[l] && saveMut.mutate({ lang: l, value: drafts[l] })}
                      >
                        <Save className="mr-1 h-3 w-3" />
                        Mentés
                      </Button>
                    </div>
                    {saveMut.isSuccess && saveMut.variables?.lang === l && (
                      <p className="flex items-center gap-1 text-xs text-emerald-600">
                        <CheckCircle2 className="h-3 w-3" /> Mentve.
                      </p>
                    )}
                  </>
                )}
              </TabsContent>
            );
          })}
        </Tabs>
      </PopoverContent>
    </Popover>
  );
}
