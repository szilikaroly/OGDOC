import { MessageSquare } from "lucide-react";

export function ReasonInput({
  value,
  onChange,
  placeholder,
  label,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  label?: string;
}) {
  return (
    <div className="flex items-center gap-2 px-3 py-2 rounded-md border border-dashed border-border bg-secondary/40">
      <MessageSquare className="size-3.5 text-muted-foreground shrink-0" />
      <div className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground shrink-0">
        {label ?? "Indoklás"}
      </div>
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder ?? "Opcionális — a következő művelet audit-bejegyzéséhez kapcsolódik"}
        className="flex-1 bg-transparent text-xs outline-none placeholder:text-muted-foreground/60"
      />
    </div>
  );
}
