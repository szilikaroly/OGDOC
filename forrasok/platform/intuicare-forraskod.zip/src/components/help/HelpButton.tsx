import { Link, useRouterState } from "@tanstack/react-router";
import { HelpCircle, ExternalLink, Lock, ListChecks, Lightbulb } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { findHelpEntry } from "@/lib/help/registry";

export function HelpButton() {
  const { location } = useRouterState();
  const entry = findHelpEntry(location.pathname);

  return (
    <Popover>
      <PopoverTrigger asChild>
        <button
          type="button"
          aria-label="Súgó az aktuális oldalhoz"
          title={entry ? `Súgó — ${entry.title}` : "Súgó"}
          className="inline-flex items-center justify-center size-8 rounded-md border border-border bg-background text-muted-foreground hover:text-primary hover:border-primary/40 transition-colors"
        >
          <HelpCircle className="size-4" />
        </button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-96 max-h-[70vh] overflow-y-auto">
        {!entry ? (
          <div className="text-sm text-muted-foreground">
            <p className="font-semibold text-foreground mb-1">Súgó</p>
            <p>Ehhez az oldalhoz még nincs gyors-súgó. Kérdezze az AI asszisztenst a jobb alsó panelen, vagy nyissa meg a kézikönyvet.</p>
            <Link to="/admin/szervezet-sugo" className="mt-2 inline-flex items-center gap-1 text-xs font-semibold text-primary hover:underline">
              Kézikönyv <ExternalLink className="size-3" />
            </Link>
          </div>
        ) : (
          <div className="space-y-3 text-sm">
            <header>
              <h3 className="font-bold text-base flex items-center gap-2">
                <HelpCircle className="size-4 text-primary" /> {entry.title}
              </h3>
            </header>
            <p className="text-muted-foreground leading-relaxed">{entry.summary}</p>

            {entry.steps && entry.steps.length > 0 && (
              <section>
                <div className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground mb-1 flex items-center gap-1">
                  <ListChecks className="size-3" /> Lépések
                </div>
                <ol className="list-decimal pl-5 space-y-1 text-xs">
                  {entry.steps.map((s, i) => <li key={i}>{s}</li>)}
                </ol>
              </section>
            )}

            {entry.tips && entry.tips.length > 0 && (
              <section className="rounded-md bg-primary/5 border border-primary/15 p-2">
                <div className="text-[10px] font-mono uppercase tracking-wider text-primary mb-1 flex items-center gap-1">
                  <Lightbulb className="size-3" /> Tippek
                </div>
                <ul className="list-disc pl-4 space-y-1 text-xs">
                  {entry.tips.map((s, i) => <li key={i}>{s}</li>)}
                </ul>
              </section>
            )}

            {entry.permissions && entry.permissions.length > 0 && (
              <div className="text-[10px] font-mono text-muted-foreground flex items-center gap-1">
                <Lock className="size-3" />
                Jogosultság: {entry.permissions.join(", ")}
              </div>
            )}

            {entry.related && entry.related.length > 0 && (
              <section>
                <div className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground mb-1">Kapcsolódó</div>
                <div className="flex flex-col gap-1">
                  {entry.related.map((l) => (
                    <Link
                      key={l.to}
                      to={l.to}
                      className="text-xs text-primary hover:underline inline-flex items-center gap-1"
                    >
                      <ExternalLink className="size-3" /> {l.label}
                    </Link>
                  ))}
                </div>
              </section>
            )}
          </div>
        )}
      </PopoverContent>
    </Popover>
  );
}
