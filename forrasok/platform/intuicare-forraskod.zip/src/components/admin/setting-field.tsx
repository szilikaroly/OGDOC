/**
 * Dinamikus mezőkomponens beállítás-katalógus alapján.
 */
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sparkles, RotateCcw, Info, Loader2, History } from "lucide-react";
import { useServerFn } from "@tanstack/react-start";
import { suggestSettingValue, explainSetting } from "@/lib/admin/ai-settings.functions";
import { getAudit } from "@/lib/admin/settings.functions";
import { toast } from "sonner";
import type { SettingDef } from "@/lib/admin/settings-catalog";

type Props = {
  def: SettingDef;
  value: unknown;
  onChange: (next: unknown) => void;
  onReset: () => void;
  brandContext?: string;
};

export function SettingField({ def, value, onChange, onReset, brandContext }: Props) {
  const [busy, setBusy] = useState(false);
  const [explanation, setExplanation] = useState<string | null>(null);
  const [showExpl, setShowExpl] = useState(false);
  const [auditRows, setAuditRows] = useState<Array<{ action: string; old_value: unknown; new_value: unknown; changed_at: string; changed_by: string | null }> | null>(null);
  const [showAudit, setShowAudit] = useState(false);
  const suggest = useServerFn(suggestSettingValue);
  const explain = useServerFn(explainSetting);
  const audit = useServerFn(getAudit);

  async function aiSuggest() {
    setBusy(true);
    try {
      const goal = window.prompt(`AI javaslat — mi a célod ehhez: "${def.label}"?`, "");
      if (goal === null) { setBusy(false); return; }
      const r = await suggest({ data: { namespace: def.namespace, key: def.key, currentValue: value, goal: goal || undefined, brandContext } });
      onChange(r.value);
      toast.success(`Javaslat: ${r.rationale || "kész"}`);
    } catch (e) {
      toast.error("AI hiba: " + (e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function fetchExplain() {
    setShowExpl((v) => !v);
    if (explanation) return;
    try {
      const r = await explain({ data: { namespace: def.namespace, key: def.key } });
      setExplanation(r.explanation);
    } catch (e) {
      setExplanation("Magyarázat hiba: " + (e as Error).message);
    }
  }
  async function fetchAudit() {
    setShowAudit((v) => !v);
    if (auditRows) return;
    try {
      const r = await audit({ data: { namespace: def.namespace, key: def.key, limit: 10 } });
      setAuditRows(r as any);
    } catch (e) {
      toast.error("Audit hiba: " + (e as Error).message);
      setAuditRows([]);
    }
  }

  return (
    <div className="border border-border/60 rounded-lg p-4 space-y-3 bg-card">
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <label className="text-sm font-medium">{def.label}</label>
            <Badge variant="outline" className="text-[10px] font-mono">{def.namespace}.{def.key}</Badge>
            {def.scope === "public" && <Badge variant="secondary" className="text-[10px]">publikus</Badge>}
          </div>
          <p className="text-xs text-muted-foreground mt-1">{def.description}</p>
        </div>
        <div className="flex gap-1 shrink-0">
          <Button type="button" variant="ghost" size="icon" title="AI magyarázat" onClick={fetchExplain}>
            <Info className="size-4" />
          </Button>
          <Button type="button" variant="ghost" size="icon" title="Változási napló" onClick={fetchAudit}>
            <History className="size-4" />
          </Button>
          <Button type="button" variant="ghost" size="icon" title="Visszaállítás alapra" onClick={onReset}>
            <RotateCcw className="size-4" />
          </Button>
          <Button type="button" variant="ghost" size="icon" title="AI javaslat" disabled={busy} onClick={aiSuggest}>
            {busy ? <Loader2 className="size-4 animate-spin" /> : <Sparkles className="size-4 text-primary" />}
          </Button>
        </div>
      </div>
      {showExpl && (
        <div className="text-xs bg-muted/50 rounded p-2 text-muted-foreground">
          {explanation ?? "Magyarázat betöltése…"}
        </div>
      )}
      {showAudit && (
        <div className="text-xs bg-muted/40 rounded p-2 space-y-1 max-h-40 overflow-y-auto">
          {auditRows === null && <div className="text-muted-foreground">Napló betöltése…</div>}
          {auditRows?.length === 0 && <div className="text-muted-foreground">Nincs napló bejegyzés.</div>}
          {auditRows?.map((r, i) => (
            <div key={i} className="border-l-2 border-border pl-2">
              <div className="text-[10px] text-muted-foreground">
                {new Date(r.changed_at).toLocaleString("hu-HU")} · {r.action}
              </div>
              <div className="font-mono text-[10px] truncate">
                {JSON.stringify(r.old_value)} → {JSON.stringify(r.new_value)}
              </div>
            </div>
          ))}
        </div>
      )}
      <FieldInput def={def} value={value} onChange={onChange} />
    </div>
  );
}

function FieldInput({ def, value, onChange }: { def: SettingDef; value: unknown; onChange: (v: unknown) => void }) {
  switch (def.type) {
    case "string":
      return <Input value={String(value ?? "")} onChange={(e) => onChange(e.target.value)} />;
    case "text":
      return <Textarea rows={3} value={String(value ?? "")} onChange={(e) => onChange(e.target.value)} />;
    case "markdown":
      return <Textarea rows={6} className="font-mono text-xs" value={String(value ?? "")} onChange={(e) => onChange(e.target.value)} />;
    case "number":
    case "duration_seconds":
      return <Input type="number" min={def.min} max={def.max} value={Number(value ?? 0)} onChange={(e) => onChange(e.target.value === "" ? 0 : Number(e.target.value))} />;
    case "boolean":
      return (
        <div className="flex items-center gap-2">
          <Switch checked={!!value} onCheckedChange={onChange} />
          <span className="text-xs text-muted-foreground">{value ? "Bekapcsolva" : "Kikapcsolva"}</span>
        </div>
      );
    case "color":
      return (
        <div className="flex gap-2 items-center">
          <input type="color" value={String(value ?? "#000000")} onChange={(e) => onChange(e.target.value)} className="size-10 rounded border" />
          <Input value={String(value ?? "")} onChange={(e) => onChange(e.target.value)} />
        </div>
      );
    case "enum":
      return (
        <select className="w-full h-9 rounded-md border border-input bg-background px-2 text-sm" value={String(value ?? "")} onChange={(e) => onChange(e.target.value)}>
          {(def.options ?? []).map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
        </select>
      );
    case "string_list":
    case "role_list": {
      const arr = Array.isArray(value) ? value : [];
      return (
        <Input
          value={arr.join(", ")}
          placeholder="vesszővel elválasztva"
          onChange={(e) => onChange(e.target.value.split(",").map((s) => s.trim()).filter(Boolean))}
        />
      );
    }
    case "json":
      return (
        <Textarea rows={6} className="font-mono text-xs"
          value={typeof value === "string" ? value : JSON.stringify(value, null, 2)}
          onChange={(e) => {
            try { onChange(JSON.parse(e.target.value)); } catch { onChange(e.target.value); }
          }} />
      );
    default:
      return <Input value={String(value ?? "")} onChange={(e) => onChange(e.target.value)} />;
  }
}
