/**
 * Páciens-kereső Combobox admin képernyőkhöz.
 * Szerveroldali keresés `searchPatientsForAdmin`-on keresztül, RLS-szel
 * korlátozva. Üres értéket is támogat (globális szabály).
 */
import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Check, ChevronsUpDown, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { searchPatientsForAdmin } from "@/lib/admin/lookups.functions";

export type PatientPickerValue = { id: string; label: string } | null;

export function PatientPicker({
  value,
  onChange,
  placeholder = "Páciens keresése (név, TAJ)",
  emptyLabel = "Globális (minden páciens)",
  className,
  ariaInvalid,
}: {
  value: PatientPickerValue;
  onChange: (v: PatientPickerValue) => void;
  placeholder?: string;
  emptyLabel?: string;
  className?: string;
  ariaInvalid?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const search = useServerFn(searchPatientsForAdmin);
  const { data, isFetching } = useQuery({
    queryKey: ["admin", "patient-search", q],
    queryFn: () => search({ data: { q } }),
    enabled: open,
    staleTime: 30_000,
  });

  // Reset search when closed
  useEffect(() => { if (!open) setQ(""); }, [open]);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          type="button"
          variant="outline"
          role="combobox"
          aria-invalid={ariaInvalid}
          aria-expanded={open}
          className={cn("w-full justify-between font-normal", !value && "text-muted-foreground", className)}
        >
          <span className="truncate">{value?.label ?? emptyLabel}</span>
          <div className="flex items-center gap-1">
            {value && (
              <X
                className="h-3 w-3 opacity-50 hover:opacity-100"
                onClick={(e) => { e.stopPropagation(); onChange(null); }}
              />
            )}
            <ChevronsUpDown className="h-4 w-4 opacity-50" />
          </div>
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[var(--radix-popover-trigger-width)] p-0" align="start">
        <Command shouldFilter={false}>
          <CommandInput placeholder={placeholder} value={q} onValueChange={setQ} />
          <CommandList>
            {isFetching && <div className="p-2 text-xs text-muted-foreground">Keresés…</div>}
            {!isFetching && (data?.length ?? 0) === 0 && (
              <CommandEmpty>Nincs találat. Írjon legalább 2 karaktert.</CommandEmpty>
            )}
            <CommandGroup>
              {(data ?? []).map((p) => {
                const label = `${p.vezeteknev ?? ""} ${p.keresztnev ?? ""}`.trim() || "—";
                return (
                  <CommandItem
                    key={p.id}
                    value={p.id}
                    onSelect={() => { onChange({ id: p.id, label }); setOpen(false); }}
                  >
                    <Check className={cn("mr-2 h-4 w-4", value?.id === p.id ? "opacity-100" : "opacity-0")} />
                    <div className="flex flex-col">
                      <span>{label}</span>
                      <span className="text-[10px] text-muted-foreground">
                        TAJ: {p.taj ?? "—"} · szül.: {p.szuletesi_datum ?? "—"}
                      </span>
                    </div>
                  </CommandItem>
                );
              })}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}
