export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      admin_audit_log: {
        Row: {
          action: string
          after_data: Json | null
          before_data: Json | null
          created_at: string
          id: string
          reason: string | null
          record_id: string | null
          summary: string | null
          table_name: string
          tenant_id: string | null
          user_id: string | null
        }
        Insert: {
          action: string
          after_data?: Json | null
          before_data?: Json | null
          created_at?: string
          id?: string
          reason?: string | null
          record_id?: string | null
          summary?: string | null
          table_name: string
          tenant_id?: string | null
          user_id?: string | null
        }
        Update: {
          action?: string
          after_data?: Json | null
          before_data?: Json | null
          created_at?: string
          id?: string
          reason?: string | null
          record_id?: string | null
          summary?: string | null
          table_name?: string
          tenant_id?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      ai_assistant_actions: {
        Row: {
          conversation_id: string
          created_at: string
          id: string
          kind: string
          payload: Json | null
          result: Json | null
          user_id: string
        }
        Insert: {
          conversation_id: string
          created_at?: string
          id?: string
          kind: string
          payload?: Json | null
          result?: Json | null
          user_id: string
        }
        Update: {
          conversation_id?: string
          created_at?: string
          id?: string
          kind?: string
          payload?: Json | null
          result?: Json | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "ai_assistant_actions_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      ai_setting_suggestions: {
        Row: {
          accepted: boolean
          accepted_at: string | null
          created_at: string
          created_by: string | null
          goal: string | null
          id: string
          model: string | null
          rationale: string | null
          suggested_value: Json
          target_key: string | null
          target_kind: string
          target_namespace: string | null
        }
        Insert: {
          accepted?: boolean
          accepted_at?: string | null
          created_at?: string
          created_by?: string | null
          goal?: string | null
          id?: string
          model?: string | null
          rationale?: string | null
          suggested_value: Json
          target_key?: string | null
          target_kind: string
          target_namespace?: string | null
        }
        Update: {
          accepted?: boolean
          accepted_at?: string | null
          created_at?: string
          created_by?: string | null
          goal?: string | null
          id?: string
          model?: string | null
          rationale?: string | null
          suggested_value?: Json
          target_key?: string | null
          target_kind?: string
          target_namespace?: string | null
        }
        Relationships: []
      }
      announcement_reads: {
        Row: {
          announcement_id: string
          read_at: string
          user_id: string
        }
        Insert: {
          announcement_id: string
          read_at?: string
          user_id: string
        }
        Update: {
          announcement_id?: string
          read_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "announcement_reads_announcement_id_fkey"
            columns: ["announcement_id"]
            isOneToOne: false
            referencedRelation: "announcements"
            referencedColumns: ["id"]
          },
        ]
      }
      announcements: {
        Row: {
          cel_org_unit_ids: string[]
          cel_szerepkorok: string[]
          cim: string
          created_at: string
          created_by: string | null
          id: string
          kategoria: string
          kep_url: string | null
          link: string | null
          prioritas: string
          publikalt: boolean
          publikalva_ig: string | null
          publikalva_tol: string
          rogzitett: boolean
          tartalom: string
          tenant_id: string
          updated_at: string
        }
        Insert: {
          cel_org_unit_ids?: string[]
          cel_szerepkorok?: string[]
          cim: string
          created_at?: string
          created_by?: string | null
          id?: string
          kategoria?: string
          kep_url?: string | null
          link?: string | null
          prioritas?: string
          publikalt?: boolean
          publikalva_ig?: string | null
          publikalva_tol?: string
          rogzitett?: boolean
          tartalom: string
          tenant_id: string
          updated_at?: string
        }
        Update: {
          cel_org_unit_ids?: string[]
          cel_szerepkorok?: string[]
          cim?: string
          created_at?: string
          created_by?: string | null
          id?: string
          kategoria?: string
          kep_url?: string | null
          link?: string | null
          prioritas?: string
          publikalt?: boolean
          publikalva_ig?: string | null
          publikalva_tol?: string
          rogzitett?: boolean
          tartalom?: string
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "announcements_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "announcements_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "announcements_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      app_settings: {
        Row: {
          created_at: string
          draft_value: Json | null
          id: string
          is_public: boolean
          key: string
          namespace: string
          schema_version: number
          updated_at: string
          updated_by: string | null
          value: Json
        }
        Insert: {
          created_at?: string
          draft_value?: Json | null
          id?: string
          is_public?: boolean
          key: string
          namespace: string
          schema_version?: number
          updated_at?: string
          updated_by?: string | null
          value?: Json
        }
        Update: {
          created_at?: string
          draft_value?: Json | null
          id?: string
          is_public?: boolean
          key?: string
          namespace?: string
          schema_version?: number
          updated_at?: string
          updated_by?: string | null
          value?: Json
        }
        Relationships: []
      }
      app_settings_audit: {
        Row: {
          action: string
          changed_at: string
          changed_by: string | null
          id: string
          key: string
          namespace: string
          new_value: Json | null
          old_value: Json | null
          reason: string | null
          setting_id: string | null
        }
        Insert: {
          action: string
          changed_at?: string
          changed_by?: string | null
          id?: string
          key: string
          namespace: string
          new_value?: Json | null
          old_value?: Json | null
          reason?: string | null
          setting_id?: string | null
        }
        Update: {
          action?: string
          changed_at?: string
          changed_by?: string | null
          id?: string
          key?: string
          namespace?: string
          new_value?: Json | null
          old_value?: Json | null
          reason?: string | null
          setting_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "app_settings_audit_setting_id_fkey"
            columns: ["setting_id"]
            isOneToOne: false
            referencedRelation: "app_settings"
            referencedColumns: ["id"]
          },
        ]
      }
      appointment_resources: {
        Row: {
          aktiv: boolean
          created_at: string
          id: string
          leiras: string | null
          nev: string
          org_unit_id: string | null
          orvos_id: string | null
          publikus: boolean
          szakma_id: string | null
          szin: string | null
          tenant_id: string
          tipus: Database["public"]["Enums"]["appt_resource_tipus"]
          updated_at: string
        }
        Insert: {
          aktiv?: boolean
          created_at?: string
          id?: string
          leiras?: string | null
          nev: string
          org_unit_id?: string | null
          orvos_id?: string | null
          publikus?: boolean
          szakma_id?: string | null
          szin?: string | null
          tenant_id: string
          tipus: Database["public"]["Enums"]["appt_resource_tipus"]
          updated_at?: string
        }
        Update: {
          aktiv?: boolean
          created_at?: string
          id?: string
          leiras?: string | null
          nev?: string
          org_unit_id?: string | null
          orvos_id?: string | null
          publikus?: boolean
          szakma_id?: string | null
          szin?: string | null
          tenant_id?: string
          tipus?: Database["public"]["Enums"]["appt_resource_tipus"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "appointment_resources_org_unit_id_fkey"
            columns: ["org_unit_id"]
            isOneToOne: false
            referencedRelation: "org_unit_conflicts"
            referencedColumns: ["org_unit_id"]
          },
          {
            foreignKeyName: "appointment_resources_org_unit_id_fkey"
            columns: ["org_unit_id"]
            isOneToOne: false
            referencedRelation: "org_units"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "appointment_resources_orvos_id_fkey"
            columns: ["orvos_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "appointment_resources_orvos_id_fkey"
            columns: ["orvos_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "appointment_resources_szakma_id_fkey"
            columns: ["szakma_id"]
            isOneToOne: false
            referencedRelation: "specialties"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "appointment_resources_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      appointment_slots: {
        Row: {
          created_at: string
          foglalt_szam: number
          id: string
          kapacitas: number
          kezdo_ts: string
          org_unit_id: string | null
          resource_id: string
          status: Database["public"]["Enums"]["appt_slot_status"]
          template_id: string | null
          tenant_id: string
          updated_at: string
          veg_ts: string
          version: number
        }
        Insert: {
          created_at?: string
          foglalt_szam?: number
          id?: string
          kapacitas?: number
          kezdo_ts: string
          org_unit_id?: string | null
          resource_id: string
          status?: Database["public"]["Enums"]["appt_slot_status"]
          template_id?: string | null
          tenant_id: string
          updated_at?: string
          veg_ts: string
          version?: number
        }
        Update: {
          created_at?: string
          foglalt_szam?: number
          id?: string
          kapacitas?: number
          kezdo_ts?: string
          org_unit_id?: string | null
          resource_id?: string
          status?: Database["public"]["Enums"]["appt_slot_status"]
          template_id?: string | null
          tenant_id?: string
          updated_at?: string
          veg_ts?: string
          version?: number
        }
        Relationships: [
          {
            foreignKeyName: "appointment_slots_org_unit_id_fkey"
            columns: ["org_unit_id"]
            isOneToOne: false
            referencedRelation: "org_unit_conflicts"
            referencedColumns: ["org_unit_id"]
          },
          {
            foreignKeyName: "appointment_slots_org_unit_id_fkey"
            columns: ["org_unit_id"]
            isOneToOne: false
            referencedRelation: "org_units"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "appointment_slots_resource_id_fkey"
            columns: ["resource_id"]
            isOneToOne: false
            referencedRelation: "appointment_resources"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "appointment_slots_template_id_fkey"
            columns: ["template_id"]
            isOneToOne: false
            referencedRelation: "appointment_templates"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "appointment_slots_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      appointment_status_events: {
        Row: {
          actor_id: string | null
          appointment_id: string
          created_at: string
          from_status: Database["public"]["Enums"]["appt_status"] | null
          id: string
          metadata: Json
          reason: string | null
          tenant_id: string
          to_status: Database["public"]["Enums"]["appt_status"]
        }
        Insert: {
          actor_id?: string | null
          appointment_id: string
          created_at?: string
          from_status?: Database["public"]["Enums"]["appt_status"] | null
          id?: string
          metadata?: Json
          reason?: string | null
          tenant_id: string
          to_status: Database["public"]["Enums"]["appt_status"]
        }
        Update: {
          actor_id?: string | null
          appointment_id?: string
          created_at?: string
          from_status?: Database["public"]["Enums"]["appt_status"] | null
          id?: string
          metadata?: Json
          reason?: string | null
          tenant_id?: string
          to_status?: Database["public"]["Enums"]["appt_status"]
        }
        Relationships: [
          {
            foreignKeyName: "appointment_status_events_actor_id_fkey"
            columns: ["actor_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "appointment_status_events_actor_id_fkey"
            columns: ["actor_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "appointment_status_events_appointment_id_fkey"
            columns: ["appointment_id"]
            isOneToOne: false
            referencedRelation: "appointments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "appointment_status_events_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      appointment_templates: {
        Row: {
          aktiv: boolean
          created_at: string
          ervenyes_ig: string | null
          ervenyes_tol: string
          id: string
          kapacitas: number
          kezd_ido: string
          napok: number[]
          nev: string
          resource_id: string
          slot_perc: number
          tenant_id: string
          unnepnap_uzemel: boolean
          updated_at: string
          veg_ido: string
        }
        Insert: {
          aktiv?: boolean
          created_at?: string
          ervenyes_ig?: string | null
          ervenyes_tol?: string
          id?: string
          kapacitas?: number
          kezd_ido: string
          napok: number[]
          nev: string
          resource_id: string
          slot_perc?: number
          tenant_id: string
          unnepnap_uzemel?: boolean
          updated_at?: string
          veg_ido: string
        }
        Update: {
          aktiv?: boolean
          created_at?: string
          ervenyes_ig?: string | null
          ervenyes_tol?: string
          id?: string
          kapacitas?: number
          kezd_ido?: string
          napok?: number[]
          nev?: string
          resource_id?: string
          slot_perc?: number
          tenant_id?: string
          unnepnap_uzemel?: boolean
          updated_at?: string
          veg_ido?: string
        }
        Relationships: [
          {
            foreignKeyName: "appointment_templates_resource_id_fkey"
            columns: ["resource_id"]
            isOneToOne: false
            referencedRelation: "appointment_resources"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "appointment_templates_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      appointments: {
        Row: {
          created_at: string
          created_by: string | null
          eeszt_idopont_id: string | null
          email_megerositve_at: string | null
          external_ref: string | null
          foglalas_kod: string
          gdpr_consent_at: string | null
          id: string
          idempotency_key: string
          megjegyzes: string | null
          ok: string | null
          patient_id: string | null
          resource_id: string
          slot_id: string
          status: Database["public"]["Enums"]["appt_status"]
          sync_statusz: Database["public"]["Enums"]["appt_sync_statusz"]
          tenant_id: string
          updated_at: string
          vendeg_email: string | null
          vendeg_nev: string | null
          vendeg_szuletesi_datum: string | null
          vendeg_telefon: string | null
          version: number
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          eeszt_idopont_id?: string | null
          email_megerositve_at?: string | null
          external_ref?: string | null
          foglalas_kod: string
          gdpr_consent_at?: string | null
          id?: string
          idempotency_key?: string
          megjegyzes?: string | null
          ok?: string | null
          patient_id?: string | null
          resource_id: string
          slot_id: string
          status?: Database["public"]["Enums"]["appt_status"]
          sync_statusz?: Database["public"]["Enums"]["appt_sync_statusz"]
          tenant_id: string
          updated_at?: string
          vendeg_email?: string | null
          vendeg_nev?: string | null
          vendeg_szuletesi_datum?: string | null
          vendeg_telefon?: string | null
          version?: number
        }
        Update: {
          created_at?: string
          created_by?: string | null
          eeszt_idopont_id?: string | null
          email_megerositve_at?: string | null
          external_ref?: string | null
          foglalas_kod?: string
          gdpr_consent_at?: string | null
          id?: string
          idempotency_key?: string
          megjegyzes?: string | null
          ok?: string | null
          patient_id?: string | null
          resource_id?: string
          slot_id?: string
          status?: Database["public"]["Enums"]["appt_status"]
          sync_statusz?: Database["public"]["Enums"]["appt_sync_statusz"]
          tenant_id?: string
          updated_at?: string
          vendeg_email?: string | null
          vendeg_nev?: string | null
          vendeg_szuletesi_datum?: string | null
          vendeg_telefon?: string | null
          version?: number
        }
        Relationships: [
          {
            foreignKeyName: "appointments_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "appointments_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "appointments_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "appointments_resource_id_fkey"
            columns: ["resource_id"]
            isOneToOne: false
            referencedRelation: "appointment_resources"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "appointments_slot_id_fkey"
            columns: ["slot_id"]
            isOneToOne: false
            referencedRelation: "appointment_slots"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "appointments_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      assignment_reminder_log: {
        Row: {
          assignment_id: string
          bucket_days: number
          channel: Database["public"]["Enums"]["reminder_channel"]
          id: string
          notes: string | null
          sent_at: string
          tenant_id: string
        }
        Insert: {
          assignment_id: string
          bucket_days: number
          channel?: Database["public"]["Enums"]["reminder_channel"]
          id?: string
          notes?: string | null
          sent_at?: string
          tenant_id: string
        }
        Update: {
          assignment_id?: string
          bucket_days?: number
          channel?: Database["public"]["Enums"]["reminder_channel"]
          id?: string
          notes?: string | null
          sent_at?: string
          tenant_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "assignment_reminder_log_assignment_id_fkey"
            columns: ["assignment_id"]
            isOneToOne: false
            referencedRelation: "questionnaire_assignments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "assignment_reminder_log_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      attendance_anchors: {
        Row: {
          created_at: string
          ervenyes: boolean
          geo_lat: number | null
          geo_lng: number | null
          geo_sugar_m: number | null
          id: string
          ip_cidr: string | null
          nev: string
          nfc_uid: string | null
          org_unit_id: string | null
          qr_secret: string | null
          site_id: string | null
          tenant_id: string
          tipus: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          ervenyes?: boolean
          geo_lat?: number | null
          geo_lng?: number | null
          geo_sugar_m?: number | null
          id?: string
          ip_cidr?: string | null
          nev: string
          nfc_uid?: string | null
          org_unit_id?: string | null
          qr_secret?: string | null
          site_id?: string | null
          tenant_id: string
          tipus?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          ervenyes?: boolean
          geo_lat?: number | null
          geo_lng?: number | null
          geo_sugar_m?: number | null
          id?: string
          ip_cidr?: string | null
          nev?: string
          nfc_uid?: string | null
          org_unit_id?: string | null
          qr_secret?: string | null
          site_id?: string | null
          tenant_id?: string
          tipus?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "attendance_anchors_org_unit_id_fkey"
            columns: ["org_unit_id"]
            isOneToOne: false
            referencedRelation: "org_unit_conflicts"
            referencedColumns: ["org_unit_id"]
          },
          {
            foreignKeyName: "attendance_anchors_org_unit_id_fkey"
            columns: ["org_unit_id"]
            isOneToOne: false
            referencedRelation: "org_units"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "attendance_anchors_site_id_fkey"
            columns: ["site_id"]
            isOneToOne: false
            referencedRelation: "sites"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "attendance_anchors_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      attendance_events: {
        Row: {
          anchor_id: string | null
          created_at: string
          esemeny_tipus: Database["public"]["Enums"]["attendance_event_type"]
          eszkoz_azonosito: string | null
          geo_lat: number | null
          geo_lng: number | null
          geo_pontossag_m: number | null
          horgony_egyezes: boolean | null
          id: string
          idopont: string
          ip_cim: unknown
          korrigalo_id: string | null
          megjegyzes: string | null
          modszer: Database["public"]["Enums"]["attendance_method"]
          tenant_id: string
          user_agent: string | null
          user_id: string
        }
        Insert: {
          anchor_id?: string | null
          created_at?: string
          esemeny_tipus: Database["public"]["Enums"]["attendance_event_type"]
          eszkoz_azonosito?: string | null
          geo_lat?: number | null
          geo_lng?: number | null
          geo_pontossag_m?: number | null
          horgony_egyezes?: boolean | null
          id?: string
          idopont?: string
          ip_cim?: unknown
          korrigalo_id?: string | null
          megjegyzes?: string | null
          modszer?: Database["public"]["Enums"]["attendance_method"]
          tenant_id: string
          user_agent?: string | null
          user_id: string
        }
        Update: {
          anchor_id?: string | null
          created_at?: string
          esemeny_tipus?: Database["public"]["Enums"]["attendance_event_type"]
          eszkoz_azonosito?: string | null
          geo_lat?: number | null
          geo_lng?: number | null
          geo_pontossag_m?: number | null
          horgony_egyezes?: boolean | null
          id?: string
          idopont?: string
          ip_cim?: unknown
          korrigalo_id?: string | null
          megjegyzes?: string | null
          modszer?: Database["public"]["Enums"]["attendance_method"]
          tenant_id?: string
          user_agent?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "attendance_events_anchor_id_fkey"
            columns: ["anchor_id"]
            isOneToOne: false
            referencedRelation: "attendance_anchors"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "attendance_events_korrigalo_id_fkey"
            columns: ["korrigalo_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "attendance_events_korrigalo_id_fkey"
            columns: ["korrigalo_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "attendance_events_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "attendance_events_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "attendance_events_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      beavatkozas_skill: {
        Row: {
          beavatkozas_id: string
          created_at: string
          id: string
          min_szint: number
          skill_id: string
        }
        Insert: {
          beavatkozas_id: string
          created_at?: string
          id?: string
          min_szint?: number
          skill_id: string
        }
        Update: {
          beavatkozas_id?: string
          created_at?: string
          id?: string
          min_szint?: number
          skill_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "beavatkozas_skill_beavatkozas_id_fkey"
            columns: ["beavatkozas_id"]
            isOneToOne: false
            referencedRelation: "beavatkozasok"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "beavatkozas_skill_skill_id_fkey"
            columns: ["skill_id"]
            isOneToOne: false
            referencedRelation: "skills"
            referencedColumns: ["id"]
          },
        ]
      }
      beavatkozasok: {
        Row: {
          aktiv: boolean
          created_at: string
          id: string
          kod: string | null
          leiras: string | null
          nev: string
          specialty_id: string | null
          tenant_id: string
          updated_at: string
        }
        Insert: {
          aktiv?: boolean
          created_at?: string
          id?: string
          kod?: string | null
          leiras?: string | null
          nev: string
          specialty_id?: string | null
          tenant_id: string
          updated_at?: string
        }
        Update: {
          aktiv?: boolean
          created_at?: string
          id?: string
          kod?: string | null
          leiras?: string | null
          nev?: string
          specialty_id?: string | null
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "beavatkozasok_specialty_id_fkey"
            columns: ["specialty_id"]
            isOneToOne: false
            referencedRelation: "specialties"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "beavatkozasok_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      case_resource_requirements: {
        Row: {
          created_at: string
          eroforras_tipus: Database["public"]["Enums"]["or_eroforras_tipus_enum"]
          foglalas_statusz: Database["public"]["Enums"]["or_resource_req_status_enum"]
          id: string
          mennyiseg: number
          mikortol: Database["public"]["Enums"]["or_resource_req_when_enum"]
          surgery_case_id: string
          tenant_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          eroforras_tipus: Database["public"]["Enums"]["or_eroforras_tipus_enum"]
          foglalas_statusz?: Database["public"]["Enums"]["or_resource_req_status_enum"]
          id?: string
          mennyiseg?: number
          mikortol?: Database["public"]["Enums"]["or_resource_req_when_enum"]
          surgery_case_id: string
          tenant_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          eroforras_tipus?: Database["public"]["Enums"]["or_eroforras_tipus_enum"]
          foglalas_statusz?: Database["public"]["Enums"]["or_resource_req_status_enum"]
          id?: string
          mennyiseg?: number
          mikortol?: Database["public"]["Enums"]["or_resource_req_when_enum"]
          surgery_case_id?: string
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "case_resource_requirements_surgery_case_id_fkey"
            columns: ["surgery_case_id"]
            isOneToOne: false
            referencedRelation: "surgery_cases"
            referencedColumns: ["id"]
          },
        ]
      }
      chat_messages: {
        Row: {
          content: string
          created_at: string
          id: string
          parts: Json | null
          role: string
          user_id: string
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          parts?: Json | null
          role: string
          user_id: string
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          parts?: Json | null
          role?: string
          user_id?: string
        }
        Relationships: []
      }
      clinical_alert_escalation_rules: {
        Row: {
          active: boolean
          created_at: string
          created_by: string | null
          escalate_after_minutes: number
          id: string
          name: string
          severity: string | null
          source: string | null
          target_role: string | null
          tenant_id: string
          updated_at: string
        }
        Insert: {
          active?: boolean
          created_at?: string
          created_by?: string | null
          escalate_after_minutes?: number
          id?: string
          name: string
          severity?: string | null
          source?: string | null
          target_role?: string | null
          tenant_id: string
          updated_at?: string
        }
        Update: {
          active?: boolean
          created_at?: string
          created_by?: string | null
          escalate_after_minutes?: number
          id?: string
          name?: string
          severity?: string | null
          source?: string | null
          target_role?: string | null
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "clinical_alert_escalation_rules_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      clinical_alert_status_log: {
        Row: {
          actor_id: string | null
          alert_id: string
          created_at: string
          from_status: string | null
          id: string
          note: string | null
          to_status: string
        }
        Insert: {
          actor_id?: string | null
          alert_id: string
          created_at?: string
          from_status?: string | null
          id?: string
          note?: string | null
          to_status: string
        }
        Update: {
          actor_id?: string | null
          alert_id?: string
          created_at?: string
          from_status?: string | null
          id?: string
          note?: string | null
          to_status?: string
        }
        Relationships: [
          {
            foreignKeyName: "clinical_alert_status_log_alert_id_fkey"
            columns: ["alert_id"]
            isOneToOne: false
            referencedRelation: "clinical_critical_alerts"
            referencedColumns: ["id"]
          },
        ]
      }
      clinical_calculator_results: {
        Row: {
          calculator: string
          created_at: string
          created_by: string
          encounter_id: string | null
          id: string
          inputs_json: Json
          interpretation_md: string | null
          outputs_json: Json
          patient_id: string | null
          updated_at: string
        }
        Insert: {
          calculator: string
          created_at?: string
          created_by: string
          encounter_id?: string | null
          id?: string
          inputs_json: Json
          interpretation_md?: string | null
          outputs_json: Json
          patient_id?: string | null
          updated_at?: string
        }
        Update: {
          calculator?: string
          created_at?: string
          created_by?: string
          encounter_id?: string | null
          id?: string
          inputs_json?: Json
          interpretation_md?: string | null
          outputs_json?: Json
          patient_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "clinical_calculator_results_encounter_id_fkey"
            columns: ["encounter_id"]
            isOneToOne: false
            referencedRelation: "clinical_encounters"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "clinical_calculator_results_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      clinical_critical_alerts: {
        Row: {
          acknowledged_at: string | null
          acknowledged_by: string | null
          code: string
          created_at: string
          created_by: string | null
          encounter_id: string | null
          escalated_at: string | null
          id: string
          message: string
          patient_id: string
          severity: string
          source: string
          triggered_at: string
          value_json: Json | null
          workflow_status: string
        }
        Insert: {
          acknowledged_at?: string | null
          acknowledged_by?: string | null
          code: string
          created_at?: string
          created_by?: string | null
          encounter_id?: string | null
          escalated_at?: string | null
          id?: string
          message: string
          patient_id: string
          severity: string
          source: string
          triggered_at?: string
          value_json?: Json | null
          workflow_status?: string
        }
        Update: {
          acknowledged_at?: string | null
          acknowledged_by?: string | null
          code?: string
          created_at?: string
          created_by?: string | null
          encounter_id?: string | null
          escalated_at?: string | null
          id?: string
          message?: string
          patient_id?: string
          severity?: string
          source?: string
          triggered_at?: string
          value_json?: Json | null
          workflow_status?: string
        }
        Relationships: [
          {
            foreignKeyName: "clinical_critical_alerts_encounter_id_fkey"
            columns: ["encounter_id"]
            isOneToOne: false
            referencedRelation: "clinical_encounters"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "clinical_critical_alerts_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      clinical_diagnoses: {
        Row: {
          certainty: string
          created_at: string
          created_by: string
          display: string
          encounter_id: string
          icd10_code: string | null
          id: string
          is_primary: boolean
          note: string | null
          onset_date: string | null
          patient_id: string
          snomed_code: string | null
          updated_at: string
        }
        Insert: {
          certainty?: string
          created_at?: string
          created_by: string
          display: string
          encounter_id: string
          icd10_code?: string | null
          id?: string
          is_primary?: boolean
          note?: string | null
          onset_date?: string | null
          patient_id: string
          snomed_code?: string | null
          updated_at?: string
        }
        Update: {
          certainty?: string
          created_at?: string
          created_by?: string
          display?: string
          encounter_id?: string
          icd10_code?: string | null
          id?: string
          is_primary?: boolean
          note?: string | null
          onset_date?: string | null
          patient_id?: string
          snomed_code?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "clinical_diagnoses_encounter_id_fkey"
            columns: ["encounter_id"]
            isOneToOne: false
            referencedRelation: "clinical_encounters"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "clinical_diagnoses_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      clinical_drug_statuses: {
        Row: {
          created_at: string
          created_by: string
          drug_id: string
          encounter_id: string | null
          id: string
          notes: string | null
          patient_id: string
          status: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by: string
          drug_id: string
          encounter_id?: string | null
          id?: string
          notes?: string | null
          patient_id: string
          status: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string
          drug_id?: string
          encounter_id?: string | null
          id?: string
          notes?: string | null
          patient_id?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "clinical_drug_statuses_encounter_id_fkey"
            columns: ["encounter_id"]
            isOneToOne: false
            referencedRelation: "clinical_encounters"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "clinical_drug_statuses_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      clinical_encounters: {
        Row: {
          chief_complaint: string | null
          closed_by: string | null
          created_at: string
          created_by: string
          encounter_type: string
          end_ts: string | null
          id: string
          location: string | null
          patient_id: string
          start_ts: string
          status: string
          tenant_id: string | null
          updated_at: string
        }
        Insert: {
          chief_complaint?: string | null
          closed_by?: string | null
          created_at?: string
          created_by: string
          encounter_type?: string
          end_ts?: string | null
          id?: string
          location?: string | null
          patient_id: string
          start_ts?: string
          status?: string
          tenant_id?: string | null
          updated_at?: string
        }
        Update: {
          chief_complaint?: string | null
          closed_by?: string | null
          created_at?: string
          created_by?: string
          encounter_type?: string
          end_ts?: string | null
          id?: string
          location?: string | null
          patient_id?: string
          start_ts?: string
          status?: string
          tenant_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "clinical_encounters_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      clinical_insulin_sessions: {
        Row: {
          basal: number | null
          basal_prep_id: string | null
          bolus_d: number | null
          bolus_e: number | null
          bolus_prep_id: string | null
          bolus_r: number | null
          bolus_type: string | null
          correction_bolus: number | null
          created_at: string
          created_by: string
          current_vc: number | null
          diabetes_type: string
          encounter_id: string | null
          icr: number | null
          id: string
          isf: number | null
          meal_ratio: string | null
          mode: string
          modifiers_json: Json
          notes: string | null
          patient_id: string
          premix_prep_id: string | null
          session_date: string
          target_vc: number | null
          tdd: number | null
          updated_at: string
          weight_kg: number
        }
        Insert: {
          basal?: number | null
          basal_prep_id?: string | null
          bolus_d?: number | null
          bolus_e?: number | null
          bolus_prep_id?: string | null
          bolus_r?: number | null
          bolus_type?: string | null
          correction_bolus?: number | null
          created_at?: string
          created_by: string
          current_vc?: number | null
          diabetes_type: string
          encounter_id?: string | null
          icr?: number | null
          id?: string
          isf?: number | null
          meal_ratio?: string | null
          mode: string
          modifiers_json?: Json
          notes?: string | null
          patient_id: string
          premix_prep_id?: string | null
          session_date?: string
          target_vc?: number | null
          tdd?: number | null
          updated_at?: string
          weight_kg: number
        }
        Update: {
          basal?: number | null
          basal_prep_id?: string | null
          bolus_d?: number | null
          bolus_e?: number | null
          bolus_prep_id?: string | null
          bolus_r?: number | null
          bolus_type?: string | null
          correction_bolus?: number | null
          created_at?: string
          created_by?: string
          current_vc?: number | null
          diabetes_type?: string
          encounter_id?: string | null
          icr?: number | null
          id?: string
          isf?: number | null
          meal_ratio?: string | null
          mode?: string
          modifiers_json?: Json
          notes?: string | null
          patient_id?: string
          premix_prep_id?: string | null
          session_date?: string
          target_vc?: number | null
          tdd?: number | null
          updated_at?: string
          weight_kg?: number
        }
        Relationships: [
          {
            foreignKeyName: "clinical_insulin_sessions_encounter_id_fkey"
            columns: ["encounter_id"]
            isOneToOne: false
            referencedRelation: "clinical_encounters"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "clinical_insulin_sessions_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      clinical_notes: {
        Row: {
          ai_generated: boolean
          author_id: string
          body_md: string | null
          created_at: string
          encounter_id: string
          id: string
          kind: string
          parent_note_id: string | null
          patient_id: string
          signed_at: string | null
          signed_by: string | null
          structured_json: Json | null
          title: string | null
          updated_at: string
          version: number
        }
        Insert: {
          ai_generated?: boolean
          author_id: string
          body_md?: string | null
          created_at?: string
          encounter_id: string
          id?: string
          kind: string
          parent_note_id?: string | null
          patient_id: string
          signed_at?: string | null
          signed_by?: string | null
          structured_json?: Json | null
          title?: string | null
          updated_at?: string
          version?: number
        }
        Update: {
          ai_generated?: boolean
          author_id?: string
          body_md?: string | null
          created_at?: string
          encounter_id?: string
          id?: string
          kind?: string
          parent_note_id?: string | null
          patient_id?: string
          signed_at?: string | null
          signed_by?: string | null
          structured_json?: Json | null
          title?: string | null
          updated_at?: string
          version?: number
        }
        Relationships: [
          {
            foreignKeyName: "clinical_notes_encounter_id_fkey"
            columns: ["encounter_id"]
            isOneToOne: false
            referencedRelation: "clinical_encounters"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "clinical_notes_parent_note_id_fkey"
            columns: ["parent_note_id"]
            isOneToOne: false
            referencedRelation: "clinical_notes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "clinical_notes_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      clinical_observations: {
        Row: {
          category: string
          code_display: string
          created_at: string
          effective_ts: string
          encounter_id: string
          id: string
          interpretation: string | null
          loinc_code: string | null
          patient_id: string
          performer_id: string | null
          snomed_code: string | null
          source: string
          updated_at: string
          value_json: Json | null
          value_quantity: number | null
          value_string: string | null
          value_unit: string | null
        }
        Insert: {
          category: string
          code_display: string
          created_at?: string
          effective_ts?: string
          encounter_id: string
          id?: string
          interpretation?: string | null
          loinc_code?: string | null
          patient_id: string
          performer_id?: string | null
          snomed_code?: string | null
          source?: string
          updated_at?: string
          value_json?: Json | null
          value_quantity?: number | null
          value_string?: string | null
          value_unit?: string | null
        }
        Update: {
          category?: string
          code_display?: string
          created_at?: string
          effective_ts?: string
          encounter_id?: string
          id?: string
          interpretation?: string | null
          loinc_code?: string | null
          patient_id?: string
          performer_id?: string | null
          snomed_code?: string | null
          source?: string
          updated_at?: string
          value_json?: Json | null
          value_quantity?: number | null
          value_string?: string | null
          value_unit?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "clinical_observations_encounter_id_fkey"
            columns: ["encounter_id"]
            isOneToOne: false
            referencedRelation: "clinical_encounters"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "clinical_observations_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      clinical_therapy_orders: {
        Row: {
          ai_generated: boolean
          atc_code: string | null
          created_at: string
          created_by: string
          display: string
          dose: string | null
          duration: string | null
          encounter_id: string
          ends_on: string | null
          frequency: string | null
          id: string
          instructions: string | null
          kind: string
          patient_id: string
          route: string | null
          snomed_code: string | null
          starts_on: string | null
          status: string
          updated_at: string
        }
        Insert: {
          ai_generated?: boolean
          atc_code?: string | null
          created_at?: string
          created_by: string
          display: string
          dose?: string | null
          duration?: string | null
          encounter_id: string
          ends_on?: string | null
          frequency?: string | null
          id?: string
          instructions?: string | null
          kind: string
          patient_id: string
          route?: string | null
          snomed_code?: string | null
          starts_on?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          ai_generated?: boolean
          atc_code?: string | null
          created_at?: string
          created_by?: string
          display?: string
          dose?: string | null
          duration?: string | null
          encounter_id?: string
          ends_on?: string | null
          frequency?: string | null
          id?: string
          instructions?: string | null
          kind?: string
          patient_id?: string
          route?: string | null
          snomed_code?: string | null
          starts_on?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "clinical_therapy_orders_encounter_id_fkey"
            columns: ["encounter_id"]
            isOneToOne: false
            referencedRelation: "clinical_encounters"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "clinical_therapy_orders_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      clinical_weekly_vc: {
        Row: {
          bolus_given: number | null
          created_at: string
          created_by: string
          encounter_id: string | null
          id: string
          measured_at: string
          measurement_type: string
          notes: string | null
          patient_id: string
          value_mmol_l: number
        }
        Insert: {
          bolus_given?: number | null
          created_at?: string
          created_by: string
          encounter_id?: string | null
          id?: string
          measured_at: string
          measurement_type: string
          notes?: string | null
          patient_id: string
          value_mmol_l: number
        }
        Update: {
          bolus_given?: number | null
          created_at?: string
          created_by?: string
          encounter_id?: string | null
          id?: string
          measured_at?: string
          measurement_type?: string
          notes?: string | null
          patient_id?: string
          value_mmol_l?: number
        }
        Relationships: [
          {
            foreignKeyName: "clinical_weekly_vc_encounter_id_fkey"
            columns: ["encounter_id"]
            isOneToOne: false
            referencedRelation: "clinical_encounters"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "clinical_weekly_vc_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      clinics: {
        Row: {
          aktiv: boolean
          created_at: string
          id: string
          nev: string
          tenant_id: string
          updated_at: string
        }
        Insert: {
          aktiv?: boolean
          created_at?: string
          id?: string
          nev: string
          tenant_id: string
          updated_at?: string
        }
        Update: {
          aktiv?: boolean
          created_at?: string
          id?: string
          nev?: string
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "clinics_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      cms_audit_log: {
        Row: {
          action: Database["public"]["Enums"]["cms_audit_action"]
          actor_email: string | null
          actor_id: string | null
          after: Json | null
          before: Json | null
          comment: string | null
          created_at: string
          diff: Json | null
          entity_id: string | null
          entity_locale: string | null
          entity_slug: string | null
          entity_type: string
          id: string
          request_meta: Json | null
        }
        Insert: {
          action: Database["public"]["Enums"]["cms_audit_action"]
          actor_email?: string | null
          actor_id?: string | null
          after?: Json | null
          before?: Json | null
          comment?: string | null
          created_at?: string
          diff?: Json | null
          entity_id?: string | null
          entity_locale?: string | null
          entity_slug?: string | null
          entity_type: string
          id?: string
          request_meta?: Json | null
        }
        Update: {
          action?: Database["public"]["Enums"]["cms_audit_action"]
          actor_email?: string | null
          actor_id?: string | null
          after?: Json | null
          before?: Json | null
          comment?: string | null
          created_at?: string
          diff?: Json | null
          entity_id?: string | null
          entity_locale?: string | null
          entity_slug?: string | null
          entity_type?: string
          id?: string
          request_meta?: Json | null
        }
        Relationships: []
      }
      cms_blocks: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          block_type: string
          content: Json
          created_at: string
          id: string
          is_published: boolean
          locale: string
          page_id: string
          position: number
          rejected_at: string | null
          rejected_by: string | null
          rejection_reason: string | null
          submitted_by: string | null
          submitted_for_review_at: string | null
          updated_at: string
          variant: string
          workflow_state: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          block_type: string
          content?: Json
          created_at?: string
          id?: string
          is_published?: boolean
          locale?: string
          page_id: string
          position?: number
          rejected_at?: string | null
          rejected_by?: string | null
          rejection_reason?: string | null
          submitted_by?: string | null
          submitted_for_review_at?: string | null
          updated_at?: string
          variant?: string
          workflow_state?: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          block_type?: string
          content?: Json
          created_at?: string
          id?: string
          is_published?: boolean
          locale?: string
          page_id?: string
          position?: number
          rejected_at?: string | null
          rejected_by?: string | null
          rejection_reason?: string | null
          submitted_by?: string | null
          submitted_for_review_at?: string | null
          updated_at?: string
          variant?: string
          workflow_state?: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Relationships: [
          {
            foreignKeyName: "cms_blocks_page_id_fkey"
            columns: ["page_id"]
            isOneToOne: false
            referencedRelation: "cms_pages"
            referencedColumns: ["id"]
          },
        ]
      }
      cms_design_tokens: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          created_at: string
          description: string | null
          id: string
          rejected_at: string | null
          rejected_by: string | null
          rejection_reason: string | null
          scope: string
          submitted_by: string | null
          submitted_for_review_at: string | null
          token_key: string
          updated_at: string
          updated_by: string | null
          value: Json
          workflow_state: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string
          description?: string | null
          id?: string
          rejected_at?: string | null
          rejected_by?: string | null
          rejection_reason?: string | null
          scope?: string
          submitted_by?: string | null
          submitted_for_review_at?: string | null
          token_key: string
          updated_at?: string
          updated_by?: string | null
          value: Json
          workflow_state?: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string
          description?: string | null
          id?: string
          rejected_at?: string | null
          rejected_by?: string | null
          rejection_reason?: string | null
          scope?: string
          submitted_by?: string | null
          submitted_for_review_at?: string | null
          token_key?: string
          updated_at?: string
          updated_by?: string | null
          value?: Json
          workflow_state?: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Relationships: []
      }
      cms_experiment_events: {
        Row: {
          created_at: string
          event_name: string | null
          event_type: string
          experiment_id: string
          id: number
          params: Json | null
          path: string | null
          referrer: string | null
          session_id: string | null
          user_agent: string | null
          variant_id: string
        }
        Insert: {
          created_at?: string
          event_name?: string | null
          event_type: string
          experiment_id: string
          id?: number
          params?: Json | null
          path?: string | null
          referrer?: string | null
          session_id?: string | null
          user_agent?: string | null
          variant_id: string
        }
        Update: {
          created_at?: string
          event_name?: string | null
          event_type?: string
          experiment_id?: string
          id?: number
          params?: Json | null
          path?: string | null
          referrer?: string | null
          session_id?: string | null
          user_agent?: string | null
          variant_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "cms_experiment_events_experiment_id_fkey"
            columns: ["experiment_id"]
            isOneToOne: false
            referencedRelation: "cms_experiments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "cms_experiment_events_variant_id_fkey"
            columns: ["variant_id"]
            isOneToOne: false
            referencedRelation: "cms_experiment_variants"
            referencedColumns: ["id"]
          },
        ]
      }
      cms_experiment_variants: {
        Row: {
          content: Json
          created_at: string
          experiment_id: string
          id: string
          is_control: boolean
          key: string
          name: string | null
          updated_at: string
          weight: number
        }
        Insert: {
          content?: Json
          created_at?: string
          experiment_id: string
          id?: string
          is_control?: boolean
          key: string
          name?: string | null
          updated_at?: string
          weight?: number
        }
        Update: {
          content?: Json
          created_at?: string
          experiment_id?: string
          id?: string
          is_control?: boolean
          key?: string
          name?: string | null
          updated_at?: string
          weight?: number
        }
        Relationships: [
          {
            foreignKeyName: "cms_experiment_variants_experiment_id_fkey"
            columns: ["experiment_id"]
            isOneToOne: false
            referencedRelation: "cms_experiments"
            referencedColumns: ["id"]
          },
        ]
      }
      cms_experiments: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          block_id: string | null
          conversion_events: Json
          created_at: string
          description: string | null
          ended_at: string | null
          goal_event: string
          id: string
          layout_block_id: string | null
          name: string
          rejected_at: string | null
          rejected_by: string | null
          rejection_reason: string | null
          started_at: string | null
          status: string
          submitted_by: string | null
          submitted_for_review_at: string | null
          traffic_allocation: number
          updated_at: string
          winner_variant_id: string | null
          workflow_state: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          block_id?: string | null
          conversion_events?: Json
          created_at?: string
          description?: string | null
          ended_at?: string | null
          goal_event: string
          id?: string
          layout_block_id?: string | null
          name: string
          rejected_at?: string | null
          rejected_by?: string | null
          rejection_reason?: string | null
          started_at?: string | null
          status?: string
          submitted_by?: string | null
          submitted_for_review_at?: string | null
          traffic_allocation?: number
          updated_at?: string
          winner_variant_id?: string | null
          workflow_state?: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          block_id?: string | null
          conversion_events?: Json
          created_at?: string
          description?: string | null
          ended_at?: string | null
          goal_event?: string
          id?: string
          layout_block_id?: string | null
          name?: string
          rejected_at?: string | null
          rejected_by?: string | null
          rejection_reason?: string | null
          started_at?: string | null
          status?: string
          submitted_by?: string | null
          submitted_for_review_at?: string | null
          traffic_allocation?: number
          updated_at?: string
          winner_variant_id?: string | null
          workflow_state?: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Relationships: [
          {
            foreignKeyName: "cms_experiments_block_id_fkey"
            columns: ["block_id"]
            isOneToOne: false
            referencedRelation: "cms_blocks"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "cms_experiments_layout_block_id_fkey"
            columns: ["layout_block_id"]
            isOneToOne: false
            referencedRelation: "cms_layout_blocks"
            referencedColumns: ["id"]
          },
        ]
      }
      cms_faqs: {
        Row: {
          answer: string
          approved_at: string | null
          approved_by: string | null
          created_at: string
          id: string
          is_published: boolean | null
          locale: string
          question: string
          rejected_at: string | null
          rejected_by: string | null
          rejection_reason: string | null
          sort_order: number | null
          submitted_by: string | null
          submitted_for_review_at: string | null
          tags: string[] | null
          updated_at: string
          workflow_state: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Insert: {
          answer: string
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string
          id?: string
          is_published?: boolean | null
          locale?: string
          question: string
          rejected_at?: string | null
          rejected_by?: string | null
          rejection_reason?: string | null
          sort_order?: number | null
          submitted_by?: string | null
          submitted_for_review_at?: string | null
          tags?: string[] | null
          updated_at?: string
          workflow_state?: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Update: {
          answer?: string
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string
          id?: string
          is_published?: boolean | null
          locale?: string
          question?: string
          rejected_at?: string | null
          rejected_by?: string | null
          rejection_reason?: string | null
          sort_order?: number | null
          submitted_by?: string | null
          submitted_for_review_at?: string | null
          tags?: string[] | null
          updated_at?: string
          workflow_state?: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Relationships: []
      }
      cms_global_regions: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          blocks: Json
          created_at: string
          id: string
          locale: string
          region_key: string
          rejected_at: string | null
          rejected_by: string | null
          rejection_reason: string | null
          status: string
          submitted_by: string | null
          submitted_for_review_at: string | null
          updated_at: string
          updated_by: string | null
          workflow_state: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          blocks?: Json
          created_at?: string
          id?: string
          locale?: string
          region_key: string
          rejected_at?: string | null
          rejected_by?: string | null
          rejection_reason?: string | null
          status?: string
          submitted_by?: string | null
          submitted_for_review_at?: string | null
          updated_at?: string
          updated_by?: string | null
          workflow_state?: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          blocks?: Json
          created_at?: string
          id?: string
          locale?: string
          region_key?: string
          rejected_at?: string | null
          rejected_by?: string | null
          rejection_reason?: string | null
          status?: string
          submitted_by?: string | null
          submitted_for_review_at?: string | null
          updated_at?: string
          updated_by?: string | null
          workflow_state?: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Relationships: []
      }
      cms_i18n_content: {
        Row: {
          data: Json
          entity_id: string
          entity_type: string
          id: string
          locale: string
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          data?: Json
          entity_id: string
          entity_type: string
          id?: string
          locale: string
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          data?: Json
          entity_id?: string
          entity_type?: string
          id?: string
          locale?: string
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      cms_layout_blocks: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          block_type: string
          content: Json
          created_at: string
          created_by: string | null
          draft_content: Json | null
          draft_note: string | null
          draft_status: string
          draft_style: Json | null
          draft_updated_at: string | null
          draft_updated_by: string | null
          end_at: string | null
          id: string
          locale: string
          page_id: string | null
          position: number
          region_key: string | null
          rejected_at: string | null
          rejected_by: string | null
          rejection_reason: string | null
          schedule_at: string | null
          status: string
          style: Json
          submitted_by: string | null
          submitted_for_review_at: string | null
          updated_at: string
          updated_by: string | null
          version: number
          visibility: Json
          workflow_state: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          block_type: string
          content?: Json
          created_at?: string
          created_by?: string | null
          draft_content?: Json | null
          draft_note?: string | null
          draft_status?: string
          draft_style?: Json | null
          draft_updated_at?: string | null
          draft_updated_by?: string | null
          end_at?: string | null
          id?: string
          locale?: string
          page_id?: string | null
          position?: number
          region_key?: string | null
          rejected_at?: string | null
          rejected_by?: string | null
          rejection_reason?: string | null
          schedule_at?: string | null
          status?: string
          style?: Json
          submitted_by?: string | null
          submitted_for_review_at?: string | null
          updated_at?: string
          updated_by?: string | null
          version?: number
          visibility?: Json
          workflow_state?: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          block_type?: string
          content?: Json
          created_at?: string
          created_by?: string | null
          draft_content?: Json | null
          draft_note?: string | null
          draft_status?: string
          draft_style?: Json | null
          draft_updated_at?: string | null
          draft_updated_by?: string | null
          end_at?: string | null
          id?: string
          locale?: string
          page_id?: string | null
          position?: number
          region_key?: string | null
          rejected_at?: string | null
          rejected_by?: string | null
          rejection_reason?: string | null
          schedule_at?: string | null
          status?: string
          style?: Json
          submitted_by?: string | null
          submitted_for_review_at?: string | null
          updated_at?: string
          updated_by?: string | null
          version?: number
          visibility?: Json
          workflow_state?: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Relationships: [
          {
            foreignKeyName: "cms_layout_blocks_page_id_fkey"
            columns: ["page_id"]
            isOneToOne: false
            referencedRelation: "cms_pages"
            referencedColumns: ["id"]
          },
        ]
      }
      cms_media: {
        Row: {
          alt_text: string | null
          approved_at: string | null
          approved_by: string | null
          caption: string | null
          category: string | null
          created_at: string
          file_name: string
          height: number | null
          id: string
          mime_type: string
          rejected_at: string | null
          rejected_by: string | null
          rejection_reason: string | null
          size_bytes: number
          storage_path: string
          submitted_by: string | null
          submitted_for_review_at: string | null
          tags: string[] | null
          uploaded_by: string | null
          width: number | null
          workflow_state: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Insert: {
          alt_text?: string | null
          approved_at?: string | null
          approved_by?: string | null
          caption?: string | null
          category?: string | null
          created_at?: string
          file_name: string
          height?: number | null
          id?: string
          mime_type: string
          rejected_at?: string | null
          rejected_by?: string | null
          rejection_reason?: string | null
          size_bytes?: number
          storage_path: string
          submitted_by?: string | null
          submitted_for_review_at?: string | null
          tags?: string[] | null
          uploaded_by?: string | null
          width?: number | null
          workflow_state?: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Update: {
          alt_text?: string | null
          approved_at?: string | null
          approved_by?: string | null
          caption?: string | null
          category?: string | null
          created_at?: string
          file_name?: string
          height?: number | null
          id?: string
          mime_type?: string
          rejected_at?: string | null
          rejected_by?: string | null
          rejection_reason?: string | null
          size_bytes?: number
          storage_path?: string
          submitted_by?: string | null
          submitted_for_review_at?: string | null
          tags?: string[] | null
          uploaded_by?: string | null
          width?: number | null
          workflow_state?: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Relationships: []
      }
      cms_menu_items: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          created_at: string
          icon: string | null
          id: string
          label: string
          locale: string
          menu_id: string
          open_in_new_tab: boolean
          page_id: string | null
          parent_id: string | null
          position: number
          rejected_at: string | null
          rejected_by: string | null
          rejection_reason: string | null
          submitted_by: string | null
          submitted_for_review_at: string | null
          updated_at: string
          url: string | null
          workflow_state: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string
          icon?: string | null
          id?: string
          label: string
          locale?: string
          menu_id: string
          open_in_new_tab?: boolean
          page_id?: string | null
          parent_id?: string | null
          position?: number
          rejected_at?: string | null
          rejected_by?: string | null
          rejection_reason?: string | null
          submitted_by?: string | null
          submitted_for_review_at?: string | null
          updated_at?: string
          url?: string | null
          workflow_state?: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string
          icon?: string | null
          id?: string
          label?: string
          locale?: string
          menu_id?: string
          open_in_new_tab?: boolean
          page_id?: string | null
          parent_id?: string | null
          position?: number
          rejected_at?: string | null
          rejected_by?: string | null
          rejection_reason?: string | null
          submitted_by?: string | null
          submitted_for_review_at?: string | null
          updated_at?: string
          url?: string | null
          workflow_state?: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Relationships: [
          {
            foreignKeyName: "cms_menu_items_menu_id_fkey"
            columns: ["menu_id"]
            isOneToOne: false
            referencedRelation: "cms_menus"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "cms_menu_items_page_id_fkey"
            columns: ["page_id"]
            isOneToOne: false
            referencedRelation: "cms_pages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "cms_menu_items_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "cms_menu_items"
            referencedColumns: ["id"]
          },
        ]
      }
      cms_menus: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          created_at: string
          id: string
          key: string
          location: string
          name: string
          rejected_at: string | null
          rejected_by: string | null
          rejection_reason: string | null
          submitted_by: string | null
          submitted_for_review_at: string | null
          updated_at: string
          workflow_state: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string
          id?: string
          key: string
          location?: string
          name: string
          rejected_at?: string | null
          rejected_by?: string | null
          rejection_reason?: string | null
          submitted_by?: string | null
          submitted_for_review_at?: string | null
          updated_at?: string
          workflow_state?: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string
          id?: string
          key?: string
          location?: string
          name?: string
          rejected_at?: string | null
          rejected_by?: string | null
          rejection_reason?: string | null
          submitted_by?: string | null
          submitted_for_review_at?: string | null
          updated_at?: string
          workflow_state?: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Relationships: []
      }
      cms_news_authors: {
        Row: {
          avatar_url: string | null
          bio: string | null
          created_at: string
          display_name: string
          email: string | null
          id: string
          is_guest: boolean
          updated_at: string
          user_id: string | null
        }
        Insert: {
          avatar_url?: string | null
          bio?: string | null
          created_at?: string
          display_name: string
          email?: string | null
          id?: string
          is_guest?: boolean
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          avatar_url?: string | null
          bio?: string | null
          created_at?: string
          display_name?: string
          email?: string | null
          id?: string
          is_guest?: boolean
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      cms_news_categories: {
        Row: {
          created_at: string
          description: string | null
          id: string
          is_active: boolean
          name: string
          parent_id: string | null
          slug: string
          sort_order: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          name: string
          parent_id?: string | null
          slug: string
          sort_order?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          name?: string
          parent_id?: string | null
          slug?: string
          sort_order?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "cms_news_categories_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "cms_news_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      cms_news_post_tags: {
        Row: {
          post_id: string
          tag_id: string
        }
        Insert: {
          post_id: string
          tag_id: string
        }
        Update: {
          post_id?: string
          tag_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "cms_news_post_tags_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "cms_news_posts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "cms_news_post_tags_tag_id_fkey"
            columns: ["tag_id"]
            isOneToOne: false
            referencedRelation: "cms_news_tags"
            referencedColumns: ["id"]
          },
        ]
      }
      cms_news_posts: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          author_id: string | null
          body: Json
          category_id: string | null
          cms_page_id: string | null
          created_at: string
          created_by: string | null
          excerpt: string | null
          featured_image_alt: string | null
          featured_image_url: string | null
          id: string
          locale: string
          og_image_url: string | null
          post_type: string
          preview_token: string
          published_at: string | null
          rejected_at: string | null
          rejected_by: string | null
          rejection_reason: string | null
          seo_description: string | null
          seo_title: string | null
          slug: string
          status: string
          submitted_by: string | null
          submitted_for_review_at: string | null
          title: string
          updated_at: string
          updated_by: string | null
          video_duration_seconds: number | null
          video_embed_url: string | null
          video_height: number | null
          video_provider: string | null
          video_thumbnail_url: string | null
          video_transcript: string | null
          video_url: string | null
          video_width: number | null
          view_count: number
          workflow_state: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          author_id?: string | null
          body?: Json
          category_id?: string | null
          cms_page_id?: string | null
          created_at?: string
          created_by?: string | null
          excerpt?: string | null
          featured_image_alt?: string | null
          featured_image_url?: string | null
          id?: string
          locale?: string
          og_image_url?: string | null
          post_type?: string
          preview_token?: string
          published_at?: string | null
          rejected_at?: string | null
          rejected_by?: string | null
          rejection_reason?: string | null
          seo_description?: string | null
          seo_title?: string | null
          slug: string
          status?: string
          submitted_by?: string | null
          submitted_for_review_at?: string | null
          title: string
          updated_at?: string
          updated_by?: string | null
          video_duration_seconds?: number | null
          video_embed_url?: string | null
          video_height?: number | null
          video_provider?: string | null
          video_thumbnail_url?: string | null
          video_transcript?: string | null
          video_url?: string | null
          video_width?: number | null
          view_count?: number
          workflow_state?: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          author_id?: string | null
          body?: Json
          category_id?: string | null
          cms_page_id?: string | null
          created_at?: string
          created_by?: string | null
          excerpt?: string | null
          featured_image_alt?: string | null
          featured_image_url?: string | null
          id?: string
          locale?: string
          og_image_url?: string | null
          post_type?: string
          preview_token?: string
          published_at?: string | null
          rejected_at?: string | null
          rejected_by?: string | null
          rejection_reason?: string | null
          seo_description?: string | null
          seo_title?: string | null
          slug?: string
          status?: string
          submitted_by?: string | null
          submitted_for_review_at?: string | null
          title?: string
          updated_at?: string
          updated_by?: string | null
          video_duration_seconds?: number | null
          video_embed_url?: string | null
          video_height?: number | null
          video_provider?: string | null
          video_thumbnail_url?: string | null
          video_transcript?: string | null
          video_url?: string | null
          video_width?: number | null
          view_count?: number
          workflow_state?: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Relationships: [
          {
            foreignKeyName: "cms_news_posts_author_id_fkey"
            columns: ["author_id"]
            isOneToOne: false
            referencedRelation: "cms_news_authors"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "cms_news_posts_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "cms_news_categories"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "cms_news_posts_cms_page_id_fkey"
            columns: ["cms_page_id"]
            isOneToOne: false
            referencedRelation: "cms_pages"
            referencedColumns: ["id"]
          },
        ]
      }
      cms_news_tags: {
        Row: {
          created_at: string
          id: string
          name: string
          slug: string
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
          slug: string
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
          slug?: string
        }
        Relationships: []
      }
      cms_newsletter_subscribers: {
        Row: {
          confirmed_at: string | null
          created_at: string
          email: string
          id: string
          source: string | null
          unsubscribe_token: string
          unsubscribed_at: string | null
        }
        Insert: {
          confirmed_at?: string | null
          created_at?: string
          email: string
          id?: string
          source?: string | null
          unsubscribe_token?: string
          unsubscribed_at?: string | null
        }
        Update: {
          confirmed_at?: string | null
          created_at?: string
          email?: string
          id?: string
          source?: string | null
          unsubscribe_token?: string
          unsubscribed_at?: string | null
        }
        Relationships: []
      }
      cms_newsletters: {
        Row: {
          audience: string
          body_html: string
          created_at: string
          created_by: string | null
          id: string
          sent_at: string | null
          sent_count: number
          status: string
          subject: string
          updated_at: string
        }
        Insert: {
          audience?: string
          body_html: string
          created_at?: string
          created_by?: string | null
          id?: string
          sent_at?: string | null
          sent_count?: number
          status?: string
          subject: string
          updated_at?: string
        }
        Update: {
          audience?: string
          body_html?: string
          created_at?: string
          created_by?: string | null
          id?: string
          sent_at?: string | null
          sent_count?: number
          status?: string
          subject?: string
          updated_at?: string
        }
        Relationships: []
      }
      cms_page_versions: {
        Row: {
          created_at: string
          created_by: string | null
          id: string
          is_autosave: boolean
          is_published: boolean
          page_id: string
          snapshot: Json
          version: number
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          id?: string
          is_autosave?: boolean
          is_published?: boolean
          page_id: string
          snapshot: Json
          version: number
        }
        Update: {
          created_at?: string
          created_by?: string | null
          id?: string
          is_autosave?: boolean
          is_published?: boolean
          page_id?: string
          snapshot?: Json
          version?: number
        }
        Relationships: [
          {
            foreignKeyName: "cms_page_versions_page_id_fkey"
            columns: ["page_id"]
            isOneToOne: false
            referencedRelation: "cms_pages"
            referencedColumns: ["id"]
          },
        ]
      }
      cms_page_views: {
        Row: {
          day: string
          id: string
          page_id: string
          views: number
        }
        Insert: {
          day?: string
          id?: string
          page_id: string
          views?: number
        }
        Update: {
          day?: string
          id?: string
          page_id?: string
          views?: number
        }
        Relationships: [
          {
            foreignKeyName: "cms_page_views_page_id_fkey"
            columns: ["page_id"]
            isOneToOne: false
            referencedRelation: "cms_pages"
            referencedColumns: ["id"]
          },
        ]
      }
      cms_pages: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          created_at: string
          created_by: string | null
          description: string | null
          id: string
          is_home: boolean
          is_system: boolean
          last_viewed_at: string | null
          layout: string
          locale: string
          nav_label: string | null
          noindex: boolean
          og_image_url: string | null
          parent_id: string | null
          preview_token: string
          published_at: string | null
          rejected_at: string | null
          rejected_by: string | null
          rejection_reason: string | null
          scheduled_publish_at: string | null
          schema_type: string
          seo_description: string | null
          seo_title: string | null
          show_in_sitemap: boolean
          slug: string
          sort_order: number
          status: string
          submitted_by: string | null
          submitted_for_review_at: string | null
          template: string
          title: string
          updated_at: string
          updated_by: string | null
          view_count: number
          workflow_state: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          is_home?: boolean
          is_system?: boolean
          last_viewed_at?: string | null
          layout?: string
          locale?: string
          nav_label?: string | null
          noindex?: boolean
          og_image_url?: string | null
          parent_id?: string | null
          preview_token?: string
          published_at?: string | null
          rejected_at?: string | null
          rejected_by?: string | null
          rejection_reason?: string | null
          scheduled_publish_at?: string | null
          schema_type?: string
          seo_description?: string | null
          seo_title?: string | null
          show_in_sitemap?: boolean
          slug: string
          sort_order?: number
          status?: string
          submitted_by?: string | null
          submitted_for_review_at?: string | null
          template?: string
          title: string
          updated_at?: string
          updated_by?: string | null
          view_count?: number
          workflow_state?: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          is_home?: boolean
          is_system?: boolean
          last_viewed_at?: string | null
          layout?: string
          locale?: string
          nav_label?: string | null
          noindex?: boolean
          og_image_url?: string | null
          parent_id?: string | null
          preview_token?: string
          published_at?: string | null
          rejected_at?: string | null
          rejected_by?: string | null
          rejection_reason?: string | null
          scheduled_publish_at?: string | null
          schema_type?: string
          seo_description?: string | null
          seo_title?: string | null
          show_in_sitemap?: boolean
          slug?: string
          sort_order?: number
          status?: string
          submitted_by?: string | null
          submitted_for_review_at?: string | null
          template?: string
          title?: string
          updated_at?: string
          updated_by?: string | null
          view_count?: number
          workflow_state?: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Relationships: [
          {
            foreignKeyName: "cms_pages_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "cms_pages"
            referencedColumns: ["id"]
          },
        ]
      }
      cms_redirects: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          created_at: string
          id: string
          is_active: boolean
          note: string | null
          rejected_at: string | null
          rejected_by: string | null
          rejection_reason: string | null
          source_path: string
          status_code: number
          submitted_by: string | null
          submitted_for_review_at: string | null
          target_path: string
          updated_at: string
          workflow_state: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string
          id?: string
          is_active?: boolean
          note?: string | null
          rejected_at?: string | null
          rejected_by?: string | null
          rejection_reason?: string | null
          source_path: string
          status_code?: number
          submitted_by?: string | null
          submitted_for_review_at?: string | null
          target_path: string
          updated_at?: string
          workflow_state?: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string
          id?: string
          is_active?: boolean
          note?: string | null
          rejected_at?: string | null
          rejected_by?: string | null
          rejection_reason?: string | null
          source_path?: string
          status_code?: number
          submitted_by?: string | null
          submitted_for_review_at?: string | null
          target_path?: string
          updated_at?: string
          workflow_state?: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Relationships: []
      }
      cms_site_settings: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          default_locale: string
          default_og_image_url: string | null
          id: number
          organization_jsonld: Json | null
          rejected_at: string | null
          rejected_by: string | null
          rejection_reason: string | null
          robots_txt: string | null
          sos_active: boolean
          sos_message: string | null
          submitted_by: string | null
          submitted_for_review_at: string | null
          updated_at: string
          updated_by: string | null
          workflow_state: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          default_locale?: string
          default_og_image_url?: string | null
          id?: number
          organization_jsonld?: Json | null
          rejected_at?: string | null
          rejected_by?: string | null
          rejection_reason?: string | null
          robots_txt?: string | null
          sos_active?: boolean
          sos_message?: string | null
          submitted_by?: string | null
          submitted_for_review_at?: string | null
          updated_at?: string
          updated_by?: string | null
          workflow_state?: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          default_locale?: string
          default_og_image_url?: string | null
          id?: number
          organization_jsonld?: Json | null
          rejected_at?: string | null
          rejected_by?: string | null
          rejection_reason?: string | null
          robots_txt?: string | null
          sos_active?: boolean
          sos_message?: string | null
          submitted_by?: string | null
          submitted_for_review_at?: string | null
          updated_at?: string
          updated_by?: string | null
          workflow_state?: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Relationships: []
      }
      cms_staff_profiles: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          bio: string | null
          created_at: string
          display_name: string
          id: string
          is_published: boolean | null
          languages: string[] | null
          locale: string
          photo_url: string | null
          profile_id: string
          public_fields: Json
          public_visibility: string
          publications: Json | null
          publish_schedule: boolean | null
          rejected_at: string | null
          rejected_by: string | null
          rejection_reason: string | null
          seo_description: string | null
          seo_title: string | null
          slug: string
          sort_order: number | null
          specialties: string[] | null
          submitted_by: string | null
          submitted_for_review_at: string | null
          title: string | null
          updated_at: string
          workflow_state: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          bio?: string | null
          created_at?: string
          display_name: string
          id?: string
          is_published?: boolean | null
          languages?: string[] | null
          locale?: string
          photo_url?: string | null
          profile_id: string
          public_fields?: Json
          public_visibility?: string
          publications?: Json | null
          publish_schedule?: boolean | null
          rejected_at?: string | null
          rejected_by?: string | null
          rejection_reason?: string | null
          seo_description?: string | null
          seo_title?: string | null
          slug: string
          sort_order?: number | null
          specialties?: string[] | null
          submitted_by?: string | null
          submitted_for_review_at?: string | null
          title?: string | null
          updated_at?: string
          workflow_state?: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          bio?: string | null
          created_at?: string
          display_name?: string
          id?: string
          is_published?: boolean | null
          languages?: string[] | null
          locale?: string
          photo_url?: string | null
          profile_id?: string
          public_fields?: Json
          public_visibility?: string
          publications?: Json | null
          publish_schedule?: boolean | null
          rejected_at?: string | null
          rejected_by?: string | null
          rejection_reason?: string | null
          seo_description?: string | null
          seo_title?: string | null
          slug?: string
          sort_order?: number | null
          specialties?: string[] | null
          submitted_by?: string | null
          submitted_for_review_at?: string | null
          title?: string | null
          updated_at?: string
          workflow_state?: Database["public"]["Enums"]["cms_workflow_state"]
        }
        Relationships: [
          {
            foreignKeyName: "cms_staff_profiles_profile_id_fkey"
            columns: ["profile_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "cms_staff_profiles_profile_id_fkey"
            columns: ["profile_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      cms_tip_audience_map: {
        Row: {
          audience_id: string
          tip_id: string
        }
        Insert: {
          audience_id: string
          tip_id: string
        }
        Update: {
          audience_id?: string
          tip_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "cms_tip_audience_map_audience_id_fkey"
            columns: ["audience_id"]
            isOneToOne: false
            referencedRelation: "cms_tip_audiences"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "cms_tip_audience_map_tip_id_fkey"
            columns: ["tip_id"]
            isOneToOne: false
            referencedRelation: "cms_tips"
            referencedColumns: ["id"]
          },
        ]
      }
      cms_tip_audiences: {
        Row: {
          created_at: string
          description_i18n: Json
          id: string
          name_i18n: Json
          slug: string
          sort_order: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          description_i18n?: Json
          id?: string
          name_i18n?: Json
          slug: string
          sort_order?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          description_i18n?: Json
          id?: string
          name_i18n?: Json
          slug?: string
          sort_order?: number
          updated_at?: string
        }
        Relationships: []
      }
      cms_tip_categories: {
        Row: {
          color: string | null
          created_at: string
          description_i18n: Json
          icon: string | null
          id: string
          name_i18n: Json
          slug: string
          sort_order: number
          updated_at: string
        }
        Insert: {
          color?: string | null
          created_at?: string
          description_i18n?: Json
          icon?: string | null
          id?: string
          name_i18n?: Json
          slug: string
          sort_order?: number
          updated_at?: string
        }
        Update: {
          color?: string | null
          created_at?: string
          description_i18n?: Json
          icon?: string | null
          id?: string
          name_i18n?: Json
          slug?: string
          sort_order?: number
          updated_at?: string
        }
        Relationships: []
      }
      cms_tip_comments: {
        Row: {
          body: string
          created_at: string
          id: string
          parent_id: string | null
          status: string
          tip_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          body: string
          created_at?: string
          id?: string
          parent_id?: string | null
          status?: string
          tip_id: string
          updated_at?: string
          user_id: string
        }
        Update: {
          body?: string
          created_at?: string
          id?: string
          parent_id?: string | null
          status?: string
          tip_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "cms_tip_comments_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "cms_tip_comments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "cms_tip_comments_tip_id_fkey"
            columns: ["tip_id"]
            isOneToOne: false
            referencedRelation: "cms_tips"
            referencedColumns: ["id"]
          },
        ]
      }
      cms_tip_likes: {
        Row: {
          created_at: string
          tip_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          tip_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          tip_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "cms_tip_likes_tip_id_fkey"
            columns: ["tip_id"]
            isOneToOne: false
            referencedRelation: "cms_tips"
            referencedColumns: ["id"]
          },
        ]
      }
      cms_tip_subscribers: {
        Row: {
          audiences: string[] | null
          created_at: string
          email_enabled: boolean
          push_enabled: boolean
          user_id: string
        }
        Insert: {
          audiences?: string[] | null
          created_at?: string
          email_enabled?: boolean
          push_enabled?: boolean
          user_id: string
        }
        Update: {
          audiences?: string[] | null
          created_at?: string
          email_enabled?: boolean
          push_enabled?: boolean
          user_id?: string
        }
        Relationships: []
      }
      cms_tip_tag_map: {
        Row: {
          tag_id: string
          tip_id: string
        }
        Insert: {
          tag_id: string
          tip_id: string
        }
        Update: {
          tag_id?: string
          tip_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "cms_tip_tag_map_tag_id_fkey"
            columns: ["tag_id"]
            isOneToOne: false
            referencedRelation: "cms_tip_tags"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "cms_tip_tag_map_tip_id_fkey"
            columns: ["tip_id"]
            isOneToOne: false
            referencedRelation: "cms_tips"
            referencedColumns: ["id"]
          },
        ]
      }
      cms_tip_tags: {
        Row: {
          created_at: string
          id: string
          name_i18n: Json
          slug: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          name_i18n?: Json
          slug: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          name_i18n?: Json
          slug?: string
          updated_at?: string
        }
        Relationships: []
      }
      cms_tip_translations: {
        Row: {
          ai_generated: boolean
          ai_source_lang: string | null
          body_html: string | null
          body_json: Json
          created_at: string
          id: string
          lead: string | null
          locale: string
          og_image: string | null
          seo_description: string | null
          seo_title: string | null
          tip_id: string
          title: string
          translation_status: string
          updated_at: string
        }
        Insert: {
          ai_generated?: boolean
          ai_source_lang?: string | null
          body_html?: string | null
          body_json?: Json
          created_at?: string
          id?: string
          lead?: string | null
          locale: string
          og_image?: string | null
          seo_description?: string | null
          seo_title?: string | null
          tip_id: string
          title?: string
          translation_status?: string
          updated_at?: string
        }
        Update: {
          ai_generated?: boolean
          ai_source_lang?: string | null
          body_html?: string | null
          body_json?: Json
          created_at?: string
          id?: string
          lead?: string | null
          locale?: string
          og_image?: string | null
          seo_description?: string | null
          seo_title?: string | null
          tip_id?: string
          title?: string
          translation_status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "cms_tip_translations_tip_id_fkey"
            columns: ["tip_id"]
            isOneToOne: false
            referencedRelation: "cms_tips"
            referencedColumns: ["id"]
          },
        ]
      }
      cms_tip_versions: {
        Row: {
          created_at: string
          created_by: string | null
          id: string
          note: string | null
          snapshot: Json
          tip_id: string
          version: number
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          id?: string
          note?: string | null
          snapshot: Json
          tip_id: string
          version: number
        }
        Update: {
          created_at?: string
          created_by?: string | null
          id?: string
          note?: string | null
          snapshot?: Json
          tip_id?: string
          version?: number
        }
        Relationships: [
          {
            foreignKeyName: "cms_tip_versions_tip_id_fkey"
            columns: ["tip_id"]
            isOneToOne: false
            referencedRelation: "cms_tips"
            referencedColumns: ["id"]
          },
        ]
      }
      cms_tip_views: {
        Row: {
          id: string
          locale: string | null
          session_hash: string | null
          tip_id: string
          user_id: string | null
          viewed_at: string
        }
        Insert: {
          id?: string
          locale?: string | null
          session_hash?: string | null
          tip_id: string
          user_id?: string | null
          viewed_at?: string
        }
        Update: {
          id?: string
          locale?: string | null
          session_hash?: string | null
          tip_id?: string
          user_id?: string | null
          viewed_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "cms_tip_views_tip_id_fkey"
            columns: ["tip_id"]
            isOneToOne: false
            referencedRelation: "cms_tips"
            referencedColumns: ["id"]
          },
        ]
      }
      cms_tips: {
        Row: {
          author_id: string | null
          category_id: string | null
          cover_url: string | null
          created_at: string
          featured: boolean
          id: string
          published_at: string | null
          reading_minutes: number | null
          slug: string
          status: string
          updated_at: string
        }
        Insert: {
          author_id?: string | null
          category_id?: string | null
          cover_url?: string | null
          created_at?: string
          featured?: boolean
          id?: string
          published_at?: string | null
          reading_minutes?: number | null
          slug: string
          status?: string
          updated_at?: string
        }
        Update: {
          author_id?: string | null
          category_id?: string | null
          cover_url?: string | null
          created_at?: string
          featured?: boolean
          id?: string
          published_at?: string | null
          reading_minutes?: number | null
          slug?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "cms_tips_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "cms_tip_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      competency_domains: {
        Row: {
          created_at: string
          ervenyes: boolean
          id: string
          kulcs: string
          leiras: string | null
          nev: string
          specialty_id: string | null
          tenant_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          ervenyes?: boolean
          id?: string
          kulcs: string
          leiras?: string | null
          nev: string
          specialty_id?: string | null
          tenant_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          ervenyes?: boolean
          id?: string
          kulcs?: string
          leiras?: string | null
          nev?: string
          specialty_id?: string | null
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "competency_domains_specialty_id_fkey"
            columns: ["specialty_id"]
            isOneToOne: false
            referencedRelation: "specialties"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "competency_domains_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      competency_levels: {
        Row: {
          created_at: string
          felugyeleti_kuszob: boolean
          id: string
          kulcs: string
          leiras: string | null
          nev: string
          sorrend: number
          tenant_id: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          felugyeleti_kuszob?: boolean
          id?: string
          kulcs: string
          leiras?: string | null
          nev: string
          sorrend: number
          tenant_id?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          felugyeleti_kuszob?: boolean
          id?: string
          kulcs?: string
          leiras?: string | null
          nev?: string
          sorrend?: number
          tenant_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "competency_levels_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      contact_messages: {
        Row: {
          body: string
          created_at: string
          handled_at: string | null
          handled_by: string | null
          id: string
          ip_hash: string | null
          locale: string | null
          org_unit_id: string | null
          sender_email: string
          sender_name: string
          sender_phone: string | null
          source_page_slug: string | null
          status: string
          subject: string | null
          updated_at: string
        }
        Insert: {
          body: string
          created_at?: string
          handled_at?: string | null
          handled_by?: string | null
          id?: string
          ip_hash?: string | null
          locale?: string | null
          org_unit_id?: string | null
          sender_email: string
          sender_name: string
          sender_phone?: string | null
          source_page_slug?: string | null
          status?: string
          subject?: string | null
          updated_at?: string
        }
        Update: {
          body?: string
          created_at?: string
          handled_at?: string | null
          handled_by?: string | null
          id?: string
          ip_hash?: string | null
          locale?: string | null
          org_unit_id?: string | null
          sender_email?: string
          sender_name?: string
          sender_phone?: string | null
          source_page_slug?: string | null
          status?: string
          subject?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "contact_messages_org_unit_id_fkey"
            columns: ["org_unit_id"]
            isOneToOne: false
            referencedRelation: "org_unit_conflicts"
            referencedColumns: ["org_unit_id"]
          },
          {
            foreignKeyName: "contact_messages_org_unit_id_fkey"
            columns: ["org_unit_id"]
            isOneToOne: false
            referencedRelation: "org_units"
            referencedColumns: ["id"]
          },
        ]
      }
      contractions: {
        Row: {
          created_at: string
          gyakorisag_perc: number | null
          id: string
          idotartam_mp: number | null
          kezdes: string
          patient_id: string
          program_id: string | null
          tenant_id: string
          veg: string | null
        }
        Insert: {
          created_at?: string
          gyakorisag_perc?: number | null
          id?: string
          idotartam_mp?: number | null
          kezdes: string
          patient_id: string
          program_id?: string | null
          tenant_id: string
          veg?: string | null
        }
        Update: {
          created_at?: string
          gyakorisag_perc?: number | null
          id?: string
          idotartam_mp?: number | null
          kezdes?: string
          patient_id?: string
          program_id?: string | null
          tenant_id?: string
          veg?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "contractions_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "contractions_program_id_fkey"
            columns: ["program_id"]
            isOneToOne: false
            referencedRelation: "monitoring_programs"
            referencedColumns: ["id"]
          },
        ]
      }
      conversation_participants: {
        Row: {
          auto_translate: boolean
          conversation_id: string
          id: string
          joined_at: string
          last_read_at: string | null
          muted: boolean
          patient_id: string | null
          role: string
          user_id: string | null
        }
        Insert: {
          auto_translate?: boolean
          conversation_id: string
          id?: string
          joined_at?: string
          last_read_at?: string | null
          muted?: boolean
          patient_id?: string | null
          role?: string
          user_id?: string | null
        }
        Update: {
          auto_translate?: boolean
          conversation_id?: string
          id?: string
          joined_at?: string
          last_read_at?: string | null
          muted?: boolean
          patient_id?: string | null
          role?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "conversation_participants_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "conversation_participants_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      conversations: {
        Row: {
          created_at: string
          created_by: string
          id: string
          kind: Database["public"]["Enums"]["conversation_kind"]
          last_message_at: string
          patient_id: string | null
          tenant_id: string
          title: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by: string
          id?: string
          kind: Database["public"]["Enums"]["conversation_kind"]
          last_message_at?: string
          patient_id?: string | null
          tenant_id: string
          title?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string
          id?: string
          kind?: Database["public"]["Enums"]["conversation_kind"]
          last_message_at?: string
          patient_id?: string | null
          tenant_id?: string
          title?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "conversations_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "conversations_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      critical_result_alerts: {
        Row: {
          acknowledged_at: string | null
          acknowledged_by: string | null
          alert_type: string
          appointment_id: string | null
          created_at: string
          id: string
          patient_id: string | null
          resolution_note: string | null
          response_id: string
          severity: string
          status: Database["public"]["Enums"]["critical_alert_status"]
          tenant_id: string
          updated_at: string
        }
        Insert: {
          acknowledged_at?: string | null
          acknowledged_by?: string | null
          alert_type: string
          appointment_id?: string | null
          created_at?: string
          id?: string
          patient_id?: string | null
          resolution_note?: string | null
          response_id: string
          severity: string
          status?: Database["public"]["Enums"]["critical_alert_status"]
          tenant_id: string
          updated_at?: string
        }
        Update: {
          acknowledged_at?: string | null
          acknowledged_by?: string | null
          alert_type?: string
          appointment_id?: string | null
          created_at?: string
          id?: string
          patient_id?: string | null
          resolution_note?: string | null
          response_id?: string
          severity?: string
          status?: Database["public"]["Enums"]["critical_alert_status"]
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "critical_result_alerts_acknowledged_by_fkey"
            columns: ["acknowledged_by"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "critical_result_alerts_acknowledged_by_fkey"
            columns: ["acknowledged_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "critical_result_alerts_appointment_id_fkey"
            columns: ["appointment_id"]
            isOneToOne: false
            referencedRelation: "appointments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "critical_result_alerts_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "critical_result_alerts_response_id_fkey"
            columns: ["response_id"]
            isOneToOne: false
            referencedRelation: "questionnaire_responses"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "critical_result_alerts_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      dashboard_widget_prefs: {
        Row: {
          config: Json
          updated_at: string
          user_id: string
        }
        Insert: {
          config?: Json
          updated_at?: string
          user_id: string
        }
        Update: {
          config?: Json
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      duty_availability: {
        Row: {
          created_at: string
          duty_line_id: string | null
          ervenyes_ig: string | null
          ervenyes_tol: string
          id: string
          kezd_ido: string | null
          megjegyzes: string | null
          napok: string[]
          site_id: string | null
          tenant_id: string
          tipus: Database["public"]["Enums"]["duty_availability_tipus"]
          updated_at: string
          user_id: string
          veg_ido: string | null
          visszavonva_at: string | null
        }
        Insert: {
          created_at?: string
          duty_line_id?: string | null
          ervenyes_ig?: string | null
          ervenyes_tol?: string
          id?: string
          kezd_ido?: string | null
          megjegyzes?: string | null
          napok?: string[]
          site_id?: string | null
          tenant_id: string
          tipus: Database["public"]["Enums"]["duty_availability_tipus"]
          updated_at?: string
          user_id: string
          veg_ido?: string | null
          visszavonva_at?: string | null
        }
        Update: {
          created_at?: string
          duty_line_id?: string | null
          ervenyes_ig?: string | null
          ervenyes_tol?: string
          id?: string
          kezd_ido?: string | null
          megjegyzes?: string | null
          napok?: string[]
          site_id?: string | null
          tenant_id?: string
          tipus?: Database["public"]["Enums"]["duty_availability_tipus"]
          updated_at?: string
          user_id?: string
          veg_ido?: string | null
          visszavonva_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "duty_availability_duty_line_id_fkey"
            columns: ["duty_line_id"]
            isOneToOne: false
            referencedRelation: "duty_lines"
            referencedColumns: ["id"]
          },
        ]
      }
      duty_line_coverage: {
        Row: {
          duty_line_id: string
          kotelezo: boolean
          megjegyzes: string | null
          org_unit_id: string
          tenant_id: string
        }
        Insert: {
          duty_line_id: string
          kotelezo?: boolean
          megjegyzes?: string | null
          org_unit_id: string
          tenant_id: string
        }
        Update: {
          duty_line_id?: string
          kotelezo?: boolean
          megjegyzes?: string | null
          org_unit_id?: string
          tenant_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "duty_line_coverage_duty_line_id_fkey"
            columns: ["duty_line_id"]
            isOneToOne: false
            referencedRelation: "duty_lines"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "duty_line_coverage_org_unit_id_fkey"
            columns: ["org_unit_id"]
            isOneToOne: false
            referencedRelation: "org_unit_conflicts"
            referencedColumns: ["org_unit_id"]
          },
          {
            foreignKeyName: "duty_line_coverage_org_unit_id_fkey"
            columns: ["org_unit_id"]
            isOneToOne: false
            referencedRelation: "org_units"
            referencedColumns: ["id"]
          },
        ]
      }
      duty_line_eligibility: {
        Row: {
          created_at: string
          duty_line_id: string
          foglalkozas_tipus:
            | Database["public"]["Enums"]["foglalkozas_tipus"]
            | null
          id: string
          prioritas: number
          staff_role_id: string | null
          tenant_id: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          duty_line_id: string
          foglalkozas_tipus?:
            | Database["public"]["Enums"]["foglalkozas_tipus"]
            | null
          id?: string
          prioritas?: number
          staff_role_id?: string | null
          tenant_id: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          duty_line_id?: string
          foglalkozas_tipus?:
            | Database["public"]["Enums"]["foglalkozas_tipus"]
            | null
          id?: string
          prioritas?: number
          staff_role_id?: string | null
          tenant_id?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "duty_line_eligibility_duty_line_id_fkey"
            columns: ["duty_line_id"]
            isOneToOne: false
            referencedRelation: "duty_lines"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "duty_line_eligibility_staff_role_id_fkey"
            columns: ["staff_role_id"]
            isOneToOne: false
            referencedRelation: "staff_roles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "duty_line_eligibility_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "duty_line_eligibility_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      duty_lines: {
        Row: {
          aktiv: boolean
          created_at: string
          id: string
          kezd_ido: string | null
          kod: string | null
          letszam: number
          megjegyzes: string | null
          napok: number[]
          nev: string
          primary_org_unit_id: string | null
          site_id: string
          sorrend: number
          szerep_tipus: Database["public"]["Enums"]["duty_szerep_tipus"]
          tenant_id: string
          unnepnap_uzemel: boolean
          updated_at: string
          veg_ido: string | null
        }
        Insert: {
          aktiv?: boolean
          created_at?: string
          id?: string
          kezd_ido?: string | null
          kod?: string | null
          letszam?: number
          megjegyzes?: string | null
          napok?: number[]
          nev: string
          primary_org_unit_id?: string | null
          site_id: string
          sorrend?: number
          szerep_tipus: Database["public"]["Enums"]["duty_szerep_tipus"]
          tenant_id: string
          unnepnap_uzemel?: boolean
          updated_at?: string
          veg_ido?: string | null
        }
        Update: {
          aktiv?: boolean
          created_at?: string
          id?: string
          kezd_ido?: string | null
          kod?: string | null
          letszam?: number
          megjegyzes?: string | null
          napok?: number[]
          nev?: string
          primary_org_unit_id?: string | null
          site_id?: string
          sorrend?: number
          szerep_tipus?: Database["public"]["Enums"]["duty_szerep_tipus"]
          tenant_id?: string
          unnepnap_uzemel?: boolean
          updated_at?: string
          veg_ido?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "duty_lines_primary_org_unit_id_fkey"
            columns: ["primary_org_unit_id"]
            isOneToOne: false
            referencedRelation: "org_unit_conflicts"
            referencedColumns: ["org_unit_id"]
          },
          {
            foreignKeyName: "duty_lines_primary_org_unit_id_fkey"
            columns: ["primary_org_unit_id"]
            isOneToOne: false
            referencedRelation: "org_units"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "duty_lines_site_id_fkey"
            columns: ["site_id"]
            isOneToOne: false
            referencedRelation: "sites"
            referencedColumns: ["id"]
          },
        ]
      }
      eeszt_patient_links: {
        Row: {
          created_at: string
          eeszt_org_oid: string | null
          eeszt_page_id: string | null
          hozzajarulas_at: string | null
          hozzajarulas_status: string
          id: string
          megjegyzes: string | null
          patient_id: string
          tenant_id: string
          updated_at: string
          utolso_szinkron_at: string | null
        }
        Insert: {
          created_at?: string
          eeszt_org_oid?: string | null
          eeszt_page_id?: string | null
          hozzajarulas_at?: string | null
          hozzajarulas_status?: string
          id?: string
          megjegyzes?: string | null
          patient_id: string
          tenant_id: string
          updated_at?: string
          utolso_szinkron_at?: string | null
        }
        Update: {
          created_at?: string
          eeszt_org_oid?: string | null
          eeszt_page_id?: string | null
          hozzajarulas_at?: string | null
          hozzajarulas_status?: string
          id?: string
          megjegyzes?: string | null
          patient_id?: string
          tenant_id?: string
          updated_at?: string
          utolso_szinkron_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "eeszt_patient_links_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "eeszt_patient_links_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      email_digest_settings: {
        Row: {
          day_of_week: number
          enabled: boolean
          hour_local: number
          include_sections: Json
          last_sent_at: string | null
          recipient_roles: string[]
          tenant_id: string
          timezone: string
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          day_of_week?: number
          enabled?: boolean
          hour_local?: number
          include_sections?: Json
          last_sent_at?: string | null
          recipient_roles?: string[]
          tenant_id: string
          timezone?: string
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          day_of_week?: number
          enabled?: boolean
          hour_local?: number
          include_sections?: Json
          last_sent_at?: string | null
          recipient_roles?: string[]
          tenant_id?: string
          timezone?: string
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "email_digest_settings_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: true
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      error_log: {
        Row: {
          ai_suggested_at: string | null
          ai_suggestion: string | null
          code: string
          created_at: string
          id: string
          kind: string
          message: string | null
          query_params: Json | null
          route: string | null
          technical: string | null
          title: string | null
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          ai_suggested_at?: string | null
          ai_suggestion?: string | null
          code: string
          created_at?: string
          id?: string
          kind?: string
          message?: string | null
          query_params?: Json | null
          route?: string | null
          technical?: string | null
          title?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          ai_suggested_at?: string | null
          ai_suggestion?: string | null
          code?: string
          created_at?: string
          id?: string
          kind?: string
          message?: string | null
          query_params?: Json | null
          route?: string | null
          technical?: string | null
          title?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      feature_flags: {
        Row: {
          created_at: string
          enabled: boolean
          id: string
          kulcs: string
          metadata: Json
          tenant_id: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          enabled?: boolean
          id?: string
          kulcs: string
          metadata?: Json
          tenant_id?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          enabled?: boolean
          id?: string
          kulcs?: string
          metadata?: Json
          tenant_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "feature_flags_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      feladat_korok: {
        Row: {
          aktiv: boolean
          created_at: string
          id: string
          kulcs: string
          leiras: string | null
          nev: string
          rendszerszintu: boolean
          sorrend: number
          tenant_id: string
          updated_at: string
        }
        Insert: {
          aktiv?: boolean
          created_at?: string
          id?: string
          kulcs: string
          leiras?: string | null
          nev: string
          rendszerszintu?: boolean
          sorrend?: number
          tenant_id: string
          updated_at?: string
        }
        Update: {
          aktiv?: boolean
          created_at?: string
          id?: string
          kulcs?: string
          leiras?: string | null
          nev?: string
          rendszerszintu?: boolean
          sorrend?: number
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "feladat_korok_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      fetal_movements: {
        Row: {
          created_at: string
          datum: string
          eltelt_perc: number | null
          id: string
          jegyzet: string | null
          mozgas_szam: number
          patient_id: string
          program_id: string | null
          szakasz_kezdes: string
          tenant_id: string
          tizedik_mozgas_ido: string | null
        }
        Insert: {
          created_at?: string
          datum?: string
          eltelt_perc?: number | null
          id?: string
          jegyzet?: string | null
          mozgas_szam?: number
          patient_id: string
          program_id?: string | null
          szakasz_kezdes?: string
          tenant_id: string
          tizedik_mozgas_ido?: string | null
        }
        Update: {
          created_at?: string
          datum?: string
          eltelt_perc?: number | null
          id?: string
          jegyzet?: string | null
          mozgas_szam?: number
          patient_id?: string
          program_id?: string | null
          szakasz_kezdes?: string
          tenant_id?: string
          tizedik_mozgas_ido?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "fetal_movements_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fetal_movements_program_id_fkey"
            columns: ["program_id"]
            isOneToOne: false
            referencedRelation: "monitoring_programs"
            referencedColumns: ["id"]
          },
        ]
      }
      floors: {
        Row: {
          aktiv: boolean
          created_at: string
          id: string
          megnevezes: string | null
          site_id: string
          sorrend: number
          szint: string
          tenant_id: string
          updated_at: string
        }
        Insert: {
          aktiv?: boolean
          created_at?: string
          id?: string
          megnevezes?: string | null
          site_id: string
          sorrend?: number
          szint: string
          tenant_id: string
          updated_at?: string
        }
        Update: {
          aktiv?: boolean
          created_at?: string
          id?: string
          megnevezes?: string | null
          site_id?: string
          sorrend?: number
          szint?: string
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "floors_site_id_fkey"
            columns: ["site_id"]
            isOneToOne: false
            referencedRelation: "sites"
            referencedColumns: ["id"]
          },
        ]
      }
      followup_enrollments: {
        Row: {
          anchor_at: string
          anchor_ref: Json
          created_at: string
          created_by: string | null
          id: string
          patient_id: string
          paused_reason: string | null
          protocol_id: string
          status: Database["public"]["Enums"]["followup_enrollment_status"]
          tenant_id: string
          updated_at: string
        }
        Insert: {
          anchor_at: string
          anchor_ref?: Json
          created_at?: string
          created_by?: string | null
          id?: string
          patient_id: string
          paused_reason?: string | null
          protocol_id: string
          status?: Database["public"]["Enums"]["followup_enrollment_status"]
          tenant_id: string
          updated_at?: string
        }
        Update: {
          anchor_at?: string
          anchor_ref?: Json
          created_at?: string
          created_by?: string | null
          id?: string
          patient_id?: string
          paused_reason?: string | null
          protocol_id?: string
          status?: Database["public"]["Enums"]["followup_enrollment_status"]
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "followup_enrollments_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "followup_enrollments_protocol_id_fkey"
            columns: ["protocol_id"]
            isOneToOne: false
            referencedRelation: "followup_protocols"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "followup_enrollments_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      followup_occurrences: {
        Row: {
          assignment_id: string | null
          created_at: string
          due_at: string
          enrollment_id: string
          id: string
          occurrence_index: number
          responded_at: string | null
          status: Database["public"]["Enums"]["followup_occurrence_status"]
          step_id: string
          updated_at: string
        }
        Insert: {
          assignment_id?: string | null
          created_at?: string
          due_at: string
          enrollment_id: string
          id?: string
          occurrence_index: number
          responded_at?: string | null
          status?: Database["public"]["Enums"]["followup_occurrence_status"]
          step_id: string
          updated_at?: string
        }
        Update: {
          assignment_id?: string | null
          created_at?: string
          due_at?: string
          enrollment_id?: string
          id?: string
          occurrence_index?: number
          responded_at?: string | null
          status?: Database["public"]["Enums"]["followup_occurrence_status"]
          step_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "followup_occurrences_assignment_id_fkey"
            columns: ["assignment_id"]
            isOneToOne: false
            referencedRelation: "questionnaire_assignments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "followup_occurrences_enrollment_id_fkey"
            columns: ["enrollment_id"]
            isOneToOne: false
            referencedRelation: "followup_enrollments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "followup_occurrences_step_id_fkey"
            columns: ["step_id"]
            isOneToOne: false
            referencedRelation: "followup_protocol_steps"
            referencedColumns: ["id"]
          },
        ]
      }
      followup_protocol_steps: {
        Row: {
          cadence_days: number
          channel: Database["public"]["Enums"]["reminder_channel"]
          created_at: string
          id: string
          offset_days_from: number
          offset_days_to: number
          phase_label: string
          phase_order: number
          protocol_id: string
          questionnaire_id: string
          reminder_buckets: number[]
          updated_at: string
        }
        Insert: {
          cadence_days: number
          channel?: Database["public"]["Enums"]["reminder_channel"]
          created_at?: string
          id?: string
          offset_days_from: number
          offset_days_to: number
          phase_label: string
          phase_order: number
          protocol_id: string
          questionnaire_id: string
          reminder_buckets?: number[]
          updated_at?: string
        }
        Update: {
          cadence_days?: number
          channel?: Database["public"]["Enums"]["reminder_channel"]
          created_at?: string
          id?: string
          offset_days_from?: number
          offset_days_to?: number
          phase_label?: string
          phase_order?: number
          protocol_id?: string
          questionnaire_id?: string
          reminder_buckets?: number[]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "followup_protocol_steps_protocol_id_fkey"
            columns: ["protocol_id"]
            isOneToOne: false
            referencedRelation: "followup_protocols"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "followup_protocol_steps_questionnaire_id_fkey"
            columns: ["questionnaire_id"]
            isOneToOne: false
            referencedRelation: "questionnaires"
            referencedColumns: ["id"]
          },
        ]
      }
      followup_protocols: {
        Row: {
          aktiv: boolean
          anchor_event: Database["public"]["Enums"]["followup_anchor_event"]
          created_at: string
          created_by: string | null
          default_window_days: number
          id: string
          kod: string
          leiras: string | null
          nev: string
          tenant_id: string
          updated_at: string
        }
        Insert: {
          aktiv?: boolean
          anchor_event: Database["public"]["Enums"]["followup_anchor_event"]
          created_at?: string
          created_by?: string | null
          default_window_days?: number
          id?: string
          kod: string
          leiras?: string | null
          nev: string
          tenant_id: string
          updated_at?: string
        }
        Update: {
          aktiv?: boolean
          anchor_event?: Database["public"]["Enums"]["followup_anchor_event"]
          created_at?: string
          created_by?: string | null
          default_window_days?: number
          id?: string
          kod?: string
          leiras?: string | null
          nev?: string
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "followup_protocols_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      food_log: {
        Row: {
          ai_becsult_kcal: number | null
          ai_makro: Json | null
          created_at: string
          etkezes_tipus: string | null
          foto_url: string | null
          id: string
          leiras: string | null
          megbizhatosag: string
          patient_id: string
          program_id: string | null
          tenant_id: string
          ts: string
        }
        Insert: {
          ai_becsult_kcal?: number | null
          ai_makro?: Json | null
          created_at?: string
          etkezes_tipus?: string | null
          foto_url?: string | null
          id?: string
          leiras?: string | null
          megbizhatosag?: string
          patient_id: string
          program_id?: string | null
          tenant_id: string
          ts?: string
        }
        Update: {
          ai_becsult_kcal?: number | null
          ai_makro?: Json | null
          created_at?: string
          etkezes_tipus?: string | null
          foto_url?: string | null
          id?: string
          leiras?: string | null
          megbizhatosag?: string
          patient_id?: string
          program_id?: string | null
          tenant_id?: string
          ts?: string
        }
        Relationships: [
          {
            foreignKeyName: "food_log_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "food_log_program_id_fkey"
            columns: ["program_id"]
            isOneToOne: false
            referencedRelation: "monitoring_programs"
            referencedColumns: ["id"]
          },
        ]
      }
      gdpr_consents: {
        Row: {
          cel: Database["public"]["Enums"]["consent_purpose"]
          created_at: string
          dokumentum_verzio: string
          elfogadva_at: string
          forras_ip: unknown
          forras_user_agent: string | null
          id: string
          szoveg_hivatkozas: string | null
          tenant_id: string
          updated_at: string
          user_id: string
          visszavonva_at: string | null
        }
        Insert: {
          cel: Database["public"]["Enums"]["consent_purpose"]
          created_at?: string
          dokumentum_verzio: string
          elfogadva_at?: string
          forras_ip?: unknown
          forras_user_agent?: string | null
          id?: string
          szoveg_hivatkozas?: string | null
          tenant_id: string
          updated_at?: string
          user_id: string
          visszavonva_at?: string | null
        }
        Update: {
          cel?: Database["public"]["Enums"]["consent_purpose"]
          created_at?: string
          dokumentum_verzio?: string
          elfogadva_at?: string
          forras_ip?: unknown
          forras_user_agent?: string | null
          id?: string
          szoveg_hivatkozas?: string | null
          tenant_id?: string
          updated_at?: string
          user_id?: string
          visszavonva_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "gdpr_consents_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "gdpr_consents_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "gdpr_consents_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      i18n_missing_keys: {
        Row: {
          created_at: string
          hits: number
          id: string
          key: string
          kind: string
          lang: string
          last_seen_at: string
          namespace: string
          source_text: string
        }
        Insert: {
          created_at?: string
          hits?: number
          id?: string
          key: string
          kind?: string
          lang: string
          last_seen_at?: string
          namespace: string
          source_text: string
        }
        Update: {
          created_at?: string
          hits?: number
          id?: string
          key?: string
          kind?: string
          lang?: string
          last_seen_at?: string
          namespace?: string
          source_text?: string
        }
        Relationships: []
      }
      i18n_source_strings: {
        Row: {
          ai_described: boolean
          created_at: string
          description: string | null
          element_type: string
          id: string
          is_active: boolean
          key: string
          max_length: number | null
          namespace: string
          screen: string | null
          source_text: string
          translator_note: string | null
          updated_at: string
        }
        Insert: {
          ai_described?: boolean
          created_at?: string
          description?: string | null
          element_type?: string
          id?: string
          is_active?: boolean
          key: string
          max_length?: number | null
          namespace?: string
          screen?: string | null
          source_text: string
          translator_note?: string | null
          updated_at?: string
        }
        Update: {
          ai_described?: boolean
          created_at?: string
          description?: string | null
          element_type?: string
          id?: string
          is_active?: boolean
          key?: string
          max_length?: number | null
          namespace?: string
          screen?: string | null
          source_text?: string
          translator_note?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      i18n_translation_jobs: {
        Row: {
          error: string | null
          failed: number
          finished_at: string | null
          id: string
          langs: string[]
          mode: string
          namespace: string | null
          started_at: string
          started_by: string | null
          status: string
          total: number
          translated: number
        }
        Insert: {
          error?: string | null
          failed?: number
          finished_at?: string | null
          id?: string
          langs: string[]
          mode?: string
          namespace?: string | null
          started_at?: string
          started_by?: string | null
          status?: string
          total?: number
          translated?: number
        }
        Update: {
          error?: string | null
          failed?: number
          finished_at?: string | null
          id?: string
          langs?: string[]
          mode?: string
          namespace?: string | null
          started_at?: string
          started_by?: string | null
          status?: string
          total?: number
          translated?: number
        }
        Relationships: []
      }
      i18n_translations: {
        Row: {
          content_ref: string | null
          created_at: string
          edited_by_user: boolean
          id: string
          key: string
          kind: string
          lang: string
          namespace: string
          source_hash: string
          source_text: string
          tenant_id: string | null
          updated_at: string
          value: string
        }
        Insert: {
          content_ref?: string | null
          created_at?: string
          edited_by_user?: boolean
          id?: string
          key: string
          kind?: string
          lang: string
          namespace: string
          source_hash: string
          source_text: string
          tenant_id?: string | null
          updated_at?: string
          value: string
        }
        Update: {
          content_ref?: string | null
          created_at?: string
          edited_by_user?: boolean
          id?: string
          key?: string
          kind?: string
          lang?: string
          namespace?: string
          source_hash?: string
          source_text?: string
          tenant_id?: string | null
          updated_at?: string
          value?: string
        }
        Relationships: [
          {
            foreignKeyName: "i18n_translations_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      illetmeny_snapshots: {
        Row: {
          bemenet: Json
          cimke: string
          created_at: string
          created_by: string | null
          eredmeny: Json
          id: string
          jogi_hivatkozasok: Json
          tenant_id: string
          updated_at: string
          user_id: string
          vegosszeg_ft: number
          vonatkozasi_datum: string
        }
        Insert: {
          bemenet?: Json
          cimke: string
          created_at?: string
          created_by?: string | null
          eredmeny?: Json
          id?: string
          jogi_hivatkozasok?: Json
          tenant_id: string
          updated_at?: string
          user_id: string
          vegosszeg_ft?: number
          vonatkozasi_datum?: string
        }
        Update: {
          bemenet?: Json
          cimke?: string
          created_at?: string
          created_by?: string | null
          eredmeny?: Json
          id?: string
          jogi_hivatkozasok?: Json
          tenant_id?: string
          updated_at?: string
          user_id?: string
          vegosszeg_ft?: number
          vonatkozasi_datum?: string
        }
        Relationships: [
          {
            foreignKeyName: "illetmeny_snapshots_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      incompatibilities: {
        Row: {
          bejelentes_datum: string
          created_at: string
          dokumentum_url: string | null
          dontes_datum: string | null
          ervenyes_ig: string | null
          ervenyes_tol: string
          heti_oraszam: number | null
          id: string
          megjegyzes: string | null
          munkakor: string | null
          munkaltato_nev: string | null
          tenant_id: string
          tipus: string
          updated_at: string
          user_id: string
          vezeto_id: string | null
          vezetoi_dontes: string | null
        }
        Insert: {
          bejelentes_datum?: string
          created_at?: string
          dokumentum_url?: string | null
          dontes_datum?: string | null
          ervenyes_ig?: string | null
          ervenyes_tol: string
          heti_oraszam?: number | null
          id?: string
          megjegyzes?: string | null
          munkakor?: string | null
          munkaltato_nev?: string | null
          tenant_id: string
          tipus: string
          updated_at?: string
          user_id: string
          vezeto_id?: string | null
          vezetoi_dontes?: string | null
        }
        Update: {
          bejelentes_datum?: string
          created_at?: string
          dokumentum_url?: string | null
          dontes_datum?: string | null
          ervenyes_ig?: string | null
          ervenyes_tol?: string
          heti_oraszam?: number | null
          id?: string
          megjegyzes?: string | null
          munkakor?: string | null
          munkaltato_nev?: string | null
          tenant_id?: string
          tipus?: string
          updated_at?: string
          user_id?: string
          vezeto_id?: string | null
          vezetoi_dontes?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "incompatibilities_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      juttatasok: {
        Row: {
          created_at: string
          dokumentum_url: string | null
          havi_osszeg_ft: number
          id: string
          kezdo_datum: string
          megjegyzes: string | null
          tenant_id: string
          tipus: string
          updated_at: string
          user_id: string
          zaro_datum: string | null
        }
        Insert: {
          created_at?: string
          dokumentum_url?: string | null
          havi_osszeg_ft?: number
          id?: string
          kezdo_datum: string
          megjegyzes?: string | null
          tenant_id: string
          tipus: string
          updated_at?: string
          user_id: string
          zaro_datum?: string | null
        }
        Update: {
          created_at?: string
          dokumentum_url?: string | null
          havi_osszeg_ft?: number
          id?: string
          kezdo_datum?: string
          megjegyzes?: string | null
          tenant_id?: string
          tipus?: string
          updated_at?: string
          user_id?: string
          zaro_datum?: string | null
        }
        Relationships: []
      }
      kirendelesek: {
        Row: {
          alairt_dokumentum_url: string | null
          cel_egeszsegugyi_szolgaltato: string
          created_at: string
          hozzajarult: boolean
          id: string
          indok: string | null
          kezdo_datum: string
          napi_dij_ft: number | null
          tenant_id: string
          updated_at: string
          user_id: string
          zaro_datum: string
        }
        Insert: {
          alairt_dokumentum_url?: string | null
          cel_egeszsegugyi_szolgaltato: string
          created_at?: string
          hozzajarult?: boolean
          id?: string
          indok?: string | null
          kezdo_datum: string
          napi_dij_ft?: number | null
          tenant_id: string
          updated_at?: string
          user_id: string
          zaro_datum: string
        }
        Update: {
          alairt_dokumentum_url?: string | null
          cel_egeszsegugyi_szolgaltato?: string
          created_at?: string
          hozzajarult?: boolean
          id?: string
          indok?: string | null
          kezdo_datum?: string
          napi_dij_ft?: number | null
          tenant_id?: string
          updated_at?: string
          user_id?: string
          zaro_datum?: string
        }
        Relationships: []
      }
      landing_page_blocks: {
        Row: {
          block_type: string
          content: Json
          created_at: string
          draft_content: Json | null
          id: string
          is_published: boolean
          locale: string
          position: number
          updated_at: string
          updated_by: string | null
          variant: string
        }
        Insert: {
          block_type: string
          content?: Json
          created_at?: string
          draft_content?: Json | null
          id?: string
          is_published?: boolean
          locale?: string
          position?: number
          updated_at?: string
          updated_by?: string | null
          variant?: string
        }
        Update: {
          block_type?: string
          content?: Json
          created_at?: string
          draft_content?: Json | null
          id?: string
          is_published?: boolean
          locale?: string
          position?: number
          updated_at?: string
          updated_by?: string | null
          variant?: string
        }
        Relationships: []
      }
      landing_page_versions: {
        Row: {
          created_at: string
          created_by: string | null
          id: string
          label: string | null
          locale: string
          snapshot: Json
          variant: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          id?: string
          label?: string | null
          locale?: string
          snapshot: Json
          variant?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          id?: string
          label?: string | null
          locale?: string
          snapshot?: Json
          variant?: string
        }
        Relationships: []
      }
      leave_admin_audit: {
        Row: {
          action: string
          actor_user_id: string | null
          after_data: Json | null
          before_data: Json | null
          created_at: string
          ev: number | null
          id: string
          jogcim: string | null
          nap: number | null
          summary: string | null
          target_user_id: string | null
          tenant_id: string
        }
        Insert: {
          action: string
          actor_user_id?: string | null
          after_data?: Json | null
          before_data?: Json | null
          created_at?: string
          ev?: number | null
          id?: string
          jogcim?: string | null
          nap?: number | null
          summary?: string | null
          target_user_id?: string | null
          tenant_id: string
        }
        Update: {
          action?: string
          actor_user_id?: string | null
          after_data?: Json | null
          before_data?: Json | null
          created_at?: string
          ev?: number | null
          id?: string
          jogcim?: string | null
          nap?: number | null
          summary?: string | null
          target_user_id?: string | null
          tenant_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "leave_admin_audit_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      leave_carryover_log: {
        Row: {
          appointment_id: string | null
          created_at: string
          created_by: string | null
          from_year: number
          id: string
          jogcim: string
          megjegyzes: string | null
          nap: number
          tenant_id: string
          tipus: string
          to_year: number | null
          user_id: string
        }
        Insert: {
          appointment_id?: string | null
          created_at?: string
          created_by?: string | null
          from_year: number
          id?: string
          jogcim: string
          megjegyzes?: string | null
          nap: number
          tenant_id: string
          tipus: string
          to_year?: number | null
          user_id: string
        }
        Update: {
          appointment_id?: string | null
          created_at?: string
          created_by?: string | null
          from_year?: number
          id?: string
          jogcim?: string
          megjegyzes?: string | null
          nap?: number
          tenant_id?: string
          tipus?: string
          to_year?: number | null
          user_id?: string
        }
        Relationships: []
      }
      leave_entitlement: {
        Row: {
          athozott_nap: number
          created_at: string
          ev: number
          forced_taken_nap: number
          hatralevo: number | null
          id: string
          jaro_nap: number
          jogcim: string
          kiadott_nap: number
          lezart_at: string | null
          lezart_by: string | null
          manual_korrekcio: number
          notes: string | null
          tenant_id: string
          terv_nap: number
          updated_at: string
          user_id: string
        }
        Insert: {
          athozott_nap?: number
          created_at?: string
          ev: number
          forced_taken_nap?: number
          hatralevo?: number | null
          id?: string
          jaro_nap?: number
          jogcim: string
          kiadott_nap?: number
          lezart_at?: string | null
          lezart_by?: string | null
          manual_korrekcio?: number
          notes?: string | null
          tenant_id: string
          terv_nap?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          athozott_nap?: number
          created_at?: string
          ev?: number
          forced_taken_nap?: number
          hatralevo?: number | null
          id?: string
          jaro_nap?: number
          jogcim?: string
          kiadott_nap?: number
          lezart_at?: string | null
          lezart_by?: string | null
          manual_korrekcio?: number
          notes?: string | null
          tenant_id?: string
          terv_nap?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      leave_policy: {
        Row: {
          alapszabadsag_mt: number
          apasagi_nap: number
          created_at: string
          eletkor_pot: Json
          eu_alap: Json
          ev: number
          forced_takeout_deadline_mmdd: string
          gyermek_pot: Json
          id: string
          max_carryover_alap_quarter: boolean
          oktatoi_max: number
          oktatoi_max_targy: number
          sugar_pot: number
          szuloi_nap: number
          tenant_id: string
          updated_at: string
          vezeto_magas_pot: number
          vezeto_pot: number
        }
        Insert: {
          alapszabadsag_mt?: number
          apasagi_nap?: number
          created_at?: string
          eletkor_pot?: Json
          eu_alap?: Json
          ev: number
          forced_takeout_deadline_mmdd?: string
          gyermek_pot?: Json
          id?: string
          max_carryover_alap_quarter?: boolean
          oktatoi_max?: number
          oktatoi_max_targy?: number
          sugar_pot?: number
          szuloi_nap?: number
          tenant_id: string
          updated_at?: string
          vezeto_magas_pot?: number
          vezeto_pot?: number
        }
        Update: {
          alapszabadsag_mt?: number
          apasagi_nap?: number
          created_at?: string
          eletkor_pot?: Json
          eu_alap?: Json
          ev?: number
          forced_takeout_deadline_mmdd?: string
          gyermek_pot?: Json
          id?: string
          max_carryover_alap_quarter?: boolean
          oktatoi_max?: number
          oktatoi_max_targy?: number
          sugar_pot?: number
          szuloi_nap?: number
          tenant_id?: string
          updated_at?: string
          vezeto_magas_pot?: number
          vezeto_pot?: number
        }
        Relationships: []
      }
      mandatory_duty_exemptions: {
        Row: {
          created_at: string
          ervenyes_ig: string | null
          ervenyes_tol: string
          id: string
          indok: string | null
          jovahagyas_at: string | null
          jovahagyas_indok: string | null
          jovahagyo_id: string | null
          ok: Database["public"]["Enums"]["mentesseg_ok"]
          status: string
          tenant_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          ervenyes_ig?: string | null
          ervenyes_tol: string
          id?: string
          indok?: string | null
          jovahagyas_at?: string | null
          jovahagyas_indok?: string | null
          jovahagyo_id?: string | null
          ok: Database["public"]["Enums"]["mentesseg_ok"]
          status?: string
          tenant_id: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          ervenyes_ig?: string | null
          ervenyes_tol?: string
          id?: string
          indok?: string | null
          jovahagyas_at?: string | null
          jovahagyas_indok?: string | null
          jovahagyo_id?: string | null
          ok?: Database["public"]["Enums"]["mentesseg_ok"]
          status?: string
          tenant_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "mandatory_duty_exemptions_jovahagyo_id_fkey"
            columns: ["jovahagyo_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "mandatory_duty_exemptions_jovahagyo_id_fkey"
            columns: ["jovahagyo_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "mandatory_duty_exemptions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "mandatory_duty_exemptions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      mandatory_duty_rules: {
        Row: {
          aktiv: boolean
          created_at: string
          id: string
          max_per_honap: number | null
          megjegyzes: string | null
          min_per_honap: number
          scope_tipus: string
          scope_value: string | null
          tenant_id: string
          updated_at: string
        }
        Insert: {
          aktiv?: boolean
          created_at?: string
          id?: string
          max_per_honap?: number | null
          megjegyzes?: string | null
          min_per_honap?: number
          scope_tipus: string
          scope_value?: string | null
          tenant_id: string
          updated_at?: string
        }
        Update: {
          aktiv?: boolean
          created_at?: string
          id?: string
          max_per_honap?: number | null
          megjegyzes?: string | null
          min_per_honap?: number
          scope_tipus?: string
          scope_value?: string | null
          tenant_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      measurements: {
        Row: {
          context: Json | null
          created_at: string
          id: string
          kind: Database["public"]["Enums"]["measurement_kind"]
          patient_id: string
          program_id: string | null
          recorded_by: string | null
          source: Database["public"]["Enums"]["measurement_source"]
          tenant_id: string
          ts: string
          unit: string | null
          value: number | null
          value2: number | null
        }
        Insert: {
          context?: Json | null
          created_at?: string
          id?: string
          kind: Database["public"]["Enums"]["measurement_kind"]
          patient_id: string
          program_id?: string | null
          recorded_by?: string | null
          source?: Database["public"]["Enums"]["measurement_source"]
          tenant_id: string
          ts?: string
          unit?: string | null
          value?: number | null
          value2?: number | null
        }
        Update: {
          context?: Json | null
          created_at?: string
          id?: string
          kind?: Database["public"]["Enums"]["measurement_kind"]
          patient_id?: string
          program_id?: string | null
          recorded_by?: string | null
          source?: Database["public"]["Enums"]["measurement_source"]
          tenant_id?: string
          ts?: string
          unit?: string | null
          value?: number | null
          value2?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "measurements_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "measurements_program_id_fkey"
            columns: ["program_id"]
            isOneToOne: false
            referencedRelation: "monitoring_programs"
            referencedColumns: ["id"]
          },
        ]
      }
      menstrual_cycles: {
        Row: {
          bbt_id: string | null
          ciklus_hossz: number | null
          ciklus_kezdet: string
          created_at: string
          id: string
          menstruacio_hossz: number | null
          ovulacio_becsult: string | null
          patient_id: string
          program_id: string | null
          tenant_id: string
          termekeny_ablak_ig: string | null
          termekeny_ablak_tol: string | null
          tunetek: Json | null
        }
        Insert: {
          bbt_id?: string | null
          ciklus_hossz?: number | null
          ciklus_kezdet: string
          created_at?: string
          id?: string
          menstruacio_hossz?: number | null
          ovulacio_becsult?: string | null
          patient_id: string
          program_id?: string | null
          tenant_id: string
          termekeny_ablak_ig?: string | null
          termekeny_ablak_tol?: string | null
          tunetek?: Json | null
        }
        Update: {
          bbt_id?: string | null
          ciklus_hossz?: number | null
          ciklus_kezdet?: string
          created_at?: string
          id?: string
          menstruacio_hossz?: number | null
          ovulacio_becsult?: string | null
          patient_id?: string
          program_id?: string | null
          tenant_id?: string
          termekeny_ablak_ig?: string | null
          termekeny_ablak_tol?: string | null
          tunetek?: Json | null
        }
        Relationships: [
          {
            foreignKeyName: "menstrual_cycles_bbt_id_fkey"
            columns: ["bbt_id"]
            isOneToOne: false
            referencedRelation: "measurements"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "menstrual_cycles_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "menstrual_cycles_program_id_fkey"
            columns: ["program_id"]
            isOneToOne: false
            referencedRelation: "monitoring_programs"
            referencedColumns: ["id"]
          },
        ]
      }
      message_attachments: {
        Row: {
          ai_summary: string | null
          ai_summary_lang: string | null
          ai_summary_status: Database["public"]["Enums"]["attachment_summary_status"]
          conversation_id: string
          created_at: string
          duration_ms: number | null
          id: string
          kind: string
          message_id: string | null
          mime: string
          original_name: string
          size_bytes: number
          storage_path: string
          transcript: string | null
          uploaded_by: string
        }
        Insert: {
          ai_summary?: string | null
          ai_summary_lang?: string | null
          ai_summary_status?: Database["public"]["Enums"]["attachment_summary_status"]
          conversation_id: string
          created_at?: string
          duration_ms?: number | null
          id?: string
          kind?: string
          message_id?: string | null
          mime: string
          original_name: string
          size_bytes: number
          storage_path: string
          transcript?: string | null
          uploaded_by: string
        }
        Update: {
          ai_summary?: string | null
          ai_summary_lang?: string | null
          ai_summary_status?: Database["public"]["Enums"]["attachment_summary_status"]
          conversation_id?: string
          created_at?: string
          duration_ms?: number | null
          id?: string
          kind?: string
          message_id?: string | null
          mime?: string
          original_name?: string
          size_bytes?: number
          storage_path?: string
          transcript?: string | null
          uploaded_by?: string
        }
        Relationships: [
          {
            foreignKeyName: "message_attachments_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "message_attachments_message_id_fkey"
            columns: ["message_id"]
            isOneToOne: false
            referencedRelation: "messages"
            referencedColumns: ["id"]
          },
        ]
      }
      message_read_receipts: {
        Row: {
          message_id: string
          read_at: string
          reader_user_id: string
        }
        Insert: {
          message_id: string
          read_at?: string
          reader_user_id: string
        }
        Update: {
          message_id?: string
          read_at?: string
          reader_user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "message_read_receipts_message_id_fkey"
            columns: ["message_id"]
            isOneToOne: false
            referencedRelation: "messages"
            referencedColumns: ["id"]
          },
        ]
      }
      message_translations: {
        Row: {
          created_at: string
          lang: string
          message_id: string
          model: string | null
          translated_text: string
        }
        Insert: {
          created_at?: string
          lang: string
          message_id: string
          model?: string | null
          translated_text: string
        }
        Update: {
          created_at?: string
          lang?: string
          message_id?: string
          model?: string | null
          translated_text?: string
        }
        Relationships: [
          {
            foreignKeyName: "message_translations_message_id_fkey"
            columns: ["message_id"]
            isOneToOne: false
            referencedRelation: "messages"
            referencedColumns: ["id"]
          },
        ]
      }
      messages: {
        Row: {
          body: string | null
          conversation_id: string
          created_at: string
          deleted_at: string | null
          edited_at: string | null
          id: string
          reply_to_id: string | null
          sender_kind: Database["public"]["Enums"]["message_sender_kind"]
          sender_patient_id: string | null
          sender_user_id: string | null
          source_lang: string | null
        }
        Insert: {
          body?: string | null
          conversation_id: string
          created_at?: string
          deleted_at?: string | null
          edited_at?: string | null
          id?: string
          reply_to_id?: string | null
          sender_kind?: Database["public"]["Enums"]["message_sender_kind"]
          sender_patient_id?: string | null
          sender_user_id?: string | null
          source_lang?: string | null
        }
        Update: {
          body?: string | null
          conversation_id?: string
          created_at?: string
          deleted_at?: string | null
          edited_at?: string | null
          id?: string
          reply_to_id?: string | null
          sender_kind?: Database["public"]["Enums"]["message_sender_kind"]
          sender_patient_id?: string | null
          sender_user_id?: string | null
          source_lang?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "messages_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "messages_reply_to_id_fkey"
            columns: ["reply_to_id"]
            isOneToOne: false
            referencedRelation: "messages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "messages_sender_patient_id_fkey"
            columns: ["sender_patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      minosites: {
        Row: {
          alairas_datum: string | null
          alairt: boolean
          created_at: string
          dokumentum_url: string | null
          eredmeny: string
          ertekelo_user_id: string | null
          id: string
          idoszak_ig: string
          idoszak_tol: string
          szoveges_ertekeles: string | null
          tenant_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          alairas_datum?: string | null
          alairt?: boolean
          created_at?: string
          dokumentum_url?: string | null
          eredmeny: string
          ertekelo_user_id?: string | null
          id?: string
          idoszak_ig: string
          idoszak_tol: string
          szoveges_ertekeles?: string | null
          tenant_id: string
          updated_at?: string
          user_id: string
        }
        Update: {
          alairas_datum?: string | null
          alairt?: boolean
          created_at?: string
          dokumentum_url?: string | null
          eredmeny?: string
          ertekelo_user_id?: string | null
          id?: string
          idoszak_ig?: string
          idoszak_tol?: string
          szoveges_ertekeles?: string | null
          tenant_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      monitoring_alerts: {
        Row: {
          ack_note: string | null
          acknowledged_at: string | null
          acknowledged_by: string | null
          created_at: string
          fetal_movement_id: string | null
          id: string
          kind: Database["public"]["Enums"]["monitoring_alert_kind"]
          measurement_id: string | null
          patient_id: string
          program_id: string | null
          severity: Database["public"]["Enums"]["monitoring_alert_severity"]
          status: Database["public"]["Enums"]["monitoring_alert_status"]
          stool_log_id: string | null
          tenant_id: string
          uzenet: string
        }
        Insert: {
          ack_note?: string | null
          acknowledged_at?: string | null
          acknowledged_by?: string | null
          created_at?: string
          fetal_movement_id?: string | null
          id?: string
          kind: Database["public"]["Enums"]["monitoring_alert_kind"]
          measurement_id?: string | null
          patient_id: string
          program_id?: string | null
          severity?: Database["public"]["Enums"]["monitoring_alert_severity"]
          status?: Database["public"]["Enums"]["monitoring_alert_status"]
          stool_log_id?: string | null
          tenant_id: string
          uzenet: string
        }
        Update: {
          ack_note?: string | null
          acknowledged_at?: string | null
          acknowledged_by?: string | null
          created_at?: string
          fetal_movement_id?: string | null
          id?: string
          kind?: Database["public"]["Enums"]["monitoring_alert_kind"]
          measurement_id?: string | null
          patient_id?: string
          program_id?: string | null
          severity?: Database["public"]["Enums"]["monitoring_alert_severity"]
          status?: Database["public"]["Enums"]["monitoring_alert_status"]
          stool_log_id?: string | null
          tenant_id?: string
          uzenet?: string
        }
        Relationships: [
          {
            foreignKeyName: "monitoring_alerts_fetal_movement_id_fkey"
            columns: ["fetal_movement_id"]
            isOneToOne: false
            referencedRelation: "fetal_movements"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "monitoring_alerts_measurement_id_fkey"
            columns: ["measurement_id"]
            isOneToOne: false
            referencedRelation: "measurements"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "monitoring_alerts_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "monitoring_alerts_program_id_fkey"
            columns: ["program_id"]
            isOneToOne: false
            referencedRelation: "monitoring_programs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "monitoring_alerts_stool_log_id_fkey"
            columns: ["stool_log_id"]
            isOneToOne: false
            referencedRelation: "stool_log"
            referencedColumns: ["id"]
          },
        ]
      }
      monitoring_programs: {
        Row: {
          aktiv: boolean
          created_at: string
          id: string
          kezdes: string
          megjegyzes: string | null
          patient_id: string
          tenant_id: string
          tipus: Database["public"]["Enums"]["monitoring_program_tipus"]
          updated_at: string
          varhato_veg: string | null
        }
        Insert: {
          aktiv?: boolean
          created_at?: string
          id?: string
          kezdes?: string
          megjegyzes?: string | null
          patient_id: string
          tenant_id: string
          tipus: Database["public"]["Enums"]["monitoring_program_tipus"]
          updated_at?: string
          varhato_veg?: string | null
        }
        Update: {
          aktiv?: boolean
          created_at?: string
          id?: string
          kezdes?: string
          megjegyzes?: string | null
          patient_id?: string
          tenant_id?: string
          tipus?: Database["public"]["Enums"]["monitoring_program_tipus"]
          updated_at?: string
          varhato_veg?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "monitoring_programs_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      monitoring_thresholds: {
        Row: {
          beallito_id: string | null
          created_at: string
          ertek: number
          id: string
          kulcs: string
          megjegyzes: string | null
          patient_id: string | null
          program_id: string | null
          tenant_id: string
          unit: string | null
          updated_at: string
        }
        Insert: {
          beallito_id?: string | null
          created_at?: string
          ertek: number
          id?: string
          kulcs: string
          megjegyzes?: string | null
          patient_id?: string | null
          program_id?: string | null
          tenant_id: string
          unit?: string | null
          updated_at?: string
        }
        Update: {
          beallito_id?: string | null
          created_at?: string
          ertek?: number
          id?: string
          kulcs?: string
          megjegyzes?: string | null
          patient_id?: string | null
          program_id?: string | null
          tenant_id?: string
          unit?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "monitoring_thresholds_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "monitoring_thresholds_program_id_fkey"
            columns: ["program_id"]
            isOneToOne: false
            referencedRelation: "monitoring_programs"
            referencedColumns: ["id"]
          },
        ]
      }
      notification_preferences: {
        Row: {
          created_at: string
          email_weekly_summary: boolean
          id: string
          push_appointments: boolean
          push_critical_alerts: boolean
          push_lab_results: boolean
          push_lifestyle_tips: boolean
          push_messages: boolean
          push_questionnaire_reminders: boolean
          quiet_hours_end: string | null
          quiet_hours_start: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          email_weekly_summary?: boolean
          id?: string
          push_appointments?: boolean
          push_critical_alerts?: boolean
          push_lab_results?: boolean
          push_lifestyle_tips?: boolean
          push_messages?: boolean
          push_questionnaire_reminders?: boolean
          quiet_hours_end?: string | null
          quiet_hours_start?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          email_weekly_summary?: boolean
          id?: string
          push_appointments?: boolean
          push_critical_alerts?: boolean
          push_lab_results?: boolean
          push_lifestyle_tips?: boolean
          push_messages?: boolean
          push_questionnaire_reminders?: boolean
          quiet_hours_end?: string | null
          quiet_hours_start?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      notifications: {
        Row: {
          cim: string
          created_at: string
          id: string
          link: string | null
          olvasott_at: string | null
          tenant_id: string | null
          tipus: string
          user_id: string
          uzenet: string | null
        }
        Insert: {
          cim: string
          created_at?: string
          id?: string
          link?: string | null
          olvasott_at?: string | null
          tenant_id?: string | null
          tipus?: string
          user_id: string
          uzenet?: string | null
        }
        Update: {
          cim?: string
          created_at?: string
          id?: string
          link?: string | null
          olvasott_at?: string | null
          tenant_id?: string | null
          tipus?: string
          user_id?: string
          uzenet?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "notifications_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      obstetric_partogram_entries: {
        Row: {
          cervix_cm: number | null
          contraction_duration_sec: number | null
          contractions_per_10min: number | null
          created_at: string
          created_by: string
          descent_station: number | null
          drugs_text: string | null
          fetal_heart_rate: number | null
          id: string
          liquor_color: string | null
          maternal_bp_dia: number | null
          maternal_bp_sys: number | null
          maternal_hr: number | null
          moulding: string | null
          notes: string | null
          oxytocin_mu: number | null
          partogram_id: string
          recorded_at: string
          temp_c: number | null
        }
        Insert: {
          cervix_cm?: number | null
          contraction_duration_sec?: number | null
          contractions_per_10min?: number | null
          created_at?: string
          created_by?: string
          descent_station?: number | null
          drugs_text?: string | null
          fetal_heart_rate?: number | null
          id?: string
          liquor_color?: string | null
          maternal_bp_dia?: number | null
          maternal_bp_sys?: number | null
          maternal_hr?: number | null
          moulding?: string | null
          notes?: string | null
          oxytocin_mu?: number | null
          partogram_id: string
          recorded_at?: string
          temp_c?: number | null
        }
        Update: {
          cervix_cm?: number | null
          contraction_duration_sec?: number | null
          contractions_per_10min?: number | null
          created_at?: string
          created_by?: string
          descent_station?: number | null
          drugs_text?: string | null
          fetal_heart_rate?: number | null
          id?: string
          liquor_color?: string | null
          maternal_bp_dia?: number | null
          maternal_bp_sys?: number | null
          maternal_hr?: number | null
          moulding?: string | null
          notes?: string | null
          oxytocin_mu?: number | null
          partogram_id?: string
          recorded_at?: string
          temp_c?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "obstetric_partogram_entries_partogram_id_fkey"
            columns: ["partogram_id"]
            isOneToOne: false
            referencedRelation: "obstetric_partograms"
            referencedColumns: ["id"]
          },
        ]
      }
      obstetric_partograms: {
        Row: {
          created_at: string
          created_by: string
          encounter_id: string
          id: string
          labor_start_ts: string
          membrane_status: string | null
          notes_md: string | null
          parity_gravida_json: Json
          patient_id: string
          tenant_id: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string
          encounter_id: string
          id?: string
          labor_start_ts?: string
          membrane_status?: string | null
          notes_md?: string | null
          parity_gravida_json?: Json
          patient_id: string
          tenant_id?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string
          encounter_id?: string
          id?: string
          labor_start_ts?: string
          membrane_status?: string | null
          notes_md?: string | null
          parity_gravida_json?: Json
          patient_id?: string
          tenant_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "obstetric_partograms_encounter_id_fkey"
            columns: ["encounter_id"]
            isOneToOne: false
            referencedRelation: "clinical_encounters"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "obstetric_partograms_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "obstetric_partograms_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      opt_out_agreements: {
        Row: {
          alairas_datum: string
          created_at: string
          dokumentum_url: string | null
          employment_id: string | null
          ervenyes_ig: string | null
          ervenyes_tol: string
          id: string
          letrehozta: string | null
          tenant_id: string
          updated_at: string
          user_id: string
          visszavonas_datum: string | null
          visszavonas_hatalyba_lep: string | null
          visszavonas_indok: string | null
        }
        Insert: {
          alairas_datum: string
          created_at?: string
          dokumentum_url?: string | null
          employment_id?: string | null
          ervenyes_ig?: string | null
          ervenyes_tol: string
          id?: string
          letrehozta?: string | null
          tenant_id: string
          updated_at?: string
          user_id: string
          visszavonas_datum?: string | null
          visszavonas_hatalyba_lep?: string | null
          visszavonas_indok?: string | null
        }
        Update: {
          alairas_datum?: string
          created_at?: string
          dokumentum_url?: string | null
          employment_id?: string | null
          ervenyes_ig?: string | null
          ervenyes_tol?: string
          id?: string
          letrehozta?: string | null
          tenant_id?: string
          updated_at?: string
          user_id?: string
          visszavonas_datum?: string | null
          visszavonas_hatalyba_lep?: string | null
          visszavonas_indok?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "opt_out_agreements_employment_id_fkey"
            columns: ["employment_id"]
            isOneToOne: false
            referencedRelation: "profile_employment"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "opt_out_agreements_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      or_blocks: {
        Row: {
          created_at: string
          created_by: string | null
          datum: string
          felszabaditasi_hatarido: string | null
          id: string
          ismetlodo_szabaly: string | null
          kezdo_ido: string
          megjegyzes: string | null
          org_unit_id: string
          sebesz_user_id: string | null
          specialty_id: string | null
          statusz: Database["public"]["Enums"]["or_block_statusz_enum"]
          surgossegi_keret: boolean
          tenant_id: string
          updated_at: string
          veg_ido: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          datum: string
          felszabaditasi_hatarido?: string | null
          id?: string
          ismetlodo_szabaly?: string | null
          kezdo_ido: string
          megjegyzes?: string | null
          org_unit_id: string
          sebesz_user_id?: string | null
          specialty_id?: string | null
          statusz?: Database["public"]["Enums"]["or_block_statusz_enum"]
          surgossegi_keret?: boolean
          tenant_id: string
          updated_at?: string
          veg_ido: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          datum?: string
          felszabaditasi_hatarido?: string | null
          id?: string
          ismetlodo_szabaly?: string | null
          kezdo_ido?: string
          megjegyzes?: string | null
          org_unit_id?: string
          sebesz_user_id?: string | null
          specialty_id?: string | null
          statusz?: Database["public"]["Enums"]["or_block_statusz_enum"]
          surgossegi_keret?: boolean
          tenant_id?: string
          updated_at?: string
          veg_ido?: string
        }
        Relationships: [
          {
            foreignKeyName: "or_blocks_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "or_blocks_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "or_blocks_org_unit_id_fkey"
            columns: ["org_unit_id"]
            isOneToOne: false
            referencedRelation: "org_unit_conflicts"
            referencedColumns: ["org_unit_id"]
          },
          {
            foreignKeyName: "or_blocks_org_unit_id_fkey"
            columns: ["org_unit_id"]
            isOneToOne: false
            referencedRelation: "org_units"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "or_blocks_sebesz_user_id_fkey"
            columns: ["sebesz_user_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "or_blocks_sebesz_user_id_fkey"
            columns: ["sebesz_user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "or_blocks_specialty_id_fkey"
            columns: ["specialty_id"]
            isOneToOne: false
            referencedRelation: "specialties"
            referencedColumns: ["id"]
          },
        ]
      }
      or_emergency_responses: {
        Row: {
          created_at: string
          eta_perc: number | null
          id: string
          megjegyzes: string | null
          notification_id: string | null
          surgery_case_id: string
          tenant_id: string
          tud_jonni: boolean
          user_id: string
        }
        Insert: {
          created_at?: string
          eta_perc?: number | null
          id?: string
          megjegyzes?: string | null
          notification_id?: string | null
          surgery_case_id: string
          tenant_id: string
          tud_jonni: boolean
          user_id: string
        }
        Update: {
          created_at?: string
          eta_perc?: number | null
          id?: string
          megjegyzes?: string | null
          notification_id?: string | null
          surgery_case_id?: string
          tenant_id?: string
          tud_jonni?: boolean
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "or_emergency_responses_notification_id_fkey"
            columns: ["notification_id"]
            isOneToOne: false
            referencedRelation: "notifications"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "or_emergency_responses_surgery_case_id_fkey"
            columns: ["surgery_case_id"]
            isOneToOne: false
            referencedRelation: "surgery_cases"
            referencedColumns: ["id"]
          },
        ]
      }
      or_resources: {
        Row: {
          aktiv: boolean
          created_at: string
          id: string
          keszlet_db: number
          megosztott: boolean
          nev: string | null
          site_id: string
          tenant_id: string
          tipus: Database["public"]["Enums"]["or_eroforras_tipus_enum"]
          updated_at: string
        }
        Insert: {
          aktiv?: boolean
          created_at?: string
          id?: string
          keszlet_db?: number
          megosztott?: boolean
          nev?: string | null
          site_id: string
          tenant_id: string
          tipus: Database["public"]["Enums"]["or_eroforras_tipus_enum"]
          updated_at?: string
        }
        Update: {
          aktiv?: boolean
          created_at?: string
          id?: string
          keszlet_db?: number
          megosztott?: boolean
          nev?: string | null
          site_id?: string
          tenant_id?: string
          tipus?: Database["public"]["Enums"]["or_eroforras_tipus_enum"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "or_resources_site_id_fkey"
            columns: ["site_id"]
            isOneToOne: false
            referencedRelation: "sites"
            referencedColumns: ["id"]
          },
        ]
      }
      or_room_profiles: {
        Row: {
          aktiv: boolean
          created_at: string
          fordulo_ido_perc: number
          id: string
          napi_kezdo_ido: string
          napi_veg_ido: string
          or_suite_id: string
          org_unit_id: string
          tartalek: boolean
          tenant_id: string
          tipus: Database["public"]["Enums"]["or_tipus_enum"]
          updated_at: string
        }
        Insert: {
          aktiv?: boolean
          created_at?: string
          fordulo_ido_perc?: number
          id?: string
          napi_kezdo_ido?: string
          napi_veg_ido?: string
          or_suite_id: string
          org_unit_id: string
          tartalek?: boolean
          tenant_id: string
          tipus?: Database["public"]["Enums"]["or_tipus_enum"]
          updated_at?: string
        }
        Update: {
          aktiv?: boolean
          created_at?: string
          fordulo_ido_perc?: number
          id?: string
          napi_kezdo_ido?: string
          napi_veg_ido?: string
          or_suite_id?: string
          org_unit_id?: string
          tartalek?: boolean
          tenant_id?: string
          tipus?: Database["public"]["Enums"]["or_tipus_enum"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "or_room_profiles_or_suite_id_fkey"
            columns: ["or_suite_id"]
            isOneToOne: false
            referencedRelation: "or_suites"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "or_room_profiles_org_unit_id_fkey"
            columns: ["org_unit_id"]
            isOneToOne: true
            referencedRelation: "org_unit_conflicts"
            referencedColumns: ["org_unit_id"]
          },
          {
            foreignKeyName: "or_room_profiles_org_unit_id_fkey"
            columns: ["org_unit_id"]
            isOneToOne: true
            referencedRelation: "org_units"
            referencedColumns: ["id"]
          },
        ]
      }
      or_staff_pool: {
        Row: {
          created_at: string
          created_by: string | null
          department_org_unit_id: string | null
          eligible_szerep: string
          ervenyes_ig: string | null
          ervenyes_tol: string
          havi_max_perc: number | null
          heti_keret_perc: number
          id: string
          megjegyzes: string | null
          or_suite_id: string
          tenant_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          department_org_unit_id?: string | null
          eligible_szerep: string
          ervenyes_ig?: string | null
          ervenyes_tol?: string
          havi_max_perc?: number | null
          heti_keret_perc?: number
          id?: string
          megjegyzes?: string | null
          or_suite_id: string
          tenant_id: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          department_org_unit_id?: string | null
          eligible_szerep?: string
          ervenyes_ig?: string | null
          ervenyes_tol?: string
          havi_max_perc?: number | null
          heti_keret_perc?: number
          id?: string
          megjegyzes?: string | null
          or_suite_id?: string
          tenant_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "or_staff_pool_or_suite_id_fkey"
            columns: ["or_suite_id"]
            isOneToOne: false
            referencedRelation: "or_suites"
            referencedColumns: ["id"]
          },
        ]
      }
      or_suites: {
        Row: {
          aktiv: boolean
          created_at: string
          id: string
          nev: string
          site_id: string
          surgossegi_keret_perc: number
          tartalek_muto_szam: number
          tenant_id: string
          updated_at: string
        }
        Insert: {
          aktiv?: boolean
          created_at?: string
          id?: string
          nev: string
          site_id: string
          surgossegi_keret_perc?: number
          tartalek_muto_szam?: number
          tenant_id: string
          updated_at?: string
        }
        Update: {
          aktiv?: boolean
          created_at?: string
          id?: string
          nev?: string
          site_id?: string
          surgossegi_keret_perc?: number
          tartalek_muto_szam?: number
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "or_suites_site_id_fkey"
            columns: ["site_id"]
            isOneToOne: false
            referencedRelation: "sites"
            referencedColumns: ["id"]
          },
        ]
      }
      org_unit_departments: {
        Row: {
          clinic_id: string
          created_at: string
          org_unit_id: string
          szerep: string
          tenant_id: string
        }
        Insert: {
          clinic_id: string
          created_at?: string
          org_unit_id: string
          szerep: string
          tenant_id: string
        }
        Update: {
          clinic_id?: string
          created_at?: string
          org_unit_id?: string
          szerep?: string
          tenant_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "org_unit_departments_clinic_id_fkey"
            columns: ["clinic_id"]
            isOneToOne: false
            referencedRelation: "clinics"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "org_unit_departments_org_unit_id_fkey"
            columns: ["org_unit_id"]
            isOneToOne: false
            referencedRelation: "org_unit_conflicts"
            referencedColumns: ["org_unit_id"]
          },
          {
            foreignKeyName: "org_unit_departments_org_unit_id_fkey"
            columns: ["org_unit_id"]
            isOneToOne: false
            referencedRelation: "org_units"
            referencedColumns: ["id"]
          },
        ]
      }
      org_unit_specialties: {
        Row: {
          org_unit_id: string
          specialty_id: string
          tenant_id: string
        }
        Insert: {
          org_unit_id: string
          specialty_id: string
          tenant_id: string
        }
        Update: {
          org_unit_id?: string
          specialty_id?: string
          tenant_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "org_unit_specialties_org_unit_id_fkey"
            columns: ["org_unit_id"]
            isOneToOne: false
            referencedRelation: "org_unit_conflicts"
            referencedColumns: ["org_unit_id"]
          },
          {
            foreignKeyName: "org_unit_specialties_org_unit_id_fkey"
            columns: ["org_unit_id"]
            isOneToOne: false
            referencedRelation: "org_units"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "org_unit_specialties_specialty_id_fkey"
            columns: ["specialty_id"]
            isOneToOne: false
            referencedRelation: "specialties"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "org_unit_specialties_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      org_units: {
        Row: {
          agyszam: number | null
          aktiv: boolean
          created_at: string
          floor_id: string | null
          id: string
          max_letszam_napi: number | null
          min_letszam_napi: number
          mukodes_kezd: string | null
          mukodes_veg: string | null
          muto_blokk_perc: number | null
          nev: string
          parameterek: Json
          parent_id: string | null
          site_id: string
          tenant_id: string
          tipus: Database["public"]["Enums"]["org_unit_tipus"]
          unnepnap_uzemel: boolean
          updated_at: string
          uzemmod: Database["public"]["Enums"]["uzemmod_tipus"] | null
        }
        Insert: {
          agyszam?: number | null
          aktiv?: boolean
          created_at?: string
          floor_id?: string | null
          id?: string
          max_letszam_napi?: number | null
          min_letszam_napi?: number
          mukodes_kezd?: string | null
          mukodes_veg?: string | null
          muto_blokk_perc?: number | null
          nev: string
          parameterek?: Json
          parent_id?: string | null
          site_id: string
          tenant_id: string
          tipus: Database["public"]["Enums"]["org_unit_tipus"]
          unnepnap_uzemel?: boolean
          updated_at?: string
          uzemmod?: Database["public"]["Enums"]["uzemmod_tipus"] | null
        }
        Update: {
          agyszam?: number | null
          aktiv?: boolean
          created_at?: string
          floor_id?: string | null
          id?: string
          max_letszam_napi?: number | null
          min_letszam_napi?: number
          mukodes_kezd?: string | null
          mukodes_veg?: string | null
          muto_blokk_perc?: number | null
          nev?: string
          parameterek?: Json
          parent_id?: string | null
          site_id?: string
          tenant_id?: string
          tipus?: Database["public"]["Enums"]["org_unit_tipus"]
          unnepnap_uzemel?: boolean
          updated_at?: string
          uzemmod?: Database["public"]["Enums"]["uzemmod_tipus"] | null
        }
        Relationships: [
          {
            foreignKeyName: "org_units_floor_id_fkey"
            columns: ["floor_id"]
            isOneToOne: false
            referencedRelation: "floors"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "org_units_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "org_unit_conflicts"
            referencedColumns: ["org_unit_id"]
          },
          {
            foreignKeyName: "org_units_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "org_units"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "org_units_site_id_fkey"
            columns: ["site_id"]
            isOneToOne: false
            referencedRelation: "sites"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "org_units_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      osszeferhetetlenseg_engedelyek: {
        Row: {
          created_at: string
          csatolmany_url: string | null
          engedely_datum: string | null
          engedelyezo_szerv: string | null
          id: string
          kerelem_datum: string | null
          leiras: string
          lejarat: string | null
          megjegyzes: string | null
          status: string
          tenant_id: string
          tipus: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          csatolmany_url?: string | null
          engedely_datum?: string | null
          engedelyezo_szerv?: string | null
          id?: string
          kerelem_datum?: string | null
          leiras: string
          lejarat?: string | null
          megjegyzes?: string | null
          status?: string
          tenant_id: string
          tipus: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          csatolmany_url?: string | null
          engedely_datum?: string | null
          engedelyezo_szerv?: string | null
          id?: string
          kerelem_datum?: string | null
          leiras?: string
          lejarat?: string | null
          megjegyzes?: string | null
          status?: string
          tenant_id?: string
          tipus?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      overtime_orders: {
        Row: {
          created_at: string
          elrendeles_at: string
          elrendelo_id: string
          id: string
          indok: string
          irasos_hivatkozas: string | null
          kategoria: string
          kezdo_idopont: string
          ora: number
          org_unit_id: string | null
          status: Database["public"]["Enums"]["overtime_order_status"]
          tenant_id: string
          updated_at: string
          user_id: string
          zaro_idopont: string
        }
        Insert: {
          created_at?: string
          elrendeles_at?: string
          elrendelo_id: string
          id?: string
          indok: string
          irasos_hivatkozas?: string | null
          kategoria?: string
          kezdo_idopont: string
          ora: number
          org_unit_id?: string | null
          status?: Database["public"]["Enums"]["overtime_order_status"]
          tenant_id: string
          updated_at?: string
          user_id: string
          zaro_idopont: string
        }
        Update: {
          created_at?: string
          elrendeles_at?: string
          elrendelo_id?: string
          id?: string
          indok?: string
          irasos_hivatkozas?: string | null
          kategoria?: string
          kezdo_idopont?: string
          ora?: number
          org_unit_id?: string | null
          status?: Database["public"]["Enums"]["overtime_order_status"]
          tenant_id?: string
          updated_at?: string
          user_id?: string
          zaro_idopont?: string
        }
        Relationships: [
          {
            foreignKeyName: "overtime_orders_elrendelo_id_fkey"
            columns: ["elrendelo_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "overtime_orders_elrendelo_id_fkey"
            columns: ["elrendelo_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "overtime_orders_org_unit_id_fkey"
            columns: ["org_unit_id"]
            isOneToOne: false
            referencedRelation: "org_unit_conflicts"
            referencedColumns: ["org_unit_id"]
          },
          {
            foreignKeyName: "overtime_orders_org_unit_id_fkey"
            columns: ["org_unit_id"]
            isOneToOne: false
            referencedRelation: "org_units"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "overtime_orders_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "overtime_orders_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "overtime_orders_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      overtime_preferences: {
        Row: {
          created_at: string
          csak_sajat_osztaly: boolean
          ervenyes_ig: string | null
          ervenyes_tol: string
          id: string
          max_ora_havi: number | null
          megjegyzes: string | null
          muszakok: string[]
          napok: number[]
          status: Database["public"]["Enums"]["overtime_pref_status"]
          tenant_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          csak_sajat_osztaly?: boolean
          ervenyes_ig?: string | null
          ervenyes_tol?: string
          id?: string
          max_ora_havi?: number | null
          megjegyzes?: string | null
          muszakok?: string[]
          napok?: number[]
          status?: Database["public"]["Enums"]["overtime_pref_status"]
          tenant_id: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          csak_sajat_osztaly?: boolean
          ervenyes_ig?: string | null
          ervenyes_tol?: string
          id?: string
          max_ora_havi?: number | null
          megjegyzes?: string | null
          muszakok?: string[]
          napok?: number[]
          status?: Database["public"]["Enums"]["overtime_pref_status"]
          tenant_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "overtime_preferences_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "overtime_preferences_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "overtime_preferences_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      paciens_360_saved_views: {
        Row: {
          created_at: string
          filters: Json
          id: string
          is_default: boolean
          name: string
          patient_id: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          filters?: Json
          id?: string
          is_default?: boolean
          name: string
          patient_id?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          filters?: Json
          id?: string
          is_default?: boolean
          name?: string
          patient_id?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "paciens_360_saved_views_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      patient_ai_explanations: {
        Row: {
          created_at: string
          critical_flags: Json
          expires_at: string
          explanation: Json
          id: string
          language: string
          model: string
          patient_id: string
          prompt_hash: string
          source_id: string
          source_table: string
          suggested_specialty_id: string | null
        }
        Insert: {
          created_at?: string
          critical_flags?: Json
          expires_at?: string
          explanation: Json
          id?: string
          language?: string
          model: string
          patient_id: string
          prompt_hash: string
          source_id: string
          source_table: string
          suggested_specialty_id?: string | null
        }
        Update: {
          created_at?: string
          critical_flags?: Json
          expires_at?: string
          explanation?: Json
          id?: string
          language?: string
          model?: string
          patient_id?: string
          prompt_hash?: string
          source_id?: string
          source_table?: string
          suggested_specialty_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "patient_ai_explanations_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "patient_ai_explanations_suggested_specialty_id_fkey"
            columns: ["suggested_specialty_id"]
            isOneToOne: false
            referencedRelation: "specialties"
            referencedColumns: ["id"]
          },
        ]
      }
      patient_appointment_requests: {
        Row: {
          appointment_id: string | null
          created_at: string
          doctor_user_id: string | null
          id: string
          patient_id: string
          preferred_datetime: string | null
          preferred_slot_id: string | null
          reason: string | null
          request_type: string
          resolved_at: string | null
          resolved_by: string | null
          specialty_id: string | null
          staff_response: string | null
          status: string
          tenant_id: string | null
          updated_at: string
          urgency: string
          user_id: string
        }
        Insert: {
          appointment_id?: string | null
          created_at?: string
          doctor_user_id?: string | null
          id?: string
          patient_id: string
          preferred_datetime?: string | null
          preferred_slot_id?: string | null
          reason?: string | null
          request_type: string
          resolved_at?: string | null
          resolved_by?: string | null
          specialty_id?: string | null
          staff_response?: string | null
          status?: string
          tenant_id?: string | null
          updated_at?: string
          urgency?: string
          user_id: string
        }
        Update: {
          appointment_id?: string | null
          created_at?: string
          doctor_user_id?: string | null
          id?: string
          patient_id?: string
          preferred_datetime?: string | null
          preferred_slot_id?: string | null
          reason?: string | null
          request_type?: string
          resolved_at?: string | null
          resolved_by?: string | null
          specialty_id?: string | null
          staff_response?: string | null
          status?: string
          tenant_id?: string | null
          updated_at?: string
          urgency?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "patient_appointment_requests_appointment_id_fkey"
            columns: ["appointment_id"]
            isOneToOne: false
            referencedRelation: "appointments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "patient_appointment_requests_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "patient_appointment_requests_preferred_slot_id_fkey"
            columns: ["preferred_slot_id"]
            isOneToOne: false
            referencedRelation: "appointment_slots"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "patient_appointment_requests_specialty_id_fkey"
            columns: ["specialty_id"]
            isOneToOne: false
            referencedRelation: "specialties"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "patient_appointment_requests_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      patient_checkin: {
        Row: {
          appointment_id: string
          called_ts: string | null
          checkin_ts: string
          created_at: string
          done_ts: string | null
          id: string
          method: Database["public"]["Enums"]["checkin_method"]
          patient_id: string | null
          queue_position: number | null
          status: Database["public"]["Enums"]["checkin_status"]
          tenant_id: string
          updated_at: string
        }
        Insert: {
          appointment_id: string
          called_ts?: string | null
          checkin_ts?: string
          created_at?: string
          done_ts?: string | null
          id?: string
          method: Database["public"]["Enums"]["checkin_method"]
          patient_id?: string | null
          queue_position?: number | null
          status?: Database["public"]["Enums"]["checkin_status"]
          tenant_id: string
          updated_at?: string
        }
        Update: {
          appointment_id?: string
          called_ts?: string | null
          checkin_ts?: string
          created_at?: string
          done_ts?: string | null
          id?: string
          method?: Database["public"]["Enums"]["checkin_method"]
          patient_id?: string | null
          queue_position?: number | null
          status?: Database["public"]["Enums"]["checkin_status"]
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "patient_checkin_appointment_id_fkey"
            columns: ["appointment_id"]
            isOneToOne: false
            referencedRelation: "appointments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "patient_checkin_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "patient_checkin_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      patient_documents: {
        Row: {
          category: string
          created_at: string
          description: string | null
          id: string
          mime_type: string | null
          patient_id: string
          shared_with_patient: boolean
          size_bytes: number | null
          storage_path: string
          tenant_id: string | null
          title: string
          updated_at: string
          uploaded_by: string
          uploader_kind: string
        }
        Insert: {
          category?: string
          created_at?: string
          description?: string | null
          id?: string
          mime_type?: string | null
          patient_id: string
          shared_with_patient?: boolean
          size_bytes?: number | null
          storage_path: string
          tenant_id?: string | null
          title: string
          updated_at?: string
          uploaded_by: string
          uploader_kind?: string
        }
        Update: {
          category?: string
          created_at?: string
          description?: string | null
          id?: string
          mime_type?: string | null
          patient_id?: string
          shared_with_patient?: boolean
          size_bytes?: number | null
          storage_path?: string
          tenant_id?: string | null
          title?: string
          updated_at?: string
          uploaded_by?: string
          uploader_kind?: string
        }
        Relationships: [
          {
            foreignKeyName: "patient_documents_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "patient_documents_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      patient_emergency_card: {
        Row: {
          allergiak: string[] | null
          egyeb_info: string | null
          etrend: string | null
          gyogyszer_erzekenyseg: string[] | null
          gyogyszerek: string[] | null
          kapcsolt_orvos_telefon: string | null
          kronikus_betegsegek: string[] | null
          patient_id: string
          qr_token: string | null
          sos_kontakt_nev: string | null
          sos_kontakt_telefon: string | null
          updated_at: string
          vercsoport: string | null
        }
        Insert: {
          allergiak?: string[] | null
          egyeb_info?: string | null
          etrend?: string | null
          gyogyszer_erzekenyseg?: string[] | null
          gyogyszerek?: string[] | null
          kapcsolt_orvos_telefon?: string | null
          kronikus_betegsegek?: string[] | null
          patient_id: string
          qr_token?: string | null
          sos_kontakt_nev?: string | null
          sos_kontakt_telefon?: string | null
          updated_at?: string
          vercsoport?: string | null
        }
        Update: {
          allergiak?: string[] | null
          egyeb_info?: string | null
          etrend?: string | null
          gyogyszer_erzekenyseg?: string[] | null
          gyogyszerek?: string[] | null
          kapcsolt_orvos_telefon?: string | null
          kronikus_betegsegek?: string[] | null
          patient_id?: string
          qr_token?: string | null
          sos_kontakt_nev?: string | null
          sos_kontakt_telefon?: string | null
          updated_at?: string
          vercsoport?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "patient_emergency_card_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: true
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      patient_encounters: {
        Row: {
          beavatkozas_ids: string[]
          bno_kodok: string[]
          created_at: string
          ellatas_kezdete: string
          ellatas_vege: string | null
          ellenjegyzo_alairas_at: string | null
          ellenjegyzo_id: string | null
          id: string
          intezmenyi_azonosito: string | null
          oeno_kodok: string[]
          org_unit_id: string | null
          osszefoglalo: string | null
          patient_id: string
          site_id: string | null
          status: string
          szerzo_alairas_at: string | null
          szerzo_id: string | null
          tenant_id: string
          tipus: Database["public"]["Enums"]["encounter_tipus"]
          updated_at: string
          vezeto_orvos_id: string | null
        }
        Insert: {
          beavatkozas_ids?: string[]
          bno_kodok?: string[]
          created_at?: string
          ellatas_kezdete: string
          ellatas_vege?: string | null
          ellenjegyzo_alairas_at?: string | null
          ellenjegyzo_id?: string | null
          id?: string
          intezmenyi_azonosito?: string | null
          oeno_kodok?: string[]
          org_unit_id?: string | null
          osszefoglalo?: string | null
          patient_id: string
          site_id?: string | null
          status?: string
          szerzo_alairas_at?: string | null
          szerzo_id?: string | null
          tenant_id: string
          tipus: Database["public"]["Enums"]["encounter_tipus"]
          updated_at?: string
          vezeto_orvos_id?: string | null
        }
        Update: {
          beavatkozas_ids?: string[]
          bno_kodok?: string[]
          created_at?: string
          ellatas_kezdete?: string
          ellatas_vege?: string | null
          ellenjegyzo_alairas_at?: string | null
          ellenjegyzo_id?: string | null
          id?: string
          intezmenyi_azonosito?: string | null
          oeno_kodok?: string[]
          org_unit_id?: string | null
          osszefoglalo?: string | null
          patient_id?: string
          site_id?: string | null
          status?: string
          szerzo_alairas_at?: string | null
          szerzo_id?: string | null
          tenant_id?: string
          tipus?: Database["public"]["Enums"]["encounter_tipus"]
          updated_at?: string
          vezeto_orvos_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "patient_encounters_org_unit_id_fkey"
            columns: ["org_unit_id"]
            isOneToOne: false
            referencedRelation: "org_unit_conflicts"
            referencedColumns: ["org_unit_id"]
          },
          {
            foreignKeyName: "patient_encounters_org_unit_id_fkey"
            columns: ["org_unit_id"]
            isOneToOne: false
            referencedRelation: "org_units"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "patient_encounters_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "patient_encounters_site_id_fkey"
            columns: ["site_id"]
            isOneToOne: false
            referencedRelation: "sites"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "patient_encounters_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "patient_encounters_vezeto_orvos_id_fkey"
            columns: ["vezeto_orvos_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "patient_encounters_vezeto_orvos_id_fkey"
            columns: ["vezeto_orvos_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      patient_health_plans: {
        Row: {
          cel: string | null
          cim: string
          created_at: string
          id: string
          kezdo_datum: string | null
          lepesek: Json
          letrehozta: string | null
          paciens_jegyzet: string | null
          patient_id: string
          status: string
          tenant_id: string | null
          updated_at: string
          zaro_datum: string | null
        }
        Insert: {
          cel?: string | null
          cim: string
          created_at?: string
          id?: string
          kezdo_datum?: string | null
          lepesek?: Json
          letrehozta?: string | null
          paciens_jegyzet?: string | null
          patient_id: string
          status?: string
          tenant_id?: string | null
          updated_at?: string
          zaro_datum?: string | null
        }
        Update: {
          cel?: string | null
          cim?: string
          created_at?: string
          id?: string
          kezdo_datum?: string | null
          lepesek?: Json
          letrehozta?: string | null
          paciens_jegyzet?: string | null
          patient_id?: string
          status?: string
          tenant_id?: string | null
          updated_at?: string
          zaro_datum?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "patient_health_plans_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "patient_health_plans_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      patient_lifestyle_log: {
        Row: {
          category: string
          created_at: string
          id: string
          logged_at: string
          notes: string | null
          patient_id: string
          user_id: string
          value_json: Json
        }
        Insert: {
          category: string
          created_at?: string
          id?: string
          logged_at?: string
          notes?: string | null
          patient_id: string
          user_id: string
          value_json?: Json
        }
        Update: {
          category?: string
          created_at?: string
          id?: string
          logged_at?: string
          notes?: string | null
          patient_id?: string
          user_id?: string
          value_json?: Json
        }
        Relationships: [
          {
            foreignKeyName: "patient_lifestyle_log_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      patient_medication_requests: {
        Row: {
          created_at: string
          gyogyszer_nev: string
          hatas_eros: string | null
          id: string
          ismetlodo: boolean
          megjegyzes: string | null
          mennyiseg: string | null
          patient_id: string
          reply: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          status: string
          surgosseg: string
          tenant_id: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          gyogyszer_nev: string
          hatas_eros?: string | null
          id?: string
          ismetlodo?: boolean
          megjegyzes?: string | null
          mennyiseg?: string | null
          patient_id: string
          reply?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          surgosseg?: string
          tenant_id?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          gyogyszer_nev?: string
          hatas_eros?: string | null
          id?: string
          ismetlodo?: boolean
          megjegyzes?: string | null
          mennyiseg?: string | null
          patient_id?: string
          reply?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          surgosseg?: string
          tenant_id?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "patient_medication_requests_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "patient_medication_requests_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      patient_referral_requests: {
        Row: {
          created_at: string
          decided_at: string | null
          decided_by: string | null
          decision_note: string | null
          eeszt_ref: string | null
          id: string
          notes: string | null
          patient_id: string
          pdf_url: string | null
          reason: string
          request_type: string
          requested_by: string | null
          specialty: string | null
          status: string
          tenant_id: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          decided_at?: string | null
          decided_by?: string | null
          decision_note?: string | null
          eeszt_ref?: string | null
          id?: string
          notes?: string | null
          patient_id: string
          pdf_url?: string | null
          reason: string
          request_type: string
          requested_by?: string | null
          specialty?: string | null
          status?: string
          tenant_id?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          decided_at?: string | null
          decided_by?: string | null
          decision_note?: string | null
          eeszt_ref?: string | null
          id?: string
          notes?: string | null
          patient_id?: string
          pdf_url?: string | null
          reason?: string
          request_type?: string
          requested_by?: string | null
          specialty?: string | null
          status?: string
          tenant_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "patient_referral_requests_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      patient_users: {
        Row: {
          created_at: string
          id: string
          kapcsolat: string
          patient_id: string
          tenant_id: string | null
          updated_at: string
          user_id: string
          verified_at: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          kapcsolat?: string
          patient_id: string
          tenant_id?: string | null
          updated_at?: string
          user_id: string
          verified_at?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          kapcsolat?: string
          patient_id?: string
          tenant_id?: string | null
          updated_at?: string
          user_id?: string
          verified_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "patient_users_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "patient_users_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      patients: {
        Row: {
          anyja_neve: string | null
          cim: string | null
          created_at: string
          email: string | null
          fo_diagnozis_bno: string | null
          gondozo_orvos_id: string | null
          id: string
          iranyitoszam: string | null
          keresztnev: string
          megjegyzes: string | null
          nem: string | null
          szuletesi_datum: string | null
          taj: string | null
          telefon: string | null
          tenant_id: string
          updated_at: string
          varos: string | null
          vezeteknev: string
        }
        Insert: {
          anyja_neve?: string | null
          cim?: string | null
          created_at?: string
          email?: string | null
          fo_diagnozis_bno?: string | null
          gondozo_orvos_id?: string | null
          id?: string
          iranyitoszam?: string | null
          keresztnev: string
          megjegyzes?: string | null
          nem?: string | null
          szuletesi_datum?: string | null
          taj?: string | null
          telefon?: string | null
          tenant_id: string
          updated_at?: string
          varos?: string | null
          vezeteknev: string
        }
        Update: {
          anyja_neve?: string | null
          cim?: string | null
          created_at?: string
          email?: string | null
          fo_diagnozis_bno?: string | null
          gondozo_orvos_id?: string | null
          id?: string
          iranyitoszam?: string | null
          keresztnev?: string
          megjegyzes?: string | null
          nem?: string | null
          szuletesi_datum?: string | null
          taj?: string | null
          telefon?: string | null
          tenant_id?: string
          updated_at?: string
          varos?: string | null
          vezeteknev?: string
        }
        Relationships: [
          {
            foreignKeyName: "patients_gondozo_orvos_id_fkey"
            columns: ["gondozo_orvos_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "patients_gondozo_orvos_id_fkey"
            columns: ["gondozo_orvos_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "patients_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      person_accreditations: {
        Row: {
          created_at: string
          domain_id: string
          ervenyes_ig: string | null
          ervenyes_tol: string
          id: string
          igazolas_hivatkozas: string | null
          jovahagyo_id: string | null
          level_id: string
          megjegyzes: string | null
          tenant_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          domain_id: string
          ervenyes_ig?: string | null
          ervenyes_tol?: string
          id?: string
          igazolas_hivatkozas?: string | null
          jovahagyo_id?: string | null
          level_id: string
          megjegyzes?: string | null
          tenant_id: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          domain_id?: string
          ervenyes_ig?: string | null
          ervenyes_tol?: string
          id?: string
          igazolas_hivatkozas?: string | null
          jovahagyo_id?: string | null
          level_id?: string
          megjegyzes?: string | null
          tenant_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "person_accreditations_domain_id_fkey"
            columns: ["domain_id"]
            isOneToOne: false
            referencedRelation: "competency_domains"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "person_accreditations_jovahagyo_id_fkey"
            columns: ["jovahagyo_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "person_accreditations_jovahagyo_id_fkey"
            columns: ["jovahagyo_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "person_accreditations_level_id_fkey"
            columns: ["level_id"]
            isOneToOne: false
            referencedRelation: "competency_levels"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "person_accreditations_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "person_accreditations_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "person_accreditations_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      probaidok: {
        Row: {
          created_at: string
          id: string
          kezdo_datum: string
          megjegyzes: string | null
          mentesseg_jogcim: string | null
          profile_employment_id: string
          tartam_honap: number
          tenant_id: string
          updated_at: string
          user_id: string
          zaro_datum: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          kezdo_datum: string
          megjegyzes?: string | null
          mentesseg_jogcim?: string | null
          profile_employment_id: string
          tartam_honap?: number
          tenant_id: string
          updated_at?: string
          user_id: string
          zaro_datum?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          kezdo_datum?: string
          megjegyzes?: string | null
          mentesseg_jogcim?: string | null
          profile_employment_id?: string
          tartam_honap?: number
          tenant_id?: string
          updated_at?: string
          user_id?: string
          zaro_datum?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "probaidok_profile_employment_id_fkey"
            columns: ["profile_employment_id"]
            isOneToOne: false
            referencedRelation: "profile_employment"
            referencedColumns: ["id"]
          },
        ]
      }
      profile_beavatkozasok: {
        Row: {
          alkalom: number
          beavatkozas_id: string
          bizonyitek_url: string | null
          created_at: string
          datum: string | null
          id: string
          megjegyzes: string | null
          mentor_igazolt: boolean
          mentor_user_id: string | null
          tenant_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          alkalom?: number
          beavatkozas_id: string
          bizonyitek_url?: string | null
          created_at?: string
          datum?: string | null
          id?: string
          megjegyzes?: string | null
          mentor_igazolt?: boolean
          mentor_user_id?: string | null
          tenant_id: string
          updated_at?: string
          user_id: string
        }
        Update: {
          alkalom?: number
          beavatkozas_id?: string
          bizonyitek_url?: string | null
          created_at?: string
          datum?: string | null
          id?: string
          megjegyzes?: string | null
          mentor_igazolt?: boolean
          mentor_user_id?: string | null
          tenant_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "profile_beavatkozasok_beavatkozas_id_fkey"
            columns: ["beavatkozas_id"]
            isOneToOne: false
            referencedRelation: "beavatkozasok"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profile_beavatkozasok_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profile_beavatkozasok_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "profile_beavatkozasok_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profile_certifications: {
        Row: {
          created_at: string
          dokumentum_url: string | null
          id: string
          kibocsato: string | null
          kibocsatva: string | null
          lejarat: string | null
          nev: string
          szam: string | null
          tenant_id: string
          tipus: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          dokumentum_url?: string | null
          id?: string
          kibocsato?: string | null
          kibocsatva?: string | null
          lejarat?: string | null
          nev: string
          szam?: string | null
          tenant_id: string
          tipus: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          dokumentum_url?: string | null
          id?: string
          kibocsato?: string | null
          kibocsatva?: string | null
          lejarat?: string | null
          nev?: string
          szam?: string | null
          tenant_id?: string
          tipus?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "profile_certifications_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profile_certifications_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "profile_certifications_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profile_constraints: {
        Row: {
          created_at: string
          ervenyes_ig: string | null
          ervenyes_tol: string
          hr_megjegyzes: string | null
          id: string
          igazolas_url: string | null
          megjegyzes: string | null
          tenant_id: string
          tipus: Database["public"]["Enums"]["constraint_tipus"]
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          ervenyes_ig?: string | null
          ervenyes_tol?: string
          hr_megjegyzes?: string | null
          id?: string
          igazolas_url?: string | null
          megjegyzes?: string | null
          tenant_id: string
          tipus: Database["public"]["Enums"]["constraint_tipus"]
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          ervenyes_ig?: string | null
          ervenyes_tol?: string
          hr_megjegyzes?: string | null
          id?: string
          igazolas_url?: string | null
          megjegyzes?: string | null
          tenant_id?: string
          tipus?: Database["public"]["Enums"]["constraint_tipus"]
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "profile_constraints_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profile_constraints_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "profile_constraints_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profile_contacts: {
        Row: {
          cimke: string | null
          created_at: string
          csak_vesz_eseten: boolean
          ertek: string
          ertesites_engedelyezve: boolean
          id: string
          is_primary: boolean
          megjegyzes: string | null
          sorrend: number
          tenant_id: string | null
          tipus: Database["public"]["Enums"]["contact_tipus"]
          updated_at: string
          user_id: string
        }
        Insert: {
          cimke?: string | null
          created_at?: string
          csak_vesz_eseten?: boolean
          ertek: string
          ertesites_engedelyezve?: boolean
          id?: string
          is_primary?: boolean
          megjegyzes?: string | null
          sorrend?: number
          tenant_id?: string | null
          tipus: Database["public"]["Enums"]["contact_tipus"]
          updated_at?: string
          user_id: string
        }
        Update: {
          cimke?: string | null
          created_at?: string
          csak_vesz_eseten?: boolean
          ertek?: string
          ertesites_engedelyezve?: boolean
          id?: string
          is_primary?: boolean
          megjegyzes?: string | null
          sorrend?: number
          tenant_id?: string | null
          tipus?: Database["public"]["Enums"]["contact_tipus"]
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "profile_contacts_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profile_contacts_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "profile_contacts_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profile_daily_preferences: {
        Row: {
          created_at: string
          ervenyes_ig: string | null
          ervenyes_tol: string
          id: string
          jovahagyas_at: string | null
          jovahagyas_indok: string | null
          jovahagyo_id: string | null
          kerult_kezd: string | null
          kerult_veg: string | null
          keszenlet_vallal: boolean | null
          max_muszak_hossz_ora: number | null
          megjegyzes: string | null
          nap_iso: number
          preferalt_kezd: string | null
          preferalt_veg: string | null
          status: string
          submitted_at: string | null
          tenant_id: string
          ugyelet_vallal: boolean | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          ervenyes_ig?: string | null
          ervenyes_tol?: string
          id?: string
          jovahagyas_at?: string | null
          jovahagyas_indok?: string | null
          jovahagyo_id?: string | null
          kerult_kezd?: string | null
          kerult_veg?: string | null
          keszenlet_vallal?: boolean | null
          max_muszak_hossz_ora?: number | null
          megjegyzes?: string | null
          nap_iso: number
          preferalt_kezd?: string | null
          preferalt_veg?: string | null
          status?: string
          submitted_at?: string | null
          tenant_id: string
          ugyelet_vallal?: boolean | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          ervenyes_ig?: string | null
          ervenyes_tol?: string
          id?: string
          jovahagyas_at?: string | null
          jovahagyas_indok?: string | null
          jovahagyo_id?: string | null
          kerult_kezd?: string | null
          kerult_veg?: string | null
          keszenlet_vallal?: boolean | null
          max_muszak_hossz_ora?: number | null
          megjegyzes?: string | null
          nap_iso?: number
          preferalt_kezd?: string | null
          preferalt_veg?: string | null
          status?: string
          submitted_at?: string | null
          tenant_id?: string
          ugyelet_vallal?: boolean | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "profile_daily_preferences_jovahagyo_id_fkey"
            columns: ["jovahagyo_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "profile_daily_preferences_jovahagyo_id_fkey"
            columns: ["jovahagyo_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profile_daily_preferences_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profile_daily_preferences_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "profile_daily_preferences_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profile_daily_preferences_events: {
        Row: {
          action: string
          actor_id: string | null
          after_data: Json | null
          before_data: Json | null
          created_at: string
          from_status: string | null
          id: string
          indok: string | null
          nap_iso: number | null
          pref_id: string | null
          tenant_id: string
          to_status: string | null
          user_id: string
        }
        Insert: {
          action: string
          actor_id?: string | null
          after_data?: Json | null
          before_data?: Json | null
          created_at?: string
          from_status?: string | null
          id?: string
          indok?: string | null
          nap_iso?: number | null
          pref_id?: string | null
          tenant_id: string
          to_status?: string | null
          user_id: string
        }
        Update: {
          action?: string
          actor_id?: string | null
          after_data?: Json | null
          before_data?: Json | null
          created_at?: string
          from_status?: string | null
          id?: string
          indok?: string | null
          nap_iso?: number | null
          pref_id?: string | null
          tenant_id?: string
          to_status?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "profile_daily_preferences_events_actor_id_fkey"
            columns: ["actor_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "profile_daily_preferences_events_actor_id_fkey"
            columns: ["actor_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profile_daily_preferences_events_pref_id_fkey"
            columns: ["pref_id"]
            isOneToOne: false
            referencedRelation: "profile_daily_preferences"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profile_daily_preferences_events_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profile_daily_preferences_events_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "profile_daily_preferences_events_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profile_employment: {
        Row: {
          created_at: string
          elsodleges: boolean
          ervenyes: boolean
          fenntarto_tipus: Database["public"]["Enums"]["fenntarto_tipus"]
          fte_szazalek: number
          id: string
          jogviszony_tipus: Database["public"]["Enums"]["jogviszony_tipus"]
          keret_ora: number | null
          kezdo_datum: string | null
          munkaido_keret: Database["public"]["Enums"]["munkaido_keret_tipus"]
          munkakor_kod: string | null
          munkakor_megnevezes: string | null
          munkaltato_nev: string
          oktatoi_munkakor_arany: number | null
          opt_out_kezdete: string | null
          opt_out_ovt: boolean
          opt_out_visszavonas: string | null
          org_unit_id: string | null
          osszeferhetetlenseg_megjegyzes: string | null
          ovt_max_evi_ora: number | null
          site_id: string | null
          tenant_id: string
          tobbes_jogviszony: boolean
          updated_at: string
          user_id: string
          vezetoi_szint: string | null
          zaro_datum: string | null
        }
        Insert: {
          created_at?: string
          elsodleges?: boolean
          ervenyes?: boolean
          fenntarto_tipus?: Database["public"]["Enums"]["fenntarto_tipus"]
          fte_szazalek?: number
          id?: string
          jogviszony_tipus?: Database["public"]["Enums"]["jogviszony_tipus"]
          keret_ora?: number | null
          kezdo_datum?: string | null
          munkaido_keret?: Database["public"]["Enums"]["munkaido_keret_tipus"]
          munkakor_kod?: string | null
          munkakor_megnevezes?: string | null
          munkaltato_nev: string
          oktatoi_munkakor_arany?: number | null
          opt_out_kezdete?: string | null
          opt_out_ovt?: boolean
          opt_out_visszavonas?: string | null
          org_unit_id?: string | null
          osszeferhetetlenseg_megjegyzes?: string | null
          ovt_max_evi_ora?: number | null
          site_id?: string | null
          tenant_id: string
          tobbes_jogviszony?: boolean
          updated_at?: string
          user_id: string
          vezetoi_szint?: string | null
          zaro_datum?: string | null
        }
        Update: {
          created_at?: string
          elsodleges?: boolean
          ervenyes?: boolean
          fenntarto_tipus?: Database["public"]["Enums"]["fenntarto_tipus"]
          fte_szazalek?: number
          id?: string
          jogviszony_tipus?: Database["public"]["Enums"]["jogviszony_tipus"]
          keret_ora?: number | null
          kezdo_datum?: string | null
          munkaido_keret?: Database["public"]["Enums"]["munkaido_keret_tipus"]
          munkakor_kod?: string | null
          munkakor_megnevezes?: string | null
          munkaltato_nev?: string
          oktatoi_munkakor_arany?: number | null
          opt_out_kezdete?: string | null
          opt_out_ovt?: boolean
          opt_out_visszavonas?: string | null
          org_unit_id?: string | null
          osszeferhetetlenseg_megjegyzes?: string | null
          ovt_max_evi_ora?: number | null
          site_id?: string | null
          tenant_id?: string
          tobbes_jogviszony?: boolean
          updated_at?: string
          user_id?: string
          vezetoi_szint?: string | null
          zaro_datum?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "profile_employment_org_unit_id_fkey"
            columns: ["org_unit_id"]
            isOneToOne: false
            referencedRelation: "org_unit_conflicts"
            referencedColumns: ["org_unit_id"]
          },
          {
            foreignKeyName: "profile_employment_org_unit_id_fkey"
            columns: ["org_unit_id"]
            isOneToOne: false
            referencedRelation: "org_units"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profile_employment_site_id_fkey"
            columns: ["site_id"]
            isOneToOne: false
            referencedRelation: "sites"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profile_employment_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profile_employment_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "profile_employment_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profile_employment_optout_log: {
        Row: {
          action: string
          created_at: string
          decided_by: string | null
          effective_date: string
          employment_id: string
          id: string
          indok: string | null
          ovt_max_evi_ora: number | null
          tenant_id: string
          user_id: string
        }
        Insert: {
          action: string
          created_at?: string
          decided_by?: string | null
          effective_date?: string
          employment_id: string
          id?: string
          indok?: string | null
          ovt_max_evi_ora?: number | null
          tenant_id: string
          user_id: string
        }
        Update: {
          action?: string
          created_at?: string
          decided_by?: string | null
          effective_date?: string
          employment_id?: string
          id?: string
          indok?: string | null
          ovt_max_evi_ora?: number | null
          tenant_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "profile_employment_optout_log_decided_by_fkey"
            columns: ["decided_by"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "profile_employment_optout_log_decided_by_fkey"
            columns: ["decided_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profile_employment_optout_log_employment_id_fkey"
            columns: ["employment_id"]
            isOneToOne: false
            referencedRelation: "profile_employment"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profile_employment_optout_log_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profile_employment_optout_log_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "profile_employment_optout_log_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profile_external_hours: {
        Row: {
          created_at: string
          ev: number
          hely: string | null
          honap: number
          id: string
          jogviszony_tipus: string | null
          megjegyzes: string | null
          ora: number
          tenant_id: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          ev: number
          hely?: string | null
          honap: number
          id?: string
          jogviszony_tipus?: string | null
          megjegyzes?: string | null
          ora: number
          tenant_id?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          ev?: number
          hely?: string | null
          honap?: number
          id?: string
          jogviszony_tipus?: string | null
          megjegyzes?: string | null
          ora?: number
          tenant_id?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      profile_paired_shifts: {
        Row: {
          created_at: string
          ervenyes_ig: string | null
          ervenyes_tol: string
          id: string
          indoklas: string | null
          muszak_kulcs: string | null
          napok: number[]
          partner_id: string
          suly: number
          tenant_id: string
          tipus: Database["public"]["Enums"]["paired_shift_tipus"]
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          ervenyes_ig?: string | null
          ervenyes_tol?: string
          id?: string
          indoklas?: string | null
          muszak_kulcs?: string | null
          napok?: number[]
          partner_id: string
          suly?: number
          tenant_id: string
          tipus: Database["public"]["Enums"]["paired_shift_tipus"]
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          ervenyes_ig?: string | null
          ervenyes_tol?: string
          id?: string
          indoklas?: string | null
          muszak_kulcs?: string | null
          napok?: number[]
          partner_id?: string
          suly?: number
          tenant_id?: string
          tipus?: Database["public"]["Enums"]["paired_shift_tipus"]
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "profile_paired_shifts_partner_id_fkey"
            columns: ["partner_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "profile_paired_shifts_partner_id_fkey"
            columns: ["partner_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profile_paired_shifts_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profile_paired_shifts_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "profile_paired_shifts_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profile_peer_links: {
        Row: {
          created_at: string
          from_user_id: string
          id: string
          indoklas: string | null
          jovahagyas_at: string | null
          jovahagyas_indok: string | null
          jovahagyo_id: string | null
          status: Database["public"]["Enums"]["peer_link_status"]
          suly: number | null
          tenant_id: string | null
          tipus: Database["public"]["Enums"]["peer_link_tipus"]
          to_user_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          from_user_id: string
          id?: string
          indoklas?: string | null
          jovahagyas_at?: string | null
          jovahagyas_indok?: string | null
          jovahagyo_id?: string | null
          status?: Database["public"]["Enums"]["peer_link_status"]
          suly?: number | null
          tenant_id?: string | null
          tipus: Database["public"]["Enums"]["peer_link_tipus"]
          to_user_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          from_user_id?: string
          id?: string
          indoklas?: string | null
          jovahagyas_at?: string | null
          jovahagyas_indok?: string | null
          jovahagyo_id?: string | null
          status?: Database["public"]["Enums"]["peer_link_status"]
          suly?: number | null
          tenant_id?: string | null
          tipus?: Database["public"]["Enums"]["peer_link_tipus"]
          to_user_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "profile_peer_links_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      profile_preferences: {
        Row: {
          created_at: string
          egymas_utani_max_ugyelet: number
          havi_max_ugyelet: number | null
          heti_max_ora: number | null
          jovahagyas_at: string | null
          jovahagyas_feltetel: string | null
          jovahagyas_indok: string | null
          jovahagyo_id: string | null
          kozossegi_napok: string[]
          last_minute_elerheto: boolean
          last_minute_orahatar: number | null
          megjegyzes: string | null
          nyelvek: string[]
          preferalt_feladat_korok: string[]
          preferalt_musakok: Database["public"]["Enums"]["musak_pref"][]
          status: Database["public"]["Enums"]["unavailability_status"]
          submitted_at: string | null
          tenant_id: string | null
          tiltott_napok: number[]
          ugyelet_utan_min_ora: number
          ugyelet_utan_pihenonap: boolean
          updated_at: string
          user_id: string
          utazasi_perc_max: number | null
        }
        Insert: {
          created_at?: string
          egymas_utani_max_ugyelet?: number
          havi_max_ugyelet?: number | null
          heti_max_ora?: number | null
          jovahagyas_at?: string | null
          jovahagyas_feltetel?: string | null
          jovahagyas_indok?: string | null
          jovahagyo_id?: string | null
          kozossegi_napok?: string[]
          last_minute_elerheto?: boolean
          last_minute_orahatar?: number | null
          megjegyzes?: string | null
          nyelvek?: string[]
          preferalt_feladat_korok?: string[]
          preferalt_musakok?: Database["public"]["Enums"]["musak_pref"][]
          status?: Database["public"]["Enums"]["unavailability_status"]
          submitted_at?: string | null
          tenant_id?: string | null
          tiltott_napok?: number[]
          ugyelet_utan_min_ora?: number
          ugyelet_utan_pihenonap?: boolean
          updated_at?: string
          user_id: string
          utazasi_perc_max?: number | null
        }
        Update: {
          created_at?: string
          egymas_utani_max_ugyelet?: number
          havi_max_ugyelet?: number | null
          heti_max_ora?: number | null
          jovahagyas_at?: string | null
          jovahagyas_feltetel?: string | null
          jovahagyas_indok?: string | null
          jovahagyo_id?: string | null
          kozossegi_napok?: string[]
          last_minute_elerheto?: boolean
          last_minute_orahatar?: number | null
          megjegyzes?: string | null
          nyelvek?: string[]
          preferalt_feladat_korok?: string[]
          preferalt_musakok?: Database["public"]["Enums"]["musak_pref"][]
          status?: Database["public"]["Enums"]["unavailability_status"]
          submitted_at?: string | null
          tenant_id?: string | null
          tiltott_napok?: number[]
          ugyelet_utan_min_ora?: number
          ugyelet_utan_pihenonap?: boolean
          updated_at?: string
          user_id?: string
          utazasi_perc_max?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "profile_preferences_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profile_preferences_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "profile_preferences_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profile_program_milestones: {
        Row: {
          created_at: string
          elerve_at: string | null
          id: string
          megjegyzes: string | null
          milestone: string
          program_id: string
          status: string
          tenant_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          elerve_at?: string | null
          id?: string
          megjegyzes?: string | null
          milestone: string
          program_id: string
          status?: string
          tenant_id: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          elerve_at?: string | null
          id?: string
          megjegyzes?: string | null
          milestone?: string
          program_id?: string
          status?: string
          tenant_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "profile_program_milestones_program_id_fkey"
            columns: ["program_id"]
            isOneToOne: false
            referencedRelation: "training_programs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profile_program_milestones_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profile_program_milestones_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "profile_program_milestones_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profile_service_history: {
        Row: {
          beszamithato_eusztv: boolean
          beszamithato_jubileum: boolean
          created_at: string
          csatolmany_url: string | null
          fenntarto_tipus: string
          forras: string
          id: string
          kezdo_datum: string
          megjegyzes: string | null
          munkakor: string | null
          munkaltato_nev: string
          rogzitette_user_id: string | null
          tenant_id: string
          updated_at: string
          user_id: string
          zaro_datum: string | null
        }
        Insert: {
          beszamithato_eusztv?: boolean
          beszamithato_jubileum?: boolean
          created_at?: string
          csatolmany_url?: string | null
          fenntarto_tipus: string
          forras?: string
          id?: string
          kezdo_datum: string
          megjegyzes?: string | null
          munkakor?: string | null
          munkaltato_nev: string
          rogzitette_user_id?: string | null
          tenant_id: string
          updated_at?: string
          user_id: string
          zaro_datum?: string | null
        }
        Update: {
          beszamithato_eusztv?: boolean
          beszamithato_jubileum?: boolean
          created_at?: string
          csatolmany_url?: string | null
          fenntarto_tipus?: string
          forras?: string
          id?: string
          kezdo_datum?: string
          megjegyzes?: string | null
          munkakor?: string | null
          munkaltato_nev?: string
          rogzitette_user_id?: string | null
          tenant_id?: string
          updated_at?: string
          user_id?: string
          zaro_datum?: string | null
        }
        Relationships: []
      }
      profile_service_time_overrides: {
        Row: {
          created_at: string
          ervenyes_ig: string | null
          ervenyes_tol: string
          id: string
          indok: string
          jovahagyo_user_id: string | null
          napok_korrekcio: number
          tenant_id: string
          tipus: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          ervenyes_ig?: string | null
          ervenyes_tol?: string
          id?: string
          indok: string
          jovahagyo_user_id?: string | null
          napok_korrekcio: number
          tenant_id: string
          tipus: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          ervenyes_ig?: string | null
          ervenyes_tol?: string
          id?: string
          indok?: string
          jovahagyo_user_id?: string | null
          napok_korrekcio?: number
          tenant_id?: string
          tipus?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      profile_skills: {
        Row: {
          created_at: string
          id: string
          igazolva_at: string | null
          lejarat: string | null
          megjegyzes: string | null
          skill_id: string
          szint: number
          tenant_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          igazolva_at?: string | null
          lejarat?: string | null
          megjegyzes?: string | null
          skill_id: string
          szint?: number
          tenant_id: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          igazolva_at?: string | null
          lejarat?: string | null
          megjegyzes?: string | null
          skill_id?: string
          szint?: number
          tenant_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "profile_skills_skill_id_fkey"
            columns: ["skill_id"]
            isOneToOne: false
            referencedRelation: "skills"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profile_skills_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profile_skills_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "profile_skills_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profile_trainings: {
        Row: {
          created_at: string
          elorehaladas_pct: number
          id: string
          kezdes: string | null
          megjegyzes: string | null
          nev: string
          program_id: string | null
          statusz: string
          tenant_id: string
          updated_at: string
          user_id: string
          varhato_veg: string | null
        }
        Insert: {
          created_at?: string
          elorehaladas_pct?: number
          id?: string
          kezdes?: string | null
          megjegyzes?: string | null
          nev: string
          program_id?: string | null
          statusz?: string
          tenant_id: string
          updated_at?: string
          user_id: string
          varhato_veg?: string | null
        }
        Update: {
          created_at?: string
          elorehaladas_pct?: number
          id?: string
          kezdes?: string | null
          megjegyzes?: string | null
          nev?: string
          program_id?: string | null
          statusz?: string
          tenant_id?: string
          updated_at?: string
          user_id?: string
          varhato_veg?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "profile_trainings_program_id_fkey"
            columns: ["program_id"]
            isOneToOne: false
            referencedRelation: "training_programs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profile_trainings_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profile_trainings_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "profile_trainings_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profile_unavailability: {
        Row: {
          akut: boolean
          created_at: string
          csak_delelott: boolean
          csak_delutan: boolean
          forrasev: number | null
          id: string
          is_kenyszer: boolean
          jogcim: string
          jovahagyas_at: string | null
          jovahagyas_indok: string | null
          jovahagyo_id: string | null
          kezdo_datum: string
          leiras: string | null
          nap_szam: number | null
          status: Database["public"]["Enums"]["unavailability_status"]
          tenant_id: string | null
          tipus: Database["public"]["Enums"]["unavailability_tipus"]
          training_program_id: string | null
          updated_at: string
          user_id: string
          zaro_datum: string
        }
        Insert: {
          akut?: boolean
          created_at?: string
          csak_delelott?: boolean
          csak_delutan?: boolean
          forrasev?: number | null
          id?: string
          is_kenyszer?: boolean
          jogcim?: string
          jovahagyas_at?: string | null
          jovahagyas_indok?: string | null
          jovahagyo_id?: string | null
          kezdo_datum: string
          leiras?: string | null
          nap_szam?: number | null
          status?: Database["public"]["Enums"]["unavailability_status"]
          tenant_id?: string | null
          tipus: Database["public"]["Enums"]["unavailability_tipus"]
          training_program_id?: string | null
          updated_at?: string
          user_id: string
          zaro_datum: string
        }
        Update: {
          akut?: boolean
          created_at?: string
          csak_delelott?: boolean
          csak_delutan?: boolean
          forrasev?: number | null
          id?: string
          is_kenyszer?: boolean
          jogcim?: string
          jovahagyas_at?: string | null
          jovahagyas_indok?: string | null
          jovahagyo_id?: string | null
          kezdo_datum?: string
          leiras?: string | null
          nap_szam?: number | null
          status?: Database["public"]["Enums"]["unavailability_status"]
          tenant_id?: string | null
          tipus?: Database["public"]["Enums"]["unavailability_tipus"]
          training_program_id?: string | null
          updated_at?: string
          user_id?: string
          zaro_datum?: string
        }
        Relationships: [
          {
            foreignKeyName: "profile_unavailability_jovahagyo_id_fkey"
            columns: ["jovahagyo_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "profile_unavailability_jovahagyo_id_fkey"
            columns: ["jovahagyo_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profile_unavailability_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profile_unavailability_training_program_id_fkey"
            columns: ["training_program_id"]
            isOneToOne: false
            referencedRelation: "training_programs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profile_unavailability_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "profile_unavailability_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profile_work_time_frame: {
        Row: {
          created_at: string
          ervenyes_ig: string | null
          ervenyes_tol: string
          havi_orakeret: number | null
          id: string
          indok: string | null
          rogzitette_user_id: string | null
          szazalek: number | null
          tenant_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          ervenyes_ig?: string | null
          ervenyes_tol: string
          havi_orakeret?: number | null
          id?: string
          indok?: string | null
          rogzitette_user_id?: string | null
          szazalek?: number | null
          tenant_id: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          ervenyes_ig?: string | null
          ervenyes_tol?: string
          havi_orakeret?: number | null
          id?: string
          indok?: string | null
          rogzitette_user_id?: string | null
          szazalek?: number | null
          tenant_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "profile_work_time_frame_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          aktiv: boolean
          avatar_url: string | null
          becenev: string | null
          belepes_datum: string | null
          bemutatkozas: string | null
          bemutatkozas_publikus: boolean
          created_at: string
          email: string
          foglalkozas_tipus: Database["public"]["Enums"]["foglalkozas_tipus"]
          gyermek_szamok: Json
          id: string
          kjt_fizetesi_osztaly: string | null
          klinikai_kombinalt: boolean
          locale: string | null
          napi_mutet_cap: number | null
          nem: Database["public"]["Enums"]["nem_tipus"] | null
          oktatoi_munkakor: boolean
          reminder_email_enabled: boolean
          reminder_push_enabled: boolean
          sugarterheles_kategoria: string | null
          szuletesi_datum: string | null
          teljes_nev: string
          tenant_id: string | null
          updated_at: string
          vezetoi_szint: string | null
        }
        Insert: {
          aktiv?: boolean
          avatar_url?: string | null
          becenev?: string | null
          belepes_datum?: string | null
          bemutatkozas?: string | null
          bemutatkozas_publikus?: boolean
          created_at?: string
          email: string
          foglalkozas_tipus?: Database["public"]["Enums"]["foglalkozas_tipus"]
          gyermek_szamok?: Json
          id: string
          kjt_fizetesi_osztaly?: string | null
          klinikai_kombinalt?: boolean
          locale?: string | null
          napi_mutet_cap?: number | null
          nem?: Database["public"]["Enums"]["nem_tipus"] | null
          oktatoi_munkakor?: boolean
          reminder_email_enabled?: boolean
          reminder_push_enabled?: boolean
          sugarterheles_kategoria?: string | null
          szuletesi_datum?: string | null
          teljes_nev: string
          tenant_id?: string | null
          updated_at?: string
          vezetoi_szint?: string | null
        }
        Update: {
          aktiv?: boolean
          avatar_url?: string | null
          becenev?: string | null
          belepes_datum?: string | null
          bemutatkozas?: string | null
          bemutatkozas_publikus?: boolean
          created_at?: string
          email?: string
          foglalkozas_tipus?: Database["public"]["Enums"]["foglalkozas_tipus"]
          gyermek_szamok?: Json
          id?: string
          kjt_fizetesi_osztaly?: string | null
          klinikai_kombinalt?: boolean
          locale?: string | null
          napi_mutet_cap?: number | null
          nem?: Database["public"]["Enums"]["nem_tipus"] | null
          oktatoi_munkakor?: boolean
          reminder_email_enabled?: boolean
          reminder_push_enabled?: boolean
          sugarterheles_kategoria?: string | null
          szuletesi_datum?: string | null
          teljes_nev?: string
          tenant_id?: string | null
          updated_at?: string
          vezetoi_szint?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "profiles_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      public_holidays: {
        Row: {
          created_at: string
          datum: string
          fizetett: boolean
          forrasszoveg: string | null
          id: string
          nev: string
          tenant_id: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          datum: string
          fizetett?: boolean
          forrasszoveg?: string | null
          id?: string
          nev: string
          tenant_id?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          datum?: string
          fizetett?: boolean
          forrasszoveg?: string | null
          id?: string
          nev?: string
          tenant_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "public_holidays_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      push_settings: {
        Row: {
          enabled: boolean
          tenant_id: string
          updated_at: string
          updated_by: string | null
          vapid_subject: string
        }
        Insert: {
          enabled?: boolean
          tenant_id: string
          updated_at?: string
          updated_by?: string | null
          vapid_subject?: string
        }
        Update: {
          enabled?: boolean
          tenant_id?: string
          updated_at?: string
          updated_by?: string | null
          vapid_subject?: string
        }
        Relationships: [
          {
            foreignKeyName: "push_settings_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: true
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      push_subscriptions: {
        Row: {
          auth: string
          created_at: string
          endpoint: string
          id: string
          last_used_at: string | null
          p256dh: string
          user_agent: string | null
          user_id: string
        }
        Insert: {
          auth: string
          created_at?: string
          endpoint: string
          id?: string
          last_used_at?: string | null
          p256dh: string
          user_agent?: string | null
          user_id: string
        }
        Update: {
          auth?: string
          created_at?: string
          endpoint?: string
          id?: string
          last_used_at?: string | null
          p256dh?: string
          user_agent?: string | null
          user_id?: string
        }
        Relationships: []
      }
      questionnaire_assignments: {
        Row: {
          appointment_id: string | null
          assigned_at: string
          assigned_by: string | null
          created_at: string
          draft_answers: Json | null
          draft_saved_at: string | null
          due_at: string | null
          id: string
          kind: Database["public"]["Enums"]["assignment_kind"]
          kiosk_pin_hash: string | null
          last_activity_at: string | null
          patient_id: string | null
          print_cancelled_at: string | null
          print_cancelled_by: string | null
          print_status: Database["public"]["Enums"]["kiosk_print_status"]
          printed_at: string | null
          printed_by: string | null
          questionnaire_id: string
          reminded_at: string | null
          reminder_count: number
          status: Database["public"]["Enums"]["q_assignment_status"]
          tenant_id: string
          token: string
          updated_at: string
        }
        Insert: {
          appointment_id?: string | null
          assigned_at?: string
          assigned_by?: string | null
          created_at?: string
          draft_answers?: Json | null
          draft_saved_at?: string | null
          due_at?: string | null
          id?: string
          kind?: Database["public"]["Enums"]["assignment_kind"]
          kiosk_pin_hash?: string | null
          last_activity_at?: string | null
          patient_id?: string | null
          print_cancelled_at?: string | null
          print_cancelled_by?: string | null
          print_status?: Database["public"]["Enums"]["kiosk_print_status"]
          printed_at?: string | null
          printed_by?: string | null
          questionnaire_id: string
          reminded_at?: string | null
          reminder_count?: number
          status?: Database["public"]["Enums"]["q_assignment_status"]
          tenant_id: string
          token: string
          updated_at?: string
        }
        Update: {
          appointment_id?: string | null
          assigned_at?: string
          assigned_by?: string | null
          created_at?: string
          draft_answers?: Json | null
          draft_saved_at?: string | null
          due_at?: string | null
          id?: string
          kind?: Database["public"]["Enums"]["assignment_kind"]
          kiosk_pin_hash?: string | null
          last_activity_at?: string | null
          patient_id?: string | null
          print_cancelled_at?: string | null
          print_cancelled_by?: string | null
          print_status?: Database["public"]["Enums"]["kiosk_print_status"]
          printed_at?: string | null
          printed_by?: string | null
          questionnaire_id?: string
          reminded_at?: string | null
          reminder_count?: number
          status?: Database["public"]["Enums"]["q_assignment_status"]
          tenant_id?: string
          token?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "questionnaire_assignments_appointment_id_fkey"
            columns: ["appointment_id"]
            isOneToOne: false
            referencedRelation: "appointments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "questionnaire_assignments_assigned_by_fkey"
            columns: ["assigned_by"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "questionnaire_assignments_assigned_by_fkey"
            columns: ["assigned_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "questionnaire_assignments_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "questionnaire_assignments_questionnaire_id_fkey"
            columns: ["questionnaire_id"]
            isOneToOne: false
            referencedRelation: "questionnaires"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "questionnaire_assignments_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      questionnaire_event_triggers: {
        Row: {
          active: boolean
          channel: Database["public"]["Enums"]["reminder_channel"]
          created_at: string
          created_by: string | null
          due_offset_days: number
          event_type: Database["public"]["Enums"]["qet_event_type"]
          id: string
          questionnaire_id: string
          reminder_buckets: number[]
          tenant_id: string
          updated_at: string
        }
        Insert: {
          active?: boolean
          channel?: Database["public"]["Enums"]["reminder_channel"]
          created_at?: string
          created_by?: string | null
          due_offset_days?: number
          event_type: Database["public"]["Enums"]["qet_event_type"]
          id?: string
          questionnaire_id: string
          reminder_buckets?: number[]
          tenant_id: string
          updated_at?: string
        }
        Update: {
          active?: boolean
          channel?: Database["public"]["Enums"]["reminder_channel"]
          created_at?: string
          created_by?: string | null
          due_offset_days?: number
          event_type?: Database["public"]["Enums"]["qet_event_type"]
          id?: string
          questionnaire_id?: string
          reminder_buckets?: number[]
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "questionnaire_event_triggers_questionnaire_id_fkey"
            columns: ["questionnaire_id"]
            isOneToOne: false
            referencedRelation: "questionnaires"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "questionnaire_event_triggers_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      questionnaire_responses: {
        Row: {
          answers: Json
          appointment_id: string | null
          assignment_id: string | null
          completed_at: string
          consent_to_record: boolean
          created_at: string
          critical_triggered: boolean
          id: string
          is_anonymous: boolean
          patient_id: string | null
          questionnaire_id: string
          severity: string | null
          subscale_scores: Json
          tenant_id: string
          total_score: number | null
        }
        Insert: {
          answers: Json
          appointment_id?: string | null
          assignment_id?: string | null
          completed_at?: string
          consent_to_record?: boolean
          created_at?: string
          critical_triggered?: boolean
          id?: string
          is_anonymous?: boolean
          patient_id?: string | null
          questionnaire_id: string
          severity?: string | null
          subscale_scores?: Json
          tenant_id: string
          total_score?: number | null
        }
        Update: {
          answers?: Json
          appointment_id?: string | null
          assignment_id?: string | null
          completed_at?: string
          consent_to_record?: boolean
          created_at?: string
          critical_triggered?: boolean
          id?: string
          is_anonymous?: boolean
          patient_id?: string | null
          questionnaire_id?: string
          severity?: string | null
          subscale_scores?: Json
          tenant_id?: string
          total_score?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "questionnaire_responses_appointment_id_fkey"
            columns: ["appointment_id"]
            isOneToOne: false
            referencedRelation: "appointments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "questionnaire_responses_assignment_id_fkey"
            columns: ["assignment_id"]
            isOneToOne: false
            referencedRelation: "questionnaire_assignments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "questionnaire_responses_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "questionnaire_responses_questionnaire_id_fkey"
            columns: ["questionnaire_id"]
            isOneToOne: false
            referencedRelation: "questionnaires"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "questionnaire_responses_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      questionnaire_schedules: {
        Row: {
          aktiv: boolean
          beallito_id: string | null
          created_at: string
          id: string
          interval_days: number
          last_run_at: string | null
          megjegyzes: string | null
          monitoring_program_id: string | null
          next_due_at: string | null
          patient_id: string | null
          questionnaire_id: string
          scope: string
          tenant_id: string
          updated_at: string
        }
        Insert: {
          aktiv?: boolean
          beallito_id?: string | null
          created_at?: string
          id?: string
          interval_days: number
          last_run_at?: string | null
          megjegyzes?: string | null
          monitoring_program_id?: string | null
          next_due_at?: string | null
          patient_id?: string | null
          questionnaire_id: string
          scope?: string
          tenant_id: string
          updated_at?: string
        }
        Update: {
          aktiv?: boolean
          beallito_id?: string | null
          created_at?: string
          id?: string
          interval_days?: number
          last_run_at?: string | null
          megjegyzes?: string | null
          monitoring_program_id?: string | null
          next_due_at?: string | null
          patient_id?: string | null
          questionnaire_id?: string
          scope?: string
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "questionnaire_schedules_monitoring_program_id_fkey"
            columns: ["monitoring_program_id"]
            isOneToOne: false
            referencedRelation: "monitoring_programs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "questionnaire_schedules_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "questionnaire_schedules_questionnaire_id_fkey"
            columns: ["questionnaire_id"]
            isOneToOne: false
            referencedRelation: "questionnaires"
            referencedColumns: ["id"]
          },
        ]
      }
      questionnaires: {
        Row: {
          aktiv: boolean
          becsult_perc: number | null
          code: string
          created_at: string
          critical_item_index: number | null
          critical_threshold: number | null
          cutoffs: Json
          id: string
          items: Json
          kioszk_eligible: boolean
          language: string
          leiras: string | null
          licenc: Database["public"]["Enums"]["q_licenc"]
          mode: Database["public"]["Enums"]["q_mode"]
          recall_rules: Json
          scoring: Json
          tenant_id: string | null
          title: string
          updated_at: string
        }
        Insert: {
          aktiv?: boolean
          becsult_perc?: number | null
          code: string
          created_at?: string
          critical_item_index?: number | null
          critical_threshold?: number | null
          cutoffs?: Json
          id?: string
          items: Json
          kioszk_eligible?: boolean
          language?: string
          leiras?: string | null
          licenc: Database["public"]["Enums"]["q_licenc"]
          mode: Database["public"]["Enums"]["q_mode"]
          recall_rules?: Json
          scoring?: Json
          tenant_id?: string | null
          title: string
          updated_at?: string
        }
        Update: {
          aktiv?: boolean
          becsult_perc?: number | null
          code?: string
          created_at?: string
          critical_item_index?: number | null
          critical_threshold?: number | null
          cutoffs?: Json
          id?: string
          items?: Json
          kioszk_eligible?: boolean
          language?: string
          leiras?: string | null
          licenc?: Database["public"]["Enums"]["q_licenc"]
          mode?: Database["public"]["Enums"]["q_mode"]
          recall_rules?: Json
          scoring?: Json
          tenant_id?: string | null
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "questionnaires_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      resource_bookings: {
        Row: {
          created_at: string
          datum: string
          id: string
          kezdo_ido: string
          megjegyzes: string | null
          mennyiseg: number
          or_resource_id: string
          surgery_case_id: string | null
          tenant_id: string
          updated_at: string
          veg_ido: string
        }
        Insert: {
          created_at?: string
          datum: string
          id?: string
          kezdo_ido: string
          megjegyzes?: string | null
          mennyiseg?: number
          or_resource_id: string
          surgery_case_id?: string | null
          tenant_id: string
          updated_at?: string
          veg_ido: string
        }
        Update: {
          created_at?: string
          datum?: string
          id?: string
          kezdo_ido?: string
          megjegyzes?: string | null
          mennyiseg?: number
          or_resource_id?: string
          surgery_case_id?: string | null
          tenant_id?: string
          updated_at?: string
          veg_ido?: string
        }
        Relationships: [
          {
            foreignKeyName: "resource_bookings_or_resource_id_fkey"
            columns: ["or_resource_id"]
            isOneToOne: false
            referencedRelation: "or_resources"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "resource_bookings_surgery_case_id_fkey"
            columns: ["surgery_case_id"]
            isOneToOne: false
            referencedRelation: "surgery_cases"
            referencedColumns: ["id"]
          },
        ]
      }
      role_permissions: {
        Row: {
          created_at: string
          id: string
          perm: string
          role_kulcs: string
        }
        Insert: {
          created_at?: string
          id?: string
          perm: string
          role_kulcs: string
        }
        Update: {
          created_at?: string
          id?: string
          perm?: string
          role_kulcs?: string
        }
        Relationships: []
      }
      roles: {
        Row: {
          id: string
          kategoria: Database["public"]["Enums"]["role_kategoria"]
          kulcs: string
          megnevezes: string
          sorrend: number
        }
        Insert: {
          id?: string
          kategoria: Database["public"]["Enums"]["role_kategoria"]
          kulcs: string
          megnevezes: string
          sorrend?: number
        }
        Update: {
          id?: string
          kategoria?: Database["public"]["Enums"]["role_kategoria"]
          kulcs?: string
          megnevezes?: string
          sorrend?: number
        }
        Relationships: []
      }
      satisfaction_surveys: {
        Row: {
          answers: Json
          appointment_id: string | null
          created_at: string
          id: string
          instrument_code: string
          is_anonymous: boolean
          nps_score: number | null
          resource_id: string | null
          submitted_at: string
          tenant_id: string
        }
        Insert: {
          answers: Json
          appointment_id?: string | null
          created_at?: string
          id?: string
          instrument_code: string
          is_anonymous?: boolean
          nps_score?: number | null
          resource_id?: string | null
          submitted_at?: string
          tenant_id: string
        }
        Update: {
          answers?: Json
          appointment_id?: string | null
          created_at?: string
          id?: string
          instrument_code?: string
          is_anonymous?: boolean
          nps_score?: number | null
          resource_id?: string | null
          submitted_at?: string
          tenant_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "satisfaction_surveys_appointment_id_fkey"
            columns: ["appointment_id"]
            isOneToOne: false
            referencedRelation: "appointments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "satisfaction_surveys_resource_id_fkey"
            columns: ["resource_id"]
            isOneToOne: false
            referencedRelation: "appointment_resources"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "satisfaction_surveys_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      schedule_assignments: {
        Row: {
          created_at: string
          created_by: string | null
          feladatkor_id: string | null
          forras: string | null
          id: string
          kategoria: Database["public"]["Enums"]["ora_kategoria"]
          kezdo_idopont: string
          megjegyzes: string | null
          ora: number
          org_unit_id: string | null
          pin: boolean
          run_id: string | null
          site_id: string | null
          status: Database["public"]["Enums"]["assignment_status"]
          tenant_id: string
          updated_at: string
          user_id: string
          zaro_idopont: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          feladatkor_id?: string | null
          forras?: string | null
          id?: string
          kategoria?: Database["public"]["Enums"]["ora_kategoria"]
          kezdo_idopont: string
          megjegyzes?: string | null
          ora: number
          org_unit_id?: string | null
          pin?: boolean
          run_id?: string | null
          site_id?: string | null
          status?: Database["public"]["Enums"]["assignment_status"]
          tenant_id: string
          updated_at?: string
          user_id: string
          zaro_idopont: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          feladatkor_id?: string | null
          forras?: string | null
          id?: string
          kategoria?: Database["public"]["Enums"]["ora_kategoria"]
          kezdo_idopont?: string
          megjegyzes?: string | null
          ora?: number
          org_unit_id?: string | null
          pin?: boolean
          run_id?: string | null
          site_id?: string | null
          status?: Database["public"]["Enums"]["assignment_status"]
          tenant_id?: string
          updated_at?: string
          user_id?: string
          zaro_idopont?: string
        }
        Relationships: [
          {
            foreignKeyName: "schedule_assignments_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "schedule_assignments_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "schedule_assignments_feladatkor_id_fkey"
            columns: ["feladatkor_id"]
            isOneToOne: false
            referencedRelation: "feladat_korok"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "schedule_assignments_org_unit_id_fkey"
            columns: ["org_unit_id"]
            isOneToOne: false
            referencedRelation: "org_unit_conflicts"
            referencedColumns: ["org_unit_id"]
          },
          {
            foreignKeyName: "schedule_assignments_org_unit_id_fkey"
            columns: ["org_unit_id"]
            isOneToOne: false
            referencedRelation: "org_units"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "schedule_assignments_run_id_fkey"
            columns: ["run_id"]
            isOneToOne: false
            referencedRelation: "schedule_runs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "schedule_assignments_site_id_fkey"
            columns: ["site_id"]
            isOneToOne: false
            referencedRelation: "sites"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "schedule_assignments_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "schedule_assignments_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "schedule_assignments_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      schedule_change_requests: {
        Row: {
          assignment_id: string
          created_at: string
          decided_at: string | null
          decided_by: string | null
          decision_note: string | null
          id: string
          reason: string | null
          request_type: Database["public"]["Enums"]["schedule_change_request_type"]
          requester_id: string
          status: Database["public"]["Enums"]["schedule_change_request_status"]
          target_user_id: string | null
          tenant_id: string
          updated_at: string
        }
        Insert: {
          assignment_id: string
          created_at?: string
          decided_at?: string | null
          decided_by?: string | null
          decision_note?: string | null
          id?: string
          reason?: string | null
          request_type: Database["public"]["Enums"]["schedule_change_request_type"]
          requester_id: string
          status?: Database["public"]["Enums"]["schedule_change_request_status"]
          target_user_id?: string | null
          tenant_id: string
          updated_at?: string
        }
        Update: {
          assignment_id?: string
          created_at?: string
          decided_at?: string | null
          decided_by?: string | null
          decision_note?: string | null
          id?: string
          reason?: string | null
          request_type?: Database["public"]["Enums"]["schedule_change_request_type"]
          requester_id?: string
          status?: Database["public"]["Enums"]["schedule_change_request_status"]
          target_user_id?: string | null
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "schedule_change_requests_assignment_id_fkey"
            columns: ["assignment_id"]
            isOneToOne: false
            referencedRelation: "schedule_assignments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "schedule_change_requests_decided_by_fkey"
            columns: ["decided_by"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "schedule_change_requests_decided_by_fkey"
            columns: ["decided_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "schedule_change_requests_requester_id_fkey"
            columns: ["requester_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "schedule_change_requests_requester_id_fkey"
            columns: ["requester_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "schedule_change_requests_target_user_id_fkey"
            columns: ["target_user_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "schedule_change_requests_target_user_id_fkey"
            columns: ["target_user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "schedule_change_requests_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      schedule_explanations: {
        Row: {
          assignment_id: string | null
          created_at: string
          datum: string | null
          id: string
          kulcs: string
          run_id: string
          sulyozas: number | null
          szint: string
          szoveg: string
          tenant_id: string
          user_id: string | null
        }
        Insert: {
          assignment_id?: string | null
          created_at?: string
          datum?: string | null
          id?: string
          kulcs: string
          run_id: string
          sulyozas?: number | null
          szint?: string
          szoveg: string
          tenant_id: string
          user_id?: string | null
        }
        Update: {
          assignment_id?: string | null
          created_at?: string
          datum?: string | null
          id?: string
          kulcs?: string
          run_id?: string
          sulyozas?: number | null
          szint?: string
          szoveg?: string
          tenant_id?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "schedule_explanations_assignment_id_fkey"
            columns: ["assignment_id"]
            isOneToOne: false
            referencedRelation: "schedule_assignments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "schedule_explanations_run_id_fkey"
            columns: ["run_id"]
            isOneToOne: false
            referencedRelation: "schedule_runs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "schedule_explanations_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "schedule_explanations_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "schedule_explanations_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      schedule_runs: {
        Row: {
          created_at: string
          eredmeny_osszegzes: Json
          hard_sertes_szam: number
          hibauzenet: string | null
          id: string
          idoszak_kezdet: string
          idoszak_veg: string
          indito_id: string | null
          lagy_pontszam: number
          org_unit_id: string | null
          parameterek: Json
          publikalo_id: string | null
          publikalt_at: string | null
          solver: string
          status: string
          tenant_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          eredmeny_osszegzes?: Json
          hard_sertes_szam?: number
          hibauzenet?: string | null
          id?: string
          idoszak_kezdet: string
          idoszak_veg: string
          indito_id?: string | null
          lagy_pontszam?: number
          org_unit_id?: string | null
          parameterek?: Json
          publikalo_id?: string | null
          publikalt_at?: string | null
          solver?: string
          status?: string
          tenant_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          eredmeny_osszegzes?: Json
          hard_sertes_szam?: number
          hibauzenet?: string | null
          id?: string
          idoszak_kezdet?: string
          idoszak_veg?: string
          indito_id?: string | null
          lagy_pontszam?: number
          org_unit_id?: string | null
          parameterek?: Json
          publikalo_id?: string | null
          publikalt_at?: string | null
          solver?: string
          status?: string
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "schedule_runs_indito_id_fkey"
            columns: ["indito_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "schedule_runs_indito_id_fkey"
            columns: ["indito_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "schedule_runs_org_unit_id_fkey"
            columns: ["org_unit_id"]
            isOneToOne: false
            referencedRelation: "org_unit_conflicts"
            referencedColumns: ["org_unit_id"]
          },
          {
            foreignKeyName: "schedule_runs_org_unit_id_fkey"
            columns: ["org_unit_id"]
            isOneToOne: false
            referencedRelation: "org_units"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "schedule_runs_publikalo_id_fkey"
            columns: ["publikalo_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "schedule_runs_publikalo_id_fkey"
            columns: ["publikalo_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "schedule_runs_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      schedule_share_tokens: {
        Row: {
          created_at: string
          created_by: string
          expires_at: string
          id: string
          revoked_at: string | null
          scope_month: string
          tenant_id: string
          token: string
        }
        Insert: {
          created_at?: string
          created_by: string
          expires_at: string
          id?: string
          revoked_at?: string | null
          scope_month: string
          tenant_id: string
          token: string
        }
        Update: {
          created_at?: string
          created_by?: string
          expires_at?: string
          id?: string
          revoked_at?: string | null
          scope_month?: string
          tenant_id?: string
          token?: string
        }
        Relationships: []
      }
      shift_notifications_sent: {
        Row: {
          assignment_id: string
          channel: string
          error: string | null
          id: string
          kind: string
          sent_at: string
          success: boolean
          user_id: string
        }
        Insert: {
          assignment_id: string
          channel: string
          error?: string | null
          id?: string
          kind: string
          sent_at?: string
          success?: boolean
          user_id: string
        }
        Update: {
          assignment_id?: string
          channel?: string
          error?: string | null
          id?: string
          kind?: string
          sent_at?: string
          success?: boolean
          user_id?: string
        }
        Relationships: []
      }
      sites: {
        Row: {
          aktiv: boolean
          cim: string | null
          clinic_id: string
          created_at: string
          fenntarto_tipus: Database["public"]["Enums"]["fenntarto_tipus"] | null
          id: string
          nev: string
          tenant_id: string
          updated_at: string
        }
        Insert: {
          aktiv?: boolean
          cim?: string | null
          clinic_id: string
          created_at?: string
          fenntarto_tipus?:
            | Database["public"]["Enums"]["fenntarto_tipus"]
            | null
          id?: string
          nev: string
          tenant_id: string
          updated_at?: string
        }
        Update: {
          aktiv?: boolean
          cim?: string | null
          clinic_id?: string
          created_at?: string
          fenntarto_tipus?:
            | Database["public"]["Enums"]["fenntarto_tipus"]
            | null
          id?: string
          nev?: string
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "sites_clinic_id_fkey"
            columns: ["clinic_id"]
            isOneToOne: false
            referencedRelation: "clinics"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sites_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      skills: {
        Row: {
          aktiv: boolean
          created_at: string
          id: string
          kategoria: string | null
          kulcs: string
          leiras: string | null
          nev: string
          specialty_id: string | null
          tenant_id: string
          updated_at: string
        }
        Insert: {
          aktiv?: boolean
          created_at?: string
          id?: string
          kategoria?: string | null
          kulcs: string
          leiras?: string | null
          nev: string
          specialty_id?: string | null
          tenant_id: string
          updated_at?: string
        }
        Update: {
          aktiv?: boolean
          created_at?: string
          id?: string
          kategoria?: string | null
          kulcs?: string
          leiras?: string | null
          nev?: string
          specialty_id?: string | null
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "skills_specialty_id_fkey"
            columns: ["specialty_id"]
            isOneToOne: false
            referencedRelation: "specialties"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "skills_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      specialties: {
        Row: {
          aktiv: boolean
          id: string
          kod: string
          nev: string
        }
        Insert: {
          aktiv?: boolean
          id?: string
          kod: string
          nev: string
        }
        Update: {
          aktiv?: boolean
          id?: string
          kod?: string
          nev?: string
        }
        Relationships: []
      }
      staff_import_runs: {
        Row: {
          created_at: string
          error_rows: number
          file_hash: string | null
          file_name: string | null
          id: string
          imported_by: string
          inserted_rows: number
          skipped_rows: number
          summary: Json
          tenant_id: string
          total_rows: number
          updated_rows: number
        }
        Insert: {
          created_at?: string
          error_rows?: number
          file_hash?: string | null
          file_name?: string | null
          id?: string
          imported_by: string
          inserted_rows?: number
          skipped_rows?: number
          summary?: Json
          tenant_id: string
          total_rows?: number
          updated_rows?: number
        }
        Update: {
          created_at?: string
          error_rows?: number
          file_hash?: string | null
          file_name?: string | null
          id?: string
          imported_by?: string
          inserted_rows?: number
          skipped_rows?: number
          summary?: Json
          tenant_id?: string
          total_rows?: number
          updated_rows?: number
        }
        Relationships: [
          {
            foreignKeyName: "staff_import_runs_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      staff_levels: {
        Row: {
          created_at: string
          ervenyes_tol: string | null
          id: string
          szint: string
          tenant_id: string
          tipus: Database["public"]["Enums"]["staff_level_tipus"]
          user_id: string
        }
        Insert: {
          created_at?: string
          ervenyes_tol?: string | null
          id?: string
          szint: string
          tenant_id: string
          tipus: Database["public"]["Enums"]["staff_level_tipus"]
          user_id: string
        }
        Update: {
          created_at?: string
          ervenyes_tol?: string | null
          id?: string
          szint?: string
          tenant_id?: string
          tipus?: Database["public"]["Enums"]["staff_level_tipus"]
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "staff_levels_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      staff_roles: {
        Row: {
          aktiv: boolean
          created_at: string
          id: string
          kulcs: string
          leiras: string | null
          nev: string
          rendszerszintu: boolean
          sorrend: number
          tenant_id: string | null
          updated_at: string
        }
        Insert: {
          aktiv?: boolean
          created_at?: string
          id?: string
          kulcs: string
          leiras?: string | null
          nev: string
          rendszerszintu?: boolean
          sorrend?: number
          tenant_id?: string | null
          updated_at?: string
        }
        Update: {
          aktiv?: boolean
          created_at?: string
          id?: string
          kulcs?: string
          leiras?: string | null
          nev?: string
          rendszerszintu?: boolean
          sorrend?: number
          tenant_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "staff_roles_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      staffing_template_roles: {
        Row: {
          created_at: string
          id: string
          kotelezo: boolean
          max_letszam: number | null
          min_letszam: number
          skill_id: string | null
          sorrend: number
          staff_role_id: string
          template_id: string
          tenant_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          kotelezo?: boolean
          max_letszam?: number | null
          min_letszam?: number
          skill_id?: string | null
          sorrend?: number
          staff_role_id: string
          template_id: string
          tenant_id?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          kotelezo?: boolean
          max_letszam?: number | null
          min_letszam?: number
          skill_id?: string | null
          sorrend?: number
          staff_role_id?: string
          template_id?: string
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "staffing_template_roles_skill_id_fkey"
            columns: ["skill_id"]
            isOneToOne: false
            referencedRelation: "skills"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "staffing_template_roles_staff_role_id_fkey"
            columns: ["staff_role_id"]
            isOneToOne: false
            referencedRelation: "staff_roles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "staffing_template_roles_template_id_fkey"
            columns: ["template_id"]
            isOneToOne: false
            referencedRelation: "staffing_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      staffing_templates: {
        Row: {
          aktiv: boolean
          created_at: string
          ervenyes_ig: string | null
          ervenyes_tol: string
          id: string
          kategoria: string
          kezd_ido: string
          leiras: string | null
          nap_bitmap: number
          nev: string
          org_unit_id: string
          tenant_id: string
          updated_at: string
          veg_ido: string
        }
        Insert: {
          aktiv?: boolean
          created_at?: string
          ervenyes_ig?: string | null
          ervenyes_tol?: string
          id?: string
          kategoria?: string
          kezd_ido: string
          leiras?: string | null
          nap_bitmap?: number
          nev: string
          org_unit_id: string
          tenant_id?: string
          updated_at?: string
          veg_ido: string
        }
        Update: {
          aktiv?: boolean
          created_at?: string
          ervenyes_ig?: string | null
          ervenyes_tol?: string
          id?: string
          kategoria?: string
          kezd_ido?: string
          leiras?: string | null
          nap_bitmap?: number
          nev?: string
          org_unit_id?: string
          tenant_id?: string
          updated_at?: string
          veg_ido?: string
        }
        Relationships: [
          {
            foreignKeyName: "staffing_templates_org_unit_id_fkey"
            columns: ["org_unit_id"]
            isOneToOne: false
            referencedRelation: "org_unit_conflicts"
            referencedColumns: ["org_unit_id"]
          },
          {
            foreignKeyName: "staffing_templates_org_unit_id_fkey"
            columns: ["org_unit_id"]
            isOneToOne: false
            referencedRelation: "org_units"
            referencedColumns: ["id"]
          },
        ]
      }
      stool_log: {
        Row: {
          ai_bristol_javaslat: number | null
          bristol_tipus: number | null
          created_at: string
          foto_url: string | null
          id: string
          nyak: boolean
          patient_id: string
          program_id: string | null
          rome_tunetek: Json | null
          tenant_id: string
          ts: string
          veres: boolean
        }
        Insert: {
          ai_bristol_javaslat?: number | null
          bristol_tipus?: number | null
          created_at?: string
          foto_url?: string | null
          id?: string
          nyak?: boolean
          patient_id: string
          program_id?: string | null
          rome_tunetek?: Json | null
          tenant_id: string
          ts?: string
          veres?: boolean
        }
        Update: {
          ai_bristol_javaslat?: number | null
          bristol_tipus?: number | null
          created_at?: string
          foto_url?: string | null
          id?: string
          nyak?: boolean
          patient_id?: string
          program_id?: string | null
          rome_tunetek?: Json | null
          tenant_id?: string
          ts?: string
          veres?: boolean
        }
        Relationships: [
          {
            foreignKeyName: "stool_log_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "stool_log_program_id_fkey"
            columns: ["program_id"]
            isOneToOne: false
            referencedRelation: "monitoring_programs"
            referencedColumns: ["id"]
          },
        ]
      }
      surgery_case_assignments: {
        Row: {
          ai_generated: boolean
          case_id: string
          created_at: string
          created_by: string | null
          id: string
          indok: string | null
          szerep: string
          tenant_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          ai_generated?: boolean
          case_id: string
          created_at?: string
          created_by?: string | null
          id?: string
          indok?: string | null
          szerep: string
          tenant_id: string
          updated_at?: string
          user_id: string
        }
        Update: {
          ai_generated?: boolean
          case_id?: string
          created_at?: string
          created_by?: string | null
          id?: string
          indok?: string | null
          szerep?: string
          tenant_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "surgery_case_assignments_case_id_fkey"
            columns: ["case_id"]
            isOneToOne: false
            referencedRelation: "surgery_cases"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "surgery_case_assignments_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "surgery_case_assignments_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "surgery_case_assignments_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "surgery_case_assignments_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "surgery_case_assignments_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      surgery_cases: {
        Row: {
          becsult_idotartam_perc: number
          created_at: string
          created_by: string | null
          delegalt_operator_id: string | null
          id: string
          jovahagyas_at: string | null
          jovahagyta_user_id: string | null
          kiemelt: boolean
          kotelezo_eroforrasok_override: Json | null
          megjegyzes: string | null
          operator_min_seniority_override: string | null
          or_block_id: string | null
          patient_id: string
          posztop_apolasi_perc: number
          prioritas: Database["public"]["Enums"]["or_case_prioritas_enum"]
          sort_order: number | null
          statusz: Database["public"]["Enums"]["or_case_statusz_enum"]
          surgery_type_id: string | null
          szukseges_szerepek: Json | null
          tenant_id: string
          tenyleges_kezdo_ido: string | null
          tenyleges_veg_ido: string | null
          tervezett_kezdo_ido: string | null
          updated_at: string
        }
        Insert: {
          becsult_idotartam_perc: number
          created_at?: string
          created_by?: string | null
          delegalt_operator_id?: string | null
          id?: string
          jovahagyas_at?: string | null
          jovahagyta_user_id?: string | null
          kiemelt?: boolean
          kotelezo_eroforrasok_override?: Json | null
          megjegyzes?: string | null
          operator_min_seniority_override?: string | null
          or_block_id?: string | null
          patient_id: string
          posztop_apolasi_perc?: number
          prioritas?: Database["public"]["Enums"]["or_case_prioritas_enum"]
          sort_order?: number | null
          statusz?: Database["public"]["Enums"]["or_case_statusz_enum"]
          surgery_type_id?: string | null
          szukseges_szerepek?: Json | null
          tenant_id: string
          tenyleges_kezdo_ido?: string | null
          tenyleges_veg_ido?: string | null
          tervezett_kezdo_ido?: string | null
          updated_at?: string
        }
        Update: {
          becsult_idotartam_perc?: number
          created_at?: string
          created_by?: string | null
          delegalt_operator_id?: string | null
          id?: string
          jovahagyas_at?: string | null
          jovahagyta_user_id?: string | null
          kiemelt?: boolean
          kotelezo_eroforrasok_override?: Json | null
          megjegyzes?: string | null
          operator_min_seniority_override?: string | null
          or_block_id?: string | null
          patient_id?: string
          posztop_apolasi_perc?: number
          prioritas?: Database["public"]["Enums"]["or_case_prioritas_enum"]
          sort_order?: number | null
          statusz?: Database["public"]["Enums"]["or_case_statusz_enum"]
          surgery_type_id?: string | null
          szukseges_szerepek?: Json | null
          tenant_id?: string
          tenyleges_kezdo_ido?: string | null
          tenyleges_veg_ido?: string | null
          tervezett_kezdo_ido?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "surgery_cases_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "surgery_cases_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "surgery_cases_delegalt_operator_id_fkey"
            columns: ["delegalt_operator_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "surgery_cases_delegalt_operator_id_fkey"
            columns: ["delegalt_operator_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "surgery_cases_jovahagyta_user_id_fkey"
            columns: ["jovahagyta_user_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "surgery_cases_jovahagyta_user_id_fkey"
            columns: ["jovahagyta_user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "surgery_cases_or_block_id_fkey"
            columns: ["or_block_id"]
            isOneToOne: false
            referencedRelation: "or_blocks"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "surgery_cases_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "surgery_cases_surgery_type_id_fkey"
            columns: ["surgery_type_id"]
            isOneToOne: false
            referencedRelation: "surgery_types"
            referencedColumns: ["id"]
          },
        ]
      }
      surgery_types: {
        Row: {
          aktiv: boolean
          beavatkozas_id: string | null
          becsult_idotartam_perc: number
          created_at: string
          delegalas_kotelezo: boolean
          id: string
          kiemelt: boolean
          kod: string | null
          kotelezo_eroforrasok: Json
          kotelezo_muto_tipus:
            | Database["public"]["Enums"]["or_tipus_enum"]
            | null
          nev: string
          operator_min_seniority: string | null
          posztop_apolasi_perc: number
          szukseges_skillek: Json
          szukseges_szerepek: Json
          tenant_id: string
          updated_at: string
        }
        Insert: {
          aktiv?: boolean
          beavatkozas_id?: string | null
          becsult_idotartam_perc?: number
          created_at?: string
          delegalas_kotelezo?: boolean
          id?: string
          kiemelt?: boolean
          kod?: string | null
          kotelezo_eroforrasok?: Json
          kotelezo_muto_tipus?:
            | Database["public"]["Enums"]["or_tipus_enum"]
            | null
          nev: string
          operator_min_seniority?: string | null
          posztop_apolasi_perc?: number
          szukseges_skillek?: Json
          szukseges_szerepek?: Json
          tenant_id: string
          updated_at?: string
        }
        Update: {
          aktiv?: boolean
          beavatkozas_id?: string | null
          becsult_idotartam_perc?: number
          created_at?: string
          delegalas_kotelezo?: boolean
          id?: string
          kiemelt?: boolean
          kod?: string | null
          kotelezo_eroforrasok?: Json
          kotelezo_muto_tipus?:
            | Database["public"]["Enums"]["or_tipus_enum"]
            | null
          nev?: string
          operator_min_seniority?: string | null
          posztop_apolasi_perc?: number
          szukseges_skillek?: Json
          szukseges_szerepek?: Json
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "surgery_types_beavatkozas_id_fkey"
            columns: ["beavatkozas_id"]
            isOneToOne: false
            referencedRelation: "beavatkozasok"
            referencedColumns: ["id"]
          },
        ]
      }
      symptom_match_feedback: {
        Row: {
          created_at: string
          id: string
          query: string
          specialty_id: string
          urgency: string | null
          user_id: string
          verdict: string
        }
        Insert: {
          created_at?: string
          id?: string
          query: string
          specialty_id: string
          urgency?: string | null
          user_id: string
          verdict: string
        }
        Update: {
          created_at?: string
          id?: string
          query?: string
          specialty_id?: string
          urgency?: string | null
          user_id?: string
          verdict?: string
        }
        Relationships: [
          {
            foreignKeyName: "symptom_match_feedback_specialty_id_fkey"
            columns: ["specialty_id"]
            isOneToOne: false
            referencedRelation: "specialties"
            referencedColumns: ["id"]
          },
        ]
      }
      szabadsag_evente: {
        Row: {
          alapszabadsag_nap: number
          created_at: string
          egyeb_jogcim_jsonb: Json
          ev: number
          gyermek_potszabadsag_nap: number
          id: string
          kivett_nap: number
          potszabadsag_nap: number
          tenant_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          alapszabadsag_nap?: number
          created_at?: string
          egyeb_jogcim_jsonb?: Json
          ev: number
          gyermek_potszabadsag_nap?: number
          id?: string
          kivett_nap?: number
          potszabadsag_nap?: number
          tenant_id: string
          updated_at?: string
          user_id: string
        }
        Update: {
          alapszabadsag_nap?: number
          created_at?: string
          egyeb_jogcim_jsonb?: Json
          ev?: number
          gyermek_potszabadsag_nap?: number
          id?: string
          kivett_nap?: number
          potszabadsag_nap?: number
          tenant_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      szolgalati_elismeres: {
        Row: {
          created_at: string
          fokozat: number
          id: string
          kifizetes_datum: string | null
          megjegyzes: string | null
          osszeg_ft: number | null
          status: string
          tenant_id: string
          updated_at: string
          user_id: string
          varhato_datum: string
        }
        Insert: {
          created_at?: string
          fokozat: number
          id?: string
          kifizetes_datum?: string | null
          megjegyzes?: string | null
          osszeg_ft?: number | null
          status?: string
          tenant_id: string
          updated_at?: string
          user_id: string
          varhato_datum: string
        }
        Update: {
          created_at?: string
          fokozat?: number
          id?: string
          kifizetes_datum?: string | null
          megjegyzes?: string | null
          osszeg_ft?: number | null
          status?: string
          tenant_id?: string
          updated_at?: string
          user_id?: string
          varhato_datum?: string
        }
        Relationships: []
      }
      tenants: {
        Row: {
          aktiv: boolean
          created_at: string
          id: string
          nev: string
          plan: string
          regio: string
          updated_at: string
        }
        Insert: {
          aktiv?: boolean
          created_at?: string
          id?: string
          nev: string
          plan?: string
          regio?: string
          updated_at?: string
        }
        Update: {
          aktiv?: boolean
          created_at?: string
          id?: string
          nev?: string
          plan?: string
          regio?: string
          updated_at?: string
        }
        Relationships: []
      }
      training_program_elements: {
        Row: {
          aktiv: boolean
          created_at: string
          id: string
          idotartam_honap: number | null
          kategoria: string | null
          klinikan_kivul_engedett: boolean
          kod: string | null
          kotelezo: boolean
          leiras: string | null
          milestone: string | null
          nev: string
          parent_element_id: string | null
          program_id: string
          sorszam: number
          updated_at: string
        }
        Insert: {
          aktiv?: boolean
          created_at?: string
          id?: string
          idotartam_honap?: number | null
          kategoria?: string | null
          klinikan_kivul_engedett?: boolean
          kod?: string | null
          kotelezo?: boolean
          leiras?: string | null
          milestone?: string | null
          nev: string
          parent_element_id?: string | null
          program_id: string
          sorszam?: number
          updated_at?: string
        }
        Update: {
          aktiv?: boolean
          created_at?: string
          id?: string
          idotartam_honap?: number | null
          kategoria?: string | null
          klinikan_kivul_engedett?: boolean
          kod?: string | null
          kotelezo?: boolean
          leiras?: string | null
          milestone?: string | null
          nev?: string
          parent_element_id?: string | null
          program_id?: string
          sorszam?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "training_program_elements_parent_element_id_fkey"
            columns: ["parent_element_id"]
            isOneToOne: false
            referencedRelation: "training_program_elements"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "training_program_elements_program_id_fkey"
            columns: ["program_id"]
            isOneToOne: false
            referencedRelation: "training_programs"
            referencedColumns: ["id"]
          },
        ]
      }
      training_program_interventions: {
        Row: {
          beavatkozas_id: string | null
          beavatkozas_nev: string
          created_at: string
          element_id: string | null
          id: string
          klinikan_kivul_engedett: boolean
          milestone: string | null
          program_id: string
          required_esetszam: number
          sorszam: number
          szerep: string
          szint: string | null
          updated_at: string
        }
        Insert: {
          beavatkozas_id?: string | null
          beavatkozas_nev: string
          created_at?: string
          element_id?: string | null
          id?: string
          klinikan_kivul_engedett?: boolean
          milestone?: string | null
          program_id: string
          required_esetszam?: number
          sorszam?: number
          szerep?: string
          szint?: string | null
          updated_at?: string
        }
        Update: {
          beavatkozas_id?: string | null
          beavatkozas_nev?: string
          created_at?: string
          element_id?: string | null
          id?: string
          klinikan_kivul_engedett?: boolean
          milestone?: string | null
          program_id?: string
          required_esetszam?: number
          sorszam?: number
          szerep?: string
          szint?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "training_program_interventions_beavatkozas_id_fkey"
            columns: ["beavatkozas_id"]
            isOneToOne: false
            referencedRelation: "beavatkozasok"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "training_program_interventions_element_id_fkey"
            columns: ["element_id"]
            isOneToOne: false
            referencedRelation: "training_program_elements"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "training_program_interventions_program_id_fkey"
            columns: ["program_id"]
            isOneToOne: false
            referencedRelation: "training_programs"
            referencedColumns: ["id"]
          },
        ]
      }
      training_program_skills: {
        Row: {
          cel_szint: number
          created_at: string
          id: string
          program_id: string
          skill_id: string
        }
        Insert: {
          cel_szint?: number
          created_at?: string
          id?: string
          program_id: string
          skill_id: string
        }
        Update: {
          cel_szint?: number
          created_at?: string
          id?: string
          program_id?: string
          skill_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "training_program_skills_program_id_fkey"
            columns: ["program_id"]
            isOneToOne: false
            referencedRelation: "training_programs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "training_program_skills_skill_id_fkey"
            columns: ["skill_id"]
            isOneToOne: false
            referencedRelation: "skills"
            referencedColumns: ["id"]
          },
        ]
      }
      training_programs: {
        Row: {
          aktiv: boolean
          created_at: string
          honap_hossz: number | null
          id: string
          leiras: string | null
          nev: string
          tenant_id: string
          updated_at: string
        }
        Insert: {
          aktiv?: boolean
          created_at?: string
          honap_hossz?: number | null
          id?: string
          leiras?: string | null
          nev: string
          tenant_id: string
          updated_at?: string
        }
        Update: {
          aktiv?: boolean
          created_at?: string
          honap_hossz?: number | null
          id?: string
          leiras?: string | null
          nev?: string
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "training_programs_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      translation_glossary: {
        Row: {
          created_at: string
          id: string
          notes: string | null
          target_lang: string
          tenant_id: string | null
          term: string
          translation: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          notes?: string | null
          target_lang: string
          tenant_id?: string | null
          term: string
          translation: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          notes?: string | null
          target_lang?: string
          tenant_id?: string | null
          term?: string
          translation?: string
          updated_at?: string
        }
        Relationships: []
      }
      user_provider_identities: {
        Row: {
          avatar_url: string | null
          created_at: string
          email: string | null
          id: string
          provider: string
          provider_user_id: string
          raw: Json | null
          updated_at: string
          user_id: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          email?: string | null
          id?: string
          provider: string
          provider_user_id: string
          raw?: Json | null
          updated_at?: string
          user_id: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          email?: string | null
          id?: string
          provider?: string
          provider_user_id?: string
          raw?: Json | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          ervenyes_ig: string | null
          ervenyes_tol: string | null
          id: string
          org_unit_id: string | null
          role_id: string
          site_id: string | null
          tenant_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          ervenyes_ig?: string | null
          ervenyes_tol?: string | null
          id?: string
          org_unit_id?: string | null
          role_id: string
          site_id?: string | null
          tenant_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          ervenyes_ig?: string | null
          ervenyes_tol?: string | null
          id?: string
          org_unit_id?: string | null
          role_id?: string
          site_id?: string | null
          tenant_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_roles_org_unit_id_fkey"
            columns: ["org_unit_id"]
            isOneToOne: false
            referencedRelation: "org_unit_conflicts"
            referencedColumns: ["org_unit_id"]
          },
          {
            foreignKeyName: "user_roles_org_unit_id_fkey"
            columns: ["org_unit_id"]
            isOneToOne: false
            referencedRelation: "org_units"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_roles_role_id_fkey"
            columns: ["role_id"]
            isOneToOne: false
            referencedRelation: "roles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_roles_site_id_fkey"
            columns: ["site_id"]
            isOneToOne: false
            referencedRelation: "sites"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_roles_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      vegkielegites_szamitasok: {
        Row: {
          created_at: string
          felmentesi_ido_nap: number
          havi_illetmeny_ft: number
          id: string
          jovahagyo_user_id: string | null
          megjegyzes: string | null
          megszunes_jogcim: string
          osszeg_ft: number
          profile_employment_id: string | null
          szamitas_datum: string
          tenant_id: string
          updated_at: string
          user_id: string
          vegkielegites_havi_szam: number
        }
        Insert: {
          created_at?: string
          felmentesi_ido_nap?: number
          havi_illetmeny_ft?: number
          id?: string
          jovahagyo_user_id?: string | null
          megjegyzes?: string | null
          megszunes_jogcim: string
          osszeg_ft?: number
          profile_employment_id?: string | null
          szamitas_datum?: string
          tenant_id: string
          updated_at?: string
          user_id: string
          vegkielegites_havi_szam?: number
        }
        Update: {
          created_at?: string
          felmentesi_ido_nap?: number
          havi_illetmeny_ft?: number
          id?: string
          jovahagyo_user_id?: string | null
          megjegyzes?: string | null
          megszunes_jogcim?: string
          osszeg_ft?: number
          profile_employment_id?: string | null
          szamitas_datum?: string
          tenant_id?: string
          updated_at?: string
          user_id?: string
          vegkielegites_havi_szam?: number
        }
        Relationships: [
          {
            foreignKeyName: "vegkielegites_szamitasok_profile_employment_id_fkey"
            columns: ["profile_employment_id"]
            isOneToOne: false
            referencedRelation: "profile_employment"
            referencedColumns: ["id"]
          },
        ]
      }
      wage_codes: {
        Row: {
          alap_szorzo: number
          created_at: string
          ervenyes: boolean
          id: string
          kategoria: string | null
          kod: string
          leiras: string | null
          nev: string
          tenant_id: string | null
          updated_at: string
        }
        Insert: {
          alap_szorzo?: number
          created_at?: string
          ervenyes?: boolean
          id?: string
          kategoria?: string | null
          kod: string
          leiras?: string | null
          nev: string
          tenant_id?: string | null
          updated_at?: string
        }
        Update: {
          alap_szorzo?: number
          created_at?: string
          ervenyes?: boolean
          id?: string
          kategoria?: string | null
          kod?: string
          leiras?: string | null
          nev?: string
          tenant_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "wage_codes_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      wage_mapping: {
        Row: {
          created_at: string
          ervenyes_ig: string | null
          ervenyes_tol: string
          felulirat_szorzo: number | null
          id: string
          kategoria: Database["public"]["Enums"]["ora_kategoria"]
          prioritas: number
          sav: string
          tenant_id: string | null
          updated_at: string
          wage_code_id: string
        }
        Insert: {
          created_at?: string
          ervenyes_ig?: string | null
          ervenyes_tol?: string
          felulirat_szorzo?: number | null
          id?: string
          kategoria: Database["public"]["Enums"]["ora_kategoria"]
          prioritas?: number
          sav?: string
          tenant_id?: string | null
          updated_at?: string
          wage_code_id: string
        }
        Update: {
          created_at?: string
          ervenyes_ig?: string | null
          ervenyes_tol?: string
          felulirat_szorzo?: number | null
          id?: string
          kategoria?: Database["public"]["Enums"]["ora_kategoria"]
          prioritas?: number
          sav?: string
          tenant_id?: string | null
          updated_at?: string
          wage_code_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "wage_mapping_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wage_mapping_wage_code_id_fkey"
            columns: ["wage_code_id"]
            isOneToOne: false
            referencedRelation: "wage_codes"
            referencedColumns: ["id"]
          },
        ]
      }
      wage_table_egeszsegugyi: {
        Row: {
          alapilletmeny_ft: number
          besorolasi_kategoria: string
          created_at: string
          ervenyes_ig: string | null
          ervenyes_tol: string
          fizetesi_fokozat: number
          fizetesi_osztaly: string | null
          forrasszoveg: string | null
          garantalt_illetmeny_ft: number | null
          gyakorlati_ido_ig_ev: number | null
          gyakorlati_ido_tol_ev: number | null
          id: string
          jogszabaly_hivatkozas: string | null
          munkakor_megnevezes: string | null
          osszeg_ft: number | null
          potlek_alap_ft: number | null
          tabla_tipus: Database["public"]["Enums"]["eusztv_tabla_tipus"]
          tenant_id: string | null
          updated_at: string
          vezeto_szorzo: number
        }
        Insert: {
          alapilletmeny_ft: number
          besorolasi_kategoria: string
          created_at?: string
          ervenyes_ig?: string | null
          ervenyes_tol: string
          fizetesi_fokozat: number
          fizetesi_osztaly?: string | null
          forrasszoveg?: string | null
          garantalt_illetmeny_ft?: number | null
          gyakorlati_ido_ig_ev?: number | null
          gyakorlati_ido_tol_ev?: number | null
          id?: string
          jogszabaly_hivatkozas?: string | null
          munkakor_megnevezes?: string | null
          osszeg_ft?: number | null
          potlek_alap_ft?: number | null
          tabla_tipus?: Database["public"]["Enums"]["eusztv_tabla_tipus"]
          tenant_id?: string | null
          updated_at?: string
          vezeto_szorzo?: number
        }
        Update: {
          alapilletmeny_ft?: number
          besorolasi_kategoria?: string
          created_at?: string
          ervenyes_ig?: string | null
          ervenyes_tol?: string
          fizetesi_fokozat?: number
          fizetesi_osztaly?: string | null
          forrasszoveg?: string | null
          garantalt_illetmeny_ft?: number | null
          gyakorlati_ido_ig_ev?: number | null
          gyakorlati_ido_tol_ev?: number | null
          id?: string
          jogszabaly_hivatkozas?: string | null
          munkakor_megnevezes?: string | null
          osszeg_ft?: number | null
          potlek_alap_ft?: number | null
          tabla_tipus?: Database["public"]["Enums"]["eusztv_tabla_tipus"]
          tenant_id?: string | null
          updated_at?: string
          vezeto_szorzo?: number
        }
        Relationships: [
          {
            foreignKeyName: "wage_table_egeszsegugyi_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      wearable_data: {
        Row: {
          alvas_perc: number | null
          atlag_pulzus: number | null
          datum: string
          hrv_ms: number | null
          id: string
          lepes: number | null
          nyugalmi_pulzus: number | null
          patient_id: string
          provider: string
          raw: Json | null
          synced_at: string
          tenant_id: string
        }
        Insert: {
          alvas_perc?: number | null
          atlag_pulzus?: number | null
          datum: string
          hrv_ms?: number | null
          id?: string
          lepes?: number | null
          nyugalmi_pulzus?: number | null
          patient_id: string
          provider: string
          raw?: Json | null
          synced_at?: string
          tenant_id: string
        }
        Update: {
          alvas_perc?: number | null
          atlag_pulzus?: number | null
          datum?: string
          hrv_ms?: number | null
          id?: string
          lepes?: number | null
          nyugalmi_pulzus?: number | null
          patient_id?: string
          provider?: string
          raw?: Json | null
          synced_at?: string
          tenant_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "wearable_data_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      work_time_custom_rules: {
        Row: {
          aktiv: boolean
          created_at: string
          created_by: string | null
          ervenyes_ig: string | null
          ervenyes_tol: string
          fenntarto_tipus: Database["public"]["Enums"]["fenntarto_tipus"] | null
          id: string
          jogszabaly_hivatkozas: string | null
          jogviszony_tipus:
            | Database["public"]["Enums"]["jogviszony_tipus"]
            | null
          konfiguracio: Json
          nev: string
          prioritas: number
          szabaly_tipus: string
          tenant_id: string
          updated_at: string
        }
        Insert: {
          aktiv?: boolean
          created_at?: string
          created_by?: string | null
          ervenyes_ig?: string | null
          ervenyes_tol?: string
          fenntarto_tipus?:
            | Database["public"]["Enums"]["fenntarto_tipus"]
            | null
          id?: string
          jogszabaly_hivatkozas?: string | null
          jogviszony_tipus?:
            | Database["public"]["Enums"]["jogviszony_tipus"]
            | null
          konfiguracio?: Json
          nev: string
          prioritas?: number
          szabaly_tipus: string
          tenant_id: string
          updated_at?: string
        }
        Update: {
          aktiv?: boolean
          created_at?: string
          created_by?: string | null
          ervenyes_ig?: string | null
          ervenyes_tol?: string
          fenntarto_tipus?:
            | Database["public"]["Enums"]["fenntarto_tipus"]
            | null
          id?: string
          jogszabaly_hivatkozas?: string | null
          jogviszony_tipus?:
            | Database["public"]["Enums"]["jogviszony_tipus"]
            | null
          konfiguracio?: Json
          nev?: string
          prioritas?: number
          szabaly_tipus?: string
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "work_time_custom_rules_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      work_time_ledger: {
        Row: {
          assignment_id: string | null
          created_at: string
          datum: string
          dijazas_tipus: string | null
          ejszakai_ora: number
          forras: string | null
          id: string
          jovahagyas_at: string | null
          jovahagyo_id: string | null
          kategoria: Database["public"]["Enums"]["ora_kategoria"]
          kezdo_idopont: string
          koltseghely: string | null
          megjegyzes: string | null
          munkaltatoi_dontes: Json | null
          ora: number
          org_unit_id: string | null
          potlek_kod: string | null
          projekt: string | null
          tenant_id: string
          unnepnapi_ora: number
          updated_at: string
          user_id: string
          vasarnapi_ora: number
          zaro_idopont: string
        }
        Insert: {
          assignment_id?: string | null
          created_at?: string
          datum: string
          dijazas_tipus?: string | null
          ejszakai_ora?: number
          forras?: string | null
          id?: string
          jovahagyas_at?: string | null
          jovahagyo_id?: string | null
          kategoria: Database["public"]["Enums"]["ora_kategoria"]
          kezdo_idopont: string
          koltseghely?: string | null
          megjegyzes?: string | null
          munkaltatoi_dontes?: Json | null
          ora: number
          org_unit_id?: string | null
          potlek_kod?: string | null
          projekt?: string | null
          tenant_id: string
          unnepnapi_ora?: number
          updated_at?: string
          user_id: string
          vasarnapi_ora?: number
          zaro_idopont: string
        }
        Update: {
          assignment_id?: string | null
          created_at?: string
          datum?: string
          dijazas_tipus?: string | null
          ejszakai_ora?: number
          forras?: string | null
          id?: string
          jovahagyas_at?: string | null
          jovahagyo_id?: string | null
          kategoria?: Database["public"]["Enums"]["ora_kategoria"]
          kezdo_idopont?: string
          koltseghely?: string | null
          megjegyzes?: string | null
          munkaltatoi_dontes?: Json | null
          ora?: number
          org_unit_id?: string | null
          potlek_kod?: string | null
          projekt?: string | null
          tenant_id?: string
          unnepnapi_ora?: number
          updated_at?: string
          user_id?: string
          vasarnapi_ora?: number
          zaro_idopont?: string
        }
        Relationships: [
          {
            foreignKeyName: "work_time_ledger_assignment_id_fkey"
            columns: ["assignment_id"]
            isOneToOne: false
            referencedRelation: "schedule_assignments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "work_time_ledger_jovahagyo_id_fkey"
            columns: ["jovahagyo_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "work_time_ledger_jovahagyo_id_fkey"
            columns: ["jovahagyo_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "work_time_ledger_org_unit_id_fkey"
            columns: ["org_unit_id"]
            isOneToOne: false
            referencedRelation: "org_unit_conflicts"
            referencedColumns: ["org_unit_id"]
          },
          {
            foreignKeyName: "work_time_ledger_org_unit_id_fkey"
            columns: ["org_unit_id"]
            isOneToOne: false
            referencedRelation: "org_units"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "work_time_ledger_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "work_time_ledger_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "work_time_ledger_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      work_time_rules: {
        Row: {
          created_at: string
          ejszakai_potlek_szazalek: number
          ervenyes_ig: string | null
          ervenyes_tol: string
          eves_ovt_rendkivuli_max: number
          eves_rendkivuli_max: number
          eves_ugyelet_rendkivuli_max: number
          fenntarto_tipus: Database["public"]["Enums"]["fenntarto_tipus"]
          forrasszoveg: string | null
          havi_keszenlet_max: number
          havi_ugyelet_keszenlet_max: number
          heti_egybefuggo_piheno_ora: number
          heti_max_ora: number
          heti_max_ora_egeszsegugyi: number
          heti_max_ora_ovt: number
          id: string
          jogszabaly_hivatkozas: string | null
          jogviszony_tipus: Database["public"]["Enums"]["jogviszony_tipus"]
          keszenleti_dij_szazalek: number
          munkaidokeret_honap: number
          munkaszuneti_utan_szabadnap_fizetett: boolean
          napi_max_ora: number
          napi_max_ora_ugyelettel: number
          napi_pihenes_min_ora: number
          tenant_id: string | null
          ugyelet_munkaidokeret_terhere: boolean
          ugyelet_utan_piheno_nap: boolean
          ugyeleti_dij_szazalek: number
          unnepnapi_potlek_szazalek: number
          updated_at: string
          vasarnapi_potlek_szazalek: number
        }
        Insert: {
          created_at?: string
          ejszakai_potlek_szazalek?: number
          ervenyes_ig?: string | null
          ervenyes_tol?: string
          eves_ovt_rendkivuli_max?: number
          eves_rendkivuli_max?: number
          eves_ugyelet_rendkivuli_max?: number
          fenntarto_tipus: Database["public"]["Enums"]["fenntarto_tipus"]
          forrasszoveg?: string | null
          havi_keszenlet_max?: number
          havi_ugyelet_keszenlet_max?: number
          heti_egybefuggo_piheno_ora?: number
          heti_max_ora?: number
          heti_max_ora_egeszsegugyi?: number
          heti_max_ora_ovt?: number
          id?: string
          jogszabaly_hivatkozas?: string | null
          jogviszony_tipus: Database["public"]["Enums"]["jogviszony_tipus"]
          keszenleti_dij_szazalek?: number
          munkaidokeret_honap?: number
          munkaszuneti_utan_szabadnap_fizetett?: boolean
          napi_max_ora?: number
          napi_max_ora_ugyelettel?: number
          napi_pihenes_min_ora?: number
          tenant_id?: string | null
          ugyelet_munkaidokeret_terhere?: boolean
          ugyelet_utan_piheno_nap?: boolean
          ugyeleti_dij_szazalek?: number
          unnepnapi_potlek_szazalek?: number
          updated_at?: string
          vasarnapi_potlek_szazalek?: number
        }
        Update: {
          created_at?: string
          ejszakai_potlek_szazalek?: number
          ervenyes_ig?: string | null
          ervenyes_tol?: string
          eves_ovt_rendkivuli_max?: number
          eves_rendkivuli_max?: number
          eves_ugyelet_rendkivuli_max?: number
          fenntarto_tipus?: Database["public"]["Enums"]["fenntarto_tipus"]
          forrasszoveg?: string | null
          havi_keszenlet_max?: number
          havi_ugyelet_keszenlet_max?: number
          heti_egybefuggo_piheno_ora?: number
          heti_max_ora?: number
          heti_max_ora_egeszsegugyi?: number
          heti_max_ora_ovt?: number
          id?: string
          jogszabaly_hivatkozas?: string | null
          jogviszony_tipus?: Database["public"]["Enums"]["jogviszony_tipus"]
          keszenleti_dij_szazalek?: number
          munkaidokeret_honap?: number
          munkaszuneti_utan_szabadnap_fizetett?: boolean
          napi_max_ora?: number
          napi_max_ora_ugyelettel?: number
          napi_pihenes_min_ora?: number
          tenant_id?: string | null
          ugyelet_munkaidokeret_terhere?: boolean
          ugyelet_utan_piheno_nap?: boolean
          ugyeleti_dij_szazalek?: number
          unnepnapi_potlek_szazalek?: number
          updated_at?: string
          vasarnapi_potlek_szazalek?: number
        }
        Relationships: [
          {
            foreignKeyName: "work_time_rules_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      cms_experiment_daily_stats: {
        Row: {
          conversion_rate: number | null
          day: string | null
          experiment_id: string | null
          goals: number | null
          variant_id: string | null
          views: number | null
        }
        Relationships: [
          {
            foreignKeyName: "cms_experiment_events_experiment_id_fkey"
            columns: ["experiment_id"]
            isOneToOne: false
            referencedRelation: "cms_experiments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "cms_experiment_events_variant_id_fkey"
            columns: ["variant_id"]
            isOneToOne: false
            referencedRelation: "cms_experiment_variants"
            referencedColumns: ["id"]
          },
        ]
      }
      org_unit_conflicts: {
        Row: {
          duty_lines_count: number | null
          duty_lines_without_eligibility: number | null
          mandatory_coverage_count: number | null
          org_unit_id: string | null
          tenant_id: string | null
        }
        Relationships: [
          {
            foreignKeyName: "org_units_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      profile_capabilities: {
        Row: {
          igazolva_at: string | null
          lejarat: string | null
          skill_id: string | null
          skill_kulcs: string | null
          skill_nev: string | null
          specialty_id: string | null
          statusz: string | null
          szint: number | null
          tenant_id: string | null
          user_id: string | null
        }
        Relationships: [
          {
            foreignKeyName: "profile_skills_skill_id_fkey"
            columns: ["skill_id"]
            isOneToOne: false
            referencedRelation: "skills"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profile_skills_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profile_skills_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "profile_skills_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "skills_specialty_id_fkey"
            columns: ["specialty_id"]
            isOneToOne: false
            referencedRelation: "specialties"
            referencedColumns: ["id"]
          },
        ]
      }
      profile_scheduling_facts: {
        Row: {
          aktiv_constraint_count: number | null
          becenev: string | null
          contact_count: number | null
          egyedulnevelo: boolean | null
          egymas_utani_max_ugyelet: number | null
          email: string | null
          foglalkozas_tipus:
            | Database["public"]["Enums"]["foglalkozas_tipus"]
            | null
          fuggo_tavollet_count: number | null
          havi_max_ugyelet: number | null
          heti_max_ora: number | null
          jovahagyott_tavollet_count: number | null
          kisgyermek_otthon: boolean | null
          last_minute_elerheto: boolean | null
          last_minute_orahatar: number | null
          mentee_count: number | null
          mentor_count: number | null
          min_pihenoido_ora: number | null
          mozgaskorlatozas: boolean | null
          negativ_kapcsolat: number | null
          nyelvek: string[] | null
          pozitiv_kapcsolat: number | null
          preferalt_musakok: string[] | null
          szoptat: boolean | null
          tartos_betegseg: boolean | null
          tavollet_nap_30: number | null
          tavollet_nap_90: number | null
          teljes_nev: string | null
          tenant_id: string | null
          terhes: boolean | null
          tiltott_ejszaka: boolean | null
          tiltott_napok: number[] | null
          tiltott_sugar_zona: boolean | null
          ugyelet_utan_min_ora: number | null
          ugyelet_utan_pihenonap: boolean | null
          user_id: string | null
          utazasi_perc_max: number | null
          van_aktiv_ertesites: boolean | null
          vedendokoru: boolean | null
        }
        Relationships: [
          {
            foreignKeyName: "profiles_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      v_havi_ledger: {
        Row: {
          ejszakai_ora: number | null
          honap_kezdete: string | null
          kategoria: Database["public"]["Enums"]["ora_kategoria"] | null
          ora_osszesen: number | null
          tenant_id: string | null
          unnepnapi_ora: number | null
          user_id: string | null
          vasarnapi_ora: number | null
        }
        Relationships: [
          {
            foreignKeyName: "work_time_ledger_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "work_time_ledger_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "work_time_ledger_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      v_heti_munkaido: {
        Row: {
          het_kezdete: string | null
          kategoria: Database["public"]["Enums"]["ora_kategoria"] | null
          ora_osszesen: number | null
          tenant_id: string | null
          user_id: string | null
        }
        Relationships: [
          {
            foreignKeyName: "work_time_ledger_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "work_time_ledger_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "work_time_ledger_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      v_napi_pihenes: {
        Row: {
          datum: string | null
          elso_kezdes: string | null
          piheno_ora_elozo_naphoz: number | null
          tenant_id: string | null
          user_id: string | null
          utolso_vege: string | null
        }
        Relationships: [
          {
            foreignKeyName: "work_time_ledger_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "work_time_ledger_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "work_time_ledger_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      v_overtime_ledger_yearly: {
        Row: {
          ev: number | null
          eves_ovt_rendkivuli_max: number | null
          eves_rendkivuli_max: number | null
          eves_ugyelet_rendkivuli_max: number | null
          ovt_ora: number | null
          rendkivuli_kihasznaltsag_szazalek: number | null
          rendkivuli_ora: number | null
          tenant_id: string | null
          ugy_rend_kihasznaltsag_szazalek: number | null
          ugyelet_plus_rendkivuli_ora: number | null
          user_id: string | null
        }
        Relationships: [
          {
            foreignKeyName: "profile_employment_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profile_employment_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profile_scheduling_facts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "profile_employment_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Functions: {
      _upsert_leave_ent: {
        Args: {
          _ev: number
          _jaro: number
          _jc: string
          _t: string
          _u: string
        }
        Returns: undefined
      }
      auto_assign_from_event: {
        Args: {
          _appointment_id?: string
          _event_at: string
          _event_type: Database["public"]["Enums"]["qet_event_type"]
          _patient_id: string
          _tenant_id: string
        }
        Returns: number
      }
      calc_gyakorlati_ido: {
        Args: { p_datum?: string; p_user_id: string }
        Returns: {
          evek: number
          napok: number
        }[]
      }
      calc_illetmeny: {
        Args: { p_datum?: string; p_user_id: string }
        Returns: {
          alap_ft: number
          gyakorlati_evek: number
          sav: string
          vegso_ft: number
          vezetoi_szorzo: number
        }[]
      }
      calc_jubileumi_ido: {
        Args: { p_datum?: string; p_user_id: string }
        Returns: {
          evek: number
          napok: number
        }[]
      }
      can_access_patient: { Args: { _patient_id: string }; Returns: boolean }
      can_book_into_block: {
        Args: { _block_id: string; _user_id: string }
        Returns: boolean
      }
      cleanup_e2e_test_data: { Args: never; Returns: Json }
      close_leave_year: {
        Args: { _actor: string; _ev: number; _tenant: string }
        Returns: number
      }
      cms_audit_write: {
        Args: {
          _action: Database["public"]["Enums"]["cms_audit_action"]
          _after?: Json
          _before?: Json
          _comment?: string
          _entity_id: string
          _entity_locale?: string
          _entity_slug?: string
          _entity_type: string
          _request_meta?: Json
        }
        Returns: string
      }
      cms_exp_event_record:
        | {
            Args: {
              _event_type: string
              _experiment_id: string
              _path?: string
              _referrer?: string
              _session_id: string
              _user_agent?: string
              _variant_id: string
            }
            Returns: number
          }
        | {
            Args: {
              _event_name?: string
              _event_type: string
              _experiment_id: string
              _params?: Json
              _path?: string
              _referrer?: string
              _session_id: string
              _user_agent?: string
              _variant_id: string
            }
            Returns: number
          }
      cms_news_increment_view: { Args: { _slug: string }; Returns: undefined }
      cms_page_view_record: { Args: { _page_id: string }; Returns: undefined }
      cms_promote_scheduled_pages: { Args: never; Returns: number }
      compute_mt_leave_days: {
        Args: {
          _birth: string
          _children_births: string[]
          _children_disabled: boolean[]
          _year: number
        }
        Returns: number
      }
      compute_potlek_savs: {
        Args: { _kezdo: string; _zaro: string }
        Returns: {
          ejszakai_ora: number
          unnepnapi_ora: number
          vasarnapi_ora: number
        }[]
      }
      current_duty_lines: {
        Args: { _datum: string; _site_id: string }
        Returns: {
          id: string
          kezd_ido: string
          letszam: number
          nev: string
          primary_org_unit_id: string
          szerep_tipus: Database["public"]["Enums"]["duty_szerep_tipus"]
          veg_ido: string
        }[]
      }
      current_tenant_id: { Args: never; Returns: string }
      current_user_patient_ids: { Args: never; Returns: string[] }
      eligible_swap_targets: {
        Args: { _assignment_id: string }
        Returns: {
          display_name: string
          last_worked: string
          user_id: string
        }[]
      }
      enforce_forced_leave_takeout: {
        Args: {
          _actor: string
          _dry_run?: boolean
          _ev: number
          _tenant: string
        }
        Returns: {
          applied: boolean
          jogcim: string
          kezdo: string
          nap: number
          user_id: string
          zaro: string
        }[]
      }
      enqueue_assignment_push: {
        Args: { _changes: string[]; _event: string; _row: Json }
        Returns: undefined
      }
      enroll_followup: {
        Args: {
          _anchor_at: string
          _anchor_ref?: Json
          _patient_id: string
          _protocol_kod: string
          _tenant_id: string
        }
        Returns: string
      }
      ensure_default_or_suite: {
        Args: { _site_id: string; _tenant_id: string }
        Returns: string
      }
      ensure_role_permissions_seed: { Args: never; Returns: number }
      expire_overdue_questionnaire_assignments: { Args: never; Returns: number }
      find_acute_replacements: {
        Args: { p_datum: string; p_user_id: string }
        Returns: {
          aktiv_korlatozok: string[]
          egyezo_kepz_szam: number
          egyezo_kepzettsegek: string[]
          egyezo_skill_szam: number
          egyezo_skillek: string[]
          email: string
          foglalkozas_tipus: string
          match_score: number
          pozitiv_kapcsolat: boolean
          szabad: boolean
          teljes_nev: string
          user_id: string
        }[]
      }
      generate_demand_for_period: {
        Args: { _from: string; _org_unit_id: string; _to: string }
        Returns: {
          datum: string
          kategoria: string
          kezd_ido: string
          kotelezo: boolean
          max_letszam: number
          min_letszam: number
          skill_id: string
          staff_role_id: string
          staff_role_kulcs: string
          staff_role_nev: string
          template_id: string
          template_nev: string
          veg_ido: string
        }[]
      }
      generate_duty_demand: {
        Args: { _from: string; _site_id: string; _to: string }
        Returns: {
          datum: string
          duty_line_id: string
          duty_line_nev: string
          kezd_ido: string
          kotelezo: boolean
          letszam: number
          org_unit_id: string
          primary_org_unit_id: string
          szerep_tipus: Database["public"]["Enums"]["duty_szerep_tipus"]
          veg_ido: string
        }[]
      }
      get_home_page_id: { Args: never; Returns: string }
      get_required_monthly_duty: {
        Args: { _honap: string; _user_id: string }
        Returns: number
      }
      has_any_role: {
        Args: { _role_kulcsok: string[]; _user_id: string }
        Returns: boolean
      }
      has_cms_access: { Args: { _user_id: string }; Returns: boolean }
      has_cms_editor: { Args: { _user_id: string }; Returns: boolean }
      has_cms_publisher: { Args: { _user_id: string }; Returns: boolean }
      has_cms_reviewer: { Args: { _user_id: string }; Returns: boolean }
      has_permission: {
        Args: { _perm: string; _user_id: string }
        Returns: boolean
      }
      has_role: {
        Args: { _role_kulcs: string; _user_id: string }
        Returns: boolean
      }
      is_conversation_participant: {
        Args: { _conv_id: string; _user_id: string }
        Returns: boolean
      }
      kiosk_autosave: {
        Args: { _answers: Json; _pin: string; _token: string }
        Returns: Json
      }
      kiosk_load: { Args: { _pin: string; _token: string }; Returns: Json }
      kiosk_submit_response: {
        Args: {
          _answers: Json
          _critical_triggered: boolean
          _pin: string
          _severity: string
          _subscale_scores: Json
          _token: string
          _total_score: number
        }
        Returns: Json
      }
      kiosk_verify: {
        Args: { _pin: string; _token: string }
        Returns: {
          appointment_id: string | null
          assigned_at: string
          assigned_by: string | null
          created_at: string
          draft_answers: Json | null
          draft_saved_at: string | null
          due_at: string | null
          id: string
          kind: Database["public"]["Enums"]["assignment_kind"]
          kiosk_pin_hash: string | null
          last_activity_at: string | null
          patient_id: string | null
          print_cancelled_at: string | null
          print_cancelled_by: string | null
          print_status: Database["public"]["Enums"]["kiosk_print_status"]
          printed_at: string | null
          printed_by: string | null
          questionnaire_id: string
          reminded_at: string | null
          reminder_count: number
          status: Database["public"]["Enums"]["q_assignment_status"]
          tenant_id: string
          token: string
          updated_at: string
        }
        SetofOptions: {
          from: "*"
          to: "questionnaire_assignments"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      log_leave_admin: {
        Args: {
          _action: string
          _actor: string
          _after: Json
          _before: Json
          _ev: number
          _jogcim: string
          _nap: number
          _summary: string
          _target_user: string
          _tenant: string
        }
        Returns: string
      }
      notify_patient_user: {
        Args: {
          _cim: string
          _link: string
          _patient_id: string
          _tipus: string
          _uzenet: string
        }
        Returns: undefined
      }
      or_block_managers: { Args: { _tenant_id: string }; Returns: string[] }
      process_followup_schedules: { Args: never; Returns: number }
      process_questionnaire_schedules: {
        Args: never
        Returns: {
          created_count: number
          schedule_id: string
        }[]
      }
      publish_schedule_run: {
        Args: { _run_id: string }
        Returns: {
          notified_count: number
          published_count: number
        }[]
      }
      recalc_leave_entitlements: {
        Args: { _ev: number; _user_id: string }
        Returns: undefined
      }
      recompute_block_case_times: {
        Args: { _block_id: string }
        Returns: undefined
      }
      reorder_block_cases: {
        Args: { _block_id: string; _ordered_case_ids: string[] }
        Returns: undefined
      }
      run_scheduled_cms_publish: { Args: never; Returns: number }
      search_patients: {
        Args: { _limit?: number; _q: string }
        Returns: {
          fo_diagnozis_bno: string
          id: string
          keresztnev: string
          nem: string
          score: number
          szuletesi_datum: string
          taj: string
          vezeteknev: string
        }[]
      }
      seed_default_org_for_tenant: {
        Args: { _tenant_id: string }
        Returns: Json
      }
      send_questionnaire_reminders: { Args: never; Returns: number }
      supervises: {
        Args: {
          _at?: string
          _domain_id: string
          _supervisee_id: string
          _supervisor_id: string
        }
        Returns: boolean
      }
      wage_simulation: {
        Args: { _honap_kezdete: string; _user_id: string }
        Returns: {
          egysegek: number
          kod: string
          nev: string
          ora: number
          szorzo: number
          wage_code_id: string
        }[]
      }
    }
    Enums: {
      appt_resource_tipus: "orvos" | "rendelo" | "mindketto"
      appt_slot_status: "szabad" | "foglalt" | "letiltott" | "torolt"
      appt_status:
        | "foglalt"
        | "megerositendo"
        | "lemondva"
        | "megerkezett"
        | "befejezett"
        | "nem_jelent_meg"
      appt_sync_statusz:
        | "local_only"
        | "pending"
        | "synced"
        | "conflict"
        | "failed"
      assignment_kind: "varakozas" | "periodikus" | "egyedi" | "foglalashoz"
      assignment_status: "tervezett" | "veglegesitett" | "tenyleges" | "torolt"
      attachment_summary_status: "pending" | "done" | "failed" | "skipped"
      attendance_event_type:
        | "bejelentkezes"
        | "kijelentkezes"
        | "szunet_kezdet"
        | "szunet_veg"
        | "manualis_korrekcio"
      attendance_method: "web" | "mobil" | "nfc" | "qr" | "manualis" | "admin"
      checkin_method: "qr" | "kiosk" | "mobile"
      checkin_status: "arrived" | "in_room" | "done"
      cms_audit_action:
        | "create"
        | "update"
        | "delete"
        | "submit_review"
        | "approve"
        | "reject"
        | "publish"
        | "unpublish"
        | "revert"
        | "restore"
      cms_workflow_state:
        | "draft"
        | "in_review"
        | "approved"
        | "published"
        | "rejected"
        | "archived"
      consent_purpose:
        | "jelenlet_helymeghatarozas"
        | "jelenlet_eszkozazonosito"
        | "biometrikus"
        | "egeszsegugyi_adat"
        | "paciensi_kommunikacio"
        | "marketing"
        | "egyeb"
      constraint_tipus:
        | "terhes"
        | "szoptat"
        | "kisgyermek_otthon"
        | "egyedulnevelo"
        | "tartos_betegseg"
        | "mozgaskorlatozas"
        | "vedendokoru"
        | "egyeb"
      contact_tipus:
        | "telefon"
        | "mobil"
        | "email"
        | "signal"
        | "whatsapp"
        | "telegram"
        | "veszhelyzeti_hozzatartozo"
        | "egyeb"
      conversation_kind:
        | "dm"
        | "group"
        | "patient_provider"
        | "patient_team"
        | "ai_assistant"
      critical_alert_status: "open" | "acknowledged" | "resolved"
      duty_availability_tipus: "tartalekos" | "behivhato" | "szabad_vagyok"
      duty_szerep_tipus:
        | "nappali_ugyelet"
        | "ejszakai_ugyelet"
        | "hatter_ugyelet"
        | "keszenlet"
        | "muteti_ugyelet"
        | "egyeb"
      encounter_tipus:
        | "ambulans"
        | "fekvobeteg"
        | "muteti"
        | "konzilium"
        | "telemedicina"
        | "egyeb"
      eusztv_tabla_tipus: "orvos_1mell" | "szakdolgozo_1a_mell"
      fenntarto_tipus:
        | "allami"
        | "onkormanyzati"
        | "egyhazi"
        | "egyetemi_klinika"
        | "maganszektor"
        | "egyeb"
      foglalkozas_tipus: "orvos" | "szakdolgozo" | "egyeb"
      followup_anchor_event:
        | "birth"
        | "surgery_completed"
        | "discharge"
        | "visit_completed"
      followup_enrollment_status:
        | "active"
        | "paused"
        | "completed"
        | "cancelled"
      followup_occurrence_status:
        | "scheduled"
        | "sent"
        | "responded"
        | "missed"
        | "cancelled"
      jogviszony_tipus:
        | "kjt_kozalkalmazott"
        | "egeszsegugyi_szolgalati"
        | "munka_tv_kv"
        | "megbizasi"
        | "egyeni_vallalkozo"
        | "tarsas_vallalkozo"
        | "kozalkalmazotti_tovabbi"
        | "rezidens_kepzes"
        | "oszintszerzodes"
        | "egyeb"
      kiosk_print_status: "not_printed" | "printed" | "cancelled"
      measurement_kind:
        | "testsuly"
        | "testmagassag"
        | "bmi"
        | "haskorfogat"
        | "nyakkorfogat"
        | "vernyomas"
        | "vercukor"
        | "testho"
        | "sport"
        | "lepes"
        | "pulzus"
        | "hrv"
        | "magzatmozgas"
      measurement_source: "kezi" | "wearable" | "eszkoz"
      mentesseg_ok:
        | "terhesseg"
        | "gyermekgondozas"
        | "kor"
        | "jogviszony"
        | "egeszsegugyi"
        | "egyeb"
      message_sender_kind: "user" | "patient" | "ai" | "system"
      monitoring_alert_kind:
        | "magzatmozgas_csokkent"
        | "gdm_vercukor"
        | "preeclampsia_bp"
        | "urgent_bp"
        | "laz"
        | "szekletveres"
        | "egyeb"
      monitoring_alert_severity: "info" | "figyelem" | "surgos" | "kritikus"
      monitoring_alert_status: "open" | "acknowledged" | "resolved"
      monitoring_program_tipus: "terhesseg" | "betegseg" | "csaladtervezes"
      munkaido_keret_tipus: "heti" | "havi" | "negyedeves" | "eves" | "egyedi"
      musak_pref: "nappal" | "delutan" | "ejszaka" | "huszonnegy"
      nem_tipus: "ferfi" | "no" | "egyeb" | "nem_nyilatkozik"
      or_block_statusz_enum: "allokalt" | "felszabaditott" | "lezart"
      or_case_prioritas_enum: "elektiv" | "sürgos" | "azonnali"
      or_case_statusz_enum:
        | "tervezett"
        | "jovahagyott"
        | "folyamatban"
        | "elvegzett"
        | "elhalasztott"
        | "torolt"
      or_eroforras_tipus_enum:
        | "aneszteziologus"
        | "mutos_szakdolgozo"
        | "cssd_keszlet"
        | "pito_agy"
        | "ito_agy"
        | "pacu_ebredo"
        | "verkeszitmeny"
        | "kepalkotas_intraop"
        | "patologia_fagyasztott"
        | "robot_konzol"
        | "embriologiai_labor"
        | "neonatologus"
        | "lezer_eszkoz"
        | "implantatum"
      or_resource_req_status_enum: "igenyelt" | "foglalt" | "nem_elerheto"
      or_resource_req_when_enum: "intraop" | "posztop"
      or_tipus_enum:
        | "altalanos"
        | "szuloszoba"
        | "egynapos_kismuteti"
        | "onkosebeszet"
        | "reproduktiv"
        | "hibrid"
        | "lezer"
        | "robot"
      ora_kategoria:
        | "rendes"
        | "ugyelet"
        | "keszenlet"
        | "ovt"
        | "rendkivuli"
        | "kompenzalo"
        | "szabadsag"
        | "tavollet"
      org_unit_tipus:
        | "fekvobeteg_osztaly"
        | "rendelo"
        | "ambulancia"
        | "muto"
        | "kismuto"
        | "egyeb"
        | "ito"
        | "pito"
        | "egynapos"
      overtime_order_status:
        | "tervezett"
        | "elrendelt"
        | "teljesitve"
        | "visszavont"
      overtime_pref_status: "aktiv" | "visszavont" | "lejart"
      paired_shift_tipus: "egyutt_kivant" | "egyutt_kerult"
      peer_link_status:
        | "aktiv"
        | "jovahagyasra_var"
        | "jovahagyott"
        | "elutasitott"
      peer_link_tipus:
        | "szivesen_dolgozik_vele"
        | "nem_dolgozik_vele"
        | "mentor"
        | "mentee"
      q_assignment_status:
        | "assigned"
        | "in_progress"
        | "completed"
        | "expired"
        | "cancelled"
      q_licenc:
        | "free"
        | "public_domain"
        | "who_noncommercial"
        | "euroqol_licensed"
        | "pearson_blocked"
      q_mode: "klinikai" | "egeszsegfejlesztesi" | "vegyes"
      qet_event_type:
        | "appointment_created"
        | "appointment_scheduled"
        | "surgery_created"
        | "surgery_scheduled"
        | "birth_recorded"
        | "surgery_completed"
        | "encounter_discharged"
        | "visit_completed"
      reminder_channel: "notification" | "push" | "email" | "sms"
      role_kategoria: "orvos" | "szakdolgozo" | "vezeto" | "admin"
      schedule_change_request_status:
        | "pending"
        | "approved"
        | "rejected"
        | "cancelled"
      schedule_change_request_type: "cancel" | "swap"
      staff_level_tipus: "orvos" | "szakdolgozo"
      unavailability_status:
        | "tervezett"
        | "jovahagyasra_var"
        | "jovahagyott"
        | "elutasitott"
      unavailability_tipus:
        | "szabadsag"
        | "betegszabadsag"
        | "tovabbkepzes"
        | "konferencia"
        | "kotelezetts_ugy"
        | "egyeb_tavollet"
      uzemmod_tipus:
        | "folyamatos_24_7"
        | "rendelesi_ido"
        | "programozott_nappali"
        | "muteti_blokk"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      appt_resource_tipus: ["orvos", "rendelo", "mindketto"],
      appt_slot_status: ["szabad", "foglalt", "letiltott", "torolt"],
      appt_status: [
        "foglalt",
        "megerositendo",
        "lemondva",
        "megerkezett",
        "befejezett",
        "nem_jelent_meg",
      ],
      appt_sync_statusz: [
        "local_only",
        "pending",
        "synced",
        "conflict",
        "failed",
      ],
      assignment_kind: ["varakozas", "periodikus", "egyedi", "foglalashoz"],
      assignment_status: ["tervezett", "veglegesitett", "tenyleges", "torolt"],
      attachment_summary_status: ["pending", "done", "failed", "skipped"],
      attendance_event_type: [
        "bejelentkezes",
        "kijelentkezes",
        "szunet_kezdet",
        "szunet_veg",
        "manualis_korrekcio",
      ],
      attendance_method: ["web", "mobil", "nfc", "qr", "manualis", "admin"],
      checkin_method: ["qr", "kiosk", "mobile"],
      checkin_status: ["arrived", "in_room", "done"],
      cms_audit_action: [
        "create",
        "update",
        "delete",
        "submit_review",
        "approve",
        "reject",
        "publish",
        "unpublish",
        "revert",
        "restore",
      ],
      cms_workflow_state: [
        "draft",
        "in_review",
        "approved",
        "published",
        "rejected",
        "archived",
      ],
      consent_purpose: [
        "jelenlet_helymeghatarozas",
        "jelenlet_eszkozazonosito",
        "biometrikus",
        "egeszsegugyi_adat",
        "paciensi_kommunikacio",
        "marketing",
        "egyeb",
      ],
      constraint_tipus: [
        "terhes",
        "szoptat",
        "kisgyermek_otthon",
        "egyedulnevelo",
        "tartos_betegseg",
        "mozgaskorlatozas",
        "vedendokoru",
        "egyeb",
      ],
      contact_tipus: [
        "telefon",
        "mobil",
        "email",
        "signal",
        "whatsapp",
        "telegram",
        "veszhelyzeti_hozzatartozo",
        "egyeb",
      ],
      conversation_kind: [
        "dm",
        "group",
        "patient_provider",
        "patient_team",
        "ai_assistant",
      ],
      critical_alert_status: ["open", "acknowledged", "resolved"],
      duty_availability_tipus: ["tartalekos", "behivhato", "szabad_vagyok"],
      duty_szerep_tipus: [
        "nappali_ugyelet",
        "ejszakai_ugyelet",
        "hatter_ugyelet",
        "keszenlet",
        "muteti_ugyelet",
        "egyeb",
      ],
      encounter_tipus: [
        "ambulans",
        "fekvobeteg",
        "muteti",
        "konzilium",
        "telemedicina",
        "egyeb",
      ],
      eusztv_tabla_tipus: ["orvos_1mell", "szakdolgozo_1a_mell"],
      fenntarto_tipus: [
        "allami",
        "onkormanyzati",
        "egyhazi",
        "egyetemi_klinika",
        "maganszektor",
        "egyeb",
      ],
      foglalkozas_tipus: ["orvos", "szakdolgozo", "egyeb"],
      followup_anchor_event: [
        "birth",
        "surgery_completed",
        "discharge",
        "visit_completed",
      ],
      followup_enrollment_status: [
        "active",
        "paused",
        "completed",
        "cancelled",
      ],
      followup_occurrence_status: [
        "scheduled",
        "sent",
        "responded",
        "missed",
        "cancelled",
      ],
      jogviszony_tipus: [
        "kjt_kozalkalmazott",
        "egeszsegugyi_szolgalati",
        "munka_tv_kv",
        "megbizasi",
        "egyeni_vallalkozo",
        "tarsas_vallalkozo",
        "kozalkalmazotti_tovabbi",
        "rezidens_kepzes",
        "oszintszerzodes",
        "egyeb",
      ],
      kiosk_print_status: ["not_printed", "printed", "cancelled"],
      measurement_kind: [
        "testsuly",
        "testmagassag",
        "bmi",
        "haskorfogat",
        "nyakkorfogat",
        "vernyomas",
        "vercukor",
        "testho",
        "sport",
        "lepes",
        "pulzus",
        "hrv",
        "magzatmozgas",
      ],
      measurement_source: ["kezi", "wearable", "eszkoz"],
      mentesseg_ok: [
        "terhesseg",
        "gyermekgondozas",
        "kor",
        "jogviszony",
        "egeszsegugyi",
        "egyeb",
      ],
      message_sender_kind: ["user", "patient", "ai", "system"],
      monitoring_alert_kind: [
        "magzatmozgas_csokkent",
        "gdm_vercukor",
        "preeclampsia_bp",
        "urgent_bp",
        "laz",
        "szekletveres",
        "egyeb",
      ],
      monitoring_alert_severity: ["info", "figyelem", "surgos", "kritikus"],
      monitoring_alert_status: ["open", "acknowledged", "resolved"],
      monitoring_program_tipus: ["terhesseg", "betegseg", "csaladtervezes"],
      munkaido_keret_tipus: ["heti", "havi", "negyedeves", "eves", "egyedi"],
      musak_pref: ["nappal", "delutan", "ejszaka", "huszonnegy"],
      nem_tipus: ["ferfi", "no", "egyeb", "nem_nyilatkozik"],
      or_block_statusz_enum: ["allokalt", "felszabaditott", "lezart"],
      or_case_prioritas_enum: ["elektiv", "sürgos", "azonnali"],
      or_case_statusz_enum: [
        "tervezett",
        "jovahagyott",
        "folyamatban",
        "elvegzett",
        "elhalasztott",
        "torolt",
      ],
      or_eroforras_tipus_enum: [
        "aneszteziologus",
        "mutos_szakdolgozo",
        "cssd_keszlet",
        "pito_agy",
        "ito_agy",
        "pacu_ebredo",
        "verkeszitmeny",
        "kepalkotas_intraop",
        "patologia_fagyasztott",
        "robot_konzol",
        "embriologiai_labor",
        "neonatologus",
        "lezer_eszkoz",
        "implantatum",
      ],
      or_resource_req_status_enum: ["igenyelt", "foglalt", "nem_elerheto"],
      or_resource_req_when_enum: ["intraop", "posztop"],
      or_tipus_enum: [
        "altalanos",
        "szuloszoba",
        "egynapos_kismuteti",
        "onkosebeszet",
        "reproduktiv",
        "hibrid",
        "lezer",
        "robot",
      ],
      ora_kategoria: [
        "rendes",
        "ugyelet",
        "keszenlet",
        "ovt",
        "rendkivuli",
        "kompenzalo",
        "szabadsag",
        "tavollet",
      ],
      org_unit_tipus: [
        "fekvobeteg_osztaly",
        "rendelo",
        "ambulancia",
        "muto",
        "kismuto",
        "egyeb",
        "ito",
        "pito",
        "egynapos",
      ],
      overtime_order_status: [
        "tervezett",
        "elrendelt",
        "teljesitve",
        "visszavont",
      ],
      overtime_pref_status: ["aktiv", "visszavont", "lejart"],
      paired_shift_tipus: ["egyutt_kivant", "egyutt_kerult"],
      peer_link_status: [
        "aktiv",
        "jovahagyasra_var",
        "jovahagyott",
        "elutasitott",
      ],
      peer_link_tipus: [
        "szivesen_dolgozik_vele",
        "nem_dolgozik_vele",
        "mentor",
        "mentee",
      ],
      q_assignment_status: [
        "assigned",
        "in_progress",
        "completed",
        "expired",
        "cancelled",
      ],
      q_licenc: [
        "free",
        "public_domain",
        "who_noncommercial",
        "euroqol_licensed",
        "pearson_blocked",
      ],
      q_mode: ["klinikai", "egeszsegfejlesztesi", "vegyes"],
      qet_event_type: [
        "appointment_created",
        "appointment_scheduled",
        "surgery_created",
        "surgery_scheduled",
        "birth_recorded",
        "surgery_completed",
        "encounter_discharged",
        "visit_completed",
      ],
      reminder_channel: ["notification", "push", "email", "sms"],
      role_kategoria: ["orvos", "szakdolgozo", "vezeto", "admin"],
      schedule_change_request_status: [
        "pending",
        "approved",
        "rejected",
        "cancelled",
      ],
      schedule_change_request_type: ["cancel", "swap"],
      staff_level_tipus: ["orvos", "szakdolgozo"],
      unavailability_status: [
        "tervezett",
        "jovahagyasra_var",
        "jovahagyott",
        "elutasitott",
      ],
      unavailability_tipus: [
        "szabadsag",
        "betegszabadsag",
        "tovabbkepzes",
        "konferencia",
        "kotelezetts_ugy",
        "egyeb_tavollet",
      ],
      uzemmod_tipus: [
        "folyamatos_24_7",
        "rendelesi_ido",
        "programozott_nappali",
        "muteti_blokk",
      ],
    },
  },
} as const
