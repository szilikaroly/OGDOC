
-- Extend i18n_translations
ALTER TABLE public.i18n_translations
  ADD COLUMN IF NOT EXISTS kind text NOT NULL DEFAULT 'ui',
  ADD COLUMN IF NOT EXISTS content_ref text;

CREATE UNIQUE INDEX IF NOT EXISTS i18n_translations_unique_key
  ON public.i18n_translations (COALESCE(tenant_id, '00000000-0000-0000-0000-000000000000'::uuid), namespace, key, lang);

-- Glossary table
CREATE TABLE IF NOT EXISTS public.translation_glossary (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  term text NOT NULL,
  target_lang text NOT NULL,
  translation text NOT NULL,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.translation_glossary TO authenticated;
GRANT ALL ON public.translation_glossary TO service_role;

ALTER TABLE public.translation_glossary ENABLE ROW LEVEL SECURITY;

CREATE POLICY "tenant members read glossary" ON public.translation_glossary
  FOR SELECT TO authenticated
  USING (tenant_id IS NULL OR tenant_id IN (SELECT p.tenant_id FROM public.profiles p WHERE p.id = auth.uid()));

CREATE POLICY "tenant members write glossary" ON public.translation_glossary
  FOR ALL TO authenticated
  USING (tenant_id IS NULL OR tenant_id IN (SELECT p.tenant_id FROM public.profiles p WHERE p.id = auth.uid()))
  WITH CHECK (tenant_id IS NULL OR tenant_id IN (SELECT p.tenant_id FROM public.profiles p WHERE p.id = auth.uid()));

CREATE INDEX IF NOT EXISTS translation_glossary_lookup ON public.translation_glossary (target_lang, tenant_id);
