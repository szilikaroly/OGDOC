CREATE TABLE public.schedule_share_tokens (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tenant_id UUID NOT NULL,
  token TEXT NOT NULL UNIQUE,
  scope_month DATE NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  created_by UUID NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  revoked_at TIMESTAMPTZ
);

CREATE INDEX idx_share_tokens_tenant ON public.schedule_share_tokens(tenant_id);
CREATE INDEX idx_share_tokens_token ON public.schedule_share_tokens(token) WHERE revoked_at IS NULL;

GRANT SELECT, INSERT, UPDATE ON public.schedule_share_tokens TO authenticated;
GRANT ALL ON public.schedule_share_tokens TO service_role;

ALTER TABLE public.schedule_share_tokens ENABLE ROW LEVEL SECURITY;

CREATE POLICY "share_tokens_select_own_tenant"
  ON public.schedule_share_tokens
  FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());

CREATE POLICY "share_tokens_insert_schedule_managers"
  ON public.schedule_share_tokens
  FOR INSERT TO authenticated
  WITH CHECK (
    tenant_id = public.current_tenant_id()
    AND created_by = auth.uid()
    AND (public.has_permission(auth.uid(), 'manage_schedule')
         OR public.has_permission(auth.uid(), 'manage_tenant'))
  );

CREATE POLICY "share_tokens_revoke_schedule_managers"
  ON public.schedule_share_tokens
  FOR UPDATE TO authenticated
  USING (
    tenant_id = public.current_tenant_id()
    AND (public.has_permission(auth.uid(), 'manage_schedule')
         OR public.has_permission(auth.uid(), 'manage_tenant'))
  );