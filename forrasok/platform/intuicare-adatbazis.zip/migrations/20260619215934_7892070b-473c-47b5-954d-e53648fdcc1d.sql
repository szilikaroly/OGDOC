
CREATE TABLE public.i18n_translations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  namespace text NOT NULL,
  key text NOT NULL,
  source_text text NOT NULL,
  lang text NOT NULL CHECK (lang IN ('en','hu','ro','sr','zh','fil','de','uk','ru')),
  value text NOT NULL,
  source_hash text NOT NULL,
  edited_by_user boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, namespace, key, lang)
);

CREATE INDEX idx_i18n_ns_key ON public.i18n_translations(tenant_id, namespace, key);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.i18n_translations TO authenticated;
GRANT ALL ON public.i18n_translations TO service_role;

ALTER TABLE public.i18n_translations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "tenant members read i18n"
  ON public.i18n_translations FOR SELECT TO authenticated
  USING (
    tenant_id IS NULL OR tenant_id IN (
      SELECT tenant_id FROM public.profiles WHERE id = auth.uid()
    )
  );

CREATE POLICY "tenant members write i18n"
  ON public.i18n_translations FOR ALL TO authenticated
  USING (
    tenant_id IS NULL OR tenant_id IN (
      SELECT tenant_id FROM public.profiles WHERE id = auth.uid()
    )
  )
  WITH CHECK (
    tenant_id IS NULL OR tenant_id IN (
      SELECT tenant_id FROM public.profiles WHERE id = auth.uid()
    )
  );

CREATE OR REPLACE FUNCTION public.i18n_set_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_i18n_updated_at
  BEFORE UPDATE ON public.i18n_translations
  FOR EACH ROW EXECUTE FUNCTION public.i18n_set_updated_at();
