create table if not exists public.symptom_match_feedback (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  query text not null,
  specialty_id uuid not null references public.specialties(id) on delete cascade,
  verdict text not null check (verdict in ('fit','miss')),
  urgency text,
  created_at timestamptz not null default now()
);

create index if not exists symptom_match_feedback_specialty_idx
  on public.symptom_match_feedback(specialty_id, verdict);
create index if not exists symptom_match_feedback_user_idx
  on public.symptom_match_feedback(user_id, created_at desc);

grant select, insert on public.symptom_match_feedback to authenticated;
grant all on public.symptom_match_feedback to service_role;

alter table public.symptom_match_feedback enable row level security;

create policy "own feedback insert" on public.symptom_match_feedback
  for insert to authenticated with check (auth.uid() = user_id);

create policy "own feedback select" on public.symptom_match_feedback
  for select to authenticated using (auth.uid() = user_id);
