CREATE OR REPLACE FUNCTION public.notify_contact_message()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_link  text := '/admin/cms?tab=contact&id=' || NEW.id::text;
  v_title text := COALESCE(NULLIF('Új üzenet: ' || NEW.subject, 'Új üzenet: '), 'Új kapcsolatfelvétel');
  v_body  text := left(coalesce(NEW.sender_name,'') || ' — ' || coalesce(NEW.body,''), 240);
  v_inserted integer := 0;
BEGIN
  -- 1) Részleg-hozzárendelt dolgozók
  IF NEW.org_unit_id IS NOT NULL THEN
    INSERT INTO public.notifications (tenant_id, user_id, tipus, cim, uzenet, link)
    SELECT DISTINCT ur.tenant_id, ur.user_id, 'contact_message', v_title, v_body, v_link
    FROM public.user_roles ur
    WHERE ur.org_unit_id = NEW.org_unit_id
      AND ur.user_id IS NOT NULL
      AND ur.tenant_id IS NOT NULL
      AND (ur.ervenyes_tol IS NULL OR ur.ervenyes_tol <= now())
      AND (ur.ervenyes_ig  IS NULL OR ur.ervenyes_ig  >= now());
    GET DIAGNOSTICS v_inserted = ROW_COUNT;
  END IF;

  -- 2) Fallback: CMS szerkesztők / tenant admin
  IF v_inserted = 0 THEN
    INSERT INTO public.notifications (tenant_id, user_id, tipus, cim, uzenet, link)
    SELECT DISTINCT ur.tenant_id, ur.user_id, 'contact_message', v_title, v_body, v_link
    FROM public.user_roles ur
    JOIN public.roles r ON r.id = ur.role_id
    WHERE r.kulcs IN ('tenant_admin','cms_editor','cms_reviewer','cms_publisher')
      AND ur.user_id IS NOT NULL
      AND ur.tenant_id IS NOT NULL
      AND (ur.ervenyes_tol IS NULL OR ur.ervenyes_tol <= now())
      AND (ur.ervenyes_ig  IS NULL OR ur.ervenyes_ig  >= now());
  END IF;

  RETURN NEW;
EXCEPTION WHEN OTHERS THEN
  -- Az értesítés sosem törheti meg a kapcsolatfelvétel mentését
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_contact_message_notify ON public.contact_messages;
CREATE TRIGGER trg_contact_message_notify
  AFTER INSERT ON public.contact_messages
  FOR EACH ROW EXECUTE FUNCTION public.notify_contact_message();
