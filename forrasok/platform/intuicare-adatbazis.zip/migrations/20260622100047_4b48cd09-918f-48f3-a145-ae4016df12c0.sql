
-- Backfill profile_constraints.tenant_id from owning profile
UPDATE public.profile_constraints pc
SET tenant_id = p.tenant_id
FROM public.profiles p
WHERE pc.user_id = p.id AND pc.tenant_id IS NULL;

-- incompatibilities
DROP POLICY IF EXISTS inc_select ON public.incompatibilities;
DROP POLICY IF EXISTS inc_update ON public.incompatibilities;
DROP POLICY IF EXISTS inc_insert ON public.incompatibilities;
DROP POLICY IF EXISTS inc_delete ON public.incompatibilities;

CREATE POLICY inc_select ON public.incompatibilities FOR SELECT TO authenticated
USING (
  tenant_id = public.current_tenant_id()
  AND (user_id = auth.uid() OR public.has_permission(auth.uid(),'manage_tenant'))
);
CREATE POLICY inc_insert ON public.incompatibilities FOR INSERT TO authenticated
WITH CHECK (tenant_id = public.current_tenant_id() AND user_id = auth.uid());
CREATE POLICY inc_update ON public.incompatibilities FOR UPDATE TO authenticated
USING (
  tenant_id = public.current_tenant_id()
  AND (user_id = auth.uid() OR public.has_permission(auth.uid(),'manage_tenant'))
)
WITH CHECK (
  tenant_id = public.current_tenant_id()
  AND (user_id = auth.uid() OR public.has_permission(auth.uid(),'manage_tenant'))
);
CREATE POLICY inc_delete ON public.incompatibilities FOR DELETE TO authenticated
USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_tenant'));

-- opt_out_agreements
DROP POLICY IF EXISTS ooa_select ON public.opt_out_agreements;
DROP POLICY IF EXISTS ooa_update ON public.opt_out_agreements;
DROP POLICY IF EXISTS ooa_insert ON public.opt_out_agreements;
DROP POLICY IF EXISTS ooa_delete ON public.opt_out_agreements;

CREATE POLICY ooa_select ON public.opt_out_agreements FOR SELECT TO authenticated
USING (
  tenant_id = public.current_tenant_id()
  AND (user_id = auth.uid() OR public.has_permission(auth.uid(),'manage_tenant'))
);
CREATE POLICY ooa_insert ON public.opt_out_agreements FOR INSERT TO authenticated
WITH CHECK (
  tenant_id = public.current_tenant_id()
  AND (user_id = auth.uid() OR public.has_permission(auth.uid(),'manage_tenant'))
);
CREATE POLICY ooa_update ON public.opt_out_agreements FOR UPDATE TO authenticated
USING (
  tenant_id = public.current_tenant_id()
  AND (user_id = auth.uid() OR public.has_permission(auth.uid(),'manage_tenant'))
)
WITH CHECK (
  tenant_id = public.current_tenant_id()
  AND (user_id = auth.uid() OR public.has_permission(auth.uid(),'manage_tenant'))
);
CREATE POLICY ooa_delete ON public.opt_out_agreements FOR DELETE TO authenticated
USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_tenant'));

-- profile_constraints: enforce non-null tenant_id going forward and apply tenant filter
ALTER TABLE public.profile_constraints ALTER COLUMN tenant_id SET NOT NULL;

DROP POLICY IF EXISTS profile_constraints_select ON public.profile_constraints;
DROP POLICY IF EXISTS profile_constraints_write ON public.profile_constraints;

CREATE POLICY profile_constraints_select ON public.profile_constraints FOR SELECT TO authenticated
USING (
  tenant_id = public.current_tenant_id()
  AND (user_id = auth.uid() OR public.has_permission(auth.uid(),'manage_tenant'))
);
CREATE POLICY profile_constraints_write ON public.profile_constraints FOR ALL TO authenticated
USING (
  tenant_id = public.current_tenant_id()
  AND (user_id = auth.uid() OR public.has_permission(auth.uid(),'manage_tenant'))
)
WITH CHECK (
  tenant_id = public.current_tenant_id()
  AND (user_id = auth.uid() OR public.has_permission(auth.uid(),'manage_tenant'))
);
