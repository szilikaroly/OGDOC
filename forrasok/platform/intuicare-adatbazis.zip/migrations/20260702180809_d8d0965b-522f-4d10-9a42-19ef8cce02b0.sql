-- Allow public A/B experiment view/goal tracking through the Data API
GRANT SELECT, INSERT ON public.cms_experiment_events TO anon, authenticated;
GRANT ALL ON public.cms_experiment_events TO service_role;

-- Only allow inserts for events belonging to a running experiment,
-- limited to 'view' and 'goal' event types.
DROP POLICY IF EXISTS cms_exp_events_public_insert ON public.cms_experiment_events;
CREATE POLICY cms_exp_events_public_insert
  ON public.cms_experiment_events
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (
    event_type IN ('view','goal')
    AND EXISTS (
      SELECT 1 FROM public.cms_experiments e
      WHERE e.id = experiment_id AND e.status = 'running'
    )
    AND EXISTS (
      SELECT 1 FROM public.cms_experiment_variants v
      WHERE v.id = variant_id AND v.experiment_id = cms_experiment_events.experiment_id
    )
  );