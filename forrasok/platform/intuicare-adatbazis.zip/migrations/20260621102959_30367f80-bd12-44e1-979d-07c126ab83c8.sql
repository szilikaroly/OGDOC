
-- ============================================================
-- Step 2: Patient module RLS hardening
-- ============================================================

-- ---- patient_users: remove permissive client INSERT (only SECURITY DEFINER server path may insert) ----
DROP POLICY IF EXISTS "Felhasználó létrehozhat saját páciens-linket (self)" ON public.patient_users;

-- Allow patients to DELETE their own link (unlink)
CREATE POLICY "Felhasználó törölheti saját páciens-linkjét"
ON public.patient_users
FOR DELETE
TO authenticated
USING (user_id = auth.uid());

-- ---- measurements: patient can read & insert own ----
CREATE POLICY "Páciens olvashatja saját méréseit"
ON public.measurements
FOR SELECT
TO authenticated
USING (patient_id IN (SELECT current_user_patient_ids()));

CREATE POLICY "Páciens rögzíthet saját mérést"
ON public.measurements
FOR INSERT
TO authenticated
WITH CHECK (patient_id IN (SELECT current_user_patient_ids()));

CREATE POLICY "Páciens módosíthatja saját mérését"
ON public.measurements
FOR UPDATE
TO authenticated
USING (patient_id IN (SELECT current_user_patient_ids()))
WITH CHECK (patient_id IN (SELECT current_user_patient_ids()));

CREATE POLICY "Páciens törölheti saját mérését"
ON public.measurements
FOR DELETE
TO authenticated
USING (patient_id IN (SELECT current_user_patient_ids()));

-- ---- questionnaire_assignments: patient can read own & mark status ----
CREATE POLICY "Páciens olvashatja saját kérdőív kiosztásait"
ON public.questionnaire_assignments
FOR SELECT
TO authenticated
USING (patient_id IN (SELECT current_user_patient_ids()));

CREATE POLICY "Páciens frissítheti saját kérdőív státuszát"
ON public.questionnaire_assignments
FOR UPDATE
TO authenticated
USING (patient_id IN (SELECT current_user_patient_ids()))
WITH CHECK (patient_id IN (SELECT current_user_patient_ids()));

-- ---- questionnaire_responses: patient can insert & read own ----
CREATE POLICY "Páciens olvashatja saját kérdőív válaszait"
ON public.questionnaire_responses
FOR SELECT
TO authenticated
USING (patient_id IN (SELECT current_user_patient_ids()));

CREATE POLICY "Páciens rögzíthet saját kérdőív választ"
ON public.questionnaire_responses
FOR INSERT
TO authenticated
WITH CHECK (patient_id IN (SELECT current_user_patient_ids()));
