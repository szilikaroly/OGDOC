-- CMS news content type with categories (parent/child), tags and guest authors

-- Categories with parent/child support
CREATE TABLE public.cms_news_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_id uuid REFERENCES public.cms_news_categories(id) ON DELETE SET NULL,
  slug text NOT NULL UNIQUE,
  name text NOT NULL,
  description text,
  sort_order integer NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.cms_news_categories TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_news_categories TO authenticated;
GRANT ALL ON public.cms_news_categories TO service_role;
ALTER TABLE public.cms_news_categories ENABLE ROW LEVEL SECURITY;
CREATE POLICY "news cats public read" ON public.cms_news_categories FOR SELECT TO anon, authenticated USING (is_active = true);
CREATE POLICY "news cats cms manage" ON public.cms_news_categories FOR ALL TO authenticated USING (public.has_cms_access(auth.uid())) WITH CHECK (public.has_cms_access(auth.uid()));

-- Tags
CREATE TABLE public.cms_news_tags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  name text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.cms_news_tags TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_news_tags TO authenticated;
GRANT ALL ON public.cms_news_tags TO service_role;
ALTER TABLE public.cms_news_tags ENABLE ROW LEVEL SECURITY;
CREATE POLICY "news tags public read" ON public.cms_news_tags FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "news tags cms manage" ON public.cms_news_tags FOR ALL TO authenticated USING (public.has_cms_access(auth.uid())) WITH CHECK (public.has_cms_access(auth.uid()));

-- Guest authors (optional override of auth user)
CREATE TABLE public.cms_news_authors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  display_name text NOT NULL,
  bio text,
  avatar_url text,
  email text,
  is_guest boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.cms_news_authors TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_news_authors TO authenticated;
GRANT ALL ON public.cms_news_authors TO service_role;
ALTER TABLE public.cms_news_authors ENABLE ROW LEVEL SECURITY;
CREATE POLICY "news authors public read" ON public.cms_news_authors FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "news authors cms manage" ON public.cms_news_authors FOR ALL TO authenticated USING (public.has_cms_access(auth.uid())) WITH CHECK (public.has_cms_access(auth.uid()));

-- News posts
CREATE TABLE public.cms_news_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  locale text NOT NULL DEFAULT 'hu',
  title text NOT NULL,
  excerpt text,
  body jsonb NOT NULL DEFAULT '{}'::jsonb,
  featured_image_url text,
  featured_image_alt text,
  author_id uuid REFERENCES public.cms_news_authors(id) ON DELETE SET NULL,
  category_id uuid REFERENCES public.cms_news_categories(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','scheduled','published','archived')),
  published_at timestamptz,
  seo_title text,
  seo_description text,
  og_image_url text,
  view_count integer NOT NULL DEFAULT 0,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  updated_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.cms_news_posts TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_news_posts TO authenticated;
GRANT ALL ON public.cms_news_posts TO service_role;
ALTER TABLE public.cms_news_posts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "news public read published" ON public.cms_news_posts FOR SELECT TO anon, authenticated
  USING (status = 'published' AND published_at IS NOT NULL AND published_at <= now());
CREATE POLICY "news cms read all" ON public.cms_news_posts FOR SELECT TO authenticated USING (public.has_cms_access(auth.uid()));
CREATE POLICY "news cms manage" ON public.cms_news_posts FOR ALL TO authenticated USING (public.has_cms_access(auth.uid())) WITH CHECK (public.has_cms_access(auth.uid()));

CREATE INDEX cms_news_posts_status_published_idx ON public.cms_news_posts(status, published_at DESC);
CREATE INDEX cms_news_posts_category_idx ON public.cms_news_posts(category_id);
CREATE INDEX cms_news_posts_locale_idx ON public.cms_news_posts(locale);

-- Tag join
CREATE TABLE public.cms_news_post_tags (
  post_id uuid NOT NULL REFERENCES public.cms_news_posts(id) ON DELETE CASCADE,
  tag_id uuid NOT NULL REFERENCES public.cms_news_tags(id) ON DELETE CASCADE,
  PRIMARY KEY (post_id, tag_id)
);
GRANT SELECT ON public.cms_news_post_tags TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_news_post_tags TO authenticated;
GRANT ALL ON public.cms_news_post_tags TO service_role;
ALTER TABLE public.cms_news_post_tags ENABLE ROW LEVEL SECURITY;
CREATE POLICY "news post tags public read" ON public.cms_news_post_tags FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "news post tags cms manage" ON public.cms_news_post_tags FOR ALL TO authenticated USING (public.has_cms_access(auth.uid())) WITH CHECK (public.has_cms_access(auth.uid()));

-- updated_at triggers (use existing public.update_updated_at_column if available; otherwise create)
CREATE OR REPLACE FUNCTION public.cms_news_touch_updated_at()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;
CREATE TRIGGER trg_cms_news_categories_uat BEFORE UPDATE ON public.cms_news_categories
  FOR EACH ROW EXECUTE FUNCTION public.cms_news_touch_updated_at();
CREATE TRIGGER trg_cms_news_authors_uat BEFORE UPDATE ON public.cms_news_authors
  FOR EACH ROW EXECUTE FUNCTION public.cms_news_touch_updated_at();
CREATE TRIGGER trg_cms_news_posts_uat BEFORE UPDATE ON public.cms_news_posts
  FOR EACH ROW EXECUTE FUNCTION public.cms_news_touch_updated_at();

-- View count RPC (anon callable)
CREATE OR REPLACE FUNCTION public.cms_news_increment_view(_slug text)
RETURNS void LANGUAGE sql SECURITY DEFINER SET search_path = public AS $$
  UPDATE public.cms_news_posts SET view_count = view_count + 1
  WHERE slug = _slug AND status = 'published' AND published_at <= now();
$$;
GRANT EXECUTE ON FUNCTION public.cms_news_increment_view(text) TO anon, authenticated;