
-- Protect HR-only column on profile_constraints: only manage_tenant may write hr_megjegyzes.
-- Unauthorized attempts are logged to admin_audit_log and blocked.

CREATE OR REPLACE FUNCTION public.profile_constraints_protect_hr_note()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_is_hr boolean := COALESCE(public.has_permission(v_uid, 'manage_tenant'), false);
  v_changed boolean := false;
BEGIN
  IF TG_OP = 'INSERT' THEN
    v_changed := NEW.hr_megjegyzes IS NOT NULL;
  ELSIF TG_OP = 'UPDATE' THEN
    v_changed := COALESCE(NEW.hr_megjegyzes, '') IS DISTINCT FROM COALESCE(OLD.hr_megjegyzes, '');
  END IF;

  IF v_changed AND NOT v_is_hr THEN
    -- audit the forbidden write attempt
    INSERT INTO public.admin_audit_log(tenant_id, user_id, action, table_name, record_id, before_data, after_data)
    VALUES (
      COALESCE(NEW.tenant_id, public.current_tenant_id()),
      v_uid,
      'FORBIDDEN_WRITE_HR_NOTE',
      TG_TABLE_NAME,
      COALESCE(NEW.id::text, ''),
      CASE WHEN TG_OP = 'UPDATE' THEN jsonb_build_object('hr_megjegyzes', OLD.hr_megjegyzes) ELSE NULL END,
      jsonb_build_object('attempted_hr_megjegyzes', NEW.hr_megjegyzes)
    );
    RAISE EXCEPTION 'A HR megjegyzés mezőt csak tenant-admin (HR) szerepkör módosíthatja.'
      USING ERRCODE = '42501';
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_profile_constraints_protect_hr_note ON public.profile_constraints;
CREATE TRIGGER trg_profile_constraints_protect_hr_note
  BEFORE INSERT OR UPDATE ON public.profile_constraints
  FOR EACH ROW EXECUTE FUNCTION public.profile_constraints_protect_hr_note();

-- Approval workflow guard on profile_unavailability:
-- - status transitions to jovahagyott/elutasitott require manage_schedule or manage_tenant
-- - the approver cannot be the same user as the request owner (no self-approval)
-- - rejection requires a non-empty jovahagyas_indok
CREATE OR REPLACE FUNCTION public.profile_unavailability_guard()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_can_approve boolean;
BEGIN
  IF TG_OP = 'UPDATE' AND NEW.status IS DISTINCT FROM OLD.status THEN
    IF NEW.status IN ('jovahagyott', 'elutasitott') THEN
      v_can_approve := COALESCE(public.has_permission(v_uid, 'manage_schedule'), false)
                    OR COALESCE(public.has_permission(v_uid, 'manage_tenant'), false);
      IF NOT v_can_approve THEN
        INSERT INTO public.admin_audit_log(tenant_id, user_id, action, table_name, record_id, before_data, after_data)
        VALUES (COALESCE(NEW.tenant_id, public.current_tenant_id()), v_uid, 'FORBIDDEN_APPROVAL',
                TG_TABLE_NAME, NEW.id::text,
                jsonb_build_object('status', OLD.status),
                jsonb_build_object('status', NEW.status));
        RAISE EXCEPTION 'Nincs jogosultsága a jóváhagyáshoz/elutasításhoz.' USING ERRCODE = '42501';
      END IF;
      IF NEW.user_id = v_uid THEN
        RAISE EXCEPTION 'A saját kérelmét nem hagyhatja jóvá / utasíthatja el.' USING ERRCODE = '42501';
      END IF;
      IF NEW.status = 'elutasitott' AND COALESCE(btrim(NEW.jovahagyas_indok), '') = '' THEN
        RAISE EXCEPTION 'Elutasításhoz kötelező az indoklás.' USING ERRCODE = '22023';
      END IF;
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_profile_unavailability_guard ON public.profile_unavailability;
CREATE TRIGGER trg_profile_unavailability_guard
  BEFORE UPDATE ON public.profile_unavailability
  FOR EACH ROW EXECUTE FUNCTION public.profile_unavailability_guard();
