-- Ensure cms_promote_scheduled_pages is executable in every context it may be called from
GRANT EXECUTE ON FUNCTION public.cms_promote_scheduled_pages() TO anon, authenticated, service_role;