
-- A) Phase: tighten RLS policies (error-level + warn-level findings)

-- 1) clinical_calculator_results: add patient access check to DELETE/UPDATE
DROP POLICY IF EXISTS "creator deletes calc results" ON public.clinical_calculator_results;
CREATE POLICY "creator deletes calc results"
ON public.clinical_calculator_results FOR DELETE
USING (
  ((auth.uid() = created_by) OR has_role(auth.uid(), 'admin'::text))
  AND ((patient_id IS NULL) OR can_access_patient(patient_id))
);

DROP POLICY IF EXISTS "creator updates calc results" ON public.clinical_calculator_results;
CREATE POLICY "creator updates calc results"
ON public.clinical_calculator_results FOR UPDATE
USING (
  (auth.uid() = created_by)
  AND ((patient_id IS NULL) OR can_access_patient(patient_id))
)
WITH CHECK (
  (auth.uid() = created_by)
  AND ((patient_id IS NULL) OR can_access_patient(patient_id))
);

-- 2) clinical_therapy_orders: add patient access check to DELETE
DROP POLICY IF EXISTS "creator deletes therapy" ON public.clinical_therapy_orders;
CREATE POLICY "creator deletes therapy"
ON public.clinical_therapy_orders FOR DELETE
USING (
  ((auth.uid() = created_by) OR has_role(auth.uid(), 'admin'::text))
  AND can_access_patient(patient_id)
);

-- 3) clinical_weekly_vc: add patient access check to DELETE/UPDATE
DROP POLICY IF EXISTS "Author delete weekly vc" ON public.clinical_weekly_vc;
CREATE POLICY "Author delete weekly vc"
ON public.clinical_weekly_vc FOR DELETE
USING ((created_by = auth.uid()) AND can_access_patient(patient_id));

DROP POLICY IF EXISTS "Author update weekly vc" ON public.clinical_weekly_vc;
CREATE POLICY "Author update weekly vc"
ON public.clinical_weekly_vc FOR UPDATE
USING ((created_by = auth.uid()) AND can_access_patient(patient_id))
WITH CHECK ((created_by = auth.uid()) AND can_access_patient(patient_id));

-- 4) questionnaire_assignments: narrow staff SELECT to view_patient_data permission
DROP POLICY IF EXISTS qa_select_auth ON public.questionnaire_assignments;
CREATE POLICY qa_select_auth
ON public.questionnaire_assignments FOR SELECT
USING (
  tenant_id = current_tenant_id()
  AND (
    has_permission(auth.uid(), 'view_patient_data'::text)
    OR has_permission(auth.uid(), 'manage_patients'::text)
    OR assigned_by = auth.uid()
  )
);

-- 5) incompatibilities: harden INSERT with tenant + user check (already in WITH CHECK; re-affirm)
-- (current policy is fine, but explicit re-create to ensure tenant_id is required)
DROP POLICY IF EXISTS inc_insert ON public.incompatibilities;
CREATE POLICY inc_insert
ON public.incompatibilities FOR INSERT
WITH CHECK (
  tenant_id = current_tenant_id()
  AND user_id = auth.uid()
);

-- 6) profile_preferences: enforce tenant scope on all policies
DROP POLICY IF EXISTS profile_preferences_select ON public.profile_preferences;
CREATE POLICY profile_preferences_select
ON public.profile_preferences FOR SELECT
USING (
  tenant_id = current_tenant_id()
  AND (
    user_id = auth.uid()
    OR has_permission(auth.uid(), 'manage_schedule'::text)
    OR has_permission(auth.uid(), 'manage_tenant'::text)
  )
);

DROP POLICY IF EXISTS profile_preferences_write ON public.profile_preferences;
CREATE POLICY profile_preferences_write
ON public.profile_preferences FOR ALL
USING (
  tenant_id = current_tenant_id()
  AND (
    user_id = auth.uid()
    OR has_permission(auth.uid(), 'manage_tenant'::text)
  )
)
WITH CHECK (
  tenant_id = current_tenant_id()
  AND (
    user_id = auth.uid()
    OR has_permission(auth.uid(), 'manage_tenant'::text)
  )
);
