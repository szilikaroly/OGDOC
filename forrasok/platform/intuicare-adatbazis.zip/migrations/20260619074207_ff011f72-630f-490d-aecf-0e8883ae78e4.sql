
-- 1. org_units bővítés
ALTER TABLE public.org_units
  ADD COLUMN IF NOT EXISTS min_letszam_napi integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS max_letszam_napi integer,
  ADD COLUMN IF NOT EXISTS mukodes_kezd time,
  ADD COLUMN IF NOT EXISTS mukodes_veg time,
  ADD COLUMN IF NOT EXISTS parameterek jsonb NOT NULL DEFAULT '{}'::jsonb;

-- 2. staff_roles referencia-tábla (szerepkörök)
CREATE TABLE IF NOT EXISTS public.staff_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  kulcs text NOT NULL,
  nev text NOT NULL,
  leiras text,
  sorrend integer NOT NULL DEFAULT 100,
  aktiv boolean NOT NULL DEFAULT true,
  rendszerszintu boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, kulcs)
);
GRANT SELECT ON public.staff_roles TO authenticated;
GRANT ALL ON public.staff_roles TO service_role;
ALTER TABLE public.staff_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "staff_roles read in tenant or system"
  ON public.staff_roles FOR SELECT TO authenticated
  USING (rendszerszintu OR tenant_id = public.current_tenant_id());
CREATE POLICY "staff_roles manage by org admins"
  ON public.staff_roles FOR ALL TO authenticated
  USING (
    (tenant_id = public.current_tenant_id())
    AND public.has_permission(auth.uid(), 'manage_org')
  )
  WITH CHECK (
    (tenant_id = public.current_tenant_id())
    AND public.has_permission(auth.uid(), 'manage_org')
  );
CREATE TRIGGER trg_staff_roles_touch BEFORE UPDATE ON public.staff_roles
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- System seed (tenant_id NULL = rendszerszintű)
INSERT INTO public.staff_roles (tenant_id, kulcs, nev, sorrend, rendszerszintu) VALUES
  (NULL, 'aneszteziologus', 'Aneszteziológus orvos', 10, true),
  (NULL, 'sebesz_operator', 'Operatőr (sebész)',    20, true),
  (NULL, 'asszisztens',     'Aneszteziológiai asszisztens', 30, true),
  (NULL, 'mutosno',         'Műtősnő',              40, true),
  (NULL, 'mutostechnikus',  'Műtőstechnikus',       50, true),
  (NULL, 'szakdolgozo',     'Szakdolgozó',          60, true)
ON CONFLICT DO NOTHING;

-- 3. staffing_templates
CREATE TABLE IF NOT EXISTS public.staffing_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL DEFAULT public.current_tenant_id(),
  org_unit_id uuid NOT NULL REFERENCES public.org_units(id) ON DELETE CASCADE,
  nev text NOT NULL,
  leiras text,
  nap_bitmap smallint NOT NULL DEFAULT 127, -- bit0=Hé .. bit6=Va
  kezd_ido time NOT NULL,
  veg_ido time NOT NULL,
  kategoria text NOT NULL DEFAULT 'rendes' CHECK (kategoria IN ('rendes','ugyelet','keszenlet','sos')),
  ervenyes_tol date NOT NULL DEFAULT CURRENT_DATE,
  ervenyes_ig date,
  aktiv boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.staffing_templates TO authenticated;
GRANT ALL ON public.staffing_templates TO service_role;
ALTER TABLE public.staffing_templates ENABLE ROW LEVEL SECURITY;
CREATE POLICY "staffing_templates read in tenant"
  ON public.staffing_templates FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY "staffing_templates manage by org admins"
  ON public.staffing_templates FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_org'))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_org'));
CREATE TRIGGER trg_staffing_templates_touch BEFORE UPDATE ON public.staffing_templates
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE INDEX IF NOT EXISTS idx_staffing_templates_org ON public.staffing_templates(org_unit_id) WHERE aktiv;

-- 4. staffing_template_roles
CREATE TABLE IF NOT EXISTS public.staffing_template_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL DEFAULT public.current_tenant_id(),
  template_id uuid NOT NULL REFERENCES public.staffing_templates(id) ON DELETE CASCADE,
  staff_role_id uuid NOT NULL REFERENCES public.staff_roles(id) ON DELETE RESTRICT,
  skill_id uuid REFERENCES public.skills(id) ON DELETE SET NULL,
  min_letszam integer NOT NULL DEFAULT 1 CHECK (min_letszam >= 0),
  max_letszam integer CHECK (max_letszam IS NULL OR max_letszam >= min_letszam),
  kotelezo boolean NOT NULL DEFAULT true,
  sorrend integer NOT NULL DEFAULT 100,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.staffing_template_roles TO authenticated;
GRANT ALL ON public.staffing_template_roles TO service_role;
ALTER TABLE public.staffing_template_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "staffing_template_roles read in tenant"
  ON public.staffing_template_roles FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY "staffing_template_roles manage by org admins"
  ON public.staffing_template_roles FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_org'))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_org'));
CREATE TRIGGER trg_staffing_template_roles_touch BEFORE UPDATE ON public.staffing_template_roles
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE INDEX IF NOT EXISTS idx_stpl_roles_template ON public.staffing_template_roles(template_id);

-- 5. RPC: napi shift-igénylista generálása
CREATE OR REPLACE FUNCTION public.generate_demand_for_period(
  _org_unit_id uuid,
  _from date,
  _to date
)
RETURNS TABLE (
  datum date,
  template_id uuid,
  template_nev text,
  kezd_ido time,
  veg_ido time,
  kategoria text,
  staff_role_id uuid,
  staff_role_kulcs text,
  staff_role_nev text,
  skill_id uuid,
  min_letszam integer,
  max_letszam integer,
  kotelezo boolean
)
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  WITH napok AS (
    SELECT d::date AS datum, EXTRACT(isodow FROM d)::int - 1 AS dow_idx
    FROM generate_series(_from::timestamp, _to::timestamp, interval '1 day') d
  )
  SELECT n.datum,
         t.id, t.nev, t.kezd_ido, t.veg_ido, t.kategoria,
         r.staff_role_id, sr.kulcs, sr.nev,
         r.skill_id, r.min_letszam, r.max_letszam, r.kotelezo
  FROM napok n
  CROSS JOIN public.staffing_templates t
  JOIN public.staffing_template_roles r ON r.template_id = t.id
  JOIN public.staff_roles sr ON sr.id = r.staff_role_id
  WHERE t.org_unit_id = _org_unit_id
    AND t.aktiv
    AND t.tenant_id = public.current_tenant_id()
    AND t.ervenyes_tol <= n.datum
    AND (t.ervenyes_ig IS NULL OR t.ervenyes_ig >= n.datum)
    AND (t.nap_bitmap & (1 << n.dow_idx)) <> 0
  ORDER BY n.datum, t.kezd_ido, r.sorrend;
$$;
