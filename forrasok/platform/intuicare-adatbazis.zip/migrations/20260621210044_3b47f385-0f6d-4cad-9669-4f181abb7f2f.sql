
-- Link organization OR units to the surgical plan board automatically.
-- An or_room_profile (+ a default or_suite per site) is auto-created for every
-- org_unit of type muto/kismuto, and kept active in sync with the unit.

CREATE OR REPLACE FUNCTION public.ensure_default_or_suite(_tenant_id uuid, _site_id uuid)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _suite_id uuid;
BEGIN
  IF _site_id IS NULL THEN
    RETURN NULL;
  END IF;
  SELECT id INTO _suite_id
    FROM public.or_suites
   WHERE tenant_id = _tenant_id AND site_id = _site_id
   ORDER BY created_at ASC
   LIMIT 1;
  IF _suite_id IS NULL THEN
    INSERT INTO public.or_suites (tenant_id, site_id, nev, aktiv)
    VALUES (_tenant_id, _site_id, 'Központi műtőblokk', true)
    RETURNING id INTO _suite_id;
  END IF;
  RETURN _suite_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.sync_or_room_profile_from_org_unit()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _suite_id uuid;
  _tipus or_tipus_enum;
  _is_or boolean;
BEGIN
  _is_or := NEW.tipus IN ('muto','kismuto');

  -- If unit is no longer an OR or became inactive, deactivate its profile.
  IF NOT _is_or OR NEW.aktiv = false THEN
    UPDATE public.or_room_profiles
       SET aktiv = false, updated_at = now()
     WHERE org_unit_id = NEW.id;
    RETURN NEW;
  END IF;

  IF NEW.site_id IS NULL THEN
    RETURN NEW; -- can't allocate a suite without a site
  END IF;

  _tipus := CASE NEW.tipus
              WHEN 'kismuto' THEN 'egynapos_kismuteti'::or_tipus_enum
              ELSE 'altalanos'::or_tipus_enum
            END;
  _suite_id := public.ensure_default_or_suite(NEW.tenant_id, NEW.site_id);

  INSERT INTO public.or_room_profiles (tenant_id, org_unit_id, or_suite_id, tipus, aktiv)
  VALUES (NEW.tenant_id, NEW.id, _suite_id, _tipus, true)
  ON CONFLICT (org_unit_id) DO UPDATE
    SET aktiv = true,
        or_suite_id = COALESCE(public.or_room_profiles.or_suite_id, EXCLUDED.or_suite_id),
        updated_at = now();

  RETURN NEW;
END;
$$;

-- Need a unique constraint on org_unit_id for ON CONFLICT to work.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes
     WHERE schemaname = 'public'
       AND indexname = 'or_room_profiles_org_unit_id_key'
  ) THEN
    -- Drop any duplicate rows first so the unique index can be created.
    DELETE FROM public.or_room_profiles a
     USING public.or_room_profiles b
     WHERE a.org_unit_id = b.org_unit_id AND a.ctid < b.ctid;
    CREATE UNIQUE INDEX or_room_profiles_org_unit_id_key
      ON public.or_room_profiles (org_unit_id);
  END IF;
END $$;

DROP TRIGGER IF EXISTS trg_sync_or_room_profile ON public.org_units;
CREATE TRIGGER trg_sync_or_room_profile
AFTER INSERT OR UPDATE OF tipus, aktiv, site_id, tenant_id ON public.org_units
FOR EACH ROW EXECUTE FUNCTION public.sync_or_room_profile_from_org_unit();

-- Backfill existing OR units.
INSERT INTO public.or_room_profiles (tenant_id, org_unit_id, or_suite_id, tipus, aktiv)
SELECT u.tenant_id,
       u.id,
       public.ensure_default_or_suite(u.tenant_id, u.site_id),
       CASE u.tipus WHEN 'kismuto' THEN 'egynapos_kismuteti'::or_tipus_enum
                    ELSE 'altalanos'::or_tipus_enum END,
       true
  FROM public.org_units u
 WHERE u.tipus IN ('muto','kismuto')
   AND u.aktiv = true
   AND u.site_id IS NOT NULL
ON CONFLICT (org_unit_id) DO UPDATE
  SET aktiv = true,
      or_suite_id = COALESCE(public.or_room_profiles.or_suite_id, EXCLUDED.or_suite_id),
      updated_at = now();
