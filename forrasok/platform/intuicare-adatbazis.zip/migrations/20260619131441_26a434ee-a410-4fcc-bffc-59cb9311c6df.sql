
-- ====== ENUMOK ======
CREATE TYPE public.or_tipus_enum AS ENUM
  ('altalanos','szuloszoba','egynapos_kismuteti','onkosebeszet','reproduktiv','hibrid','lezer','robot');

CREATE TYPE public.or_eroforras_tipus_enum AS ENUM
  ('aneszteziologus','mutos_szakdolgozo','cssd_keszlet','pito_agy','ito_agy','pacu_ebredo',
   'verkeszitmeny','kepalkotas_intraop','patologia_fagyasztott','robot_konzol','embriologiai_labor',
   'neonatologus','lezer_eszkoz','implantatum');

CREATE TYPE public.or_block_statusz_enum AS ENUM ('allokalt','felszabaditott','lezart');
CREATE TYPE public.or_case_statusz_enum  AS ENUM ('tervezett','jovahagyott','folyamatban','elvegzett','elhalasztott','torolt');
CREATE TYPE public.or_case_prioritas_enum AS ENUM ('elektiv','sürgos','azonnali');
CREATE TYPE public.or_resource_req_when_enum AS ENUM ('intraop','posztop');
CREATE TYPE public.or_resource_req_status_enum AS ENUM ('igenyelt','foglalt','nem_elerheto');

-- ====== OR_SUITES ======
CREATE TABLE public.or_suites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  site_id uuid NOT NULL REFERENCES public.sites(id) ON DELETE CASCADE,
  nev text NOT NULL,
  tartalek_muto_szam int NOT NULL DEFAULT 0 CHECK (tartalek_muto_szam >= 0),
  surgossegi_keret_perc int NOT NULL DEFAULT 0 CHECK (surgossegi_keret_perc >= 0),
  aktiv boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.or_suites TO authenticated;
GRANT ALL ON public.or_suites TO service_role;
ALTER TABLE public.or_suites ENABLE ROW LEVEL SECURITY;
CREATE POLICY "or_suites_select_tenant" ON public.or_suites FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY "or_suites_write_managers" ON public.or_suites FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_schedule')
              OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id()
              AND (public.has_permission(auth.uid(),'manage_schedule')
                   OR public.has_permission(auth.uid(),'manage_tenant')));
CREATE TRIGGER or_suites_touch BEFORE UPDATE ON public.or_suites
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER or_suites_audit AFTER INSERT OR UPDATE OR DELETE ON public.or_suites
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ====== OR_ROOM_PROFILES (extends org_units) ======
CREATE TABLE public.or_room_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  org_unit_id uuid NOT NULL UNIQUE REFERENCES public.org_units(id) ON DELETE CASCADE,
  or_suite_id uuid NOT NULL REFERENCES public.or_suites(id) ON DELETE RESTRICT,
  tipus public.or_tipus_enum NOT NULL DEFAULT 'altalanos',
  tartalek boolean NOT NULL DEFAULT false,
  napi_kezdo_ido time NOT NULL DEFAULT '08:00',
  napi_veg_ido   time NOT NULL DEFAULT '16:00',
  fordulo_ido_perc int NOT NULL DEFAULT 30 CHECK (fordulo_ido_perc >= 0),
  aktiv boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.or_room_profiles TO authenticated;
GRANT ALL ON public.or_room_profiles TO service_role;
ALTER TABLE public.or_room_profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "or_room_profiles_select_tenant" ON public.or_room_profiles FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY "or_room_profiles_write_managers" ON public.or_room_profiles FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_schedule')
              OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id()
              AND (public.has_permission(auth.uid(),'manage_schedule')
                   OR public.has_permission(auth.uid(),'manage_tenant')));
CREATE TRIGGER or_room_profiles_touch BEFORE UPDATE ON public.or_room_profiles
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER or_room_profiles_audit AFTER INSERT OR UPDATE OR DELETE ON public.or_room_profiles
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ====== OR_RESOURCES ======
CREATE TABLE public.or_resources (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  site_id uuid NOT NULL REFERENCES public.sites(id) ON DELETE CASCADE,
  tipus public.or_eroforras_tipus_enum NOT NULL,
  nev text,
  keszlet_db int NOT NULL DEFAULT 1 CHECK (keszlet_db >= 0),
  megosztott boolean NOT NULL DEFAULT false,
  aktiv boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.or_resources TO authenticated;
GRANT ALL ON public.or_resources TO service_role;
ALTER TABLE public.or_resources ENABLE ROW LEVEL SECURITY;
CREATE POLICY "or_resources_select_tenant" ON public.or_resources FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY "or_resources_write_managers" ON public.or_resources FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_schedule')
              OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id()
              AND (public.has_permission(auth.uid(),'manage_schedule')
                   OR public.has_permission(auth.uid(),'manage_tenant')));
CREATE TRIGGER or_resources_touch BEFORE UPDATE ON public.or_resources
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER or_resources_audit AFTER INSERT OR UPDATE OR DELETE ON public.or_resources
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ====== OR_BLOCKS ======
CREATE TABLE public.or_blocks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  org_unit_id uuid NOT NULL REFERENCES public.org_units(id) ON DELETE CASCADE,
  datum date NOT NULL,
  kezdo_ido time NOT NULL,
  veg_ido   time NOT NULL,
  specialty_id uuid REFERENCES public.specialties(id) ON DELETE SET NULL,
  sebesz_user_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  statusz public.or_block_statusz_enum NOT NULL DEFAULT 'allokalt',
  felszabaditasi_hatarido timestamptz,
  ismetlodo_szabaly text,
  surgossegi_keret boolean NOT NULL DEFAULT false,
  megjegyzes text,
  created_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (veg_ido > kezdo_ido)
);
CREATE INDEX or_blocks_org_unit_datum_idx ON public.or_blocks (org_unit_id, datum);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.or_blocks TO authenticated;
GRANT ALL ON public.or_blocks TO service_role;
ALTER TABLE public.or_blocks ENABLE ROW LEVEL SECURITY;
CREATE POLICY "or_blocks_select_tenant" ON public.or_blocks FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY "or_blocks_write_managers" ON public.or_blocks FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_schedule')
              OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id()
              AND (public.has_permission(auth.uid(),'manage_schedule')
                   OR public.has_permission(auth.uid(),'manage_tenant')));
CREATE TRIGGER or_blocks_touch BEFORE UPDATE ON public.or_blocks
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER or_blocks_audit AFTER INSERT OR UPDATE OR DELETE ON public.or_blocks
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ====== SURGERY_TYPES ======
CREATE TABLE public.surgery_types (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  beavatkozas_id uuid REFERENCES public.beavatkozasok(id) ON DELETE SET NULL,
  kod text,
  nev text NOT NULL,
  kotelezo_muto_tipus public.or_tipus_enum,
  becsult_idotartam_perc int NOT NULL DEFAULT 60 CHECK (becsult_idotartam_perc > 0),
  posztop_apolasi_perc int NOT NULL DEFAULT 0 CHECK (posztop_apolasi_perc >= 0),
  szukseges_szerepek jsonb NOT NULL DEFAULT '[]'::jsonb,   -- [{staff_role_kulcs, letszam}]
  szukseges_skillek jsonb NOT NULL DEFAULT '[]'::jsonb,    -- [skill_id]
  kotelezo_eroforrasok jsonb NOT NULL DEFAULT '[]'::jsonb, -- [{tipus, mennyiseg, mikortol}]
  aktiv boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.surgery_types TO authenticated;
GRANT ALL ON public.surgery_types TO service_role;
ALTER TABLE public.surgery_types ENABLE ROW LEVEL SECURITY;
CREATE POLICY "surgery_types_select_tenant" ON public.surgery_types FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY "surgery_types_write_managers" ON public.surgery_types FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_schedule')
              OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id()
              AND (public.has_permission(auth.uid(),'manage_schedule')
                   OR public.has_permission(auth.uid(),'manage_tenant')));
CREATE TRIGGER surgery_types_touch BEFORE UPDATE ON public.surgery_types
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER surgery_types_audit AFTER INSERT OR UPDATE OR DELETE ON public.surgery_types
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ====== SURGERY_CASES ======
CREATE TABLE public.surgery_cases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE RESTRICT,
  surgery_type_id uuid REFERENCES public.surgery_types(id) ON DELETE SET NULL,
  or_block_id uuid REFERENCES public.or_blocks(id) ON DELETE SET NULL,
  becsult_idotartam_perc int NOT NULL CHECK (becsult_idotartam_perc > 0),
  posztop_apolasi_perc int NOT NULL DEFAULT 0 CHECK (posztop_apolasi_perc >= 0),
  prioritas public.or_case_prioritas_enum NOT NULL DEFAULT 'elektiv',
  statusz public.or_case_statusz_enum NOT NULL DEFAULT 'tervezett',
  tervezett_kezdo_ido timestamptz,
  tenyleges_kezdo_ido timestamptz,
  tenyleges_veg_ido timestamptz,
  jovahagyta_user_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  jovahagyas_at timestamptz,
  megjegyzes text,
  created_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX surgery_cases_block_idx ON public.surgery_cases (or_block_id);
CREATE INDEX surgery_cases_patient_idx ON public.surgery_cases (patient_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.surgery_cases TO authenticated;
GRANT ALL ON public.surgery_cases TO service_role;
ALTER TABLE public.surgery_cases ENABLE ROW LEVEL SECURITY;
CREATE POLICY "surgery_cases_select_tenant" ON public.surgery_cases FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY "surgery_cases_write_managers" ON public.surgery_cases FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_schedule')
              OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id()
              AND (public.has_permission(auth.uid(),'manage_schedule')
                   OR public.has_permission(auth.uid(),'manage_tenant')));
CREATE TRIGGER surgery_cases_touch BEFORE UPDATE ON public.surgery_cases
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER surgery_cases_audit AFTER INSERT OR UPDATE OR DELETE ON public.surgery_cases
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ====== CASE_RESOURCE_REQUIREMENTS ======
CREATE TABLE public.case_resource_requirements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  surgery_case_id uuid NOT NULL REFERENCES public.surgery_cases(id) ON DELETE CASCADE,
  eroforras_tipus public.or_eroforras_tipus_enum NOT NULL,
  mennyiseg int NOT NULL DEFAULT 1 CHECK (mennyiseg > 0),
  mikortol public.or_resource_req_when_enum NOT NULL DEFAULT 'intraop',
  foglalas_statusz public.or_resource_req_status_enum NOT NULL DEFAULT 'igenyelt',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX case_resource_req_case_idx ON public.case_resource_requirements (surgery_case_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.case_resource_requirements TO authenticated;
GRANT ALL ON public.case_resource_requirements TO service_role;
ALTER TABLE public.case_resource_requirements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "case_res_req_select_tenant" ON public.case_resource_requirements FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY "case_res_req_write_managers" ON public.case_resource_requirements FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_schedule')
              OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id()
              AND (public.has_permission(auth.uid(),'manage_schedule')
                   OR public.has_permission(auth.uid(),'manage_tenant')));
CREATE TRIGGER case_res_req_touch BEFORE UPDATE ON public.case_resource_requirements
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER case_res_req_audit AFTER INSERT OR UPDATE OR DELETE ON public.case_resource_requirements
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ====== RESOURCE_BOOKINGS ======
CREATE TABLE public.resource_bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  or_resource_id uuid NOT NULL REFERENCES public.or_resources(id) ON DELETE CASCADE,
  surgery_case_id uuid REFERENCES public.surgery_cases(id) ON DELETE CASCADE,
  datum date NOT NULL,
  kezdo_ido time NOT NULL,
  veg_ido   time NOT NULL,
  mennyiseg int NOT NULL DEFAULT 1 CHECK (mennyiseg > 0),
  megjegyzes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (veg_ido > kezdo_ido)
);
CREATE INDEX resource_bookings_res_date_idx ON public.resource_bookings (or_resource_id, datum);
CREATE INDEX resource_bookings_case_idx ON public.resource_bookings (surgery_case_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.resource_bookings TO authenticated;
GRANT ALL ON public.resource_bookings TO service_role;
ALTER TABLE public.resource_bookings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "resource_bookings_select_tenant" ON public.resource_bookings FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY "resource_bookings_write_managers" ON public.resource_bookings FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_schedule')
              OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id()
              AND (public.has_permission(auth.uid(),'manage_schedule')
                   OR public.has_permission(auth.uid(),'manage_tenant')));
CREATE TRIGGER resource_bookings_touch BEFORE UPDATE ON public.resource_bookings
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER resource_bookings_audit AFTER INSERT OR UPDATE OR DELETE ON public.resource_bookings
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();
