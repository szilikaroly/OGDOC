
-- Konfliktus-nézet: ellátóhely → érintett sorok / kötelező lefedés / üres eligibility
CREATE OR REPLACE VIEW public.org_unit_conflicts AS
SELECT
  ou.id AS org_unit_id,
  ou.tenant_id,
  COUNT(DISTINCT dlc.duty_line_id) FILTER (WHERE dlc.duty_line_id IS NOT NULL) AS duty_lines_count,
  COUNT(DISTINCT dlc.duty_line_id) FILTER (WHERE dlc.kotelezo) AS mandatory_coverage_count,
  COUNT(DISTINCT dl.id) FILTER (
    WHERE dl.id IS NOT NULL AND NOT EXISTS (
      SELECT 1 FROM public.duty_line_eligibility e WHERE e.duty_line_id = dl.id
    )
  ) AS duty_lines_without_eligibility
FROM public.org_units ou
LEFT JOIN public.duty_line_coverage dlc ON dlc.org_unit_id = ou.id
LEFT JOIN public.duty_lines dl ON dl.id = dlc.duty_line_id AND dl.aktiv = true
GROUP BY ou.id, ou.tenant_id;

GRANT SELECT ON public.org_unit_conflicts TO authenticated;

-- Seed: új tenant alap konfiguráció
CREATE OR REPLACE FUNCTION public.seed_default_org_for_tenant(_tenant_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_clinic uuid;
  v_site uuid;
  v_osztaly uuid;
  v_muto uuid;
  v_dl_nappal uuid;
  v_dl_ejjel uuid;
  v_dl_hatter uuid;
  v_existing int;
BEGIN
  -- jogosultság-ellenőrzés
  IF NOT public.has_permission(auth.uid(), 'manage_tenant') THEN
    RAISE EXCEPTION 'manage_tenant jogosultság szükséges';
  END IF;

  SELECT COUNT(*) INTO v_existing FROM public.clinics WHERE tenant_id = _tenant_id;
  IF v_existing > 0 THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'already_initialized');
  END IF;

  INSERT INTO public.clinics (tenant_id, nev) VALUES (_tenant_id, 'Minta Klinika') RETURNING id INTO v_clinic;
  INSERT INTO public.sites (tenant_id, clinic_id, nev, cim) VALUES (_tenant_id, v_clinic, 'Központi telephely', '—') RETURNING id INTO v_site;

  INSERT INTO public.floors (tenant_id, site_id, szint, megnevezes, sorrend) VALUES
    (_tenant_id, v_site, '-1', 'Pince', 1),
    (_tenant_id, v_site, '0',  'Földszint', 2),
    (_tenant_id, v_site, '1',  '1. emelet', 3);

  INSERT INTO public.org_units (tenant_id, site_id, nev, tipus, uzemmod, agyszam)
    VALUES (_tenant_id, v_site, 'Belgyógyászati osztály', 'osztaly', 'folyamatos_24_7', 24) RETURNING id INTO v_osztaly;

  INSERT INTO public.org_units (tenant_id, site_id, nev, tipus, uzemmod, muto_blokk_perc)
    VALUES (_tenant_id, v_site, 'Központi műtő', 'muto', 'muteti_blokk', 480) RETURNING id INTO v_muto;

  INSERT INTO public.duty_lines (tenant_id, site_id, nev, kod, szerep_tipus, primary_org_unit_id, letszam, napok, kezd_ido, veg_ido, aktiv)
    VALUES (_tenant_id, v_site, 'Belgyógyászat nappali', 'BELGY_NAP', 'nappali_ugyelet', v_osztaly, 2, ARRAY[1,2,3,4,5,6,7], '08:00', '20:00', true) RETURNING id INTO v_dl_nappal;

  INSERT INTO public.duty_lines (tenant_id, site_id, nev, kod, szerep_tipus, primary_org_unit_id, letszam, napok, kezd_ido, veg_ido, aktiv)
    VALUES (_tenant_id, v_site, 'Belgyógyászat éjszakai', 'BELGY_EJ', 'ejszakai_ugyelet', v_osztaly, 1, ARRAY[1,2,3,4,5,6,7], '20:00', '08:00', true) RETURNING id INTO v_dl_ejjel;

  INSERT INTO public.duty_lines (tenant_id, site_id, nev, kod, szerep_tipus, primary_org_unit_id, letszam, napok, kezd_ido, veg_ido, aktiv)
    VALUES (_tenant_id, v_site, 'Telephelyi háttér', 'HATTER', 'hatter_ugyelet', v_osztaly, 1, ARRAY[1,2,3,4,5,6,7], '00:00', '23:59', true) RETURNING id INTO v_dl_hatter;

  INSERT INTO public.duty_line_coverage (tenant_id, duty_line_id, org_unit_id, kotelezo) VALUES
    (_tenant_id, v_dl_nappal, v_osztaly, true),
    (_tenant_id, v_dl_ejjel,  v_osztaly, true),
    (_tenant_id, v_dl_hatter, v_osztaly, true),
    (_tenant_id, v_dl_hatter, v_muto,    false);

  INSERT INTO public.duty_line_eligibility (tenant_id, duty_line_id, foglalkozas_tipus, prioritas) VALUES
    (_tenant_id, v_dl_nappal, 'orvos', 0),
    (_tenant_id, v_dl_ejjel,  'orvos', 0),
    (_tenant_id, v_dl_hatter, 'orvos', 0);

  RETURN jsonb_build_object(
    'ok', true,
    'clinic_id', v_clinic,
    'site_id', v_site,
    'org_units', jsonb_build_array(v_osztaly, v_muto),
    'duty_lines', jsonb_build_array(v_dl_nappal, v_dl_ejjel, v_dl_hatter)
  );
END;
$$;

REVOKE EXECUTE ON FUNCTION public.seed_default_org_for_tenant(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.seed_default_org_for_tenant(uuid) TO authenticated;
