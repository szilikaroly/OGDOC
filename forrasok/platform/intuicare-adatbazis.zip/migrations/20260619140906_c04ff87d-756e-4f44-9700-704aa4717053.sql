
CREATE TYPE public.appt_resource_tipus AS ENUM ('orvos','rendelo','mindketto');
CREATE TYPE public.appt_slot_status AS ENUM ('szabad','foglalt','letiltott','torolt');
CREATE TYPE public.appt_status AS ENUM ('foglalt','megerositendo','lemondva','megerkezett','befejezett','nem_jelent_meg');
CREATE TYPE public.appt_sync_statusz AS ENUM ('local_only','pending','synced','conflict','failed');
CREATE TYPE public.checkin_method AS ENUM ('qr','kiosk','mobile');
CREATE TYPE public.checkin_status AS ENUM ('arrived','in_room','done');
CREATE TYPE public.q_mode AS ENUM ('klinikai','egeszsegfejlesztesi','vegyes');
CREATE TYPE public.q_licenc AS ENUM ('free','public_domain','who_noncommercial','euroqol_licensed','pearson_blocked');
CREATE TYPE public.q_assignment_status AS ENUM ('assigned','in_progress','completed','expired','cancelled');
CREATE TYPE public.critical_alert_status AS ENUM ('open','acknowledged','resolved');

CREATE TABLE public.feature_flags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  kulcs text NOT NULL,
  enabled boolean NOT NULL DEFAULT false,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, kulcs)
);
GRANT SELECT ON public.feature_flags TO authenticated;
GRANT ALL ON public.feature_flags TO service_role;
ALTER TABLE public.feature_flags ENABLE ROW LEVEL SECURITY;
CREATE POLICY ff_select ON public.feature_flags FOR SELECT TO authenticated
  USING (tenant_id IS NULL OR tenant_id = public.current_tenant_id());
CREATE POLICY ff_write ON public.feature_flags FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_tenant'))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_tenant'));
CREATE TRIGGER trg_ff_touch BEFORE UPDATE ON public.feature_flags FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER trg_ff_audit AFTER INSERT OR UPDATE OR DELETE ON public.feature_flags FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

CREATE TABLE public.appointment_resources (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  nev text NOT NULL,
  tipus public.appt_resource_tipus NOT NULL,
  orvos_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  org_unit_id uuid REFERENCES public.org_units(id) ON DELETE SET NULL,
  szakma_id uuid REFERENCES public.specialties(id) ON DELETE SET NULL,
  aktiv boolean NOT NULL DEFAULT true,
  publikus boolean NOT NULL DEFAULT true,
  szin text,
  leiras text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (orvos_id IS NOT NULL OR org_unit_id IS NOT NULL)
);
CREATE INDEX appt_resources_tenant_idx ON public.appointment_resources(tenant_id, aktiv);
GRANT SELECT ON public.appointment_resources TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.appointment_resources TO authenticated;
GRANT ALL ON public.appointment_resources TO service_role;
ALTER TABLE public.appointment_resources ENABLE ROW LEVEL SECURITY;
CREATE POLICY ar_public_read ON public.appointment_resources FOR SELECT TO anon
  USING (aktiv AND publikus);
CREATE POLICY ar_select ON public.appointment_resources FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() OR (aktiv AND publikus));
CREATE POLICY ar_write ON public.appointment_resources FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_schedule') OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_schedule') OR public.has_permission(auth.uid(),'manage_tenant')));
CREATE TRIGGER trg_ar_touch BEFORE UPDATE ON public.appointment_resources FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER trg_ar_audit AFTER INSERT OR UPDATE OR DELETE ON public.appointment_resources FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

CREATE TABLE public.appointment_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  resource_id uuid NOT NULL REFERENCES public.appointment_resources(id) ON DELETE CASCADE,
  nev text NOT NULL,
  napok smallint[] NOT NULL,
  kezd_ido time NOT NULL,
  veg_ido time NOT NULL,
  slot_perc smallint NOT NULL DEFAULT 15 CHECK (slot_perc BETWEEN 5 AND 240),
  kapacitas smallint NOT NULL DEFAULT 1 CHECK (kapacitas > 0),
  ervenyes_tol date NOT NULL DEFAULT CURRENT_DATE,
  ervenyes_ig date,
  unnepnap_uzemel boolean NOT NULL DEFAULT false,
  aktiv boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (veg_ido > kezd_ido)
);
CREATE INDEX appt_tpl_resource_idx ON public.appointment_templates(resource_id, aktiv);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.appointment_templates TO authenticated;
GRANT ALL ON public.appointment_templates TO service_role;
ALTER TABLE public.appointment_templates ENABLE ROW LEVEL SECURITY;
CREATE POLICY at_select ON public.appointment_templates FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY at_write ON public.appointment_templates FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_schedule') OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_schedule') OR public.has_permission(auth.uid(),'manage_tenant')));
CREATE TRIGGER trg_at_touch BEFORE UPDATE ON public.appointment_templates FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER trg_at_audit AFTER INSERT OR UPDATE OR DELETE ON public.appointment_templates FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

CREATE TABLE public.appointment_slots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  resource_id uuid NOT NULL REFERENCES public.appointment_resources(id) ON DELETE CASCADE,
  org_unit_id uuid REFERENCES public.org_units(id) ON DELETE SET NULL,
  template_id uuid REFERENCES public.appointment_templates(id) ON DELETE SET NULL,
  kezdo_ts timestamptz NOT NULL,
  veg_ts timestamptz NOT NULL,
  kapacitas smallint NOT NULL DEFAULT 1,
  foglalt_szam smallint NOT NULL DEFAULT 0,
  status public.appt_slot_status NOT NULL DEFAULT 'szabad',
  version int NOT NULL DEFAULT 1,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (veg_ts > kezdo_ts),
  CHECK (foglalt_szam >= 0 AND foglalt_szam <= kapacitas)
);
CREATE UNIQUE INDEX appt_slot_unique_active ON public.appointment_slots(resource_id, kezdo_ts)
  WHERE status <> 'torolt';
CREATE INDEX appt_slot_lookup_idx ON public.appointment_slots(tenant_id, resource_id, kezdo_ts);
CREATE INDEX appt_slot_status_idx ON public.appointment_slots(status, kezdo_ts);
GRANT SELECT ON public.appointment_slots TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.appointment_slots TO authenticated;
GRANT ALL ON public.appointment_slots TO service_role;
ALTER TABLE public.appointment_slots ENABLE ROW LEVEL SECURITY;
CREATE POLICY as_public_read ON public.appointment_slots FOR SELECT TO anon
  USING (status = 'szabad' AND kezdo_ts > now());
CREATE POLICY as_select ON public.appointment_slots FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() OR (status = 'szabad' AND kezdo_ts > now()));
CREATE POLICY as_write ON public.appointment_slots FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_schedule') OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_schedule') OR public.has_permission(auth.uid(),'manage_tenant')));
CREATE TRIGGER trg_as_touch BEFORE UPDATE ON public.appointment_slots FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER trg_as_audit AFTER INSERT OR UPDATE OR DELETE ON public.appointment_slots FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

CREATE TABLE public.appointments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  slot_id uuid NOT NULL REFERENCES public.appointment_slots(id) ON DELETE RESTRICT,
  resource_id uuid NOT NULL REFERENCES public.appointment_resources(id) ON DELETE RESTRICT,
  patient_id uuid REFERENCES public.patients(id) ON DELETE SET NULL,
  vendeg_nev text,
  vendeg_email text,
  vendeg_telefon text,
  vendeg_szuletesi_datum date,
  ok text,
  megjegyzes text,
  foglalas_kod text NOT NULL UNIQUE,
  email_megerositve_at timestamptz,
  status public.appt_status NOT NULL DEFAULT 'megerositendo',
  eeszt_idopont_id text,
  sync_statusz public.appt_sync_statusz NOT NULL DEFAULT 'local_only',
  external_ref text,
  idempotency_key uuid NOT NULL DEFAULT gen_random_uuid(),
  version int NOT NULL DEFAULT 1,
  gdpr_consent_at timestamptz,
  created_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (patient_id IS NOT NULL OR vendeg_nev IS NOT NULL)
);
CREATE INDEX appt_slot_idx ON public.appointments(slot_id);
CREATE INDEX appt_patient_idx ON public.appointments(patient_id);
CREATE INDEX appt_status_idx ON public.appointments(tenant_id, status);
CREATE INDEX appt_kod_idx ON public.appointments(foglalas_kod);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.appointments TO authenticated;
GRANT ALL ON public.appointments TO service_role;
ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;
CREATE POLICY ap_select ON public.appointments FOR SELECT TO authenticated
  USING (
    tenant_id = public.current_tenant_id()
    AND (
      public.has_permission(auth.uid(),'manage_schedule')
      OR public.has_permission(auth.uid(),'manage_tenant')
      OR public.has_permission(auth.uid(),'manage_patients')
      OR public.has_permission(auth.uid(),'view_team')
    )
  );
CREATE POLICY ap_write ON public.appointments FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_schedule') OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_schedule') OR public.has_permission(auth.uid(),'manage_tenant')));
CREATE TRIGGER trg_appt_touch BEFORE UPDATE ON public.appointments FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER trg_appt_audit AFTER INSERT OR UPDATE OR DELETE ON public.appointments FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

CREATE TABLE public.appointment_status_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  appointment_id uuid NOT NULL REFERENCES public.appointments(id) ON DELETE CASCADE,
  from_status public.appt_status,
  to_status public.appt_status NOT NULL,
  actor_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  reason text,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX appt_ev_idx ON public.appointment_status_events(appointment_id, created_at);
GRANT SELECT, INSERT ON public.appointment_status_events TO authenticated;
GRANT ALL ON public.appointment_status_events TO service_role;
ALTER TABLE public.appointment_status_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY ase_select ON public.appointment_status_events FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY ase_insert ON public.appointment_status_events FOR INSERT TO authenticated
  WITH CHECK (tenant_id = public.current_tenant_id());

CREATE TABLE public.patient_checkin (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  appointment_id uuid NOT NULL REFERENCES public.appointments(id) ON DELETE CASCADE,
  patient_id uuid REFERENCES public.patients(id) ON DELETE SET NULL,
  method public.checkin_method NOT NULL,
  status public.checkin_status NOT NULL DEFAULT 'arrived',
  queue_position int,
  checkin_ts timestamptz NOT NULL DEFAULT now(),
  called_ts timestamptz,
  done_ts timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX checkin_appt_idx ON public.patient_checkin(appointment_id);
CREATE INDEX checkin_queue_idx ON public.patient_checkin(tenant_id, status, checkin_ts);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.patient_checkin TO authenticated;
GRANT INSERT ON public.patient_checkin TO anon;
GRANT ALL ON public.patient_checkin TO service_role;
ALTER TABLE public.patient_checkin ENABLE ROW LEVEL SECURITY;
CREATE POLICY pc_select ON public.patient_checkin FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY pc_write ON public.patient_checkin FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id())
  WITH CHECK (tenant_id = public.current_tenant_id());
CREATE TRIGGER trg_pc_touch BEFORE UPDATE ON public.patient_checkin FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER trg_pc_audit AFTER INSERT OR UPDATE OR DELETE ON public.patient_checkin FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

CREATE TABLE public.questionnaires (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  code text NOT NULL,
  title text NOT NULL,
  leiras text,
  language text NOT NULL DEFAULT 'hu',
  items jsonb NOT NULL,
  scoring jsonb NOT NULL DEFAULT '{}'::jsonb,
  cutoffs jsonb NOT NULL DEFAULT '{}'::jsonb,
  licenc public.q_licenc NOT NULL,
  mode public.q_mode NOT NULL,
  critical_item_index int,
  critical_threshold int,
  aktiv boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, code, language)
);
GRANT SELECT ON public.questionnaires TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.questionnaires TO authenticated;
GRANT ALL ON public.questionnaires TO service_role;
ALTER TABLE public.questionnaires ENABLE ROW LEVEL SECURITY;
CREATE POLICY q_select ON public.questionnaires FOR SELECT TO anon
  USING (aktiv AND tenant_id IS NULL);
CREATE POLICY q_select_auth ON public.questionnaires FOR SELECT TO authenticated
  USING (aktiv AND (tenant_id IS NULL OR tenant_id = public.current_tenant_id()));
CREATE POLICY q_write ON public.questionnaires FOR ALL TO authenticated
  USING ((tenant_id = public.current_tenant_id() OR tenant_id IS NULL)
         AND public.has_permission(auth.uid(),'manage_tenant'))
  WITH CHECK ((tenant_id = public.current_tenant_id() OR tenant_id IS NULL)
         AND public.has_permission(auth.uid(),'manage_tenant'));
CREATE TRIGGER trg_q_touch BEFORE UPDATE ON public.questionnaires FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TABLE public.questionnaire_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  questionnaire_id uuid NOT NULL REFERENCES public.questionnaires(id) ON DELETE RESTRICT,
  patient_id uuid REFERENCES public.patients(id) ON DELETE SET NULL,
  appointment_id uuid REFERENCES public.appointments(id) ON DELETE SET NULL,
  assigned_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  token text NOT NULL UNIQUE,
  assigned_at timestamptz NOT NULL DEFAULT now(),
  due_at timestamptz,
  status public.q_assignment_status NOT NULL DEFAULT 'assigned',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX qa_appt_idx ON public.questionnaire_assignments(appointment_id);
CREATE INDEX qa_patient_idx ON public.questionnaire_assignments(patient_id);
GRANT SELECT, INSERT, UPDATE ON public.questionnaire_assignments TO authenticated;
GRANT ALL ON public.questionnaire_assignments TO service_role;
ALTER TABLE public.questionnaire_assignments ENABLE ROW LEVEL SECURITY;
CREATE POLICY qa_select_auth ON public.questionnaire_assignments FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY qa_write_auth ON public.questionnaire_assignments FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id())
  WITH CHECK (tenant_id = public.current_tenant_id());
CREATE TRIGGER trg_qa_touch BEFORE UPDATE ON public.questionnaire_assignments FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER trg_qa_audit AFTER INSERT OR UPDATE OR DELETE ON public.questionnaire_assignments FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

CREATE TABLE public.questionnaire_responses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  assignment_id uuid REFERENCES public.questionnaire_assignments(id) ON DELETE SET NULL,
  questionnaire_id uuid NOT NULL REFERENCES public.questionnaires(id) ON DELETE RESTRICT,
  patient_id uuid REFERENCES public.patients(id) ON DELETE SET NULL,
  appointment_id uuid REFERENCES public.appointments(id) ON DELETE SET NULL,
  answers jsonb NOT NULL,
  total_score numeric,
  severity text,
  critical_triggered boolean NOT NULL DEFAULT false,
  consent_to_record boolean NOT NULL DEFAULT false,
  is_anonymous boolean NOT NULL DEFAULT false,
  completed_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX qr_patient_idx ON public.questionnaire_responses(patient_id);
CREATE INDEX qr_appt_idx ON public.questionnaire_responses(appointment_id);
CREATE INDEX qr_q_idx ON public.questionnaire_responses(questionnaire_id);
GRANT SELECT, INSERT ON public.questionnaire_responses TO authenticated;
GRANT ALL ON public.questionnaire_responses TO service_role;
ALTER TABLE public.questionnaire_responses ENABLE ROW LEVEL SECURITY;
CREATE POLICY qr_select ON public.questionnaire_responses FOR SELECT TO authenticated
  USING (
    tenant_id = public.current_tenant_id()
    AND (public.has_permission(auth.uid(),'manage_patients')
         OR public.has_permission(auth.uid(),'manage_tenant'))
  );
CREATE POLICY qr_insert ON public.questionnaire_responses FOR INSERT TO authenticated
  WITH CHECK (tenant_id = public.current_tenant_id());

CREATE TABLE public.critical_result_alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  response_id uuid NOT NULL REFERENCES public.questionnaire_responses(id) ON DELETE CASCADE,
  patient_id uuid REFERENCES public.patients(id) ON DELETE SET NULL,
  appointment_id uuid REFERENCES public.appointments(id) ON DELETE SET NULL,
  alert_type text NOT NULL,
  severity text NOT NULL,
  status public.critical_alert_status NOT NULL DEFAULT 'open',
  acknowledged_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  acknowledged_at timestamptz,
  resolution_note text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX cra_status_idx ON public.critical_result_alerts(tenant_id, status, created_at);
GRANT SELECT, INSERT, UPDATE ON public.critical_result_alerts TO authenticated;
GRANT ALL ON public.critical_result_alerts TO service_role;
ALTER TABLE public.critical_result_alerts ENABLE ROW LEVEL SECURITY;
CREATE POLICY cra_select ON public.critical_result_alerts FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_patients') OR public.has_permission(auth.uid(),'manage_tenant')));
CREATE POLICY cra_write ON public.critical_result_alerts FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_patients') OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id());
CREATE TRIGGER trg_cra_touch BEFORE UPDATE ON public.critical_result_alerts FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER trg_cra_audit AFTER INSERT OR UPDATE OR DELETE ON public.critical_result_alerts FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

CREATE OR REPLACE FUNCTION public.qr_critical_alert_fn()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE v_q record;
BEGIN
  IF NEW.critical_triggered THEN
    SELECT code, title INTO v_q FROM public.questionnaires WHERE id = NEW.questionnaire_id;
    INSERT INTO public.critical_result_alerts (tenant_id, response_id, patient_id, appointment_id, alert_type, severity)
    VALUES (NEW.tenant_id, NEW.id, NEW.patient_id, NEW.appointment_id,
            CASE WHEN v_q.code = 'PHQ9' THEN 'suicidal_ideation' ELSE 'critical_screening' END,
            COALESCE(NEW.severity, 'severe'));
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER trg_qr_critical AFTER INSERT ON public.questionnaire_responses
  FOR EACH ROW EXECUTE FUNCTION public.qr_critical_alert_fn();

CREATE TABLE public.satisfaction_surveys (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  appointment_id uuid REFERENCES public.appointments(id) ON DELETE SET NULL,
  resource_id uuid REFERENCES public.appointment_resources(id) ON DELETE SET NULL,
  instrument_code text NOT NULL,
  answers jsonb NOT NULL,
  nps_score int CHECK (nps_score IS NULL OR (nps_score BETWEEN 0 AND 10)),
  is_anonymous boolean NOT NULL DEFAULT true,
  submitted_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ss_appt_idx ON public.satisfaction_surveys(appointment_id);
CREATE INDEX ss_tenant_idx ON public.satisfaction_surveys(tenant_id, submitted_at);
GRANT SELECT, INSERT ON public.satisfaction_surveys TO authenticated;
GRANT INSERT ON public.satisfaction_surveys TO anon;
GRANT ALL ON public.satisfaction_surveys TO service_role;
ALTER TABLE public.satisfaction_surveys ENABLE ROW LEVEL SECURITY;
CREATE POLICY ss_select ON public.satisfaction_surveys FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_schedule')
              OR public.has_permission(auth.uid(),'manage_tenant')
              OR public.has_permission(auth.uid(),'view_team')));
CREATE POLICY ss_insert_anon ON public.satisfaction_surveys FOR INSERT TO anon
  WITH CHECK (true);
CREATE POLICY ss_insert_auth ON public.satisfaction_surveys FOR INSERT TO authenticated
  WITH CHECK (tenant_id = public.current_tenant_id());

INSERT INTO public.questionnaires (code, title, leiras, items, scoring, cutoffs, licenc, mode, critical_item_index, critical_threshold) VALUES
('PHQ9','PHQ-9 (Depresszió szűrés)',
 'Az elmúlt 2 hétben milyen gyakran zavarták a következő problémák? (Pfizer 2010 — szabad felhasználás)',
 '{"items":[{"id":"q1","text":"Csekély érdeklődés vagy öröm a dolgok iránt"},{"id":"q2","text":"Levert, lehangolt vagy reménytelen hangulat"},{"id":"q3","text":"Alvási nehézség (elalvás, átalvás vagy túl sok alvás)"},{"id":"q4","text":"Fáradtság vagy energiahiány"},{"id":"q5","text":"Étvágytalanság vagy túlevés"},{"id":"q6","text":"Rossz érzés saját magával kapcsolatban"},{"id":"q7","text":"Koncentrációs nehézség"},{"id":"q8","text":"Lassú mozgás/beszéd vagy nyugtalanság"},{"id":"q9","text":"Gondolatok arról, hogy jobb lenne meghalni vagy önmagát bántani"}],"options":[{"v":0,"l":"Egyáltalán nem"},{"v":1,"l":"Néhány napon"},{"v":2,"l":"A napok több mint felében"},{"v":3,"l":"Majdnem minden nap"}]}'::jsonb,
 '{"type":"sum","range":[0,27]}'::jsonb,
 '{"thresholds":[{"min":0,"max":4,"severity":"minimal"},{"min":5,"max":9,"severity":"mild"},{"min":10,"max":14,"severity":"moderate"},{"min":15,"max":19,"severity":"moderately_severe"},{"min":20,"max":27,"severity":"severe"}]}'::jsonb,
 'free','klinikai',9,1),
('GAD7','GAD-7 (Szorongás szűrés)','Pfizer 2010 — szabad felhasználás',
 '{"items":[{"id":"q1","text":"Idegesség, szorongás vagy feszültség érzése"},{"id":"q2","text":"Képtelen abbahagyni vagy kontrollálni az aggódást"},{"id":"q3","text":"Túlzott aggódás különböző dolgok miatt"},{"id":"q4","text":"Nehéz ellazulni"},{"id":"q5","text":"Annyira nyugtalan, hogy nehéz nyugton ülni"},{"id":"q6","text":"Könnyen bosszankodó vagy ingerlékeny"},{"id":"q7","text":"Félelem, mintha valami szörnyű történne"}],"options":[{"v":0,"l":"Egyáltalán nem"},{"v":1,"l":"Néhány napon"},{"v":2,"l":"A napok több mint felében"},{"v":3,"l":"Majdnem minden nap"}]}'::jsonb,
 '{"type":"sum","range":[0,21]}'::jsonb,
 '{"thresholds":[{"min":0,"max":4,"severity":"minimal"},{"min":5,"max":9,"severity":"mild"},{"min":10,"max":14,"severity":"moderate"},{"min":15,"max":21,"severity":"severe"}]}'::jsonb,
 'free','klinikai',NULL,NULL),
('PHQ4','PHQ-4 (Ultrarövid triage)','Kroenke et al.',
 '{"items":[{"id":"a1","text":"Idegesség, szorongás vagy feszültség"},{"id":"a2","text":"Képtelen abbahagyni vagy kontrollálni az aggódást"},{"id":"d1","text":"Csekély érdeklődés vagy öröm a dolgok iránt"},{"id":"d2","text":"Levert, lehangolt vagy reménytelen hangulat"}],"options":[{"v":0,"l":"Egyáltalán nem"},{"v":1,"l":"Néhány napon"},{"v":2,"l":"A napok több mint felében"},{"v":3,"l":"Majdnem minden nap"}]}'::jsonb,
 '{"type":"sum","range":[0,12]}'::jsonb,
 '{"thresholds":[{"min":0,"max":2,"severity":"none"},{"min":3,"max":5,"severity":"mild"},{"min":6,"max":8,"severity":"moderate"},{"min":9,"max":12,"severity":"severe"}]}'::jsonb,
 'free','vegyes',NULL,NULL),
('AUDITC','AUDIT-C (Alkoholfogyasztás)','WHO AUDIT-C',
 '{"items":[{"id":"q1","text":"Milyen gyakran iszik alkoholt?","opts":[{"v":0,"l":"Soha"},{"v":1,"l":"Havonta vagy ritkábban"},{"v":2,"l":"Havi 2-4 alkalommal"},{"v":3,"l":"Heti 2-3 alkalommal"},{"v":4,"l":"Heti 4 vagy több alkalommal"}]},{"id":"q2","text":"Hány egységnyi alkoholt fogyaszt egy tipikus napon?","opts":[{"v":0,"l":"1-2"},{"v":1,"l":"3-4"},{"v":2,"l":"5-6"},{"v":3,"l":"7-9"},{"v":4,"l":"10 vagy több"}]},{"id":"q3","text":"Milyen gyakran iszik 6+ egységet egyszerre?","opts":[{"v":0,"l":"Soha"},{"v":1,"l":"Ritkábban mint havonta"},{"v":2,"l":"Havonta"},{"v":3,"l":"Hetente"},{"v":4,"l":"Naponta"}]}]}'::jsonb,
 '{"type":"sum","range":[0,12]}'::jsonb,
 '{"thresholds":[{"min":0,"max":2,"severity":"low"},{"min":3,"max":4,"severity":"at_risk"},{"min":5,"max":12,"severity":"hazardous"}]}'::jsonb,
 'free','vegyes',NULL,NULL),
('FAGERSTROM','Fagerström (Nikotinfüggőség)','FTND',
 '{"items":[{"id":"q1","text":"Felkelés után milyen hamar gyújt rá?","opts":[{"v":3,"l":"5 percen belül"},{"v":2,"l":"6-30 perc"},{"v":1,"l":"31-60 perc"},{"v":0,"l":"60 perc után"}]},{"id":"q2","text":"Nehéz tartózkodnia nemdohányzó helyeken?","opts":[{"v":1,"l":"Igen"},{"v":0,"l":"Nem"}]},{"id":"q3","text":"Melyik cigarettáról esne legnehezebben lemondania?","opts":[{"v":1,"l":"A reggeli elsőről"},{"v":0,"l":"Bármelyik másikról"}]},{"id":"q4","text":"Naponta hány szál cigarettát szív el?","opts":[{"v":0,"l":"10 vagy kevesebb"},{"v":1,"l":"11-20"},{"v":2,"l":"21-30"},{"v":3,"l":"31 vagy több"}]},{"id":"q5","text":"Gyakrabban dohányzik az első órákban?","opts":[{"v":1,"l":"Igen"},{"v":0,"l":"Nem"}]},{"id":"q6","text":"Dohányzik betegen is?","opts":[{"v":1,"l":"Igen"},{"v":0,"l":"Nem"}]}]}'::jsonb,
 '{"type":"sum","range":[0,10]}'::jsonb,
 '{"thresholds":[{"min":0,"max":2,"severity":"very_low"},{"min":3,"max":4,"severity":"low"},{"min":5,"max":5,"severity":"medium"},{"min":6,"max":7,"severity":"high"},{"min":8,"max":10,"severity":"very_high"}]}'::jsonb,
 'free','egeszsegfejlesztesi',NULL,NULL),
('CGCAHPS','Páciens-elégedettség (CG-CAHPS alapú, 12 tétel)','AHRQ CG-CAHPS public domain alapján',
 '{"items":[{"id":"q1","text":"Mennyi idő alatt kapott időpontot?"},{"id":"q2","text":"Időben tudott bejutni?"},{"id":"q3","text":"Tisztelettel bántak a recepciósok?"},{"id":"q4","text":"A szolgáltató figyelmesen meghallgatta?"},{"id":"q5","text":"Világosan elmagyarázta a dolgokat?"},{"id":"q6","text":"Bevonta a döntésekbe?"},{"id":"q7","text":"Eleget töltött Önnel?"},{"id":"q8","text":"Bízott a szakértelmében?"},{"id":"q9","text":"Könnyen kapott választ telefonon?"},{"id":"q10","text":"A rendelő tiszta volt?"},{"id":"q11","text":"Időben kapott eredményeket?"},{"id":"q12","text":"Összértékelés 0-10"}],"options":[{"v":1,"l":"Soha"},{"v":2,"l":"Néha"},{"v":3,"l":"Általában"},{"v":4,"l":"Mindig"}]}'::jsonb,
 '{"type":"mean","range":[1,4]}'::jsonb,
 '{}'::jsonb,
 'public_domain','egeszsegfejlesztesi',NULL,NULL),
('NPS','NPS — Ajánlási hajlandóság','Adams et al. (2022): NPS másodlagos trend-metrika.',
 '{"items":[{"id":"q1","text":"Mennyire valószínű, hogy ajánlaná rendelőnket? (0-10)","scale":{"min":0,"max":10}},{"id":"q2","text":"Indoklás (opcionális)","type":"text"}]}'::jsonb,
 '{"type":"nps"}'::jsonb,'{}'::jsonb,'free','egeszsegfejlesztesi',NULL,NULL),
('WHO5','WHO-5 (Jóllét) — LICENC SZÜKSÉGES','WHO 2024 CC BY-NC-SA 3.0 IGO — kereskedelmi engedély szükséges.',
 '{"items":[]}'::jsonb,'{}'::jsonb,'{}'::jsonb,'who_noncommercial','egeszsegfejlesztesi',NULL,NULL),
('EQ5D','EQ-5D — LICENC SZÜKSÉGES','EuroQol licenc szükséges — euroqol.org regisztráció.',
 '{"items":[]}'::jsonb,'{}'::jsonb,'{}'::jsonb,'euroqol_licensed','klinikai',NULL,NULL);

UPDATE public.questionnaires SET aktiv = false WHERE code IN ('WHO5','EQ5D');
