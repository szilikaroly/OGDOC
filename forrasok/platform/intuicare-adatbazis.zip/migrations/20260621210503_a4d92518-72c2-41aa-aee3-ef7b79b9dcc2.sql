
-- Helper: get manager user ids for a tenant who can manage OR blocks
CREATE OR REPLACE FUNCTION public.or_block_managers(_tenant_id uuid)
RETURNS SETOF uuid
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT DISTINCT p.id
    FROM public.profiles p
   WHERE p.tenant_id = _tenant_id
     AND public.has_permission(p.id, 'manage_or_blocks');
$$;

-- 1) Conflict scan + notifications when an OR org_unit is deactivated or
--    its type is changed away from muto/kismuto.
CREATE OR REPLACE FUNCTION public.warn_org_unit_or_deactivation()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _was_or boolean;
  _is_or boolean;
  _affected_blocks int;
  _affected_cases int;
  _mgr uuid;
  _msg text;
BEGIN
  _was_or := OLD.tipus IN ('muto','kismuto') AND OLD.aktiv = true;
  _is_or  := NEW.tipus IN ('muto','kismuto') AND NEW.aktiv = true;
  IF _was_or AND NOT _is_or THEN
    SELECT count(*) INTO _affected_blocks
      FROM public.or_blocks b
     WHERE b.org_unit_id = NEW.id
       AND b.datum >= CURRENT_DATE
       AND b.statusz <> 'felszabaditott';
    SELECT count(*) INTO _affected_cases
      FROM public.surgery_cases c
      JOIN public.or_blocks b ON b.id = c.or_block_id
     WHERE b.org_unit_id = NEW.id
       AND b.datum >= CURRENT_DATE
       AND b.statusz <> 'felszabaditott';

    IF _affected_blocks > 0 OR _affected_cases > 0 THEN
      RAISE WARNING 'Műtő inaktiválás: % jövőbeli blokk és % beosztott eset ütközik (org_unit %).',
        _affected_blocks, _affected_cases, NEW.id;
      _msg := format('A(z) "%s" műtő inaktiválásra került. %s jövőbeli blokk és %s beosztott eset érintett a Blokk-naptárban — kérjük, ellenőrizze.',
                     NEW.nev, _affected_blocks, _affected_cases);
      FOR _mgr IN SELECT public.or_block_managers(NEW.tenant_id) LOOP
        INSERT INTO public.notifications (tenant_id, user_id, tipus, cim, uzenet, link)
        VALUES (NEW.tenant_id, _mgr, 'or_board_conflict',
                'Műtő inaktiválás — ütköző beosztások', _msg, '/muteti-terv/blokkok');
      END LOOP;
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_warn_org_unit_or_deactivation ON public.org_units;
CREATE TRIGGER trg_warn_org_unit_or_deactivation
BEFORE UPDATE OF aktiv, tipus ON public.org_units
FOR EACH ROW EXECUTE FUNCTION public.warn_org_unit_or_deactivation();

-- 2) Notifications when an OR room profile becomes active or inactive.
CREATE OR REPLACE FUNCTION public.notify_or_room_profile_state()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _nev text;
  _mgr uuid;
  _msg text;
  _cim text;
BEGIN
  IF OLD.aktiv IS DISTINCT FROM NEW.aktiv THEN
    SELECT u.nev INTO _nev FROM public.org_units u WHERE u.id = NEW.org_unit_id;
    IF NEW.aktiv THEN
      _cim := 'Műtő-profil aktiválva';
      _msg := format('A(z) "%s" műtő mostantól megjelenik a Blokk-naptárban.', COALESCE(_nev, NEW.org_unit_id::text));
    ELSE
      _cim := 'Műtő-profil inaktiválva';
      _msg := format('A(z) "%s" műtő eltűnt a Blokk-naptárból.', COALESCE(_nev, NEW.org_unit_id::text));
    END IF;
    FOR _mgr IN SELECT public.or_block_managers(NEW.tenant_id) LOOP
      INSERT INTO public.notifications (tenant_id, user_id, tipus, cim, uzenet, link)
      VALUES (NEW.tenant_id, _mgr, 'or_room_state', _cim, _msg, '/muteti-terv/blokkok');
    END LOOP;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_notify_or_room_profile_state ON public.or_room_profiles;
CREATE TRIGGER trg_notify_or_room_profile_state
AFTER UPDATE OF aktiv ON public.or_room_profiles
FOR EACH ROW EXECUTE FUNCTION public.notify_or_room_profile_state();

-- 3) Conflict check on OR block time changes / release.
CREATE OR REPLACE FUNCTION public.warn_or_block_conflicts()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _new_minutes int;
  _used_minutes int;
  _case_count int;
  _mgr uuid;
  _msg text;
BEGIN
  -- Only react to schedule-relevant changes.
  IF NEW.kezdo_ido = OLD.kezdo_ido
     AND NEW.veg_ido = OLD.veg_ido
     AND NEW.datum = OLD.datum
     AND NEW.statusz = OLD.statusz THEN
    RETURN NEW;
  END IF;

  SELECT COALESCE(SUM(c.becsult_idotartam_perc), 0), COUNT(*)
    INTO _used_minutes, _case_count
    FROM public.surgery_cases c
   WHERE c.or_block_id = NEW.id;

  _new_minutes := EXTRACT(EPOCH FROM (NEW.veg_ido - NEW.kezdo_ido))/60;

  IF _case_count > 0 AND (NEW.statusz = 'felszabaditott' OR _used_minutes > _new_minutes) THEN
    RAISE WARNING 'Műtőblokk módosítás: % beosztott eset (% perc) ütközik az új % perces blokkal.',
      _case_count, _used_minutes, _new_minutes;
    _msg := format('Műtőblokk módosult (%s %s–%s). %s beosztott eset (összesen %s perc) ütközhet — kérjük, ellenőrizze.',
                   NEW.datum, NEW.kezdo_ido, NEW.veg_ido, _case_count, _used_minutes);
    FOR _mgr IN SELECT public.or_block_managers(NEW.tenant_id) LOOP
      INSERT INTO public.notifications (tenant_id, user_id, tipus, cim, uzenet, link)
      VALUES (NEW.tenant_id, _mgr, 'or_board_conflict',
              'Műtőblokk ütközés', _msg, '/muteti-terv/blokkok');
    END LOOP;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_warn_or_block_conflicts ON public.or_blocks;
CREATE TRIGGER trg_warn_or_block_conflicts
AFTER UPDATE OF kezdo_ido, veg_ido, datum, statusz ON public.or_blocks
FOR EACH ROW EXECUTE FUNCTION public.warn_or_block_conflicts();

-- 4) Re-run backfill defensively for any OR units still missing a profile.
INSERT INTO public.or_room_profiles (tenant_id, org_unit_id, or_suite_id, tipus, aktiv)
SELECT u.tenant_id,
       u.id,
       public.ensure_default_or_suite(u.tenant_id, u.site_id),
       CASE u.tipus WHEN 'kismuto' THEN 'egynapos_kismuteti'::or_tipus_enum
                    ELSE 'altalanos'::or_tipus_enum END,
       true
  FROM public.org_units u
 WHERE u.tipus IN ('muto','kismuto')
   AND u.aktiv = true
   AND u.site_id IS NOT NULL
ON CONFLICT (org_unit_id) DO UPDATE
  SET aktiv = true,
      or_suite_id = COALESCE(public.or_room_profiles.or_suite_id, EXCLUDED.or_suite_id),
      updated_at = now();
