
CREATE TYPE public.duty_availability_tipus AS ENUM ('tartalekos','behivhato','szabad_vagyok');

CREATE TABLE public.duty_availability (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  user_id uuid NOT NULL,
  site_id uuid NULL,
  duty_line_id uuid NULL REFERENCES public.duty_lines(id) ON DELETE CASCADE,
  napok date[] NOT NULL DEFAULT '{}',
  tipus public.duty_availability_tipus NOT NULL,
  kezd_ido time NULL,
  veg_ido time NULL,
  megjegyzes text NULL,
  ervenyes_tol date NOT NULL DEFAULT CURRENT_DATE,
  ervenyes_ig date NULL,
  visszavonva_at timestamptz NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.duty_availability TO authenticated;
GRANT ALL ON public.duty_availability TO service_role;

ALTER TABLE public.duty_availability ENABLE ROW LEVEL SECURITY;

CREATE POLICY "duty_availability_select_tenant"
  ON public.duty_availability FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());

CREATE POLICY "duty_availability_self_manage"
  ON public.duty_availability FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
    AND (user_id = auth.uid() OR public.has_permission(auth.uid(), 'manage_schedule')))
  WITH CHECK (tenant_id = public.current_tenant_id()
    AND (user_id = auth.uid() OR public.has_permission(auth.uid(), 'manage_schedule')));

CREATE TRIGGER touch_duty_availability BEFORE UPDATE ON public.duty_availability
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE INDEX idx_duty_availability_user_napok ON public.duty_availability USING GIN (napok);
CREATE INDEX idx_duty_availability_site ON public.duty_availability (tenant_id, site_id, tipus)
  WHERE visszavonva_at IS NULL;

CREATE UNIQUE INDEX IF NOT EXISTS uq_duty_line_eligibility_user
  ON public.duty_line_eligibility (duty_line_id, user_id) WHERE user_id IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS uq_duty_line_eligibility_foglalkozas
  ON public.duty_line_eligibility (duty_line_id, foglalkozas_tipus) WHERE foglalkozas_tipus IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS uq_duty_line_eligibility_role
  ON public.duty_line_eligibility (duty_line_id, staff_role_id) WHERE staff_role_id IS NOT NULL;

DROP POLICY IF EXISTS "mandatory_duty_rules_manage" ON public.mandatory_duty_rules;
CREATE POLICY "mandatory_duty_rules_manage_tenant_only"
  ON public.mandatory_duty_rules FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_tenant'))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_tenant'));

CREATE OR REPLACE FUNCTION public.audit_mandatory_duty_rules()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.admin_audit_log (tenant_id, user_id, action, table_name, record_id, before_data, after_data, summary, created_at)
  VALUES (
    COALESCE(NEW.tenant_id, OLD.tenant_id), auth.uid(), TG_OP, 'mandatory_duty_rules',
    COALESCE(NEW.id::text, OLD.id::text),
    CASE WHEN TG_OP <> 'INSERT' THEN to_jsonb(OLD) END,
    CASE WHEN TG_OP <> 'DELETE' THEN to_jsonb(NEW) END,
    'Kötelező ügyelet szabály ' || TG_OP, now()
  );
  RETURN COALESCE(NEW, OLD);
END;
$$;

DROP TRIGGER IF EXISTS trg_audit_mandatory_duty_rules ON public.mandatory_duty_rules;
CREATE TRIGGER trg_audit_mandatory_duty_rules
  AFTER INSERT OR UPDATE OR DELETE ON public.mandatory_duty_rules
  FOR EACH ROW EXECUTE FUNCTION public.audit_mandatory_duty_rules();
