
-- ============== CMS Tips module ==============

-- Categories
CREATE TABLE public.cms_tip_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  name_i18n jsonb NOT NULL DEFAULT '{}'::jsonb,
  description_i18n jsonb NOT NULL DEFAULT '{}'::jsonb,
  icon text,
  color text,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.cms_tip_categories TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_tip_categories TO authenticated;
GRANT ALL ON public.cms_tip_categories TO service_role;
ALTER TABLE public.cms_tip_categories ENABLE ROW LEVEL SECURITY;
CREATE POLICY "cms_tip_categories_public_read" ON public.cms_tip_categories FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "cms_tip_categories_admin_write" ON public.cms_tip_categories FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor'))
  WITH CHECK (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor'));

-- Tags
CREATE TABLE public.cms_tip_tags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  name_i18n jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.cms_tip_tags TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_tip_tags TO authenticated;
GRANT ALL ON public.cms_tip_tags TO service_role;
ALTER TABLE public.cms_tip_tags ENABLE ROW LEVEL SECURITY;
CREATE POLICY "cms_tip_tags_public_read" ON public.cms_tip_tags FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "cms_tip_tags_admin_write" ON public.cms_tip_tags FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor'))
  WITH CHECK (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor'));

-- Audiences
CREATE TABLE public.cms_tip_audiences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  name_i18n jsonb NOT NULL DEFAULT '{}'::jsonb,
  description_i18n jsonb NOT NULL DEFAULT '{}'::jsonb,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.cms_tip_audiences TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_tip_audiences TO authenticated;
GRANT ALL ON public.cms_tip_audiences TO service_role;
ALTER TABLE public.cms_tip_audiences ENABLE ROW LEVEL SECURITY;
CREATE POLICY "cms_tip_audiences_public_read" ON public.cms_tip_audiences FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "cms_tip_audiences_admin_write" ON public.cms_tip_audiences FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor'))
  WITH CHECK (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor'));

-- Tips (main)
CREATE TABLE public.cms_tips (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  category_id uuid REFERENCES public.cms_tip_categories(id) ON DELETE SET NULL,
  cover_url text,
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published','archived')),
  featured boolean NOT NULL DEFAULT false,
  published_at timestamptz,
  author_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  reading_minutes int,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX cms_tips_status_pub_idx ON public.cms_tips(status, published_at DESC);
CREATE INDEX cms_tips_category_idx ON public.cms_tips(category_id);
GRANT SELECT ON public.cms_tips TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_tips TO authenticated;
GRANT ALL ON public.cms_tips TO service_role;
ALTER TABLE public.cms_tips ENABLE ROW LEVEL SECURITY;
CREATE POLICY "cms_tips_public_read_published" ON public.cms_tips FOR SELECT TO anon USING (status = 'published');
CREATE POLICY "cms_tips_auth_read" ON public.cms_tips FOR SELECT TO authenticated USING (
  status = 'published' OR public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor')
);
CREATE POLICY "cms_tips_admin_write" ON public.cms_tips FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor'))
  WITH CHECK (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor'));

-- Translations (1 row per locale)
CREATE TABLE public.cms_tip_translations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tip_id uuid NOT NULL REFERENCES public.cms_tips(id) ON DELETE CASCADE,
  locale text NOT NULL,
  title text NOT NULL DEFAULT '',
  lead text DEFAULT '',
  body_json jsonb NOT NULL DEFAULT '{}'::jsonb,
  body_html text DEFAULT '',
  seo_title text,
  seo_description text,
  og_image text,
  ai_generated boolean NOT NULL DEFAULT false,
  ai_source_lang text,
  translation_status text NOT NULL DEFAULT 'manual' CHECK (translation_status IN ('manual','ai','reviewed')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(tip_id, locale)
);
CREATE INDEX cms_tip_translations_locale_idx ON public.cms_tip_translations(locale);
GRANT SELECT ON public.cms_tip_translations TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_tip_translations TO authenticated;
GRANT ALL ON public.cms_tip_translations TO service_role;
ALTER TABLE public.cms_tip_translations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "cms_tip_translations_public_read" ON public.cms_tip_translations FOR SELECT TO anon USING (
  EXISTS (SELECT 1 FROM public.cms_tips t WHERE t.id = tip_id AND t.status = 'published')
);
CREATE POLICY "cms_tip_translations_auth_read" ON public.cms_tip_translations FOR SELECT TO authenticated USING (
  public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor')
  OR EXISTS (SELECT 1 FROM public.cms_tips t WHERE t.id = tip_id AND t.status = 'published')
);
CREATE POLICY "cms_tip_translations_admin_write" ON public.cms_tip_translations FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor'))
  WITH CHECK (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor'));

-- Versions
CREATE TABLE public.cms_tip_versions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tip_id uuid NOT NULL REFERENCES public.cms_tips(id) ON DELETE CASCADE,
  version int NOT NULL,
  snapshot jsonb NOT NULL,
  note text,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(tip_id, version)
);
CREATE INDEX cms_tip_versions_tip_idx ON public.cms_tip_versions(tip_id, version DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_tip_versions TO authenticated;
GRANT ALL ON public.cms_tip_versions TO service_role;
ALTER TABLE public.cms_tip_versions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "cms_tip_versions_admin" ON public.cms_tip_versions FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor'))
  WITH CHECK (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor'));

-- Tag map
CREATE TABLE public.cms_tip_tag_map (
  tip_id uuid NOT NULL REFERENCES public.cms_tips(id) ON DELETE CASCADE,
  tag_id uuid NOT NULL REFERENCES public.cms_tip_tags(id) ON DELETE CASCADE,
  PRIMARY KEY (tip_id, tag_id)
);
GRANT SELECT ON public.cms_tip_tag_map TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_tip_tag_map TO authenticated;
GRANT ALL ON public.cms_tip_tag_map TO service_role;
ALTER TABLE public.cms_tip_tag_map ENABLE ROW LEVEL SECURITY;
CREATE POLICY "cms_tip_tag_map_public_read" ON public.cms_tip_tag_map FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "cms_tip_tag_map_admin_write" ON public.cms_tip_tag_map FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor'))
  WITH CHECK (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor'));

-- Audience map
CREATE TABLE public.cms_tip_audience_map (
  tip_id uuid NOT NULL REFERENCES public.cms_tips(id) ON DELETE CASCADE,
  audience_id uuid NOT NULL REFERENCES public.cms_tip_audiences(id) ON DELETE CASCADE,
  PRIMARY KEY (tip_id, audience_id)
);
GRANT SELECT ON public.cms_tip_audience_map TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_tip_audience_map TO authenticated;
GRANT ALL ON public.cms_tip_audience_map TO service_role;
ALTER TABLE public.cms_tip_audience_map ENABLE ROW LEVEL SECURITY;
CREATE POLICY "cms_tip_audience_map_public_read" ON public.cms_tip_audience_map FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "cms_tip_audience_map_admin_write" ON public.cms_tip_audience_map FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor'))
  WITH CHECK (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor'));

-- updated_at triggers
CREATE TRIGGER trg_cms_tips_updated BEFORE UPDATE ON public.cms_tips
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_cms_tip_translations_updated BEFORE UPDATE ON public.cms_tip_translations
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_cms_tip_categories_updated BEFORE UPDATE ON public.cms_tip_categories
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_cms_tip_tags_updated BEFORE UPDATE ON public.cms_tip_tags
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_cms_tip_audiences_updated BEFORE UPDATE ON public.cms_tip_audiences
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Seed audiences
INSERT INTO public.cms_tip_audiences (slug, name_i18n, sort_order) VALUES
  ('general',   '{"hu":"Általános","en":"General","de":"Allgemein"}',          0),
  ('pregnant', '{"hu":"Várandós","en":"Pregnant","de":"Schwangere"}',          10),
  ('new-mother','{"hu":"Kismama","en":"New mother","de":"Junge Mutter"}',      20),
  ('child',    '{"hu":"Gyermek","en":"Child","de":"Kind"}',                    30),
  ('elderly',  '{"hu":"Idős","en":"Elderly","de":"Senioren"}',                 40),
  ('diabetic', '{"hu":"Cukorbeteg","en":"Diabetic","de":"Diabetiker"}',        50),
  ('chronic',  '{"hu":"Krónikus beteg","en":"Chronic patient","de":"Chronisch Kranke"}', 60),
  ('athlete',  '{"hu":"Sportoló","en":"Athlete","de":"Sportler"}',             70);
