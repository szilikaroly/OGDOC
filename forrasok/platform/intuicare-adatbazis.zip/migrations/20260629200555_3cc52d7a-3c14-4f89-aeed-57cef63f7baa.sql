-- =========================================================================
-- 1. profile_work_time_frame — időszakos havi munkaidő-keret munkavállalónként
-- =========================================================================
CREATE TABLE public.profile_work_time_frame (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  ervenyes_tol date NOT NULL,
  ervenyes_ig date,
  havi_orakeret numeric,
  szazalek numeric,
  indok text,
  rogzitette_user_id uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pwtf_value_present CHECK (havi_orakeret IS NOT NULL OR szazalek IS NOT NULL),
  CONSTRAINT pwtf_range CHECK (ervenyes_ig IS NULL OR ervenyes_ig >= ervenyes_tol)
);

CREATE INDEX pwtf_user_ervenyes_idx
  ON public.profile_work_time_frame (user_id, ervenyes_tol DESC);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_work_time_frame TO authenticated;
GRANT ALL ON public.profile_work_time_frame TO service_role;

ALTER TABLE public.profile_work_time_frame ENABLE ROW LEVEL SECURITY;

CREATE POLICY "pwtf_select_self_or_admin"
  ON public.profile_work_time_frame
  FOR SELECT TO authenticated
  USING (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_eusztv')
  );

CREATE POLICY "pwtf_write_self_or_admin"
  ON public.profile_work_time_frame
  FOR ALL TO authenticated
  USING (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_eusztv')
  )
  WITH CHECK (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_eusztv')
  );

CREATE TRIGGER pwtf_touch
  BEFORE UPDATE ON public.profile_work_time_frame
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- =========================================================================
-- 2. illetmeny_snapshots — mentett havi illetmény-számítások
-- =========================================================================
CREATE TABLE public.illetmeny_snapshots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  cimke text NOT NULL,
  vonatkozasi_datum date NOT NULL DEFAULT CURRENT_DATE,
  bemenet jsonb NOT NULL DEFAULT '{}'::jsonb,
  eredmeny jsonb NOT NULL DEFAULT '{}'::jsonb,
  vegosszeg_ft numeric NOT NULL DEFAULT 0,
  jogi_hivatkozasok jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX illetmeny_snap_user_idx
  ON public.illetmeny_snapshots (user_id, created_at DESC);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.illetmeny_snapshots TO authenticated;
GRANT ALL ON public.illetmeny_snapshots TO service_role;

ALTER TABLE public.illetmeny_snapshots ENABLE ROW LEVEL SECURITY;

CREATE POLICY "isnap_select_self_or_admin"
  ON public.illetmeny_snapshots
  FOR SELECT TO authenticated
  USING (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_eusztv')
  );

CREATE POLICY "isnap_write_self_or_admin"
  ON public.illetmeny_snapshots
  FOR ALL TO authenticated
  USING (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_eusztv')
  )
  WITH CHECK (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_eusztv')
  );

CREATE TRIGGER isnap_touch
  BEFORE UPDATE ON public.illetmeny_snapshots
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();