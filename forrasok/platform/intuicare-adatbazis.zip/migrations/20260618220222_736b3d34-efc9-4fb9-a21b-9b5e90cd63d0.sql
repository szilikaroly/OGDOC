create extension if not exists pg_trgm with schema public;

create index if not exists idx_patients_fullname_trgm
  on public.patients using gin ((coalesce(vezeteknev,'') || ' ' || coalesce(keresztnev,'')) gin_trgm_ops);

create index if not exists idx_patients_taj on public.patients (taj);

create or replace function public.search_patients(_q text, _limit int default 20)
returns table (
  id uuid,
  taj text,
  vezeteknev text,
  keresztnev text,
  szuletesi_datum date,
  nem text,
  fo_diagnozis_bno text,
  score real
)
language sql
stable
security invoker
set search_path = public
as $$
  select p.id, p.taj, p.vezeteknev, p.keresztnev, p.szuletesi_datum, p.nem, p.fo_diagnozis_bno,
    greatest(
      similarity(coalesce(p.vezeteknev,'') || ' ' || coalesce(p.keresztnev,''), coalesce(_q,'')),
      case when p.taj is not null and _q is not null and p.taj like '%' || _q || '%' then 1.0 else 0 end
    )::real as score
  from public.patients p
  where _q is null or _q = ''
     or (coalesce(p.vezeteknev,'') || ' ' || coalesce(p.keresztnev,'')) % _q
     or p.taj ilike '%' || _q || '%'
  order by score desc, p.vezeteknev
  limit greatest(1, least(_limit, 100));
$$;

grant execute on function public.search_patients(text, int) to authenticated;

create or replace function public._enc_progress_beavatkozasok()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  bid uuid;
begin
  if NEW.szerzo_alairas_at is not null
     and (OLD.szerzo_alairas_at is null)
     and NEW.szerzo_id is not null
     and NEW.beavatkozas_ids is not null
     and array_length(NEW.beavatkozas_ids, 1) > 0
  then
    foreach bid in array NEW.beavatkozas_ids loop
      insert into public.profile_beavatkozasok
        (tenant_id, user_id, beavatkozas_id, alkalom, datum, megjegyzes, mentor_igazolt, mentor_user_id)
      values
        (NEW.tenant_id, NEW.szerzo_id, bid, 1,
         (NEW.ellatas_kezdete)::date,
         'encounter:' || NEW.id::text,
         (NEW.ellenjegyzo_id is not null),
         NEW.ellenjegyzo_id)
      on conflict do nothing;
    end loop;
  end if;
  return NEW;
end;
$$;

drop trigger if exists trg_enc_progress_beavatkozasok on public.patient_encounters;
create trigger trg_enc_progress_beavatkozasok
  after update of szerzo_alairas_at on public.patient_encounters
  for each row execute function public._enc_progress_beavatkozasok();