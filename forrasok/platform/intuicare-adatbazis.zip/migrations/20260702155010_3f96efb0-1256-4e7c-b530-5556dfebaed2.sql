REVOKE EXECUTE ON FUNCTION public.notify_contact_message() FROM PUBLIC, anon, authenticated;
