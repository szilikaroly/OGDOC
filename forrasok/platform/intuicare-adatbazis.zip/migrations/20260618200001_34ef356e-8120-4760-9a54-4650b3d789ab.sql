DO $$ BEGIN
  CREATE TYPE public.jogviszony_tipus AS ENUM (
    'kjt_kozalkalmazott',
    'egeszsegugyi_szolgalati',
    'munka_tv_kv',
    'megbizasi',
    'egyeni_vallalkozo',
    'tarsas_vallalkozo',
    'kozalkalmazotti_tovabbi',
    'rezidens_kepzes',
    'oszintszerzodes',
    'egyeb'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.fenntarto_tipus AS ENUM (
    'allami','onkormanyzati','egyhazi','egyetemi_klinika','maganszektor','egyeb'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.munkaido_keret_tipus AS ENUM (
    'heti','havi','negyedeves','eves','egyedi'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS public.profile_employment (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  elsodleges BOOLEAN NOT NULL DEFAULT false,
  jogviszony_tipus public.jogviszony_tipus NOT NULL DEFAULT 'egeszsegugyi_szolgalati',
  fenntarto_tipus public.fenntarto_tipus NOT NULL DEFAULT 'allami',
  munkaltato_nev TEXT NOT NULL,
  munkakor_megnevezes TEXT,
  munkakor_kod TEXT,
  org_unit_id UUID REFERENCES public.org_units(id) ON DELETE SET NULL,
  site_id UUID REFERENCES public.sites(id) ON DELETE SET NULL,
  kezdo_datum DATE,
  zaro_datum DATE,
  munkaido_keret public.munkaido_keret_tipus NOT NULL DEFAULT 'heti',
  keret_ora NUMERIC(7,2),
  fte_szazalek SMALLINT NOT NULL DEFAULT 100 CHECK (fte_szazalek BETWEEN 0 AND 200),
  tobbes_jogviszony BOOLEAN NOT NULL DEFAULT false,
  opt_out_ovt BOOLEAN NOT NULL DEFAULT false,
  opt_out_kezdete DATE,
  opt_out_visszavonas DATE,
  ovt_max_evi_ora INT,
  osszeferhetetlenseg_megjegyzes TEXT,
  ervenyes BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_employment TO authenticated;
GRANT ALL ON public.profile_employment TO service_role;
ALTER TABLE public.profile_employment ENABLE ROW LEVEL SECURITY;

CREATE POLICY pe_select ON public.profile_employment FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (user_id = auth.uid()
              OR public.has_permission(auth.uid(),'view_team')
              OR public.has_permission(auth.uid(),'manage_schedule')
              OR public.has_permission(auth.uid(),'manage_tenant')));

CREATE POLICY pe_write_self_or_hr ON public.profile_employment FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (user_id = auth.uid() OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id()
         AND (user_id = auth.uid() OR public.has_permission(auth.uid(),'manage_tenant')));

CREATE INDEX idx_pe_user ON public.profile_employment(user_id);
CREATE INDEX idx_pe_tenant ON public.profile_employment(tenant_id);
CREATE UNIQUE INDEX uq_pe_one_primary ON public.profile_employment(user_id) WHERE elsodleges = true;

CREATE TRIGGER touch_pe BEFORE UPDATE ON public.profile_employment
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER audit_pe AFTER INSERT OR UPDATE OR DELETE ON public.profile_employment
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ensure single primary
CREATE OR REPLACE FUNCTION public.profile_employment_single_primary()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.elsodleges = true THEN
    UPDATE public.profile_employment
       SET elsodleges = false
     WHERE user_id = NEW.user_id
       AND id <> NEW.id
       AND elsodleges = true;
  END IF;
  RETURN NEW;
END $$;

CREATE TRIGGER pe_primary_unique
AFTER INSERT OR UPDATE OF elsodleges ON public.profile_employment
FOR EACH ROW WHEN (NEW.elsodleges = true)
EXECUTE FUNCTION public.profile_employment_single_primary();

-- OVT opt-out audit log
CREATE TABLE IF NOT EXISTS public.profile_employment_optout_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  employment_id UUID NOT NULL REFERENCES public.profile_employment(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  action TEXT NOT NULL CHECK (action IN ('opt_in','opt_out','revoke','keret_modositas')),
  effective_date DATE NOT NULL DEFAULT CURRENT_DATE,
  ovt_max_evi_ora INT,
  indok TEXT,
  decided_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_employment_optout_log TO authenticated;
GRANT ALL ON public.profile_employment_optout_log TO service_role;
ALTER TABLE public.profile_employment_optout_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY peol_select ON public.profile_employment_optout_log FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (user_id = auth.uid()
              OR public.has_permission(auth.uid(),'view_team')
              OR public.has_permission(auth.uid(),'manage_schedule')
              OR public.has_permission(auth.uid(),'manage_tenant')));

CREATE POLICY peol_insert_self_or_hr ON public.profile_employment_optout_log FOR INSERT TO authenticated
  WITH CHECK (tenant_id = public.current_tenant_id()
         AND (user_id = auth.uid() OR public.has_permission(auth.uid(),'manage_tenant')));

CREATE POLICY peol_update_hr ON public.profile_employment_optout_log FOR UPDATE TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_tenant'))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_tenant'));

CREATE POLICY peol_delete_hr ON public.profile_employment_optout_log FOR DELETE TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_tenant'));

CREATE INDEX idx_peol_employment ON public.profile_employment_optout_log(employment_id);
CREATE INDEX idx_peol_user ON public.profile_employment_optout_log(user_id);

CREATE TRIGGER audit_peol AFTER INSERT OR UPDATE OR DELETE ON public.profile_employment_optout_log
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();