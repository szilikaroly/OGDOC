
CREATE TABLE public.patient_referral_requests (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tenant_id UUID,
  patient_id UUID NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  requested_by UUID REFERENCES auth.users(id),
  request_type TEXT NOT NULL CHECK (request_type IN ('referral','prescription','certificate')),
  specialty TEXT,
  reason TEXT NOT NULL,
  notes TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected','fulfilled','cancelled')),
  decision_note TEXT,
  decided_by UUID REFERENCES auth.users(id),
  decided_at TIMESTAMPTZ,
  eeszt_ref TEXT,
  pdf_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.patient_referral_requests TO authenticated;
GRANT ALL ON public.patient_referral_requests TO service_role;

ALTER TABLE public.patient_referral_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Patient sees own referral requests"
ON public.patient_referral_requests FOR SELECT TO authenticated
USING (patient_id IN (SELECT patient_id FROM public.patient_users WHERE user_id = auth.uid()));

CREATE POLICY "Patient creates own referral requests"
ON public.patient_referral_requests FOR INSERT TO authenticated
WITH CHECK (
  patient_id IN (SELECT patient_id FROM public.patient_users WHERE user_id = auth.uid())
  AND requested_by = auth.uid()
);

CREATE POLICY "Staff manages referral requests"
ON public.patient_referral_requests FOR ALL TO authenticated
USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'orvos'))
WITH CHECK (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'orvos'));

CREATE TRIGGER trg_pat_ref_req_updated
BEFORE UPDATE ON public.patient_referral_requests
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE INDEX idx_pat_ref_req_patient ON public.patient_referral_requests(patient_id, created_at DESC);
CREATE INDEX idx_pat_ref_req_status ON public.patient_referral_requests(status, created_at DESC);
