
-- ============================================================
-- G kör: túlóra preferenciák, elrendelések, keret-nézet
-- ============================================================

DO $$ BEGIN
  CREATE TYPE public.overtime_pref_status AS ENUM ('aktiv','visszavont','lejart');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.overtime_order_status AS ENUM ('tervezett','elrendelt','teljesitve','visszavont');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS public.overtime_preferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  ervenyes_tol date NOT NULL DEFAULT CURRENT_DATE,
  ervenyes_ig date,
  max_ora_havi numeric(6,2),
  napok smallint[] NOT NULL DEFAULT '{}',           -- ISO: 1=hétfő..7=vasárnap
  muszakok text[] NOT NULL DEFAULT '{}',            -- pl. {'nappal','ejszaka','ugyelet','keszenlet'}
  csak_sajat_osztaly boolean NOT NULL DEFAULT false,
  megjegyzes text,
  status public.overtime_pref_status NOT NULL DEFAULT 'aktiv',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_op_user ON public.overtime_preferences (user_id);
CREATE INDEX IF NOT EXISTS idx_op_window ON public.overtime_preferences (ervenyes_tol, ervenyes_ig);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.overtime_preferences TO authenticated;
GRANT ALL ON public.overtime_preferences TO service_role;
ALTER TABLE public.overtime_preferences ENABLE ROW LEVEL SECURITY;

CREATE POLICY op_select ON public.overtime_preferences FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(),'manage_schedule')
    OR public.has_permission(auth.uid(),'view_team')
    OR public.has_permission(auth.uid(),'manage_tenant')
  ));

CREATE POLICY op_write_self_or_admin ON public.overtime_preferences FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(),'manage_tenant')
  ))
  WITH CHECK (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(),'manage_tenant')
  ));

CREATE TRIGGER op_touch BEFORE UPDATE ON public.overtime_preferences
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TRIGGER audit_op AFTER INSERT OR UPDATE OR DELETE ON public.overtime_preferences
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- Elrendelt rendkívüli munka (528/2020 16. §)
CREATE TABLE IF NOT EXISTS public.overtime_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  org_unit_id uuid REFERENCES public.org_units(id) ON DELETE SET NULL,
  kezdo_idopont timestamptz NOT NULL,
  zaro_idopont timestamptz NOT NULL,
  ora numeric(6,2) NOT NULL,
  kategoria text NOT NULL DEFAULT 'rendkivuli',     -- rendkivuli | ugyelet | keszenlet | ovt
  indok text NOT NULL,
  elrendelo_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT,
  elrendeles_at timestamptz NOT NULL DEFAULT now(),
  irasos_hivatkozas text,
  status public.overtime_order_status NOT NULL DEFAULT 'elrendelt',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT oo_time_chk CHECK (zaro_idopont > kezdo_idopont),
  CONSTRAINT oo_ora_chk CHECK (ora > 0)
);

CREATE INDEX IF NOT EXISTS idx_oo_user ON public.overtime_orders (user_id);
CREATE INDEX IF NOT EXISTS idx_oo_time ON public.overtime_orders (kezdo_idopont, zaro_idopont);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.overtime_orders TO authenticated;
GRANT ALL ON public.overtime_orders TO service_role;
ALTER TABLE public.overtime_orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY oo_select ON public.overtime_orders FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(),'manage_schedule')
    OR public.has_permission(auth.uid(),'view_team')
    OR public.has_permission(auth.uid(),'manage_tenant')
  ));

CREATE POLICY oo_write_admin ON public.overtime_orders FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    public.has_permission(auth.uid(),'manage_schedule')
    OR public.has_permission(auth.uid(),'manage_tenant')
  ))
  WITH CHECK (tenant_id = public.current_tenant_id() AND (
    public.has_permission(auth.uid(),'manage_schedule')
    OR public.has_permission(auth.uid(),'manage_tenant')
  ));

CREATE TRIGGER oo_touch BEFORE UPDATE ON public.overtime_orders
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TRIGGER audit_oo AFTER INSERT OR UPDATE OR DELETE ON public.overtime_orders
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- Éves keret-nézet (kihasználtság a work_time_rules küszöbökhöz mérten)
CREATE OR REPLACE VIEW public.v_overtime_ledger_yearly AS
WITH primary_emp AS (
  SELECT DISTINCT ON (pe.user_id)
    pe.user_id, pe.tenant_id, pe.jogviszony_tipus, pe.fenntarto_tipus
  FROM public.profile_employment pe
  WHERE pe.ervenyes = true
  ORDER BY pe.user_id, pe.elsodleges DESC, pe.created_at DESC
),
rules AS (
  SELECT pe.user_id, pe.tenant_id,
         wtr.eves_rendkivuli_max,
         wtr.eves_ugyelet_rendkivuli_max,
         wtr.eves_ovt_rendkivuli_max
  FROM primary_emp pe
  LEFT JOIN public.work_time_rules wtr
    ON (wtr.tenant_id = pe.tenant_id OR wtr.tenant_id IS NULL)
   AND wtr.jogviszony_tipus = pe.jogviszony_tipus
   AND wtr.fenntarto_tipus = pe.fenntarto_tipus
   AND (wtr.ervenyes_ig IS NULL OR wtr.ervenyes_ig >= CURRENT_DATE)
),
agg AS (
  SELECT
    oo.user_id,
    EXTRACT(year FROM oo.kezdo_idopont)::int AS ev,
    SUM(CASE WHEN oo.kategoria = 'rendkivuli' THEN oo.ora ELSE 0 END) AS rendkivuli_ora,
    SUM(CASE WHEN oo.kategoria IN ('rendkivuli','ugyelet') THEN oo.ora ELSE 0 END) AS ugyelet_plus_rendkivuli_ora,
    SUM(CASE WHEN oo.kategoria = 'ovt' THEN oo.ora ELSE 0 END) AS ovt_ora
  FROM public.overtime_orders oo
  WHERE oo.status IN ('elrendelt','teljesitve')
  GROUP BY oo.user_id, EXTRACT(year FROM oo.kezdo_idopont)
)
SELECT
  pe.user_id,
  pe.tenant_id,
  COALESCE(a.ev, EXTRACT(year FROM CURRENT_DATE)::int) AS ev,
  COALESCE(a.rendkivuli_ora, 0) AS rendkivuli_ora,
  COALESCE(a.ugyelet_plus_rendkivuli_ora, 0) AS ugyelet_plus_rendkivuli_ora,
  COALESCE(a.ovt_ora, 0) AS ovt_ora,
  r.eves_rendkivuli_max,
  r.eves_ugyelet_rendkivuli_max,
  r.eves_ovt_rendkivuli_max,
  CASE WHEN r.eves_rendkivuli_max > 0
       THEN ROUND(100 * COALESCE(a.rendkivuli_ora,0) / r.eves_rendkivuli_max, 1) END AS rendkivuli_kihasznaltsag_szazalek,
  CASE WHEN r.eves_ugyelet_rendkivuli_max > 0
       THEN ROUND(100 * COALESCE(a.ugyelet_plus_rendkivuli_ora,0) / r.eves_ugyelet_rendkivuli_max, 1) END AS ugy_rend_kihasznaltsag_szazalek
FROM primary_emp pe
LEFT JOIN rules r ON r.user_id = pe.user_id
LEFT JOIN agg a ON a.user_id = pe.user_id;

GRANT SELECT ON public.v_overtime_ledger_yearly TO authenticated;
