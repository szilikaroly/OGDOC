
-- ============================================================
-- ENUM TÍPUSOK
-- ============================================================
CREATE TYPE public.foglalkozas_tipus AS ENUM ('orvos', 'szakdolgozo', 'egyeb');
CREATE TYPE public.role_kategoria AS ENUM ('orvos', 'szakdolgozo', 'vezeto', 'admin');
CREATE TYPE public.staff_level_tipus AS ENUM ('orvos', 'szakdolgozo');
CREATE TYPE public.org_unit_tipus AS ENUM ('fekvobeteg_osztaly', 'rendelo', 'ambulancia', 'muto', 'kismuto', 'egyeb');

-- ============================================================
-- TÁBLÁK (sorrend: minden függvényhivatkozás előtt)
-- ============================================================
CREATE TABLE public.tenants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  nev TEXT NOT NULL,
  regio TEXT NOT NULL DEFAULT 'eu-central-1',
  plan TEXT NOT NULL DEFAULT 'starter',
  aktiv BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.tenants TO authenticated;
GRANT ALL ON public.tenants TO service_role;
ALTER TABLE public.tenants ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  tenant_id UUID REFERENCES public.tenants(id) ON DELETE SET NULL,
  teljes_nev TEXT NOT NULL,
  email TEXT NOT NULL,
  foglalkozas_tipus public.foglalkozas_tipus NOT NULL DEFAULT 'egyeb',
  aktiv BOOLEAN NOT NULL DEFAULT true,
  avatar_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_profiles_tenant ON public.profiles(tenant_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  kulcs TEXT NOT NULL UNIQUE,
  megnevezes TEXT NOT NULL,
  kategoria public.role_kategoria NOT NULL,
  sorrend INT NOT NULL DEFAULT 0
);
GRANT SELECT ON public.roles TO authenticated;
GRANT ALL ON public.roles TO service_role;
ALTER TABLE public.roles ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.clinics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  nev TEXT NOT NULL,
  aktiv BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_clinics_tenant ON public.clinics(tenant_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.clinics TO authenticated;
GRANT ALL ON public.clinics TO service_role;
ALTER TABLE public.clinics ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.sites (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  clinic_id UUID NOT NULL REFERENCES public.clinics(id) ON DELETE CASCADE,
  nev TEXT NOT NULL,
  cim TEXT,
  aktiv BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_sites_tenant ON public.sites(tenant_id);
CREATE INDEX idx_sites_clinic ON public.sites(clinic_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.sites TO authenticated;
GRANT ALL ON public.sites TO service_role;
ALTER TABLE public.sites ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.org_units (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  site_id UUID NOT NULL REFERENCES public.sites(id) ON DELETE CASCADE,
  parent_id UUID REFERENCES public.org_units(id) ON DELETE SET NULL,
  nev TEXT NOT NULL,
  tipus public.org_unit_tipus NOT NULL,
  aktiv BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_org_units_tenant ON public.org_units(tenant_id);
CREATE INDEX idx_org_units_site ON public.org_units(site_id);
CREATE INDEX idx_org_units_parent ON public.org_units(parent_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.org_units TO authenticated;
GRANT ALL ON public.org_units TO service_role;
ALTER TABLE public.org_units ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.specialties (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  kod TEXT NOT NULL UNIQUE,
  nev TEXT NOT NULL,
  aktiv BOOLEAN NOT NULL DEFAULT true
);
GRANT SELECT ON public.specialties TO authenticated;
GRANT ALL ON public.specialties TO service_role;
ALTER TABLE public.specialties ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.org_unit_specialties (
  org_unit_id UUID NOT NULL REFERENCES public.org_units(id) ON DELETE CASCADE,
  specialty_id UUID NOT NULL REFERENCES public.specialties(id) ON DELETE CASCADE,
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  PRIMARY KEY (org_unit_id, specialty_id)
);
CREATE INDEX idx_ous_tenant ON public.org_unit_specialties(tenant_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.org_unit_specialties TO authenticated;
GRANT ALL ON public.org_unit_specialties TO service_role;
ALTER TABLE public.org_unit_specialties ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role_id UUID NOT NULL REFERENCES public.roles(id) ON DELETE RESTRICT,
  site_id UUID REFERENCES public.sites(id) ON DELETE CASCADE,
  org_unit_id UUID REFERENCES public.org_units(id) ON DELETE CASCADE,
  ervenyes_tol TIMESTAMPTZ,
  ervenyes_ig TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, user_id, role_id, site_id, org_unit_id)
);
CREATE INDEX idx_user_roles_user ON public.user_roles(user_id);
CREATE INDEX idx_user_roles_tenant ON public.user_roles(tenant_id);
CREATE INDEX idx_user_roles_role ON public.user_roles(role_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.staff_levels (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  tipus public.staff_level_tipus NOT NULL,
  szint TEXT NOT NULL,
  ervenyes_tol DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, tipus)
);
CREATE INDEX idx_staff_levels_user ON public.staff_levels(user_id);
CREATE INDEX idx_staff_levels_tenant ON public.staff_levels(tenant_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.staff_levels TO authenticated;
GRANT ALL ON public.staff_levels TO service_role;
ALTER TABLE public.staff_levels ENABLE ROW LEVEL SECURITY;

-- ============================================================
-- HELPER FÜGGVÉNYEK (most már léteznek a hivatkozott táblák)
-- ============================================================
CREATE OR REPLACE FUNCTION public.current_tenant_id()
RETURNS UUID
LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public
AS $$ SELECT tenant_id FROM public.profiles WHERE id = auth.uid() $$;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role_kulcs TEXT)
RETURNS BOOLEAN
LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles ur
    JOIN public.roles r ON r.id = ur.role_id
    WHERE ur.user_id = _user_id
      AND r.kulcs = _role_kulcs
      AND (ur.ervenyes_tol IS NULL OR ur.ervenyes_tol <= now())
      AND (ur.ervenyes_ig IS NULL OR ur.ervenyes_ig >= now())
  )
$$;

CREATE OR REPLACE FUNCTION public.has_any_role(_user_id UUID, _role_kulcsok TEXT[])
RETURNS BOOLEAN
LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles ur
    JOIN public.roles r ON r.id = ur.role_id
    WHERE ur.user_id = _user_id
      AND r.kulcs = ANY(_role_kulcsok)
      AND (ur.ervenyes_tol IS NULL OR ur.ervenyes_tol <= now())
      AND (ur.ervenyes_ig IS NULL OR ur.ervenyes_ig >= now())
  )
$$;

-- ============================================================
-- RLS POLICIES
-- ============================================================
CREATE POLICY "tenants_select_own" ON public.tenants
  FOR SELECT TO authenticated USING (id = public.current_tenant_id());
CREATE POLICY "tenants_update_admin" ON public.tenants
  FOR UPDATE TO authenticated
  USING (id = public.current_tenant_id() AND public.has_any_role(auth.uid(), ARRAY['tenant_admin','igazgato']))
  WITH CHECK (id = public.current_tenant_id());

CREATE POLICY "profiles_select_self_or_tenant" ON public.profiles
  FOR SELECT TO authenticated
  USING (id = auth.uid() OR (tenant_id IS NOT NULL AND tenant_id = public.current_tenant_id()));
CREATE POLICY "profiles_insert_self" ON public.profiles
  FOR INSERT TO authenticated WITH CHECK (id = auth.uid());
CREATE POLICY "profiles_update_self_or_admin" ON public.profiles
  FOR UPDATE TO authenticated
  USING (
    id = auth.uid()
    OR (tenant_id = public.current_tenant_id()
        AND public.has_any_role(auth.uid(), ARRAY['tenant_admin','igazgato','intezetvezeto']))
  );

CREATE POLICY "roles_select_all" ON public.roles
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "user_roles_select_tenant" ON public.user_roles
  FOR SELECT TO authenticated USING (tenant_id = public.current_tenant_id());
CREATE POLICY "user_roles_write_admin" ON public.user_roles
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
    AND public.has_any_role(auth.uid(), ARRAY['tenant_admin','igazgato','intezetvezeto']))
  WITH CHECK (tenant_id = public.current_tenant_id()
    AND public.has_any_role(auth.uid(), ARRAY['tenant_admin','igazgato','intezetvezeto']));

CREATE POLICY "staff_levels_select_tenant" ON public.staff_levels
  FOR SELECT TO authenticated USING (tenant_id = public.current_tenant_id());
CREATE POLICY "staff_levels_write_admin" ON public.staff_levels
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
    AND public.has_any_role(auth.uid(), ARRAY['tenant_admin','igazgato','intezetvezeto']))
  WITH CHECK (tenant_id = public.current_tenant_id()
    AND public.has_any_role(auth.uid(), ARRAY['tenant_admin','igazgato','intezetvezeto']));

CREATE POLICY "clinics_select_tenant" ON public.clinics
  FOR SELECT TO authenticated USING (tenant_id = public.current_tenant_id());
CREATE POLICY "clinics_write_admin" ON public.clinics
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
    AND public.has_any_role(auth.uid(), ARRAY['tenant_admin','igazgato','intezetvezeto']))
  WITH CHECK (tenant_id = public.current_tenant_id());

CREATE POLICY "sites_select_tenant" ON public.sites
  FOR SELECT TO authenticated USING (tenant_id = public.current_tenant_id());
CREATE POLICY "sites_write_admin" ON public.sites
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
    AND public.has_any_role(auth.uid(), ARRAY['tenant_admin','igazgato','intezetvezeto','telephelyvezeto']))
  WITH CHECK (tenant_id = public.current_tenant_id());

CREATE POLICY "org_units_select_tenant" ON public.org_units
  FOR SELECT TO authenticated USING (tenant_id = public.current_tenant_id());
CREATE POLICY "org_units_write_admin" ON public.org_units
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
    AND public.has_any_role(auth.uid(), ARRAY['tenant_admin','igazgato','intezetvezeto','telephelyvezeto']))
  WITH CHECK (tenant_id = public.current_tenant_id());

CREATE POLICY "specialties_select_all" ON public.specialties
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "specialties_write_admin" ON public.specialties
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'tenant_admin'))
  WITH CHECK (public.has_role(auth.uid(), 'tenant_admin'));

CREATE POLICY "ous_select_tenant" ON public.org_unit_specialties
  FOR SELECT TO authenticated USING (tenant_id = public.current_tenant_id());
CREATE POLICY "ous_write_admin" ON public.org_unit_specialties
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
    AND public.has_any_role(auth.uid(), ARRAY['tenant_admin','igazgato','intezetvezeto','telephelyvezeto']))
  WITH CHECK (tenant_id = public.current_tenant_id());

-- ============================================================
-- TRIGGER: auto profile on signup
-- ============================================================
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, teljes_nev, foglalkozas_tipus)
  VALUES (
    NEW.id, NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'teljes_nev', NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
    'egyeb'
  );
  RETURN NEW;
END; $$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- updated_at
CREATE OR REPLACE FUNCTION public.touch_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public
AS $$ BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

CREATE TRIGGER touch_tenants BEFORE UPDATE ON public.tenants
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER touch_profiles BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER touch_clinics BEFORE UPDATE ON public.clinics
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER touch_sites BEFORE UPDATE ON public.sites
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER touch_org_units BEFORE UPDATE ON public.org_units
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
