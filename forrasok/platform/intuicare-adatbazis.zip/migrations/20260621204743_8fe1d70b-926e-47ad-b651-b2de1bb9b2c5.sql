CREATE OR REPLACE FUNCTION public.apply_approved_change_request()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.status = 'approved' AND OLD.status <> 'approved' THEN
    IF NEW.request_type = 'cancel' THEN
      UPDATE public.schedule_assignments
         SET status = 'torolt'::assignment_status
       WHERE id = NEW.assignment_id;
    ELSIF NEW.request_type = 'swap' AND NEW.target_user_id IS NOT NULL THEN
      UPDATE public.schedule_assignments
         SET user_id = NEW.target_user_id
       WHERE id = NEW.assignment_id;
    END IF;
  END IF;
  RETURN NEW;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.apply_approved_change_request() FROM PUBLIC, anon;

DROP TRIGGER IF EXISTS scr_apply_approved ON public.schedule_change_requests;
CREATE TRIGGER scr_apply_approved
  AFTER UPDATE ON public.schedule_change_requests
  FOR EACH ROW EXECUTE FUNCTION public.apply_approved_change_request();