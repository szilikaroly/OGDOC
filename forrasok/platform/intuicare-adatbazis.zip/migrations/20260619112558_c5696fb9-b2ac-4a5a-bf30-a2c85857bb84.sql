
-- =========================================================
-- 1) Új enumok
-- =========================================================
do $$ begin
  create type public.uzemmod_tipus as enum
    ('folyamatos_24_7','rendelesi_ido','programozott_nappali','muteti_blokk');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.fenntarto_tipus as enum
    ('allami','onkormanyzati','egyhazi','magan','egyeb');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.duty_szerep_tipus as enum
    ('nappali_ugyelet','ejszakai_ugyelet','hatter_ugyelet','keszenlet','muteti_ugyelet','egyeb');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.mentesseg_ok as enum
    ('terhesseg','gyermekgondozas','kor','jogviszony','egeszsegugyi','egyeb');
exception when duplicate_object then null; end $$;

-- Bővítjük az org_unit_tipus enumot
alter type public.org_unit_tipus add value if not exists 'ito';
alter type public.org_unit_tipus add value if not exists 'pito';
alter type public.org_unit_tipus add value if not exists 'egynapos';

-- =========================================================
-- 2) Meglévő táblák bővítése
-- =========================================================
alter table public.sites
  add column if not exists fenntarto_tipus public.fenntarto_tipus;

alter table public.org_units
  add column if not exists uzemmod public.uzemmod_tipus,
  add column if not exists unnepnap_uzemel boolean not null default false,
  add column if not exists agyszam int,
  add column if not exists muto_blokk_perc int,
  add column if not exists floor_id uuid;

-- üzemmód default a típusból (csak ha NULL maradt)
create or replace function public.org_units_default_uzemmod()
returns trigger language plpgsql set search_path = public as $$
begin
  if NEW.uzemmod is null then
    NEW.uzemmod := case NEW.tipus
      when 'ito' then 'folyamatos_24_7'::public.uzemmod_tipus
      when 'pito' then 'folyamatos_24_7'::public.uzemmod_tipus
      when 'fekvobeteg_osztaly' then 'folyamatos_24_7'::public.uzemmod_tipus
      when 'muto' then 'muteti_blokk'::public.uzemmod_tipus
      when 'kismuto' then 'muteti_blokk'::public.uzemmod_tipus
      when 'egynapos' then 'programozott_nappali'::public.uzemmod_tipus
      when 'ambulancia' then 'rendelesi_ido'::public.uzemmod_tipus
      when 'rendelo' then 'rendelesi_ido'::public.uzemmod_tipus
      else 'rendelesi_ido'::public.uzemmod_tipus
    end;
  end if;
  return NEW;
end $$;

drop trigger if exists trg_org_units_default_uzemmod on public.org_units;
create trigger trg_org_units_default_uzemmod
before insert or update of tipus, uzemmod on public.org_units
for each row execute function public.org_units_default_uzemmod();

-- backfill üzemmód
update public.org_units set uzemmod = case tipus
  when 'fekvobeteg_osztaly' then 'folyamatos_24_7'::public.uzemmod_tipus
  when 'muto' then 'muteti_blokk'::public.uzemmod_tipus
  when 'kismuto' then 'muteti_blokk'::public.uzemmod_tipus
  when 'ambulancia' then 'rendelesi_ido'::public.uzemmod_tipus
  when 'rendelo' then 'rendelesi_ido'::public.uzemmod_tipus
  else 'rendelesi_ido'::public.uzemmod_tipus
end where uzemmod is null;

-- =========================================================
-- 3) floors (szint/emelet)
-- =========================================================
create table if not exists public.floors (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  site_id uuid not null references public.sites(id) on delete cascade,
  szint text not null,
  megnevezes text,
  sorrend int not null default 0,
  aktiv boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update, delete on public.floors to authenticated;
grant all on public.floors to service_role;
alter table public.floors enable row level security;

create policy "floors_select_tenant" on public.floors for select to authenticated
  using (tenant_id = public.current_tenant_id());
create policy "floors_manage_org" on public.floors for all to authenticated
  using (tenant_id = public.current_tenant_id()
         and (public.has_permission(auth.uid(),'manage_org')
              or public.has_permission(auth.uid(),'manage_tenant')))
  with check (tenant_id = public.current_tenant_id()
         and (public.has_permission(auth.uid(),'manage_org')
              or public.has_permission(auth.uid(),'manage_tenant')));

drop trigger if exists trg_floors_touch on public.floors;
create trigger trg_floors_touch before update on public.floors
for each row execute function public.touch_updated_at();

-- floor_id FK org_units-on (most adjuk hozzá, hogy létezzen a floors)
do $$ begin
  alter table public.org_units
    add constraint org_units_floor_id_fkey
    foreign key (floor_id) references public.floors(id) on delete set null;
exception when duplicate_object then null; end $$;

-- =========================================================
-- 4) org_unit_departments (megosztott egységek)
-- =========================================================
create table if not exists public.org_unit_departments (
  tenant_id uuid not null,
  org_unit_id uuid not null references public.org_units(id) on delete cascade,
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  szerep text not null check (szerep in ('mukodteto','hasznalo')),
  created_at timestamptz not null default now(),
  primary key (org_unit_id, clinic_id)
);
grant select, insert, update, delete on public.org_unit_departments to authenticated;
grant all on public.org_unit_departments to service_role;
alter table public.org_unit_departments enable row level security;

create policy "oud_select_tenant" on public.org_unit_departments for select to authenticated
  using (tenant_id = public.current_tenant_id());
create policy "oud_manage_org" on public.org_unit_departments for all to authenticated
  using (tenant_id = public.current_tenant_id()
         and (public.has_permission(auth.uid(),'manage_org')
              or public.has_permission(auth.uid(),'manage_tenant')))
  with check (tenant_id = public.current_tenant_id()
         and (public.has_permission(auth.uid(),'manage_org')
              or public.has_permission(auth.uid(),'manage_tenant')));

-- =========================================================
-- 5) duty_lines (ügyeleti sorok)
-- =========================================================
create table if not exists public.duty_lines (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  site_id uuid not null references public.sites(id) on delete cascade,
  nev text not null,
  kod text,
  szerep_tipus public.duty_szerep_tipus not null,
  primary_org_unit_id uuid references public.org_units(id) on delete set null,
  letszam smallint not null default 1 check (letszam between 1 and 20),
  napok int[] not null default '{1,2,3,4,5,6,7}',
  kezd_ido time,
  veg_ido time,
  unnepnap_uzemel boolean not null default true,
  aktiv boolean not null default true,
  sorrend int not null default 0,
  megjegyzes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update, delete on public.duty_lines to authenticated;
grant all on public.duty_lines to service_role;
alter table public.duty_lines enable row level security;

create policy "duty_lines_select_tenant" on public.duty_lines for select to authenticated
  using (tenant_id = public.current_tenant_id());
create policy "duty_lines_manage" on public.duty_lines for all to authenticated
  using (tenant_id = public.current_tenant_id()
         and (public.has_permission(auth.uid(),'manage_org')
              or public.has_permission(auth.uid(),'manage_schedule')
              or public.has_permission(auth.uid(),'manage_tenant')))
  with check (tenant_id = public.current_tenant_id()
         and (public.has_permission(auth.uid(),'manage_org')
              or public.has_permission(auth.uid(),'manage_schedule')
              or public.has_permission(auth.uid(),'manage_tenant')));

drop trigger if exists trg_duty_lines_touch on public.duty_lines;
create trigger trg_duty_lines_touch before update on public.duty_lines
for each row execute function public.touch_updated_at();

-- =========================================================
-- 6) duty_line_coverage
-- =========================================================
create table if not exists public.duty_line_coverage (
  tenant_id uuid not null,
  duty_line_id uuid not null references public.duty_lines(id) on delete cascade,
  org_unit_id uuid not null references public.org_units(id) on delete cascade,
  kotelezo boolean not null default true,
  megjegyzes text,
  primary key (duty_line_id, org_unit_id)
);
grant select, insert, update, delete on public.duty_line_coverage to authenticated;
grant all on public.duty_line_coverage to service_role;
alter table public.duty_line_coverage enable row level security;

create policy "dlc_select_tenant" on public.duty_line_coverage for select to authenticated
  using (tenant_id = public.current_tenant_id());
create policy "dlc_manage" on public.duty_line_coverage for all to authenticated
  using (tenant_id = public.current_tenant_id()
         and (public.has_permission(auth.uid(),'manage_org')
              or public.has_permission(auth.uid(),'manage_schedule')
              or public.has_permission(auth.uid(),'manage_tenant')))
  with check (tenant_id = public.current_tenant_id()
         and (public.has_permission(auth.uid(),'manage_org')
              or public.has_permission(auth.uid(),'manage_schedule')
              or public.has_permission(auth.uid(),'manage_tenant')));

-- =========================================================
-- 7) duty_line_eligibility
-- =========================================================
create table if not exists public.duty_line_eligibility (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  duty_line_id uuid not null references public.duty_lines(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  foglalkozas_tipus public.foglalkozas_tipus,
  staff_role_id uuid references public.staff_roles(id) on delete cascade,
  prioritas int not null default 100,
  created_at timestamptz not null default now(),
  check (
    (user_id is not null)::int
    + (foglalkozas_tipus is not null)::int
    + (staff_role_id is not null)::int = 1
  )
);
grant select, insert, update, delete on public.duty_line_eligibility to authenticated;
grant all on public.duty_line_eligibility to service_role;
alter table public.duty_line_eligibility enable row level security;

create policy "dle_select_tenant" on public.duty_line_eligibility for select to authenticated
  using (tenant_id = public.current_tenant_id());
create policy "dle_manage" on public.duty_line_eligibility for all to authenticated
  using (tenant_id = public.current_tenant_id()
         and (public.has_permission(auth.uid(),'manage_org')
              or public.has_permission(auth.uid(),'manage_schedule')
              or public.has_permission(auth.uid(),'manage_tenant')))
  with check (tenant_id = public.current_tenant_id()
         and (public.has_permission(auth.uid(),'manage_org')
              or public.has_permission(auth.uid(),'manage_schedule')
              or public.has_permission(auth.uid(),'manage_tenant')));

-- =========================================================
-- 8) mandatory_duty_rules
-- =========================================================
create table if not exists public.mandatory_duty_rules (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  scope_tipus text not null check (scope_tipus in ('global','foglalkozas_tipus','staff_role','site')),
  scope_value text,
  min_per_honap int not null default 0 check (min_per_honap >= 0),
  max_per_honap int check (max_per_honap is null or max_per_honap >= min_per_honap),
  megjegyzes text,
  aktiv boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update, delete on public.mandatory_duty_rules to authenticated;
grant all on public.mandatory_duty_rules to service_role;
alter table public.mandatory_duty_rules enable row level security;

create policy "mdr_select_tenant" on public.mandatory_duty_rules for select to authenticated
  using (tenant_id = public.current_tenant_id());
create policy "mdr_manage" on public.mandatory_duty_rules for all to authenticated
  using (tenant_id = public.current_tenant_id()
         and (public.has_permission(auth.uid(),'manage_schedule')
              or public.has_permission(auth.uid(),'manage_tenant')))
  with check (tenant_id = public.current_tenant_id()
         and (public.has_permission(auth.uid(),'manage_schedule')
              or public.has_permission(auth.uid(),'manage_tenant')));

drop trigger if exists trg_mdr_touch on public.mandatory_duty_rules;
create trigger trg_mdr_touch before update on public.mandatory_duty_rules
for each row execute function public.touch_updated_at();

-- =========================================================
-- 9) mandatory_duty_exemptions
-- =========================================================
create table if not exists public.mandatory_duty_exemptions (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  user_id uuid not null references public.profiles(id) on delete cascade,
  ok public.mentesseg_ok not null,
  ervenyes_tol date not null,
  ervenyes_ig date,
  indok text,
  status text not null default 'jovahagyasra_var' check (status in ('jovahagyasra_var','jovahagyott','elutasitott')),
  jovahagyo_id uuid references public.profiles(id) on delete set null,
  jovahagyas_at timestamptz,
  jovahagyas_indok text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update, delete on public.mandatory_duty_exemptions to authenticated;
grant all on public.mandatory_duty_exemptions to service_role;
alter table public.mandatory_duty_exemptions enable row level security;

create policy "mde_select_own_or_hr" on public.mandatory_duty_exemptions for select to authenticated
  using (tenant_id = public.current_tenant_id()
         and (user_id = auth.uid()
              or public.has_permission(auth.uid(),'view_team')
              or public.has_permission(auth.uid(),'manage_schedule')
              or public.has_permission(auth.uid(),'manage_tenant')));

create policy "mde_insert_self_or_hr" on public.mandatory_duty_exemptions for insert to authenticated
  with check (tenant_id = public.current_tenant_id()
              and (user_id = auth.uid()
                   or public.has_permission(auth.uid(),'manage_tenant')));

create policy "mde_update_hr" on public.mandatory_duty_exemptions for update to authenticated
  using (tenant_id = public.current_tenant_id()
         and public.has_permission(auth.uid(),'manage_tenant'))
  with check (tenant_id = public.current_tenant_id()
              and public.has_permission(auth.uid(),'manage_tenant'));

create policy "mde_delete_hr" on public.mandatory_duty_exemptions for delete to authenticated
  using (tenant_id = public.current_tenant_id()
         and public.has_permission(auth.uid(),'manage_tenant'));

drop trigger if exists trg_mde_touch on public.mandatory_duty_exemptions;
create trigger trg_mde_touch before update on public.mandatory_duty_exemptions
for each row execute function public.touch_updated_at();

-- HR guard: jóváhagyás csak HR, saját kérelmét nem
create or replace function public.mandatory_duty_exemption_guard()
returns trigger language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid();
begin
  if TG_OP = 'UPDATE' and NEW.status is distinct from OLD.status
     and NEW.status in ('jovahagyott','elutasitott') then
    if not coalesce(public.has_permission(v_uid,'manage_tenant'), false) then
      raise exception 'Mentesség jóváhagyásához HR (tenant-admin) jogosultság szükséges.' using errcode='42501';
    end if;
    if NEW.user_id = v_uid then
      raise exception 'Saját mentességét nem hagyhatja jóvá.' using errcode='42501';
    end if;
    if NEW.status = 'elutasitott' and coalesce(btrim(NEW.jovahagyas_indok),'') = '' then
      raise exception 'Elutasításhoz kötelező az indoklás.' using errcode='22023';
    end if;
    NEW.jovahagyo_id := v_uid;
    NEW.jovahagyas_at := now();
  end if;
  return NEW;
end $$;

drop trigger if exists trg_mde_guard on public.mandatory_duty_exemptions;
create trigger trg_mde_guard before update on public.mandatory_duty_exemptions
for each row execute function public.mandatory_duty_exemption_guard();

-- =========================================================
-- 10) Helper függvény: effektív kötelező minimum
-- =========================================================
create or replace function public.get_required_monthly_duty(_user_id uuid, _honap date)
returns int language plpgsql stable security definer set search_path = public as $$
declare
  v_min int := 0;
  v_prof record;
  v_has_exempt boolean;
begin
  select p.foglalkozas_tipus::text as fog, p.tenant_id
    into v_prof
    from public.profiles p where p.id = _user_id;
  if not found then return 0; end if;

  -- aktív, jóváhagyott mentesség?
  select exists(
    select 1 from public.mandatory_duty_exemptions e
    where e.user_id = _user_id
      and e.status = 'jovahagyott'
      and e.ervenyes_tol <= (date_trunc('month', _honap)::date + interval '1 month - 1 day')::date
      and (e.ervenyes_ig is null or e.ervenyes_ig >= date_trunc('month', _honap)::date)
  ) into v_has_exempt;
  if v_has_exempt then return 0; end if;

  select coalesce(max(r.min_per_honap), 0) into v_min
  from public.mandatory_duty_rules r
  where r.tenant_id = v_prof.tenant_id and r.aktiv
    and (
      r.scope_tipus = 'global'
      or (r.scope_tipus = 'foglalkozas_tipus' and r.scope_value = v_prof.fog)
    );
  return v_min;
end $$;
grant execute on function public.get_required_monthly_duty(uuid,date) to authenticated;

-- =========================================================
-- 11) Helper függvény: adott napi aktív ügyeleti sorok
-- =========================================================
create or replace function public.current_duty_lines(_site_id uuid, _datum date)
returns table (
  id uuid, nev text, szerep_tipus public.duty_szerep_tipus,
  letszam smallint, kezd_ido time, veg_ido time, primary_org_unit_id uuid
)
language sql stable security definer set search_path = public as $$
  select dl.id, dl.nev, dl.szerep_tipus, dl.letszam, dl.kezd_ido, dl.veg_ido, dl.primary_org_unit_id
  from public.duty_lines dl
  where dl.site_id = _site_id
    and dl.aktiv
    and dl.tenant_id = public.current_tenant_id()
    and extract(isodow from _datum)::int = any(dl.napok)
    and (dl.unnepnap_uzemel
         or not exists (
           select 1 from public.public_holidays h
            where h.datum = _datum
              and (h.tenant_id is null or h.tenant_id = public.current_tenant_id())
         ))
  order by dl.sorrend, dl.nev;
$$;
grant execute on function public.current_duty_lines(uuid,date) to authenticated;

-- indexek
create index if not exists idx_floors_site on public.floors(site_id);
create index if not exists idx_org_units_floor on public.org_units(floor_id);
create index if not exists idx_duty_lines_site on public.duty_lines(site_id);
create index if not exists idx_dlc_line on public.duty_line_coverage(duty_line_id);
create index if not exists idx_dle_line on public.duty_line_eligibility(duty_line_id);
create index if not exists idx_mde_user on public.mandatory_duty_exemptions(user_id);
