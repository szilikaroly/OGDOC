CREATE OR REPLACE FUNCTION public.eligible_swap_targets(_assignment_id uuid)
RETURNS TABLE(user_id uuid, display_name text, last_worked timestamptz)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_feladatkor uuid;
  v_tenant     uuid;
  v_owner      uuid;
BEGIN
  SELECT sa.feladatkor_id, sa.tenant_id, sa.user_id
    INTO v_feladatkor, v_tenant, v_owner
  FROM public.schedule_assignments sa
  WHERE sa.id = _assignment_id;

  IF v_owner IS NULL THEN
    RETURN;
  END IF;

  IF v_owner <> auth.uid()
     AND NOT has_permission(auth.uid(), 'manage_schedule')
     AND NOT has_permission(auth.uid(), 'manage_tenant') THEN
    RETURN;
  END IF;

  IF v_feladatkor IS NULL THEN
    RETURN;
  END IF;

  RETURN QUERY
  SELECT p.id,
         COALESCE(NULLIF(p.teljes_nev, ''), p.email, 'Felhasználó') AS display_name,
         max(sa2.kezdo_idopont) AS last_worked
  FROM public.schedule_assignments sa2
  JOIN public.profiles p ON p.id = sa2.user_id
  WHERE sa2.tenant_id = v_tenant
    AND sa2.feladatkor_id = v_feladatkor
    AND sa2.kezdo_idopont >= now() - interval '12 months'
    AND sa2.user_id <> v_owner
  GROUP BY p.id, p.teljes_nev, p.email
  ORDER BY display_name;
END;
$$;