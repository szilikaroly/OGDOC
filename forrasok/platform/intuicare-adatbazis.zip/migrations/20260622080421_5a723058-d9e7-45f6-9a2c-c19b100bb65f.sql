
ALTER TABLE public.surgery_types
  ADD COLUMN IF NOT EXISTS operator_min_seniority text CHECK (operator_min_seniority IN ('szakorvos','foorvos')),
  ADD COLUMN IF NOT EXISTS delegalas_kotelezo boolean NOT NULL DEFAULT false;

ALTER TABLE public.surgery_cases
  ADD COLUMN IF NOT EXISTS operator_min_seniority_override text CHECK (operator_min_seniority_override IN ('szakorvos','foorvos')),
  ADD COLUMN IF NOT EXISTS kotelezo_eroforrasok_override jsonb;

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS napi_mutet_cap integer;
