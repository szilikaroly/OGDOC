-- 1) akut flag a profile_unavailability táblán
ALTER TABLE public.profile_unavailability
  ADD COLUMN IF NOT EXISTS akut BOOLEAN NOT NULL DEFAULT false;

CREATE INDEX IF NOT EXISTS idx_profile_unavailability_akut
  ON public.profile_unavailability(akut, kezdo_datum, zaro_datum)
  WHERE akut = true;

-- 2) helyettesítés-kereső függvény
CREATE OR REPLACE FUNCTION public.find_acute_replacements(
  p_user_id uuid,
  p_datum date
)
RETURNS TABLE (
  user_id uuid,
  teljes_nev text,
  email text,
  foglalkozas_tipus text,
  egyezo_skillek text[],
  egyezo_kepzettsegek text[],
  egyezo_skill_szam int,
  egyezo_kepz_szam int,
  pozitiv_kapcsolat boolean,
  match_score int,
  szabad boolean,
  aktiv_korlatozok text[]
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT (
      public.has_permission(auth.uid(), 'view_team')
   OR public.has_permission(auth.uid(), 'manage_schedule')
   OR public.has_permission(auth.uid(), 'manage_tenant')
  ) THEN
    RAISE EXCEPTION 'Nincs jogosultsága helyettesítési javaslat lekérdezéséhez.'
      USING ERRCODE = '42501';
  END IF;

  RETURN QUERY
  WITH
    sick AS (
      SELECT p.foglalkozas_tipus, p.tenant_id
      FROM public.profiles p
      WHERE p.id = p_user_id
    ),
    sick_skills AS (
      SELECT skill_id FROM public.profile_skills WHERE profile_skills.user_id = p_user_id
    ),
    sick_cert_keys AS (
      SELECT DISTINCT lower(nev) AS k FROM public.profile_certifications WHERE profile_certifications.user_id = p_user_id
    ),
    cand AS (
      SELECT p.id, p.teljes_nev, p.email, p.foglalkozas_tipus::text AS foglalkozas_tipus
      FROM public.profiles p, sick s
      WHERE p.id <> p_user_id
        AND p.tenant_id IS NOT DISTINCT FROM s.tenant_id
        AND p.foglalkozas_tipus = s.foglalkozas_tipus
    ),
    c_skills AS (
      SELECT ps.user_id, array_agg(sk.nev ORDER BY sk.nev) AS nevek, count(*)::int AS cnt
      FROM public.profile_skills ps
      JOIN public.skills sk ON sk.id = ps.skill_id
      WHERE ps.skill_id IN (SELECT skill_id FROM sick_skills)
        AND ps.user_id IN (SELECT id FROM cand)
      GROUP BY ps.user_id
    ),
    c_certs AS (
      SELECT pc.user_id, array_agg(pc.nev ORDER BY pc.nev) AS nevek, count(*)::int AS cnt
      FROM public.profile_certifications pc
      WHERE lower(pc.nev) IN (SELECT k FROM sick_cert_keys)
        AND pc.user_id IN (SELECT id FROM cand)
      GROUP BY pc.user_id
    ),
    c_unav AS (
      SELECT pu.user_id
      FROM public.profile_unavailability pu
      WHERE pu.status IN ('jovahagyott','jovahagyasra_var')
        AND pu.kezdo_datum <= p_datum
        AND pu.zaro_datum >= p_datum
        AND pu.user_id IN (SELECT id FROM cand)
      GROUP BY pu.user_id
    ),
    c_peer_pos AS (
      SELECT pl.to_user_id AS user_id
      FROM public.profile_peer_links pl
      WHERE pl.from_user_id = p_user_id
        AND pl.tipus = 'szivesen_dolgozik_vele'
        AND pl.status = 'aktiv'
    ),
    c_peer_neg AS (
      SELECT pl.to_user_id AS user_id
      FROM public.profile_peer_links pl
      WHERE pl.from_user_id = p_user_id
        AND pl.tipus = 'nem_dolgozik_vele'
        AND pl.status = 'jovahagyott'
      UNION
      SELECT pl.from_user_id AS user_id
      FROM public.profile_peer_links pl
      WHERE pl.to_user_id = p_user_id
        AND pl.tipus = 'nem_dolgozik_vele'
        AND pl.status = 'jovahagyott'
    ),
    c_constraints AS (
      SELECT pc.user_id,
             array_agg(pc.tipus::text ORDER BY pc.tipus::text) AS aktiv
      FROM public.profile_constraints pc
      WHERE (pc.ervenyes_ig IS NULL OR pc.ervenyes_ig >= p_datum)
        AND pc.ervenyes_tol <= p_datum
        AND pc.user_id IN (SELECT id FROM cand)
      GROUP BY pc.user_id
    )
  SELECT
    c.id,
    c.teljes_nev,
    c.email,
    c.foglalkozas_tipus,
    COALESCE(cs.nevek, ARRAY[]::text[])  AS egyezo_skillek,
    COALESCE(cc.nevek, ARRAY[]::text[])  AS egyezo_kepzettsegek,
    COALESCE(cs.cnt, 0)                  AS egyezo_skill_szam,
    COALESCE(cc.cnt, 0)                  AS egyezo_kepz_szam,
    (cp.user_id IS NOT NULL)             AS pozitiv_kapcsolat,
    (COALESCE(cs.cnt, 0) * 10
       + COALESCE(cc.cnt, 0) * 5
       + CASE WHEN cp.user_id IS NOT NULL THEN 3 ELSE 0 END)::int AS match_score,
    (cu.user_id IS NULL AND cn.user_id IS NULL) AS szabad,
    COALESCE(cc2.aktiv, ARRAY[]::text[]) AS aktiv_korlatozok
  FROM cand c
  LEFT JOIN c_skills      cs  ON cs.user_id  = c.id
  LEFT JOIN c_certs       cc  ON cc.user_id  = c.id
  LEFT JOIN c_unav        cu  ON cu.user_id  = c.id
  LEFT JOIN c_peer_pos    cp  ON cp.user_id  = c.id
  LEFT JOIN c_peer_neg    cn  ON cn.user_id  = c.id
  LEFT JOIN c_constraints cc2 ON cc2.user_id = c.id
  WHERE COALESCE(cs.cnt, 0) > 0
     OR COALESCE(cc.cnt, 0) > 0
  ORDER BY
    (cu.user_id IS NULL AND cn.user_id IS NULL) DESC,
    (COALESCE(cs.cnt, 0) * 10
       + COALESCE(cc.cnt, 0) * 5
       + CASE WHEN cp.user_id IS NOT NULL THEN 3 ELSE 0 END) DESC,
    c.teljes_nev;
END;
$$;

REVOKE ALL ON FUNCTION public.find_acute_replacements(uuid, date) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.find_acute_replacements(uuid, date) TO authenticated;

COMMENT ON FUNCTION public.find_acute_replacements(uuid, date) IS
  'Akut betegjelentésekhez helyettesítési javaslat. Visszaad azonos foglalkozású, közös skill/képzettségű kollégákat, jelölve a napi szabad állapotot és kapcsolati súlyt.';