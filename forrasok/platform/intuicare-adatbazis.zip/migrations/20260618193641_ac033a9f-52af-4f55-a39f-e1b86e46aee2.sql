DROP VIEW IF EXISTS public.profile_scheduling_facts CASCADE;

CREATE VIEW public.profile_scheduling_facts
WITH (security_invoker = true) AS
WITH
  c_agg AS (
    SELECT
      user_id,
      bool_or(tipus = 'terhes' AND (ervenyes_ig IS NULL OR ervenyes_ig >= CURRENT_DATE)) AS terhes,
      bool_or(tipus = 'szoptat' AND (ervenyes_ig IS NULL OR ervenyes_ig >= CURRENT_DATE)) AS szoptat,
      bool_or(tipus = 'kisgyermek_otthon' AND (ervenyes_ig IS NULL OR ervenyes_ig >= CURRENT_DATE)) AS kisgyermek_otthon,
      bool_or(tipus = 'egyedulnevelo' AND (ervenyes_ig IS NULL OR ervenyes_ig >= CURRENT_DATE)) AS egyedulnevelo,
      bool_or(tipus = 'tartos_betegseg' AND (ervenyes_ig IS NULL OR ervenyes_ig >= CURRENT_DATE)) AS tartos_betegseg,
      bool_or(tipus = 'mozgaskorlatozas' AND (ervenyes_ig IS NULL OR ervenyes_ig >= CURRENT_DATE)) AS mozgaskorlatozas,
      bool_or(tipus = 'vedendokoru' AND (ervenyes_ig IS NULL OR ervenyes_ig >= CURRENT_DATE)) AS vedendokoru,
      count(*) FILTER (WHERE (ervenyes_ig IS NULL OR ervenyes_ig >= CURRENT_DATE))::int AS aktiv_constraint_count
    FROM public.profile_constraints
    GROUP BY user_id
  ),
  u_agg AS (
    SELECT
      user_id,
      COALESCE(SUM(
        CASE WHEN status = 'jovahagyott'
             AND kezdo_datum <= (CURRENT_DATE + INTERVAL '30 day')::date
             AND zaro_datum >= CURRENT_DATE
        THEN (LEAST(zaro_datum, (CURRENT_DATE + INTERVAL '30 day')::date)
              - GREATEST(kezdo_datum, CURRENT_DATE) + 1) END
      ), 0)::int AS tavollet_nap_30,
      COALESCE(SUM(
        CASE WHEN status = 'jovahagyott'
             AND kezdo_datum <= (CURRENT_DATE + INTERVAL '90 day')::date
             AND zaro_datum >= CURRENT_DATE
        THEN (LEAST(zaro_datum, (CURRENT_DATE + INTERVAL '90 day')::date)
              - GREATEST(kezdo_datum, CURRENT_DATE) + 1) END
      ), 0)::int AS tavollet_nap_90,
      count(*) FILTER (WHERE status = 'jovahagyasra_var')::int AS fuggo_tavollet_count,
      count(*) FILTER (WHERE status = 'jovahagyott' AND zaro_datum >= CURRENT_DATE)::int AS jovahagyott_tavollet_count
    FROM public.profile_unavailability
    GROUP BY user_id
  ),
  p_agg AS (
    SELECT
      from_user_id AS user_id,
      count(*) FILTER (WHERE tipus = 'szivesen_dolgozik_vele' AND status = 'aktiv')::int AS pozitiv_kapcsolat,
      count(*) FILTER (WHERE tipus = 'nem_dolgozik_vele' AND status = 'jovahagyott')::int AS negativ_kapcsolat,
      count(*) FILTER (WHERE tipus = 'mentor' AND status = 'aktiv')::int AS mentor_count,
      count(*) FILTER (WHERE tipus = 'mentee' AND status = 'aktiv')::int AS mentee_count
    FROM public.profile_peer_links
    GROUP BY from_user_id
  ),
  ct_agg AS (
    SELECT
      user_id,
      count(*)::int AS contact_count,
      bool_or(is_primary AND ertesites_engedelyezve) AS van_aktiv_ertesites
    FROM public.profile_contacts
    GROUP BY user_id
  )
SELECT
  pr.id AS user_id,
  pr.tenant_id,
  pr.teljes_nev,
  pr.becenev,
  pr.foglalkozas_tipus,
  pr.email,
  pp.heti_max_ora,
  pp.havi_max_ugyelet,
  COALESCE(pp.ugyelet_utan_pihenonap, false) AS ugyelet_utan_pihenonap,
  COALESCE(pp.ugyelet_utan_min_ora, 0) AS ugyelet_utan_min_ora,
  COALESCE(pp.egymas_utani_max_ugyelet, 0) AS egymas_utani_max_ugyelet,
  COALESCE(pp.last_minute_elerheto, false) AS last_minute_elerheto,
  pp.last_minute_orahatar,
  pp.utazasi_perc_max,
  COALESCE(pp.preferalt_musakok::text[], ARRAY[]::text[]) AS preferalt_musakok,
  COALESCE(pp.tiltott_napok, ARRAY[]::int[]) AS tiltott_napok,
  COALESCE(pp.nyelvek, ARRAY[]::text[]) AS nyelvek,
  COALESCE(ca.terhes, false) AS terhes,
  COALESCE(ca.szoptat, false) AS szoptat,
  COALESCE(ca.kisgyermek_otthon, false) AS kisgyermek_otthon,
  COALESCE(ca.egyedulnevelo, false) AS egyedulnevelo,
  COALESCE(ca.tartos_betegseg, false) AS tartos_betegseg,
  COALESCE(ca.mozgaskorlatozas, false) AS mozgaskorlatozas,
  COALESCE(ca.vedendokoru, false) AS vedendokoru,
  COALESCE(ca.aktiv_constraint_count, 0) AS aktiv_constraint_count,
  (COALESCE(ca.terhes, false) OR COALESCE(ca.szoptat, false)) AS tiltott_ejszaka,
  (COALESCE(ca.terhes, false) OR COALESCE(ca.mozgaskorlatozas, false)) AS tiltott_sugar_zona,
  GREATEST(
    CASE WHEN COALESCE(pp.ugyelet_utan_pihenonap, false) THEN COALESCE(pp.ugyelet_utan_min_ora, 24) ELSE 0 END,
    CASE WHEN COALESCE(ca.terhes, false) OR COALESCE(ca.kisgyermek_otthon, false) THEN 24 ELSE 0 END
  ) AS min_pihenoido_ora,
  COALESCE(ua.tavollet_nap_30, 0) AS tavollet_nap_30,
  COALESCE(ua.tavollet_nap_90, 0) AS tavollet_nap_90,
  COALESCE(ua.fuggo_tavollet_count, 0) AS fuggo_tavollet_count,
  COALESCE(ua.jovahagyott_tavollet_count, 0) AS jovahagyott_tavollet_count,
  COALESCE(pa.pozitiv_kapcsolat, 0) AS pozitiv_kapcsolat,
  COALESCE(pa.negativ_kapcsolat, 0) AS negativ_kapcsolat,
  COALESCE(pa.mentor_count, 0) AS mentor_count,
  COALESCE(pa.mentee_count, 0) AS mentee_count,
  COALESCE(cta.contact_count, 0) AS contact_count,
  COALESCE(cta.van_aktiv_ertesites, false) AS van_aktiv_ertesites
FROM public.profiles pr
LEFT JOIN public.profile_preferences pp ON pp.user_id = pr.id
LEFT JOIN c_agg  ca  ON ca.user_id = pr.id
LEFT JOIN u_agg  ua  ON ua.user_id = pr.id
LEFT JOIN p_agg  pa  ON pa.user_id = pr.id
LEFT JOIN ct_agg cta ON cta.user_id = pr.id;

GRANT SELECT ON public.profile_scheduling_facts TO authenticated;

COMMENT ON VIEW public.profile_scheduling_facts IS
  'Hard/soft constraint aggregátum a beosztó-motor (M1) és a csapat admin-nézet számára. RLS-örökölt (security_invoker).';