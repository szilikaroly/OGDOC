
-- ============================================================
-- SECURITY DEFINER függvények: csak authenticated futtathatja
-- ============================================================
REVOKE EXECUTE ON FUNCTION public.current_tenant_id() FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.has_role(UUID, TEXT) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.has_any_role(UUID, TEXT[]) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.touch_updated_at() FROM PUBLIC, anon, authenticated;

GRANT EXECUTE ON FUNCTION public.current_tenant_id() TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_role(UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_any_role(UUID, TEXT[]) TO authenticated;

-- ============================================================
-- SEED: szerepkörök
-- ============================================================
INSERT INTO public.roles (kulcs, megnevezes, kategoria, sorrend) VALUES
  -- Orvos
  ('hallgato',           'Hallgató',                 'orvos', 10),
  ('gyakornok_orvos',    'Gyakornok orvos',          'orvos', 20),
  ('rezidens',           'Rezidens',                 'orvos', 30),
  ('szakgyakornok',      'Szakgyakornok',            'orvos', 40),
  ('vezetorezidens',     'Vezetőrezidens',           'orvos', 50),
  ('szakorvos',          'Szakorvos',                'orvos', 60),
  ('foorvos',            'Főorvos',                  'orvos', 70),
  ('szakteruleti_expert','Szakterületi expert',      'orvos', 80),
  -- Vezetői
  ('ugyeletvezeto',      'Ügyeletvezető',            'vezeto', 100),
  ('telephelyvezeto',    'Telephelyvezető',          'vezeto', 110),
  ('intezetvezeto',      'Intézetvezető',            'vezeto', 120),
  ('igazgato',           'Igazgató',                 'vezeto', 130),
  -- Szakdolgozó / szülésznő / ápoló
  ('tanulo',             'Tanuló',                   'szakdolgozo', 10),
  ('gyakornok_szakd',    'Gyakornok szakdolgozó',    'szakdolgozo', 20),
  ('gyakorlo',           'Gyakorló',                 'szakdolgozo', 30),
  ('pro',                'Pro',                      'szakdolgozo', 40),
  ('mester',             'Mester',                   'szakdolgozo', 50),
  -- Admin
  ('tenant_admin',       'Bérlő admin',              'admin', 1),
  ('beoszto',            'Beosztó',                  'admin', 2);

-- ============================================================
-- SEED: szakterületek
-- ============================================================
INSERT INTO public.specialties (kod, nev) VALUES
  ('HAZIORVOS',  'Háziorvosi'),
  ('SZULNOGY',   'Szülészet-nőgyógyászat'),
  ('ENDOKRIN',   'Endokrinológia'),
  ('BELGYOGY',   'Belgyógyászat'),
  ('SEBESZ',     'Sebészet'),
  ('TRAUMAT',    'Traumatológia'),
  ('ANESZT',     'Aneszteziológia és intenzív terápia'),
  ('GYERMEK',    'Gyermekgyógyászat'),
  ('UROLOGIA',   'Urológia'),
  ('KARDIO',     'Kardiológia');
