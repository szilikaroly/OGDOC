
-- ============================================================
-- I kör: jelenlét + GDPR-hozzájárulás
-- ============================================================

DO $$ BEGIN
  CREATE TYPE public.attendance_event_type AS ENUM ('bejelentkezes','kijelentkezes','szunet_kezdet','szunet_veg','manualis_korrekcio');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.attendance_method AS ENUM ('web','mobil','nfc','qr','manualis','admin');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.consent_purpose AS ENUM (
    'jelenlet_helymeghatarozas','jelenlet_eszkozazonosito','biometrikus','egeszsegugyi_adat',
    'paciensi_kommunikacio','marketing','egyeb'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- Jelenléti horgonyok
CREATE TABLE IF NOT EXISTS public.attendance_anchors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  site_id uuid REFERENCES public.sites(id) ON DELETE SET NULL,
  org_unit_id uuid REFERENCES public.org_units(id) ON DELETE SET NULL,
  nev text NOT NULL,
  tipus text NOT NULL DEFAULT 'geofence',  -- geofence | ip | nfc | qr
  geo_lat numeric(9,6),
  geo_lng numeric(9,6),
  geo_sugar_m integer,
  ip_cidr text,
  nfc_uid text,
  qr_secret text,
  ervenyes boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.attendance_anchors TO authenticated;
GRANT ALL ON public.attendance_anchors TO service_role;
ALTER TABLE public.attendance_anchors ENABLE ROW LEVEL SECURITY;

CREATE POLICY aa_select ON public.attendance_anchors FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());

CREATE POLICY aa_write_admin ON public.attendance_anchors FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_tenant'))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_tenant'));

CREATE TRIGGER aa_touch BEFORE UPDATE ON public.attendance_anchors
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- Jelenlét-események
CREATE TABLE IF NOT EXISTS public.attendance_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  anchor_id uuid REFERENCES public.attendance_anchors(id) ON DELETE SET NULL,
  esemeny_tipus public.attendance_event_type NOT NULL,
  modszer public.attendance_method NOT NULL DEFAULT 'web',
  idopont timestamptz NOT NULL DEFAULT now(),
  eszkoz_azonosito text,
  ip_cim inet,
  geo_lat numeric(9,6),
  geo_lng numeric(9,6),
  geo_pontossag_m numeric(6,2),
  horgony_egyezes boolean,
  user_agent text,
  megjegyzes text,
  korrigalo_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_ae_user_time ON public.attendance_events (user_id, idopont);
CREATE INDEX IF NOT EXISTS idx_ae_anchor ON public.attendance_events (anchor_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.attendance_events TO authenticated;
GRANT ALL ON public.attendance_events TO service_role;
ALTER TABLE public.attendance_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY ae_select ON public.attendance_events FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(),'manage_schedule')
    OR public.has_permission(auth.uid(),'view_team')
    OR public.has_permission(auth.uid(),'manage_tenant')
  ));

-- Dolgozó csak a saját, jelenlegi időpontú eseményt rögzíthet; HR/beosztó bármit
CREATE POLICY ae_insert_self ON public.attendance_events FOR INSERT TO authenticated
  WITH CHECK (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(),'manage_schedule')
    OR public.has_permission(auth.uid(),'manage_tenant')
  ));

CREATE POLICY ae_update_admin ON public.attendance_events FOR UPDATE TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    public.has_permission(auth.uid(),'manage_schedule')
    OR public.has_permission(auth.uid(),'manage_tenant')
  ))
  WITH CHECK (tenant_id = public.current_tenant_id() AND (
    public.has_permission(auth.uid(),'manage_schedule')
    OR public.has_permission(auth.uid(),'manage_tenant')
  ));

CREATE POLICY ae_delete_admin ON public.attendance_events FOR DELETE TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_tenant'));

CREATE TRIGGER audit_ae AFTER INSERT OR UPDATE OR DELETE ON public.attendance_events
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- GDPR hozzájárulások
CREATE TABLE IF NOT EXISTS public.gdpr_consents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  cel public.consent_purpose NOT NULL,
  dokumentum_verzio text NOT NULL,
  elfogadva_at timestamptz NOT NULL DEFAULT now(),
  visszavonva_at timestamptz,
  forras_ip inet,
  forras_user_agent text,
  szoveg_hivatkozas text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, user_id, cel, dokumentum_verzio)
);

CREATE INDEX IF NOT EXISTS idx_gc_user ON public.gdpr_consents (user_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.gdpr_consents TO authenticated;
GRANT ALL ON public.gdpr_consents TO service_role;
ALTER TABLE public.gdpr_consents ENABLE ROW LEVEL SECURITY;

CREATE POLICY gc_select ON public.gdpr_consents FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(),'manage_tenant')
  ));

CREATE POLICY gc_insert_self ON public.gdpr_consents FOR INSERT TO authenticated
  WITH CHECK (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(),'manage_tenant')
  ));

-- Visszavonás (visszavonva_at állítás) a saját rekordra
CREATE POLICY gc_update_self ON public.gdpr_consents FOR UPDATE TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(),'manage_tenant')
  ))
  WITH CHECK (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(),'manage_tenant')
  ));

CREATE TRIGGER gc_touch BEFORE UPDATE ON public.gdpr_consents
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TRIGGER audit_gc AFTER INSERT OR UPDATE OR DELETE ON public.gdpr_consents
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();
