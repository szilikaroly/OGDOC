-- =========================================================================
-- Phase 2: schedule_change_requests + skill check + change notifications
-- =========================================================================

-- 1) Enums
DO $$ BEGIN
  CREATE TYPE public.schedule_change_request_type AS ENUM ('cancel', 'swap');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.schedule_change_request_status AS ENUM ('pending', 'approved', 'rejected', 'cancelled');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- 2) Table
CREATE TABLE IF NOT EXISTS public.schedule_change_requests (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id        uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  assignment_id    uuid NOT NULL REFERENCES public.schedule_assignments(id) ON DELETE CASCADE,
  requester_id     uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  request_type     public.schedule_change_request_type NOT NULL,
  target_user_id   uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  reason           text,
  status           public.schedule_change_request_status NOT NULL DEFAULT 'pending',
  decided_by       uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  decided_at       timestamptz,
  decision_note    text,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT scr_swap_needs_target CHECK (
    (request_type = 'swap'   AND target_user_id IS NOT NULL)
 OR (request_type = 'cancel' AND target_user_id IS NULL)
  )
);

CREATE INDEX IF NOT EXISTS idx_scr_assignment ON public.schedule_change_requests(assignment_id);
CREATE INDEX IF NOT EXISTS idx_scr_requester  ON public.schedule_change_requests(requester_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_scr_target     ON public.schedule_change_requests(target_user_id) WHERE target_user_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_scr_pending    ON public.schedule_change_requests(tenant_id, status) WHERE status = 'pending';

-- 3) Grants (BEFORE RLS)
GRANT SELECT, INSERT, UPDATE, DELETE ON public.schedule_change_requests TO authenticated;
GRANT ALL ON public.schedule_change_requests TO service_role;

-- 4) RLS
ALTER TABLE public.schedule_change_requests ENABLE ROW LEVEL SECURITY;

-- SELECT: requester, target user, managers, admin
CREATE POLICY "scr_select"
  ON public.schedule_change_requests
  FOR SELECT TO authenticated
  USING (
    tenant_id = current_tenant_id() AND (
      requester_id = auth.uid()
      OR target_user_id = auth.uid()
      OR has_permission(auth.uid(), 'manage_schedule')
      OR has_permission(auth.uid(), 'manage_tenant')
    )
  );

-- INSERT: requester for OWN assignment, only when status is pending and no other pending exists
CREATE POLICY "scr_insert_own"
  ON public.schedule_change_requests
  FOR INSERT TO authenticated
  WITH CHECK (
    tenant_id = current_tenant_id()
    AND requester_id = auth.uid()
    AND status = 'pending'
    AND EXISTS (
      SELECT 1 FROM public.schedule_assignments sa
      WHERE sa.id = assignment_id AND sa.user_id = auth.uid()
    )
  );

-- UPDATE: requester can cancel own pending request; manager can decide
CREATE POLICY "scr_update_requester_cancel"
  ON public.schedule_change_requests
  FOR UPDATE TO authenticated
  USING (
    tenant_id = current_tenant_id()
    AND requester_id = auth.uid()
    AND status = 'pending'
  )
  WITH CHECK (
    tenant_id = current_tenant_id()
    AND requester_id = auth.uid()
    AND status IN ('pending','cancelled')
  );

CREATE POLICY "scr_update_manager"
  ON public.schedule_change_requests
  FOR UPDATE TO authenticated
  USING (
    tenant_id = current_tenant_id()
    AND (has_permission(auth.uid(), 'manage_schedule') OR has_permission(auth.uid(), 'manage_tenant'))
  )
  WITH CHECK (
    tenant_id = current_tenant_id()
    AND (has_permission(auth.uid(), 'manage_schedule') OR has_permission(auth.uid(), 'manage_tenant'))
  );

-- 5) Trigger: validate swap target has compatible skill (worked same feladatkor in last 12 months)
CREATE OR REPLACE FUNCTION public.validate_swap_request()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_feladatkor uuid;
  v_match int;
BEGIN
  IF NEW.request_type <> 'swap' THEN
    RETURN NEW;
  END IF;

  IF NEW.target_user_id = NEW.requester_id THEN
    RAISE EXCEPTION 'A célfelhasználó nem lehet azonos a kérelmezővel.';
  END IF;

  SELECT feladatkor_id INTO v_feladatkor
  FROM public.schedule_assignments WHERE id = NEW.assignment_id;

  -- If assignment has no feladatkor, require manager skill verification (block self-service swap)
  IF v_feladatkor IS NULL THEN
    RAISE EXCEPTION 'Ehhez a műszakhoz nincs feladatkör rendelve, csere csak vezetővel egyeztetve lehetséges.';
  END IF;

  SELECT count(*) INTO v_match
  FROM public.schedule_assignments
  WHERE user_id = NEW.target_user_id
    AND feladatkor_id = v_feladatkor
    AND kezdo_idopont >= now() - interval '12 months';

  IF v_match = 0 THEN
    RAISE EXCEPTION 'A választott felhasználó nem rendelkezik a szükséges tapasztalattal ehhez a feladatkörhöz (utolsó 12 hónap).';
  END IF;

  RETURN NEW;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.validate_swap_request() FROM PUBLIC, anon;

DROP TRIGGER IF EXISTS scr_validate_swap ON public.schedule_change_requests;
CREATE TRIGGER scr_validate_swap
  BEFORE INSERT ON public.schedule_change_requests
  FOR EACH ROW EXECUTE FUNCTION public.validate_swap_request();

-- 6) Trigger: touch updated_at + set decided_at when status leaves 'pending' by manager
CREATE OR REPLACE FUNCTION public.scr_touch_decided()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  IF NEW.status IS DISTINCT FROM OLD.status
     AND NEW.status IN ('approved','rejected')
     AND NEW.decided_at IS NULL THEN
    NEW.decided_at = now();
    NEW.decided_by = COALESCE(NEW.decided_by, auth.uid());
  END IF;
  RETURN NEW;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.scr_touch_decided() FROM PUBLIC, anon;

DROP TRIGGER IF EXISTS scr_touch ON public.schedule_change_requests;
CREATE TRIGGER scr_touch
  BEFORE UPDATE ON public.schedule_change_requests
  FOR EACH ROW EXECUTE FUNCTION public.scr_touch_decided();

-- 7) Trigger: notify requester + target on request lifecycle, notify managers on new pending
CREATE OR REPLACE FUNCTION public.notify_scr_lifecycle()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_label text;
  v_when  timestamptz;
  v_mgr   uuid;
BEGIN
  SELECT sa.kezdo_idopont INTO v_when
  FROM public.schedule_assignments sa WHERE sa.id = NEW.assignment_id;

  v_label := to_char(v_when AT TIME ZONE 'Europe/Budapest', 'YYYY-MM-DD HH24:MI');

  IF TG_OP = 'INSERT' THEN
    -- Notify all managers in tenant
    FOR v_mgr IN
      SELECT ur.user_id FROM public.user_roles ur
      WHERE ur.tenant_id = NEW.tenant_id
        AND (has_permission(ur.user_id, 'manage_schedule') OR has_permission(ur.user_id, 'manage_tenant'))
    LOOP
      INSERT INTO public.notifications(tenant_id, user_id, tipus, cim, uzenet, link)
      VALUES (NEW.tenant_id, v_mgr, 'beosztas_keres',
        CASE NEW.request_type WHEN 'cancel' THEN 'Új lemondási kérés' ELSE 'Új csere kérés' END,
        'Műszak: ' || v_label || ' – jóváhagyásra vár',
        '/beosztas');
    END LOOP;
    -- Notify target on swap
    IF NEW.request_type = 'swap' AND NEW.target_user_id IS NOT NULL THEN
      INSERT INTO public.notifications(tenant_id, user_id, tipus, cim, uzenet, link)
      VALUES (NEW.tenant_id, NEW.target_user_id, 'beosztas_keres',
        'Csereajánlat érkezett',
        'Egy kollégád felajánlotta a műszakát ('|| v_label ||') cserére.',
        '/beosztas');
    END IF;

  ELSIF TG_OP = 'UPDATE' AND NEW.status IS DISTINCT FROM OLD.status THEN
    -- Notify requester about decision
    INSERT INTO public.notifications(tenant_id, user_id, tipus, cim, uzenet, link)
    VALUES (NEW.tenant_id, NEW.requester_id, 'beosztas_keres',
      CASE NEW.status
        WHEN 'approved' THEN 'Kérelmed jóváhagyva'
        WHEN 'rejected' THEN 'Kérelmed elutasítva'
        WHEN 'cancelled' THEN 'Kérelmed visszavonva'
        ELSE 'Kérelem státusza módosult'
      END,
      'Műszak: ' || v_label || COALESCE(' – ' || NEW.decision_note, ''),
      '/beosztas');
  END IF;

  RETURN NEW;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.notify_scr_lifecycle() FROM PUBLIC, anon;

DROP TRIGGER IF EXISTS scr_notify ON public.schedule_change_requests;
CREATE TRIGGER scr_notify
  AFTER INSERT OR UPDATE ON public.schedule_change_requests
  FOR EACH ROW EXECUTE FUNCTION public.notify_scr_lifecycle();

-- 8) Trigger: notify owner when their assignment time/status/category changes
CREATE OR REPLACE FUNCTION public.notify_assignment_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_changes text[] := ARRAY[]::text[];
  v_msg text;
BEGIN
  IF NEW.user_id IS NULL THEN RETURN NEW; END IF;
  IF auth.uid() IS NOT NULL AND NEW.user_id = auth.uid() THEN
    -- Owner edited own row (e.g. note), skip self-notification
    RETURN NEW;
  END IF;

  IF NEW.kezdo_idopont IS DISTINCT FROM OLD.kezdo_idopont
     OR NEW.zaro_idopont IS DISTINCT FROM OLD.zaro_idopont THEN
    v_changes := array_append(v_changes,
      'Új időpont: ' || to_char(NEW.kezdo_idopont AT TIME ZONE 'Europe/Budapest','YYYY-MM-DD HH24:MI')
       || '–' || to_char(NEW.zaro_idopont AT TIME ZONE 'Europe/Budapest','HH24:MI'));
  END IF;
  IF NEW.status IS DISTINCT FROM OLD.status THEN
    v_changes := array_append(v_changes, 'Státusz: ' || NEW.status::text);
  END IF;
  IF NEW.kategoria IS DISTINCT FROM OLD.kategoria THEN
    v_changes := array_append(v_changes, 'Kategória: ' || NEW.kategoria::text);
  END IF;

  IF array_length(v_changes, 1) IS NULL THEN
    RETURN NEW;
  END IF;

  v_msg := array_to_string(v_changes, ' • ');

  INSERT INTO public.notifications(tenant_id, user_id, tipus, cim, uzenet, link)
  VALUES (NEW.tenant_id, NEW.user_id, 'beosztas',
    'Beosztásod változott',
    v_msg,
    '/iranyitopult');

  RETURN NEW;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.notify_assignment_change() FROM PUBLIC, anon;

DROP TRIGGER IF EXISTS sa_notify_change ON public.schedule_assignments;
CREATE TRIGGER sa_notify_change
  AFTER UPDATE ON public.schedule_assignments
  FOR EACH ROW EXECUTE FUNCTION public.notify_assignment_change();