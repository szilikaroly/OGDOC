
/* ===== 1. ENUMs ===== */
DO $$ BEGIN
  CREATE TYPE public.qet_event_type AS ENUM (
    'appointment_created',
    'appointment_scheduled',
    'surgery_created',
    'surgery_scheduled'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.reminder_channel AS ENUM ('notification', 'push', 'email', 'sms');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

/* ===== 2. questionnaire_event_triggers ===== */
CREATE TABLE IF NOT EXISTS public.questionnaire_event_triggers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  questionnaire_id UUID NOT NULL REFERENCES public.questionnaires(id) ON DELETE CASCADE,
  event_type public.qet_event_type NOT NULL,
  /* Esedékesség az esemény előtt (pozitív szám = előtte annyi nappal). */
  due_offset_days INTEGER NOT NULL DEFAULT 0,
  /* Bucketek napokban, pl. {-7,-3,-1,1,3,7}: negatív = esedékesség előtt, pozitív = után */
  reminder_buckets INTEGER[] NOT NULL DEFAULT ARRAY[-7,-3,-1,1,3,7],
  channel public.reminder_channel NOT NULL DEFAULT 'notification',
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, questionnaire_id, event_type)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.questionnaire_event_triggers TO authenticated;
GRANT ALL ON public.questionnaire_event_triggers TO service_role;
ALTER TABLE public.questionnaire_event_triggers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "qet_select" ON public.questionnaire_event_triggers
  FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_tenant'));

CREATE POLICY "qet_write" ON public.questionnaire_event_triggers
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_tenant'))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_tenant'));

CREATE TRIGGER trg_qet_touch BEFORE UPDATE ON public.questionnaire_event_triggers
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE INDEX IF NOT EXISTS qet_lookup_idx
  ON public.questionnaire_event_triggers (tenant_id, event_type) WHERE active;

/* ===== 3. assignment_reminder_log ===== */
CREATE TABLE IF NOT EXISTS public.assignment_reminder_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  assignment_id UUID NOT NULL REFERENCES public.questionnaire_assignments(id) ON DELETE CASCADE,
  /* Bucket napokban (negatív = előtte, pozitív = utána). */
  bucket_days INTEGER NOT NULL,
  channel public.reminder_channel NOT NULL DEFAULT 'notification',
  sent_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  notes TEXT,
  UNIQUE (assignment_id, bucket_days, channel)
);

GRANT SELECT ON public.assignment_reminder_log TO authenticated;
GRANT ALL ON public.assignment_reminder_log TO service_role;
ALTER TABLE public.assignment_reminder_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "arl_select" ON public.assignment_reminder_log
  FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_tenant'));

CREATE INDEX IF NOT EXISTS arl_assignment_idx ON public.assignment_reminder_log (assignment_id);

/* ===== 4. Auto-assignment helper ===== */
CREATE OR REPLACE FUNCTION public.auto_assign_from_event(
  _tenant_id UUID,
  _event_type public.qet_event_type,
  _patient_id UUID,
  _event_at TIMESTAMPTZ,
  _appointment_id UUID DEFAULT NULL
) RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_count INTEGER := 0;
  v_trig RECORD;
  v_due TIMESTAMPTZ;
  v_token TEXT;
BEGIN
  IF _patient_id IS NULL THEN RETURN 0; END IF;

  FOR v_trig IN
    SELECT id, questionnaire_id, due_offset_days
      FROM public.questionnaire_event_triggers
     WHERE tenant_id = _tenant_id
       AND event_type = _event_type
       AND active
  LOOP
    /* Ne dupla-rendeljünk ugyanahhoz a forrás eseményhez. */
    IF EXISTS (
      SELECT 1 FROM public.questionnaire_assignments qa
       WHERE qa.tenant_id = _tenant_id
         AND qa.patient_id = _patient_id
         AND qa.questionnaire_id = v_trig.questionnaire_id
         AND qa.status IN ('assigned', 'in_progress')
         AND ( _appointment_id IS NULL OR qa.appointment_id = _appointment_id )
    ) THEN CONTINUE; END IF;

    v_due := CASE
      WHEN _event_at IS NULL THEN now() + (v_trig.due_offset_days || ' days')::interval
      ELSE _event_at - (v_trig.due_offset_days || ' days')::interval
    END;

    v_token := encode(gen_random_bytes(16), 'hex');

    INSERT INTO public.questionnaire_assignments
      (tenant_id, questionnaire_id, patient_id, appointment_id, due_at, kind, status, token)
    VALUES
      (_tenant_id, v_trig.questionnaire_id, _patient_id, _appointment_id, v_due,
       'egyedi', 'assigned', v_token);

    v_count := v_count + 1;
  END LOOP;

  RETURN v_count;
END $$;

/* ===== 5. Triggers on appointments / surgery_cases ===== */
CREATE OR REPLACE FUNCTION public.trg_appt_auto_assign()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_event_at TIMESTAMPTZ;
BEGIN
  IF NEW.patient_id IS NULL THEN RETURN NEW; END IF;
  SELECT s.kezdo_ts INTO v_event_at FROM public.appointment_slots s WHERE s.id = NEW.slot_id;

  IF TG_OP = 'INSERT' THEN
    PERFORM public.auto_assign_from_event(
      NEW.tenant_id, 'appointment_created'::public.qet_event_type,
      NEW.patient_id, v_event_at, NEW.id);
    IF NEW.status = 'megerositett' OR NEW.status::text = 'foglalt' OR NEW.status::text = 'megerositett' THEN
      PERFORM public.auto_assign_from_event(
        NEW.tenant_id, 'appointment_scheduled'::public.qet_event_type,
        NEW.patient_id, v_event_at, NEW.id);
    END IF;
  ELSIF TG_OP = 'UPDATE'
        AND (OLD.status IS DISTINCT FROM NEW.status)
        AND NEW.status::text IN ('megerositett','foglalt') THEN
    PERFORM public.auto_assign_from_event(
      NEW.tenant_id, 'appointment_scheduled'::public.qet_event_type,
      NEW.patient_id, v_event_at, NEW.id);
  END IF;

  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_appt_auto_assign ON public.appointments;
CREATE TRIGGER trg_appt_auto_assign
  AFTER INSERT OR UPDATE OF status ON public.appointments
  FOR EACH ROW EXECUTE FUNCTION public.trg_appt_auto_assign();

CREATE OR REPLACE FUNCTION public.trg_surgery_auto_assign()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    PERFORM public.auto_assign_from_event(
      NEW.tenant_id, 'surgery_created'::public.qet_event_type,
      NEW.patient_id, NEW.tervezett_kezdo_ido, NULL);
    IF NEW.tervezett_kezdo_ido IS NOT NULL THEN
      PERFORM public.auto_assign_from_event(
        NEW.tenant_id, 'surgery_scheduled'::public.qet_event_type,
        NEW.patient_id, NEW.tervezett_kezdo_ido, NULL);
    END IF;
  ELSIF TG_OP = 'UPDATE'
        AND OLD.tervezett_kezdo_ido IS DISTINCT FROM NEW.tervezett_kezdo_ido
        AND NEW.tervezett_kezdo_ido IS NOT NULL THEN
    PERFORM public.auto_assign_from_event(
      NEW.tenant_id, 'surgery_scheduled'::public.qet_event_type,
      NEW.patient_id, NEW.tervezett_kezdo_ido, NULL);
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_surgery_auto_assign ON public.surgery_cases;
CREATE TRIGGER trg_surgery_auto_assign
  AFTER INSERT OR UPDATE OF tervezett_kezdo_ido ON public.surgery_cases
  FOR EACH ROW EXECUTE FUNCTION public.trg_surgery_auto_assign();

/* ===== 6. Bucket-tudatos send_questionnaire_reminders ===== */
CREATE OR REPLACE FUNCTION public.send_questionnaire_reminders()
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_count INTEGER := 0;
  v_rec RECORD;
  v_days_to_due INTEGER;
  v_bucket INTEGER;
  v_b INTEGER;
  v_buckets INTEGER[];
  v_channel public.reminder_channel;
BEGIN
  FOR v_rec IN
    SELECT qa.id, qa.tenant_id, qa.patient_id, qa.questionnaire_id, qa.due_at,
           p.felelos_user_id, q.title,
           COALESCE(t.reminder_buckets, ARRAY[-7,-3,-1,1,3,7]::INTEGER[]) AS buckets,
           COALESCE(t.channel, 'notification'::public.reminder_channel)   AS channel
      FROM public.questionnaire_assignments qa
      JOIN public.questionnaires q ON q.id = qa.questionnaire_id
      LEFT JOIN public.patients p ON p.id = qa.patient_id
      LEFT JOIN public.questionnaire_event_triggers t
             ON t.tenant_id = qa.tenant_id
            AND t.questionnaire_id = qa.questionnaire_id
            AND t.active
     WHERE qa.status IN ('assigned','in_progress')
       AND qa.due_at IS NOT NULL
  LOOP
    v_days_to_due := EXTRACT(DAY FROM (v_rec.due_at - now()))::INTEGER;
    /* Aktuális bucket = az a legközelebbi konfigurált küszöb, amit a "due-tól vett előjeles távolság" elért. */
    /* Negatív bucket = még due előtt vagyunk, pozitív = után. */
    /* Aktuális előjeles távolság: -v_days_to_due (mert v_days_to_due = due - now napokban). */
    v_bucket := NULL;
    v_buckets := v_rec.buckets;
    FOREACH v_b IN ARRAY v_buckets LOOP
      /* "elértük" akkor, ha v_b negatív: -v_days_to_due >= v_b  (azaz közelebb vagyunk due-hoz, mint a küszöb)
         ha v_b pozitív: -v_days_to_due >= v_b (azaz due óta legalább v_b nap telt el) */
      IF (-v_days_to_due) >= v_b THEN
        IF v_bucket IS NULL OR v_b > v_bucket THEN v_bucket := v_b; END IF;
      END IF;
    END LOOP;

    IF v_bucket IS NULL THEN CONTINUE; END IF;

    v_channel := v_rec.channel;

    /* Ha ehhez a buckethez már ment értesítés, ugorjuk. */
    IF EXISTS (
      SELECT 1 FROM public.assignment_reminder_log l
       WHERE l.assignment_id = v_rec.id
         AND l.bucket_days  = v_bucket
         AND l.channel      = v_channel
    ) THEN CONTINUE; END IF;

    /* Értesítés a felelős klinikusnak (jelenleg notification csatorna). */
    IF v_rec.felelos_user_id IS NOT NULL THEN
      INSERT INTO public.notifications (tenant_id, user_id, tipus, cim, uzenet, link)
      VALUES (v_rec.tenant_id, v_rec.felelos_user_id, 'kerdoiv',
              CASE WHEN v_bucket < 0 THEN 'Közelgő kérdőív' ELSE 'Lejárt kérdőív' END,
              format('A(z) "%s" kérdőív %s. (bucket: %s nap, határidő: %s)',
                     v_rec.title,
                     CASE WHEN v_bucket < 0 THEN 'hamarosan esedékes' ELSE 'lejárt és nincs kitöltve' END,
                     v_bucket,
                     to_char(v_rec.due_at AT TIME ZONE 'Europe/Budapest','YYYY-MM-DD')),
              '/kerdoivek');
    END IF;

    INSERT INTO public.assignment_reminder_log (tenant_id, assignment_id, bucket_days, channel, notes)
    VALUES (v_rec.tenant_id, v_rec.id, v_bucket, v_channel,
            format('days_to_due=%s', v_days_to_due));

    UPDATE public.questionnaire_assignments
       SET reminded_at = now(),
           reminder_count = reminder_count + 1
     WHERE id = v_rec.id;

    v_count := v_count + 1;
  END LOOP;

  RETURN v_count;
END $$;
