
ALTER TABLE public.schedule_runs
  ADD COLUMN IF NOT EXISTS publikalt_at timestamptz,
  ADD COLUMN IF NOT EXISTS publikalo_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL;

CREATE OR REPLACE FUNCTION public.publish_schedule_run(_run_id uuid)
RETURNS TABLE(published_count int, notified_count int)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_run public.schedule_runs%ROWTYPE;
  v_notified int := 0;
  v_assignments int := 0;
BEGIN
  SELECT * INTO v_run FROM public.schedule_runs WHERE id = _run_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Futtatás nem található.' USING ERRCODE = '22023';
  END IF;
  IF v_run.tenant_id IS DISTINCT FROM public.current_tenant_id() THEN
    RAISE EXCEPTION 'Nincs jogosultság ehhez a futtatáshoz.' USING ERRCODE = '42501';
  END IF;
  IF NOT (
    COALESCE(public.has_permission(v_uid,'manage_schedule'), false)
    OR COALESCE(public.has_permission(v_uid,'manage_tenant'), false)
  ) THEN
    RAISE EXCEPTION 'Csak beosztás-vezető publikálhat.' USING ERRCODE = '42501';
  END IF;
  IF v_run.status NOT IN ('kesz') THEN
    RAISE EXCEPTION 'Csak "kész" státuszú futtatás publikálható (jelenleg: %).', v_run.status USING ERRCODE = '22023';
  END IF;

  UPDATE public.schedule_runs
     SET status = 'publikalt',
         publikalt_at = now(),
         publikalo_id = v_uid
   WHERE id = _run_id;

  SELECT COUNT(*) INTO v_assignments FROM public.schedule_assignments WHERE run_id = _run_id;

  WITH affected AS (
    SELECT DISTINCT user_id
    FROM public.schedule_assignments
    WHERE run_id = _run_id AND user_id IS NOT NULL
  ),
  ins AS (
    INSERT INTO public.notifications (tenant_id, user_id, tipus, cim, uzenet, link)
    SELECT v_run.tenant_id, a.user_id, 'beosztas',
           'Új beosztás közzétéve',
           'Időszak: ' || to_char(v_run.idoszak_kezdet, 'YYYY-MM-DD') ||
             ' – ' || to_char(v_run.idoszak_veg, 'YYYY-MM-DD'),
           '/munkaido'
    FROM affected a
    RETURNING 1
  )
  SELECT COUNT(*) INTO v_notified FROM ins;

  RETURN QUERY SELECT v_assignments, v_notified;
END;
$$;

GRANT EXECUTE ON FUNCTION public.publish_schedule_run(uuid) TO authenticated;
