
-- 1. Add 'kiemelt' to surgery_types
ALTER TABLE public.surgery_types ADD COLUMN IF NOT EXISTS kiemelt boolean NOT NULL DEFAULT false;

-- 2. Add kiemelt + delegalt_operator + szukseges_szerepek override to surgery_cases
ALTER TABLE public.surgery_cases
  ADD COLUMN IF NOT EXISTS kiemelt boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS delegalt_operator_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS szukseges_szerepek jsonb;

-- 3. New table: surgery_case_assignments
CREATE TABLE IF NOT EXISTS public.surgery_case_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  case_id uuid NOT NULL REFERENCES public.surgery_cases(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  szerep text NOT NULL CHECK (szerep IN ('operator','asszisztens','felugyelo','aneszteziologus','mutos_szakdolgozo','egyeb')),
  indok text,
  ai_generated boolean NOT NULL DEFAULT false,
  created_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (case_id, user_id, szerep)
);

CREATE INDEX IF NOT EXISTS idx_sca_case ON public.surgery_case_assignments(case_id);
CREATE INDEX IF NOT EXISTS idx_sca_user ON public.surgery_case_assignments(user_id);
CREATE INDEX IF NOT EXISTS idx_sca_tenant ON public.surgery_case_assignments(tenant_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.surgery_case_assignments TO authenticated;
GRANT ALL ON public.surgery_case_assignments TO service_role;

ALTER TABLE public.surgery_case_assignments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "sca_select_tenant" ON public.surgery_case_assignments
  FOR SELECT TO authenticated
  USING (tenant_id = current_tenant_id());

CREATE POLICY "sca_write_or_team" ON public.surgery_case_assignments
  FOR ALL TO authenticated
  USING (
    tenant_id = current_tenant_id()
    AND (has_permission(auth.uid(),'manage_or_blocks') OR has_permission(auth.uid(),'book_or_case'))
  )
  WITH CHECK (
    tenant_id = current_tenant_id()
    AND (has_permission(auth.uid(),'manage_or_blocks') OR has_permission(auth.uid(),'book_or_case'))
  );

CREATE TRIGGER trg_sca_touch BEFORE UPDATE ON public.surgery_case_assignments
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
