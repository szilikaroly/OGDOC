
CREATE TABLE public.role_permissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  role_kulcs TEXT NOT NULL,
  perm TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (role_kulcs, perm)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.role_permissions TO authenticated;
GRANT ALL ON public.role_permissions TO service_role;

ALTER TABLE public.role_permissions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "role_perms_read_all" ON public.role_permissions
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "role_perms_admin_write" ON public.role_permissions
  FOR ALL TO authenticated
  USING (public.has_any_role(auth.uid(), ARRAY['tenant_admin']))
  WITH CHECK (public.has_any_role(auth.uid(), ARRAY['tenant_admin']));

-- Seed: a jelenlegi has_permission mapping
INSERT INTO public.role_permissions(role_kulcs, perm) VALUES
  ('tenant_admin','manage_tenant'),
  ('tenant_admin','manage_org'),('igazgato','manage_org'),('intezetvezeto','manage_org'),('telephelyvezeto','manage_org'),
  ('tenant_admin','manage_roles'),('igazgato','manage_roles'),('intezetvezeto','manage_roles'),
  ('tenant_admin','manage_schedule'),('igazgato','manage_schedule'),('intezetvezeto','manage_schedule'),('telephelyvezeto','manage_schedule'),('ugyeletvezeto','manage_schedule'),('beoszto','manage_schedule'),
  ('tenant_admin','manage_training'),('igazgato','manage_training'),('intezetvezeto','manage_training'),('foorvos','manage_training'),
  ('tenant_admin','manage_patients'),('igazgato','manage_patients'),('intezetvezeto','manage_patients'),('telephelyvezeto','manage_patients'),('foorvos','manage_patients'),('szakorvos','manage_patients'),('rezidens','manage_patients'),('szakgyakornok','manage_patients'),('vezetorezidens','manage_patients'),
  ('tenant_admin','view_audit'),('igazgato','view_audit'),('intezetvezeto','view_audit'),
  ('tenant_admin','view_team'),('igazgato','view_team'),('intezetvezeto','view_team'),('telephelyvezeto','view_team'),('foorvos','view_team'),('ugyeletvezeto','view_team'),('beoszto','view_team')
ON CONFLICT DO NOTHING;

-- has_permission tábla-alapú
CREATE OR REPLACE FUNCTION public.has_permission(_user_id UUID, _perm TEXT)
RETURNS BOOLEAN
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles ur
    JOIN public.roles r ON r.id = ur.role_id
    JOIN public.role_permissions rp ON rp.role_kulcs = r.kulcs
    WHERE ur.user_id = _user_id
      AND rp.perm = _perm
      AND (ur.ervenyes_tol IS NULL OR ur.ervenyes_tol <= now())
      AND (ur.ervenyes_ig IS NULL OR ur.ervenyes_ig >= now())
  )
$$;
