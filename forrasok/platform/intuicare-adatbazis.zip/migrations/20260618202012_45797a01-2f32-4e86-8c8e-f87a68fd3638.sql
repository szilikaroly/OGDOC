
-- ============================================================
-- J kör: napi prefek, párosítások, EMR + EESZT alapok
-- ============================================================

-- Napi preferenciák
CREATE TABLE IF NOT EXISTS public.profile_daily_preferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  nap_iso smallint NOT NULL CHECK (nap_iso BETWEEN 1 AND 7),  -- 1=hétfő..7=vasárnap
  preferalt_kezd time,
  preferalt_veg time,
  kerult_kezd time,
  kerult_veg time,
  max_muszak_hossz_ora numeric(4,1),
  ugyelet_vallal boolean,
  keszenlet_vallal boolean,
  megjegyzes text,
  ervenyes_tol date NOT NULL DEFAULT CURRENT_DATE,
  ervenyes_ig date,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, user_id, nap_iso, ervenyes_tol)
);

CREATE INDEX IF NOT EXISTS idx_pdp_user ON public.profile_daily_preferences (user_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_daily_preferences TO authenticated;
GRANT ALL ON public.profile_daily_preferences TO service_role;
ALTER TABLE public.profile_daily_preferences ENABLE ROW LEVEL SECURITY;

CREATE POLICY pdp_select ON public.profile_daily_preferences FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(),'view_team')
    OR public.has_permission(auth.uid(),'manage_schedule')
    OR public.has_permission(auth.uid(),'manage_tenant')
  ));

CREATE POLICY pdp_write_self_or_admin ON public.profile_daily_preferences FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid() OR public.has_permission(auth.uid(),'manage_tenant')
  ))
  WITH CHECK (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid() OR public.has_permission(auth.uid(),'manage_tenant')
  ));

CREATE TRIGGER pdp_touch BEFORE UPDATE ON public.profile_daily_preferences
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TRIGGER audit_pdp AFTER INSERT OR UPDATE OR DELETE ON public.profile_daily_preferences
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- Időszaki / műszak-szintű párosítási kérés
DO $$ BEGIN
  CREATE TYPE public.paired_shift_tipus AS ENUM ('egyutt_kivant','egyutt_kerult');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS public.profile_paired_shifts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  partner_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  tipus public.paired_shift_tipus NOT NULL,
  muszak_kulcs text,                       -- pl. 'ugyelet', 'nappali', NULL = bármely
  napok smallint[] NOT NULL DEFAULT '{}',  -- ISO napok, üres = bármely
  ervenyes_tol date NOT NULL DEFAULT CURRENT_DATE,
  ervenyes_ig date,
  suly smallint NOT NULL DEFAULT 50,
  indoklas text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pps_diff CHECK (user_id <> partner_id)
);

CREATE INDEX IF NOT EXISTS idx_pps_user ON public.profile_paired_shifts (user_id);
CREATE INDEX IF NOT EXISTS idx_pps_partner ON public.profile_paired_shifts (partner_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_paired_shifts TO authenticated;
GRANT ALL ON public.profile_paired_shifts TO service_role;
ALTER TABLE public.profile_paired_shifts ENABLE ROW LEVEL SECURITY;

CREATE POLICY pps_select ON public.profile_paired_shifts FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid() OR partner_id = auth.uid()
    OR public.has_permission(auth.uid(),'view_team')
    OR public.has_permission(auth.uid(),'manage_schedule')
    OR public.has_permission(auth.uid(),'manage_tenant')
  ));

CREATE POLICY pps_write_self ON public.profile_paired_shifts FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid() OR public.has_permission(auth.uid(),'manage_tenant')
  ))
  WITH CHECK (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid() OR public.has_permission(auth.uid(),'manage_tenant')
  ));

CREATE TRIGGER pps_touch BEFORE UPDATE ON public.profile_paired_shifts
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TRIGGER audit_pps AFTER INSERT OR UPDATE OR DELETE ON public.profile_paired_shifts
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ============================================================
-- EMR alapok
-- ============================================================

CREATE TABLE IF NOT EXISTS public.patients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  taj text,
  vezeteknev text NOT NULL,
  keresztnev text NOT NULL,
  szuletesi_datum date,
  nem text CHECK (nem IN ('ferfi','no','egyeb')),
  anyja_neve text,
  fo_diagnozis_bno text,
  gondozo_orvos_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  megjegyzes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, taj)
);

CREATE INDEX IF NOT EXISTS idx_patients_name ON public.patients (tenant_id, vezeteknev, keresztnev);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.patients TO authenticated;
GRANT ALL ON public.patients TO service_role;
ALTER TABLE public.patients ENABLE ROW LEVEL SECURITY;

CREATE POLICY pat_select ON public.patients FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_patients'));

CREATE POLICY pat_write ON public.patients FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_patients'))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_patients'));

CREATE TRIGGER pat_touch BEFORE UPDATE ON public.patients
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TRIGGER audit_pat AFTER INSERT OR UPDATE OR DELETE ON public.patients
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- Páciens találkozók
DO $$ BEGIN
  CREATE TYPE public.encounter_tipus AS ENUM ('ambulans','fekvobeteg','muteti','konzilium','telemedicina','egyeb');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS public.patient_encounters (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  ellatas_kezdete timestamptz NOT NULL,
  ellatas_vege timestamptz,
  tipus public.encounter_tipus NOT NULL,
  org_unit_id uuid REFERENCES public.org_units(id) ON DELETE SET NULL,
  site_id uuid REFERENCES public.sites(id) ON DELETE SET NULL,
  vezeto_orvos_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  bno_kodok text[] NOT NULL DEFAULT '{}',
  oeno_kodok text[] NOT NULL DEFAULT '{}',
  beavatkozas_ids uuid[] NOT NULL DEFAULT '{}',
  osszefoglalo text,
  intezmenyi_azonosito text,
  status text NOT NULL DEFAULT 'nyitott',  -- nyitott | lezart | torolt
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_pe_patient ON public.patient_encounters (patient_id, ellatas_kezdete DESC);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.patient_encounters TO authenticated;
GRANT ALL ON public.patient_encounters TO service_role;
ALTER TABLE public.patient_encounters ENABLE ROW LEVEL SECURITY;

CREATE POLICY penc_select ON public.patient_encounters FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_patients'));

CREATE POLICY penc_write ON public.patient_encounters FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_patients'))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_patients'));

CREATE TRIGGER penc_touch BEFORE UPDATE ON public.patient_encounters
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TRIGGER audit_penc AFTER INSERT OR UPDATE OR DELETE ON public.patient_encounters
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- EESZT azonosító-leképezés (akkreditált rendszer integrálja a tényleges adatcserét)
CREATE TABLE IF NOT EXISTS public.eeszt_patient_links (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  eeszt_page_id text,
  eeszt_org_oid text,
  hozzajarulas_status text NOT NULL DEFAULT 'ismeretlen',  -- van | nincs | visszavont | ismeretlen
  hozzajarulas_at timestamptz,
  utolso_szinkron_at timestamptz,
  megjegyzes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, patient_id)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.eeszt_patient_links TO authenticated;
GRANT ALL ON public.eeszt_patient_links TO service_role;
ALTER TABLE public.eeszt_patient_links ENABLE ROW LEVEL SECURITY;

CREATE POLICY eep_select ON public.eeszt_patient_links FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_patients'));

CREATE POLICY eep_write_admin ON public.eeszt_patient_links FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_tenant'))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_tenant'));

CREATE TRIGGER eep_touch BEFORE UPDATE ON public.eeszt_patient_links
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TRIGGER audit_eep AFTER INSERT OR UPDATE OR DELETE ON public.eeszt_patient_links
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();
