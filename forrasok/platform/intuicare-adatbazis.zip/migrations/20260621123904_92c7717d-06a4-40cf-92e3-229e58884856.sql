-- 1) push_settings
CREATE TABLE IF NOT EXISTS public.push_settings (
  tenant_id UUID PRIMARY KEY REFERENCES public.tenants(id) ON DELETE CASCADE,
  vapid_subject TEXT NOT NULL DEFAULT 'mailto:szilikaroly@gmail.com',
  enabled BOOLEAN NOT NULL DEFAULT true,
  updated_by UUID REFERENCES auth.users(id),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.push_settings TO authenticated;
GRANT ALL ON public.push_settings TO service_role;
ALTER TABLE public.push_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "tenant admins read push settings" ON public.push_settings;
CREATE POLICY "tenant admins read push settings"
  ON public.push_settings FOR SELECT TO authenticated
  USING (
    tenant_id = public.current_tenant_id()
    AND (
      public.has_role(auth.uid(), 'tenant_admin')
      OR public.has_role(auth.uid(), 'igazgato')
      OR public.has_permission(auth.uid(), 'manage_tenant')
    )
  );

DROP POLICY IF EXISTS "tenant admins upsert push settings" ON public.push_settings;
CREATE POLICY "tenant admins upsert push settings"
  ON public.push_settings FOR INSERT TO authenticated
  WITH CHECK (
    tenant_id = public.current_tenant_id()
    AND (
      public.has_role(auth.uid(), 'tenant_admin')
      OR public.has_role(auth.uid(), 'igazgato')
      OR public.has_permission(auth.uid(), 'manage_tenant')
    )
  );

DROP POLICY IF EXISTS "tenant admins update push settings" ON public.push_settings;
CREATE POLICY "tenant admins update push settings"
  ON public.push_settings FOR UPDATE TO authenticated
  USING (
    tenant_id = public.current_tenant_id()
    AND (
      public.has_role(auth.uid(), 'tenant_admin')
      OR public.has_role(auth.uid(), 'igazgato')
      OR public.has_permission(auth.uid(), 'manage_tenant')
    )
  )
  WITH CHECK (tenant_id = public.current_tenant_id());

CREATE TRIGGER trg_push_settings_updated
  BEFORE UPDATE ON public.push_settings
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 2) can_access_patient helper
CREATE OR REPLACE FUNCTION public.can_access_patient(_patient_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.patients p
    WHERE p.id = _patient_id
      AND p.tenant_id = public.current_tenant_id()
  ) AND public.has_permission(auth.uid(), 'manage_patients');
$$;
REVOKE EXECUTE ON FUNCTION public.can_access_patient(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.can_access_patient(uuid) TO authenticated, service_role;

-- 3) Klinikai tablak SELECT szigoritasa
DROP POLICY IF EXISTS "auth users read encounters" ON public.clinical_encounters;
CREATE POLICY "tenant read encounters" ON public.clinical_encounters
  FOR SELECT TO authenticated USING (public.can_access_patient(patient_id));

DROP POLICY IF EXISTS "auth users read observations" ON public.clinical_observations;
CREATE POLICY "tenant read observations" ON public.clinical_observations
  FOR SELECT TO authenticated USING (public.can_access_patient(patient_id));

DROP POLICY IF EXISTS "auth users read notes" ON public.clinical_notes;
CREATE POLICY "tenant read notes" ON public.clinical_notes
  FOR SELECT TO authenticated USING (public.can_access_patient(patient_id));

DROP POLICY IF EXISTS "auth users read diagnoses" ON public.clinical_diagnoses;
CREATE POLICY "tenant read diagnoses" ON public.clinical_diagnoses
  FOR SELECT TO authenticated USING (public.can_access_patient(patient_id));

DROP POLICY IF EXISTS "auth users read therapy" ON public.clinical_therapy_orders;
CREATE POLICY "tenant read therapy" ON public.clinical_therapy_orders
  FOR SELECT TO authenticated USING (public.can_access_patient(patient_id));

DROP POLICY IF EXISTS "auth users read calc results" ON public.clinical_calculator_results;
CREATE POLICY "tenant read calc results" ON public.clinical_calculator_results
  FOR SELECT TO authenticated USING (patient_id IS NULL OR public.can_access_patient(patient_id));

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_tables WHERE schemaname='public' AND tablename='clinical_insulin_sessions') THEN
    EXECUTE 'DROP POLICY IF EXISTS "auth users read insulin sessions" ON public.clinical_insulin_sessions';
    EXECUTE 'DROP POLICY IF EXISTS "Authenticated read insulin sessions" ON public.clinical_insulin_sessions';
    EXECUTE 'CREATE POLICY "tenant read insulin sessions" ON public.clinical_insulin_sessions FOR SELECT TO authenticated USING (public.can_access_patient(patient_id))';
  END IF;
  IF EXISTS (SELECT 1 FROM pg_tables WHERE schemaname='public' AND tablename='clinical_weekly_vc') THEN
    EXECUTE 'DROP POLICY IF EXISTS "auth users read weekly vc" ON public.clinical_weekly_vc';
    EXECUTE 'DROP POLICY IF EXISTS "Authenticated read weekly vc" ON public.clinical_weekly_vc';
    EXECUTE 'CREATE POLICY "tenant read weekly vc" ON public.clinical_weekly_vc FOR SELECT TO authenticated USING (public.can_access_patient(patient_id))';
  END IF;
END $$;

-- 4) clinical_drug_statuses: olvasas + szerkesztes szigoritva
DROP POLICY IF EXISTS "Authenticated read drug statuses" ON public.clinical_drug_statuses;
DROP POLICY IF EXISTS "Authenticated upsert drug statuses" ON public.clinical_drug_statuses;
DROP POLICY IF EXISTS "Authenticated update drug statuses" ON public.clinical_drug_statuses;
DROP POLICY IF EXISTS "Author delete drug statuses" ON public.clinical_drug_statuses;

CREATE POLICY "tenant read drug statuses" ON public.clinical_drug_statuses
  FOR SELECT TO authenticated USING (public.can_access_patient(patient_id));
CREATE POLICY "tenant insert drug statuses" ON public.clinical_drug_statuses
  FOR INSERT TO authenticated WITH CHECK (created_by = auth.uid() AND public.can_access_patient(patient_id));
CREATE POLICY "tenant update drug statuses" ON public.clinical_drug_statuses
  FOR UPDATE TO authenticated USING (public.can_access_patient(patient_id))
  WITH CHECK (public.can_access_patient(patient_id));
CREATE POLICY "tenant delete drug statuses" ON public.clinical_drug_statuses
  FOR DELETE TO authenticated USING (public.can_access_patient(patient_id) AND (created_by = auth.uid() OR public.has_role(auth.uid(), 'admin')));

-- 5) realtime.messages deny-by-default (postgres_changes nem erinti)
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='realtime' AND table_name='messages') THEN
    BEGIN
      EXECUTE 'ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY';
      EXECUTE 'DROP POLICY IF EXISTS "deny_broadcast_subscribe" ON realtime.messages';
      EXECUTE 'CREATE POLICY "deny_broadcast_subscribe" ON realtime.messages FOR SELECT TO authenticated USING (false)';
      EXECUTE 'DROP POLICY IF EXISTS "deny_broadcast_send" ON realtime.messages';
      EXECUTE 'CREATE POLICY "deny_broadcast_send" ON realtime.messages FOR INSERT TO authenticated WITH CHECK (false)';
    EXCEPTION WHEN insufficient_privilege THEN
      RAISE NOTICE 'realtime.messages RLS skipped (insufficient privileges)';
    END;
  END IF;
END $$;