-- ===== A/B teszt: D. migráció =====

-- 1) Kísérlet
CREATE TABLE public.cms_experiments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  name text NOT NULL,
  description text,
  block_id uuid REFERENCES public.cms_blocks(id) ON DELETE CASCADE,
  layout_block_id uuid REFERENCES public.cms_layout_blocks(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'draft', -- draft|running|paused|completed
  traffic_allocation numeric(3,2) NOT NULL DEFAULT 1.00 CHECK (traffic_allocation BETWEEN 0.01 AND 1.00),
  goal_event text NOT NULL,
  started_at timestamptz,
  ended_at timestamptz,
  winner_variant_id uuid,
  -- Phase 1 workflow oszlopok
  workflow_state public.cms_workflow_state NOT NULL DEFAULT 'draft',
  submitted_for_review_at timestamptz,
  submitted_by uuid,
  approved_at timestamptz,
  approved_by uuid,
  rejected_at timestamptz,
  rejected_by uuid,
  rejection_reason text,
  CHECK (
    (block_id IS NOT NULL AND layout_block_id IS NULL) OR
    (block_id IS NULL AND layout_block_id IS NOT NULL)
  ),
  CHECK (status IN ('draft','running','paused','completed'))
);

CREATE INDEX cms_experiments_block_idx ON public.cms_experiments (block_id) WHERE block_id IS NOT NULL;
CREATE INDEX cms_experiments_layout_idx ON public.cms_experiments (layout_block_id) WHERE layout_block_id IS NOT NULL;
CREATE INDEX cms_experiments_status_idx ON public.cms_experiments (status);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_experiments TO authenticated;
GRANT SELECT ON public.cms_experiments TO anon;
GRANT ALL ON public.cms_experiments TO service_role;

ALTER TABLE public.cms_experiments ENABLE ROW LEVEL SECURITY;

-- Publikus olvasás: csak futó kísérletek (anon ↔ szükséges a publikus rendereléshez)
CREATE POLICY "cms_experiments_public_running" ON public.cms_experiments
  FOR SELECT TO anon, authenticated
  USING (status = 'running');
-- CMS-szerű olvasás: mind
CREATE POLICY "cms_experiments_cms_select" ON public.cms_experiments
  FOR SELECT TO authenticated USING (public.has_cms_access(auth.uid()));
CREATE POLICY "cms_experiments_cms_insert" ON public.cms_experiments
  FOR INSERT TO authenticated WITH CHECK (public.has_cms_editor(auth.uid()));
CREATE POLICY "cms_experiments_cms_update" ON public.cms_experiments
  FOR UPDATE TO authenticated
  USING (public.has_cms_editor(auth.uid()))
  WITH CHECK (public.has_cms_editor(auth.uid()));
CREATE POLICY "cms_experiments_cms_delete" ON public.cms_experiments
  FOR DELETE TO authenticated USING (public.has_cms_publisher(auth.uid()));

-- 2) Variánsok
CREATE TABLE public.cms_experiment_variants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  experiment_id uuid NOT NULL REFERENCES public.cms_experiments(id) ON DELETE CASCADE,
  key text NOT NULL,
  name text,
  is_control boolean NOT NULL DEFAULT false,
  weight numeric(5,3) NOT NULL DEFAULT 1.000 CHECK (weight >= 0),
  content jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (experiment_id, key)
);

CREATE INDEX cms_experiment_variants_exp_idx ON public.cms_experiment_variants (experiment_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_experiment_variants TO authenticated;
GRANT SELECT ON public.cms_experiment_variants TO anon;
GRANT ALL ON public.cms_experiment_variants TO service_role;

ALTER TABLE public.cms_experiment_variants ENABLE ROW LEVEL SECURITY;

-- Publikus: csak ha a hozzá tartozó kísérlet futó
CREATE POLICY "cms_exp_variants_public" ON public.cms_experiment_variants
  FOR SELECT TO anon, authenticated
  USING (EXISTS (
    SELECT 1 FROM public.cms_experiments e
    WHERE e.id = experiment_id AND e.status = 'running'
  ));
CREATE POLICY "cms_exp_variants_cms_select" ON public.cms_experiment_variants
  FOR SELECT TO authenticated USING (public.has_cms_access(auth.uid()));
CREATE POLICY "cms_exp_variants_cms_write" ON public.cms_experiment_variants
  FOR ALL TO authenticated
  USING (public.has_cms_editor(auth.uid()))
  WITH CHECK (public.has_cms_editor(auth.uid()));

-- 3) Események
CREATE TABLE public.cms_experiment_events (
  id bigserial PRIMARY KEY,
  created_at timestamptz NOT NULL DEFAULT now(),
  experiment_id uuid NOT NULL REFERENCES public.cms_experiments(id) ON DELETE CASCADE,
  variant_id uuid NOT NULL REFERENCES public.cms_experiment_variants(id) ON DELETE CASCADE,
  event_type text NOT NULL CHECK (event_type IN ('view','goal')),
  session_id text,
  path text,
  referrer text,
  user_agent text
);

CREATE INDEX cms_exp_events_agg_idx
  ON public.cms_experiment_events (experiment_id, variant_id, event_type, created_at);
CREATE INDEX cms_exp_events_session_idx
  ON public.cms_experiment_events (session_id, experiment_id);

GRANT SELECT ON public.cms_experiment_events TO authenticated;
GRANT ALL ON public.cms_experiment_events TO service_role;

ALTER TABLE public.cms_experiment_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "cms_exp_events_cms_select" ON public.cms_experiment_events
  FOR SELECT TO authenticated USING (public.has_cms_access(auth.uid()));
-- INSERT csak security definer fn-en át, nincs policy

-- 4) Esemény rögzítő fn (rate-limit megfontolás: 60 req/perc/session_id)
CREATE OR REPLACE FUNCTION public.cms_exp_event_record(
  _experiment_id uuid,
  _variant_id uuid,
  _event_type text,
  _session_id text,
  _path text DEFAULT NULL,
  _referrer text DEFAULT NULL,
  _user_agent text DEFAULT NULL
)
RETURNS bigint
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _id bigint;
  _recent_count int;
BEGIN
  IF _event_type NOT IN ('view','goal') THEN
    RAISE EXCEPTION 'invalid event_type';
  END IF;

  -- futó kísérlet ellenőrzése
  IF NOT EXISTS (
    SELECT 1 FROM public.cms_experiments e
    WHERE e.id = _experiment_id AND e.status = 'running'
  ) THEN
    RETURN NULL;
  END IF;

  -- variant tartozzon a kísérlethez
  IF NOT EXISTS (
    SELECT 1 FROM public.cms_experiment_variants v
    WHERE v.id = _variant_id AND v.experiment_id = _experiment_id
  ) THEN
    RAISE EXCEPTION 'variant mismatch';
  END IF;

  -- soft rate-limit: 60/perc/session/experiment
  IF _session_id IS NOT NULL THEN
    SELECT COUNT(*) INTO _recent_count
    FROM public.cms_experiment_events
    WHERE session_id = _session_id
      AND experiment_id = _experiment_id
      AND created_at > now() - interval '1 minute';
    IF _recent_count > 60 THEN
      RETURN NULL;
    END IF;
  END IF;

  -- view dedupe: csak első view/nap/session/experiment/variant
  IF _event_type = 'view' AND _session_id IS NOT NULL THEN
    IF EXISTS (
      SELECT 1 FROM public.cms_experiment_events
      WHERE session_id = _session_id
        AND experiment_id = _experiment_id
        AND variant_id = _variant_id
        AND event_type = 'view'
        AND created_at::date = CURRENT_DATE
    ) THEN
      RETURN NULL;
    END IF;
  END IF;

  INSERT INTO public.cms_experiment_events
    (experiment_id, variant_id, event_type, session_id, path, referrer, user_agent)
  VALUES
    (_experiment_id, _variant_id, _event_type, _session_id,
     LEFT(_path, 500), LEFT(_referrer, 500), LEFT(_user_agent, 500))
  RETURNING id INTO _id;

  RETURN _id;
END;
$$;

REVOKE ALL ON FUNCTION public.cms_exp_event_record(uuid, uuid, text, text, text, text, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.cms_exp_event_record(uuid, uuid, text, text, text, text, text) TO anon, authenticated;

-- 5) Napi statisztika view
CREATE OR REPLACE VIEW public.cms_experiment_daily_stats AS
SELECT
  experiment_id,
  variant_id,
  date_trunc('day', created_at)::date AS day,
  COUNT(*) FILTER (WHERE event_type = 'view') AS views,
  COUNT(*) FILTER (WHERE event_type = 'goal') AS goals,
  CASE WHEN COUNT(*) FILTER (WHERE event_type = 'view') > 0
       THEN COUNT(*) FILTER (WHERE event_type = 'goal')::numeric
            / COUNT(*) FILTER (WHERE event_type = 'view')::numeric
       ELSE 0 END AS conversion_rate
FROM public.cms_experiment_events
GROUP BY experiment_id, variant_id, day;

GRANT SELECT ON public.cms_experiment_daily_stats TO authenticated;

-- 6) updated_at triggerek
CREATE OR REPLACE FUNCTION public.cms_experiments_set_updated()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;

CREATE TRIGGER cms_experiments_updated_at
  BEFORE UPDATE ON public.cms_experiments
  FOR EACH ROW EXECUTE FUNCTION public.cms_experiments_set_updated();

CREATE TRIGGER cms_experiment_variants_updated_at
  BEFORE UPDATE ON public.cms_experiment_variants
  FOR EACH ROW EXECUTE FUNCTION public.cms_experiments_set_updated();