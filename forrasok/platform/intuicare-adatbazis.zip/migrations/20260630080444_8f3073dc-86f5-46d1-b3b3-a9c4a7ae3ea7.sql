
-- 1. cms_pages bővítés: home/system flag, layout, nav címke
ALTER TABLE public.cms_pages
  ADD COLUMN IF NOT EXISTS is_home boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS is_system boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS layout text NOT NULL DEFAULT 'default',
  ADD COLUMN IF NOT EXISTS nav_label text;

-- Csak EGY home page lehet egyszerre
CREATE UNIQUE INDEX IF NOT EXISTS cms_pages_only_one_home
  ON public.cms_pages ((1)) WHERE is_home = true;

-- 2. Globális régiók (header, top_bar, footer, mobile_drawer)
CREATE TABLE IF NOT EXISTS public.cms_global_regions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  region_key text NOT NULL,
  locale text NOT NULL DEFAULT 'hu',
  blocks jsonb NOT NULL DEFAULT '[]'::jsonb,
  status text NOT NULL DEFAULT 'published',
  updated_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (region_key, locale)
);
GRANT SELECT ON public.cms_global_regions TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_global_regions TO authenticated;
GRANT ALL ON public.cms_global_regions TO service_role;
ALTER TABLE public.cms_global_regions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "anyone reads published regions"
  ON public.cms_global_regions FOR SELECT
  USING (status = 'published');
CREATE POLICY "cms editors manage regions"
  ON public.cms_global_regions FOR ALL
  TO authenticated
  USING (public.has_cms_access(auth.uid()))
  WITH CHECK (public.has_cms_access(auth.uid()));

CREATE TRIGGER trg_cms_global_regions_updated
  BEFORE UPDATE ON public.cms_global_regions
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 3. Design tokenek (brand színek, betűk, sugarak)
CREATE TABLE IF NOT EXISTS public.cms_design_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  token_key text NOT NULL UNIQUE,
  value jsonb NOT NULL,
  scope text NOT NULL DEFAULT 'global',
  description text,
  updated_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.cms_design_tokens TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_design_tokens TO authenticated;
GRANT ALL ON public.cms_design_tokens TO service_role;
ALTER TABLE public.cms_design_tokens ENABLE ROW LEVEL SECURITY;

CREATE POLICY "anyone reads design tokens"
  ON public.cms_design_tokens FOR SELECT USING (true);
CREATE POLICY "cms editors manage tokens"
  ON public.cms_design_tokens FOR ALL
  TO authenticated
  USING (public.has_cms_access(auth.uid()))
  WITH CHECK (public.has_cms_access(auth.uid()));

CREATE TRIGGER trg_cms_design_tokens_updated
  BEFORE UPDATE ON public.cms_design_tokens
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 4. Egységes layout blokk tábla (oldal + globális blokk-tár alapja)
CREATE TABLE IF NOT EXISTS public.cms_layout_blocks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  page_id uuid REFERENCES public.cms_pages(id) ON DELETE CASCADE,
  region_key text,
  position integer NOT NULL DEFAULT 0,
  block_type text NOT NULL,
  content jsonb NOT NULL DEFAULT '{}'::jsonb,
  style jsonb NOT NULL DEFAULT '{}'::jsonb,
  visibility jsonb NOT NULL DEFAULT '{}'::jsonb,
  locale text NOT NULL DEFAULT 'hu',
  status text NOT NULL DEFAULT 'published',
  schedule_at timestamptz,
  end_at timestamptz,
  version integer NOT NULL DEFAULT 1,
  created_by uuid REFERENCES auth.users(id),
  updated_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT cms_layout_blocks_target_chk CHECK (
    (page_id IS NOT NULL AND region_key IS NULL)
    OR (page_id IS NULL AND region_key IS NOT NULL)
  )
);
CREATE INDEX IF NOT EXISTS cms_layout_blocks_page_idx
  ON public.cms_layout_blocks(page_id, locale, position);
CREATE INDEX IF NOT EXISTS cms_layout_blocks_region_idx
  ON public.cms_layout_blocks(region_key, locale, position);

GRANT SELECT ON public.cms_layout_blocks TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_layout_blocks TO authenticated;
GRANT ALL ON public.cms_layout_blocks TO service_role;
ALTER TABLE public.cms_layout_blocks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "anyone reads published layout blocks"
  ON public.cms_layout_blocks FOR SELECT
  USING (
    status = 'published'
    AND (schedule_at IS NULL OR schedule_at <= now())
    AND (end_at IS NULL OR end_at > now())
  );
CREATE POLICY "cms editors manage layout blocks"
  ON public.cms_layout_blocks FOR ALL
  TO authenticated
  USING (public.has_cms_access(auth.uid()))
  WITH CHECK (public.has_cms_access(auth.uid()));

CREATE TRIGGER trg_cms_layout_blocks_updated
  BEFORE UPDATE ON public.cms_layout_blocks
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 5. Verziók: autosave snapshot támogatás (ha még nincs)
ALTER TABLE public.cms_page_versions
  ADD COLUMN IF NOT EXISTS is_autosave boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS snapshot jsonb;

-- 6. Helper: aktuális home page lekérése (frontend gyors útvonal)
CREATE OR REPLACE FUNCTION public.get_home_page_id()
RETURNS uuid
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT id FROM public.cms_pages WHERE is_home = true AND status = 'published' LIMIT 1;
$$;
