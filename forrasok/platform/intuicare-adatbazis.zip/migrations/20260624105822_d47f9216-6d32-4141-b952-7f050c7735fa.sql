
DO $$ BEGIN
  CREATE TYPE public.eusztv_tabla_tipus AS ENUM ('orvos_1mell','szakdolgozo_1a_mell');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

ALTER TABLE public.wage_table_egeszsegugyi
  ADD COLUMN IF NOT EXISTS tabla_tipus public.eusztv_tabla_tipus NOT NULL DEFAULT 'orvos_1mell',
  ADD COLUMN IF NOT EXISTS gyakorlati_ido_tol_ev integer,
  ADD COLUMN IF NOT EXISTS gyakorlati_ido_ig_ev integer,
  ADD COLUMN IF NOT EXISTS vezeto_szorzo numeric(4,2) NOT NULL DEFAULT 1.20,
  ADD COLUMN IF NOT EXISTS fizetesi_osztaly text,
  ADD COLUMN IF NOT EXISTS osszeg_ft bigint;

CREATE INDEX IF NOT EXISTS idx_wte_eusztv_lookup
  ON public.wage_table_egeszsegugyi(tabla_tipus, ervenyes_tol, gyakorlati_ido_tol_ev);

CREATE TABLE IF NOT EXISTS public.profile_service_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  munkaltato_nev text NOT NULL,
  fenntarto_tipus text NOT NULL CHECK (fenntarto_tipus IN ('allami','onkormanyzati','egyhazi','magan','kulfoldi','egyeb')),
  munkakor text,
  kezdo_datum date NOT NULL,
  zaro_datum date,
  beszamithato_eusztv boolean NOT NULL DEFAULT true,
  beszamithato_jubileum boolean NOT NULL DEFAULT true,
  forras text NOT NULL DEFAULT 'nyilatkozat' CHECK (forras IN ('dokumentum','nyilatkozat','MOK','korabbi_munkaltato_igazolas')),
  csatolmany_url text,
  megjegyzes text,
  rogzitette_user_id uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (zaro_datum IS NULL OR zaro_datum >= kezdo_datum)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_service_history TO authenticated;
GRANT ALL ON public.profile_service_history TO service_role;
ALTER TABLE public.profile_service_history ENABLE ROW LEVEL SECURITY;
CREATE POLICY psh_read ON public.profile_service_history FOR SELECT TO authenticated
  USING (tenant_id = current_tenant_id() AND (user_id = auth.uid() OR has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));
CREATE POLICY psh_write ON public.profile_service_history FOR ALL TO authenticated
  USING (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')))
  WITH CHECK (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));
CREATE INDEX idx_psh_user ON public.profile_service_history(tenant_id, user_id);

CREATE TABLE IF NOT EXISTS public.profile_service_time_overrides (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  tipus text NOT NULL CHECK (tipus IN ('gyakorlati_ido','jubileumi')),
  napok_korrekcio integer NOT NULL,
  indok text NOT NULL,
  jovahagyo_user_id uuid REFERENCES auth.users(id),
  ervenyes_tol date NOT NULL DEFAULT CURRENT_DATE,
  ervenyes_ig date,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_service_time_overrides TO authenticated;
GRANT ALL ON public.profile_service_time_overrides TO service_role;
ALTER TABLE public.profile_service_time_overrides ENABLE ROW LEVEL SECURITY;
CREATE POLICY psto_read ON public.profile_service_time_overrides FOR SELECT TO authenticated
  USING (tenant_id = current_tenant_id() AND (user_id = auth.uid() OR has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));
CREATE POLICY psto_write ON public.profile_service_time_overrides FOR ALL TO authenticated
  USING (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')))
  WITH CHECK (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));

CREATE TABLE IF NOT EXISTS public.probaidok (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  profile_employment_id uuid NOT NULL REFERENCES public.profile_employment(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  tartam_honap smallint NOT NULL DEFAULT 3 CHECK (tartam_honap BETWEEN 1 AND 4),
  kezdo_datum date NOT NULL,
  zaro_datum date,
  mentesseg_jogcim text CHECK (mentesseg_jogcim IS NULL OR mentesseg_jogcim IN ('athelyezes','azonos_felek','kormrend_szakmai_gyakorlat','hatarozott_ido')),
  megjegyzes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE OR REPLACE FUNCTION public.set_probaido_zaro() RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.zaro_datum := (NEW.kezdo_datum + (NEW.tartam_honap || ' months')::interval)::date; RETURN NEW; END $$;
CREATE TRIGGER trg_probaido_zaro BEFORE INSERT OR UPDATE OF kezdo_datum, tartam_honap ON public.probaidok
  FOR EACH ROW EXECUTE FUNCTION public.set_probaido_zaro();
GRANT SELECT, INSERT, UPDATE, DELETE ON public.probaidok TO authenticated;
GRANT ALL ON public.probaidok TO service_role;
ALTER TABLE public.probaidok ENABLE ROW LEVEL SECURITY;
CREATE POLICY pid_read ON public.probaidok FOR SELECT TO authenticated
  USING (tenant_id = current_tenant_id() AND (user_id = auth.uid() OR has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));
CREATE POLICY pid_write ON public.probaidok FOR ALL TO authenticated
  USING (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')))
  WITH CHECK (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));

CREATE TABLE IF NOT EXISTS public.osszeferhetetlenseg_engedelyek (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  tipus text NOT NULL CHECK (tipus IN ('kulso_jogviszony','szekhelyen_tevekenyseg','tudomanyos','oktatoi','egyeb')),
  leiras text NOT NULL,
  engedelyezo_szerv text,
  kerelem_datum date,
  engedely_datum date,
  lejarat date,
  status text NOT NULL DEFAULT 'beadva' CHECK (status IN ('beadva','engedelyezve','elutasitva','visszavonva','lejart')),
  csatolmany_url text,
  megjegyzes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.osszeferhetetlenseg_engedelyek TO authenticated;
GRANT ALL ON public.osszeferhetetlenseg_engedelyek TO service_role;
ALTER TABLE public.osszeferhetetlenseg_engedelyek ENABLE ROW LEVEL SECURITY;
CREATE POLICY oe_read ON public.osszeferhetetlenseg_engedelyek FOR SELECT TO authenticated
  USING (tenant_id = current_tenant_id() AND (user_id = auth.uid() OR has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));
CREATE POLICY oe_write ON public.osszeferhetetlenseg_engedelyek FOR ALL TO authenticated
  USING (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')))
  WITH CHECK (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));

CREATE TABLE IF NOT EXISTS public.minosites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  ertekelo_user_id uuid REFERENCES auth.users(id),
  idoszak_tol date NOT NULL,
  idoszak_ig date NOT NULL,
  eredmeny text NOT NULL CHECK (eredmeny IN ('kivalo','jo','megfelelo','nem_megfelelo')),
  szoveges_ertekeles text,
  dokumentum_url text,
  alairt boolean NOT NULL DEFAULT false,
  alairas_datum date,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.minosites TO authenticated;
GRANT ALL ON public.minosites TO service_role;
ALTER TABLE public.minosites ENABLE ROW LEVEL SECURITY;
CREATE POLICY min_read ON public.minosites FOR SELECT TO authenticated
  USING (tenant_id = current_tenant_id() AND (user_id = auth.uid() OR ertekelo_user_id = auth.uid() OR has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));
CREATE POLICY min_write ON public.minosites FOR ALL TO authenticated
  USING (tenant_id = current_tenant_id() AND (ertekelo_user_id = auth.uid() OR has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')))
  WITH CHECK (tenant_id = current_tenant_id() AND (ertekelo_user_id = auth.uid() OR has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));

CREATE TABLE IF NOT EXISTS public.szabadsag_evente (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  ev smallint NOT NULL,
  alapszabadsag_nap smallint NOT NULL DEFAULT 0,
  potszabadsag_nap smallint NOT NULL DEFAULT 0,
  gyermek_potszabadsag_nap smallint NOT NULL DEFAULT 0,
  egyeb_jogcim_jsonb jsonb NOT NULL DEFAULT '{}'::jsonb,
  kivett_nap numeric(5,1) NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, user_id, ev)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.szabadsag_evente TO authenticated;
GRANT ALL ON public.szabadsag_evente TO service_role;
ALTER TABLE public.szabadsag_evente ENABLE ROW LEVEL SECURITY;
CREATE POLICY sze_read ON public.szabadsag_evente FOR SELECT TO authenticated
  USING (tenant_id = current_tenant_id() AND (user_id = auth.uid() OR has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));
CREATE POLICY sze_write ON public.szabadsag_evente FOR ALL TO authenticated
  USING (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')))
  WITH CHECK (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));

CREATE TABLE IF NOT EXISTS public.szolgalati_elismeres (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  fokozat smallint NOT NULL CHECK (fokozat IN (25,30,40,45,50)),
  varhato_datum date NOT NULL,
  kifizetes_datum date,
  osszeg_ft bigint,
  status text NOT NULL DEFAULT 'tervezett' CHECK (status IN ('tervezett','jovahagyva','kifizetve','elhalasztva')),
  megjegyzes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, user_id, fokozat)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.szolgalati_elismeres TO authenticated;
GRANT ALL ON public.szolgalati_elismeres TO service_role;
ALTER TABLE public.szolgalati_elismeres ENABLE ROW LEVEL SECURITY;
CREATE POLICY se_read ON public.szolgalati_elismeres FOR SELECT TO authenticated
  USING (tenant_id = current_tenant_id() AND (user_id = auth.uid() OR has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));
CREATE POLICY se_write ON public.szolgalati_elismeres FOR ALL TO authenticated
  USING (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')))
  WITH CHECK (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));

CREATE TABLE IF NOT EXISTS public.vegkielegites_szamitasok (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  user_id uuid NOT NULL,
  profile_employment_id uuid REFERENCES public.profile_employment(id) ON DELETE CASCADE,
  megszunes_jogcim text NOT NULL,
  felmentesi_ido_nap integer NOT NULL DEFAULT 0,
  vegkielegites_havi_szam numeric(3,1) NOT NULL DEFAULT 0,
  havi_illetmeny_ft bigint NOT NULL DEFAULT 0,
  osszeg_ft bigint NOT NULL DEFAULT 0,
  szamitas_datum date NOT NULL DEFAULT CURRENT_DATE,
  jovahagyo_user_id uuid REFERENCES auth.users(id),
  megjegyzes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE OR REPLACE FUNCTION public.set_vegki_osszeg() RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.osszeg_ft := (NEW.havi_illetmeny_ft * NEW.vegkielegites_havi_szam)::bigint; RETURN NEW; END $$;
CREATE TRIGGER trg_vegki_osszeg BEFORE INSERT OR UPDATE OF havi_illetmeny_ft, vegkielegites_havi_szam ON public.vegkielegites_szamitasok
  FOR EACH ROW EXECUTE FUNCTION public.set_vegki_osszeg();
GRANT SELECT, INSERT, UPDATE, DELETE ON public.vegkielegites_szamitasok TO authenticated;
GRANT ALL ON public.vegkielegites_szamitasok TO service_role;
ALTER TABLE public.vegkielegites_szamitasok ENABLE ROW LEVEL SECURITY;
CREATE POLICY vsz_read ON public.vegkielegites_szamitasok FOR SELECT TO authenticated
  USING (tenant_id = current_tenant_id() AND (user_id = auth.uid() OR has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));
CREATE POLICY vsz_write ON public.vegkielegites_szamitasok FOR ALL TO authenticated
  USING (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')))
  WITH CHECK (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));

CREATE TABLE IF NOT EXISTS public.juttatasok (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  tipus text NOT NULL CHECK (tipus IN ('lakhatasi_tamogatas','koltsegterites','utazasi','kepzesi','etkezesi','cafeteria','egyeb')),
  havi_osszeg_ft bigint NOT NULL DEFAULT 0,
  kezdo_datum date NOT NULL,
  zaro_datum date,
  dokumentum_url text,
  megjegyzes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.juttatasok TO authenticated;
GRANT ALL ON public.juttatasok TO service_role;
ALTER TABLE public.juttatasok ENABLE ROW LEVEL SECURITY;
CREATE POLICY jut_read ON public.juttatasok FOR SELECT TO authenticated
  USING (tenant_id = current_tenant_id() AND (user_id = auth.uid() OR has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));
CREATE POLICY jut_write ON public.juttatasok FOR ALL TO authenticated
  USING (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')))
  WITH CHECK (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));

CREATE TABLE IF NOT EXISTS public.kirendelesek (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  cel_egeszsegugyi_szolgaltato text NOT NULL,
  kezdo_datum date NOT NULL,
  zaro_datum date NOT NULL,
  indok text,
  napi_dij_ft bigint,
  hozzajarult boolean NOT NULL DEFAULT false,
  alairt_dokumentum_url text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (zaro_datum >= kezdo_datum)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.kirendelesek TO authenticated;
GRANT ALL ON public.kirendelesek TO service_role;
ALTER TABLE public.kirendelesek ENABLE ROW LEVEL SECURITY;
CREATE POLICY kir_read ON public.kirendelesek FOR SELECT TO authenticated
  USING (tenant_id = current_tenant_id() AND (user_id = auth.uid() OR has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));
CREATE POLICY kir_write ON public.kirendelesek FOR ALL TO authenticated
  USING (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')))
  WITH CHECK (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));

DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['profile_service_history','profile_service_time_overrides','probaidok','osszeferhetetlenseg_engedelyek','minosites','szabadsag_evente','szolgalati_elismeres','vegkielegites_szamitasok','juttatasok','kirendelesek'] LOOP
    EXECUTE format('CREATE TRIGGER trg_%I_updated_at BEFORE UPDATE ON public.%I FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column()', t, t);
  END LOOP;
END $$;

CREATE OR REPLACE FUNCTION public.calc_gyakorlati_ido(p_user_id uuid, p_datum date DEFAULT CURRENT_DATE)
RETURNS TABLE (napok integer, evek numeric)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE v_napok integer := 0; v_korrekcio integer := 0;
BEGIN
  WITH spans AS (
    SELECT kezdo_datum AS s, COALESCE(LEAST(zaro_datum, p_datum), p_datum) AS e FROM public.profile_employment WHERE user_id = p_user_id AND kezdo_datum <= p_datum
    UNION ALL
    SELECT kezdo_datum, COALESCE(LEAST(zaro_datum, p_datum), p_datum) FROM public.profile_service_history WHERE user_id = p_user_id AND beszamithato_eusztv = true AND kezdo_datum <= p_datum
  ),
  ordered AS (SELECT s, e FROM spans WHERE e >= s ORDER BY s, e),
  flagged AS (
    SELECT s, e, MAX(e) OVER (ORDER BY s, e ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING) AS prev_max FROM ordered
  ),
  grouped AS (
    SELECT s, e, SUM(CASE WHEN prev_max IS NULL OR s > prev_max THEN 1 ELSE 0 END) OVER (ORDER BY s, e ROWS UNBOUNDED PRECEDING) AS grp FROM flagged
  ),
  merged AS (SELECT grp, MIN(s) AS s, MAX(e) AS e FROM grouped GROUP BY grp)
  SELECT COALESCE(SUM((e - s) + 1), 0)::integer INTO v_napok FROM merged;

  SELECT COALESCE(SUM(napok_korrekcio),0) INTO v_korrekcio FROM public.profile_service_time_overrides
    WHERE user_id = p_user_id AND tipus = 'gyakorlati_ido' AND ervenyes_tol <= p_datum AND (ervenyes_ig IS NULL OR ervenyes_ig >= p_datum);
  v_napok := GREATEST(0, COALESCE(v_napok,0) + v_korrekcio);
  RETURN QUERY SELECT v_napok, ROUND(v_napok::numeric / 365.25, 2);
END $$;
GRANT EXECUTE ON FUNCTION public.calc_gyakorlati_ido(uuid, date) TO authenticated, service_role;

CREATE OR REPLACE FUNCTION public.calc_jubileumi_ido(p_user_id uuid, p_datum date DEFAULT CURRENT_DATE)
RETURNS TABLE (napok integer, evek numeric)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE v_napok integer := 0; v_korrekcio integer := 0;
BEGIN
  WITH spans AS (
    SELECT kezdo_datum AS s, COALESCE(LEAST(zaro_datum, p_datum), p_datum) AS e FROM public.profile_employment WHERE user_id = p_user_id AND kezdo_datum <= p_datum
    UNION ALL
    SELECT kezdo_datum, COALESCE(LEAST(zaro_datum, p_datum), p_datum) FROM public.profile_service_history WHERE user_id = p_user_id AND beszamithato_jubileum = true AND kezdo_datum <= p_datum
  ),
  ordered AS (SELECT s, e FROM spans WHERE e >= s ORDER BY s, e),
  flagged AS (SELECT s, e, MAX(e) OVER (ORDER BY s, e ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING) AS prev_max FROM ordered),
  grouped AS (SELECT s, e, SUM(CASE WHEN prev_max IS NULL OR s > prev_max THEN 1 ELSE 0 END) OVER (ORDER BY s, e ROWS UNBOUNDED PRECEDING) AS grp FROM flagged),
  merged AS (SELECT grp, MIN(s) AS s, MAX(e) AS e FROM grouped GROUP BY grp)
  SELECT COALESCE(SUM((e - s) + 1), 0)::integer INTO v_napok FROM merged;

  SELECT COALESCE(SUM(napok_korrekcio),0) INTO v_korrekcio FROM public.profile_service_time_overrides
    WHERE user_id = p_user_id AND tipus = 'jubileumi' AND ervenyes_tol <= p_datum AND (ervenyes_ig IS NULL OR ervenyes_ig >= p_datum);
  v_napok := GREATEST(0, COALESCE(v_napok,0) + v_korrekcio);
  RETURN QUERY SELECT v_napok, ROUND(v_napok::numeric / 365.25, 2);
END $$;
GRANT EXECUTE ON FUNCTION public.calc_jubileumi_ido(uuid, date) TO authenticated, service_role;

CREATE OR REPLACE FUNCTION public.calc_illetmeny(p_user_id uuid, p_datum date DEFAULT CURRENT_DATE)
RETURNS TABLE (alap_ft bigint, sav text, vezetoi_szorzo numeric, vegso_ft bigint, gyakorlati_evek numeric)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE v_evek numeric; v_napok integer; v_tabla_tipus public.eusztv_tabla_tipus; v_row record; v_orvos boolean := true; v_vezeto boolean := false;
BEGIN
  SELECT g.napok, g.evek INTO v_napok, v_evek FROM public.calc_gyakorlati_ido(p_user_id, p_datum) g;
  SELECT (lower(COALESCE(munkakor_megnevezes,'')) LIKE '%orvos%' OR lower(COALESCE(munkakor_megnevezes,'')) LIKE '%gyógyszerész%'), (vezetoi_szint IS NOT NULL)
    INTO v_orvos, v_vezeto
    FROM public.profile_employment WHERE user_id = p_user_id AND ervenyes = true
    ORDER BY elsodleges DESC NULLS LAST, kezdo_datum DESC LIMIT 1;
  v_tabla_tipus := CASE WHEN v_orvos THEN 'orvos_1mell'::public.eusztv_tabla_tipus ELSE 'szakdolgozo_1a_mell'::public.eusztv_tabla_tipus END;

  SELECT * INTO v_row FROM public.wage_table_egeszsegugyi
    WHERE tabla_tipus = v_tabla_tipus AND ervenyes_tol <= p_datum AND (ervenyes_ig IS NULL OR ervenyes_ig >= p_datum)
      AND COALESCE(gyakorlati_ido_tol_ev, 0) <= v_evek AND (gyakorlati_ido_ig_ev IS NULL OR v_evek <= gyakorlati_ido_ig_ev) AND osszeg_ft IS NOT NULL
    ORDER BY ervenyes_tol DESC, gyakorlati_ido_tol_ev DESC NULLS LAST LIMIT 1;

  IF v_row.id IS NULL THEN
    RETURN QUERY SELECT 0::bigint, 'nincs_besorolas'::text, 1.0::numeric, 0::bigint, v_evek; RETURN;
  END IF;
  RETURN QUERY SELECT v_row.osszeg_ft,
    COALESCE(v_row.gyakorlati_ido_tol_ev::text,'0') || '–' || COALESCE(v_row.gyakorlati_ido_ig_ev::text,'∞') || ' év',
    CASE WHEN v_vezeto THEN v_row.vezeto_szorzo ELSE 1.0 END,
    (v_row.osszeg_ft * CASE WHEN v_vezeto THEN v_row.vezeto_szorzo ELSE 1.0 END)::bigint,
    v_evek;
END $$;
GRANT EXECUTE ON FUNCTION public.calc_illetmeny(uuid, date) TO authenticated, service_role;

INSERT INTO public.role_permissions(role_kulcs, perm) VALUES ('tenant_admin','manage_eusztv') ON CONFLICT DO NOTHING;
