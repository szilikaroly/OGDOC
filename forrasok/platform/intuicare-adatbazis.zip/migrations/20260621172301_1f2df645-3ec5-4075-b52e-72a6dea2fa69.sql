
-- ===== Security finding fixes =====

-- 1) clinical_alert_status_log: restrict to alerts the user can access (via patient)
DROP POLICY IF EXISTS alert_status_log_read_authenticated ON public.clinical_alert_status_log;
CREATE POLICY alert_status_log_read_scoped ON public.clinical_alert_status_log
  FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.clinical_critical_alerts a
    WHERE a.id = clinical_alert_status_log.alert_id
      AND public.can_access_patient(a.patient_id)
  ));

-- Allow the escalation worker (service_role) and authorized writers to insert via existing logic;
-- the application already inserts log rows from server functions, but RLS for INSERT was not defined.
-- Add an INSERT policy bound to patient access AND actor = auth.uid().
DROP POLICY IF EXISTS alert_status_log_insert_scoped ON public.clinical_alert_status_log;
CREATE POLICY alert_status_log_insert_scoped ON public.clinical_alert_status_log
  FOR INSERT TO authenticated
  WITH CHECK (
    actor_id = auth.uid()
    AND EXISTS (
      SELECT 1 FROM public.clinical_critical_alerts a
      WHERE a.id = clinical_alert_status_log.alert_id
        AND public.can_access_patient(a.patient_id)
    )
  );

-- 2) clinical_diagnoses: enforce can_access_patient on writes
DROP POLICY IF EXISTS "auth users insert diagnoses" ON public.clinical_diagnoses;
CREATE POLICY "auth users insert diagnoses" ON public.clinical_diagnoses
  FOR INSERT TO authenticated
  WITH CHECK (
    auth.uid() = created_by
    AND public.can_access_patient(patient_id)
  );

DROP POLICY IF EXISTS "creator updates diagnoses" ON public.clinical_diagnoses;
CREATE POLICY "creator updates diagnoses" ON public.clinical_diagnoses
  FOR UPDATE TO authenticated
  USING (
    (auth.uid() = created_by OR public.has_role(auth.uid(), 'admin'))
    AND public.can_access_patient(patient_id)
  )
  WITH CHECK (public.can_access_patient(patient_id));

DROP POLICY IF EXISTS "creator deletes diagnoses" ON public.clinical_diagnoses;
CREATE POLICY "creator deletes diagnoses" ON public.clinical_diagnoses
  FOR DELETE TO authenticated
  USING (
    (auth.uid() = created_by OR public.has_role(auth.uid(), 'admin'))
    AND public.can_access_patient(patient_id)
  );

-- 3) clinical_encounters: enforce can_access_patient on writes
DROP POLICY IF EXISTS "auth users insert encounters" ON public.clinical_encounters;
CREATE POLICY "auth users insert encounters" ON public.clinical_encounters
  FOR INSERT TO authenticated
  WITH CHECK (
    auth.uid() = created_by
    AND public.can_access_patient(patient_id)
  );

DROP POLICY IF EXISTS "creator updates encounters" ON public.clinical_encounters;
CREATE POLICY "creator updates encounters" ON public.clinical_encounters
  FOR UPDATE TO authenticated
  USING (
    (auth.uid() = created_by OR public.has_role(auth.uid(), 'admin'))
    AND public.can_access_patient(patient_id)
  )
  WITH CHECK (public.can_access_patient(patient_id));

DROP POLICY IF EXISTS "creator deletes encounters" ON public.clinical_encounters;
CREATE POLICY "creator deletes encounters" ON public.clinical_encounters
  FOR DELETE TO authenticated
  USING (
    (auth.uid() = created_by OR public.has_role(auth.uid(), 'admin'))
    AND public.can_access_patient(patient_id)
  );

-- ===== Escalation worker support =====
-- Track when an alert was last auto-evaluated, to avoid relogging on every run
ALTER TABLE public.clinical_critical_alerts
  ADD COLUMN IF NOT EXISTS escalated_at TIMESTAMPTZ;

-- Index to keep the worker query fast
CREATE INDEX IF NOT EXISTS clinical_critical_alerts_workflow_open_idx
  ON public.clinical_critical_alerts (workflow_status, triggered_at)
  WHERE workflow_status IS DISTINCT FROM 'resolved'
    AND workflow_status IS DISTINCT FROM 'escalated';
