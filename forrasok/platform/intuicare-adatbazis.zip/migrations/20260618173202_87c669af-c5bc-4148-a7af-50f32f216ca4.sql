
-- Új bérlő létrehozható minden hitelesített felhasználó által, ha még nincs hozzárendelve bérlőhöz
CREATE POLICY "tenants_insert_unaffiliated" ON public.tenants
  FOR INSERT TO authenticated
  WITH CHECK (
    public.current_tenant_id() IS NULL
  );

-- Saját első tenant_admin szerepkör felvétele: az alapító user magához tudja rendelni
-- a tenant_admin szerepkört a frissen létrehozott tenantban
CREATE POLICY "user_roles_bootstrap_admin" ON public.user_roles
  FOR INSERT TO authenticated
  WITH CHECK (
    user_id = auth.uid()
    AND role_id IN (SELECT id FROM public.roles WHERE kulcs = 'tenant_admin')
    AND EXISTS (
      SELECT 1 FROM public.tenants t
      WHERE t.id = user_roles.tenant_id
    )
  );
