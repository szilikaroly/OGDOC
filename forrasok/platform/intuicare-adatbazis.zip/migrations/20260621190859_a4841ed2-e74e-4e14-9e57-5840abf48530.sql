
CREATE TABLE public.announcements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  cim text NOT NULL,
  tartalom text NOT NULL,
  prioritas text NOT NULL DEFAULT 'info' CHECK (prioritas IN ('info','warning','critical','success')),
  kategoria text NOT NULL DEFAULT 'hir' CHECK (kategoria IN ('hir','hirdetmeny','esemeny','figyelmeztetes')),
  cel_szerepkorok text[] NOT NULL DEFAULT '{}',
  cel_org_unit_ids uuid[] NOT NULL DEFAULT '{}',
  publikalt boolean NOT NULL DEFAULT true,
  publikalva_tol timestamptz NOT NULL DEFAULT now(),
  publikalva_ig timestamptz,
  link text,
  kep_url text,
  rogzitett boolean NOT NULL DEFAULT false,
  created_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_announcements_tenant_pub ON public.announcements(tenant_id, publikalva_tol DESC) WHERE publikalt = true;

GRANT SELECT, INSERT, UPDATE, DELETE ON public.announcements TO authenticated;
GRANT ALL ON public.announcements TO service_role;
ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;

CREATE POLICY "announcements_select" ON public.announcements
  FOR SELECT TO authenticated
  USING (
    publikalt = true
    AND (publikalva_ig IS NULL OR publikalva_ig > now())
    AND publikalva_tol <= now()
    AND tenant_id IN (SELECT tenant_id FROM public.profiles WHERE id = auth.uid())
    AND (
      cardinality(cel_szerepkorok) = 0
      OR EXISTS (
        SELECT 1 FROM public.user_roles ur
        JOIN public.roles r ON r.id = ur.role_id
        WHERE ur.user_id = auth.uid()
          AND r.kulcs = ANY(cel_szerepkorok)
      )
    )
    AND (
      cardinality(cel_org_unit_ids) = 0
      OR EXISTS (
        SELECT 1 FROM public.profile_employment pe
        WHERE pe.user_id = auth.uid()
          AND pe.org_unit_id = ANY(cel_org_unit_ids)
          AND pe.ervenyes = true
      )
    )
  );

CREATE POLICY "announcements_admin_all" ON public.announcements
  FOR ALL TO authenticated
  USING (
    tenant_id IN (SELECT tenant_id FROM public.profiles WHERE id = auth.uid())
    AND (public.has_role(auth.uid(), 'admin') OR public.has_permission(auth.uid(), 'manage_tenant'))
  )
  WITH CHECK (
    tenant_id IN (SELECT tenant_id FROM public.profiles WHERE id = auth.uid())
    AND (public.has_role(auth.uid(), 'admin') OR public.has_permission(auth.uid(), 'manage_tenant'))
  );

CREATE TRIGGER tg_announcements_updated_at BEFORE UPDATE ON public.announcements
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.announcement_reads (
  announcement_id uuid NOT NULL REFERENCES public.announcements(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  read_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (announcement_id, user_id)
);

GRANT SELECT, INSERT, DELETE ON public.announcement_reads TO authenticated;
GRANT ALL ON public.announcement_reads TO service_role;
ALTER TABLE public.announcement_reads ENABLE ROW LEVEL SECURITY;

CREATE POLICY "announcement_reads_own" ON public.announcement_reads
  FOR ALL TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

CREATE TABLE public.dashboard_widget_prefs (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  config jsonb NOT NULL DEFAULT '{"widgets":[]}'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.dashboard_widget_prefs TO authenticated;
GRANT ALL ON public.dashboard_widget_prefs TO service_role;
ALTER TABLE public.dashboard_widget_prefs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "dashboard_widget_prefs_own" ON public.dashboard_widget_prefs
  FOR ALL TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

CREATE TRIGGER tg_dashboard_widget_prefs_updated_at BEFORE UPDATE ON public.dashboard_widget_prefs
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
