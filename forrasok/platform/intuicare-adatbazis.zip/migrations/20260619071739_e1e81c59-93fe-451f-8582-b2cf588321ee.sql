
-- Beosztás-értesítés
CREATE OR REPLACE FUNCTION public.notify_new_shift()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.user_id IS NOT NULL THEN
    INSERT INTO public.notifications (tenant_id, user_id, tipus, cim, uzenet, link)
    VALUES (
      NEW.tenant_id,
      NEW.user_id,
      'beosztas',
      'Új műszak a beosztásban',
      to_char(NEW.kezdo_idopont AT TIME ZONE 'Europe/Budapest', 'YYYY-MM-DD HH24:MI')
        || ' – '
        || to_char(NEW.zaro_idopont AT TIME ZONE 'Europe/Budapest', 'HH24:MI')
        || ' (' || COALESCE(NEW.kategoria::text, 'műszak') || ')',
      '/munkaido'
    );
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_notify_new_shift ON public.schedule_assignments;
CREATE TRIGGER trg_notify_new_shift
  AFTER INSERT ON public.schedule_assignments
  FOR EACH ROW
  EXECUTE FUNCTION public.notify_new_shift();

-- Távollét-kérelem státuszváltozás értesítés
CREATE OR REPLACE FUNCTION public.notify_unavailability_status()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_cim text;
  v_uzenet text;
BEGIN
  IF NEW.status IS DISTINCT FROM OLD.status
     AND NEW.status IN ('jovahagyott','elutasitott') THEN
    IF NEW.status = 'jovahagyott' THEN
      v_cim := 'Távollét-kérelem jóváhagyva';
      v_uzenet := to_char(NEW.kezdo_datum, 'YYYY-MM-DD') || ' – ' || to_char(NEW.zaro_datum, 'YYYY-MM-DD');
    ELSE
      v_cim := 'Távollét-kérelem elutasítva';
      v_uzenet := to_char(NEW.kezdo_datum, 'YYYY-MM-DD') || ' – ' || to_char(NEW.zaro_datum, 'YYYY-MM-DD')
                  || COALESCE(E'\nIndoklás: ' || NEW.jovahagyas_indok, '');
    END IF;

    INSERT INTO public.notifications (tenant_id, user_id, tipus, cim, uzenet, link)
    VALUES (NEW.tenant_id, NEW.user_id, 'tavollet', v_cim, v_uzenet, '/karakterlap');
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_notify_unavailability_status ON public.profile_unavailability;
CREATE TRIGGER trg_notify_unavailability_status
  AFTER UPDATE ON public.profile_unavailability
  FOR EACH ROW
  EXECUTE FUNCTION public.notify_unavailability_status();

-- Preferencia státuszváltozás értesítés
CREATE OR REPLACE FUNCTION public.notify_preferences_status()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_cim text;
BEGIN
  IF NEW.status IS DISTINCT FROM OLD.status
     AND NEW.status IN ('jovahagyott','elutasitott') THEN
    v_cim := CASE NEW.status
      WHEN 'jovahagyott' THEN 'Preferencia jóváhagyva'
      ELSE 'Preferencia elutasítva'
    END;

    INSERT INTO public.notifications (tenant_id, user_id, tipus, cim, uzenet, link)
    VALUES (
      NEW.tenant_id,
      NEW.user_id,
      'preferencia',
      v_cim,
      COALESCE(NEW.jovahagyas_indok, NULL),
      '/karakterlap'
    );
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_notify_preferences_status ON public.profile_preferences;
CREATE TRIGGER trg_notify_preferences_status
  AFTER UPDATE ON public.profile_preferences
  FOR EACH ROW
  EXECUTE FUNCTION public.notify_preferences_status();
