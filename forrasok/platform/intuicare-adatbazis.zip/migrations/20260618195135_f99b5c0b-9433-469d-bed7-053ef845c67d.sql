
CREATE TABLE IF NOT EXISTS public.feladat_korok (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  kulcs TEXT NOT NULL,
  nev TEXT NOT NULL,
  leiras TEXT,
  sorrend INTEGER NOT NULL DEFAULT 100,
  aktiv BOOLEAN NOT NULL DEFAULT true,
  rendszerszintu BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, kulcs)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.feladat_korok TO authenticated;
GRANT ALL ON public.feladat_korok TO service_role;

ALTER TABLE public.feladat_korok ENABLE ROW LEVEL SECURITY;

CREATE POLICY "feladat_korok_select_tenant" ON public.feladat_korok
  FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());

CREATE POLICY "feladat_korok_manage_admin" ON public.feladat_korok
  FOR ALL TO authenticated
  USING (
    tenant_id = public.current_tenant_id()
    AND (
      public.has_permission(auth.uid(), 'manage_tenant')
      OR public.has_permission(auth.uid(), 'manage_org')
      OR public.has_permission(auth.uid(), 'manage_schedule')
    )
  )
  WITH CHECK (
    tenant_id = public.current_tenant_id()
    AND (
      public.has_permission(auth.uid(), 'manage_tenant')
      OR public.has_permission(auth.uid(), 'manage_org')
      OR public.has_permission(auth.uid(), 'manage_schedule')
    )
  );

CREATE TRIGGER touch_feladat_korok BEFORE UPDATE ON public.feladat_korok
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

INSERT INTO public.feladat_korok (tenant_id, kulcs, nev, sorrend, rendszerszintu)
SELECT t.id, k.kulcs, k.nev, k.sorrend, true
FROM public.tenants t
CROSS JOIN (VALUES
  ('muto',           'Műtő',           10),
  ('ambulancia',     'Ambulancia',     20),
  ('osztaly',        'Osztály',        30),
  ('ultrahang',      'Ultrahang',      40),
  ('terhesgondozas', 'Terhesgondozás', 50),
  ('kismuto',        'Kisműtő',        60),
  ('ivf',            'IVF',            70),
  ('fmc',            'FMC',            80),
  ('egyeb',          'Egyéb',          999)
) AS k(kulcs, nev, sorrend)
ON CONFLICT (tenant_id, kulcs) DO NOTHING;

ALTER TABLE public.profile_preferences
  ADD COLUMN IF NOT EXISTS kozossegi_napok DATE[] NOT NULL DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS preferalt_feladat_korok TEXT[] NOT NULL DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS status public.unavailability_status NOT NULL DEFAULT 'tervezett',
  ADD COLUMN IF NOT EXISTS submitted_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS jovahagyo_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS jovahagyas_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS jovahagyas_indok TEXT,
  ADD COLUMN IF NOT EXISTS jovahagyas_feltetel TEXT;

CREATE OR REPLACE FUNCTION public.profile_preferences_guard()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_can_approve boolean;
BEGIN
  IF TG_OP = 'UPDATE' AND NEW.status IS DISTINCT FROM OLD.status THEN
    IF NEW.status IN ('jovahagyott', 'elutasitott') THEN
      v_can_approve := COALESCE(public.has_permission(v_uid, 'manage_schedule'), false)
                    OR COALESCE(public.has_permission(v_uid, 'manage_tenant'), false);
      IF NOT v_can_approve THEN
        INSERT INTO public.admin_audit_log(tenant_id, user_id, action, table_name, record_id, before_data, after_data)
        VALUES (
          COALESCE(NEW.tenant_id, public.current_tenant_id()),
          v_uid,
          'FORBIDDEN_APPROVAL',
          TG_TABLE_NAME,
          NEW.user_id::text,
          jsonb_build_object('status', OLD.status),
          jsonb_build_object('status', NEW.status)
        );
        RAISE EXCEPTION 'Nincs jogosultsága a preferenciák jóváhagyásához.'
          USING ERRCODE = '42501';
      END IF;
      IF NEW.user_id = v_uid THEN
        RAISE EXCEPTION 'A saját preferenciáját nem hagyhatja jóvá / utasíthatja el.'
          USING ERRCODE = '42501';
      END IF;
      IF NEW.status = 'elutasitott' AND COALESCE(btrim(NEW.jovahagyas_indok), '') = '' THEN
        RAISE EXCEPTION 'Elutasításhoz kötelező az indoklás.'
          USING ERRCODE = '22023';
      END IF;
      NEW.jovahagyo_id := v_uid;
      NEW.jovahagyas_at := now();
    ELSIF NEW.status = 'jovahagyasra_var' THEN
      NEW.submitted_at := now();
      NEW.jovahagyo_id := NULL;
      NEW.jovahagyas_at := NULL;
      NEW.jovahagyas_indok := NULL;
      NEW.jovahagyas_feltetel := NULL;
    ELSIF NEW.status = 'tervezett' THEN
      NEW.submitted_at := NULL;
      NEW.jovahagyo_id := NULL;
      NEW.jovahagyas_at := NULL;
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS profile_preferences_guard ON public.profile_preferences;
CREATE TRIGGER profile_preferences_guard
  BEFORE UPDATE ON public.profile_preferences
  FOR EACH ROW
  EXECUTE FUNCTION public.profile_preferences_guard();

DROP TRIGGER IF EXISTS profile_preferences_audit ON public.profile_preferences;
CREATE TRIGGER profile_preferences_audit
  AFTER INSERT OR UPDATE OR DELETE ON public.profile_preferences
  FOR EACH ROW
  EXECUTE FUNCTION public.audit_trigger_fn();
