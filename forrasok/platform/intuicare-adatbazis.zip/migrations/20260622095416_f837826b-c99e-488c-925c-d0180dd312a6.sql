create or replace function public.evaluate_questionnaire_red_flag()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_red_flag boolean := false;
  v_score_critical boolean := false;
  v_q_title text;
begin
  if new.answers is null then return new; end if;
  begin
    v_red_flag := coalesce((new.answers->>'_red_flag')::boolean, false);
  exception when others then v_red_flag := false; end;
  begin
    v_score_critical := coalesce((new.answers->>'_score_critical')::boolean, false);
  exception when others then v_score_critical := false; end;
  if not (v_red_flag or v_score_critical) then return new; end if;
  select title into v_q_title from public.questionnaires where id = new.questionnaire_id;
  insert into public.clinical_critical_alerts (
    patient_id, code, severity, source, message, value_json, triggered_at, workflow_status
  ) values (
    new.patient_id,
    'questionnaire_red_flag',
    case when v_score_critical then 'high' else 'medium' end,
    'patient_questionnaire',
    coalesce(v_q_title, 'Kérdőív válasz') || ' — automatikus eszkaláció',
    jsonb_build_object('questionnaire_id', new.questionnaire_id, 'response_id', new.id, 'assignment_id', new.assignment_id),
    now(),
    'open'
  );
  return new;
end;
$$;

drop trigger if exists trg_questionnaire_response_red_flag on public.questionnaire_responses;
create trigger trg_questionnaire_response_red_flag
  after insert on public.questionnaire_responses
  for each row execute function public.evaluate_questionnaire_red_flag();

create index if not exists idx_patient_appt_requests_status_created
  on public.patient_appointment_requests (status, created_at desc);

create index if not exists idx_patient_referral_requests_status_created
  on public.patient_referral_requests (status, created_at desc);

create index if not exists idx_monitoring_thresholds_kulcs_patient
  on public.monitoring_thresholds (kulcs, patient_id);