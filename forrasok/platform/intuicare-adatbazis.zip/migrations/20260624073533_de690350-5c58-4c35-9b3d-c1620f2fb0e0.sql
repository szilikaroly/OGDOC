
DROP POLICY IF EXISTS "staff read med requests" ON public.patient_medication_requests;
CREATE POLICY "staff read med requests"
ON public.patient_medication_requests
FOR SELECT
TO authenticated
USING (
  has_permission(auth.uid(), 'view_patient_data')
  AND can_access_patient(patient_id)
);

DROP POLICY IF EXISTS "staff update med requests" ON public.patient_medication_requests;
CREATE POLICY "staff update med requests"
ON public.patient_medication_requests
FOR UPDATE
TO authenticated
USING (
  has_permission(auth.uid(), 'view_patient_data')
  AND can_access_patient(patient_id)
)
WITH CHECK (
  has_permission(auth.uid(), 'view_patient_data')
  AND can_access_patient(patient_id)
);
