
-- Helper: notify linked patient_user (if any)
CREATE OR REPLACE FUNCTION public.notify_patient_user(
  _patient_id uuid,
  _tipus text,
  _cim text,
  _uzenet text,
  _link text
) RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _user_id uuid;
BEGIN
  IF _patient_id IS NULL THEN RETURN; END IF;
  SELECT user_id INTO _user_id
  FROM public.patient_users
  WHERE patient_id = _patient_id
  LIMIT 1;
  IF _user_id IS NULL THEN RETURN; END IF;
  INSERT INTO public.notifications (user_id, tipus, cim, uzenet, link)
  VALUES (_user_id, _tipus, _cim, _uzenet, _link);
END;
$$;

-- 1) Critical clinical alerts -> patient notification
CREATE OR REPLACE FUNCTION public.tg_critical_alert_notify()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.severity IN ('critical','high') THEN
    PERFORM public.notify_patient_user(
      NEW.patient_id,
      'danger',
      'Sürgős klinikai riasztás',
      COALESCE(NEW.message, NEW.code, 'Új klinikai riasztás érkezett. Kérjük, vegye fel a kapcsolatot kezelőorvosával.'),
      '/portal/leletek'
    );
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_critical_alert_notify ON public.clinical_critical_alerts;
CREATE TRIGGER trg_critical_alert_notify
AFTER INSERT ON public.clinical_critical_alerts
FOR EACH ROW EXECUTE FUNCTION public.tg_critical_alert_notify();

-- 2) Abnormal lab observations -> patient notification
CREATE OR REPLACE FUNCTION public.tg_observation_abnormal_notify()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.interpretation IN ('H','HH','L','LL','A','AA') THEN
    PERFORM public.notify_patient_user(
      NEW.patient_id,
      'info',
      'Új lelet elérhető',
      'Új laboreredménye érkezett. Tekintse meg a portálon.',
      '/portal/leletek'
    );
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_observation_abnormal_notify ON public.clinical_observations;
CREATE TRIGGER trg_observation_abnormal_notify
AFTER INSERT ON public.clinical_observations
FOR EACH ROW EXECUTE FUNCTION public.tg_observation_abnormal_notify();

-- 3) New appointment booking -> patient notification
CREATE OR REPLACE FUNCTION public.tg_appointment_booked_notify()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _start timestamptz;
BEGIN
  IF NEW.patient_id IS NULL THEN RETURN NEW; END IF;
  SELECT kezdo_ts INTO _start FROM public.appointment_slots WHERE id = NEW.slot_id;
  PERFORM public.notify_patient_user(
    NEW.patient_id,
    'success',
    'Időpont visszaigazolva',
    CASE WHEN _start IS NOT NULL
      THEN 'Új időpontja: ' || to_char(_start AT TIME ZONE 'Europe/Budapest','YYYY-MM-DD HH24:MI')
      ELSE 'Új időpontja került rögzítésre.'
    END,
    '/portal/idopontok'
  );
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_appointment_booked_notify ON public.appointments;
CREATE TRIGGER trg_appointment_booked_notify
AFTER INSERT ON public.appointments
FOR EACH ROW EXECUTE FUNCTION public.tg_appointment_booked_notify();

-- 4) Followup enrollment -> patient notification
CREATE OR REPLACE FUNCTION public.tg_followup_enrolled_notify()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  PERFORM public.notify_patient_user(
    NEW.patient_id,
    'info',
    'Utánkövetési programba sorolva',
    'A kezelőorvosa utánkövetési programba sorolta. A részleteket a portálon tekintheti meg.',
    '/portal'
  );
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_followup_enrolled_notify ON public.followup_enrollments;
CREATE TRIGGER trg_followup_enrolled_notify
AFTER INSERT ON public.followup_enrollments
FOR EACH ROW EXECUTE FUNCTION public.tg_followup_enrolled_notify();

-- 5) Patient can read their own signed clinical notes (zárójelentés, ambuláns lap)
CREATE POLICY "Patient reads own signed notes"
ON public.clinical_notes
FOR SELECT
TO authenticated
USING (
  signed_at IS NOT NULL
  AND EXISTS (
    SELECT 1 FROM public.patient_users pu
    WHERE pu.patient_id = clinical_notes.patient_id
      AND pu.user_id = auth.uid()
  )
);
