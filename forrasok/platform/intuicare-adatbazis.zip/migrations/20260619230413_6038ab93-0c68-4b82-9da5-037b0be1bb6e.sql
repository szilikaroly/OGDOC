
-- 1) Profile locale
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS locale text;

-- 2) attendance_anchors: restrict select to managers
DROP POLICY IF EXISTS aa_select ON public.attendance_anchors;
CREATE POLICY aa_select ON public.attendance_anchors
  FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id()
    AND (public.has_permission(auth.uid(),'manage_tenant')
         OR public.has_permission(auth.uid(),'manage_schedule')));

-- 3) Clinical tables: require manage_patients OR manage_tenant
DO $$
DECLARE
  t text;
  tables text[] := ARRAY['measurements','contractions','fetal_movements','menstrual_cycles','stool_log','food_log','wearable_data','monitoring_alerts','monitoring_programs','monitoring_thresholds','questionnaire_schedules'];
  polname text;
BEGIN
  FOREACH t IN ARRAY tables LOOP
    polname := 'tenant_isolation_' || t;
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', polname, t);
    EXECUTE format($f$
      CREATE POLICY %I ON public.%I
        FOR ALL TO authenticated
        USING (tenant_id = public.current_tenant_id()
          AND (public.has_permission(auth.uid(),'manage_patients')
               OR public.has_permission(auth.uid(),'manage_tenant')))
        WITH CHECK (tenant_id = public.current_tenant_id()
          AND (public.has_permission(auth.uid(),'manage_patients')
               OR public.has_permission(auth.uid(),'manage_tenant')))
    $f$, polname, t);
  END LOOP;
END $$;

-- 4) patient_checkin: tighten write
DROP POLICY IF EXISTS pc_write ON public.patient_checkin;
CREATE POLICY pc_write ON public.patient_checkin
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
    AND (public.has_permission(auth.uid(),'manage_patients')
         OR public.has_permission(auth.uid(),'manage_schedule')
         OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id()
    AND (public.has_permission(auth.uid(),'manage_patients')
         OR public.has_permission(auth.uid(),'manage_schedule')
         OR public.has_permission(auth.uid(),'manage_tenant')));
