
-- 1. Drop overlapping permissive policies (loose one wins via OR)
DROP POLICY IF EXISTS "tenant_isolation_fetal_mov" ON public.fetal_movements;
DROP POLICY IF EXISTS "tenant_isolation_menstrual" ON public.menstrual_cycles;
DROP POLICY IF EXISTS "tenant_isolation_mon_alerts" ON public.monitoring_alerts;
DROP POLICY IF EXISTS "tenant_isolation_mon_programs" ON public.monitoring_programs;
DROP POLICY IF EXISTS "tenant_isolation_thresholds" ON public.monitoring_thresholds;
DROP POLICY IF EXISTS "tenant_isolation_qsched" ON public.questionnaire_schedules;
DROP POLICY IF EXISTS "tenant_isolation_stool_log" ON public.stool_log;
DROP POLICY IF EXISTS "tenant_isolation_wearable" ON public.wearable_data;

-- 2. clinical_calculator_results: enforce can_access_patient on INSERT and UPDATE
DROP POLICY IF EXISTS "auth users insert calc results" ON public.clinical_calculator_results;
CREATE POLICY "auth users insert calc results" ON public.clinical_calculator_results
  FOR INSERT TO authenticated
  WITH CHECK (
    auth.uid() = created_by
    AND (patient_id IS NULL OR public.can_access_patient(patient_id))
  );

DROP POLICY IF EXISTS "creator updates calc results" ON public.clinical_calculator_results;
CREATE POLICY "creator updates calc results" ON public.clinical_calculator_results
  FOR UPDATE TO authenticated
  USING (auth.uid() = created_by)
  WITH CHECK (
    auth.uid() = created_by
    AND (patient_id IS NULL OR public.can_access_patient(patient_id))
  );

-- 3. clinical_therapy_orders: enforce can_access_patient on INSERT and UPDATE
DROP POLICY IF EXISTS "auth users insert therapy" ON public.clinical_therapy_orders;
CREATE POLICY "auth users insert therapy" ON public.clinical_therapy_orders
  FOR INSERT TO authenticated
  WITH CHECK (
    auth.uid() = created_by
    AND public.can_access_patient(patient_id)
  );

DROP POLICY IF EXISTS "creator updates therapy" ON public.clinical_therapy_orders;
CREATE POLICY "creator updates therapy" ON public.clinical_therapy_orders
  FOR UPDATE TO authenticated
  USING (auth.uid() = created_by)
  WITH CHECK (
    auth.uid() = created_by
    AND public.can_access_patient(patient_id)
  );

-- 4. email_digest_settings: add tenant filter
DROP POLICY IF EXISTS "admins_select_digest" ON public.email_digest_settings;
CREATE POLICY "admins_select_digest" ON public.email_digest_settings
  FOR SELECT TO authenticated
  USING (
    tenant_id = public.current_tenant_id()
    AND (public.has_role(auth.uid(), 'tenant_admin') OR public.has_role(auth.uid(), 'igazgato'))
  );

DROP POLICY IF EXISTS "admins_upsert_digest" ON public.email_digest_settings;
CREATE POLICY "admins_upsert_digest" ON public.email_digest_settings
  FOR ALL TO authenticated
  USING (
    tenant_id = public.current_tenant_id()
    AND (public.has_role(auth.uid(), 'tenant_admin') OR public.has_role(auth.uid(), 'igazgato'))
  )
  WITH CHECK (
    tenant_id = public.current_tenant_id()
    AND (public.has_role(auth.uid(), 'tenant_admin') OR public.has_role(auth.uid(), 'igazgato'))
  );

-- 5. clinical_alert_escalation_rules: replace has_role with has_permission + tenant
DROP POLICY IF EXISTS "cae_rules_write_admin_or_orvos" ON public.clinical_alert_escalation_rules;
CREATE POLICY "cae_rules_write_admin_or_orvos" ON public.clinical_alert_escalation_rules
  FOR ALL TO authenticated
  USING (
    tenant_id = public.current_tenant_id()
    AND public.has_permission(auth.uid(), 'manage_tenant')
  )
  WITH CHECK (
    tenant_id = public.current_tenant_id()
    AND public.has_permission(auth.uid(), 'manage_tenant')
  );

-- 6. i18n_translations: restrict writes to manage_tenant
DROP POLICY IF EXISTS "tenant members write i18n" ON public.i18n_translations;
CREATE POLICY "tenant members write i18n" ON public.i18n_translations
  FOR ALL TO authenticated
  USING (
    (tenant_id IS NULL OR tenant_id = public.current_tenant_id())
    AND public.has_permission(auth.uid(), 'manage_tenant')
  )
  WITH CHECK (
    (tenant_id IS NULL OR tenant_id = public.current_tenant_id())
    AND public.has_permission(auth.uid(), 'manage_tenant')
  );

-- 7. translation_glossary: restrict writes to manage_tenant
DROP POLICY IF EXISTS "tenant members write glossary" ON public.translation_glossary;
CREATE POLICY "tenant members write glossary" ON public.translation_glossary
  FOR ALL TO authenticated
  USING (
    (tenant_id IS NULL OR tenant_id = public.current_tenant_id())
    AND public.has_permission(auth.uid(), 'manage_tenant')
  )
  WITH CHECK (
    (tenant_id IS NULL OR tenant_id = public.current_tenant_id())
    AND public.has_permission(auth.uid(), 'manage_tenant')
  );

-- 8. questionnaire_assignments: require manage_patients permission for writes
DROP POLICY IF EXISTS "qa_write_auth" ON public.questionnaire_assignments;
CREATE POLICY "qa_write_auth" ON public.questionnaire_assignments
  FOR ALL TO authenticated
  USING (
    tenant_id = public.current_tenant_id()
    AND public.has_permission(auth.uid(), 'manage_patients')
  )
  WITH CHECK (
    tenant_id = public.current_tenant_id()
    AND public.has_permission(auth.uid(), 'manage_patients')
  );

-- 9. user_roles bootstrap: only allow when the target tenant has zero existing roles AND the user's profile is attached to it
DROP POLICY IF EXISTS "user_roles_bootstrap_admin" ON public.user_roles;
CREATE POLICY "user_roles_bootstrap_admin" ON public.user_roles
  FOR INSERT TO authenticated
  WITH CHECK (
    user_id = auth.uid()
    AND role_id IN (SELECT id FROM public.roles WHERE kulcs = 'tenant_admin')
    AND EXISTS (
      SELECT 1 FROM public.profiles p
      WHERE p.id = auth.uid() AND p.tenant_id = user_roles.tenant_id
    )
    AND NOT EXISTS (
      SELECT 1 FROM public.user_roles ur
      WHERE ur.tenant_id = user_roles.tenant_id
    )
  );
