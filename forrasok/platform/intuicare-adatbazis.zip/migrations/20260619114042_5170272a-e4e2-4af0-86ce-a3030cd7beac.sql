
-- generate_duty_demand: derives daily demand rows from duty_lines + coverage
CREATE OR REPLACE FUNCTION public.generate_duty_demand(_site_id uuid, _from date, _to date)
RETURNS TABLE(
  datum date,
  duty_line_id uuid,
  duty_line_nev text,
  szerep_tipus duty_szerep_tipus,
  primary_org_unit_id uuid,
  kezd_ido time,
  veg_ido time,
  letszam smallint,
  org_unit_id uuid,
  kotelezo boolean
)
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  WITH napok AS (
    SELECT d::date AS datum, EXTRACT(isodow FROM d)::int AS iso
    FROM generate_series(_from::timestamp, _to::timestamp, interval '1 day') d
  )
  SELECT n.datum, dl.id, dl.nev, dl.szerep_tipus, dl.primary_org_unit_id,
         dl.kezd_ido, dl.veg_ido, dl.letszam,
         cov.org_unit_id, cov.kotelezo
  FROM napok n
  CROSS JOIN public.duty_lines dl
  LEFT JOIN public.duty_line_coverage cov ON cov.duty_line_id = dl.id
  WHERE dl.site_id = _site_id
    AND dl.aktiv
    AND dl.tenant_id = public.current_tenant_id()
    AND n.iso = ANY(dl.napok)
    AND (dl.unnepnap_uzemel OR NOT EXISTS (
      SELECT 1 FROM public.public_holidays h
      WHERE h.datum = n.datum
        AND (h.tenant_id IS NULL OR h.tenant_id = public.current_tenant_id())
    ))
  ORDER BY n.datum, dl.sorrend, dl.nev;
$$;

GRANT EXECUTE ON FUNCTION public.generate_duty_demand(uuid,date,date) TO authenticated;
