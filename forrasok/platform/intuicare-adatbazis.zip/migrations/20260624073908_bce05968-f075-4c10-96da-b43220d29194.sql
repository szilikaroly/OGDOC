
DROP POLICY IF EXISTS profile_contacts_select ON public.profile_contacts;
CREATE POLICY profile_contacts_select
ON public.profile_contacts
FOR SELECT
TO authenticated
USING (
  user_id = auth.uid()
  OR (
    has_permission(auth.uid(), 'manage_tenant')
    AND tenant_id = current_tenant_id()
  )
);

DROP POLICY IF EXISTS profile_contacts_write ON public.profile_contacts;
CREATE POLICY profile_contacts_write
ON public.profile_contacts
FOR ALL
TO authenticated
USING (
  user_id = auth.uid()
  OR (
    has_permission(auth.uid(), 'manage_tenant')
    AND tenant_id = current_tenant_id()
  )
)
WITH CHECK (
  user_id = auth.uid()
  OR (
    has_permission(auth.uid(), 'manage_tenant')
    AND tenant_id = current_tenant_id()
  )
);
