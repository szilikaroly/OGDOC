-- Phase 1: allow users to update only the megjegyzes field on their own schedule rows

CREATE POLICY "sa_user_update_own_note"
  ON public.schedule_assignments
  FOR UPDATE
  TO authenticated
  USING (tenant_id = current_tenant_id() AND user_id = auth.uid())
  WITH CHECK (tenant_id = current_tenant_id() AND user_id = auth.uid());

CREATE OR REPLACE FUNCTION public.enforce_user_only_megjegyzes_update()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Admins / schedule managers may update anything (their own policy already covers them)
  IF has_permission(auth.uid(), 'manage_schedule') OR has_permission(auth.uid(), 'manage_tenant') THEN
    RETURN NEW;
  END IF;

  -- For the owner editing their own row: only megjegyzes may change
  IF NEW.user_id = auth.uid() AND OLD.user_id = auth.uid() THEN
    IF NEW.tenant_id     IS DISTINCT FROM OLD.tenant_id
    OR NEW.user_id       IS DISTINCT FROM OLD.user_id
    OR NEW.org_unit_id   IS DISTINCT FROM OLD.org_unit_id
    OR NEW.site_id       IS DISTINCT FROM OLD.site_id
    OR NEW.feladatkor_id IS DISTINCT FROM OLD.feladatkor_id
    OR NEW.kezdo_idopont IS DISTINCT FROM OLD.kezdo_idopont
    OR NEW.zaro_idopont  IS DISTINCT FROM OLD.zaro_idopont
    OR NEW.ora           IS DISTINCT FROM OLD.ora
    OR NEW.kategoria     IS DISTINCT FROM OLD.kategoria
    OR NEW.status        IS DISTINCT FROM OLD.status
    OR NEW.pin           IS DISTINCT FROM OLD.pin
    OR NEW.forras        IS DISTINCT FROM OLD.forras
    OR NEW.created_by    IS DISTINCT FROM OLD.created_by
    OR NEW.run_id        IS DISTINCT FROM OLD.run_id THEN
      RAISE EXCEPTION 'Csak a megjegyzés módosítható a saját beosztáson.';
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS sa_enforce_user_note_only ON public.schedule_assignments;
CREATE TRIGGER sa_enforce_user_note_only
  BEFORE UPDATE ON public.schedule_assignments
  FOR EACH ROW
  EXECUTE FUNCTION public.enforce_user_only_megjegyzes_update();