
-- 1. Push subscriptions
CREATE TABLE public.push_subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  endpoint TEXT NOT NULL,
  p256dh TEXT NOT NULL,
  auth TEXT NOT NULL,
  user_agent TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_used_at TIMESTAMPTZ,
  UNIQUE (endpoint)
);
CREATE INDEX idx_push_subscriptions_user ON public.push_subscriptions(user_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.push_subscriptions TO authenticated;
GRANT ALL ON public.push_subscriptions TO service_role;

ALTER TABLE public.push_subscriptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage own push subscriptions"
  ON public.push_subscriptions FOR ALL
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- 2. Shift notifications log (idempotency)
CREATE TABLE public.shift_notifications_sent (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assignment_id UUID NOT NULL,
  user_id UUID NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('24h','2h')),
  channel TEXT NOT NULL CHECK (channel IN ('email','push')),
  sent_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  success BOOLEAN NOT NULL DEFAULT true,
  error TEXT,
  UNIQUE (assignment_id, kind, channel)
);
CREATE INDEX idx_shift_notif_user ON public.shift_notifications_sent(user_id, sent_at DESC);

GRANT SELECT ON public.shift_notifications_sent TO authenticated;
GRANT ALL ON public.shift_notifications_sent TO service_role;

ALTER TABLE public.shift_notifications_sent ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users see own shift notifications"
  ON public.shift_notifications_sent FOR SELECT
  USING (auth.uid() = user_id);

-- 3. Profile preferences
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS reminder_email_enabled BOOLEAN NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS reminder_push_enabled BOOLEAN NOT NULL DEFAULT true;
