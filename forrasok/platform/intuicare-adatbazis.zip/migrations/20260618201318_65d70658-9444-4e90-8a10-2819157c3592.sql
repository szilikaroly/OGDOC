
DROP VIEW IF EXISTS public.profile_scheduling_facts CASCADE;

CREATE TABLE public.work_time_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  jogviszony_tipus public.jogviszony_tipus NOT NULL,
  fenntarto_tipus public.fenntarto_tipus NOT NULL,
  napi_pihenes_min_ora numeric NOT NULL DEFAULT 11,
  heti_max_ora numeric NOT NULL DEFAULT 48,
  heti_max_ora_ovt numeric NOT NULL DEFAULT 60,
  heti_max_ora_egeszsegugyi numeric NOT NULL DEFAULT 72,
  napi_max_ora numeric NOT NULL DEFAULT 12,
  napi_max_ora_ugyelettel numeric NOT NULL DEFAULT 24,
  eves_ugyelet_rendkivuli_max numeric NOT NULL DEFAULT 416,
  eves_rendkivuli_max numeric NOT NULL DEFAULT 250,
  eves_ovt_rendkivuli_max numeric NOT NULL DEFAULT 150,
  havi_ugyelet_keszenlet_max int NOT NULL DEFAULT 14,
  havi_keszenlet_max int NOT NULL DEFAULT 10,
  heti_egybefuggo_piheno_ora numeric NOT NULL DEFAULT 48,
  forrasszoveg text,
  ervenyes_tol date NOT NULL DEFAULT CURRENT_DATE,
  ervenyes_ig date,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, jogviszony_tipus, fenntarto_tipus, ervenyes_tol)
);
GRANT SELECT ON public.work_time_rules TO authenticated;
GRANT ALL ON public.work_time_rules TO service_role;
ALTER TABLE public.work_time_rules ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wtr_select_authenticated" ON public.work_time_rules
  FOR SELECT TO authenticated USING (tenant_id IS NULL OR tenant_id = public.current_tenant_id());
CREATE POLICY "wtr_write_admin" ON public.work_time_rules
  FOR ALL TO authenticated
  USING (public.has_permission(auth.uid(), 'manage_tenant'))
  WITH CHECK (public.has_permission(auth.uid(), 'manage_tenant'));
CREATE TRIGGER wtr_touch BEFORE UPDATE ON public.work_time_rules
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

INSERT INTO public.work_time_rules (tenant_id, jogviszony_tipus, fenntarto_tipus, forrasszoveg) VALUES
  (NULL, 'egeszsegugyi_szolgalati', 'allami',           'Eszjtv. 2020/C + 528/2020 + Eütev. 12/A-G'),
  (NULL, 'egeszsegugyi_szolgalati', 'onkormanyzati',    'Eszjtv. 2020/C + 528/2020 + Eütev. 12/A-G'),
  (NULL, 'munka_tv_kv',             'maganszektor',     'Mt. 2012/I + Eütev. 12/A-G (528/2020 NEM)'),
  (NULL, 'munka_tv_kv',             'egyhazi',          'Mt. 2012/I + Eütev. 12/A-G'),
  (NULL, 'kjt_kozalkalmazott',      'egyetemi_klinika', 'Kjt. + Eütev. 12/A-G');

CREATE TABLE public.opt_out_agreements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  employment_id uuid REFERENCES public.profile_employment(id) ON DELETE SET NULL,
  alairas_datum date NOT NULL,
  ervenyes_tol date NOT NULL,
  ervenyes_ig date,
  visszavonas_datum date,
  visszavonas_hatalyba_lep date,
  visszavonas_indok text,
  dokumentum_url text,
  letrehozta uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.opt_out_agreements TO authenticated;
GRANT ALL ON public.opt_out_agreements TO service_role;
ALTER TABLE public.opt_out_agreements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "ooa_select" ON public.opt_out_agreements FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_permission(auth.uid(), 'manage_tenant'));
CREATE POLICY "ooa_insert" ON public.opt_out_agreements FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid() OR public.has_permission(auth.uid(), 'manage_tenant'));
CREATE POLICY "ooa_update" ON public.opt_out_agreements FOR UPDATE TO authenticated
  USING (user_id = auth.uid() OR public.has_permission(auth.uid(), 'manage_tenant'))
  WITH CHECK (user_id = auth.uid() OR public.has_permission(auth.uid(), 'manage_tenant'));
CREATE POLICY "ooa_delete" ON public.opt_out_agreements FOR DELETE TO authenticated
  USING (public.has_permission(auth.uid(), 'manage_tenant'));
CREATE TRIGGER ooa_touch BEFORE UPDATE ON public.opt_out_agreements
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE OR REPLACE FUNCTION public.opt_out_revocation_guard()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.visszavonas_datum IS NOT NULL
     AND (OLD.visszavonas_datum IS NULL OR NEW.visszavonas_datum IS DISTINCT FROM OLD.visszavonas_datum) THEN
    IF NEW.visszavonas_datum < (NEW.ervenyes_tol + INTERVAL '12 months')::date THEN
      RAISE EXCEPTION 'ÖVT visszavonás csak az aktiválás (%) után 12 hónappal lehetséges (Eütev. 12/B).', NEW.ervenyes_tol
        USING ERRCODE = '22023';
    END IF;
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER ooa_revocation_guard BEFORE UPDATE ON public.opt_out_agreements
  FOR EACH ROW EXECUTE FUNCTION public.opt_out_revocation_guard();

CREATE TABLE public.incompatibilities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  tipus text NOT NULL,
  munkaltato_nev text,
  munkakor text,
  heti_oraszam numeric,
  bejelentes_datum date NOT NULL DEFAULT CURRENT_DATE,
  ervenyes_tol date NOT NULL,
  ervenyes_ig date,
  vezetoi_dontes text,
  vezeto_id uuid REFERENCES auth.users(id),
  dontes_datum date,
  dokumentum_url text,
  megjegyzes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.incompatibilities TO authenticated;
GRANT ALL ON public.incompatibilities TO service_role;
ALTER TABLE public.incompatibilities ENABLE ROW LEVEL SECURITY;
CREATE POLICY "inc_select" ON public.incompatibilities FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_permission(auth.uid(), 'manage_tenant'));
CREATE POLICY "inc_insert" ON public.incompatibilities FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());
CREATE POLICY "inc_update" ON public.incompatibilities FOR UPDATE TO authenticated
  USING (user_id = auth.uid() OR public.has_permission(auth.uid(), 'manage_tenant'))
  WITH CHECK (user_id = auth.uid() OR public.has_permission(auth.uid(), 'manage_tenant'));
CREATE POLICY "inc_delete" ON public.incompatibilities FOR DELETE TO authenticated
  USING (public.has_permission(auth.uid(), 'manage_tenant'));
CREATE TRIGGER inc_touch BEFORE UPDATE ON public.incompatibilities
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE VIEW public.profile_scheduling_facts
WITH (security_invoker = true) AS
SELECT
  p.id AS user_id,
  p.tenant_id,
  p.teljes_nev,
  p.foglalkozas_tipus,
  COALESCE((
    SELECT array_agg(DISTINCT pc.tipus::text)
    FROM public.profile_constraints pc
    WHERE pc.user_id = p.id
      AND pc.ervenyes_tol <= CURRENT_DATE
      AND (pc.ervenyes_ig IS NULL OR pc.ervenyes_ig >= CURRENT_DATE)
  ), ARRAY[]::text[]) AS aktiv_korlatozok,
  EXISTS (
    SELECT 1 FROM public.profile_constraints pc
    WHERE pc.user_id = p.id AND pc.tipus = 'terhes'
      AND pc.ervenyes_tol <= CURRENT_DATE
      AND (pc.ervenyes_ig IS NULL OR pc.ervenyes_ig >= CURRENT_DATE)
  ) AS terhes,
  EXISTS (
    SELECT 1 FROM public.profile_unavailability pu
    WHERE pu.user_id = p.id AND pu.status = 'jovahagyott'
      AND pu.kezdo_datum <= CURRENT_DATE AND pu.zaro_datum >= CURRENT_DATE
  ) AS ma_tavol,
  (SELECT pp.heti_max_ora FROM public.profile_preferences pp WHERE pp.user_id = p.id) AS pref_heti_max_ora,
  (SELECT pp.preferalt_feladat_korok FROM public.profile_preferences pp WHERE pp.user_id = p.id) AS pref_feladat_korok,
  (SELECT pp.kozossegi_napok FROM public.profile_preferences pp WHERE pp.user_id = p.id) AS pref_kozossegi_napok,
  pe.id AS primary_employment_id,
  pe.jogviszony_tipus,
  pe.fenntarto_tipus,
  pe.fte_szazalek,
  pe.munkaido_keret,
  EXISTS (
    SELECT 1 FROM public.opt_out_agreements ooa
    WHERE ooa.user_id = p.id
      AND ooa.ervenyes_tol <= CURRENT_DATE
      AND (ooa.ervenyes_ig IS NULL OR ooa.ervenyes_ig >= CURRENT_DATE)
      AND (ooa.visszavonas_hatalyba_lep IS NULL OR ooa.visszavonas_hatalyba_lep > CURRENT_DATE)
  ) AS ovt_aktiv,
  (SELECT count(*)::int FROM public.profile_skills ps WHERE ps.user_id = p.id) AS skill_count,
  (SELECT count(*)::int FROM public.profile_certifications pcert
    WHERE pcert.user_id = p.id
      AND pcert.lejarat IS NOT NULL
      AND pcert.lejarat <= CURRENT_DATE + INTERVAL '60 days'
      AND pcert.lejarat >= CURRENT_DATE
  ) AS hamarosan_lejaro_kepzettseg,
  (SELECT count(*)::int FROM public.profile_peer_links pl
    WHERE (pl.from_user_id = p.id OR pl.to_user_id = p.id)
      AND pl.tipus = 'nem_dolgozik_vele'
      AND pl.status = 'jovahagyott'
  ) AS negativ_kapcsolat_szam
FROM public.profiles p
LEFT JOIN public.profile_employment pe
  ON pe.user_id = p.id AND pe.elsodleges = true;

GRANT SELECT ON public.profile_scheduling_facts TO authenticated;
