
-- 1) Allow 'scheduled' as a valid page status
ALTER TABLE public.cms_pages DROP CONSTRAINT IF EXISTS cms_pages_status_check;
ALTER TABLE public.cms_pages ADD CONSTRAINT cms_pages_status_check
  CHECK (status = ANY (ARRAY['draft'::text,'scheduled'::text,'published'::text,'archived'::text]));

-- 2) Auto-publish function: promote due scheduled pages to published
CREATE OR REPLACE FUNCTION public.run_scheduled_cms_publish()
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  updated_count integer;
BEGIN
  WITH promoted AS (
    UPDATE public.cms_pages
       SET status = 'published',
           published_at = now(),
           scheduled_publish_at = NULL,
           updated_at = now()
     WHERE status = 'scheduled'
       AND scheduled_publish_at IS NOT NULL
       AND scheduled_publish_at <= now()
     RETURNING id
  )
  SELECT count(*)::int INTO updated_count FROM promoted;
  RETURN updated_count;
END;
$$;

REVOKE ALL ON FUNCTION public.run_scheduled_cms_publish() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.run_scheduled_cms_publish() TO service_role;

-- 3) pg_cron: run every minute
DO $$
BEGIN
  PERFORM cron.unschedule('cms-auto-publish-scheduled');
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

SELECT cron.schedule(
  'cms-auto-publish-scheduled',
  '* * * * *',
  $cron$SELECT public.run_scheduled_cms_publish();$cron$
);
