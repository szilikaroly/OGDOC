
DROP INDEX IF EXISTS public.i18n_translations_unique_key;
ALTER TABLE public.i18n_translations
  DROP CONSTRAINT IF EXISTS i18n_translations_ns_key_lang_unique;
ALTER TABLE public.i18n_translations
  ADD CONSTRAINT i18n_translations_ns_key_lang_unique UNIQUE (namespace, key, lang);
