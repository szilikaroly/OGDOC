ALTER TABLE public.cms_pages
  ADD COLUMN IF NOT EXISTS schema_type text NOT NULL DEFAULT 'auto';

COMMENT ON COLUMN public.cms_pages.schema_type IS
  'schema.org típus a JSON-LD auto-generátorhoz: auto | webpage | article | faqpage | contactpage | aboutpage | service | organization | localbusiness | collectionpage';