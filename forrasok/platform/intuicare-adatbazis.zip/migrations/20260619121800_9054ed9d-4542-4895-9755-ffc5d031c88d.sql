DROP VIEW IF EXISTS public.profile_scheduling_facts;

CREATE VIEW public.profile_scheduling_facts AS
SELECT
  p.id AS user_id,
  p.tenant_id,
  p.teljes_nev,
  p.becenev,
  p.email,
  p.foglalkozas_tipus,
  pp.heti_max_ora,
  pp.havi_max_ugyelet,
  COALESCE(pp.ugyelet_utan_pihenonap, false) AS ugyelet_utan_pihenonap,
  COALESCE(pp.ugyelet_utan_min_ora, 11) AS ugyelet_utan_min_ora,
  COALESCE(pp.egymas_utani_max_ugyelet, 1) AS egymas_utani_max_ugyelet,
  COALESCE(pp.last_minute_elerheto, false) AS last_minute_elerheto,
  pp.last_minute_orahatar,
  pp.utazasi_perc_max,
  COALESCE(pp.preferalt_musakok::text[], ARRAY[]::text[]) AS preferalt_musakok,
  COALESCE(pp.tiltott_napok, ARRAY[]::integer[]) AS tiltott_napok,
  COALESCE(pp.nyelvek, ARRAY[]::text[]) AS nyelvek,
  EXISTS (SELECT 1 FROM profile_constraints pc WHERE pc.user_id=p.id AND pc.tipus='terhes' AND pc.ervenyes_tol<=CURRENT_DATE AND (pc.ervenyes_ig IS NULL OR pc.ervenyes_ig>=CURRENT_DATE)) AS terhes,
  EXISTS (SELECT 1 FROM profile_constraints pc WHERE pc.user_id=p.id AND pc.tipus='szoptat' AND pc.ervenyes_tol<=CURRENT_DATE AND (pc.ervenyes_ig IS NULL OR pc.ervenyes_ig>=CURRENT_DATE)) AS szoptat,
  EXISTS (SELECT 1 FROM profile_constraints pc WHERE pc.user_id=p.id AND pc.tipus='kisgyermek_otthon' AND pc.ervenyes_tol<=CURRENT_DATE AND (pc.ervenyes_ig IS NULL OR pc.ervenyes_ig>=CURRENT_DATE)) AS kisgyermek_otthon,
  EXISTS (SELECT 1 FROM profile_constraints pc WHERE pc.user_id=p.id AND pc.tipus='egyedulnevelo' AND pc.ervenyes_tol<=CURRENT_DATE AND (pc.ervenyes_ig IS NULL OR pc.ervenyes_ig>=CURRENT_DATE)) AS egyedulnevelo,
  EXISTS (SELECT 1 FROM profile_constraints pc WHERE pc.user_id=p.id AND pc.tipus='tartos_betegseg' AND pc.ervenyes_tol<=CURRENT_DATE AND (pc.ervenyes_ig IS NULL OR pc.ervenyes_ig>=CURRENT_DATE)) AS tartos_betegseg,
  EXISTS (SELECT 1 FROM profile_constraints pc WHERE pc.user_id=p.id AND pc.tipus='mozgaskorlatozas' AND pc.ervenyes_tol<=CURRENT_DATE AND (pc.ervenyes_ig IS NULL OR pc.ervenyes_ig>=CURRENT_DATE)) AS mozgaskorlatozas,
  EXISTS (SELECT 1 FROM profile_constraints pc WHERE pc.user_id=p.id AND pc.tipus='vedendokoru' AND pc.ervenyes_tol<=CURRENT_DATE AND (pc.ervenyes_ig IS NULL OR pc.ervenyes_ig>=CURRENT_DATE)) AS vedendokoru,
  (SELECT COUNT(*)::int FROM profile_constraints pc WHERE pc.user_id=p.id AND pc.ervenyes_tol<=CURRENT_DATE AND (pc.ervenyes_ig IS NULL OR pc.ervenyes_ig>=CURRENT_DATE)) AS aktiv_constraint_count,
  EXISTS (SELECT 1 FROM profile_constraints pc WHERE pc.user_id=p.id AND pc.tipus IN ('terhes','szoptat','vedendokoru') AND pc.ervenyes_tol<=CURRENT_DATE AND (pc.ervenyes_ig IS NULL OR pc.ervenyes_ig>=CURRENT_DATE)) AS tiltott_ejszaka,
  EXISTS (SELECT 1 FROM profile_constraints pc WHERE pc.user_id=p.id AND pc.tipus IN ('terhes','szoptat') AND pc.ervenyes_tol<=CURRENT_DATE AND (pc.ervenyes_ig IS NULL OR pc.ervenyes_ig>=CURRENT_DATE)) AS tiltott_sugar_zona,
  COALESCE(pp.ugyelet_utan_min_ora, 11) AS min_pihenoido_ora,
  (SELECT COUNT(*)::int FROM profile_unavailability pu WHERE pu.user_id=p.id AND pu.status='jovahagyott' AND pu.kezdo_datum >= CURRENT_DATE - INTERVAL '30 days' AND pu.kezdo_datum <= CURRENT_DATE + INTERVAL '30 days') AS tavollet_nap_30,
  (SELECT COUNT(*)::int FROM profile_unavailability pu WHERE pu.user_id=p.id AND pu.status='jovahagyott' AND pu.kezdo_datum >= CURRENT_DATE - INTERVAL '90 days' AND pu.kezdo_datum <= CURRENT_DATE + INTERVAL '90 days') AS tavollet_nap_90,
  (SELECT COUNT(*)::int FROM profile_unavailability pu WHERE pu.user_id=p.id AND pu.status='jovahagyasra_var') AS fuggo_tavollet_count,
  (SELECT COUNT(*)::int FROM profile_unavailability pu WHERE pu.user_id=p.id AND pu.status='jovahagyott') AS jovahagyott_tavollet_count,
  (SELECT COUNT(*)::int FROM profile_peer_links pl WHERE (pl.from_user_id=p.id OR pl.to_user_id=p.id) AND pl.tipus='szivesen_dolgozik_vele' AND pl.status='jovahagyott') AS pozitiv_kapcsolat,
  (SELECT COUNT(*)::int FROM profile_peer_links pl WHERE (pl.from_user_id=p.id OR pl.to_user_id=p.id) AND pl.tipus='nem_dolgozik_vele' AND pl.status='jovahagyott') AS negativ_kapcsolat,
  (SELECT COUNT(*)::int FROM profile_peer_links pl WHERE pl.from_user_id=p.id AND pl.tipus='mentor' AND pl.status='jovahagyott') AS mentor_count,
  (SELECT COUNT(*)::int FROM profile_peer_links pl WHERE pl.to_user_id=p.id AND pl.tipus='mentor' AND pl.status='jovahagyott') AS mentee_count,
  (SELECT COUNT(*)::int FROM profile_contacts pcon WHERE pcon.user_id=p.id) AS contact_count,
  EXISTS (SELECT 1 FROM notifications n WHERE n.user_id=p.id AND n.olvasott_at IS NULL) AS van_aktiv_ertesites
FROM profiles p
LEFT JOIN profile_preferences pp ON pp.user_id = p.id;

GRANT SELECT ON public.profile_scheduling_facts TO authenticated;

CREATE OR REPLACE FUNCTION public.touch_updated_at() RETURNS trigger
LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

CREATE TABLE public.profile_external_hours (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  tenant_id uuid,
  ev integer NOT NULL CHECK (ev BETWEEN 2020 AND 2100),
  honap integer NOT NULL CHECK (honap BETWEEN 1 AND 12),
  ora numeric(6,2) NOT NULL CHECK (ora >= 0 AND ora <= 744),
  hely text,
  jogviszony_tipus text,
  megjegyzes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX uq_profile_external_hours_user_ym_hely ON public.profile_external_hours(user_id, ev, honap, COALESCE(hely, ''));
CREATE INDEX idx_profile_external_hours_user_ym ON public.profile_external_hours(user_id, ev, honap);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_external_hours TO authenticated;
GRANT ALL ON public.profile_external_hours TO service_role;
ALTER TABLE public.profile_external_hours ENABLE ROW LEVEL SECURITY;

CREATE POLICY "external_hours_self_select" ON public.profile_external_hours FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "external_hours_self_insert" ON public.profile_external_hours FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "external_hours_self_update" ON public.profile_external_hours FOR UPDATE TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE POLICY "external_hours_self_delete" ON public.profile_external_hours FOR DELETE TO authenticated USING (user_id = auth.uid());
CREATE POLICY "external_hours_leaders_select" ON public.profile_external_hours FOR SELECT TO authenticated USING (public.has_permission(auth.uid(), 'view_team') OR public.has_permission(auth.uid(), 'manage_org') OR public.has_permission(auth.uid(), 'manage_schedule'));
CREATE POLICY "external_hours_leaders_modify" ON public.profile_external_hours FOR ALL TO authenticated USING (public.has_permission(auth.uid(), 'manage_org') OR public.has_permission(auth.uid(), 'manage_schedule')) WITH CHECK (public.has_permission(auth.uid(), 'manage_org') OR public.has_permission(auth.uid(), 'manage_schedule'));

CREATE TRIGGER trg_profile_external_hours_touch BEFORE UPDATE ON public.profile_external_hours FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();