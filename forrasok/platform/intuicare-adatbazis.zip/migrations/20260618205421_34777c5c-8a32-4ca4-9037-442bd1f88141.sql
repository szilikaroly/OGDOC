-- Schedule runs (solver futtatás-naplók) + magyarázatok
CREATE TABLE IF NOT EXISTS public.schedule_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  indito_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  idoszak_kezdet date NOT NULL,
  idoszak_veg date NOT NULL,
  org_unit_id uuid REFERENCES public.org_units(id) ON DELETE SET NULL,
  solver text NOT NULL DEFAULT 'yalps',
  status text NOT NULL DEFAULT 'kesz',  -- futo | kesz | hibas | elvetett
  parameterek jsonb NOT NULL DEFAULT '{}'::jsonb,
  eredmeny_osszegzes jsonb NOT NULL DEFAULT '{}'::jsonb,
  hard_sertes_szam int NOT NULL DEFAULT 0,
  lagy_pontszam numeric(10,2) NOT NULL DEFAULT 0,
  hibauzenet text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.schedule_runs TO authenticated;
GRANT ALL ON public.schedule_runs TO service_role;
ALTER TABLE public.schedule_runs ENABLE ROW LEVEL SECURITY;

CREATE POLICY sr_select ON public.schedule_runs FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());

CREATE POLICY sr_write_admin ON public.schedule_runs FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (public.has_permission(auth.uid(),'manage_schedule') OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id() AND (public.has_permission(auth.uid(),'manage_schedule') OR public.has_permission(auth.uid(),'manage_tenant')));

CREATE TRIGGER sr_touch BEFORE UPDATE ON public.schedule_runs
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- Magyarázat-tételek (assignment-szintű "miért így döntött a solver")
CREATE TABLE IF NOT EXISTS public.schedule_explanations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  run_id uuid NOT NULL REFERENCES public.schedule_runs(id) ON DELETE CASCADE,
  assignment_id uuid REFERENCES public.schedule_assignments(id) ON DELETE CASCADE,
  user_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  datum date,
  szint text NOT NULL DEFAULT 'info',  -- info | figyelmeztetes | sertes
  kulcs text NOT NULL,                  -- pl. 'preferencia', 'paros_kivant', 'utolso_jeloltent'
  szoveg text NOT NULL,
  sulyozas numeric(8,2),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_se_run ON public.schedule_explanations (run_id);
CREATE INDEX IF NOT EXISTS idx_se_assignment ON public.schedule_explanations (assignment_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.schedule_explanations TO authenticated;
GRANT ALL ON public.schedule_explanations TO service_role;
ALTER TABLE public.schedule_explanations ENABLE ROW LEVEL SECURITY;

CREATE POLICY se_select ON public.schedule_explanations FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());

CREATE POLICY se_write_admin ON public.schedule_explanations FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (public.has_permission(auth.uid(),'manage_schedule') OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id() AND (public.has_permission(auth.uid(),'manage_schedule') OR public.has_permission(auth.uid(),'manage_tenant')));

-- Hozzáadjuk a schedule_assignments-hez a run_id mezőt (NULL = kézi)
ALTER TABLE public.schedule_assignments
  ADD COLUMN IF NOT EXISTS run_id uuid REFERENCES public.schedule_runs(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_sa_run ON public.schedule_assignments (run_id);
