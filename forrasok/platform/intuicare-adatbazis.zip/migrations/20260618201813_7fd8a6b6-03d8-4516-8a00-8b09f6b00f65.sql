
-- ============================================================
-- H kör: assignments, ledger, díjkódok
-- ============================================================

DO $$ BEGIN
  CREATE TYPE public.ora_kategoria AS ENUM (
    'rendes','ugyelet','keszenlet','ovt','rendkivuli','kompenzalo','szabadsag','tavollet'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.assignment_status AS ENUM ('tervezett','veglegesitett','tenyleges','torolt');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- Tervezett / véglegesített beosztás
CREATE TABLE IF NOT EXISTS public.schedule_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  org_unit_id uuid REFERENCES public.org_units(id) ON DELETE SET NULL,
  site_id uuid REFERENCES public.sites(id) ON DELETE SET NULL,
  feladatkor_id uuid REFERENCES public.feladat_korok(id) ON DELETE SET NULL,
  kezdo_idopont timestamptz NOT NULL,
  zaro_idopont timestamptz NOT NULL,
  ora numeric(6,2) NOT NULL,
  kategoria public.ora_kategoria NOT NULL DEFAULT 'rendes',
  status public.assignment_status NOT NULL DEFAULT 'tervezett',
  pin boolean NOT NULL DEFAULT false,
  forras text,
  megjegyzes text,
  created_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT sa_time_chk CHECK (zaro_idopont > kezdo_idopont),
  CONSTRAINT sa_ora_chk CHECK (ora > 0)
);

CREATE INDEX IF NOT EXISTS idx_sa_user_time ON public.schedule_assignments (user_id, kezdo_idopont, zaro_idopont);
CREATE INDEX IF NOT EXISTS idx_sa_org ON public.schedule_assignments (org_unit_id, kezdo_idopont);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.schedule_assignments TO authenticated;
GRANT ALL ON public.schedule_assignments TO service_role;
ALTER TABLE public.schedule_assignments ENABLE ROW LEVEL SECURITY;

CREATE POLICY sa_select ON public.schedule_assignments FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(),'manage_schedule')
    OR public.has_permission(auth.uid(),'view_team')
    OR public.has_permission(auth.uid(),'manage_tenant')
  ));

CREATE POLICY sa_write_admin ON public.schedule_assignments FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    public.has_permission(auth.uid(),'manage_schedule')
    OR public.has_permission(auth.uid(),'manage_tenant')
  ))
  WITH CHECK (tenant_id = public.current_tenant_id() AND (
    public.has_permission(auth.uid(),'manage_schedule')
    OR public.has_permission(auth.uid(),'manage_tenant')
  ));

CREATE TRIGGER sa_touch BEFORE UPDATE ON public.schedule_assignments
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TRIGGER audit_sa AFTER INSERT OR UPDATE OR DELETE ON public.schedule_assignments
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- Tény munkaidő (számfejtésre)
CREATE TABLE IF NOT EXISTS public.work_time_ledger (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  assignment_id uuid REFERENCES public.schedule_assignments(id) ON DELETE SET NULL,
  org_unit_id uuid REFERENCES public.org_units(id) ON DELETE SET NULL,
  datum date NOT NULL,
  kezdo_idopont timestamptz NOT NULL,
  zaro_idopont timestamptz NOT NULL,
  ora numeric(6,2) NOT NULL,
  kategoria public.ora_kategoria NOT NULL,
  ejszakai_ora numeric(6,2) NOT NULL DEFAULT 0,
  vasarnapi_ora numeric(6,2) NOT NULL DEFAULT 0,
  unnepnapi_ora numeric(6,2) NOT NULL DEFAULT 0,
  jovahagyo_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  jovahagyas_at timestamptz,
  forras text DEFAULT 'kezi',
  megjegyzes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT wtl_time_chk CHECK (zaro_idopont > kezdo_idopont),
  CONSTRAINT wtl_ora_chk CHECK (ora > 0)
);

CREATE INDEX IF NOT EXISTS idx_wtl_user_datum ON public.work_time_ledger (user_id, datum);
CREATE INDEX IF NOT EXISTS idx_wtl_kategoria ON public.work_time_ledger (kategoria);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.work_time_ledger TO authenticated;
GRANT ALL ON public.work_time_ledger TO service_role;
ALTER TABLE public.work_time_ledger ENABLE ROW LEVEL SECURITY;

CREATE POLICY wtl_select ON public.work_time_ledger FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(),'manage_schedule')
    OR public.has_permission(auth.uid(),'view_team')
    OR public.has_permission(auth.uid(),'manage_tenant')
  ));

CREATE POLICY wtl_write_admin ON public.work_time_ledger FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    public.has_permission(auth.uid(),'manage_schedule')
    OR public.has_permission(auth.uid(),'manage_tenant')
  ))
  WITH CHECK (tenant_id = public.current_tenant_id() AND (
    public.has_permission(auth.uid(),'manage_schedule')
    OR public.has_permission(auth.uid(),'manage_tenant')
  ));

CREATE TRIGGER wtl_touch BEFORE UPDATE ON public.work_time_ledger
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TRIGGER audit_wtl AFTER INSERT OR UPDATE OR DELETE ON public.work_time_ledger
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- Díjkód katalógus
CREATE TABLE IF NOT EXISTS public.wage_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  kod text NOT NULL,
  nev text NOT NULL,
  alap_szorzo numeric(5,3) NOT NULL DEFAULT 1.000,
  kategoria text,
  leiras text,
  ervenyes boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, kod)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.wage_codes TO authenticated;
GRANT ALL ON public.wage_codes TO service_role;
ALTER TABLE public.wage_codes ENABLE ROW LEVEL SECURITY;

CREATE POLICY wc_select ON public.wage_codes FOR SELECT TO authenticated
  USING (tenant_id IS NULL OR tenant_id = public.current_tenant_id());

CREATE POLICY wc_write_admin ON public.wage_codes FOR ALL TO authenticated
  USING (public.has_permission(auth.uid(),'manage_tenant'))
  WITH CHECK (public.has_permission(auth.uid(),'manage_tenant'));

CREATE TRIGGER wc_touch BEFORE UPDATE ON public.wage_codes
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- Alap-díjkód katalógus (NULL = globális)
INSERT INTO public.wage_codes (tenant_id, kod, nev, alap_szorzo, kategoria) VALUES
  (NULL,'RENDES','Rendes munkaidő',1.000,'rendes'),
  (NULL,'EJSZ','Éjszakai pótlék (22-06)',1.150,'potlek'),
  (NULL,'VASAR','Vasárnapi pótlék',1.500,'potlek'),
  (NULL,'UNNEP','Munkaszüneti napi pótlék',2.000,'potlek'),
  (NULL,'UGYELET','Ügyeleti díj',1.000,'ugyelet'),
  (NULL,'KESZ','Készenléti díj',0.250,'keszenlet'),
  (NULL,'OVT','Önként vállalt többletmunka',1.500,'ovt'),
  (NULL,'RENDKIV','Rendkívüli munkaidő',1.500,'rendkivuli'),
  (NULL,'KOMP','Kompenzáló pihenőidő',0.000,'kompenzalo')
ON CONFLICT DO NOTHING;

-- Díjkód-leképezés (óra-kategória + sáv → díjkód)
CREATE TABLE IF NOT EXISTS public.wage_mapping (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  kategoria public.ora_kategoria NOT NULL,
  sav text NOT NULL DEFAULT 'nappal',  -- nappal | ejszaka | vasarnap | unnep
  wage_code_id uuid NOT NULL REFERENCES public.wage_codes(id) ON DELETE RESTRICT,
  felulirat_szorzo numeric(5,3),
  prioritas smallint NOT NULL DEFAULT 100,
  ervenyes_tol date NOT NULL DEFAULT CURRENT_DATE,
  ervenyes_ig date,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, kategoria, sav, ervenyes_tol)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.wage_mapping TO authenticated;
GRANT ALL ON public.wage_mapping TO service_role;
ALTER TABLE public.wage_mapping ENABLE ROW LEVEL SECURITY;

CREATE POLICY wm_select ON public.wage_mapping FOR SELECT TO authenticated
  USING (tenant_id IS NULL OR tenant_id = public.current_tenant_id());

CREATE POLICY wm_write_admin ON public.wage_mapping FOR ALL TO authenticated
  USING (public.has_permission(auth.uid(),'manage_tenant'))
  WITH CHECK (public.has_permission(auth.uid(),'manage_tenant'));

CREATE TRIGGER wm_touch BEFORE UPDATE ON public.wage_mapping
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- Nézetek
CREATE OR REPLACE VIEW public.v_napi_pihenes
WITH (security_invoker = true) AS
SELECT
  user_id,
  tenant_id,
  datum,
  MIN(kezdo_idopont) AS elso_kezdes,
  MAX(zaro_idopont) AS utolso_vege,
  ROUND(EXTRACT(epoch FROM (MIN(kezdo_idopont) - LAG(MAX(zaro_idopont)) OVER (PARTITION BY user_id ORDER BY datum)))/3600.0, 2)
    AS piheno_ora_elozo_naphoz
FROM public.work_time_ledger
GROUP BY user_id, tenant_id, datum;

CREATE OR REPLACE VIEW public.v_heti_munkaido
WITH (security_invoker = true) AS
SELECT
  user_id,
  tenant_id,
  date_trunc('week', datum)::date AS het_kezdete,
  kategoria,
  SUM(ora)::numeric(8,2) AS ora_osszesen
FROM public.work_time_ledger
GROUP BY user_id, tenant_id, date_trunc('week', datum), kategoria;

CREATE OR REPLACE VIEW public.v_havi_ledger
WITH (security_invoker = true) AS
SELECT
  user_id,
  tenant_id,
  date_trunc('month', datum)::date AS honap_kezdete,
  kategoria,
  SUM(ora)::numeric(8,2) AS ora_osszesen,
  SUM(ejszakai_ora)::numeric(8,2) AS ejszakai_ora,
  SUM(vasarnapi_ora)::numeric(8,2) AS vasarnapi_ora,
  SUM(unnepnapi_ora)::numeric(8,2) AS unnepnapi_ora
FROM public.work_time_ledger
GROUP BY user_id, tenant_id, date_trunc('month', datum), kategoria;

GRANT SELECT ON public.v_napi_pihenes, public.v_heti_munkaido, public.v_havi_ledger TO authenticated;
