
-- ============================================================================
-- 1) Audit log: reason oszlop + post-write update saját bejegyzésre
-- ============================================================================
ALTER TABLE public.admin_audit_log ADD COLUMN IF NOT EXISTS reason TEXT;

CREATE POLICY "audit_update_own_recent" ON public.admin_audit_log
  FOR UPDATE TO authenticated
  USING (user_id = auth.uid() AND created_at > now() - interval '10 minutes')
  WITH CHECK (user_id = auth.uid());

-- ============================================================================
-- 2) role_permissions seed self-heal függvény
-- ============================================================================
CREATE OR REPLACE FUNCTION public.ensure_role_permissions_seed()
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_inserted INTEGER := 0;
  v_count_before INTEGER;
  v_count_after INTEGER;
BEGIN
  SELECT COUNT(*) INTO v_count_before FROM public.role_permissions;

  INSERT INTO public.role_permissions(role_kulcs, perm) VALUES
    ('tenant_admin','manage_tenant'),
    ('tenant_admin','manage_org'),('igazgato','manage_org'),('intezetvezeto','manage_org'),('telephelyvezeto','manage_org'),
    ('tenant_admin','manage_roles'),('igazgato','manage_roles'),('intezetvezeto','manage_roles'),
    ('tenant_admin','manage_schedule'),('igazgato','manage_schedule'),('intezetvezeto','manage_schedule'),('telephelyvezeto','manage_schedule'),('ugyeletvezeto','manage_schedule'),('beoszto','manage_schedule'),
    ('tenant_admin','manage_training'),('igazgato','manage_training'),('intezetvezeto','manage_training'),('foorvos','manage_training'),
    ('tenant_admin','manage_patients'),('igazgato','manage_patients'),('intezetvezeto','manage_patients'),('telephelyvezeto','manage_patients'),('foorvos','manage_patients'),('szakorvos','manage_patients'),('rezidens','manage_patients'),('szakgyakornok','manage_patients'),('vezetorezidens','manage_patients'),
    ('tenant_admin','view_audit'),('igazgato','view_audit'),('intezetvezeto','view_audit'),
    ('tenant_admin','view_team'),('igazgato','view_team'),('intezetvezeto','view_team'),('telephelyvezeto','view_team'),('foorvos','view_team'),('ugyeletvezeto','view_team'),('beoszto','view_team')
  ON CONFLICT DO NOTHING;

  SELECT COUNT(*) INTO v_count_after FROM public.role_permissions;
  v_inserted := v_count_after - v_count_before;
  RETURN v_inserted;
END;
$$;

GRANT EXECUTE ON FUNCTION public.ensure_role_permissions_seed() TO authenticated;

-- Azonnali pótlás (idempotens)
SELECT public.ensure_role_permissions_seed();

-- ============================================================================
-- 3) Updated_at trigger újrahasznosításhoz
-- ============================================================================
-- touch_updated_at már létezik

-- ============================================================================
-- 4) SKILL KATALÓGUS
-- ============================================================================
CREATE TABLE public.skills (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  specialty_id UUID REFERENCES public.specialties(id) ON DELETE SET NULL,
  kulcs TEXT NOT NULL,
  nev TEXT NOT NULL,
  leiras TEXT,
  kategoria TEXT,
  aktiv BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, kulcs)
);
CREATE INDEX idx_skills_tenant ON public.skills(tenant_id);
CREATE INDEX idx_skills_specialty ON public.skills(specialty_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.skills TO authenticated;
GRANT ALL ON public.skills TO service_role;
ALTER TABLE public.skills ENABLE ROW LEVEL SECURITY;

CREATE POLICY "skills_select_tenant" ON public.skills FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY "skills_write_training" ON public.skills FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_training'))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_training'));

CREATE TRIGGER touch_skills BEFORE UPDATE ON public.skills FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER audit_skills AFTER INSERT OR UPDATE OR DELETE ON public.skills FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ============================================================================
-- 5) BEAVATKOZÁS KATALÓGUS
-- ============================================================================
CREATE TABLE public.beavatkozasok (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  specialty_id UUID REFERENCES public.specialties(id) ON DELETE SET NULL,
  kod TEXT,
  nev TEXT NOT NULL,
  leiras TEXT,
  aktiv BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, kod)
);
CREATE INDEX idx_beavatkozasok_tenant ON public.beavatkozasok(tenant_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.beavatkozasok TO authenticated;
GRANT ALL ON public.beavatkozasok TO service_role;
ALTER TABLE public.beavatkozasok ENABLE ROW LEVEL SECURITY;

CREATE POLICY "bea_select_tenant" ON public.beavatkozasok FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY "bea_write_training" ON public.beavatkozasok FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_training'))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_training'));

CREATE TRIGGER touch_bea BEFORE UPDATE ON public.beavatkozasok FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER audit_bea AFTER INSERT OR UPDATE OR DELETE ON public.beavatkozasok FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ============================================================================
-- 6) BEAVATKOZÁS → SKILL
-- ============================================================================
CREATE TABLE public.beavatkozas_skill (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  beavatkozas_id UUID NOT NULL REFERENCES public.beavatkozasok(id) ON DELETE CASCADE,
  skill_id UUID NOT NULL REFERENCES public.skills(id) ON DELETE CASCADE,
  min_szint SMALLINT NOT NULL DEFAULT 1 CHECK (min_szint BETWEEN 1 AND 5),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (beavatkozas_id, skill_id)
);
CREATE INDEX idx_bs_skill ON public.beavatkozas_skill(skill_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.beavatkozas_skill TO authenticated;
GRANT ALL ON public.beavatkozas_skill TO service_role;
ALTER TABLE public.beavatkozas_skill ENABLE ROW LEVEL SECURITY;

CREATE POLICY "bs_select_via_parent" ON public.beavatkozas_skill FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.beavatkozasok b WHERE b.id = beavatkozas_id AND b.tenant_id = public.current_tenant_id()));
CREATE POLICY "bs_write_training" ON public.beavatkozas_skill FOR ALL TO authenticated
  USING (
    public.has_permission(auth.uid(), 'manage_training')
    AND EXISTS (SELECT 1 FROM public.beavatkozasok b WHERE b.id = beavatkozas_id AND b.tenant_id = public.current_tenant_id())
  )
  WITH CHECK (
    public.has_permission(auth.uid(), 'manage_training')
    AND EXISTS (SELECT 1 FROM public.beavatkozasok b WHERE b.id = beavatkozas_id AND b.tenant_id = public.current_tenant_id())
  );

-- ============================================================================
-- 7) KÉPZÉSI PROGRAMOK
-- ============================================================================
CREATE TABLE public.training_programs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  nev TEXT NOT NULL,
  leiras TEXT,
  honap_hossz SMALLINT,
  aktiv BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_tp_tenant ON public.training_programs(tenant_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.training_programs TO authenticated;
GRANT ALL ON public.training_programs TO service_role;
ALTER TABLE public.training_programs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "tp_select_tenant" ON public.training_programs FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY "tp_write_training" ON public.training_programs FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_training'))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_training'));

CREATE TRIGGER touch_tp BEFORE UPDATE ON public.training_programs FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER audit_tp AFTER INSERT OR UPDATE OR DELETE ON public.training_programs FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ============================================================================
-- 8) PROGRAM → SKILL
-- ============================================================================
CREATE TABLE public.training_program_skills (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  program_id UUID NOT NULL REFERENCES public.training_programs(id) ON DELETE CASCADE,
  skill_id UUID NOT NULL REFERENCES public.skills(id) ON DELETE CASCADE,
  cel_szint SMALLINT NOT NULL DEFAULT 3 CHECK (cel_szint BETWEEN 1 AND 5),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (program_id, skill_id)
);
CREATE INDEX idx_tps_skill ON public.training_program_skills(skill_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.training_program_skills TO authenticated;
GRANT ALL ON public.training_program_skills TO service_role;
ALTER TABLE public.training_program_skills ENABLE ROW LEVEL SECURITY;

CREATE POLICY "tps_select_via_parent" ON public.training_program_skills FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.training_programs p WHERE p.id = program_id AND p.tenant_id = public.current_tenant_id()));
CREATE POLICY "tps_write_training" ON public.training_program_skills FOR ALL TO authenticated
  USING (
    public.has_permission(auth.uid(), 'manage_training')
    AND EXISTS (SELECT 1 FROM public.training_programs p WHERE p.id = program_id AND p.tenant_id = public.current_tenant_id())
  )
  WITH CHECK (
    public.has_permission(auth.uid(), 'manage_training')
    AND EXISTS (SELECT 1 FROM public.training_programs p WHERE p.id = program_id AND p.tenant_id = public.current_tenant_id())
  );

-- ============================================================================
-- 9) PROFILE_SKILLS
-- ============================================================================
CREATE TABLE public.profile_skills (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  skill_id UUID NOT NULL REFERENCES public.skills(id) ON DELETE CASCADE,
  szint SMALLINT NOT NULL DEFAULT 1 CHECK (szint BETWEEN 1 AND 5),
  igazolva_at DATE,
  lejarat DATE,
  megjegyzes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, skill_id)
);
CREATE INDEX idx_ps_user ON public.profile_skills(user_id);
CREATE INDEX idx_ps_skill ON public.profile_skills(skill_id);
CREATE INDEX idx_ps_tenant ON public.profile_skills(tenant_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_skills TO authenticated;
GRANT ALL ON public.profile_skills TO service_role;
ALTER TABLE public.profile_skills ENABLE ROW LEVEL SECURITY;

CREATE POLICY "ps_select_own_or_team" ON public.profile_skills FOR SELECT TO authenticated
  USING (
    user_id = auth.uid()
    OR (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'view_team'))
  );
CREATE POLICY "ps_write_own_or_training" ON public.profile_skills FOR ALL TO authenticated
  USING (
    (user_id = auth.uid() AND tenant_id = public.current_tenant_id())
    OR (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_training'))
  )
  WITH CHECK (
    (user_id = auth.uid() AND tenant_id = public.current_tenant_id())
    OR (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_training'))
  );

CREATE TRIGGER touch_ps BEFORE UPDATE ON public.profile_skills FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER audit_ps AFTER INSERT OR UPDATE OR DELETE ON public.profile_skills FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ============================================================================
-- 10) PROFILE_CERTIFICATIONS
-- ============================================================================
CREATE TABLE public.profile_certifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  nev TEXT NOT NULL,
  tipus TEXT NOT NULL CHECK (tipus IN ('oklevel','szakvizsga','licenc','tovabbkepzes','egyeb')),
  kibocsato TEXT,
  szam TEXT,
  kibocsatva DATE,
  lejarat DATE,
  dokumentum_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_pc_user ON public.profile_certifications(user_id);
CREATE INDEX idx_pc_tenant ON public.profile_certifications(tenant_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_certifications TO authenticated;
GRANT ALL ON public.profile_certifications TO service_role;
ALTER TABLE public.profile_certifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "pc_select_own_or_team" ON public.profile_certifications FOR SELECT TO authenticated
  USING (
    user_id = auth.uid()
    OR (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'view_team'))
  );
CREATE POLICY "pc_write_own_or_training" ON public.profile_certifications FOR ALL TO authenticated
  USING (
    (user_id = auth.uid() AND tenant_id = public.current_tenant_id())
    OR (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_training'))
  )
  WITH CHECK (
    (user_id = auth.uid() AND tenant_id = public.current_tenant_id())
    OR (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_training'))
  );

CREATE TRIGGER touch_pc BEFORE UPDATE ON public.profile_certifications FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER audit_pc AFTER INSERT OR UPDATE OR DELETE ON public.profile_certifications FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ============================================================================
-- 11) PROFILE_TRAININGS (folyamatban lévő)
-- ============================================================================
CREATE TABLE public.profile_trainings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  program_id UUID REFERENCES public.training_programs(id) ON DELETE SET NULL,
  nev TEXT NOT NULL,
  kezdes DATE,
  varhato_veg DATE,
  elorehaladas_pct SMALLINT NOT NULL DEFAULT 0 CHECK (elorehaladas_pct BETWEEN 0 AND 100),
  statusz TEXT NOT NULL DEFAULT 'folyamatban' CHECK (statusz IN ('folyamatban','befejezett','megszakitott','tervezett')),
  megjegyzes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_pt_user ON public.profile_trainings(user_id);
CREATE INDEX idx_pt_tenant ON public.profile_trainings(tenant_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_trainings TO authenticated;
GRANT ALL ON public.profile_trainings TO service_role;
ALTER TABLE public.profile_trainings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "pt_select_own_or_team" ON public.profile_trainings FOR SELECT TO authenticated
  USING (
    user_id = auth.uid()
    OR (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'view_team'))
  );
CREATE POLICY "pt_write_own_or_training" ON public.profile_trainings FOR ALL TO authenticated
  USING (
    (user_id = auth.uid() AND tenant_id = public.current_tenant_id())
    OR (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_training'))
  )
  WITH CHECK (
    (user_id = auth.uid() AND tenant_id = public.current_tenant_id())
    OR (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_training'))
  );

CREATE TRIGGER touch_pt BEFORE UPDATE ON public.profile_trainings FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER audit_pt AFTER INSERT OR UPDATE OR DELETE ON public.profile_trainings FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ============================================================================
-- 12) PROFILE_BEAVATKOZASOK (gyakorlatszám)
-- ============================================================================
CREATE TABLE public.profile_beavatkozasok (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  beavatkozas_id UUID NOT NULL REFERENCES public.beavatkozasok(id) ON DELETE CASCADE,
  alkalom SMALLINT NOT NULL DEFAULT 1,
  datum DATE,
  megjegyzes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_pb_user ON public.profile_beavatkozasok(user_id);
CREATE INDEX idx_pb_tenant ON public.profile_beavatkozasok(tenant_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_beavatkozasok TO authenticated;
GRANT ALL ON public.profile_beavatkozasok TO service_role;
ALTER TABLE public.profile_beavatkozasok ENABLE ROW LEVEL SECURITY;

CREATE POLICY "pb_select_own_or_team" ON public.profile_beavatkozasok FOR SELECT TO authenticated
  USING (
    user_id = auth.uid()
    OR (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'view_team'))
  );
CREATE POLICY "pb_write_own_or_training" ON public.profile_beavatkozasok FOR ALL TO authenticated
  USING (
    (user_id = auth.uid() AND tenant_id = public.current_tenant_id())
    OR (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_training'))
  )
  WITH CHECK (
    (user_id = auth.uid() AND tenant_id = public.current_tenant_id())
    OR (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_training'))
  );

CREATE TRIGGER touch_pb BEFORE UPDATE ON public.profile_beavatkozasok FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER audit_pb AFTER INSERT OR UPDATE OR DELETE ON public.profile_beavatkozasok FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ============================================================================
-- 13) profile_capabilities VIEW (érvényes skill-ek)
-- ============================================================================
CREATE OR REPLACE VIEW public.profile_capabilities
WITH (security_invoker=on) AS
SELECT
  ps.user_id,
  ps.tenant_id,
  ps.skill_id,
  s.kulcs AS skill_kulcs,
  s.nev AS skill_nev,
  s.specialty_id,
  ps.szint,
  ps.igazolva_at,
  ps.lejarat,
  CASE
    WHEN ps.lejarat IS NULL THEN 'ervenyes'
    WHEN ps.lejarat < CURRENT_DATE THEN 'lejart'
    WHEN ps.lejarat < CURRENT_DATE + INTERVAL '30 days' THEN 'hamarosan'
    ELSE 'ervenyes'
  END AS statusz
FROM public.profile_skills ps
JOIN public.skills s ON s.id = ps.skill_id;

GRANT SELECT ON public.profile_capabilities TO authenticated;
