-- Tenant cross-check szigorítás 5 táblán
-- 1) profile_beavatkozasok / certifications / skills / trainings:
--    A "saját" ág is kapjon tenant_id = current_tenant_id() szűrést,
--    hogy multi-tenant userek ne lássák/írják cross-tenant a saját rekordjaikat.
-- 2) app_settings_audit: SELECT-et szigorítjuk view_audit permre,
--    INSERT-nél marad az admin ellenőrzés.

-- profile_beavatkozasok
DROP POLICY IF EXISTS pb_select_own_or_team ON public.profile_beavatkozasok;
DROP POLICY IF EXISTS pb_write_own_or_training ON public.profile_beavatkozasok;
CREATE POLICY pb_select_own_or_team ON public.profile_beavatkozasok
  FOR SELECT TO authenticated
  USING (
    tenant_id = current_tenant_id()
    AND (user_id = auth.uid() OR has_permission(auth.uid(), 'view_team'))
  );
CREATE POLICY pb_write_own_or_training ON public.profile_beavatkozasok
  FOR ALL TO authenticated
  USING (
    tenant_id = current_tenant_id()
    AND (user_id = auth.uid() OR has_permission(auth.uid(), 'manage_training'))
  )
  WITH CHECK (
    tenant_id = current_tenant_id()
    AND (user_id = auth.uid() OR has_permission(auth.uid(), 'manage_training'))
  );

-- profile_certifications
DROP POLICY IF EXISTS pc_select_own_or_team ON public.profile_certifications;
DROP POLICY IF EXISTS pc_write_own_or_training ON public.profile_certifications;
CREATE POLICY pc_select_own_or_team ON public.profile_certifications
  FOR SELECT TO authenticated
  USING (
    tenant_id = current_tenant_id()
    AND (user_id = auth.uid() OR has_permission(auth.uid(), 'view_team'))
  );
CREATE POLICY pc_write_own_or_training ON public.profile_certifications
  FOR ALL TO authenticated
  USING (
    tenant_id = current_tenant_id()
    AND (user_id = auth.uid() OR has_permission(auth.uid(), 'manage_training'))
  )
  WITH CHECK (
    tenant_id = current_tenant_id()
    AND (user_id = auth.uid() OR has_permission(auth.uid(), 'manage_training'))
  );

-- profile_skills
DROP POLICY IF EXISTS ps_select_own_or_team ON public.profile_skills;
DROP POLICY IF EXISTS ps_write_own_or_training ON public.profile_skills;
CREATE POLICY ps_select_own_or_team ON public.profile_skills
  FOR SELECT TO authenticated
  USING (
    tenant_id = current_tenant_id()
    AND (user_id = auth.uid() OR has_permission(auth.uid(), 'view_team'))
  );
CREATE POLICY ps_write_own_or_training ON public.profile_skills
  FOR ALL TO authenticated
  USING (
    tenant_id = current_tenant_id()
    AND (user_id = auth.uid() OR has_permission(auth.uid(), 'manage_training'))
  )
  WITH CHECK (
    tenant_id = current_tenant_id()
    AND (user_id = auth.uid() OR has_permission(auth.uid(), 'manage_training'))
  );

-- profile_trainings
DROP POLICY IF EXISTS pt_select_own_or_team ON public.profile_trainings;
DROP POLICY IF EXISTS pt_write_own_or_training ON public.profile_trainings;
CREATE POLICY pt_select_own_or_team ON public.profile_trainings
  FOR SELECT TO authenticated
  USING (
    tenant_id = current_tenant_id()
    AND (user_id = auth.uid() OR has_permission(auth.uid(), 'view_team'))
  );
CREATE POLICY pt_write_own_or_training ON public.profile_trainings
  FOR ALL TO authenticated
  USING (
    tenant_id = current_tenant_id()
    AND (user_id = auth.uid() OR has_permission(auth.uid(), 'manage_training'))
  )
  WITH CHECK (
    tenant_id = current_tenant_id()
    AND (user_id = auth.uid() OR has_permission(auth.uid(), 'manage_training'))
  );

-- app_settings_audit: SELECT-et szigorítjuk view_audit permre (admin szerepkör nélkül is engedélyezhető),
-- így nem ad cross-tenant globális rálátást indokolatlanul. Az INSERT marad admin-only.
DROP POLICY IF EXISTS "Admins read audit" ON public.app_settings_audit;
CREATE POLICY app_settings_audit_select ON public.app_settings_audit
  FOR SELECT TO authenticated
  USING (has_permission(auth.uid(), 'view_audit'));
