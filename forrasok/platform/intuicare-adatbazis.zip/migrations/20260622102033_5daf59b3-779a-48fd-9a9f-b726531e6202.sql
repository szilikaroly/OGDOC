-- Tighten RLS policy roles: change public -> authenticated for sensitive tables.

-- 1) clinical_calculator_results DELETE/UPDATE
DROP POLICY IF EXISTS "creator deletes calc results" ON public.clinical_calculator_results;
CREATE POLICY "creator deletes calc results"
ON public.clinical_calculator_results FOR DELETE TO authenticated
USING (
  ((auth.uid() = created_by) OR has_role(auth.uid(), 'admin'::text))
  AND ((patient_id IS NULL) OR can_access_patient(patient_id))
);

DROP POLICY IF EXISTS "creator updates calc results" ON public.clinical_calculator_results;
CREATE POLICY "creator updates calc results"
ON public.clinical_calculator_results FOR UPDATE TO authenticated
USING (
  (auth.uid() = created_by)
  AND ((patient_id IS NULL) OR can_access_patient(patient_id))
)
WITH CHECK (
  (auth.uid() = created_by)
  AND ((patient_id IS NULL) OR can_access_patient(patient_id))
);

-- 2) clinical_therapy_orders DELETE
DROP POLICY IF EXISTS "creator deletes therapy" ON public.clinical_therapy_orders;
CREATE POLICY "creator deletes therapy"
ON public.clinical_therapy_orders FOR DELETE TO authenticated
USING (
  ((auth.uid() = created_by) OR has_role(auth.uid(), 'admin'::text))
  AND can_access_patient(patient_id)
);

-- 3) clinical_weekly_vc DELETE/UPDATE
DROP POLICY IF EXISTS "Author delete weekly vc" ON public.clinical_weekly_vc;
CREATE POLICY "Author delete weekly vc"
ON public.clinical_weekly_vc FOR DELETE TO authenticated
USING ((created_by = auth.uid()) AND can_access_patient(patient_id));

DROP POLICY IF EXISTS "Author update weekly vc" ON public.clinical_weekly_vc;
CREATE POLICY "Author update weekly vc"
ON public.clinical_weekly_vc FOR UPDATE TO authenticated
USING ((created_by = auth.uid()) AND can_access_patient(patient_id))
WITH CHECK ((created_by = auth.uid()) AND can_access_patient(patient_id));

-- 4) questionnaire_assignments SELECT (qa_select_auth)
DROP POLICY IF EXISTS qa_select_auth ON public.questionnaire_assignments;
CREATE POLICY qa_select_auth
ON public.questionnaire_assignments FOR SELECT TO authenticated
USING (
  tenant_id = current_tenant_id()
  AND (
    has_permission(auth.uid(), 'view_patient_data'::text)
    OR has_permission(auth.uid(), 'manage_patients'::text)
    OR assigned_by = auth.uid()
  )
);

-- 5) incompatibilities INSERT
DROP POLICY IF EXISTS inc_insert ON public.incompatibilities;
CREATE POLICY inc_insert
ON public.incompatibilities FOR INSERT TO authenticated
WITH CHECK (
  tenant_id = current_tenant_id()
  AND user_id = auth.uid()
);

-- 6) profile_preferences SELECT + ALL
DROP POLICY IF EXISTS profile_preferences_select ON public.profile_preferences;
CREATE POLICY profile_preferences_select
ON public.profile_preferences FOR SELECT TO authenticated
USING (
  tenant_id = current_tenant_id()
  AND (
    user_id = auth.uid()
    OR has_permission(auth.uid(), 'manage_schedule'::text)
    OR has_permission(auth.uid(), 'manage_tenant'::text)
  )
);

DROP POLICY IF EXISTS profile_preferences_write ON public.profile_preferences;
CREATE POLICY profile_preferences_write
ON public.profile_preferences FOR ALL TO authenticated
USING (
  tenant_id = current_tenant_id()
  AND (
    user_id = auth.uid()
    OR has_permission(auth.uid(), 'manage_tenant'::text)
  )
)
WITH CHECK (
  tenant_id = current_tenant_id()
  AND (
    user_id = auth.uid()
    OR has_permission(auth.uid(), 'manage_tenant'::text)
  )
);

-- 7) profile_peer_links (all four policies) -> authenticated
DROP POLICY IF EXISTS profile_peer_links_select ON public.profile_peer_links;
CREATE POLICY profile_peer_links_select
ON public.profile_peer_links FOR SELECT TO authenticated
USING ((from_user_id = auth.uid()) OR (to_user_id = auth.uid()) OR has_permission(auth.uid(), 'manage_schedule'::text) OR has_permission(auth.uid(), 'manage_tenant'::text));

DROP POLICY IF EXISTS profile_peer_links_insert ON public.profile_peer_links;
CREATE POLICY profile_peer_links_insert
ON public.profile_peer_links FOR INSERT TO authenticated
WITH CHECK ((from_user_id = auth.uid()) OR has_permission(auth.uid(), 'manage_schedule'::text) OR has_permission(auth.uid(), 'manage_tenant'::text));

DROP POLICY IF EXISTS profile_peer_links_update ON public.profile_peer_links;
CREATE POLICY profile_peer_links_update
ON public.profile_peer_links FOR UPDATE TO authenticated
USING ((from_user_id = auth.uid()) OR has_permission(auth.uid(), 'manage_schedule'::text) OR has_permission(auth.uid(), 'manage_tenant'::text))
WITH CHECK ((from_user_id = auth.uid()) OR has_permission(auth.uid(), 'manage_schedule'::text) OR has_permission(auth.uid(), 'manage_tenant'::text));

DROP POLICY IF EXISTS profile_peer_links_delete ON public.profile_peer_links;
CREATE POLICY profile_peer_links_delete
ON public.profile_peer_links FOR DELETE TO authenticated
USING ((from_user_id = auth.uid()) OR has_permission(auth.uid(), 'manage_tenant'::text));

-- 8) push_subscriptions
DROP POLICY IF EXISTS "Users manage own push subscriptions" ON public.push_subscriptions;
CREATE POLICY "Users manage own push subscriptions"
ON public.push_subscriptions FOR ALL TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- 9) shift_notifications_sent
DROP POLICY IF EXISTS "Users see own shift notifications" ON public.shift_notifications_sent;
CREATE POLICY "Users see own shift notifications"
ON public.shift_notifications_sent FOR SELECT TO authenticated
USING (auth.uid() = user_id);

-- 10) error_log INSERT - restrict to authenticated only
DROP POLICY IF EXISTS "Anyone can insert error logs" ON public.error_log;
CREATE POLICY "Authenticated users can insert error logs"
ON public.error_log FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id OR user_id IS NULL);