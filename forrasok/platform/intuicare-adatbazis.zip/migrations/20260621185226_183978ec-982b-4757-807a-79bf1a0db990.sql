
-- ============================================================
-- Csapatmenedzsment: staff_import_runs + biztons\u00e1gi RLS jav\u00edt\u00e1sok
-- ============================================================

-- 1) staff_import_runs: HR Excel import audit
CREATE TABLE public.staff_import_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  imported_by uuid NOT NULL REFERENCES auth.users(id) ON DELETE SET NULL,
  file_name text,
  file_hash text,
  total_rows integer NOT NULL DEFAULT 0,
  inserted_rows integer NOT NULL DEFAULT 0,
  updated_rows integer NOT NULL DEFAULT 0,
  skipped_rows integer NOT NULL DEFAULT 0,
  error_rows integer NOT NULL DEFAULT 0,
  summary jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);
CREATE INDEX idx_staff_import_runs_tenant ON public.staff_import_runs(tenant_id, created_at DESC);

GRANT SELECT, INSERT ON public.staff_import_runs TO authenticated;
GRANT ALL ON public.staff_import_runs TO service_role;
ALTER TABLE public.staff_import_runs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "staff_import_runs_select_tenant_admin"
  ON public.staff_import_runs
  FOR SELECT TO authenticated
  USING (tenant_id = current_tenant_id() AND public.has_permission(auth.uid(), 'manage_tenant'));

CREATE POLICY "staff_import_runs_insert_self"
  ON public.staff_import_runs
  FOR INSERT TO authenticated
  WITH CHECK (
    tenant_id = current_tenant_id()
    AND imported_by = auth.uid()
    AND public.has_permission(auth.uid(), 'manage_tenant')
  );

-- 2) RPC: \u00e9ves szabads\u00e1g \u00fajrasz\u00e1mol\u00e1s magyar Mt. szerint
CREATE OR REPLACE FUNCTION public.compute_mt_leave_days(
  _birth date,
  _children_births date[],
  _children_disabled boolean[],
  _year integer
) RETURNS integer
LANGUAGE plpgsql IMMUTABLE
SET search_path = public
AS $$
DECLARE
  stichtag date := make_date(_year, 12, 31);
  age integer;
  base integer := 20;
  age_bonus integer := 0;
  child_bonus integer := 0;
  eligible_children integer := 0;
  disabled_bonus integer := 0;
  i integer;
  c_birth date;
  c_disabled boolean;
  c_age integer;
BEGIN
  IF _birth IS NULL THEN
    RETURN base;
  END IF;
  age := EXTRACT(YEAR FROM age(stichtag, _birth));
  IF age >= 45 THEN age_bonus := 10;
  ELSIF age >= 43 THEN age_bonus := 9;
  ELSIF age >= 41 THEN age_bonus := 8;
  ELSIF age >= 39 THEN age_bonus := 7;
  ELSIF age >= 37 THEN age_bonus := 6;
  ELSIF age >= 35 THEN age_bonus := 5;
  ELSIF age >= 33 THEN age_bonus := 4;
  ELSIF age >= 31 THEN age_bonus := 3;
  ELSIF age >= 28 THEN age_bonus := 2;
  ELSIF age >= 25 THEN age_bonus := 1;
  END IF;

  IF _children_births IS NOT NULL THEN
    FOR i IN 1..array_length(_children_births, 1) LOOP
      c_birth := _children_births[i];
      IF c_birth IS NULL THEN CONTINUE; END IF;
      c_age := EXTRACT(YEAR FROM age(stichtag, c_birth));
      IF c_age < 16 THEN
        eligible_children := eligible_children + 1;
        c_disabled := COALESCE(_children_disabled[i], false);
        IF c_disabled THEN
          disabled_bonus := disabled_bonus + 2;
        END IF;
      END IF;
    END LOOP;
  END IF;

  IF eligible_children >= 3 THEN child_bonus := 7;
  ELSIF eligible_children = 2 THEN child_bonus := 4;
  ELSIF eligible_children = 1 THEN child_bonus := 2;
  END IF;

  RETURN base + age_bonus + child_bonus + disabled_bonus;
END;
$$;

GRANT EXECUTE ON FUNCTION public.compute_mt_leave_days(date, date[], boolean[], integer) TO authenticated, service_role;

-- 3) Biztons\u00e1gi jav\u00edt\u00e1sok: clinical_weekly_vc INSERT
DROP POLICY IF EXISTS "Authenticated insert weekly vc" ON public.clinical_weekly_vc;
CREATE POLICY "Authenticated insert weekly vc"
  ON public.clinical_weekly_vc
  FOR INSERT TO authenticated
  WITH CHECK (created_by = auth.uid() AND can_access_patient(patient_id));

-- 4) obstetric_partograms: tenant-scope a can_access_patient(patient_id)-vel
DROP POLICY IF EXISTS partogram_select ON public.obstetric_partograms;
DROP POLICY IF EXISTS partogram_insert ON public.obstetric_partograms;
DROP POLICY IF EXISTS partogram_update ON public.obstetric_partograms;
DROP POLICY IF EXISTS partogram_delete ON public.obstetric_partograms;

CREATE POLICY partogram_select ON public.obstetric_partograms
  FOR SELECT TO authenticated
  USING (can_access_patient(patient_id));
CREATE POLICY partogram_insert ON public.obstetric_partograms
  FOR INSERT TO authenticated
  WITH CHECK (created_by = auth.uid() AND can_access_patient(patient_id));
CREATE POLICY partogram_update ON public.obstetric_partograms
  FOR UPDATE TO authenticated
  USING (can_access_patient(patient_id))
  WITH CHECK (can_access_patient(patient_id));
CREATE POLICY partogram_delete ON public.obstetric_partograms
  FOR DELETE TO authenticated
  USING (can_access_patient(patient_id) AND (created_by = auth.uid() OR has_permission(auth.uid(),'manage_patients')));

-- 5) obstetric_partogram_entries: a sz\u00fcl\u0151 partogram p\u00e1ciens\u00e9hez kapcsolt tenant-check
DROP POLICY IF EXISTS partogram_entry_select ON public.obstetric_partogram_entries;
DROP POLICY IF EXISTS partogram_entry_insert ON public.obstetric_partogram_entries;
DROP POLICY IF EXISTS partogram_entry_update ON public.obstetric_partogram_entries;
DROP POLICY IF EXISTS partogram_entry_delete ON public.obstetric_partogram_entries;

CREATE POLICY partogram_entry_select ON public.obstetric_partogram_entries
  FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.obstetric_partograms p
    WHERE p.id = obstetric_partogram_entries.partogram_id
      AND can_access_patient(p.patient_id)
  ));
CREATE POLICY partogram_entry_insert ON public.obstetric_partogram_entries
  FOR INSERT TO authenticated
  WITH CHECK (
    created_by = auth.uid()
    AND EXISTS (
      SELECT 1 FROM public.obstetric_partograms p
      WHERE p.id = obstetric_partogram_entries.partogram_id
        AND can_access_patient(p.patient_id)
    )
  );
CREATE POLICY partogram_entry_update ON public.obstetric_partogram_entries
  FOR UPDATE TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.obstetric_partograms p
    WHERE p.id = obstetric_partogram_entries.partogram_id
      AND can_access_patient(p.patient_id)
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM public.obstetric_partograms p
    WHERE p.id = obstetric_partogram_entries.partogram_id
      AND can_access_patient(p.patient_id)
  ));
CREATE POLICY partogram_entry_delete ON public.obstetric_partogram_entries
  FOR DELETE TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.obstetric_partograms p
    WHERE p.id = obstetric_partogram_entries.partogram_id
      AND can_access_patient(p.patient_id)
      AND (obstetric_partogram_entries.created_by = auth.uid() OR has_permission(auth.uid(),'manage_patients'))
  ));

-- 6) patient_referral_requests: has_role -> has_permission(manage_patients) + tenant_id g\u00e1t
DROP POLICY IF EXISTS "Staff manages referral requests in own tenant" ON public.patient_referral_requests;
CREATE POLICY "Staff manages referral requests in own tenant"
  ON public.patient_referral_requests
  FOR ALL TO authenticated
  USING (tenant_id = current_tenant_id() AND has_permission(auth.uid(), 'manage_patients'))
  WITH CHECK (tenant_id = current_tenant_id() AND has_permission(auth.uid(), 'manage_patients'));
