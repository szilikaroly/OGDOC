
-- Konverziós eseménydefiníciók a kísérleten
ALTER TABLE public.cms_experiments
  ADD COLUMN IF NOT EXISTS conversion_events jsonb NOT NULL DEFAULT '[]'::jsonb;

-- Esemény név + paraméter tárolás
ALTER TABLE public.cms_experiment_events
  ADD COLUMN IF NOT EXISTS event_name text,
  ADD COLUMN IF NOT EXISTS params jsonb;

CREATE INDEX IF NOT EXISTS cms_experiment_events_name_idx
  ON public.cms_experiment_events (experiment_id, event_name);

-- Bővített RPC: event_name + params
CREATE OR REPLACE FUNCTION public.cms_exp_event_record(
  _experiment_id uuid,
  _variant_id uuid,
  _event_type text,
  _session_id text,
  _path text DEFAULT NULL,
  _referrer text DEFAULT NULL,
  _user_agent text DEFAULT NULL,
  _event_name text DEFAULT NULL,
  _params jsonb DEFAULT NULL
)
RETURNS bigint
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  _id bigint;
  _recent_count int;
BEGIN
  IF _event_type NOT IN ('view','goal') THEN
    RAISE EXCEPTION 'invalid event_type';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM public.cms_experiments e WHERE e.id = _experiment_id AND e.status = 'running') THEN
    RETURN NULL;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM public.cms_experiment_variants v WHERE v.id = _variant_id AND v.experiment_id = _experiment_id) THEN
    RAISE EXCEPTION 'variant mismatch';
  END IF;

  IF _session_id IS NOT NULL THEN
    SELECT COUNT(*) INTO _recent_count
    FROM public.cms_experiment_events
    WHERE session_id = _session_id
      AND experiment_id = _experiment_id
      AND created_at > now() - interval '1 minute';
    IF _recent_count > 60 THEN
      RETURN NULL;
    END IF;
  END IF;

  IF _event_type = 'view' AND _session_id IS NOT NULL THEN
    IF EXISTS (
      SELECT 1 FROM public.cms_experiment_events
      WHERE session_id = _session_id
        AND experiment_id = _experiment_id
        AND variant_id = _variant_id
        AND event_type = 'view'
        AND created_at::date = CURRENT_DATE
    ) THEN
      RETURN NULL;
    END IF;
  END IF;

  INSERT INTO public.cms_experiment_events
    (experiment_id, variant_id, event_type, session_id, path, referrer, user_agent, event_name, params)
  VALUES
    (_experiment_id, _variant_id, _event_type, _session_id,
     LEFT(_path, 500), LEFT(_referrer, 500), LEFT(_user_agent, 500),
     NULLIF(LEFT(_event_name, 80), ''), _params)
  RETURNING id INTO _id;

  RETURN _id;
END;
$$;
