
DO $$
DECLARE
  v_tenant record;
  v_q_mother uuid; v_q_child uuid; v_q_surgery uuid; v_q_sat uuid;
  v_p_mother uuid; v_p_child uuid; v_p_surgery uuid; v_p_sat uuid;
  v_items_mother jsonb := '[{"id":1,"code":"epds_total","text":"Hangulati skála (EPDS rövid 0-30)","type":"number"},{"id":2,"code":"fever_gt_38","text":"Van-e 38°C feletti láza?","type":"yesno"},{"id":3,"code":"heavy_bleeding","text":"Erős vérzés / véralvadékok?","type":"yesno"},{"id":4,"code":"pain_nrs","text":"Fájdalom 0-10","type":"number"},{"id":5,"code":"breastfeeding_ok","text":"Szoptatás megfelelő?","type":"yesno"}]'::jsonb;
  v_items_child jsonb := '[{"id":1,"code":"child_fever_gt_38","text":"38°C feletti láz?","type":"yesno"},{"id":2,"code":"child_milestone_miss","text":"Hány fejlődési mérföldkő hiányzik (0-5)?","type":"number"},{"id":3,"code":"feeding_difficulty","text":"Etetési nehézség 0-3","type":"number"},{"id":4,"code":"weight_concern","text":"Súlygyarapodás aggasztó?","type":"yesno"}]'::jsonb;
  v_items_surgery jsonb := '[{"id":1,"code":"fever_gt_38","text":"38°C feletti láz?","type":"yesno"},{"id":2,"code":"wound_redness","text":"Sebkörnyéki pír 0-3","type":"number"},{"id":3,"code":"pain_nrs","text":"Fájdalom 0-10","type":"number"},{"id":4,"code":"discharge","text":"Sebváladék?","type":"yesno"},{"id":5,"code":"mobility","text":"Mobilitás 0-5","type":"number"}]'::jsonb;
  v_items_sat jsonb := '[{"id":1,"code":"nps","text":"Mennyire ajánlana minket? (0-10)","type":"number"},{"id":2,"code":"communication","text":"Kommunikáció (1-5)","type":"number"},{"id":3,"code":"waiting","text":"Várakozási idő (1-5)","type":"number"},{"id":4,"code":"cleanliness","text":"Tisztaság (1-5)","type":"number"}]'::jsonb;
BEGIN
FOR v_tenant IN SELECT id FROM public.tenants LOOP
  INSERT INTO public.questionnaires (tenant_id, code, title, leiras, language, items, licenc, mode, recall_rules, kioszk_eligible)
  VALUES (v_tenant.id, 'fu_postpartum_mother_v1', 'Szülés utáni állapot — anya',
    'Hetente / havonta / évente jelentkező követés szülés után.', 'hu', v_items_mother, 'free', 'klinikai',
    jsonb_build_object('rules', jsonb_build_array(
      jsonb_build_object('if', jsonb_build_object('code','fever_gt_38','min',1),'then', jsonb_build_object('recall','urgent_24h','specialty','obgyn')),
      jsonb_build_object('if', jsonb_build_object('code','heavy_bleeding','min',1),'then', jsonb_build_object('recall','urgent_24h','specialty','obgyn')),
      jsonb_build_object('if', jsonb_build_object('code','epds_total','min',13),'then', jsonb_build_object('recall','soon_7d','specialty','psy'))
    )), false)
  ON CONFLICT (tenant_id, code, language) DO UPDATE SET title = EXCLUDED.title, recall_rules = EXCLUDED.recall_rules, items = EXCLUDED.items
  RETURNING id INTO v_q_mother;

  INSERT INTO public.questionnaires (tenant_id, code, title, leiras, language, items, licenc, mode, recall_rules, kioszk_eligible)
  VALUES (v_tenant.id, 'fu_postpartum_child_v1', 'Újszülött / gyermek fejlődés',
    'Súly, etetés, fejlődési mérföldkövek, allergiák.', 'hu', v_items_child, 'free', 'klinikai',
    jsonb_build_object('rules', jsonb_build_array(
      jsonb_build_object('if', jsonb_build_object('code','child_fever_gt_38','min',1),'then', jsonb_build_object('recall','urgent_24h','specialty','pediatry')),
      jsonb_build_object('if', jsonb_build_object('code','child_milestone_miss','min',2),'then', jsonb_build_object('recall','soon_14d','specialty','pediatry')),
      jsonb_build_object('if', jsonb_build_object('code','feeding_difficulty','min',2),'then', jsonb_build_object('recall','soon_7d','specialty','pediatry'))
    )), false)
  ON CONFLICT (tenant_id, code, language) DO UPDATE SET title = EXCLUDED.title, recall_rules = EXCLUDED.recall_rules, items = EXCLUDED.items
  RETURNING id INTO v_q_child;

  INSERT INTO public.questionnaires (tenant_id, code, title, leiras, language, items, licenc, mode, recall_rules, kioszk_eligible)
  VALUES (v_tenant.id, 'fu_postsurgery_v1', 'Műtét utáni tünetkövetés',
    'Seb állapota, fájdalom, funkcionális visszanyerés.', 'hu', v_items_surgery, 'free', 'klinikai',
    jsonb_build_object('rules', jsonb_build_array(
      jsonb_build_object('if', jsonb_build_object('code','fever_gt_38','min',1),'then', jsonb_build_object('recall','urgent_24h','specialty','surgery')),
      jsonb_build_object('if', jsonb_build_object('code','wound_redness','min',2),'then', jsonb_build_object('recall','soon_72h','specialty','surgery')),
      jsonb_build_object('if', jsonb_build_object('code','pain_nrs','min',7),'then', jsonb_build_object('recall','soon_72h','specialty','surgery'))
    )), false)
  ON CONFLICT (tenant_id, code, language) DO UPDATE SET title = EXCLUDED.title, recall_rules = EXCLUDED.recall_rules, items = EXCLUDED.items
  RETURNING id INTO v_q_surgery;

  INSERT INTO public.questionnaires (tenant_id, code, title, leiras, language, items, licenc, mode, recall_rules, kioszk_eligible)
  VALUES (v_tenant.id, 'fu_satisfaction_v1', 'Beteg-elégedettség (NPS)',
    'Rövid elégedettségi felmérés vizit után.', 'hu', v_items_sat, 'free', 'egeszsegfejlesztesi', '{}'::jsonb, true)
  ON CONFLICT (tenant_id, code, language) DO UPDATE SET title = EXCLUDED.title, items = EXCLUDED.items
  RETURNING id INTO v_q_sat;

  INSERT INTO public.followup_protocols (tenant_id, kod, nev, leiras, anchor_event, default_window_days)
  VALUES (v_tenant.id, 'postpartum_mother', 'Szülés utáni követés — anya','Heti az 1. hónapban, havi fél évig, évente 5 évig.', 'birth', 1825)
  ON CONFLICT (tenant_id, kod) DO UPDATE SET nev = EXCLUDED.nev RETURNING id INTO v_p_mother;

  INSERT INTO public.followup_protocols (tenant_id, kod, nev, leiras, anchor_event, default_window_days)
  VALUES (v_tenant.id, 'postpartum_child', 'Gyermek fejlődés követése','Heti 3 hónapig, havi 12 hónapig, félévente 18 éves korig.', 'birth', 6570)
  ON CONFLICT (tenant_id, kod) DO UPDATE SET nev = EXCLUDED.nev RETURNING id INTO v_p_child;

  INSERT INTO public.followup_protocols (tenant_id, kod, nev, leiras, anchor_event, default_window_days)
  VALUES (v_tenant.id, 'postsurgery_symptoms', 'Műtét utáni tünetkövetés','Rögzített időpontokban: 1./3./7./14./30./90. nap.', 'surgery_completed', 90)
  ON CONFLICT (tenant_id, kod) DO UPDATE SET nev = EXCLUDED.nev RETURNING id INTO v_p_surgery;

  INSERT INTO public.followup_protocols (tenant_id, kod, nev, leiras, anchor_event, default_window_days)
  VALUES (v_tenant.id, 'satisfaction_postvisit', 'Vizit utáni elégedettség','Egyszeri elégedettségi felmérés vizit után.', 'visit_completed', 7)
  ON CONFLICT (tenant_id, kod) DO UPDATE SET nev = EXCLUDED.nev RETURNING id INTO v_p_sat;

  DELETE FROM public.followup_protocol_steps WHERE protocol_id IN (v_p_mother, v_p_child, v_p_surgery, v_p_sat);

  INSERT INTO public.followup_protocol_steps (protocol_id, phase_label, phase_order, questionnaire_id, offset_days_from, offset_days_to, cadence_days, channel) VALUES
    (v_p_mother, '1. hónap — hetente', 1, v_q_mother, 7, 28, 7, 'notification'),
    (v_p_mother, '2-6. hónap — havonta', 2, v_q_mother, 60, 180, 30, 'notification'),
    (v_p_mother, '1-5. év — évente', 3, v_q_mother, 365, 1825, 365, 'notification'),
    (v_p_child, '0-3. hónap — hetente', 1, v_q_child, 7, 90, 7, 'notification'),
    (v_p_child, '3-12. hónap — havonta', 2, v_q_child, 120, 365, 30, 'notification'),
    (v_p_child, '1-18. év — félévente', 3, v_q_child, 545, 6570, 180, 'notification'),
    (v_p_surgery, '1-3. nap', 1, v_q_surgery, 1, 3, 2, 'push'),
    (v_p_surgery, '7-14. nap', 2, v_q_surgery, 7, 14, 7, 'notification'),
    (v_p_surgery, '30-90. nap', 3, v_q_surgery, 30, 90, 30, 'notification'),
    (v_p_sat, 'Egyszeri visszajelzés', 1, v_q_sat, 1, 1, 1, 'email');
END LOOP;
END $$;
