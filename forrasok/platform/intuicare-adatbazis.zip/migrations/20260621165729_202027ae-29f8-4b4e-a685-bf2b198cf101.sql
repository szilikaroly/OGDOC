
-- 1) clinical_critical_alerts: drop permissive policies, add tenant+permission scoped ones
DROP POLICY IF EXISTS "Authenticated read clinical alerts" ON public.clinical_critical_alerts;
DROP POLICY IF EXISTS "Authenticated insert clinical alerts" ON public.clinical_critical_alerts;
DROP POLICY IF EXISTS "Authenticated ack clinical alerts" ON public.clinical_critical_alerts;

CREATE POLICY "Staff read clinical alerts in own tenant"
ON public.clinical_critical_alerts
FOR SELECT
TO authenticated
USING (public.can_access_patient(patient_id));

CREATE POLICY "Staff insert clinical alerts in own tenant"
ON public.clinical_critical_alerts
FOR INSERT
TO authenticated
WITH CHECK (
  public.can_access_patient(patient_id)
  AND public.has_permission(auth.uid(), 'manage_patients')
);

CREATE POLICY "Staff ack clinical alerts in own tenant"
ON public.clinical_critical_alerts
FOR UPDATE
TO authenticated
USING (
  public.can_access_patient(patient_id)
  AND public.has_permission(auth.uid(), 'manage_patients')
)
WITH CHECK (
  public.can_access_patient(patient_id)
  AND public.has_permission(auth.uid(), 'manage_patients')
);

-- 2) patient_referral_requests: enforce tenant scope on staff policy
DROP POLICY IF EXISTS "Staff manages referral requests" ON public.patient_referral_requests;

CREATE POLICY "Staff manages referral requests in own tenant"
ON public.patient_referral_requests
FOR ALL
TO authenticated
USING (
  tenant_id = public.current_tenant_id()
  AND (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'orvos'))
)
WITH CHECK (
  tenant_id = public.current_tenant_id()
  AND (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'orvos'))
);

-- 3) i18n_missing_keys: anyone can log a missing key (insert), only admins can update/delete; read open (no sensitive data)
DROP POLICY IF EXISTS i18n_missing_keys_all_auth ON public.i18n_missing_keys;

CREATE POLICY i18n_missing_keys_read
ON public.i18n_missing_keys
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY i18n_missing_keys_insert
ON public.i18n_missing_keys
FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY i18n_missing_keys_admin_update
ON public.i18n_missing_keys
FOR UPDATE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY i18n_missing_keys_admin_delete
ON public.i18n_missing_keys
FOR DELETE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- 4) patient_ai_explanations: explicit tenant-scoped staff read
CREATE POLICY "Staff reads patient AI explanations in tenant"
ON public.patient_ai_explanations
FOR SELECT
TO authenticated
USING (public.can_access_patient(patient_id));

-- 5) chat-attachments storage: explicit restrictive UPDATE deny for non-owners
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname='storage' AND tablename='objects'
      AND policyname='chat_attachments_no_replace'
  ) THEN
    EXECUTE $p$
      CREATE POLICY chat_attachments_no_replace
      ON storage.objects
      AS RESTRICTIVE
      FOR UPDATE
      TO authenticated
      USING (
        bucket_id <> 'chat-attachments'
        OR owner = auth.uid()
      )
      WITH CHECK (
        bucket_id <> 'chat-attachments'
        OR owner = auth.uid()
      );
    $p$;
  END IF;
END $$;
