
-- ============================================================
-- Follow-up (visszajelentő) rendszer alapinfrastruktúra
-- ============================================================

-- 1) Enumok
DO $$ BEGIN
  CREATE TYPE public.followup_anchor_event AS ENUM (
    'birth', 'surgery_completed', 'discharge', 'visit_completed'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.followup_enrollment_status AS ENUM (
    'active', 'paused', 'completed', 'cancelled'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.followup_occurrence_status AS ENUM (
    'scheduled', 'sent', 'responded', 'missed', 'cancelled'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- qet_event_type enum bővítés
DO $$ BEGIN
  ALTER TYPE public.qet_event_type ADD VALUE IF NOT EXISTS 'birth_recorded';
EXCEPTION WHEN others THEN NULL; END $$;
DO $$ BEGIN
  ALTER TYPE public.qet_event_type ADD VALUE IF NOT EXISTS 'surgery_completed';
EXCEPTION WHEN others THEN NULL; END $$;
DO $$ BEGIN
  ALTER TYPE public.qet_event_type ADD VALUE IF NOT EXISTS 'encounter_discharged';
EXCEPTION WHEN others THEN NULL; END $$;
DO $$ BEGIN
  ALTER TYPE public.qet_event_type ADD VALUE IF NOT EXISTS 'visit_completed';
EXCEPTION WHEN others THEN NULL; END $$;

-- 2) Recall szabály mező a questionnaires-en
ALTER TABLE public.questionnaires
  ADD COLUMN IF NOT EXISTS recall_rules jsonb NOT NULL DEFAULT '{}'::jsonb;

-- 3) followup_protocols
CREATE TABLE IF NOT EXISTS public.followup_protocols (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  kod text NOT NULL,
  nev text NOT NULL,
  leiras text,
  anchor_event public.followup_anchor_event NOT NULL,
  default_window_days integer NOT NULL DEFAULT 365,
  aktiv boolean NOT NULL DEFAULT true,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, kod)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.followup_protocols TO authenticated;
GRANT ALL ON public.followup_protocols TO service_role;
ALTER TABLE public.followup_protocols ENABLE ROW LEVEL SECURITY;

CREATE POLICY "followup_protocols_select"
  ON public.followup_protocols FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY "followup_protocols_write"
  ON public.followup_protocols FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_patients'))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_patients'));

-- 4) followup_protocol_steps
CREATE TABLE IF NOT EXISTS public.followup_protocol_steps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  protocol_id uuid NOT NULL REFERENCES public.followup_protocols(id) ON DELETE CASCADE,
  phase_label text NOT NULL,
  phase_order integer NOT NULL,
  questionnaire_id uuid NOT NULL REFERENCES public.questionnaires(id) ON DELETE RESTRICT,
  offset_days_from integer NOT NULL,
  offset_days_to integer NOT NULL,
  cadence_days integer NOT NULL,
  channel public.reminder_channel NOT NULL DEFAULT 'notification',
  reminder_buckets integer[] NOT NULL DEFAULT ARRAY[1,3]::integer[],
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (offset_days_to >= offset_days_from),
  CHECK (cadence_days > 0)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.followup_protocol_steps TO authenticated;
GRANT ALL ON public.followup_protocol_steps TO service_role;
ALTER TABLE public.followup_protocol_steps ENABLE ROW LEVEL SECURITY;

CREATE POLICY "followup_steps_select"
  ON public.followup_protocol_steps FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.followup_protocols p
                 WHERE p.id = protocol_id AND p.tenant_id = public.current_tenant_id()));
CREATE POLICY "followup_steps_write"
  ON public.followup_protocol_steps FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.followup_protocols p
                 WHERE p.id = protocol_id AND p.tenant_id = public.current_tenant_id()
                 AND public.has_permission(auth.uid(), 'manage_patients')))
  WITH CHECK (EXISTS (SELECT 1 FROM public.followup_protocols p
                      WHERE p.id = protocol_id AND p.tenant_id = public.current_tenant_id()
                      AND public.has_permission(auth.uid(), 'manage_patients')));

-- 5) followup_enrollments
CREATE TABLE IF NOT EXISTS public.followup_enrollments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  protocol_id uuid NOT NULL REFERENCES public.followup_protocols(id) ON DELETE RESTRICT,
  anchor_at timestamptz NOT NULL,
  anchor_ref jsonb NOT NULL DEFAULT '{}'::jsonb,
  status public.followup_enrollment_status NOT NULL DEFAULT 'active',
  paused_reason text,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (patient_id, protocol_id, anchor_at)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.followup_enrollments TO authenticated;
GRANT ALL ON public.followup_enrollments TO service_role;
ALTER TABLE public.followup_enrollments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "followup_enroll_select"
  ON public.followup_enrollments FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(), 'manage_patients')
              OR public.has_permission(auth.uid(), 'view_patients')));
CREATE POLICY "followup_enroll_write"
  ON public.followup_enrollments FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_patients'))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_patients'));

CREATE INDEX IF NOT EXISTS followup_enroll_status_idx
  ON public.followup_enrollments(tenant_id, status);

-- 6) followup_occurrences
CREATE TABLE IF NOT EXISTS public.followup_occurrences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  enrollment_id uuid NOT NULL REFERENCES public.followup_enrollments(id) ON DELETE CASCADE,
  step_id uuid NOT NULL REFERENCES public.followup_protocol_steps(id) ON DELETE RESTRICT,
  occurrence_index integer NOT NULL,
  due_at timestamptz NOT NULL,
  assignment_id uuid REFERENCES public.questionnaire_assignments(id) ON DELETE SET NULL,
  status public.followup_occurrence_status NOT NULL DEFAULT 'scheduled',
  responded_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (enrollment_id, step_id, occurrence_index)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.followup_occurrences TO authenticated;
GRANT ALL ON public.followup_occurrences TO service_role;
ALTER TABLE public.followup_occurrences ENABLE ROW LEVEL SECURITY;

CREATE POLICY "followup_occ_select"
  ON public.followup_occurrences FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.followup_enrollments e
                 WHERE e.id = enrollment_id
                 AND e.tenant_id = public.current_tenant_id()
                 AND (public.has_permission(auth.uid(), 'manage_patients')
                      OR public.has_permission(auth.uid(), 'view_patients'))));
CREATE POLICY "followup_occ_write"
  ON public.followup_occurrences FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.followup_enrollments e
                 WHERE e.id = enrollment_id
                 AND e.tenant_id = public.current_tenant_id()
                 AND public.has_permission(auth.uid(), 'manage_patients')))
  WITH CHECK (EXISTS (SELECT 1 FROM public.followup_enrollments e
                      WHERE e.id = enrollment_id
                      AND e.tenant_id = public.current_tenant_id()
                      AND public.has_permission(auth.uid(), 'manage_patients')));

CREATE INDEX IF NOT EXISTS followup_occ_due_idx
  ON public.followup_occurrences(status, due_at);

-- 7) updated_at triggerek
CREATE TRIGGER followup_protocols_touch BEFORE UPDATE ON public.followup_protocols
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER followup_steps_touch BEFORE UPDATE ON public.followup_protocol_steps
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER followup_enroll_touch BEFORE UPDATE ON public.followup_enrollments
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER followup_occ_touch BEFORE UPDATE ON public.followup_occurrences
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 8) Idempotens enroll helper
CREATE OR REPLACE FUNCTION public.enroll_followup(
  _tenant_id uuid,
  _patient_id uuid,
  _protocol_kod text,
  _anchor_at timestamptz,
  _anchor_ref jsonb DEFAULT '{}'::jsonb
) RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_protocol_id uuid;
  v_enrollment_id uuid;
BEGIN
  SELECT id INTO v_protocol_id
    FROM public.followup_protocols
   WHERE tenant_id = _tenant_id AND kod = _protocol_kod AND aktiv = true
   LIMIT 1;
  IF v_protocol_id IS NULL THEN RETURN NULL; END IF;

  INSERT INTO public.followup_enrollments
    (tenant_id, patient_id, protocol_id, anchor_at, anchor_ref, status)
  VALUES (_tenant_id, _patient_id, v_protocol_id, _anchor_at, _anchor_ref, 'active')
  ON CONFLICT (patient_id, protocol_id, anchor_at) DO UPDATE SET updated_at = now()
  RETURNING id INTO v_enrollment_id;

  RETURN v_enrollment_id;
END $$;

REVOKE ALL ON FUNCTION public.enroll_followup(uuid, uuid, text, timestamptz, jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.enroll_followup(uuid, uuid, text, timestamptz, jsonb) TO service_role;

-- 9) Fő feldolgozó: generálja a soron következő occurrence-eket és assignment-eket
CREATE OR REPLACE FUNCTION public.process_followup_schedules()
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_enrollment record;
  v_step record;
  v_next_due timestamptz;
  v_idx integer;
  v_assignment_id uuid;
  v_count integer := 0;
  v_token text;
BEGIN
  FOR v_enrollment IN
    SELECT e.* FROM public.followup_enrollments e
     WHERE e.status = 'active'
  LOOP
    FOR v_step IN
      SELECT s.* FROM public.followup_protocol_steps s
       WHERE s.protocol_id = v_enrollment.protocol_id
       ORDER BY s.phase_order ASC
    LOOP
      -- Számolja, hány occurrence van már ehhez a stephez
      SELECT COALESCE(MAX(occurrence_index), -1) + 1
        INTO v_idx
        FROM public.followup_occurrences
       WHERE enrollment_id = v_enrollment.id AND step_id = v_step.id;

      LOOP
        v_next_due := v_enrollment.anchor_at + (v_step.offset_days_from || ' days')::interval
                      + (v_idx * v_step.cadence_days || ' days')::interval;

        -- Ha túllóg a fázis felső határán, kilépünk ebből a stepből
        IF v_next_due > v_enrollment.anchor_at + (v_step.offset_days_to || ' days')::interval THEN
          EXIT;
        END IF;

        -- Csak a jelen + következő 24 órás ablakon belüli due-kat hozzuk létre,
        -- hogy ne túltermeljünk; a cron napi futása fokozatosan tölti fel.
        IF v_next_due > now() + interval '1 day' THEN
          EXIT;
        END IF;

        -- Token generálás (sha256 + random bytes)
        v_token := encode(digest(gen_random_uuid()::text || clock_timestamp()::text, 'sha256'), 'hex');

        -- Assignment létrehozása
        INSERT INTO public.questionnaire_assignments
          (tenant_id, questionnaire_id, patient_id, due_at, status, token, assigned_by)
        VALUES (v_enrollment.tenant_id, v_step.questionnaire_id, v_enrollment.patient_id,
                v_next_due, 'assigned', substr(v_token, 1, 32), v_enrollment.created_by)
        RETURNING id INTO v_assignment_id;

        -- Occurrence rögzítése
        INSERT INTO public.followup_occurrences
          (enrollment_id, step_id, occurrence_index, due_at, assignment_id, status)
        VALUES (v_enrollment.id, v_step.id, v_idx, v_next_due, v_assignment_id, 'sent')
        ON CONFLICT (enrollment_id, step_id, occurrence_index) DO NOTHING;

        v_count := v_count + 1;
        v_idx := v_idx + 1;
      END LOOP;
    END LOOP;

    -- Ellenőrizzük lejárt enrollment-eket
    IF v_enrollment.anchor_at + (
        SELECT MAX(offset_days_to) FROM public.followup_protocol_steps
         WHERE protocol_id = v_enrollment.protocol_id) * interval '1 day' < now() THEN
      UPDATE public.followup_enrollments
         SET status = 'completed', updated_at = now()
       WHERE id = v_enrollment.id AND status = 'active';
    END IF;
  END LOOP;

  -- Lejárt (missed) occurrence-ek
  UPDATE public.followup_occurrences
     SET status = 'missed', updated_at = now()
   WHERE status = 'sent'
     AND due_at < now() - interval '14 days';

  RETURN v_count;
END $$;

REVOKE ALL ON FUNCTION public.process_followup_schedules() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.process_followup_schedules() TO service_role;

-- 10) Trigger: amikor egy assignment-hez tartozó response érkezik, jelöljük responded-ként
CREATE OR REPLACE FUNCTION public.mark_followup_occurrence_responded()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.assignment_id IS NOT NULL THEN
    UPDATE public.followup_occurrences
       SET status = 'responded', responded_at = NEW.completed_at, updated_at = now()
     WHERE assignment_id = NEW.assignment_id;
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_followup_mark_responded ON public.questionnaire_responses;
CREATE TRIGGER trg_followup_mark_responded
  AFTER INSERT ON public.questionnaire_responses
  FOR EACH ROW EXECUTE FUNCTION public.mark_followup_occurrence_responded();

-- 11) Esemény-triggerek a horgony eseményekhez
-- Surgery completed
CREATE OR REPLACE FUNCTION public.trg_surgery_followup_enroll()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_patient_id uuid;
BEGIN
  IF NEW.status = 'completed' AND (OLD.status IS DISTINCT FROM NEW.status) THEN
    -- Megpróbáljuk a páciens id-t az appointment kapcsolatból
    SELECT patient_id INTO v_patient_id FROM public.appointments
     WHERE id = NEW.appointment_id;
    IF v_patient_id IS NOT NULL THEN
      PERFORM public.enroll_followup(
        NEW.tenant_id, v_patient_id, 'postsurgery_symptoms',
        now(), jsonb_build_object('surgery_case_id', NEW.id));
    END IF;
  END IF;
  RETURN NEW;
END $$;

-- A surgery_cases táblának van appointment_id-je? Csak akkor kötjük be, ha igen.
DO $$ BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
     WHERE table_schema='public' AND table_name='surgery_cases' AND column_name='appointment_id'
  ) THEN
    DROP TRIGGER IF EXISTS trg_surgery_followup ON public.surgery_cases;
    CREATE TRIGGER trg_surgery_followup
      AFTER UPDATE ON public.surgery_cases
      FOR EACH ROW EXECUTE FUNCTION public.trg_surgery_followup_enroll();
  END IF;
END $$;

-- Encounter discharged
CREATE OR REPLACE FUNCTION public.trg_encounter_followup_enroll()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.discharged_at IS NOT NULL AND (OLD.discharged_at IS NULL) THEN
    PERFORM public.enroll_followup(
      NEW.tenant_id, NEW.patient_id, 'satisfaction_postvisit',
      NEW.discharged_at + interval '1 day',
      jsonb_build_object('encounter_id', NEW.id));
  END IF;
  RETURN NEW;
END $$;

DO $$ BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
     WHERE table_schema='public' AND table_name='clinical_encounters' AND column_name='discharged_at'
  ) THEN
    DROP TRIGGER IF EXISTS trg_encounter_followup ON public.clinical_encounters;
    CREATE TRIGGER trg_encounter_followup
      AFTER UPDATE ON public.clinical_encounters
      FOR EACH ROW EXECUTE FUNCTION public.trg_encounter_followup_enroll();
  END IF;
END $$;

-- Visit completed (appointments)
CREATE OR REPLACE FUNCTION public.trg_visit_followup_enroll()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.status = 'completed' AND (OLD.status IS DISTINCT FROM NEW.status) AND NEW.patient_id IS NOT NULL THEN
    PERFORM public.enroll_followup(
      NEW.tenant_id, NEW.patient_id, 'satisfaction_postvisit',
      now() + interval '1 day',
      jsonb_build_object('appointment_id', NEW.id));
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_visit_followup ON public.appointments;
CREATE TRIGGER trg_visit_followup
  AFTER UPDATE ON public.appointments
  FOR EACH ROW EXECUTE FUNCTION public.trg_visit_followup_enroll();

-- Obstetric: partogram lezárás → szülés rögzítve
CREATE OR REPLACE FUNCTION public.trg_birth_followup_enroll()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_patient_id uuid;
  v_tenant_id uuid;
BEGIN
  IF NEW.completed_at IS NOT NULL AND (OLD.completed_at IS NULL) THEN
    SELECT patient_id, tenant_id INTO v_patient_id, v_tenant_id
      FROM public.patients WHERE id = NEW.patient_id;
    -- v_patient_id ez maga a NEW.patient_id; tenant_id a partogramon vagy a patient-en
    IF v_tenant_id IS NULL THEN
      v_tenant_id := NEW.tenant_id;
    END IF;
    PERFORM public.enroll_followup(
      v_tenant_id, NEW.patient_id, 'postpartum_mother',
      NEW.completed_at,
      jsonb_build_object('partogram_id', NEW.id));
    -- Gyermek protokoll szintén az anyára indul; a páciens-portál a UI-ban
    -- külön kérdezi rá, ha külön child rekord jön létre.
    PERFORM public.enroll_followup(
      v_tenant_id, NEW.patient_id, 'postpartum_child',
      NEW.completed_at,
      jsonb_build_object('partogram_id', NEW.id, 'subject', 'child'));
  END IF;
  RETURN NEW;
END $$;

DO $$ BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
     WHERE table_schema='public' AND table_name='obstetric_partograms' AND column_name='completed_at'
  ) THEN
    DROP TRIGGER IF EXISTS trg_birth_followup ON public.obstetric_partograms;
    CREATE TRIGGER trg_birth_followup
      AFTER UPDATE ON public.obstetric_partograms
      FOR EACH ROW EXECUTE FUNCTION public.trg_birth_followup_enroll();
  END IF;
END $$;
