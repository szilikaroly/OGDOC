ALTER TABLE public.patients
  ADD COLUMN IF NOT EXISTS telefon text,
  ADD COLUMN IF NOT EXISTS email text,
  ADD COLUMN IF NOT EXISTS iranyitoszam text,
  ADD COLUMN IF NOT EXISTS varos text,
  ADD COLUMN IF NOT EXISTS cim text;

ALTER TABLE public.patient_emergency_card
  ADD COLUMN IF NOT EXISTS gyogyszer_erzekenyseg text[],
  ADD COLUMN IF NOT EXISTS etrend text,
  ADD COLUMN IF NOT EXISTS kapcsolt_orvos_telefon text;

CREATE TABLE IF NOT EXISTS public.patient_medication_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  gyogyszer_nev text NOT NULL,
  hatas_eros text,
  mennyiseg text,
  ismetlodo boolean NOT NULL DEFAULT false,
  surgosseg text NOT NULL DEFAULT 'normal' CHECK (surgosseg IN ('normal','surgos')),
  megjegyzes text,
  status text NOT NULL DEFAULT 'uj' CHECK (status IN ('uj','elbiralas','jovahagyva','elutasitva','teljesitve')),
  reply text,
  reviewed_by uuid,
  reviewed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.patient_medication_requests TO authenticated;
GRANT ALL ON public.patient_medication_requests TO service_role;

ALTER TABLE public.patient_medication_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "patient owns med requests"
  ON public.patient_medication_requests FOR ALL TO authenticated
  USING (patient_id IN (SELECT current_user_patient_ids()))
  WITH CHECK (patient_id IN (SELECT current_user_patient_ids()) AND user_id = auth.uid());

CREATE POLICY "staff read med requests"
  ON public.patient_medication_requests FOR SELECT TO authenticated
  USING (has_permission(auth.uid(), 'view_patient_data'));

CREATE POLICY "staff update med requests"
  ON public.patient_medication_requests FOR UPDATE TO authenticated
  USING (has_permission(auth.uid(), 'view_patient_data'))
  WITH CHECK (has_permission(auth.uid(), 'view_patient_data'));

CREATE TRIGGER trg_medreq_updated_at BEFORE UPDATE ON public.patient_medication_requests
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE INDEX IF NOT EXISTS idx_medreq_patient ON public.patient_medication_requests(patient_id, created_at DESC);

CREATE TABLE IF NOT EXISTS public.patient_documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  uploaded_by uuid NOT NULL,
  uploader_kind text NOT NULL DEFAULT 'patient' CHECK (uploader_kind IN ('patient','staff','clinic')),
  category text NOT NULL DEFAULT 'general' CHECK (category IN ('general','lab','imaging','referral','discharge','prescription','other')),
  title text NOT NULL,
  description text,
  storage_path text NOT NULL,
  mime_type text,
  size_bytes integer,
  shared_with_patient boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.patient_documents TO authenticated;
GRANT ALL ON public.patient_documents TO service_role;

ALTER TABLE public.patient_documents ENABLE ROW LEVEL SECURITY;

CREATE POLICY "patient sees own documents"
  ON public.patient_documents FOR SELECT TO authenticated
  USING (patient_id IN (SELECT current_user_patient_ids()) AND shared_with_patient = true);

CREATE POLICY "patient uploads own documents"
  ON public.patient_documents FOR INSERT TO authenticated
  WITH CHECK (patient_id IN (SELECT current_user_patient_ids()) AND uploaded_by = auth.uid() AND uploader_kind = 'patient');

CREATE POLICY "patient deletes own uploads"
  ON public.patient_documents FOR DELETE TO authenticated
  USING (patient_id IN (SELECT current_user_patient_ids()) AND uploaded_by = auth.uid() AND uploader_kind = 'patient');

CREATE POLICY "staff manages documents"
  ON public.patient_documents FOR ALL TO authenticated
  USING (has_permission(auth.uid(), 'view_patient_data'))
  WITH CHECK (has_permission(auth.uid(), 'view_patient_data'));

CREATE TRIGGER trg_patdocs_updated_at BEFORE UPDATE ON public.patient_documents
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE INDEX IF NOT EXISTS idx_patdocs_patient ON public.patient_documents(patient_id, created_at DESC);

CREATE TABLE IF NOT EXISTS public.patient_health_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  cim text NOT NULL,
  cel text,
  lepesek jsonb NOT NULL DEFAULT '[]'::jsonb,
  status text NOT NULL DEFAULT 'aktiv' CHECK (status IN ('aktiv','befejezett','felfuggesztve')),
  kezdo_datum date,
  zaro_datum date,
  letrehozta uuid,
  paciens_jegyzet text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.patient_health_plans TO authenticated;
GRANT ALL ON public.patient_health_plans TO service_role;

ALTER TABLE public.patient_health_plans ENABLE ROW LEVEL SECURITY;

CREATE POLICY "patient reads own plans"
  ON public.patient_health_plans FOR SELECT TO authenticated
  USING (patient_id IN (SELECT current_user_patient_ids()));

CREATE POLICY "patient updates own note"
  ON public.patient_health_plans FOR UPDATE TO authenticated
  USING (patient_id IN (SELECT current_user_patient_ids()))
  WITH CHECK (patient_id IN (SELECT current_user_patient_ids()));

CREATE POLICY "staff manages plans"
  ON public.patient_health_plans FOR ALL TO authenticated
  USING (has_permission(auth.uid(), 'view_patient_data'))
  WITH CHECK (has_permission(auth.uid(), 'view_patient_data'));

CREATE TRIGGER trg_plans_updated_at BEFORE UPDATE ON public.patient_health_plans
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE INDEX IF NOT EXISTS idx_plans_patient ON public.patient_health_plans(patient_id, created_at DESC);