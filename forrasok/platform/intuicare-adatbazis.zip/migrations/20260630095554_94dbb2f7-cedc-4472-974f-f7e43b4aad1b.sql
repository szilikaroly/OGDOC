
ALTER TABLE public.cms_news_posts
  ADD COLUMN IF NOT EXISTS post_type text NOT NULL DEFAULT 'blog',
  ADD COLUMN IF NOT EXISTS video_provider text,
  ADD COLUMN IF NOT EXISTS video_url text,
  ADD COLUMN IF NOT EXISTS video_embed_url text,
  ADD COLUMN IF NOT EXISTS video_thumbnail_url text,
  ADD COLUMN IF NOT EXISTS video_duration_seconds integer,
  ADD COLUMN IF NOT EXISTS video_transcript text;

ALTER TABLE public.cms_news_posts
  DROP CONSTRAINT IF EXISTS cms_news_posts_post_type_check;
ALTER TABLE public.cms_news_posts
  ADD CONSTRAINT cms_news_posts_post_type_check CHECK (post_type IN ('blog','vlog'));

ALTER TABLE public.cms_news_posts
  DROP CONSTRAINT IF EXISTS cms_news_posts_video_provider_check;
ALTER TABLE public.cms_news_posts
  ADD CONSTRAINT cms_news_posts_video_provider_check
  CHECK (video_provider IS NULL OR video_provider IN ('youtube','vimeo','file'));

CREATE INDEX IF NOT EXISTS cms_news_posts_post_type_status_idx
  ON public.cms_news_posts (post_type, status, published_at DESC);
