
-- ============================================================
-- 1) app_settings
-- ============================================================
CREATE TABLE public.app_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  namespace TEXT NOT NULL,
  key TEXT NOT NULL,
  value JSONB NOT NULL DEFAULT '{}'::jsonb,
  draft_value JSONB,
  is_public BOOLEAN NOT NULL DEFAULT false,
  schema_version INT NOT NULL DEFAULT 1,
  updated_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(namespace, key)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.app_settings TO authenticated;
GRANT SELECT ON public.app_settings TO anon;
GRANT ALL ON public.app_settings TO service_role;

ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins manage all settings"
  ON public.app_settings FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Authenticated read public settings"
  ON public.app_settings FOR SELECT
  TO authenticated
  USING (is_public = true OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Anon read public settings"
  ON public.app_settings FOR SELECT
  TO anon
  USING (is_public = true);

CREATE INDEX idx_app_settings_namespace ON public.app_settings(namespace);
CREATE INDEX idx_app_settings_public ON public.app_settings(is_public) WHERE is_public = true;

-- ============================================================
-- 2) app_settings_audit
-- ============================================================
CREATE TABLE public.app_settings_audit (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  setting_id UUID REFERENCES public.app_settings(id) ON DELETE SET NULL,
  namespace TEXT NOT NULL,
  key TEXT NOT NULL,
  action TEXT NOT NULL CHECK (action IN ('create','update','delete','publish','reset')),
  old_value JSONB,
  new_value JSONB,
  changed_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  reason TEXT,
  changed_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT ON public.app_settings_audit TO authenticated;
GRANT ALL ON public.app_settings_audit TO service_role;

ALTER TABLE public.app_settings_audit ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins read audit"
  ON public.app_settings_audit FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins insert audit"
  ON public.app_settings_audit FOR INSERT
  TO authenticated
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE INDEX idx_app_settings_audit_key ON public.app_settings_audit(namespace, key, changed_at DESC);

-- Trigger: log every change
CREATE OR REPLACE FUNCTION public.fn_app_settings_audit()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    INSERT INTO public.app_settings_audit(setting_id, namespace, key, action, old_value, new_value, changed_by)
    VALUES (NEW.id, NEW.namespace, NEW.key, 'create', NULL, NEW.value, NEW.updated_by);
    RETURN NEW;
  ELSIF TG_OP = 'UPDATE' THEN
    IF OLD.value IS DISTINCT FROM NEW.value OR OLD.draft_value IS DISTINCT FROM NEW.draft_value THEN
      INSERT INTO public.app_settings_audit(setting_id, namespace, key, action, old_value, new_value, changed_by)
      VALUES (NEW.id, NEW.namespace, NEW.key, 'update', OLD.value, NEW.value, NEW.updated_by);
    END IF;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    INSERT INTO public.app_settings_audit(setting_id, namespace, key, action, old_value, new_value, changed_by)
    VALUES (OLD.id, OLD.namespace, OLD.key, 'delete', OLD.value, NULL, OLD.updated_by);
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$;

CREATE TRIGGER trg_app_settings_audit
AFTER INSERT OR UPDATE OR DELETE ON public.app_settings
FOR EACH ROW EXECUTE FUNCTION public.fn_app_settings_audit();

-- updated_at trigger
CREATE OR REPLACE FUNCTION public.fn_app_settings_touch()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

CREATE TRIGGER trg_app_settings_touch
BEFORE UPDATE ON public.app_settings
FOR EACH ROW EXECUTE FUNCTION public.fn_app_settings_touch();

-- ============================================================
-- 3) landing_page_blocks
-- ============================================================
CREATE TABLE public.landing_page_blocks (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  block_type TEXT NOT NULL,
  position INT NOT NULL DEFAULT 0,
  locale TEXT NOT NULL DEFAULT 'hu',
  content JSONB NOT NULL DEFAULT '{}'::jsonb,
  draft_content JSONB,
  is_published BOOLEAN NOT NULL DEFAULT false,
  variant TEXT NOT NULL DEFAULT 'default',
  updated_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.landing_page_blocks TO authenticated;
GRANT SELECT ON public.landing_page_blocks TO anon;
GRANT ALL ON public.landing_page_blocks TO service_role;

ALTER TABLE public.landing_page_blocks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins manage landing blocks"
  ON public.landing_page_blocks FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Anon read published blocks"
  ON public.landing_page_blocks FOR SELECT
  TO anon
  USING (is_published = true);

CREATE POLICY "Authenticated read published blocks"
  ON public.landing_page_blocks FOR SELECT
  TO authenticated
  USING (is_published = true OR public.has_role(auth.uid(), 'admin'));

CREATE INDEX idx_landing_blocks_order ON public.landing_page_blocks(locale, variant, position);

CREATE TRIGGER trg_landing_blocks_touch
BEFORE UPDATE ON public.landing_page_blocks
FOR EACH ROW EXECUTE FUNCTION public.fn_app_settings_touch();

-- ============================================================
-- 4) landing_page_versions (snapshot)
-- ============================================================
CREATE TABLE public.landing_page_versions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  label TEXT,
  locale TEXT NOT NULL DEFAULT 'hu',
  variant TEXT NOT NULL DEFAULT 'default',
  snapshot JSONB NOT NULL,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, DELETE ON public.landing_page_versions TO authenticated;
GRANT ALL ON public.landing_page_versions TO service_role;

ALTER TABLE public.landing_page_versions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins manage landing versions"
  ON public.landing_page_versions FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE INDEX idx_landing_versions_created ON public.landing_page_versions(created_at DESC);

-- ============================================================
-- 5) ai_setting_suggestions
-- ============================================================
CREATE TABLE public.ai_setting_suggestions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  target_kind TEXT NOT NULL CHECK (target_kind IN ('setting','landing_block','landing_full')),
  target_namespace TEXT,
  target_key TEXT,
  goal TEXT,
  suggested_value JSONB NOT NULL,
  rationale TEXT,
  model TEXT,
  accepted BOOLEAN NOT NULL DEFAULT false,
  accepted_at TIMESTAMPTZ,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.ai_setting_suggestions TO authenticated;
GRANT ALL ON public.ai_setting_suggestions TO service_role;

ALTER TABLE public.ai_setting_suggestions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins manage AI suggestions"
  ON public.ai_setting_suggestions FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE INDEX idx_ai_suggestions_target ON public.ai_setting_suggestions(target_kind, target_namespace, target_key, created_at DESC);
