
ALTER TABLE public.cms_pages
  ADD COLUMN IF NOT EXISTS scheduled_publish_at timestamptz,
  ADD COLUMN IF NOT EXISTS noindex boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS preview_token uuid NOT NULL DEFAULT gen_random_uuid();

CREATE INDEX IF NOT EXISTS cms_pages_scheduled_publish_at_idx
  ON public.cms_pages (scheduled_publish_at)
  WHERE scheduled_publish_at IS NOT NULL;

-- Cron-szerű auto-publish: a scheduled státuszú oldalakat élesíti,
-- ha a scheduled_publish_at időpont elérkezett.
CREATE OR REPLACE FUNCTION public.cms_promote_scheduled_pages()
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  n integer;
BEGIN
  UPDATE public.cms_pages
     SET status = 'published',
         published_at = COALESCE(scheduled_publish_at, now()),
         scheduled_publish_at = NULL
   WHERE status = 'scheduled'
     AND scheduled_publish_at IS NOT NULL
     AND scheduled_publish_at <= now();
  GET DIAGNOSTICS n = ROW_COUNT;
  RETURN n;
END;
$$;
