
-- 1) Profiles bővítése
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS szuletesi_datum date,
  ADD COLUMN IF NOT EXISTS gyermek_szamok jsonb NOT NULL DEFAULT '[]'::jsonb,
  ADD COLUMN IF NOT EXISTS vezetoi_szint text,
  ADD COLUMN IF NOT EXISTS sugarterheles_kategoria text,
  ADD COLUMN IF NOT EXISTS oktatoi_munkakor boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS klinikai_kombinalt boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS kjt_fizetesi_osztaly text,
  ADD COLUMN IF NOT EXISTS belepes_datum date;

ALTER TABLE public.profile_employment
  ADD COLUMN IF NOT EXISTS oktatoi_munkakor_arany smallint,
  ADD COLUMN IF NOT EXISTS vezetoi_szint text;

ALTER TABLE public.profile_unavailability
  ADD COLUMN IF NOT EXISTS is_kenyszer boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS forrasev integer,
  ADD COLUMN IF NOT EXISTS jogcim text NOT NULL DEFAULT 'alap',
  ADD COLUMN IF NOT EXISTS nap_szam numeric(5,2);

-- 2) leave_policy
CREATE TABLE IF NOT EXISTS public.leave_policy (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  ev integer NOT NULL,
  alapszabadsag_mt integer NOT NULL DEFAULT 20,
  eletkor_pot jsonb NOT NULL DEFAULT '[{"kor":25,"nap":1},{"kor":28,"nap":2},{"kor":31,"nap":3},{"kor":33,"nap":4},{"kor":35,"nap":5},{"kor":37,"nap":6},{"kor":39,"nap":7},{"kor":41,"nap":8},{"kor":43,"nap":9},{"kor":45,"nap":10}]'::jsonb,
  gyermek_pot jsonb NOT NULL DEFAULT '{"1":2,"2":4,"3+":7,"fogyatekos_plusz":2}'::jsonb,
  apasagi_nap integer NOT NULL DEFAULT 10,
  szuloi_nap integer NOT NULL DEFAULT 44,
  eu_alap jsonb NOT NULL DEFAULT '{"alap":20,"felsofoku":21}'::jsonb,
  oktatoi_max integer NOT NULL DEFAULT 25,
  oktatoi_max_targy integer NOT NULL DEFAULT 15,
  vezeto_magas_pot integer NOT NULL DEFAULT 10,
  vezeto_pot integer NOT NULL DEFAULT 5,
  sugar_pot integer NOT NULL DEFAULT 10,
  forced_takeout_deadline_mmdd text NOT NULL DEFAULT '01-30',
  max_carryover_alap_quarter boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, ev)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.leave_policy TO authenticated;
GRANT ALL ON public.leave_policy TO service_role;
ALTER TABLE public.leave_policy ENABLE ROW LEVEL SECURITY;

CREATE POLICY "leave_policy_select_own_tenant" ON public.leave_policy
  FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());

CREATE POLICY "leave_policy_admin_write" ON public.leave_policy
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_any_role(auth.uid(), ARRAY['tenant_admin','igazgato','intezetvezeto']))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_any_role(auth.uid(), ARRAY['tenant_admin','igazgato','intezetvezeto']));

CREATE TRIGGER trg_leave_policy_updated BEFORE UPDATE ON public.leave_policy
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- 3) leave_entitlement
CREATE TABLE IF NOT EXISTS public.leave_entitlement (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  ev integer NOT NULL,
  jogcim text NOT NULL,
  jaro_nap numeric(6,2) NOT NULL DEFAULT 0,
  manual_korrekcio numeric(6,2) NOT NULL DEFAULT 0,
  athozott_nap numeric(6,2) NOT NULL DEFAULT 0,
  kiadott_nap numeric(6,2) NOT NULL DEFAULT 0,
  terv_nap numeric(6,2) NOT NULL DEFAULT 0,
  forced_taken_nap numeric(6,2) NOT NULL DEFAULT 0,
  hatralevo numeric(6,2) GENERATED ALWAYS AS (jaro_nap + manual_korrekcio + athozott_nap - kiadott_nap - terv_nap) STORED,
  lezart_at timestamptz,
  lezart_by uuid,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, user_id, ev, jogcim)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.leave_entitlement TO authenticated;
GRANT ALL ON public.leave_entitlement TO service_role;
ALTER TABLE public.leave_entitlement ENABLE ROW LEVEL SECURITY;

CREATE POLICY "leave_ent_select_own_or_hr" ON public.leave_entitlement
  FOR SELECT TO authenticated
  USING (
    tenant_id = public.current_tenant_id()
    AND (user_id = auth.uid()
         OR public.has_any_role(auth.uid(), ARRAY['tenant_admin','igazgato','intezetvezeto','beoszto','foorvos','telephelyvezeto']))
  );

CREATE POLICY "leave_ent_admin_write" ON public.leave_entitlement
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_any_role(auth.uid(), ARRAY['tenant_admin','igazgato','intezetvezeto','beoszto','foorvos']))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_any_role(auth.uid(), ARRAY['tenant_admin','igazgato','intezetvezeto','beoszto','foorvos']));

CREATE TRIGGER trg_leave_ent_updated BEFORE UPDATE ON public.leave_entitlement
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE INDEX IF NOT EXISTS idx_leave_ent_user_ev ON public.leave_entitlement (user_id, ev);
CREATE INDEX IF NOT EXISTS idx_leave_ent_tenant_ev ON public.leave_entitlement (tenant_id, ev);

-- 4) leave_carryover_log
CREATE TABLE IF NOT EXISTS public.leave_carryover_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  user_id uuid NOT NULL,
  from_year integer NOT NULL,
  to_year integer,
  jogcim text NOT NULL,
  nap numeric(6,2) NOT NULL,
  tipus text NOT NULL CHECK (tipus IN ('carryover','forced_takeout','forfeit','manual_adjust')),
  appointment_id uuid,
  megjegyzes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  created_by uuid
);

GRANT SELECT, INSERT ON public.leave_carryover_log TO authenticated;
GRANT ALL ON public.leave_carryover_log TO service_role;
ALTER TABLE public.leave_carryover_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "leave_log_select_own_or_hr" ON public.leave_carryover_log
  FOR SELECT TO authenticated
  USING (
    tenant_id = public.current_tenant_id()
    AND (user_id = auth.uid()
         OR public.has_any_role(auth.uid(), ARRAY['tenant_admin','igazgato','intezetvezeto','beoszto','foorvos']))
  );

CREATE POLICY "leave_log_insert_hr" ON public.leave_carryover_log
  FOR INSERT TO authenticated
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_any_role(auth.uid(), ARRAY['tenant_admin','igazgato','intezetvezeto','beoszto','foorvos']));

CREATE INDEX IF NOT EXISTS idx_leave_log_user ON public.leave_carryover_log (user_id, from_year);

-- 5) recalc függvény (jogcímenkénti járó nap)
CREATE OR REPLACE FUNCTION public.recalc_leave_entitlements(_user_id uuid, _ev integer)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $fn$
DECLARE
  v_prof RECORD;
  v_pol  RECORD;
  v_tenant uuid;
  v_age int;
  v_eletkor_nap numeric := 0;
  v_kor_szabaly jsonb;
  v_gyermek_alap int := 0;
  v_gyermek_fogy int := 0;
  v_gyermek_nap int := 0;
  v_emp RECORD;
  v_jogviszony text;
  v_eu_alap int := 20;
  v_oktatoi_nap int := 0;
  v_vezetoi_nap int := 0;
  v_sugar_nap int := 0;
  v_alap int := 20;
  v_full_year_days int;
  v_worked_days int;
  v_arany numeric := 1;
  v_kid jsonb;
  v_now date := make_date(_ev, 12, 31);
BEGIN
  SELECT * INTO v_prof FROM public.profiles WHERE id = _user_id;
  IF NOT FOUND THEN RETURN; END IF;
  v_tenant := v_prof.tenant_id;

  SELECT * INTO v_pol FROM public.leave_policy WHERE tenant_id = v_tenant AND ev = _ev;
  IF NOT FOUND THEN
    INSERT INTO public.leave_policy (tenant_id, ev) VALUES (v_tenant, _ev)
    ON CONFLICT (tenant_id, ev) DO NOTHING;
    SELECT * INTO v_pol FROM public.leave_policy WHERE tenant_id = v_tenant AND ev = _ev;
  END IF;

  -- elsődleges jogviszony
  SELECT * INTO v_emp FROM public.profile_employment
    WHERE user_id = _user_id AND COALESCE(ervenyes,true)=true
    ORDER BY elsodleges DESC NULLS LAST, kezdo_datum DESC NULLS LAST LIMIT 1;
  v_jogviszony := COALESCE(v_emp.jogviszony_tipus::text, 'munka_tv_kv');

  -- alapszabadság
  IF v_jogviszony = 'egeszsegugyi_szolgalati' THEN
    v_alap := COALESCE((v_pol.eu_alap->>'alap')::int, 20);
    IF v_prof.kjt_fizetesi_osztaly IS NOT NULL AND v_prof.kjt_fizetesi_osztaly ~ '^[E-J]' THEN
      v_alap := COALESCE((v_pol.eu_alap->>'felsofoku')::int, 21);
    END IF;
  ELSIF v_jogviszony = 'kjt_kozalkalmazott' THEN
    v_alap := CASE WHEN v_prof.kjt_fizetesi_osztaly IS NOT NULL AND v_prof.kjt_fizetesi_osztaly ~ '^[E-J]' THEN 21 ELSE 20 END;
  ELSE
    v_alap := v_pol.alapszabadsag_mt;
  END IF;

  -- életkori
  IF v_prof.szuletesi_datum IS NOT NULL THEN
    v_age := _ev - EXTRACT(year FROM v_prof.szuletesi_datum)::int;
    FOR v_kor_szabaly IN SELECT jsonb_array_elements(v_pol.eletkor_pot) LOOP
      IF v_age >= (v_kor_szabaly->>'kor')::int THEN
        v_eletkor_nap := GREATEST(v_eletkor_nap, (v_kor_szabaly->>'nap')::numeric);
      END IF;
    END LOOP;
  END IF;

  -- gyermek pótszabadság
  IF jsonb_typeof(v_prof.gyermek_szamok) = 'array' THEN
    FOR v_kid IN SELECT jsonb_array_elements(v_prof.gyermek_szamok) LOOP
      DECLARE
        d_birth date := NULLIF(v_kid->>'szuletes','')::date;
        d_age int;
      BEGIN
        IF d_birth IS NULL THEN CONTINUE; END IF;
        d_age := _ev - EXTRACT(year FROM d_birth)::int;
        IF d_age <= 16 AND _ev >= EXTRACT(year FROM d_birth)::int THEN
          v_gyermek_alap := v_gyermek_alap + 1;
          IF COALESCE((v_kid->>'fogyatekos')::boolean, false) THEN
            v_gyermek_fogy := v_gyermek_fogy + 1;
          END IF;
        END IF;
      END;
    END LOOP;
    v_gyermek_nap := CASE
      WHEN v_gyermek_alap = 0 THEN 0
      WHEN v_gyermek_alap = 1 THEN COALESCE((v_pol.gyermek_pot->>'1')::int, 2)
      WHEN v_gyermek_alap = 2 THEN COALESCE((v_pol.gyermek_pot->>'2')::int, 4)
      ELSE COALESCE((v_pol.gyermek_pot->>'3+')::int, 7)
    END + v_gyermek_fogy * COALESCE((v_pol.gyermek_pot->>'fogyatekos_plusz')::int, 2);
  END IF;

  -- vezetői vs oktatói (halmozódás: a magasabb)
  IF COALESCE(v_emp.vezetoi_szint, v_prof.vezetoi_szint) = 'magasabb_vezeto' THEN
    v_vezetoi_nap := v_pol.vezeto_magas_pot;
  ELSIF COALESCE(v_emp.vezetoi_szint, v_prof.vezetoi_szint) = 'vezeto' THEN
    v_vezetoi_nap := v_pol.vezeto_pot;
  END IF;

  IF v_prof.oktatoi_munkakor THEN
    v_oktatoi_nap := v_pol.oktatoi_max;
  END IF;

  -- a magasabbat tartjuk meg külön sorként, a kisebbet 0-ra
  IF v_vezetoi_nap >= v_oktatoi_nap THEN
    v_oktatoi_nap := 0;
  ELSE
    v_vezetoi_nap := 0;
  END IF;

  -- sugár pótszabadság
  IF v_prof.sugarterheles_kategoria IS NOT NULL THEN
    v_sugar_nap := v_pol.sugar_pot;
  END IF;

  -- arányosítás belépés/kilépés alapján
  v_full_year_days := (make_date(_ev,12,31) - make_date(_ev,1,1)) + 1;
  v_worked_days := v_full_year_days;
  IF v_prof.belepes_datum IS NOT NULL AND EXTRACT(year FROM v_prof.belepes_datum)::int = _ev THEN
    v_worked_days := (make_date(_ev,12,31) - v_prof.belepes_datum) + 1;
  END IF;
  v_arany := v_worked_days::numeric / v_full_year_days::numeric;

  -- upsert jogcímek
  PERFORM public._upsert_leave_ent(v_tenant, _user_id, _ev, 'alap', ROUND(v_alap * v_arany, 2));
  PERFORM public._upsert_leave_ent(v_tenant, _user_id, _ev, 'eletkor', ROUND(v_eletkor_nap * v_arany, 2));
  PERFORM public._upsert_leave_ent(v_tenant, _user_id, _ev, 'gyermek', ROUND(v_gyermek_nap * v_arany, 2));
  PERFORM public._upsert_leave_ent(v_tenant, _user_id, _ev, 'vezetoi', ROUND(v_vezetoi_nap * v_arany, 2));
  PERFORM public._upsert_leave_ent(v_tenant, _user_id, _ev, 'oktatoi', ROUND(v_oktatoi_nap * v_arany, 2));
  PERFORM public._upsert_leave_ent(v_tenant, _user_id, _ev, 'sugar', ROUND(v_sugar_nap * v_arany, 2));
END;
$fn$;

CREATE OR REPLACE FUNCTION public._upsert_leave_ent(_t uuid, _u uuid, _ev int, _jc text, _jaro numeric)
RETURNS void
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  INSERT INTO public.leave_entitlement (tenant_id, user_id, ev, jogcim, jaro_nap)
  VALUES (_t, _u, _ev, _jc, _jaro)
  ON CONFLICT (tenant_id, user_id, ev, jogcim)
  DO UPDATE SET jaro_nap = EXCLUDED.jaro_nap, updated_at = now();
$$;

-- 6) profile_unavailability trigger: kiadott_nap/terv_nap update
CREATE OR REPLACE FUNCTION public.leave_apply_unavailability()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $fn$
DECLARE
  v_ev int;
  v_napok numeric;
  v_jogcim text;
  v_tenant uuid;
  v_user uuid;
  v_old_status text;
  v_new_status text;
BEGIN
  IF TG_OP = 'DELETE' THEN
    IF OLD.tipus::text <> 'szabadsag' THEN RETURN OLD; END IF;
    v_ev := COALESCE(OLD.forrasev, EXTRACT(year FROM OLD.kezdo_datum)::int);
    v_napok := COALESCE(OLD.nap_szam, (OLD.zaro_datum - OLD.kezdo_datum + 1)::numeric);
    v_jogcim := COALESCE(OLD.jogcim, 'alap');
    IF OLD.status::text = 'jovahagyott' THEN
      UPDATE public.leave_entitlement SET kiadott_nap = GREATEST(0, kiadott_nap - v_napok)
       WHERE tenant_id = OLD.tenant_id AND user_id = OLD.user_id AND ev = v_ev AND jogcim = v_jogcim;
    ELSIF OLD.status::text IN ('tervezett','jovahagyasra_var') THEN
      UPDATE public.leave_entitlement SET terv_nap = GREATEST(0, terv_nap - v_napok)
       WHERE tenant_id = OLD.tenant_id AND user_id = OLD.user_id AND ev = v_ev AND jogcim = v_jogcim;
    END IF;
    RETURN OLD;
  END IF;

  IF NEW.tipus::text <> 'szabadsag' THEN RETURN NEW; END IF;

  -- napszám automatikus számítás munkanapokban (egyszerű: hétvégét levonjuk)
  IF NEW.nap_szam IS NULL THEN
    SELECT COUNT(*)::numeric INTO v_napok
      FROM generate_series(NEW.kezdo_datum, NEW.zaro_datum, interval '1 day') d
      WHERE EXTRACT(isodow FROM d) < 6;
    NEW.nap_szam := v_napok;
  ELSE
    v_napok := NEW.nap_szam;
  END IF;

  IF NEW.forrasev IS NULL THEN
    NEW.forrasev := EXTRACT(year FROM NEW.kezdo_datum)::int;
  END IF;
  v_ev := NEW.forrasev;
  v_jogcim := COALESCE(NEW.jogcim, 'alap');

  IF TG_OP = 'INSERT' THEN
    -- biztosítsuk hogy van entitlement sor
    INSERT INTO public.leave_entitlement (tenant_id, user_id, ev, jogcim, jaro_nap)
    VALUES (NEW.tenant_id, NEW.user_id, v_ev, v_jogcim, 0)
    ON CONFLICT (tenant_id, user_id, ev, jogcim) DO NOTHING;

    IF NEW.status::text = 'jovahagyott' THEN
      UPDATE public.leave_entitlement SET kiadott_nap = kiadott_nap + v_napok
       WHERE tenant_id = NEW.tenant_id AND user_id = NEW.user_id AND ev = v_ev AND jogcim = v_jogcim;
    ELSIF NEW.status::text IN ('tervezett','jovahagyasra_var') THEN
      UPDATE public.leave_entitlement SET terv_nap = terv_nap + v_napok
       WHERE tenant_id = NEW.tenant_id AND user_id = NEW.user_id AND ev = v_ev AND jogcim = v_jogcim;
    END IF;
  ELSIF TG_OP = 'UPDATE' THEN
    -- visszavonjuk a régit, alkalmazzuk az újat
    DECLARE
      old_napok numeric := COALESCE(OLD.nap_szam, (OLD.zaro_datum - OLD.kezdo_datum + 1)::numeric);
      old_ev int := COALESCE(OLD.forrasev, EXTRACT(year FROM OLD.kezdo_datum)::int);
      old_jc text := COALESCE(OLD.jogcim, 'alap');
    BEGIN
      IF OLD.status::text = 'jovahagyott' THEN
        UPDATE public.leave_entitlement SET kiadott_nap = GREATEST(0, kiadott_nap - old_napok)
          WHERE tenant_id = OLD.tenant_id AND user_id = OLD.user_id AND ev = old_ev AND jogcim = old_jc;
      ELSIF OLD.status::text IN ('tervezett','jovahagyasra_var') THEN
        UPDATE public.leave_entitlement SET terv_nap = GREATEST(0, terv_nap - old_napok)
          WHERE tenant_id = OLD.tenant_id AND user_id = OLD.user_id AND ev = old_ev AND jogcim = old_jc;
      END IF;
    END;

    INSERT INTO public.leave_entitlement (tenant_id, user_id, ev, jogcim, jaro_nap)
    VALUES (NEW.tenant_id, NEW.user_id, v_ev, v_jogcim, 0)
    ON CONFLICT (tenant_id, user_id, ev, jogcim) DO NOTHING;

    IF NEW.status::text = 'jovahagyott' THEN
      UPDATE public.leave_entitlement SET kiadott_nap = kiadott_nap + v_napok
       WHERE tenant_id = NEW.tenant_id AND user_id = NEW.user_id AND ev = v_ev AND jogcim = v_jogcim;
    ELSIF NEW.status::text IN ('tervezett','jovahagyasra_var') THEN
      UPDATE public.leave_entitlement SET terv_nap = terv_nap + v_napok
       WHERE tenant_id = NEW.tenant_id AND user_id = NEW.user_id AND ev = v_ev AND jogcim = v_jogcim;
    END IF;
  END IF;

  RETURN NEW;
END;
$fn$;

DROP TRIGGER IF EXISTS trg_leave_apply_unavail ON public.profile_unavailability;
CREATE TRIGGER trg_leave_apply_unavail
  BEFORE INSERT OR UPDATE OR DELETE ON public.profile_unavailability
  FOR EACH ROW EXECUTE FUNCTION public.leave_apply_unavailability();

-- 7) closeYear / enforceForcedTakeout helper függvények
CREATE OR REPLACE FUNCTION public.close_leave_year(_tenant uuid, _ev int, _actor uuid)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $fn$
DECLARE
  v_rec RECORD;
  v_cnt int := 0;
  v_pol RECORD;
  v_max_carry numeric;
BEGIN
  SELECT * INTO v_pol FROM public.leave_policy WHERE tenant_id = _tenant AND ev = _ev;

  FOR v_rec IN
    SELECT * FROM public.leave_entitlement
    WHERE tenant_id = _tenant AND ev = _ev AND hatralevo > 0 AND lezart_at IS NULL
  LOOP
    v_max_carry := v_rec.hatralevo;
    -- alapszabadság 1/4 korlát (Mt. 123. §) ha be van kapcsolva
    IF v_rec.jogcim = 'alap' AND COALESCE(v_pol.max_carryover_alap_quarter, true) THEN
      v_max_carry := LEAST(v_rec.hatralevo, ROUND(v_rec.jaro_nap / 4.0, 2));
    END IF;

    INSERT INTO public.leave_entitlement (tenant_id, user_id, ev, jogcim, jaro_nap, athozott_nap)
    VALUES (_tenant, v_rec.user_id, _ev + 1, v_rec.jogcim, 0, v_max_carry)
    ON CONFLICT (tenant_id, user_id, ev, jogcim)
    DO UPDATE SET athozott_nap = public.leave_entitlement.athozott_nap + v_max_carry, updated_at = now();

    INSERT INTO public.leave_carryover_log (tenant_id, user_id, from_year, to_year, jogcim, nap, tipus, created_by, megjegyzes)
    VALUES (_tenant, v_rec.user_id, _ev, _ev + 1, v_rec.jogcim, v_max_carry, 'carryover', _actor,
            CASE WHEN v_max_carry < v_rec.hatralevo THEN format('Korlát: %s nap nem hozható át', v_rec.hatralevo - v_max_carry) ELSE NULL END);

    IF v_max_carry < v_rec.hatralevo THEN
      INSERT INTO public.leave_carryover_log (tenant_id, user_id, from_year, jogcim, nap, tipus, created_by, megjegyzes)
      VALUES (_tenant, v_rec.user_id, _ev, v_rec.jogcim, v_rec.hatralevo - v_max_carry, 'forfeit', _actor, 'Mt. 123. § alap 1/4 korlát');
    END IF;

    UPDATE public.leave_entitlement SET lezart_at = now(), lezart_by = _actor WHERE id = v_rec.id;
    v_cnt := v_cnt + 1;
  END LOOP;

  RETURN v_cnt;
END;
$fn$;

CREATE OR REPLACE FUNCTION public.enforce_forced_leave_takeout(_tenant uuid, _ev int, _actor uuid, _dry_run boolean DEFAULT false)
RETURNS TABLE(user_id uuid, jogcim text, nap numeric, kezdo date, zaro date, applied boolean)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $fn$
DECLARE
  v_rec RECORD;
  v_start date;
  v_end date;
  v_uid uuid;
  v_napok numeric;
BEGIN
  FOR v_rec IN
    SELECT * FROM public.leave_entitlement
    WHERE tenant_id = _tenant AND ev = _ev + 1
      AND athozott_nap > 0
      AND athozott_nap > (kiadott_nap + forced_taken_nap)
  LOOP
    v_napok := v_rec.athozott_nap - v_rec.kiadott_nap - v_rec.forced_taken_nap;
    IF v_napok <= 0 THEN CONTINUE; END IF;

    -- következő hétköznap
    v_start := CURRENT_DATE;
    WHILE EXTRACT(isodow FROM v_start) > 5 LOOP v_start := v_start + 1; END LOOP;
    v_end := v_start;
    DECLARE
      added numeric := 1;
    BEGIN
      WHILE added < v_napok LOOP
        v_end := v_end + 1;
        IF EXTRACT(isodow FROM v_end) < 6 THEN added := added + 1; END IF;
      END LOOP;
    END;

    user_id := v_rec.user_id;
    jogcim := v_rec.jogcim;
    nap := v_napok;
    kezdo := v_start;
    zaro := v_end;
    applied := NOT _dry_run;

    IF NOT _dry_run THEN
      INSERT INTO public.profile_unavailability
        (tenant_id, user_id, tipus, kezdo_datum, zaro_datum, leiras, status, is_kenyszer, forrasev, jogcim, nap_szam, jovahagyo_id, jovahagyas_at, jovahagyas_indok)
      VALUES (_tenant, v_rec.user_id, 'szabadsag', v_start, v_end,
              format('Előző évi szabadság kényszerkiadása (%s)', _ev),
              'jovahagyott', true, _ev, v_rec.jogcim, v_napok, _actor, now(),
              'Mt./Eszjtv. — tárgyévet követő január 30. határidő');

      UPDATE public.leave_entitlement SET forced_taken_nap = forced_taken_nap + v_napok
        WHERE id = v_rec.id;

      INSERT INTO public.leave_carryover_log (tenant_id, user_id, from_year, to_year, jogcim, nap, tipus, created_by, megjegyzes)
      VALUES (_tenant, v_rec.user_id, _ev, _ev + 1, v_rec.jogcim, v_napok, 'forced_takeout', _actor,
              format('Kényszerkiadás %s — %s', v_start, v_end));
    END IF;

    RETURN NEXT;
  END LOOP;
END;
$fn$;
