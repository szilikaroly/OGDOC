
-- 1) Alskála-pontszámok perzisztálása
ALTER TABLE public.questionnaire_responses
  ADD COLUMN IF NOT EXISTS subscale_scores jsonb NOT NULL DEFAULT '{}'::jsonb;

CREATE INDEX IF NOT EXISTS idx_qr_subscale_scores
  ON public.questionnaire_responses USING gin (subscale_scores);

CREATE INDEX IF NOT EXISTS idx_qr_patient_created
  ON public.questionnaire_responses (patient_id, created_at DESC);

-- 2) Bővített automatikus alert-trigger: bucket-küszöbök minden szabad licencű skálához.
CREATE OR REPLACE FUNCTION public.qr_critical_alert_fn()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
  v_code text;
  v_title text;
  v_sex text;
  v_auditc_cutoff numeric;
  v_phq2 numeric;
  v_gad2 numeric;
  v_who5_index numeric;
  v_alert_type text;
  v_severity text;
BEGIN
  SELECT code, title INTO v_code, v_title FROM public.questionnaires WHERE id = NEW.questionnaire_id;

  -- PHQ-9 #9 (öngyilkossági gondolat) — meglévő logika megtartva
  IF NEW.critical_triggered THEN
    INSERT INTO public.critical_result_alerts (tenant_id, response_id, patient_id, appointment_id, alert_type, severity)
    VALUES (NEW.tenant_id, NEW.id, NEW.patient_id, NEW.appointment_id,
            CASE WHEN v_code = 'PHQ9' THEN 'suicidal_ideation' ELSE 'critical_screening' END,
            COALESCE(NEW.severity, 'severe'));
  END IF;

  -- PHQ-9 közepes+ (≥10) — klinikus felülvizsgálat
  IF v_code = 'PHQ9' AND NEW.total_score IS NOT NULL AND NEW.total_score >= 10 THEN
    INSERT INTO public.critical_result_alerts (tenant_id, response_id, patient_id, appointment_id, alert_type, severity)
    VALUES (NEW.tenant_id, NEW.id, NEW.patient_id, NEW.appointment_id,
            'depresszio_kozepes_plus',
            CASE WHEN NEW.total_score >= 20 THEN 'high'
                 WHEN NEW.total_score >= 15 THEN 'medium'
                 ELSE 'low' END);
  END IF;

  -- GAD-7 súlyos (≥15)
  IF v_code = 'GAD7' AND NEW.total_score IS NOT NULL AND NEW.total_score >= 15 THEN
    INSERT INTO public.critical_result_alerts (tenant_id, response_id, patient_id, appointment_id, alert_type, severity)
    VALUES (NEW.tenant_id, NEW.id, NEW.patient_id, NEW.appointment_id,
            'szorongas_sulyos', 'high');
  END IF;

  -- PHQ-4 alskálák ≥3 → "follow-up javasolt"
  IF v_code = 'PHQ4' THEN
    v_phq2 := COALESCE((NEW.subscale_scores->>'phq2')::numeric, NULL);
    v_gad2 := COALESCE((NEW.subscale_scores->>'gad2')::numeric, NULL);
    IF v_phq2 IS NOT NULL AND v_phq2 >= 3 THEN
      INSERT INTO public.critical_result_alerts (tenant_id, response_id, patient_id, appointment_id, alert_type, severity)
      VALUES (NEW.tenant_id, NEW.id, NEW.patient_id, NEW.appointment_id, 'phq2_pozitiv', 'low');
    END IF;
    IF v_gad2 IS NOT NULL AND v_gad2 >= 3 THEN
      INSERT INTO public.critical_result_alerts (tenant_id, response_id, patient_id, appointment_id, alert_type, severity)
      VALUES (NEW.tenant_id, NEW.id, NEW.patient_id, NEW.appointment_id, 'gad2_pozitiv', 'low');
    END IF;
  END IF;

  -- WHO-5 index < 50 → jóllét-csökkenés
  IF v_code = 'WHO5' THEN
    v_who5_index := COALESCE((NEW.subscale_scores->>'who5_index')::numeric, NEW.total_score);
    IF v_who5_index IS NOT NULL AND v_who5_index < 50 THEN
      INSERT INTO public.critical_result_alerts (tenant_id, response_id, patient_id, appointment_id, alert_type, severity)
      VALUES (NEW.tenant_id, NEW.id, NEW.patient_id, NEW.appointment_id,
              'jollet_csokkent',
              CASE WHEN v_who5_index < 28 THEN 'medium' ELSE 'low' END);
    END IF;
  END IF;

  -- AUDIT-C pozitív (nemi küszöb a pácienstől: férfi 4, nő 3, ismeretlen 4)
  IF v_code = 'AUDITC' AND NEW.total_score IS NOT NULL AND NEW.patient_id IS NOT NULL THEN
    SELECT lower(nem) INTO v_sex FROM public.patients WHERE id = NEW.patient_id;
    v_auditc_cutoff := CASE WHEN v_sex IN ('no','nő','female','f') THEN 3 ELSE 4 END;
    IF NEW.total_score >= v_auditc_cutoff THEN
      INSERT INTO public.critical_result_alerts (tenant_id, response_id, patient_id, appointment_id, alert_type, severity)
      VALUES (NEW.tenant_id, NEW.id, NEW.patient_id, NEW.appointment_id,
              'auditc_pozitiv',
              CASE WHEN NEW.total_score >= 8 THEN 'medium' ELSE 'low' END);
    END IF;
  END IF;

  -- AUDIT teljes ≥16 (káros ivás) / ≥20 (függőség gyanú)
  IF v_code = 'AUDIT' AND NEW.total_score IS NOT NULL THEN
    IF NEW.total_score >= 20 THEN
      INSERT INTO public.critical_result_alerts (tenant_id, response_id, patient_id, appointment_id, alert_type, severity)
      VALUES (NEW.tenant_id, NEW.id, NEW.patient_id, NEW.appointment_id, 'audit_fuggoseg_gyanu', 'high');
    ELSIF NEW.total_score >= 16 THEN
      INSERT INTO public.critical_result_alerts (tenant_id, response_id, patient_id, appointment_id, alert_type, severity)
      VALUES (NEW.tenant_id, NEW.id, NEW.patient_id, NEW.appointment_id, 'audit_karos_ivas', 'medium');
    END IF;
  END IF;

  RETURN NEW;
END
$function$;
