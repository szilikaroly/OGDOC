
-- séma-bővítés
ALTER TABLE public.questionnaires
  ADD COLUMN IF NOT EXISTS kioszk_eligible boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS becsult_perc int NULL;

-- globális (tenant nélküli) kérdőív-bank parciális egyedi index
CREATE UNIQUE INDEX IF NOT EXISTS uq_questionnaires_global_code_lang
  ON public.questionnaires (code, language)
  WHERE tenant_id IS NULL;

DO $$ BEGIN
  CREATE TYPE public.assignment_kind AS ENUM ('varakozas','periodikus','egyedi','foglalashoz');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

ALTER TABLE public.questionnaire_assignments
  ADD COLUMN IF NOT EXISTS kind public.assignment_kind NOT NULL DEFAULT 'egyedi';

CREATE INDEX IF NOT EXISTS idx_qassign_kind_status
  ON public.questionnaire_assignments(kind, status);

CREATE TABLE IF NOT EXISTS public.questionnaire_schedules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  questionnaire_id uuid NOT NULL REFERENCES public.questionnaires(id) ON DELETE CASCADE,
  monitoring_program_id uuid NULL REFERENCES public.monitoring_programs(id) ON DELETE CASCADE,
  patient_id uuid NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  scope text NOT NULL DEFAULT 'program',
  interval_days int NOT NULL CHECK (interval_days BETWEEN 1 AND 365),
  next_due_at timestamptz NULL,
  last_run_at timestamptz NULL,
  aktiv boolean NOT NULL DEFAULT true,
  beallito_id uuid NULL,
  megjegyzes text NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_qsched_tenant ON public.questionnaire_schedules(tenant_id);
CREATE INDEX IF NOT EXISTS idx_qsched_program ON public.questionnaire_schedules(monitoring_program_id);
CREATE INDEX IF NOT EXISTS idx_qsched_due ON public.questionnaire_schedules(next_due_at) WHERE aktiv = true;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.questionnaire_schedules TO authenticated;
GRANT ALL ON public.questionnaire_schedules TO service_role;
ALTER TABLE public.questionnaire_schedules ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "tenant_isolation_qsched" ON public.questionnaire_schedules;
CREATE POLICY "tenant_isolation_qsched" ON public.questionnaire_schedules
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id())
  WITH CHECK (tenant_id = public.current_tenant_id());
DROP POLICY IF EXISTS "service_role_qsched" ON public.questionnaire_schedules;
CREATE POLICY "service_role_qsched" ON public.questionnaire_schedules
  FOR ALL TO service_role USING (true) WITH CHECK (true);
DROP TRIGGER IF EXISTS trg_qsched_touch ON public.questionnaire_schedules;
CREATE TRIGGER trg_qsched_touch BEFORE UPDATE ON public.questionnaire_schedules
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- ============================================================
-- Seed (tenant_id NULL = globális bank; ON CONFLICT parciális indexre)
-- ============================================================

-- PHQ-9
INSERT INTO public.questionnaires (code, title, leiras, language, items, scoring, cutoffs, licenc, mode, critical_item_index, critical_threshold, kioszk_eligible, becsult_perc, aktiv)
VALUES ('PHQ9', 'PHQ-9 — Depresszió szűrő',
'Az elmúlt 2 hét során milyen gyakran zavarták Önt a következő problémák?', 'hu',
jsonb_build_object(
  'lead_in_hu', 'Az elmúlt 2 hét során milyen gyakran zavarták Önt a következő problémák?',
  'lead_in_en', 'Over the last 2 weeks, how often have you been bothered by any of the following problems?',
  'scale', jsonb_build_array(
    jsonb_build_object('value',0,'hu','Egyáltalán nem','en','Not at all'),
    jsonb_build_object('value',1,'hu','Néhány napon','en','Several days'),
    jsonb_build_object('value',2,'hu','A napok több mint felében','en','More than half the days'),
    jsonb_build_object('value',3,'hu','Majdnem minden nap','en','Nearly every day')
  ),
  'questions', jsonb_build_array(
    jsonb_build_object('idx',1,'hu','Kevés érdeklődés vagy öröm a tevékenységekben','en','Little interest or pleasure in doing things'),
    jsonb_build_object('idx',2,'hu','Levertség, lehangoltság vagy reménytelenség érzése','en','Feeling down, depressed, or hopeless'),
    jsonb_build_object('idx',3,'hu','Elalvási vagy átalvási nehézség, vagy túl sok alvás','en','Trouble falling/staying asleep, or sleeping too much'),
    jsonb_build_object('idx',4,'hu','Fáradtság vagy kevés energia','en','Feeling tired or having little energy'),
    jsonb_build_object('idx',5,'hu','Étvágytalanság vagy túlevés','en','Poor appetite or overeating'),
    jsonb_build_object('idx',6,'hu','Rossz véleménnyel van önmagáról','en','Feeling bad about yourself / failure'),
    jsonb_build_object('idx',7,'hu','Koncentrálási nehézség','en','Trouble concentrating'),
    jsonb_build_object('idx',8,'hu','Olyan lassú mozgás/beszéd vagy szokatlan nyugtalanság','en','Moving/speaking slowly or restless'),
    jsonb_build_object('idx',9,'hu','Az a gondolat, hogy jobb lenne meghalni, vagy hogy kárt tenne magában','en','Thoughts of being better off dead or self-harm','critical',true)
  )
),
jsonb_build_object('type','sum','min',0,'max',27),
jsonb_build_object('bands', jsonb_build_array(
  jsonb_build_object('min',0,'max',4,'severity','minimalis'),
  jsonb_build_object('min',5,'max',9,'severity','enyhe'),
  jsonb_build_object('min',10,'max',14,'severity','kozepes'),
  jsonb_build_object('min',15,'max',19,'severity','kozepesen_sulyos'),
  jsonb_build_object('min',20,'max',27,'severity','sulyos')
), 'positive_cutoff', 10),
'free','klinikai', 9, 1, true, 3, true)
ON CONFLICT (code, language) WHERE tenant_id IS NULL DO UPDATE SET
  title=EXCLUDED.title, items=EXCLUDED.items, scoring=EXCLUDED.scoring, cutoffs=EXCLUDED.cutoffs,
  critical_item_index=EXCLUDED.critical_item_index, critical_threshold=EXCLUDED.critical_threshold,
  kioszk_eligible=EXCLUDED.kioszk_eligible, becsult_perc=EXCLUDED.becsult_perc, aktiv=EXCLUDED.aktiv;

-- GAD-7
INSERT INTO public.questionnaires (code, title, leiras, language, items, scoring, cutoffs, licenc, mode, kioszk_eligible, becsult_perc, aktiv)
VALUES ('GAD7', 'GAD-7 — Generalizált szorongás szűrő',
'Az elmúlt 2 hét során milyen gyakran zavarták Önt a következő problémák?', 'hu',
jsonb_build_object(
  'lead_in_hu','Az elmúlt 2 hét során milyen gyakran zavarták Önt a következő problémák?',
  'lead_in_en','Over the last 2 weeks, how often have you been bothered by the following problems?',
  'scale', jsonb_build_array(
    jsonb_build_object('value',0,'hu','Egyáltalán nem','en','Not at all'),
    jsonb_build_object('value',1,'hu','Néhány napon','en','Several days'),
    jsonb_build_object('value',2,'hu','A napok több mint felében','en','More than half the days'),
    jsonb_build_object('value',3,'hu','Majdnem minden nap','en','Nearly every day')
  ),
  'questions', jsonb_build_array(
    jsonb_build_object('idx',1,'hu','Idegesség, szorongás vagy feszültség érzése','en','Feeling nervous, anxious, or on edge'),
    jsonb_build_object('idx',2,'hu','Képtelenség abbahagyni vagy kontrollálni az aggódást','en','Not being able to stop or control worrying'),
    jsonb_build_object('idx',3,'hu','Túlzott aggódás különböző dolgok miatt','en','Worrying too much about different things'),
    jsonb_build_object('idx',4,'hu','Nehézség az ellazulásban','en','Trouble relaxing'),
    jsonb_build_object('idx',5,'hu','Olyan nyugtalanság, hogy nehéz nyugton maradni','en','Being so restless that it is hard to sit still'),
    jsonb_build_object('idx',6,'hu','Könnyen bosszússá vagy ingerlékennyé válás','en','Becoming easily annoyed or irritable'),
    jsonb_build_object('idx',7,'hu','Félelem, mintha valami szörnyűség történne','en','Feeling afraid as if something awful might happen')
  )
),
jsonb_build_object('type','sum','min',0,'max',21),
jsonb_build_object('bands', jsonb_build_array(
  jsonb_build_object('min',0,'max',4,'severity','minimalis'),
  jsonb_build_object('min',5,'max',9,'severity','enyhe'),
  jsonb_build_object('min',10,'max',14,'severity','kozepes'),
  jsonb_build_object('min',15,'max',21,'severity','sulyos')
), 'positive_cutoff', 10),
'free','klinikai', true, 3, true)
ON CONFLICT (code, language) WHERE tenant_id IS NULL DO UPDATE SET
  title=EXCLUDED.title, items=EXCLUDED.items, scoring=EXCLUDED.scoring, cutoffs=EXCLUDED.cutoffs,
  kioszk_eligible=EXCLUDED.kioszk_eligible, becsult_perc=EXCLUDED.becsult_perc, aktiv=EXCLUDED.aktiv;

-- PHQ-4
INSERT INTO public.questionnaires (code, title, leiras, language, items, scoring, cutoffs, licenc, mode, kioszk_eligible, becsult_perc, aktiv)
VALUES ('PHQ4', 'PHQ-4 — Ultrarövid distressz-szűrő',
'Az elmúlt 2 hét során milyen gyakran zavarták Önt a következő problémák?', 'hu',
jsonb_build_object(
  'lead_in_hu','Az elmúlt 2 hét során milyen gyakran zavarták Önt a következő problémák?',
  'scale', jsonb_build_array(
    jsonb_build_object('value',0,'hu','Egyáltalán nem','en','Not at all'),
    jsonb_build_object('value',1,'hu','Néhány napon','en','Several days'),
    jsonb_build_object('value',2,'hu','A napok több mint felében','en','More than half the days'),
    jsonb_build_object('value',3,'hu','Majdnem minden nap','en','Nearly every day')
  ),
  'questions', jsonb_build_array(
    jsonb_build_object('idx',1,'subscale','PHQ2','hu','Kevés érdeklődés vagy öröm a tevékenységekben','en','Little interest or pleasure'),
    jsonb_build_object('idx',2,'subscale','PHQ2','hu','Levertség, lehangoltság vagy reménytelenség','en','Feeling down, depressed, hopeless'),
    jsonb_build_object('idx',3,'subscale','GAD2','hu','Idegesség, szorongás vagy feszültség','en','Feeling nervous, anxious, on edge'),
    jsonb_build_object('idx',4,'subscale','GAD2','hu','Képtelenség abbahagyni vagy kontrollálni az aggódást','en','Not being able to control worrying')
  )
),
jsonb_build_object('type','sum_with_subscales','min',0,'max',12,
  'subscales', jsonb_build_array(
    jsonb_build_object('key','PHQ2','items', jsonb_build_array(1,2), 'positive_cutoff', 3),
    jsonb_build_object('key','GAD2','items', jsonb_build_array(3,4), 'positive_cutoff', 3)
  )
),
jsonb_build_object('bands', jsonb_build_array(
  jsonb_build_object('min',0,'max',2,'severity','normal'),
  jsonb_build_object('min',3,'max',5,'severity','enyhe'),
  jsonb_build_object('min',6,'max',8,'severity','kozepes'),
  jsonb_build_object('min',9,'max',12,'severity','sulyos')
)),
'free','klinikai', true, 1, true)
ON CONFLICT (code, language) WHERE tenant_id IS NULL DO UPDATE SET
  title=EXCLUDED.title, items=EXCLUDED.items, scoring=EXCLUDED.scoring, cutoffs=EXCLUDED.cutoffs,
  kioszk_eligible=EXCLUDED.kioszk_eligible, becsult_perc=EXCLUDED.becsult_perc, aktiv=EXCLUDED.aktiv;

-- AUDIT
INSERT INTO public.questionnaires (code, title, leiras, language, items, scoring, cutoffs, licenc, mode, kioszk_eligible, becsult_perc, aktiv)
VALUES ('AUDIT', 'AUDIT — Alkoholhasználat-zavar szűrő',
'Egység = standard ital ≈ 10 g tiszta alkohol.', 'hu',
jsonb_build_object('questions', jsonb_build_array(
  jsonb_build_object('idx',1,'hu','Milyen gyakran fogyaszt alkoholt?','en','How often do you have a drink?',
    'options', jsonb_build_array('Soha','Havonta vagy ritkábban','Havi 2–4×','Heti 2–3×','Heti 4+×'),'scores', jsonb_build_array(0,1,2,3,4)),
  jsonb_build_object('idx',2,'hu','Egy átlagos ivós napon hány egységet fogyaszt?','en','Standard drinks on a typical day?',
    'options', jsonb_build_array('1–2','3–4','5–6','7–9','10+'),'scores', jsonb_build_array(0,1,2,3,4)),
  jsonb_build_object('idx',3,'hu','Milyen gyakran fogyaszt 6+ egységet egy alkalommal?','en','Six or more drinks on one occasion?',
    'options', jsonb_build_array('Soha','Havonta ritkábban','Havonta','Hetente','Naponta vagy majdnem'),'scores', jsonb_build_array(0,1,2,3,4)),
  jsonb_build_object('idx',4,'hu','Milyen gyakran nem tudta abbahagyni az ivást, miután elkezdte?','en','Unable to stop once started?',
    'options', jsonb_build_array('Soha','Havonta ritkábban','Havonta','Hetente','Naponta vagy majdnem'),'scores', jsonb_build_array(0,1,2,3,4)),
  jsonb_build_object('idx',5,'hu','Milyen gyakran nem tudta megtenni, amit elvártak Öntől az ivás miatt?','en','Failed to do what was expected?',
    'options', jsonb_build_array('Soha','Havonta ritkábban','Havonta','Hetente','Naponta vagy majdnem'),'scores', jsonb_build_array(0,1,2,3,4)),
  jsonb_build_object('idx',6,'hu','Milyen gyakran volt szüksége reggeli italra, hogy beinduljon?','en','Needed a first drink in the morning?',
    'options', jsonb_build_array('Soha','Havonta ritkábban','Havonta','Hetente','Naponta vagy majdnem'),'scores', jsonb_build_array(0,1,2,3,4)),
  jsonb_build_object('idx',7,'hu','Milyen gyakran érzett bűntudatot ivás után?','en','Guilt or remorse after drinking?',
    'options', jsonb_build_array('Soha','Havonta ritkábban','Havonta','Hetente','Naponta vagy majdnem'),'scores', jsonb_build_array(0,1,2,3,4)),
  jsonb_build_object('idx',8,'hu','Milyen gyakran nem emlékezett az előző estére az ivás miatt?','en','Unable to remember the night before?',
    'options', jsonb_build_array('Soha','Havonta ritkábban','Havonta','Hetente','Naponta vagy majdnem'),'scores', jsonb_build_array(0,1,2,3,4)),
  jsonb_build_object('idx',9,'hu','Megsérült-e Ön vagy más az Ön ivása következtében?','en','Anyone been injured?',
    'options', jsonb_build_array('Nem','Igen, de nem az utóbbi évben','Igen, az utóbbi évben'),'scores', jsonb_build_array(0,2,4)),
  jsonb_build_object('idx',10,'hu','Aggódott-e hozzátartozó vagy orvos az ivása miatt?','en','Has anyone been concerned?',
    'options', jsonb_build_array('Nem','Igen, de nem az utóbbi évben','Igen, az utóbbi évben'),'scores', jsonb_build_array(0,2,4))
)),
jsonb_build_object('type','sum_per_item_scores','min',0,'max',40),
jsonb_build_object('bands', jsonb_build_array(
  jsonb_build_object('min',0,'max',7,'severity','alacsony_kockazat'),
  jsonb_build_object('min',8,'max',15,'severity','kockazatos'),
  jsonb_build_object('min',16,'max',19,'severity','artalmas'),
  jsonb_build_object('min',20,'max',40,'severity','fuggoseg_gyanu')
), 'positive_cutoff', 8),
'free','klinikai', false, 5, true)
ON CONFLICT (code, language) WHERE tenant_id IS NULL DO UPDATE SET
  title=EXCLUDED.title, items=EXCLUDED.items, scoring=EXCLUDED.scoring, cutoffs=EXCLUDED.cutoffs, aktiv=EXCLUDED.aktiv;

-- AUDIT-C
INSERT INTO public.questionnaires (code, title, leiras, language, items, scoring, cutoffs, licenc, mode, kioszk_eligible, becsult_perc, aktiv)
VALUES ('AUDITC', 'AUDIT-C — Rövid alkoholfogyasztási szűrő',
'AUDIT első három tétele; nemfüggő küszöb.', 'hu',
jsonb_build_object('questions', jsonb_build_array(
  jsonb_build_object('idx',1,'hu','Milyen gyakran fogyaszt alkoholt?','en','How often do you have a drink?',
    'options', jsonb_build_array('Soha','Havonta vagy ritkábban','Havi 2–4×','Heti 2–3×','Heti 4+×'),'scores', jsonb_build_array(0,1,2,3,4)),
  jsonb_build_object('idx',2,'hu','Egy átlagos ivós napon hány egységet fogyaszt?','en','Standard drinks on a typical day?',
    'options', jsonb_build_array('1–2','3–4','5–6','7–9','10+'),'scores', jsonb_build_array(0,1,2,3,4)),
  jsonb_build_object('idx',3,'hu','Milyen gyakran fogyaszt 6+ egységet egy alkalommal?','en','Six or more drinks on one occasion?',
    'options', jsonb_build_array('Soha','Havonta ritkábban','Havonta','Hetente','Naponta vagy majdnem'),'scores', jsonb_build_array(0,1,2,3,4))
)),
jsonb_build_object('type','sum_per_item_scores','min',0,'max',12),
jsonb_build_object('bands', jsonb_build_array(
  jsonb_build_object('min',0,'max',2,'severity','alacsony'),
  jsonb_build_object('min',3,'max',12,'severity','pozitiv')
), 'positive_cutoff_female', 3, 'positive_cutoff_male', 4),
'free','klinikai', true, 1, true)
ON CONFLICT (code, language) WHERE tenant_id IS NULL DO UPDATE SET
  title=EXCLUDED.title, items=EXCLUDED.items, scoring=EXCLUDED.scoring, cutoffs=EXCLUDED.cutoffs,
  kioszk_eligible=EXCLUDED.kioszk_eligible, aktiv=EXCLUDED.aktiv;

-- Fagerström
INSERT INTO public.questionnaires (code, title, leiras, language, items, scoring, cutoffs, licenc, mode, kioszk_eligible, becsult_perc, aktiv)
VALUES ('FAGERSTROM', 'Fagerström — Nikotinfüggőség (FTND)',
'Hat tételes nikotinfüggőség-teszt.', 'hu',
jsonb_build_object('questions', jsonb_build_array(
  jsonb_build_object('idx',1,'hu','Ébredés után milyen hamar gyújt rá az első cigarettára?','en','How soon after waking?',
    'options', jsonb_build_array('≤5 perc','6–30 perc','31–60 perc','>60 perc'),'scores', jsonb_build_array(3,2,1,0)),
  jsonb_build_object('idx',2,'hu','Nehéz tartózkodnia a dohányzástól ott, ahol tilos?','en','Hard to refrain where forbidden?',
    'options', jsonb_build_array('Igen','Nem'),'scores', jsonb_build_array(1,0)),
  jsonb_build_object('idx',3,'hu','Melyik cigarettáról mondana le a legnehezebben?','en','Hardest to give up?',
    'options', jsonb_build_array('Az első reggeli','Bármely más'),'scores', jsonb_build_array(1,0)),
  jsonb_build_object('idx',4,'hu','Naponta hány szálat szív?','en','How many per day?',
    'options', jsonb_build_array('≤10','11–20','21–30','31+'),'scores', jsonb_build_array(0,1,2,3)),
  jsonb_build_object('idx',5,'hu','Gyakrabban dohányzik az ébredés utáni első órákban?','en','Smoke more in first hours?',
    'options', jsonb_build_array('Igen','Nem'),'scores', jsonb_build_array(1,0)),
  jsonb_build_object('idx',6,'hu','Akkor is dohányzik, ha betegen ágyban fekszik?','en','Smoke even when ill in bed?',
    'options', jsonb_build_array('Igen','Nem'),'scores', jsonb_build_array(1,0))
)),
jsonb_build_object('type','sum_per_item_scores','min',0,'max',10),
jsonb_build_object('bands', jsonb_build_array(
  jsonb_build_object('min',0,'max',2,'severity','nagyon_alacsony'),
  jsonb_build_object('min',3,'max',4,'severity','alacsony'),
  jsonb_build_object('min',5,'max',5,'severity','kozepes'),
  jsonb_build_object('min',6,'max',7,'severity','magas'),
  jsonb_build_object('min',8,'max',10,'severity','nagyon_magas')
)),
'free','egeszsegfejlesztesi', false, 3, true)
ON CONFLICT (code, language) WHERE tenant_id IS NULL DO UPDATE SET
  title=EXCLUDED.title, items=EXCLUDED.items, scoring=EXCLUDED.scoring, cutoffs=EXCLUDED.cutoffs, aktiv=EXCLUDED.aktiv;

-- WHO-5
INSERT INTO public.questionnaires (code, title, leiras, language, items, scoring, cutoffs, licenc, mode, kioszk_eligible, becsult_perc, aktiv)
VALUES ('WHO5', 'WHO-5 — Jóllét index',
'CC BY-NC-SA 3.0 IGO — kereskedelmi használathoz WHO-engedély kötelező.', 'hu',
jsonb_build_object(
  'lead_in_hu','Az alábbi öt állítás az elmúlt két hét közérzetére vonatkozik.',
  'scale', jsonb_build_array(
    jsonb_build_object('value',5,'hu','Mindig'),
    jsonb_build_object('value',4,'hu','Az idő nagy részében'),
    jsonb_build_object('value',3,'hu','Az idő több mint felében'),
    jsonb_build_object('value',2,'hu','Az idő kevesebb mint felében'),
    jsonb_build_object('value',1,'hu','Néha'),
    jsonb_build_object('value',0,'hu','Soha')
  ),
  'questions', jsonb_build_array(
    jsonb_build_object('idx',1,'hu','Vidámnak és jókedvűnek éreztem magam'),
    jsonb_build_object('idx',2,'hu','Nyugodtnak és ellazultnak éreztem magam'),
    jsonb_build_object('idx',3,'hu','Aktívnak és energikusnak éreztem magam'),
    jsonb_build_object('idx',4,'hu','Frissen és kipihenten ébredtem'),
    jsonb_build_object('idx',5,'hu','A mindennapjaim tele voltak számomra érdekes dolgokkal')
  )
),
jsonb_build_object('type','sum_times_four','min',0,'max',100),
jsonb_build_object('bands', jsonb_build_array(
  jsonb_build_object('min',0,'max',28,'severity','valoszinu_depresszio'),
  jsonb_build_object('min',29,'max',50,'severity','alacsony_jollet'),
  jsonb_build_object('min',51,'max',100,'severity','normalis_jollet')
), 'low_wellbeing_cutoff', 50, 'probable_depression_cutoff', 28),
'who_noncommercial','egeszsegfejlesztesi', false, 2, false)
ON CONFLICT (code, language) WHERE tenant_id IS NULL DO UPDATE SET
  title=EXCLUDED.title, leiras=EXCLUDED.leiras, items=EXCLUDED.items, scoring=EXCLUDED.scoring,
  cutoffs=EXCLUDED.cutoffs, licenc=EXCLUDED.licenc, aktiv=EXCLUDED.aktiv;

-- CG-CAHPS
INSERT INTO public.questionnaires (code, title, leiras, language, items, scoring, cutoffs, licenc, mode, kioszk_eligible, becsult_perc, aktiv)
VALUES ('CGCAHPS', 'Betegelégedettség — CG-CAHPS adaptált',
'Vizit utáni minőségbiztosítási felmérés.', 'hu',
jsonb_build_object('sections', jsonb_build_array(
  jsonb_build_object('key','hozzaferes','title','Hozzáférés / szervezés','items', jsonb_build_array(
    jsonb_build_object('idx',1,'hu','Az időpontot a kívánt időben kapta meg?',
      'options', jsonb_build_array('Soha','Néha','Általában','Mindig')),
    jsonb_build_object('idx',2,'hu','A telefonos vagy online ügyintézés gördülékeny volt?',
      'options', jsonb_build_array('Soha','Néha','Általában','Mindig')),
    jsonb_build_object('idx',3,'hu','Mennyi ideig várt a megbeszélt időponton túl?',
      'options', jsonb_build_array('<15 perc','15–30 perc','30–60 perc','>60 perc'))
  )),
  jsonb_build_object('key','kommunikacio','title','Orvos-beteg kommunikáció','items', jsonb_build_array(
    jsonb_build_object('idx',4,'hu','Az orvos érthetően magyarázott?', 'options', jsonb_build_array('Soha','Néha','Általában','Mindig')),
    jsonb_build_object('idx',5,'hu','Az orvos figyelmesen meghallgatta Önt?', 'options', jsonb_build_array('Soha','Néha','Általában','Mindig')),
    jsonb_build_object('idx',6,'hu','Az orvos tiszteletben tartotta a véleményét?', 'options', jsonb_build_array('Soha','Néha','Általában','Mindig')),
    jsonb_build_object('idx',7,'hu','Az orvos elegendő időt szánt Önre?', 'options', jsonb_build_array('Soha','Néha','Általában','Mindig')),
    jsonb_build_object('idx',8,'hu','A személyzet udvarias és segítőkész volt?', 'options', jsonb_build_array('Soha','Néha','Általában','Mindig'))
  )),
  jsonb_build_object('key','globalis','title','Globális értékelés','items', jsonb_build_array(
    jsonb_build_object('idx',9,'hu','Összességében hogyan értékeli ezt az orvost/rendelőt?','type','scale_0_10'),
    jsonb_build_object('idx',10,'hu','Ajánlaná ezt a rendelőt másnak?',
      'options', jsonb_build_array('Biztosan nem','Valószínűleg nem','Valószínűleg igen','Biztosan igen'))
  )),
  jsonb_build_object('key','szoveges','title','Szöveges visszajelzés','items', jsonb_build_array(
    jsonb_build_object('idx',11,'hu','Egyéb észrevétel (opcionális)','type','text_open')
  ))
)),
jsonb_build_object('type','top_box_per_domain'),
jsonb_build_object('top_box','Mindig'),
'public_domain','vegyes', true, 5, true)
ON CONFLICT (code, language) WHERE tenant_id IS NULL DO UPDATE SET
  title=EXCLUDED.title, items=EXCLUDED.items, scoring=EXCLUDED.scoring,
  cutoffs=EXCLUDED.cutoffs, kioszk_eligible=EXCLUDED.kioszk_eligible, aktiv=EXCLUDED.aktiv;

-- NPS
INSERT INTO public.questionnaires (code, title, leiras, language, items, scoring, cutoffs, licenc, mode, kioszk_eligible, becsult_perc, aktiv)
VALUES ('NPS', 'NPS — Net Promoter Score',
'Másodlagos trendmutató; nem elsődleges minőségmérce.', 'hu',
jsonb_build_object('questions', jsonb_build_array(
  jsonb_build_object('idx',1,'hu','Mennyire valószínű, hogy ajánlana minket egy barátnak vagy családtagnak?','type','scale_0_10'),
  jsonb_build_object('idx',2,'hu','Mi a fő oka az értékelésének? (opcionális)','type','text_open')
)),
jsonb_build_object('type','nps_single','min',0,'max',10),
jsonb_build_object('buckets', jsonb_build_array(
  jsonb_build_object('min',0,'max',6,'label','detractor'),
  jsonb_build_object('min',7,'max',8,'label','passive'),
  jsonb_build_object('min',9,'max',10,'label','promoter')
)),
'free','vegyes', true, 1, true)
ON CONFLICT (code, language) WHERE tenant_id IS NULL DO UPDATE SET
  title=EXCLUDED.title, items=EXCLUDED.items, scoring=EXCLUDED.scoring,
  cutoffs=EXCLUDED.cutoffs, kioszk_eligible=EXCLUDED.kioszk_eligible, aktiv=EXCLUDED.aktiv;
