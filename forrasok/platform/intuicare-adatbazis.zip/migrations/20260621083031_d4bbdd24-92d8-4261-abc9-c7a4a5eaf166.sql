
-- Páciens portál: auth.users ↔ patients link + RLS bővítések

CREATE TABLE public.patient_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  tenant_id uuid REFERENCES public.tenants(id),
  kapcsolat text NOT NULL DEFAULT 'self' CHECK (kapcsolat IN ('self','szulo','gondozo','hozzatartozo','meghatalmazott')),
  verified_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, patient_id)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.patient_users TO authenticated;
GRANT ALL ON public.patient_users TO service_role;

ALTER TABLE public.patient_users ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Felhasználó látja a saját páciens-linkjeit"
  ON public.patient_users FOR SELECT TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Felhasználó létrehozhat saját páciens-linket (self)"
  ON public.patient_users FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid() AND kapcsolat = 'self');

CREATE TRIGGER trg_patient_users_updated_at
  BEFORE UPDATE ON public.patient_users
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Helper: aktuális user által hozzáférhető patient_id-k
CREATE OR REPLACE FUNCTION public.current_user_patient_ids()
RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT patient_id FROM public.patient_users WHERE user_id = auth.uid();
$$;

-- Páciens SELECT policy-k a saját adataihoz (additív, a meglévő staff policy-k mellé)
CREATE POLICY "Páciens látja saját adatát"
  ON public.patients FOR SELECT TO authenticated
  USING (id IN (SELECT public.current_user_patient_ids()));

CREATE POLICY "Páciens látja saját ellátásait"
  ON public.clinical_encounters FOR SELECT TO authenticated
  USING (patient_id IN (SELECT public.current_user_patient_ids()));

CREATE POLICY "Páciens látja saját megfigyeléseit"
  ON public.clinical_observations FOR SELECT TO authenticated
  USING (patient_id IN (SELECT public.current_user_patient_ids()));

CREATE POLICY "Páciens látja saját időpontjait"
  ON public.appointments FOR SELECT TO authenticated
  USING (patient_id IN (SELECT public.current_user_patient_ids()));

CREATE POLICY "Páciens látja saját diagnózisait"
  ON public.clinical_diagnoses FOR SELECT TO authenticated
  USING (patient_id IN (SELECT public.current_user_patient_ids()));

CREATE POLICY "Páciens látja saját kritikus riasztásait"
  ON public.clinical_critical_alerts FOR SELECT TO authenticated
  USING (patient_id IN (SELECT public.current_user_patient_ids()));

-- Időpont kérés workflow
CREATE TABLE public.patient_appointment_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  tenant_id uuid REFERENCES public.tenants(id),
  request_type text NOT NULL CHECK (request_type IN ('new','reschedule','cancel')),
  appointment_id uuid REFERENCES public.appointments(id),
  preferred_slot_id uuid REFERENCES public.appointment_slots(id),
  specialty_id uuid REFERENCES public.specialties(id),
  doctor_user_id uuid REFERENCES auth.users(id),
  urgency text NOT NULL DEFAULT 'normal' CHECK (urgency IN ('low','normal','high','urgent')),
  reason text,
  preferred_datetime timestamptz,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected','rescheduled','cancelled')),
  staff_response text,
  resolved_by uuid REFERENCES auth.users(id),
  resolved_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.patient_appointment_requests TO authenticated;
GRANT ALL ON public.patient_appointment_requests TO service_role;

ALTER TABLE public.patient_appointment_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Páciens kezeli a saját kéréseit"
  ON public.patient_appointment_requests FOR ALL TO authenticated
  USING (user_id = auth.uid() OR patient_id IN (SELECT public.current_user_patient_ids()))
  WITH CHECK (user_id = auth.uid() AND patient_id IN (SELECT public.current_user_patient_ids()));

CREATE TRIGGER trg_patient_appt_req_updated_at
  BEFORE UPDATE ON public.patient_appointment_requests
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- AI lelet-magyarázat cache
CREATE TABLE public.patient_ai_explanations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  source_table text NOT NULL,
  source_id uuid NOT NULL,
  language text NOT NULL DEFAULT 'hu',
  model text NOT NULL,
  prompt_hash text NOT NULL,
  explanation jsonb NOT NULL,
  critical_flags jsonb NOT NULL DEFAULT '[]'::jsonb,
  suggested_specialty_id uuid REFERENCES public.specialties(id),
  expires_at timestamptz NOT NULL DEFAULT (now() + interval '7 days'),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (patient_id, source_table, source_id, prompt_hash, language)
);

GRANT SELECT, INSERT ON public.patient_ai_explanations TO authenticated;
GRANT ALL ON public.patient_ai_explanations TO service_role;

ALTER TABLE public.patient_ai_explanations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Páciens olvashatja saját AI magyarázatait"
  ON public.patient_ai_explanations FOR SELECT TO authenticated
  USING (patient_id IN (SELECT public.current_user_patient_ids()));

-- Életmód napló
CREATE TABLE public.patient_lifestyle_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  logged_at timestamptz NOT NULL DEFAULT now(),
  category text NOT NULL CHECK (category IN ('etel','mozgas','alvas','hangulat','stressz','dohanyzas','alkohol','viz','gyogyszer','egyeb')),
  value_json jsonb NOT NULL DEFAULT '{}'::jsonb,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.patient_lifestyle_log TO authenticated;
GRANT ALL ON public.patient_lifestyle_log TO service_role;

ALTER TABLE public.patient_lifestyle_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Páciens kezeli saját életmód naplóját"
  ON public.patient_lifestyle_log FOR ALL TO authenticated
  USING (user_id = auth.uid() OR patient_id IN (SELECT public.current_user_patient_ids()))
  WITH CHECK (user_id = auth.uid() AND patient_id IN (SELECT public.current_user_patient_ids()));

CREATE INDEX idx_patient_lifestyle_log_patient_date
  ON public.patient_lifestyle_log (patient_id, logged_at DESC);

-- SOS / készenléti kártya
CREATE TABLE public.patient_emergency_card (
  patient_id uuid PRIMARY KEY REFERENCES public.patients(id) ON DELETE CASCADE,
  vercsoport text,
  allergiak text[],
  kronikus_betegsegek text[],
  gyogyszerek text[],
  sos_kontakt_nev text,
  sos_kontakt_telefon text,
  egyeb_info text,
  qr_token text UNIQUE DEFAULT encode(gen_random_bytes(16),'hex'),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.patient_emergency_card TO authenticated;
GRANT ALL ON public.patient_emergency_card TO service_role;

ALTER TABLE public.patient_emergency_card ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Páciens kezeli SOS kártyáját"
  ON public.patient_emergency_card FOR ALL TO authenticated
  USING (patient_id IN (SELECT public.current_user_patient_ids()))
  WITH CHECK (patient_id IN (SELECT public.current_user_patient_ids()));

CREATE TRIGGER trg_patient_emergency_updated_at
  BEFORE UPDATE ON public.patient_emergency_card
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
