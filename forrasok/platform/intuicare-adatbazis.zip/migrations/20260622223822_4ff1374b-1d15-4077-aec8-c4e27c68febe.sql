-- 1) Revoke broad EXECUTE on all SECURITY DEFINER functions in public
DO $$
DECLARE
  r RECORD;
BEGIN
  FOR r IN
    SELECT p.oid::regprocedure::text AS sig
    FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public' AND p.prosecdef = true
  LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION %s FROM PUBLIC, anon', r.sig);
  END LOOP;
END $$;

-- 2) Re-grant EXECUTE to authenticated for functions used as RPC from app code
--    and for helpers referenced inside RLS policies.
DO $$
DECLARE
  fn text;
  fn_names text[] := ARRAY[
    -- App-called RPCs
    'can_book_into_block','close_leave_year','current_tenant_id','eligible_swap_targets',
    'enforce_forced_leave_takeout','ensure_role_permissions_seed',
    'expire_overdue_questionnaire_assignments','find_acute_replacements',
    'generate_demand_for_period','has_any_role','has_permission','has_role',
    'is_conversation_participant','kiosk_autosave','kiosk_load','kiosk_submit_response',
    'log_leave_admin','process_followup_schedules','process_questionnaire_schedules',
    'publish_schedule_run','recalc_leave_entitlements','recompute_block_case_times',
    'reorder_block_cases','search_patients','seed_default_org_for_tenant',
    'send_questionnaire_reminders','wage_simulation',
    -- RLS helpers
    'can_access_patient','current_user_patient_ids','bump_conversation_last_message',
    'apply_approved_change_request','enroll_followup'
  ];
  r RECORD;
BEGIN
  FOREACH fn IN ARRAY fn_names LOOP
    FOR r IN
      SELECT p.oid::regprocedure::text AS sig
      FROM pg_proc p
      JOIN pg_namespace n ON n.oid = p.pronamespace
      WHERE n.nspname = 'public' AND p.proname = fn
    LOOP
      EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO authenticated', r.sig);
    END LOOP;
  END LOOP;
END $$;

-- 3) Tighten i18n_missing_keys_insert: must include tenant_id matching current_tenant_id (if column exists)
--    Otherwise leave as-is. We check column existence dynamically.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema='public' AND table_name='i18n_missing_keys' AND column_name='tenant_id'
  ) THEN
    DROP POLICY IF EXISTS i18n_missing_keys_insert ON public.i18n_missing_keys;
    CREATE POLICY i18n_missing_keys_insert ON public.i18n_missing_keys
      FOR INSERT TO authenticated
      WITH CHECK (tenant_id = public.current_tenant_id());
  END IF;
END $$;
