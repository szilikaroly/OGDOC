
ALTER FUNCTION public.set_updated_at() SET search_path = public;
ALTER FUNCTION public.bump_conversation_last_message() SET search_path = public;

REVOKE EXECUTE ON FUNCTION public.is_conversation_participant(uuid, uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_conversation_participant(uuid, uuid) TO authenticated, service_role;

REVOKE EXECUTE ON FUNCTION public.bump_conversation_last_message() FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.set_updated_at() FROM PUBLIC, anon;
