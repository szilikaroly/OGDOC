-- Kioszk kitöltés: autosave + resume + PIN-zár
CREATE EXTENSION IF NOT EXISTS pgcrypto;

ALTER TABLE public.questionnaire_assignments
  ADD COLUMN IF NOT EXISTS draft_answers jsonb,
  ADD COLUMN IF NOT EXISTS draft_saved_at timestamptz,
  ADD COLUMN IF NOT EXISTS kiosk_pin_hash text,
  ADD COLUMN IF NOT EXISTS last_activity_at timestamptz;

-- PIN-hash trigger: a páciens születési dátumának DDMM része; hash = sha256(token || pin)
CREATE OR REPLACE FUNCTION public.set_kiosk_pin_hash()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_birth date;
  v_pin text;
BEGIN
  IF NEW.patient_id IS NULL THEN
    RETURN NEW;
  END IF;
  SELECT szuletesi_datum INTO v_birth FROM public.patients WHERE id = NEW.patient_id;
  IF v_birth IS NULL THEN
    RETURN NEW;
  END IF;
  v_pin := to_char(v_birth, 'DDMM');
  NEW.kiosk_pin_hash := encode(digest(NEW.token || ':' || v_pin, 'sha256'), 'hex');
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_set_kiosk_pin_hash ON public.questionnaire_assignments;
CREATE TRIGGER trg_set_kiosk_pin_hash
  BEFORE INSERT ON public.questionnaire_assignments
  FOR EACH ROW EXECUTE FUNCTION public.set_kiosk_pin_hash();

-- Backfill meglévő assignmentekre
UPDATE public.questionnaire_assignments qa
   SET kiosk_pin_hash = encode(digest(qa.token || ':' || to_char(p.szuletesi_datum, 'DDMM'), 'sha256'), 'hex')
  FROM public.patients p
 WHERE qa.patient_id = p.id
   AND p.szuletesi_datum IS NOT NULL
   AND qa.kiosk_pin_hash IS NULL;

-- Belső segéd: token + PIN ellenőrzése, visszaadja az assignment-et (vagy NULL)
CREATE OR REPLACE FUNCTION public.kiosk_verify(_token text, _pin text)
RETURNS public.questionnaire_assignments
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_row public.questionnaire_assignments%ROWTYPE;
  v_expected text;
BEGIN
  SELECT * INTO v_row FROM public.questionnaire_assignments WHERE token = _token;
  IF NOT FOUND THEN RETURN NULL; END IF;
  IF v_row.kiosk_pin_hash IS NULL THEN
    RETURN v_row; -- anonim assignmenthez nincs PIN
  END IF;
  v_expected := encode(digest(_token || ':' || COALESCE(_pin, ''), 'sha256'), 'hex');
  IF v_expected = v_row.kiosk_pin_hash THEN
    RETURN v_row;
  END IF;
  RETURN NULL;
END;
$$;

-- Betöltés: assignment + questionnaire + páciens név + draft
CREATE OR REPLACE FUNCTION public.kiosk_load(_token text, _pin text)
RETURNS jsonb
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_asg public.questionnaire_assignments%ROWTYPE;
  v_q public.questionnaires%ROWTYPE;
  v_p record;
BEGIN
  v_asg := public.kiosk_verify(_token, _pin);
  IF v_asg.id IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'invalid_token_or_pin');
  END IF;
  IF v_asg.status NOT IN ('assigned','in_progress') THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'not_open', 'status', v_asg.status);
  END IF;

  SELECT * INTO v_q FROM public.questionnaires WHERE id = v_asg.questionnaire_id;

  SELECT vezeteknev, keresztnev INTO v_p
    FROM public.patients WHERE id = v_asg.patient_id;

  RETURN jsonb_build_object(
    'ok', true,
    'assignment', jsonb_build_object(
      'id', v_asg.id,
      'status', v_asg.status,
      'due_at', v_asg.due_at,
      'draft_answers', v_asg.draft_answers,
      'draft_saved_at', v_asg.draft_saved_at,
      'requires_pin', v_asg.kiosk_pin_hash IS NOT NULL
    ),
    'questionnaire', jsonb_build_object(
      'id', v_q.id, 'code', v_q.code, 'title', v_q.title, 'leiras', v_q.leiras,
      'language', v_q.language, 'items', v_q.items, 'becsult_perc', v_q.becsult_perc
    ),
    'patient_name', COALESCE(v_p.vezeteknev || ' ' || v_p.keresztnev, NULL)
  );
END;
$$;

-- Autosave: csak draft + last_activity_at frissítés, státusz in_progress-re vált
CREATE OR REPLACE FUNCTION public.kiosk_autosave(_token text, _pin text, _answers jsonb)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_asg public.questionnaire_assignments%ROWTYPE;
BEGIN
  v_asg := public.kiosk_verify(_token, _pin);
  IF v_asg.id IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'invalid_token_or_pin');
  END IF;
  IF v_asg.status NOT IN ('assigned','in_progress') THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'not_open');
  END IF;

  UPDATE public.questionnaire_assignments
     SET draft_answers = _answers,
         draft_saved_at = now(),
         last_activity_at = now(),
         status = CASE WHEN status = 'assigned' THEN 'in_progress'::questionnaire_assignment_status ELSE status END
   WHERE id = v_asg.id;

  RETURN jsonb_build_object('ok', true, 'saved_at', now());
END;
$$;

-- Submit: a server fn-nek kell scorolnia, majd ezt hívja az insert-hez.
-- Beilleszti a questionnaire_responses sort és lezárja az assignmentet.
CREATE OR REPLACE FUNCTION public.kiosk_submit_response(
  _token text, _pin text, _answers jsonb,
  _total_score numeric, _severity text, _subscale_scores jsonb,
  _critical_triggered boolean
) RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_asg public.questionnaire_assignments%ROWTYPE;
  v_response_id uuid;
BEGIN
  v_asg := public.kiosk_verify(_token, _pin);
  IF v_asg.id IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'invalid_token_or_pin');
  END IF;
  IF v_asg.status = 'completed' THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'already_completed');
  END IF;

  INSERT INTO public.questionnaire_responses (
    tenant_id, questionnaire_id, assignment_id, patient_id, appointment_id,
    answers, total_score, severity, subscale_scores, critical_triggered,
    is_anonymous, consent_to_record
  ) VALUES (
    v_asg.tenant_id, v_asg.questionnaire_id, v_asg.id, v_asg.patient_id, v_asg.appointment_id,
    _answers, _total_score, _severity, _subscale_scores, COALESCE(_critical_triggered, false),
    false, true
  ) RETURNING id INTO v_response_id;

  UPDATE public.questionnaire_assignments
     SET status = 'completed',
         draft_answers = NULL,
         last_activity_at = now()
   WHERE id = v_asg.id;

  RETURN jsonb_build_object('ok', true, 'response_id', v_response_id, 'critical_triggered', COALESCE(_critical_triggered, false));
END;
$$;

GRANT EXECUTE ON FUNCTION public.kiosk_load(text, text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.kiosk_autosave(text, text, jsonb) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.kiosk_submit_response(text, text, jsonb, numeric, text, jsonb, boolean) TO anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.kiosk_verify(text, text) FROM PUBLIC;