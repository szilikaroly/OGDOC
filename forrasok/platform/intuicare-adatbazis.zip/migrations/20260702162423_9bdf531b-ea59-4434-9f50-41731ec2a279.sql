-- 1. Kapcsolat hír → CMS oldal
ALTER TABLE public.cms_news_posts
  ADD COLUMN IF NOT EXISTS cms_page_id uuid REFERENCES public.cms_pages(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_cms_news_posts_cms_page_id ON public.cms_news_posts(cms_page_id);

-- 2. /hirek listaoldal seed
INSERT INTO public.cms_pages (slug, locale, title, description, status, seo_title, seo_description, template, published_at, schema_type)
VALUES (
  'hirek', 'hu', 'Hírek',
  'Kövesse a klinika legfrissebb híreit, tájékoztatóit és eseményeit.',
  'published',
  'Hírek – Klinika',
  'A klinika legfrissebb hírei, tájékoztatói és eseményei egy helyen.',
  'default', now(), 'collectionpage'
)
ON CONFLICT (slug, locale) DO UPDATE
  SET status = 'published',
      published_at = COALESCE(public.cms_pages.published_at, EXCLUDED.published_at);

-- Alap blokkok a hirek oldalhoz (csak ha még nincs blokkja)
DO $$
DECLARE
  v_page_id uuid;
BEGIN
  SELECT id INTO v_page_id FROM public.cms_pages WHERE slug = 'hirek' AND locale = 'hu';
  IF v_page_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM public.cms_blocks WHERE page_id = v_page_id) THEN
    INSERT INTO public.cms_blocks (page_id, block_type, position, locale, content, is_published) VALUES
      (v_page_id, 'heading', 0, 'hu', '{"text": "Hírek"}'::jsonb, true),
      (v_page_id, 'richtext', 1, 'hu', '{"html": "<p class=\"lead\">Kövesse a klinika legfrissebb híreit, tájékoztatóit és eseményeit.</p>"}'::jsonb, true),
      (v_page_id, 'dyn_news_list', 2, 'hu', '{"title": "Legfrissebb hírek", "limit": 12, "locale": "hu"}'::jsonb, true);
  END IF;
END $$;

-- 3. Backfill: minden meglévő hírhez CMS oldal létrehozása
DO $$
DECLARE
  r RECORD;
  v_page_id uuid;
  v_body_html text;
  v_cms_slug text;
BEGIN
  FOR r IN
    SELECT id, slug, title, excerpt, body, featured_image_url, featured_image_alt,
           seo_title, seo_description, og_image_url, status, published_at, locale
    FROM public.cms_news_posts
    WHERE cms_page_id IS NULL
  LOOP
    v_body_html := COALESCE((r.body->>'html'), '');
    v_cms_slug := 'hirek/' || r.slug;

    SELECT id INTO v_page_id FROM public.cms_pages WHERE slug = v_cms_slug AND locale = r.locale;

    IF v_page_id IS NULL THEN
      INSERT INTO public.cms_pages
        (slug, locale, title, description, status, seo_title, seo_description, og_image_url, template, published_at, schema_type)
      VALUES
        (v_cms_slug, r.locale, r.title, r.excerpt,
         CASE WHEN r.status IN ('draft','published','scheduled','archived') THEN r.status ELSE 'draft' END,
         r.seo_title, r.seo_description, COALESCE(r.og_image_url, r.featured_image_url),
         'default', r.published_at, 'article')
      RETURNING id INTO v_page_id;

      INSERT INTO public.cms_blocks (page_id, block_type, position, locale, content, is_published) VALUES
        (v_page_id, 'dyn_news_hero', 0, r.locale,
         jsonb_build_object(
           'title', r.title,
           'excerpt', r.excerpt,
           'cover', r.featured_image_url,
           'cover_alt', r.featured_image_alt,
           'post_slug', r.slug
         ), true),
        (v_page_id, 'richtext', 1, r.locale,
         jsonb_build_object('html', v_body_html), true),
        (v_page_id, 'dyn_share_bar', 2, r.locale,
         jsonb_build_object('title', r.title), true),
        (v_page_id, 'dyn_news_related', 3, r.locale,
         jsonb_build_object('title', 'Kapcsolódó cikkek', 'post_slug', r.slug, 'limit', 3), true);
    END IF;

    UPDATE public.cms_news_posts SET cms_page_id = v_page_id WHERE id = r.id;
  END LOOP;
END $$;