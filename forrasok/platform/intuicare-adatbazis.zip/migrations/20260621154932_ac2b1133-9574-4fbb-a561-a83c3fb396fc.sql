
CREATE TABLE IF NOT EXISTS public.error_log (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  code text NOT NULL UNIQUE,
  kind text NOT NULL DEFAULT 'unknown',
  title text,
  message text,
  technical text,
  route text,
  query_params jsonb,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  user_agent text,
  ai_suggestion text,
  ai_suggested_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_error_log_created_at ON public.error_log(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_error_log_kind ON public.error_log(kind);

GRANT SELECT, INSERT, UPDATE ON public.error_log TO authenticated;
GRANT INSERT ON public.error_log TO anon;
GRANT ALL ON public.error_log TO service_role;

ALTER TABLE public.error_log ENABLE ROW LEVEL SECURITY;

-- Anyone (anon + authed) can insert their own error log entries
CREATE POLICY "Anyone can insert error logs"
  ON public.error_log FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

-- Only admins can read
CREATE POLICY "Admins can view error logs"
  ON public.error_log FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

-- Only admins can update (for AI suggestion)
CREATE POLICY "Admins can update error logs"
  ON public.error_log FOR UPDATE
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Generate short support code if not provided
CREATE OR REPLACE FUNCTION public.error_log_set_code()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
DECLARE
  v_try int := 0;
  v_code text;
BEGIN
  IF NEW.code IS NOT NULL AND NEW.code <> '' THEN
    RETURN NEW;
  END IF;
  LOOP
    v_try := v_try + 1;
    v_code := 'ERR-' || upper(substring(encode(gen_random_bytes(4), 'hex') from 1 for 6));
    IF NOT EXISTS (SELECT 1 FROM public.error_log WHERE code = v_code) THEN
      NEW.code := v_code;
      RETURN NEW;
    END IF;
    IF v_try > 5 THEN
      NEW.code := 'ERR-' || upper(substring(encode(gen_random_bytes(8), 'hex') from 1 for 10));
      RETURN NEW;
    END IF;
  END LOOP;
END;
$$;

DROP TRIGGER IF EXISTS trg_error_log_set_code ON public.error_log;
CREATE TRIGGER trg_error_log_set_code
  BEFORE INSERT ON public.error_log
  FOR EACH ROW
  EXECUTE FUNCTION public.error_log_set_code();
