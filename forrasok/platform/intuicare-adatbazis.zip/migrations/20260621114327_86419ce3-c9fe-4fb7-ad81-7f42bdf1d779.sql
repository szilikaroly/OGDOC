
CREATE TABLE public.email_digest_settings (
  tenant_id uuid PRIMARY KEY REFERENCES public.tenants(id) ON DELETE CASCADE,
  enabled boolean NOT NULL DEFAULT false,
  day_of_week smallint NOT NULL DEFAULT 1 CHECK (day_of_week BETWEEN 0 AND 6),
  hour_local smallint NOT NULL DEFAULT 8 CHECK (hour_local BETWEEN 0 AND 23),
  timezone text NOT NULL DEFAULT 'Europe/Budapest',
  recipient_roles text[] NOT NULL DEFAULT ARRAY['tenant_admin','igazgato']::text[],
  include_sections jsonb NOT NULL DEFAULT '{"new_patients":true,"questionnaires":true,"critical_alerts":true,"referrals":true,"eeszt_errors":true}'::jsonb,
  last_sent_at timestamptz,
  updated_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.email_digest_settings TO authenticated;
GRANT ALL ON public.email_digest_settings TO service_role;

ALTER TABLE public.email_digest_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "admins_select_digest" ON public.email_digest_settings
  FOR SELECT TO authenticated
  USING (
    public.has_role(auth.uid(), 'tenant_admin')
    OR public.has_role(auth.uid(), 'igazgato')
  );

CREATE POLICY "admins_upsert_digest" ON public.email_digest_settings
  FOR ALL TO authenticated
  USING (
    public.has_role(auth.uid(), 'tenant_admin')
    OR public.has_role(auth.uid(), 'igazgato')
  )
  WITH CHECK (
    public.has_role(auth.uid(), 'tenant_admin')
    OR public.has_role(auth.uid(), 'igazgato')
  );

CREATE OR REPLACE FUNCTION public.email_digest_settings_touch()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER email_digest_settings_touch
BEFORE UPDATE ON public.email_digest_settings
FOR EACH ROW EXECUTE FUNCTION public.email_digest_settings_touch();
