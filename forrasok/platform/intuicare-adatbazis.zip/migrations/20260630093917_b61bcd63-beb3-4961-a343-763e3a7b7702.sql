
CREATE OR REPLACE FUNCTION public.cms_pages_autoredirect_on_slug_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  old_path text;
  new_path text;
BEGIN
  IF NEW.slug = OLD.slug AND NEW.locale = OLD.locale THEN
    RETURN NEW;
  END IF;

  old_path := CASE WHEN OLD.locale = 'hu' THEN '/o/' || OLD.slug ELSE '/' || OLD.locale || '/o/' || OLD.slug END;
  new_path := CASE WHEN NEW.locale = 'hu' THEN '/o/' || NEW.slug ELSE '/' || NEW.locale || '/o/' || NEW.slug END;

  IF old_path = new_path THEN
    RETURN NEW;
  END IF;

  -- Ha már létezik aktív redirect ugyanerre a source-ra, frissítsük a célt;
  -- különben szúrjunk be újat.
  INSERT INTO public.cms_redirects (source_path, target_path, status_code, is_active, note)
  VALUES (old_path, new_path, 301, true, 'Auto: slug-változás')
  ON CONFLICT (source_path) DO UPDATE
    SET target_path = EXCLUDED.target_path,
        status_code = 301,
        is_active = true,
        updated_at = now();

  -- Láncreakció elkerülése: ha az új path ugyanaz, mint egy meglévő redirect source-a, kapcsoljuk ki azt.
  UPDATE public.cms_redirects SET is_active = false
   WHERE source_path = new_path;

  RETURN NEW;
END;
$$;

-- A trigger biztosítja, hogy a slug/locale módosulás előtt a régi értékek elérhetők.
DROP TRIGGER IF EXISTS cms_pages_slug_change_redirect ON public.cms_pages;
CREATE TRIGGER cms_pages_slug_change_redirect
  AFTER UPDATE OF slug, locale ON public.cms_pages
  FOR EACH ROW
  EXECUTE FUNCTION public.cms_pages_autoredirect_on_slug_change();

-- Az ON CONFLICT-hoz unique index a source_path-on (idempotens).
CREATE UNIQUE INDEX IF NOT EXISTS cms_redirects_source_path_uniq
  ON public.cms_redirects (source_path);
