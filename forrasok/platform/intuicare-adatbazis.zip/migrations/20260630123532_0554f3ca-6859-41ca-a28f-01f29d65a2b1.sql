
-- 1. Staff public visibility
ALTER TABLE public.cms_staff_profiles
  ADD COLUMN IF NOT EXISTS public_visibility text NOT NULL DEFAULT 'private'
    CHECK (public_visibility IN ('private','partial','full')),
  ADD COLUMN IF NOT EXISTS public_fields jsonb NOT NULL DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS is_published boolean NOT NULL DEFAULT false;

CREATE INDEX IF NOT EXISTS cms_staff_profiles_published_idx
  ON public.cms_staff_profiles (is_published) WHERE is_published = true;

-- Add anon SELECT policy for published staff
DROP POLICY IF EXISTS "Public staff profiles are viewable" ON public.cms_staff_profiles;
CREATE POLICY "Public staff profiles are viewable"
  ON public.cms_staff_profiles FOR SELECT
  TO anon, authenticated
  USING (is_published = true AND public_visibility <> 'private');

GRANT SELECT ON public.cms_staff_profiles TO anon;

-- 2. Tip views
CREATE TABLE IF NOT EXISTS public.cms_tip_views (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tip_id uuid NOT NULL REFERENCES public.cms_tips(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  session_hash text,
  locale text,
  viewed_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS cms_tip_views_tip_idx ON public.cms_tip_views (tip_id, viewed_at DESC);
GRANT SELECT, INSERT ON public.cms_tip_views TO anon, authenticated;
GRANT ALL ON public.cms_tip_views TO service_role;
ALTER TABLE public.cms_tip_views ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can insert views" ON public.cms_tip_views FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Admins read views" ON public.cms_tip_views FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

-- 3. Tip likes
CREATE TABLE IF NOT EXISTS public.cms_tip_likes (
  tip_id uuid NOT NULL REFERENCES public.cms_tips(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tip_id, user_id)
);
GRANT SELECT, INSERT, DELETE ON public.cms_tip_likes TO authenticated;
GRANT SELECT ON public.cms_tip_likes TO anon;
GRANT ALL ON public.cms_tip_likes TO service_role;
ALTER TABLE public.cms_tip_likes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone reads likes" ON public.cms_tip_likes FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Users like" ON public.cms_tip_likes FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users unlike" ON public.cms_tip_likes FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- 4. Tip comments
CREATE TABLE IF NOT EXISTS public.cms_tip_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tip_id uuid NOT NULL REFERENCES public.cms_tips(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  parent_id uuid REFERENCES public.cms_tip_comments(id) ON DELETE CASCADE,
  body text NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS cms_tip_comments_tip_idx ON public.cms_tip_comments (tip_id, created_at DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_tip_comments TO authenticated;
GRANT SELECT ON public.cms_tip_comments TO anon;
GRANT ALL ON public.cms_tip_comments TO service_role;
ALTER TABLE public.cms_tip_comments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone reads approved" ON public.cms_tip_comments FOR SELECT TO anon, authenticated
  USING (status = 'approved' OR auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Users post comments" ON public.cms_tip_comments FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users edit own" ON public.cms_tip_comments FOR UPDATE TO authenticated
  USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'))
  WITH CHECK (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Users delete own" ON public.cms_tip_comments FOR DELETE TO authenticated
  USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));

-- 5. Tip subscribers (auth users opt-in)
CREATE TABLE IF NOT EXISTS public.cms_tip_subscribers (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email_enabled boolean NOT NULL DEFAULT true,
  push_enabled boolean NOT NULL DEFAULT false,
  audiences text[] DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_tip_subscribers TO authenticated;
GRANT ALL ON public.cms_tip_subscribers TO service_role;
ALTER TABLE public.cms_tip_subscribers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Own sub" ON public.cms_tip_subscribers FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- 6. Newsletter subscribers (external emails)
CREATE TABLE IF NOT EXISTS public.cms_newsletter_subscribers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL UNIQUE,
  confirmed_at timestamptz,
  unsubscribed_at timestamptz,
  unsubscribe_token text NOT NULL DEFAULT encode(gen_random_bytes(24),'hex'),
  source text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.cms_newsletter_subscribers TO anon, authenticated;
GRANT ALL ON public.cms_newsletter_subscribers TO service_role;
ALTER TABLE public.cms_newsletter_subscribers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone subscribes" ON public.cms_newsletter_subscribers FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Admins read" ON public.cms_newsletter_subscribers FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

-- 7. Newsletters
CREATE TABLE IF NOT EXISTS public.cms_newsletters (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subject text NOT NULL,
  body_html text NOT NULL,
  audience text NOT NULL DEFAULT 'all' CHECK (audience IN ('all','tips','news','newsletter')),
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','sending','sent','failed')),
  sent_at timestamptz,
  sent_count integer NOT NULL DEFAULT 0,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_newsletters TO authenticated;
GRANT ALL ON public.cms_newsletters TO service_role;
ALTER TABLE public.cms_newsletters ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins manage newsletters" ON public.cms_newsletters FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- 8. updated_at triggers
DROP TRIGGER IF EXISTS trg_cms_tip_comments_updated ON public.cms_tip_comments;
CREATE TRIGGER trg_cms_tip_comments_updated BEFORE UPDATE ON public.cms_tip_comments
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
DROP TRIGGER IF EXISTS trg_cms_newsletters_updated ON public.cms_newsletters;
CREATE TRIGGER trg_cms_newsletters_updated BEFORE UPDATE ON public.cms_newsletters
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
