-- Remove the unsafe anon insert policy; submissions now go through the
-- token-validated server route /api/public/elegedettseg which uses the
-- service-role client after verifying foglalas_kod + vendeg_email.
DROP POLICY IF EXISTS ss_insert_anon ON public.satisfaction_surveys;