DO $$
DECLARE
  r RECORD;
  whitelist text[] := ARRAY[
    'can_book_into_block','close_leave_year','current_tenant_id','eligible_swap_targets',
    'enforce_forced_leave_takeout','ensure_role_permissions_seed',
    'expire_overdue_questionnaire_assignments','find_acute_replacements',
    'generate_demand_for_period','has_any_role','has_permission','has_role',
    'is_conversation_participant','kiosk_autosave','kiosk_load','kiosk_submit_response',
    'log_leave_admin','process_followup_schedules','process_questionnaire_schedules',
    'publish_schedule_run','recalc_leave_entitlements','recompute_block_case_times',
    'reorder_block_cases','search_patients','seed_default_org_for_tenant',
    'send_questionnaire_reminders','wage_simulation',
    'can_access_patient','current_user_patient_ids','bump_conversation_last_message',
    'apply_approved_change_request','enroll_followup'
  ];
BEGIN
  FOR r IN
    SELECT p.oid::regprocedure::text AS sig, p.proname
    FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public' AND p.prosecdef = true
      AND NOT (p.proname = ANY(whitelist))
  LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION %s FROM authenticated', r.sig);
  END LOOP;
END $$;
