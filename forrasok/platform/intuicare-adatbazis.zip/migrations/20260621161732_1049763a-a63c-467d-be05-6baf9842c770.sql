
-- 1) leave_admin_audit table
CREATE TABLE IF NOT EXISTS public.leave_admin_audit (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  actor_user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  action TEXT NOT NULL CHECK (action IN ('recalc_tenant','close_year','enforce_dry_run','enforce_apply','policy_update')),
  ev INTEGER,
  target_user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  jogcim TEXT,
  nap NUMERIC(6,2),
  before_data JSONB,
  after_data JSONB,
  summary TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT ON public.leave_admin_audit TO authenticated;
GRANT ALL ON public.leave_admin_audit TO service_role;

ALTER TABLE public.leave_admin_audit ENABLE ROW LEVEL SECURITY;

CREATE POLICY "leave_audit_select_authorized"
  ON public.leave_admin_audit FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_leave'));

CREATE INDEX IF NOT EXISTS idx_leave_admin_audit_tenant_created
  ON public.leave_admin_audit (tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_leave_admin_audit_ev
  ON public.leave_admin_audit (tenant_id, ev, created_at DESC);

-- 2) helper to log entries (SECURITY DEFINER bypasses no-INSERT policy)
CREATE OR REPLACE FUNCTION public.log_leave_admin(
  _tenant uuid,
  _actor uuid,
  _action text,
  _ev int,
  _target_user uuid,
  _jogcim text,
  _nap numeric,
  _before jsonb,
  _after jsonb,
  _summary text
) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_id uuid;
BEGIN
  INSERT INTO public.leave_admin_audit
    (tenant_id, actor_user_id, action, ev, target_user_id, jogcim, nap, before_data, after_data, summary)
  VALUES (_tenant, _actor, _action, _ev, _target_user, _jogcim, _nap, _before, _after, _summary)
  RETURNING id INTO v_id;
  RETURN v_id;
END $$;

REVOKE ALL ON FUNCTION public.log_leave_admin(uuid,uuid,text,int,uuid,text,numeric,jsonb,jsonb,text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.log_leave_admin(uuid,uuid,text,int,uuid,text,numeric,jsonb,jsonb,text) TO authenticated, service_role;

-- 3) manage_leave permission, granted to admin/leadership roles
INSERT INTO public.role_permissions (role_kulcs, perm)
SELECT r.kulcs, 'manage_leave'
FROM public.roles r
WHERE r.kulcs IN ('tenant_admin','igazgato','intezetvezeto','telephelyvezeto')
ON CONFLICT DO NOTHING;
