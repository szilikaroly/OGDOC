
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;

CREATE TYPE public.conversation_kind AS ENUM ('dm','group','patient_provider','patient_team','ai_assistant');
CREATE TYPE public.message_sender_kind AS ENUM ('user','patient','ai','system');
CREATE TYPE public.attachment_summary_status AS ENUM ('pending','done','failed','skipped');

CREATE TABLE public.conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  kind public.conversation_kind NOT NULL,
  title text,
  patient_id uuid REFERENCES public.patients(id) ON DELETE SET NULL,
  created_by uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  last_message_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_conversations_tenant_last ON public.conversations(tenant_id, last_message_at DESC);
CREATE INDEX idx_conversations_patient ON public.conversations(patient_id) WHERE patient_id IS NOT NULL;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.conversations TO authenticated;
GRANT ALL ON public.conversations TO service_role;
ALTER TABLE public.conversations ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.conversation_participants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  patient_id uuid REFERENCES public.patients(id) ON DELETE CASCADE,
  role text NOT NULL DEFAULT 'member' CHECK (role IN ('member','owner','observer')),
  auto_translate boolean NOT NULL DEFAULT true,
  muted boolean NOT NULL DEFAULT false,
  last_read_at timestamptz,
  joined_at timestamptz NOT NULL DEFAULT now(),
  CHECK ((user_id IS NOT NULL) <> (patient_id IS NOT NULL))
);
CREATE UNIQUE INDEX uq_participants_conv_user ON public.conversation_participants(conversation_id, user_id) WHERE user_id IS NOT NULL;
CREATE UNIQUE INDEX uq_participants_conv_patient ON public.conversation_participants(conversation_id, patient_id) WHERE patient_id IS NOT NULL;
CREATE INDEX idx_participants_user ON public.conversation_participants(user_id) WHERE user_id IS NOT NULL;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.conversation_participants TO authenticated;
GRANT ALL ON public.conversation_participants TO service_role;
ALTER TABLE public.conversation_participants ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.is_conversation_participant(_conv_id uuid, _user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.conversation_participants
    WHERE conversation_id = _conv_id AND user_id = _user_id
  );
$$;

CREATE TABLE public.messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  sender_user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  sender_patient_id uuid REFERENCES public.patients(id) ON DELETE SET NULL,
  sender_kind public.message_sender_kind NOT NULL DEFAULT 'user',
  body text,
  source_lang text,
  reply_to_id uuid REFERENCES public.messages(id) ON DELETE SET NULL,
  edited_at timestamptz,
  deleted_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_messages_conv_created ON public.messages(conversation_id, created_at DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.messages TO authenticated;
GRANT ALL ON public.messages TO service_role;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.message_translations (
  message_id uuid NOT NULL REFERENCES public.messages(id) ON DELETE CASCADE,
  lang text NOT NULL,
  translated_text text NOT NULL,
  model text,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (message_id, lang)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.message_translations TO authenticated;
GRANT ALL ON public.message_translations TO service_role;
ALTER TABLE public.message_translations ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.message_attachments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id uuid REFERENCES public.messages(id) ON DELETE CASCADE,
  conversation_id uuid NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  uploaded_by uuid NOT NULL REFERENCES auth.users(id) ON DELETE SET NULL,
  storage_path text NOT NULL,
  mime text NOT NULL,
  size_bytes bigint NOT NULL,
  original_name text NOT NULL,
  kind text NOT NULL DEFAULT 'file' CHECK (kind IN ('image','pdf','spreadsheet','audio','file')),
  duration_ms integer,
  ai_summary text,
  ai_summary_status public.attachment_summary_status NOT NULL DEFAULT 'pending',
  ai_summary_lang text,
  transcript text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_attachments_message ON public.message_attachments(message_id);
CREATE INDEX idx_attachments_conv ON public.message_attachments(conversation_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.message_attachments TO authenticated;
GRANT ALL ON public.message_attachments TO service_role;
ALTER TABLE public.message_attachments ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.message_read_receipts (
  message_id uuid NOT NULL REFERENCES public.messages(id) ON DELETE CASCADE,
  reader_user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  read_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (message_id, reader_user_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.message_read_receipts TO authenticated;
GRANT ALL ON public.message_read_receipts TO service_role;
ALTER TABLE public.message_read_receipts ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.ai_assistant_actions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  kind text NOT NULL,
  payload jsonb,
  result jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_assistant_actions_conv ON public.ai_assistant_actions(conversation_id, created_at DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.ai_assistant_actions TO authenticated;
GRANT ALL ON public.ai_assistant_actions TO service_role;
ALTER TABLE public.ai_assistant_actions ENABLE ROW LEVEL SECURITY;

CREATE POLICY conversations_select_participant ON public.conversations FOR SELECT TO authenticated
  USING (public.is_conversation_participant(id, auth.uid()));
CREATE POLICY conversations_insert_self ON public.conversations FOR INSERT TO authenticated
  WITH CHECK (created_by = auth.uid());
CREATE POLICY conversations_update_participant ON public.conversations FOR UPDATE TO authenticated
  USING (public.is_conversation_participant(id, auth.uid()));

CREATE POLICY participants_select_same_conv ON public.conversation_participants FOR SELECT TO authenticated
  USING (public.is_conversation_participant(conversation_id, auth.uid()) OR user_id = auth.uid());
CREATE POLICY participants_insert_creator_or_self ON public.conversation_participants FOR INSERT TO authenticated
  WITH CHECK (
    user_id = auth.uid()
    OR EXISTS (SELECT 1 FROM public.conversations c WHERE c.id = conversation_id AND c.created_by = auth.uid())
  );
CREATE POLICY participants_update_self ON public.conversation_participants FOR UPDATE TO authenticated
  USING (user_id = auth.uid());
CREATE POLICY participants_delete_self_or_owner ON public.conversation_participants FOR DELETE TO authenticated
  USING (
    user_id = auth.uid()
    OR EXISTS (SELECT 1 FROM public.conversations c WHERE c.id = conversation_id AND c.created_by = auth.uid())
  );

CREATE POLICY messages_select_participant ON public.messages FOR SELECT TO authenticated
  USING (public.is_conversation_participant(conversation_id, auth.uid()));
CREATE POLICY messages_insert_participant ON public.messages FOR INSERT TO authenticated
  WITH CHECK (
    public.is_conversation_participant(conversation_id, auth.uid())
    AND (sender_user_id = auth.uid() OR sender_kind IN ('ai','system'))
  );
CREATE POLICY messages_update_own ON public.messages FOR UPDATE TO authenticated
  USING (sender_user_id = auth.uid());
CREATE POLICY messages_delete_own ON public.messages FOR DELETE TO authenticated
  USING (sender_user_id = auth.uid());

CREATE POLICY translations_select_participant ON public.message_translations FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.messages m WHERE m.id = message_id AND public.is_conversation_participant(m.conversation_id, auth.uid())));
CREATE POLICY translations_insert_participant ON public.message_translations FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM public.messages m WHERE m.id = message_id AND public.is_conversation_participant(m.conversation_id, auth.uid())));

CREATE POLICY attachments_select_participant ON public.message_attachments FOR SELECT TO authenticated
  USING (public.is_conversation_participant(conversation_id, auth.uid()));
CREATE POLICY attachments_insert_uploader ON public.message_attachments FOR INSERT TO authenticated
  WITH CHECK (uploaded_by = auth.uid() AND public.is_conversation_participant(conversation_id, auth.uid()));
CREATE POLICY attachments_update_uploader ON public.message_attachments FOR UPDATE TO authenticated
  USING (uploaded_by = auth.uid() OR public.is_conversation_participant(conversation_id, auth.uid()));
CREATE POLICY attachments_delete_uploader ON public.message_attachments FOR DELETE TO authenticated
  USING (uploaded_by = auth.uid());

CREATE POLICY receipts_select_participant ON public.message_read_receipts FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.messages m WHERE m.id = message_id AND public.is_conversation_participant(m.conversation_id, auth.uid())));
CREATE POLICY receipts_insert_self ON public.message_read_receipts FOR INSERT TO authenticated
  WITH CHECK (reader_user_id = auth.uid());

CREATE POLICY assistant_actions_select_own ON public.ai_assistant_actions FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_conversation_participant(conversation_id, auth.uid()));
CREATE POLICY assistant_actions_insert_self ON public.ai_assistant_actions FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE TRIGGER trg_conversations_updated_at
  BEFORE UPDATE ON public.conversations
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE OR REPLACE FUNCTION public.bump_conversation_last_message()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  UPDATE public.conversations SET last_message_at = NEW.created_at, updated_at = now() WHERE id = NEW.conversation_id;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_messages_bump_conv
  AFTER INSERT ON public.messages
  FOR EACH ROW EXECUTE FUNCTION public.bump_conversation_last_message();

ALTER PUBLICATION supabase_realtime ADD TABLE public.messages;
ALTER PUBLICATION supabase_realtime ADD TABLE public.message_read_receipts;
ALTER PUBLICATION supabase_realtime ADD TABLE public.message_attachments;
ALTER PUBLICATION supabase_realtime ADD TABLE public.conversations;
