-- Add sort_order to surgery_cases for in-block sequencing
ALTER TABLE public.surgery_cases ADD COLUMN IF NOT EXISTS sort_order integer;
CREATE INDEX IF NOT EXISTS idx_surgery_cases_block_sort ON public.surgery_cases (or_block_id, sort_order);

-- Helper: recompute tervezett_kezdo_ido for all cases in a block based on sort_order + block start + per-case duration + turnover
CREATE OR REPLACE FUNCTION public.recompute_block_case_times(_block_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_block  record;
  v_room   record;
  v_turnover int := 15;
  v_cursor timestamptz;
  r record;
BEGIN
  SELECT b.* INTO v_block FROM public.or_blocks b WHERE b.id = _block_id;
  IF NOT FOUND THEN RETURN; END IF;

  SELECT rp.fordulo_ido_perc INTO v_turnover
    FROM public.or_room_profiles rp
   WHERE rp.org_unit_id = v_block.org_unit_id AND rp.aktiv = true
   LIMIT 1;
  IF v_turnover IS NULL THEN v_turnover := 15; END IF;

  v_cursor := (v_block.datum::text || ' ' || v_block.kezdo_ido::text)::timestamptz;

  FOR r IN
    SELECT id, becsult_idotartam_perc
      FROM public.surgery_cases
     WHERE or_block_id = _block_id
       AND statusz NOT IN ('torolt','elvegzett')
     ORDER BY COALESCE(sort_order, 999999), created_at
  LOOP
    UPDATE public.surgery_cases
       SET tervezett_kezdo_ido = v_cursor
     WHERE id = r.id;
    v_cursor := v_cursor + make_interval(mins => COALESCE(r.becsult_idotartam_perc, 60) + v_turnover);
  END LOOP;
END;
$$;

GRANT EXECUTE ON FUNCTION public.recompute_block_case_times(uuid) TO authenticated;

-- Reorder RPC: accepts an ordered array of case ids for a single block
CREATE OR REPLACE FUNCTION public.reorder_block_cases(_block_id uuid, _ordered_case_ids uuid[])
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_allowed boolean;
  i int;
BEGIN
  SELECT public.has_permission(v_uid, 'book_or_case') INTO v_allowed;
  IF NOT v_allowed THEN
    RAISE EXCEPTION 'Nincs jogosultsága a műtéti sor rendezéséhez';
  END IF;

  FOR i IN 1..array_length(_ordered_case_ids, 1) LOOP
    UPDATE public.surgery_cases
       SET sort_order = i
     WHERE id = _ordered_case_ids[i]
       AND or_block_id = _block_id;
  END LOOP;

  PERFORM public.recompute_block_case_times(_block_id);
END;
$$;

GRANT EXECUTE ON FUNCTION public.reorder_block_cases(uuid, uuid[]) TO authenticated;