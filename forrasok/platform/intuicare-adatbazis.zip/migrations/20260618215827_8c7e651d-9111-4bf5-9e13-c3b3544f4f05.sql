
ALTER TABLE public.patient_encounters
  ADD COLUMN IF NOT EXISTS szerzo_id uuid REFERENCES auth.users(id),
  ADD COLUMN IF NOT EXISTS szerzo_alairas_at timestamptz,
  ADD COLUMN IF NOT EXISTS ellenjegyzo_id uuid REFERENCES auth.users(id),
  ADD COLUMN IF NOT EXISTS ellenjegyzo_alairas_at timestamptz;

-- Immutability check: when status='ellenjegyezve' do not allow body changes
CREATE OR REPLACE FUNCTION public.patient_encounters_lock_signed()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
BEGIN
  IF OLD.status = 'ellenjegyezve' AND NEW.status = 'ellenjegyezve' THEN
    IF NEW.bno_kodok IS DISTINCT FROM OLD.bno_kodok
       OR NEW.oeno_kodok IS DISTINCT FROM OLD.oeno_kodok
       OR NEW.beavatkozas_ids IS DISTINCT FROM OLD.beavatkozas_ids
       OR NEW.osszefoglalo IS DISTINCT FROM OLD.osszefoglalo
       OR NEW.ellatas_kezdete IS DISTINCT FROM OLD.ellatas_kezdete
       OR NEW.ellatas_vege IS DISTINCT FROM OLD.ellatas_vege THEN
      RAISE EXCEPTION 'A lezárt (ellenjegyzett) ellátás nem módosítható.';
    END IF;
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_patient_encounters_lock ON public.patient_encounters;
CREATE TRIGGER trg_patient_encounters_lock
  BEFORE UPDATE ON public.patient_encounters
  FOR EACH ROW EXECUTE FUNCTION public.patient_encounters_lock_signed();
