
ALTER TABLE public.questionnaire_assignments
  ADD COLUMN IF NOT EXISTS reminded_at timestamptz,
  ADD COLUMN IF NOT EXISTS reminder_count integer NOT NULL DEFAULT 0;

CREATE INDEX IF NOT EXISTS idx_qa_status_due
  ON public.questionnaire_assignments (tenant_id, status, due_at);
CREATE INDEX IF NOT EXISTS idx_qa_patient_status
  ON public.questionnaire_assignments (patient_id, status);

CREATE OR REPLACE FUNCTION public.process_questionnaire_schedules()
RETURNS TABLE(schedule_id uuid, created_count integer)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
  v_sched record;
  v_patient_id uuid;
  v_created integer;
BEGIN
  FOR v_sched IN
    SELECT * FROM public.questionnaire_schedules
    WHERE aktiv = true
      AND (next_due_at IS NULL OR next_due_at <= now())
  LOOP
    v_created := 0;

    IF v_sched.scope = 'patient' AND v_sched.patient_id IS NOT NULL THEN
      INSERT INTO public.questionnaire_assignments
        (tenant_id, questionnaire_id, patient_id, kind, status, due_at, token)
      SELECT v_sched.tenant_id, v_sched.questionnaire_id, v_sched.patient_id,
             'periodikus', 'assigned',
             COALESCE(v_sched.next_due_at, now()) + interval '7 days',
             encode(gen_random_bytes(16), 'hex')
      WHERE NOT EXISTS (
        SELECT 1 FROM public.questionnaire_assignments qa
        WHERE qa.patient_id = v_sched.patient_id
          AND qa.questionnaire_id = v_sched.questionnaire_id
          AND qa.kind = 'periodikus'
          AND qa.status IN ('assigned','in_progress')
      );
      GET DIAGNOSTICS v_created = ROW_COUNT;

    ELSIF v_sched.scope = 'program' AND v_sched.monitoring_program_id IS NOT NULL THEN
      FOR v_patient_id IN
        SELECT mp.patient_id FROM public.monitoring_programs mp
        WHERE mp.id = v_sched.monitoring_program_id AND mp.aktiv = true
      LOOP
        INSERT INTO public.questionnaire_assignments
          (tenant_id, questionnaire_id, patient_id, kind, status, due_at, token)
        SELECT v_sched.tenant_id, v_sched.questionnaire_id, v_patient_id,
               'periodikus', 'assigned',
               COALESCE(v_sched.next_due_at, now()) + interval '7 days',
               encode(gen_random_bytes(16), 'hex')
        WHERE NOT EXISTS (
          SELECT 1 FROM public.questionnaire_assignments qa
          WHERE qa.patient_id = v_patient_id
            AND qa.questionnaire_id = v_sched.questionnaire_id
            AND qa.kind = 'periodikus'
            AND qa.status IN ('assigned','in_progress')
        );
        IF FOUND THEN v_created := v_created + 1; END IF;
      END LOOP;
    END IF;

    UPDATE public.questionnaire_schedules
      SET last_run_at = now(),
          next_due_at = COALESCE(next_due_at, now()) + (interval_days || ' days')::interval
      WHERE id = v_sched.id;

    schedule_id := v_sched.id;
    created_count := v_created;
    RETURN NEXT;
  END LOOP;

  RETURN;
END
$function$;

CREATE OR REPLACE FUNCTION public.expire_overdue_questionnaire_assignments()
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
  v_count integer;
BEGIN
  WITH expired AS (
    UPDATE public.questionnaire_assignments
       SET status = 'expired'
     WHERE status IN ('assigned','in_progress')
       AND due_at IS NOT NULL
       AND due_at < now() - interval '7 days'
    RETURNING tenant_id, patient_id, questionnaire_id
  )
  INSERT INTO public.notifications (tenant_id, user_id, tipus, cim, uzenet, link)
  SELECT e.tenant_id, p.felelos_user_id, 'kerdoiv',
         'Kitöltetlen kérdőív lejárt',
         'A páciens nem töltötte ki a kiosztott kérdőívet a határidőre.',
         '/kerdoivek'
  FROM expired e
  JOIN public.patients p ON p.id = e.patient_id
  WHERE p.felelos_user_id IS NOT NULL;

  GET DIAGNOSTICS v_count = ROW_COUNT;
  RETURN COALESCE(v_count, 0);
END
$function$;

CREATE OR REPLACE FUNCTION public.send_questionnaire_reminders()
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
  v_count integer := 0;
  v_rec record;
BEGIN
  FOR v_rec IN
    SELECT qa.id, qa.tenant_id, qa.patient_id, qa.questionnaire_id, qa.due_at,
           p.felelos_user_id, q.title
    FROM public.questionnaire_assignments qa
    JOIN public.questionnaires q ON q.id = qa.questionnaire_id
    LEFT JOIN public.patients p ON p.id = qa.patient_id
    WHERE qa.status IN ('assigned','in_progress')
      AND qa.due_at IS NOT NULL
      AND qa.due_at <= now() + interval '1 day'
      AND qa.reminder_count < 3
      AND (qa.reminded_at IS NULL OR qa.reminded_at < now() - interval '3 days')
  LOOP
    IF v_rec.felelos_user_id IS NOT NULL THEN
      INSERT INTO public.notifications (tenant_id, user_id, tipus, cim, uzenet, link)
      VALUES (v_rec.tenant_id, v_rec.felelos_user_id, 'kerdoiv',
              'Esedékes kérdőív emlékeztető',
              format('A(z) "%s" kérdőív kitöltése esedékes (határidő: %s).',
                     v_rec.title,
                     to_char(v_rec.due_at AT TIME ZONE 'Europe/Budapest','YYYY-MM-DD')),
              '/kerdoivek');
    END IF;

    UPDATE public.questionnaire_assignments
       SET reminded_at = now(),
           reminder_count = reminder_count + 1
     WHERE id = v_rec.id;
    v_count := v_count + 1;
  END LOOP;
  RETURN v_count;
END
$function$;

REVOKE EXECUTE ON FUNCTION public.process_questionnaire_schedules() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.expire_overdue_questionnaire_assignments() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.send_questionnaire_reminders() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.process_questionnaire_schedules() TO service_role;
GRANT EXECUTE ON FUNCTION public.expire_overdue_questionnaire_assignments() TO service_role;
GRANT EXECUTE ON FUNCTION public.send_questionnaire_reminders() TO service_role;
