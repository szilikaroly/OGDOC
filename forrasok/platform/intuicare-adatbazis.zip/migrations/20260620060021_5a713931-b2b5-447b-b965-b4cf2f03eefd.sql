CREATE TABLE IF NOT EXISTS public.i18n_missing_keys (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  namespace text NOT NULL,
  key text NOT NULL,
  lang text NOT NULL,
  source_text text NOT NULL,
  kind text NOT NULL DEFAULT 'ui',
  hits integer NOT NULL DEFAULT 1,
  last_seen_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (namespace, key, lang)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.i18n_missing_keys TO authenticated;
GRANT ALL ON public.i18n_missing_keys TO service_role;

ALTER TABLE public.i18n_missing_keys ENABLE ROW LEVEL SECURITY;

CREATE POLICY "i18n_missing_keys_all_auth" ON public.i18n_missing_keys
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE INDEX IF NOT EXISTS idx_i18n_missing_keys_lang ON public.i18n_missing_keys (lang, last_seen_at DESC);