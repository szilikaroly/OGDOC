-- ===== CMS workflow + audit log: 1. fázis (A migráció) =====

-- 1) ENUM-ok
CREATE TYPE public.cms_workflow_state AS ENUM (
  'draft', 'in_review', 'approved', 'published', 'rejected', 'archived'
);

CREATE TYPE public.cms_audit_action AS ENUM (
  'create', 'update', 'delete',
  'submit_review', 'approve', 'reject',
  'publish', 'unpublish',
  'revert', 'restore'
);

-- 2) Új CMS szerepkörök (admin kategória)
INSERT INTO public.roles (kulcs, megnevezes, kategoria, sorrend) VALUES
  ('cms_reviewer', 'CMS véleményező', 'admin', 100),
  ('cms_publisher', 'CMS publikáló', 'admin', 101)
ON CONFLICT (kulcs) DO NOTHING;

-- 3) Bővített cms hozzáférés-ellenőrzés
CREATE OR REPLACE FUNCTION public.has_cms_access(_user_id uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT
    public.has_role(_user_id, 'tenant_admin')
    OR public.has_role(_user_id, 'cms_editor')
    OR public.has_role(_user_id, 'cms_reviewer')
    OR public.has_role(_user_id, 'cms_publisher');
$$;

CREATE OR REPLACE FUNCTION public.has_cms_editor(_user_id uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT
    public.has_role(_user_id, 'tenant_admin')
    OR public.has_role(_user_id, 'cms_editor')
    OR public.has_role(_user_id, 'cms_reviewer')
    OR public.has_role(_user_id, 'cms_publisher');
$$;

CREATE OR REPLACE FUNCTION public.has_cms_reviewer(_user_id uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT
    public.has_role(_user_id, 'tenant_admin')
    OR public.has_role(_user_id, 'cms_reviewer')
    OR public.has_role(_user_id, 'cms_publisher');
$$;

CREATE OR REPLACE FUNCTION public.has_cms_publisher(_user_id uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT
    public.has_role(_user_id, 'tenant_admin')
    OR public.has_role(_user_id, 'cms_publisher');
$$;

-- 4) Audit log tábla
CREATE TABLE public.cms_audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz NOT NULL DEFAULT now(),
  entity_type text NOT NULL,
  entity_id uuid,
  entity_slug text,
  entity_locale text,
  action public.cms_audit_action NOT NULL,
  actor_id uuid,
  actor_email text,
  before jsonb,
  after jsonb,
  diff jsonb,
  comment text,
  request_meta jsonb DEFAULT '{}'::jsonb
);

CREATE INDEX cms_audit_log_entity_idx
  ON public.cms_audit_log (entity_type, entity_id, created_at DESC);
CREATE INDEX cms_audit_log_actor_idx
  ON public.cms_audit_log (actor_id, created_at DESC);
CREATE INDEX cms_audit_log_action_idx
  ON public.cms_audit_log (action, created_at DESC);

GRANT SELECT ON public.cms_audit_log TO authenticated;
GRANT ALL ON public.cms_audit_log TO service_role;

ALTER TABLE public.cms_audit_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "cms_audit_log_select"
  ON public.cms_audit_log
  FOR SELECT
  TO authenticated
  USING (public.has_cms_access(auth.uid()));

-- (RLS enabled + nincs INSERT policy → tiltott; csak SECURITY DEFINER fn írhat)

-- 5) Audit író helper
CREATE OR REPLACE FUNCTION public.cms_audit_write(
  _entity_type text,
  _entity_id uuid,
  _action public.cms_audit_action,
  _before jsonb DEFAULT NULL,
  _after jsonb DEFAULT NULL,
  _comment text DEFAULT NULL,
  _entity_slug text DEFAULT NULL,
  _entity_locale text DEFAULT NULL,
  _request_meta jsonb DEFAULT '{}'::jsonb
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _id uuid;
  _email text;
  _diff jsonb;
BEGIN
  SELECT email INTO _email FROM auth.users WHERE id = auth.uid();

  IF _before IS NOT NULL AND _after IS NOT NULL THEN
    SELECT jsonb_object_agg(key, value) INTO _diff
    FROM jsonb_each(_after)
    WHERE COALESCE(_before -> key, 'null'::jsonb) IS DISTINCT FROM value;
  ELSE
    _diff := NULL;
  END IF;

  INSERT INTO public.cms_audit_log (
    entity_type, entity_id, entity_slug, entity_locale,
    action, actor_id, actor_email,
    before, after, diff, comment, request_meta
  ) VALUES (
    _entity_type, _entity_id, _entity_slug, _entity_locale,
    _action, auth.uid(), _email,
    _before, _after, _diff, _comment, COALESCE(_request_meta, '{}'::jsonb)
  )
  RETURNING id INTO _id;

  RETURN _id;
END;
$$;

REVOKE ALL ON FUNCTION public.cms_audit_write(text, uuid, public.cms_audit_action, jsonb, jsonb, text, text, text, jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.cms_audit_write(text, uuid, public.cms_audit_action, jsonb, jsonb, text, text, text, jsonb) TO authenticated;