
-- Helper: update_updated_at (idempotent)
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- =========================================================
-- 1) clinical_encounters
-- =========================================================
CREATE TABLE public.clinical_encounters (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tenant_id UUID,
  patient_id UUID NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  encounter_type TEXT NOT NULL DEFAULT 'ambulatory',
    -- 'ambulatory' | 'emergency' | 'inpatient' | 'obstetric' | 'home'
  status TEXT NOT NULL DEFAULT 'in-progress',
    -- 'planned' | 'in-progress' | 'finished' | 'cancelled'
  start_ts TIMESTAMPTZ NOT NULL DEFAULT now(),
  end_ts TIMESTAMPTZ,
  chief_complaint TEXT,
  location TEXT,
  created_by UUID NOT NULL REFERENCES auth.users(id),
  closed_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_clin_enc_patient ON public.clinical_encounters(patient_id, start_ts DESC);
CREATE INDEX idx_clin_enc_status ON public.clinical_encounters(status);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.clinical_encounters TO authenticated;
GRANT ALL ON public.clinical_encounters TO service_role;
ALTER TABLE public.clinical_encounters ENABLE ROW LEVEL SECURITY;

CREATE POLICY "auth users read encounters"
  ON public.clinical_encounters FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth users insert encounters"
  ON public.clinical_encounters FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = created_by);
CREATE POLICY "creator updates encounters"
  ON public.clinical_encounters FOR UPDATE TO authenticated
  USING (auth.uid() = created_by OR public.has_role(auth.uid(), 'admin'))
  WITH CHECK (true);
CREATE POLICY "creator deletes encounters"
  ON public.clinical_encounters FOR DELETE TO authenticated
  USING (auth.uid() = created_by OR public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER trg_clin_enc_updated
  BEFORE UPDATE ON public.clinical_encounters
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- =========================================================
-- 2) clinical_observations  (FHIR Observation)
-- =========================================================
CREATE TABLE public.clinical_observations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  encounter_id UUID NOT NULL REFERENCES public.clinical_encounters(id) ON DELETE CASCADE,
  patient_id UUID NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  category TEXT NOT NULL,
    -- 'vital-signs' | 'laboratory' | 'imaging' | 'exam' | 'survey' | 'fluid-balance' | 'pain'
  loinc_code TEXT,
  snomed_code TEXT,
  code_display TEXT NOT NULL,
  value_quantity NUMERIC,
  value_unit TEXT,
  value_string TEXT,
  value_json JSONB,
  interpretation TEXT,
    -- 'normal' | 'low' | 'high' | 'critical-low' | 'critical-high'
  effective_ts TIMESTAMPTZ NOT NULL DEFAULT now(),
  performer_id UUID REFERENCES auth.users(id),
  source TEXT NOT NULL DEFAULT 'manual',
    -- 'manual' | 'device' | 'calculator' | 'import'
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_clin_obs_encounter ON public.clinical_observations(encounter_id, effective_ts);
CREATE INDEX idx_clin_obs_patient ON public.clinical_observations(patient_id, effective_ts DESC);
CREATE INDEX idx_clin_obs_loinc ON public.clinical_observations(loinc_code);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.clinical_observations TO authenticated;
GRANT ALL ON public.clinical_observations TO service_role;
ALTER TABLE public.clinical_observations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "auth users read observations"
  ON public.clinical_observations FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth users insert observations"
  ON public.clinical_observations FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = performer_id OR performer_id IS NULL);
CREATE POLICY "performer updates observations"
  ON public.clinical_observations FOR UPDATE TO authenticated
  USING (auth.uid() = performer_id OR public.has_role(auth.uid(), 'admin'))
  WITH CHECK (true);
CREATE POLICY "performer deletes observations"
  ON public.clinical_observations FOR DELETE TO authenticated
  USING (auth.uid() = performer_id OR public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER trg_clin_obs_updated
  BEFORE UPDATE ON public.clinical_observations
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- =========================================================
-- 3) clinical_notes
-- =========================================================
CREATE TABLE public.clinical_notes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  encounter_id UUID NOT NULL REFERENCES public.clinical_encounters(id) ON DELETE CASCADE,
  patient_id UUID NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  kind TEXT NOT NULL,
    -- 'anamnesis' | 'complaint' | 'status' | 'ultrasound' | 'imaging'
    -- | 'epicrisis' | 'therapy' | 'recommendation' | 'summary'
    -- | 'lifestyle' | 'diet' | 'progress'
  title TEXT,
  body_md TEXT,
  structured_json JSONB,
  author_id UUID NOT NULL REFERENCES auth.users(id),
  signed_at TIMESTAMPTZ,
  signed_by UUID REFERENCES auth.users(id),
  version INT NOT NULL DEFAULT 1,
  parent_note_id UUID REFERENCES public.clinical_notes(id),
  ai_generated BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_clin_notes_encounter ON public.clinical_notes(encounter_id, kind);
CREATE INDEX idx_clin_notes_patient ON public.clinical_notes(patient_id, created_at DESC);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.clinical_notes TO authenticated;
GRANT ALL ON public.clinical_notes TO service_role;
ALTER TABLE public.clinical_notes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "auth users read notes"
  ON public.clinical_notes FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth users insert notes"
  ON public.clinical_notes FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = author_id);
CREATE POLICY "author updates unsigned notes"
  ON public.clinical_notes FOR UPDATE TO authenticated
  USING ((auth.uid() = author_id AND signed_at IS NULL) OR public.has_role(auth.uid(), 'admin'))
  WITH CHECK (true);
CREATE POLICY "author deletes unsigned notes"
  ON public.clinical_notes FOR DELETE TO authenticated
  USING ((auth.uid() = author_id AND signed_at IS NULL) OR public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER trg_clin_notes_updated
  BEFORE UPDATE ON public.clinical_notes
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- =========================================================
-- 4) clinical_diagnoses  (FHIR Condition)
-- =========================================================
CREATE TABLE public.clinical_diagnoses (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  encounter_id UUID NOT NULL REFERENCES public.clinical_encounters(id) ON DELETE CASCADE,
  patient_id UUID NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  icd10_code TEXT,
  snomed_code TEXT,
  display TEXT NOT NULL,
  certainty TEXT NOT NULL DEFAULT 'confirmed',
    -- 'suspected' | 'confirmed' | 'ruled-out' | 'differential'
  is_primary BOOLEAN NOT NULL DEFAULT false,
  onset_date DATE,
  note TEXT,
  created_by UUID NOT NULL REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_clin_dx_encounter ON public.clinical_diagnoses(encounter_id);
CREATE INDEX idx_clin_dx_patient ON public.clinical_diagnoses(patient_id);
CREATE INDEX idx_clin_dx_icd ON public.clinical_diagnoses(icd10_code);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.clinical_diagnoses TO authenticated;
GRANT ALL ON public.clinical_diagnoses TO service_role;
ALTER TABLE public.clinical_diagnoses ENABLE ROW LEVEL SECURITY;

CREATE POLICY "auth users read diagnoses"
  ON public.clinical_diagnoses FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth users insert diagnoses"
  ON public.clinical_diagnoses FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = created_by);
CREATE POLICY "creator updates diagnoses"
  ON public.clinical_diagnoses FOR UPDATE TO authenticated
  USING (auth.uid() = created_by OR public.has_role(auth.uid(), 'admin'))
  WITH CHECK (true);
CREATE POLICY "creator deletes diagnoses"
  ON public.clinical_diagnoses FOR DELETE TO authenticated
  USING (auth.uid() = created_by OR public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER trg_clin_dx_updated
  BEFORE UPDATE ON public.clinical_diagnoses
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- =========================================================
-- 5) clinical_therapy_orders
-- =========================================================
CREATE TABLE public.clinical_therapy_orders (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  encounter_id UUID NOT NULL REFERENCES public.clinical_encounters(id) ON DELETE CASCADE,
  patient_id UUID NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  kind TEXT NOT NULL,
    -- 'medication' | 'procedure' | 'lifestyle' | 'diet' | 'imaging' | 'lab-request' | 'referral'
  atc_code TEXT,
  snomed_code TEXT,
  display TEXT NOT NULL,
  dose TEXT,
  route TEXT,
  frequency TEXT,
  duration TEXT,
  instructions TEXT,
  status TEXT NOT NULL DEFAULT 'active',
    -- 'active' | 'completed' | 'cancelled' | 'on-hold' | 'draft'
  starts_on DATE,
  ends_on DATE,
  ai_generated BOOLEAN NOT NULL DEFAULT false,
  created_by UUID NOT NULL REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_clin_tx_encounter ON public.clinical_therapy_orders(encounter_id);
CREATE INDEX idx_clin_tx_patient ON public.clinical_therapy_orders(patient_id, status);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.clinical_therapy_orders TO authenticated;
GRANT ALL ON public.clinical_therapy_orders TO service_role;
ALTER TABLE public.clinical_therapy_orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "auth users read therapy"
  ON public.clinical_therapy_orders FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth users insert therapy"
  ON public.clinical_therapy_orders FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = created_by);
CREATE POLICY "creator updates therapy"
  ON public.clinical_therapy_orders FOR UPDATE TO authenticated
  USING (auth.uid() = created_by OR public.has_role(auth.uid(), 'admin'))
  WITH CHECK (true);
CREATE POLICY "creator deletes therapy"
  ON public.clinical_therapy_orders FOR DELETE TO authenticated
  USING (auth.uid() = created_by OR public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER trg_clin_tx_updated
  BEFORE UPDATE ON public.clinical_therapy_orders
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- =========================================================
-- 6) clinical_calculator_results
-- =========================================================
CREATE TABLE public.clinical_calculator_results (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  encounter_id UUID REFERENCES public.clinical_encounters(id) ON DELETE CASCADE,
  patient_id UUID REFERENCES public.patients(id) ON DELETE CASCADE,
  calculator TEXT NOT NULL,
    -- 'bloodgas' | 't2dm' | 'who-lcg' | 'qsofa' | 'sirs' | 'preeclampsia' | ...
  inputs_json JSONB NOT NULL,
  outputs_json JSONB NOT NULL,
  interpretation_md TEXT,
  created_by UUID NOT NULL REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_clin_calc_patient ON public.clinical_calculator_results(patient_id, calculator, created_at DESC);
CREATE INDEX idx_clin_calc_encounter ON public.clinical_calculator_results(encounter_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.clinical_calculator_results TO authenticated;
GRANT ALL ON public.clinical_calculator_results TO service_role;
ALTER TABLE public.clinical_calculator_results ENABLE ROW LEVEL SECURITY;

CREATE POLICY "auth users read calc results"
  ON public.clinical_calculator_results FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth users insert calc results"
  ON public.clinical_calculator_results FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = created_by);
CREATE POLICY "creator updates calc results"
  ON public.clinical_calculator_results FOR UPDATE TO authenticated
  USING (auth.uid() = created_by OR public.has_role(auth.uid(), 'admin'))
  WITH CHECK (true);
CREATE POLICY "creator deletes calc results"
  ON public.clinical_calculator_results FOR DELETE TO authenticated
  USING (auth.uid() = created_by OR public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER trg_clin_calc_updated
  BEFORE UPDATE ON public.clinical_calculator_results
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
