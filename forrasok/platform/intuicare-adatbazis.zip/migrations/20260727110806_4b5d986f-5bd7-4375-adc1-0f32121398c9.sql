-- 1) Therapy orders: re-verify patient access on update
DROP POLICY IF EXISTS "creator updates therapy" ON public.clinical_therapy_orders;
CREATE POLICY "creator updates therapy"
ON public.clinical_therapy_orders
FOR UPDATE
USING ((auth.uid() = created_by) AND can_access_patient(patient_id))
WITH CHECK ((auth.uid() = created_by) AND can_access_patient(patient_id));

-- 2) Trigger-only SECURITY DEFINER functions must not be API-callable
REVOKE ALL ON FUNCTION public.notify_assignment_insert() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.notify_assignment_delete() FROM PUBLIC, anon, authenticated;

-- 3) Privileged SECURITY DEFINER functions: enforce in-function authorization
CREATE OR REPLACE FUNCTION public.close_leave_year(_tenant uuid, _ev integer, _actor uuid)
 RETURNS integer
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_rec RECORD;
  v_cnt int := 0;
  v_pol RECORD;
  v_max_carry numeric;
  v_uid uuid := auth.uid();
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Authentikáció szükséges.' USING ERRCODE = '42501';
  END IF;
  IF _tenant IS DISTINCT FROM public.current_tenant_id() THEN
    RAISE EXCEPTION 'Nincs jogosultság ehhez a szervezethez.' USING ERRCODE = '42501';
  END IF;
  IF NOT COALESCE(public.has_permission(v_uid, 'manage_tenant'), false) THEN
    RAISE EXCEPTION 'Csak adminisztrátor zárhatja le a szabadságévet.' USING ERRCODE = '42501';
  END IF;

  SELECT * INTO v_pol FROM public.leave_policy WHERE tenant_id = _tenant AND ev = _ev;

  FOR v_rec IN
    SELECT * FROM public.leave_entitlement
    WHERE tenant_id = _tenant AND ev = _ev AND hatralevo > 0 AND lezart_at IS NULL
  LOOP
    v_max_carry := v_rec.hatralevo;
    IF v_rec.jogcim = 'alap' AND COALESCE(v_pol.max_carryover_alap_quarter, true) THEN
      v_max_carry := LEAST(v_rec.hatralevo, ROUND(v_rec.jaro_nap / 4.0, 2));
    END IF;

    INSERT INTO public.leave_entitlement (tenant_id, user_id, ev, jogcim, jaro_nap, athozott_nap)
    VALUES (_tenant, v_rec.user_id, _ev + 1, v_rec.jogcim, 0, v_max_carry)
    ON CONFLICT (tenant_id, user_id, ev, jogcim)
    DO UPDATE SET athozott_nap = public.leave_entitlement.athozott_nap + v_max_carry, updated_at = now();

    INSERT INTO public.leave_carryover_log (tenant_id, user_id, from_year, to_year, jogcim, nap, tipus, created_by, megjegyzes)
    VALUES (_tenant, v_rec.user_id, _ev, _ev + 1, v_rec.jogcim, v_max_carry, 'carryover', _actor,
            CASE WHEN v_max_carry < v_rec.hatralevo THEN format('Korlát: %s nap nem hozható át', v_rec.hatralevo - v_max_carry) ELSE NULL END);

    IF v_max_carry < v_rec.hatralevo THEN
      INSERT INTO public.leave_carryover_log (tenant_id, user_id, from_year, jogcim, nap, tipus, created_by, megjegyzes)
      VALUES (_tenant, v_rec.user_id, _ev, v_rec.jogcim, v_rec.hatralevo - v_max_carry, 'forfeit', _actor, 'Mt. 123. § alap 1/4 korlát');
    END IF;

    UPDATE public.leave_entitlement SET lezart_at = now(), lezart_by = _actor WHERE id = v_rec.id;
    v_cnt := v_cnt + 1;
  END LOOP;

  RETURN v_cnt;
END;
$function$;

CREATE OR REPLACE FUNCTION public.log_leave_admin(_tenant uuid, _actor uuid, _action text, _ev integer, _target_user uuid, _jogcim text, _nap numeric, _before jsonb, _after jsonb, _summary text)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_id uuid;
  v_uid uuid := auth.uid();
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Authentikáció szükséges.' USING ERRCODE = '42501';
  END IF;
  IF _tenant IS DISTINCT FROM public.current_tenant_id() THEN
    RAISE EXCEPTION 'Nincs jogosultság ehhez a szervezethez.' USING ERRCODE = '42501';
  END IF;
  IF NOT COALESCE(public.has_permission(v_uid, 'manage_tenant'), false) THEN
    RAISE EXCEPTION 'Csak adminisztrátor naplózhat szabadság-műveletet.' USING ERRCODE = '42501';
  END IF;

  INSERT INTO public.leave_admin_audit
    (tenant_id, actor_user_id, action, ev, target_user_id, jogcim, nap, before_data, after_data, summary)
  VALUES (_tenant, v_uid, _action, _ev, _target_user, _jogcim, _nap, _before, _after, _summary)
  RETURNING id INTO v_id;
  RETURN v_id;
END $function$;
