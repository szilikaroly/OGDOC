CREATE UNIQUE INDEX IF NOT EXISTS uq_staff_roles_global_kulcs
  ON public.staff_roles (kulcs) WHERE tenant_id IS NULL;