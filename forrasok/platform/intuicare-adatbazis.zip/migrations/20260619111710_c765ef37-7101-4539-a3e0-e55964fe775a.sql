
-- 1) Add approval-status columns to profile_daily_preferences
ALTER TABLE public.profile_daily_preferences
  ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'tervezett',
  ADD COLUMN IF NOT EXISTS submitted_at timestamptz,
  ADD COLUMN IF NOT EXISTS jovahagyo_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS jovahagyas_at timestamptz,
  ADD COLUMN IF NOT EXISTS jovahagyas_indok text;

DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'pdp_status_check'
  ) THEN
    ALTER TABLE public.profile_daily_preferences
      ADD CONSTRAINT pdp_status_check
      CHECK (status IN ('tervezett','jovahagyasra_var','jovahagyott','elutasitott'));
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_pdp_status ON public.profile_daily_preferences(tenant_id, status);

-- 2) Event log table
CREATE TABLE IF NOT EXISTS public.profile_daily_preferences_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  pref_id uuid REFERENCES public.profile_daily_preferences(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  actor_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  action text NOT NULL CHECK (action IN ('letrehozva','modositva','torolve','beadva','jovahagyva','elutasitva')),
  from_status text,
  to_status text,
  nap_iso smallint,
  before_data jsonb,
  after_data jsonb,
  indok text,
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT ON public.profile_daily_preferences_events TO authenticated;
GRANT ALL ON public.profile_daily_preferences_events TO service_role;

ALTER TABLE public.profile_daily_preferences_events ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS pdp_events_select ON public.profile_daily_preferences_events;
CREATE POLICY pdp_events_select ON public.profile_daily_preferences_events
  FOR SELECT TO authenticated
  USING (
    tenant_id = public.current_tenant_id()
    AND (
      user_id = auth.uid()
      OR public.has_permission(auth.uid(), 'view_team')
      OR public.has_permission(auth.uid(), 'manage_schedule')
      OR public.has_permission(auth.uid(), 'manage_tenant')
    )
  );

-- Writes happen only through SECURITY DEFINER trigger; deny direct user inserts
DROP POLICY IF EXISTS pdp_events_no_direct_write ON public.profile_daily_preferences_events;
CREATE POLICY pdp_events_no_direct_write ON public.profile_daily_preferences_events
  FOR INSERT TO authenticated
  WITH CHECK (false);

CREATE INDEX IF NOT EXISTS idx_pdp_events_pref ON public.profile_daily_preferences_events(pref_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_pdp_events_user ON public.profile_daily_preferences_events(user_id, created_at DESC);

-- 3) Approval guard trigger (mirrors profile_preferences_guard)
CREATE OR REPLACE FUNCTION public.profile_daily_preferences_guard()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_can_approve boolean;
BEGIN
  IF TG_OP = 'UPDATE' AND NEW.status IS DISTINCT FROM OLD.status THEN
    IF NEW.status IN ('jovahagyott','elutasitott') THEN
      v_can_approve := COALESCE(public.has_permission(v_uid,'manage_schedule'), false)
                    OR COALESCE(public.has_permission(v_uid,'manage_tenant'), false);
      IF NOT v_can_approve THEN
        INSERT INTO public.admin_audit_log(tenant_id, user_id, action, table_name, record_id, before_data, after_data)
        VALUES (
          COALESCE(NEW.tenant_id, public.current_tenant_id()), v_uid, 'FORBIDDEN_APPROVAL',
          TG_TABLE_NAME, NEW.id::text,
          jsonb_build_object('status', OLD.status),
          jsonb_build_object('status', NEW.status)
        );
        RAISE EXCEPTION 'Nincs jogosultsága a napi preferencia jóváhagyásához.' USING ERRCODE = '42501';
      END IF;
      IF NEW.user_id = v_uid THEN
        RAISE EXCEPTION 'A saját preferenciáját nem hagyhatja jóvá / utasíthatja el.' USING ERRCODE = '42501';
      END IF;
      IF NEW.status = 'elutasitott' AND COALESCE(btrim(NEW.jovahagyas_indok), '') = '' THEN
        RAISE EXCEPTION 'Elutasításhoz kötelező az indoklás.' USING ERRCODE = '22023';
      END IF;
      NEW.jovahagyo_id := v_uid;
      NEW.jovahagyas_at := now();
    ELSIF NEW.status = 'jovahagyasra_var' THEN
      NEW.submitted_at := now();
      NEW.jovahagyo_id := NULL;
      NEW.jovahagyas_at := NULL;
      NEW.jovahagyas_indok := NULL;
    ELSIF NEW.status = 'tervezett' THEN
      NEW.submitted_at := NULL;
      NEW.jovahagyo_id := NULL;
      NEW.jovahagyas_at := NULL;
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS pdp_guard ON public.profile_daily_preferences;
CREATE TRIGGER pdp_guard
  BEFORE UPDATE ON public.profile_daily_preferences
  FOR EACH ROW EXECUTE FUNCTION public.profile_daily_preferences_guard();

-- 4) Event-log trigger
CREATE OR REPLACE FUNCTION public.profile_daily_preferences_log_event()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_action text;
  v_from text;
  v_to text;
  v_user_id uuid;
  v_tenant uuid;
  v_pref uuid;
  v_nap smallint;
BEGIN
  IF TG_OP = 'INSERT' THEN
    v_action := 'letrehozva';
    v_from := NULL; v_to := NEW.status;
    v_user_id := NEW.user_id; v_tenant := NEW.tenant_id;
    v_pref := NEW.id; v_nap := NEW.nap_iso;
    INSERT INTO public.profile_daily_preferences_events
      (tenant_id, pref_id, user_id, actor_id, action, from_status, to_status, nap_iso, before_data, after_data)
    VALUES (v_tenant, v_pref, v_user_id, auth.uid(), v_action, v_from, v_to, v_nap, NULL, to_jsonb(NEW));
    RETURN NEW;
  ELSIF TG_OP = 'UPDATE' THEN
    IF NEW.status IS DISTINCT FROM OLD.status THEN
      v_action := CASE NEW.status
        WHEN 'jovahagyasra_var' THEN 'beadva'
        WHEN 'jovahagyott' THEN 'jovahagyva'
        WHEN 'elutasitott' THEN 'elutasitva'
        ELSE 'modositva'
      END;
    ELSE
      v_action := 'modositva';
    END IF;
    INSERT INTO public.profile_daily_preferences_events
      (tenant_id, pref_id, user_id, actor_id, action, from_status, to_status, nap_iso, before_data, after_data, indok)
    VALUES (NEW.tenant_id, NEW.id, NEW.user_id, auth.uid(), v_action,
            OLD.status, NEW.status, NEW.nap_iso, to_jsonb(OLD), to_jsonb(NEW),
            CASE WHEN v_action IN ('jovahagyva','elutasitva') THEN NEW.jovahagyas_indok ELSE NULL END);
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    INSERT INTO public.profile_daily_preferences_events
      (tenant_id, pref_id, user_id, actor_id, action, from_status, to_status, nap_iso, before_data, after_data)
    VALUES (OLD.tenant_id, OLD.id, OLD.user_id, auth.uid(), 'torolve',
            OLD.status, NULL, OLD.nap_iso, to_jsonb(OLD), NULL);
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$;

DROP TRIGGER IF EXISTS pdp_log_event ON public.profile_daily_preferences;
CREATE TRIGGER pdp_log_event
  AFTER INSERT OR UPDATE OR DELETE ON public.profile_daily_preferences
  FOR EACH ROW EXECUTE FUNCTION public.profile_daily_preferences_log_event();

-- 5) Notification on status change
CREATE OR REPLACE FUNCTION public.notify_daily_preferences_status()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_cim text;
BEGIN
  IF NEW.status IS DISTINCT FROM OLD.status
     AND NEW.status IN ('jovahagyott','elutasitott') THEN
    v_cim := CASE NEW.status
      WHEN 'jovahagyott' THEN 'Napi preferencia jóváhagyva'
      ELSE 'Napi preferencia elutasítva'
    END;
    INSERT INTO public.notifications (tenant_id, user_id, tipus, cim, uzenet, link)
    VALUES (NEW.tenant_id, NEW.user_id, 'preferencia', v_cim, NEW.jovahagyas_indok, '/karakterlap');
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS pdp_notify_status ON public.profile_daily_preferences;
CREATE TRIGGER pdp_notify_status
  AFTER UPDATE ON public.profile_daily_preferences
  FOR EACH ROW EXECUTE FUNCTION public.notify_daily_preferences_status();
