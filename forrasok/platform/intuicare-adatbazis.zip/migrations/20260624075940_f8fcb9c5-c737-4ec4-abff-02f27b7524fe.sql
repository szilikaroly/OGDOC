ALTER TABLE public.patient_emergency_card REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.patient_emergency_card;