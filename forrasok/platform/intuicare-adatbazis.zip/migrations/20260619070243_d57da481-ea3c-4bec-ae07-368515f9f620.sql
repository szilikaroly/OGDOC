CREATE TRIGGER schedule_share_tokens_audit
AFTER INSERT OR UPDATE OR DELETE ON public.schedule_share_tokens
FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();