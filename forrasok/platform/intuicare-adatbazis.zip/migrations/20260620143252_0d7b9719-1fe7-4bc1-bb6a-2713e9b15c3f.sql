CREATE TABLE public.obstetric_partograms (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  encounter_id UUID NOT NULL REFERENCES public.clinical_encounters(id) ON DELETE CASCADE,
  patient_id UUID NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  labor_start_ts TIMESTAMPTZ NOT NULL DEFAULT now(),
  parity_gravida_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  membrane_status TEXT,
  notes_md TEXT,
  created_by UUID NOT NULL DEFAULT auth.uid(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.obstetric_partograms TO authenticated;
GRANT ALL ON public.obstetric_partograms TO service_role;
ALTER TABLE public.obstetric_partograms ENABLE ROW LEVEL SECURITY;
CREATE POLICY "partogram_select" ON public.obstetric_partograms FOR SELECT TO authenticated USING (created_by = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "partogram_insert" ON public.obstetric_partograms FOR INSERT TO authenticated WITH CHECK (created_by = auth.uid());
CREATE POLICY "partogram_update" ON public.obstetric_partograms FOR UPDATE TO authenticated USING (created_by = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "partogram_delete" ON public.obstetric_partograms FOR DELETE TO authenticated USING (created_by = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE TRIGGER update_obstetric_partograms_updated_at BEFORE UPDATE ON public.obstetric_partograms FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.obstetric_partogram_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  partogram_id UUID NOT NULL REFERENCES public.obstetric_partograms(id) ON DELETE CASCADE,
  recorded_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  cervix_cm NUMERIC(3,1),
  descent_station SMALLINT,
  contractions_per_10min SMALLINT,
  contraction_duration_sec SMALLINT,
  fetal_heart_rate SMALLINT,
  maternal_hr SMALLINT,
  maternal_bp_sys SMALLINT,
  maternal_bp_dia SMALLINT,
  temp_c NUMERIC(4,1),
  liquor_color TEXT,
  moulding TEXT,
  oxytocin_mu NUMERIC(6,2),
  drugs_text TEXT,
  notes TEXT,
  created_by UUID NOT NULL DEFAULT auth.uid(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.obstetric_partogram_entries TO authenticated;
GRANT ALL ON public.obstetric_partogram_entries TO service_role;
ALTER TABLE public.obstetric_partogram_entries ENABLE ROW LEVEL SECURITY;
CREATE POLICY "partogram_entry_select" ON public.obstetric_partogram_entries FOR SELECT TO authenticated USING (EXISTS (SELECT 1 FROM public.obstetric_partograms p WHERE p.id = partogram_id AND (p.created_by = auth.uid() OR public.has_role(auth.uid(),'admin'))));
CREATE POLICY "partogram_entry_insert" ON public.obstetric_partogram_entries FOR INSERT TO authenticated WITH CHECK (created_by = auth.uid() AND EXISTS (SELECT 1 FROM public.obstetric_partograms p WHERE p.id = partogram_id AND p.created_by = auth.uid()));
CREATE POLICY "partogram_entry_update" ON public.obstetric_partogram_entries FOR UPDATE TO authenticated USING (created_by = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "partogram_entry_delete" ON public.obstetric_partogram_entries FOR DELETE TO authenticated USING (created_by = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE INDEX idx_partogram_entries_partogram ON public.obstetric_partogram_entries(partogram_id, recorded_at);