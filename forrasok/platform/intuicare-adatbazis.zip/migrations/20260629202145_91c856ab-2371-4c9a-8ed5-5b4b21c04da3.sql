
CREATE POLICY "cms-media public read" ON storage.objects FOR SELECT USING (bucket_id = 'cms-media');
CREATE POLICY "cms-media editors upload" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'cms-media' AND public.has_cms_access(auth.uid()));
CREATE POLICY "cms-media editors update" ON storage.objects FOR UPDATE TO authenticated USING (bucket_id = 'cms-media' AND public.has_cms_access(auth.uid()));
CREATE POLICY "cms-media editors delete" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'cms-media' AND public.has_cms_access(auth.uid()));
