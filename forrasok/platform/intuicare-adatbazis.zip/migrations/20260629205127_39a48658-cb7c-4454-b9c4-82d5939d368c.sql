-- ============================================================
-- 1) cms_staff_profiles
-- ============================================================
CREATE TABLE IF NOT EXISTS public.cms_staff_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  slug text NOT NULL,
  locale text NOT NULL DEFAULT 'hu',
  display_name text NOT NULL,
  title text,
  photo_url text,
  bio text,
  specialties text[] DEFAULT '{}',
  languages text[] DEFAULT '{}',
  publications jsonb DEFAULT '[]'::jsonb,
  publish_schedule boolean DEFAULT false,
  is_published boolean DEFAULT false,
  sort_order int DEFAULT 0,
  seo_title text,
  seo_description text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (slug, locale)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_staff_profiles TO authenticated;
GRANT SELECT ON public.cms_staff_profiles TO anon;
GRANT ALL ON public.cms_staff_profiles TO service_role;

ALTER TABLE public.cms_staff_profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public can view published staff profiles"
  ON public.cms_staff_profiles FOR SELECT
  USING (is_published = true);

CREATE POLICY "CMS editors manage staff profiles"
  ON public.cms_staff_profiles FOR ALL
  TO authenticated
  USING (public.has_cms_access(auth.uid()))
  WITH CHECK (public.has_cms_access(auth.uid()));

-- ============================================================
-- 2) cms_faqs
-- ============================================================
CREATE TABLE IF NOT EXISTS public.cms_faqs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  locale text NOT NULL DEFAULT 'hu',
  question text NOT NULL,
  answer text NOT NULL,
  tags text[] DEFAULT '{}',
  sort_order int DEFAULT 0,
  is_published boolean DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_faqs TO authenticated;
GRANT SELECT ON public.cms_faqs TO anon;
GRANT ALL ON public.cms_faqs TO service_role;

ALTER TABLE public.cms_faqs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public can view published FAQs"
  ON public.cms_faqs FOR SELECT
  USING (is_published = true);

CREATE POLICY "CMS editors manage FAQs"
  ON public.cms_faqs FOR ALL
  TO authenticated
  USING (public.has_cms_access(auth.uid()))
  WITH CHECK (public.has_cms_access(auth.uid()));

CREATE INDEX IF NOT EXISTS cms_faqs_tags_idx ON public.cms_faqs USING GIN (tags);

-- ============================================================
-- 3) contact_messages
-- ============================================================
CREATE TABLE IF NOT EXISTS public.contact_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_unit_id uuid REFERENCES public.org_units(id) ON DELETE SET NULL,
  source_page_slug text,
  sender_name text NOT NULL,
  sender_email text NOT NULL,
  sender_phone text,
  subject text,
  body text NOT NULL,
  locale text DEFAULT 'hu',
  status text NOT NULL DEFAULT 'new',
  handled_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  handled_at timestamptz,
  ip_hash text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT INSERT ON public.contact_messages TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.contact_messages TO authenticated;
GRANT ALL ON public.contact_messages TO service_role;

ALTER TABLE public.contact_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can submit a contact message"
  ON public.contact_messages FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "CMS editors view contact messages"
  ON public.contact_messages FOR SELECT
  TO authenticated
  USING (public.has_cms_access(auth.uid()));

CREATE POLICY "CMS editors update contact messages"
  ON public.contact_messages FOR UPDATE
  TO authenticated
  USING (public.has_cms_access(auth.uid()))
  WITH CHECK (public.has_cms_access(auth.uid()));

CREATE INDEX IF NOT EXISTS contact_messages_status_idx ON public.contact_messages (status, created_at DESC);

-- ============================================================
-- 4) cms_site_settings (single-row config)
-- ============================================================
CREATE TABLE IF NOT EXISTS public.cms_site_settings (
  id int PRIMARY KEY DEFAULT 1,
  sos_active boolean NOT NULL DEFAULT false,
  sos_message text,
  robots_txt text,
  default_og_image_url text,
  default_locale text NOT NULL DEFAULT 'hu',
  organization_jsonld jsonb,
  updated_at timestamptz NOT NULL DEFAULT now(),
  updated_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  CONSTRAINT cms_site_settings_singleton CHECK (id = 1)
);

GRANT SELECT, INSERT, UPDATE ON public.cms_site_settings TO authenticated;
GRANT SELECT ON public.cms_site_settings TO anon;
GRANT ALL ON public.cms_site_settings TO service_role;

ALTER TABLE public.cms_site_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public can view site settings"
  ON public.cms_site_settings FOR SELECT
  USING (true);

CREATE POLICY "CMS editors manage site settings"
  ON public.cms_site_settings FOR ALL
  TO authenticated
  USING (public.has_cms_access(auth.uid()))
  WITH CHECK (public.has_cms_access(auth.uid()));

INSERT INTO public.cms_site_settings (id) VALUES (1) ON CONFLICT (id) DO NOTHING;

-- ============================================================
-- updated_at triggers
-- ============================================================
CREATE OR REPLACE FUNCTION public.cms_touch_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END $$;

DROP TRIGGER IF EXISTS trg_cms_staff_profiles_touch ON public.cms_staff_profiles;
CREATE TRIGGER trg_cms_staff_profiles_touch BEFORE UPDATE ON public.cms_staff_profiles
  FOR EACH ROW EXECUTE FUNCTION public.cms_touch_updated_at();

DROP TRIGGER IF EXISTS trg_cms_faqs_touch ON public.cms_faqs;
CREATE TRIGGER trg_cms_faqs_touch BEFORE UPDATE ON public.cms_faqs
  FOR EACH ROW EXECUTE FUNCTION public.cms_touch_updated_at();

DROP TRIGGER IF EXISTS trg_contact_messages_touch ON public.contact_messages;
CREATE TRIGGER trg_contact_messages_touch BEFORE UPDATE ON public.contact_messages
  FOR EACH ROW EXECUTE FUNCTION public.cms_touch_updated_at();

DROP TRIGGER IF EXISTS trg_cms_site_settings_touch ON public.cms_site_settings;
CREATE TRIGGER trg_cms_site_settings_touch BEFORE UPDATE ON public.cms_site_settings
  FOR EACH ROW EXECUTE FUNCTION public.cms_touch_updated_at();