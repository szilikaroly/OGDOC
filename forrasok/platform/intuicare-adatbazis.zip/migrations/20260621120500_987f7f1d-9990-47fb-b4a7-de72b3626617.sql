DO $$ BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.ai_assistant_actions; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
ALTER TABLE public.ai_assistant_actions REPLICA IDENTITY FULL;