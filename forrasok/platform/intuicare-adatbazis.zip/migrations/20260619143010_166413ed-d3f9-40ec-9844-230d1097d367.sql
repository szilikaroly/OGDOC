
-- ============================================================
-- Monitoring modul — Fázis 1 (séma)
-- ============================================================

-- 1) Enumok
DO $$ BEGIN
  CREATE TYPE public.monitoring_program_tipus AS ENUM ('terhesseg','betegseg','csaladtervezes');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.measurement_kind AS ENUM (
    'testsuly','testmagassag','bmi','haskorfogat','nyakkorfogat',
    'vernyomas','vercukor','testho','sport','lepes','pulzus','hrv','magzatmozgas'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.measurement_source AS ENUM ('kezi','wearable','eszkoz');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.monitoring_alert_kind AS ENUM (
    'magzatmozgas_csokkent','gdm_vercukor','preeclampsia_bp','urgent_bp',
    'laz','szekletveres','egyeb'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.monitoring_alert_status AS ENUM ('open','acknowledged','resolved');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.monitoring_alert_severity AS ENUM ('info','figyelem','surgos','kritikus');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- 2) monitoring_programs
CREATE TABLE public.monitoring_programs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  tipus public.monitoring_program_tipus NOT NULL,
  kezdes date NOT NULL DEFAULT current_date,
  varhato_veg date NULL,
  aktiv boolean NOT NULL DEFAULT true,
  megjegyzes text NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_mon_programs_patient ON public.monitoring_programs(patient_id);
CREATE INDEX idx_mon_programs_tenant ON public.monitoring_programs(tenant_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.monitoring_programs TO authenticated;
GRANT ALL ON public.monitoring_programs TO service_role;
ALTER TABLE public.monitoring_programs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "tenant_isolation_mon_programs" ON public.monitoring_programs
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id())
  WITH CHECK (tenant_id = public.current_tenant_id());
CREATE POLICY "service_role_mon_programs" ON public.monitoring_programs
  FOR ALL TO service_role USING (true) WITH CHECK (true);
CREATE TRIGGER trg_mon_programs_touch BEFORE UPDATE ON public.monitoring_programs
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER trg_mon_programs_audit AFTER INSERT OR UPDATE OR DELETE ON public.monitoring_programs
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- 3) measurements (közös mérés-eseménytár)
CREATE TABLE public.measurements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  program_id uuid NULL REFERENCES public.monitoring_programs(id) ON DELETE SET NULL,
  kind public.measurement_kind NOT NULL,
  ts timestamptz NOT NULL DEFAULT now(),
  value numeric NULL,
  value2 numeric NULL,
  unit text NULL,
  context jsonb NULL,
  source public.measurement_source NOT NULL DEFAULT 'kezi',
  recorded_by uuid NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_measurements_patient_ts ON public.measurements(patient_id, ts DESC);
CREATE INDEX idx_measurements_kind_ts ON public.measurements(kind, ts DESC);
CREATE INDEX idx_measurements_program ON public.measurements(program_id) WHERE program_id IS NOT NULL;
CREATE INDEX idx_measurements_tenant ON public.measurements(tenant_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.measurements TO authenticated;
GRANT ALL ON public.measurements TO service_role;
ALTER TABLE public.measurements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "tenant_isolation_measurements" ON public.measurements
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id())
  WITH CHECK (tenant_id = public.current_tenant_id());
CREATE POLICY "service_role_measurements" ON public.measurements
  FOR ALL TO service_role USING (true) WITH CHECK (true);
CREATE TRIGGER trg_measurements_audit AFTER INSERT OR UPDATE OR DELETE ON public.measurements
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- 4) food_log
CREATE TABLE public.food_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  program_id uuid NULL REFERENCES public.monitoring_programs(id) ON DELETE SET NULL,
  ts timestamptz NOT NULL DEFAULT now(),
  foto_url text NULL,
  leiras text NULL,
  ai_becsult_kcal numeric NULL,
  ai_makro jsonb NULL,
  etkezes_tipus text NULL,
  megbizhatosag text NOT NULL DEFAULT 'alacsony',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_food_log_patient_ts ON public.food_log(patient_id, ts DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.food_log TO authenticated;
GRANT ALL ON public.food_log TO service_role;
ALTER TABLE public.food_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY "tenant_isolation_food_log" ON public.food_log
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id())
  WITH CHECK (tenant_id = public.current_tenant_id());
CREATE POLICY "service_role_food_log" ON public.food_log
  FOR ALL TO service_role USING (true) WITH CHECK (true);

-- 5) stool_log (Bristol + Róma IV)
CREATE TABLE public.stool_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  program_id uuid NULL REFERENCES public.monitoring_programs(id) ON DELETE SET NULL,
  ts timestamptz NOT NULL DEFAULT now(),
  foto_url text NULL,
  bristol_tipus int NULL CHECK (bristol_tipus BETWEEN 1 AND 7),
  ai_bristol_javaslat int NULL CHECK (ai_bristol_javaslat BETWEEN 1 AND 7),
  rome_tunetek jsonb NULL,
  veres boolean NOT NULL DEFAULT false,
  nyak boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_stool_log_patient_ts ON public.stool_log(patient_id, ts DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.stool_log TO authenticated;
GRANT ALL ON public.stool_log TO service_role;
ALTER TABLE public.stool_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY "tenant_isolation_stool_log" ON public.stool_log
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id())
  WITH CHECK (tenant_id = public.current_tenant_id());
CREATE POLICY "service_role_stool_log" ON public.stool_log
  FOR ALL TO service_role USING (true) WITH CHECK (true);

-- 6) contractions (terhességi fájás-timer)
CREATE TABLE public.contractions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  program_id uuid NULL REFERENCES public.monitoring_programs(id) ON DELETE SET NULL,
  kezdes timestamptz NOT NULL,
  veg timestamptz NULL,
  idotartam_mp int NULL,
  gyakorisag_perc numeric NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_contractions_patient_kezdes ON public.contractions(patient_id, kezdes DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.contractions TO authenticated;
GRANT ALL ON public.contractions TO service_role;
ALTER TABLE public.contractions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "tenant_isolation_contractions" ON public.contractions
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id())
  WITH CHECK (tenant_id = public.current_tenant_id());
CREATE POLICY "service_role_contractions" ON public.contractions
  FOR ALL TO service_role USING (true) WITH CHECK (true);

-- 7) fetal_movements (kick counter)
CREATE TABLE public.fetal_movements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  program_id uuid NULL REFERENCES public.monitoring_programs(id) ON DELETE SET NULL,
  datum date NOT NULL DEFAULT current_date,
  szakasz_kezdes timestamptz NOT NULL DEFAULT now(),
  mozgas_szam int NOT NULL DEFAULT 0,
  tizedik_mozgas_ido timestamptz NULL,
  eltelt_perc int NULL,
  jegyzet text NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_fetal_movements_patient ON public.fetal_movements(patient_id, datum DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.fetal_movements TO authenticated;
GRANT ALL ON public.fetal_movements TO service_role;
ALTER TABLE public.fetal_movements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "tenant_isolation_fetal_mov" ON public.fetal_movements
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id())
  WITH CHECK (tenant_id = public.current_tenant_id());
CREATE POLICY "service_role_fetal_mov" ON public.fetal_movements
  FOR ALL TO service_role USING (true) WITH CHECK (true);

-- 8) menstrual_cycles
CREATE TABLE public.menstrual_cycles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  program_id uuid NULL REFERENCES public.monitoring_programs(id) ON DELETE SET NULL,
  ciklus_kezdet date NOT NULL,
  ciklus_hossz int NULL,
  menstruacio_hossz int NULL,
  tunetek jsonb NULL,
  bbt_id uuid NULL REFERENCES public.measurements(id) ON DELETE SET NULL,
  ovulacio_becsult date NULL,
  termekeny_ablak_tol date NULL,
  termekeny_ablak_ig date NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_menstrual_patient ON public.menstrual_cycles(patient_id, ciklus_kezdet DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.menstrual_cycles TO authenticated;
GRANT ALL ON public.menstrual_cycles TO service_role;
ALTER TABLE public.menstrual_cycles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "tenant_isolation_menstrual" ON public.menstrual_cycles
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id())
  WITH CHECK (tenant_id = public.current_tenant_id());
CREATE POLICY "service_role_menstrual" ON public.menstrual_cycles
  FOR ALL TO service_role USING (true) WITH CHECK (true);

-- 9) wearable_data
CREATE TABLE public.wearable_data (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  provider text NOT NULL,
  datum date NOT NULL,
  lepes int NULL,
  atlag_pulzus int NULL,
  nyugalmi_pulzus int NULL,
  hrv_ms numeric NULL,
  alvas_perc int NULL,
  raw jsonb NULL,
  synced_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (patient_id, provider, datum)
);
CREATE INDEX idx_wearable_patient_datum ON public.wearable_data(patient_id, datum DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.wearable_data TO authenticated;
GRANT ALL ON public.wearable_data TO service_role;
ALTER TABLE public.wearable_data ENABLE ROW LEVEL SECURITY;
CREATE POLICY "tenant_isolation_wearable" ON public.wearable_data
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id())
  WITH CHECK (tenant_id = public.current_tenant_id());
CREATE POLICY "service_role_wearable" ON public.wearable_data
  FOR ALL TO service_role USING (true) WITH CHECK (true);

-- 10) monitoring_thresholds (programonként paraméterezhető küszöbök)
CREATE TABLE public.monitoring_thresholds (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  program_id uuid NULL REFERENCES public.monitoring_programs(id) ON DELETE CASCADE,
  patient_id uuid NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  -- ha mindkettő NULL → tenant-szintű alapérték
  kulcs text NOT NULL,           -- pl. 'bp_sys_warn', 'bp_sys_urgent', 'glucose_fasting'
  ertek numeric NOT NULL,
  unit text NULL,
  megjegyzes text NULL,
  beallito_id uuid NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, program_id, patient_id, kulcs)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.monitoring_thresholds TO authenticated;
GRANT ALL ON public.monitoring_thresholds TO service_role;
ALTER TABLE public.monitoring_thresholds ENABLE ROW LEVEL SECURITY;
CREATE POLICY "tenant_isolation_thresholds" ON public.monitoring_thresholds
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id())
  WITH CHECK (tenant_id = public.current_tenant_id());
CREATE POLICY "service_role_thresholds" ON public.monitoring_thresholds
  FOR ALL TO service_role USING (true) WITH CHECK (true);
CREATE TRIGGER trg_thresholds_touch BEFORE UPDATE ON public.monitoring_thresholds
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- 11) monitoring_alerts
CREATE TABLE public.monitoring_alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  program_id uuid NULL REFERENCES public.monitoring_programs(id) ON DELETE SET NULL,
  measurement_id uuid NULL REFERENCES public.measurements(id) ON DELETE SET NULL,
  fetal_movement_id uuid NULL REFERENCES public.fetal_movements(id) ON DELETE SET NULL,
  stool_log_id uuid NULL REFERENCES public.stool_log(id) ON DELETE SET NULL,
  kind public.monitoring_alert_kind NOT NULL,
  severity public.monitoring_alert_severity NOT NULL DEFAULT 'figyelem',
  status public.monitoring_alert_status NOT NULL DEFAULT 'open',
  uzenet text NOT NULL,
  acknowledged_by uuid NULL,
  acknowledged_at timestamptz NULL,
  ack_note text NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_mon_alerts_patient ON public.monitoring_alerts(patient_id, created_at DESC);
CREATE INDEX idx_mon_alerts_status ON public.monitoring_alerts(status, severity);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.monitoring_alerts TO authenticated;
GRANT ALL ON public.monitoring_alerts TO service_role;
ALTER TABLE public.monitoring_alerts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "tenant_isolation_mon_alerts" ON public.monitoring_alerts
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id())
  WITH CHECK (tenant_id = public.current_tenant_id());
CREATE POLICY "service_role_mon_alerts" ON public.monitoring_alerts
  FOR ALL TO service_role USING (true) WITH CHECK (true);
CREATE TRIGGER trg_mon_alerts_audit AFTER INSERT OR UPDATE OR DELETE ON public.monitoring_alerts
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- 12) Automatikus riasztás-trigger (vérnyomás, vércukor, láz, székletvér)
CREATE OR REPLACE FUNCTION public.measurements_auto_alert()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_sys numeric; v_dia numeric;
  v_th_sys_urg numeric; v_th_sys_warn numeric;
  v_th_dia_urg numeric; v_th_dia_warn numeric;
  v_th_glu_fast numeric; v_th_glu_pp numeric;
  v_th_fever numeric;
  v_is_post boolean;
BEGIN
  -- vérnyomás
  IF NEW.kind = 'vernyomas' AND NEW.value IS NOT NULL AND NEW.value2 IS NOT NULL THEN
    v_sys := NEW.value; v_dia := NEW.value2;
    SELECT ertek INTO v_th_sys_urg FROM public.monitoring_thresholds
      WHERE tenant_id = NEW.tenant_id AND kulcs = 'bp_sys_urgent'
        AND (program_id = NEW.program_id OR program_id IS NULL)
      ORDER BY program_id NULLS LAST LIMIT 1;
    v_th_sys_urg := COALESCE(v_th_sys_urg, 160);
    SELECT ertek INTO v_th_dia_urg FROM public.monitoring_thresholds
      WHERE tenant_id = NEW.tenant_id AND kulcs = 'bp_dia_urgent'
        AND (program_id = NEW.program_id OR program_id IS NULL)
      ORDER BY program_id NULLS LAST LIMIT 1;
    v_th_dia_urg := COALESCE(v_th_dia_urg, 110);
    SELECT ertek INTO v_th_sys_warn FROM public.monitoring_thresholds
      WHERE tenant_id = NEW.tenant_id AND kulcs = 'bp_sys_warn'
        AND (program_id = NEW.program_id OR program_id IS NULL)
      ORDER BY program_id NULLS LAST LIMIT 1;
    v_th_sys_warn := COALESCE(v_th_sys_warn, 140);
    SELECT ertek INTO v_th_dia_warn FROM public.monitoring_thresholds
      WHERE tenant_id = NEW.tenant_id AND kulcs = 'bp_dia_warn'
        AND (program_id = NEW.program_id OR program_id IS NULL)
      ORDER BY program_id NULLS LAST LIMIT 1;
    v_th_dia_warn := COALESCE(v_th_dia_warn, 90);

    IF v_sys >= v_th_sys_urg OR v_dia >= v_th_dia_urg THEN
      INSERT INTO public.monitoring_alerts(tenant_id, patient_id, program_id, measurement_id, kind, severity, uzenet)
      VALUES (NEW.tenant_id, NEW.patient_id, NEW.program_id, NEW.id,
              'urgent_bp','kritikus',
              format('Sürgős vérnyomás-eszkaláció: %s/%s Hgmm — azonnali orvosi konzultáció.', v_sys::text, v_dia::text));
    ELSIF v_sys >= v_th_sys_warn OR v_dia >= v_th_dia_warn THEN
      INSERT INTO public.monitoring_alerts(tenant_id, patient_id, program_id, measurement_id, kind, severity, uzenet)
      VALUES (NEW.tenant_id, NEW.patient_id, NEW.program_id, NEW.id,
              'preeclampsia_bp','figyelem',
              format('Magas vérnyomás: %s/%s Hgmm — klinikus felülvizsgálat javasolt.', v_sys::text, v_dia::text));
    END IF;
  END IF;

  -- vércukor (GDM)
  IF NEW.kind = 'vercukor' AND NEW.value IS NOT NULL THEN
    v_is_post := COALESCE((NEW.context->>'idopont') ILIKE '%_utan', false);
    IF v_is_post THEN
      SELECT ertek INTO v_th_glu_pp FROM public.monitoring_thresholds
        WHERE tenant_id = NEW.tenant_id AND kulcs = 'glucose_postprandial'
          AND (program_id = NEW.program_id OR program_id IS NULL)
        ORDER BY program_id NULLS LAST LIMIT 1;
      v_th_glu_pp := COALESCE(v_th_glu_pp, 7.8);
      IF NEW.value >= v_th_glu_pp THEN
        INSERT INTO public.monitoring_alerts(tenant_id, patient_id, program_id, measurement_id, kind, severity, uzenet)
        VALUES (NEW.tenant_id, NEW.patient_id, NEW.program_id, NEW.id,
                'gdm_vercukor','figyelem',
                format('Posztprandiális vércukor küszöb felett: %s mmol/L. Döntéstámogatás, nem dózis-tanács.', NEW.value::text));
      END IF;
    ELSE
      SELECT ertek INTO v_th_glu_fast FROM public.monitoring_thresholds
        WHERE tenant_id = NEW.tenant_id AND kulcs = 'glucose_fasting'
          AND (program_id = NEW.program_id OR program_id IS NULL)
        ORDER BY program_id NULLS LAST LIMIT 1;
      v_th_glu_fast := COALESCE(v_th_glu_fast, 5.3);
      IF NEW.value >= v_th_glu_fast THEN
        INSERT INTO public.monitoring_alerts(tenant_id, patient_id, program_id, measurement_id, kind, severity, uzenet)
        VALUES (NEW.tenant_id, NEW.patient_id, NEW.program_id, NEW.id,
                'gdm_vercukor','figyelem',
                format('Éhomi vércukor küszöb felett: %s mmol/L.', NEW.value::text));
      END IF;
    END IF;
  END IF;

  -- láz
  IF NEW.kind = 'testho' AND NEW.value IS NOT NULL THEN
    SELECT ertek INTO v_th_fever FROM public.monitoring_thresholds
      WHERE tenant_id = NEW.tenant_id AND kulcs = 'fever'
        AND (program_id = NEW.program_id OR program_id IS NULL)
      ORDER BY program_id NULLS LAST LIMIT 1;
    v_th_fever := COALESCE(v_th_fever, 38.0);
    IF NEW.value >= v_th_fever THEN
      INSERT INTO public.monitoring_alerts(tenant_id, patient_id, program_id, measurement_id, kind, severity, uzenet)
      VALUES (NEW.tenant_id, NEW.patient_id, NEW.program_id, NEW.id,
              'laz','figyelem',
              format('Láz: %s °C.', NEW.value::text));
    END IF;
  END IF;

  RETURN NEW;
END $$;

CREATE TRIGGER trg_measurements_auto_alert
AFTER INSERT ON public.measurements
FOR EACH ROW EXECUTE FUNCTION public.measurements_auto_alert();

-- 13) Magzatmozgás-zárás riasztás (ha 10 mozgás nem érte el a beállított ablakot)
CREATE OR REPLACE FUNCTION public.fetal_movements_auto_alert()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_window int;
BEGIN
  SELECT ertek::int INTO v_window FROM public.monitoring_thresholds
    WHERE tenant_id = NEW.tenant_id AND kulcs = 'fetal_window_perc'
      AND (program_id = NEW.program_id OR program_id IS NULL)
    ORDER BY program_id NULLS LAST LIMIT 1;
  v_window := COALESCE(v_window, 120);

  IF (NEW.mozgas_szam < 10 AND NEW.eltelt_perc IS NOT NULL AND NEW.eltelt_perc >= v_window)
     OR (NEW.tizedik_mozgas_ido IS NOT NULL AND NEW.eltelt_perc IS NOT NULL AND NEW.eltelt_perc > v_window) THEN
    INSERT INTO public.monitoring_alerts(tenant_id, patient_id, program_id, fetal_movement_id, kind, severity, uzenet)
    VALUES (NEW.tenant_id, NEW.patient_id, NEW.program_id, NEW.id,
            'magzatmozgas_csokkent','kritikus',
            'SÜRGŐS: a magzatmozgás-számláló nem érte el a 10 mozgást a beállított időablakban. Azonnal forduljon szülészeti ügyelethez.');
  END IF;
  RETURN NEW;
END $$;

CREATE TRIGGER trg_fetal_auto_alert
AFTER INSERT OR UPDATE ON public.fetal_movements
FOR EACH ROW EXECUTE FUNCTION public.fetal_movements_auto_alert();

-- 14) Székletvér riasztás
CREATE OR REPLACE FUNCTION public.stool_log_auto_alert()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.veres = true THEN
    INSERT INTO public.monitoring_alerts(tenant_id, patient_id, program_id, stool_log_id, kind, severity, uzenet)
    VALUES (NEW.tenant_id, NEW.patient_id, NEW.program_id, NEW.id,
            'szekletveres','surgos',
            'Vér a székletben — orvosi konzultáció javasolt.');
  END IF;
  RETURN NEW;
END $$;

CREATE TRIGGER trg_stool_auto_alert
AFTER INSERT ON public.stool_log
FOR EACH ROW EXECUTE FUNCTION public.stool_log_auto_alert();

-- 15) BMI auto-frissítés új testsúly mérésnél (a legutóbbi testmagasságból)
CREATE OR REPLACE FUNCTION public.measurements_recompute_bmi()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_h numeric;
  v_bmi numeric;
BEGIN
  IF NEW.kind = 'testsuly' AND NEW.value IS NOT NULL THEN
    SELECT value INTO v_h FROM public.measurements
      WHERE patient_id = NEW.patient_id AND kind = 'testmagassag' AND value IS NOT NULL
      ORDER BY ts DESC LIMIT 1;
    IF v_h IS NOT NULL AND v_h > 0 THEN
      v_bmi := ROUND( (NEW.value / ((v_h/100.0) * (v_h/100.0)))::numeric , 2);
      INSERT INTO public.measurements(tenant_id, patient_id, program_id, kind, ts, value, unit, source, context)
      VALUES (NEW.tenant_id, NEW.patient_id, NEW.program_id, 'bmi', NEW.ts, v_bmi, 'kg/m2', 'kezi',
              jsonb_build_object('derived_from', NEW.id::text));
    END IF;
  END IF;
  RETURN NEW;
END $$;

CREATE TRIGGER trg_measurements_bmi
AFTER INSERT ON public.measurements
FOR EACH ROW
WHEN (NEW.kind = 'testsuly')
EXECUTE FUNCTION public.measurements_recompute_bmi();
