
DO $$ BEGIN
  CREATE TYPE public.kiosk_print_status AS ENUM ('not_printed', 'printed', 'cancelled');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

ALTER TABLE public.questionnaire_assignments
  ADD COLUMN IF NOT EXISTS print_status public.kiosk_print_status NOT NULL DEFAULT 'not_printed',
  ADD COLUMN IF NOT EXISTS printed_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS printed_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS print_cancelled_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS print_cancelled_by UUID REFERENCES auth.users(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS questionnaire_assignments_print_status_idx
  ON public.questionnaire_assignments (print_status);
