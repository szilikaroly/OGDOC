
-- 1. Audit log tábla
CREATE TABLE public.admin_audit_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID,
  user_id UUID,
  action TEXT NOT NULL CHECK (action IN ('INSERT','UPDATE','DELETE')),
  table_name TEXT NOT NULL,
  record_id TEXT,
  before_data JSONB,
  after_data JSONB,
  summary TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_audit_tenant_created ON public.admin_audit_log(tenant_id, created_at DESC);
CREATE INDEX idx_audit_user_created ON public.admin_audit_log(user_id, created_at DESC);
CREATE INDEX idx_audit_table ON public.admin_audit_log(table_name, created_at DESC);

GRANT SELECT ON public.admin_audit_log TO authenticated;
GRANT ALL ON public.admin_audit_log TO service_role;

ALTER TABLE public.admin_audit_log ENABLE ROW LEVEL SECURITY;

-- 2. Permission függvény
CREATE OR REPLACE FUNCTION public.has_permission(_user_id UUID, _perm TEXT)
RETURNS BOOLEAN
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT CASE _perm
    WHEN 'manage_tenant'   THEN public.has_any_role(_user_id, ARRAY['tenant_admin'])
    WHEN 'manage_org'      THEN public.has_any_role(_user_id, ARRAY['tenant_admin','igazgato','intezetvezeto','telephelyvezeto'])
    WHEN 'manage_roles'    THEN public.has_any_role(_user_id, ARRAY['tenant_admin','igazgato','intezetvezeto'])
    WHEN 'manage_schedule' THEN public.has_any_role(_user_id, ARRAY['tenant_admin','igazgato','intezetvezeto','telephelyvezeto','ugyeletvezeto','beoszto'])
    WHEN 'manage_training' THEN public.has_any_role(_user_id, ARRAY['tenant_admin','igazgato','intezetvezeto','foorvos'])
    WHEN 'manage_patients' THEN public.has_any_role(_user_id, ARRAY['tenant_admin','igazgato','intezetvezeto','telephelyvezeto','foorvos','szakorvos','rezidens','szakgyakornok','vezetorezidens'])
    WHEN 'view_audit'      THEN public.has_any_role(_user_id, ARRAY['tenant_admin','igazgato','intezetvezeto'])
    WHEN 'view_team'       THEN public.has_any_role(_user_id, ARRAY['tenant_admin','igazgato','intezetvezeto','telephelyvezeto','foorvos','ugyeletvezeto','beoszto'])
    ELSE FALSE
  END
$$;

-- 3. RLS: audit log csak nézhető a saját bérlőn belül és csak jogosultaknak
CREATE POLICY "audit_select_authorized" ON public.admin_audit_log
  FOR SELECT TO authenticated
  USING (
    tenant_id = public.current_tenant_id()
    AND public.has_permission(auth.uid(), 'view_audit')
  );

-- 4. Generikus audit trigger függvény
CREATE OR REPLACE FUNCTION public.audit_trigger_fn()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_tenant_id UUID;
  v_record_id TEXT;
  v_before JSONB;
  v_after JSONB;
BEGIN
  -- tenant_id kinyerése
  IF TG_OP = 'DELETE' THEN
    v_before := to_jsonb(OLD);
    v_after := NULL;
    v_record_id := COALESCE((to_jsonb(OLD)->>'id'), '');
    v_tenant_id := NULLIF(to_jsonb(OLD)->>'tenant_id','')::uuid;
  ELSIF TG_OP = 'UPDATE' THEN
    v_before := to_jsonb(OLD);
    v_after := to_jsonb(NEW);
    v_record_id := COALESCE((to_jsonb(NEW)->>'id'), '');
    v_tenant_id := NULLIF(to_jsonb(NEW)->>'tenant_id','')::uuid;
  ELSE
    v_before := NULL;
    v_after := to_jsonb(NEW);
    v_record_id := COALESCE((to_jsonb(NEW)->>'id'), '');
    v_tenant_id := NULLIF(to_jsonb(NEW)->>'tenant_id','')::uuid;
  END IF;

  -- profiles esetén a profile saját id = user_id, tenant a sorból
  IF TG_TABLE_NAME = 'tenants' AND v_tenant_id IS NULL THEN
    v_tenant_id := v_record_id::uuid;
  END IF;

  INSERT INTO public.admin_audit_log(tenant_id, user_id, action, table_name, record_id, before_data, after_data)
  VALUES (
    COALESCE(v_tenant_id, public.current_tenant_id()),
    auth.uid(),
    TG_OP,
    TG_TABLE_NAME,
    v_record_id,
    v_before,
    v_after
  );

  IF TG_OP = 'DELETE' THEN RETURN OLD; ELSE RETURN NEW; END IF;
END;
$$;

-- 5. Triggerek felrakása
DO $$
DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY['tenants','profiles','clinics','sites','org_units','org_unit_specialties','user_roles','specialties','staff_levels']
  LOOP
    EXECUTE format('DROP TRIGGER IF EXISTS audit_%I ON public.%I', t, t);
    EXECUTE format('CREATE TRIGGER audit_%I AFTER INSERT OR UPDATE OR DELETE ON public.%I FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn()', t, t);
  END LOOP;
END $$;

GRANT EXECUTE ON FUNCTION public.has_permission(UUID, TEXT) TO authenticated;
