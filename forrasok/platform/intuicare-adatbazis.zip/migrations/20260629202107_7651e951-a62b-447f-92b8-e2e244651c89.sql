
-- =====================================================================
-- CMS 1. fázis: oldalak, blokkok, menük, média, átirányítások, i18n
-- =====================================================================

-- Helper: van-e CMS jog (admin VAGY cms_editor)
CREATE OR REPLACE FUNCTION public.has_cms_access(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT public.has_role(_user_id, 'tenant_admin') OR public.has_role(_user_id, 'cms_editor');
$$;

-- ---------- cms_pages ----------
CREATE TABLE public.cms_pages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL,
  locale text NOT NULL DEFAULT 'hu',
  parent_id uuid REFERENCES public.cms_pages(id) ON DELETE SET NULL,
  title text NOT NULL,
  description text,
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published','archived')),
  published_at timestamptz,
  sort_order int NOT NULL DEFAULT 0,
  seo_title text,
  seo_description text,
  og_image_url text,
  show_in_sitemap boolean NOT NULL DEFAULT true,
  template text NOT NULL DEFAULT 'default',
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  updated_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (slug, locale)
);
CREATE INDEX cms_pages_status_idx ON public.cms_pages(status);
CREATE INDEX cms_pages_locale_idx ON public.cms_pages(locale);

GRANT SELECT ON public.cms_pages TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.cms_pages TO authenticated;
GRANT ALL ON public.cms_pages TO service_role;
ALTER TABLE public.cms_pages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read published pages" ON public.cms_pages FOR SELECT USING (status='published' OR public.has_cms_access(auth.uid()));
CREATE POLICY "cms editors manage pages" ON public.cms_pages FOR ALL TO authenticated USING (public.has_cms_access(auth.uid())) WITH CHECK (public.has_cms_access(auth.uid()));

-- ---------- cms_page_versions ----------
CREATE TABLE public.cms_page_versions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  page_id uuid NOT NULL REFERENCES public.cms_pages(id) ON DELETE CASCADE,
  version int NOT NULL,
  snapshot jsonb NOT NULL,
  is_published boolean NOT NULL DEFAULT false,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (page_id, version)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_page_versions TO authenticated;
GRANT ALL ON public.cms_page_versions TO service_role;
ALTER TABLE public.cms_page_versions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "cms editors manage versions" ON public.cms_page_versions FOR ALL TO authenticated USING (public.has_cms_access(auth.uid())) WITH CHECK (public.has_cms_access(auth.uid()));

-- ---------- cms_blocks ----------
CREATE TABLE public.cms_blocks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  page_id uuid NOT NULL REFERENCES public.cms_pages(id) ON DELETE CASCADE,
  block_type text NOT NULL,
  position int NOT NULL DEFAULT 0,
  locale text NOT NULL DEFAULT 'hu',
  content jsonb NOT NULL DEFAULT '{}'::jsonb,
  variant text NOT NULL DEFAULT 'default',
  is_published boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX cms_blocks_page_idx ON public.cms_blocks(page_id, position);
GRANT SELECT ON public.cms_blocks TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.cms_blocks TO authenticated;
GRANT ALL ON public.cms_blocks TO service_role;
ALTER TABLE public.cms_blocks ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read blocks of published pages" ON public.cms_blocks FOR SELECT USING (
  is_published AND EXISTS (SELECT 1 FROM public.cms_pages p WHERE p.id = cms_blocks.page_id AND p.status='published')
  OR public.has_cms_access(auth.uid())
);
CREATE POLICY "cms editors manage blocks" ON public.cms_blocks FOR ALL TO authenticated USING (public.has_cms_access(auth.uid())) WITH CHECK (public.has_cms_access(auth.uid()));

-- ---------- cms_menus ----------
CREATE TABLE public.cms_menus (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text NOT NULL UNIQUE,
  name text NOT NULL,
  location text NOT NULL DEFAULT 'header',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.cms_menus TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.cms_menus TO authenticated;
GRANT ALL ON public.cms_menus TO service_role;
ALTER TABLE public.cms_menus ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read menus" ON public.cms_menus FOR SELECT USING (true);
CREATE POLICY "cms editors manage menus" ON public.cms_menus FOR ALL TO authenticated USING (public.has_cms_access(auth.uid())) WITH CHECK (public.has_cms_access(auth.uid()));

-- ---------- cms_menu_items ----------
CREATE TABLE public.cms_menu_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  menu_id uuid NOT NULL REFERENCES public.cms_menus(id) ON DELETE CASCADE,
  parent_id uuid REFERENCES public.cms_menu_items(id) ON DELETE CASCADE,
  position int NOT NULL DEFAULT 0,
  label text NOT NULL,
  url text,
  page_id uuid REFERENCES public.cms_pages(id) ON DELETE SET NULL,
  locale text NOT NULL DEFAULT 'hu',
  open_in_new_tab boolean NOT NULL DEFAULT false,
  icon text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX cms_menu_items_menu_idx ON public.cms_menu_items(menu_id, position);
GRANT SELECT ON public.cms_menu_items TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.cms_menu_items TO authenticated;
GRANT ALL ON public.cms_menu_items TO service_role;
ALTER TABLE public.cms_menu_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read menu items" ON public.cms_menu_items FOR SELECT USING (true);
CREATE POLICY "cms editors manage menu items" ON public.cms_menu_items FOR ALL TO authenticated USING (public.has_cms_access(auth.uid())) WITH CHECK (public.has_cms_access(auth.uid()));

-- ---------- cms_media ----------
CREATE TABLE public.cms_media (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  storage_path text NOT NULL,
  file_name text NOT NULL,
  mime_type text NOT NULL,
  size_bytes bigint NOT NULL DEFAULT 0,
  width int,
  height int,
  alt_text text,
  caption text,
  category text,
  tags text[] DEFAULT '{}',
  uploaded_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX cms_media_category_idx ON public.cms_media(category);
GRANT SELECT ON public.cms_media TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.cms_media TO authenticated;
GRANT ALL ON public.cms_media TO service_role;
ALTER TABLE public.cms_media ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read media" ON public.cms_media FOR SELECT USING (true);
CREATE POLICY "cms editors manage media" ON public.cms_media FOR ALL TO authenticated USING (public.has_cms_access(auth.uid())) WITH CHECK (public.has_cms_access(auth.uid()));

-- ---------- cms_redirects ----------
CREATE TABLE public.cms_redirects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  source_path text NOT NULL UNIQUE,
  target_path text NOT NULL,
  status_code int NOT NULL DEFAULT 301 CHECK (status_code IN (301,302,307,308)),
  note text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.cms_redirects TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.cms_redirects TO authenticated;
GRANT ALL ON public.cms_redirects TO service_role;
ALTER TABLE public.cms_redirects ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read redirects" ON public.cms_redirects FOR SELECT USING (is_active);
CREATE POLICY "cms editors manage redirects" ON public.cms_redirects FOR ALL TO authenticated USING (public.has_cms_access(auth.uid())) WITH CHECK (public.has_cms_access(auth.uid()));

-- ---------- cms_i18n_content ----------
CREATE TABLE public.cms_i18n_content (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  entity_type text NOT NULL,
  entity_id uuid NOT NULL,
  locale text NOT NULL,
  data jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (entity_type, entity_id, locale)
);
GRANT SELECT ON public.cms_i18n_content TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.cms_i18n_content TO authenticated;
GRANT ALL ON public.cms_i18n_content TO service_role;
ALTER TABLE public.cms_i18n_content ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read i18n" ON public.cms_i18n_content FOR SELECT USING (true);
CREATE POLICY "cms editors manage i18n" ON public.cms_i18n_content FOR ALL TO authenticated USING (public.has_cms_access(auth.uid())) WITH CHECK (public.has_cms_access(auth.uid()));

-- ---------- updated_at trigger ----------
CREATE OR REPLACE FUNCTION public.cms_touch_updated_at() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

CREATE TRIGGER cms_pages_touch BEFORE UPDATE ON public.cms_pages FOR EACH ROW EXECUTE FUNCTION public.cms_touch_updated_at();
CREATE TRIGGER cms_blocks_touch BEFORE UPDATE ON public.cms_blocks FOR EACH ROW EXECUTE FUNCTION public.cms_touch_updated_at();
CREATE TRIGGER cms_menus_touch BEFORE UPDATE ON public.cms_menus FOR EACH ROW EXECUTE FUNCTION public.cms_touch_updated_at();
CREATE TRIGGER cms_menu_items_touch BEFORE UPDATE ON public.cms_menu_items FOR EACH ROW EXECUTE FUNCTION public.cms_touch_updated_at();
CREATE TRIGGER cms_redirects_touch BEFORE UPDATE ON public.cms_redirects FOR EACH ROW EXECUTE FUNCTION public.cms_touch_updated_at();

-- ---------- Default menus ----------
INSERT INTO public.cms_menus (key, name, location) VALUES
  ('main', 'Főmenü', 'header'),
  ('footer', 'Lábléc menü', 'footer')
ON CONFLICT (key) DO NOTHING;
