-- ===== CMS workflow + audit log: 1. fázis (B migráció) =====
-- Workflow oszlopok minden érintett CMS táblán

-- Helper: backfill expression (status alapján)
-- A táblák egy részén van 'status' column ('draft'/'published'/'scheduled'/'archived');
-- másoknál csak boolean 'is_active'/'is_published' van. Külön kezeljük.

DO $$
DECLARE
  t text;
  has_status boolean;
  has_is_active boolean;
  has_is_published boolean;
  tables text[] := ARRAY[
    'cms_pages', 'cms_news_posts', 'cms_blocks', 'cms_layout_blocks',
    'cms_menus', 'cms_menu_items', 'cms_redirects', 'cms_staff_profiles',
    'cms_faqs', 'cms_design_tokens', 'cms_site_settings',
    'cms_global_regions', 'cms_media'
  ];
BEGIN
  FOREACH t IN ARRAY tables LOOP
    -- 1. oszlopok hozzáadása (idempotens)
    EXECUTE format('ALTER TABLE public.%I
      ADD COLUMN IF NOT EXISTS workflow_state public.cms_workflow_state NOT NULL DEFAULT ''draft'',
      ADD COLUMN IF NOT EXISTS submitted_for_review_at timestamptz,
      ADD COLUMN IF NOT EXISTS submitted_by uuid,
      ADD COLUMN IF NOT EXISTS approved_at timestamptz,
      ADD COLUMN IF NOT EXISTS approved_by uuid,
      ADD COLUMN IF NOT EXISTS rejected_at timestamptz,
      ADD COLUMN IF NOT EXISTS rejected_by uuid,
      ADD COLUMN IF NOT EXISTS rejection_reason text', t);

    -- 2. backfill state
    SELECT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name=t AND column_name='status') INTO has_status;
    SELECT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name=t AND column_name='is_active') INTO has_is_active;
    SELECT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name=t AND column_name='is_published') INTO has_is_published;

    IF has_status THEN
      EXECUTE format(
        'UPDATE public.%I SET workflow_state = CASE
            WHEN status::text = ''published'' THEN ''published''::public.cms_workflow_state
            WHEN status::text = ''archived''  THEN ''archived''::public.cms_workflow_state
            ELSE ''draft''::public.cms_workflow_state
          END WHERE workflow_state = ''draft''', t);
    ELSIF has_is_published THEN
      EXECUTE format(
        'UPDATE public.%I SET workflow_state = CASE WHEN is_published THEN ''published''::public.cms_workflow_state ELSE ''draft''::public.cms_workflow_state END WHERE workflow_state = ''draft''', t);
    ELSIF has_is_active THEN
      EXECUTE format(
        'UPDATE public.%I SET workflow_state = CASE WHEN is_active THEN ''published''::public.cms_workflow_state ELSE ''draft''::public.cms_workflow_state END WHERE workflow_state = ''draft''', t);
    ELSE
      -- nincs publikációs jel → kezeljük publikáltnak (visszafelé kompatibilitás)
      EXECUTE format('UPDATE public.%I SET workflow_state = ''published''::public.cms_workflow_state WHERE workflow_state = ''draft''', t);
    END IF;

    -- 3. index a state-en
    EXECUTE format('CREATE INDEX IF NOT EXISTS %I ON public.%I (workflow_state)',
      t || '_workflow_state_idx', t);
  END LOOP;
END $$;