
-- 1) profile_beavatkozasok bővítése
ALTER TABLE public.profile_beavatkozasok
  ADD COLUMN IF NOT EXISTS mentor_igazolt boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS mentor_user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS bizonyitek_url text;

-- 2) peer link enums
DO $$ BEGIN
  CREATE TYPE public.peer_link_tipus AS ENUM ('szivesen_dolgozik_vele','nem_dolgozik_vele','mentor','mentee');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.peer_link_status AS ENUM ('aktiv','jovahagyasra_var','jovahagyott','elutasitott');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- 3) profile_peer_links tábla
CREATE TABLE IF NOT EXISTS public.profile_peer_links (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  from_user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  to_user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  tipus public.peer_link_tipus NOT NULL,
  suly smallint,
  indoklas text,
  status public.peer_link_status NOT NULL DEFAULT 'aktiv',
  jovahagyo_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  jovahagyas_at timestamptz,
  jovahagyas_indok text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT peer_links_no_self CHECK (from_user_id <> to_user_id),
  CONSTRAINT peer_links_suly_range CHECK (suly IS NULL OR (suly BETWEEN 1 AND 5)),
  CONSTRAINT peer_links_unique UNIQUE (from_user_id, to_user_id, tipus)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_peer_links TO authenticated;
GRANT ALL ON public.profile_peer_links TO service_role;

ALTER TABLE public.profile_peer_links ENABLE ROW LEVEL SECURITY;

-- olvasás: saját kapcsolatok (mindkét irány) + beosztás/HR
CREATE POLICY profile_peer_links_select ON public.profile_peer_links
  FOR SELECT
  USING (
    from_user_id = auth.uid()
    OR to_user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_schedule')
    OR public.has_permission(auth.uid(), 'manage_tenant')
  );

-- írás: saját bejegyzéseit a forrás felhasználó kezeli; HR/beosztásvezető is szerkeszthet
CREATE POLICY profile_peer_links_insert ON public.profile_peer_links
  FOR INSERT
  WITH CHECK (
    from_user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_schedule')
    OR public.has_permission(auth.uid(), 'manage_tenant')
  );

CREATE POLICY profile_peer_links_update ON public.profile_peer_links
  FOR UPDATE
  USING (
    from_user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_schedule')
    OR public.has_permission(auth.uid(), 'manage_tenant')
  )
  WITH CHECK (
    from_user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_schedule')
    OR public.has_permission(auth.uid(), 'manage_tenant')
  );

CREATE POLICY profile_peer_links_delete ON public.profile_peer_links
  FOR DELETE
  USING (
    from_user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_tenant')
  );

-- audit + touch
CREATE TRIGGER audit_ppl AFTER INSERT OR UPDATE OR DELETE ON public.profile_peer_links
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();
CREATE TRIGGER touch_ppl BEFORE UPDATE ON public.profile_peer_links
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- 4) negatív kapcsolat HR-jóváhagyásához trigger
CREATE OR REPLACE FUNCTION public.profile_peer_links_guard()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_is_hr boolean := COALESCE(public.has_permission(v_uid, 'manage_tenant'), false);
BEGIN
  -- negatív kapcsolat alapból jóváhagyásra vár
  IF TG_OP = 'INSERT' THEN
    IF NEW.tipus = 'nem_dolgozik_vele' AND NOT v_is_hr THEN
      NEW.status := 'jovahagyasra_var';
    END IF;
  END IF;

  -- státusz-átmenet jóváhagyott/elutasított csak HR-rel
  IF TG_OP = 'UPDATE' AND NEW.status IS DISTINCT FROM OLD.status
     AND NEW.status IN ('jovahagyott','elutasitott') THEN
    IF NOT v_is_hr THEN
      INSERT INTO public.admin_audit_log(tenant_id, user_id, action, table_name, record_id, before_data, after_data)
      VALUES (COALESCE(NEW.tenant_id, public.current_tenant_id()), v_uid, 'FORBIDDEN_APPROVAL',
              TG_TABLE_NAME, NEW.id::text,
              jsonb_build_object('status', OLD.status),
              jsonb_build_object('status', NEW.status));
      RAISE EXCEPTION 'Negatív kapcsolat jóváhagyása csak HR (tenant-admin) jogosultsággal lehetséges.'
        USING ERRCODE = '42501';
    END IF;
    IF NEW.from_user_id = v_uid OR NEW.to_user_id = v_uid THEN
      RAISE EXCEPTION 'Saját kapcsolatát nem hagyhatja jóvá.' USING ERRCODE = '42501';
    END IF;
    IF NEW.status = 'elutasitott' AND COALESCE(btrim(NEW.jovahagyas_indok), '') = '' THEN
      RAISE EXCEPTION 'Elutasításhoz kötelező az indoklás.' USING ERRCODE = '22023';
    END IF;
    NEW.jovahagyo_id := v_uid;
    NEW.jovahagyas_at := now();
  END IF;

  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_ppl_guard
  BEFORE INSERT OR UPDATE ON public.profile_peer_links
  FOR EACH ROW EXECUTE FUNCTION public.profile_peer_links_guard();
