CREATE POLICY "patient reads own docs in bucket"
  ON storage.objects FOR SELECT TO authenticated
  USING (
    bucket_id = 'patient-documents'
    AND EXISTS (
      SELECT 1 FROM public.patient_documents d
      WHERE d.storage_path = storage.objects.name
        AND d.patient_id IN (SELECT current_user_patient_ids())
        AND d.shared_with_patient = true
    )
  );

CREATE POLICY "patient uploads own docs to bucket"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'patient-documents'
    AND (storage.foldername(name))[1] IN (
      SELECT id::text FROM public.patients WHERE id IN (SELECT current_user_patient_ids())
    )
  );

CREATE POLICY "patient deletes own docs in bucket"
  ON storage.objects FOR DELETE TO authenticated
  USING (
    bucket_id = 'patient-documents'
    AND EXISTS (
      SELECT 1 FROM public.patient_documents d
      WHERE d.storage_path = storage.objects.name
        AND d.uploaded_by = auth.uid()
        AND d.uploader_kind = 'patient'
    )
  );

CREATE POLICY "staff manages docs in bucket"
  ON storage.objects FOR ALL TO authenticated
  USING (bucket_id = 'patient-documents' AND has_permission(auth.uid(), 'view_patient_data'))
  WITH CHECK (bucket_id = 'patient-documents' AND has_permission(auth.uid(), 'view_patient_data'));