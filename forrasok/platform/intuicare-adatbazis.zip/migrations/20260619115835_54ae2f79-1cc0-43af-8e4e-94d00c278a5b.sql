
CREATE OR REPLACE FUNCTION public.notify_duty_availability_offer()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user_name text;
BEGIN
  IF NEW.tipus <> 'szabad_vagyok' THEN
    RETURN NEW;
  END IF;

  SELECT teljes_nev INTO v_user_name FROM public.profiles WHERE id = NEW.user_id;

  INSERT INTO public.notifications (tenant_id, user_id, tipus, cim, uzenet, link)
  SELECT
    NEW.tenant_id,
    ur.user_id,
    'duty_availability_offer',
    'Új önkéntes ügyelet felajánlás',
    COALESCE(v_user_name, 'Egy dolgozó') || ' vállal extra ügyeletet (' || array_length(NEW.napok, 1) || ' nap)',
    '/karakterlap?user=' || NEW.user_id::text
  FROM public.user_roles ur
  JOIN public.role_permissions rp ON rp.role_id = ur.role_id
  WHERE ur.tenant_id = NEW.tenant_id
    AND rp.permission = 'manage_schedule'
    AND ur.user_id <> NEW.user_id;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_notify_duty_offer ON public.duty_availability;
CREATE TRIGGER trg_notify_duty_offer
  AFTER INSERT ON public.duty_availability
  FOR EACH ROW EXECUTE FUNCTION public.notify_duty_availability_offer();
