
-- ============================================================
-- Munkaszüneti napok
-- ============================================================
CREATE TABLE IF NOT EXISTS public.public_holidays (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,  -- NULL = globális
  datum date NOT NULL,
  nev text NOT NULL,
  fizetett boolean NOT NULL DEFAULT true,
  forrasszoveg text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, datum)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.public_holidays TO authenticated;
GRANT ALL ON public.public_holidays TO service_role;
ALTER TABLE public.public_holidays ENABLE ROW LEVEL SECURITY;

CREATE POLICY ph_select ON public.public_holidays FOR SELECT TO authenticated
  USING (tenant_id IS NULL OR tenant_id = public.current_tenant_id());

CREATE POLICY ph_write_admin ON public.public_holidays FOR ALL TO authenticated
  USING (public.has_permission(auth.uid(),'manage_tenant'))
  WITH CHECK (public.has_permission(auth.uid(),'manage_tenant'));

CREATE TRIGGER ph_touch BEFORE UPDATE ON public.public_holidays
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- Magyar 2026–2027 munkaszüneti napok (globális seed)
INSERT INTO public.public_holidays (tenant_id, datum, nev, fizetett) VALUES
  (NULL,'2026-01-01','Újév',true),
  (NULL,'2026-03-15','Nemzeti ünnep',true),
  (NULL,'2026-04-03','Nagypéntek',true),
  (NULL,'2026-04-05','Húsvétvasárnap',true),
  (NULL,'2026-04-06','Húsvéthétfő',true),
  (NULL,'2026-05-01','Munka ünnepe',true),
  (NULL,'2026-05-24','Pünkösdvasárnap',true),
  (NULL,'2026-05-25','Pünkösdhétfő',true),
  (NULL,'2026-08-20','Államalapítás ünnepe',true),
  (NULL,'2026-10-23','Nemzeti ünnep',true),
  (NULL,'2026-11-01','Mindenszentek',true),
  (NULL,'2026-12-25','Karácsony',true),
  (NULL,'2026-12-26','Karácsony 2. napja',true),
  (NULL,'2027-01-01','Újév',true),
  (NULL,'2027-03-15','Nemzeti ünnep',true),
  (NULL,'2027-03-26','Nagypéntek',true),
  (NULL,'2027-03-28','Húsvétvasárnap',true),
  (NULL,'2027-03-29','Húsvéthétfő',true),
  (NULL,'2027-05-01','Munka ünnepe',true),
  (NULL,'2027-05-16','Pünkösdvasárnap',true),
  (NULL,'2027-05-17','Pünkösdhétfő',true),
  (NULL,'2027-08-20','Államalapítás ünnepe',true),
  (NULL,'2027-10-23','Nemzeti ünnep',true),
  (NULL,'2027-11-01','Mindenszentek',true),
  (NULL,'2027-12-25','Karácsony',true),
  (NULL,'2027-12-26','Karácsony 2. napja',true)
ON CONFLICT DO NOTHING;

-- ============================================================
-- Pótlék-sávok számítása
-- ============================================================
CREATE OR REPLACE FUNCTION public.compute_potlek_savs(_kezdo timestamptz, _zaro timestamptz)
RETURNS TABLE(ejszakai_ora numeric, vasarnapi_ora numeric, unnepnapi_ora numeric)
LANGUAGE plpgsql
STABLE
SET search_path = public
AS $$
DECLARE
  v_cur timestamptz := _kezdo;
  v_step timestamptz;
  v_ej numeric := 0;
  v_vas numeric := 0;
  v_un numeric := 0;
  v_h numeric;
  v_dow int;
  v_is_holiday boolean;
  v_hour int;
BEGIN
  -- 15 perces lépésekben bontunk, így percpontosság alatti ferde számítási hiba nélkül
  WHILE v_cur < _zaro LOOP
    v_step := LEAST(v_cur + interval '15 minutes', _zaro);
    v_h := EXTRACT(epoch FROM (v_step - v_cur)) / 3600.0;
    v_dow := EXTRACT(isodow FROM v_cur);
    v_hour := EXTRACT(hour FROM v_cur);

    SELECT EXISTS(
      SELECT 1 FROM public.public_holidays
      WHERE datum = v_cur::date
        AND (tenant_id IS NULL OR tenant_id = public.current_tenant_id())
    ) INTO v_is_holiday;

    IF v_hour >= 22 OR v_hour < 6 THEN
      v_ej := v_ej + v_h;
    END IF;
    IF v_dow = 7 THEN
      v_vas := v_vas + v_h;
    END IF;
    IF v_is_holiday THEN
      v_un := v_un + v_h;
    END IF;

    v_cur := v_step;
  END LOOP;
  RETURN QUERY SELECT v_ej, v_vas, v_un;
END;
$$;

-- Trigger: work_time_ledger automatikus sáv-kitöltés
CREATE OR REPLACE FUNCTION public.wtl_compute_savs_fn()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
DECLARE
  r RECORD;
BEGIN
  SELECT * INTO r FROM public.compute_potlek_savs(NEW.kezdo_idopont, NEW.zaro_idopont);
  NEW.ejszakai_ora := COALESCE(r.ejszakai_ora, 0);
  NEW.vasarnapi_ora := COALESCE(r.vasarnapi_ora, 0);
  NEW.unnepnapi_ora := COALESCE(r.unnepnapi_ora, 0);
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS wtl_compute_savs ON public.work_time_ledger;
CREATE TRIGGER wtl_compute_savs
  BEFORE INSERT OR UPDATE OF kezdo_idopont, zaro_idopont
  ON public.work_time_ledger
  FOR EACH ROW EXECUTE FUNCTION public.wtl_compute_savs_fn();

-- ============================================================
-- Bér-szimuláció (NEM számfejt!)
-- ============================================================
CREATE OR REPLACE FUNCTION public.wage_simulation(_user_id uuid, _honap_kezdete date)
RETURNS TABLE(
  wage_code_id uuid,
  kod text,
  nev text,
  ora numeric,
  szorzo numeric,
  egysegek numeric
)
LANGUAGE sql
STABLE SECURITY INVOKER
SET search_path = public
AS $$
  WITH ledger AS (
    SELECT wtl.user_id, wtl.tenant_id, wtl.kategoria,
           wtl.ora, wtl.ejszakai_ora, wtl.vasarnapi_ora, wtl.unnepnapi_ora
    FROM public.work_time_ledger wtl
    WHERE wtl.user_id = _user_id
      AND wtl.datum >= _honap_kezdete
      AND wtl.datum < (_honap_kezdete + interval '1 month')::date
  ),
  -- alap-óradíj a kategória nappali leképezésével
  alap AS (
    SELECT wm.kategoria,
           wc.id AS wage_code_id, wc.kod, wc.nev,
           COALESCE(wm.felulirat_szorzo, wc.alap_szorzo) AS szorzo,
           SUM(l.ora - l.ejszakai_ora - l.vasarnapi_ora - l.unnepnapi_ora) AS ora
    FROM ledger l
    JOIN public.wage_mapping wm
      ON wm.kategoria = l.kategoria AND wm.sav = 'nappal'
     AND (wm.tenant_id IS NULL OR wm.tenant_id = l.tenant_id)
     AND (wm.ervenyes_ig IS NULL OR wm.ervenyes_ig >= _honap_kezdete)
    JOIN public.wage_codes wc ON wc.id = wm.wage_code_id
    GROUP BY wm.kategoria, wc.id, wc.kod, wc.nev, wm.felulirat_szorzo, wc.alap_szorzo
  ),
  potlek AS (
    SELECT sav, SUM(ora) AS ora
    FROM (
      SELECT 'ejszaka'::text AS sav, SUM(ejszakai_ora) AS ora FROM ledger
      UNION ALL
      SELECT 'vasarnap', SUM(vasarnapi_ora) FROM ledger
      UNION ALL
      SELECT 'unnep', SUM(unnepnapi_ora) FROM ledger
    ) s
    GROUP BY sav
  ),
  potlek_mapped AS (
    SELECT wc.id AS wage_code_id, wc.kod, wc.nev,
           COALESCE(wm.felulirat_szorzo, wc.alap_szorzo) AS szorzo,
           p.ora
    FROM potlek p
    JOIN public.wage_mapping wm ON wm.sav = p.sav
    JOIN public.wage_codes wc ON wc.id = wm.wage_code_id
    WHERE p.ora > 0
  ),
  egyesitett AS (
    SELECT wage_code_id, kod, nev, ora, szorzo FROM alap WHERE ora > 0
    UNION ALL
    SELECT wage_code_id, kod, nev, ora, szorzo FROM potlek_mapped
  )
  SELECT wage_code_id, kod, nev,
         ROUND(SUM(ora)::numeric, 2) AS ora,
         MAX(szorzo) AS szorzo,
         ROUND(SUM(ora * szorzo)::numeric, 2) AS egysegek
  FROM egyesitett
  GROUP BY wage_code_id, kod, nev
  ORDER BY kod;
$$;

-- ============================================================
-- incompatibilities jóváhagyási őr
-- ============================================================
CREATE OR REPLACE FUNCTION public.incompatibilities_guard()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_is_hr boolean := COALESCE(public.has_permission(v_uid,'manage_tenant'), false);
BEGIN
  IF TG_OP = 'UPDATE' AND NEW.status IS DISTINCT FROM OLD.status
     AND NEW.status IN ('jovahagyott','elutasitott') THEN
    IF NOT v_is_hr THEN
      INSERT INTO public.admin_audit_log(tenant_id, user_id, action, table_name, record_id, before_data, after_data)
      VALUES (COALESCE(NEW.tenant_id, public.current_tenant_id()), v_uid, 'FORBIDDEN_APPROVAL',
              TG_TABLE_NAME, NEW.id::text,
              jsonb_build_object('status', OLD.status),
              jsonb_build_object('status', NEW.status));
      RAISE EXCEPTION 'Összeférhetetlenség jóváhagyása csak HR (tenant-admin) jogosultsággal lehetséges.'
        USING ERRCODE = '42501';
    END IF;
    IF NEW.user_id = v_uid THEN
      RAISE EXCEPTION 'A saját bejelentését nem hagyhatja jóvá.' USING ERRCODE = '42501';
    END IF;
    IF NEW.status = 'elutasitott' AND COALESCE(btrim(NEW.jovahagyas_indok), '') = '' THEN
      RAISE EXCEPTION 'Elutasításhoz kötelező az indoklás.' USING ERRCODE = '22023';
    END IF;
    NEW.jovahagyo_id := v_uid;
    NEW.jovahagyas_at := now();
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS incompatibilities_approval ON public.incompatibilities;
CREATE TRIGGER incompatibilities_approval
  BEFORE UPDATE ON public.incompatibilities
  FOR EACH ROW EXECUTE FUNCTION public.incompatibilities_guard();

-- ============================================================
-- További work_time_rules seedek
-- ============================================================
INSERT INTO public.work_time_rules
  (tenant_id, jogviszony_tipus, fenntarto_tipus, forrasszoveg)
VALUES
  (NULL,'kjt_kozalkalmazott','egyhazi','Kjt + Eütev. (egyházi fenntartó)'),
  (NULL,'kjt_kozalkalmazott','onkormanyzati','Kjt + Eütev.'),
  (NULL,'munka_tv_kv','egyetemi_klinika','Mt. + Eütev. (egyetemi klinika)'),
  (NULL,'munka_tv_kv','allami','Mt. + Eütev.'),
  (NULL,'megbizasi','allami','Ptk. megbízási, Eütev. nem alkalmazandó közvetlenül'),
  (NULL,'egyeni_vallalkozo','maganszektor','Egyéni vállalkozó, önszabályozott'),
  (NULL,'rezidens_kepzes','egyetemi_klinika','Eütev. + 162/2015 rezidens-rendelet'),
  (NULL,'rezidens_kepzes','allami','Eütev. + 162/2015 rezidens-rendelet')
ON CONFLICT DO NOTHING;
