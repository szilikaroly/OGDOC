
-- ============================================================
-- F kör: kompetencia-domének, szintek, személyi akkreditációk
-- ============================================================

CREATE TABLE IF NOT EXISTS public.competency_domains (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  specialty_id uuid REFERENCES public.specialties(id) ON DELETE SET NULL,
  kulcs text NOT NULL,
  nev text NOT NULL,
  leiras text,
  ervenyes boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, kulcs)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.competency_domains TO authenticated;
GRANT ALL ON public.competency_domains TO service_role;
ALTER TABLE public.competency_domains ENABLE ROW LEVEL SECURITY;

CREATE POLICY cd_select ON public.competency_domains FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY cd_write_admin ON public.competency_domains FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (public.has_permission(auth.uid(),'manage_tenant') OR public.has_permission(auth.uid(),'manage_training')))
  WITH CHECK (tenant_id = public.current_tenant_id() AND (public.has_permission(auth.uid(),'manage_tenant') OR public.has_permission(auth.uid(),'manage_training')));

CREATE TRIGGER cd_touch BEFORE UPDATE ON public.competency_domains
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- Szintek katalógus (tenant-szinten testreszabható)
CREATE TABLE IF NOT EXISTS public.competency_levels (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  kulcs text NOT NULL,
  nev text NOT NULL,
  sorrend smallint NOT NULL,
  felugyeleti_kuszob boolean NOT NULL DEFAULT false,
  leiras text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, kulcs)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.competency_levels TO authenticated;
GRANT ALL ON public.competency_levels TO service_role;
ALTER TABLE public.competency_levels ENABLE ROW LEVEL SECURITY;

CREATE POLICY cl_select ON public.competency_levels FOR SELECT TO authenticated
  USING (tenant_id IS NULL OR tenant_id = public.current_tenant_id());
CREATE POLICY cl_write_admin ON public.competency_levels FOR ALL TO authenticated
  USING (public.has_permission(auth.uid(),'manage_tenant') OR public.has_permission(auth.uid(),'manage_training'))
  WITH CHECK (public.has_permission(auth.uid(),'manage_tenant') OR public.has_permission(auth.uid(),'manage_training'));

CREATE TRIGGER cl_touch BEFORE UPDATE ON public.competency_levels
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- Alap szint-katalógus (NULL tenant = globális)
INSERT INTO public.competency_levels (tenant_id, kulcs, nev, sorrend, felugyeleti_kuszob, leiras) VALUES
  (NULL,'junior','Junior',10,false,'Önállóan korlátozottan végzi, felügyelet alatt áll.'),
  (NULL,'kozephalado','Középhaladó',20,false,'Rutinfeladatokat önállóan, összetetteket konzultációval.'),
  (NULL,'szenior','Szenior',30,false,'Önállóan teljes körben, képes csapatot támogatni.'),
  (NULL,'felugyelo','Felügyelő',40,true,'Felügyeletre jogosult: ügyeletvezető / tutor.'),
  (NULL,'oktato','Oktató',50,true,'Akkreditált oktató / programvezető.')
ON CONFLICT DO NOTHING;

-- Személyi akkreditációk
CREATE TABLE IF NOT EXISTS public.person_accreditations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  domain_id uuid NOT NULL REFERENCES public.competency_domains(id) ON DELETE CASCADE,
  level_id uuid NOT NULL REFERENCES public.competency_levels(id) ON DELETE RESTRICT,
  ervenyes_tol date NOT NULL DEFAULT CURRENT_DATE,
  ervenyes_ig date,
  igazolas_hivatkozas text,
  megjegyzes text,
  jovahagyo_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_pa_user_domain_level_active
  ON public.person_accreditations (tenant_id, user_id, domain_id, level_id)
  WHERE ervenyes_ig IS NULL;

CREATE INDEX IF NOT EXISTS idx_pa_user ON public.person_accreditations (user_id);
CREATE INDEX IF NOT EXISTS idx_pa_domain ON public.person_accreditations (domain_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.person_accreditations TO authenticated;
GRANT ALL ON public.person_accreditations TO service_role;
ALTER TABLE public.person_accreditations ENABLE ROW LEVEL SECURITY;

CREATE POLICY pa_select ON public.person_accreditations FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(),'view_team')
    OR public.has_permission(auth.uid(),'manage_schedule')
    OR public.has_permission(auth.uid(),'manage_tenant')
    OR public.has_permission(auth.uid(),'manage_training')
  ));

CREATE POLICY pa_write_admin ON public.person_accreditations FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    public.has_permission(auth.uid(),'manage_tenant')
    OR public.has_permission(auth.uid(),'manage_training')
  ))
  WITH CHECK (tenant_id = public.current_tenant_id() AND (
    public.has_permission(auth.uid(),'manage_tenant')
    OR public.has_permission(auth.uid(),'manage_training')
  ));

CREATE TRIGGER pa_touch BEFORE UPDATE ON public.person_accreditations
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TRIGGER audit_pa AFTER INSERT OR UPDATE OR DELETE ON public.person_accreditations
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- supervises(): true, ha az adott időpontban a felügyelő szintje >= felügyeleti küszöb,
-- és a felügyelő szintje > a felügyelté ugyanabban a doménben.
CREATE OR REPLACE FUNCTION public.supervises(
  _supervisor_id uuid,
  _supervisee_id uuid,
  _domain_id uuid,
  _at timestamptz DEFAULT now()
)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  WITH sup AS (
    SELECT cl.sorrend AS sor, cl.felugyeleti_kuszob
    FROM public.person_accreditations pa
    JOIN public.competency_levels cl ON cl.id = pa.level_id
    WHERE pa.user_id = _supervisor_id
      AND pa.domain_id = _domain_id
      AND pa.ervenyes_tol <= _at::date
      AND (pa.ervenyes_ig IS NULL OR pa.ervenyes_ig >= _at::date)
    ORDER BY cl.sorrend DESC LIMIT 1
  ),
  sub AS (
    SELECT cl.sorrend AS sor
    FROM public.person_accreditations pa
    JOIN public.competency_levels cl ON cl.id = pa.level_id
    WHERE pa.user_id = _supervisee_id
      AND pa.domain_id = _domain_id
      AND pa.ervenyes_tol <= _at::date
      AND (pa.ervenyes_ig IS NULL OR pa.ervenyes_ig >= _at::date)
    ORDER BY cl.sorrend DESC LIMIT 1
  )
  SELECT COALESCE(
    (SELECT sup.felugyeleti_kuszob AND sup.sor > COALESCE((SELECT sub.sor FROM sub), -1)
     FROM sup),
    false
  );
$$;
