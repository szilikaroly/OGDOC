-- 1) Profiles: restrict full-row read to self or supervisors (view_team permission)
DROP POLICY IF EXISTS "profiles_select_self_or_tenant" ON public.profiles;

CREATE POLICY "profiles_select_self_or_supervisor" ON public.profiles
  FOR SELECT TO authenticated
  USING (
    id = auth.uid()
    OR (
      tenant_id IS NOT NULL
      AND tenant_id = current_tenant_id()
      AND has_permission(auth.uid(), 'view_team')
    )
  );

-- 2) user_roles bootstrap: prevent grabbing tenant_admin on a tenant that already has one
DROP POLICY IF EXISTS "user_roles_bootstrap_admin" ON public.user_roles;

CREATE POLICY "user_roles_bootstrap_admin" ON public.user_roles
  FOR INSERT TO authenticated
  WITH CHECK (
    user_id = auth.uid()
    AND role_id IN (SELECT id FROM public.roles WHERE kulcs = 'tenant_admin')
    AND EXISTS (SELECT 1 FROM public.tenants t WHERE t.id = user_roles.tenant_id)
    AND NOT EXISTS (
      SELECT 1
      FROM public.user_roles ur
      JOIN public.roles r ON r.id = ur.role_id
      WHERE ur.tenant_id = user_roles.tenant_id
        AND r.kulcs = 'tenant_admin'
    )
  );