
-- 1) Saved views (kedvencek) ----------------------------------------------------
CREATE TABLE public.paciens_360_saved_views (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  patient_id UUID NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  filters JSONB NOT NULL DEFAULT '{}'::jsonb,
  is_default BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX p360_saved_views_user_idx ON public.paciens_360_saved_views(user_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.paciens_360_saved_views TO authenticated;
GRANT ALL ON public.paciens_360_saved_views TO service_role;

ALTER TABLE public.paciens_360_saved_views ENABLE ROW LEVEL SECURITY;

CREATE POLICY "p360_saved_views_owner_all"
  ON public.paciens_360_saved_views FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- 2) Alert workflow status oszlop ----------------------------------------------
ALTER TABLE public.clinical_critical_alerts
  ADD COLUMN IF NOT EXISTS workflow_status TEXT NOT NULL DEFAULT 'open';

-- 3) Alert status log -----------------------------------------------------------
CREATE TABLE public.clinical_alert_status_log (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  alert_id UUID NOT NULL REFERENCES public.clinical_critical_alerts(id) ON DELETE CASCADE,
  actor_id UUID NULL REFERENCES auth.users(id) ON DELETE SET NULL,
  from_status TEXT NULL,
  to_status TEXT NOT NULL,
  note TEXT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX clinical_alert_status_log_alert_idx ON public.clinical_alert_status_log(alert_id, created_at DESC);

GRANT SELECT ON public.clinical_alert_status_log TO authenticated;
GRANT ALL ON public.clinical_alert_status_log TO service_role;

ALTER TABLE public.clinical_alert_status_log ENABLE ROW LEVEL SECURITY;

-- Csak hitelesített felhasználók olvashatják (klinikai napló). Írás csak server fn-en.
CREATE POLICY "alert_status_log_read_authenticated"
  ON public.clinical_alert_status_log FOR SELECT
  TO authenticated
  USING (true);

-- 4) Escalation rules -----------------------------------------------------------
CREATE TABLE public.clinical_alert_escalation_rules (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  severity TEXT NULL,
  source TEXT NULL,
  escalate_after_minutes INTEGER NOT NULL DEFAULT 30,
  target_role TEXT NULL,
  active BOOLEAN NOT NULL DEFAULT true,
  created_by UUID NULL REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX cae_rules_tenant_idx ON public.clinical_alert_escalation_rules(tenant_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.clinical_alert_escalation_rules TO authenticated;
GRANT ALL ON public.clinical_alert_escalation_rules TO service_role;

ALTER TABLE public.clinical_alert_escalation_rules ENABLE ROW LEVEL SECURITY;

CREATE POLICY "cae_rules_read_same_tenant"
  ON public.clinical_alert_escalation_rules FOR SELECT
  TO authenticated
  USING (tenant_id = public.current_tenant_id());

CREATE POLICY "cae_rules_write_admin_or_orvos"
  ON public.clinical_alert_escalation_rules FOR ALL
  TO authenticated
  USING (
    tenant_id = public.current_tenant_id()
    AND (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'orvos'))
  )
  WITH CHECK (
    tenant_id = public.current_tenant_id()
    AND (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'orvos'))
  );

-- 5) updated_at triggers --------------------------------------------------------
CREATE OR REPLACE FUNCTION public.touch_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END $$;

CREATE TRIGGER p360_saved_views_touch
  BEFORE UPDATE ON public.paciens_360_saved_views
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TRIGGER cae_rules_touch
  BEFORE UPDATE ON public.clinical_alert_escalation_rules
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
