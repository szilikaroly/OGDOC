
-- 1) Revoke broad EXECUTE on every SECURITY DEFINER function in public
DO $$
DECLARE
  fn record;
BEGIN
  FOR fn IN
    SELECT n.nspname AS schema_name, p.proname AS fn_name,
           pg_get_function_identity_arguments(p.oid) AS args
    FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public' AND p.prosecdef = true
  LOOP
    EXECUTE format(
      'REVOKE EXECUTE ON FUNCTION %I.%I(%s) FROM PUBLIC, anon, authenticated',
      fn.schema_name, fn.fn_name, fn.args
    );
  END LOOP;
END $$;

-- 2) Grant EXECUTE back only where the app actually needs it.
--    anon: public tracking + kiosk (no login).
GRANT EXECUTE ON FUNCTION public.kiosk_load(text, text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.kiosk_autosave(text, text, jsonb) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.kiosk_submit_response(text, text, jsonb, numeric, text, jsonb, boolean) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.cms_exp_event_record(uuid, uuid, text, text, text, text, text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.cms_news_increment_view(text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.cms_page_view_record(uuid) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.get_home_page_id() TO anon, authenticated;

--    authenticated: RLS-helper + admin/RPC callable functions.
GRANT EXECUTE ON FUNCTION public.has_role(uuid, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_any_role(uuid, text[]) TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_permission(uuid, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_cms_access(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_cms_editor(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_cms_publisher(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_cms_reviewer(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.can_access_patient(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.can_book_into_block(uuid, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.current_tenant_id() TO authenticated;
GRANT EXECUTE ON FUNCTION public.current_user_patient_ids() TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_conversation_participant(uuid, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.eligible_swap_targets(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.calc_gyakorlati_ido(uuid, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.calc_illetmeny(uuid, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.calc_jubileumi_ido(uuid, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.find_acute_replacements(uuid, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.generate_demand_for_period(uuid, date, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.publish_schedule_run(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.recompute_block_case_times(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.reorder_block_cases(uuid, uuid[]) TO authenticated;
GRANT EXECUTE ON FUNCTION public.recalc_leave_entitlements(uuid, integer) TO authenticated;
GRANT EXECUTE ON FUNCTION public.log_leave_admin(uuid, uuid, text, integer, uuid, text, numeric, jsonb, jsonb, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.close_leave_year(uuid, integer, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.enforce_forced_leave_takeout(uuid, integer, uuid, boolean) TO authenticated;
GRANT EXECUTE ON FUNCTION public.seed_default_org_for_tenant(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.ensure_role_permissions_seed() TO authenticated;
GRANT EXECUTE ON FUNCTION public.cleanup_e2e_test_data() TO authenticated;
GRANT EXECUTE ON FUNCTION public.cms_audit_write(text, uuid, cms_audit_action, jsonb, jsonb, text, text, text, jsonb) TO authenticated;
GRANT EXECUTE ON FUNCTION public.cms_promote_scheduled_pages() TO authenticated;

--    Cron / trigger / admin-only functions get NO anon or authenticated grant.
--    They are invoked by triggers or by service_role from /api/public/hooks/*:
--      process_questionnaire_schedules, expire_overdue_questionnaire_assignments,
--      send_questionnaire_reminders, process_followup_schedules,
--      apply_approved_change_request, bump_conversation_last_message,
--      cms_pages_autoredirect_on_slug_change, fn_app_settings_audit,
--      enroll_followup

-- 3) Tighten always-true RLS policies on public INSERT tables

-- Newsletter subscribers: enforce format & prevent pre-confirmation abuse
DROP POLICY IF EXISTS "Anyone subscribes" ON public.cms_newsletter_subscribers;
CREATE POLICY "Anyone subscribes"
  ON public.cms_newsletter_subscribers
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (
    email IS NOT NULL
    AND length(email) BETWEEN 3 AND 254
    AND email ~ '^[^@\s]+@[^@\s]+\.[^@\s]+$'
    AND confirmed_at IS NULL
    AND unsubscribed_at IS NULL
    AND unsubscribe_token IS NOT NULL
    AND length(unsubscribe_token) BETWEEN 16 AND 128
    AND (source IS NULL OR length(source) <= 64)
  );

-- Tip views: only own views can be attributed; length limits on session_hash/locale
DROP POLICY IF EXISTS "Anyone can insert views" ON public.cms_tip_views;
CREATE POLICY "Anyone can insert views"
  ON public.cms_tip_views
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (
    tip_id IS NOT NULL
    AND (user_id IS NULL OR user_id = auth.uid())
    AND (session_hash IS NULL OR length(session_hash) BETWEEN 8 AND 128)
    AND (locale IS NULL OR length(locale) <= 10)
  );

-- Contact messages: length limits + status must start as new/pending, cannot pre-assign handler
DROP POLICY IF EXISTS "Anyone can submit a contact message" ON public.contact_messages;
CREATE POLICY "Anyone can submit a contact message"
  ON public.contact_messages
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (
    sender_name IS NOT NULL
    AND length(sender_name) BETWEEN 2 AND 120
    AND sender_email IS NOT NULL
    AND length(sender_email) BETWEEN 3 AND 254
    AND sender_email ~ '^[^@\s]+@[^@\s]+\.[^@\s]+$'
    AND (sender_phone IS NULL OR length(sender_phone) <= 40)
    AND (subject IS NULL OR length(subject) <= 200)
    AND body IS NOT NULL
    AND length(body) BETWEEN 5 AND 5000
    AND status IN ('new','pending')
    AND handled_by IS NULL
    AND handled_at IS NULL
    AND (locale IS NULL OR length(locale) <= 10)
  );

-- 4) Drop redundant service_role catch-all policies (service_role bypasses RLS).
DROP POLICY IF EXISTS "service_role_contractions" ON public.contractions;
DROP POLICY IF EXISTS "service_role_fetal_mov" ON public.fetal_movements;
DROP POLICY IF EXISTS "service_role_food_log" ON public.food_log;
DROP POLICY IF EXISTS "service_role_measurements" ON public.measurements;
DROP POLICY IF EXISTS "service_role_menstrual" ON public.menstrual_cycles;
DROP POLICY IF EXISTS "service_role_mon_alerts" ON public.monitoring_alerts;
DROP POLICY IF EXISTS "service_role_mon_programs" ON public.monitoring_programs;
DROP POLICY IF EXISTS "service_role_thresholds" ON public.monitoring_thresholds;
DROP POLICY IF EXISTS "service_role_qsched" ON public.questionnaire_schedules;
DROP POLICY IF EXISTS "service_role_stool_log" ON public.stool_log;
DROP POLICY IF EXISTS "service_role_wearable" ON public.wearable_data;
