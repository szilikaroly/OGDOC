ALTER TABLE public.cms_pages
  ADD COLUMN IF NOT EXISTS view_count integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS last_viewed_at timestamptz;

CREATE TABLE IF NOT EXISTS public.cms_page_views (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  page_id uuid NOT NULL REFERENCES public.cms_pages(id) ON DELETE CASCADE,
  day date NOT NULL DEFAULT CURRENT_DATE,
  views integer NOT NULL DEFAULT 0,
  UNIQUE (page_id, day)
);

GRANT SELECT ON public.cms_page_views TO authenticated;
GRANT ALL ON public.cms_page_views TO service_role;

ALTER TABLE public.cms_page_views ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "cms_page_views_admin_read" ON public.cms_page_views;
CREATE POLICY "cms_page_views_admin_read" ON public.cms_page_views
  FOR SELECT TO authenticated
  USING (public.has_cms_access(auth.uid()));

CREATE OR REPLACE FUNCTION public.cms_page_view_record(_page_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.cms_pages
     SET view_count = view_count + 1,
         last_viewed_at = now()
   WHERE id = _page_id AND status = 'published';

  IF FOUND THEN
    INSERT INTO public.cms_page_views (page_id, day, views)
    VALUES (_page_id, CURRENT_DATE, 1)
    ON CONFLICT (page_id, day) DO UPDATE
      SET views = public.cms_page_views.views + 1;
  END IF;
END;
$$;

GRANT EXECUTE ON FUNCTION public.cms_page_view_record(uuid) TO anon, authenticated;