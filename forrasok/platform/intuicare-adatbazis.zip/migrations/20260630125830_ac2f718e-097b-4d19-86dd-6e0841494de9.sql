
-- Block-level draft + approval ---------------------------------------------
ALTER TABLE public.cms_layout_blocks
  ADD COLUMN IF NOT EXISTS draft_content jsonb,
  ADD COLUMN IF NOT EXISTS draft_style jsonb,
  ADD COLUMN IF NOT EXISTS draft_updated_at timestamptz,
  ADD COLUMN IF NOT EXISTS draft_updated_by uuid,
  ADD COLUMN IF NOT EXISTS draft_status text NOT NULL DEFAULT 'none',
  ADD COLUMN IF NOT EXISTS draft_note text;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'cms_layout_blocks_draft_status_check'
  ) THEN
    ALTER TABLE public.cms_layout_blocks
      ADD CONSTRAINT cms_layout_blocks_draft_status_check
      CHECK (draft_status IN ('none','pending','approved','rejected'));
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS cms_layout_blocks_pending_drafts_idx
  ON public.cms_layout_blocks (page_id)
  WHERE draft_status = 'pending';
