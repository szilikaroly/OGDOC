-- 1) Storage: tighten patient-documents bucket access to caller's tenant
DROP POLICY IF EXISTS "staff manages docs in bucket" ON storage.objects;
CREATE POLICY "staff manages docs in bucket"
ON storage.objects FOR ALL TO authenticated
USING (
  bucket_id = 'patient-documents'
  AND public.has_permission(auth.uid(), 'view_patient_data')
  AND EXISTS (
    SELECT 1 FROM public.patient_documents d
    JOIN public.patients p ON p.id = d.patient_id
    WHERE d.storage_path = storage.objects.name
      AND p.tenant_id = public.current_tenant_id()
  )
)
WITH CHECK (
  bucket_id = 'patient-documents'
  AND public.has_permission(auth.uid(), 'view_patient_data')
  AND EXISTS (
    SELECT 1 FROM public.patient_documents d
    JOIN public.patients p ON p.id = d.patient_id
    WHERE d.storage_path = storage.objects.name
      AND p.tenant_id = public.current_tenant_id()
  )
);

-- 2) profile_peer_links: enforce tenant on every branch
DROP POLICY IF EXISTS profile_peer_links_select ON public.profile_peer_links;
DROP POLICY IF EXISTS profile_peer_links_insert ON public.profile_peer_links;
DROP POLICY IF EXISTS profile_peer_links_update ON public.profile_peer_links;
DROP POLICY IF EXISTS profile_peer_links_delete ON public.profile_peer_links;

CREATE POLICY profile_peer_links_select ON public.profile_peer_links
FOR SELECT TO authenticated
USING (
  (tenant_id IS NULL OR tenant_id = public.current_tenant_id())
  AND (
    from_user_id = auth.uid()
    OR to_user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_schedule')
    OR public.has_permission(auth.uid(), 'manage_tenant')
  )
);

CREATE POLICY profile_peer_links_insert ON public.profile_peer_links
FOR INSERT TO authenticated
WITH CHECK (
  (tenant_id IS NULL OR tenant_id = public.current_tenant_id())
  AND (
    from_user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_schedule')
    OR public.has_permission(auth.uid(), 'manage_tenant')
  )
);

CREATE POLICY profile_peer_links_update ON public.profile_peer_links
FOR UPDATE TO authenticated
USING (
  (tenant_id IS NULL OR tenant_id = public.current_tenant_id())
  AND (
    from_user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_schedule')
    OR public.has_permission(auth.uid(), 'manage_tenant')
  )
)
WITH CHECK (
  (tenant_id IS NULL OR tenant_id = public.current_tenant_id())
  AND (
    from_user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_schedule')
    OR public.has_permission(auth.uid(), 'manage_tenant')
  )
);

CREATE POLICY profile_peer_links_delete ON public.profile_peer_links
FOR DELETE TO authenticated
USING (
  (tenant_id IS NULL OR tenant_id = public.current_tenant_id())
  AND (
    from_user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_tenant')
  )
);

-- 3) profile_unavailability: enforce tenant on select/write
DROP POLICY IF EXISTS profile_unavailability_select ON public.profile_unavailability;
DROP POLICY IF EXISTS profile_unavailability_write ON public.profile_unavailability;

CREATE POLICY profile_unavailability_select ON public.profile_unavailability
FOR SELECT TO authenticated
USING (
  (tenant_id IS NULL OR tenant_id = public.current_tenant_id())
  AND (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_schedule')
    OR public.has_permission(auth.uid(), 'manage_tenant')
  )
);

CREATE POLICY profile_unavailability_write ON public.profile_unavailability
FOR ALL TO authenticated
USING (
  (tenant_id IS NULL OR tenant_id = public.current_tenant_id())
  AND (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_schedule')
    OR public.has_permission(auth.uid(), 'manage_tenant')
  )
)
WITH CHECK (
  (tenant_id IS NULL OR tenant_id = public.current_tenant_id())
  AND (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_schedule')
    OR public.has_permission(auth.uid(), 'manage_tenant')
  )
);