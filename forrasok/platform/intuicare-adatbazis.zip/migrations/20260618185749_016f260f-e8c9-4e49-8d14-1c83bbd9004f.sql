-- =========================================================
-- KARAKTERLAP BŐVÍTÉS — KÖR A
-- profiles bővítés + profile_contacts + profile_preferences
-- =========================================================

-- 1. profiles bővítés ---------------------------------------------------
DO $$ BEGIN
  CREATE TYPE public.nem_tipus AS ENUM ('ferfi','no','egyeb','nem_nyilatkozik');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS becenev TEXT,
  ADD COLUMN IF NOT EXISTS szuletesi_datum DATE,
  ADD COLUMN IF NOT EXISTS nem public.nem_tipus,
  ADD COLUMN IF NOT EXISTS bemutatkozas TEXT,
  ADD COLUMN IF NOT EXISTS bemutatkozas_publikus BOOLEAN NOT NULL DEFAULT false;

ALTER TABLE public.profiles
  DROP CONSTRAINT IF EXISTS profiles_bemutatkozas_len_chk;
ALTER TABLE public.profiles
  ADD CONSTRAINT profiles_bemutatkozas_len_chk
  CHECK (bemutatkozas IS NULL OR char_length(bemutatkozas) <= 2000);

-- 2. profile_contacts ---------------------------------------------------
DO $$ BEGIN
  CREATE TYPE public.contact_tipus AS ENUM (
    'telefon','mobil','email','signal','whatsapp','telegram',
    'veszhelyzeti_hozzatartozo','egyeb'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS public.profile_contacts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  tenant_id UUID REFERENCES public.tenants(id) ON DELETE SET NULL,
  tipus public.contact_tipus NOT NULL,
  cimke TEXT,
  ertek TEXT NOT NULL,
  is_primary BOOLEAN NOT NULL DEFAULT false,
  sorrend INT NOT NULL DEFAULT 0,
  csak_vesz_eseten BOOLEAN NOT NULL DEFAULT false,
  ertesites_engedelyezve BOOLEAN NOT NULL DEFAULT true,
  megjegyzes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT profile_contacts_ertek_len_chk CHECK (char_length(ertek) BETWEEN 1 AND 255)
);
CREATE INDEX IF NOT EXISTS idx_profile_contacts_user ON public.profile_contacts(user_id);
CREATE INDEX IF NOT EXISTS idx_profile_contacts_tenant ON public.profile_contacts(tenant_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_contacts TO authenticated;
GRANT ALL ON public.profile_contacts TO service_role;

ALTER TABLE public.profile_contacts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS profile_contacts_select ON public.profile_contacts;
CREATE POLICY profile_contacts_select ON public.profile_contacts
  FOR SELECT TO authenticated
  USING (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_tenant')
  );

DROP POLICY IF EXISTS profile_contacts_write ON public.profile_contacts;
CREATE POLICY profile_contacts_write ON public.profile_contacts
  FOR ALL TO authenticated
  USING (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_tenant')
  )
  WITH CHECK (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_tenant')
  );

DROP TRIGGER IF EXISTS trg_profile_contacts_touch ON public.profile_contacts;
CREATE TRIGGER trg_profile_contacts_touch
  BEFORE UPDATE ON public.profile_contacts
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

DROP TRIGGER IF EXISTS trg_profile_contacts_audit ON public.profile_contacts;
CREATE TRIGGER trg_profile_contacts_audit
  AFTER INSERT OR UPDATE OR DELETE ON public.profile_contacts
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- 3. profile_preferences (1:1) -----------------------------------------
DO $$ BEGIN
  CREATE TYPE public.musak_pref AS ENUM ('nappal','delutan','ejszaka','huszonnegy');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS public.profile_preferences (
  user_id UUID PRIMARY KEY REFERENCES public.profiles(id) ON DELETE CASCADE,
  tenant_id UUID REFERENCES public.tenants(id) ON DELETE SET NULL,
  heti_max_ora INT,
  havi_max_ugyelet INT,
  preferalt_musakok public.musak_pref[] NOT NULL DEFAULT '{}',
  tiltott_napok INT[] NOT NULL DEFAULT '{}',          -- 0=vasárnap … 6=szombat (ISO-független, doc-on belüli)
  ugyelet_utan_pihenonap BOOLEAN NOT NULL DEFAULT true,
  ugyelet_utan_min_ora INT NOT NULL DEFAULT 24,
  egymas_utani_max_ugyelet INT NOT NULL DEFAULT 1,
  last_minute_elerheto BOOLEAN NOT NULL DEFAULT false,
  last_minute_orahatar INT,                            -- pl. 4 = max 4 órán belüli értesítésre is bevállalja
  utazasi_perc_max INT,
  nyelvek TEXT[] NOT NULL DEFAULT '{}',
  megjegyzes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT pref_heti_ora_chk CHECK (heti_max_ora IS NULL OR heti_max_ora BETWEEN 0 AND 168),
  CONSTRAINT pref_pihenoora_chk CHECK (ugyelet_utan_min_ora BETWEEN 0 AND 96),
  CONSTRAINT pref_egymas_chk CHECK (egymas_utani_max_ugyelet BETWEEN 0 AND 10)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_preferences TO authenticated;
GRANT ALL ON public.profile_preferences TO service_role;

ALTER TABLE public.profile_preferences ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS profile_preferences_select ON public.profile_preferences;
CREATE POLICY profile_preferences_select ON public.profile_preferences
  FOR SELECT TO authenticated
  USING (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_schedule')
    OR public.has_permission(auth.uid(), 'manage_tenant')
  );

DROP POLICY IF EXISTS profile_preferences_write ON public.profile_preferences;
CREATE POLICY profile_preferences_write ON public.profile_preferences
  FOR ALL TO authenticated
  USING (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_tenant')
  )
  WITH CHECK (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_tenant')
  );

DROP TRIGGER IF EXISTS trg_profile_preferences_touch ON public.profile_preferences;
CREATE TRIGGER trg_profile_preferences_touch
  BEFORE UPDATE ON public.profile_preferences
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

DROP TRIGGER IF EXISTS trg_profile_preferences_audit ON public.profile_preferences;
CREATE TRIGGER trg_profile_preferences_audit
  AFTER INSERT OR UPDATE OR DELETE ON public.profile_preferences
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();
