
-- clinical_insulin_sessions
DROP POLICY IF EXISTS "Authenticated insert insulin sessions" ON public.clinical_insulin_sessions;
CREATE POLICY "Authenticated insert insulin sessions" ON public.clinical_insulin_sessions
  FOR INSERT TO authenticated
  WITH CHECK (created_by = auth.uid() AND public.can_access_patient(patient_id));

DROP POLICY IF EXISTS "Author update insulin sessions" ON public.clinical_insulin_sessions;
CREATE POLICY "Author update insulin sessions" ON public.clinical_insulin_sessions
  FOR UPDATE TO authenticated
  USING (created_by = auth.uid() AND public.can_access_patient(patient_id))
  WITH CHECK (public.can_access_patient(patient_id));

DROP POLICY IF EXISTS "Author delete insulin sessions" ON public.clinical_insulin_sessions;
CREATE POLICY "Author delete insulin sessions" ON public.clinical_insulin_sessions
  FOR DELETE TO authenticated
  USING (created_by = auth.uid() AND public.can_access_patient(patient_id));

-- clinical_notes
DROP POLICY IF EXISTS "auth users insert notes" ON public.clinical_notes;
CREATE POLICY "auth users insert notes" ON public.clinical_notes
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = author_id AND public.can_access_patient(patient_id));

DROP POLICY IF EXISTS "author updates unsigned notes" ON public.clinical_notes;
CREATE POLICY "author updates unsigned notes" ON public.clinical_notes
  FOR UPDATE TO authenticated
  USING (
    (((auth.uid() = author_id) AND (signed_at IS NULL)) OR public.has_role(auth.uid(), 'admin'))
    AND public.can_access_patient(patient_id)
  )
  WITH CHECK (public.can_access_patient(patient_id));

DROP POLICY IF EXISTS "author deletes unsigned notes" ON public.clinical_notes;
CREATE POLICY "author deletes unsigned notes" ON public.clinical_notes
  FOR DELETE TO authenticated
  USING (
    (((auth.uid() = author_id) AND (signed_at IS NULL)) OR public.has_role(auth.uid(), 'admin'))
    AND public.can_access_patient(patient_id)
  );

-- clinical_observations
DROP POLICY IF EXISTS "auth users insert observations" ON public.clinical_observations;
CREATE POLICY "auth users insert observations" ON public.clinical_observations
  FOR INSERT TO authenticated
  WITH CHECK (
    ((auth.uid() = performer_id) OR (performer_id IS NULL))
    AND public.can_access_patient(patient_id)
  );

DROP POLICY IF EXISTS "performer updates observations" ON public.clinical_observations;
CREATE POLICY "performer updates observations" ON public.clinical_observations
  FOR UPDATE TO authenticated
  USING (
    ((auth.uid() = performer_id) OR public.has_role(auth.uid(), 'admin'))
    AND public.can_access_patient(patient_id)
  )
  WITH CHECK (public.can_access_patient(patient_id));

DROP POLICY IF EXISTS "performer deletes observations" ON public.clinical_observations;
CREATE POLICY "performer deletes observations" ON public.clinical_observations
  FOR DELETE TO authenticated
  USING (
    ((auth.uid() = performer_id) OR public.has_role(auth.uid(), 'admin'))
    AND public.can_access_patient(patient_id)
  );
