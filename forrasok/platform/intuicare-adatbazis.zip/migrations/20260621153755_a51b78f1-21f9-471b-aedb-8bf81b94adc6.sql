CREATE OR REPLACE FUNCTION public.notify_or_emergency()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_suite_id uuid;
  v_type_nev text;
  v_user record;
BEGIN
  IF NEW.prioritas <> 'azonnali' THEN RETURN NEW; END IF;
  IF TG_OP = 'UPDATE' AND OLD.prioritas = 'azonnali' THEN RETURN NEW; END IF;

  SELECT st.nev INTO v_type_nev FROM public.surgery_types st WHERE st.id = NEW.surgery_type_id;

  SELECT rp.or_suite_id INTO v_suite_id
  FROM public.or_blocks b
  LEFT JOIN public.or_room_profiles rp ON rp.org_unit_id = b.org_unit_id
  WHERE b.id = NEW.or_block_id;

  FOR v_user IN
    SELECT DISTINCT p.id AS user_id
    FROM public.profiles p
    JOIN public.or_staff_pool sp ON sp.user_id = p.id
    WHERE p.tenant_id = NEW.tenant_id
      AND (sp.ervenyes_ig IS NULL OR sp.ervenyes_ig >= current_date)
      AND sp.ervenyes_tol <= current_date
      AND (v_suite_id IS NULL OR sp.or_suite_id = v_suite_id)
      AND EXISTS (
        SELECT 1 FROM public.attendance_events ae
        WHERE ae.user_id = p.id
          AND ae.idopont >= (now() - interval '12 hours')
      )
  LOOP
    INSERT INTO public.notifications (tenant_id, user_id, tipus, cim, uzenet, link)
    VALUES (
      NEW.tenant_id,
      v_user.user_id,
      'or_emergency',
      'Sürgősségi műtét',
      COALESCE(v_type_nev, 'Sürgősségi eset') || ' – azonnali bevonás szükséges',
      '/muteti-terv/blokkok'
    );
  END LOOP;

  RETURN NEW;
END;
$$;