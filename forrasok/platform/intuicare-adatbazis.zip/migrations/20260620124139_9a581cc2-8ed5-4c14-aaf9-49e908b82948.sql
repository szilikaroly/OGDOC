-- 1) Új permission kulcsok seedelése (idempotens)
INSERT INTO public.role_permissions (role_kulcs, perm)
SELECT r.kulcs, p.perm
FROM public.roles r
CROSS JOIN (VALUES
  ('view_or_board'),
  ('manage_or_blocks'),
  ('book_or_case'),
  ('sign_off_or_case'),
  ('trigger_or_emergency')
) AS p(perm)
WHERE
  (r.kulcs IN ('tenant_admin','igazgato','orvosigazgato','super_admin'))
  OR (r.kulcs IN ('mutos_koordinator','muteti_koordinator') AND p.perm IN ('view_or_board','manage_or_blocks','book_or_case','trigger_or_emergency'))
  OR (r.kulcs IN ('sebeszvezeto','sebesz_osztalyvezeto','osztalyvezeto') AND p.perm IN ('view_or_board','book_or_case','sign_off_or_case'))
  OR (r.kulcs IN ('sebesz','orvos','rezidens_sebesz') AND p.perm IN ('view_or_board','book_or_case'))
  OR (r.kulcs IN ('aneszteziologus','mutos_asszisztens','mutos_szakdolgozo','operacios_nover') AND p.perm = 'view_or_board')
ON CONFLICT DO NOTHING;

-- 2) or_staff_pool
CREATE TABLE IF NOT EXISTS public.or_staff_pool (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  user_id uuid NOT NULL,
  or_suite_id uuid NOT NULL REFERENCES public.or_suites(id) ON DELETE CASCADE,
  department_org_unit_id uuid NULL,
  eligible_szerep text NOT NULL CHECK (eligible_szerep IN ('operator','asszisztens','aneszteziologus','mutos_szakdolgozo','neonatologus','egyeb')),
  heti_keret_perc integer NOT NULL DEFAULT 0 CHECK (heti_keret_perc >= 0),
  havi_max_perc integer NULL CHECK (havi_max_perc IS NULL OR havi_max_perc >= 0),
  ervenyes_tol date NOT NULL DEFAULT current_date,
  ervenyes_ig date NULL,
  megjegyzes text NULL,
  created_by uuid NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.or_staff_pool TO authenticated;
GRANT ALL ON public.or_staff_pool TO service_role;
ALTER TABLE public.or_staff_pool ENABLE ROW LEVEL SECURITY;

CREATE POLICY "or_staff_pool_select" ON public.or_staff_pool
  FOR SELECT TO authenticated
  USING (
    tenant_id = public.current_tenant_id()
    AND (
      user_id = auth.uid()
      OR public.has_permission(auth.uid(), 'view_or_board')
      OR public.has_permission(auth.uid(), 'manage_or_blocks')
      OR public.has_permission(auth.uid(), 'view_team')
    )
  );

CREATE POLICY "or_staff_pool_write" ON public.or_staff_pool
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_or_blocks'))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_or_blocks'));

CREATE INDEX IF NOT EXISTS idx_or_staff_pool_user ON public.or_staff_pool(user_id, ervenyes_tol);
CREATE INDEX IF NOT EXISTS idx_or_staff_pool_suite ON public.or_staff_pool(or_suite_id);

CREATE TRIGGER trg_or_staff_pool_touch
  BEFORE UPDATE ON public.or_staff_pool
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- 3) or_emergency_responses
CREATE TABLE IF NOT EXISTS public.or_emergency_responses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  surgery_case_id uuid NOT NULL REFERENCES public.surgery_cases(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  notification_id uuid NULL REFERENCES public.notifications(id) ON DELETE SET NULL,
  tud_jonni boolean NOT NULL,
  eta_perc integer NULL CHECK (eta_perc IS NULL OR eta_perc >= 0),
  megjegyzes text NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (surgery_case_id, user_id)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.or_emergency_responses TO authenticated;
GRANT ALL ON public.or_emergency_responses TO service_role;
ALTER TABLE public.or_emergency_responses ENABLE ROW LEVEL SECURITY;

CREATE POLICY "oer_select" ON public.or_emergency_responses
  FOR SELECT TO authenticated
  USING (
    tenant_id = public.current_tenant_id()
    AND (
      user_id = auth.uid()
      OR public.has_permission(auth.uid(), 'manage_or_blocks')
      OR public.has_permission(auth.uid(), 'trigger_or_emergency')
    )
  );

CREATE POLICY "oer_insert_self" ON public.or_emergency_responses
  FOR INSERT TO authenticated
  WITH CHECK (tenant_id = public.current_tenant_id() AND user_id = auth.uid());

CREATE POLICY "oer_update_self" ON public.or_emergency_responses
  FOR UPDATE TO authenticated
  USING (tenant_id = public.current_tenant_id() AND user_id = auth.uid())
  WITH CHECK (tenant_id = public.current_tenant_id() AND user_id = auth.uid());

-- 4) can_book_into_block
CREATE OR REPLACE FUNCTION public.can_book_into_block(_user_id uuid, _block_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.or_blocks b
    WHERE b.id = _block_id
      AND b.tenant_id = public.current_tenant_id()
      AND public.has_permission(_user_id, 'book_or_case')
      AND (
        public.has_permission(_user_id, 'manage_or_blocks')
        OR b.sebesz_user_id = _user_id
        OR b.sebesz_user_id IS NULL
        OR EXISTS (
          SELECT 1 FROM public.org_unit_specialties ous
          JOIN public.profile_employment pe ON pe.org_unit_id = ous.org_unit_id
          WHERE ous.specialty_id = b.specialty_id
            AND pe.user_id = _user_id
            AND COALESCE(pe.ervenyes, true) = true
        )
      )
  )
$$;

-- 5) notify_or_emergency trigger
CREATE OR REPLACE FUNCTION public.notify_or_emergency()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_suite_id uuid;
  v_type_nev text;
  v_user record;
BEGIN
  IF NEW.prioritas <> 'azonnali' THEN RETURN NEW; END IF;
  IF TG_OP = 'UPDATE' AND OLD.prioritas = 'azonnali' THEN RETURN NEW; END IF;

  SELECT st.megnevezes INTO v_type_nev FROM public.surgery_types st WHERE st.id = NEW.surgery_type_id;

  SELECT rp.or_suite_id INTO v_suite_id
  FROM public.or_blocks b
  LEFT JOIN public.or_room_profiles rp ON rp.org_unit_id = b.org_unit_id
  WHERE b.id = NEW.or_block_id;

  FOR v_user IN
    SELECT DISTINCT p.id AS user_id
    FROM public.profiles p
    JOIN public.or_staff_pool sp ON sp.user_id = p.id
    WHERE p.tenant_id = NEW.tenant_id
      AND (sp.ervenyes_ig IS NULL OR sp.ervenyes_ig >= current_date)
      AND sp.ervenyes_tol <= current_date
      AND (v_suite_id IS NULL OR sp.or_suite_id = v_suite_id)
      AND EXISTS (
        SELECT 1 FROM public.attendance_events ae
        WHERE ae.user_id = p.id
          AND ae.idopont >= (now() - interval '12 hours')
      )
  LOOP
    INSERT INTO public.notifications (tenant_id, user_id, tipus, cim, uzenet, link)
    VALUES (
      NEW.tenant_id,
      v_user.user_id,
      'or_emergency',
      'SÜRGŐS MŰTÉT – segítség kérése',
      COALESCE('Beavatkozás: ' || v_type_nev, 'Azonnali műtéti segítség szükséges.')
        || ' Tervezett kezdés: '
        || to_char(COALESCE(NEW.tervezett_kezdo_ido, now()) AT TIME ZONE 'Europe/Budapest', 'HH24:MI'),
      '/muteti-terv/blokkok?case=' || NEW.id::text
    );
  END LOOP;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_notify_or_emergency_ins ON public.surgery_cases;
DROP TRIGGER IF EXISTS trg_notify_or_emergency_upd ON public.surgery_cases;
CREATE TRIGGER trg_notify_or_emergency_ins
  AFTER INSERT ON public.surgery_cases
  FOR EACH ROW EXECUTE FUNCTION public.notify_or_emergency();
CREATE TRIGGER trg_notify_or_emergency_upd
  AFTER UPDATE OF prioritas ON public.surgery_cases
  FOR EACH ROW EXECUTE FUNCTION public.notify_or_emergency();

-- 6) Realtime publikáció (idempotens)
DO $$
BEGIN
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.or_blocks; EXCEPTION WHEN duplicate_object THEN NULL; END;
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.surgery_cases; EXCEPTION WHEN duplicate_object THEN NULL; END;
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.resource_bookings; EXCEPTION WHEN duplicate_object THEN NULL; END;
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.or_emergency_responses; EXCEPTION WHEN duplicate_object THEN NULL; END;
END $$;
