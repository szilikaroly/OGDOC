
-- patient_documents
DROP POLICY IF EXISTS "staff manages documents" ON public.patient_documents;
CREATE POLICY "staff manages documents accessible patients"
ON public.patient_documents
FOR ALL
TO authenticated
USING (
  has_permission(auth.uid(), 'view_patient_data')
  AND can_access_patient(patient_id)
)
WITH CHECK (
  has_permission(auth.uid(), 'view_patient_data')
  AND can_access_patient(patient_id)
);

-- patient_emergency_card
DROP POLICY IF EXISTS "Staff olvashatja SOS kártyát" ON public.patient_emergency_card;
CREATE POLICY "Staff olvashatja SOS kártyát"
ON public.patient_emergency_card
FOR SELECT
TO authenticated
USING (
  has_permission(auth.uid(), 'view_patient_data')
  AND can_access_patient(patient_id)
);

-- patient_health_plans
DROP POLICY IF EXISTS "staff manages plans" ON public.patient_health_plans;
CREATE POLICY "staff manages plans accessible patients"
ON public.patient_health_plans
FOR ALL
TO authenticated
USING (
  has_permission(auth.uid(), 'view_patient_data')
  AND can_access_patient(patient_id)
)
WITH CHECK (
  has_permission(auth.uid(), 'view_patient_data')
  AND can_access_patient(patient_id)
);

-- storage.objects - staff access to patient-documents bucket
DROP POLICY IF EXISTS "staff reads patient documents" ON storage.objects;
CREATE POLICY "staff reads patient documents"
ON storage.objects
FOR SELECT
TO authenticated
USING (
  bucket_id = 'patient-documents'
  AND has_permission(auth.uid(), 'view_patient_data')
  AND EXISTS (
    SELECT 1 FROM public.patient_documents d
    WHERE d.storage_path = objects.name
      AND can_access_patient(d.patient_id)
  )
);

DROP POLICY IF EXISTS "staff manages patient documents" ON storage.objects;
CREATE POLICY "staff manages patient documents"
ON storage.objects
FOR ALL
TO authenticated
USING (
  bucket_id = 'patient-documents'
  AND has_permission(auth.uid(), 'view_patient_data')
  AND EXISTS (
    SELECT 1 FROM public.patient_documents d
    WHERE d.storage_path = objects.name
      AND can_access_patient(d.patient_id)
  )
)
WITH CHECK (
  bucket_id = 'patient-documents'
  AND has_permission(auth.uid(), 'view_patient_data')
  AND EXISTS (
    SELECT 1 FROM public.patient_documents d
    WHERE d.storage_path = objects.name
      AND can_access_patient(d.patient_id)
  )
);
