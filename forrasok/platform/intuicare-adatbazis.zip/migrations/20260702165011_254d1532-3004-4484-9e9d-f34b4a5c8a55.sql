
-- 1) user_provider_identities table
CREATE TABLE public.user_provider_identities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  provider TEXT NOT NULL,
  provider_user_id TEXT NOT NULL,
  email TEXT,
  avatar_url TEXT,
  raw JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (provider, provider_user_id)
);
CREATE INDEX idx_user_provider_identities_user ON public.user_provider_identities(user_id);

GRANT SELECT, DELETE ON public.user_provider_identities TO authenticated;
GRANT ALL ON public.user_provider_identities TO service_role;

ALTER TABLE public.user_provider_identities ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Own identities: select"
  ON public.user_provider_identities FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Own identities: delete"
  ON public.user_provider_identities FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE TRIGGER touch_user_provider_identities
  BEFORE UPDATE ON public.user_provider_identities
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- 2) sync function fired from auth.identities
CREATE OR REPLACE FUNCTION public.sync_provider_identity()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_email TEXT;
  v_avatar TEXT;
  v_name TEXT;
BEGIN
  v_email  := COALESCE(NEW.identity_data->>'email', NULL);
  v_avatar := COALESCE(
    NEW.identity_data->>'avatar_url',
    NEW.identity_data->>'picture'
  );
  v_name := COALESCE(
    NEW.identity_data->>'full_name',
    NEW.identity_data->>'name',
    NEW.identity_data->>'teljes_nev'
  );

  INSERT INTO public.user_provider_identities (
    user_id, provider, provider_user_id, email, avatar_url, raw
  )
  VALUES (
    NEW.user_id, NEW.provider, NEW.provider_id, v_email, v_avatar, NEW.identity_data
  )
  ON CONFLICT (provider, provider_user_id) DO UPDATE
  SET user_id    = EXCLUDED.user_id,
      email      = EXCLUDED.email,
      avatar_url = EXCLUDED.avatar_url,
      raw        = EXCLUDED.raw,
      updated_at = now();

  -- Backfill profile avatar/name if empty (first social login).
  UPDATE public.profiles
     SET avatar_url = COALESCE(profiles.avatar_url, v_avatar),
         teljes_nev = CASE
                        WHEN profiles.teljes_nev IS NULL
                          OR profiles.teljes_nev = ''
                          OR profiles.teljes_nev = split_part(profiles.email, '@', 1)
                        THEN COALESCE(v_name, profiles.teljes_nev)
                        ELSE profiles.teljes_nev
                      END,
         updated_at = now()
   WHERE id = NEW.user_id;

  RETURN NEW;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.sync_provider_identity() FROM PUBLIC, anon, authenticated;

DROP TRIGGER IF EXISTS on_auth_identity_upsert ON auth.identities;
CREATE TRIGGER on_auth_identity_upsert
  AFTER INSERT OR UPDATE ON auth.identities
  FOR EACH ROW EXECUTE FUNCTION public.sync_provider_identity();

-- 3) enrich handle_new_user with avatar/name from OAuth metadata
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, teljes_nev, avatar_url, foglalkozas_tipus)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(
      NEW.raw_user_meta_data->>'teljes_nev',
      NEW.raw_user_meta_data->>'full_name',
      NEW.raw_user_meta_data->>'name',
      split_part(NEW.email, '@', 1)
    ),
    COALESCE(
      NEW.raw_user_meta_data->>'avatar_url',
      NEW.raw_user_meta_data->>'picture'
    ),
    'egyeb'
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
