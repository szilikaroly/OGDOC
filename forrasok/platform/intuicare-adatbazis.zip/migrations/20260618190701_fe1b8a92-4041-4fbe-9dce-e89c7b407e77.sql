
-- Enums
CREATE TYPE public.unavailability_tipus AS ENUM (
  'szabadsag','betegszabadsag','tovabbkepzes','konferencia','kotelezetts_ugy','egyeb_tavollet'
);
CREATE TYPE public.unavailability_status AS ENUM (
  'tervezett','jovahagyasra_var','jovahagyott','elutasitott'
);
CREATE TYPE public.constraint_tipus AS ENUM (
  'terhes','szoptat','kisgyermek_otthon','egyedulnevelo','tartos_betegseg','mozgaskorlatozas','vedendokoru','egyeb'
);

-- ===== profile_unavailability =====
CREATE TABLE public.profile_unavailability (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  tenant_id UUID REFERENCES public.tenants(id) ON DELETE SET NULL,
  tipus public.unavailability_tipus NOT NULL,
  kezdo_datum DATE NOT NULL,
  zaro_datum DATE NOT NULL,
  csak_delelott BOOLEAN NOT NULL DEFAULT false,
  csak_delutan BOOLEAN NOT NULL DEFAULT false,
  leiras TEXT,
  training_program_id UUID REFERENCES public.training_programs(id) ON DELETE SET NULL,
  status public.unavailability_status NOT NULL DEFAULT 'tervezett',
  jovahagyo_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  jovahagyas_at TIMESTAMPTZ,
  jovahagyas_indok TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT profile_unavailability_datum_chk CHECK (zaro_datum >= kezdo_datum)
);
CREATE INDEX idx_profile_unavailability_user ON public.profile_unavailability(user_id);
CREATE INDEX idx_profile_unavailability_tenant ON public.profile_unavailability(tenant_id);
CREATE INDEX idx_profile_unavailability_datum ON public.profile_unavailability(kezdo_datum, zaro_datum);
CREATE INDEX idx_profile_unavailability_status ON public.profile_unavailability(status);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_unavailability TO authenticated;
GRANT ALL ON public.profile_unavailability TO service_role;

ALTER TABLE public.profile_unavailability ENABLE ROW LEVEL SECURITY;

CREATE POLICY "profile_unavailability_select" ON public.profile_unavailability
  FOR SELECT TO authenticated
  USING (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_schedule')
    OR public.has_permission(auth.uid(), 'manage_tenant')
  );

CREATE POLICY "profile_unavailability_write" ON public.profile_unavailability
  FOR ALL TO authenticated
  USING (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_schedule')
    OR public.has_permission(auth.uid(), 'manage_tenant')
  )
  WITH CHECK (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_schedule')
    OR public.has_permission(auth.uid(), 'manage_tenant')
  );

CREATE TRIGGER trg_profile_unavailability_touch
  BEFORE UPDATE ON public.profile_unavailability
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TRIGGER trg_profile_unavailability_audit
  AFTER INSERT OR UPDATE OR DELETE ON public.profile_unavailability
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ===== profile_constraints =====
CREATE TABLE public.profile_constraints (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  tenant_id UUID REFERENCES public.tenants(id) ON DELETE SET NULL,
  tipus public.constraint_tipus NOT NULL,
  ervenyes_tol DATE NOT NULL DEFAULT CURRENT_DATE,
  ervenyes_ig DATE,
  igazolas_url TEXT,
  hr_megjegyzes TEXT,
  megjegyzes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT profile_constraints_datum_chk CHECK (ervenyes_ig IS NULL OR ervenyes_ig >= ervenyes_tol)
);
CREATE INDEX idx_profile_constraints_user ON public.profile_constraints(user_id);
CREATE INDEX idx_profile_constraints_tenant ON public.profile_constraints(tenant_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_constraints TO authenticated;
GRANT ALL ON public.profile_constraints TO service_role;

ALTER TABLE public.profile_constraints ENABLE ROW LEVEL SECURITY;

CREATE POLICY "profile_constraints_select" ON public.profile_constraints
  FOR SELECT TO authenticated
  USING (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_tenant')
  );

CREATE POLICY "profile_constraints_write" ON public.profile_constraints
  FOR ALL TO authenticated
  USING (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_tenant')
  )
  WITH CHECK (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_tenant')
  );

CREATE TRIGGER trg_profile_constraints_touch
  BEFORE UPDATE ON public.profile_constraints
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TRIGGER trg_profile_constraints_audit
  AFTER INSERT OR UPDATE OR DELETE ON public.profile_constraints
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();
