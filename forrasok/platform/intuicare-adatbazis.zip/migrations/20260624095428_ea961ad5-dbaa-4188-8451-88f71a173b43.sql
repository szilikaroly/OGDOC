
-- =========================================================================
-- 1. questionnaire_assignments: tighten staff access
-- =========================================================================
DROP POLICY IF EXISTS qa_select_auth ON public.questionnaire_assignments;
DROP POLICY IF EXISTS qa_write_auth ON public.questionnaire_assignments;

CREATE POLICY qa_select_staff ON public.questionnaire_assignments
  FOR SELECT TO authenticated
  USING (
    tenant_id = current_tenant_id()
    AND (
      assigned_by = auth.uid()
      OR has_permission(auth.uid(), 'manage_patients')
      OR has_permission(auth.uid(), 'view_patient_data')
      OR has_permission(auth.uid(), 'manage_tenant')
    )
  );

CREATE POLICY qa_write_staff ON public.questionnaire_assignments
  FOR ALL TO authenticated
  USING (
    tenant_id = current_tenant_id()
    AND (
      has_permission(auth.uid(), 'manage_patients')
      OR has_permission(auth.uid(), 'manage_tenant')
    )
  )
  WITH CHECK (
    tenant_id = current_tenant_id()
    AND (
      has_permission(auth.uid(), 'manage_patients')
      OR has_permission(auth.uid(), 'manage_tenant')
    )
  );

-- =========================================================================
-- 2. has_permission cross-tenant: enforce tenant_id on write policies
-- =========================================================================
DROP POLICY IF EXISTS cl_write_admin ON public.competency_levels;
CREATE POLICY cl_write_admin ON public.competency_levels
  FOR ALL TO authenticated
  USING (
    (tenant_id IS NULL OR tenant_id = current_tenant_id())
    AND (has_permission(auth.uid(), 'manage_tenant') OR has_permission(auth.uid(), 'manage_training'))
  )
  WITH CHECK (
    (tenant_id IS NULL OR tenant_id = current_tenant_id())
    AND (has_permission(auth.uid(), 'manage_tenant') OR has_permission(auth.uid(), 'manage_training'))
  );

DROP POLICY IF EXISTS ph_write_admin ON public.public_holidays;
CREATE POLICY ph_write_admin ON public.public_holidays
  FOR ALL TO authenticated
  USING ((tenant_id IS NULL OR tenant_id = current_tenant_id())
         AND has_permission(auth.uid(), 'manage_tenant'))
  WITH CHECK ((tenant_id IS NULL OR tenant_id = current_tenant_id())
              AND has_permission(auth.uid(), 'manage_tenant'));

DROP POLICY IF EXISTS wc_write_admin ON public.wage_codes;
CREATE POLICY wc_write_admin ON public.wage_codes
  FOR ALL TO authenticated
  USING ((tenant_id IS NULL OR tenant_id = current_tenant_id())
         AND has_permission(auth.uid(), 'manage_tenant'))
  WITH CHECK ((tenant_id IS NULL OR tenant_id = current_tenant_id())
              AND has_permission(auth.uid(), 'manage_tenant'));

DROP POLICY IF EXISTS wm_write_admin ON public.wage_mapping;
CREATE POLICY wm_write_admin ON public.wage_mapping
  FOR ALL TO authenticated
  USING ((tenant_id IS NULL OR tenant_id = current_tenant_id())
         AND has_permission(auth.uid(), 'manage_tenant'))
  WITH CHECK ((tenant_id IS NULL OR tenant_id = current_tenant_id())
              AND has_permission(auth.uid(), 'manage_tenant'));

DROP POLICY IF EXISTS wtr_write_admin ON public.work_time_rules;
CREATE POLICY wtr_write_admin ON public.work_time_rules
  FOR ALL TO authenticated
  USING ((tenant_id IS NULL OR tenant_id = current_tenant_id())
         AND has_permission(auth.uid(), 'manage_tenant'))
  WITH CHECK ((tenant_id IS NULL OR tenant_id = current_tenant_id())
              AND has_permission(auth.uid(), 'manage_tenant'));

-- =========================================================================
-- 3. obstetric_partograms: explicit tenant column + scoped policies
-- =========================================================================
ALTER TABLE public.obstetric_partograms
  ADD COLUMN IF NOT EXISTS tenant_id UUID REFERENCES public.tenants(id);

UPDATE public.obstetric_partograms p
SET tenant_id = pat.tenant_id
FROM public.patients pat
WHERE p.patient_id = pat.id AND p.tenant_id IS NULL;

CREATE OR REPLACE FUNCTION public.partogram_set_tenant()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.tenant_id IS NULL THEN
    SELECT tenant_id INTO NEW.tenant_id FROM public.patients WHERE id = NEW.patient_id;
  END IF;
  RETURN NEW;
END $$;
REVOKE EXECUTE ON FUNCTION public.partogram_set_tenant() FROM PUBLIC, anon, authenticated;

DROP TRIGGER IF EXISTS trg_partogram_set_tenant ON public.obstetric_partograms;
CREATE TRIGGER trg_partogram_set_tenant
  BEFORE INSERT ON public.obstetric_partograms
  FOR EACH ROW EXECUTE FUNCTION public.partogram_set_tenant();

DROP POLICY IF EXISTS partogram_select ON public.obstetric_partograms;
DROP POLICY IF EXISTS partogram_insert ON public.obstetric_partograms;
DROP POLICY IF EXISTS partogram_update ON public.obstetric_partograms;
DROP POLICY IF EXISTS partogram_delete ON public.obstetric_partograms;

CREATE POLICY partogram_select ON public.obstetric_partograms
  FOR SELECT TO authenticated
  USING (tenant_id = current_tenant_id() AND can_access_patient(patient_id));

CREATE POLICY partogram_insert ON public.obstetric_partograms
  FOR INSERT TO authenticated
  WITH CHECK (
    created_by = auth.uid()
    AND can_access_patient(patient_id)
    AND (tenant_id IS NULL OR tenant_id = current_tenant_id())
  );

CREATE POLICY partogram_update ON public.obstetric_partograms
  FOR UPDATE TO authenticated
  USING (tenant_id = current_tenant_id() AND can_access_patient(patient_id))
  WITH CHECK (tenant_id = current_tenant_id() AND can_access_patient(patient_id));

CREATE POLICY partogram_delete ON public.obstetric_partograms
  FOR DELETE TO authenticated
  USING (
    tenant_id = current_tenant_id()
    AND can_access_patient(patient_id)
    AND (created_by = auth.uid() OR has_permission(auth.uid(), 'manage_patients'))
  );

DROP POLICY IF EXISTS partogram_entry_select ON public.obstetric_partogram_entries;
DROP POLICY IF EXISTS partogram_entry_insert ON public.obstetric_partogram_entries;
DROP POLICY IF EXISTS partogram_entry_update ON public.obstetric_partogram_entries;
DROP POLICY IF EXISTS partogram_entry_delete ON public.obstetric_partogram_entries;

CREATE POLICY partogram_entry_select ON public.obstetric_partogram_entries
  FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.obstetric_partograms p
    WHERE p.id = obstetric_partogram_entries.partogram_id
      AND p.tenant_id = current_tenant_id()
      AND can_access_patient(p.patient_id)
  ));

CREATE POLICY partogram_entry_insert ON public.obstetric_partogram_entries
  FOR INSERT TO authenticated
  WITH CHECK (created_by = auth.uid() AND EXISTS (
    SELECT 1 FROM public.obstetric_partograms p
    WHERE p.id = obstetric_partogram_entries.partogram_id
      AND p.tenant_id = current_tenant_id()
      AND can_access_patient(p.patient_id)
  ));

CREATE POLICY partogram_entry_update ON public.obstetric_partogram_entries
  FOR UPDATE TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.obstetric_partograms p
    WHERE p.id = obstetric_partogram_entries.partogram_id
      AND p.tenant_id = current_tenant_id()
      AND can_access_patient(p.patient_id)
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM public.obstetric_partograms p
    WHERE p.id = obstetric_partogram_entries.partogram_id
      AND p.tenant_id = current_tenant_id()
      AND can_access_patient(p.patient_id)
  ));

CREATE POLICY partogram_entry_delete ON public.obstetric_partogram_entries
  FOR DELETE TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.obstetric_partograms p
    WHERE p.id = obstetric_partogram_entries.partogram_id
      AND p.tenant_id = current_tenant_id()
      AND can_access_patient(p.patient_id)
      AND (obstetric_partogram_entries.created_by = auth.uid()
           OR has_permission(auth.uid(), 'manage_patients'))
  ));

-- =========================================================================
-- 4. always-true cleanup
-- =========================================================================
DROP POLICY IF EXISTS "Service role delete clinical alerts" ON public.clinical_critical_alerts;

DROP POLICY IF EXISTS i18n_missing_keys_insert ON public.i18n_missing_keys;
CREATE POLICY i18n_missing_keys_insert ON public.i18n_missing_keys
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() IS NOT NULL);

-- =========================================================================
-- 5. Move extensions out of public schema
-- =========================================================================
CREATE SCHEMA IF NOT EXISTS extensions;
GRANT USAGE ON SCHEMA extensions TO postgres, anon, authenticated, service_role;

ALTER EXTENSION pg_trgm SET SCHEMA extensions;

-- pg_net does not support SET SCHEMA, so drop and recreate it in the extensions schema.
DROP EXTENSION IF EXISTS pg_net;
CREATE EXTENSION IF NOT EXISTS pg_net WITH SCHEMA extensions;

-- =========================================================================
-- 6. Revoke EXECUTE on SECURITY DEFINER helpers from PUBLIC / anon
-- =========================================================================
DO $$
DECLARE
  fn RECORD;
BEGIN
  FOR fn IN
    SELECT p.oid::regprocedure AS sig
    FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public' AND p.prosecdef = true
  LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION %s FROM PUBLIC, anon', fn.sig);
  END LOOP;
END $$;
