ALTER VIEW public.cms_experiment_daily_stats SET (security_invoker = on);

CREATE OR REPLACE FUNCTION public.cms_experiments_set_updated()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;