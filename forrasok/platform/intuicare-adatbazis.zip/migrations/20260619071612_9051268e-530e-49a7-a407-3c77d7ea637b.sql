
CREATE TABLE public.notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  tipus text NOT NULL DEFAULT 'info',
  cim text NOT NULL,
  uzenet text,
  link text,
  olvasott_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.notifications TO authenticated;
GRANT ALL ON public.notifications TO service_role;

CREATE INDEX notifications_user_unread_idx
  ON public.notifications (user_id, created_at DESC)
  WHERE olvasott_at IS NULL;

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Saját értesítések olvasása"
  ON public.notifications FOR SELECT
  TO authenticated
  USING (user_id = auth.uid() OR public.has_permission(auth.uid(), 'manage_tenant'));

CREATE POLICY "Saját értesítések frissítése (olvasott)"
  ON public.notifications FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Saját értesítések törlése"
  ON public.notifications FOR DELETE
  TO authenticated
  USING (user_id = auth.uid());

-- Insert: csak service_role / privileged backend hoz létre értesítést.
CREATE POLICY "Tenant-admin értesítést készíthet"
  ON public.notifications FOR INSERT
  TO authenticated
  WITH CHECK (public.has_permission(auth.uid(), 'manage_tenant'));
