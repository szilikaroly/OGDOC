
-- ============ Diabétesz modul + klinikai riasztások ============

-- 1) Inzulin session-ök
CREATE TABLE public.clinical_insulin_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  encounter_id UUID REFERENCES public.clinical_encounters(id) ON DELETE SET NULL,
  patient_id UUID NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  session_date DATE NOT NULL DEFAULT CURRENT_DATE,
  mode TEXT NOT NULL CHECK (mode IN ('bb','premix2','premix3')),
  diabetes_type TEXT NOT NULL CHECK (diabetes_type IN ('t1','t2','t2r','gest')),
  weight_kg NUMERIC(5,1) NOT NULL,
  bolus_type TEXT CHECK (bolus_type IN ('analog','regular')),
  meal_ratio TEXT,
  bolus_prep_id TEXT,
  basal_prep_id TEXT,
  premix_prep_id TEXT,
  tdd NUMERIC(6,2),
  basal NUMERIC(6,2),
  bolus_r NUMERIC(6,2),
  bolus_d NUMERIC(6,2),
  bolus_e NUMERIC(6,2),
  icr NUMERIC(6,2),
  isf NUMERIC(6,2),
  target_vc NUMERIC(4,2) DEFAULT 6.0,
  current_vc NUMERIC(5,2),
  correction_bolus NUMERIC(6,2),
  modifiers_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  notes TEXT,
  created_by UUID NOT NULL REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.clinical_insulin_sessions TO authenticated;
GRANT ALL ON public.clinical_insulin_sessions TO service_role;
ALTER TABLE public.clinical_insulin_sessions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated read insulin sessions" ON public.clinical_insulin_sessions
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated insert insulin sessions" ON public.clinical_insulin_sessions
  FOR INSERT TO authenticated WITH CHECK (created_by = auth.uid());
CREATE POLICY "Author update insulin sessions" ON public.clinical_insulin_sessions
  FOR UPDATE TO authenticated USING (created_by = auth.uid()) WITH CHECK (created_by = auth.uid());
CREATE POLICY "Author delete insulin sessions" ON public.clinical_insulin_sessions
  FOR DELETE TO authenticated USING (created_by = auth.uid());

CREATE INDEX idx_insulin_sessions_patient ON public.clinical_insulin_sessions(patient_id, session_date DESC);
CREATE INDEX idx_insulin_sessions_encounter ON public.clinical_insulin_sessions(encounter_id);

-- 2) Heti vércukor mérések
CREATE TABLE public.clinical_weekly_vc (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  encounter_id UUID REFERENCES public.clinical_encounters(id) ON DELETE SET NULL,
  measured_at TIMESTAMPTZ NOT NULL,
  value_mmol_l NUMERIC(5,2) NOT NULL,
  measurement_type TEXT NOT NULL CHECK (measurement_type IN
    ('night','fasting','regPP','lunchPre','lunchPP','dinnerPre','dinnerPP')),
  bolus_given NUMERIC(6,2),
  notes TEXT,
  created_by UUID NOT NULL REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.clinical_weekly_vc TO authenticated;
GRANT ALL ON public.clinical_weekly_vc TO service_role;
ALTER TABLE public.clinical_weekly_vc ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated read weekly vc" ON public.clinical_weekly_vc
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated insert weekly vc" ON public.clinical_weekly_vc
  FOR INSERT TO authenticated WITH CHECK (created_by = auth.uid());
CREATE POLICY "Author update weekly vc" ON public.clinical_weekly_vc
  FOR UPDATE TO authenticated USING (created_by = auth.uid()) WITH CHECK (created_by = auth.uid());
CREATE POLICY "Author delete weekly vc" ON public.clinical_weekly_vc
  FOR DELETE TO authenticated USING (created_by = auth.uid());
CREATE INDEX idx_weekly_vc_patient_date ON public.clinical_weekly_vc(patient_id, measured_at DESC);

-- 3) Gyógyszer státuszok (per encounter)
CREATE TABLE public.clinical_drug_statuses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  encounter_id UUID REFERENCES public.clinical_encounters(id) ON DELETE SET NULL,
  drug_id TEXT NOT NULL CHECK (drug_id IN ('metformin','su','sglt2','dpp4','glp1')),
  status TEXT NOT NULL CHECK (status IN ('none','current','planned','stop')),
  notes TEXT,
  created_by UUID NOT NULL REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (patient_id, drug_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.clinical_drug_statuses TO authenticated;
GRANT ALL ON public.clinical_drug_statuses TO service_role;
ALTER TABLE public.clinical_drug_statuses ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated read drug statuses" ON public.clinical_drug_statuses
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated upsert drug statuses" ON public.clinical_drug_statuses
  FOR INSERT TO authenticated WITH CHECK (created_by = auth.uid());
CREATE POLICY "Authenticated update drug statuses" ON public.clinical_drug_statuses
  FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Author delete drug statuses" ON public.clinical_drug_statuses
  FOR DELETE TO authenticated USING (created_by = auth.uid());

-- 4) Klinikai kritikus riasztások (cross-modul)
CREATE TABLE public.clinical_critical_alerts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  encounter_id UUID REFERENCES public.clinical_encounters(id) ON DELETE SET NULL,
  source TEXT NOT NULL CHECK (source IN ('insulin','weekly_vc','vergaz','lab','partogram','vital','other')),
  severity TEXT NOT NULL CHECK (severity IN ('info','warn','critical')),
  code TEXT NOT NULL,
  message TEXT NOT NULL,
  value_json JSONB,
  triggered_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  acknowledged_at TIMESTAMPTZ,
  acknowledged_by UUID REFERENCES auth.users(id),
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.clinical_critical_alerts TO authenticated;
GRANT ALL ON public.clinical_critical_alerts TO service_role;
ALTER TABLE public.clinical_critical_alerts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated read clinical alerts" ON public.clinical_critical_alerts
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated insert clinical alerts" ON public.clinical_critical_alerts
  FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated ack clinical alerts" ON public.clinical_critical_alerts
  FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Service role delete clinical alerts" ON public.clinical_critical_alerts
  FOR DELETE TO service_role USING (true);
CREATE INDEX idx_clinical_alerts_patient ON public.clinical_critical_alerts(patient_id, triggered_at DESC);
CREATE INDEX idx_clinical_alerts_unack ON public.clinical_critical_alerts(acknowledged_at) WHERE acknowledged_at IS NULL;

-- 5) updated_at triggerek
CREATE OR REPLACE FUNCTION public.update_clinical_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END $$;

CREATE TRIGGER trg_insulin_sessions_updated BEFORE UPDATE ON public.clinical_insulin_sessions
  FOR EACH ROW EXECUTE FUNCTION public.update_clinical_updated_at();
CREATE TRIGGER trg_drug_statuses_updated BEFORE UPDATE ON public.clinical_drug_statuses
  FOR EACH ROW EXECUTE FUNCTION public.update_clinical_updated_at();

-- 6) Auto-alarm trigger: heti VC mérés → kritikus / warn
CREATE OR REPLACE FUNCTION public.weekly_vc_alarm_trigger()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
DECLARE
  sev TEXT;
  msg TEXT;
  code TEXT;
BEGIN
  IF NEW.value_mmol_l < 3.9 THEN
    sev := 'critical'; code := 'HYPO'; msg := 'Hypoglikémia: VC ' || NEW.value_mmol_l || ' mmol/L';
  ELSIF NEW.value_mmol_l > 22 THEN
    sev := 'critical'; code := 'HYPER_SEVERE'; msg := 'Súlyos hiperglikémia: VC ' || NEW.value_mmol_l || ' mmol/L';
  ELSIF NEW.value_mmol_l > 15 THEN
    sev := 'warn'; code := 'HYPER'; msg := 'Magas vércukor: ' || NEW.value_mmol_l || ' mmol/L';
  ELSE
    RETURN NEW;
  END IF;
  INSERT INTO public.clinical_critical_alerts
    (patient_id, encounter_id, source, severity, code, message, value_json, created_by)
  VALUES
    (NEW.patient_id, NEW.encounter_id, 'weekly_vc', sev, code, msg,
     jsonb_build_object('value_mmol_l', NEW.value_mmol_l, 'measurement_type', NEW.measurement_type,
                        'measured_at', NEW.measured_at, 'vc_id', NEW.id),
     NEW.created_by);
  RETURN NEW;
END $$;

CREATE TRIGGER trg_weekly_vc_alarm AFTER INSERT ON public.clinical_weekly_vc
  FOR EACH ROW EXECUTE FUNCTION public.weekly_vc_alarm_trigger();

-- 7) Auto-alarm trigger: inzulin session → hypo overlay rögzítés
CREATE OR REPLACE FUNCTION public.insulin_session_alarm_trigger()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF NEW.current_vc IS NOT NULL AND NEW.current_vc < 3.9 THEN
    INSERT INTO public.clinical_critical_alerts
      (patient_id, encounter_id, source, severity, code, message, value_json, created_by)
    VALUES
      (NEW.patient_id, NEW.encounter_id, 'insulin', 'critical', 'HYPO_PRE_BOLUS',
       'Hypoglikémia bólusz előtt: VC ' || NEW.current_vc || ' mmol/L — bólusz tiltva',
       jsonb_build_object('current_vc', NEW.current_vc, 'session_id', NEW.id),
       NEW.created_by);
  END IF;
  RETURN NEW;
END $$;

CREATE TRIGGER trg_insulin_session_alarm AFTER INSERT ON public.clinical_insulin_sessions
  FOR EACH ROW EXECUTE FUNCTION public.insulin_session_alarm_trigger();
