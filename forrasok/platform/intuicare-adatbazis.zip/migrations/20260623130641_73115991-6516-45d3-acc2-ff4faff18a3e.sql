
-- ============================================================
-- E2E TESZT SEED — Szilika Klinika tenant
-- Idempotens: ismételt futtatás nem duplikál
-- ============================================================
DO $$
DECLARE
  v_tenant uuid := '13aacb24-a6c2-445c-84b5-5ddbd1fcca82';
  v_site uuid := '3843dfc1-7dd9-4722-bc41-4b8587e83c6c';
  v_muto_id uuid;
  v_ambulancia_id uuid;
  v_resource_id uuid;
  v_patient_id uuid;
BEGIN
  -- 1) E2E Műtő szervezeti egység
  SELECT id INTO v_muto_id FROM public.org_units
    WHERE tenant_id=v_tenant AND nev='E2E_Teszt Műtő' LIMIT 1;
  IF v_muto_id IS NULL THEN
    INSERT INTO public.org_units (tenant_id, site_id, nev, tipus, aktiv, mukodes_kezd, mukodes_veg, muto_blokk_perc)
    VALUES (v_tenant, v_site, 'E2E_Teszt Műtő', 'muto'::org_unit_tipus, true, '08:00','16:00',480)
    RETURNING id INTO v_muto_id;
  END IF;

  -- 2) E2E Kontroll Ambulancia szervezeti egység
  SELECT id INTO v_ambulancia_id FROM public.org_units
    WHERE tenant_id=v_tenant AND nev='E2E_Kontroll Ambulancia' LIMIT 1;
  IF v_ambulancia_id IS NULL THEN
    INSERT INTO public.org_units (tenant_id, site_id, nev, tipus, aktiv, mukodes_kezd, mukodes_veg)
    VALUES (v_tenant, v_site, 'E2E_Kontroll Ambulancia', 'ambulancia'::org_unit_tipus, true, '08:00','12:00')
    RETURNING id INTO v_ambulancia_id;
  END IF;

  -- 3) Appointment resource (rendelő típus) + sablon
  SELECT id INTO v_resource_id FROM public.appointment_resources
    WHERE tenant_id=v_tenant AND nev='E2E_Kontroll Ambulancia' LIMIT 1;
  IF v_resource_id IS NULL THEN
    INSERT INTO public.appointment_resources (tenant_id, nev, tipus, org_unit_id, aktiv, publikus, szin, leiras)
    VALUES (v_tenant, 'E2E_Kontroll Ambulancia', 'rendelo'::appt_resource_tipus, v_ambulancia_id, true, true, '#16a34a', 'E2E teszt — kontroll vizsgálatok')
    RETURNING id INTO v_resource_id;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM public.appointment_templates WHERE tenant_id=v_tenant AND nev='E2E_Kontroll napi sablon') THEN
    INSERT INTO public.appointment_templates
      (tenant_id, resource_id, nev, napok, kezd_ido, veg_ido, slot_perc, kapacitas, aktiv)
    VALUES (v_tenant, v_resource_id, 'E2E_Kontroll napi sablon',
            ARRAY[1,2,3,4,5]::int[], '08:00','12:00', 15, 1, true);
  END IF;

  -- 4) Surgery type
  IF NOT EXISTS (SELECT 1 FROM public.surgery_types WHERE tenant_id=v_tenant AND nev='E2E_Rutin Beavatkozás') THEN
    INSERT INTO public.surgery_types
      (tenant_id, kod, nev, becsult_idotartam_perc, posztop_apolasi_perc, szukseges_szerepek, aktiv)
    VALUES (v_tenant, 'E2E_RUTIN', 'E2E_Rutin Beavatkozás', 60, 30,
            '[{"role":"szakorvos","count":1},{"role":"szakdolgozo","count":1}]'::jsonb, true);
  END IF;

  -- 5) Teszt beteg
  SELECT id INTO v_patient_id FROM public.patients
    WHERE tenant_id=v_tenant AND vezeteknev='E2E_Teszt' AND keresztnev='Béla' LIMIT 1;
  IF v_patient_id IS NULL THEN
    INSERT INTO public.patients (tenant_id, taj, vezeteknev, keresztnev, szuletesi_datum, nem, megjegyzes)
    VALUES (v_tenant, '999000111', 'E2E_Teszt', 'Béla', '1980-01-01', 'ferfi', 'E2E automatizált tesztbeteg')
    RETURNING id INTO v_patient_id;
  END IF;

  -- 6) Monitoring küszöb — vércukor > 11 mmol/l kritikus
  IF NOT EXISTS (SELECT 1 FROM public.monitoring_thresholds WHERE tenant_id=v_tenant AND kulcs='E2E_vercukor_kritikus') THEN
    INSERT INTO public.monitoring_thresholds (tenant_id, kulcs, ertek, unit, megjegyzes)
    VALUES (v_tenant, 'E2E_vercukor_kritikus', 11.0, 'mmol/l', 'E2E: kritikus küszöb vércukorra');
  END IF;

  -- 7) Eszkalációs szabály
  IF NOT EXISTS (SELECT 1 FROM public.clinical_alert_escalation_rules WHERE tenant_id=v_tenant AND name='E2E_Kritikus alert eszkaláció') THEN
    INSERT INTO public.clinical_alert_escalation_rules
      (tenant_id, name, severity, source, escalate_after_minutes, target_role, active)
    VALUES (v_tenant, 'E2E_Kritikus alert eszkaláció', 'critical', 'measurement', 30, 'foorvos', true);
  END IF;
END $$;

-- ============================================================
-- CLEANUP FÜGGVÉNY — admin-only
-- ============================================================
CREATE OR REPLACE FUNCTION public.cleanup_e2e_test_data()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_tenant uuid := '13aacb24-a6c2-445c-84b5-5ddbd1fcca82';
  v_caller uuid := auth.uid();
  v_is_admin boolean;
  v_counts jsonb := '{}'::jsonb;
  v_n int;
BEGIN
  IF v_caller IS NULL THEN
    RAISE EXCEPTION 'Authentikáció szükséges';
  END IF;
  SELECT EXISTS(
    SELECT 1 FROM public.user_roles ur
    JOIN public.roles r ON r.id=ur.role_id
    WHERE ur.user_id=v_caller AND r.kulcs='tenant_admin' AND ur.tenant_id=v_tenant
  ) INTO v_is_admin;
  IF NOT v_is_admin THEN
    RAISE EXCEPTION 'Csak tenant_admin futtathatja (caller=%)', v_caller;
  END IF;

  -- Függő rekordok először
  DELETE FROM public.or_blocks WHERE tenant_id=v_tenant AND org_unit_id IN
    (SELECT id FROM public.org_units WHERE tenant_id=v_tenant AND nev LIKE 'E2E\_%' ESCAPE '\');
  GET DIAGNOSTICS v_n = ROW_COUNT; v_counts := v_counts || jsonb_build_object('or_blocks', v_n);

  DELETE FROM public.appointment_templates WHERE tenant_id=v_tenant AND nev LIKE 'E2E\_%' ESCAPE '\';
  GET DIAGNOSTICS v_n = ROW_COUNT; v_counts := v_counts || jsonb_build_object('appointment_templates', v_n);

  DELETE FROM public.appointment_resources WHERE tenant_id=v_tenant AND nev LIKE 'E2E\_%' ESCAPE '\';
  GET DIAGNOSTICS v_n = ROW_COUNT; v_counts := v_counts || jsonb_build_object('appointment_resources', v_n);

  DELETE FROM public.surgery_types WHERE tenant_id=v_tenant AND nev LIKE 'E2E\_%' ESCAPE '\';
  GET DIAGNOSTICS v_n = ROW_COUNT; v_counts := v_counts || jsonb_build_object('surgery_types', v_n);

  DELETE FROM public.monitoring_thresholds WHERE tenant_id=v_tenant AND kulcs LIKE 'E2E\_%' ESCAPE '\';
  GET DIAGNOSTICS v_n = ROW_COUNT; v_counts := v_counts || jsonb_build_object('monitoring_thresholds', v_n);

  DELETE FROM public.clinical_alert_escalation_rules WHERE tenant_id=v_tenant AND name LIKE 'E2E\_%' ESCAPE '\';
  GET DIAGNOSTICS v_n = ROW_COUNT; v_counts := v_counts || jsonb_build_object('escalation_rules', v_n);

  DELETE FROM public.patients WHERE tenant_id=v_tenant AND vezeteknev='E2E_Teszt';
  GET DIAGNOSTICS v_n = ROW_COUNT; v_counts := v_counts || jsonb_build_object('patients', v_n);

  DELETE FROM public.org_units WHERE tenant_id=v_tenant AND nev LIKE 'E2E\_%' ESCAPE '\';
  GET DIAGNOSTICS v_n = ROW_COUNT; v_counts := v_counts || jsonb_build_object('org_units', v_n);

  RETURN jsonb_build_object('ok', true, 'deleted', v_counts, 'tenant_id', v_tenant);
END;
$$;

GRANT EXECUTE ON FUNCTION public.cleanup_e2e_test_data() TO authenticated;
