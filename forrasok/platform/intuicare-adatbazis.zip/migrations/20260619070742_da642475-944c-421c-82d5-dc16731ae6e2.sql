DO $$
DECLARE
  v_tenant uuid := '13aacb24-a6c2-445c-84b5-5ddbd1fcca82';
  v_pw text := crypt('test1234', gen_salt('bf'));
  new_id uuid;
  v_role_id uuid;
  orvosok text[][] := ARRAY[
    ['Kovács','Anna','foorvos'],['Nagy','Béla','foorvos'],
    ['Szabó','Csilla','szakorvos'],['Tóth','Dániel','szakorvos'],
    ['Horváth','Eszter','szakorvos'],['Varga','Ferenc','szakorvos'],
    ['Kiss','Gábor','rezidens'],['Molnár','Hanna','rezidens'],
    ['Németh','István','rezidens'],['Farkas','Júlia','rezidens'],
    ['Balogh','Krisztián','szakgyakornok'],['Papp','Laura','szakgyakornok'],
    ['Takács','Márton','szakgyakornok'],['Juhász','Nóra','szakgyakornok'],
    ['Lakatos','Orsolya','vezetorezidens'],['Mészáros','Péter','vezetorezidens'],
    ['Oláh','Réka','ugyeletvezeto'],['Simon','Szabolcs','ugyeletvezeto'],
    ['Rácz','Tímea','intezetvezeto'],['Fekete','Viktor','intezetvezeto']
  ];
  szakd text[][] := ARRAY[
    ['Bognár','Adél','gyakorlo'],['Sándor','Bence','gyakorlo'],
    ['Antal','Csenge','gyakorlo'],['Bíró','Donát','gyakorlo'],
    ['Fodor','Eleonóra','pro'],['Gál','Flórián','pro'],
    ['Halász','Gabriella','pro'],['Hegedűs','Hubert','pro'],
    ['Király','Ilona','pro'],['Lukács','János','pro'],
    ['Major','Katalin','mester'],['Pál','Levente','mester'],
    ['Pásztor','Melinda','mester'],['Pintér','Norbert','mester'],
    ['Soós','Petra','szakteruleti_expert'],['Sipos','Roland','szakteruleti_expert'],
    ['Tamás','Sára','szakteruleti_expert'],['Váradi','Tibor','gyakornok_szakd'],
    ['Veres','Ursula','gyakornok_szakd'],['Vincze','Zoltán','gyakornok_szakd']
  ];
  i int; v_email text; v_nev text; v_role text; v_fogl text;
BEGIN
  FOR i IN 1..40 LOOP
    IF i <= 20 THEN
      v_nev := 'Dr. ' || orvosok[i][1] || ' ' || orvosok[i][2];
      v_email := 'teszt.orvos' || lpad(i::text,2,'0') || '@szilika.test';
      v_role := orvosok[i][3]; v_fogl := 'orvos';
    ELSE
      v_nev := szakd[i-20][1] || ' ' || szakd[i-20][2];
      v_email := 'teszt.szakd' || lpad((i-20)::text,2,'0') || '@szilika.test';
      v_role := szakd[i-20][3]; v_fogl := 'szakdolgozo';
    END IF;

    SELECT id INTO new_id FROM auth.users WHERE email = v_email LIMIT 1;
    IF new_id IS NULL THEN
      new_id := gen_random_uuid();
      INSERT INTO auth.users (instance_id, id, aud, role, email, encrypted_password,
        email_confirmed_at, created_at, updated_at, raw_app_meta_data, raw_user_meta_data, is_super_admin)
      VALUES ('00000000-0000-0000-0000-000000000000', new_id, 'authenticated', 'authenticated',
        v_email, v_pw, now(), now(), now(),
        '{"provider":"email","providers":["email"]}'::jsonb,
        jsonb_build_object('teljes_nev', v_nev, 'seed', true), false);

      INSERT INTO auth.identities (id, user_id, identity_data, provider, provider_id, last_sign_in_at, created_at, updated_at)
      VALUES (gen_random_uuid(), new_id,
        jsonb_build_object('sub', new_id::text, 'email', v_email, 'email_verified', true),
        'email', v_email, now(), now(), now());
    END IF;

    INSERT INTO public.profiles (id, tenant_id, email, teljes_nev, foglalkozas_tipus, aktiv)
    VALUES (new_id, v_tenant, v_email, v_nev, v_fogl::public.foglalkozas_tipus, true)
    ON CONFLICT (id) DO UPDATE
      SET tenant_id = EXCLUDED.tenant_id,
          teljes_nev = EXCLUDED.teljes_nev,
          foglalkozas_tipus = EXCLUDED.foglalkozas_tipus,
          aktiv = true;

    SELECT id INTO v_role_id FROM public.roles WHERE kulcs = v_role;
    IF v_role_id IS NOT NULL THEN
      INSERT INTO public.user_roles (user_id, role_id, tenant_id, ervenyes_tol)
      VALUES (new_id, v_role_id, v_tenant, now()) ON CONFLICT DO NOTHING;
    END IF;
  END LOOP;
END $$;