
CREATE EXTENSION IF NOT EXISTS pg_net;

-- Extend allowed kind values on shift_notifications_sent
ALTER TABLE public.shift_notifications_sent DROP CONSTRAINT IF EXISTS shift_notifications_sent_kind_check;
ALTER TABLE public.shift_notifications_sent ADD CONSTRAINT shift_notifications_sent_kind_check
  CHECK (kind IN ('24h','2h','new','change','cancel'));

-- Enqueue helper: fires an async POST to the public webhook, non-blocking.
CREATE OR REPLACE FUNCTION public.enqueue_assignment_push(_event text, _row jsonb, _changes text[])
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_url text := 'https://project--23fe2ad3-1ad0-4e50-b650-1486a8fd8e70.lovable.app/api/public/hooks/schedule-notify';
  v_apikey text := 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZpdWhueXp5eHFrc21kZ3BxdmloIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODE3OTg4NzgsImV4cCI6MjA5NzM3NDg3OH0.R2fE1KWLwyK-ftcJw7gDwJ43Xik32Iu_OiXSKqx_qiM';
BEGIN
  BEGIN
    PERFORM net.http_post(
      url := v_url,
      headers := jsonb_build_object('Content-Type','application/json','apikey', v_apikey),
      body := jsonb_build_object('event', _event, 'assignment', _row, 'changes', to_jsonb(_changes))
    );
  EXCEPTION WHEN OTHERS THEN
    -- swallow: never block the mutation on webhook failure
    NULL;
  END;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.enqueue_assignment_push(text, jsonb, text[]) FROM PUBLIC, anon, authenticated;

-- INSERT trigger: notify user of a newly-assigned shift
CREATE OR REPLACE FUNCTION public.notify_assignment_insert()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.user_id IS NULL THEN RETURN NEW; END IF;
  IF NEW.status::text = 'visszavont' THEN RETURN NEW; END IF;
  -- Skip if the user assigned it to themselves
  IF auth.uid() IS NOT NULL AND NEW.user_id = auth.uid() THEN RETURN NEW; END IF;

  PERFORM public.enqueue_assignment_push('new', to_jsonb(NEW), NULL);

  INSERT INTO public.notifications(tenant_id, user_id, tipus, cim, uzenet, link)
  VALUES (NEW.tenant_id, NEW.user_id, 'beosztas',
    'Új műszakot kaptál',
    to_char(NEW.kezdo_idopont AT TIME ZONE 'Europe/Budapest','YYYY-MM-DD HH24:MI')
      || ' (' || NEW.kategoria::text || ')',
    '/beosztas');

  RETURN NEW;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.notify_assignment_insert() FROM PUBLIC, anon;
DROP TRIGGER IF EXISTS sa_notify_insert ON public.schedule_assignments;
CREATE TRIGGER sa_notify_insert
  AFTER INSERT ON public.schedule_assignments
  FOR EACH ROW EXECUTE FUNCTION public.notify_assignment_insert();

-- DELETE trigger: notify user of a cancelled shift
CREATE OR REPLACE FUNCTION public.notify_assignment_delete()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF OLD.user_id IS NULL THEN RETURN OLD; END IF;
  IF auth.uid() IS NOT NULL AND OLD.user_id = auth.uid() THEN RETURN OLD; END IF;

  PERFORM public.enqueue_assignment_push('cancel', to_jsonb(OLD), NULL);

  INSERT INTO public.notifications(tenant_id, user_id, tipus, cim, uzenet, link)
  VALUES (OLD.tenant_id, OLD.user_id, 'beosztas',
    'Törölt műszak',
    to_char(OLD.kezdo_idopont AT TIME ZONE 'Europe/Budapest','YYYY-MM-DD HH24:MI')
      || ' (' || OLD.kategoria::text || ')',
    '/beosztas');

  RETURN OLD;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.notify_assignment_delete() FROM PUBLIC, anon;
DROP TRIGGER IF EXISTS sa_notify_delete ON public.schedule_assignments;
CREATE TRIGGER sa_notify_delete
  AFTER DELETE ON public.schedule_assignments
  FOR EACH ROW EXECUTE FUNCTION public.notify_assignment_delete();

-- UPDATE trigger: keep the existing in-app notification AND enqueue a push
CREATE OR REPLACE FUNCTION public.notify_assignment_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_changes text[] := ARRAY[]::text[];
  v_msg text;
BEGIN
  IF NEW.user_id IS NULL THEN RETURN NEW; END IF;
  IF auth.uid() IS NOT NULL AND NEW.user_id = auth.uid() THEN
    RETURN NEW;
  END IF;

  IF NEW.kezdo_idopont IS DISTINCT FROM OLD.kezdo_idopont
     OR NEW.zaro_idopont IS DISTINCT FROM OLD.zaro_idopont THEN
    v_changes := array_append(v_changes,
      'Új időpont: ' || to_char(NEW.kezdo_idopont AT TIME ZONE 'Europe/Budapest','YYYY-MM-DD HH24:MI')
       || '–' || to_char(NEW.zaro_idopont AT TIME ZONE 'Europe/Budapest','HH24:MI'));
  END IF;
  IF NEW.status IS DISTINCT FROM OLD.status THEN
    v_changes := array_append(v_changes, 'Státusz: ' || NEW.status::text);
  END IF;
  IF NEW.kategoria IS DISTINCT FROM OLD.kategoria THEN
    v_changes := array_append(v_changes, 'Kategória: ' || NEW.kategoria::text);
  END IF;

  IF array_length(v_changes, 1) IS NULL THEN
    RETURN NEW;
  END IF;

  v_msg := array_to_string(v_changes, ' • ');

  INSERT INTO public.notifications(tenant_id, user_id, tipus, cim, uzenet, link)
  VALUES (NEW.tenant_id, NEW.user_id, 'beosztas',
    'Beosztásod változott',
    v_msg,
    '/iranyitopult');

  PERFORM public.enqueue_assignment_push('change', to_jsonb(NEW), v_changes);

  RETURN NEW;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.notify_assignment_change() FROM PUBLIC, anon;
