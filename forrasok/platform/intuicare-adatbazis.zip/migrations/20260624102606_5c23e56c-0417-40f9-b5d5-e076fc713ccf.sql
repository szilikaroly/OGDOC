
-- 1) work_time_ledger új oszlopok
ALTER TABLE public.work_time_ledger
  ADD COLUMN IF NOT EXISTS potlek_kod text,
  ADD COLUMN IF NOT EXISTS projekt text,
  ADD COLUMN IF NOT EXISTS koltseghely text,
  ADD COLUMN IF NOT EXISTS dijazas_tipus text
    CHECK (dijazas_tipus IS NULL OR dijazas_tipus IN ('alap','potlek','bonusz','tulora','keszenleti_dij','ugyeleti_dij')),
  ADD COLUMN IF NOT EXISTS munkaltatoi_dontes jsonb;

COMMENT ON COLUMN public.work_time_ledger.munkaltatoi_dontes IS 'Munkáltatói döntés metaadat: {dontes_szam, dontes_datum, indok, hivatkozas}';

-- 2) work_time_rules új oszlopok
ALTER TABLE public.work_time_rules
  ADD COLUMN IF NOT EXISTS ugyelet_utan_piheno_nap boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS ugyelet_munkaidokeret_terhere boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS munkaszuneti_utan_szabadnap_fizetett boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS ejszakai_potlek_szazalek numeric NOT NULL DEFAULT 15,
  ADD COLUMN IF NOT EXISTS vasarnapi_potlek_szazalek numeric NOT NULL DEFAULT 50,
  ADD COLUMN IF NOT EXISTS unnepnapi_potlek_szazalek numeric NOT NULL DEFAULT 100,
  ADD COLUMN IF NOT EXISTS ugyeleti_dij_szazalek numeric NOT NULL DEFAULT 50,
  ADD COLUMN IF NOT EXISTS keszenleti_dij_szazalek numeric NOT NULL DEFAULT 25,
  ADD COLUMN IF NOT EXISTS munkaidokeret_honap integer NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS jogszabaly_hivatkozas text;

-- 3) Egyedi tenant-szintű munkaidő-szabályok
CREATE TABLE IF NOT EXISTS public.work_time_custom_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  nev text NOT NULL,
  szabaly_tipus text NOT NULL CHECK (szabaly_tipus IN (
    'ugyelet_utan_piheno','min_piheno_muszakok_kozott','unnep_auto_felar',
    'max_havi_potlek_ora','max_heti_ugyelet','kotelezo_ebed_szunet',
    'eltolt_muszak_korlat','egyedi'
  )),
  konfiguracio jsonb NOT NULL DEFAULT '{}'::jsonb,
  jogszabaly_hivatkozas text,
  prioritas smallint NOT NULL DEFAULT 100,
  aktiv boolean NOT NULL DEFAULT true,
  ervenyes_tol date NOT NULL DEFAULT CURRENT_DATE,
  ervenyes_ig date,
  jogviszony_tipus jogviszony_tipus,
  fenntarto_tipus  fenntarto_tipus,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_wtcr_tenant_aktiv
  ON public.work_time_custom_rules(tenant_id, aktiv, prioritas);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.work_time_custom_rules TO authenticated;
GRANT ALL ON public.work_time_custom_rules TO service_role;

ALTER TABLE public.work_time_custom_rules ENABLE ROW LEVEL SECURITY;

CREATE POLICY "wtcr_tenant_read"
  ON public.work_time_custom_rules FOR SELECT TO authenticated
  USING (tenant_id = current_tenant_id());

CREATE POLICY "wtcr_admin_write"
  ON public.work_time_custom_rules FOR ALL TO authenticated
  USING (
    tenant_id = current_tenant_id()
    AND (has_role(auth.uid(), 'tenant_admin')
         OR has_permission(auth.uid(), 'manage_worktime'))
  )
  WITH CHECK (
    tenant_id = current_tenant_id()
    AND (has_role(auth.uid(), 'tenant_admin')
         OR has_permission(auth.uid(), 'manage_worktime'))
  );

CREATE TRIGGER trg_wtcr_updated_at
  BEFORE UPDATE ON public.work_time_custom_rules
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER trg_wtcr_audit
  AFTER INSERT OR UPDATE OR DELETE ON public.work_time_custom_rules
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- 4) 2020. évi C. tv. bértábla
CREATE TABLE IF NOT EXISTS public.wage_table_egeszsegugyi (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  besorolasi_kategoria text NOT NULL,
  fizetesi_fokozat smallint NOT NULL,
  munkakor_megnevezes text,
  alapilletmeny_ft integer NOT NULL,
  garantalt_illetmeny_ft integer,
  potlek_alap_ft integer,
  ervenyes_tol date NOT NULL,
  ervenyes_ig date,
  jogszabaly_hivatkozas text DEFAULT '2020. évi C. törvény az egészségügyi szolgálati jogviszonyról',
  forrasszoveg text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, besorolasi_kategoria, fizetesi_fokozat, ervenyes_tol)
);

CREATE INDEX IF NOT EXISTS idx_wte_lookup
  ON public.wage_table_egeszsegugyi(tenant_id, ervenyes_tol);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.wage_table_egeszsegugyi TO authenticated;
GRANT ALL ON public.wage_table_egeszsegugyi TO service_role;

ALTER TABLE public.wage_table_egeszsegugyi ENABLE ROW LEVEL SECURITY;

CREATE POLICY "wte_read_global_or_tenant"
  ON public.wage_table_egeszsegugyi FOR SELECT TO authenticated
  USING (tenant_id IS NULL OR tenant_id = current_tenant_id());

CREATE POLICY "wte_admin_write"
  ON public.wage_table_egeszsegugyi FOR ALL TO authenticated
  USING (
    tenant_id = current_tenant_id()
    AND (has_role(auth.uid(), 'tenant_admin')
         OR has_permission(auth.uid(), 'manage_worktime'))
  )
  WITH CHECK (
    tenant_id = current_tenant_id()
    AND (has_role(auth.uid(), 'tenant_admin')
         OR has_permission(auth.uid(), 'manage_worktime'))
  );

CREATE TRIGGER trg_wte_updated_at
  BEFORE UPDATE ON public.wage_table_egeszsegugyi
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER trg_wte_audit
  AFTER INSERT OR UPDATE OR DELETE ON public.wage_table_egeszsegugyi
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- 5) Új jogosultság-kulcs: manage_worktime — alapból a tenant_admin szerepkör megkapja
INSERT INTO public.role_permissions (role_kulcs, perm)
VALUES ('tenant_admin', 'manage_worktime')
ON CONFLICT DO NOTHING;
