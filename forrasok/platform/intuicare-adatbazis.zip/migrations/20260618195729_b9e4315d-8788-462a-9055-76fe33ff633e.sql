CREATE TABLE IF NOT EXISTS public.training_program_elements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  program_id UUID NOT NULL REFERENCES public.training_programs(id) ON DELETE CASCADE,
  parent_element_id UUID REFERENCES public.training_program_elements(id) ON DELETE CASCADE,
  kod TEXT,
  nev TEXT NOT NULL,
  leiras TEXT,
  kategoria TEXT,
  sorszam SMALLINT NOT NULL DEFAULT 0,
  idotartam_honap NUMERIC(5,2),
  milestone TEXT,
  kotelezo BOOLEAN NOT NULL DEFAULT true,
  klinikan_kivul_engedett BOOLEAN NOT NULL DEFAULT false,
  aktiv BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.training_program_elements TO authenticated;
GRANT ALL ON public.training_program_elements TO service_role;
ALTER TABLE public.training_program_elements ENABLE ROW LEVEL SECURITY;
CREATE POLICY tpe_select_via_parent ON public.training_program_elements FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.training_programs p WHERE p.id = training_program_elements.program_id AND p.tenant_id = public.current_tenant_id()));
CREATE POLICY tpe_write_training ON public.training_program_elements FOR ALL TO authenticated
  USING (public.has_permission(auth.uid(),'manage_training') AND EXISTS (SELECT 1 FROM public.training_programs p WHERE p.id = training_program_elements.program_id AND p.tenant_id = public.current_tenant_id()))
  WITH CHECK (public.has_permission(auth.uid(),'manage_training') AND EXISTS (SELECT 1 FROM public.training_programs p WHERE p.id = training_program_elements.program_id AND p.tenant_id = public.current_tenant_id()));
CREATE INDEX idx_tpe_program ON public.training_program_elements(program_id);
CREATE INDEX idx_tpe_parent  ON public.training_program_elements(parent_element_id);
CREATE TRIGGER touch_tpe BEFORE UPDATE ON public.training_program_elements FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER audit_tpe AFTER INSERT OR UPDATE OR DELETE ON public.training_program_elements FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

CREATE TABLE IF NOT EXISTS public.training_program_interventions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  program_id UUID NOT NULL REFERENCES public.training_programs(id) ON DELETE CASCADE,
  element_id UUID REFERENCES public.training_program_elements(id) ON DELETE SET NULL,
  milestone TEXT,
  beavatkozas_id UUID REFERENCES public.beavatkozasok(id) ON DELETE SET NULL,
  beavatkozas_nev TEXT NOT NULL,
  szerep TEXT NOT NULL DEFAULT 'operator',
  szint TEXT,
  required_esetszam INT NOT NULL DEFAULT 0,
  klinikan_kivul_engedett BOOLEAN NOT NULL DEFAULT true,
  sorszam SMALLINT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.training_program_interventions TO authenticated;
GRANT ALL ON public.training_program_interventions TO service_role;
ALTER TABLE public.training_program_interventions ENABLE ROW LEVEL SECURITY;
CREATE POLICY tpi_select_via_parent ON public.training_program_interventions FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.training_programs p WHERE p.id = training_program_interventions.program_id AND p.tenant_id = public.current_tenant_id()));
CREATE POLICY tpi_write_training ON public.training_program_interventions FOR ALL TO authenticated
  USING (public.has_permission(auth.uid(),'manage_training') AND EXISTS (SELECT 1 FROM public.training_programs p WHERE p.id = training_program_interventions.program_id AND p.tenant_id = public.current_tenant_id()))
  WITH CHECK (public.has_permission(auth.uid(),'manage_training') AND EXISTS (SELECT 1 FROM public.training_programs p WHERE p.id = training_program_interventions.program_id AND p.tenant_id = public.current_tenant_id()));
CREATE INDEX idx_tpi_program ON public.training_program_interventions(program_id);
CREATE INDEX idx_tpi_milestone ON public.training_program_interventions(program_id, milestone);
CREATE TRIGGER touch_tpi BEFORE UPDATE ON public.training_program_interventions FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER audit_tpi AFTER INSERT OR UPDATE OR DELETE ON public.training_program_interventions FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

CREATE TABLE IF NOT EXISTS public.profile_program_milestones (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  program_id UUID NOT NULL REFERENCES public.training_programs(id) ON DELETE CASCADE,
  milestone TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'folyamatban',
  elerve_at TIMESTAMPTZ,
  megjegyzes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, program_id, milestone)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_program_milestones TO authenticated;
GRANT ALL ON public.profile_program_milestones TO service_role;
ALTER TABLE public.profile_program_milestones ENABLE ROW LEVEL SECURITY;
CREATE POLICY ppm_select_self_or_team ON public.profile_program_milestones FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (user_id = auth.uid() OR public.has_permission(auth.uid(),'view_team') OR public.has_permission(auth.uid(),'manage_training') OR public.has_permission(auth.uid(),'manage_tenant')));
CREATE POLICY ppm_write_training ON public.profile_program_milestones FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (public.has_permission(auth.uid(),'manage_training') OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id() AND (public.has_permission(auth.uid(),'manage_training') OR public.has_permission(auth.uid(),'manage_tenant')));
CREATE INDEX idx_ppm_user ON public.profile_program_milestones(user_id);
CREATE INDEX idx_ppm_program ON public.profile_program_milestones(program_id);
CREATE TRIGGER touch_ppm BEFORE UPDATE ON public.profile_program_milestones FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER audit_ppm AFTER INSERT OR UPDATE OR DELETE ON public.profile_program_milestones FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

DO $$
DECLARE
  t RECORD; v_program UUID; v_phase1 UUID; v_phase2 UUID;
BEGIN
  FOR t IN SELECT id FROM public.tenants LOOP
    SELECT id INTO v_program FROM public.training_programs
     WHERE tenant_id = t.id AND nev = 'Szülészet-nőgyógyászat szakorvosképzés';
    IF v_program IS NULL THEN
      INSERT INTO public.training_programs(tenant_id, nev, leiras, honap_hossz)
      VALUES (t.id,'Szülészet-nőgyógyászat szakorvosképzés','53 hó 2 hét, 2 részvizsga + szakvizsga (42. szakképesítés)',54)
      RETURNING id INTO v_program;
    END IF;

    SELECT id INTO v_phase1 FROM public.training_program_elements WHERE program_id = v_program AND kod = 'PH1';
    IF v_phase1 IS NULL THEN
      INSERT INTO public.training_program_elements(program_id, kod, nev, kategoria, sorszam, idotartam_honap, milestone, kotelezo)
      VALUES (v_program,'PH1','Első két év (22 hó) – 1. részvizsga felé','fazis',1,22,'reszvizsga_1',true)
      RETURNING id INTO v_phase1;
      INSERT INTO public.training_program_elements(program_id, parent_element_id, kod, nev, kategoria, sorszam, idotartam_honap, milestone, klinikan_kivul_engedett) VALUES
        (v_program, v_phase1, 'PH1.1','Sürgősségi gyakorlat','rotacio',1,2,'reszvizsga_1', true),
        (v_program, v_phase1, 'PH1.2','Multidiszciplináris intenzív terápia','rotacio',2,1,'reszvizsga_1', true),
        (v_program, v_phase1, 'PH1.3','Mentőgyakorlat','rotacio',3,0.5,'reszvizsga_1', true),
        (v_program, v_phase1, 'PH1.4','Sebészeti gyakorlat (skill tréning 1 hó)','rotacio',4,3,'reszvizsga_1', true),
        (v_program, v_phase1, 'PH1.5','Szülészeti képzés','torzs',5,7.75,'reszvizsga_1', true),
        (v_program, v_phase1, 'PH1.6','Nőgyógyászati képzés','torzs',6,7.75,'reszvizsga_1', true);
    END IF;

    SELECT id INTO v_phase2 FROM public.training_program_elements WHERE program_id = v_program AND kod = 'PH2';
    IF v_phase2 IS NULL THEN
      INSERT INTO public.training_program_elements(program_id, kod, nev, kategoria, sorszam, idotartam_honap, milestone, kotelezo)
      VALUES (v_program,'PH2','Fennmaradó képzés (31 hó 2 hét) – 2. részvizsga és szakvizsga felé','fazis',2,31.5,'szakvizsga',true)
      RETURNING id INTO v_phase2;
      INSERT INTO public.training_program_elements(program_id, parent_element_id, kod, nev, kategoria, sorszam, idotartam_honap, milestone, klinikan_kivul_engedett) VALUES
        (v_program, v_phase2, 'PH2.1','Szülészet','torzs',1,9.25,'reszvizsga_2', true),
        (v_program, v_phase2, 'PH2.2','Nőgyógyászat','torzs',2,9.25,'reszvizsga_2', true),
        (v_program, v_phase2, 'PH2.3','Nőgyógyászati onkológia','rotacio',3,2,'szakvizsga', true),
        (v_program, v_phase2, 'PH2.4','Nőgyógyászati endokrinológia és asszisztált reprodukció','rotacio',4,1,'szakvizsga', true),
        (v_program, v_phase2, 'PH2.5','Szülészeti aneszteziológia','rotacio',5,1,'szakvizsga', true),
        (v_program, v_phase2, 'PH2.6','Urológia','rotacio',6,1,'szakvizsga', true),
        (v_program, v_phase2, 'PH2.7','Szülészet-nőgyógyászat ultrahang','rotacio',7,3,'szakvizsga', true),
        (v_program, v_phase2, 'PH2.8','Kötelező egyetemi tanfolyamok (Kolposzkópia, Neonatológia, Endoszkópia, Pszichoszomatika, Gyermeknőgyógyászat, UH-diagnosztika)','tanfolyam',8,2,'szakvizsga', false),
        (v_program, v_phase2, 'PH2.9','Háziorvosi gyakorlat','rotacio',9,2.5,'szakvizsga', true),
        (v_program, v_phase2, 'PH2.10','Várandósgondozás háziorvosi együttműködésben','rotacio',10,0.5,'szakvizsga', true);
    END IF;

    IF NOT EXISTS (SELECT 1 FROM public.training_program_interventions WHERE program_id = v_program AND milestone='reszvizsga_1') THEN
      INSERT INTO public.training_program_interventions (program_id, milestone, beavatkozas_nev, szint, required_esetszam, klinikan_kivul_engedett, sorszam)
      VALUES
        (v_program,'reszvizsga_1','Hüvelyi szülés levezetése','IV',15,true,1),
        (v_program,'reszvizsga_1','Gátmetszés és ellátása','IV',15,true,2),
        (v_program,'reszvizsga_1','Várandós szülőszobai felvétele','IV',50,true,3),
        (v_program,'reszvizsga_1','Diagnosztikus terv elkészítése szülőszobán','IV',50,true,4),
        (v_program,'reszvizsga_1','Terápiás terv készítése szülőszobán','IV',50,true,5),
        (v_program,'reszvizsga_1','Császármetszés asszisztencia','IV',50,true,6),
        (v_program,'reszvizsga_1','Cardiotocographia','IV',100,true,7),
        (v_program,'reszvizsga_1','Vénabiztosítás, vérvétel','I',30,true,8),
        (v_program,'reszvizsga_1','Zárójelentés összeállítása gyermekágyon','IV',50,true,9);
    END IF;

    IF NOT EXISTS (SELECT 1 FROM public.training_program_interventions WHERE program_id = v_program AND milestone='reszvizsga_2') THEN
      INSERT INTO public.training_program_interventions (program_id, milestone, beavatkozas_nev, szint, required_esetszam, klinikan_kivul_engedett, sorszam)
      VALUES
        (v_program,'reszvizsga_2','Nőgyógyászati vizsgálat','II',100,true,1),
        (v_program,'reszvizsga_2','Nőgyógyászati kisműtétek','III',50,true,2),
        (v_program,'reszvizsga_2','Szülészeti vizsgálat','II',150,true,3),
        (v_program,'reszvizsga_2','Szülés levezetése','III',50,true,4),
        (v_program,'reszvizsga_2','Császármetszés végzése','IV',30,true,5),
        (v_program,'reszvizsga_2','Hüvelyi szülésbefejező beavatkozás elvégzése','IV',2,true,6),
        (v_program,'reszvizsga_2','Akut nőgyógyászati onkológiai ellátás','IV',30,true,7),
        (v_program,'reszvizsga_2','Tájékozódó szülészeti vizsgálat','II',100,true,8),
        (v_program,'reszvizsga_2','Nőgyógyászati ultrahang vizsgálat','II',100,true,9);
    END IF;

    IF NOT EXISTS (SELECT 1 FROM public.training_program_interventions WHERE program_id = v_program AND milestone='szakvizsga') THEN
      INSERT INTO public.training_program_interventions (program_id, milestone, beavatkozas_nev, szerep, required_esetszam, klinikan_kivul_engedett, sorszam)
      VALUES
        (v_program,'szakvizsga','Császármetszés','operator',50,true,1),
        (v_program,'szakvizsga','Hüvelyi szülésvezetés','operator',100,true,2),
        (v_program,'szakvizsga','Hüvelyi szülésbefejező beavatkozások','operator',5,true,3),
        (v_program,'szakvizsga','Méhűri betapintás','operator',10,true,4),
        (v_program,'szakvizsga','Vetélés befejező beavatkozások és terhességmegszakítás','operator',20,true,5),
        (v_program,'szakvizsga','Hüvelyfali és méhnyak műtétek','operator',20,true,6),
        (v_program,'szakvizsga','Diagnosztikus hysteroscopia','operator',10,true,7),
        (v_program,'szakvizsga','Operatív hysteroscopia','operator',5,true,8),
        (v_program,'szakvizsga','Hüvelyi méheltávolítás','operator',10,true,9),
        (v_program,'szakvizsga','Diagnosztikus laparoscopia','operator',10,true,10),
        (v_program,'szakvizsga','Operatív laparoscopia','operator',5,true,11),
        (v_program,'szakvizsga','Adnex műtét (laparoscopia / laparotomia)','operator',15,true,12),
        (v_program,'szakvizsga','Hasi méheltávolítás','operator',10,true,13),
        (v_program,'szakvizsga','Onkológiai műtét asszisztencia','asszisztens',5,true,14),
        (v_program,'szakvizsga','Hasi sebészet műtétasszisztálás','asszisztens',5,true,15);
    END IF;

  END LOOP;
END$$;