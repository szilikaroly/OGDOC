
-- 1. admin_audit_log: add tenant scoping to update policy
DROP POLICY IF EXISTS audit_update_own_recent ON public.admin_audit_log;
CREATE POLICY audit_update_own_recent ON public.admin_audit_log
  FOR UPDATE TO authenticated
  USING (user_id = auth.uid()
         AND tenant_id = current_tenant_id()
         AND created_at > (now() - interval '10 minutes'))
  WITH CHECK (user_id = auth.uid() AND tenant_id = current_tenant_id());

-- 2. app_settings_audit: restrict inserts via view_audit permission
DROP POLICY IF EXISTS "Admins insert audit" ON public.app_settings_audit;
CREATE POLICY app_settings_audit_insert ON public.app_settings_audit
  FOR INSERT TO authenticated
  WITH CHECK (has_permission(auth.uid(), 'manage_tenant'));

-- 3. profile_external_hours: enforce tenant_id on leader policies
DROP POLICY IF EXISTS external_hours_leaders_select ON public.profile_external_hours;
CREATE POLICY external_hours_leaders_select ON public.profile_external_hours
  FOR SELECT TO authenticated
  USING (tenant_id = current_tenant_id()
         AND (has_permission(auth.uid(), 'view_team')
              OR has_permission(auth.uid(), 'manage_org')
              OR has_permission(auth.uid(), 'manage_schedule')));

DROP POLICY IF EXISTS external_hours_leaders_modify ON public.profile_external_hours;
CREATE POLICY external_hours_leaders_modify ON public.profile_external_hours
  FOR ALL TO authenticated
  USING (tenant_id = current_tenant_id()
         AND (has_permission(auth.uid(), 'manage_org')
              OR has_permission(auth.uid(), 'manage_schedule')))
  WITH CHECK (tenant_id = current_tenant_id()
              AND (has_permission(auth.uid(), 'manage_org')
                   OR has_permission(auth.uid(), 'manage_schedule')));

-- 4. role_permissions: remove tenant_admin direct write path
DROP POLICY IF EXISTS role_perms_admin_write ON public.role_permissions;
-- service_role retains full access via existing GRANT ALL

-- 5. patient_lifestyle_log: add tenant-scoped staff read policy
CREATE POLICY patient_lifestyle_log_staff_select ON public.patient_lifestyle_log
  FOR SELECT TO authenticated
  USING (
    has_permission(auth.uid(), 'manage_patients')
    AND patient_id IN (
      SELECT id FROM public.patients WHERE tenant_id = current_tenant_id()
    )
  );

-- 6. messages: prevent participants from forging ai/system messages
DROP POLICY IF EXISTS messages_insert_participant ON public.messages;
CREATE POLICY messages_insert_participant ON public.messages
  FOR INSERT TO authenticated
  WITH CHECK (
    is_conversation_participant(conversation_id, auth.uid())
    AND sender_user_id = auth.uid()
    AND sender_kind = 'user'::message_sender_kind
  );
