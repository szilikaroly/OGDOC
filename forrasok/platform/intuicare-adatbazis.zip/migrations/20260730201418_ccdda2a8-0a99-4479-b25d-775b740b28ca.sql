CREATE TABLE IF NOT EXISTS public.i18n_source_strings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  namespace text NOT NULL DEFAULT 'ui',
  key text NOT NULL,
  source_text text NOT NULL,
  element_type text NOT NULL DEFAULT 'label' CHECK (element_type IN ('label','button','title','placeholder','helper','error','menu','badge','content','other')),
  screen text,
  description text,
  translator_note text,
  max_length integer,
  is_active boolean NOT NULL DEFAULT true,
  ai_described boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (namespace, key)
);

CREATE INDEX IF NOT EXISTS i18n_source_strings_ns_idx ON public.i18n_source_strings(namespace);
CREATE INDEX IF NOT EXISTS i18n_source_strings_desc_idx ON public.i18n_source_strings(ai_described);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.i18n_source_strings TO authenticated;
GRANT ALL ON public.i18n_source_strings TO service_role;
ALTER TABLE public.i18n_source_strings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "i18n_source_strings_read" ON public.i18n_source_strings
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "i18n_source_strings_admin_write" ON public.i18n_source_strings
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'tenant_admin'))
  WITH CHECK (public.has_role(auth.uid(), 'tenant_admin'));

CREATE TABLE IF NOT EXISTS public.i18n_translation_jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  langs text[] NOT NULL,
  namespace text,
  mode text NOT NULL DEFAULT 'missing' CHECK (mode IN ('missing','full')),
  status text NOT NULL DEFAULT 'running' CHECK (status IN ('running','done','partial','failed')),
  total integer NOT NULL DEFAULT 0,
  translated integer NOT NULL DEFAULT 0,
  failed integer NOT NULL DEFAULT 0,
  error text,
  started_by uuid,
  started_at timestamptz NOT NULL DEFAULT now(),
  finished_at timestamptz
);

CREATE INDEX IF NOT EXISTS i18n_translation_jobs_started_idx ON public.i18n_translation_jobs(started_at DESC);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.i18n_translation_jobs TO authenticated;
GRANT ALL ON public.i18n_translation_jobs TO service_role;
ALTER TABLE public.i18n_translation_jobs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "i18n_translation_jobs_read" ON public.i18n_translation_jobs
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "i18n_translation_jobs_admin_write" ON public.i18n_translation_jobs
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'tenant_admin'))
  WITH CHECK (public.has_role(auth.uid(), 'tenant_admin'));

CREATE TRIGGER trg_i18n_source_strings_updated
  BEFORE UPDATE ON public.i18n_source_strings
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

ALTER TABLE public.i18n_translations DROP CONSTRAINT IF EXISTS i18n_translations_lang_check;
ALTER TABLE public.i18n_translations
  ADD CONSTRAINT i18n_translations_lang_check
  CHECK (lang IN ('en','hu','ro','sr','zh','fil','de','uk','ru','sk'));