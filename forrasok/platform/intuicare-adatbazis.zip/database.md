# Adatbázis mező-referencia (generált)

Táblák: **230** · Enum típusok: **65**

## `admin_audit_log`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `action` | `string` | igen |
| `after_data` | `Json \| null` | nem |
| `before_data` | `Json \| null` | nem |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `reason` | `string \| null` | nem |
| `record_id` | `string \| null` | nem |
| `summary` | `string \| null` | nem |
| `table_name` | `string` | igen |
| `tenant_id` | `string \| null` | nem |
| `user_id` | `string \| null` | nem |

## `ai_assistant_actions`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `conversation_id` | `string` | igen |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `kind` | `string` | igen |
| `payload` | `Json \| null` | nem |
| `result` | `Json \| null` | nem |
| `user_id` | `string` | igen |

## `ai_setting_suggestions`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `accepted` | `boolean` | igen |
| `accepted_at` | `string \| null` | nem |
| `created_at` | `string` | igen |
| `created_by` | `string \| null` | nem |
| `goal` | `string \| null` | nem |
| `id` | `string` | igen |
| `model` | `string \| null` | nem |
| `rationale` | `string \| null` | nem |
| `suggested_value` | `Json` | igen |
| `target_key` | `string \| null` | nem |
| `target_kind` | `string` | igen |
| `target_namespace` | `string \| null` | nem |

## `announcement_reads`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `announcement_id` | `string` | igen |
| `read_at` | `string` | igen |
| `user_id` | `string` | igen |

## `announcements`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `cel_org_unit_ids` | `string[]` | igen |
| `cel_szerepkorok` | `string[]` | igen |
| `cim` | `string` | igen |
| `created_at` | `string` | igen |
| `created_by` | `string \| null` | nem |
| `id` | `string` | igen |
| `kategoria` | `string` | igen |
| `kep_url` | `string \| null` | nem |
| `link` | `string \| null` | nem |
| `prioritas` | `string` | igen |
| `publikalt` | `boolean` | igen |
| `publikalva_ig` | `string \| null` | nem |
| `publikalva_tol` | `string` | igen |
| `rogzitett` | `boolean` | igen |
| `tartalom` | `string` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |

## `app_settings`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `draft_value` | `Json \| null` | nem |
| `id` | `string` | igen |
| `is_public` | `boolean` | igen |
| `key` | `string` | igen |
| `namespace` | `string` | igen |
| `schema_version` | `number` | igen |
| `updated_at` | `string` | igen |
| `updated_by` | `string \| null` | nem |
| `value` | `Json` | igen |

## `app_settings_audit`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `action` | `string` | igen |
| `changed_at` | `string` | igen |
| `changed_by` | `string \| null` | nem |
| `id` | `string` | igen |
| `key` | `string` | igen |
| `namespace` | `string` | igen |
| `new_value` | `Json \| null` | nem |
| `old_value` | `Json \| null` | nem |
| `reason` | `string \| null` | nem |
| `setting_id` | `string \| null` | nem |

## `appointment_resources`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `aktiv` | `boolean` | igen |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `leiras` | `string \| null` | nem |
| `nev` | `string` | igen |
| `org_unit_id` | `string \| null` | nem |
| `orvos_id` | `string \| null` | nem |
| `publikus` | `boolean` | igen |
| `szakma_id` | `string \| null` | nem |
| `szin` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `tipus` | `Database["public"]["Enums"]["appt_resource_tipus"]` | igen |
| `updated_at` | `string` | igen |

## `appointment_slots`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `foglalt_szam` | `number` | igen |
| `id` | `string` | igen |
| `kapacitas` | `number` | igen |
| `kezdo_ts` | `string` | igen |
| `org_unit_id` | `string \| null` | nem |
| `resource_id` | `string` | igen |
| `status` | `Database["public"]["Enums"]["appt_slot_status"]` | igen |
| `template_id` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |
| `veg_ts` | `string` | igen |
| `version` | `number` | igen |

## `appointment_status_events`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `actor_id` | `string \| null` | nem |
| `appointment_id` | `string` | igen |
| `created_at` | `string` | igen |
| `from_status` | `Database["public"]["Enums"]["appt_status"] \| null` | nem |
| `id` | `string` | igen |
| `metadata` | `Json` | igen |
| `reason` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `to_status` | `Database["public"]["Enums"]["appt_status"]` | igen |

## `appointment_templates`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `aktiv` | `boolean` | igen |
| `created_at` | `string` | igen |
| `ervenyes_ig` | `string \| null` | nem |
| `ervenyes_tol` | `string` | igen |
| `id` | `string` | igen |
| `kapacitas` | `number` | igen |
| `kezd_ido` | `string` | igen |
| `napok` | `number[]` | igen |
| `nev` | `string` | igen |
| `resource_id` | `string` | igen |
| `slot_perc` | `number` | igen |
| `tenant_id` | `string` | igen |
| `unnepnap_uzemel` | `boolean` | igen |
| `updated_at` | `string` | igen |
| `veg_ido` | `string` | igen |

## `appointments`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `created_by` | `string \| null` | nem |
| `eeszt_idopont_id` | `string \| null` | nem |
| `email_megerositve_at` | `string \| null` | nem |
| `external_ref` | `string \| null` | nem |
| `foglalas_kod` | `string` | igen |
| `gdpr_consent_at` | `string \| null` | nem |
| `id` | `string` | igen |
| `idempotency_key` | `string` | igen |
| `megjegyzes` | `string \| null` | nem |
| `ok` | `string \| null` | nem |
| `patient_id` | `string \| null` | nem |
| `resource_id` | `string` | igen |
| `slot_id` | `string` | igen |
| `status` | `Database["public"]["Enums"]["appt_status"]` | igen |
| `sync_statusz` | `Database["public"]["Enums"]["appt_sync_statusz"]` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |
| `vendeg_email` | `string \| null` | nem |
| `vendeg_nev` | `string \| null` | nem |
| `vendeg_szuletesi_datum` | `string \| null` | nem |
| `vendeg_telefon` | `string \| null` | nem |
| `version` | `number` | igen |

## `assignment_reminder_log`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `assignment_id` | `string` | igen |
| `bucket_days` | `number` | igen |
| `channel` | `Database["public"]["Enums"]["reminder_channel"]` | igen |
| `id` | `string` | igen |
| `notes` | `string \| null` | nem |
| `sent_at` | `string` | igen |
| `tenant_id` | `string` | igen |

## `attendance_anchors`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `ervenyes` | `boolean` | igen |
| `geo_lat` | `number \| null` | nem |
| `geo_lng` | `number \| null` | nem |
| `geo_sugar_m` | `number \| null` | nem |
| `id` | `string` | igen |
| `ip_cidr` | `string \| null` | nem |
| `nev` | `string` | igen |
| `nfc_uid` | `string \| null` | nem |
| `org_unit_id` | `string \| null` | nem |
| `qr_secret` | `string \| null` | nem |
| `site_id` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `tipus` | `string` | igen |
| `updated_at` | `string` | igen |

## `attendance_events`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `anchor_id` | `string \| null` | nem |
| `created_at` | `string` | igen |
| `esemeny_tipus` | `Database["public"]["Enums"]["attendance_event_type"]` | igen |
| `eszkoz_azonosito` | `string \| null` | nem |
| `geo_lat` | `number \| null` | nem |
| `geo_lng` | `number \| null` | nem |
| `geo_pontossag_m` | `number \| null` | nem |
| `horgony_egyezes` | `boolean \| null` | nem |
| `id` | `string` | igen |
| `idopont` | `string` | igen |
| `ip_cim` | `unknown` | igen |
| `korrigalo_id` | `string \| null` | nem |
| `megjegyzes` | `string \| null` | nem |
| `modszer` | `Database["public"]["Enums"]["attendance_method"]` | igen |
| `tenant_id` | `string` | igen |
| `user_agent` | `string \| null` | nem |
| `user_id` | `string` | igen |

## `beavatkozas_skill`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `beavatkozas_id` | `string` | igen |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `min_szint` | `number` | igen |
| `skill_id` | `string` | igen |

## `beavatkozasok`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `aktiv` | `boolean` | igen |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `kod` | `string \| null` | nem |
| `leiras` | `string \| null` | nem |
| `nev` | `string` | igen |
| `specialty_id` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |

## `case_resource_requirements`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `eroforras_tipus` | `Database["public"]["Enums"]["or_eroforras_tipus_enum"]` | igen |
| `foglalas_statusz` | `Database["public"]["Enums"]["or_resource_req_status_enum"]` | igen |
| `id` | `string` | igen |
| `mennyiseg` | `number` | igen |
| `mikortol` | `Database["public"]["Enums"]["or_resource_req_when_enum"]` | igen |
| `surgery_case_id` | `string` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |

## `chat_messages`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `content` | `string` | igen |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `parts` | `Json \| null` | nem |
| `role` | `string` | igen |
| `user_id` | `string` | igen |

## `clinical_alert_escalation_rules`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `active` | `boolean` | igen |
| `created_at` | `string` | igen |
| `created_by` | `string \| null` | nem |
| `escalate_after_minutes` | `number` | igen |
| `id` | `string` | igen |
| `name` | `string` | igen |
| `severity` | `string \| null` | nem |
| `source` | `string \| null` | nem |
| `target_role` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |

## `clinical_alert_status_log`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `actor_id` | `string \| null` | nem |
| `alert_id` | `string` | igen |
| `created_at` | `string` | igen |
| `from_status` | `string \| null` | nem |
| `id` | `string` | igen |
| `note` | `string \| null` | nem |
| `to_status` | `string` | igen |

## `clinical_calculator_results`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `calculator` | `string` | igen |
| `created_at` | `string` | igen |
| `created_by` | `string` | igen |
| `encounter_id` | `string \| null` | nem |
| `id` | `string` | igen |
| `inputs_json` | `Json` | igen |
| `interpretation_md` | `string \| null` | nem |
| `outputs_json` | `Json` | igen |
| `patient_id` | `string \| null` | nem |
| `updated_at` | `string` | igen |

## `clinical_critical_alerts`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `acknowledged_at` | `string \| null` | nem |
| `acknowledged_by` | `string \| null` | nem |
| `code` | `string` | igen |
| `created_at` | `string` | igen |
| `created_by` | `string \| null` | nem |
| `encounter_id` | `string \| null` | nem |
| `escalated_at` | `string \| null` | nem |
| `id` | `string` | igen |
| `message` | `string` | igen |
| `patient_id` | `string` | igen |
| `severity` | `string` | igen |
| `source` | `string` | igen |
| `triggered_at` | `string` | igen |
| `value_json` | `Json \| null` | nem |
| `workflow_status` | `string` | igen |

## `clinical_diagnoses`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `certainty` | `string` | igen |
| `created_at` | `string` | igen |
| `created_by` | `string` | igen |
| `display` | `string` | igen |
| `encounter_id` | `string` | igen |
| `icd10_code` | `string \| null` | nem |
| `id` | `string` | igen |
| `is_primary` | `boolean` | igen |
| `note` | `string \| null` | nem |
| `onset_date` | `string \| null` | nem |
| `patient_id` | `string` | igen |
| `snomed_code` | `string \| null` | nem |
| `updated_at` | `string` | igen |

## `clinical_drug_statuses`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `created_by` | `string` | igen |
| `drug_id` | `string` | igen |
| `encounter_id` | `string \| null` | nem |
| `id` | `string` | igen |
| `notes` | `string \| null` | nem |
| `patient_id` | `string` | igen |
| `status` | `string` | igen |
| `updated_at` | `string` | igen |

## `clinical_encounters`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `chief_complaint` | `string \| null` | nem |
| `closed_by` | `string \| null` | nem |
| `created_at` | `string` | igen |
| `created_by` | `string` | igen |
| `encounter_type` | `string` | igen |
| `end_ts` | `string \| null` | nem |
| `id` | `string` | igen |
| `location` | `string \| null` | nem |
| `patient_id` | `string` | igen |
| `start_ts` | `string` | igen |
| `status` | `string` | igen |
| `tenant_id` | `string \| null` | nem |
| `updated_at` | `string` | igen |

## `clinical_insulin_sessions`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `basal` | `number \| null` | nem |
| `basal_prep_id` | `string \| null` | nem |
| `bolus_d` | `number \| null` | nem |
| `bolus_e` | `number \| null` | nem |
| `bolus_prep_id` | `string \| null` | nem |
| `bolus_r` | `number \| null` | nem |
| `bolus_type` | `string \| null` | nem |
| `correction_bolus` | `number \| null` | nem |
| `created_at` | `string` | igen |
| `created_by` | `string` | igen |
| `current_vc` | `number \| null` | nem |
| `diabetes_type` | `string` | igen |
| `encounter_id` | `string \| null` | nem |
| `icr` | `number \| null` | nem |
| `id` | `string` | igen |
| `isf` | `number \| null` | nem |
| `meal_ratio` | `string \| null` | nem |
| `mode` | `string` | igen |
| `modifiers_json` | `Json` | igen |
| `notes` | `string \| null` | nem |
| `patient_id` | `string` | igen |
| `premix_prep_id` | `string \| null` | nem |
| `session_date` | `string` | igen |
| `target_vc` | `number \| null` | nem |
| `tdd` | `number \| null` | nem |
| `updated_at` | `string` | igen |
| `weight_kg` | `number` | igen |

## `clinical_notes`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `ai_generated` | `boolean` | igen |
| `author_id` | `string` | igen |
| `body_md` | `string \| null` | nem |
| `created_at` | `string` | igen |
| `encounter_id` | `string` | igen |
| `id` | `string` | igen |
| `kind` | `string` | igen |
| `parent_note_id` | `string \| null` | nem |
| `patient_id` | `string` | igen |
| `signed_at` | `string \| null` | nem |
| `signed_by` | `string \| null` | nem |
| `structured_json` | `Json \| null` | nem |
| `title` | `string \| null` | nem |
| `updated_at` | `string` | igen |
| `version` | `number` | igen |

## `clinical_observations`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `category` | `string` | igen |
| `code_display` | `string` | igen |
| `created_at` | `string` | igen |
| `effective_ts` | `string` | igen |
| `encounter_id` | `string` | igen |
| `id` | `string` | igen |
| `interpretation` | `string \| null` | nem |
| `loinc_code` | `string \| null` | nem |
| `patient_id` | `string` | igen |
| `performer_id` | `string \| null` | nem |
| `snomed_code` | `string \| null` | nem |
| `source` | `string` | igen |
| `updated_at` | `string` | igen |
| `value_json` | `Json \| null` | nem |
| `value_quantity` | `number \| null` | nem |
| `value_string` | `string \| null` | nem |
| `value_unit` | `string \| null` | nem |

## `clinical_therapy_orders`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `ai_generated` | `boolean` | igen |
| `atc_code` | `string \| null` | nem |
| `created_at` | `string` | igen |
| `created_by` | `string` | igen |
| `display` | `string` | igen |
| `dose` | `string \| null` | nem |
| `duration` | `string \| null` | nem |
| `encounter_id` | `string` | igen |
| `ends_on` | `string \| null` | nem |
| `frequency` | `string \| null` | nem |
| `id` | `string` | igen |
| `instructions` | `string \| null` | nem |
| `kind` | `string` | igen |
| `patient_id` | `string` | igen |
| `route` | `string \| null` | nem |
| `snomed_code` | `string \| null` | nem |
| `starts_on` | `string \| null` | nem |
| `status` | `string` | igen |
| `updated_at` | `string` | igen |

## `clinical_weekly_vc`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `bolus_given` | `number \| null` | nem |
| `created_at` | `string` | igen |
| `created_by` | `string` | igen |
| `encounter_id` | `string \| null` | nem |
| `id` | `string` | igen |
| `measured_at` | `string` | igen |
| `measurement_type` | `string` | igen |
| `notes` | `string \| null` | nem |
| `patient_id` | `string` | igen |
| `value_mmol_l` | `number` | igen |

## `clinics`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `aktiv` | `boolean` | igen |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `nev` | `string` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |

## `cms_audit_log`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `action` | `Database["public"]["Enums"]["cms_audit_action"]` | igen |
| `actor_email` | `string \| null` | nem |
| `actor_id` | `string \| null` | nem |
| `after` | `Json \| null` | nem |
| `before` | `Json \| null` | nem |
| `comment` | `string \| null` | nem |
| `created_at` | `string` | igen |
| `diff` | `Json \| null` | nem |
| `entity_id` | `string \| null` | nem |
| `entity_locale` | `string \| null` | nem |
| `entity_slug` | `string \| null` | nem |
| `entity_type` | `string` | igen |
| `id` | `string` | igen |
| `request_meta` | `Json \| null` | nem |

## `cms_blocks`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `approved_at` | `string \| null` | nem |
| `approved_by` | `string \| null` | nem |
| `block_type` | `string` | igen |
| `content` | `Json` | igen |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `is_published` | `boolean` | igen |
| `locale` | `string` | igen |
| `page_id` | `string` | igen |
| `position` | `number` | igen |
| `rejected_at` | `string \| null` | nem |
| `rejected_by` | `string \| null` | nem |
| `rejection_reason` | `string \| null` | nem |
| `submitted_by` | `string \| null` | nem |
| `submitted_for_review_at` | `string \| null` | nem |
| `updated_at` | `string` | igen |
| `variant` | `string` | igen |
| `workflow_state` | `Database["public"]["Enums"]["cms_workflow_state"]` | igen |

## `cms_design_tokens`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `approved_at` | `string \| null` | nem |
| `approved_by` | `string \| null` | nem |
| `created_at` | `string` | igen |
| `description` | `string \| null` | nem |
| `id` | `string` | igen |
| `rejected_at` | `string \| null` | nem |
| `rejected_by` | `string \| null` | nem |
| `rejection_reason` | `string \| null` | nem |
| `scope` | `string` | igen |
| `submitted_by` | `string \| null` | nem |
| `submitted_for_review_at` | `string \| null` | nem |
| `token_key` | `string` | igen |
| `updated_at` | `string` | igen |
| `updated_by` | `string \| null` | nem |
| `value` | `Json` | igen |
| `workflow_state` | `Database["public"]["Enums"]["cms_workflow_state"]` | igen |

## `cms_experiment_events`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `event_name` | `string \| null` | nem |
| `event_type` | `string` | igen |
| `experiment_id` | `string` | igen |
| `id` | `number` | igen |
| `params` | `Json \| null` | nem |
| `path` | `string \| null` | nem |
| `referrer` | `string \| null` | nem |
| `session_id` | `string \| null` | nem |
| `user_agent` | `string \| null` | nem |
| `variant_id` | `string` | igen |

## `cms_experiment_variants`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `content` | `Json` | igen |
| `created_at` | `string` | igen |
| `experiment_id` | `string` | igen |
| `id` | `string` | igen |
| `is_control` | `boolean` | igen |
| `key` | `string` | igen |
| `name` | `string \| null` | nem |
| `updated_at` | `string` | igen |
| `weight` | `number` | igen |

## `cms_experiments`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `approved_at` | `string \| null` | nem |
| `approved_by` | `string \| null` | nem |
| `block_id` | `string \| null` | nem |
| `conversion_events` | `Json` | igen |
| `created_at` | `string` | igen |
| `description` | `string \| null` | nem |
| `ended_at` | `string \| null` | nem |
| `goal_event` | `string` | igen |
| `id` | `string` | igen |
| `layout_block_id` | `string \| null` | nem |
| `name` | `string` | igen |
| `rejected_at` | `string \| null` | nem |
| `rejected_by` | `string \| null` | nem |
| `rejection_reason` | `string \| null` | nem |
| `started_at` | `string \| null` | nem |
| `status` | `string` | igen |
| `submitted_by` | `string \| null` | nem |
| `submitted_for_review_at` | `string \| null` | nem |
| `traffic_allocation` | `number` | igen |
| `updated_at` | `string` | igen |
| `winner_variant_id` | `string \| null` | nem |
| `workflow_state` | `Database["public"]["Enums"]["cms_workflow_state"]` | igen |

## `cms_faqs`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `answer` | `string` | igen |
| `approved_at` | `string \| null` | nem |
| `approved_by` | `string \| null` | nem |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `is_published` | `boolean \| null` | nem |
| `locale` | `string` | igen |
| `question` | `string` | igen |
| `rejected_at` | `string \| null` | nem |
| `rejected_by` | `string \| null` | nem |
| `rejection_reason` | `string \| null` | nem |
| `sort_order` | `number \| null` | nem |
| `submitted_by` | `string \| null` | nem |
| `submitted_for_review_at` | `string \| null` | nem |
| `tags` | `string[] \| null` | nem |
| `updated_at` | `string` | igen |
| `workflow_state` | `Database["public"]["Enums"]["cms_workflow_state"]` | igen |

## `cms_global_regions`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `approved_at` | `string \| null` | nem |
| `approved_by` | `string \| null` | nem |
| `blocks` | `Json` | igen |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `locale` | `string` | igen |
| `region_key` | `string` | igen |
| `rejected_at` | `string \| null` | nem |
| `rejected_by` | `string \| null` | nem |
| `rejection_reason` | `string \| null` | nem |
| `status` | `string` | igen |
| `submitted_by` | `string \| null` | nem |
| `submitted_for_review_at` | `string \| null` | nem |
| `updated_at` | `string` | igen |
| `updated_by` | `string \| null` | nem |
| `workflow_state` | `Database["public"]["Enums"]["cms_workflow_state"]` | igen |

## `cms_i18n_content`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `data` | `Json` | igen |
| `entity_id` | `string` | igen |
| `entity_type` | `string` | igen |
| `id` | `string` | igen |
| `locale` | `string` | igen |
| `updated_at` | `string` | igen |
| `updated_by` | `string \| null` | nem |

## `cms_layout_blocks`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `approved_at` | `string \| null` | nem |
| `approved_by` | `string \| null` | nem |
| `block_type` | `string` | igen |
| `content` | `Json` | igen |
| `created_at` | `string` | igen |
| `created_by` | `string \| null` | nem |
| `draft_content` | `Json \| null` | nem |
| `draft_note` | `string \| null` | nem |
| `draft_status` | `string` | igen |
| `draft_style` | `Json \| null` | nem |
| `draft_updated_at` | `string \| null` | nem |
| `draft_updated_by` | `string \| null` | nem |
| `end_at` | `string \| null` | nem |
| `id` | `string` | igen |
| `locale` | `string` | igen |
| `page_id` | `string \| null` | nem |
| `position` | `number` | igen |
| `region_key` | `string \| null` | nem |
| `rejected_at` | `string \| null` | nem |
| `rejected_by` | `string \| null` | nem |
| `rejection_reason` | `string \| null` | nem |
| `schedule_at` | `string \| null` | nem |
| `status` | `string` | igen |
| `style` | `Json` | igen |
| `submitted_by` | `string \| null` | nem |
| `submitted_for_review_at` | `string \| null` | nem |
| `updated_at` | `string` | igen |
| `updated_by` | `string \| null` | nem |
| `version` | `number` | igen |
| `visibility` | `Json` | igen |
| `workflow_state` | `Database["public"]["Enums"]["cms_workflow_state"]` | igen |

## `cms_media`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `alt_text` | `string \| null` | nem |
| `approved_at` | `string \| null` | nem |
| `approved_by` | `string \| null` | nem |
| `caption` | `string \| null` | nem |
| `category` | `string \| null` | nem |
| `created_at` | `string` | igen |
| `file_name` | `string` | igen |
| `height` | `number \| null` | nem |
| `id` | `string` | igen |
| `mime_type` | `string` | igen |
| `rejected_at` | `string \| null` | nem |
| `rejected_by` | `string \| null` | nem |
| `rejection_reason` | `string \| null` | nem |
| `size_bytes` | `number` | igen |
| `storage_path` | `string` | igen |
| `submitted_by` | `string \| null` | nem |
| `submitted_for_review_at` | `string \| null` | nem |
| `tags` | `string[] \| null` | nem |
| `uploaded_by` | `string \| null` | nem |
| `width` | `number \| null` | nem |
| `workflow_state` | `Database["public"]["Enums"]["cms_workflow_state"]` | igen |

## `cms_menu_items`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `approved_at` | `string \| null` | nem |
| `approved_by` | `string \| null` | nem |
| `created_at` | `string` | igen |
| `icon` | `string \| null` | nem |
| `id` | `string` | igen |
| `label` | `string` | igen |
| `locale` | `string` | igen |
| `menu_id` | `string` | igen |
| `open_in_new_tab` | `boolean` | igen |
| `page_id` | `string \| null` | nem |
| `parent_id` | `string \| null` | nem |
| `position` | `number` | igen |
| `rejected_at` | `string \| null` | nem |
| `rejected_by` | `string \| null` | nem |
| `rejection_reason` | `string \| null` | nem |
| `submitted_by` | `string \| null` | nem |
| `submitted_for_review_at` | `string \| null` | nem |
| `updated_at` | `string` | igen |
| `url` | `string \| null` | nem |
| `workflow_state` | `Database["public"]["Enums"]["cms_workflow_state"]` | igen |

## `cms_menus`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `approved_at` | `string \| null` | nem |
| `approved_by` | `string \| null` | nem |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `key` | `string` | igen |
| `location` | `string` | igen |
| `name` | `string` | igen |
| `rejected_at` | `string \| null` | nem |
| `rejected_by` | `string \| null` | nem |
| `rejection_reason` | `string \| null` | nem |
| `submitted_by` | `string \| null` | nem |
| `submitted_for_review_at` | `string \| null` | nem |
| `updated_at` | `string` | igen |
| `workflow_state` | `Database["public"]["Enums"]["cms_workflow_state"]` | igen |

## `cms_news_authors`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `avatar_url` | `string \| null` | nem |
| `bio` | `string \| null` | nem |
| `created_at` | `string` | igen |
| `display_name` | `string` | igen |
| `email` | `string \| null` | nem |
| `id` | `string` | igen |
| `is_guest` | `boolean` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string \| null` | nem |

## `cms_news_categories`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `description` | `string \| null` | nem |
| `id` | `string` | igen |
| `is_active` | `boolean` | igen |
| `name` | `string` | igen |
| `parent_id` | `string \| null` | nem |
| `slug` | `string` | igen |
| `sort_order` | `number` | igen |
| `updated_at` | `string` | igen |

## `cms_news_post_tags`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `post_id` | `string` | igen |
| `tag_id` | `string` | igen |

## `cms_news_posts`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `approved_at` | `string \| null` | nem |
| `approved_by` | `string \| null` | nem |
| `author_id` | `string \| null` | nem |
| `body` | `Json` | igen |
| `category_id` | `string \| null` | nem |
| `cms_page_id` | `string \| null` | nem |
| `created_at` | `string` | igen |
| `created_by` | `string \| null` | nem |
| `excerpt` | `string \| null` | nem |
| `featured_image_alt` | `string \| null` | nem |
| `featured_image_url` | `string \| null` | nem |
| `id` | `string` | igen |
| `locale` | `string` | igen |
| `og_image_url` | `string \| null` | nem |
| `post_type` | `string` | igen |
| `preview_token` | `string` | igen |
| `published_at` | `string \| null` | nem |
| `rejected_at` | `string \| null` | nem |
| `rejected_by` | `string \| null` | nem |
| `rejection_reason` | `string \| null` | nem |
| `seo_description` | `string \| null` | nem |
| `seo_title` | `string \| null` | nem |
| `slug` | `string` | igen |
| `status` | `string` | igen |
| `submitted_by` | `string \| null` | nem |
| `submitted_for_review_at` | `string \| null` | nem |
| `title` | `string` | igen |
| `updated_at` | `string` | igen |
| `updated_by` | `string \| null` | nem |
| `video_duration_seconds` | `number \| null` | nem |
| `video_embed_url` | `string \| null` | nem |
| `video_height` | `number \| null` | nem |
| `video_provider` | `string \| null` | nem |
| `video_thumbnail_url` | `string \| null` | nem |
| `video_transcript` | `string \| null` | nem |
| `video_url` | `string \| null` | nem |
| `video_width` | `number \| null` | nem |
| `view_count` | `number` | igen |
| `workflow_state` | `Database["public"]["Enums"]["cms_workflow_state"]` | igen |

## `cms_news_tags`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `name` | `string` | igen |
| `slug` | `string` | igen |

## `cms_newsletter_subscribers`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `confirmed_at` | `string \| null` | nem |
| `created_at` | `string` | igen |
| `email` | `string` | igen |
| `id` | `string` | igen |
| `source` | `string \| null` | nem |
| `unsubscribe_token` | `string` | igen |
| `unsubscribed_at` | `string \| null` | nem |

## `cms_newsletters`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `audience` | `string` | igen |
| `body_html` | `string` | igen |
| `created_at` | `string` | igen |
| `created_by` | `string \| null` | nem |
| `id` | `string` | igen |
| `sent_at` | `string \| null` | nem |
| `sent_count` | `number` | igen |
| `status` | `string` | igen |
| `subject` | `string` | igen |
| `updated_at` | `string` | igen |

## `cms_page_versions`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `created_by` | `string \| null` | nem |
| `id` | `string` | igen |
| `is_autosave` | `boolean` | igen |
| `is_published` | `boolean` | igen |
| `page_id` | `string` | igen |
| `snapshot` | `Json` | igen |
| `version` | `number` | igen |

## `cms_page_views`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `day` | `string` | igen |
| `id` | `string` | igen |
| `page_id` | `string` | igen |
| `views` | `number` | igen |

## `cms_pages`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `approved_at` | `string \| null` | nem |
| `approved_by` | `string \| null` | nem |
| `created_at` | `string` | igen |
| `created_by` | `string \| null` | nem |
| `description` | `string \| null` | nem |
| `id` | `string` | igen |
| `is_home` | `boolean` | igen |
| `is_system` | `boolean` | igen |
| `last_viewed_at` | `string \| null` | nem |
| `layout` | `string` | igen |
| `locale` | `string` | igen |
| `nav_label` | `string \| null` | nem |
| `noindex` | `boolean` | igen |
| `og_image_url` | `string \| null` | nem |
| `parent_id` | `string \| null` | nem |
| `preview_token` | `string` | igen |
| `published_at` | `string \| null` | nem |
| `rejected_at` | `string \| null` | nem |
| `rejected_by` | `string \| null` | nem |
| `rejection_reason` | `string \| null` | nem |
| `scheduled_publish_at` | `string \| null` | nem |
| `schema_type` | `string` | igen |
| `seo_description` | `string \| null` | nem |
| `seo_title` | `string \| null` | nem |
| `show_in_sitemap` | `boolean` | igen |
| `slug` | `string` | igen |
| `sort_order` | `number` | igen |
| `status` | `string` | igen |
| `submitted_by` | `string \| null` | nem |
| `submitted_for_review_at` | `string \| null` | nem |
| `template` | `string` | igen |
| `title` | `string` | igen |
| `updated_at` | `string` | igen |
| `updated_by` | `string \| null` | nem |
| `view_count` | `number` | igen |
| `workflow_state` | `Database["public"]["Enums"]["cms_workflow_state"]` | igen |

## `cms_redirects`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `approved_at` | `string \| null` | nem |
| `approved_by` | `string \| null` | nem |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `is_active` | `boolean` | igen |
| `note` | `string \| null` | nem |
| `rejected_at` | `string \| null` | nem |
| `rejected_by` | `string \| null` | nem |
| `rejection_reason` | `string \| null` | nem |
| `source_path` | `string` | igen |
| `status_code` | `number` | igen |
| `submitted_by` | `string \| null` | nem |
| `submitted_for_review_at` | `string \| null` | nem |
| `target_path` | `string` | igen |
| `updated_at` | `string` | igen |
| `workflow_state` | `Database["public"]["Enums"]["cms_workflow_state"]` | igen |

## `cms_site_settings`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `approved_at` | `string \| null` | nem |
| `approved_by` | `string \| null` | nem |
| `default_locale` | `string` | igen |
| `default_og_image_url` | `string \| null` | nem |
| `id` | `number` | igen |
| `organization_jsonld` | `Json \| null` | nem |
| `rejected_at` | `string \| null` | nem |
| `rejected_by` | `string \| null` | nem |
| `rejection_reason` | `string \| null` | nem |
| `robots_txt` | `string \| null` | nem |
| `sos_active` | `boolean` | igen |
| `sos_message` | `string \| null` | nem |
| `submitted_by` | `string \| null` | nem |
| `submitted_for_review_at` | `string \| null` | nem |
| `updated_at` | `string` | igen |
| `updated_by` | `string \| null` | nem |
| `workflow_state` | `Database["public"]["Enums"]["cms_workflow_state"]` | igen |

## `cms_staff_profiles`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `approved_at` | `string \| null` | nem |
| `approved_by` | `string \| null` | nem |
| `bio` | `string \| null` | nem |
| `created_at` | `string` | igen |
| `display_name` | `string` | igen |
| `id` | `string` | igen |
| `is_published` | `boolean \| null` | nem |
| `languages` | `string[] \| null` | nem |
| `locale` | `string` | igen |
| `photo_url` | `string \| null` | nem |
| `profile_id` | `string` | igen |
| `public_fields` | `Json` | igen |
| `public_visibility` | `string` | igen |
| `publications` | `Json \| null` | nem |
| `publish_schedule` | `boolean \| null` | nem |
| `rejected_at` | `string \| null` | nem |
| `rejected_by` | `string \| null` | nem |
| `rejection_reason` | `string \| null` | nem |
| `seo_description` | `string \| null` | nem |
| `seo_title` | `string \| null` | nem |
| `slug` | `string` | igen |
| `sort_order` | `number \| null` | nem |
| `specialties` | `string[] \| null` | nem |
| `submitted_by` | `string \| null` | nem |
| `submitted_for_review_at` | `string \| null` | nem |
| `title` | `string \| null` | nem |
| `updated_at` | `string` | igen |
| `workflow_state` | `Database["public"]["Enums"]["cms_workflow_state"]` | igen |

## `cms_tip_audience_map`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `audience_id` | `string` | igen |
| `tip_id` | `string` | igen |

## `cms_tip_audiences`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `description_i18n` | `Json` | igen |
| `id` | `string` | igen |
| `name_i18n` | `Json` | igen |
| `slug` | `string` | igen |
| `sort_order` | `number` | igen |
| `updated_at` | `string` | igen |

## `cms_tip_categories`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `color` | `string \| null` | nem |
| `created_at` | `string` | igen |
| `description_i18n` | `Json` | igen |
| `icon` | `string \| null` | nem |
| `id` | `string` | igen |
| `name_i18n` | `Json` | igen |
| `slug` | `string` | igen |
| `sort_order` | `number` | igen |
| `updated_at` | `string` | igen |

## `cms_tip_comments`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `body` | `string` | igen |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `parent_id` | `string \| null` | nem |
| `status` | `string` | igen |
| `tip_id` | `string` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |

## `cms_tip_likes`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `tip_id` | `string` | igen |
| `user_id` | `string` | igen |

## `cms_tip_subscribers`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `audiences` | `string[] \| null` | nem |
| `created_at` | `string` | igen |
| `email_enabled` | `boolean` | igen |
| `push_enabled` | `boolean` | igen |
| `user_id` | `string` | igen |

## `cms_tip_tag_map`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `tag_id` | `string` | igen |
| `tip_id` | `string` | igen |

## `cms_tip_tags`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `name_i18n` | `Json` | igen |
| `slug` | `string` | igen |
| `updated_at` | `string` | igen |

## `cms_tip_translations`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `ai_generated` | `boolean` | igen |
| `ai_source_lang` | `string \| null` | nem |
| `body_html` | `string \| null` | nem |
| `body_json` | `Json` | igen |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `lead` | `string \| null` | nem |
| `locale` | `string` | igen |
| `og_image` | `string \| null` | nem |
| `seo_description` | `string \| null` | nem |
| `seo_title` | `string \| null` | nem |
| `tip_id` | `string` | igen |
| `title` | `string` | igen |
| `translation_status` | `string` | igen |
| `updated_at` | `string` | igen |

## `cms_tip_versions`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `created_by` | `string \| null` | nem |
| `id` | `string` | igen |
| `note` | `string \| null` | nem |
| `snapshot` | `Json` | igen |
| `tip_id` | `string` | igen |
| `version` | `number` | igen |

## `cms_tip_views`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `id` | `string` | igen |
| `locale` | `string \| null` | nem |
| `session_hash` | `string \| null` | nem |
| `tip_id` | `string` | igen |
| `user_id` | `string \| null` | nem |
| `viewed_at` | `string` | igen |

## `cms_tips`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `author_id` | `string \| null` | nem |
| `category_id` | `string \| null` | nem |
| `cover_url` | `string \| null` | nem |
| `created_at` | `string` | igen |
| `featured` | `boolean` | igen |
| `id` | `string` | igen |
| `published_at` | `string \| null` | nem |
| `reading_minutes` | `number \| null` | nem |
| `slug` | `string` | igen |
| `status` | `string` | igen |
| `updated_at` | `string` | igen |

## `competency_domains`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `ervenyes` | `boolean` | igen |
| `id` | `string` | igen |
| `kulcs` | `string` | igen |
| `leiras` | `string \| null` | nem |
| `nev` | `string` | igen |
| `specialty_id` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |

## `competency_levels`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `felugyeleti_kuszob` | `boolean` | igen |
| `id` | `string` | igen |
| `kulcs` | `string` | igen |
| `leiras` | `string \| null` | nem |
| `nev` | `string` | igen |
| `sorrend` | `number` | igen |
| `tenant_id` | `string \| null` | nem |
| `updated_at` | `string` | igen |

## `contact_messages`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `body` | `string` | igen |
| `created_at` | `string` | igen |
| `handled_at` | `string \| null` | nem |
| `handled_by` | `string \| null` | nem |
| `id` | `string` | igen |
| `ip_hash` | `string \| null` | nem |
| `locale` | `string \| null` | nem |
| `org_unit_id` | `string \| null` | nem |
| `sender_email` | `string` | igen |
| `sender_name` | `string` | igen |
| `sender_phone` | `string \| null` | nem |
| `source_page_slug` | `string \| null` | nem |
| `status` | `string` | igen |
| `subject` | `string \| null` | nem |
| `updated_at` | `string` | igen |

## `contractions`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `gyakorisag_perc` | `number \| null` | nem |
| `id` | `string` | igen |
| `idotartam_mp` | `number \| null` | nem |
| `kezdes` | `string` | igen |
| `patient_id` | `string` | igen |
| `program_id` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `veg` | `string \| null` | nem |

## `conversation_participants`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `auto_translate` | `boolean` | igen |
| `conversation_id` | `string` | igen |
| `id` | `string` | igen |
| `joined_at` | `string` | igen |
| `last_read_at` | `string \| null` | nem |
| `muted` | `boolean` | igen |
| `patient_id` | `string \| null` | nem |
| `role` | `string` | igen |
| `user_id` | `string \| null` | nem |

## `conversations`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `created_by` | `string` | igen |
| `id` | `string` | igen |
| `kind` | `Database["public"]["Enums"]["conversation_kind"]` | igen |
| `last_message_at` | `string` | igen |
| `patient_id` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `title` | `string \| null` | nem |
| `updated_at` | `string` | igen |

## `critical_result_alerts`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `acknowledged_at` | `string \| null` | nem |
| `acknowledged_by` | `string \| null` | nem |
| `alert_type` | `string` | igen |
| `appointment_id` | `string \| null` | nem |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `patient_id` | `string \| null` | nem |
| `resolution_note` | `string \| null` | nem |
| `response_id` | `string` | igen |
| `severity` | `string` | igen |
| `status` | `Database["public"]["Enums"]["critical_alert_status"]` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |

## `dashboard_widget_prefs`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `config` | `Json` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |

## `duty_availability`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `duty_line_id` | `string \| null` | nem |
| `ervenyes_ig` | `string \| null` | nem |
| `ervenyes_tol` | `string` | igen |
| `id` | `string` | igen |
| `kezd_ido` | `string \| null` | nem |
| `megjegyzes` | `string \| null` | nem |
| `napok` | `string[]` | igen |
| `site_id` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `tipus` | `Database["public"]["Enums"]["duty_availability_tipus"]` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |
| `veg_ido` | `string \| null` | nem |
| `visszavonva_at` | `string \| null` | nem |

## `duty_line_coverage`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `duty_line_id` | `string` | igen |
| `kotelezo` | `boolean` | igen |
| `megjegyzes` | `string \| null` | nem |
| `org_unit_id` | `string` | igen |
| `tenant_id` | `string` | igen |

## `duty_line_eligibility`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `duty_line_id` | `string` | igen |
| `id` | `string` | igen |
| `prioritas` | `number` | igen |
| `staff_role_id` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `user_id` | `string \| null` | nem |

## `duty_lines`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `aktiv` | `boolean` | igen |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `kezd_ido` | `string \| null` | nem |
| `kod` | `string \| null` | nem |
| `letszam` | `number` | igen |
| `megjegyzes` | `string \| null` | nem |
| `napok` | `number[]` | igen |
| `nev` | `string` | igen |
| `primary_org_unit_id` | `string \| null` | nem |
| `site_id` | `string` | igen |
| `sorrend` | `number` | igen |
| `szerep_tipus` | `Database["public"]["Enums"]["duty_szerep_tipus"]` | igen |
| `tenant_id` | `string` | igen |
| `unnepnap_uzemel` | `boolean` | igen |
| `updated_at` | `string` | igen |
| `veg_ido` | `string \| null` | nem |

## `eeszt_patient_links`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `eeszt_org_oid` | `string \| null` | nem |
| `eeszt_page_id` | `string \| null` | nem |
| `hozzajarulas_at` | `string \| null` | nem |
| `hozzajarulas_status` | `string` | igen |
| `id` | `string` | igen |
| `megjegyzes` | `string \| null` | nem |
| `patient_id` | `string` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |
| `utolso_szinkron_at` | `string \| null` | nem |

## `email_digest_settings`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `day_of_week` | `number` | igen |
| `enabled` | `boolean` | igen |
| `hour_local` | `number` | igen |
| `include_sections` | `Json` | igen |
| `last_sent_at` | `string \| null` | nem |
| `recipient_roles` | `string[]` | igen |
| `tenant_id` | `string` | igen |
| `timezone` | `string` | igen |
| `updated_at` | `string` | igen |
| `updated_by` | `string \| null` | nem |

## `error_log`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `ai_suggested_at` | `string \| null` | nem |
| `ai_suggestion` | `string \| null` | nem |
| `code` | `string` | igen |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `kind` | `string` | igen |
| `message` | `string \| null` | nem |
| `query_params` | `Json \| null` | nem |
| `route` | `string \| null` | nem |
| `technical` | `string \| null` | nem |
| `title` | `string \| null` | nem |
| `user_agent` | `string \| null` | nem |
| `user_id` | `string \| null` | nem |

## `feature_flags`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `enabled` | `boolean` | igen |
| `id` | `string` | igen |
| `kulcs` | `string` | igen |
| `metadata` | `Json` | igen |
| `tenant_id` | `string \| null` | nem |
| `updated_at` | `string` | igen |

## `feladat_korok`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `aktiv` | `boolean` | igen |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `kulcs` | `string` | igen |
| `leiras` | `string \| null` | nem |
| `nev` | `string` | igen |
| `rendszerszintu` | `boolean` | igen |
| `sorrend` | `number` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |

## `fetal_movements`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `datum` | `string` | igen |
| `eltelt_perc` | `number \| null` | nem |
| `id` | `string` | igen |
| `jegyzet` | `string \| null` | nem |
| `mozgas_szam` | `number` | igen |
| `patient_id` | `string` | igen |
| `program_id` | `string \| null` | nem |
| `szakasz_kezdes` | `string` | igen |
| `tenant_id` | `string` | igen |
| `tizedik_mozgas_ido` | `string \| null` | nem |

## `floors`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `aktiv` | `boolean` | igen |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `megnevezes` | `string \| null` | nem |
| `site_id` | `string` | igen |
| `sorrend` | `number` | igen |
| `szint` | `string` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |

## `followup_enrollments`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `anchor_at` | `string` | igen |
| `anchor_ref` | `Json` | igen |
| `created_at` | `string` | igen |
| `created_by` | `string \| null` | nem |
| `id` | `string` | igen |
| `patient_id` | `string` | igen |
| `paused_reason` | `string \| null` | nem |
| `protocol_id` | `string` | igen |
| `status` | `Database["public"]["Enums"]["followup_enrollment_status"]` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |

## `followup_occurrences`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `assignment_id` | `string \| null` | nem |
| `created_at` | `string` | igen |
| `due_at` | `string` | igen |
| `enrollment_id` | `string` | igen |
| `id` | `string` | igen |
| `occurrence_index` | `number` | igen |
| `responded_at` | `string \| null` | nem |
| `status` | `Database["public"]["Enums"]["followup_occurrence_status"]` | igen |
| `step_id` | `string` | igen |
| `updated_at` | `string` | igen |

## `followup_protocol_steps`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `cadence_days` | `number` | igen |
| `channel` | `Database["public"]["Enums"]["reminder_channel"]` | igen |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `offset_days_from` | `number` | igen |
| `offset_days_to` | `number` | igen |
| `phase_label` | `string` | igen |
| `phase_order` | `number` | igen |
| `protocol_id` | `string` | igen |
| `questionnaire_id` | `string` | igen |
| `reminder_buckets` | `number[]` | igen |
| `updated_at` | `string` | igen |

## `followup_protocols`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `aktiv` | `boolean` | igen |
| `anchor_event` | `Database["public"]["Enums"]["followup_anchor_event"]` | igen |
| `created_at` | `string` | igen |
| `created_by` | `string \| null` | nem |
| `default_window_days` | `number` | igen |
| `id` | `string` | igen |
| `kod` | `string` | igen |
| `leiras` | `string \| null` | nem |
| `nev` | `string` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |

## `food_log`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `ai_becsult_kcal` | `number \| null` | nem |
| `ai_makro` | `Json \| null` | nem |
| `created_at` | `string` | igen |
| `etkezes_tipus` | `string \| null` | nem |
| `foto_url` | `string \| null` | nem |
| `id` | `string` | igen |
| `leiras` | `string \| null` | nem |
| `megbizhatosag` | `string` | igen |
| `patient_id` | `string` | igen |
| `program_id` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `ts` | `string` | igen |

## `gdpr_consents`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `cel` | `Database["public"]["Enums"]["consent_purpose"]` | igen |
| `created_at` | `string` | igen |
| `dokumentum_verzio` | `string` | igen |
| `elfogadva_at` | `string` | igen |
| `forras_ip` | `unknown` | igen |
| `forras_user_agent` | `string \| null` | nem |
| `id` | `string` | igen |
| `szoveg_hivatkozas` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |
| `visszavonva_at` | `string \| null` | nem |

## `i18n_missing_keys`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `hits` | `number` | igen |
| `id` | `string` | igen |
| `key` | `string` | igen |
| `kind` | `string` | igen |
| `lang` | `string` | igen |
| `last_seen_at` | `string` | igen |
| `namespace` | `string` | igen |
| `source_text` | `string` | igen |

## `i18n_source_strings`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `ai_described` | `boolean` | igen |
| `created_at` | `string` | igen |
| `description` | `string \| null` | nem |
| `element_type` | `string` | igen |
| `id` | `string` | igen |
| `is_active` | `boolean` | igen |
| `key` | `string` | igen |
| `max_length` | `number \| null` | nem |
| `namespace` | `string` | igen |
| `screen` | `string \| null` | nem |
| `source_text` | `string` | igen |
| `translator_note` | `string \| null` | nem |
| `updated_at` | `string` | igen |

## `i18n_translation_jobs`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `error` | `string \| null` | nem |
| `failed` | `number` | igen |
| `finished_at` | `string \| null` | nem |
| `id` | `string` | igen |
| `langs` | `string[]` | igen |
| `mode` | `string` | igen |
| `namespace` | `string \| null` | nem |
| `started_at` | `string` | igen |
| `started_by` | `string \| null` | nem |
| `status` | `string` | igen |
| `total` | `number` | igen |
| `translated` | `number` | igen |

## `i18n_translations`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `content_ref` | `string \| null` | nem |
| `created_at` | `string` | igen |
| `edited_by_user` | `boolean` | igen |
| `id` | `string` | igen |
| `key` | `string` | igen |
| `kind` | `string` | igen |
| `lang` | `string` | igen |
| `namespace` | `string` | igen |
| `source_hash` | `string` | igen |
| `source_text` | `string` | igen |
| `tenant_id` | `string \| null` | nem |
| `updated_at` | `string` | igen |
| `value` | `string` | igen |

## `illetmeny_snapshots`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `bemenet` | `Json` | igen |
| `cimke` | `string` | igen |
| `created_at` | `string` | igen |
| `created_by` | `string \| null` | nem |
| `eredmeny` | `Json` | igen |
| `id` | `string` | igen |
| `jogi_hivatkozasok` | `Json` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |
| `vegosszeg_ft` | `number` | igen |
| `vonatkozasi_datum` | `string` | igen |

## `incompatibilities`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `bejelentes_datum` | `string` | igen |
| `created_at` | `string` | igen |
| `dokumentum_url` | `string \| null` | nem |
| `dontes_datum` | `string \| null` | nem |
| `ervenyes_ig` | `string \| null` | nem |
| `ervenyes_tol` | `string` | igen |
| `heti_oraszam` | `number \| null` | nem |
| `id` | `string` | igen |
| `megjegyzes` | `string \| null` | nem |
| `munkakor` | `string \| null` | nem |
| `munkaltato_nev` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `tipus` | `string` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |
| `vezeto_id` | `string \| null` | nem |
| `vezetoi_dontes` | `string \| null` | nem |

## `juttatasok`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `dokumentum_url` | `string \| null` | nem |
| `havi_osszeg_ft` | `number` | igen |
| `id` | `string` | igen |
| `kezdo_datum` | `string` | igen |
| `megjegyzes` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `tipus` | `string` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |
| `zaro_datum` | `string \| null` | nem |

## `kirendelesek`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `alairt_dokumentum_url` | `string \| null` | nem |
| `cel_egeszsegugyi_szolgaltato` | `string` | igen |
| `created_at` | `string` | igen |
| `hozzajarult` | `boolean` | igen |
| `id` | `string` | igen |
| `indok` | `string \| null` | nem |
| `kezdo_datum` | `string` | igen |
| `napi_dij_ft` | `number \| null` | nem |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |
| `zaro_datum` | `string` | igen |

## `landing_page_blocks`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `block_type` | `string` | igen |
| `content` | `Json` | igen |
| `created_at` | `string` | igen |
| `draft_content` | `Json \| null` | nem |
| `id` | `string` | igen |
| `is_published` | `boolean` | igen |
| `locale` | `string` | igen |
| `position` | `number` | igen |
| `updated_at` | `string` | igen |
| `updated_by` | `string \| null` | nem |
| `variant` | `string` | igen |

## `landing_page_versions`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `created_by` | `string \| null` | nem |
| `id` | `string` | igen |
| `label` | `string \| null` | nem |
| `locale` | `string` | igen |
| `snapshot` | `Json` | igen |
| `variant` | `string` | igen |

## `leave_admin_audit`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `action` | `string` | igen |
| `actor_user_id` | `string \| null` | nem |
| `after_data` | `Json \| null` | nem |
| `before_data` | `Json \| null` | nem |
| `created_at` | `string` | igen |
| `ev` | `number \| null` | nem |
| `id` | `string` | igen |
| `jogcim` | `string \| null` | nem |
| `nap` | `number \| null` | nem |
| `summary` | `string \| null` | nem |
| `target_user_id` | `string \| null` | nem |
| `tenant_id` | `string` | igen |

## `leave_carryover_log`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `appointment_id` | `string \| null` | nem |
| `created_at` | `string` | igen |
| `created_by` | `string \| null` | nem |
| `from_year` | `number` | igen |
| `id` | `string` | igen |
| `jogcim` | `string` | igen |
| `megjegyzes` | `string \| null` | nem |
| `nap` | `number` | igen |
| `tenant_id` | `string` | igen |
| `tipus` | `string` | igen |
| `to_year` | `number \| null` | nem |
| `user_id` | `string` | igen |

## `leave_entitlement`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `athozott_nap` | `number` | igen |
| `created_at` | `string` | igen |
| `ev` | `number` | igen |
| `forced_taken_nap` | `number` | igen |
| `hatralevo` | `number \| null` | nem |
| `id` | `string` | igen |
| `jaro_nap` | `number` | igen |
| `jogcim` | `string` | igen |
| `kiadott_nap` | `number` | igen |
| `lezart_at` | `string \| null` | nem |
| `lezart_by` | `string \| null` | nem |
| `manual_korrekcio` | `number` | igen |
| `notes` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `terv_nap` | `number` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |

## `leave_policy`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `alapszabadsag_mt` | `number` | igen |
| `apasagi_nap` | `number` | igen |
| `created_at` | `string` | igen |
| `eletkor_pot` | `Json` | igen |
| `eu_alap` | `Json` | igen |
| `ev` | `number` | igen |
| `forced_takeout_deadline_mmdd` | `string` | igen |
| `gyermek_pot` | `Json` | igen |
| `id` | `string` | igen |
| `max_carryover_alap_quarter` | `boolean` | igen |
| `oktatoi_max` | `number` | igen |
| `oktatoi_max_targy` | `number` | igen |
| `sugar_pot` | `number` | igen |
| `szuloi_nap` | `number` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |
| `vezeto_magas_pot` | `number` | igen |
| `vezeto_pot` | `number` | igen |

## `mandatory_duty_exemptions`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `ervenyes_ig` | `string \| null` | nem |
| `ervenyes_tol` | `string` | igen |
| `id` | `string` | igen |
| `indok` | `string \| null` | nem |
| `jovahagyas_at` | `string \| null` | nem |
| `jovahagyas_indok` | `string \| null` | nem |
| `jovahagyo_id` | `string \| null` | nem |
| `ok` | `Database["public"]["Enums"]["mentesseg_ok"]` | igen |
| `status` | `string` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |

## `mandatory_duty_rules`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `aktiv` | `boolean` | igen |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `max_per_honap` | `number \| null` | nem |
| `megjegyzes` | `string \| null` | nem |
| `min_per_honap` | `number` | igen |
| `scope_tipus` | `string` | igen |
| `scope_value` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |

## `measurements`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `context` | `Json \| null` | nem |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `kind` | `Database["public"]["Enums"]["measurement_kind"]` | igen |
| `patient_id` | `string` | igen |
| `program_id` | `string \| null` | nem |
| `recorded_by` | `string \| null` | nem |
| `source` | `Database["public"]["Enums"]["measurement_source"]` | igen |
| `tenant_id` | `string` | igen |
| `ts` | `string` | igen |
| `unit` | `string \| null` | nem |
| `value` | `number \| null` | nem |
| `value2` | `number \| null` | nem |

## `menstrual_cycles`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `bbt_id` | `string \| null` | nem |
| `ciklus_hossz` | `number \| null` | nem |
| `ciklus_kezdet` | `string` | igen |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `menstruacio_hossz` | `number \| null` | nem |
| `ovulacio_becsult` | `string \| null` | nem |
| `patient_id` | `string` | igen |
| `program_id` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `termekeny_ablak_ig` | `string \| null` | nem |
| `termekeny_ablak_tol` | `string \| null` | nem |
| `tunetek` | `Json \| null` | nem |

## `message_attachments`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `ai_summary` | `string \| null` | nem |
| `ai_summary_lang` | `string \| null` | nem |
| `ai_summary_status` | `Database["public"]["Enums"]["attachment_summary_status"]` | igen |
| `conversation_id` | `string` | igen |
| `created_at` | `string` | igen |
| `duration_ms` | `number \| null` | nem |
| `id` | `string` | igen |
| `kind` | `string` | igen |
| `message_id` | `string \| null` | nem |
| `mime` | `string` | igen |
| `original_name` | `string` | igen |
| `size_bytes` | `number` | igen |
| `storage_path` | `string` | igen |
| `transcript` | `string \| null` | nem |
| `uploaded_by` | `string` | igen |

## `message_read_receipts`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `message_id` | `string` | igen |
| `read_at` | `string` | igen |
| `reader_user_id` | `string` | igen |

## `message_translations`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `lang` | `string` | igen |
| `message_id` | `string` | igen |
| `model` | `string \| null` | nem |
| `translated_text` | `string` | igen |

## `messages`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `body` | `string \| null` | nem |
| `conversation_id` | `string` | igen |
| `created_at` | `string` | igen |
| `deleted_at` | `string \| null` | nem |
| `edited_at` | `string \| null` | nem |
| `id` | `string` | igen |
| `reply_to_id` | `string \| null` | nem |
| `sender_kind` | `Database["public"]["Enums"]["message_sender_kind"]` | igen |
| `sender_patient_id` | `string \| null` | nem |
| `sender_user_id` | `string \| null` | nem |
| `source_lang` | `string \| null` | nem |

## `minosites`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `alairas_datum` | `string \| null` | nem |
| `alairt` | `boolean` | igen |
| `created_at` | `string` | igen |
| `dokumentum_url` | `string \| null` | nem |
| `eredmeny` | `string` | igen |
| `ertekelo_user_id` | `string \| null` | nem |
| `id` | `string` | igen |
| `idoszak_ig` | `string` | igen |
| `idoszak_tol` | `string` | igen |
| `szoveges_ertekeles` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |

## `monitoring_alerts`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `ack_note` | `string \| null` | nem |
| `acknowledged_at` | `string \| null` | nem |
| `acknowledged_by` | `string \| null` | nem |
| `created_at` | `string` | igen |
| `fetal_movement_id` | `string \| null` | nem |
| `id` | `string` | igen |
| `kind` | `Database["public"]["Enums"]["monitoring_alert_kind"]` | igen |
| `measurement_id` | `string \| null` | nem |
| `patient_id` | `string` | igen |
| `program_id` | `string \| null` | nem |
| `severity` | `Database["public"]["Enums"]["monitoring_alert_severity"]` | igen |
| `status` | `Database["public"]["Enums"]["monitoring_alert_status"]` | igen |
| `stool_log_id` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `uzenet` | `string` | igen |

## `monitoring_programs`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `aktiv` | `boolean` | igen |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `kezdes` | `string` | igen |
| `megjegyzes` | `string \| null` | nem |
| `patient_id` | `string` | igen |
| `tenant_id` | `string` | igen |
| `tipus` | `Database["public"]["Enums"]["monitoring_program_tipus"]` | igen |
| `updated_at` | `string` | igen |
| `varhato_veg` | `string \| null` | nem |

## `monitoring_thresholds`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `beallito_id` | `string \| null` | nem |
| `created_at` | `string` | igen |
| `ertek` | `number` | igen |
| `id` | `string` | igen |
| `kulcs` | `string` | igen |
| `megjegyzes` | `string \| null` | nem |
| `patient_id` | `string \| null` | nem |
| `program_id` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `unit` | `string \| null` | nem |
| `updated_at` | `string` | igen |

## `notification_preferences`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `email_weekly_summary` | `boolean` | igen |
| `id` | `string` | igen |
| `push_appointments` | `boolean` | igen |
| `push_critical_alerts` | `boolean` | igen |
| `push_lab_results` | `boolean` | igen |
| `push_lifestyle_tips` | `boolean` | igen |
| `push_messages` | `boolean` | igen |
| `push_questionnaire_reminders` | `boolean` | igen |
| `quiet_hours_end` | `string \| null` | nem |
| `quiet_hours_start` | `string \| null` | nem |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |

## `notifications`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `cim` | `string` | igen |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `link` | `string \| null` | nem |
| `olvasott_at` | `string \| null` | nem |
| `tenant_id` | `string \| null` | nem |
| `tipus` | `string` | igen |
| `user_id` | `string` | igen |
| `uzenet` | `string \| null` | nem |

## `obstetric_partogram_entries`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `cervix_cm` | `number \| null` | nem |
| `contraction_duration_sec` | `number \| null` | nem |
| `contractions_per_10min` | `number \| null` | nem |
| `created_at` | `string` | igen |
| `created_by` | `string` | igen |
| `descent_station` | `number \| null` | nem |
| `drugs_text` | `string \| null` | nem |
| `fetal_heart_rate` | `number \| null` | nem |
| `id` | `string` | igen |
| `liquor_color` | `string \| null` | nem |
| `maternal_bp_dia` | `number \| null` | nem |
| `maternal_bp_sys` | `number \| null` | nem |
| `maternal_hr` | `number \| null` | nem |
| `moulding` | `string \| null` | nem |
| `notes` | `string \| null` | nem |
| `oxytocin_mu` | `number \| null` | nem |
| `partogram_id` | `string` | igen |
| `recorded_at` | `string` | igen |
| `temp_c` | `number \| null` | nem |

## `obstetric_partograms`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `created_by` | `string` | igen |
| `encounter_id` | `string` | igen |
| `id` | `string` | igen |
| `labor_start_ts` | `string` | igen |
| `membrane_status` | `string \| null` | nem |
| `notes_md` | `string \| null` | nem |
| `parity_gravida_json` | `Json` | igen |
| `patient_id` | `string` | igen |
| `tenant_id` | `string \| null` | nem |
| `updated_at` | `string` | igen |

## `opt_out_agreements`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `alairas_datum` | `string` | igen |
| `created_at` | `string` | igen |
| `dokumentum_url` | `string \| null` | nem |
| `employment_id` | `string \| null` | nem |
| `ervenyes_ig` | `string \| null` | nem |
| `ervenyes_tol` | `string` | igen |
| `id` | `string` | igen |
| `letrehozta` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |
| `visszavonas_datum` | `string \| null` | nem |
| `visszavonas_hatalyba_lep` | `string \| null` | nem |
| `visszavonas_indok` | `string \| null` | nem |

## `or_blocks`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `created_by` | `string \| null` | nem |
| `datum` | `string` | igen |
| `felszabaditasi_hatarido` | `string \| null` | nem |
| `id` | `string` | igen |
| `ismetlodo_szabaly` | `string \| null` | nem |
| `kezdo_ido` | `string` | igen |
| `megjegyzes` | `string \| null` | nem |
| `org_unit_id` | `string` | igen |
| `sebesz_user_id` | `string \| null` | nem |
| `specialty_id` | `string \| null` | nem |
| `statusz` | `Database["public"]["Enums"]["or_block_statusz_enum"]` | igen |
| `surgossegi_keret` | `boolean` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |
| `veg_ido` | `string` | igen |

## `or_emergency_responses`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `eta_perc` | `number \| null` | nem |
| `id` | `string` | igen |
| `megjegyzes` | `string \| null` | nem |
| `notification_id` | `string \| null` | nem |
| `surgery_case_id` | `string` | igen |
| `tenant_id` | `string` | igen |
| `tud_jonni` | `boolean` | igen |
| `user_id` | `string` | igen |

## `or_resources`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `aktiv` | `boolean` | igen |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `keszlet_db` | `number` | igen |
| `megosztott` | `boolean` | igen |
| `nev` | `string \| null` | nem |
| `site_id` | `string` | igen |
| `tenant_id` | `string` | igen |
| `tipus` | `Database["public"]["Enums"]["or_eroforras_tipus_enum"]` | igen |
| `updated_at` | `string` | igen |

## `or_room_profiles`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `aktiv` | `boolean` | igen |
| `created_at` | `string` | igen |
| `fordulo_ido_perc` | `number` | igen |
| `id` | `string` | igen |
| `napi_kezdo_ido` | `string` | igen |
| `napi_veg_ido` | `string` | igen |
| `or_suite_id` | `string` | igen |
| `org_unit_id` | `string` | igen |
| `tartalek` | `boolean` | igen |
| `tenant_id` | `string` | igen |
| `tipus` | `Database["public"]["Enums"]["or_tipus_enum"]` | igen |
| `updated_at` | `string` | igen |

## `or_staff_pool`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `created_by` | `string \| null` | nem |
| `department_org_unit_id` | `string \| null` | nem |
| `eligible_szerep` | `string` | igen |
| `ervenyes_ig` | `string \| null` | nem |
| `ervenyes_tol` | `string` | igen |
| `havi_max_perc` | `number \| null` | nem |
| `heti_keret_perc` | `number` | igen |
| `id` | `string` | igen |
| `megjegyzes` | `string \| null` | nem |
| `or_suite_id` | `string` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |

## `or_suites`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `aktiv` | `boolean` | igen |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `nev` | `string` | igen |
| `site_id` | `string` | igen |
| `surgossegi_keret_perc` | `number` | igen |
| `tartalek_muto_szam` | `number` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |

## `org_unit_departments`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `clinic_id` | `string` | igen |
| `created_at` | `string` | igen |
| `org_unit_id` | `string` | igen |
| `szerep` | `string` | igen |
| `tenant_id` | `string` | igen |

## `org_unit_specialties`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `org_unit_id` | `string` | igen |
| `specialty_id` | `string` | igen |
| `tenant_id` | `string` | igen |

## `org_units`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `agyszam` | `number \| null` | nem |
| `aktiv` | `boolean` | igen |
| `created_at` | `string` | igen |
| `floor_id` | `string \| null` | nem |
| `id` | `string` | igen |
| `max_letszam_napi` | `number \| null` | nem |
| `min_letszam_napi` | `number` | igen |
| `mukodes_kezd` | `string \| null` | nem |
| `mukodes_veg` | `string \| null` | nem |
| `muto_blokk_perc` | `number \| null` | nem |
| `nev` | `string` | igen |
| `parameterek` | `Json` | igen |
| `parent_id` | `string \| null` | nem |
| `site_id` | `string` | igen |
| `tenant_id` | `string` | igen |
| `tipus` | `Database["public"]["Enums"]["org_unit_tipus"]` | igen |
| `unnepnap_uzemel` | `boolean` | igen |
| `updated_at` | `string` | igen |
| `uzemmod` | `Database["public"]["Enums"]["uzemmod_tipus"] \| null` | nem |

## `osszeferhetetlenseg_engedelyek`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `csatolmany_url` | `string \| null` | nem |
| `engedely_datum` | `string \| null` | nem |
| `engedelyezo_szerv` | `string \| null` | nem |
| `id` | `string` | igen |
| `kerelem_datum` | `string \| null` | nem |
| `leiras` | `string` | igen |
| `lejarat` | `string \| null` | nem |
| `megjegyzes` | `string \| null` | nem |
| `status` | `string` | igen |
| `tenant_id` | `string` | igen |
| `tipus` | `string` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |

## `overtime_orders`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `elrendeles_at` | `string` | igen |
| `elrendelo_id` | `string` | igen |
| `id` | `string` | igen |
| `indok` | `string` | igen |
| `irasos_hivatkozas` | `string \| null` | nem |
| `kategoria` | `string` | igen |
| `kezdo_idopont` | `string` | igen |
| `ora` | `number` | igen |
| `org_unit_id` | `string \| null` | nem |
| `status` | `Database["public"]["Enums"]["overtime_order_status"]` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |
| `zaro_idopont` | `string` | igen |

## `overtime_preferences`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `csak_sajat_osztaly` | `boolean` | igen |
| `ervenyes_ig` | `string \| null` | nem |
| `ervenyes_tol` | `string` | igen |
| `id` | `string` | igen |
| `max_ora_havi` | `number \| null` | nem |
| `megjegyzes` | `string \| null` | nem |
| `muszakok` | `string[]` | igen |
| `napok` | `number[]` | igen |
| `status` | `Database["public"]["Enums"]["overtime_pref_status"]` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |

## `paciens_360_saved_views`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `filters` | `Json` | igen |
| `id` | `string` | igen |
| `is_default` | `boolean` | igen |
| `name` | `string` | igen |
| `patient_id` | `string \| null` | nem |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |

## `patient_ai_explanations`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `critical_flags` | `Json` | igen |
| `expires_at` | `string` | igen |
| `explanation` | `Json` | igen |
| `id` | `string` | igen |
| `language` | `string` | igen |
| `model` | `string` | igen |
| `patient_id` | `string` | igen |
| `prompt_hash` | `string` | igen |
| `source_id` | `string` | igen |
| `source_table` | `string` | igen |
| `suggested_specialty_id` | `string \| null` | nem |

## `patient_appointment_requests`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `appointment_id` | `string \| null` | nem |
| `created_at` | `string` | igen |
| `doctor_user_id` | `string \| null` | nem |
| `id` | `string` | igen |
| `patient_id` | `string` | igen |
| `preferred_datetime` | `string \| null` | nem |
| `preferred_slot_id` | `string \| null` | nem |
| `reason` | `string \| null` | nem |
| `request_type` | `string` | igen |
| `resolved_at` | `string \| null` | nem |
| `resolved_by` | `string \| null` | nem |
| `specialty_id` | `string \| null` | nem |
| `staff_response` | `string \| null` | nem |
| `status` | `string` | igen |
| `tenant_id` | `string \| null` | nem |
| `updated_at` | `string` | igen |
| `urgency` | `string` | igen |
| `user_id` | `string` | igen |

## `patient_checkin`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `appointment_id` | `string` | igen |
| `called_ts` | `string \| null` | nem |
| `checkin_ts` | `string` | igen |
| `created_at` | `string` | igen |
| `done_ts` | `string \| null` | nem |
| `id` | `string` | igen |
| `method` | `Database["public"]["Enums"]["checkin_method"]` | igen |
| `patient_id` | `string \| null` | nem |
| `queue_position` | `number \| null` | nem |
| `status` | `Database["public"]["Enums"]["checkin_status"]` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |

## `patient_documents`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `category` | `string` | igen |
| `created_at` | `string` | igen |
| `description` | `string \| null` | nem |
| `id` | `string` | igen |
| `mime_type` | `string \| null` | nem |
| `patient_id` | `string` | igen |
| `shared_with_patient` | `boolean` | igen |
| `size_bytes` | `number \| null` | nem |
| `storage_path` | `string` | igen |
| `tenant_id` | `string \| null` | nem |
| `title` | `string` | igen |
| `updated_at` | `string` | igen |
| `uploaded_by` | `string` | igen |
| `uploader_kind` | `string` | igen |

## `patient_emergency_card`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `allergiak` | `string[] \| null` | nem |
| `egyeb_info` | `string \| null` | nem |
| `etrend` | `string \| null` | nem |
| `gyogyszer_erzekenyseg` | `string[] \| null` | nem |
| `gyogyszerek` | `string[] \| null` | nem |
| `kapcsolt_orvos_telefon` | `string \| null` | nem |
| `kronikus_betegsegek` | `string[] \| null` | nem |
| `patient_id` | `string` | igen |
| `qr_token` | `string \| null` | nem |
| `sos_kontakt_nev` | `string \| null` | nem |
| `sos_kontakt_telefon` | `string \| null` | nem |
| `updated_at` | `string` | igen |
| `vercsoport` | `string \| null` | nem |

## `patient_encounters`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `beavatkozas_ids` | `string[]` | igen |
| `bno_kodok` | `string[]` | igen |
| `created_at` | `string` | igen |
| `ellatas_kezdete` | `string` | igen |
| `ellatas_vege` | `string \| null` | nem |
| `ellenjegyzo_alairas_at` | `string \| null` | nem |
| `ellenjegyzo_id` | `string \| null` | nem |
| `id` | `string` | igen |
| `intezmenyi_azonosito` | `string \| null` | nem |
| `oeno_kodok` | `string[]` | igen |
| `org_unit_id` | `string \| null` | nem |
| `osszefoglalo` | `string \| null` | nem |
| `patient_id` | `string` | igen |
| `site_id` | `string \| null` | nem |
| `status` | `string` | igen |
| `szerzo_alairas_at` | `string \| null` | nem |
| `szerzo_id` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `tipus` | `Database["public"]["Enums"]["encounter_tipus"]` | igen |
| `updated_at` | `string` | igen |
| `vezeto_orvos_id` | `string \| null` | nem |

## `patient_health_plans`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `cel` | `string \| null` | nem |
| `cim` | `string` | igen |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `kezdo_datum` | `string \| null` | nem |
| `lepesek` | `Json` | igen |
| `letrehozta` | `string \| null` | nem |
| `paciens_jegyzet` | `string \| null` | nem |
| `patient_id` | `string` | igen |
| `status` | `string` | igen |
| `tenant_id` | `string \| null` | nem |
| `updated_at` | `string` | igen |
| `zaro_datum` | `string \| null` | nem |

## `patient_lifestyle_log`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `category` | `string` | igen |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `logged_at` | `string` | igen |
| `notes` | `string \| null` | nem |
| `patient_id` | `string` | igen |
| `user_id` | `string` | igen |
| `value_json` | `Json` | igen |

## `patient_medication_requests`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `gyogyszer_nev` | `string` | igen |
| `hatas_eros` | `string \| null` | nem |
| `id` | `string` | igen |
| `ismetlodo` | `boolean` | igen |
| `megjegyzes` | `string \| null` | nem |
| `mennyiseg` | `string \| null` | nem |
| `patient_id` | `string` | igen |
| `reply` | `string \| null` | nem |
| `reviewed_at` | `string \| null` | nem |
| `reviewed_by` | `string \| null` | nem |
| `status` | `string` | igen |
| `surgosseg` | `string` | igen |
| `tenant_id` | `string \| null` | nem |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |

## `patient_referral_requests`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `decided_at` | `string \| null` | nem |
| `decided_by` | `string \| null` | nem |
| `decision_note` | `string \| null` | nem |
| `eeszt_ref` | `string \| null` | nem |
| `id` | `string` | igen |
| `notes` | `string \| null` | nem |
| `patient_id` | `string` | igen |
| `pdf_url` | `string \| null` | nem |
| `reason` | `string` | igen |
| `request_type` | `string` | igen |
| `requested_by` | `string \| null` | nem |
| `specialty` | `string \| null` | nem |
| `status` | `string` | igen |
| `tenant_id` | `string \| null` | nem |
| `updated_at` | `string` | igen |

## `patient_users`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `kapcsolat` | `string` | igen |
| `patient_id` | `string` | igen |
| `tenant_id` | `string \| null` | nem |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |
| `verified_at` | `string \| null` | nem |

## `patients`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `anyja_neve` | `string \| null` | nem |
| `cim` | `string \| null` | nem |
| `created_at` | `string` | igen |
| `email` | `string \| null` | nem |
| `fo_diagnozis_bno` | `string \| null` | nem |
| `gondozo_orvos_id` | `string \| null` | nem |
| `id` | `string` | igen |
| `iranyitoszam` | `string \| null` | nem |
| `keresztnev` | `string` | igen |
| `megjegyzes` | `string \| null` | nem |
| `nem` | `string \| null` | nem |
| `szuletesi_datum` | `string \| null` | nem |
| `taj` | `string \| null` | nem |
| `telefon` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |
| `varos` | `string \| null` | nem |
| `vezeteknev` | `string` | igen |

## `person_accreditations`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `domain_id` | `string` | igen |
| `ervenyes_ig` | `string \| null` | nem |
| `ervenyes_tol` | `string` | igen |
| `id` | `string` | igen |
| `igazolas_hivatkozas` | `string \| null` | nem |
| `jovahagyo_id` | `string \| null` | nem |
| `level_id` | `string` | igen |
| `megjegyzes` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |

## `probaidok`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `kezdo_datum` | `string` | igen |
| `megjegyzes` | `string \| null` | nem |
| `mentesseg_jogcim` | `string \| null` | nem |
| `profile_employment_id` | `string` | igen |
| `tartam_honap` | `number` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |
| `zaro_datum` | `string \| null` | nem |

## `profile_beavatkozasok`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `alkalom` | `number` | igen |
| `beavatkozas_id` | `string` | igen |
| `bizonyitek_url` | `string \| null` | nem |
| `created_at` | `string` | igen |
| `datum` | `string \| null` | nem |
| `id` | `string` | igen |
| `megjegyzes` | `string \| null` | nem |
| `mentor_igazolt` | `boolean` | igen |
| `mentor_user_id` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |

## `profile_certifications`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `dokumentum_url` | `string \| null` | nem |
| `id` | `string` | igen |
| `kibocsato` | `string \| null` | nem |
| `kibocsatva` | `string \| null` | nem |
| `lejarat` | `string \| null` | nem |
| `nev` | `string` | igen |
| `szam` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `tipus` | `string` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |

## `profile_constraints`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `ervenyes_ig` | `string \| null` | nem |
| `ervenyes_tol` | `string` | igen |
| `hr_megjegyzes` | `string \| null` | nem |
| `id` | `string` | igen |
| `igazolas_url` | `string \| null` | nem |
| `megjegyzes` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `tipus` | `Database["public"]["Enums"]["constraint_tipus"]` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |

## `profile_contacts`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `cimke` | `string \| null` | nem |
| `created_at` | `string` | igen |
| `csak_vesz_eseten` | `boolean` | igen |
| `ertek` | `string` | igen |
| `ertesites_engedelyezve` | `boolean` | igen |
| `id` | `string` | igen |
| `is_primary` | `boolean` | igen |
| `megjegyzes` | `string \| null` | nem |
| `sorrend` | `number` | igen |
| `tenant_id` | `string \| null` | nem |
| `tipus` | `Database["public"]["Enums"]["contact_tipus"]` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |

## `profile_daily_preferences`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `ervenyes_ig` | `string \| null` | nem |
| `ervenyes_tol` | `string` | igen |
| `id` | `string` | igen |
| `jovahagyas_at` | `string \| null` | nem |
| `jovahagyas_indok` | `string \| null` | nem |
| `jovahagyo_id` | `string \| null` | nem |
| `kerult_kezd` | `string \| null` | nem |
| `kerult_veg` | `string \| null` | nem |
| `keszenlet_vallal` | `boolean \| null` | nem |
| `max_muszak_hossz_ora` | `number \| null` | nem |
| `megjegyzes` | `string \| null` | nem |
| `nap_iso` | `number` | igen |
| `preferalt_kezd` | `string \| null` | nem |
| `preferalt_veg` | `string \| null` | nem |
| `status` | `string` | igen |
| `submitted_at` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `ugyelet_vallal` | `boolean \| null` | nem |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |

## `profile_daily_preferences_events`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `action` | `string` | igen |
| `actor_id` | `string \| null` | nem |
| `after_data` | `Json \| null` | nem |
| `before_data` | `Json \| null` | nem |
| `created_at` | `string` | igen |
| `from_status` | `string \| null` | nem |
| `id` | `string` | igen |
| `indok` | `string \| null` | nem |
| `nap_iso` | `number \| null` | nem |
| `pref_id` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `to_status` | `string \| null` | nem |
| `user_id` | `string` | igen |

## `profile_employment`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `elsodleges` | `boolean` | igen |
| `ervenyes` | `boolean` | igen |
| `fenntarto_tipus` | `Database["public"]["Enums"]["fenntarto_tipus"]` | igen |
| `fte_szazalek` | `number` | igen |
| `id` | `string` | igen |
| `jogviszony_tipus` | `Database["public"]["Enums"]["jogviszony_tipus"]` | igen |
| `keret_ora` | `number \| null` | nem |
| `kezdo_datum` | `string \| null` | nem |
| `munkaido_keret` | `Database["public"]["Enums"]["munkaido_keret_tipus"]` | igen |
| `munkakor_kod` | `string \| null` | nem |
| `munkakor_megnevezes` | `string \| null` | nem |
| `munkaltato_nev` | `string` | igen |
| `oktatoi_munkakor_arany` | `number \| null` | nem |
| `opt_out_kezdete` | `string \| null` | nem |
| `opt_out_ovt` | `boolean` | igen |
| `opt_out_visszavonas` | `string \| null` | nem |
| `org_unit_id` | `string \| null` | nem |
| `osszeferhetetlenseg_megjegyzes` | `string \| null` | nem |
| `ovt_max_evi_ora` | `number \| null` | nem |
| `site_id` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `tobbes_jogviszony` | `boolean` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |
| `vezetoi_szint` | `string \| null` | nem |
| `zaro_datum` | `string \| null` | nem |

## `profile_employment_optout_log`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `action` | `string` | igen |
| `created_at` | `string` | igen |
| `decided_by` | `string \| null` | nem |
| `effective_date` | `string` | igen |
| `employment_id` | `string` | igen |
| `id` | `string` | igen |
| `indok` | `string \| null` | nem |
| `ovt_max_evi_ora` | `number \| null` | nem |
| `tenant_id` | `string` | igen |
| `user_id` | `string` | igen |

## `profile_external_hours`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `ev` | `number` | igen |
| `hely` | `string \| null` | nem |
| `honap` | `number` | igen |
| `id` | `string` | igen |
| `jogviszony_tipus` | `string \| null` | nem |
| `megjegyzes` | `string \| null` | nem |
| `ora` | `number` | igen |
| `tenant_id` | `string \| null` | nem |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |

## `profile_paired_shifts`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `ervenyes_ig` | `string \| null` | nem |
| `ervenyes_tol` | `string` | igen |
| `id` | `string` | igen |
| `indoklas` | `string \| null` | nem |
| `muszak_kulcs` | `string \| null` | nem |
| `napok` | `number[]` | igen |
| `partner_id` | `string` | igen |
| `suly` | `number` | igen |
| `tenant_id` | `string` | igen |
| `tipus` | `Database["public"]["Enums"]["paired_shift_tipus"]` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |

## `profile_peer_links`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `from_user_id` | `string` | igen |
| `id` | `string` | igen |
| `indoklas` | `string \| null` | nem |
| `jovahagyas_at` | `string \| null` | nem |
| `jovahagyas_indok` | `string \| null` | nem |
| `jovahagyo_id` | `string \| null` | nem |
| `status` | `Database["public"]["Enums"]["peer_link_status"]` | igen |
| `suly` | `number \| null` | nem |
| `tenant_id` | `string \| null` | nem |
| `tipus` | `Database["public"]["Enums"]["peer_link_tipus"]` | igen |
| `to_user_id` | `string` | igen |
| `updated_at` | `string` | igen |

## `profile_preferences`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `egymas_utani_max_ugyelet` | `number` | igen |
| `havi_max_ugyelet` | `number \| null` | nem |
| `heti_max_ora` | `number \| null` | nem |
| `jovahagyas_at` | `string \| null` | nem |
| `jovahagyas_feltetel` | `string \| null` | nem |
| `jovahagyas_indok` | `string \| null` | nem |
| `jovahagyo_id` | `string \| null` | nem |
| `kozossegi_napok` | `string[]` | igen |
| `last_minute_elerheto` | `boolean` | igen |
| `last_minute_orahatar` | `number \| null` | nem |
| `megjegyzes` | `string \| null` | nem |
| `nyelvek` | `string[]` | igen |
| `preferalt_feladat_korok` | `string[]` | igen |
| `preferalt_musakok` | `Database["public"]["Enums"]["musak_pref"][]` | igen |
| `status` | `Database["public"]["Enums"]["unavailability_status"]` | igen |
| `submitted_at` | `string \| null` | nem |
| `tenant_id` | `string \| null` | nem |
| `tiltott_napok` | `number[]` | igen |
| `ugyelet_utan_min_ora` | `number` | igen |
| `ugyelet_utan_pihenonap` | `boolean` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |
| `utazasi_perc_max` | `number \| null` | nem |

## `profile_program_milestones`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `elerve_at` | `string \| null` | nem |
| `id` | `string` | igen |
| `megjegyzes` | `string \| null` | nem |
| `milestone` | `string` | igen |
| `program_id` | `string` | igen |
| `status` | `string` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |

## `profile_service_history`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `beszamithato_eusztv` | `boolean` | igen |
| `beszamithato_jubileum` | `boolean` | igen |
| `created_at` | `string` | igen |
| `csatolmany_url` | `string \| null` | nem |
| `fenntarto_tipus` | `string` | igen |
| `forras` | `string` | igen |
| `id` | `string` | igen |
| `kezdo_datum` | `string` | igen |
| `megjegyzes` | `string \| null` | nem |
| `munkakor` | `string \| null` | nem |
| `munkaltato_nev` | `string` | igen |
| `rogzitette_user_id` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |
| `zaro_datum` | `string \| null` | nem |

## `profile_service_time_overrides`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `ervenyes_ig` | `string \| null` | nem |
| `ervenyes_tol` | `string` | igen |
| `id` | `string` | igen |
| `indok` | `string` | igen |
| `jovahagyo_user_id` | `string \| null` | nem |
| `napok_korrekcio` | `number` | igen |
| `tenant_id` | `string` | igen |
| `tipus` | `string` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |

## `profile_skills`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `igazolva_at` | `string \| null` | nem |
| `lejarat` | `string \| null` | nem |
| `megjegyzes` | `string \| null` | nem |
| `skill_id` | `string` | igen |
| `szint` | `number` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |

## `profile_trainings`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `elorehaladas_pct` | `number` | igen |
| `id` | `string` | igen |
| `kezdes` | `string \| null` | nem |
| `megjegyzes` | `string \| null` | nem |
| `nev` | `string` | igen |
| `program_id` | `string \| null` | nem |
| `statusz` | `string` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |
| `varhato_veg` | `string \| null` | nem |

## `profile_unavailability`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `akut` | `boolean` | igen |
| `created_at` | `string` | igen |
| `csak_delelott` | `boolean` | igen |
| `csak_delutan` | `boolean` | igen |
| `forrasev` | `number \| null` | nem |
| `id` | `string` | igen |
| `is_kenyszer` | `boolean` | igen |
| `jogcim` | `string` | igen |
| `jovahagyas_at` | `string \| null` | nem |
| `jovahagyas_indok` | `string \| null` | nem |
| `jovahagyo_id` | `string \| null` | nem |
| `kezdo_datum` | `string` | igen |
| `leiras` | `string \| null` | nem |
| `nap_szam` | `number \| null` | nem |
| `status` | `Database["public"]["Enums"]["unavailability_status"]` | igen |
| `tenant_id` | `string \| null` | nem |
| `tipus` | `Database["public"]["Enums"]["unavailability_tipus"]` | igen |
| `training_program_id` | `string \| null` | nem |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |
| `zaro_datum` | `string` | igen |

## `profile_work_time_frame`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `ervenyes_ig` | `string \| null` | nem |
| `ervenyes_tol` | `string` | igen |
| `havi_orakeret` | `number \| null` | nem |
| `id` | `string` | igen |
| `indok` | `string \| null` | nem |
| `rogzitette_user_id` | `string \| null` | nem |
| `szazalek` | `number \| null` | nem |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |

## `profiles`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `aktiv` | `boolean` | igen |
| `avatar_url` | `string \| null` | nem |
| `becenev` | `string \| null` | nem |
| `belepes_datum` | `string \| null` | nem |
| `bemutatkozas` | `string \| null` | nem |
| `bemutatkozas_publikus` | `boolean` | igen |
| `created_at` | `string` | igen |
| `email` | `string` | igen |
| `foglalkozas_tipus` | `Database["public"]["Enums"]["foglalkozas_tipus"]` | igen |
| `gyermek_szamok` | `Json` | igen |
| `id` | `string` | igen |
| `kjt_fizetesi_osztaly` | `string \| null` | nem |
| `klinikai_kombinalt` | `boolean` | igen |
| `locale` | `string \| null` | nem |
| `napi_mutet_cap` | `number \| null` | nem |
| `nem` | `Database["public"]["Enums"]["nem_tipus"] \| null` | nem |
| `oktatoi_munkakor` | `boolean` | igen |
| `reminder_email_enabled` | `boolean` | igen |
| `reminder_push_enabled` | `boolean` | igen |
| `sugarterheles_kategoria` | `string \| null` | nem |
| `szuletesi_datum` | `string \| null` | nem |
| `teljes_nev` | `string` | igen |
| `tenant_id` | `string \| null` | nem |
| `updated_at` | `string` | igen |
| `vezetoi_szint` | `string \| null` | nem |

## `public_holidays`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `datum` | `string` | igen |
| `fizetett` | `boolean` | igen |
| `forrasszoveg` | `string \| null` | nem |
| `id` | `string` | igen |
| `nev` | `string` | igen |
| `tenant_id` | `string \| null` | nem |
| `updated_at` | `string` | igen |

## `push_settings`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `enabled` | `boolean` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |
| `updated_by` | `string \| null` | nem |
| `vapid_subject` | `string` | igen |

## `push_subscriptions`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `auth` | `string` | igen |
| `created_at` | `string` | igen |
| `endpoint` | `string` | igen |
| `id` | `string` | igen |
| `last_used_at` | `string \| null` | nem |
| `p256dh` | `string` | igen |
| `user_agent` | `string \| null` | nem |
| `user_id` | `string` | igen |

## `questionnaire_assignments`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `appointment_id` | `string \| null` | nem |
| `assigned_at` | `string` | igen |
| `assigned_by` | `string \| null` | nem |
| `created_at` | `string` | igen |
| `draft_answers` | `Json \| null` | nem |
| `draft_saved_at` | `string \| null` | nem |
| `due_at` | `string \| null` | nem |
| `id` | `string` | igen |
| `kind` | `Database["public"]["Enums"]["assignment_kind"]` | igen |
| `kiosk_pin_hash` | `string \| null` | nem |
| `last_activity_at` | `string \| null` | nem |
| `patient_id` | `string \| null` | nem |
| `print_cancelled_at` | `string \| null` | nem |
| `print_cancelled_by` | `string \| null` | nem |
| `print_status` | `Database["public"]["Enums"]["kiosk_print_status"]` | igen |
| `printed_at` | `string \| null` | nem |
| `printed_by` | `string \| null` | nem |
| `questionnaire_id` | `string` | igen |
| `reminded_at` | `string \| null` | nem |
| `reminder_count` | `number` | igen |
| `status` | `Database["public"]["Enums"]["q_assignment_status"]` | igen |
| `tenant_id` | `string` | igen |
| `token` | `string` | igen |
| `updated_at` | `string` | igen |

## `questionnaire_event_triggers`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `active` | `boolean` | igen |
| `channel` | `Database["public"]["Enums"]["reminder_channel"]` | igen |
| `created_at` | `string` | igen |
| `created_by` | `string \| null` | nem |
| `due_offset_days` | `number` | igen |
| `event_type` | `Database["public"]["Enums"]["qet_event_type"]` | igen |
| `id` | `string` | igen |
| `questionnaire_id` | `string` | igen |
| `reminder_buckets` | `number[]` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |

## `questionnaire_responses`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `answers` | `Json` | igen |
| `appointment_id` | `string \| null` | nem |
| `assignment_id` | `string \| null` | nem |
| `completed_at` | `string` | igen |
| `consent_to_record` | `boolean` | igen |
| `created_at` | `string` | igen |
| `critical_triggered` | `boolean` | igen |
| `id` | `string` | igen |
| `is_anonymous` | `boolean` | igen |
| `patient_id` | `string \| null` | nem |
| `questionnaire_id` | `string` | igen |
| `severity` | `string \| null` | nem |
| `subscale_scores` | `Json` | igen |
| `tenant_id` | `string` | igen |
| `total_score` | `number \| null` | nem |

## `questionnaire_schedules`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `aktiv` | `boolean` | igen |
| `beallito_id` | `string \| null` | nem |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `interval_days` | `number` | igen |
| `last_run_at` | `string \| null` | nem |
| `megjegyzes` | `string \| null` | nem |
| `monitoring_program_id` | `string \| null` | nem |
| `next_due_at` | `string \| null` | nem |
| `patient_id` | `string \| null` | nem |
| `questionnaire_id` | `string` | igen |
| `scope` | `string` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |

## `questionnaires`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `aktiv` | `boolean` | igen |
| `becsult_perc` | `number \| null` | nem |
| `code` | `string` | igen |
| `created_at` | `string` | igen |
| `critical_item_index` | `number \| null` | nem |
| `critical_threshold` | `number \| null` | nem |
| `cutoffs` | `Json` | igen |
| `id` | `string` | igen |
| `items` | `Json` | igen |
| `kioszk_eligible` | `boolean` | igen |
| `language` | `string` | igen |
| `leiras` | `string \| null` | nem |
| `licenc` | `Database["public"]["Enums"]["q_licenc"]` | igen |
| `mode` | `Database["public"]["Enums"]["q_mode"]` | igen |
| `recall_rules` | `Json` | igen |
| `scoring` | `Json` | igen |
| `tenant_id` | `string \| null` | nem |
| `title` | `string` | igen |
| `updated_at` | `string` | igen |

## `resource_bookings`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `datum` | `string` | igen |
| `id` | `string` | igen |
| `kezdo_ido` | `string` | igen |
| `megjegyzes` | `string \| null` | nem |
| `mennyiseg` | `number` | igen |
| `or_resource_id` | `string` | igen |
| `surgery_case_id` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |
| `veg_ido` | `string` | igen |

## `role_permissions`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `perm` | `string` | igen |
| `role_kulcs` | `string` | igen |

## `roles`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `id` | `string` | igen |
| `kategoria` | `Database["public"]["Enums"]["role_kategoria"]` | igen |
| `kulcs` | `string` | igen |
| `megnevezes` | `string` | igen |
| `sorrend` | `number` | igen |

## `satisfaction_surveys`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `answers` | `Json` | igen |
| `appointment_id` | `string \| null` | nem |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `instrument_code` | `string` | igen |
| `is_anonymous` | `boolean` | igen |
| `nps_score` | `number \| null` | nem |
| `resource_id` | `string \| null` | nem |
| `submitted_at` | `string` | igen |
| `tenant_id` | `string` | igen |

## `schedule_assignments`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `created_by` | `string \| null` | nem |
| `feladatkor_id` | `string \| null` | nem |
| `forras` | `string \| null` | nem |
| `id` | `string` | igen |
| `kategoria` | `Database["public"]["Enums"]["ora_kategoria"]` | igen |
| `kezdo_idopont` | `string` | igen |
| `megjegyzes` | `string \| null` | nem |
| `ora` | `number` | igen |
| `org_unit_id` | `string \| null` | nem |
| `pin` | `boolean` | igen |
| `run_id` | `string \| null` | nem |
| `site_id` | `string \| null` | nem |
| `status` | `Database["public"]["Enums"]["assignment_status"]` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |
| `zaro_idopont` | `string` | igen |

## `schedule_change_requests`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `assignment_id` | `string` | igen |
| `created_at` | `string` | igen |
| `decided_at` | `string \| null` | nem |
| `decided_by` | `string \| null` | nem |
| `decision_note` | `string \| null` | nem |
| `id` | `string` | igen |
| `reason` | `string \| null` | nem |
| `request_type` | `Database["public"]["Enums"]["schedule_change_request_type"]` | igen |
| `requester_id` | `string` | igen |
| `status` | `Database["public"]["Enums"]["schedule_change_request_status"]` | igen |
| `target_user_id` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |

## `schedule_explanations`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `assignment_id` | `string \| null` | nem |
| `created_at` | `string` | igen |
| `datum` | `string \| null` | nem |
| `id` | `string` | igen |
| `kulcs` | `string` | igen |
| `run_id` | `string` | igen |
| `sulyozas` | `number \| null` | nem |
| `szint` | `string` | igen |
| `szoveg` | `string` | igen |
| `tenant_id` | `string` | igen |
| `user_id` | `string \| null` | nem |

## `schedule_runs`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `eredmeny_osszegzes` | `Json` | igen |
| `hard_sertes_szam` | `number` | igen |
| `hibauzenet` | `string \| null` | nem |
| `id` | `string` | igen |
| `idoszak_kezdet` | `string` | igen |
| `idoszak_veg` | `string` | igen |
| `indito_id` | `string \| null` | nem |
| `lagy_pontszam` | `number` | igen |
| `org_unit_id` | `string \| null` | nem |
| `parameterek` | `Json` | igen |
| `publikalo_id` | `string \| null` | nem |
| `publikalt_at` | `string \| null` | nem |
| `solver` | `string` | igen |
| `status` | `string` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |

## `schedule_share_tokens`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `created_by` | `string` | igen |
| `expires_at` | `string` | igen |
| `id` | `string` | igen |
| `revoked_at` | `string \| null` | nem |
| `scope_month` | `string` | igen |
| `tenant_id` | `string` | igen |
| `token` | `string` | igen |

## `shift_notifications_sent`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `assignment_id` | `string` | igen |
| `channel` | `string` | igen |
| `error` | `string \| null` | nem |
| `id` | `string` | igen |
| `kind` | `string` | igen |
| `sent_at` | `string` | igen |
| `success` | `boolean` | igen |
| `user_id` | `string` | igen |

## `sites`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `aktiv` | `boolean` | igen |
| `cim` | `string \| null` | nem |
| `clinic_id` | `string` | igen |
| `created_at` | `string` | igen |
| `fenntarto_tipus` | `Database["public"]["Enums"]["fenntarto_tipus"] \| null` | nem |
| `id` | `string` | igen |
| `nev` | `string` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |

## `skills`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `aktiv` | `boolean` | igen |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `kategoria` | `string \| null` | nem |
| `kulcs` | `string` | igen |
| `leiras` | `string \| null` | nem |
| `nev` | `string` | igen |
| `specialty_id` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |

## `specialties`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `aktiv` | `boolean` | igen |
| `id` | `string` | igen |
| `kod` | `string` | igen |
| `nev` | `string` | igen |

## `staff_import_runs`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `error_rows` | `number` | igen |
| `file_hash` | `string \| null` | nem |
| `file_name` | `string \| null` | nem |
| `id` | `string` | igen |
| `imported_by` | `string` | igen |
| `inserted_rows` | `number` | igen |
| `skipped_rows` | `number` | igen |
| `summary` | `Json` | igen |
| `tenant_id` | `string` | igen |
| `total_rows` | `number` | igen |
| `updated_rows` | `number` | igen |

## `staff_levels`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `ervenyes_tol` | `string \| null` | nem |
| `id` | `string` | igen |
| `szint` | `string` | igen |
| `tenant_id` | `string` | igen |
| `tipus` | `Database["public"]["Enums"]["staff_level_tipus"]` | igen |
| `user_id` | `string` | igen |

## `staff_roles`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `aktiv` | `boolean` | igen |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `kulcs` | `string` | igen |
| `leiras` | `string \| null` | nem |
| `nev` | `string` | igen |
| `rendszerszintu` | `boolean` | igen |
| `sorrend` | `number` | igen |
| `tenant_id` | `string \| null` | nem |
| `updated_at` | `string` | igen |

## `staffing_template_roles`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `kotelezo` | `boolean` | igen |
| `max_letszam` | `number \| null` | nem |
| `min_letszam` | `number` | igen |
| `skill_id` | `string \| null` | nem |
| `sorrend` | `number` | igen |
| `staff_role_id` | `string` | igen |
| `template_id` | `string` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |

## `staffing_templates`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `aktiv` | `boolean` | igen |
| `created_at` | `string` | igen |
| `ervenyes_ig` | `string \| null` | nem |
| `ervenyes_tol` | `string` | igen |
| `id` | `string` | igen |
| `kategoria` | `string` | igen |
| `kezd_ido` | `string` | igen |
| `leiras` | `string \| null` | nem |
| `nap_bitmap` | `number` | igen |
| `nev` | `string` | igen |
| `org_unit_id` | `string` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |
| `veg_ido` | `string` | igen |

## `stool_log`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `ai_bristol_javaslat` | `number \| null` | nem |
| `bristol_tipus` | `number \| null` | nem |
| `created_at` | `string` | igen |
| `foto_url` | `string \| null` | nem |
| `id` | `string` | igen |
| `nyak` | `boolean` | igen |
| `patient_id` | `string` | igen |
| `program_id` | `string \| null` | nem |
| `rome_tunetek` | `Json \| null` | nem |
| `tenant_id` | `string` | igen |
| `ts` | `string` | igen |
| `veres` | `boolean` | igen |

## `surgery_case_assignments`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `ai_generated` | `boolean` | igen |
| `case_id` | `string` | igen |
| `created_at` | `string` | igen |
| `created_by` | `string \| null` | nem |
| `id` | `string` | igen |
| `indok` | `string \| null` | nem |
| `szerep` | `string` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |

## `surgery_cases`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `becsult_idotartam_perc` | `number` | igen |
| `created_at` | `string` | igen |
| `created_by` | `string \| null` | nem |
| `delegalt_operator_id` | `string \| null` | nem |
| `id` | `string` | igen |
| `jovahagyas_at` | `string \| null` | nem |
| `jovahagyta_user_id` | `string \| null` | nem |
| `kiemelt` | `boolean` | igen |
| `kotelezo_eroforrasok_override` | `Json \| null` | nem |
| `megjegyzes` | `string \| null` | nem |
| `operator_min_seniority_override` | `string \| null` | nem |
| `or_block_id` | `string \| null` | nem |
| `patient_id` | `string` | igen |
| `posztop_apolasi_perc` | `number` | igen |
| `prioritas` | `Database["public"]["Enums"]["or_case_prioritas_enum"]` | igen |
| `sort_order` | `number \| null` | nem |
| `statusz` | `Database["public"]["Enums"]["or_case_statusz_enum"]` | igen |
| `surgery_type_id` | `string \| null` | nem |
| `szukseges_szerepek` | `Json \| null` | nem |
| `tenant_id` | `string` | igen |
| `tenyleges_kezdo_ido` | `string \| null` | nem |
| `tenyleges_veg_ido` | `string \| null` | nem |
| `tervezett_kezdo_ido` | `string \| null` | nem |
| `updated_at` | `string` | igen |

## `surgery_types`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `aktiv` | `boolean` | igen |
| `beavatkozas_id` | `string \| null` | nem |
| `becsult_idotartam_perc` | `number` | igen |
| `created_at` | `string` | igen |
| `delegalas_kotelezo` | `boolean` | igen |
| `id` | `string` | igen |
| `kiemelt` | `boolean` | igen |
| `kod` | `string \| null` | nem |
| `kotelezo_eroforrasok` | `Json` | igen |
| `nev` | `string` | igen |
| `operator_min_seniority` | `string \| null` | nem |
| `posztop_apolasi_perc` | `number` | igen |
| `szukseges_skillek` | `Json` | igen |
| `szukseges_szerepek` | `Json` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |

## `symptom_match_feedback`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `query` | `string` | igen |
| `specialty_id` | `string` | igen |
| `urgency` | `string \| null` | nem |
| `user_id` | `string` | igen |
| `verdict` | `string` | igen |

## `szabadsag_evente`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `alapszabadsag_nap` | `number` | igen |
| `created_at` | `string` | igen |
| `egyeb_jogcim_jsonb` | `Json` | igen |
| `ev` | `number` | igen |
| `gyermek_potszabadsag_nap` | `number` | igen |
| `id` | `string` | igen |
| `kivett_nap` | `number` | igen |
| `potszabadsag_nap` | `number` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |

## `szolgalati_elismeres`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `fokozat` | `number` | igen |
| `id` | `string` | igen |
| `kifizetes_datum` | `string \| null` | nem |
| `megjegyzes` | `string \| null` | nem |
| `osszeg_ft` | `number \| null` | nem |
| `status` | `string` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |
| `varhato_datum` | `string` | igen |

## `tenants`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `aktiv` | `boolean` | igen |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `nev` | `string` | igen |
| `plan` | `string` | igen |
| `regio` | `string` | igen |
| `updated_at` | `string` | igen |

## `training_program_elements`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `aktiv` | `boolean` | igen |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `idotartam_honap` | `number \| null` | nem |
| `kategoria` | `string \| null` | nem |
| `klinikan_kivul_engedett` | `boolean` | igen |
| `kod` | `string \| null` | nem |
| `kotelezo` | `boolean` | igen |
| `leiras` | `string \| null` | nem |
| `milestone` | `string \| null` | nem |
| `nev` | `string` | igen |
| `parent_element_id` | `string \| null` | nem |
| `program_id` | `string` | igen |
| `sorszam` | `number` | igen |
| `updated_at` | `string` | igen |

## `training_program_interventions`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `beavatkozas_id` | `string \| null` | nem |
| `beavatkozas_nev` | `string` | igen |
| `created_at` | `string` | igen |
| `element_id` | `string \| null` | nem |
| `id` | `string` | igen |
| `klinikan_kivul_engedett` | `boolean` | igen |
| `milestone` | `string \| null` | nem |
| `program_id` | `string` | igen |
| `required_esetszam` | `number` | igen |
| `sorszam` | `number` | igen |
| `szerep` | `string` | igen |
| `szint` | `string \| null` | nem |
| `updated_at` | `string` | igen |

## `training_program_skills`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `cel_szint` | `number` | igen |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `program_id` | `string` | igen |
| `skill_id` | `string` | igen |

## `training_programs`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `aktiv` | `boolean` | igen |
| `created_at` | `string` | igen |
| `honap_hossz` | `number \| null` | nem |
| `id` | `string` | igen |
| `leiras` | `string \| null` | nem |
| `nev` | `string` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |

## `translation_glossary`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `id` | `string` | igen |
| `notes` | `string \| null` | nem |
| `target_lang` | `string` | igen |
| `tenant_id` | `string \| null` | nem |
| `term` | `string` | igen |
| `translation` | `string` | igen |
| `updated_at` | `string` | igen |

## `user_provider_identities`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `avatar_url` | `string \| null` | nem |
| `created_at` | `string` | igen |
| `email` | `string \| null` | nem |
| `id` | `string` | igen |
| `provider` | `string` | igen |
| `provider_user_id` | `string` | igen |
| `raw` | `Json \| null` | nem |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |

## `user_roles`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `ervenyes_ig` | `string \| null` | nem |
| `ervenyes_tol` | `string \| null` | nem |
| `id` | `string` | igen |
| `org_unit_id` | `string \| null` | nem |
| `role_id` | `string` | igen |
| `site_id` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `user_id` | `string` | igen |

## `vegkielegites_szamitasok`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `felmentesi_ido_nap` | `number` | igen |
| `havi_illetmeny_ft` | `number` | igen |
| `id` | `string` | igen |
| `jovahagyo_user_id` | `string \| null` | nem |
| `megjegyzes` | `string \| null` | nem |
| `megszunes_jogcim` | `string` | igen |
| `osszeg_ft` | `number` | igen |
| `profile_employment_id` | `string \| null` | nem |
| `szamitas_datum` | `string` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |
| `vegkielegites_havi_szam` | `number` | igen |

## `wage_codes`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `alap_szorzo` | `number` | igen |
| `created_at` | `string` | igen |
| `ervenyes` | `boolean` | igen |
| `id` | `string` | igen |
| `kategoria` | `string \| null` | nem |
| `kod` | `string` | igen |
| `leiras` | `string \| null` | nem |
| `nev` | `string` | igen |
| `tenant_id` | `string \| null` | nem |
| `updated_at` | `string` | igen |

## `wage_mapping`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `ervenyes_ig` | `string \| null` | nem |
| `ervenyes_tol` | `string` | igen |
| `felulirat_szorzo` | `number \| null` | nem |
| `id` | `string` | igen |
| `kategoria` | `Database["public"]["Enums"]["ora_kategoria"]` | igen |
| `prioritas` | `number` | igen |
| `sav` | `string` | igen |
| `tenant_id` | `string \| null` | nem |
| `updated_at` | `string` | igen |
| `wage_code_id` | `string` | igen |

## `wage_table_egeszsegugyi`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `alapilletmeny_ft` | `number` | igen |
| `besorolasi_kategoria` | `string` | igen |
| `created_at` | `string` | igen |
| `ervenyes_ig` | `string \| null` | nem |
| `ervenyes_tol` | `string` | igen |
| `fizetesi_fokozat` | `number` | igen |
| `fizetesi_osztaly` | `string \| null` | nem |
| `forrasszoveg` | `string \| null` | nem |
| `garantalt_illetmeny_ft` | `number \| null` | nem |
| `gyakorlati_ido_ig_ev` | `number \| null` | nem |
| `gyakorlati_ido_tol_ev` | `number \| null` | nem |
| `id` | `string` | igen |
| `jogszabaly_hivatkozas` | `string \| null` | nem |
| `munkakor_megnevezes` | `string \| null` | nem |
| `osszeg_ft` | `number \| null` | nem |
| `potlek_alap_ft` | `number \| null` | nem |
| `tabla_tipus` | `Database["public"]["Enums"]["eusztv_tabla_tipus"]` | igen |
| `tenant_id` | `string \| null` | nem |
| `updated_at` | `string` | igen |
| `vezeto_szorzo` | `number` | igen |

## `wearable_data`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `alvas_perc` | `number \| null` | nem |
| `atlag_pulzus` | `number \| null` | nem |
| `datum` | `string` | igen |
| `hrv_ms` | `number \| null` | nem |
| `id` | `string` | igen |
| `lepes` | `number \| null` | nem |
| `nyugalmi_pulzus` | `number \| null` | nem |
| `patient_id` | `string` | igen |
| `provider` | `string` | igen |
| `raw` | `Json \| null` | nem |
| `synced_at` | `string` | igen |
| `tenant_id` | `string` | igen |

## `work_time_custom_rules`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `aktiv` | `boolean` | igen |
| `created_at` | `string` | igen |
| `created_by` | `string \| null` | nem |
| `ervenyes_ig` | `string \| null` | nem |
| `ervenyes_tol` | `string` | igen |
| `fenntarto_tipus` | `Database["public"]["Enums"]["fenntarto_tipus"] \| null` | nem |
| `id` | `string` | igen |
| `jogszabaly_hivatkozas` | `string \| null` | nem |
| `konfiguracio` | `Json` | igen |
| `nev` | `string` | igen |
| `prioritas` | `number` | igen |
| `szabaly_tipus` | `string` | igen |
| `tenant_id` | `string` | igen |
| `updated_at` | `string` | igen |

## `work_time_ledger`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `assignment_id` | `string \| null` | nem |
| `created_at` | `string` | igen |
| `datum` | `string` | igen |
| `dijazas_tipus` | `string \| null` | nem |
| `ejszakai_ora` | `number` | igen |
| `forras` | `string \| null` | nem |
| `id` | `string` | igen |
| `jovahagyas_at` | `string \| null` | nem |
| `jovahagyo_id` | `string \| null` | nem |
| `kategoria` | `Database["public"]["Enums"]["ora_kategoria"]` | igen |
| `kezdo_idopont` | `string` | igen |
| `koltseghely` | `string \| null` | nem |
| `megjegyzes` | `string \| null` | nem |
| `munkaltatoi_dontes` | `Json \| null` | nem |
| `ora` | `number` | igen |
| `org_unit_id` | `string \| null` | nem |
| `potlek_kod` | `string \| null` | nem |
| `projekt` | `string \| null` | nem |
| `tenant_id` | `string` | igen |
| `unnepnapi_ora` | `number` | igen |
| `updated_at` | `string` | igen |
| `user_id` | `string` | igen |
| `vasarnapi_ora` | `number` | igen |
| `zaro_idopont` | `string` | igen |

## `work_time_rules`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `created_at` | `string` | igen |
| `ejszakai_potlek_szazalek` | `number` | igen |
| `ervenyes_ig` | `string \| null` | nem |
| `ervenyes_tol` | `string` | igen |
| `eves_ovt_rendkivuli_max` | `number` | igen |
| `eves_rendkivuli_max` | `number` | igen |
| `eves_ugyelet_rendkivuli_max` | `number` | igen |
| `fenntarto_tipus` | `Database["public"]["Enums"]["fenntarto_tipus"]` | igen |
| `forrasszoveg` | `string \| null` | nem |
| `havi_keszenlet_max` | `number` | igen |
| `havi_ugyelet_keszenlet_max` | `number` | igen |
| `heti_egybefuggo_piheno_ora` | `number` | igen |
| `heti_max_ora` | `number` | igen |
| `heti_max_ora_egeszsegugyi` | `number` | igen |
| `heti_max_ora_ovt` | `number` | igen |
| `id` | `string` | igen |
| `jogszabaly_hivatkozas` | `string \| null` | nem |
| `jogviszony_tipus` | `Database["public"]["Enums"]["jogviszony_tipus"]` | igen |
| `keszenleti_dij_szazalek` | `number` | igen |
| `munkaidokeret_honap` | `number` | igen |
| `munkaszuneti_utan_szabadnap_fizetett` | `boolean` | igen |
| `napi_max_ora` | `number` | igen |
| `napi_max_ora_ugyelettel` | `number` | igen |
| `napi_pihenes_min_ora` | `number` | igen |
| `tenant_id` | `string \| null` | nem |
| `ugyelet_munkaidokeret_terhere` | `boolean` | igen |
| `ugyelet_utan_piheno_nap` | `boolean` | igen |
| `ugyeleti_dij_szazalek` | `number` | igen |
| `unnepnapi_potlek_szazalek` | `number` | igen |
| `updated_at` | `string` | igen |
| `vasarnapi_potlek_szazalek` | `number` | igen |

## `cms_experiment_daily_stats`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `conversion_rate` | `number \| null` | nem |
| `day` | `string \| null` | nem |
| `experiment_id` | `string \| null` | nem |
| `goals` | `number \| null` | nem |
| `variant_id` | `string \| null` | nem |
| `views` | `number \| null` | nem |

## `org_unit_conflicts`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `duty_lines_count` | `number \| null` | nem |
| `duty_lines_without_eligibility` | `number \| null` | nem |
| `mandatory_coverage_count` | `number \| null` | nem |
| `org_unit_id` | `string \| null` | nem |
| `tenant_id` | `string \| null` | nem |

## `profile_capabilities`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `igazolva_at` | `string \| null` | nem |
| `lejarat` | `string \| null` | nem |
| `skill_id` | `string \| null` | nem |
| `skill_kulcs` | `string \| null` | nem |
| `skill_nev` | `string \| null` | nem |
| `specialty_id` | `string \| null` | nem |
| `statusz` | `string \| null` | nem |
| `szint` | `number \| null` | nem |
| `tenant_id` | `string \| null` | nem |
| `user_id` | `string \| null` | nem |

## `profile_scheduling_facts`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `aktiv_constraint_count` | `number \| null` | nem |
| `becenev` | `string \| null` | nem |
| `contact_count` | `number \| null` | nem |
| `egyedulnevelo` | `boolean \| null` | nem |
| `egymas_utani_max_ugyelet` | `number \| null` | nem |
| `email` | `string \| null` | nem |
| `fuggo_tavollet_count` | `number \| null` | nem |
| `havi_max_ugyelet` | `number \| null` | nem |
| `heti_max_ora` | `number \| null` | nem |
| `jovahagyott_tavollet_count` | `number \| null` | nem |
| `kisgyermek_otthon` | `boolean \| null` | nem |
| `last_minute_elerheto` | `boolean \| null` | nem |
| `last_minute_orahatar` | `number \| null` | nem |
| `mentee_count` | `number \| null` | nem |
| `mentor_count` | `number \| null` | nem |
| `min_pihenoido_ora` | `number \| null` | nem |
| `mozgaskorlatozas` | `boolean \| null` | nem |
| `negativ_kapcsolat` | `number \| null` | nem |
| `nyelvek` | `string[] \| null` | nem |
| `pozitiv_kapcsolat` | `number \| null` | nem |
| `preferalt_musakok` | `string[] \| null` | nem |
| `szoptat` | `boolean \| null` | nem |
| `tartos_betegseg` | `boolean \| null` | nem |
| `tavollet_nap_30` | `number \| null` | nem |
| `tavollet_nap_90` | `number \| null` | nem |
| `teljes_nev` | `string \| null` | nem |
| `tenant_id` | `string \| null` | nem |
| `terhes` | `boolean \| null` | nem |
| `tiltott_ejszaka` | `boolean \| null` | nem |
| `tiltott_napok` | `number[] \| null` | nem |
| `tiltott_sugar_zona` | `boolean \| null` | nem |
| `ugyelet_utan_min_ora` | `number \| null` | nem |
| `ugyelet_utan_pihenonap` | `boolean \| null` | nem |
| `user_id` | `string \| null` | nem |
| `utazasi_perc_max` | `number \| null` | nem |
| `van_aktiv_ertesites` | `boolean \| null` | nem |
| `vedendokoru` | `boolean \| null` | nem |

## `v_havi_ledger`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `ejszakai_ora` | `number \| null` | nem |
| `honap_kezdete` | `string \| null` | nem |
| `kategoria` | `Database["public"]["Enums"]["ora_kategoria"] \| null` | nem |
| `ora_osszesen` | `number \| null` | nem |
| `tenant_id` | `string \| null` | nem |
| `unnepnapi_ora` | `number \| null` | nem |
| `user_id` | `string \| null` | nem |
| `vasarnapi_ora` | `number \| null` | nem |

## `v_heti_munkaido`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `het_kezdete` | `string \| null` | nem |
| `kategoria` | `Database["public"]["Enums"]["ora_kategoria"] \| null` | nem |
| `ora_osszesen` | `number \| null` | nem |
| `tenant_id` | `string \| null` | nem |
| `user_id` | `string \| null` | nem |

## `v_napi_pihenes`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `datum` | `string \| null` | nem |
| `elso_kezdes` | `string \| null` | nem |
| `piheno_ora_elozo_naphoz` | `number \| null` | nem |
| `tenant_id` | `string \| null` | nem |
| `user_id` | `string \| null` | nem |
| `utolso_vege` | `string \| null` | nem |

## `v_overtime_ledger_yearly`

| Mező | Típus | Kötelező |
| --- | --- | --- |
| `ev` | `number \| null` | nem |
| `eves_ovt_rendkivuli_max` | `number \| null` | nem |
| `eves_rendkivuli_max` | `number \| null` | nem |
| `eves_ugyelet_rendkivuli_max` | `number \| null` | nem |
| `ovt_ora` | `number \| null` | nem |
| `rendkivuli_kihasznaltsag_szazalek` | `number \| null` | nem |
| `rendkivuli_ora` | `number \| null` | nem |
| `tenant_id` | `string \| null` | nem |
| `ugy_rend_kihasznaltsag_szazalek` | `number \| null` | nem |
| `ugyelet_plus_rendkivuli_ora` | `number \| null` | nem |
| `user_id` | `string \| null` | nem |

## Enum típusok

- `appt_resource_tipus`: `orvos`, `rendelo`, `mindketto`
- `appt_slot_status`: `szabad`, `foglalt`, `letiltott`, `torolt`
- `appt_status`: `foglalt`, `megerositendo`, `lemondva`, `megerkezett`, `befejezett`, `nem_jelent_meg`
- `appt_sync_statusz`: `local_only`, `pending`, `synced`, `conflict`, `failed`
- `assignment_kind`: `varakozas`, `periodikus`, `egyedi`, `foglalashoz`
- `assignment_status`: `tervezett`, `veglegesitett`, `tenyleges`, `torolt`
- `attachment_summary_status`: `pending`, `done`, `failed`, `skipped`
- `attendance_event_type`: `bejelentkezes`, `kijelentkezes`, `szunet_kezdet`, `szunet_veg`, `manualis_korrekcio`
- `attendance_method`: `web`, `mobil`, `nfc`, `qr`, `manualis`, `admin`
- `checkin_method`: `qr`, `kiosk`, `mobile`
- `checkin_status`: `arrived`, `in_room`, `done`
- `cms_audit_action`: `create`, `update`, `delete`, `submit_review`, `approve`, `reject`, `publish`, `unpublish`, `revert`, `restore`
- `cms_workflow_state`: `draft`, `in_review`, `approved`, `published`, `rejected`, `archived`
- `consent_purpose`: `jelenlet_helymeghatarozas`, `jelenlet_eszkozazonosito`, `biometrikus`, `egeszsegugyi_adat`, `paciensi_kommunikacio`, `marketing`, `egyeb`
- `constraint_tipus`: `terhes`, `szoptat`, `kisgyermek_otthon`, `egyedulnevelo`, `tartos_betegseg`, `mozgaskorlatozas`, `vedendokoru`, `egyeb`
- `contact_tipus`: `telefon`, `mobil`, `email`, `signal`, `whatsapp`, `telegram`, `veszhelyzeti_hozzatartozo`, `egyeb`
- `conversation_kind`: `dm`, `group`, `patient_provider`, `patient_team`, `ai_assistant`
- `critical_alert_status`: `open`, `acknowledged`, `resolved`
- `duty_availability_tipus`: `tartalekos`, `behivhato`, `szabad_vagyok`
- `duty_szerep_tipus`: `nappali_ugyelet`, `ejszakai_ugyelet`, `hatter_ugyelet`, `keszenlet`, `muteti_ugyelet`, `egyeb`
- `encounter_tipus`: `ambulans`, `fekvobeteg`, `muteti`, `konzilium`, `telemedicina`, `egyeb`
- `eusztv_tabla_tipus`: `orvos_1mell`, `szakdolgozo_1a_mell`
- `fenntarto_tipus`: `allami`, `onkormanyzati`, `egyhazi`, `egyetemi_klinika`, `maganszektor`, `egyeb`
- `foglalkozas_tipus`: `orvos`, `szakdolgozo`, `egyeb`
- `followup_anchor_event`: `birth`, `surgery_completed`, `discharge`, `visit_completed`
- `followup_enrollment_status`: `active`, `paused`, `completed`, `cancelled`
- `followup_occurrence_status`: `scheduled`, `sent`, `responded`, `missed`, `cancelled`
- `jogviszony_tipus`: `kjt_kozalkalmazott`, `egeszsegugyi_szolgalati`, `munka_tv_kv`, `megbizasi`, `egyeni_vallalkozo`, `tarsas_vallalkozo`, `kozalkalmazotti_tovabbi`, `rezidens_kepzes`, `oszintszerzodes`, `egyeb`
- `kiosk_print_status`: `not_printed`, `printed`, `cancelled`
- `measurement_kind`: `testsuly`, `testmagassag`, `bmi`, `haskorfogat`, `nyakkorfogat`, `vernyomas`, `vercukor`, `testho`, `sport`, `lepes`, `pulzus`, `hrv`, `magzatmozgas`
- `measurement_source`: `kezi`, `wearable`, `eszkoz`
- `mentesseg_ok`: `terhesseg`, `gyermekgondozas`, `kor`, `jogviszony`, `egeszsegugyi`, `egyeb`
- `message_sender_kind`: `user`, `patient`, `ai`, `system`
- `monitoring_alert_kind`: `magzatmozgas_csokkent`, `gdm_vercukor`, `preeclampsia_bp`, `urgent_bp`, `laz`, `szekletveres`, `egyeb`
- `monitoring_alert_severity`: `info`, `figyelem`, `surgos`, `kritikus`
- `monitoring_alert_status`: `open`, `acknowledged`, `resolved`
- `monitoring_program_tipus`: `terhesseg`, `betegseg`, `csaladtervezes`
- `munkaido_keret_tipus`: `heti`, `havi`, `negyedeves`, `eves`, `egyedi`
- `musak_pref`: `nappal`, `delutan`, `ejszaka`, `huszonnegy`
- `nem_tipus`: `ferfi`, `no`, `egyeb`, `nem_nyilatkozik`
- `or_block_statusz_enum`: `allokalt`, `felszabaditott`, `lezart`
- `or_case_prioritas_enum`: `elektiv`, `sürgos`, `azonnali`
- `or_case_statusz_enum`: `tervezett`, `jovahagyott`, `folyamatban`, `elvegzett`, `elhalasztott`, `torolt`
- `or_eroforras_tipus_enum`: `aneszteziologus`, `mutos_szakdolgozo`, `cssd_keszlet`, `pito_agy`, `ito_agy`, `pacu_ebredo`, `verkeszitmeny`, `kepalkotas_intraop`, `patologia_fagyasztott`, `robot_konzol`, `embriologiai_labor`, `neonatologus`, `lezer_eszkoz`, `implantatum`
- `or_resource_req_status_enum`: `igenyelt`, `foglalt`, `nem_elerheto`
- `or_resource_req_when_enum`: `intraop`, `posztop`
- `or_tipus_enum`: `altalanos`, `szuloszoba`, `egynapos_kismuteti`, `onkosebeszet`, `reproduktiv`, `hibrid`, `lezer`, `robot`
- `ora_kategoria`: `rendes`, `ugyelet`, `keszenlet`, `ovt`, `rendkivuli`, `kompenzalo`, `szabadsag`, `tavollet`
- `org_unit_tipus`: `fekvobeteg_osztaly`, `rendelo`, `ambulancia`, `muto`, `kismuto`, `egyeb`, `ito`, `pito`, `egynapos`
- `overtime_order_status`: `tervezett`, `elrendelt`, `teljesitve`, `visszavont`
- `overtime_pref_status`: `aktiv`, `visszavont`, `lejart`
- `paired_shift_tipus`: `egyutt_kivant`, `egyutt_kerult`
- `peer_link_status`: `aktiv`, `jovahagyasra_var`, `jovahagyott`, `elutasitott`
- `peer_link_tipus`: `szivesen_dolgozik_vele`, `nem_dolgozik_vele`, `mentor`, `mentee`
- `q_assignment_status`: `assigned`, `in_progress`, `completed`, `expired`, `cancelled`
- `q_licenc`: `free`, `public_domain`, `who_noncommercial`, `euroqol_licensed`, `pearson_blocked`
- `q_mode`: `klinikai`, `egeszsegfejlesztesi`, `vegyes`
- `qet_event_type`: `appointment_created`, `appointment_scheduled`, `surgery_created`, `surgery_scheduled`, `birth_recorded`, `surgery_completed`, `encounter_discharged`, `visit_completed`
- `reminder_channel`: `notification`, `push`, `email`, `sms`
- `role_kategoria`: `orvos`, `szakdolgozo`, `vezeto`, `admin`
- `schedule_change_request_status`: `pending`, `approved`, `rejected`, `cancelled`
- `schedule_change_request_type`: `cancel`, `swap`
- `staff_level_tipus`: `orvos`, `szakdolgozo`
- `unavailability_status`: `tervezett`, `jovahagyasra_var`, `jovahagyott`, `elutasitott`
- `unavailability_tipus`: `szabadsag`, `betegszabadsag`, `tovabbkepzes`, `konferencia`, `kotelezetts_ugy`, `egyeb_tavollet`
