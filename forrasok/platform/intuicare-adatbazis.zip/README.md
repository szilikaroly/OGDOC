# IntuiCare – adatbázis csomag

Tartalom:
- `schema.sql` – a teljes séma egyben (összes migráció sorrendben). Import: `psql "$DB_URL" -f schema.sql`
- `migrations/` – az eredeti, időbélyeges migrációs fájlok (Supabase CLI: `supabase db push`)
- `database.md` – ember által olvasható mező-referencia (táblák, típusok, nullability, enumok)
- `database-fields.json` – gépi feldolgozásra kész mező-manifeszt
- `types.ts` – generált TypeScript típusok a klienshez

## Importálás új környezetbe
1. Hozz létre egy üres Postgres/Supabase projektet.
2. `psql "$DB_URL" -f schema.sql`
3. Állítsd be az env változókat (VITE_SUPABASE_URL, VITE_SUPABASE_PUBLISHABLE_KEY, VITE_SUPABASE_PROJECT_ID).
4. Auth szolgáltatók (Google/Apple) és storage bucketek konfigurálása.

## Adatok (sorok) exportja
A séma mellett a tényleges adatsorok exportja a Lovable felületén érhető el:
Cloud → Advanced settings → Export data. (Az itt található csomag csak a struktúrát tartalmazza.)
