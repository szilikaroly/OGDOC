-- =====================================================================
-- TELJES ADATBÁZIS SÉMA (generált: minden migráció időrendben)
-- Importálás üres Postgres/Supabase projektbe: psql -f schema.sql
-- Generálva: 2026-09-01T08:53:17.714Z  |  Migrációk: 155
-- =====================================================================


-- ─── 20260618172710_75f7ec47-99e1-4cc7-927a-9937d49ad68a.sql ───

-- ============================================================
-- ENUM TÍPUSOK
-- ============================================================
CREATE TYPE public.foglalkozas_tipus AS ENUM ('orvos', 'szakdolgozo', 'egyeb');
CREATE TYPE public.role_kategoria AS ENUM ('orvos', 'szakdolgozo', 'vezeto', 'admin');
CREATE TYPE public.staff_level_tipus AS ENUM ('orvos', 'szakdolgozo');
CREATE TYPE public.org_unit_tipus AS ENUM ('fekvobeteg_osztaly', 'rendelo', 'ambulancia', 'muto', 'kismuto', 'egyeb');

-- ============================================================
-- TÁBLÁK (sorrend: minden függvényhivatkozás előtt)
-- ============================================================
CREATE TABLE public.tenants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  nev TEXT NOT NULL,
  regio TEXT NOT NULL DEFAULT 'eu-central-1',
  plan TEXT NOT NULL DEFAULT 'starter',
  aktiv BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.tenants TO authenticated;
GRANT ALL ON public.tenants TO service_role;
ALTER TABLE public.tenants ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  tenant_id UUID REFERENCES public.tenants(id) ON DELETE SET NULL,
  teljes_nev TEXT NOT NULL,
  email TEXT NOT NULL,
  foglalkozas_tipus public.foglalkozas_tipus NOT NULL DEFAULT 'egyeb',
  aktiv BOOLEAN NOT NULL DEFAULT true,
  avatar_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_profiles_tenant ON public.profiles(tenant_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  kulcs TEXT NOT NULL UNIQUE,
  megnevezes TEXT NOT NULL,
  kategoria public.role_kategoria NOT NULL,
  sorrend INT NOT NULL DEFAULT 0
);
GRANT SELECT ON public.roles TO authenticated;
GRANT ALL ON public.roles TO service_role;
ALTER TABLE public.roles ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.clinics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  nev TEXT NOT NULL,
  aktiv BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_clinics_tenant ON public.clinics(tenant_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.clinics TO authenticated;
GRANT ALL ON public.clinics TO service_role;
ALTER TABLE public.clinics ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.sites (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  clinic_id UUID NOT NULL REFERENCES public.clinics(id) ON DELETE CASCADE,
  nev TEXT NOT NULL,
  cim TEXT,
  aktiv BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_sites_tenant ON public.sites(tenant_id);
CREATE INDEX idx_sites_clinic ON public.sites(clinic_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.sites TO authenticated;
GRANT ALL ON public.sites TO service_role;
ALTER TABLE public.sites ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.org_units (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  site_id UUID NOT NULL REFERENCES public.sites(id) ON DELETE CASCADE,
  parent_id UUID REFERENCES public.org_units(id) ON DELETE SET NULL,
  nev TEXT NOT NULL,
  tipus public.org_unit_tipus NOT NULL,
  aktiv BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_org_units_tenant ON public.org_units(tenant_id);
CREATE INDEX idx_org_units_site ON public.org_units(site_id);
CREATE INDEX idx_org_units_parent ON public.org_units(parent_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.org_units TO authenticated;
GRANT ALL ON public.org_units TO service_role;
ALTER TABLE public.org_units ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.specialties (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  kod TEXT NOT NULL UNIQUE,
  nev TEXT NOT NULL,
  aktiv BOOLEAN NOT NULL DEFAULT true
);
GRANT SELECT ON public.specialties TO authenticated;
GRANT ALL ON public.specialties TO service_role;
ALTER TABLE public.specialties ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.org_unit_specialties (
  org_unit_id UUID NOT NULL REFERENCES public.org_units(id) ON DELETE CASCADE,
  specialty_id UUID NOT NULL REFERENCES public.specialties(id) ON DELETE CASCADE,
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  PRIMARY KEY (org_unit_id, specialty_id)
);
CREATE INDEX idx_ous_tenant ON public.org_unit_specialties(tenant_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.org_unit_specialties TO authenticated;
GRANT ALL ON public.org_unit_specialties TO service_role;
ALTER TABLE public.org_unit_specialties ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role_id UUID NOT NULL REFERENCES public.roles(id) ON DELETE RESTRICT,
  site_id UUID REFERENCES public.sites(id) ON DELETE CASCADE,
  org_unit_id UUID REFERENCES public.org_units(id) ON DELETE CASCADE,
  ervenyes_tol TIMESTAMPTZ,
  ervenyes_ig TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, user_id, role_id, site_id, org_unit_id)
);
CREATE INDEX idx_user_roles_user ON public.user_roles(user_id);
CREATE INDEX idx_user_roles_tenant ON public.user_roles(tenant_id);
CREATE INDEX idx_user_roles_role ON public.user_roles(role_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.staff_levels (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  tipus public.staff_level_tipus NOT NULL,
  szint TEXT NOT NULL,
  ervenyes_tol DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, tipus)
);
CREATE INDEX idx_staff_levels_user ON public.staff_levels(user_id);
CREATE INDEX idx_staff_levels_tenant ON public.staff_levels(tenant_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.staff_levels TO authenticated;
GRANT ALL ON public.staff_levels TO service_role;
ALTER TABLE public.staff_levels ENABLE ROW LEVEL SECURITY;

-- ============================================================
-- HELPER FÜGGVÉNYEK (most már léteznek a hivatkozott táblák)
-- ============================================================
CREATE OR REPLACE FUNCTION public.current_tenant_id()
RETURNS UUID
LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public
AS $$ SELECT tenant_id FROM public.profiles WHERE id = auth.uid() $$;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role_kulcs TEXT)
RETURNS BOOLEAN
LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles ur
    JOIN public.roles r ON r.id = ur.role_id
    WHERE ur.user_id = _user_id
      AND r.kulcs = _role_kulcs
      AND (ur.ervenyes_tol IS NULL OR ur.ervenyes_tol <= now())
      AND (ur.ervenyes_ig IS NULL OR ur.ervenyes_ig >= now())
  )
$$;

CREATE OR REPLACE FUNCTION public.has_any_role(_user_id UUID, _role_kulcsok TEXT[])
RETURNS BOOLEAN
LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles ur
    JOIN public.roles r ON r.id = ur.role_id
    WHERE ur.user_id = _user_id
      AND r.kulcs = ANY(_role_kulcsok)
      AND (ur.ervenyes_tol IS NULL OR ur.ervenyes_tol <= now())
      AND (ur.ervenyes_ig IS NULL OR ur.ervenyes_ig >= now())
  )
$$;

-- ============================================================
-- RLS POLICIES
-- ============================================================
CREATE POLICY "tenants_select_own" ON public.tenants
  FOR SELECT TO authenticated USING (id = public.current_tenant_id());
CREATE POLICY "tenants_update_admin" ON public.tenants
  FOR UPDATE TO authenticated
  USING (id = public.current_tenant_id() AND public.has_any_role(auth.uid(), ARRAY['tenant_admin','igazgato']))
  WITH CHECK (id = public.current_tenant_id());

CREATE POLICY "profiles_select_self_or_tenant" ON public.profiles
  FOR SELECT TO authenticated
  USING (id = auth.uid() OR (tenant_id IS NOT NULL AND tenant_id = public.current_tenant_id()));
CREATE POLICY "profiles_insert_self" ON public.profiles
  FOR INSERT TO authenticated WITH CHECK (id = auth.uid());
CREATE POLICY "profiles_update_self_or_admin" ON public.profiles
  FOR UPDATE TO authenticated
  USING (
    id = auth.uid()
    OR (tenant_id = public.current_tenant_id()
        AND public.has_any_role(auth.uid(), ARRAY['tenant_admin','igazgato','intezetvezeto']))
  );

CREATE POLICY "roles_select_all" ON public.roles
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "user_roles_select_tenant" ON public.user_roles
  FOR SELECT TO authenticated USING (tenant_id = public.current_tenant_id());
CREATE POLICY "user_roles_write_admin" ON public.user_roles
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
    AND public.has_any_role(auth.uid(), ARRAY['tenant_admin','igazgato','intezetvezeto']))
  WITH CHECK (tenant_id = public.current_tenant_id()
    AND public.has_any_role(auth.uid(), ARRAY['tenant_admin','igazgato','intezetvezeto']));

CREATE POLICY "staff_levels_select_tenant" ON public.staff_levels
  FOR SELECT TO authenticated USING (tenant_id = public.current_tenant_id());
CREATE POLICY "staff_levels_write_admin" ON public.staff_levels
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
    AND public.has_any_role(auth.uid(), ARRAY['tenant_admin','igazgato','intezetvezeto']))
  WITH CHECK (tenant_id = public.current_tenant_id()
    AND public.has_any_role(auth.uid(), ARRAY['tenant_admin','igazgato','intezetvezeto']));

CREATE POLICY "clinics_select_tenant" ON public.clinics
  FOR SELECT TO authenticated USING (tenant_id = public.current_tenant_id());
CREATE POLICY "clinics_write_admin" ON public.clinics
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
    AND public.has_any_role(auth.uid(), ARRAY['tenant_admin','igazgato','intezetvezeto']))
  WITH CHECK (tenant_id = public.current_tenant_id());

CREATE POLICY "sites_select_tenant" ON public.sites
  FOR SELECT TO authenticated USING (tenant_id = public.current_tenant_id());
CREATE POLICY "sites_write_admin" ON public.sites
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
    AND public.has_any_role(auth.uid(), ARRAY['tenant_admin','igazgato','intezetvezeto','telephelyvezeto']))
  WITH CHECK (tenant_id = public.current_tenant_id());

CREATE POLICY "org_units_select_tenant" ON public.org_units
  FOR SELECT TO authenticated USING (tenant_id = public.current_tenant_id());
CREATE POLICY "org_units_write_admin" ON public.org_units
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
    AND public.has_any_role(auth.uid(), ARRAY['tenant_admin','igazgato','intezetvezeto','telephelyvezeto']))
  WITH CHECK (tenant_id = public.current_tenant_id());

CREATE POLICY "specialties_select_all" ON public.specialties
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "specialties_write_admin" ON public.specialties
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'tenant_admin'))
  WITH CHECK (public.has_role(auth.uid(), 'tenant_admin'));

CREATE POLICY "ous_select_tenant" ON public.org_unit_specialties
  FOR SELECT TO authenticated USING (tenant_id = public.current_tenant_id());
CREATE POLICY "ous_write_admin" ON public.org_unit_specialties
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
    AND public.has_any_role(auth.uid(), ARRAY['tenant_admin','igazgato','intezetvezeto','telephelyvezeto']))
  WITH CHECK (tenant_id = public.current_tenant_id());

-- ============================================================
-- TRIGGER: auto profile on signup
-- ============================================================
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, teljes_nev, foglalkozas_tipus)
  VALUES (
    NEW.id, NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'teljes_nev', NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
    'egyeb'
  );
  RETURN NEW;
END; $$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- updated_at
CREATE OR REPLACE FUNCTION public.touch_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public
AS $$ BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

CREATE TRIGGER touch_tenants BEFORE UPDATE ON public.tenants
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER touch_profiles BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER touch_clinics BEFORE UPDATE ON public.clinics
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER touch_sites BEFORE UPDATE ON public.sites
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER touch_org_units BEFORE UPDATE ON public.org_units
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


-- ─── 20260618172738_dcdac6e2-f1e2-4cb6-a88f-1a0b9fe416fe.sql ───

-- ============================================================
-- SECURITY DEFINER függvények: csak authenticated futtathatja
-- ============================================================
REVOKE EXECUTE ON FUNCTION public.current_tenant_id() FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.has_role(UUID, TEXT) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.has_any_role(UUID, TEXT[]) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.touch_updated_at() FROM PUBLIC, anon, authenticated;

GRANT EXECUTE ON FUNCTION public.current_tenant_id() TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_role(UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_any_role(UUID, TEXT[]) TO authenticated;

-- ============================================================
-- SEED: szerepkörök
-- ============================================================
INSERT INTO public.roles (kulcs, megnevezes, kategoria, sorrend) VALUES
  -- Orvos
  ('hallgato',           'Hallgató',                 'orvos', 10),
  ('gyakornok_orvos',    'Gyakornok orvos',          'orvos', 20),
  ('rezidens',           'Rezidens',                 'orvos', 30),
  ('szakgyakornok',      'Szakgyakornok',            'orvos', 40),
  ('vezetorezidens',     'Vezetőrezidens',           'orvos', 50),
  ('szakorvos',          'Szakorvos',                'orvos', 60),
  ('foorvos',            'Főorvos',                  'orvos', 70),
  ('szakteruleti_expert','Szakterületi expert',      'orvos', 80),
  -- Vezetői
  ('ugyeletvezeto',      'Ügyeletvezető',            'vezeto', 100),
  ('telephelyvezeto',    'Telephelyvezető',          'vezeto', 110),
  ('intezetvezeto',      'Intézetvezető',            'vezeto', 120),
  ('igazgato',           'Igazgató',                 'vezeto', 130),
  -- Szakdolgozó / szülésznő / ápoló
  ('tanulo',             'Tanuló',                   'szakdolgozo', 10),
  ('gyakornok_szakd',    'Gyakornok szakdolgozó',    'szakdolgozo', 20),
  ('gyakorlo',           'Gyakorló',                 'szakdolgozo', 30),
  ('pro',                'Pro',                      'szakdolgozo', 40),
  ('mester',             'Mester',                   'szakdolgozo', 50),
  -- Admin
  ('tenant_admin',       'Bérlő admin',              'admin', 1),
  ('beoszto',            'Beosztó',                  'admin', 2);

-- ============================================================
-- SEED: szakterületek
-- ============================================================
INSERT INTO public.specialties (kod, nev) VALUES
  ('HAZIORVOS',  'Háziorvosi'),
  ('SZULNOGY',   'Szülészet-nőgyógyászat'),
  ('ENDOKRIN',   'Endokrinológia'),
  ('BELGYOGY',   'Belgyógyászat'),
  ('SEBESZ',     'Sebészet'),
  ('TRAUMAT',    'Traumatológia'),
  ('ANESZT',     'Aneszteziológia és intenzív terápia'),
  ('GYERMEK',    'Gyermekgyógyászat'),
  ('UROLOGIA',   'Urológia'),
  ('KARDIO',     'Kardiológia');


-- ─── 20260618173202_87c669af-c5bc-4148-a7af-50f32f216ca4.sql ───

-- Új bérlő létrehozható minden hitelesített felhasználó által, ha még nincs hozzárendelve bérlőhöz
CREATE POLICY "tenants_insert_unaffiliated" ON public.tenants
  FOR INSERT TO authenticated
  WITH CHECK (
    public.current_tenant_id() IS NULL
  );

-- Saját első tenant_admin szerepkör felvétele: az alapító user magához tudja rendelni
-- a tenant_admin szerepkört a frissen létrehozott tenantban
CREATE POLICY "user_roles_bootstrap_admin" ON public.user_roles
  FOR INSERT TO authenticated
  WITH CHECK (
    user_id = auth.uid()
    AND role_id IN (SELECT id FROM public.roles WHERE kulcs = 'tenant_admin')
    AND EXISTS (
      SELECT 1 FROM public.tenants t
      WHERE t.id = user_roles.tenant_id
    )
  );


-- ─── 20260618181125_562bfde5-7792-44dd-a8de-95c08cb3b6ab.sql ───

-- 1. Audit log tábla
CREATE TABLE public.admin_audit_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID,
  user_id UUID,
  action TEXT NOT NULL CHECK (action IN ('INSERT','UPDATE','DELETE')),
  table_name TEXT NOT NULL,
  record_id TEXT,
  before_data JSONB,
  after_data JSONB,
  summary TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_audit_tenant_created ON public.admin_audit_log(tenant_id, created_at DESC);
CREATE INDEX idx_audit_user_created ON public.admin_audit_log(user_id, created_at DESC);
CREATE INDEX idx_audit_table ON public.admin_audit_log(table_name, created_at DESC);

GRANT SELECT ON public.admin_audit_log TO authenticated;
GRANT ALL ON public.admin_audit_log TO service_role;

ALTER TABLE public.admin_audit_log ENABLE ROW LEVEL SECURITY;

-- 2. Permission függvény
CREATE OR REPLACE FUNCTION public.has_permission(_user_id UUID, _perm TEXT)
RETURNS BOOLEAN
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT CASE _perm
    WHEN 'manage_tenant'   THEN public.has_any_role(_user_id, ARRAY['tenant_admin'])
    WHEN 'manage_org'      THEN public.has_any_role(_user_id, ARRAY['tenant_admin','igazgato','intezetvezeto','telephelyvezeto'])
    WHEN 'manage_roles'    THEN public.has_any_role(_user_id, ARRAY['tenant_admin','igazgato','intezetvezeto'])
    WHEN 'manage_schedule' THEN public.has_any_role(_user_id, ARRAY['tenant_admin','igazgato','intezetvezeto','telephelyvezeto','ugyeletvezeto','beoszto'])
    WHEN 'manage_training' THEN public.has_any_role(_user_id, ARRAY['tenant_admin','igazgato','intezetvezeto','foorvos'])
    WHEN 'manage_patients' THEN public.has_any_role(_user_id, ARRAY['tenant_admin','igazgato','intezetvezeto','telephelyvezeto','foorvos','szakorvos','rezidens','szakgyakornok','vezetorezidens'])
    WHEN 'view_audit'      THEN public.has_any_role(_user_id, ARRAY['tenant_admin','igazgato','intezetvezeto'])
    WHEN 'view_team'       THEN public.has_any_role(_user_id, ARRAY['tenant_admin','igazgato','intezetvezeto','telephelyvezeto','foorvos','ugyeletvezeto','beoszto'])
    ELSE FALSE
  END
$$;

-- 3. RLS: audit log csak nézhető a saját bérlőn belül és csak jogosultaknak
CREATE POLICY "audit_select_authorized" ON public.admin_audit_log
  FOR SELECT TO authenticated
  USING (
    tenant_id = public.current_tenant_id()
    AND public.has_permission(auth.uid(), 'view_audit')
  );

-- 4. Generikus audit trigger függvény
CREATE OR REPLACE FUNCTION public.audit_trigger_fn()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_tenant_id UUID;
  v_record_id TEXT;
  v_before JSONB;
  v_after JSONB;
BEGIN
  -- tenant_id kinyerése
  IF TG_OP = 'DELETE' THEN
    v_before := to_jsonb(OLD);
    v_after := NULL;
    v_record_id := COALESCE((to_jsonb(OLD)->>'id'), '');
    v_tenant_id := NULLIF(to_jsonb(OLD)->>'tenant_id','')::uuid;
  ELSIF TG_OP = 'UPDATE' THEN
    v_before := to_jsonb(OLD);
    v_after := to_jsonb(NEW);
    v_record_id := COALESCE((to_jsonb(NEW)->>'id'), '');
    v_tenant_id := NULLIF(to_jsonb(NEW)->>'tenant_id','')::uuid;
  ELSE
    v_before := NULL;
    v_after := to_jsonb(NEW);
    v_record_id := COALESCE((to_jsonb(NEW)->>'id'), '');
    v_tenant_id := NULLIF(to_jsonb(NEW)->>'tenant_id','')::uuid;
  END IF;

  -- profiles esetén a profile saját id = user_id, tenant a sorból
  IF TG_TABLE_NAME = 'tenants' AND v_tenant_id IS NULL THEN
    v_tenant_id := v_record_id::uuid;
  END IF;

  INSERT INTO public.admin_audit_log(tenant_id, user_id, action, table_name, record_id, before_data, after_data)
  VALUES (
    COALESCE(v_tenant_id, public.current_tenant_id()),
    auth.uid(),
    TG_OP,
    TG_TABLE_NAME,
    v_record_id,
    v_before,
    v_after
  );

  IF TG_OP = 'DELETE' THEN RETURN OLD; ELSE RETURN NEW; END IF;
END;
$$;

-- 5. Triggerek felrakása
DO $$
DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY['tenants','profiles','clinics','sites','org_units','org_unit_specialties','user_roles','specialties','staff_levels']
  LOOP
    EXECUTE format('DROP TRIGGER IF EXISTS audit_%I ON public.%I', t, t);
    EXECUTE format('CREATE TRIGGER audit_%I AFTER INSERT OR UPDATE OR DELETE ON public.%I FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn()', t, t);
  END LOOP;
END $$;

GRANT EXECUTE ON FUNCTION public.has_permission(UUID, TEXT) TO authenticated;


-- ─── 20260618181558_094ee462-5d3a-48fa-bfa9-73d15f85e7e0.sql ───

CREATE TABLE public.role_permissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  role_kulcs TEXT NOT NULL,
  perm TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (role_kulcs, perm)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.role_permissions TO authenticated;
GRANT ALL ON public.role_permissions TO service_role;

ALTER TABLE public.role_permissions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "role_perms_read_all" ON public.role_permissions
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "role_perms_admin_write" ON public.role_permissions
  FOR ALL TO authenticated
  USING (public.has_any_role(auth.uid(), ARRAY['tenant_admin']))
  WITH CHECK (public.has_any_role(auth.uid(), ARRAY['tenant_admin']));

-- Seed: a jelenlegi has_permission mapping
INSERT INTO public.role_permissions(role_kulcs, perm) VALUES
  ('tenant_admin','manage_tenant'),
  ('tenant_admin','manage_org'),('igazgato','manage_org'),('intezetvezeto','manage_org'),('telephelyvezeto','manage_org'),
  ('tenant_admin','manage_roles'),('igazgato','manage_roles'),('intezetvezeto','manage_roles'),
  ('tenant_admin','manage_schedule'),('igazgato','manage_schedule'),('intezetvezeto','manage_schedule'),('telephelyvezeto','manage_schedule'),('ugyeletvezeto','manage_schedule'),('beoszto','manage_schedule'),
  ('tenant_admin','manage_training'),('igazgato','manage_training'),('intezetvezeto','manage_training'),('foorvos','manage_training'),
  ('tenant_admin','manage_patients'),('igazgato','manage_patients'),('intezetvezeto','manage_patients'),('telephelyvezeto','manage_patients'),('foorvos','manage_patients'),('szakorvos','manage_patients'),('rezidens','manage_patients'),('szakgyakornok','manage_patients'),('vezetorezidens','manage_patients'),
  ('tenant_admin','view_audit'),('igazgato','view_audit'),('intezetvezeto','view_audit'),
  ('tenant_admin','view_team'),('igazgato','view_team'),('intezetvezeto','view_team'),('telephelyvezeto','view_team'),('foorvos','view_team'),('ugyeletvezeto','view_team'),('beoszto','view_team')
ON CONFLICT DO NOTHING;

-- has_permission tábla-alapú
CREATE OR REPLACE FUNCTION public.has_permission(_user_id UUID, _perm TEXT)
RETURNS BOOLEAN
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles ur
    JOIN public.roles r ON r.id = ur.role_id
    JOIN public.role_permissions rp ON rp.role_kulcs = r.kulcs
    WHERE ur.user_id = _user_id
      AND rp.perm = _perm
      AND (ur.ervenyes_tol IS NULL OR ur.ervenyes_tol <= now())
      AND (ur.ervenyes_ig IS NULL OR ur.ervenyes_ig >= now())
  )
$$;


-- ─── 20260618182629_9a3e0e48-252a-4454-af01-2d56d9088995.sql ───

-- ============================================================================
-- 1) Audit log: reason oszlop + post-write update saját bejegyzésre
-- ============================================================================
ALTER TABLE public.admin_audit_log ADD COLUMN IF NOT EXISTS reason TEXT;

CREATE POLICY "audit_update_own_recent" ON public.admin_audit_log
  FOR UPDATE TO authenticated
  USING (user_id = auth.uid() AND created_at > now() - interval '10 minutes')
  WITH CHECK (user_id = auth.uid());

-- ============================================================================
-- 2) role_permissions seed self-heal függvény
-- ============================================================================
CREATE OR REPLACE FUNCTION public.ensure_role_permissions_seed()
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_inserted INTEGER := 0;
  v_count_before INTEGER;
  v_count_after INTEGER;
BEGIN
  SELECT COUNT(*) INTO v_count_before FROM public.role_permissions;

  INSERT INTO public.role_permissions(role_kulcs, perm) VALUES
    ('tenant_admin','manage_tenant'),
    ('tenant_admin','manage_org'),('igazgato','manage_org'),('intezetvezeto','manage_org'),('telephelyvezeto','manage_org'),
    ('tenant_admin','manage_roles'),('igazgato','manage_roles'),('intezetvezeto','manage_roles'),
    ('tenant_admin','manage_schedule'),('igazgato','manage_schedule'),('intezetvezeto','manage_schedule'),('telephelyvezeto','manage_schedule'),('ugyeletvezeto','manage_schedule'),('beoszto','manage_schedule'),
    ('tenant_admin','manage_training'),('igazgato','manage_training'),('intezetvezeto','manage_training'),('foorvos','manage_training'),
    ('tenant_admin','manage_patients'),('igazgato','manage_patients'),('intezetvezeto','manage_patients'),('telephelyvezeto','manage_patients'),('foorvos','manage_patients'),('szakorvos','manage_patients'),('rezidens','manage_patients'),('szakgyakornok','manage_patients'),('vezetorezidens','manage_patients'),
    ('tenant_admin','view_audit'),('igazgato','view_audit'),('intezetvezeto','view_audit'),
    ('tenant_admin','view_team'),('igazgato','view_team'),('intezetvezeto','view_team'),('telephelyvezeto','view_team'),('foorvos','view_team'),('ugyeletvezeto','view_team'),('beoszto','view_team')
  ON CONFLICT DO NOTHING;

  SELECT COUNT(*) INTO v_count_after FROM public.role_permissions;
  v_inserted := v_count_after - v_count_before;
  RETURN v_inserted;
END;
$$;

GRANT EXECUTE ON FUNCTION public.ensure_role_permissions_seed() TO authenticated;

-- Azonnali pótlás (idempotens)
SELECT public.ensure_role_permissions_seed();

-- ============================================================================
-- 3) Updated_at trigger újrahasznosításhoz
-- ============================================================================
-- touch_updated_at már létezik

-- ============================================================================
-- 4) SKILL KATALÓGUS
-- ============================================================================
CREATE TABLE public.skills (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  specialty_id UUID REFERENCES public.specialties(id) ON DELETE SET NULL,
  kulcs TEXT NOT NULL,
  nev TEXT NOT NULL,
  leiras TEXT,
  kategoria TEXT,
  aktiv BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, kulcs)
);
CREATE INDEX idx_skills_tenant ON public.skills(tenant_id);
CREATE INDEX idx_skills_specialty ON public.skills(specialty_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.skills TO authenticated;
GRANT ALL ON public.skills TO service_role;
ALTER TABLE public.skills ENABLE ROW LEVEL SECURITY;

CREATE POLICY "skills_select_tenant" ON public.skills FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY "skills_write_training" ON public.skills FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_training'))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_training'));

CREATE TRIGGER touch_skills BEFORE UPDATE ON public.skills FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER audit_skills AFTER INSERT OR UPDATE OR DELETE ON public.skills FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ============================================================================
-- 5) BEAVATKOZÁS KATALÓGUS
-- ============================================================================
CREATE TABLE public.beavatkozasok (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  specialty_id UUID REFERENCES public.specialties(id) ON DELETE SET NULL,
  kod TEXT,
  nev TEXT NOT NULL,
  leiras TEXT,
  aktiv BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, kod)
);
CREATE INDEX idx_beavatkozasok_tenant ON public.beavatkozasok(tenant_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.beavatkozasok TO authenticated;
GRANT ALL ON public.beavatkozasok TO service_role;
ALTER TABLE public.beavatkozasok ENABLE ROW LEVEL SECURITY;

CREATE POLICY "bea_select_tenant" ON public.beavatkozasok FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY "bea_write_training" ON public.beavatkozasok FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_training'))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_training'));

CREATE TRIGGER touch_bea BEFORE UPDATE ON public.beavatkozasok FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER audit_bea AFTER INSERT OR UPDATE OR DELETE ON public.beavatkozasok FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ============================================================================
-- 6) BEAVATKOZÁS → SKILL
-- ============================================================================
CREATE TABLE public.beavatkozas_skill (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  beavatkozas_id UUID NOT NULL REFERENCES public.beavatkozasok(id) ON DELETE CASCADE,
  skill_id UUID NOT NULL REFERENCES public.skills(id) ON DELETE CASCADE,
  min_szint SMALLINT NOT NULL DEFAULT 1 CHECK (min_szint BETWEEN 1 AND 5),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (beavatkozas_id, skill_id)
);
CREATE INDEX idx_bs_skill ON public.beavatkozas_skill(skill_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.beavatkozas_skill TO authenticated;
GRANT ALL ON public.beavatkozas_skill TO service_role;
ALTER TABLE public.beavatkozas_skill ENABLE ROW LEVEL SECURITY;

CREATE POLICY "bs_select_via_parent" ON public.beavatkozas_skill FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.beavatkozasok b WHERE b.id = beavatkozas_id AND b.tenant_id = public.current_tenant_id()));
CREATE POLICY "bs_write_training" ON public.beavatkozas_skill FOR ALL TO authenticated
  USING (
    public.has_permission(auth.uid(), 'manage_training')
    AND EXISTS (SELECT 1 FROM public.beavatkozasok b WHERE b.id = beavatkozas_id AND b.tenant_id = public.current_tenant_id())
  )
  WITH CHECK (
    public.has_permission(auth.uid(), 'manage_training')
    AND EXISTS (SELECT 1 FROM public.beavatkozasok b WHERE b.id = beavatkozas_id AND b.tenant_id = public.current_tenant_id())
  );

-- ============================================================================
-- 7) KÉPZÉSI PROGRAMOK
-- ============================================================================
CREATE TABLE public.training_programs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  nev TEXT NOT NULL,
  leiras TEXT,
  honap_hossz SMALLINT,
  aktiv BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_tp_tenant ON public.training_programs(tenant_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.training_programs TO authenticated;
GRANT ALL ON public.training_programs TO service_role;
ALTER TABLE public.training_programs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "tp_select_tenant" ON public.training_programs FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY "tp_write_training" ON public.training_programs FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_training'))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_training'));

CREATE TRIGGER touch_tp BEFORE UPDATE ON public.training_programs FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER audit_tp AFTER INSERT OR UPDATE OR DELETE ON public.training_programs FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ============================================================================
-- 8) PROGRAM → SKILL
-- ============================================================================
CREATE TABLE public.training_program_skills (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  program_id UUID NOT NULL REFERENCES public.training_programs(id) ON DELETE CASCADE,
  skill_id UUID NOT NULL REFERENCES public.skills(id) ON DELETE CASCADE,
  cel_szint SMALLINT NOT NULL DEFAULT 3 CHECK (cel_szint BETWEEN 1 AND 5),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (program_id, skill_id)
);
CREATE INDEX idx_tps_skill ON public.training_program_skills(skill_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.training_program_skills TO authenticated;
GRANT ALL ON public.training_program_skills TO service_role;
ALTER TABLE public.training_program_skills ENABLE ROW LEVEL SECURITY;

CREATE POLICY "tps_select_via_parent" ON public.training_program_skills FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.training_programs p WHERE p.id = program_id AND p.tenant_id = public.current_tenant_id()));
CREATE POLICY "tps_write_training" ON public.training_program_skills FOR ALL TO authenticated
  USING (
    public.has_permission(auth.uid(), 'manage_training')
    AND EXISTS (SELECT 1 FROM public.training_programs p WHERE p.id = program_id AND p.tenant_id = public.current_tenant_id())
  )
  WITH CHECK (
    public.has_permission(auth.uid(), 'manage_training')
    AND EXISTS (SELECT 1 FROM public.training_programs p WHERE p.id = program_id AND p.tenant_id = public.current_tenant_id())
  );

-- ============================================================================
-- 9) PROFILE_SKILLS
-- ============================================================================
CREATE TABLE public.profile_skills (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  skill_id UUID NOT NULL REFERENCES public.skills(id) ON DELETE CASCADE,
  szint SMALLINT NOT NULL DEFAULT 1 CHECK (szint BETWEEN 1 AND 5),
  igazolva_at DATE,
  lejarat DATE,
  megjegyzes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, skill_id)
);
CREATE INDEX idx_ps_user ON public.profile_skills(user_id);
CREATE INDEX idx_ps_skill ON public.profile_skills(skill_id);
CREATE INDEX idx_ps_tenant ON public.profile_skills(tenant_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_skills TO authenticated;
GRANT ALL ON public.profile_skills TO service_role;
ALTER TABLE public.profile_skills ENABLE ROW LEVEL SECURITY;

CREATE POLICY "ps_select_own_or_team" ON public.profile_skills FOR SELECT TO authenticated
  USING (
    user_id = auth.uid()
    OR (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'view_team'))
  );
CREATE POLICY "ps_write_own_or_training" ON public.profile_skills FOR ALL TO authenticated
  USING (
    (user_id = auth.uid() AND tenant_id = public.current_tenant_id())
    OR (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_training'))
  )
  WITH CHECK (
    (user_id = auth.uid() AND tenant_id = public.current_tenant_id())
    OR (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_training'))
  );

CREATE TRIGGER touch_ps BEFORE UPDATE ON public.profile_skills FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER audit_ps AFTER INSERT OR UPDATE OR DELETE ON public.profile_skills FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ============================================================================
-- 10) PROFILE_CERTIFICATIONS
-- ============================================================================
CREATE TABLE public.profile_certifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  nev TEXT NOT NULL,
  tipus TEXT NOT NULL CHECK (tipus IN ('oklevel','szakvizsga','licenc','tovabbkepzes','egyeb')),
  kibocsato TEXT,
  szam TEXT,
  kibocsatva DATE,
  lejarat DATE,
  dokumentum_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_pc_user ON public.profile_certifications(user_id);
CREATE INDEX idx_pc_tenant ON public.profile_certifications(tenant_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_certifications TO authenticated;
GRANT ALL ON public.profile_certifications TO service_role;
ALTER TABLE public.profile_certifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "pc_select_own_or_team" ON public.profile_certifications FOR SELECT TO authenticated
  USING (
    user_id = auth.uid()
    OR (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'view_team'))
  );
CREATE POLICY "pc_write_own_or_training" ON public.profile_certifications FOR ALL TO authenticated
  USING (
    (user_id = auth.uid() AND tenant_id = public.current_tenant_id())
    OR (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_training'))
  )
  WITH CHECK (
    (user_id = auth.uid() AND tenant_id = public.current_tenant_id())
    OR (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_training'))
  );

CREATE TRIGGER touch_pc BEFORE UPDATE ON public.profile_certifications FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER audit_pc AFTER INSERT OR UPDATE OR DELETE ON public.profile_certifications FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ============================================================================
-- 11) PROFILE_TRAININGS (folyamatban lévő)
-- ============================================================================
CREATE TABLE public.profile_trainings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  program_id UUID REFERENCES public.training_programs(id) ON DELETE SET NULL,
  nev TEXT NOT NULL,
  kezdes DATE,
  varhato_veg DATE,
  elorehaladas_pct SMALLINT NOT NULL DEFAULT 0 CHECK (elorehaladas_pct BETWEEN 0 AND 100),
  statusz TEXT NOT NULL DEFAULT 'folyamatban' CHECK (statusz IN ('folyamatban','befejezett','megszakitott','tervezett')),
  megjegyzes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_pt_user ON public.profile_trainings(user_id);
CREATE INDEX idx_pt_tenant ON public.profile_trainings(tenant_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_trainings TO authenticated;
GRANT ALL ON public.profile_trainings TO service_role;
ALTER TABLE public.profile_trainings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "pt_select_own_or_team" ON public.profile_trainings FOR SELECT TO authenticated
  USING (
    user_id = auth.uid()
    OR (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'view_team'))
  );
CREATE POLICY "pt_write_own_or_training" ON public.profile_trainings FOR ALL TO authenticated
  USING (
    (user_id = auth.uid() AND tenant_id = public.current_tenant_id())
    OR (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_training'))
  )
  WITH CHECK (
    (user_id = auth.uid() AND tenant_id = public.current_tenant_id())
    OR (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_training'))
  );

CREATE TRIGGER touch_pt BEFORE UPDATE ON public.profile_trainings FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER audit_pt AFTER INSERT OR UPDATE OR DELETE ON public.profile_trainings FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ============================================================================
-- 12) PROFILE_BEAVATKOZASOK (gyakorlatszám)
-- ============================================================================
CREATE TABLE public.profile_beavatkozasok (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  beavatkozas_id UUID NOT NULL REFERENCES public.beavatkozasok(id) ON DELETE CASCADE,
  alkalom SMALLINT NOT NULL DEFAULT 1,
  datum DATE,
  megjegyzes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_pb_user ON public.profile_beavatkozasok(user_id);
CREATE INDEX idx_pb_tenant ON public.profile_beavatkozasok(tenant_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_beavatkozasok TO authenticated;
GRANT ALL ON public.profile_beavatkozasok TO service_role;
ALTER TABLE public.profile_beavatkozasok ENABLE ROW LEVEL SECURITY;

CREATE POLICY "pb_select_own_or_team" ON public.profile_beavatkozasok FOR SELECT TO authenticated
  USING (
    user_id = auth.uid()
    OR (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'view_team'))
  );
CREATE POLICY "pb_write_own_or_training" ON public.profile_beavatkozasok FOR ALL TO authenticated
  USING (
    (user_id = auth.uid() AND tenant_id = public.current_tenant_id())
    OR (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_training'))
  )
  WITH CHECK (
    (user_id = auth.uid() AND tenant_id = public.current_tenant_id())
    OR (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_training'))
  );

CREATE TRIGGER touch_pb BEFORE UPDATE ON public.profile_beavatkozasok FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER audit_pb AFTER INSERT OR UPDATE OR DELETE ON public.profile_beavatkozasok FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ============================================================================
-- 13) profile_capabilities VIEW (érvényes skill-ek)
-- ============================================================================
CREATE OR REPLACE VIEW public.profile_capabilities
WITH (security_invoker=on) AS
SELECT
  ps.user_id,
  ps.tenant_id,
  ps.skill_id,
  s.kulcs AS skill_kulcs,
  s.nev AS skill_nev,
  s.specialty_id,
  ps.szint,
  ps.igazolva_at,
  ps.lejarat,
  CASE
    WHEN ps.lejarat IS NULL THEN 'ervenyes'
    WHEN ps.lejarat < CURRENT_DATE THEN 'lejart'
    WHEN ps.lejarat < CURRENT_DATE + INTERVAL '30 days' THEN 'hamarosan'
    ELSE 'ervenyes'
  END AS statusz
FROM public.profile_skills ps
JOIN public.skills s ON s.id = ps.skill_id;

GRANT SELECT ON public.profile_capabilities TO authenticated;


-- ─── 20260618185749_016f260f-e8c9-4e49-8d14-1c83bbd9004f.sql ───
-- =========================================================
-- KARAKTERLAP BŐVÍTÉS — KÖR A
-- profiles bővítés + profile_contacts + profile_preferences
-- =========================================================

-- 1. profiles bővítés ---------------------------------------------------
DO $$ BEGIN
  CREATE TYPE public.nem_tipus AS ENUM ('ferfi','no','egyeb','nem_nyilatkozik');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS becenev TEXT,
  ADD COLUMN IF NOT EXISTS szuletesi_datum DATE,
  ADD COLUMN IF NOT EXISTS nem public.nem_tipus,
  ADD COLUMN IF NOT EXISTS bemutatkozas TEXT,
  ADD COLUMN IF NOT EXISTS bemutatkozas_publikus BOOLEAN NOT NULL DEFAULT false;

ALTER TABLE public.profiles
  DROP CONSTRAINT IF EXISTS profiles_bemutatkozas_len_chk;
ALTER TABLE public.profiles
  ADD CONSTRAINT profiles_bemutatkozas_len_chk
  CHECK (bemutatkozas IS NULL OR char_length(bemutatkozas) <= 2000);

-- 2. profile_contacts ---------------------------------------------------
DO $$ BEGIN
  CREATE TYPE public.contact_tipus AS ENUM (
    'telefon','mobil','email','signal','whatsapp','telegram',
    'veszhelyzeti_hozzatartozo','egyeb'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS public.profile_contacts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  tenant_id UUID REFERENCES public.tenants(id) ON DELETE SET NULL,
  tipus public.contact_tipus NOT NULL,
  cimke TEXT,
  ertek TEXT NOT NULL,
  is_primary BOOLEAN NOT NULL DEFAULT false,
  sorrend INT NOT NULL DEFAULT 0,
  csak_vesz_eseten BOOLEAN NOT NULL DEFAULT false,
  ertesites_engedelyezve BOOLEAN NOT NULL DEFAULT true,
  megjegyzes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT profile_contacts_ertek_len_chk CHECK (char_length(ertek) BETWEEN 1 AND 255)
);
CREATE INDEX IF NOT EXISTS idx_profile_contacts_user ON public.profile_contacts(user_id);
CREATE INDEX IF NOT EXISTS idx_profile_contacts_tenant ON public.profile_contacts(tenant_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_contacts TO authenticated;
GRANT ALL ON public.profile_contacts TO service_role;

ALTER TABLE public.profile_contacts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS profile_contacts_select ON public.profile_contacts;
CREATE POLICY profile_contacts_select ON public.profile_contacts
  FOR SELECT TO authenticated
  USING (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_tenant')
  );

DROP POLICY IF EXISTS profile_contacts_write ON public.profile_contacts;
CREATE POLICY profile_contacts_write ON public.profile_contacts
  FOR ALL TO authenticated
  USING (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_tenant')
  )
  WITH CHECK (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_tenant')
  );

DROP TRIGGER IF EXISTS trg_profile_contacts_touch ON public.profile_contacts;
CREATE TRIGGER trg_profile_contacts_touch
  BEFORE UPDATE ON public.profile_contacts
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

DROP TRIGGER IF EXISTS trg_profile_contacts_audit ON public.profile_contacts;
CREATE TRIGGER trg_profile_contacts_audit
  AFTER INSERT OR UPDATE OR DELETE ON public.profile_contacts
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- 3. profile_preferences (1:1) -----------------------------------------
DO $$ BEGIN
  CREATE TYPE public.musak_pref AS ENUM ('nappal','delutan','ejszaka','huszonnegy');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS public.profile_preferences (
  user_id UUID PRIMARY KEY REFERENCES public.profiles(id) ON DELETE CASCADE,
  tenant_id UUID REFERENCES public.tenants(id) ON DELETE SET NULL,
  heti_max_ora INT,
  havi_max_ugyelet INT,
  preferalt_musakok public.musak_pref[] NOT NULL DEFAULT '{}',
  tiltott_napok INT[] NOT NULL DEFAULT '{}',          -- 0=vasárnap … 6=szombat (ISO-független, doc-on belüli)
  ugyelet_utan_pihenonap BOOLEAN NOT NULL DEFAULT true,
  ugyelet_utan_min_ora INT NOT NULL DEFAULT 24,
  egymas_utani_max_ugyelet INT NOT NULL DEFAULT 1,
  last_minute_elerheto BOOLEAN NOT NULL DEFAULT false,
  last_minute_orahatar INT,                            -- pl. 4 = max 4 órán belüli értesítésre is bevállalja
  utazasi_perc_max INT,
  nyelvek TEXT[] NOT NULL DEFAULT '{}',
  megjegyzes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT pref_heti_ora_chk CHECK (heti_max_ora IS NULL OR heti_max_ora BETWEEN 0 AND 168),
  CONSTRAINT pref_pihenoora_chk CHECK (ugyelet_utan_min_ora BETWEEN 0 AND 96),
  CONSTRAINT pref_egymas_chk CHECK (egymas_utani_max_ugyelet BETWEEN 0 AND 10)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_preferences TO authenticated;
GRANT ALL ON public.profile_preferences TO service_role;

ALTER TABLE public.profile_preferences ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS profile_preferences_select ON public.profile_preferences;
CREATE POLICY profile_preferences_select ON public.profile_preferences
  FOR SELECT TO authenticated
  USING (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_schedule')
    OR public.has_permission(auth.uid(), 'manage_tenant')
  );

DROP POLICY IF EXISTS profile_preferences_write ON public.profile_preferences;
CREATE POLICY profile_preferences_write ON public.profile_preferences
  FOR ALL TO authenticated
  USING (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_tenant')
  )
  WITH CHECK (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_tenant')
  );

DROP TRIGGER IF EXISTS trg_profile_preferences_touch ON public.profile_preferences;
CREATE TRIGGER trg_profile_preferences_touch
  BEFORE UPDATE ON public.profile_preferences
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

DROP TRIGGER IF EXISTS trg_profile_preferences_audit ON public.profile_preferences;
CREATE TRIGGER trg_profile_preferences_audit
  AFTER INSERT OR UPDATE OR DELETE ON public.profile_preferences
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();


-- ─── 20260618190701_fe1b8a92-4041-4fbe-9dce-e89c7b407e77.sql ───

-- Enums
CREATE TYPE public.unavailability_tipus AS ENUM (
  'szabadsag','betegszabadsag','tovabbkepzes','konferencia','kotelezetts_ugy','egyeb_tavollet'
);
CREATE TYPE public.unavailability_status AS ENUM (
  'tervezett','jovahagyasra_var','jovahagyott','elutasitott'
);
CREATE TYPE public.constraint_tipus AS ENUM (
  'terhes','szoptat','kisgyermek_otthon','egyedulnevelo','tartos_betegseg','mozgaskorlatozas','vedendokoru','egyeb'
);

-- ===== profile_unavailability =====
CREATE TABLE public.profile_unavailability (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  tenant_id UUID REFERENCES public.tenants(id) ON DELETE SET NULL,
  tipus public.unavailability_tipus NOT NULL,
  kezdo_datum DATE NOT NULL,
  zaro_datum DATE NOT NULL,
  csak_delelott BOOLEAN NOT NULL DEFAULT false,
  csak_delutan BOOLEAN NOT NULL DEFAULT false,
  leiras TEXT,
  training_program_id UUID REFERENCES public.training_programs(id) ON DELETE SET NULL,
  status public.unavailability_status NOT NULL DEFAULT 'tervezett',
  jovahagyo_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  jovahagyas_at TIMESTAMPTZ,
  jovahagyas_indok TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT profile_unavailability_datum_chk CHECK (zaro_datum >= kezdo_datum)
);
CREATE INDEX idx_profile_unavailability_user ON public.profile_unavailability(user_id);
CREATE INDEX idx_profile_unavailability_tenant ON public.profile_unavailability(tenant_id);
CREATE INDEX idx_profile_unavailability_datum ON public.profile_unavailability(kezdo_datum, zaro_datum);
CREATE INDEX idx_profile_unavailability_status ON public.profile_unavailability(status);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_unavailability TO authenticated;
GRANT ALL ON public.profile_unavailability TO service_role;

ALTER TABLE public.profile_unavailability ENABLE ROW LEVEL SECURITY;

CREATE POLICY "profile_unavailability_select" ON public.profile_unavailability
  FOR SELECT TO authenticated
  USING (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_schedule')
    OR public.has_permission(auth.uid(), 'manage_tenant')
  );

CREATE POLICY "profile_unavailability_write" ON public.profile_unavailability
  FOR ALL TO authenticated
  USING (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_schedule')
    OR public.has_permission(auth.uid(), 'manage_tenant')
  )
  WITH CHECK (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_schedule')
    OR public.has_permission(auth.uid(), 'manage_tenant')
  );

CREATE TRIGGER trg_profile_unavailability_touch
  BEFORE UPDATE ON public.profile_unavailability
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TRIGGER trg_profile_unavailability_audit
  AFTER INSERT OR UPDATE OR DELETE ON public.profile_unavailability
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ===== profile_constraints =====
CREATE TABLE public.profile_constraints (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  tenant_id UUID REFERENCES public.tenants(id) ON DELETE SET NULL,
  tipus public.constraint_tipus NOT NULL,
  ervenyes_tol DATE NOT NULL DEFAULT CURRENT_DATE,
  ervenyes_ig DATE,
  igazolas_url TEXT,
  hr_megjegyzes TEXT,
  megjegyzes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT profile_constraints_datum_chk CHECK (ervenyes_ig IS NULL OR ervenyes_ig >= ervenyes_tol)
);
CREATE INDEX idx_profile_constraints_user ON public.profile_constraints(user_id);
CREATE INDEX idx_profile_constraints_tenant ON public.profile_constraints(tenant_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_constraints TO authenticated;
GRANT ALL ON public.profile_constraints TO service_role;

ALTER TABLE public.profile_constraints ENABLE ROW LEVEL SECURITY;

CREATE POLICY "profile_constraints_select" ON public.profile_constraints
  FOR SELECT TO authenticated
  USING (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_tenant')
  );

CREATE POLICY "profile_constraints_write" ON public.profile_constraints
  FOR ALL TO authenticated
  USING (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_tenant')
  )
  WITH CHECK (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_tenant')
  );

CREATE TRIGGER trg_profile_constraints_touch
  BEFORE UPDATE ON public.profile_constraints
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TRIGGER trg_profile_constraints_audit
  AFTER INSERT OR UPDATE OR DELETE ON public.profile_constraints
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();


-- ─── 20260618192607_afee431b-40fd-42c5-a3e8-fd8820e7b7a1.sql ───

-- Protect HR-only column on profile_constraints: only manage_tenant may write hr_megjegyzes.
-- Unauthorized attempts are logged to admin_audit_log and blocked.

CREATE OR REPLACE FUNCTION public.profile_constraints_protect_hr_note()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_is_hr boolean := COALESCE(public.has_permission(v_uid, 'manage_tenant'), false);
  v_changed boolean := false;
BEGIN
  IF TG_OP = 'INSERT' THEN
    v_changed := NEW.hr_megjegyzes IS NOT NULL;
  ELSIF TG_OP = 'UPDATE' THEN
    v_changed := COALESCE(NEW.hr_megjegyzes, '') IS DISTINCT FROM COALESCE(OLD.hr_megjegyzes, '');
  END IF;

  IF v_changed AND NOT v_is_hr THEN
    -- audit the forbidden write attempt
    INSERT INTO public.admin_audit_log(tenant_id, user_id, action, table_name, record_id, before_data, after_data)
    VALUES (
      COALESCE(NEW.tenant_id, public.current_tenant_id()),
      v_uid,
      'FORBIDDEN_WRITE_HR_NOTE',
      TG_TABLE_NAME,
      COALESCE(NEW.id::text, ''),
      CASE WHEN TG_OP = 'UPDATE' THEN jsonb_build_object('hr_megjegyzes', OLD.hr_megjegyzes) ELSE NULL END,
      jsonb_build_object('attempted_hr_megjegyzes', NEW.hr_megjegyzes)
    );
    RAISE EXCEPTION 'A HR megjegyzés mezőt csak tenant-admin (HR) szerepkör módosíthatja.'
      USING ERRCODE = '42501';
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_profile_constraints_protect_hr_note ON public.profile_constraints;
CREATE TRIGGER trg_profile_constraints_protect_hr_note
  BEFORE INSERT OR UPDATE ON public.profile_constraints
  FOR EACH ROW EXECUTE FUNCTION public.profile_constraints_protect_hr_note();

-- Approval workflow guard on profile_unavailability:
-- - status transitions to jovahagyott/elutasitott require manage_schedule or manage_tenant
-- - the approver cannot be the same user as the request owner (no self-approval)
-- - rejection requires a non-empty jovahagyas_indok
CREATE OR REPLACE FUNCTION public.profile_unavailability_guard()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_can_approve boolean;
BEGIN
  IF TG_OP = 'UPDATE' AND NEW.status IS DISTINCT FROM OLD.status THEN
    IF NEW.status IN ('jovahagyott', 'elutasitott') THEN
      v_can_approve := COALESCE(public.has_permission(v_uid, 'manage_schedule'), false)
                    OR COALESCE(public.has_permission(v_uid, 'manage_tenant'), false);
      IF NOT v_can_approve THEN
        INSERT INTO public.admin_audit_log(tenant_id, user_id, action, table_name, record_id, before_data, after_data)
        VALUES (COALESCE(NEW.tenant_id, public.current_tenant_id()), v_uid, 'FORBIDDEN_APPROVAL',
                TG_TABLE_NAME, NEW.id::text,
                jsonb_build_object('status', OLD.status),
                jsonb_build_object('status', NEW.status));
        RAISE EXCEPTION 'Nincs jogosultsága a jóváhagyáshoz/elutasításhoz.' USING ERRCODE = '42501';
      END IF;
      IF NEW.user_id = v_uid THEN
        RAISE EXCEPTION 'A saját kérelmét nem hagyhatja jóvá / utasíthatja el.' USING ERRCODE = '42501';
      END IF;
      IF NEW.status = 'elutasitott' AND COALESCE(btrim(NEW.jovahagyas_indok), '') = '' THEN
        RAISE EXCEPTION 'Elutasításhoz kötelező az indoklás.' USING ERRCODE = '22023';
      END IF;
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_profile_unavailability_guard ON public.profile_unavailability;
CREATE TRIGGER trg_profile_unavailability_guard
  BEFORE UPDATE ON public.profile_unavailability
  FOR EACH ROW EXECUTE FUNCTION public.profile_unavailability_guard();


-- ─── 20260618193023_b5ebfdbc-9bc7-400c-a68d-55f357aa5361.sql ───

-- 1) profile_beavatkozasok bővítése
ALTER TABLE public.profile_beavatkozasok
  ADD COLUMN IF NOT EXISTS mentor_igazolt boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS mentor_user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS bizonyitek_url text;

-- 2) peer link enums
DO $$ BEGIN
  CREATE TYPE public.peer_link_tipus AS ENUM ('szivesen_dolgozik_vele','nem_dolgozik_vele','mentor','mentee');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.peer_link_status AS ENUM ('aktiv','jovahagyasra_var','jovahagyott','elutasitott');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- 3) profile_peer_links tábla
CREATE TABLE IF NOT EXISTS public.profile_peer_links (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  from_user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  to_user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  tipus public.peer_link_tipus NOT NULL,
  suly smallint,
  indoklas text,
  status public.peer_link_status NOT NULL DEFAULT 'aktiv',
  jovahagyo_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  jovahagyas_at timestamptz,
  jovahagyas_indok text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT peer_links_no_self CHECK (from_user_id <> to_user_id),
  CONSTRAINT peer_links_suly_range CHECK (suly IS NULL OR (suly BETWEEN 1 AND 5)),
  CONSTRAINT peer_links_unique UNIQUE (from_user_id, to_user_id, tipus)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_peer_links TO authenticated;
GRANT ALL ON public.profile_peer_links TO service_role;

ALTER TABLE public.profile_peer_links ENABLE ROW LEVEL SECURITY;

-- olvasás: saját kapcsolatok (mindkét irány) + beosztás/HR
CREATE POLICY profile_peer_links_select ON public.profile_peer_links
  FOR SELECT
  USING (
    from_user_id = auth.uid()
    OR to_user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_schedule')
    OR public.has_permission(auth.uid(), 'manage_tenant')
  );

-- írás: saját bejegyzéseit a forrás felhasználó kezeli; HR/beosztásvezető is szerkeszthet
CREATE POLICY profile_peer_links_insert ON public.profile_peer_links
  FOR INSERT
  WITH CHECK (
    from_user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_schedule')
    OR public.has_permission(auth.uid(), 'manage_tenant')
  );

CREATE POLICY profile_peer_links_update ON public.profile_peer_links
  FOR UPDATE
  USING (
    from_user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_schedule')
    OR public.has_permission(auth.uid(), 'manage_tenant')
  )
  WITH CHECK (
    from_user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_schedule')
    OR public.has_permission(auth.uid(), 'manage_tenant')
  );

CREATE POLICY profile_peer_links_delete ON public.profile_peer_links
  FOR DELETE
  USING (
    from_user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_tenant')
  );

-- audit + touch
CREATE TRIGGER audit_ppl AFTER INSERT OR UPDATE OR DELETE ON public.profile_peer_links
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();
CREATE TRIGGER touch_ppl BEFORE UPDATE ON public.profile_peer_links
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- 4) negatív kapcsolat HR-jóváhagyásához trigger
CREATE OR REPLACE FUNCTION public.profile_peer_links_guard()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_is_hr boolean := COALESCE(public.has_permission(v_uid, 'manage_tenant'), false);
BEGIN
  -- negatív kapcsolat alapból jóváhagyásra vár
  IF TG_OP = 'INSERT' THEN
    IF NEW.tipus = 'nem_dolgozik_vele' AND NOT v_is_hr THEN
      NEW.status := 'jovahagyasra_var';
    END IF;
  END IF;

  -- státusz-átmenet jóváhagyott/elutasított csak HR-rel
  IF TG_OP = 'UPDATE' AND NEW.status IS DISTINCT FROM OLD.status
     AND NEW.status IN ('jovahagyott','elutasitott') THEN
    IF NOT v_is_hr THEN
      INSERT INTO public.admin_audit_log(tenant_id, user_id, action, table_name, record_id, before_data, after_data)
      VALUES (COALESCE(NEW.tenant_id, public.current_tenant_id()), v_uid, 'FORBIDDEN_APPROVAL',
              TG_TABLE_NAME, NEW.id::text,
              jsonb_build_object('status', OLD.status),
              jsonb_build_object('status', NEW.status));
      RAISE EXCEPTION 'Negatív kapcsolat jóváhagyása csak HR (tenant-admin) jogosultsággal lehetséges.'
        USING ERRCODE = '42501';
    END IF;
    IF NEW.from_user_id = v_uid OR NEW.to_user_id = v_uid THEN
      RAISE EXCEPTION 'Saját kapcsolatát nem hagyhatja jóvá.' USING ERRCODE = '42501';
    END IF;
    IF NEW.status = 'elutasitott' AND COALESCE(btrim(NEW.jovahagyas_indok), '') = '' THEN
      RAISE EXCEPTION 'Elutasításhoz kötelező az indoklás.' USING ERRCODE = '22023';
    END IF;
    NEW.jovahagyo_id := v_uid;
    NEW.jovahagyas_at := now();
  END IF;

  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_ppl_guard
  BEFORE INSERT OR UPDATE ON public.profile_peer_links
  FOR EACH ROW EXECUTE FUNCTION public.profile_peer_links_guard();


-- ─── 20260618193641_ac033a9f-52af-4f55-a39f-e1b86e46aee2.sql ───
DROP VIEW IF EXISTS public.profile_scheduling_facts CASCADE;

CREATE VIEW public.profile_scheduling_facts
WITH (security_invoker = true) AS
WITH
  c_agg AS (
    SELECT
      user_id,
      bool_or(tipus = 'terhes' AND (ervenyes_ig IS NULL OR ervenyes_ig >= CURRENT_DATE)) AS terhes,
      bool_or(tipus = 'szoptat' AND (ervenyes_ig IS NULL OR ervenyes_ig >= CURRENT_DATE)) AS szoptat,
      bool_or(tipus = 'kisgyermek_otthon' AND (ervenyes_ig IS NULL OR ervenyes_ig >= CURRENT_DATE)) AS kisgyermek_otthon,
      bool_or(tipus = 'egyedulnevelo' AND (ervenyes_ig IS NULL OR ervenyes_ig >= CURRENT_DATE)) AS egyedulnevelo,
      bool_or(tipus = 'tartos_betegseg' AND (ervenyes_ig IS NULL OR ervenyes_ig >= CURRENT_DATE)) AS tartos_betegseg,
      bool_or(tipus = 'mozgaskorlatozas' AND (ervenyes_ig IS NULL OR ervenyes_ig >= CURRENT_DATE)) AS mozgaskorlatozas,
      bool_or(tipus = 'vedendokoru' AND (ervenyes_ig IS NULL OR ervenyes_ig >= CURRENT_DATE)) AS vedendokoru,
      count(*) FILTER (WHERE (ervenyes_ig IS NULL OR ervenyes_ig >= CURRENT_DATE))::int AS aktiv_constraint_count
    FROM public.profile_constraints
    GROUP BY user_id
  ),
  u_agg AS (
    SELECT
      user_id,
      COALESCE(SUM(
        CASE WHEN status = 'jovahagyott'
             AND kezdo_datum <= (CURRENT_DATE + INTERVAL '30 day')::date
             AND zaro_datum >= CURRENT_DATE
        THEN (LEAST(zaro_datum, (CURRENT_DATE + INTERVAL '30 day')::date)
              - GREATEST(kezdo_datum, CURRENT_DATE) + 1) END
      ), 0)::int AS tavollet_nap_30,
      COALESCE(SUM(
        CASE WHEN status = 'jovahagyott'
             AND kezdo_datum <= (CURRENT_DATE + INTERVAL '90 day')::date
             AND zaro_datum >= CURRENT_DATE
        THEN (LEAST(zaro_datum, (CURRENT_DATE + INTERVAL '90 day')::date)
              - GREATEST(kezdo_datum, CURRENT_DATE) + 1) END
      ), 0)::int AS tavollet_nap_90,
      count(*) FILTER (WHERE status = 'jovahagyasra_var')::int AS fuggo_tavollet_count,
      count(*) FILTER (WHERE status = 'jovahagyott' AND zaro_datum >= CURRENT_DATE)::int AS jovahagyott_tavollet_count
    FROM public.profile_unavailability
    GROUP BY user_id
  ),
  p_agg AS (
    SELECT
      from_user_id AS user_id,
      count(*) FILTER (WHERE tipus = 'szivesen_dolgozik_vele' AND status = 'aktiv')::int AS pozitiv_kapcsolat,
      count(*) FILTER (WHERE tipus = 'nem_dolgozik_vele' AND status = 'jovahagyott')::int AS negativ_kapcsolat,
      count(*) FILTER (WHERE tipus = 'mentor' AND status = 'aktiv')::int AS mentor_count,
      count(*) FILTER (WHERE tipus = 'mentee' AND status = 'aktiv')::int AS mentee_count
    FROM public.profile_peer_links
    GROUP BY from_user_id
  ),
  ct_agg AS (
    SELECT
      user_id,
      count(*)::int AS contact_count,
      bool_or(is_primary AND ertesites_engedelyezve) AS van_aktiv_ertesites
    FROM public.profile_contacts
    GROUP BY user_id
  )
SELECT
  pr.id AS user_id,
  pr.tenant_id,
  pr.teljes_nev,
  pr.becenev,
  pr.foglalkozas_tipus,
  pr.email,
  pp.heti_max_ora,
  pp.havi_max_ugyelet,
  COALESCE(pp.ugyelet_utan_pihenonap, false) AS ugyelet_utan_pihenonap,
  COALESCE(pp.ugyelet_utan_min_ora, 0) AS ugyelet_utan_min_ora,
  COALESCE(pp.egymas_utani_max_ugyelet, 0) AS egymas_utani_max_ugyelet,
  COALESCE(pp.last_minute_elerheto, false) AS last_minute_elerheto,
  pp.last_minute_orahatar,
  pp.utazasi_perc_max,
  COALESCE(pp.preferalt_musakok::text[], ARRAY[]::text[]) AS preferalt_musakok,
  COALESCE(pp.tiltott_napok, ARRAY[]::int[]) AS tiltott_napok,
  COALESCE(pp.nyelvek, ARRAY[]::text[]) AS nyelvek,
  COALESCE(ca.terhes, false) AS terhes,
  COALESCE(ca.szoptat, false) AS szoptat,
  COALESCE(ca.kisgyermek_otthon, false) AS kisgyermek_otthon,
  COALESCE(ca.egyedulnevelo, false) AS egyedulnevelo,
  COALESCE(ca.tartos_betegseg, false) AS tartos_betegseg,
  COALESCE(ca.mozgaskorlatozas, false) AS mozgaskorlatozas,
  COALESCE(ca.vedendokoru, false) AS vedendokoru,
  COALESCE(ca.aktiv_constraint_count, 0) AS aktiv_constraint_count,
  (COALESCE(ca.terhes, false) OR COALESCE(ca.szoptat, false)) AS tiltott_ejszaka,
  (COALESCE(ca.terhes, false) OR COALESCE(ca.mozgaskorlatozas, false)) AS tiltott_sugar_zona,
  GREATEST(
    CASE WHEN COALESCE(pp.ugyelet_utan_pihenonap, false) THEN COALESCE(pp.ugyelet_utan_min_ora, 24) ELSE 0 END,
    CASE WHEN COALESCE(ca.terhes, false) OR COALESCE(ca.kisgyermek_otthon, false) THEN 24 ELSE 0 END
  ) AS min_pihenoido_ora,
  COALESCE(ua.tavollet_nap_30, 0) AS tavollet_nap_30,
  COALESCE(ua.tavollet_nap_90, 0) AS tavollet_nap_90,
  COALESCE(ua.fuggo_tavollet_count, 0) AS fuggo_tavollet_count,
  COALESCE(ua.jovahagyott_tavollet_count, 0) AS jovahagyott_tavollet_count,
  COALESCE(pa.pozitiv_kapcsolat, 0) AS pozitiv_kapcsolat,
  COALESCE(pa.negativ_kapcsolat, 0) AS negativ_kapcsolat,
  COALESCE(pa.mentor_count, 0) AS mentor_count,
  COALESCE(pa.mentee_count, 0) AS mentee_count,
  COALESCE(cta.contact_count, 0) AS contact_count,
  COALESCE(cta.van_aktiv_ertesites, false) AS van_aktiv_ertesites
FROM public.profiles pr
LEFT JOIN public.profile_preferences pp ON pp.user_id = pr.id
LEFT JOIN c_agg  ca  ON ca.user_id = pr.id
LEFT JOIN u_agg  ua  ON ua.user_id = pr.id
LEFT JOIN p_agg  pa  ON pa.user_id = pr.id
LEFT JOIN ct_agg cta ON cta.user_id = pr.id;

GRANT SELECT ON public.profile_scheduling_facts TO authenticated;

COMMENT ON VIEW public.profile_scheduling_facts IS
  'Hard/soft constraint aggregátum a beosztó-motor (M1) és a csapat admin-nézet számára. RLS-örökölt (security_invoker).';

-- ─── 20260618194108_62c6062d-96a8-4adb-a472-d10d7b27d343.sql ───
-- 1) akut flag a profile_unavailability táblán
ALTER TABLE public.profile_unavailability
  ADD COLUMN IF NOT EXISTS akut BOOLEAN NOT NULL DEFAULT false;

CREATE INDEX IF NOT EXISTS idx_profile_unavailability_akut
  ON public.profile_unavailability(akut, kezdo_datum, zaro_datum)
  WHERE akut = true;

-- 2) helyettesítés-kereső függvény
CREATE OR REPLACE FUNCTION public.find_acute_replacements(
  p_user_id uuid,
  p_datum date
)
RETURNS TABLE (
  user_id uuid,
  teljes_nev text,
  email text,
  foglalkozas_tipus text,
  egyezo_skillek text[],
  egyezo_kepzettsegek text[],
  egyezo_skill_szam int,
  egyezo_kepz_szam int,
  pozitiv_kapcsolat boolean,
  match_score int,
  szabad boolean,
  aktiv_korlatozok text[]
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT (
      public.has_permission(auth.uid(), 'view_team')
   OR public.has_permission(auth.uid(), 'manage_schedule')
   OR public.has_permission(auth.uid(), 'manage_tenant')
  ) THEN
    RAISE EXCEPTION 'Nincs jogosultsága helyettesítési javaslat lekérdezéséhez.'
      USING ERRCODE = '42501';
  END IF;

  RETURN QUERY
  WITH
    sick AS (
      SELECT p.foglalkozas_tipus, p.tenant_id
      FROM public.profiles p
      WHERE p.id = p_user_id
    ),
    sick_skills AS (
      SELECT skill_id FROM public.profile_skills WHERE profile_skills.user_id = p_user_id
    ),
    sick_cert_keys AS (
      SELECT DISTINCT lower(nev) AS k FROM public.profile_certifications WHERE profile_certifications.user_id = p_user_id
    ),
    cand AS (
      SELECT p.id, p.teljes_nev, p.email, p.foglalkozas_tipus::text AS foglalkozas_tipus
      FROM public.profiles p, sick s
      WHERE p.id <> p_user_id
        AND p.tenant_id IS NOT DISTINCT FROM s.tenant_id
        AND p.foglalkozas_tipus = s.foglalkozas_tipus
    ),
    c_skills AS (
      SELECT ps.user_id, array_agg(sk.nev ORDER BY sk.nev) AS nevek, count(*)::int AS cnt
      FROM public.profile_skills ps
      JOIN public.skills sk ON sk.id = ps.skill_id
      WHERE ps.skill_id IN (SELECT skill_id FROM sick_skills)
        AND ps.user_id IN (SELECT id FROM cand)
      GROUP BY ps.user_id
    ),
    c_certs AS (
      SELECT pc.user_id, array_agg(pc.nev ORDER BY pc.nev) AS nevek, count(*)::int AS cnt
      FROM public.profile_certifications pc
      WHERE lower(pc.nev) IN (SELECT k FROM sick_cert_keys)
        AND pc.user_id IN (SELECT id FROM cand)
      GROUP BY pc.user_id
    ),
    c_unav AS (
      SELECT pu.user_id
      FROM public.profile_unavailability pu
      WHERE pu.status IN ('jovahagyott','jovahagyasra_var')
        AND pu.kezdo_datum <= p_datum
        AND pu.zaro_datum >= p_datum
        AND pu.user_id IN (SELECT id FROM cand)
      GROUP BY pu.user_id
    ),
    c_peer_pos AS (
      SELECT pl.to_user_id AS user_id
      FROM public.profile_peer_links pl
      WHERE pl.from_user_id = p_user_id
        AND pl.tipus = 'szivesen_dolgozik_vele'
        AND pl.status = 'aktiv'
    ),
    c_peer_neg AS (
      SELECT pl.to_user_id AS user_id
      FROM public.profile_peer_links pl
      WHERE pl.from_user_id = p_user_id
        AND pl.tipus = 'nem_dolgozik_vele'
        AND pl.status = 'jovahagyott'
      UNION
      SELECT pl.from_user_id AS user_id
      FROM public.profile_peer_links pl
      WHERE pl.to_user_id = p_user_id
        AND pl.tipus = 'nem_dolgozik_vele'
        AND pl.status = 'jovahagyott'
    ),
    c_constraints AS (
      SELECT pc.user_id,
             array_agg(pc.tipus::text ORDER BY pc.tipus::text) AS aktiv
      FROM public.profile_constraints pc
      WHERE (pc.ervenyes_ig IS NULL OR pc.ervenyes_ig >= p_datum)
        AND pc.ervenyes_tol <= p_datum
        AND pc.user_id IN (SELECT id FROM cand)
      GROUP BY pc.user_id
    )
  SELECT
    c.id,
    c.teljes_nev,
    c.email,
    c.foglalkozas_tipus,
    COALESCE(cs.nevek, ARRAY[]::text[])  AS egyezo_skillek,
    COALESCE(cc.nevek, ARRAY[]::text[])  AS egyezo_kepzettsegek,
    COALESCE(cs.cnt, 0)                  AS egyezo_skill_szam,
    COALESCE(cc.cnt, 0)                  AS egyezo_kepz_szam,
    (cp.user_id IS NOT NULL)             AS pozitiv_kapcsolat,
    (COALESCE(cs.cnt, 0) * 10
       + COALESCE(cc.cnt, 0) * 5
       + CASE WHEN cp.user_id IS NOT NULL THEN 3 ELSE 0 END)::int AS match_score,
    (cu.user_id IS NULL AND cn.user_id IS NULL) AS szabad,
    COALESCE(cc2.aktiv, ARRAY[]::text[]) AS aktiv_korlatozok
  FROM cand c
  LEFT JOIN c_skills      cs  ON cs.user_id  = c.id
  LEFT JOIN c_certs       cc  ON cc.user_id  = c.id
  LEFT JOIN c_unav        cu  ON cu.user_id  = c.id
  LEFT JOIN c_peer_pos    cp  ON cp.user_id  = c.id
  LEFT JOIN c_peer_neg    cn  ON cn.user_id  = c.id
  LEFT JOIN c_constraints cc2 ON cc2.user_id = c.id
  WHERE COALESCE(cs.cnt, 0) > 0
     OR COALESCE(cc.cnt, 0) > 0
  ORDER BY
    (cu.user_id IS NULL AND cn.user_id IS NULL) DESC,
    (COALESCE(cs.cnt, 0) * 10
       + COALESCE(cc.cnt, 0) * 5
       + CASE WHEN cp.user_id IS NOT NULL THEN 3 ELSE 0 END) DESC,
    c.teljes_nev;
END;
$$;

REVOKE ALL ON FUNCTION public.find_acute_replacements(uuid, date) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.find_acute_replacements(uuid, date) TO authenticated;

COMMENT ON FUNCTION public.find_acute_replacements(uuid, date) IS
  'Akut betegjelentésekhez helyettesítési javaslat. Visszaad azonos foglalkozású, közös skill/képzettségű kollégákat, jelölve a napi szabad állapotot és kapcsolati súlyt.';

-- ─── 20260618195135_f99b5c0b-9433-469d-bed7-053ef845c67d.sql ───

CREATE TABLE IF NOT EXISTS public.feladat_korok (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  kulcs TEXT NOT NULL,
  nev TEXT NOT NULL,
  leiras TEXT,
  sorrend INTEGER NOT NULL DEFAULT 100,
  aktiv BOOLEAN NOT NULL DEFAULT true,
  rendszerszintu BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, kulcs)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.feladat_korok TO authenticated;
GRANT ALL ON public.feladat_korok TO service_role;

ALTER TABLE public.feladat_korok ENABLE ROW LEVEL SECURITY;

CREATE POLICY "feladat_korok_select_tenant" ON public.feladat_korok
  FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());

CREATE POLICY "feladat_korok_manage_admin" ON public.feladat_korok
  FOR ALL TO authenticated
  USING (
    tenant_id = public.current_tenant_id()
    AND (
      public.has_permission(auth.uid(), 'manage_tenant')
      OR public.has_permission(auth.uid(), 'manage_org')
      OR public.has_permission(auth.uid(), 'manage_schedule')
    )
  )
  WITH CHECK (
    tenant_id = public.current_tenant_id()
    AND (
      public.has_permission(auth.uid(), 'manage_tenant')
      OR public.has_permission(auth.uid(), 'manage_org')
      OR public.has_permission(auth.uid(), 'manage_schedule')
    )
  );

CREATE TRIGGER touch_feladat_korok BEFORE UPDATE ON public.feladat_korok
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

INSERT INTO public.feladat_korok (tenant_id, kulcs, nev, sorrend, rendszerszintu)
SELECT t.id, k.kulcs, k.nev, k.sorrend, true
FROM public.tenants t
CROSS JOIN (VALUES
  ('muto',           'Műtő',           10),
  ('ambulancia',     'Ambulancia',     20),
  ('osztaly',        'Osztály',        30),
  ('ultrahang',      'Ultrahang',      40),
  ('terhesgondozas', 'Terhesgondozás', 50),
  ('kismuto',        'Kisműtő',        60),
  ('ivf',            'IVF',            70),
  ('fmc',            'FMC',            80),
  ('egyeb',          'Egyéb',          999)
) AS k(kulcs, nev, sorrend)
ON CONFLICT (tenant_id, kulcs) DO NOTHING;

ALTER TABLE public.profile_preferences
  ADD COLUMN IF NOT EXISTS kozossegi_napok DATE[] NOT NULL DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS preferalt_feladat_korok TEXT[] NOT NULL DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS status public.unavailability_status NOT NULL DEFAULT 'tervezett',
  ADD COLUMN IF NOT EXISTS submitted_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS jovahagyo_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS jovahagyas_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS jovahagyas_indok TEXT,
  ADD COLUMN IF NOT EXISTS jovahagyas_feltetel TEXT;

CREATE OR REPLACE FUNCTION public.profile_preferences_guard()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_can_approve boolean;
BEGIN
  IF TG_OP = 'UPDATE' AND NEW.status IS DISTINCT FROM OLD.status THEN
    IF NEW.status IN ('jovahagyott', 'elutasitott') THEN
      v_can_approve := COALESCE(public.has_permission(v_uid, 'manage_schedule'), false)
                    OR COALESCE(public.has_permission(v_uid, 'manage_tenant'), false);
      IF NOT v_can_approve THEN
        INSERT INTO public.admin_audit_log(tenant_id, user_id, action, table_name, record_id, before_data, after_data)
        VALUES (
          COALESCE(NEW.tenant_id, public.current_tenant_id()),
          v_uid,
          'FORBIDDEN_APPROVAL',
          TG_TABLE_NAME,
          NEW.user_id::text,
          jsonb_build_object('status', OLD.status),
          jsonb_build_object('status', NEW.status)
        );
        RAISE EXCEPTION 'Nincs jogosultsága a preferenciák jóváhagyásához.'
          USING ERRCODE = '42501';
      END IF;
      IF NEW.user_id = v_uid THEN
        RAISE EXCEPTION 'A saját preferenciáját nem hagyhatja jóvá / utasíthatja el.'
          USING ERRCODE = '42501';
      END IF;
      IF NEW.status = 'elutasitott' AND COALESCE(btrim(NEW.jovahagyas_indok), '') = '' THEN
        RAISE EXCEPTION 'Elutasításhoz kötelező az indoklás.'
          USING ERRCODE = '22023';
      END IF;
      NEW.jovahagyo_id := v_uid;
      NEW.jovahagyas_at := now();
    ELSIF NEW.status = 'jovahagyasra_var' THEN
      NEW.submitted_at := now();
      NEW.jovahagyo_id := NULL;
      NEW.jovahagyas_at := NULL;
      NEW.jovahagyas_indok := NULL;
      NEW.jovahagyas_feltetel := NULL;
    ELSIF NEW.status = 'tervezett' THEN
      NEW.submitted_at := NULL;
      NEW.jovahagyo_id := NULL;
      NEW.jovahagyas_at := NULL;
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS profile_preferences_guard ON public.profile_preferences;
CREATE TRIGGER profile_preferences_guard
  BEFORE UPDATE ON public.profile_preferences
  FOR EACH ROW
  EXECUTE FUNCTION public.profile_preferences_guard();

DROP TRIGGER IF EXISTS profile_preferences_audit ON public.profile_preferences;
CREATE TRIGGER profile_preferences_audit
  AFTER INSERT OR UPDATE OR DELETE ON public.profile_preferences
  FOR EACH ROW
  EXECUTE FUNCTION public.audit_trigger_fn();


-- ─── 20260618195729_b9e4315d-8788-462a-9055-76fe33ff633e.sql ───
CREATE TABLE IF NOT EXISTS public.training_program_elements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  program_id UUID NOT NULL REFERENCES public.training_programs(id) ON DELETE CASCADE,
  parent_element_id UUID REFERENCES public.training_program_elements(id) ON DELETE CASCADE,
  kod TEXT,
  nev TEXT NOT NULL,
  leiras TEXT,
  kategoria TEXT,
  sorszam SMALLINT NOT NULL DEFAULT 0,
  idotartam_honap NUMERIC(5,2),
  milestone TEXT,
  kotelezo BOOLEAN NOT NULL DEFAULT true,
  klinikan_kivul_engedett BOOLEAN NOT NULL DEFAULT false,
  aktiv BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.training_program_elements TO authenticated;
GRANT ALL ON public.training_program_elements TO service_role;
ALTER TABLE public.training_program_elements ENABLE ROW LEVEL SECURITY;
CREATE POLICY tpe_select_via_parent ON public.training_program_elements FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.training_programs p WHERE p.id = training_program_elements.program_id AND p.tenant_id = public.current_tenant_id()));
CREATE POLICY tpe_write_training ON public.training_program_elements FOR ALL TO authenticated
  USING (public.has_permission(auth.uid(),'manage_training') AND EXISTS (SELECT 1 FROM public.training_programs p WHERE p.id = training_program_elements.program_id AND p.tenant_id = public.current_tenant_id()))
  WITH CHECK (public.has_permission(auth.uid(),'manage_training') AND EXISTS (SELECT 1 FROM public.training_programs p WHERE p.id = training_program_elements.program_id AND p.tenant_id = public.current_tenant_id()));
CREATE INDEX idx_tpe_program ON public.training_program_elements(program_id);
CREATE INDEX idx_tpe_parent  ON public.training_program_elements(parent_element_id);
CREATE TRIGGER touch_tpe BEFORE UPDATE ON public.training_program_elements FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER audit_tpe AFTER INSERT OR UPDATE OR DELETE ON public.training_program_elements FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

CREATE TABLE IF NOT EXISTS public.training_program_interventions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  program_id UUID NOT NULL REFERENCES public.training_programs(id) ON DELETE CASCADE,
  element_id UUID REFERENCES public.training_program_elements(id) ON DELETE SET NULL,
  milestone TEXT,
  beavatkozas_id UUID REFERENCES public.beavatkozasok(id) ON DELETE SET NULL,
  beavatkozas_nev TEXT NOT NULL,
  szerep TEXT NOT NULL DEFAULT 'operator',
  szint TEXT,
  required_esetszam INT NOT NULL DEFAULT 0,
  klinikan_kivul_engedett BOOLEAN NOT NULL DEFAULT true,
  sorszam SMALLINT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.training_program_interventions TO authenticated;
GRANT ALL ON public.training_program_interventions TO service_role;
ALTER TABLE public.training_program_interventions ENABLE ROW LEVEL SECURITY;
CREATE POLICY tpi_select_via_parent ON public.training_program_interventions FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.training_programs p WHERE p.id = training_program_interventions.program_id AND p.tenant_id = public.current_tenant_id()));
CREATE POLICY tpi_write_training ON public.training_program_interventions FOR ALL TO authenticated
  USING (public.has_permission(auth.uid(),'manage_training') AND EXISTS (SELECT 1 FROM public.training_programs p WHERE p.id = training_program_interventions.program_id AND p.tenant_id = public.current_tenant_id()))
  WITH CHECK (public.has_permission(auth.uid(),'manage_training') AND EXISTS (SELECT 1 FROM public.training_programs p WHERE p.id = training_program_interventions.program_id AND p.tenant_id = public.current_tenant_id()));
CREATE INDEX idx_tpi_program ON public.training_program_interventions(program_id);
CREATE INDEX idx_tpi_milestone ON public.training_program_interventions(program_id, milestone);
CREATE TRIGGER touch_tpi BEFORE UPDATE ON public.training_program_interventions FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER audit_tpi AFTER INSERT OR UPDATE OR DELETE ON public.training_program_interventions FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

CREATE TABLE IF NOT EXISTS public.profile_program_milestones (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  program_id UUID NOT NULL REFERENCES public.training_programs(id) ON DELETE CASCADE,
  milestone TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'folyamatban',
  elerve_at TIMESTAMPTZ,
  megjegyzes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, program_id, milestone)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_program_milestones TO authenticated;
GRANT ALL ON public.profile_program_milestones TO service_role;
ALTER TABLE public.profile_program_milestones ENABLE ROW LEVEL SECURITY;
CREATE POLICY ppm_select_self_or_team ON public.profile_program_milestones FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (user_id = auth.uid() OR public.has_permission(auth.uid(),'view_team') OR public.has_permission(auth.uid(),'manage_training') OR public.has_permission(auth.uid(),'manage_tenant')));
CREATE POLICY ppm_write_training ON public.profile_program_milestones FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (public.has_permission(auth.uid(),'manage_training') OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id() AND (public.has_permission(auth.uid(),'manage_training') OR public.has_permission(auth.uid(),'manage_tenant')));
CREATE INDEX idx_ppm_user ON public.profile_program_milestones(user_id);
CREATE INDEX idx_ppm_program ON public.profile_program_milestones(program_id);
CREATE TRIGGER touch_ppm BEFORE UPDATE ON public.profile_program_milestones FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER audit_ppm AFTER INSERT OR UPDATE OR DELETE ON public.profile_program_milestones FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

DO $$
DECLARE
  t RECORD; v_program UUID; v_phase1 UUID; v_phase2 UUID;
BEGIN
  FOR t IN SELECT id FROM public.tenants LOOP
    SELECT id INTO v_program FROM public.training_programs
     WHERE tenant_id = t.id AND nev = 'Szülészet-nőgyógyászat szakorvosképzés';
    IF v_program IS NULL THEN
      INSERT INTO public.training_programs(tenant_id, nev, leiras, honap_hossz)
      VALUES (t.id,'Szülészet-nőgyógyászat szakorvosképzés','53 hó 2 hét, 2 részvizsga + szakvizsga (42. szakképesítés)',54)
      RETURNING id INTO v_program;
    END IF;

    SELECT id INTO v_phase1 FROM public.training_program_elements WHERE program_id = v_program AND kod = 'PH1';
    IF v_phase1 IS NULL THEN
      INSERT INTO public.training_program_elements(program_id, kod, nev, kategoria, sorszam, idotartam_honap, milestone, kotelezo)
      VALUES (v_program,'PH1','Első két év (22 hó) – 1. részvizsga felé','fazis',1,22,'reszvizsga_1',true)
      RETURNING id INTO v_phase1;
      INSERT INTO public.training_program_elements(program_id, parent_element_id, kod, nev, kategoria, sorszam, idotartam_honap, milestone, klinikan_kivul_engedett) VALUES
        (v_program, v_phase1, 'PH1.1','Sürgősségi gyakorlat','rotacio',1,2,'reszvizsga_1', true),
        (v_program, v_phase1, 'PH1.2','Multidiszciplináris intenzív terápia','rotacio',2,1,'reszvizsga_1', true),
        (v_program, v_phase1, 'PH1.3','Mentőgyakorlat','rotacio',3,0.5,'reszvizsga_1', true),
        (v_program, v_phase1, 'PH1.4','Sebészeti gyakorlat (skill tréning 1 hó)','rotacio',4,3,'reszvizsga_1', true),
        (v_program, v_phase1, 'PH1.5','Szülészeti képzés','torzs',5,7.75,'reszvizsga_1', true),
        (v_program, v_phase1, 'PH1.6','Nőgyógyászati képzés','torzs',6,7.75,'reszvizsga_1', true);
    END IF;

    SELECT id INTO v_phase2 FROM public.training_program_elements WHERE program_id = v_program AND kod = 'PH2';
    IF v_phase2 IS NULL THEN
      INSERT INTO public.training_program_elements(program_id, kod, nev, kategoria, sorszam, idotartam_honap, milestone, kotelezo)
      VALUES (v_program,'PH2','Fennmaradó képzés (31 hó 2 hét) – 2. részvizsga és szakvizsga felé','fazis',2,31.5,'szakvizsga',true)
      RETURNING id INTO v_phase2;
      INSERT INTO public.training_program_elements(program_id, parent_element_id, kod, nev, kategoria, sorszam, idotartam_honap, milestone, klinikan_kivul_engedett) VALUES
        (v_program, v_phase2, 'PH2.1','Szülészet','torzs',1,9.25,'reszvizsga_2', true),
        (v_program, v_phase2, 'PH2.2','Nőgyógyászat','torzs',2,9.25,'reszvizsga_2', true),
        (v_program, v_phase2, 'PH2.3','Nőgyógyászati onkológia','rotacio',3,2,'szakvizsga', true),
        (v_program, v_phase2, 'PH2.4','Nőgyógyászati endokrinológia és asszisztált reprodukció','rotacio',4,1,'szakvizsga', true),
        (v_program, v_phase2, 'PH2.5','Szülészeti aneszteziológia','rotacio',5,1,'szakvizsga', true),
        (v_program, v_phase2, 'PH2.6','Urológia','rotacio',6,1,'szakvizsga', true),
        (v_program, v_phase2, 'PH2.7','Szülészet-nőgyógyászat ultrahang','rotacio',7,3,'szakvizsga', true),
        (v_program, v_phase2, 'PH2.8','Kötelező egyetemi tanfolyamok (Kolposzkópia, Neonatológia, Endoszkópia, Pszichoszomatika, Gyermeknőgyógyászat, UH-diagnosztika)','tanfolyam',8,2,'szakvizsga', false),
        (v_program, v_phase2, 'PH2.9','Háziorvosi gyakorlat','rotacio',9,2.5,'szakvizsga', true),
        (v_program, v_phase2, 'PH2.10','Várandósgondozás háziorvosi együttműködésben','rotacio',10,0.5,'szakvizsga', true);
    END IF;

    IF NOT EXISTS (SELECT 1 FROM public.training_program_interventions WHERE program_id = v_program AND milestone='reszvizsga_1') THEN
      INSERT INTO public.training_program_interventions (program_id, milestone, beavatkozas_nev, szint, required_esetszam, klinikan_kivul_engedett, sorszam)
      VALUES
        (v_program,'reszvizsga_1','Hüvelyi szülés levezetése','IV',15,true,1),
        (v_program,'reszvizsga_1','Gátmetszés és ellátása','IV',15,true,2),
        (v_program,'reszvizsga_1','Várandós szülőszobai felvétele','IV',50,true,3),
        (v_program,'reszvizsga_1','Diagnosztikus terv elkészítése szülőszobán','IV',50,true,4),
        (v_program,'reszvizsga_1','Terápiás terv készítése szülőszobán','IV',50,true,5),
        (v_program,'reszvizsga_1','Császármetszés asszisztencia','IV',50,true,6),
        (v_program,'reszvizsga_1','Cardiotocographia','IV',100,true,7),
        (v_program,'reszvizsga_1','Vénabiztosítás, vérvétel','I',30,true,8),
        (v_program,'reszvizsga_1','Zárójelentés összeállítása gyermekágyon','IV',50,true,9);
    END IF;

    IF NOT EXISTS (SELECT 1 FROM public.training_program_interventions WHERE program_id = v_program AND milestone='reszvizsga_2') THEN
      INSERT INTO public.training_program_interventions (program_id, milestone, beavatkozas_nev, szint, required_esetszam, klinikan_kivul_engedett, sorszam)
      VALUES
        (v_program,'reszvizsga_2','Nőgyógyászati vizsgálat','II',100,true,1),
        (v_program,'reszvizsga_2','Nőgyógyászati kisműtétek','III',50,true,2),
        (v_program,'reszvizsga_2','Szülészeti vizsgálat','II',150,true,3),
        (v_program,'reszvizsga_2','Szülés levezetése','III',50,true,4),
        (v_program,'reszvizsga_2','Császármetszés végzése','IV',30,true,5),
        (v_program,'reszvizsga_2','Hüvelyi szülésbefejező beavatkozás elvégzése','IV',2,true,6),
        (v_program,'reszvizsga_2','Akut nőgyógyászati onkológiai ellátás','IV',30,true,7),
        (v_program,'reszvizsga_2','Tájékozódó szülészeti vizsgálat','II',100,true,8),
        (v_program,'reszvizsga_2','Nőgyógyászati ultrahang vizsgálat','II',100,true,9);
    END IF;

    IF NOT EXISTS (SELECT 1 FROM public.training_program_interventions WHERE program_id = v_program AND milestone='szakvizsga') THEN
      INSERT INTO public.training_program_interventions (program_id, milestone, beavatkozas_nev, szerep, required_esetszam, klinikan_kivul_engedett, sorszam)
      VALUES
        (v_program,'szakvizsga','Császármetszés','operator',50,true,1),
        (v_program,'szakvizsga','Hüvelyi szülésvezetés','operator',100,true,2),
        (v_program,'szakvizsga','Hüvelyi szülésbefejező beavatkozások','operator',5,true,3),
        (v_program,'szakvizsga','Méhűri betapintás','operator',10,true,4),
        (v_program,'szakvizsga','Vetélés befejező beavatkozások és terhességmegszakítás','operator',20,true,5),
        (v_program,'szakvizsga','Hüvelyfali és méhnyak műtétek','operator',20,true,6),
        (v_program,'szakvizsga','Diagnosztikus hysteroscopia','operator',10,true,7),
        (v_program,'szakvizsga','Operatív hysteroscopia','operator',5,true,8),
        (v_program,'szakvizsga','Hüvelyi méheltávolítás','operator',10,true,9),
        (v_program,'szakvizsga','Diagnosztikus laparoscopia','operator',10,true,10),
        (v_program,'szakvizsga','Operatív laparoscopia','operator',5,true,11),
        (v_program,'szakvizsga','Adnex műtét (laparoscopia / laparotomia)','operator',15,true,12),
        (v_program,'szakvizsga','Hasi méheltávolítás','operator',10,true,13),
        (v_program,'szakvizsga','Onkológiai műtét asszisztencia','asszisztens',5,true,14),
        (v_program,'szakvizsga','Hasi sebészet műtétasszisztálás','asszisztens',5,true,15);
    END IF;

  END LOOP;
END$$;

-- ─── 20260618200001_34ef356e-8120-4760-9a54-4650b3d789ab.sql ───
DO $$ BEGIN
  CREATE TYPE public.jogviszony_tipus AS ENUM (
    'kjt_kozalkalmazott',
    'egeszsegugyi_szolgalati',
    'munka_tv_kv',
    'megbizasi',
    'egyeni_vallalkozo',
    'tarsas_vallalkozo',
    'kozalkalmazotti_tovabbi',
    'rezidens_kepzes',
    'oszintszerzodes',
    'egyeb'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.fenntarto_tipus AS ENUM (
    'allami','onkormanyzati','egyhazi','egyetemi_klinika','maganszektor','egyeb'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.munkaido_keret_tipus AS ENUM (
    'heti','havi','negyedeves','eves','egyedi'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS public.profile_employment (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  elsodleges BOOLEAN NOT NULL DEFAULT false,
  jogviszony_tipus public.jogviszony_tipus NOT NULL DEFAULT 'egeszsegugyi_szolgalati',
  fenntarto_tipus public.fenntarto_tipus NOT NULL DEFAULT 'allami',
  munkaltato_nev TEXT NOT NULL,
  munkakor_megnevezes TEXT,
  munkakor_kod TEXT,
  org_unit_id UUID REFERENCES public.org_units(id) ON DELETE SET NULL,
  site_id UUID REFERENCES public.sites(id) ON DELETE SET NULL,
  kezdo_datum DATE,
  zaro_datum DATE,
  munkaido_keret public.munkaido_keret_tipus NOT NULL DEFAULT 'heti',
  keret_ora NUMERIC(7,2),
  fte_szazalek SMALLINT NOT NULL DEFAULT 100 CHECK (fte_szazalek BETWEEN 0 AND 200),
  tobbes_jogviszony BOOLEAN NOT NULL DEFAULT false,
  opt_out_ovt BOOLEAN NOT NULL DEFAULT false,
  opt_out_kezdete DATE,
  opt_out_visszavonas DATE,
  ovt_max_evi_ora INT,
  osszeferhetetlenseg_megjegyzes TEXT,
  ervenyes BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_employment TO authenticated;
GRANT ALL ON public.profile_employment TO service_role;
ALTER TABLE public.profile_employment ENABLE ROW LEVEL SECURITY;

CREATE POLICY pe_select ON public.profile_employment FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (user_id = auth.uid()
              OR public.has_permission(auth.uid(),'view_team')
              OR public.has_permission(auth.uid(),'manage_schedule')
              OR public.has_permission(auth.uid(),'manage_tenant')));

CREATE POLICY pe_write_self_or_hr ON public.profile_employment FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (user_id = auth.uid() OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id()
         AND (user_id = auth.uid() OR public.has_permission(auth.uid(),'manage_tenant')));

CREATE INDEX idx_pe_user ON public.profile_employment(user_id);
CREATE INDEX idx_pe_tenant ON public.profile_employment(tenant_id);
CREATE UNIQUE INDEX uq_pe_one_primary ON public.profile_employment(user_id) WHERE elsodleges = true;

CREATE TRIGGER touch_pe BEFORE UPDATE ON public.profile_employment
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER audit_pe AFTER INSERT OR UPDATE OR DELETE ON public.profile_employment
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ensure single primary
CREATE OR REPLACE FUNCTION public.profile_employment_single_primary()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.elsodleges = true THEN
    UPDATE public.profile_employment
       SET elsodleges = false
     WHERE user_id = NEW.user_id
       AND id <> NEW.id
       AND elsodleges = true;
  END IF;
  RETURN NEW;
END $$;

CREATE TRIGGER pe_primary_unique
AFTER INSERT OR UPDATE OF elsodleges ON public.profile_employment
FOR EACH ROW WHEN (NEW.elsodleges = true)
EXECUTE FUNCTION public.profile_employment_single_primary();

-- OVT opt-out audit log
CREATE TABLE IF NOT EXISTS public.profile_employment_optout_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  employment_id UUID NOT NULL REFERENCES public.profile_employment(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  action TEXT NOT NULL CHECK (action IN ('opt_in','opt_out','revoke','keret_modositas')),
  effective_date DATE NOT NULL DEFAULT CURRENT_DATE,
  ovt_max_evi_ora INT,
  indok TEXT,
  decided_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_employment_optout_log TO authenticated;
GRANT ALL ON public.profile_employment_optout_log TO service_role;
ALTER TABLE public.profile_employment_optout_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY peol_select ON public.profile_employment_optout_log FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (user_id = auth.uid()
              OR public.has_permission(auth.uid(),'view_team')
              OR public.has_permission(auth.uid(),'manage_schedule')
              OR public.has_permission(auth.uid(),'manage_tenant')));

CREATE POLICY peol_insert_self_or_hr ON public.profile_employment_optout_log FOR INSERT TO authenticated
  WITH CHECK (tenant_id = public.current_tenant_id()
         AND (user_id = auth.uid() OR public.has_permission(auth.uid(),'manage_tenant')));

CREATE POLICY peol_update_hr ON public.profile_employment_optout_log FOR UPDATE TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_tenant'))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_tenant'));

CREATE POLICY peol_delete_hr ON public.profile_employment_optout_log FOR DELETE TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_tenant'));

CREATE INDEX idx_peol_employment ON public.profile_employment_optout_log(employment_id);
CREATE INDEX idx_peol_user ON public.profile_employment_optout_log(user_id);

CREATE TRIGGER audit_peol AFTER INSERT OR UPDATE OR DELETE ON public.profile_employment_optout_log
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ─── 20260618201318_65d70658-9444-4e90-8a10-2819157c3592.sql ───

DROP VIEW IF EXISTS public.profile_scheduling_facts CASCADE;

CREATE TABLE public.work_time_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  jogviszony_tipus public.jogviszony_tipus NOT NULL,
  fenntarto_tipus public.fenntarto_tipus NOT NULL,
  napi_pihenes_min_ora numeric NOT NULL DEFAULT 11,
  heti_max_ora numeric NOT NULL DEFAULT 48,
  heti_max_ora_ovt numeric NOT NULL DEFAULT 60,
  heti_max_ora_egeszsegugyi numeric NOT NULL DEFAULT 72,
  napi_max_ora numeric NOT NULL DEFAULT 12,
  napi_max_ora_ugyelettel numeric NOT NULL DEFAULT 24,
  eves_ugyelet_rendkivuli_max numeric NOT NULL DEFAULT 416,
  eves_rendkivuli_max numeric NOT NULL DEFAULT 250,
  eves_ovt_rendkivuli_max numeric NOT NULL DEFAULT 150,
  havi_ugyelet_keszenlet_max int NOT NULL DEFAULT 14,
  havi_keszenlet_max int NOT NULL DEFAULT 10,
  heti_egybefuggo_piheno_ora numeric NOT NULL DEFAULT 48,
  forrasszoveg text,
  ervenyes_tol date NOT NULL DEFAULT CURRENT_DATE,
  ervenyes_ig date,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, jogviszony_tipus, fenntarto_tipus, ervenyes_tol)
);
GRANT SELECT ON public.work_time_rules TO authenticated;
GRANT ALL ON public.work_time_rules TO service_role;
ALTER TABLE public.work_time_rules ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wtr_select_authenticated" ON public.work_time_rules
  FOR SELECT TO authenticated USING (tenant_id IS NULL OR tenant_id = public.current_tenant_id());
CREATE POLICY "wtr_write_admin" ON public.work_time_rules
  FOR ALL TO authenticated
  USING (public.has_permission(auth.uid(), 'manage_tenant'))
  WITH CHECK (public.has_permission(auth.uid(), 'manage_tenant'));
CREATE TRIGGER wtr_touch BEFORE UPDATE ON public.work_time_rules
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

INSERT INTO public.work_time_rules (tenant_id, jogviszony_tipus, fenntarto_tipus, forrasszoveg) VALUES
  (NULL, 'egeszsegugyi_szolgalati', 'allami',           'Eszjtv. 2020/C + 528/2020 + Eütev. 12/A-G'),
  (NULL, 'egeszsegugyi_szolgalati', 'onkormanyzati',    'Eszjtv. 2020/C + 528/2020 + Eütev. 12/A-G'),
  (NULL, 'munka_tv_kv',             'maganszektor',     'Mt. 2012/I + Eütev. 12/A-G (528/2020 NEM)'),
  (NULL, 'munka_tv_kv',             'egyhazi',          'Mt. 2012/I + Eütev. 12/A-G'),
  (NULL, 'kjt_kozalkalmazott',      'egyetemi_klinika', 'Kjt. + Eütev. 12/A-G');

CREATE TABLE public.opt_out_agreements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  employment_id uuid REFERENCES public.profile_employment(id) ON DELETE SET NULL,
  alairas_datum date NOT NULL,
  ervenyes_tol date NOT NULL,
  ervenyes_ig date,
  visszavonas_datum date,
  visszavonas_hatalyba_lep date,
  visszavonas_indok text,
  dokumentum_url text,
  letrehozta uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.opt_out_agreements TO authenticated;
GRANT ALL ON public.opt_out_agreements TO service_role;
ALTER TABLE public.opt_out_agreements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "ooa_select" ON public.opt_out_agreements FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_permission(auth.uid(), 'manage_tenant'));
CREATE POLICY "ooa_insert" ON public.opt_out_agreements FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid() OR public.has_permission(auth.uid(), 'manage_tenant'));
CREATE POLICY "ooa_update" ON public.opt_out_agreements FOR UPDATE TO authenticated
  USING (user_id = auth.uid() OR public.has_permission(auth.uid(), 'manage_tenant'))
  WITH CHECK (user_id = auth.uid() OR public.has_permission(auth.uid(), 'manage_tenant'));
CREATE POLICY "ooa_delete" ON public.opt_out_agreements FOR DELETE TO authenticated
  USING (public.has_permission(auth.uid(), 'manage_tenant'));
CREATE TRIGGER ooa_touch BEFORE UPDATE ON public.opt_out_agreements
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE OR REPLACE FUNCTION public.opt_out_revocation_guard()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.visszavonas_datum IS NOT NULL
     AND (OLD.visszavonas_datum IS NULL OR NEW.visszavonas_datum IS DISTINCT FROM OLD.visszavonas_datum) THEN
    IF NEW.visszavonas_datum < (NEW.ervenyes_tol + INTERVAL '12 months')::date THEN
      RAISE EXCEPTION 'ÖVT visszavonás csak az aktiválás (%) után 12 hónappal lehetséges (Eütev. 12/B).', NEW.ervenyes_tol
        USING ERRCODE = '22023';
    END IF;
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER ooa_revocation_guard BEFORE UPDATE ON public.opt_out_agreements
  FOR EACH ROW EXECUTE FUNCTION public.opt_out_revocation_guard();

CREATE TABLE public.incompatibilities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  tipus text NOT NULL,
  munkaltato_nev text,
  munkakor text,
  heti_oraszam numeric,
  bejelentes_datum date NOT NULL DEFAULT CURRENT_DATE,
  ervenyes_tol date NOT NULL,
  ervenyes_ig date,
  vezetoi_dontes text,
  vezeto_id uuid REFERENCES auth.users(id),
  dontes_datum date,
  dokumentum_url text,
  megjegyzes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.incompatibilities TO authenticated;
GRANT ALL ON public.incompatibilities TO service_role;
ALTER TABLE public.incompatibilities ENABLE ROW LEVEL SECURITY;
CREATE POLICY "inc_select" ON public.incompatibilities FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_permission(auth.uid(), 'manage_tenant'));
CREATE POLICY "inc_insert" ON public.incompatibilities FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());
CREATE POLICY "inc_update" ON public.incompatibilities FOR UPDATE TO authenticated
  USING (user_id = auth.uid() OR public.has_permission(auth.uid(), 'manage_tenant'))
  WITH CHECK (user_id = auth.uid() OR public.has_permission(auth.uid(), 'manage_tenant'));
CREATE POLICY "inc_delete" ON public.incompatibilities FOR DELETE TO authenticated
  USING (public.has_permission(auth.uid(), 'manage_tenant'));
CREATE TRIGGER inc_touch BEFORE UPDATE ON public.incompatibilities
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE VIEW public.profile_scheduling_facts
WITH (security_invoker = true) AS
SELECT
  p.id AS user_id,
  p.tenant_id,
  p.teljes_nev,
  p.foglalkozas_tipus,
  COALESCE((
    SELECT array_agg(DISTINCT pc.tipus::text)
    FROM public.profile_constraints pc
    WHERE pc.user_id = p.id
      AND pc.ervenyes_tol <= CURRENT_DATE
      AND (pc.ervenyes_ig IS NULL OR pc.ervenyes_ig >= CURRENT_DATE)
  ), ARRAY[]::text[]) AS aktiv_korlatozok,
  EXISTS (
    SELECT 1 FROM public.profile_constraints pc
    WHERE pc.user_id = p.id AND pc.tipus = 'terhes'
      AND pc.ervenyes_tol <= CURRENT_DATE
      AND (pc.ervenyes_ig IS NULL OR pc.ervenyes_ig >= CURRENT_DATE)
  ) AS terhes,
  EXISTS (
    SELECT 1 FROM public.profile_unavailability pu
    WHERE pu.user_id = p.id AND pu.status = 'jovahagyott'
      AND pu.kezdo_datum <= CURRENT_DATE AND pu.zaro_datum >= CURRENT_DATE
  ) AS ma_tavol,
  (SELECT pp.heti_max_ora FROM public.profile_preferences pp WHERE pp.user_id = p.id) AS pref_heti_max_ora,
  (SELECT pp.preferalt_feladat_korok FROM public.profile_preferences pp WHERE pp.user_id = p.id) AS pref_feladat_korok,
  (SELECT pp.kozossegi_napok FROM public.profile_preferences pp WHERE pp.user_id = p.id) AS pref_kozossegi_napok,
  pe.id AS primary_employment_id,
  pe.jogviszony_tipus,
  pe.fenntarto_tipus,
  pe.fte_szazalek,
  pe.munkaido_keret,
  EXISTS (
    SELECT 1 FROM public.opt_out_agreements ooa
    WHERE ooa.user_id = p.id
      AND ooa.ervenyes_tol <= CURRENT_DATE
      AND (ooa.ervenyes_ig IS NULL OR ooa.ervenyes_ig >= CURRENT_DATE)
      AND (ooa.visszavonas_hatalyba_lep IS NULL OR ooa.visszavonas_hatalyba_lep > CURRENT_DATE)
  ) AS ovt_aktiv,
  (SELECT count(*)::int FROM public.profile_skills ps WHERE ps.user_id = p.id) AS skill_count,
  (SELECT count(*)::int FROM public.profile_certifications pcert
    WHERE pcert.user_id = p.id
      AND pcert.lejarat IS NOT NULL
      AND pcert.lejarat <= CURRENT_DATE + INTERVAL '60 days'
      AND pcert.lejarat >= CURRENT_DATE
  ) AS hamarosan_lejaro_kepzettseg,
  (SELECT count(*)::int FROM public.profile_peer_links pl
    WHERE (pl.from_user_id = p.id OR pl.to_user_id = p.id)
      AND pl.tipus = 'nem_dolgozik_vele'
      AND pl.status = 'jovahagyott'
  ) AS negativ_kapcsolat_szam
FROM public.profiles p
LEFT JOIN public.profile_employment pe
  ON pe.user_id = p.id AND pe.elsodleges = true;

GRANT SELECT ON public.profile_scheduling_facts TO authenticated;


-- ─── 20260618201611_f5a1a89b-5dd6-4872-8e6b-63fc146b1d24.sql ───

-- ============================================================
-- F kör: kompetencia-domének, szintek, személyi akkreditációk
-- ============================================================

CREATE TABLE IF NOT EXISTS public.competency_domains (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  specialty_id uuid REFERENCES public.specialties(id) ON DELETE SET NULL,
  kulcs text NOT NULL,
  nev text NOT NULL,
  leiras text,
  ervenyes boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, kulcs)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.competency_domains TO authenticated;
GRANT ALL ON public.competency_domains TO service_role;
ALTER TABLE public.competency_domains ENABLE ROW LEVEL SECURITY;

CREATE POLICY cd_select ON public.competency_domains FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY cd_write_admin ON public.competency_domains FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (public.has_permission(auth.uid(),'manage_tenant') OR public.has_permission(auth.uid(),'manage_training')))
  WITH CHECK (tenant_id = public.current_tenant_id() AND (public.has_permission(auth.uid(),'manage_tenant') OR public.has_permission(auth.uid(),'manage_training')));

CREATE TRIGGER cd_touch BEFORE UPDATE ON public.competency_domains
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- Szintek katalógus (tenant-szinten testreszabható)
CREATE TABLE IF NOT EXISTS public.competency_levels (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  kulcs text NOT NULL,
  nev text NOT NULL,
  sorrend smallint NOT NULL,
  felugyeleti_kuszob boolean NOT NULL DEFAULT false,
  leiras text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, kulcs)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.competency_levels TO authenticated;
GRANT ALL ON public.competency_levels TO service_role;
ALTER TABLE public.competency_levels ENABLE ROW LEVEL SECURITY;

CREATE POLICY cl_select ON public.competency_levels FOR SELECT TO authenticated
  USING (tenant_id IS NULL OR tenant_id = public.current_tenant_id());
CREATE POLICY cl_write_admin ON public.competency_levels FOR ALL TO authenticated
  USING (public.has_permission(auth.uid(),'manage_tenant') OR public.has_permission(auth.uid(),'manage_training'))
  WITH CHECK (public.has_permission(auth.uid(),'manage_tenant') OR public.has_permission(auth.uid(),'manage_training'));

CREATE TRIGGER cl_touch BEFORE UPDATE ON public.competency_levels
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- Alap szint-katalógus (NULL tenant = globális)
INSERT INTO public.competency_levels (tenant_id, kulcs, nev, sorrend, felugyeleti_kuszob, leiras) VALUES
  (NULL,'junior','Junior',10,false,'Önállóan korlátozottan végzi, felügyelet alatt áll.'),
  (NULL,'kozephalado','Középhaladó',20,false,'Rutinfeladatokat önállóan, összetetteket konzultációval.'),
  (NULL,'szenior','Szenior',30,false,'Önállóan teljes körben, képes csapatot támogatni.'),
  (NULL,'felugyelo','Felügyelő',40,true,'Felügyeletre jogosult: ügyeletvezető / tutor.'),
  (NULL,'oktato','Oktató',50,true,'Akkreditált oktató / programvezető.')
ON CONFLICT DO NOTHING;

-- Személyi akkreditációk
CREATE TABLE IF NOT EXISTS public.person_accreditations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  domain_id uuid NOT NULL REFERENCES public.competency_domains(id) ON DELETE CASCADE,
  level_id uuid NOT NULL REFERENCES public.competency_levels(id) ON DELETE RESTRICT,
  ervenyes_tol date NOT NULL DEFAULT CURRENT_DATE,
  ervenyes_ig date,
  igazolas_hivatkozas text,
  megjegyzes text,
  jovahagyo_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_pa_user_domain_level_active
  ON public.person_accreditations (tenant_id, user_id, domain_id, level_id)
  WHERE ervenyes_ig IS NULL;

CREATE INDEX IF NOT EXISTS idx_pa_user ON public.person_accreditations (user_id);
CREATE INDEX IF NOT EXISTS idx_pa_domain ON public.person_accreditations (domain_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.person_accreditations TO authenticated;
GRANT ALL ON public.person_accreditations TO service_role;
ALTER TABLE public.person_accreditations ENABLE ROW LEVEL SECURITY;

CREATE POLICY pa_select ON public.person_accreditations FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(),'view_team')
    OR public.has_permission(auth.uid(),'manage_schedule')
    OR public.has_permission(auth.uid(),'manage_tenant')
    OR public.has_permission(auth.uid(),'manage_training')
  ));

CREATE POLICY pa_write_admin ON public.person_accreditations FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    public.has_permission(auth.uid(),'manage_tenant')
    OR public.has_permission(auth.uid(),'manage_training')
  ))
  WITH CHECK (tenant_id = public.current_tenant_id() AND (
    public.has_permission(auth.uid(),'manage_tenant')
    OR public.has_permission(auth.uid(),'manage_training')
  ));

CREATE TRIGGER pa_touch BEFORE UPDATE ON public.person_accreditations
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TRIGGER audit_pa AFTER INSERT OR UPDATE OR DELETE ON public.person_accreditations
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- supervises(): true, ha az adott időpontban a felügyelő szintje >= felügyeleti küszöb,
-- és a felügyelő szintje > a felügyelté ugyanabban a doménben.
CREATE OR REPLACE FUNCTION public.supervises(
  _supervisor_id uuid,
  _supervisee_id uuid,
  _domain_id uuid,
  _at timestamptz DEFAULT now()
)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  WITH sup AS (
    SELECT cl.sorrend AS sor, cl.felugyeleti_kuszob
    FROM public.person_accreditations pa
    JOIN public.competency_levels cl ON cl.id = pa.level_id
    WHERE pa.user_id = _supervisor_id
      AND pa.domain_id = _domain_id
      AND pa.ervenyes_tol <= _at::date
      AND (pa.ervenyes_ig IS NULL OR pa.ervenyes_ig >= _at::date)
    ORDER BY cl.sorrend DESC LIMIT 1
  ),
  sub AS (
    SELECT cl.sorrend AS sor
    FROM public.person_accreditations pa
    JOIN public.competency_levels cl ON cl.id = pa.level_id
    WHERE pa.user_id = _supervisee_id
      AND pa.domain_id = _domain_id
      AND pa.ervenyes_tol <= _at::date
      AND (pa.ervenyes_ig IS NULL OR pa.ervenyes_ig >= _at::date)
    ORDER BY cl.sorrend DESC LIMIT 1
  )
  SELECT COALESCE(
    (SELECT sup.felugyeleti_kuszob AND sup.sor > COALESCE((SELECT sub.sor FROM sub), -1)
     FROM sup),
    false
  );
$$;


-- ─── 20260618201701_1f8a7e40-6cc5-4344-99f4-255bc77a079a.sql ───

-- ============================================================
-- G kör: túlóra preferenciák, elrendelések, keret-nézet
-- ============================================================

DO $$ BEGIN
  CREATE TYPE public.overtime_pref_status AS ENUM ('aktiv','visszavont','lejart');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.overtime_order_status AS ENUM ('tervezett','elrendelt','teljesitve','visszavont');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS public.overtime_preferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  ervenyes_tol date NOT NULL DEFAULT CURRENT_DATE,
  ervenyes_ig date,
  max_ora_havi numeric(6,2),
  napok smallint[] NOT NULL DEFAULT '{}',           -- ISO: 1=hétfő..7=vasárnap
  muszakok text[] NOT NULL DEFAULT '{}',            -- pl. {'nappal','ejszaka','ugyelet','keszenlet'}
  csak_sajat_osztaly boolean NOT NULL DEFAULT false,
  megjegyzes text,
  status public.overtime_pref_status NOT NULL DEFAULT 'aktiv',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_op_user ON public.overtime_preferences (user_id);
CREATE INDEX IF NOT EXISTS idx_op_window ON public.overtime_preferences (ervenyes_tol, ervenyes_ig);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.overtime_preferences TO authenticated;
GRANT ALL ON public.overtime_preferences TO service_role;
ALTER TABLE public.overtime_preferences ENABLE ROW LEVEL SECURITY;

CREATE POLICY op_select ON public.overtime_preferences FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(),'manage_schedule')
    OR public.has_permission(auth.uid(),'view_team')
    OR public.has_permission(auth.uid(),'manage_tenant')
  ));

CREATE POLICY op_write_self_or_admin ON public.overtime_preferences FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(),'manage_tenant')
  ))
  WITH CHECK (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(),'manage_tenant')
  ));

CREATE TRIGGER op_touch BEFORE UPDATE ON public.overtime_preferences
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TRIGGER audit_op AFTER INSERT OR UPDATE OR DELETE ON public.overtime_preferences
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- Elrendelt rendkívüli munka (528/2020 16. §)
CREATE TABLE IF NOT EXISTS public.overtime_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  org_unit_id uuid REFERENCES public.org_units(id) ON DELETE SET NULL,
  kezdo_idopont timestamptz NOT NULL,
  zaro_idopont timestamptz NOT NULL,
  ora numeric(6,2) NOT NULL,
  kategoria text NOT NULL DEFAULT 'rendkivuli',     -- rendkivuli | ugyelet | keszenlet | ovt
  indok text NOT NULL,
  elrendelo_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT,
  elrendeles_at timestamptz NOT NULL DEFAULT now(),
  irasos_hivatkozas text,
  status public.overtime_order_status NOT NULL DEFAULT 'elrendelt',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT oo_time_chk CHECK (zaro_idopont > kezdo_idopont),
  CONSTRAINT oo_ora_chk CHECK (ora > 0)
);

CREATE INDEX IF NOT EXISTS idx_oo_user ON public.overtime_orders (user_id);
CREATE INDEX IF NOT EXISTS idx_oo_time ON public.overtime_orders (kezdo_idopont, zaro_idopont);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.overtime_orders TO authenticated;
GRANT ALL ON public.overtime_orders TO service_role;
ALTER TABLE public.overtime_orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY oo_select ON public.overtime_orders FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(),'manage_schedule')
    OR public.has_permission(auth.uid(),'view_team')
    OR public.has_permission(auth.uid(),'manage_tenant')
  ));

CREATE POLICY oo_write_admin ON public.overtime_orders FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    public.has_permission(auth.uid(),'manage_schedule')
    OR public.has_permission(auth.uid(),'manage_tenant')
  ))
  WITH CHECK (tenant_id = public.current_tenant_id() AND (
    public.has_permission(auth.uid(),'manage_schedule')
    OR public.has_permission(auth.uid(),'manage_tenant')
  ));

CREATE TRIGGER oo_touch BEFORE UPDATE ON public.overtime_orders
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TRIGGER audit_oo AFTER INSERT OR UPDATE OR DELETE ON public.overtime_orders
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- Éves keret-nézet (kihasználtság a work_time_rules küszöbökhöz mérten)
CREATE OR REPLACE VIEW public.v_overtime_ledger_yearly AS
WITH primary_emp AS (
  SELECT DISTINCT ON (pe.user_id)
    pe.user_id, pe.tenant_id, pe.jogviszony_tipus, pe.fenntarto_tipus
  FROM public.profile_employment pe
  WHERE pe.ervenyes = true
  ORDER BY pe.user_id, pe.elsodleges DESC, pe.created_at DESC
),
rules AS (
  SELECT pe.user_id, pe.tenant_id,
         wtr.eves_rendkivuli_max,
         wtr.eves_ugyelet_rendkivuli_max,
         wtr.eves_ovt_rendkivuli_max
  FROM primary_emp pe
  LEFT JOIN public.work_time_rules wtr
    ON (wtr.tenant_id = pe.tenant_id OR wtr.tenant_id IS NULL)
   AND wtr.jogviszony_tipus = pe.jogviszony_tipus
   AND wtr.fenntarto_tipus = pe.fenntarto_tipus
   AND (wtr.ervenyes_ig IS NULL OR wtr.ervenyes_ig >= CURRENT_DATE)
),
agg AS (
  SELECT
    oo.user_id,
    EXTRACT(year FROM oo.kezdo_idopont)::int AS ev,
    SUM(CASE WHEN oo.kategoria = 'rendkivuli' THEN oo.ora ELSE 0 END) AS rendkivuli_ora,
    SUM(CASE WHEN oo.kategoria IN ('rendkivuli','ugyelet') THEN oo.ora ELSE 0 END) AS ugyelet_plus_rendkivuli_ora,
    SUM(CASE WHEN oo.kategoria = 'ovt' THEN oo.ora ELSE 0 END) AS ovt_ora
  FROM public.overtime_orders oo
  WHERE oo.status IN ('elrendelt','teljesitve')
  GROUP BY oo.user_id, EXTRACT(year FROM oo.kezdo_idopont)
)
SELECT
  pe.user_id,
  pe.tenant_id,
  COALESCE(a.ev, EXTRACT(year FROM CURRENT_DATE)::int) AS ev,
  COALESCE(a.rendkivuli_ora, 0) AS rendkivuli_ora,
  COALESCE(a.ugyelet_plus_rendkivuli_ora, 0) AS ugyelet_plus_rendkivuli_ora,
  COALESCE(a.ovt_ora, 0) AS ovt_ora,
  r.eves_rendkivuli_max,
  r.eves_ugyelet_rendkivuli_max,
  r.eves_ovt_rendkivuli_max,
  CASE WHEN r.eves_rendkivuli_max > 0
       THEN ROUND(100 * COALESCE(a.rendkivuli_ora,0) / r.eves_rendkivuli_max, 1) END AS rendkivuli_kihasznaltsag_szazalek,
  CASE WHEN r.eves_ugyelet_rendkivuli_max > 0
       THEN ROUND(100 * COALESCE(a.ugyelet_plus_rendkivuli_ora,0) / r.eves_ugyelet_rendkivuli_max, 1) END AS ugy_rend_kihasznaltsag_szazalek
FROM primary_emp pe
LEFT JOIN rules r ON r.user_id = pe.user_id
LEFT JOIN agg a ON a.user_id = pe.user_id;

GRANT SELECT ON public.v_overtime_ledger_yearly TO authenticated;


-- ─── 20260618201715_f883cb46-0bc4-477a-8dd6-f8d6b43e155b.sql ───
ALTER VIEW public.v_overtime_ledger_yearly SET (security_invoker = true);

-- ─── 20260618201813_7fd8a6b6-03d8-4516-8a00-8b09f6b00f65.sql ───

-- ============================================================
-- H kör: assignments, ledger, díjkódok
-- ============================================================

DO $$ BEGIN
  CREATE TYPE public.ora_kategoria AS ENUM (
    'rendes','ugyelet','keszenlet','ovt','rendkivuli','kompenzalo','szabadsag','tavollet'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.assignment_status AS ENUM ('tervezett','veglegesitett','tenyleges','torolt');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- Tervezett / véglegesített beosztás
CREATE TABLE IF NOT EXISTS public.schedule_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  org_unit_id uuid REFERENCES public.org_units(id) ON DELETE SET NULL,
  site_id uuid REFERENCES public.sites(id) ON DELETE SET NULL,
  feladatkor_id uuid REFERENCES public.feladat_korok(id) ON DELETE SET NULL,
  kezdo_idopont timestamptz NOT NULL,
  zaro_idopont timestamptz NOT NULL,
  ora numeric(6,2) NOT NULL,
  kategoria public.ora_kategoria NOT NULL DEFAULT 'rendes',
  status public.assignment_status NOT NULL DEFAULT 'tervezett',
  pin boolean NOT NULL DEFAULT false,
  forras text,
  megjegyzes text,
  created_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT sa_time_chk CHECK (zaro_idopont > kezdo_idopont),
  CONSTRAINT sa_ora_chk CHECK (ora > 0)
);

CREATE INDEX IF NOT EXISTS idx_sa_user_time ON public.schedule_assignments (user_id, kezdo_idopont, zaro_idopont);
CREATE INDEX IF NOT EXISTS idx_sa_org ON public.schedule_assignments (org_unit_id, kezdo_idopont);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.schedule_assignments TO authenticated;
GRANT ALL ON public.schedule_assignments TO service_role;
ALTER TABLE public.schedule_assignments ENABLE ROW LEVEL SECURITY;

CREATE POLICY sa_select ON public.schedule_assignments FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(),'manage_schedule')
    OR public.has_permission(auth.uid(),'view_team')
    OR public.has_permission(auth.uid(),'manage_tenant')
  ));

CREATE POLICY sa_write_admin ON public.schedule_assignments FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    public.has_permission(auth.uid(),'manage_schedule')
    OR public.has_permission(auth.uid(),'manage_tenant')
  ))
  WITH CHECK (tenant_id = public.current_tenant_id() AND (
    public.has_permission(auth.uid(),'manage_schedule')
    OR public.has_permission(auth.uid(),'manage_tenant')
  ));

CREATE TRIGGER sa_touch BEFORE UPDATE ON public.schedule_assignments
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TRIGGER audit_sa AFTER INSERT OR UPDATE OR DELETE ON public.schedule_assignments
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- Tény munkaidő (számfejtésre)
CREATE TABLE IF NOT EXISTS public.work_time_ledger (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  assignment_id uuid REFERENCES public.schedule_assignments(id) ON DELETE SET NULL,
  org_unit_id uuid REFERENCES public.org_units(id) ON DELETE SET NULL,
  datum date NOT NULL,
  kezdo_idopont timestamptz NOT NULL,
  zaro_idopont timestamptz NOT NULL,
  ora numeric(6,2) NOT NULL,
  kategoria public.ora_kategoria NOT NULL,
  ejszakai_ora numeric(6,2) NOT NULL DEFAULT 0,
  vasarnapi_ora numeric(6,2) NOT NULL DEFAULT 0,
  unnepnapi_ora numeric(6,2) NOT NULL DEFAULT 0,
  jovahagyo_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  jovahagyas_at timestamptz,
  forras text DEFAULT 'kezi',
  megjegyzes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT wtl_time_chk CHECK (zaro_idopont > kezdo_idopont),
  CONSTRAINT wtl_ora_chk CHECK (ora > 0)
);

CREATE INDEX IF NOT EXISTS idx_wtl_user_datum ON public.work_time_ledger (user_id, datum);
CREATE INDEX IF NOT EXISTS idx_wtl_kategoria ON public.work_time_ledger (kategoria);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.work_time_ledger TO authenticated;
GRANT ALL ON public.work_time_ledger TO service_role;
ALTER TABLE public.work_time_ledger ENABLE ROW LEVEL SECURITY;

CREATE POLICY wtl_select ON public.work_time_ledger FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(),'manage_schedule')
    OR public.has_permission(auth.uid(),'view_team')
    OR public.has_permission(auth.uid(),'manage_tenant')
  ));

CREATE POLICY wtl_write_admin ON public.work_time_ledger FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    public.has_permission(auth.uid(),'manage_schedule')
    OR public.has_permission(auth.uid(),'manage_tenant')
  ))
  WITH CHECK (tenant_id = public.current_tenant_id() AND (
    public.has_permission(auth.uid(),'manage_schedule')
    OR public.has_permission(auth.uid(),'manage_tenant')
  ));

CREATE TRIGGER wtl_touch BEFORE UPDATE ON public.work_time_ledger
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TRIGGER audit_wtl AFTER INSERT OR UPDATE OR DELETE ON public.work_time_ledger
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- Díjkód katalógus
CREATE TABLE IF NOT EXISTS public.wage_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  kod text NOT NULL,
  nev text NOT NULL,
  alap_szorzo numeric(5,3) NOT NULL DEFAULT 1.000,
  kategoria text,
  leiras text,
  ervenyes boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, kod)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.wage_codes TO authenticated;
GRANT ALL ON public.wage_codes TO service_role;
ALTER TABLE public.wage_codes ENABLE ROW LEVEL SECURITY;

CREATE POLICY wc_select ON public.wage_codes FOR SELECT TO authenticated
  USING (tenant_id IS NULL OR tenant_id = public.current_tenant_id());

CREATE POLICY wc_write_admin ON public.wage_codes FOR ALL TO authenticated
  USING (public.has_permission(auth.uid(),'manage_tenant'))
  WITH CHECK (public.has_permission(auth.uid(),'manage_tenant'));

CREATE TRIGGER wc_touch BEFORE UPDATE ON public.wage_codes
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- Alap-díjkód katalógus (NULL = globális)
INSERT INTO public.wage_codes (tenant_id, kod, nev, alap_szorzo, kategoria) VALUES
  (NULL,'RENDES','Rendes munkaidő',1.000,'rendes'),
  (NULL,'EJSZ','Éjszakai pótlék (22-06)',1.150,'potlek'),
  (NULL,'VASAR','Vasárnapi pótlék',1.500,'potlek'),
  (NULL,'UNNEP','Munkaszüneti napi pótlék',2.000,'potlek'),
  (NULL,'UGYELET','Ügyeleti díj',1.000,'ugyelet'),
  (NULL,'KESZ','Készenléti díj',0.250,'keszenlet'),
  (NULL,'OVT','Önként vállalt többletmunka',1.500,'ovt'),
  (NULL,'RENDKIV','Rendkívüli munkaidő',1.500,'rendkivuli'),
  (NULL,'KOMP','Kompenzáló pihenőidő',0.000,'kompenzalo')
ON CONFLICT DO NOTHING;

-- Díjkód-leképezés (óra-kategória + sáv → díjkód)
CREATE TABLE IF NOT EXISTS public.wage_mapping (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  kategoria public.ora_kategoria NOT NULL,
  sav text NOT NULL DEFAULT 'nappal',  -- nappal | ejszaka | vasarnap | unnep
  wage_code_id uuid NOT NULL REFERENCES public.wage_codes(id) ON DELETE RESTRICT,
  felulirat_szorzo numeric(5,3),
  prioritas smallint NOT NULL DEFAULT 100,
  ervenyes_tol date NOT NULL DEFAULT CURRENT_DATE,
  ervenyes_ig date,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, kategoria, sav, ervenyes_tol)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.wage_mapping TO authenticated;
GRANT ALL ON public.wage_mapping TO service_role;
ALTER TABLE public.wage_mapping ENABLE ROW LEVEL SECURITY;

CREATE POLICY wm_select ON public.wage_mapping FOR SELECT TO authenticated
  USING (tenant_id IS NULL OR tenant_id = public.current_tenant_id());

CREATE POLICY wm_write_admin ON public.wage_mapping FOR ALL TO authenticated
  USING (public.has_permission(auth.uid(),'manage_tenant'))
  WITH CHECK (public.has_permission(auth.uid(),'manage_tenant'));

CREATE TRIGGER wm_touch BEFORE UPDATE ON public.wage_mapping
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- Nézetek
CREATE OR REPLACE VIEW public.v_napi_pihenes
WITH (security_invoker = true) AS
SELECT
  user_id,
  tenant_id,
  datum,
  MIN(kezdo_idopont) AS elso_kezdes,
  MAX(zaro_idopont) AS utolso_vege,
  ROUND(EXTRACT(epoch FROM (MIN(kezdo_idopont) - LAG(MAX(zaro_idopont)) OVER (PARTITION BY user_id ORDER BY datum)))/3600.0, 2)
    AS piheno_ora_elozo_naphoz
FROM public.work_time_ledger
GROUP BY user_id, tenant_id, datum;

CREATE OR REPLACE VIEW public.v_heti_munkaido
WITH (security_invoker = true) AS
SELECT
  user_id,
  tenant_id,
  date_trunc('week', datum)::date AS het_kezdete,
  kategoria,
  SUM(ora)::numeric(8,2) AS ora_osszesen
FROM public.work_time_ledger
GROUP BY user_id, tenant_id, date_trunc('week', datum), kategoria;

CREATE OR REPLACE VIEW public.v_havi_ledger
WITH (security_invoker = true) AS
SELECT
  user_id,
  tenant_id,
  date_trunc('month', datum)::date AS honap_kezdete,
  kategoria,
  SUM(ora)::numeric(8,2) AS ora_osszesen,
  SUM(ejszakai_ora)::numeric(8,2) AS ejszakai_ora,
  SUM(vasarnapi_ora)::numeric(8,2) AS vasarnapi_ora,
  SUM(unnepnapi_ora)::numeric(8,2) AS unnepnapi_ora
FROM public.work_time_ledger
GROUP BY user_id, tenant_id, date_trunc('month', datum), kategoria;

GRANT SELECT ON public.v_napi_pihenes, public.v_heti_munkaido, public.v_havi_ledger TO authenticated;


-- ─── 20260618201859_85323f7a-49d0-4879-8d86-a6cbeead83fe.sql ───

-- ============================================================
-- I kör: jelenlét + GDPR-hozzájárulás
-- ============================================================

DO $$ BEGIN
  CREATE TYPE public.attendance_event_type AS ENUM ('bejelentkezes','kijelentkezes','szunet_kezdet','szunet_veg','manualis_korrekcio');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.attendance_method AS ENUM ('web','mobil','nfc','qr','manualis','admin');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.consent_purpose AS ENUM (
    'jelenlet_helymeghatarozas','jelenlet_eszkozazonosito','biometrikus','egeszsegugyi_adat',
    'paciensi_kommunikacio','marketing','egyeb'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- Jelenléti horgonyok
CREATE TABLE IF NOT EXISTS public.attendance_anchors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  site_id uuid REFERENCES public.sites(id) ON DELETE SET NULL,
  org_unit_id uuid REFERENCES public.org_units(id) ON DELETE SET NULL,
  nev text NOT NULL,
  tipus text NOT NULL DEFAULT 'geofence',  -- geofence | ip | nfc | qr
  geo_lat numeric(9,6),
  geo_lng numeric(9,6),
  geo_sugar_m integer,
  ip_cidr text,
  nfc_uid text,
  qr_secret text,
  ervenyes boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.attendance_anchors TO authenticated;
GRANT ALL ON public.attendance_anchors TO service_role;
ALTER TABLE public.attendance_anchors ENABLE ROW LEVEL SECURITY;

CREATE POLICY aa_select ON public.attendance_anchors FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());

CREATE POLICY aa_write_admin ON public.attendance_anchors FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_tenant'))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_tenant'));

CREATE TRIGGER aa_touch BEFORE UPDATE ON public.attendance_anchors
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- Jelenlét-események
CREATE TABLE IF NOT EXISTS public.attendance_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  anchor_id uuid REFERENCES public.attendance_anchors(id) ON DELETE SET NULL,
  esemeny_tipus public.attendance_event_type NOT NULL,
  modszer public.attendance_method NOT NULL DEFAULT 'web',
  idopont timestamptz NOT NULL DEFAULT now(),
  eszkoz_azonosito text,
  ip_cim inet,
  geo_lat numeric(9,6),
  geo_lng numeric(9,6),
  geo_pontossag_m numeric(6,2),
  horgony_egyezes boolean,
  user_agent text,
  megjegyzes text,
  korrigalo_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_ae_user_time ON public.attendance_events (user_id, idopont);
CREATE INDEX IF NOT EXISTS idx_ae_anchor ON public.attendance_events (anchor_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.attendance_events TO authenticated;
GRANT ALL ON public.attendance_events TO service_role;
ALTER TABLE public.attendance_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY ae_select ON public.attendance_events FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(),'manage_schedule')
    OR public.has_permission(auth.uid(),'view_team')
    OR public.has_permission(auth.uid(),'manage_tenant')
  ));

-- Dolgozó csak a saját, jelenlegi időpontú eseményt rögzíthet; HR/beosztó bármit
CREATE POLICY ae_insert_self ON public.attendance_events FOR INSERT TO authenticated
  WITH CHECK (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(),'manage_schedule')
    OR public.has_permission(auth.uid(),'manage_tenant')
  ));

CREATE POLICY ae_update_admin ON public.attendance_events FOR UPDATE TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    public.has_permission(auth.uid(),'manage_schedule')
    OR public.has_permission(auth.uid(),'manage_tenant')
  ))
  WITH CHECK (tenant_id = public.current_tenant_id() AND (
    public.has_permission(auth.uid(),'manage_schedule')
    OR public.has_permission(auth.uid(),'manage_tenant')
  ));

CREATE POLICY ae_delete_admin ON public.attendance_events FOR DELETE TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_tenant'));

CREATE TRIGGER audit_ae AFTER INSERT OR UPDATE OR DELETE ON public.attendance_events
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- GDPR hozzájárulások
CREATE TABLE IF NOT EXISTS public.gdpr_consents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  cel public.consent_purpose NOT NULL,
  dokumentum_verzio text NOT NULL,
  elfogadva_at timestamptz NOT NULL DEFAULT now(),
  visszavonva_at timestamptz,
  forras_ip inet,
  forras_user_agent text,
  szoveg_hivatkozas text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, user_id, cel, dokumentum_verzio)
);

CREATE INDEX IF NOT EXISTS idx_gc_user ON public.gdpr_consents (user_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.gdpr_consents TO authenticated;
GRANT ALL ON public.gdpr_consents TO service_role;
ALTER TABLE public.gdpr_consents ENABLE ROW LEVEL SECURITY;

CREATE POLICY gc_select ON public.gdpr_consents FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(),'manage_tenant')
  ));

CREATE POLICY gc_insert_self ON public.gdpr_consents FOR INSERT TO authenticated
  WITH CHECK (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(),'manage_tenant')
  ));

-- Visszavonás (visszavonva_at állítás) a saját rekordra
CREATE POLICY gc_update_self ON public.gdpr_consents FOR UPDATE TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(),'manage_tenant')
  ))
  WITH CHECK (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(),'manage_tenant')
  ));

CREATE TRIGGER gc_touch BEFORE UPDATE ON public.gdpr_consents
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TRIGGER audit_gc AFTER INSERT OR UPDATE OR DELETE ON public.gdpr_consents
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();


-- ─── 20260618202012_45797a01-2f32-4e86-8c8e-f87a68fd3638.sql ───

-- ============================================================
-- J kör: napi prefek, párosítások, EMR + EESZT alapok
-- ============================================================

-- Napi preferenciák
CREATE TABLE IF NOT EXISTS public.profile_daily_preferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  nap_iso smallint NOT NULL CHECK (nap_iso BETWEEN 1 AND 7),  -- 1=hétfő..7=vasárnap
  preferalt_kezd time,
  preferalt_veg time,
  kerult_kezd time,
  kerult_veg time,
  max_muszak_hossz_ora numeric(4,1),
  ugyelet_vallal boolean,
  keszenlet_vallal boolean,
  megjegyzes text,
  ervenyes_tol date NOT NULL DEFAULT CURRENT_DATE,
  ervenyes_ig date,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, user_id, nap_iso, ervenyes_tol)
);

CREATE INDEX IF NOT EXISTS idx_pdp_user ON public.profile_daily_preferences (user_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_daily_preferences TO authenticated;
GRANT ALL ON public.profile_daily_preferences TO service_role;
ALTER TABLE public.profile_daily_preferences ENABLE ROW LEVEL SECURITY;

CREATE POLICY pdp_select ON public.profile_daily_preferences FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(),'view_team')
    OR public.has_permission(auth.uid(),'manage_schedule')
    OR public.has_permission(auth.uid(),'manage_tenant')
  ));

CREATE POLICY pdp_write_self_or_admin ON public.profile_daily_preferences FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid() OR public.has_permission(auth.uid(),'manage_tenant')
  ))
  WITH CHECK (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid() OR public.has_permission(auth.uid(),'manage_tenant')
  ));

CREATE TRIGGER pdp_touch BEFORE UPDATE ON public.profile_daily_preferences
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TRIGGER audit_pdp AFTER INSERT OR UPDATE OR DELETE ON public.profile_daily_preferences
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- Időszaki / műszak-szintű párosítási kérés
DO $$ BEGIN
  CREATE TYPE public.paired_shift_tipus AS ENUM ('egyutt_kivant','egyutt_kerult');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS public.profile_paired_shifts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  partner_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  tipus public.paired_shift_tipus NOT NULL,
  muszak_kulcs text,                       -- pl. 'ugyelet', 'nappali', NULL = bármely
  napok smallint[] NOT NULL DEFAULT '{}',  -- ISO napok, üres = bármely
  ervenyes_tol date NOT NULL DEFAULT CURRENT_DATE,
  ervenyes_ig date,
  suly smallint NOT NULL DEFAULT 50,
  indoklas text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pps_diff CHECK (user_id <> partner_id)
);

CREATE INDEX IF NOT EXISTS idx_pps_user ON public.profile_paired_shifts (user_id);
CREATE INDEX IF NOT EXISTS idx_pps_partner ON public.profile_paired_shifts (partner_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_paired_shifts TO authenticated;
GRANT ALL ON public.profile_paired_shifts TO service_role;
ALTER TABLE public.profile_paired_shifts ENABLE ROW LEVEL SECURITY;

CREATE POLICY pps_select ON public.profile_paired_shifts FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid() OR partner_id = auth.uid()
    OR public.has_permission(auth.uid(),'view_team')
    OR public.has_permission(auth.uid(),'manage_schedule')
    OR public.has_permission(auth.uid(),'manage_tenant')
  ));

CREATE POLICY pps_write_self ON public.profile_paired_shifts FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid() OR public.has_permission(auth.uid(),'manage_tenant')
  ))
  WITH CHECK (tenant_id = public.current_tenant_id() AND (
    user_id = auth.uid() OR public.has_permission(auth.uid(),'manage_tenant')
  ));

CREATE TRIGGER pps_touch BEFORE UPDATE ON public.profile_paired_shifts
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TRIGGER audit_pps AFTER INSERT OR UPDATE OR DELETE ON public.profile_paired_shifts
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ============================================================
-- EMR alapok
-- ============================================================

CREATE TABLE IF NOT EXISTS public.patients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  taj text,
  vezeteknev text NOT NULL,
  keresztnev text NOT NULL,
  szuletesi_datum date,
  nem text CHECK (nem IN ('ferfi','no','egyeb')),
  anyja_neve text,
  fo_diagnozis_bno text,
  gondozo_orvos_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  megjegyzes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, taj)
);

CREATE INDEX IF NOT EXISTS idx_patients_name ON public.patients (tenant_id, vezeteknev, keresztnev);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.patients TO authenticated;
GRANT ALL ON public.patients TO service_role;
ALTER TABLE public.patients ENABLE ROW LEVEL SECURITY;

CREATE POLICY pat_select ON public.patients FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_patients'));

CREATE POLICY pat_write ON public.patients FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_patients'))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_patients'));

CREATE TRIGGER pat_touch BEFORE UPDATE ON public.patients
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TRIGGER audit_pat AFTER INSERT OR UPDATE OR DELETE ON public.patients
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- Páciens találkozók
DO $$ BEGIN
  CREATE TYPE public.encounter_tipus AS ENUM ('ambulans','fekvobeteg','muteti','konzilium','telemedicina','egyeb');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS public.patient_encounters (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  ellatas_kezdete timestamptz NOT NULL,
  ellatas_vege timestamptz,
  tipus public.encounter_tipus NOT NULL,
  org_unit_id uuid REFERENCES public.org_units(id) ON DELETE SET NULL,
  site_id uuid REFERENCES public.sites(id) ON DELETE SET NULL,
  vezeto_orvos_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  bno_kodok text[] NOT NULL DEFAULT '{}',
  oeno_kodok text[] NOT NULL DEFAULT '{}',
  beavatkozas_ids uuid[] NOT NULL DEFAULT '{}',
  osszefoglalo text,
  intezmenyi_azonosito text,
  status text NOT NULL DEFAULT 'nyitott',  -- nyitott | lezart | torolt
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_pe_patient ON public.patient_encounters (patient_id, ellatas_kezdete DESC);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.patient_encounters TO authenticated;
GRANT ALL ON public.patient_encounters TO service_role;
ALTER TABLE public.patient_encounters ENABLE ROW LEVEL SECURITY;

CREATE POLICY penc_select ON public.patient_encounters FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_patients'));

CREATE POLICY penc_write ON public.patient_encounters FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_patients'))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_patients'));

CREATE TRIGGER penc_touch BEFORE UPDATE ON public.patient_encounters
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TRIGGER audit_penc AFTER INSERT OR UPDATE OR DELETE ON public.patient_encounters
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- EESZT azonosító-leképezés (akkreditált rendszer integrálja a tényleges adatcserét)
CREATE TABLE IF NOT EXISTS public.eeszt_patient_links (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  eeszt_page_id text,
  eeszt_org_oid text,
  hozzajarulas_status text NOT NULL DEFAULT 'ismeretlen',  -- van | nincs | visszavont | ismeretlen
  hozzajarulas_at timestamptz,
  utolso_szinkron_at timestamptz,
  megjegyzes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, patient_id)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.eeszt_patient_links TO authenticated;
GRANT ALL ON public.eeszt_patient_links TO service_role;
ALTER TABLE public.eeszt_patient_links ENABLE ROW LEVEL SECURITY;

CREATE POLICY eep_select ON public.eeszt_patient_links FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_patients'));

CREATE POLICY eep_write_admin ON public.eeszt_patient_links FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_tenant'))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_tenant'));

CREATE TRIGGER eep_touch BEFORE UPDATE ON public.eeszt_patient_links
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TRIGGER audit_eep AFTER INSERT OR UPDATE OR DELETE ON public.eeszt_patient_links
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();


-- ─── 20260618202246_8847f6d2-509d-4d3d-bf1e-de28bbc1289a.sql ───

-- ============================================================
-- Munkaszüneti napok
-- ============================================================
CREATE TABLE IF NOT EXISTS public.public_holidays (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,  -- NULL = globális
  datum date NOT NULL,
  nev text NOT NULL,
  fizetett boolean NOT NULL DEFAULT true,
  forrasszoveg text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, datum)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.public_holidays TO authenticated;
GRANT ALL ON public.public_holidays TO service_role;
ALTER TABLE public.public_holidays ENABLE ROW LEVEL SECURITY;

CREATE POLICY ph_select ON public.public_holidays FOR SELECT TO authenticated
  USING (tenant_id IS NULL OR tenant_id = public.current_tenant_id());

CREATE POLICY ph_write_admin ON public.public_holidays FOR ALL TO authenticated
  USING (public.has_permission(auth.uid(),'manage_tenant'))
  WITH CHECK (public.has_permission(auth.uid(),'manage_tenant'));

CREATE TRIGGER ph_touch BEFORE UPDATE ON public.public_holidays
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- Magyar 2026–2027 munkaszüneti napok (globális seed)
INSERT INTO public.public_holidays (tenant_id, datum, nev, fizetett) VALUES
  (NULL,'2026-01-01','Újév',true),
  (NULL,'2026-03-15','Nemzeti ünnep',true),
  (NULL,'2026-04-03','Nagypéntek',true),
  (NULL,'2026-04-05','Húsvétvasárnap',true),
  (NULL,'2026-04-06','Húsvéthétfő',true),
  (NULL,'2026-05-01','Munka ünnepe',true),
  (NULL,'2026-05-24','Pünkösdvasárnap',true),
  (NULL,'2026-05-25','Pünkösdhétfő',true),
  (NULL,'2026-08-20','Államalapítás ünnepe',true),
  (NULL,'2026-10-23','Nemzeti ünnep',true),
  (NULL,'2026-11-01','Mindenszentek',true),
  (NULL,'2026-12-25','Karácsony',true),
  (NULL,'2026-12-26','Karácsony 2. napja',true),
  (NULL,'2027-01-01','Újév',true),
  (NULL,'2027-03-15','Nemzeti ünnep',true),
  (NULL,'2027-03-26','Nagypéntek',true),
  (NULL,'2027-03-28','Húsvétvasárnap',true),
  (NULL,'2027-03-29','Húsvéthétfő',true),
  (NULL,'2027-05-01','Munka ünnepe',true),
  (NULL,'2027-05-16','Pünkösdvasárnap',true),
  (NULL,'2027-05-17','Pünkösdhétfő',true),
  (NULL,'2027-08-20','Államalapítás ünnepe',true),
  (NULL,'2027-10-23','Nemzeti ünnep',true),
  (NULL,'2027-11-01','Mindenszentek',true),
  (NULL,'2027-12-25','Karácsony',true),
  (NULL,'2027-12-26','Karácsony 2. napja',true)
ON CONFLICT DO NOTHING;

-- ============================================================
-- Pótlék-sávok számítása
-- ============================================================
CREATE OR REPLACE FUNCTION public.compute_potlek_savs(_kezdo timestamptz, _zaro timestamptz)
RETURNS TABLE(ejszakai_ora numeric, vasarnapi_ora numeric, unnepnapi_ora numeric)
LANGUAGE plpgsql
STABLE
SET search_path = public
AS $$
DECLARE
  v_cur timestamptz := _kezdo;
  v_step timestamptz;
  v_ej numeric := 0;
  v_vas numeric := 0;
  v_un numeric := 0;
  v_h numeric;
  v_dow int;
  v_is_holiday boolean;
  v_hour int;
BEGIN
  -- 15 perces lépésekben bontunk, így percpontosság alatti ferde számítási hiba nélkül
  WHILE v_cur < _zaro LOOP
    v_step := LEAST(v_cur + interval '15 minutes', _zaro);
    v_h := EXTRACT(epoch FROM (v_step - v_cur)) / 3600.0;
    v_dow := EXTRACT(isodow FROM v_cur);
    v_hour := EXTRACT(hour FROM v_cur);

    SELECT EXISTS(
      SELECT 1 FROM public.public_holidays
      WHERE datum = v_cur::date
        AND (tenant_id IS NULL OR tenant_id = public.current_tenant_id())
    ) INTO v_is_holiday;

    IF v_hour >= 22 OR v_hour < 6 THEN
      v_ej := v_ej + v_h;
    END IF;
    IF v_dow = 7 THEN
      v_vas := v_vas + v_h;
    END IF;
    IF v_is_holiday THEN
      v_un := v_un + v_h;
    END IF;

    v_cur := v_step;
  END LOOP;
  RETURN QUERY SELECT v_ej, v_vas, v_un;
END;
$$;

-- Trigger: work_time_ledger automatikus sáv-kitöltés
CREATE OR REPLACE FUNCTION public.wtl_compute_savs_fn()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
DECLARE
  r RECORD;
BEGIN
  SELECT * INTO r FROM public.compute_potlek_savs(NEW.kezdo_idopont, NEW.zaro_idopont);
  NEW.ejszakai_ora := COALESCE(r.ejszakai_ora, 0);
  NEW.vasarnapi_ora := COALESCE(r.vasarnapi_ora, 0);
  NEW.unnepnapi_ora := COALESCE(r.unnepnapi_ora, 0);
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS wtl_compute_savs ON public.work_time_ledger;
CREATE TRIGGER wtl_compute_savs
  BEFORE INSERT OR UPDATE OF kezdo_idopont, zaro_idopont
  ON public.work_time_ledger
  FOR EACH ROW EXECUTE FUNCTION public.wtl_compute_savs_fn();

-- ============================================================
-- Bér-szimuláció (NEM számfejt!)
-- ============================================================
CREATE OR REPLACE FUNCTION public.wage_simulation(_user_id uuid, _honap_kezdete date)
RETURNS TABLE(
  wage_code_id uuid,
  kod text,
  nev text,
  ora numeric,
  szorzo numeric,
  egysegek numeric
)
LANGUAGE sql
STABLE SECURITY INVOKER
SET search_path = public
AS $$
  WITH ledger AS (
    SELECT wtl.user_id, wtl.tenant_id, wtl.kategoria,
           wtl.ora, wtl.ejszakai_ora, wtl.vasarnapi_ora, wtl.unnepnapi_ora
    FROM public.work_time_ledger wtl
    WHERE wtl.user_id = _user_id
      AND wtl.datum >= _honap_kezdete
      AND wtl.datum < (_honap_kezdete + interval '1 month')::date
  ),
  -- alap-óradíj a kategória nappali leképezésével
  alap AS (
    SELECT wm.kategoria,
           wc.id AS wage_code_id, wc.kod, wc.nev,
           COALESCE(wm.felulirat_szorzo, wc.alap_szorzo) AS szorzo,
           SUM(l.ora - l.ejszakai_ora - l.vasarnapi_ora - l.unnepnapi_ora) AS ora
    FROM ledger l
    JOIN public.wage_mapping wm
      ON wm.kategoria = l.kategoria AND wm.sav = 'nappal'
     AND (wm.tenant_id IS NULL OR wm.tenant_id = l.tenant_id)
     AND (wm.ervenyes_ig IS NULL OR wm.ervenyes_ig >= _honap_kezdete)
    JOIN public.wage_codes wc ON wc.id = wm.wage_code_id
    GROUP BY wm.kategoria, wc.id, wc.kod, wc.nev, wm.felulirat_szorzo, wc.alap_szorzo
  ),
  potlek AS (
    SELECT sav, SUM(ora) AS ora
    FROM (
      SELECT 'ejszaka'::text AS sav, SUM(ejszakai_ora) AS ora FROM ledger
      UNION ALL
      SELECT 'vasarnap', SUM(vasarnapi_ora) FROM ledger
      UNION ALL
      SELECT 'unnep', SUM(unnepnapi_ora) FROM ledger
    ) s
    GROUP BY sav
  ),
  potlek_mapped AS (
    SELECT wc.id AS wage_code_id, wc.kod, wc.nev,
           COALESCE(wm.felulirat_szorzo, wc.alap_szorzo) AS szorzo,
           p.ora
    FROM potlek p
    JOIN public.wage_mapping wm ON wm.sav = p.sav
    JOIN public.wage_codes wc ON wc.id = wm.wage_code_id
    WHERE p.ora > 0
  ),
  egyesitett AS (
    SELECT wage_code_id, kod, nev, ora, szorzo FROM alap WHERE ora > 0
    UNION ALL
    SELECT wage_code_id, kod, nev, ora, szorzo FROM potlek_mapped
  )
  SELECT wage_code_id, kod, nev,
         ROUND(SUM(ora)::numeric, 2) AS ora,
         MAX(szorzo) AS szorzo,
         ROUND(SUM(ora * szorzo)::numeric, 2) AS egysegek
  FROM egyesitett
  GROUP BY wage_code_id, kod, nev
  ORDER BY kod;
$$;

-- ============================================================
-- incompatibilities jóváhagyási őr
-- ============================================================
CREATE OR REPLACE FUNCTION public.incompatibilities_guard()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_is_hr boolean := COALESCE(public.has_permission(v_uid,'manage_tenant'), false);
BEGIN
  IF TG_OP = 'UPDATE' AND NEW.status IS DISTINCT FROM OLD.status
     AND NEW.status IN ('jovahagyott','elutasitott') THEN
    IF NOT v_is_hr THEN
      INSERT INTO public.admin_audit_log(tenant_id, user_id, action, table_name, record_id, before_data, after_data)
      VALUES (COALESCE(NEW.tenant_id, public.current_tenant_id()), v_uid, 'FORBIDDEN_APPROVAL',
              TG_TABLE_NAME, NEW.id::text,
              jsonb_build_object('status', OLD.status),
              jsonb_build_object('status', NEW.status));
      RAISE EXCEPTION 'Összeférhetetlenség jóváhagyása csak HR (tenant-admin) jogosultsággal lehetséges.'
        USING ERRCODE = '42501';
    END IF;
    IF NEW.user_id = v_uid THEN
      RAISE EXCEPTION 'A saját bejelentését nem hagyhatja jóvá.' USING ERRCODE = '42501';
    END IF;
    IF NEW.status = 'elutasitott' AND COALESCE(btrim(NEW.jovahagyas_indok), '') = '' THEN
      RAISE EXCEPTION 'Elutasításhoz kötelező az indoklás.' USING ERRCODE = '22023';
    END IF;
    NEW.jovahagyo_id := v_uid;
    NEW.jovahagyas_at := now();
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS incompatibilities_approval ON public.incompatibilities;
CREATE TRIGGER incompatibilities_approval
  BEFORE UPDATE ON public.incompatibilities
  FOR EACH ROW EXECUTE FUNCTION public.incompatibilities_guard();

-- ============================================================
-- További work_time_rules seedek
-- ============================================================
INSERT INTO public.work_time_rules
  (tenant_id, jogviszony_tipus, fenntarto_tipus, forrasszoveg)
VALUES
  (NULL,'kjt_kozalkalmazott','egyhazi','Kjt + Eütev. (egyházi fenntartó)'),
  (NULL,'kjt_kozalkalmazott','onkormanyzati','Kjt + Eütev.'),
  (NULL,'munka_tv_kv','egyetemi_klinika','Mt. + Eütev. (egyetemi klinika)'),
  (NULL,'munka_tv_kv','allami','Mt. + Eütev.'),
  (NULL,'megbizasi','allami','Ptk. megbízási, Eütev. nem alkalmazandó közvetlenül'),
  (NULL,'egyeni_vallalkozo','maganszektor','Egyéni vállalkozó, önszabályozott'),
  (NULL,'rezidens_kepzes','egyetemi_klinika','Eütev. + 162/2015 rezidens-rendelet'),
  (NULL,'rezidens_kepzes','allami','Eütev. + 162/2015 rezidens-rendelet')
ON CONFLICT DO NOTHING;


-- ─── 20260618205421_34777c5c-8a32-4ca4-9037-442bd1f88141.sql ───
-- Schedule runs (solver futtatás-naplók) + magyarázatok
CREATE TABLE IF NOT EXISTS public.schedule_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  indito_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  idoszak_kezdet date NOT NULL,
  idoszak_veg date NOT NULL,
  org_unit_id uuid REFERENCES public.org_units(id) ON DELETE SET NULL,
  solver text NOT NULL DEFAULT 'yalps',
  status text NOT NULL DEFAULT 'kesz',  -- futo | kesz | hibas | elvetett
  parameterek jsonb NOT NULL DEFAULT '{}'::jsonb,
  eredmeny_osszegzes jsonb NOT NULL DEFAULT '{}'::jsonb,
  hard_sertes_szam int NOT NULL DEFAULT 0,
  lagy_pontszam numeric(10,2) NOT NULL DEFAULT 0,
  hibauzenet text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.schedule_runs TO authenticated;
GRANT ALL ON public.schedule_runs TO service_role;
ALTER TABLE public.schedule_runs ENABLE ROW LEVEL SECURITY;

CREATE POLICY sr_select ON public.schedule_runs FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());

CREATE POLICY sr_write_admin ON public.schedule_runs FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (public.has_permission(auth.uid(),'manage_schedule') OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id() AND (public.has_permission(auth.uid(),'manage_schedule') OR public.has_permission(auth.uid(),'manage_tenant')));

CREATE TRIGGER sr_touch BEFORE UPDATE ON public.schedule_runs
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- Magyarázat-tételek (assignment-szintű "miért így döntött a solver")
CREATE TABLE IF NOT EXISTS public.schedule_explanations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  run_id uuid NOT NULL REFERENCES public.schedule_runs(id) ON DELETE CASCADE,
  assignment_id uuid REFERENCES public.schedule_assignments(id) ON DELETE CASCADE,
  user_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  datum date,
  szint text NOT NULL DEFAULT 'info',  -- info | figyelmeztetes | sertes
  kulcs text NOT NULL,                  -- pl. 'preferencia', 'paros_kivant', 'utolso_jeloltent'
  szoveg text NOT NULL,
  sulyozas numeric(8,2),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_se_run ON public.schedule_explanations (run_id);
CREATE INDEX IF NOT EXISTS idx_se_assignment ON public.schedule_explanations (assignment_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.schedule_explanations TO authenticated;
GRANT ALL ON public.schedule_explanations TO service_role;
ALTER TABLE public.schedule_explanations ENABLE ROW LEVEL SECURITY;

CREATE POLICY se_select ON public.schedule_explanations FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());

CREATE POLICY se_write_admin ON public.schedule_explanations FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND (public.has_permission(auth.uid(),'manage_schedule') OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id() AND (public.has_permission(auth.uid(),'manage_schedule') OR public.has_permission(auth.uid(),'manage_tenant')));

-- Hozzáadjuk a schedule_assignments-hez a run_id mezőt (NULL = kézi)
ALTER TABLE public.schedule_assignments
  ADD COLUMN IF NOT EXISTS run_id uuid REFERENCES public.schedule_runs(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_sa_run ON public.schedule_assignments (run_id);


-- ─── 20260618215827_8c7e651d-9111-4bf5-9e13-c3b3544f4f05.sql ───

ALTER TABLE public.patient_encounters
  ADD COLUMN IF NOT EXISTS szerzo_id uuid REFERENCES auth.users(id),
  ADD COLUMN IF NOT EXISTS szerzo_alairas_at timestamptz,
  ADD COLUMN IF NOT EXISTS ellenjegyzo_id uuid REFERENCES auth.users(id),
  ADD COLUMN IF NOT EXISTS ellenjegyzo_alairas_at timestamptz;

-- Immutability check: when status='ellenjegyezve' do not allow body changes
CREATE OR REPLACE FUNCTION public.patient_encounters_lock_signed()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
BEGIN
  IF OLD.status = 'ellenjegyezve' AND NEW.status = 'ellenjegyezve' THEN
    IF NEW.bno_kodok IS DISTINCT FROM OLD.bno_kodok
       OR NEW.oeno_kodok IS DISTINCT FROM OLD.oeno_kodok
       OR NEW.beavatkozas_ids IS DISTINCT FROM OLD.beavatkozas_ids
       OR NEW.osszefoglalo IS DISTINCT FROM OLD.osszefoglalo
       OR NEW.ellatas_kezdete IS DISTINCT FROM OLD.ellatas_kezdete
       OR NEW.ellatas_vege IS DISTINCT FROM OLD.ellatas_vege THEN
      RAISE EXCEPTION 'A lezárt (ellenjegyzett) ellátás nem módosítható.';
    END IF;
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_patient_encounters_lock ON public.patient_encounters;
CREATE TRIGGER trg_patient_encounters_lock
  BEFORE UPDATE ON public.patient_encounters
  FOR EACH ROW EXECUTE FUNCTION public.patient_encounters_lock_signed();


-- ─── 20260618220222_736b3d34-efc9-4fb9-a21b-9b5e90cd63d0.sql ───
create extension if not exists pg_trgm with schema public;

create index if not exists idx_patients_fullname_trgm
  on public.patients using gin ((coalesce(vezeteknev,'') || ' ' || coalesce(keresztnev,'')) gin_trgm_ops);

create index if not exists idx_patients_taj on public.patients (taj);

create or replace function public.search_patients(_q text, _limit int default 20)
returns table (
  id uuid,
  taj text,
  vezeteknev text,
  keresztnev text,
  szuletesi_datum date,
  nem text,
  fo_diagnozis_bno text,
  score real
)
language sql
stable
security invoker
set search_path = public
as $$
  select p.id, p.taj, p.vezeteknev, p.keresztnev, p.szuletesi_datum, p.nem, p.fo_diagnozis_bno,
    greatest(
      similarity(coalesce(p.vezeteknev,'') || ' ' || coalesce(p.keresztnev,''), coalesce(_q,'')),
      case when p.taj is not null and _q is not null and p.taj like '%' || _q || '%' then 1.0 else 0 end
    )::real as score
  from public.patients p
  where _q is null or _q = ''
     or (coalesce(p.vezeteknev,'') || ' ' || coalesce(p.keresztnev,'')) % _q
     or p.taj ilike '%' || _q || '%'
  order by score desc, p.vezeteknev
  limit greatest(1, least(_limit, 100));
$$;

grant execute on function public.search_patients(text, int) to authenticated;

create or replace function public._enc_progress_beavatkozasok()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  bid uuid;
begin
  if NEW.szerzo_alairas_at is not null
     and (OLD.szerzo_alairas_at is null)
     and NEW.szerzo_id is not null
     and NEW.beavatkozas_ids is not null
     and array_length(NEW.beavatkozas_ids, 1) > 0
  then
    foreach bid in array NEW.beavatkozas_ids loop
      insert into public.profile_beavatkozasok
        (tenant_id, user_id, beavatkozas_id, alkalom, datum, megjegyzes, mentor_igazolt, mentor_user_id)
      values
        (NEW.tenant_id, NEW.szerzo_id, bid, 1,
         (NEW.ellatas_kezdete)::date,
         'encounter:' || NEW.id::text,
         (NEW.ellenjegyzo_id is not null),
         NEW.ellenjegyzo_id)
      on conflict do nothing;
    end loop;
  end if;
  return NEW;
end;
$$;

drop trigger if exists trg_enc_progress_beavatkozasok on public.patient_encounters;
create trigger trg_enc_progress_beavatkozasok
  after update of szerzo_alairas_at on public.patient_encounters
  for each row execute function public._enc_progress_beavatkozasok();

-- ─── 20260619065750_22953a03-1128-45a8-b74f-fcfab8c3e4d3.sql ───
CREATE TABLE public.schedule_share_tokens (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tenant_id UUID NOT NULL,
  token TEXT NOT NULL UNIQUE,
  scope_month DATE NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  created_by UUID NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  revoked_at TIMESTAMPTZ
);

CREATE INDEX idx_share_tokens_tenant ON public.schedule_share_tokens(tenant_id);
CREATE INDEX idx_share_tokens_token ON public.schedule_share_tokens(token) WHERE revoked_at IS NULL;

GRANT SELECT, INSERT, UPDATE ON public.schedule_share_tokens TO authenticated;
GRANT ALL ON public.schedule_share_tokens TO service_role;

ALTER TABLE public.schedule_share_tokens ENABLE ROW LEVEL SECURITY;

CREATE POLICY "share_tokens_select_own_tenant"
  ON public.schedule_share_tokens
  FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());

CREATE POLICY "share_tokens_insert_schedule_managers"
  ON public.schedule_share_tokens
  FOR INSERT TO authenticated
  WITH CHECK (
    tenant_id = public.current_tenant_id()
    AND created_by = auth.uid()
    AND (public.has_permission(auth.uid(), 'manage_schedule')
         OR public.has_permission(auth.uid(), 'manage_tenant'))
  );

CREATE POLICY "share_tokens_revoke_schedule_managers"
  ON public.schedule_share_tokens
  FOR UPDATE TO authenticated
  USING (
    tenant_id = public.current_tenant_id()
    AND (public.has_permission(auth.uid(), 'manage_schedule')
         OR public.has_permission(auth.uid(), 'manage_tenant'))
  );

-- ─── 20260619070243_d57da481-ea3c-4bec-ae07-368515f9f620.sql ───
CREATE TRIGGER schedule_share_tokens_audit
AFTER INSERT OR UPDATE OR DELETE ON public.schedule_share_tokens
FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ─── 20260619070742_da642475-944c-421c-82d5-dc16731ae6e2.sql ───
DO $$
DECLARE
  v_tenant uuid := '13aacb24-a6c2-445c-84b5-5ddbd1fcca82';
  v_pw text := crypt('test1234', gen_salt('bf'));
  new_id uuid;
  v_role_id uuid;
  orvosok text[][] := ARRAY[
    ['Kovács','Anna','foorvos'],['Nagy','Béla','foorvos'],
    ['Szabó','Csilla','szakorvos'],['Tóth','Dániel','szakorvos'],
    ['Horváth','Eszter','szakorvos'],['Varga','Ferenc','szakorvos'],
    ['Kiss','Gábor','rezidens'],['Molnár','Hanna','rezidens'],
    ['Németh','István','rezidens'],['Farkas','Júlia','rezidens'],
    ['Balogh','Krisztián','szakgyakornok'],['Papp','Laura','szakgyakornok'],
    ['Takács','Márton','szakgyakornok'],['Juhász','Nóra','szakgyakornok'],
    ['Lakatos','Orsolya','vezetorezidens'],['Mészáros','Péter','vezetorezidens'],
    ['Oláh','Réka','ugyeletvezeto'],['Simon','Szabolcs','ugyeletvezeto'],
    ['Rácz','Tímea','intezetvezeto'],['Fekete','Viktor','intezetvezeto']
  ];
  szakd text[][] := ARRAY[
    ['Bognár','Adél','gyakorlo'],['Sándor','Bence','gyakorlo'],
    ['Antal','Csenge','gyakorlo'],['Bíró','Donát','gyakorlo'],
    ['Fodor','Eleonóra','pro'],['Gál','Flórián','pro'],
    ['Halász','Gabriella','pro'],['Hegedűs','Hubert','pro'],
    ['Király','Ilona','pro'],['Lukács','János','pro'],
    ['Major','Katalin','mester'],['Pál','Levente','mester'],
    ['Pásztor','Melinda','mester'],['Pintér','Norbert','mester'],
    ['Soós','Petra','szakteruleti_expert'],['Sipos','Roland','szakteruleti_expert'],
    ['Tamás','Sára','szakteruleti_expert'],['Váradi','Tibor','gyakornok_szakd'],
    ['Veres','Ursula','gyakornok_szakd'],['Vincze','Zoltán','gyakornok_szakd']
  ];
  i int; v_email text; v_nev text; v_role text; v_fogl text;
BEGIN
  FOR i IN 1..40 LOOP
    IF i <= 20 THEN
      v_nev := 'Dr. ' || orvosok[i][1] || ' ' || orvosok[i][2];
      v_email := 'teszt.orvos' || lpad(i::text,2,'0') || '@szilika.test';
      v_role := orvosok[i][3]; v_fogl := 'orvos';
    ELSE
      v_nev := szakd[i-20][1] || ' ' || szakd[i-20][2];
      v_email := 'teszt.szakd' || lpad((i-20)::text,2,'0') || '@szilika.test';
      v_role := szakd[i-20][3]; v_fogl := 'szakdolgozo';
    END IF;

    SELECT id INTO new_id FROM auth.users WHERE email = v_email LIMIT 1;
    IF new_id IS NULL THEN
      new_id := gen_random_uuid();
      INSERT INTO auth.users (instance_id, id, aud, role, email, encrypted_password,
        email_confirmed_at, created_at, updated_at, raw_app_meta_data, raw_user_meta_data, is_super_admin)
      VALUES ('00000000-0000-0000-0000-000000000000', new_id, 'authenticated', 'authenticated',
        v_email, v_pw, now(), now(), now(),
        '{"provider":"email","providers":["email"]}'::jsonb,
        jsonb_build_object('teljes_nev', v_nev, 'seed', true), false);

      INSERT INTO auth.identities (id, user_id, identity_data, provider, provider_id, last_sign_in_at, created_at, updated_at)
      VALUES (gen_random_uuid(), new_id,
        jsonb_build_object('sub', new_id::text, 'email', v_email, 'email_verified', true),
        'email', v_email, now(), now(), now());
    END IF;

    INSERT INTO public.profiles (id, tenant_id, email, teljes_nev, foglalkozas_tipus, aktiv)
    VALUES (new_id, v_tenant, v_email, v_nev, v_fogl::public.foglalkozas_tipus, true)
    ON CONFLICT (id) DO UPDATE
      SET tenant_id = EXCLUDED.tenant_id,
          teljes_nev = EXCLUDED.teljes_nev,
          foglalkozas_tipus = EXCLUDED.foglalkozas_tipus,
          aktiv = true;

    SELECT id INTO v_role_id FROM public.roles WHERE kulcs = v_role;
    IF v_role_id IS NOT NULL THEN
      INSERT INTO public.user_roles (user_id, role_id, tenant_id, ervenyes_tol)
      VALUES (new_id, v_role_id, v_tenant, now()) ON CONFLICT DO NOTHING;
    END IF;
  END LOOP;
END $$;

-- ─── 20260619071612_9051268e-530e-49a7-a407-3c77d7ea637b.sql ───

CREATE TABLE public.notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  tipus text NOT NULL DEFAULT 'info',
  cim text NOT NULL,
  uzenet text,
  link text,
  olvasott_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.notifications TO authenticated;
GRANT ALL ON public.notifications TO service_role;

CREATE INDEX notifications_user_unread_idx
  ON public.notifications (user_id, created_at DESC)
  WHERE olvasott_at IS NULL;

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Saját értesítések olvasása"
  ON public.notifications FOR SELECT
  TO authenticated
  USING (user_id = auth.uid() OR public.has_permission(auth.uid(), 'manage_tenant'));

CREATE POLICY "Saját értesítések frissítése (olvasott)"
  ON public.notifications FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Saját értesítések törlése"
  ON public.notifications FOR DELETE
  TO authenticated
  USING (user_id = auth.uid());

-- Insert: csak service_role / privileged backend hoz létre értesítést.
CREATE POLICY "Tenant-admin értesítést készíthet"
  ON public.notifications FOR INSERT
  TO authenticated
  WITH CHECK (public.has_permission(auth.uid(), 'manage_tenant'));


-- ─── 20260619071739_e1e81c59-93fe-451f-8582-b2cf588321ee.sql ───

-- Beosztás-értesítés
CREATE OR REPLACE FUNCTION public.notify_new_shift()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.user_id IS NOT NULL THEN
    INSERT INTO public.notifications (tenant_id, user_id, tipus, cim, uzenet, link)
    VALUES (
      NEW.tenant_id,
      NEW.user_id,
      'beosztas',
      'Új műszak a beosztásban',
      to_char(NEW.kezdo_idopont AT TIME ZONE 'Europe/Budapest', 'YYYY-MM-DD HH24:MI')
        || ' – '
        || to_char(NEW.zaro_idopont AT TIME ZONE 'Europe/Budapest', 'HH24:MI')
        || ' (' || COALESCE(NEW.kategoria::text, 'műszak') || ')',
      '/munkaido'
    );
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_notify_new_shift ON public.schedule_assignments;
CREATE TRIGGER trg_notify_new_shift
  AFTER INSERT ON public.schedule_assignments
  FOR EACH ROW
  EXECUTE FUNCTION public.notify_new_shift();

-- Távollét-kérelem státuszváltozás értesítés
CREATE OR REPLACE FUNCTION public.notify_unavailability_status()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_cim text;
  v_uzenet text;
BEGIN
  IF NEW.status IS DISTINCT FROM OLD.status
     AND NEW.status IN ('jovahagyott','elutasitott') THEN
    IF NEW.status = 'jovahagyott' THEN
      v_cim := 'Távollét-kérelem jóváhagyva';
      v_uzenet := to_char(NEW.kezdo_datum, 'YYYY-MM-DD') || ' – ' || to_char(NEW.zaro_datum, 'YYYY-MM-DD');
    ELSE
      v_cim := 'Távollét-kérelem elutasítva';
      v_uzenet := to_char(NEW.kezdo_datum, 'YYYY-MM-DD') || ' – ' || to_char(NEW.zaro_datum, 'YYYY-MM-DD')
                  || COALESCE(E'\nIndoklás: ' || NEW.jovahagyas_indok, '');
    END IF;

    INSERT INTO public.notifications (tenant_id, user_id, tipus, cim, uzenet, link)
    VALUES (NEW.tenant_id, NEW.user_id, 'tavollet', v_cim, v_uzenet, '/karakterlap');
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_notify_unavailability_status ON public.profile_unavailability;
CREATE TRIGGER trg_notify_unavailability_status
  AFTER UPDATE ON public.profile_unavailability
  FOR EACH ROW
  EXECUTE FUNCTION public.notify_unavailability_status();

-- Preferencia státuszváltozás értesítés
CREATE OR REPLACE FUNCTION public.notify_preferences_status()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_cim text;
BEGIN
  IF NEW.status IS DISTINCT FROM OLD.status
     AND NEW.status IN ('jovahagyott','elutasitott') THEN
    v_cim := CASE NEW.status
      WHEN 'jovahagyott' THEN 'Preferencia jóváhagyva'
      ELSE 'Preferencia elutasítva'
    END;

    INSERT INTO public.notifications (tenant_id, user_id, tipus, cim, uzenet, link)
    VALUES (
      NEW.tenant_id,
      NEW.user_id,
      'preferencia',
      v_cim,
      COALESCE(NEW.jovahagyas_indok, NULL),
      '/karakterlap'
    );
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_notify_preferences_status ON public.profile_preferences;
CREATE TRIGGER trg_notify_preferences_status
  AFTER UPDATE ON public.profile_preferences
  FOR EACH ROW
  EXECUTE FUNCTION public.notify_preferences_status();


-- ─── 20260619074207_ff011f72-630f-490d-aecf-0e8883ae78e4.sql ───

-- 1. org_units bővítés
ALTER TABLE public.org_units
  ADD COLUMN IF NOT EXISTS min_letszam_napi integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS max_letszam_napi integer,
  ADD COLUMN IF NOT EXISTS mukodes_kezd time,
  ADD COLUMN IF NOT EXISTS mukodes_veg time,
  ADD COLUMN IF NOT EXISTS parameterek jsonb NOT NULL DEFAULT '{}'::jsonb;

-- 2. staff_roles referencia-tábla (szerepkörök)
CREATE TABLE IF NOT EXISTS public.staff_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  kulcs text NOT NULL,
  nev text NOT NULL,
  leiras text,
  sorrend integer NOT NULL DEFAULT 100,
  aktiv boolean NOT NULL DEFAULT true,
  rendszerszintu boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, kulcs)
);
GRANT SELECT ON public.staff_roles TO authenticated;
GRANT ALL ON public.staff_roles TO service_role;
ALTER TABLE public.staff_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "staff_roles read in tenant or system"
  ON public.staff_roles FOR SELECT TO authenticated
  USING (rendszerszintu OR tenant_id = public.current_tenant_id());
CREATE POLICY "staff_roles manage by org admins"
  ON public.staff_roles FOR ALL TO authenticated
  USING (
    (tenant_id = public.current_tenant_id())
    AND public.has_permission(auth.uid(), 'manage_org')
  )
  WITH CHECK (
    (tenant_id = public.current_tenant_id())
    AND public.has_permission(auth.uid(), 'manage_org')
  );
CREATE TRIGGER trg_staff_roles_touch BEFORE UPDATE ON public.staff_roles
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- System seed (tenant_id NULL = rendszerszintű)
INSERT INTO public.staff_roles (tenant_id, kulcs, nev, sorrend, rendszerszintu) VALUES
  (NULL, 'aneszteziologus', 'Aneszteziológus orvos', 10, true),
  (NULL, 'sebesz_operator', 'Operatőr (sebész)',    20, true),
  (NULL, 'asszisztens',     'Aneszteziológiai asszisztens', 30, true),
  (NULL, 'mutosno',         'Műtősnő',              40, true),
  (NULL, 'mutostechnikus',  'Műtőstechnikus',       50, true),
  (NULL, 'szakdolgozo',     'Szakdolgozó',          60, true)
ON CONFLICT DO NOTHING;

-- 3. staffing_templates
CREATE TABLE IF NOT EXISTS public.staffing_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL DEFAULT public.current_tenant_id(),
  org_unit_id uuid NOT NULL REFERENCES public.org_units(id) ON DELETE CASCADE,
  nev text NOT NULL,
  leiras text,
  nap_bitmap smallint NOT NULL DEFAULT 127, -- bit0=Hé .. bit6=Va
  kezd_ido time NOT NULL,
  veg_ido time NOT NULL,
  kategoria text NOT NULL DEFAULT 'rendes' CHECK (kategoria IN ('rendes','ugyelet','keszenlet','sos')),
  ervenyes_tol date NOT NULL DEFAULT CURRENT_DATE,
  ervenyes_ig date,
  aktiv boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.staffing_templates TO authenticated;
GRANT ALL ON public.staffing_templates TO service_role;
ALTER TABLE public.staffing_templates ENABLE ROW LEVEL SECURITY;
CREATE POLICY "staffing_templates read in tenant"
  ON public.staffing_templates FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY "staffing_templates manage by org admins"
  ON public.staffing_templates FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_org'))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_org'));
CREATE TRIGGER trg_staffing_templates_touch BEFORE UPDATE ON public.staffing_templates
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE INDEX IF NOT EXISTS idx_staffing_templates_org ON public.staffing_templates(org_unit_id) WHERE aktiv;

-- 4. staffing_template_roles
CREATE TABLE IF NOT EXISTS public.staffing_template_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL DEFAULT public.current_tenant_id(),
  template_id uuid NOT NULL REFERENCES public.staffing_templates(id) ON DELETE CASCADE,
  staff_role_id uuid NOT NULL REFERENCES public.staff_roles(id) ON DELETE RESTRICT,
  skill_id uuid REFERENCES public.skills(id) ON DELETE SET NULL,
  min_letszam integer NOT NULL DEFAULT 1 CHECK (min_letszam >= 0),
  max_letszam integer CHECK (max_letszam IS NULL OR max_letszam >= min_letszam),
  kotelezo boolean NOT NULL DEFAULT true,
  sorrend integer NOT NULL DEFAULT 100,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.staffing_template_roles TO authenticated;
GRANT ALL ON public.staffing_template_roles TO service_role;
ALTER TABLE public.staffing_template_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "staffing_template_roles read in tenant"
  ON public.staffing_template_roles FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY "staffing_template_roles manage by org admins"
  ON public.staffing_template_roles FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_org'))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_org'));
CREATE TRIGGER trg_staffing_template_roles_touch BEFORE UPDATE ON public.staffing_template_roles
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE INDEX IF NOT EXISTS idx_stpl_roles_template ON public.staffing_template_roles(template_id);

-- 5. RPC: napi shift-igénylista generálása
CREATE OR REPLACE FUNCTION public.generate_demand_for_period(
  _org_unit_id uuid,
  _from date,
  _to date
)
RETURNS TABLE (
  datum date,
  template_id uuid,
  template_nev text,
  kezd_ido time,
  veg_ido time,
  kategoria text,
  staff_role_id uuid,
  staff_role_kulcs text,
  staff_role_nev text,
  skill_id uuid,
  min_letszam integer,
  max_letszam integer,
  kotelezo boolean
)
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  WITH napok AS (
    SELECT d::date AS datum, EXTRACT(isodow FROM d)::int - 1 AS dow_idx
    FROM generate_series(_from::timestamp, _to::timestamp, interval '1 day') d
  )
  SELECT n.datum,
         t.id, t.nev, t.kezd_ido, t.veg_ido, t.kategoria,
         r.staff_role_id, sr.kulcs, sr.nev,
         r.skill_id, r.min_letszam, r.max_letszam, r.kotelezo
  FROM napok n
  CROSS JOIN public.staffing_templates t
  JOIN public.staffing_template_roles r ON r.template_id = t.id
  JOIN public.staff_roles sr ON sr.id = r.staff_role_id
  WHERE t.org_unit_id = _org_unit_id
    AND t.aktiv
    AND t.tenant_id = public.current_tenant_id()
    AND t.ervenyes_tol <= n.datum
    AND (t.ervenyes_ig IS NULL OR t.ervenyes_ig >= n.datum)
    AND (t.nap_bitmap & (1 << n.dow_idx)) <> 0
  ORDER BY n.datum, t.kezd_ido, r.sorrend;
$$;


-- ─── 20260619103853_2adff3b2-b8f0-4846-be42-bcba6e1c70be.sql ───

ALTER TABLE public.schedule_runs
  ADD COLUMN IF NOT EXISTS publikalt_at timestamptz,
  ADD COLUMN IF NOT EXISTS publikalo_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL;

CREATE OR REPLACE FUNCTION public.publish_schedule_run(_run_id uuid)
RETURNS TABLE(published_count int, notified_count int)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_run public.schedule_runs%ROWTYPE;
  v_notified int := 0;
  v_assignments int := 0;
BEGIN
  SELECT * INTO v_run FROM public.schedule_runs WHERE id = _run_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Futtatás nem található.' USING ERRCODE = '22023';
  END IF;
  IF v_run.tenant_id IS DISTINCT FROM public.current_tenant_id() THEN
    RAISE EXCEPTION 'Nincs jogosultság ehhez a futtatáshoz.' USING ERRCODE = '42501';
  END IF;
  IF NOT (
    COALESCE(public.has_permission(v_uid,'manage_schedule'), false)
    OR COALESCE(public.has_permission(v_uid,'manage_tenant'), false)
  ) THEN
    RAISE EXCEPTION 'Csak beosztás-vezető publikálhat.' USING ERRCODE = '42501';
  END IF;
  IF v_run.status NOT IN ('kesz') THEN
    RAISE EXCEPTION 'Csak "kész" státuszú futtatás publikálható (jelenleg: %).', v_run.status USING ERRCODE = '22023';
  END IF;

  UPDATE public.schedule_runs
     SET status = 'publikalt',
         publikalt_at = now(),
         publikalo_id = v_uid
   WHERE id = _run_id;

  SELECT COUNT(*) INTO v_assignments FROM public.schedule_assignments WHERE run_id = _run_id;

  WITH affected AS (
    SELECT DISTINCT user_id
    FROM public.schedule_assignments
    WHERE run_id = _run_id AND user_id IS NOT NULL
  ),
  ins AS (
    INSERT INTO public.notifications (tenant_id, user_id, tipus, cim, uzenet, link)
    SELECT v_run.tenant_id, a.user_id, 'beosztas',
           'Új beosztás közzétéve',
           'Időszak: ' || to_char(v_run.idoszak_kezdet, 'YYYY-MM-DD') ||
             ' – ' || to_char(v_run.idoszak_veg, 'YYYY-MM-DD'),
           '/munkaido'
    FROM affected a
    RETURNING 1
  )
  SELECT COUNT(*) INTO v_notified FROM ins;

  RETURN QUERY SELECT v_assignments, v_notified;
END;
$$;

GRANT EXECUTE ON FUNCTION public.publish_schedule_run(uuid) TO authenticated;


-- ─── 20260619111710_c765ef37-7101-4539-a3e0-e55964fe775a.sql ───

-- 1) Add approval-status columns to profile_daily_preferences
ALTER TABLE public.profile_daily_preferences
  ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'tervezett',
  ADD COLUMN IF NOT EXISTS submitted_at timestamptz,
  ADD COLUMN IF NOT EXISTS jovahagyo_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS jovahagyas_at timestamptz,
  ADD COLUMN IF NOT EXISTS jovahagyas_indok text;

DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'pdp_status_check'
  ) THEN
    ALTER TABLE public.profile_daily_preferences
      ADD CONSTRAINT pdp_status_check
      CHECK (status IN ('tervezett','jovahagyasra_var','jovahagyott','elutasitott'));
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_pdp_status ON public.profile_daily_preferences(tenant_id, status);

-- 2) Event log table
CREATE TABLE IF NOT EXISTS public.profile_daily_preferences_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  pref_id uuid REFERENCES public.profile_daily_preferences(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  actor_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  action text NOT NULL CHECK (action IN ('letrehozva','modositva','torolve','beadva','jovahagyva','elutasitva')),
  from_status text,
  to_status text,
  nap_iso smallint,
  before_data jsonb,
  after_data jsonb,
  indok text,
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT ON public.profile_daily_preferences_events TO authenticated;
GRANT ALL ON public.profile_daily_preferences_events TO service_role;

ALTER TABLE public.profile_daily_preferences_events ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS pdp_events_select ON public.profile_daily_preferences_events;
CREATE POLICY pdp_events_select ON public.profile_daily_preferences_events
  FOR SELECT TO authenticated
  USING (
    tenant_id = public.current_tenant_id()
    AND (
      user_id = auth.uid()
      OR public.has_permission(auth.uid(), 'view_team')
      OR public.has_permission(auth.uid(), 'manage_schedule')
      OR public.has_permission(auth.uid(), 'manage_tenant')
    )
  );

-- Writes happen only through SECURITY DEFINER trigger; deny direct user inserts
DROP POLICY IF EXISTS pdp_events_no_direct_write ON public.profile_daily_preferences_events;
CREATE POLICY pdp_events_no_direct_write ON public.profile_daily_preferences_events
  FOR INSERT TO authenticated
  WITH CHECK (false);

CREATE INDEX IF NOT EXISTS idx_pdp_events_pref ON public.profile_daily_preferences_events(pref_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_pdp_events_user ON public.profile_daily_preferences_events(user_id, created_at DESC);

-- 3) Approval guard trigger (mirrors profile_preferences_guard)
CREATE OR REPLACE FUNCTION public.profile_daily_preferences_guard()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_can_approve boolean;
BEGIN
  IF TG_OP = 'UPDATE' AND NEW.status IS DISTINCT FROM OLD.status THEN
    IF NEW.status IN ('jovahagyott','elutasitott') THEN
      v_can_approve := COALESCE(public.has_permission(v_uid,'manage_schedule'), false)
                    OR COALESCE(public.has_permission(v_uid,'manage_tenant'), false);
      IF NOT v_can_approve THEN
        INSERT INTO public.admin_audit_log(tenant_id, user_id, action, table_name, record_id, before_data, after_data)
        VALUES (
          COALESCE(NEW.tenant_id, public.current_tenant_id()), v_uid, 'FORBIDDEN_APPROVAL',
          TG_TABLE_NAME, NEW.id::text,
          jsonb_build_object('status', OLD.status),
          jsonb_build_object('status', NEW.status)
        );
        RAISE EXCEPTION 'Nincs jogosultsága a napi preferencia jóváhagyásához.' USING ERRCODE = '42501';
      END IF;
      IF NEW.user_id = v_uid THEN
        RAISE EXCEPTION 'A saját preferenciáját nem hagyhatja jóvá / utasíthatja el.' USING ERRCODE = '42501';
      END IF;
      IF NEW.status = 'elutasitott' AND COALESCE(btrim(NEW.jovahagyas_indok), '') = '' THEN
        RAISE EXCEPTION 'Elutasításhoz kötelező az indoklás.' USING ERRCODE = '22023';
      END IF;
      NEW.jovahagyo_id := v_uid;
      NEW.jovahagyas_at := now();
    ELSIF NEW.status = 'jovahagyasra_var' THEN
      NEW.submitted_at := now();
      NEW.jovahagyo_id := NULL;
      NEW.jovahagyas_at := NULL;
      NEW.jovahagyas_indok := NULL;
    ELSIF NEW.status = 'tervezett' THEN
      NEW.submitted_at := NULL;
      NEW.jovahagyo_id := NULL;
      NEW.jovahagyas_at := NULL;
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS pdp_guard ON public.profile_daily_preferences;
CREATE TRIGGER pdp_guard
  BEFORE UPDATE ON public.profile_daily_preferences
  FOR EACH ROW EXECUTE FUNCTION public.profile_daily_preferences_guard();

-- 4) Event-log trigger
CREATE OR REPLACE FUNCTION public.profile_daily_preferences_log_event()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_action text;
  v_from text;
  v_to text;
  v_user_id uuid;
  v_tenant uuid;
  v_pref uuid;
  v_nap smallint;
BEGIN
  IF TG_OP = 'INSERT' THEN
    v_action := 'letrehozva';
    v_from := NULL; v_to := NEW.status;
    v_user_id := NEW.user_id; v_tenant := NEW.tenant_id;
    v_pref := NEW.id; v_nap := NEW.nap_iso;
    INSERT INTO public.profile_daily_preferences_events
      (tenant_id, pref_id, user_id, actor_id, action, from_status, to_status, nap_iso, before_data, after_data)
    VALUES (v_tenant, v_pref, v_user_id, auth.uid(), v_action, v_from, v_to, v_nap, NULL, to_jsonb(NEW));
    RETURN NEW;
  ELSIF TG_OP = 'UPDATE' THEN
    IF NEW.status IS DISTINCT FROM OLD.status THEN
      v_action := CASE NEW.status
        WHEN 'jovahagyasra_var' THEN 'beadva'
        WHEN 'jovahagyott' THEN 'jovahagyva'
        WHEN 'elutasitott' THEN 'elutasitva'
        ELSE 'modositva'
      END;
    ELSE
      v_action := 'modositva';
    END IF;
    INSERT INTO public.profile_daily_preferences_events
      (tenant_id, pref_id, user_id, actor_id, action, from_status, to_status, nap_iso, before_data, after_data, indok)
    VALUES (NEW.tenant_id, NEW.id, NEW.user_id, auth.uid(), v_action,
            OLD.status, NEW.status, NEW.nap_iso, to_jsonb(OLD), to_jsonb(NEW),
            CASE WHEN v_action IN ('jovahagyva','elutasitva') THEN NEW.jovahagyas_indok ELSE NULL END);
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    INSERT INTO public.profile_daily_preferences_events
      (tenant_id, pref_id, user_id, actor_id, action, from_status, to_status, nap_iso, before_data, after_data)
    VALUES (OLD.tenant_id, OLD.id, OLD.user_id, auth.uid(), 'torolve',
            OLD.status, NULL, OLD.nap_iso, to_jsonb(OLD), NULL);
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$;

DROP TRIGGER IF EXISTS pdp_log_event ON public.profile_daily_preferences;
CREATE TRIGGER pdp_log_event
  AFTER INSERT OR UPDATE OR DELETE ON public.profile_daily_preferences
  FOR EACH ROW EXECUTE FUNCTION public.profile_daily_preferences_log_event();

-- 5) Notification on status change
CREATE OR REPLACE FUNCTION public.notify_daily_preferences_status()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_cim text;
BEGIN
  IF NEW.status IS DISTINCT FROM OLD.status
     AND NEW.status IN ('jovahagyott','elutasitott') THEN
    v_cim := CASE NEW.status
      WHEN 'jovahagyott' THEN 'Napi preferencia jóváhagyva'
      ELSE 'Napi preferencia elutasítva'
    END;
    INSERT INTO public.notifications (tenant_id, user_id, tipus, cim, uzenet, link)
    VALUES (NEW.tenant_id, NEW.user_id, 'preferencia', v_cim, NEW.jovahagyas_indok, '/karakterlap');
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS pdp_notify_status ON public.profile_daily_preferences;
CREATE TRIGGER pdp_notify_status
  AFTER UPDATE ON public.profile_daily_preferences
  FOR EACH ROW EXECUTE FUNCTION public.notify_daily_preferences_status();


-- ─── 20260619112558_c5696fb9-b2ac-4a5a-bf30-a2c85857bb84.sql ───

-- =========================================================
-- 1) Új enumok
-- =========================================================
do $$ begin
  create type public.uzemmod_tipus as enum
    ('folyamatos_24_7','rendelesi_ido','programozott_nappali','muteti_blokk');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.fenntarto_tipus as enum
    ('allami','onkormanyzati','egyhazi','magan','egyeb');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.duty_szerep_tipus as enum
    ('nappali_ugyelet','ejszakai_ugyelet','hatter_ugyelet','keszenlet','muteti_ugyelet','egyeb');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.mentesseg_ok as enum
    ('terhesseg','gyermekgondozas','kor','jogviszony','egeszsegugyi','egyeb');
exception when duplicate_object then null; end $$;

-- Bővítjük az org_unit_tipus enumot
alter type public.org_unit_tipus add value if not exists 'ito';
alter type public.org_unit_tipus add value if not exists 'pito';
alter type public.org_unit_tipus add value if not exists 'egynapos';

-- =========================================================
-- 2) Meglévő táblák bővítése
-- =========================================================
alter table public.sites
  add column if not exists fenntarto_tipus public.fenntarto_tipus;

alter table public.org_units
  add column if not exists uzemmod public.uzemmod_tipus,
  add column if not exists unnepnap_uzemel boolean not null default false,
  add column if not exists agyszam int,
  add column if not exists muto_blokk_perc int,
  add column if not exists floor_id uuid;

-- üzemmód default a típusból (csak ha NULL maradt)
create or replace function public.org_units_default_uzemmod()
returns trigger language plpgsql set search_path = public as $$
begin
  if NEW.uzemmod is null then
    NEW.uzemmod := case NEW.tipus
      when 'ito' then 'folyamatos_24_7'::public.uzemmod_tipus
      when 'pito' then 'folyamatos_24_7'::public.uzemmod_tipus
      when 'fekvobeteg_osztaly' then 'folyamatos_24_7'::public.uzemmod_tipus
      when 'muto' then 'muteti_blokk'::public.uzemmod_tipus
      when 'kismuto' then 'muteti_blokk'::public.uzemmod_tipus
      when 'egynapos' then 'programozott_nappali'::public.uzemmod_tipus
      when 'ambulancia' then 'rendelesi_ido'::public.uzemmod_tipus
      when 'rendelo' then 'rendelesi_ido'::public.uzemmod_tipus
      else 'rendelesi_ido'::public.uzemmod_tipus
    end;
  end if;
  return NEW;
end $$;

drop trigger if exists trg_org_units_default_uzemmod on public.org_units;
create trigger trg_org_units_default_uzemmod
before insert or update of tipus, uzemmod on public.org_units
for each row execute function public.org_units_default_uzemmod();

-- backfill üzemmód
update public.org_units set uzemmod = case tipus
  when 'fekvobeteg_osztaly' then 'folyamatos_24_7'::public.uzemmod_tipus
  when 'muto' then 'muteti_blokk'::public.uzemmod_tipus
  when 'kismuto' then 'muteti_blokk'::public.uzemmod_tipus
  when 'ambulancia' then 'rendelesi_ido'::public.uzemmod_tipus
  when 'rendelo' then 'rendelesi_ido'::public.uzemmod_tipus
  else 'rendelesi_ido'::public.uzemmod_tipus
end where uzemmod is null;

-- =========================================================
-- 3) floors (szint/emelet)
-- =========================================================
create table if not exists public.floors (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  site_id uuid not null references public.sites(id) on delete cascade,
  szint text not null,
  megnevezes text,
  sorrend int not null default 0,
  aktiv boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update, delete on public.floors to authenticated;
grant all on public.floors to service_role;
alter table public.floors enable row level security;

create policy "floors_select_tenant" on public.floors for select to authenticated
  using (tenant_id = public.current_tenant_id());
create policy "floors_manage_org" on public.floors for all to authenticated
  using (tenant_id = public.current_tenant_id()
         and (public.has_permission(auth.uid(),'manage_org')
              or public.has_permission(auth.uid(),'manage_tenant')))
  with check (tenant_id = public.current_tenant_id()
         and (public.has_permission(auth.uid(),'manage_org')
              or public.has_permission(auth.uid(),'manage_tenant')));

drop trigger if exists trg_floors_touch on public.floors;
create trigger trg_floors_touch before update on public.floors
for each row execute function public.touch_updated_at();

-- floor_id FK org_units-on (most adjuk hozzá, hogy létezzen a floors)
do $$ begin
  alter table public.org_units
    add constraint org_units_floor_id_fkey
    foreign key (floor_id) references public.floors(id) on delete set null;
exception when duplicate_object then null; end $$;

-- =========================================================
-- 4) org_unit_departments (megosztott egységek)
-- =========================================================
create table if not exists public.org_unit_departments (
  tenant_id uuid not null,
  org_unit_id uuid not null references public.org_units(id) on delete cascade,
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  szerep text not null check (szerep in ('mukodteto','hasznalo')),
  created_at timestamptz not null default now(),
  primary key (org_unit_id, clinic_id)
);
grant select, insert, update, delete on public.org_unit_departments to authenticated;
grant all on public.org_unit_departments to service_role;
alter table public.org_unit_departments enable row level security;

create policy "oud_select_tenant" on public.org_unit_departments for select to authenticated
  using (tenant_id = public.current_tenant_id());
create policy "oud_manage_org" on public.org_unit_departments for all to authenticated
  using (tenant_id = public.current_tenant_id()
         and (public.has_permission(auth.uid(),'manage_org')
              or public.has_permission(auth.uid(),'manage_tenant')))
  with check (tenant_id = public.current_tenant_id()
         and (public.has_permission(auth.uid(),'manage_org')
              or public.has_permission(auth.uid(),'manage_tenant')));

-- =========================================================
-- 5) duty_lines (ügyeleti sorok)
-- =========================================================
create table if not exists public.duty_lines (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  site_id uuid not null references public.sites(id) on delete cascade,
  nev text not null,
  kod text,
  szerep_tipus public.duty_szerep_tipus not null,
  primary_org_unit_id uuid references public.org_units(id) on delete set null,
  letszam smallint not null default 1 check (letszam between 1 and 20),
  napok int[] not null default '{1,2,3,4,5,6,7}',
  kezd_ido time,
  veg_ido time,
  unnepnap_uzemel boolean not null default true,
  aktiv boolean not null default true,
  sorrend int not null default 0,
  megjegyzes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update, delete on public.duty_lines to authenticated;
grant all on public.duty_lines to service_role;
alter table public.duty_lines enable row level security;

create policy "duty_lines_select_tenant" on public.duty_lines for select to authenticated
  using (tenant_id = public.current_tenant_id());
create policy "duty_lines_manage" on public.duty_lines for all to authenticated
  using (tenant_id = public.current_tenant_id()
         and (public.has_permission(auth.uid(),'manage_org')
              or public.has_permission(auth.uid(),'manage_schedule')
              or public.has_permission(auth.uid(),'manage_tenant')))
  with check (tenant_id = public.current_tenant_id()
         and (public.has_permission(auth.uid(),'manage_org')
              or public.has_permission(auth.uid(),'manage_schedule')
              or public.has_permission(auth.uid(),'manage_tenant')));

drop trigger if exists trg_duty_lines_touch on public.duty_lines;
create trigger trg_duty_lines_touch before update on public.duty_lines
for each row execute function public.touch_updated_at();

-- =========================================================
-- 6) duty_line_coverage
-- =========================================================
create table if not exists public.duty_line_coverage (
  tenant_id uuid not null,
  duty_line_id uuid not null references public.duty_lines(id) on delete cascade,
  org_unit_id uuid not null references public.org_units(id) on delete cascade,
  kotelezo boolean not null default true,
  megjegyzes text,
  primary key (duty_line_id, org_unit_id)
);
grant select, insert, update, delete on public.duty_line_coverage to authenticated;
grant all on public.duty_line_coverage to service_role;
alter table public.duty_line_coverage enable row level security;

create policy "dlc_select_tenant" on public.duty_line_coverage for select to authenticated
  using (tenant_id = public.current_tenant_id());
create policy "dlc_manage" on public.duty_line_coverage for all to authenticated
  using (tenant_id = public.current_tenant_id()
         and (public.has_permission(auth.uid(),'manage_org')
              or public.has_permission(auth.uid(),'manage_schedule')
              or public.has_permission(auth.uid(),'manage_tenant')))
  with check (tenant_id = public.current_tenant_id()
         and (public.has_permission(auth.uid(),'manage_org')
              or public.has_permission(auth.uid(),'manage_schedule')
              or public.has_permission(auth.uid(),'manage_tenant')));

-- =========================================================
-- 7) duty_line_eligibility
-- =========================================================
create table if not exists public.duty_line_eligibility (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  duty_line_id uuid not null references public.duty_lines(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  foglalkozas_tipus public.foglalkozas_tipus,
  staff_role_id uuid references public.staff_roles(id) on delete cascade,
  prioritas int not null default 100,
  created_at timestamptz not null default now(),
  check (
    (user_id is not null)::int
    + (foglalkozas_tipus is not null)::int
    + (staff_role_id is not null)::int = 1
  )
);
grant select, insert, update, delete on public.duty_line_eligibility to authenticated;
grant all on public.duty_line_eligibility to service_role;
alter table public.duty_line_eligibility enable row level security;

create policy "dle_select_tenant" on public.duty_line_eligibility for select to authenticated
  using (tenant_id = public.current_tenant_id());
create policy "dle_manage" on public.duty_line_eligibility for all to authenticated
  using (tenant_id = public.current_tenant_id()
         and (public.has_permission(auth.uid(),'manage_org')
              or public.has_permission(auth.uid(),'manage_schedule')
              or public.has_permission(auth.uid(),'manage_tenant')))
  with check (tenant_id = public.current_tenant_id()
         and (public.has_permission(auth.uid(),'manage_org')
              or public.has_permission(auth.uid(),'manage_schedule')
              or public.has_permission(auth.uid(),'manage_tenant')));

-- =========================================================
-- 8) mandatory_duty_rules
-- =========================================================
create table if not exists public.mandatory_duty_rules (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  scope_tipus text not null check (scope_tipus in ('global','foglalkozas_tipus','staff_role','site')),
  scope_value text,
  min_per_honap int not null default 0 check (min_per_honap >= 0),
  max_per_honap int check (max_per_honap is null or max_per_honap >= min_per_honap),
  megjegyzes text,
  aktiv boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update, delete on public.mandatory_duty_rules to authenticated;
grant all on public.mandatory_duty_rules to service_role;
alter table public.mandatory_duty_rules enable row level security;

create policy "mdr_select_tenant" on public.mandatory_duty_rules for select to authenticated
  using (tenant_id = public.current_tenant_id());
create policy "mdr_manage" on public.mandatory_duty_rules for all to authenticated
  using (tenant_id = public.current_tenant_id()
         and (public.has_permission(auth.uid(),'manage_schedule')
              or public.has_permission(auth.uid(),'manage_tenant')))
  with check (tenant_id = public.current_tenant_id()
         and (public.has_permission(auth.uid(),'manage_schedule')
              or public.has_permission(auth.uid(),'manage_tenant')));

drop trigger if exists trg_mdr_touch on public.mandatory_duty_rules;
create trigger trg_mdr_touch before update on public.mandatory_duty_rules
for each row execute function public.touch_updated_at();

-- =========================================================
-- 9) mandatory_duty_exemptions
-- =========================================================
create table if not exists public.mandatory_duty_exemptions (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  user_id uuid not null references public.profiles(id) on delete cascade,
  ok public.mentesseg_ok not null,
  ervenyes_tol date not null,
  ervenyes_ig date,
  indok text,
  status text not null default 'jovahagyasra_var' check (status in ('jovahagyasra_var','jovahagyott','elutasitott')),
  jovahagyo_id uuid references public.profiles(id) on delete set null,
  jovahagyas_at timestamptz,
  jovahagyas_indok text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update, delete on public.mandatory_duty_exemptions to authenticated;
grant all on public.mandatory_duty_exemptions to service_role;
alter table public.mandatory_duty_exemptions enable row level security;

create policy "mde_select_own_or_hr" on public.mandatory_duty_exemptions for select to authenticated
  using (tenant_id = public.current_tenant_id()
         and (user_id = auth.uid()
              or public.has_permission(auth.uid(),'view_team')
              or public.has_permission(auth.uid(),'manage_schedule')
              or public.has_permission(auth.uid(),'manage_tenant')));

create policy "mde_insert_self_or_hr" on public.mandatory_duty_exemptions for insert to authenticated
  with check (tenant_id = public.current_tenant_id()
              and (user_id = auth.uid()
                   or public.has_permission(auth.uid(),'manage_tenant')));

create policy "mde_update_hr" on public.mandatory_duty_exemptions for update to authenticated
  using (tenant_id = public.current_tenant_id()
         and public.has_permission(auth.uid(),'manage_tenant'))
  with check (tenant_id = public.current_tenant_id()
              and public.has_permission(auth.uid(),'manage_tenant'));

create policy "mde_delete_hr" on public.mandatory_duty_exemptions for delete to authenticated
  using (tenant_id = public.current_tenant_id()
         and public.has_permission(auth.uid(),'manage_tenant'));

drop trigger if exists trg_mde_touch on public.mandatory_duty_exemptions;
create trigger trg_mde_touch before update on public.mandatory_duty_exemptions
for each row execute function public.touch_updated_at();

-- HR guard: jóváhagyás csak HR, saját kérelmét nem
create or replace function public.mandatory_duty_exemption_guard()
returns trigger language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid();
begin
  if TG_OP = 'UPDATE' and NEW.status is distinct from OLD.status
     and NEW.status in ('jovahagyott','elutasitott') then
    if not coalesce(public.has_permission(v_uid,'manage_tenant'), false) then
      raise exception 'Mentesség jóváhagyásához HR (tenant-admin) jogosultság szükséges.' using errcode='42501';
    end if;
    if NEW.user_id = v_uid then
      raise exception 'Saját mentességét nem hagyhatja jóvá.' using errcode='42501';
    end if;
    if NEW.status = 'elutasitott' and coalesce(btrim(NEW.jovahagyas_indok),'') = '' then
      raise exception 'Elutasításhoz kötelező az indoklás.' using errcode='22023';
    end if;
    NEW.jovahagyo_id := v_uid;
    NEW.jovahagyas_at := now();
  end if;
  return NEW;
end $$;

drop trigger if exists trg_mde_guard on public.mandatory_duty_exemptions;
create trigger trg_mde_guard before update on public.mandatory_duty_exemptions
for each row execute function public.mandatory_duty_exemption_guard();

-- =========================================================
-- 10) Helper függvény: effektív kötelező minimum
-- =========================================================
create or replace function public.get_required_monthly_duty(_user_id uuid, _honap date)
returns int language plpgsql stable security definer set search_path = public as $$
declare
  v_min int := 0;
  v_prof record;
  v_has_exempt boolean;
begin
  select p.foglalkozas_tipus::text as fog, p.tenant_id
    into v_prof
    from public.profiles p where p.id = _user_id;
  if not found then return 0; end if;

  -- aktív, jóváhagyott mentesség?
  select exists(
    select 1 from public.mandatory_duty_exemptions e
    where e.user_id = _user_id
      and e.status = 'jovahagyott'
      and e.ervenyes_tol <= (date_trunc('month', _honap)::date + interval '1 month - 1 day')::date
      and (e.ervenyes_ig is null or e.ervenyes_ig >= date_trunc('month', _honap)::date)
  ) into v_has_exempt;
  if v_has_exempt then return 0; end if;

  select coalesce(max(r.min_per_honap), 0) into v_min
  from public.mandatory_duty_rules r
  where r.tenant_id = v_prof.tenant_id and r.aktiv
    and (
      r.scope_tipus = 'global'
      or (r.scope_tipus = 'foglalkozas_tipus' and r.scope_value = v_prof.fog)
    );
  return v_min;
end $$;
grant execute on function public.get_required_monthly_duty(uuid,date) to authenticated;

-- =========================================================
-- 11) Helper függvény: adott napi aktív ügyeleti sorok
-- =========================================================
create or replace function public.current_duty_lines(_site_id uuid, _datum date)
returns table (
  id uuid, nev text, szerep_tipus public.duty_szerep_tipus,
  letszam smallint, kezd_ido time, veg_ido time, primary_org_unit_id uuid
)
language sql stable security definer set search_path = public as $$
  select dl.id, dl.nev, dl.szerep_tipus, dl.letszam, dl.kezd_ido, dl.veg_ido, dl.primary_org_unit_id
  from public.duty_lines dl
  where dl.site_id = _site_id
    and dl.aktiv
    and dl.tenant_id = public.current_tenant_id()
    and extract(isodow from _datum)::int = any(dl.napok)
    and (dl.unnepnap_uzemel
         or not exists (
           select 1 from public.public_holidays h
            where h.datum = _datum
              and (h.tenant_id is null or h.tenant_id = public.current_tenant_id())
         ))
  order by dl.sorrend, dl.nev;
$$;
grant execute on function public.current_duty_lines(uuid,date) to authenticated;

-- indexek
create index if not exists idx_floors_site on public.floors(site_id);
create index if not exists idx_org_units_floor on public.org_units(floor_id);
create index if not exists idx_duty_lines_site on public.duty_lines(site_id);
create index if not exists idx_dlc_line on public.duty_line_coverage(duty_line_id);
create index if not exists idx_dle_line on public.duty_line_eligibility(duty_line_id);
create index if not exists idx_mde_user on public.mandatory_duty_exemptions(user_id);


-- ─── 20260619114042_5170272a-e4e2-4af0-86ce-a3030cd7beac.sql ───

-- generate_duty_demand: derives daily demand rows from duty_lines + coverage
CREATE OR REPLACE FUNCTION public.generate_duty_demand(_site_id uuid, _from date, _to date)
RETURNS TABLE(
  datum date,
  duty_line_id uuid,
  duty_line_nev text,
  szerep_tipus duty_szerep_tipus,
  primary_org_unit_id uuid,
  kezd_ido time,
  veg_ido time,
  letszam smallint,
  org_unit_id uuid,
  kotelezo boolean
)
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  WITH napok AS (
    SELECT d::date AS datum, EXTRACT(isodow FROM d)::int AS iso
    FROM generate_series(_from::timestamp, _to::timestamp, interval '1 day') d
  )
  SELECT n.datum, dl.id, dl.nev, dl.szerep_tipus, dl.primary_org_unit_id,
         dl.kezd_ido, dl.veg_ido, dl.letszam,
         cov.org_unit_id, cov.kotelezo
  FROM napok n
  CROSS JOIN public.duty_lines dl
  LEFT JOIN public.duty_line_coverage cov ON cov.duty_line_id = dl.id
  WHERE dl.site_id = _site_id
    AND dl.aktiv
    AND dl.tenant_id = public.current_tenant_id()
    AND n.iso = ANY(dl.napok)
    AND (dl.unnepnap_uzemel OR NOT EXISTS (
      SELECT 1 FROM public.public_holidays h
      WHERE h.datum = n.datum
        AND (h.tenant_id IS NULL OR h.tenant_id = public.current_tenant_id())
    ))
  ORDER BY n.datum, dl.sorrend, dl.nev;
$$;

GRANT EXECUTE ON FUNCTION public.generate_duty_demand(uuid,date,date) TO authenticated;


-- ─── 20260619114925_c10732f8-aef2-4202-86a6-c7beb639252e.sql ───

CREATE TYPE public.duty_availability_tipus AS ENUM ('tartalekos','behivhato','szabad_vagyok');

CREATE TABLE public.duty_availability (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  user_id uuid NOT NULL,
  site_id uuid NULL,
  duty_line_id uuid NULL REFERENCES public.duty_lines(id) ON DELETE CASCADE,
  napok date[] NOT NULL DEFAULT '{}',
  tipus public.duty_availability_tipus NOT NULL,
  kezd_ido time NULL,
  veg_ido time NULL,
  megjegyzes text NULL,
  ervenyes_tol date NOT NULL DEFAULT CURRENT_DATE,
  ervenyes_ig date NULL,
  visszavonva_at timestamptz NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.duty_availability TO authenticated;
GRANT ALL ON public.duty_availability TO service_role;

ALTER TABLE public.duty_availability ENABLE ROW LEVEL SECURITY;

CREATE POLICY "duty_availability_select_tenant"
  ON public.duty_availability FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());

CREATE POLICY "duty_availability_self_manage"
  ON public.duty_availability FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
    AND (user_id = auth.uid() OR public.has_permission(auth.uid(), 'manage_schedule')))
  WITH CHECK (tenant_id = public.current_tenant_id()
    AND (user_id = auth.uid() OR public.has_permission(auth.uid(), 'manage_schedule')));

CREATE TRIGGER touch_duty_availability BEFORE UPDATE ON public.duty_availability
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE INDEX idx_duty_availability_user_napok ON public.duty_availability USING GIN (napok);
CREATE INDEX idx_duty_availability_site ON public.duty_availability (tenant_id, site_id, tipus)
  WHERE visszavonva_at IS NULL;

CREATE UNIQUE INDEX IF NOT EXISTS uq_duty_line_eligibility_user
  ON public.duty_line_eligibility (duty_line_id, user_id) WHERE user_id IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS uq_duty_line_eligibility_foglalkozas
  ON public.duty_line_eligibility (duty_line_id, foglalkozas_tipus) WHERE foglalkozas_tipus IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS uq_duty_line_eligibility_role
  ON public.duty_line_eligibility (duty_line_id, staff_role_id) WHERE staff_role_id IS NOT NULL;

DROP POLICY IF EXISTS "mandatory_duty_rules_manage" ON public.mandatory_duty_rules;
CREATE POLICY "mandatory_duty_rules_manage_tenant_only"
  ON public.mandatory_duty_rules FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_tenant'))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_tenant'));

CREATE OR REPLACE FUNCTION public.audit_mandatory_duty_rules()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.admin_audit_log (tenant_id, user_id, action, table_name, record_id, before_data, after_data, summary, created_at)
  VALUES (
    COALESCE(NEW.tenant_id, OLD.tenant_id), auth.uid(), TG_OP, 'mandatory_duty_rules',
    COALESCE(NEW.id::text, OLD.id::text),
    CASE WHEN TG_OP <> 'INSERT' THEN to_jsonb(OLD) END,
    CASE WHEN TG_OP <> 'DELETE' THEN to_jsonb(NEW) END,
    'Kötelező ügyelet szabály ' || TG_OP, now()
  );
  RETURN COALESCE(NEW, OLD);
END;
$$;

DROP TRIGGER IF EXISTS trg_audit_mandatory_duty_rules ON public.mandatory_duty_rules;
CREATE TRIGGER trg_audit_mandatory_duty_rules
  AFTER INSERT OR UPDATE OR DELETE ON public.mandatory_duty_rules
  FOR EACH ROW EXECUTE FUNCTION public.audit_mandatory_duty_rules();


-- ─── 20260619115449_66d69644-0aba-4e5e-b04d-8dd29fbc0deb.sql ───

-- Konfliktus-nézet: ellátóhely → érintett sorok / kötelező lefedés / üres eligibility
CREATE OR REPLACE VIEW public.org_unit_conflicts AS
SELECT
  ou.id AS org_unit_id,
  ou.tenant_id,
  COUNT(DISTINCT dlc.duty_line_id) FILTER (WHERE dlc.duty_line_id IS NOT NULL) AS duty_lines_count,
  COUNT(DISTINCT dlc.duty_line_id) FILTER (WHERE dlc.kotelezo) AS mandatory_coverage_count,
  COUNT(DISTINCT dl.id) FILTER (
    WHERE dl.id IS NOT NULL AND NOT EXISTS (
      SELECT 1 FROM public.duty_line_eligibility e WHERE e.duty_line_id = dl.id
    )
  ) AS duty_lines_without_eligibility
FROM public.org_units ou
LEFT JOIN public.duty_line_coverage dlc ON dlc.org_unit_id = ou.id
LEFT JOIN public.duty_lines dl ON dl.id = dlc.duty_line_id AND dl.aktiv = true
GROUP BY ou.id, ou.tenant_id;

GRANT SELECT ON public.org_unit_conflicts TO authenticated;

-- Seed: új tenant alap konfiguráció
CREATE OR REPLACE FUNCTION public.seed_default_org_for_tenant(_tenant_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_clinic uuid;
  v_site uuid;
  v_osztaly uuid;
  v_muto uuid;
  v_dl_nappal uuid;
  v_dl_ejjel uuid;
  v_dl_hatter uuid;
  v_existing int;
BEGIN
  -- jogosultság-ellenőrzés
  IF NOT public.has_permission(auth.uid(), 'manage_tenant') THEN
    RAISE EXCEPTION 'manage_tenant jogosultság szükséges';
  END IF;

  SELECT COUNT(*) INTO v_existing FROM public.clinics WHERE tenant_id = _tenant_id;
  IF v_existing > 0 THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'already_initialized');
  END IF;

  INSERT INTO public.clinics (tenant_id, nev) VALUES (_tenant_id, 'Minta Klinika') RETURNING id INTO v_clinic;
  INSERT INTO public.sites (tenant_id, clinic_id, nev, cim) VALUES (_tenant_id, v_clinic, 'Központi telephely', '—') RETURNING id INTO v_site;

  INSERT INTO public.floors (tenant_id, site_id, szint, megnevezes, sorrend) VALUES
    (_tenant_id, v_site, '-1', 'Pince', 1),
    (_tenant_id, v_site, '0',  'Földszint', 2),
    (_tenant_id, v_site, '1',  '1. emelet', 3);

  INSERT INTO public.org_units (tenant_id, site_id, nev, tipus, uzemmod, agyszam)
    VALUES (_tenant_id, v_site, 'Belgyógyászati osztály', 'osztaly', 'folyamatos_24_7', 24) RETURNING id INTO v_osztaly;

  INSERT INTO public.org_units (tenant_id, site_id, nev, tipus, uzemmod, muto_blokk_perc)
    VALUES (_tenant_id, v_site, 'Központi műtő', 'muto', 'muteti_blokk', 480) RETURNING id INTO v_muto;

  INSERT INTO public.duty_lines (tenant_id, site_id, nev, kod, szerep_tipus, primary_org_unit_id, letszam, napok, kezd_ido, veg_ido, aktiv)
    VALUES (_tenant_id, v_site, 'Belgyógyászat nappali', 'BELGY_NAP', 'nappali_ugyelet', v_osztaly, 2, ARRAY[1,2,3,4,5,6,7], '08:00', '20:00', true) RETURNING id INTO v_dl_nappal;

  INSERT INTO public.duty_lines (tenant_id, site_id, nev, kod, szerep_tipus, primary_org_unit_id, letszam, napok, kezd_ido, veg_ido, aktiv)
    VALUES (_tenant_id, v_site, 'Belgyógyászat éjszakai', 'BELGY_EJ', 'ejszakai_ugyelet', v_osztaly, 1, ARRAY[1,2,3,4,5,6,7], '20:00', '08:00', true) RETURNING id INTO v_dl_ejjel;

  INSERT INTO public.duty_lines (tenant_id, site_id, nev, kod, szerep_tipus, primary_org_unit_id, letszam, napok, kezd_ido, veg_ido, aktiv)
    VALUES (_tenant_id, v_site, 'Telephelyi háttér', 'HATTER', 'hatter_ugyelet', v_osztaly, 1, ARRAY[1,2,3,4,5,6,7], '00:00', '23:59', true) RETURNING id INTO v_dl_hatter;

  INSERT INTO public.duty_line_coverage (tenant_id, duty_line_id, org_unit_id, kotelezo) VALUES
    (_tenant_id, v_dl_nappal, v_osztaly, true),
    (_tenant_id, v_dl_ejjel,  v_osztaly, true),
    (_tenant_id, v_dl_hatter, v_osztaly, true),
    (_tenant_id, v_dl_hatter, v_muto,    false);

  INSERT INTO public.duty_line_eligibility (tenant_id, duty_line_id, foglalkozas_tipus, prioritas) VALUES
    (_tenant_id, v_dl_nappal, 'orvos', 0),
    (_tenant_id, v_dl_ejjel,  'orvos', 0),
    (_tenant_id, v_dl_hatter, 'orvos', 0);

  RETURN jsonb_build_object(
    'ok', true,
    'clinic_id', v_clinic,
    'site_id', v_site,
    'org_units', jsonb_build_array(v_osztaly, v_muto),
    'duty_lines', jsonb_build_array(v_dl_nappal, v_dl_ejjel, v_dl_hatter)
  );
END;
$$;

REVOKE EXECUTE ON FUNCTION public.seed_default_org_for_tenant(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.seed_default_org_for_tenant(uuid) TO authenticated;


-- ─── 20260619115503_666f195e-5c4d-4ab8-b72e-4d88c89cada6.sql ───
ALTER VIEW public.org_unit_conflicts SET (security_invoker = true);

-- ─── 20260619115835_54ae2f79-1cc0-43af-8e4e-94d00c278a5b.sql ───

CREATE OR REPLACE FUNCTION public.notify_duty_availability_offer()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user_name text;
BEGIN
  IF NEW.tipus <> 'szabad_vagyok' THEN
    RETURN NEW;
  END IF;

  SELECT teljes_nev INTO v_user_name FROM public.profiles WHERE id = NEW.user_id;

  INSERT INTO public.notifications (tenant_id, user_id, tipus, cim, uzenet, link)
  SELECT
    NEW.tenant_id,
    ur.user_id,
    'duty_availability_offer',
    'Új önkéntes ügyelet felajánlás',
    COALESCE(v_user_name, 'Egy dolgozó') || ' vállal extra ügyeletet (' || array_length(NEW.napok, 1) || ' nap)',
    '/karakterlap?user=' || NEW.user_id::text
  FROM public.user_roles ur
  JOIN public.role_permissions rp ON rp.role_id = ur.role_id
  WHERE ur.tenant_id = NEW.tenant_id
    AND rp.permission = 'manage_schedule'
    AND ur.user_id <> NEW.user_id;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_notify_duty_offer ON public.duty_availability;
CREATE TRIGGER trg_notify_duty_offer
  AFTER INSERT ON public.duty_availability
  FOR EACH ROW EXECUTE FUNCTION public.notify_duty_availability_offer();


-- ─── 20260619121053_23dfca44-56b5-4a62-8685-85295ea1925b.sql ───
CREATE TABLE public.chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('user','assistant','system')),
  content text NOT NULL,
  parts jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_chat_messages_user_created ON public.chat_messages(user_id, created_at);
GRANT SELECT, INSERT, DELETE ON public.chat_messages TO authenticated;
GRANT ALL ON public.chat_messages TO service_role;
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "chat_messages_select_own" ON public.chat_messages FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "chat_messages_insert_own" ON public.chat_messages FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "chat_messages_delete_own" ON public.chat_messages FOR DELETE TO authenticated USING (user_id = auth.uid());

-- ─── 20260619121800_9054ed9d-4542-4895-9755-ffc5d031c88d.sql ───
DROP VIEW IF EXISTS public.profile_scheduling_facts;

CREATE VIEW public.profile_scheduling_facts AS
SELECT
  p.id AS user_id,
  p.tenant_id,
  p.teljes_nev,
  p.becenev,
  p.email,
  p.foglalkozas_tipus,
  pp.heti_max_ora,
  pp.havi_max_ugyelet,
  COALESCE(pp.ugyelet_utan_pihenonap, false) AS ugyelet_utan_pihenonap,
  COALESCE(pp.ugyelet_utan_min_ora, 11) AS ugyelet_utan_min_ora,
  COALESCE(pp.egymas_utani_max_ugyelet, 1) AS egymas_utani_max_ugyelet,
  COALESCE(pp.last_minute_elerheto, false) AS last_minute_elerheto,
  pp.last_minute_orahatar,
  pp.utazasi_perc_max,
  COALESCE(pp.preferalt_musakok::text[], ARRAY[]::text[]) AS preferalt_musakok,
  COALESCE(pp.tiltott_napok, ARRAY[]::integer[]) AS tiltott_napok,
  COALESCE(pp.nyelvek, ARRAY[]::text[]) AS nyelvek,
  EXISTS (SELECT 1 FROM profile_constraints pc WHERE pc.user_id=p.id AND pc.tipus='terhes' AND pc.ervenyes_tol<=CURRENT_DATE AND (pc.ervenyes_ig IS NULL OR pc.ervenyes_ig>=CURRENT_DATE)) AS terhes,
  EXISTS (SELECT 1 FROM profile_constraints pc WHERE pc.user_id=p.id AND pc.tipus='szoptat' AND pc.ervenyes_tol<=CURRENT_DATE AND (pc.ervenyes_ig IS NULL OR pc.ervenyes_ig>=CURRENT_DATE)) AS szoptat,
  EXISTS (SELECT 1 FROM profile_constraints pc WHERE pc.user_id=p.id AND pc.tipus='kisgyermek_otthon' AND pc.ervenyes_tol<=CURRENT_DATE AND (pc.ervenyes_ig IS NULL OR pc.ervenyes_ig>=CURRENT_DATE)) AS kisgyermek_otthon,
  EXISTS (SELECT 1 FROM profile_constraints pc WHERE pc.user_id=p.id AND pc.tipus='egyedulnevelo' AND pc.ervenyes_tol<=CURRENT_DATE AND (pc.ervenyes_ig IS NULL OR pc.ervenyes_ig>=CURRENT_DATE)) AS egyedulnevelo,
  EXISTS (SELECT 1 FROM profile_constraints pc WHERE pc.user_id=p.id AND pc.tipus='tartos_betegseg' AND pc.ervenyes_tol<=CURRENT_DATE AND (pc.ervenyes_ig IS NULL OR pc.ervenyes_ig>=CURRENT_DATE)) AS tartos_betegseg,
  EXISTS (SELECT 1 FROM profile_constraints pc WHERE pc.user_id=p.id AND pc.tipus='mozgaskorlatozas' AND pc.ervenyes_tol<=CURRENT_DATE AND (pc.ervenyes_ig IS NULL OR pc.ervenyes_ig>=CURRENT_DATE)) AS mozgaskorlatozas,
  EXISTS (SELECT 1 FROM profile_constraints pc WHERE pc.user_id=p.id AND pc.tipus='vedendokoru' AND pc.ervenyes_tol<=CURRENT_DATE AND (pc.ervenyes_ig IS NULL OR pc.ervenyes_ig>=CURRENT_DATE)) AS vedendokoru,
  (SELECT COUNT(*)::int FROM profile_constraints pc WHERE pc.user_id=p.id AND pc.ervenyes_tol<=CURRENT_DATE AND (pc.ervenyes_ig IS NULL OR pc.ervenyes_ig>=CURRENT_DATE)) AS aktiv_constraint_count,
  EXISTS (SELECT 1 FROM profile_constraints pc WHERE pc.user_id=p.id AND pc.tipus IN ('terhes','szoptat','vedendokoru') AND pc.ervenyes_tol<=CURRENT_DATE AND (pc.ervenyes_ig IS NULL OR pc.ervenyes_ig>=CURRENT_DATE)) AS tiltott_ejszaka,
  EXISTS (SELECT 1 FROM profile_constraints pc WHERE pc.user_id=p.id AND pc.tipus IN ('terhes','szoptat') AND pc.ervenyes_tol<=CURRENT_DATE AND (pc.ervenyes_ig IS NULL OR pc.ervenyes_ig>=CURRENT_DATE)) AS tiltott_sugar_zona,
  COALESCE(pp.ugyelet_utan_min_ora, 11) AS min_pihenoido_ora,
  (SELECT COUNT(*)::int FROM profile_unavailability pu WHERE pu.user_id=p.id AND pu.status='jovahagyott' AND pu.kezdo_datum >= CURRENT_DATE - INTERVAL '30 days' AND pu.kezdo_datum <= CURRENT_DATE + INTERVAL '30 days') AS tavollet_nap_30,
  (SELECT COUNT(*)::int FROM profile_unavailability pu WHERE pu.user_id=p.id AND pu.status='jovahagyott' AND pu.kezdo_datum >= CURRENT_DATE - INTERVAL '90 days' AND pu.kezdo_datum <= CURRENT_DATE + INTERVAL '90 days') AS tavollet_nap_90,
  (SELECT COUNT(*)::int FROM profile_unavailability pu WHERE pu.user_id=p.id AND pu.status='jovahagyasra_var') AS fuggo_tavollet_count,
  (SELECT COUNT(*)::int FROM profile_unavailability pu WHERE pu.user_id=p.id AND pu.status='jovahagyott') AS jovahagyott_tavollet_count,
  (SELECT COUNT(*)::int FROM profile_peer_links pl WHERE (pl.from_user_id=p.id OR pl.to_user_id=p.id) AND pl.tipus='szivesen_dolgozik_vele' AND pl.status='jovahagyott') AS pozitiv_kapcsolat,
  (SELECT COUNT(*)::int FROM profile_peer_links pl WHERE (pl.from_user_id=p.id OR pl.to_user_id=p.id) AND pl.tipus='nem_dolgozik_vele' AND pl.status='jovahagyott') AS negativ_kapcsolat,
  (SELECT COUNT(*)::int FROM profile_peer_links pl WHERE pl.from_user_id=p.id AND pl.tipus='mentor' AND pl.status='jovahagyott') AS mentor_count,
  (SELECT COUNT(*)::int FROM profile_peer_links pl WHERE pl.to_user_id=p.id AND pl.tipus='mentor' AND pl.status='jovahagyott') AS mentee_count,
  (SELECT COUNT(*)::int FROM profile_contacts pcon WHERE pcon.user_id=p.id) AS contact_count,
  EXISTS (SELECT 1 FROM notifications n WHERE n.user_id=p.id AND n.olvasott_at IS NULL) AS van_aktiv_ertesites
FROM profiles p
LEFT JOIN profile_preferences pp ON pp.user_id = p.id;

GRANT SELECT ON public.profile_scheduling_facts TO authenticated;

CREATE OR REPLACE FUNCTION public.touch_updated_at() RETURNS trigger
LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

CREATE TABLE public.profile_external_hours (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  tenant_id uuid,
  ev integer NOT NULL CHECK (ev BETWEEN 2020 AND 2100),
  honap integer NOT NULL CHECK (honap BETWEEN 1 AND 12),
  ora numeric(6,2) NOT NULL CHECK (ora >= 0 AND ora <= 744),
  hely text,
  jogviszony_tipus text,
  megjegyzes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX uq_profile_external_hours_user_ym_hely ON public.profile_external_hours(user_id, ev, honap, COALESCE(hely, ''));
CREATE INDEX idx_profile_external_hours_user_ym ON public.profile_external_hours(user_id, ev, honap);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_external_hours TO authenticated;
GRANT ALL ON public.profile_external_hours TO service_role;
ALTER TABLE public.profile_external_hours ENABLE ROW LEVEL SECURITY;

CREATE POLICY "external_hours_self_select" ON public.profile_external_hours FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "external_hours_self_insert" ON public.profile_external_hours FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "external_hours_self_update" ON public.profile_external_hours FOR UPDATE TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE POLICY "external_hours_self_delete" ON public.profile_external_hours FOR DELETE TO authenticated USING (user_id = auth.uid());
CREATE POLICY "external_hours_leaders_select" ON public.profile_external_hours FOR SELECT TO authenticated USING (public.has_permission(auth.uid(), 'view_team') OR public.has_permission(auth.uid(), 'manage_org') OR public.has_permission(auth.uid(), 'manage_schedule'));
CREATE POLICY "external_hours_leaders_modify" ON public.profile_external_hours FOR ALL TO authenticated USING (public.has_permission(auth.uid(), 'manage_org') OR public.has_permission(auth.uid(), 'manage_schedule')) WITH CHECK (public.has_permission(auth.uid(), 'manage_org') OR public.has_permission(auth.uid(), 'manage_schedule'));

CREATE TRIGGER trg_profile_external_hours_touch BEFORE UPDATE ON public.profile_external_hours FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- ─── 20260619121815_607bc755-5a00-49ef-84f0-acd5f70e972f.sql ───
ALTER VIEW public.profile_scheduling_facts SET (security_invoker = true);

-- ─── 20260619124901_f9d4bebf-3ea5-4a30-a636-5af8a99151b6.sql ───

-- 1. Push subscriptions
CREATE TABLE public.push_subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  endpoint TEXT NOT NULL,
  p256dh TEXT NOT NULL,
  auth TEXT NOT NULL,
  user_agent TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_used_at TIMESTAMPTZ,
  UNIQUE (endpoint)
);
CREATE INDEX idx_push_subscriptions_user ON public.push_subscriptions(user_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.push_subscriptions TO authenticated;
GRANT ALL ON public.push_subscriptions TO service_role;

ALTER TABLE public.push_subscriptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage own push subscriptions"
  ON public.push_subscriptions FOR ALL
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- 2. Shift notifications log (idempotency)
CREATE TABLE public.shift_notifications_sent (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assignment_id UUID NOT NULL,
  user_id UUID NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('24h','2h')),
  channel TEXT NOT NULL CHECK (channel IN ('email','push')),
  sent_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  success BOOLEAN NOT NULL DEFAULT true,
  error TEXT,
  UNIQUE (assignment_id, kind, channel)
);
CREATE INDEX idx_shift_notif_user ON public.shift_notifications_sent(user_id, sent_at DESC);

GRANT SELECT ON public.shift_notifications_sent TO authenticated;
GRANT ALL ON public.shift_notifications_sent TO service_role;

ALTER TABLE public.shift_notifications_sent ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users see own shift notifications"
  ON public.shift_notifications_sent FOR SELECT
  USING (auth.uid() = user_id);

-- 3. Profile preferences
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS reminder_email_enabled BOOLEAN NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS reminder_push_enabled BOOLEAN NOT NULL DEFAULT true;


-- ─── 20260619131441_26a434ee-a410-4fcc-bffc-59cb9311c6df.sql ───

-- ====== ENUMOK ======
CREATE TYPE public.or_tipus_enum AS ENUM
  ('altalanos','szuloszoba','egynapos_kismuteti','onkosebeszet','reproduktiv','hibrid','lezer','robot');

CREATE TYPE public.or_eroforras_tipus_enum AS ENUM
  ('aneszteziologus','mutos_szakdolgozo','cssd_keszlet','pito_agy','ito_agy','pacu_ebredo',
   'verkeszitmeny','kepalkotas_intraop','patologia_fagyasztott','robot_konzol','embriologiai_labor',
   'neonatologus','lezer_eszkoz','implantatum');

CREATE TYPE public.or_block_statusz_enum AS ENUM ('allokalt','felszabaditott','lezart');
CREATE TYPE public.or_case_statusz_enum  AS ENUM ('tervezett','jovahagyott','folyamatban','elvegzett','elhalasztott','torolt');
CREATE TYPE public.or_case_prioritas_enum AS ENUM ('elektiv','sürgos','azonnali');
CREATE TYPE public.or_resource_req_when_enum AS ENUM ('intraop','posztop');
CREATE TYPE public.or_resource_req_status_enum AS ENUM ('igenyelt','foglalt','nem_elerheto');

-- ====== OR_SUITES ======
CREATE TABLE public.or_suites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  site_id uuid NOT NULL REFERENCES public.sites(id) ON DELETE CASCADE,
  nev text NOT NULL,
  tartalek_muto_szam int NOT NULL DEFAULT 0 CHECK (tartalek_muto_szam >= 0),
  surgossegi_keret_perc int NOT NULL DEFAULT 0 CHECK (surgossegi_keret_perc >= 0),
  aktiv boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.or_suites TO authenticated;
GRANT ALL ON public.or_suites TO service_role;
ALTER TABLE public.or_suites ENABLE ROW LEVEL SECURITY;
CREATE POLICY "or_suites_select_tenant" ON public.or_suites FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY "or_suites_write_managers" ON public.or_suites FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_schedule')
              OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id()
              AND (public.has_permission(auth.uid(),'manage_schedule')
                   OR public.has_permission(auth.uid(),'manage_tenant')));
CREATE TRIGGER or_suites_touch BEFORE UPDATE ON public.or_suites
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER or_suites_audit AFTER INSERT OR UPDATE OR DELETE ON public.or_suites
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ====== OR_ROOM_PROFILES (extends org_units) ======
CREATE TABLE public.or_room_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  org_unit_id uuid NOT NULL UNIQUE REFERENCES public.org_units(id) ON DELETE CASCADE,
  or_suite_id uuid NOT NULL REFERENCES public.or_suites(id) ON DELETE RESTRICT,
  tipus public.or_tipus_enum NOT NULL DEFAULT 'altalanos',
  tartalek boolean NOT NULL DEFAULT false,
  napi_kezdo_ido time NOT NULL DEFAULT '08:00',
  napi_veg_ido   time NOT NULL DEFAULT '16:00',
  fordulo_ido_perc int NOT NULL DEFAULT 30 CHECK (fordulo_ido_perc >= 0),
  aktiv boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.or_room_profiles TO authenticated;
GRANT ALL ON public.or_room_profiles TO service_role;
ALTER TABLE public.or_room_profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "or_room_profiles_select_tenant" ON public.or_room_profiles FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY "or_room_profiles_write_managers" ON public.or_room_profiles FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_schedule')
              OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id()
              AND (public.has_permission(auth.uid(),'manage_schedule')
                   OR public.has_permission(auth.uid(),'manage_tenant')));
CREATE TRIGGER or_room_profiles_touch BEFORE UPDATE ON public.or_room_profiles
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER or_room_profiles_audit AFTER INSERT OR UPDATE OR DELETE ON public.or_room_profiles
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ====== OR_RESOURCES ======
CREATE TABLE public.or_resources (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  site_id uuid NOT NULL REFERENCES public.sites(id) ON DELETE CASCADE,
  tipus public.or_eroforras_tipus_enum NOT NULL,
  nev text,
  keszlet_db int NOT NULL DEFAULT 1 CHECK (keszlet_db >= 0),
  megosztott boolean NOT NULL DEFAULT false,
  aktiv boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.or_resources TO authenticated;
GRANT ALL ON public.or_resources TO service_role;
ALTER TABLE public.or_resources ENABLE ROW LEVEL SECURITY;
CREATE POLICY "or_resources_select_tenant" ON public.or_resources FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY "or_resources_write_managers" ON public.or_resources FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_schedule')
              OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id()
              AND (public.has_permission(auth.uid(),'manage_schedule')
                   OR public.has_permission(auth.uid(),'manage_tenant')));
CREATE TRIGGER or_resources_touch BEFORE UPDATE ON public.or_resources
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER or_resources_audit AFTER INSERT OR UPDATE OR DELETE ON public.or_resources
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ====== OR_BLOCKS ======
CREATE TABLE public.or_blocks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  org_unit_id uuid NOT NULL REFERENCES public.org_units(id) ON DELETE CASCADE,
  datum date NOT NULL,
  kezdo_ido time NOT NULL,
  veg_ido   time NOT NULL,
  specialty_id uuid REFERENCES public.specialties(id) ON DELETE SET NULL,
  sebesz_user_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  statusz public.or_block_statusz_enum NOT NULL DEFAULT 'allokalt',
  felszabaditasi_hatarido timestamptz,
  ismetlodo_szabaly text,
  surgossegi_keret boolean NOT NULL DEFAULT false,
  megjegyzes text,
  created_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (veg_ido > kezdo_ido)
);
CREATE INDEX or_blocks_org_unit_datum_idx ON public.or_blocks (org_unit_id, datum);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.or_blocks TO authenticated;
GRANT ALL ON public.or_blocks TO service_role;
ALTER TABLE public.or_blocks ENABLE ROW LEVEL SECURITY;
CREATE POLICY "or_blocks_select_tenant" ON public.or_blocks FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY "or_blocks_write_managers" ON public.or_blocks FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_schedule')
              OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id()
              AND (public.has_permission(auth.uid(),'manage_schedule')
                   OR public.has_permission(auth.uid(),'manage_tenant')));
CREATE TRIGGER or_blocks_touch BEFORE UPDATE ON public.or_blocks
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER or_blocks_audit AFTER INSERT OR UPDATE OR DELETE ON public.or_blocks
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ====== SURGERY_TYPES ======
CREATE TABLE public.surgery_types (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  beavatkozas_id uuid REFERENCES public.beavatkozasok(id) ON DELETE SET NULL,
  kod text,
  nev text NOT NULL,
  kotelezo_muto_tipus public.or_tipus_enum,
  becsult_idotartam_perc int NOT NULL DEFAULT 60 CHECK (becsult_idotartam_perc > 0),
  posztop_apolasi_perc int NOT NULL DEFAULT 0 CHECK (posztop_apolasi_perc >= 0),
  szukseges_szerepek jsonb NOT NULL DEFAULT '[]'::jsonb,   -- [{staff_role_kulcs, letszam}]
  szukseges_skillek jsonb NOT NULL DEFAULT '[]'::jsonb,    -- [skill_id]
  kotelezo_eroforrasok jsonb NOT NULL DEFAULT '[]'::jsonb, -- [{tipus, mennyiseg, mikortol}]
  aktiv boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.surgery_types TO authenticated;
GRANT ALL ON public.surgery_types TO service_role;
ALTER TABLE public.surgery_types ENABLE ROW LEVEL SECURITY;
CREATE POLICY "surgery_types_select_tenant" ON public.surgery_types FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY "surgery_types_write_managers" ON public.surgery_types FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_schedule')
              OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id()
              AND (public.has_permission(auth.uid(),'manage_schedule')
                   OR public.has_permission(auth.uid(),'manage_tenant')));
CREATE TRIGGER surgery_types_touch BEFORE UPDATE ON public.surgery_types
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER surgery_types_audit AFTER INSERT OR UPDATE OR DELETE ON public.surgery_types
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ====== SURGERY_CASES ======
CREATE TABLE public.surgery_cases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE RESTRICT,
  surgery_type_id uuid REFERENCES public.surgery_types(id) ON DELETE SET NULL,
  or_block_id uuid REFERENCES public.or_blocks(id) ON DELETE SET NULL,
  becsult_idotartam_perc int NOT NULL CHECK (becsult_idotartam_perc > 0),
  posztop_apolasi_perc int NOT NULL DEFAULT 0 CHECK (posztop_apolasi_perc >= 0),
  prioritas public.or_case_prioritas_enum NOT NULL DEFAULT 'elektiv',
  statusz public.or_case_statusz_enum NOT NULL DEFAULT 'tervezett',
  tervezett_kezdo_ido timestamptz,
  tenyleges_kezdo_ido timestamptz,
  tenyleges_veg_ido timestamptz,
  jovahagyta_user_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  jovahagyas_at timestamptz,
  megjegyzes text,
  created_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX surgery_cases_block_idx ON public.surgery_cases (or_block_id);
CREATE INDEX surgery_cases_patient_idx ON public.surgery_cases (patient_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.surgery_cases TO authenticated;
GRANT ALL ON public.surgery_cases TO service_role;
ALTER TABLE public.surgery_cases ENABLE ROW LEVEL SECURITY;
CREATE POLICY "surgery_cases_select_tenant" ON public.surgery_cases FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY "surgery_cases_write_managers" ON public.surgery_cases FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_schedule')
              OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id()
              AND (public.has_permission(auth.uid(),'manage_schedule')
                   OR public.has_permission(auth.uid(),'manage_tenant')));
CREATE TRIGGER surgery_cases_touch BEFORE UPDATE ON public.surgery_cases
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER surgery_cases_audit AFTER INSERT OR UPDATE OR DELETE ON public.surgery_cases
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ====== CASE_RESOURCE_REQUIREMENTS ======
CREATE TABLE public.case_resource_requirements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  surgery_case_id uuid NOT NULL REFERENCES public.surgery_cases(id) ON DELETE CASCADE,
  eroforras_tipus public.or_eroforras_tipus_enum NOT NULL,
  mennyiseg int NOT NULL DEFAULT 1 CHECK (mennyiseg > 0),
  mikortol public.or_resource_req_when_enum NOT NULL DEFAULT 'intraop',
  foglalas_statusz public.or_resource_req_status_enum NOT NULL DEFAULT 'igenyelt',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX case_resource_req_case_idx ON public.case_resource_requirements (surgery_case_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.case_resource_requirements TO authenticated;
GRANT ALL ON public.case_resource_requirements TO service_role;
ALTER TABLE public.case_resource_requirements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "case_res_req_select_tenant" ON public.case_resource_requirements FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY "case_res_req_write_managers" ON public.case_resource_requirements FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_schedule')
              OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id()
              AND (public.has_permission(auth.uid(),'manage_schedule')
                   OR public.has_permission(auth.uid(),'manage_tenant')));
CREATE TRIGGER case_res_req_touch BEFORE UPDATE ON public.case_resource_requirements
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER case_res_req_audit AFTER INSERT OR UPDATE OR DELETE ON public.case_resource_requirements
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- ====== RESOURCE_BOOKINGS ======
CREATE TABLE public.resource_bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  or_resource_id uuid NOT NULL REFERENCES public.or_resources(id) ON DELETE CASCADE,
  surgery_case_id uuid REFERENCES public.surgery_cases(id) ON DELETE CASCADE,
  datum date NOT NULL,
  kezdo_ido time NOT NULL,
  veg_ido   time NOT NULL,
  mennyiseg int NOT NULL DEFAULT 1 CHECK (mennyiseg > 0),
  megjegyzes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (veg_ido > kezdo_ido)
);
CREATE INDEX resource_bookings_res_date_idx ON public.resource_bookings (or_resource_id, datum);
CREATE INDEX resource_bookings_case_idx ON public.resource_bookings (surgery_case_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.resource_bookings TO authenticated;
GRANT ALL ON public.resource_bookings TO service_role;
ALTER TABLE public.resource_bookings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "resource_bookings_select_tenant" ON public.resource_bookings FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY "resource_bookings_write_managers" ON public.resource_bookings FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_schedule')
              OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id()
              AND (public.has_permission(auth.uid(),'manage_schedule')
                   OR public.has_permission(auth.uid(),'manage_tenant')));
CREATE TRIGGER resource_bookings_touch BEFORE UPDATE ON public.resource_bookings
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER resource_bookings_audit AFTER INSERT OR UPDATE OR DELETE ON public.resource_bookings
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();


-- ─── 20260619140906_c04ff87d-756e-4f44-9700-704aa4717053.sql ───

CREATE TYPE public.appt_resource_tipus AS ENUM ('orvos','rendelo','mindketto');
CREATE TYPE public.appt_slot_status AS ENUM ('szabad','foglalt','letiltott','torolt');
CREATE TYPE public.appt_status AS ENUM ('foglalt','megerositendo','lemondva','megerkezett','befejezett','nem_jelent_meg');
CREATE TYPE public.appt_sync_statusz AS ENUM ('local_only','pending','synced','conflict','failed');
CREATE TYPE public.checkin_method AS ENUM ('qr','kiosk','mobile');
CREATE TYPE public.checkin_status AS ENUM ('arrived','in_room','done');
CREATE TYPE public.q_mode AS ENUM ('klinikai','egeszsegfejlesztesi','vegyes');
CREATE TYPE public.q_licenc AS ENUM ('free','public_domain','who_noncommercial','euroqol_licensed','pearson_blocked');
CREATE TYPE public.q_assignment_status AS ENUM ('assigned','in_progress','completed','expired','cancelled');
CREATE TYPE public.critical_alert_status AS ENUM ('open','acknowledged','resolved');

CREATE TABLE public.feature_flags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  kulcs text NOT NULL,
  enabled boolean NOT NULL DEFAULT false,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, kulcs)
);
GRANT SELECT ON public.feature_flags TO authenticated;
GRANT ALL ON public.feature_flags TO service_role;
ALTER TABLE public.feature_flags ENABLE ROW LEVEL SECURITY;
CREATE POLICY ff_select ON public.feature_flags FOR SELECT TO authenticated
  USING (tenant_id IS NULL OR tenant_id = public.current_tenant_id());
CREATE POLICY ff_write ON public.feature_flags FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_tenant'))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_tenant'));
CREATE TRIGGER trg_ff_touch BEFORE UPDATE ON public.feature_flags FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER trg_ff_audit AFTER INSERT OR UPDATE OR DELETE ON public.feature_flags FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

CREATE TABLE public.appointment_resources (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  nev text NOT NULL,
  tipus public.appt_resource_tipus NOT NULL,
  orvos_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  org_unit_id uuid REFERENCES public.org_units(id) ON DELETE SET NULL,
  szakma_id uuid REFERENCES public.specialties(id) ON DELETE SET NULL,
  aktiv boolean NOT NULL DEFAULT true,
  publikus boolean NOT NULL DEFAULT true,
  szin text,
  leiras text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (orvos_id IS NOT NULL OR org_unit_id IS NOT NULL)
);
CREATE INDEX appt_resources_tenant_idx ON public.appointment_resources(tenant_id, aktiv);
GRANT SELECT ON public.appointment_resources TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.appointment_resources TO authenticated;
GRANT ALL ON public.appointment_resources TO service_role;
ALTER TABLE public.appointment_resources ENABLE ROW LEVEL SECURITY;
CREATE POLICY ar_public_read ON public.appointment_resources FOR SELECT TO anon
  USING (aktiv AND publikus);
CREATE POLICY ar_select ON public.appointment_resources FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() OR (aktiv AND publikus));
CREATE POLICY ar_write ON public.appointment_resources FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_schedule') OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_schedule') OR public.has_permission(auth.uid(),'manage_tenant')));
CREATE TRIGGER trg_ar_touch BEFORE UPDATE ON public.appointment_resources FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER trg_ar_audit AFTER INSERT OR UPDATE OR DELETE ON public.appointment_resources FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

CREATE TABLE public.appointment_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  resource_id uuid NOT NULL REFERENCES public.appointment_resources(id) ON DELETE CASCADE,
  nev text NOT NULL,
  napok smallint[] NOT NULL,
  kezd_ido time NOT NULL,
  veg_ido time NOT NULL,
  slot_perc smallint NOT NULL DEFAULT 15 CHECK (slot_perc BETWEEN 5 AND 240),
  kapacitas smallint NOT NULL DEFAULT 1 CHECK (kapacitas > 0),
  ervenyes_tol date NOT NULL DEFAULT CURRENT_DATE,
  ervenyes_ig date,
  unnepnap_uzemel boolean NOT NULL DEFAULT false,
  aktiv boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (veg_ido > kezd_ido)
);
CREATE INDEX appt_tpl_resource_idx ON public.appointment_templates(resource_id, aktiv);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.appointment_templates TO authenticated;
GRANT ALL ON public.appointment_templates TO service_role;
ALTER TABLE public.appointment_templates ENABLE ROW LEVEL SECURITY;
CREATE POLICY at_select ON public.appointment_templates FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY at_write ON public.appointment_templates FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_schedule') OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_schedule') OR public.has_permission(auth.uid(),'manage_tenant')));
CREATE TRIGGER trg_at_touch BEFORE UPDATE ON public.appointment_templates FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER trg_at_audit AFTER INSERT OR UPDATE OR DELETE ON public.appointment_templates FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

CREATE TABLE public.appointment_slots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  resource_id uuid NOT NULL REFERENCES public.appointment_resources(id) ON DELETE CASCADE,
  org_unit_id uuid REFERENCES public.org_units(id) ON DELETE SET NULL,
  template_id uuid REFERENCES public.appointment_templates(id) ON DELETE SET NULL,
  kezdo_ts timestamptz NOT NULL,
  veg_ts timestamptz NOT NULL,
  kapacitas smallint NOT NULL DEFAULT 1,
  foglalt_szam smallint NOT NULL DEFAULT 0,
  status public.appt_slot_status NOT NULL DEFAULT 'szabad',
  version int NOT NULL DEFAULT 1,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (veg_ts > kezdo_ts),
  CHECK (foglalt_szam >= 0 AND foglalt_szam <= kapacitas)
);
CREATE UNIQUE INDEX appt_slot_unique_active ON public.appointment_slots(resource_id, kezdo_ts)
  WHERE status <> 'torolt';
CREATE INDEX appt_slot_lookup_idx ON public.appointment_slots(tenant_id, resource_id, kezdo_ts);
CREATE INDEX appt_slot_status_idx ON public.appointment_slots(status, kezdo_ts);
GRANT SELECT ON public.appointment_slots TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.appointment_slots TO authenticated;
GRANT ALL ON public.appointment_slots TO service_role;
ALTER TABLE public.appointment_slots ENABLE ROW LEVEL SECURITY;
CREATE POLICY as_public_read ON public.appointment_slots FOR SELECT TO anon
  USING (status = 'szabad' AND kezdo_ts > now());
CREATE POLICY as_select ON public.appointment_slots FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() OR (status = 'szabad' AND kezdo_ts > now()));
CREATE POLICY as_write ON public.appointment_slots FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_schedule') OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_schedule') OR public.has_permission(auth.uid(),'manage_tenant')));
CREATE TRIGGER trg_as_touch BEFORE UPDATE ON public.appointment_slots FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER trg_as_audit AFTER INSERT OR UPDATE OR DELETE ON public.appointment_slots FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

CREATE TABLE public.appointments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  slot_id uuid NOT NULL REFERENCES public.appointment_slots(id) ON DELETE RESTRICT,
  resource_id uuid NOT NULL REFERENCES public.appointment_resources(id) ON DELETE RESTRICT,
  patient_id uuid REFERENCES public.patients(id) ON DELETE SET NULL,
  vendeg_nev text,
  vendeg_email text,
  vendeg_telefon text,
  vendeg_szuletesi_datum date,
  ok text,
  megjegyzes text,
  foglalas_kod text NOT NULL UNIQUE,
  email_megerositve_at timestamptz,
  status public.appt_status NOT NULL DEFAULT 'megerositendo',
  eeszt_idopont_id text,
  sync_statusz public.appt_sync_statusz NOT NULL DEFAULT 'local_only',
  external_ref text,
  idempotency_key uuid NOT NULL DEFAULT gen_random_uuid(),
  version int NOT NULL DEFAULT 1,
  gdpr_consent_at timestamptz,
  created_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (patient_id IS NOT NULL OR vendeg_nev IS NOT NULL)
);
CREATE INDEX appt_slot_idx ON public.appointments(slot_id);
CREATE INDEX appt_patient_idx ON public.appointments(patient_id);
CREATE INDEX appt_status_idx ON public.appointments(tenant_id, status);
CREATE INDEX appt_kod_idx ON public.appointments(foglalas_kod);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.appointments TO authenticated;
GRANT ALL ON public.appointments TO service_role;
ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;
CREATE POLICY ap_select ON public.appointments FOR SELECT TO authenticated
  USING (
    tenant_id = public.current_tenant_id()
    AND (
      public.has_permission(auth.uid(),'manage_schedule')
      OR public.has_permission(auth.uid(),'manage_tenant')
      OR public.has_permission(auth.uid(),'manage_patients')
      OR public.has_permission(auth.uid(),'view_team')
    )
  );
CREATE POLICY ap_write ON public.appointments FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_schedule') OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_schedule') OR public.has_permission(auth.uid(),'manage_tenant')));
CREATE TRIGGER trg_appt_touch BEFORE UPDATE ON public.appointments FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER trg_appt_audit AFTER INSERT OR UPDATE OR DELETE ON public.appointments FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

CREATE TABLE public.appointment_status_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  appointment_id uuid NOT NULL REFERENCES public.appointments(id) ON DELETE CASCADE,
  from_status public.appt_status,
  to_status public.appt_status NOT NULL,
  actor_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  reason text,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX appt_ev_idx ON public.appointment_status_events(appointment_id, created_at);
GRANT SELECT, INSERT ON public.appointment_status_events TO authenticated;
GRANT ALL ON public.appointment_status_events TO service_role;
ALTER TABLE public.appointment_status_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY ase_select ON public.appointment_status_events FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY ase_insert ON public.appointment_status_events FOR INSERT TO authenticated
  WITH CHECK (tenant_id = public.current_tenant_id());

CREATE TABLE public.patient_checkin (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  appointment_id uuid NOT NULL REFERENCES public.appointments(id) ON DELETE CASCADE,
  patient_id uuid REFERENCES public.patients(id) ON DELETE SET NULL,
  method public.checkin_method NOT NULL,
  status public.checkin_status NOT NULL DEFAULT 'arrived',
  queue_position int,
  checkin_ts timestamptz NOT NULL DEFAULT now(),
  called_ts timestamptz,
  done_ts timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX checkin_appt_idx ON public.patient_checkin(appointment_id);
CREATE INDEX checkin_queue_idx ON public.patient_checkin(tenant_id, status, checkin_ts);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.patient_checkin TO authenticated;
GRANT INSERT ON public.patient_checkin TO anon;
GRANT ALL ON public.patient_checkin TO service_role;
ALTER TABLE public.patient_checkin ENABLE ROW LEVEL SECURITY;
CREATE POLICY pc_select ON public.patient_checkin FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY pc_write ON public.patient_checkin FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id())
  WITH CHECK (tenant_id = public.current_tenant_id());
CREATE TRIGGER trg_pc_touch BEFORE UPDATE ON public.patient_checkin FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER trg_pc_audit AFTER INSERT OR UPDATE OR DELETE ON public.patient_checkin FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

CREATE TABLE public.questionnaires (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  code text NOT NULL,
  title text NOT NULL,
  leiras text,
  language text NOT NULL DEFAULT 'hu',
  items jsonb NOT NULL,
  scoring jsonb NOT NULL DEFAULT '{}'::jsonb,
  cutoffs jsonb NOT NULL DEFAULT '{}'::jsonb,
  licenc public.q_licenc NOT NULL,
  mode public.q_mode NOT NULL,
  critical_item_index int,
  critical_threshold int,
  aktiv boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, code, language)
);
GRANT SELECT ON public.questionnaires TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.questionnaires TO authenticated;
GRANT ALL ON public.questionnaires TO service_role;
ALTER TABLE public.questionnaires ENABLE ROW LEVEL SECURITY;
CREATE POLICY q_select ON public.questionnaires FOR SELECT TO anon
  USING (aktiv AND tenant_id IS NULL);
CREATE POLICY q_select_auth ON public.questionnaires FOR SELECT TO authenticated
  USING (aktiv AND (tenant_id IS NULL OR tenant_id = public.current_tenant_id()));
CREATE POLICY q_write ON public.questionnaires FOR ALL TO authenticated
  USING ((tenant_id = public.current_tenant_id() OR tenant_id IS NULL)
         AND public.has_permission(auth.uid(),'manage_tenant'))
  WITH CHECK ((tenant_id = public.current_tenant_id() OR tenant_id IS NULL)
         AND public.has_permission(auth.uid(),'manage_tenant'));
CREATE TRIGGER trg_q_touch BEFORE UPDATE ON public.questionnaires FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TABLE public.questionnaire_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  questionnaire_id uuid NOT NULL REFERENCES public.questionnaires(id) ON DELETE RESTRICT,
  patient_id uuid REFERENCES public.patients(id) ON DELETE SET NULL,
  appointment_id uuid REFERENCES public.appointments(id) ON DELETE SET NULL,
  assigned_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  token text NOT NULL UNIQUE,
  assigned_at timestamptz NOT NULL DEFAULT now(),
  due_at timestamptz,
  status public.q_assignment_status NOT NULL DEFAULT 'assigned',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX qa_appt_idx ON public.questionnaire_assignments(appointment_id);
CREATE INDEX qa_patient_idx ON public.questionnaire_assignments(patient_id);
GRANT SELECT, INSERT, UPDATE ON public.questionnaire_assignments TO authenticated;
GRANT ALL ON public.questionnaire_assignments TO service_role;
ALTER TABLE public.questionnaire_assignments ENABLE ROW LEVEL SECURITY;
CREATE POLICY qa_select_auth ON public.questionnaire_assignments FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY qa_write_auth ON public.questionnaire_assignments FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id())
  WITH CHECK (tenant_id = public.current_tenant_id());
CREATE TRIGGER trg_qa_touch BEFORE UPDATE ON public.questionnaire_assignments FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER trg_qa_audit AFTER INSERT OR UPDATE OR DELETE ON public.questionnaire_assignments FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

CREATE TABLE public.questionnaire_responses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  assignment_id uuid REFERENCES public.questionnaire_assignments(id) ON DELETE SET NULL,
  questionnaire_id uuid NOT NULL REFERENCES public.questionnaires(id) ON DELETE RESTRICT,
  patient_id uuid REFERENCES public.patients(id) ON DELETE SET NULL,
  appointment_id uuid REFERENCES public.appointments(id) ON DELETE SET NULL,
  answers jsonb NOT NULL,
  total_score numeric,
  severity text,
  critical_triggered boolean NOT NULL DEFAULT false,
  consent_to_record boolean NOT NULL DEFAULT false,
  is_anonymous boolean NOT NULL DEFAULT false,
  completed_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX qr_patient_idx ON public.questionnaire_responses(patient_id);
CREATE INDEX qr_appt_idx ON public.questionnaire_responses(appointment_id);
CREATE INDEX qr_q_idx ON public.questionnaire_responses(questionnaire_id);
GRANT SELECT, INSERT ON public.questionnaire_responses TO authenticated;
GRANT ALL ON public.questionnaire_responses TO service_role;
ALTER TABLE public.questionnaire_responses ENABLE ROW LEVEL SECURITY;
CREATE POLICY qr_select ON public.questionnaire_responses FOR SELECT TO authenticated
  USING (
    tenant_id = public.current_tenant_id()
    AND (public.has_permission(auth.uid(),'manage_patients')
         OR public.has_permission(auth.uid(),'manage_tenant'))
  );
CREATE POLICY qr_insert ON public.questionnaire_responses FOR INSERT TO authenticated
  WITH CHECK (tenant_id = public.current_tenant_id());

CREATE TABLE public.critical_result_alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  response_id uuid NOT NULL REFERENCES public.questionnaire_responses(id) ON DELETE CASCADE,
  patient_id uuid REFERENCES public.patients(id) ON DELETE SET NULL,
  appointment_id uuid REFERENCES public.appointments(id) ON DELETE SET NULL,
  alert_type text NOT NULL,
  severity text NOT NULL,
  status public.critical_alert_status NOT NULL DEFAULT 'open',
  acknowledged_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  acknowledged_at timestamptz,
  resolution_note text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX cra_status_idx ON public.critical_result_alerts(tenant_id, status, created_at);
GRANT SELECT, INSERT, UPDATE ON public.critical_result_alerts TO authenticated;
GRANT ALL ON public.critical_result_alerts TO service_role;
ALTER TABLE public.critical_result_alerts ENABLE ROW LEVEL SECURITY;
CREATE POLICY cra_select ON public.critical_result_alerts FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_patients') OR public.has_permission(auth.uid(),'manage_tenant')));
CREATE POLICY cra_write ON public.critical_result_alerts FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_patients') OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id());
CREATE TRIGGER trg_cra_touch BEFORE UPDATE ON public.critical_result_alerts FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER trg_cra_audit AFTER INSERT OR UPDATE OR DELETE ON public.critical_result_alerts FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

CREATE OR REPLACE FUNCTION public.qr_critical_alert_fn()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE v_q record;
BEGIN
  IF NEW.critical_triggered THEN
    SELECT code, title INTO v_q FROM public.questionnaires WHERE id = NEW.questionnaire_id;
    INSERT INTO public.critical_result_alerts (tenant_id, response_id, patient_id, appointment_id, alert_type, severity)
    VALUES (NEW.tenant_id, NEW.id, NEW.patient_id, NEW.appointment_id,
            CASE WHEN v_q.code = 'PHQ9' THEN 'suicidal_ideation' ELSE 'critical_screening' END,
            COALESCE(NEW.severity, 'severe'));
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER trg_qr_critical AFTER INSERT ON public.questionnaire_responses
  FOR EACH ROW EXECUTE FUNCTION public.qr_critical_alert_fn();

CREATE TABLE public.satisfaction_surveys (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  appointment_id uuid REFERENCES public.appointments(id) ON DELETE SET NULL,
  resource_id uuid REFERENCES public.appointment_resources(id) ON DELETE SET NULL,
  instrument_code text NOT NULL,
  answers jsonb NOT NULL,
  nps_score int CHECK (nps_score IS NULL OR (nps_score BETWEEN 0 AND 10)),
  is_anonymous boolean NOT NULL DEFAULT true,
  submitted_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ss_appt_idx ON public.satisfaction_surveys(appointment_id);
CREATE INDEX ss_tenant_idx ON public.satisfaction_surveys(tenant_id, submitted_at);
GRANT SELECT, INSERT ON public.satisfaction_surveys TO authenticated;
GRANT INSERT ON public.satisfaction_surveys TO anon;
GRANT ALL ON public.satisfaction_surveys TO service_role;
ALTER TABLE public.satisfaction_surveys ENABLE ROW LEVEL SECURITY;
CREATE POLICY ss_select ON public.satisfaction_surveys FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(),'manage_schedule')
              OR public.has_permission(auth.uid(),'manage_tenant')
              OR public.has_permission(auth.uid(),'view_team')));
CREATE POLICY ss_insert_anon ON public.satisfaction_surveys FOR INSERT TO anon
  WITH CHECK (true);
CREATE POLICY ss_insert_auth ON public.satisfaction_surveys FOR INSERT TO authenticated
  WITH CHECK (tenant_id = public.current_tenant_id());

INSERT INTO public.questionnaires (code, title, leiras, items, scoring, cutoffs, licenc, mode, critical_item_index, critical_threshold) VALUES
('PHQ9','PHQ-9 (Depresszió szűrés)',
 'Az elmúlt 2 hétben milyen gyakran zavarták a következő problémák? (Pfizer 2010 — szabad felhasználás)',
 '{"items":[{"id":"q1","text":"Csekély érdeklődés vagy öröm a dolgok iránt"},{"id":"q2","text":"Levert, lehangolt vagy reménytelen hangulat"},{"id":"q3","text":"Alvási nehézség (elalvás, átalvás vagy túl sok alvás)"},{"id":"q4","text":"Fáradtság vagy energiahiány"},{"id":"q5","text":"Étvágytalanság vagy túlevés"},{"id":"q6","text":"Rossz érzés saját magával kapcsolatban"},{"id":"q7","text":"Koncentrációs nehézség"},{"id":"q8","text":"Lassú mozgás/beszéd vagy nyugtalanság"},{"id":"q9","text":"Gondolatok arról, hogy jobb lenne meghalni vagy önmagát bántani"}],"options":[{"v":0,"l":"Egyáltalán nem"},{"v":1,"l":"Néhány napon"},{"v":2,"l":"A napok több mint felében"},{"v":3,"l":"Majdnem minden nap"}]}'::jsonb,
 '{"type":"sum","range":[0,27]}'::jsonb,
 '{"thresholds":[{"min":0,"max":4,"severity":"minimal"},{"min":5,"max":9,"severity":"mild"},{"min":10,"max":14,"severity":"moderate"},{"min":15,"max":19,"severity":"moderately_severe"},{"min":20,"max":27,"severity":"severe"}]}'::jsonb,
 'free','klinikai',9,1),
('GAD7','GAD-7 (Szorongás szűrés)','Pfizer 2010 — szabad felhasználás',
 '{"items":[{"id":"q1","text":"Idegesség, szorongás vagy feszültség érzése"},{"id":"q2","text":"Képtelen abbahagyni vagy kontrollálni az aggódást"},{"id":"q3","text":"Túlzott aggódás különböző dolgok miatt"},{"id":"q4","text":"Nehéz ellazulni"},{"id":"q5","text":"Annyira nyugtalan, hogy nehéz nyugton ülni"},{"id":"q6","text":"Könnyen bosszankodó vagy ingerlékeny"},{"id":"q7","text":"Félelem, mintha valami szörnyű történne"}],"options":[{"v":0,"l":"Egyáltalán nem"},{"v":1,"l":"Néhány napon"},{"v":2,"l":"A napok több mint felében"},{"v":3,"l":"Majdnem minden nap"}]}'::jsonb,
 '{"type":"sum","range":[0,21]}'::jsonb,
 '{"thresholds":[{"min":0,"max":4,"severity":"minimal"},{"min":5,"max":9,"severity":"mild"},{"min":10,"max":14,"severity":"moderate"},{"min":15,"max":21,"severity":"severe"}]}'::jsonb,
 'free','klinikai',NULL,NULL),
('PHQ4','PHQ-4 (Ultrarövid triage)','Kroenke et al.',
 '{"items":[{"id":"a1","text":"Idegesség, szorongás vagy feszültség"},{"id":"a2","text":"Képtelen abbahagyni vagy kontrollálni az aggódást"},{"id":"d1","text":"Csekély érdeklődés vagy öröm a dolgok iránt"},{"id":"d2","text":"Levert, lehangolt vagy reménytelen hangulat"}],"options":[{"v":0,"l":"Egyáltalán nem"},{"v":1,"l":"Néhány napon"},{"v":2,"l":"A napok több mint felében"},{"v":3,"l":"Majdnem minden nap"}]}'::jsonb,
 '{"type":"sum","range":[0,12]}'::jsonb,
 '{"thresholds":[{"min":0,"max":2,"severity":"none"},{"min":3,"max":5,"severity":"mild"},{"min":6,"max":8,"severity":"moderate"},{"min":9,"max":12,"severity":"severe"}]}'::jsonb,
 'free','vegyes',NULL,NULL),
('AUDITC','AUDIT-C (Alkoholfogyasztás)','WHO AUDIT-C',
 '{"items":[{"id":"q1","text":"Milyen gyakran iszik alkoholt?","opts":[{"v":0,"l":"Soha"},{"v":1,"l":"Havonta vagy ritkábban"},{"v":2,"l":"Havi 2-4 alkalommal"},{"v":3,"l":"Heti 2-3 alkalommal"},{"v":4,"l":"Heti 4 vagy több alkalommal"}]},{"id":"q2","text":"Hány egységnyi alkoholt fogyaszt egy tipikus napon?","opts":[{"v":0,"l":"1-2"},{"v":1,"l":"3-4"},{"v":2,"l":"5-6"},{"v":3,"l":"7-9"},{"v":4,"l":"10 vagy több"}]},{"id":"q3","text":"Milyen gyakran iszik 6+ egységet egyszerre?","opts":[{"v":0,"l":"Soha"},{"v":1,"l":"Ritkábban mint havonta"},{"v":2,"l":"Havonta"},{"v":3,"l":"Hetente"},{"v":4,"l":"Naponta"}]}]}'::jsonb,
 '{"type":"sum","range":[0,12]}'::jsonb,
 '{"thresholds":[{"min":0,"max":2,"severity":"low"},{"min":3,"max":4,"severity":"at_risk"},{"min":5,"max":12,"severity":"hazardous"}]}'::jsonb,
 'free','vegyes',NULL,NULL),
('FAGERSTROM','Fagerström (Nikotinfüggőség)','FTND',
 '{"items":[{"id":"q1","text":"Felkelés után milyen hamar gyújt rá?","opts":[{"v":3,"l":"5 percen belül"},{"v":2,"l":"6-30 perc"},{"v":1,"l":"31-60 perc"},{"v":0,"l":"60 perc után"}]},{"id":"q2","text":"Nehéz tartózkodnia nemdohányzó helyeken?","opts":[{"v":1,"l":"Igen"},{"v":0,"l":"Nem"}]},{"id":"q3","text":"Melyik cigarettáról esne legnehezebben lemondania?","opts":[{"v":1,"l":"A reggeli elsőről"},{"v":0,"l":"Bármelyik másikról"}]},{"id":"q4","text":"Naponta hány szál cigarettát szív el?","opts":[{"v":0,"l":"10 vagy kevesebb"},{"v":1,"l":"11-20"},{"v":2,"l":"21-30"},{"v":3,"l":"31 vagy több"}]},{"id":"q5","text":"Gyakrabban dohányzik az első órákban?","opts":[{"v":1,"l":"Igen"},{"v":0,"l":"Nem"}]},{"id":"q6","text":"Dohányzik betegen is?","opts":[{"v":1,"l":"Igen"},{"v":0,"l":"Nem"}]}]}'::jsonb,
 '{"type":"sum","range":[0,10]}'::jsonb,
 '{"thresholds":[{"min":0,"max":2,"severity":"very_low"},{"min":3,"max":4,"severity":"low"},{"min":5,"max":5,"severity":"medium"},{"min":6,"max":7,"severity":"high"},{"min":8,"max":10,"severity":"very_high"}]}'::jsonb,
 'free','egeszsegfejlesztesi',NULL,NULL),
('CGCAHPS','Páciens-elégedettség (CG-CAHPS alapú, 12 tétel)','AHRQ CG-CAHPS public domain alapján',
 '{"items":[{"id":"q1","text":"Mennyi idő alatt kapott időpontot?"},{"id":"q2","text":"Időben tudott bejutni?"},{"id":"q3","text":"Tisztelettel bántak a recepciósok?"},{"id":"q4","text":"A szolgáltató figyelmesen meghallgatta?"},{"id":"q5","text":"Világosan elmagyarázta a dolgokat?"},{"id":"q6","text":"Bevonta a döntésekbe?"},{"id":"q7","text":"Eleget töltött Önnel?"},{"id":"q8","text":"Bízott a szakértelmében?"},{"id":"q9","text":"Könnyen kapott választ telefonon?"},{"id":"q10","text":"A rendelő tiszta volt?"},{"id":"q11","text":"Időben kapott eredményeket?"},{"id":"q12","text":"Összértékelés 0-10"}],"options":[{"v":1,"l":"Soha"},{"v":2,"l":"Néha"},{"v":3,"l":"Általában"},{"v":4,"l":"Mindig"}]}'::jsonb,
 '{"type":"mean","range":[1,4]}'::jsonb,
 '{}'::jsonb,
 'public_domain','egeszsegfejlesztesi',NULL,NULL),
('NPS','NPS — Ajánlási hajlandóság','Adams et al. (2022): NPS másodlagos trend-metrika.',
 '{"items":[{"id":"q1","text":"Mennyire valószínű, hogy ajánlaná rendelőnket? (0-10)","scale":{"min":0,"max":10}},{"id":"q2","text":"Indoklás (opcionális)","type":"text"}]}'::jsonb,
 '{"type":"nps"}'::jsonb,'{}'::jsonb,'free','egeszsegfejlesztesi',NULL,NULL),
('WHO5','WHO-5 (Jóllét) — LICENC SZÜKSÉGES','WHO 2024 CC BY-NC-SA 3.0 IGO — kereskedelmi engedély szükséges.',
 '{"items":[]}'::jsonb,'{}'::jsonb,'{}'::jsonb,'who_noncommercial','egeszsegfejlesztesi',NULL,NULL),
('EQ5D','EQ-5D — LICENC SZÜKSÉGES','EuroQol licenc szükséges — euroqol.org regisztráció.',
 '{"items":[]}'::jsonb,'{}'::jsonb,'{}'::jsonb,'euroqol_licensed','klinikai',NULL,NULL);

UPDATE public.questionnaires SET aktiv = false WHERE code IN ('WHO5','EQ5D');


-- ─── 20260619143010_166413ed-d3f9-40ec-9844-230d1097d367.sql ───

-- ============================================================
-- Monitoring modul — Fázis 1 (séma)
-- ============================================================

-- 1) Enumok
DO $$ BEGIN
  CREATE TYPE public.monitoring_program_tipus AS ENUM ('terhesseg','betegseg','csaladtervezes');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.measurement_kind AS ENUM (
    'testsuly','testmagassag','bmi','haskorfogat','nyakkorfogat',
    'vernyomas','vercukor','testho','sport','lepes','pulzus','hrv','magzatmozgas'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.measurement_source AS ENUM ('kezi','wearable','eszkoz');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.monitoring_alert_kind AS ENUM (
    'magzatmozgas_csokkent','gdm_vercukor','preeclampsia_bp','urgent_bp',
    'laz','szekletveres','egyeb'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.monitoring_alert_status AS ENUM ('open','acknowledged','resolved');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.monitoring_alert_severity AS ENUM ('info','figyelem','surgos','kritikus');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- 2) monitoring_programs
CREATE TABLE public.monitoring_programs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  tipus public.monitoring_program_tipus NOT NULL,
  kezdes date NOT NULL DEFAULT current_date,
  varhato_veg date NULL,
  aktiv boolean NOT NULL DEFAULT true,
  megjegyzes text NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_mon_programs_patient ON public.monitoring_programs(patient_id);
CREATE INDEX idx_mon_programs_tenant ON public.monitoring_programs(tenant_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.monitoring_programs TO authenticated;
GRANT ALL ON public.monitoring_programs TO service_role;
ALTER TABLE public.monitoring_programs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "tenant_isolation_mon_programs" ON public.monitoring_programs
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id())
  WITH CHECK (tenant_id = public.current_tenant_id());
CREATE POLICY "service_role_mon_programs" ON public.monitoring_programs
  FOR ALL TO service_role USING (true) WITH CHECK (true);
CREATE TRIGGER trg_mon_programs_touch BEFORE UPDATE ON public.monitoring_programs
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER trg_mon_programs_audit AFTER INSERT OR UPDATE OR DELETE ON public.monitoring_programs
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- 3) measurements (közös mérés-eseménytár)
CREATE TABLE public.measurements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  program_id uuid NULL REFERENCES public.monitoring_programs(id) ON DELETE SET NULL,
  kind public.measurement_kind NOT NULL,
  ts timestamptz NOT NULL DEFAULT now(),
  value numeric NULL,
  value2 numeric NULL,
  unit text NULL,
  context jsonb NULL,
  source public.measurement_source NOT NULL DEFAULT 'kezi',
  recorded_by uuid NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_measurements_patient_ts ON public.measurements(patient_id, ts DESC);
CREATE INDEX idx_measurements_kind_ts ON public.measurements(kind, ts DESC);
CREATE INDEX idx_measurements_program ON public.measurements(program_id) WHERE program_id IS NOT NULL;
CREATE INDEX idx_measurements_tenant ON public.measurements(tenant_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.measurements TO authenticated;
GRANT ALL ON public.measurements TO service_role;
ALTER TABLE public.measurements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "tenant_isolation_measurements" ON public.measurements
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id())
  WITH CHECK (tenant_id = public.current_tenant_id());
CREATE POLICY "service_role_measurements" ON public.measurements
  FOR ALL TO service_role USING (true) WITH CHECK (true);
CREATE TRIGGER trg_measurements_audit AFTER INSERT OR UPDATE OR DELETE ON public.measurements
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- 4) food_log
CREATE TABLE public.food_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  program_id uuid NULL REFERENCES public.monitoring_programs(id) ON DELETE SET NULL,
  ts timestamptz NOT NULL DEFAULT now(),
  foto_url text NULL,
  leiras text NULL,
  ai_becsult_kcal numeric NULL,
  ai_makro jsonb NULL,
  etkezes_tipus text NULL,
  megbizhatosag text NOT NULL DEFAULT 'alacsony',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_food_log_patient_ts ON public.food_log(patient_id, ts DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.food_log TO authenticated;
GRANT ALL ON public.food_log TO service_role;
ALTER TABLE public.food_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY "tenant_isolation_food_log" ON public.food_log
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id())
  WITH CHECK (tenant_id = public.current_tenant_id());
CREATE POLICY "service_role_food_log" ON public.food_log
  FOR ALL TO service_role USING (true) WITH CHECK (true);

-- 5) stool_log (Bristol + Róma IV)
CREATE TABLE public.stool_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  program_id uuid NULL REFERENCES public.monitoring_programs(id) ON DELETE SET NULL,
  ts timestamptz NOT NULL DEFAULT now(),
  foto_url text NULL,
  bristol_tipus int NULL CHECK (bristol_tipus BETWEEN 1 AND 7),
  ai_bristol_javaslat int NULL CHECK (ai_bristol_javaslat BETWEEN 1 AND 7),
  rome_tunetek jsonb NULL,
  veres boolean NOT NULL DEFAULT false,
  nyak boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_stool_log_patient_ts ON public.stool_log(patient_id, ts DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.stool_log TO authenticated;
GRANT ALL ON public.stool_log TO service_role;
ALTER TABLE public.stool_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY "tenant_isolation_stool_log" ON public.stool_log
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id())
  WITH CHECK (tenant_id = public.current_tenant_id());
CREATE POLICY "service_role_stool_log" ON public.stool_log
  FOR ALL TO service_role USING (true) WITH CHECK (true);

-- 6) contractions (terhességi fájás-timer)
CREATE TABLE public.contractions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  program_id uuid NULL REFERENCES public.monitoring_programs(id) ON DELETE SET NULL,
  kezdes timestamptz NOT NULL,
  veg timestamptz NULL,
  idotartam_mp int NULL,
  gyakorisag_perc numeric NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_contractions_patient_kezdes ON public.contractions(patient_id, kezdes DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.contractions TO authenticated;
GRANT ALL ON public.contractions TO service_role;
ALTER TABLE public.contractions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "tenant_isolation_contractions" ON public.contractions
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id())
  WITH CHECK (tenant_id = public.current_tenant_id());
CREATE POLICY "service_role_contractions" ON public.contractions
  FOR ALL TO service_role USING (true) WITH CHECK (true);

-- 7) fetal_movements (kick counter)
CREATE TABLE public.fetal_movements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  program_id uuid NULL REFERENCES public.monitoring_programs(id) ON DELETE SET NULL,
  datum date NOT NULL DEFAULT current_date,
  szakasz_kezdes timestamptz NOT NULL DEFAULT now(),
  mozgas_szam int NOT NULL DEFAULT 0,
  tizedik_mozgas_ido timestamptz NULL,
  eltelt_perc int NULL,
  jegyzet text NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_fetal_movements_patient ON public.fetal_movements(patient_id, datum DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.fetal_movements TO authenticated;
GRANT ALL ON public.fetal_movements TO service_role;
ALTER TABLE public.fetal_movements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "tenant_isolation_fetal_mov" ON public.fetal_movements
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id())
  WITH CHECK (tenant_id = public.current_tenant_id());
CREATE POLICY "service_role_fetal_mov" ON public.fetal_movements
  FOR ALL TO service_role USING (true) WITH CHECK (true);

-- 8) menstrual_cycles
CREATE TABLE public.menstrual_cycles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  program_id uuid NULL REFERENCES public.monitoring_programs(id) ON DELETE SET NULL,
  ciklus_kezdet date NOT NULL,
  ciklus_hossz int NULL,
  menstruacio_hossz int NULL,
  tunetek jsonb NULL,
  bbt_id uuid NULL REFERENCES public.measurements(id) ON DELETE SET NULL,
  ovulacio_becsult date NULL,
  termekeny_ablak_tol date NULL,
  termekeny_ablak_ig date NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_menstrual_patient ON public.menstrual_cycles(patient_id, ciklus_kezdet DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.menstrual_cycles TO authenticated;
GRANT ALL ON public.menstrual_cycles TO service_role;
ALTER TABLE public.menstrual_cycles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "tenant_isolation_menstrual" ON public.menstrual_cycles
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id())
  WITH CHECK (tenant_id = public.current_tenant_id());
CREATE POLICY "service_role_menstrual" ON public.menstrual_cycles
  FOR ALL TO service_role USING (true) WITH CHECK (true);

-- 9) wearable_data
CREATE TABLE public.wearable_data (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  provider text NOT NULL,
  datum date NOT NULL,
  lepes int NULL,
  atlag_pulzus int NULL,
  nyugalmi_pulzus int NULL,
  hrv_ms numeric NULL,
  alvas_perc int NULL,
  raw jsonb NULL,
  synced_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (patient_id, provider, datum)
);
CREATE INDEX idx_wearable_patient_datum ON public.wearable_data(patient_id, datum DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.wearable_data TO authenticated;
GRANT ALL ON public.wearable_data TO service_role;
ALTER TABLE public.wearable_data ENABLE ROW LEVEL SECURITY;
CREATE POLICY "tenant_isolation_wearable" ON public.wearable_data
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id())
  WITH CHECK (tenant_id = public.current_tenant_id());
CREATE POLICY "service_role_wearable" ON public.wearable_data
  FOR ALL TO service_role USING (true) WITH CHECK (true);

-- 10) monitoring_thresholds (programonként paraméterezhető küszöbök)
CREATE TABLE public.monitoring_thresholds (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  program_id uuid NULL REFERENCES public.monitoring_programs(id) ON DELETE CASCADE,
  patient_id uuid NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  -- ha mindkettő NULL → tenant-szintű alapérték
  kulcs text NOT NULL,           -- pl. 'bp_sys_warn', 'bp_sys_urgent', 'glucose_fasting'
  ertek numeric NOT NULL,
  unit text NULL,
  megjegyzes text NULL,
  beallito_id uuid NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, program_id, patient_id, kulcs)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.monitoring_thresholds TO authenticated;
GRANT ALL ON public.monitoring_thresholds TO service_role;
ALTER TABLE public.monitoring_thresholds ENABLE ROW LEVEL SECURITY;
CREATE POLICY "tenant_isolation_thresholds" ON public.monitoring_thresholds
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id())
  WITH CHECK (tenant_id = public.current_tenant_id());
CREATE POLICY "service_role_thresholds" ON public.monitoring_thresholds
  FOR ALL TO service_role USING (true) WITH CHECK (true);
CREATE TRIGGER trg_thresholds_touch BEFORE UPDATE ON public.monitoring_thresholds
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- 11) monitoring_alerts
CREATE TABLE public.monitoring_alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  program_id uuid NULL REFERENCES public.monitoring_programs(id) ON DELETE SET NULL,
  measurement_id uuid NULL REFERENCES public.measurements(id) ON DELETE SET NULL,
  fetal_movement_id uuid NULL REFERENCES public.fetal_movements(id) ON DELETE SET NULL,
  stool_log_id uuid NULL REFERENCES public.stool_log(id) ON DELETE SET NULL,
  kind public.monitoring_alert_kind NOT NULL,
  severity public.monitoring_alert_severity NOT NULL DEFAULT 'figyelem',
  status public.monitoring_alert_status NOT NULL DEFAULT 'open',
  uzenet text NOT NULL,
  acknowledged_by uuid NULL,
  acknowledged_at timestamptz NULL,
  ack_note text NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_mon_alerts_patient ON public.monitoring_alerts(patient_id, created_at DESC);
CREATE INDEX idx_mon_alerts_status ON public.monitoring_alerts(status, severity);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.monitoring_alerts TO authenticated;
GRANT ALL ON public.monitoring_alerts TO service_role;
ALTER TABLE public.monitoring_alerts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "tenant_isolation_mon_alerts" ON public.monitoring_alerts
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id())
  WITH CHECK (tenant_id = public.current_tenant_id());
CREATE POLICY "service_role_mon_alerts" ON public.monitoring_alerts
  FOR ALL TO service_role USING (true) WITH CHECK (true);
CREATE TRIGGER trg_mon_alerts_audit AFTER INSERT OR UPDATE OR DELETE ON public.monitoring_alerts
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- 12) Automatikus riasztás-trigger (vérnyomás, vércukor, láz, székletvér)
CREATE OR REPLACE FUNCTION public.measurements_auto_alert()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_sys numeric; v_dia numeric;
  v_th_sys_urg numeric; v_th_sys_warn numeric;
  v_th_dia_urg numeric; v_th_dia_warn numeric;
  v_th_glu_fast numeric; v_th_glu_pp numeric;
  v_th_fever numeric;
  v_is_post boolean;
BEGIN
  -- vérnyomás
  IF NEW.kind = 'vernyomas' AND NEW.value IS NOT NULL AND NEW.value2 IS NOT NULL THEN
    v_sys := NEW.value; v_dia := NEW.value2;
    SELECT ertek INTO v_th_sys_urg FROM public.monitoring_thresholds
      WHERE tenant_id = NEW.tenant_id AND kulcs = 'bp_sys_urgent'
        AND (program_id = NEW.program_id OR program_id IS NULL)
      ORDER BY program_id NULLS LAST LIMIT 1;
    v_th_sys_urg := COALESCE(v_th_sys_urg, 160);
    SELECT ertek INTO v_th_dia_urg FROM public.monitoring_thresholds
      WHERE tenant_id = NEW.tenant_id AND kulcs = 'bp_dia_urgent'
        AND (program_id = NEW.program_id OR program_id IS NULL)
      ORDER BY program_id NULLS LAST LIMIT 1;
    v_th_dia_urg := COALESCE(v_th_dia_urg, 110);
    SELECT ertek INTO v_th_sys_warn FROM public.monitoring_thresholds
      WHERE tenant_id = NEW.tenant_id AND kulcs = 'bp_sys_warn'
        AND (program_id = NEW.program_id OR program_id IS NULL)
      ORDER BY program_id NULLS LAST LIMIT 1;
    v_th_sys_warn := COALESCE(v_th_sys_warn, 140);
    SELECT ertek INTO v_th_dia_warn FROM public.monitoring_thresholds
      WHERE tenant_id = NEW.tenant_id AND kulcs = 'bp_dia_warn'
        AND (program_id = NEW.program_id OR program_id IS NULL)
      ORDER BY program_id NULLS LAST LIMIT 1;
    v_th_dia_warn := COALESCE(v_th_dia_warn, 90);

    IF v_sys >= v_th_sys_urg OR v_dia >= v_th_dia_urg THEN
      INSERT INTO public.monitoring_alerts(tenant_id, patient_id, program_id, measurement_id, kind, severity, uzenet)
      VALUES (NEW.tenant_id, NEW.patient_id, NEW.program_id, NEW.id,
              'urgent_bp','kritikus',
              format('Sürgős vérnyomás-eszkaláció: %s/%s Hgmm — azonnali orvosi konzultáció.', v_sys::text, v_dia::text));
    ELSIF v_sys >= v_th_sys_warn OR v_dia >= v_th_dia_warn THEN
      INSERT INTO public.monitoring_alerts(tenant_id, patient_id, program_id, measurement_id, kind, severity, uzenet)
      VALUES (NEW.tenant_id, NEW.patient_id, NEW.program_id, NEW.id,
              'preeclampsia_bp','figyelem',
              format('Magas vérnyomás: %s/%s Hgmm — klinikus felülvizsgálat javasolt.', v_sys::text, v_dia::text));
    END IF;
  END IF;

  -- vércukor (GDM)
  IF NEW.kind = 'vercukor' AND NEW.value IS NOT NULL THEN
    v_is_post := COALESCE((NEW.context->>'idopont') ILIKE '%_utan', false);
    IF v_is_post THEN
      SELECT ertek INTO v_th_glu_pp FROM public.monitoring_thresholds
        WHERE tenant_id = NEW.tenant_id AND kulcs = 'glucose_postprandial'
          AND (program_id = NEW.program_id OR program_id IS NULL)
        ORDER BY program_id NULLS LAST LIMIT 1;
      v_th_glu_pp := COALESCE(v_th_glu_pp, 7.8);
      IF NEW.value >= v_th_glu_pp THEN
        INSERT INTO public.monitoring_alerts(tenant_id, patient_id, program_id, measurement_id, kind, severity, uzenet)
        VALUES (NEW.tenant_id, NEW.patient_id, NEW.program_id, NEW.id,
                'gdm_vercukor','figyelem',
                format('Posztprandiális vércukor küszöb felett: %s mmol/L. Döntéstámogatás, nem dózis-tanács.', NEW.value::text));
      END IF;
    ELSE
      SELECT ertek INTO v_th_glu_fast FROM public.monitoring_thresholds
        WHERE tenant_id = NEW.tenant_id AND kulcs = 'glucose_fasting'
          AND (program_id = NEW.program_id OR program_id IS NULL)
        ORDER BY program_id NULLS LAST LIMIT 1;
      v_th_glu_fast := COALESCE(v_th_glu_fast, 5.3);
      IF NEW.value >= v_th_glu_fast THEN
        INSERT INTO public.monitoring_alerts(tenant_id, patient_id, program_id, measurement_id, kind, severity, uzenet)
        VALUES (NEW.tenant_id, NEW.patient_id, NEW.program_id, NEW.id,
                'gdm_vercukor','figyelem',
                format('Éhomi vércukor küszöb felett: %s mmol/L.', NEW.value::text));
      END IF;
    END IF;
  END IF;

  -- láz
  IF NEW.kind = 'testho' AND NEW.value IS NOT NULL THEN
    SELECT ertek INTO v_th_fever FROM public.monitoring_thresholds
      WHERE tenant_id = NEW.tenant_id AND kulcs = 'fever'
        AND (program_id = NEW.program_id OR program_id IS NULL)
      ORDER BY program_id NULLS LAST LIMIT 1;
    v_th_fever := COALESCE(v_th_fever, 38.0);
    IF NEW.value >= v_th_fever THEN
      INSERT INTO public.monitoring_alerts(tenant_id, patient_id, program_id, measurement_id, kind, severity, uzenet)
      VALUES (NEW.tenant_id, NEW.patient_id, NEW.program_id, NEW.id,
              'laz','figyelem',
              format('Láz: %s °C.', NEW.value::text));
    END IF;
  END IF;

  RETURN NEW;
END $$;

CREATE TRIGGER trg_measurements_auto_alert
AFTER INSERT ON public.measurements
FOR EACH ROW EXECUTE FUNCTION public.measurements_auto_alert();

-- 13) Magzatmozgás-zárás riasztás (ha 10 mozgás nem érte el a beállított ablakot)
CREATE OR REPLACE FUNCTION public.fetal_movements_auto_alert()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_window int;
BEGIN
  SELECT ertek::int INTO v_window FROM public.monitoring_thresholds
    WHERE tenant_id = NEW.tenant_id AND kulcs = 'fetal_window_perc'
      AND (program_id = NEW.program_id OR program_id IS NULL)
    ORDER BY program_id NULLS LAST LIMIT 1;
  v_window := COALESCE(v_window, 120);

  IF (NEW.mozgas_szam < 10 AND NEW.eltelt_perc IS NOT NULL AND NEW.eltelt_perc >= v_window)
     OR (NEW.tizedik_mozgas_ido IS NOT NULL AND NEW.eltelt_perc IS NOT NULL AND NEW.eltelt_perc > v_window) THEN
    INSERT INTO public.monitoring_alerts(tenant_id, patient_id, program_id, fetal_movement_id, kind, severity, uzenet)
    VALUES (NEW.tenant_id, NEW.patient_id, NEW.program_id, NEW.id,
            'magzatmozgas_csokkent','kritikus',
            'SÜRGŐS: a magzatmozgás-számláló nem érte el a 10 mozgást a beállított időablakban. Azonnal forduljon szülészeti ügyelethez.');
  END IF;
  RETURN NEW;
END $$;

CREATE TRIGGER trg_fetal_auto_alert
AFTER INSERT OR UPDATE ON public.fetal_movements
FOR EACH ROW EXECUTE FUNCTION public.fetal_movements_auto_alert();

-- 14) Székletvér riasztás
CREATE OR REPLACE FUNCTION public.stool_log_auto_alert()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.veres = true THEN
    INSERT INTO public.monitoring_alerts(tenant_id, patient_id, program_id, stool_log_id, kind, severity, uzenet)
    VALUES (NEW.tenant_id, NEW.patient_id, NEW.program_id, NEW.id,
            'szekletveres','surgos',
            'Vér a székletben — orvosi konzultáció javasolt.');
  END IF;
  RETURN NEW;
END $$;

CREATE TRIGGER trg_stool_auto_alert
AFTER INSERT ON public.stool_log
FOR EACH ROW EXECUTE FUNCTION public.stool_log_auto_alert();

-- 15) BMI auto-frissítés új testsúly mérésnél (a legutóbbi testmagasságból)
CREATE OR REPLACE FUNCTION public.measurements_recompute_bmi()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_h numeric;
  v_bmi numeric;
BEGIN
  IF NEW.kind = 'testsuly' AND NEW.value IS NOT NULL THEN
    SELECT value INTO v_h FROM public.measurements
      WHERE patient_id = NEW.patient_id AND kind = 'testmagassag' AND value IS NOT NULL
      ORDER BY ts DESC LIMIT 1;
    IF v_h IS NOT NULL AND v_h > 0 THEN
      v_bmi := ROUND( (NEW.value / ((v_h/100.0) * (v_h/100.0)))::numeric , 2);
      INSERT INTO public.measurements(tenant_id, patient_id, program_id, kind, ts, value, unit, source, context)
      VALUES (NEW.tenant_id, NEW.patient_id, NEW.program_id, 'bmi', NEW.ts, v_bmi, 'kg/m2', 'kezi',
              jsonb_build_object('derived_from', NEW.id::text));
    END IF;
  END IF;
  RETURN NEW;
END $$;

CREATE TRIGGER trg_measurements_bmi
AFTER INSERT ON public.measurements
FOR EACH ROW
WHEN (NEW.kind = 'testsuly')
EXECUTE FUNCTION public.measurements_recompute_bmi();


-- ─── 20260619143723_4e0d6548-9fcf-45f7-bfe6-c38deae68059.sql ───

-- séma-bővítés
ALTER TABLE public.questionnaires
  ADD COLUMN IF NOT EXISTS kioszk_eligible boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS becsult_perc int NULL;

-- globális (tenant nélküli) kérdőív-bank parciális egyedi index
CREATE UNIQUE INDEX IF NOT EXISTS uq_questionnaires_global_code_lang
  ON public.questionnaires (code, language)
  WHERE tenant_id IS NULL;

DO $$ BEGIN
  CREATE TYPE public.assignment_kind AS ENUM ('varakozas','periodikus','egyedi','foglalashoz');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

ALTER TABLE public.questionnaire_assignments
  ADD COLUMN IF NOT EXISTS kind public.assignment_kind NOT NULL DEFAULT 'egyedi';

CREATE INDEX IF NOT EXISTS idx_qassign_kind_status
  ON public.questionnaire_assignments(kind, status);

CREATE TABLE IF NOT EXISTS public.questionnaire_schedules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  questionnaire_id uuid NOT NULL REFERENCES public.questionnaires(id) ON DELETE CASCADE,
  monitoring_program_id uuid NULL REFERENCES public.monitoring_programs(id) ON DELETE CASCADE,
  patient_id uuid NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  scope text NOT NULL DEFAULT 'program',
  interval_days int NOT NULL CHECK (interval_days BETWEEN 1 AND 365),
  next_due_at timestamptz NULL,
  last_run_at timestamptz NULL,
  aktiv boolean NOT NULL DEFAULT true,
  beallito_id uuid NULL,
  megjegyzes text NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_qsched_tenant ON public.questionnaire_schedules(tenant_id);
CREATE INDEX IF NOT EXISTS idx_qsched_program ON public.questionnaire_schedules(monitoring_program_id);
CREATE INDEX IF NOT EXISTS idx_qsched_due ON public.questionnaire_schedules(next_due_at) WHERE aktiv = true;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.questionnaire_schedules TO authenticated;
GRANT ALL ON public.questionnaire_schedules TO service_role;
ALTER TABLE public.questionnaire_schedules ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "tenant_isolation_qsched" ON public.questionnaire_schedules;
CREATE POLICY "tenant_isolation_qsched" ON public.questionnaire_schedules
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id())
  WITH CHECK (tenant_id = public.current_tenant_id());
DROP POLICY IF EXISTS "service_role_qsched" ON public.questionnaire_schedules;
CREATE POLICY "service_role_qsched" ON public.questionnaire_schedules
  FOR ALL TO service_role USING (true) WITH CHECK (true);
DROP TRIGGER IF EXISTS trg_qsched_touch ON public.questionnaire_schedules;
CREATE TRIGGER trg_qsched_touch BEFORE UPDATE ON public.questionnaire_schedules
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- ============================================================
-- Seed (tenant_id NULL = globális bank; ON CONFLICT parciális indexre)
-- ============================================================

-- PHQ-9
INSERT INTO public.questionnaires (code, title, leiras, language, items, scoring, cutoffs, licenc, mode, critical_item_index, critical_threshold, kioszk_eligible, becsult_perc, aktiv)
VALUES ('PHQ9', 'PHQ-9 — Depresszió szűrő',
'Az elmúlt 2 hét során milyen gyakran zavarták Önt a következő problémák?', 'hu',
jsonb_build_object(
  'lead_in_hu', 'Az elmúlt 2 hét során milyen gyakran zavarták Önt a következő problémák?',
  'lead_in_en', 'Over the last 2 weeks, how often have you been bothered by any of the following problems?',
  'scale', jsonb_build_array(
    jsonb_build_object('value',0,'hu','Egyáltalán nem','en','Not at all'),
    jsonb_build_object('value',1,'hu','Néhány napon','en','Several days'),
    jsonb_build_object('value',2,'hu','A napok több mint felében','en','More than half the days'),
    jsonb_build_object('value',3,'hu','Majdnem minden nap','en','Nearly every day')
  ),
  'questions', jsonb_build_array(
    jsonb_build_object('idx',1,'hu','Kevés érdeklődés vagy öröm a tevékenységekben','en','Little interest or pleasure in doing things'),
    jsonb_build_object('idx',2,'hu','Levertség, lehangoltság vagy reménytelenség érzése','en','Feeling down, depressed, or hopeless'),
    jsonb_build_object('idx',3,'hu','Elalvási vagy átalvási nehézség, vagy túl sok alvás','en','Trouble falling/staying asleep, or sleeping too much'),
    jsonb_build_object('idx',4,'hu','Fáradtság vagy kevés energia','en','Feeling tired or having little energy'),
    jsonb_build_object('idx',5,'hu','Étvágytalanság vagy túlevés','en','Poor appetite or overeating'),
    jsonb_build_object('idx',6,'hu','Rossz véleménnyel van önmagáról','en','Feeling bad about yourself / failure'),
    jsonb_build_object('idx',7,'hu','Koncentrálási nehézség','en','Trouble concentrating'),
    jsonb_build_object('idx',8,'hu','Olyan lassú mozgás/beszéd vagy szokatlan nyugtalanság','en','Moving/speaking slowly or restless'),
    jsonb_build_object('idx',9,'hu','Az a gondolat, hogy jobb lenne meghalni, vagy hogy kárt tenne magában','en','Thoughts of being better off dead or self-harm','critical',true)
  )
),
jsonb_build_object('type','sum','min',0,'max',27),
jsonb_build_object('bands', jsonb_build_array(
  jsonb_build_object('min',0,'max',4,'severity','minimalis'),
  jsonb_build_object('min',5,'max',9,'severity','enyhe'),
  jsonb_build_object('min',10,'max',14,'severity','kozepes'),
  jsonb_build_object('min',15,'max',19,'severity','kozepesen_sulyos'),
  jsonb_build_object('min',20,'max',27,'severity','sulyos')
), 'positive_cutoff', 10),
'free','klinikai', 9, 1, true, 3, true)
ON CONFLICT (code, language) WHERE tenant_id IS NULL DO UPDATE SET
  title=EXCLUDED.title, items=EXCLUDED.items, scoring=EXCLUDED.scoring, cutoffs=EXCLUDED.cutoffs,
  critical_item_index=EXCLUDED.critical_item_index, critical_threshold=EXCLUDED.critical_threshold,
  kioszk_eligible=EXCLUDED.kioszk_eligible, becsult_perc=EXCLUDED.becsult_perc, aktiv=EXCLUDED.aktiv;

-- GAD-7
INSERT INTO public.questionnaires (code, title, leiras, language, items, scoring, cutoffs, licenc, mode, kioszk_eligible, becsult_perc, aktiv)
VALUES ('GAD7', 'GAD-7 — Generalizált szorongás szűrő',
'Az elmúlt 2 hét során milyen gyakran zavarták Önt a következő problémák?', 'hu',
jsonb_build_object(
  'lead_in_hu','Az elmúlt 2 hét során milyen gyakran zavarták Önt a következő problémák?',
  'lead_in_en','Over the last 2 weeks, how often have you been bothered by the following problems?',
  'scale', jsonb_build_array(
    jsonb_build_object('value',0,'hu','Egyáltalán nem','en','Not at all'),
    jsonb_build_object('value',1,'hu','Néhány napon','en','Several days'),
    jsonb_build_object('value',2,'hu','A napok több mint felében','en','More than half the days'),
    jsonb_build_object('value',3,'hu','Majdnem minden nap','en','Nearly every day')
  ),
  'questions', jsonb_build_array(
    jsonb_build_object('idx',1,'hu','Idegesség, szorongás vagy feszültség érzése','en','Feeling nervous, anxious, or on edge'),
    jsonb_build_object('idx',2,'hu','Képtelenség abbahagyni vagy kontrollálni az aggódást','en','Not being able to stop or control worrying'),
    jsonb_build_object('idx',3,'hu','Túlzott aggódás különböző dolgok miatt','en','Worrying too much about different things'),
    jsonb_build_object('idx',4,'hu','Nehézség az ellazulásban','en','Trouble relaxing'),
    jsonb_build_object('idx',5,'hu','Olyan nyugtalanság, hogy nehéz nyugton maradni','en','Being so restless that it is hard to sit still'),
    jsonb_build_object('idx',6,'hu','Könnyen bosszússá vagy ingerlékennyé válás','en','Becoming easily annoyed or irritable'),
    jsonb_build_object('idx',7,'hu','Félelem, mintha valami szörnyűség történne','en','Feeling afraid as if something awful might happen')
  )
),
jsonb_build_object('type','sum','min',0,'max',21),
jsonb_build_object('bands', jsonb_build_array(
  jsonb_build_object('min',0,'max',4,'severity','minimalis'),
  jsonb_build_object('min',5,'max',9,'severity','enyhe'),
  jsonb_build_object('min',10,'max',14,'severity','kozepes'),
  jsonb_build_object('min',15,'max',21,'severity','sulyos')
), 'positive_cutoff', 10),
'free','klinikai', true, 3, true)
ON CONFLICT (code, language) WHERE tenant_id IS NULL DO UPDATE SET
  title=EXCLUDED.title, items=EXCLUDED.items, scoring=EXCLUDED.scoring, cutoffs=EXCLUDED.cutoffs,
  kioszk_eligible=EXCLUDED.kioszk_eligible, becsult_perc=EXCLUDED.becsult_perc, aktiv=EXCLUDED.aktiv;

-- PHQ-4
INSERT INTO public.questionnaires (code, title, leiras, language, items, scoring, cutoffs, licenc, mode, kioszk_eligible, becsult_perc, aktiv)
VALUES ('PHQ4', 'PHQ-4 — Ultrarövid distressz-szűrő',
'Az elmúlt 2 hét során milyen gyakran zavarták Önt a következő problémák?', 'hu',
jsonb_build_object(
  'lead_in_hu','Az elmúlt 2 hét során milyen gyakran zavarták Önt a következő problémák?',
  'scale', jsonb_build_array(
    jsonb_build_object('value',0,'hu','Egyáltalán nem','en','Not at all'),
    jsonb_build_object('value',1,'hu','Néhány napon','en','Several days'),
    jsonb_build_object('value',2,'hu','A napok több mint felében','en','More than half the days'),
    jsonb_build_object('value',3,'hu','Majdnem minden nap','en','Nearly every day')
  ),
  'questions', jsonb_build_array(
    jsonb_build_object('idx',1,'subscale','PHQ2','hu','Kevés érdeklődés vagy öröm a tevékenységekben','en','Little interest or pleasure'),
    jsonb_build_object('idx',2,'subscale','PHQ2','hu','Levertség, lehangoltság vagy reménytelenség','en','Feeling down, depressed, hopeless'),
    jsonb_build_object('idx',3,'subscale','GAD2','hu','Idegesség, szorongás vagy feszültség','en','Feeling nervous, anxious, on edge'),
    jsonb_build_object('idx',4,'subscale','GAD2','hu','Képtelenség abbahagyni vagy kontrollálni az aggódást','en','Not being able to control worrying')
  )
),
jsonb_build_object('type','sum_with_subscales','min',0,'max',12,
  'subscales', jsonb_build_array(
    jsonb_build_object('key','PHQ2','items', jsonb_build_array(1,2), 'positive_cutoff', 3),
    jsonb_build_object('key','GAD2','items', jsonb_build_array(3,4), 'positive_cutoff', 3)
  )
),
jsonb_build_object('bands', jsonb_build_array(
  jsonb_build_object('min',0,'max',2,'severity','normal'),
  jsonb_build_object('min',3,'max',5,'severity','enyhe'),
  jsonb_build_object('min',6,'max',8,'severity','kozepes'),
  jsonb_build_object('min',9,'max',12,'severity','sulyos')
)),
'free','klinikai', true, 1, true)
ON CONFLICT (code, language) WHERE tenant_id IS NULL DO UPDATE SET
  title=EXCLUDED.title, items=EXCLUDED.items, scoring=EXCLUDED.scoring, cutoffs=EXCLUDED.cutoffs,
  kioszk_eligible=EXCLUDED.kioszk_eligible, becsult_perc=EXCLUDED.becsult_perc, aktiv=EXCLUDED.aktiv;

-- AUDIT
INSERT INTO public.questionnaires (code, title, leiras, language, items, scoring, cutoffs, licenc, mode, kioszk_eligible, becsult_perc, aktiv)
VALUES ('AUDIT', 'AUDIT — Alkoholhasználat-zavar szűrő',
'Egység = standard ital ≈ 10 g tiszta alkohol.', 'hu',
jsonb_build_object('questions', jsonb_build_array(
  jsonb_build_object('idx',1,'hu','Milyen gyakran fogyaszt alkoholt?','en','How often do you have a drink?',
    'options', jsonb_build_array('Soha','Havonta vagy ritkábban','Havi 2–4×','Heti 2–3×','Heti 4+×'),'scores', jsonb_build_array(0,1,2,3,4)),
  jsonb_build_object('idx',2,'hu','Egy átlagos ivós napon hány egységet fogyaszt?','en','Standard drinks on a typical day?',
    'options', jsonb_build_array('1–2','3–4','5–6','7–9','10+'),'scores', jsonb_build_array(0,1,2,3,4)),
  jsonb_build_object('idx',3,'hu','Milyen gyakran fogyaszt 6+ egységet egy alkalommal?','en','Six or more drinks on one occasion?',
    'options', jsonb_build_array('Soha','Havonta ritkábban','Havonta','Hetente','Naponta vagy majdnem'),'scores', jsonb_build_array(0,1,2,3,4)),
  jsonb_build_object('idx',4,'hu','Milyen gyakran nem tudta abbahagyni az ivást, miután elkezdte?','en','Unable to stop once started?',
    'options', jsonb_build_array('Soha','Havonta ritkábban','Havonta','Hetente','Naponta vagy majdnem'),'scores', jsonb_build_array(0,1,2,3,4)),
  jsonb_build_object('idx',5,'hu','Milyen gyakran nem tudta megtenni, amit elvártak Öntől az ivás miatt?','en','Failed to do what was expected?',
    'options', jsonb_build_array('Soha','Havonta ritkábban','Havonta','Hetente','Naponta vagy majdnem'),'scores', jsonb_build_array(0,1,2,3,4)),
  jsonb_build_object('idx',6,'hu','Milyen gyakran volt szüksége reggeli italra, hogy beinduljon?','en','Needed a first drink in the morning?',
    'options', jsonb_build_array('Soha','Havonta ritkábban','Havonta','Hetente','Naponta vagy majdnem'),'scores', jsonb_build_array(0,1,2,3,4)),
  jsonb_build_object('idx',7,'hu','Milyen gyakran érzett bűntudatot ivás után?','en','Guilt or remorse after drinking?',
    'options', jsonb_build_array('Soha','Havonta ritkábban','Havonta','Hetente','Naponta vagy majdnem'),'scores', jsonb_build_array(0,1,2,3,4)),
  jsonb_build_object('idx',8,'hu','Milyen gyakran nem emlékezett az előző estére az ivás miatt?','en','Unable to remember the night before?',
    'options', jsonb_build_array('Soha','Havonta ritkábban','Havonta','Hetente','Naponta vagy majdnem'),'scores', jsonb_build_array(0,1,2,3,4)),
  jsonb_build_object('idx',9,'hu','Megsérült-e Ön vagy más az Ön ivása következtében?','en','Anyone been injured?',
    'options', jsonb_build_array('Nem','Igen, de nem az utóbbi évben','Igen, az utóbbi évben'),'scores', jsonb_build_array(0,2,4)),
  jsonb_build_object('idx',10,'hu','Aggódott-e hozzátartozó vagy orvos az ivása miatt?','en','Has anyone been concerned?',
    'options', jsonb_build_array('Nem','Igen, de nem az utóbbi évben','Igen, az utóbbi évben'),'scores', jsonb_build_array(0,2,4))
)),
jsonb_build_object('type','sum_per_item_scores','min',0,'max',40),
jsonb_build_object('bands', jsonb_build_array(
  jsonb_build_object('min',0,'max',7,'severity','alacsony_kockazat'),
  jsonb_build_object('min',8,'max',15,'severity','kockazatos'),
  jsonb_build_object('min',16,'max',19,'severity','artalmas'),
  jsonb_build_object('min',20,'max',40,'severity','fuggoseg_gyanu')
), 'positive_cutoff', 8),
'free','klinikai', false, 5, true)
ON CONFLICT (code, language) WHERE tenant_id IS NULL DO UPDATE SET
  title=EXCLUDED.title, items=EXCLUDED.items, scoring=EXCLUDED.scoring, cutoffs=EXCLUDED.cutoffs, aktiv=EXCLUDED.aktiv;

-- AUDIT-C
INSERT INTO public.questionnaires (code, title, leiras, language, items, scoring, cutoffs, licenc, mode, kioszk_eligible, becsult_perc, aktiv)
VALUES ('AUDITC', 'AUDIT-C — Rövid alkoholfogyasztási szűrő',
'AUDIT első három tétele; nemfüggő küszöb.', 'hu',
jsonb_build_object('questions', jsonb_build_array(
  jsonb_build_object('idx',1,'hu','Milyen gyakran fogyaszt alkoholt?','en','How often do you have a drink?',
    'options', jsonb_build_array('Soha','Havonta vagy ritkábban','Havi 2–4×','Heti 2–3×','Heti 4+×'),'scores', jsonb_build_array(0,1,2,3,4)),
  jsonb_build_object('idx',2,'hu','Egy átlagos ivós napon hány egységet fogyaszt?','en','Standard drinks on a typical day?',
    'options', jsonb_build_array('1–2','3–4','5–6','7–9','10+'),'scores', jsonb_build_array(0,1,2,3,4)),
  jsonb_build_object('idx',3,'hu','Milyen gyakran fogyaszt 6+ egységet egy alkalommal?','en','Six or more drinks on one occasion?',
    'options', jsonb_build_array('Soha','Havonta ritkábban','Havonta','Hetente','Naponta vagy majdnem'),'scores', jsonb_build_array(0,1,2,3,4))
)),
jsonb_build_object('type','sum_per_item_scores','min',0,'max',12),
jsonb_build_object('bands', jsonb_build_array(
  jsonb_build_object('min',0,'max',2,'severity','alacsony'),
  jsonb_build_object('min',3,'max',12,'severity','pozitiv')
), 'positive_cutoff_female', 3, 'positive_cutoff_male', 4),
'free','klinikai', true, 1, true)
ON CONFLICT (code, language) WHERE tenant_id IS NULL DO UPDATE SET
  title=EXCLUDED.title, items=EXCLUDED.items, scoring=EXCLUDED.scoring, cutoffs=EXCLUDED.cutoffs,
  kioszk_eligible=EXCLUDED.kioszk_eligible, aktiv=EXCLUDED.aktiv;

-- Fagerström
INSERT INTO public.questionnaires (code, title, leiras, language, items, scoring, cutoffs, licenc, mode, kioszk_eligible, becsult_perc, aktiv)
VALUES ('FAGERSTROM', 'Fagerström — Nikotinfüggőség (FTND)',
'Hat tételes nikotinfüggőség-teszt.', 'hu',
jsonb_build_object('questions', jsonb_build_array(
  jsonb_build_object('idx',1,'hu','Ébredés után milyen hamar gyújt rá az első cigarettára?','en','How soon after waking?',
    'options', jsonb_build_array('≤5 perc','6–30 perc','31–60 perc','>60 perc'),'scores', jsonb_build_array(3,2,1,0)),
  jsonb_build_object('idx',2,'hu','Nehéz tartózkodnia a dohányzástól ott, ahol tilos?','en','Hard to refrain where forbidden?',
    'options', jsonb_build_array('Igen','Nem'),'scores', jsonb_build_array(1,0)),
  jsonb_build_object('idx',3,'hu','Melyik cigarettáról mondana le a legnehezebben?','en','Hardest to give up?',
    'options', jsonb_build_array('Az első reggeli','Bármely más'),'scores', jsonb_build_array(1,0)),
  jsonb_build_object('idx',4,'hu','Naponta hány szálat szív?','en','How many per day?',
    'options', jsonb_build_array('≤10','11–20','21–30','31+'),'scores', jsonb_build_array(0,1,2,3)),
  jsonb_build_object('idx',5,'hu','Gyakrabban dohányzik az ébredés utáni első órákban?','en','Smoke more in first hours?',
    'options', jsonb_build_array('Igen','Nem'),'scores', jsonb_build_array(1,0)),
  jsonb_build_object('idx',6,'hu','Akkor is dohányzik, ha betegen ágyban fekszik?','en','Smoke even when ill in bed?',
    'options', jsonb_build_array('Igen','Nem'),'scores', jsonb_build_array(1,0))
)),
jsonb_build_object('type','sum_per_item_scores','min',0,'max',10),
jsonb_build_object('bands', jsonb_build_array(
  jsonb_build_object('min',0,'max',2,'severity','nagyon_alacsony'),
  jsonb_build_object('min',3,'max',4,'severity','alacsony'),
  jsonb_build_object('min',5,'max',5,'severity','kozepes'),
  jsonb_build_object('min',6,'max',7,'severity','magas'),
  jsonb_build_object('min',8,'max',10,'severity','nagyon_magas')
)),
'free','egeszsegfejlesztesi', false, 3, true)
ON CONFLICT (code, language) WHERE tenant_id IS NULL DO UPDATE SET
  title=EXCLUDED.title, items=EXCLUDED.items, scoring=EXCLUDED.scoring, cutoffs=EXCLUDED.cutoffs, aktiv=EXCLUDED.aktiv;

-- WHO-5
INSERT INTO public.questionnaires (code, title, leiras, language, items, scoring, cutoffs, licenc, mode, kioszk_eligible, becsult_perc, aktiv)
VALUES ('WHO5', 'WHO-5 — Jóllét index',
'CC BY-NC-SA 3.0 IGO — kereskedelmi használathoz WHO-engedély kötelező.', 'hu',
jsonb_build_object(
  'lead_in_hu','Az alábbi öt állítás az elmúlt két hét közérzetére vonatkozik.',
  'scale', jsonb_build_array(
    jsonb_build_object('value',5,'hu','Mindig'),
    jsonb_build_object('value',4,'hu','Az idő nagy részében'),
    jsonb_build_object('value',3,'hu','Az idő több mint felében'),
    jsonb_build_object('value',2,'hu','Az idő kevesebb mint felében'),
    jsonb_build_object('value',1,'hu','Néha'),
    jsonb_build_object('value',0,'hu','Soha')
  ),
  'questions', jsonb_build_array(
    jsonb_build_object('idx',1,'hu','Vidámnak és jókedvűnek éreztem magam'),
    jsonb_build_object('idx',2,'hu','Nyugodtnak és ellazultnak éreztem magam'),
    jsonb_build_object('idx',3,'hu','Aktívnak és energikusnak éreztem magam'),
    jsonb_build_object('idx',4,'hu','Frissen és kipihenten ébredtem'),
    jsonb_build_object('idx',5,'hu','A mindennapjaim tele voltak számomra érdekes dolgokkal')
  )
),
jsonb_build_object('type','sum_times_four','min',0,'max',100),
jsonb_build_object('bands', jsonb_build_array(
  jsonb_build_object('min',0,'max',28,'severity','valoszinu_depresszio'),
  jsonb_build_object('min',29,'max',50,'severity','alacsony_jollet'),
  jsonb_build_object('min',51,'max',100,'severity','normalis_jollet')
), 'low_wellbeing_cutoff', 50, 'probable_depression_cutoff', 28),
'who_noncommercial','egeszsegfejlesztesi', false, 2, false)
ON CONFLICT (code, language) WHERE tenant_id IS NULL DO UPDATE SET
  title=EXCLUDED.title, leiras=EXCLUDED.leiras, items=EXCLUDED.items, scoring=EXCLUDED.scoring,
  cutoffs=EXCLUDED.cutoffs, licenc=EXCLUDED.licenc, aktiv=EXCLUDED.aktiv;

-- CG-CAHPS
INSERT INTO public.questionnaires (code, title, leiras, language, items, scoring, cutoffs, licenc, mode, kioszk_eligible, becsult_perc, aktiv)
VALUES ('CGCAHPS', 'Betegelégedettség — CG-CAHPS adaptált',
'Vizit utáni minőségbiztosítási felmérés.', 'hu',
jsonb_build_object('sections', jsonb_build_array(
  jsonb_build_object('key','hozzaferes','title','Hozzáférés / szervezés','items', jsonb_build_array(
    jsonb_build_object('idx',1,'hu','Az időpontot a kívánt időben kapta meg?',
      'options', jsonb_build_array('Soha','Néha','Általában','Mindig')),
    jsonb_build_object('idx',2,'hu','A telefonos vagy online ügyintézés gördülékeny volt?',
      'options', jsonb_build_array('Soha','Néha','Általában','Mindig')),
    jsonb_build_object('idx',3,'hu','Mennyi ideig várt a megbeszélt időponton túl?',
      'options', jsonb_build_array('<15 perc','15–30 perc','30–60 perc','>60 perc'))
  )),
  jsonb_build_object('key','kommunikacio','title','Orvos-beteg kommunikáció','items', jsonb_build_array(
    jsonb_build_object('idx',4,'hu','Az orvos érthetően magyarázott?', 'options', jsonb_build_array('Soha','Néha','Általában','Mindig')),
    jsonb_build_object('idx',5,'hu','Az orvos figyelmesen meghallgatta Önt?', 'options', jsonb_build_array('Soha','Néha','Általában','Mindig')),
    jsonb_build_object('idx',6,'hu','Az orvos tiszteletben tartotta a véleményét?', 'options', jsonb_build_array('Soha','Néha','Általában','Mindig')),
    jsonb_build_object('idx',7,'hu','Az orvos elegendő időt szánt Önre?', 'options', jsonb_build_array('Soha','Néha','Általában','Mindig')),
    jsonb_build_object('idx',8,'hu','A személyzet udvarias és segítőkész volt?', 'options', jsonb_build_array('Soha','Néha','Általában','Mindig'))
  )),
  jsonb_build_object('key','globalis','title','Globális értékelés','items', jsonb_build_array(
    jsonb_build_object('idx',9,'hu','Összességében hogyan értékeli ezt az orvost/rendelőt?','type','scale_0_10'),
    jsonb_build_object('idx',10,'hu','Ajánlaná ezt a rendelőt másnak?',
      'options', jsonb_build_array('Biztosan nem','Valószínűleg nem','Valószínűleg igen','Biztosan igen'))
  )),
  jsonb_build_object('key','szoveges','title','Szöveges visszajelzés','items', jsonb_build_array(
    jsonb_build_object('idx',11,'hu','Egyéb észrevétel (opcionális)','type','text_open')
  ))
)),
jsonb_build_object('type','top_box_per_domain'),
jsonb_build_object('top_box','Mindig'),
'public_domain','vegyes', true, 5, true)
ON CONFLICT (code, language) WHERE tenant_id IS NULL DO UPDATE SET
  title=EXCLUDED.title, items=EXCLUDED.items, scoring=EXCLUDED.scoring,
  cutoffs=EXCLUDED.cutoffs, kioszk_eligible=EXCLUDED.kioszk_eligible, aktiv=EXCLUDED.aktiv;

-- NPS
INSERT INTO public.questionnaires (code, title, leiras, language, items, scoring, cutoffs, licenc, mode, kioszk_eligible, becsult_perc, aktiv)
VALUES ('NPS', 'NPS — Net Promoter Score',
'Másodlagos trendmutató; nem elsődleges minőségmérce.', 'hu',
jsonb_build_object('questions', jsonb_build_array(
  jsonb_build_object('idx',1,'hu','Mennyire valószínű, hogy ajánlana minket egy barátnak vagy családtagnak?','type','scale_0_10'),
  jsonb_build_object('idx',2,'hu','Mi a fő oka az értékelésének? (opcionális)','type','text_open')
)),
jsonb_build_object('type','nps_single','min',0,'max',10),
jsonb_build_object('buckets', jsonb_build_array(
  jsonb_build_object('min',0,'max',6,'label','detractor'),
  jsonb_build_object('min',7,'max',8,'label','passive'),
  jsonb_build_object('min',9,'max',10,'label','promoter')
)),
'free','vegyes', true, 1, true)
ON CONFLICT (code, language) WHERE tenant_id IS NULL DO UPDATE SET
  title=EXCLUDED.title, items=EXCLUDED.items, scoring=EXCLUDED.scoring,
  cutoffs=EXCLUDED.cutoffs, kioszk_eligible=EXCLUDED.kioszk_eligible, aktiv=EXCLUDED.aktiv;


-- ─── 20260619143902_0159ac21-6e25-4890-ac03-0c2039fa0277.sql ───
CREATE UNIQUE INDEX IF NOT EXISTS uq_staff_roles_global_kulcs
  ON public.staff_roles (kulcs) WHERE tenant_id IS NULL;

-- ─── 20260619214953_7caa67f2-cddc-42cb-b84a-346a808d9349.sql ───

-- 1) Alskála-pontszámok perzisztálása
ALTER TABLE public.questionnaire_responses
  ADD COLUMN IF NOT EXISTS subscale_scores jsonb NOT NULL DEFAULT '{}'::jsonb;

CREATE INDEX IF NOT EXISTS idx_qr_subscale_scores
  ON public.questionnaire_responses USING gin (subscale_scores);

CREATE INDEX IF NOT EXISTS idx_qr_patient_created
  ON public.questionnaire_responses (patient_id, created_at DESC);

-- 2) Bővített automatikus alert-trigger: bucket-küszöbök minden szabad licencű skálához.
CREATE OR REPLACE FUNCTION public.qr_critical_alert_fn()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
  v_code text;
  v_title text;
  v_sex text;
  v_auditc_cutoff numeric;
  v_phq2 numeric;
  v_gad2 numeric;
  v_who5_index numeric;
  v_alert_type text;
  v_severity text;
BEGIN
  SELECT code, title INTO v_code, v_title FROM public.questionnaires WHERE id = NEW.questionnaire_id;

  -- PHQ-9 #9 (öngyilkossági gondolat) — meglévő logika megtartva
  IF NEW.critical_triggered THEN
    INSERT INTO public.critical_result_alerts (tenant_id, response_id, patient_id, appointment_id, alert_type, severity)
    VALUES (NEW.tenant_id, NEW.id, NEW.patient_id, NEW.appointment_id,
            CASE WHEN v_code = 'PHQ9' THEN 'suicidal_ideation' ELSE 'critical_screening' END,
            COALESCE(NEW.severity, 'severe'));
  END IF;

  -- PHQ-9 közepes+ (≥10) — klinikus felülvizsgálat
  IF v_code = 'PHQ9' AND NEW.total_score IS NOT NULL AND NEW.total_score >= 10 THEN
    INSERT INTO public.critical_result_alerts (tenant_id, response_id, patient_id, appointment_id, alert_type, severity)
    VALUES (NEW.tenant_id, NEW.id, NEW.patient_id, NEW.appointment_id,
            'depresszio_kozepes_plus',
            CASE WHEN NEW.total_score >= 20 THEN 'high'
                 WHEN NEW.total_score >= 15 THEN 'medium'
                 ELSE 'low' END);
  END IF;

  -- GAD-7 súlyos (≥15)
  IF v_code = 'GAD7' AND NEW.total_score IS NOT NULL AND NEW.total_score >= 15 THEN
    INSERT INTO public.critical_result_alerts (tenant_id, response_id, patient_id, appointment_id, alert_type, severity)
    VALUES (NEW.tenant_id, NEW.id, NEW.patient_id, NEW.appointment_id,
            'szorongas_sulyos', 'high');
  END IF;

  -- PHQ-4 alskálák ≥3 → "follow-up javasolt"
  IF v_code = 'PHQ4' THEN
    v_phq2 := COALESCE((NEW.subscale_scores->>'phq2')::numeric, NULL);
    v_gad2 := COALESCE((NEW.subscale_scores->>'gad2')::numeric, NULL);
    IF v_phq2 IS NOT NULL AND v_phq2 >= 3 THEN
      INSERT INTO public.critical_result_alerts (tenant_id, response_id, patient_id, appointment_id, alert_type, severity)
      VALUES (NEW.tenant_id, NEW.id, NEW.patient_id, NEW.appointment_id, 'phq2_pozitiv', 'low');
    END IF;
    IF v_gad2 IS NOT NULL AND v_gad2 >= 3 THEN
      INSERT INTO public.critical_result_alerts (tenant_id, response_id, patient_id, appointment_id, alert_type, severity)
      VALUES (NEW.tenant_id, NEW.id, NEW.patient_id, NEW.appointment_id, 'gad2_pozitiv', 'low');
    END IF;
  END IF;

  -- WHO-5 index < 50 → jóllét-csökkenés
  IF v_code = 'WHO5' THEN
    v_who5_index := COALESCE((NEW.subscale_scores->>'who5_index')::numeric, NEW.total_score);
    IF v_who5_index IS NOT NULL AND v_who5_index < 50 THEN
      INSERT INTO public.critical_result_alerts (tenant_id, response_id, patient_id, appointment_id, alert_type, severity)
      VALUES (NEW.tenant_id, NEW.id, NEW.patient_id, NEW.appointment_id,
              'jollet_csokkent',
              CASE WHEN v_who5_index < 28 THEN 'medium' ELSE 'low' END);
    END IF;
  END IF;

  -- AUDIT-C pozitív (nemi küszöb a pácienstől: férfi 4, nő 3, ismeretlen 4)
  IF v_code = 'AUDITC' AND NEW.total_score IS NOT NULL AND NEW.patient_id IS NOT NULL THEN
    SELECT lower(nem) INTO v_sex FROM public.patients WHERE id = NEW.patient_id;
    v_auditc_cutoff := CASE WHEN v_sex IN ('no','nő','female','f') THEN 3 ELSE 4 END;
    IF NEW.total_score >= v_auditc_cutoff THEN
      INSERT INTO public.critical_result_alerts (tenant_id, response_id, patient_id, appointment_id, alert_type, severity)
      VALUES (NEW.tenant_id, NEW.id, NEW.patient_id, NEW.appointment_id,
              'auditc_pozitiv',
              CASE WHEN NEW.total_score >= 8 THEN 'medium' ELSE 'low' END);
    END IF;
  END IF;

  -- AUDIT teljes ≥16 (káros ivás) / ≥20 (függőség gyanú)
  IF v_code = 'AUDIT' AND NEW.total_score IS NOT NULL THEN
    IF NEW.total_score >= 20 THEN
      INSERT INTO public.critical_result_alerts (tenant_id, response_id, patient_id, appointment_id, alert_type, severity)
      VALUES (NEW.tenant_id, NEW.id, NEW.patient_id, NEW.appointment_id, 'audit_fuggoseg_gyanu', 'high');
    ELSIF NEW.total_score >= 16 THEN
      INSERT INTO public.critical_result_alerts (tenant_id, response_id, patient_id, appointment_id, alert_type, severity)
      VALUES (NEW.tenant_id, NEW.id, NEW.patient_id, NEW.appointment_id, 'audit_karos_ivas', 'medium');
    END IF;
  END IF;

  RETURN NEW;
END
$function$;


-- ─── 20260619215403_74b9592e-2643-4be1-b537-8ffc1f5f5043.sql ───

ALTER TABLE public.questionnaire_assignments
  ADD COLUMN IF NOT EXISTS reminded_at timestamptz,
  ADD COLUMN IF NOT EXISTS reminder_count integer NOT NULL DEFAULT 0;

CREATE INDEX IF NOT EXISTS idx_qa_status_due
  ON public.questionnaire_assignments (tenant_id, status, due_at);
CREATE INDEX IF NOT EXISTS idx_qa_patient_status
  ON public.questionnaire_assignments (patient_id, status);

CREATE OR REPLACE FUNCTION public.process_questionnaire_schedules()
RETURNS TABLE(schedule_id uuid, created_count integer)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
  v_sched record;
  v_patient_id uuid;
  v_created integer;
BEGIN
  FOR v_sched IN
    SELECT * FROM public.questionnaire_schedules
    WHERE aktiv = true
      AND (next_due_at IS NULL OR next_due_at <= now())
  LOOP
    v_created := 0;

    IF v_sched.scope = 'patient' AND v_sched.patient_id IS NOT NULL THEN
      INSERT INTO public.questionnaire_assignments
        (tenant_id, questionnaire_id, patient_id, kind, status, due_at, token)
      SELECT v_sched.tenant_id, v_sched.questionnaire_id, v_sched.patient_id,
             'periodikus', 'assigned',
             COALESCE(v_sched.next_due_at, now()) + interval '7 days',
             encode(gen_random_bytes(16), 'hex')
      WHERE NOT EXISTS (
        SELECT 1 FROM public.questionnaire_assignments qa
        WHERE qa.patient_id = v_sched.patient_id
          AND qa.questionnaire_id = v_sched.questionnaire_id
          AND qa.kind = 'periodikus'
          AND qa.status IN ('assigned','in_progress')
      );
      GET DIAGNOSTICS v_created = ROW_COUNT;

    ELSIF v_sched.scope = 'program' AND v_sched.monitoring_program_id IS NOT NULL THEN
      FOR v_patient_id IN
        SELECT mp.patient_id FROM public.monitoring_programs mp
        WHERE mp.id = v_sched.monitoring_program_id AND mp.aktiv = true
      LOOP
        INSERT INTO public.questionnaire_assignments
          (tenant_id, questionnaire_id, patient_id, kind, status, due_at, token)
        SELECT v_sched.tenant_id, v_sched.questionnaire_id, v_patient_id,
               'periodikus', 'assigned',
               COALESCE(v_sched.next_due_at, now()) + interval '7 days',
               encode(gen_random_bytes(16), 'hex')
        WHERE NOT EXISTS (
          SELECT 1 FROM public.questionnaire_assignments qa
          WHERE qa.patient_id = v_patient_id
            AND qa.questionnaire_id = v_sched.questionnaire_id
            AND qa.kind = 'periodikus'
            AND qa.status IN ('assigned','in_progress')
        );
        IF FOUND THEN v_created := v_created + 1; END IF;
      END LOOP;
    END IF;

    UPDATE public.questionnaire_schedules
      SET last_run_at = now(),
          next_due_at = COALESCE(next_due_at, now()) + (interval_days || ' days')::interval
      WHERE id = v_sched.id;

    schedule_id := v_sched.id;
    created_count := v_created;
    RETURN NEXT;
  END LOOP;

  RETURN;
END
$function$;

CREATE OR REPLACE FUNCTION public.expire_overdue_questionnaire_assignments()
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
  v_count integer;
BEGIN
  WITH expired AS (
    UPDATE public.questionnaire_assignments
       SET status = 'expired'
     WHERE status IN ('assigned','in_progress')
       AND due_at IS NOT NULL
       AND due_at < now() - interval '7 days'
    RETURNING tenant_id, patient_id, questionnaire_id
  )
  INSERT INTO public.notifications (tenant_id, user_id, tipus, cim, uzenet, link)
  SELECT e.tenant_id, p.felelos_user_id, 'kerdoiv',
         'Kitöltetlen kérdőív lejárt',
         'A páciens nem töltötte ki a kiosztott kérdőívet a határidőre.',
         '/kerdoivek'
  FROM expired e
  JOIN public.patients p ON p.id = e.patient_id
  WHERE p.felelos_user_id IS NOT NULL;

  GET DIAGNOSTICS v_count = ROW_COUNT;
  RETURN COALESCE(v_count, 0);
END
$function$;

CREATE OR REPLACE FUNCTION public.send_questionnaire_reminders()
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
  v_count integer := 0;
  v_rec record;
BEGIN
  FOR v_rec IN
    SELECT qa.id, qa.tenant_id, qa.patient_id, qa.questionnaire_id, qa.due_at,
           p.felelos_user_id, q.title
    FROM public.questionnaire_assignments qa
    JOIN public.questionnaires q ON q.id = qa.questionnaire_id
    LEFT JOIN public.patients p ON p.id = qa.patient_id
    WHERE qa.status IN ('assigned','in_progress')
      AND qa.due_at IS NOT NULL
      AND qa.due_at <= now() + interval '1 day'
      AND qa.reminder_count < 3
      AND (qa.reminded_at IS NULL OR qa.reminded_at < now() - interval '3 days')
  LOOP
    IF v_rec.felelos_user_id IS NOT NULL THEN
      INSERT INTO public.notifications (tenant_id, user_id, tipus, cim, uzenet, link)
      VALUES (v_rec.tenant_id, v_rec.felelos_user_id, 'kerdoiv',
              'Esedékes kérdőív emlékeztető',
              format('A(z) "%s" kérdőív kitöltése esedékes (határidő: %s).',
                     v_rec.title,
                     to_char(v_rec.due_at AT TIME ZONE 'Europe/Budapest','YYYY-MM-DD')),
              '/kerdoivek');
    END IF;

    UPDATE public.questionnaire_assignments
       SET reminded_at = now(),
           reminder_count = reminder_count + 1
     WHERE id = v_rec.id;
    v_count := v_count + 1;
  END LOOP;
  RETURN v_count;
END
$function$;

REVOKE EXECUTE ON FUNCTION public.process_questionnaire_schedules() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.expire_overdue_questionnaire_assignments() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.send_questionnaire_reminders() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.process_questionnaire_schedules() TO service_role;
GRANT EXECUTE ON FUNCTION public.expire_overdue_questionnaire_assignments() TO service_role;
GRANT EXECUTE ON FUNCTION public.send_questionnaire_reminders() TO service_role;


-- ─── 20260619215934_7892070b-473c-47b5-954d-e53648fdcc1d.sql ───

CREATE TABLE public.i18n_translations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  namespace text NOT NULL,
  key text NOT NULL,
  source_text text NOT NULL,
  lang text NOT NULL CHECK (lang IN ('en','hu','ro','sr','zh','fil','de','uk','ru')),
  value text NOT NULL,
  source_hash text NOT NULL,
  edited_by_user boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, namespace, key, lang)
);

CREATE INDEX idx_i18n_ns_key ON public.i18n_translations(tenant_id, namespace, key);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.i18n_translations TO authenticated;
GRANT ALL ON public.i18n_translations TO service_role;

ALTER TABLE public.i18n_translations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "tenant members read i18n"
  ON public.i18n_translations FOR SELECT TO authenticated
  USING (
    tenant_id IS NULL OR tenant_id IN (
      SELECT tenant_id FROM public.profiles WHERE id = auth.uid()
    )
  );

CREATE POLICY "tenant members write i18n"
  ON public.i18n_translations FOR ALL TO authenticated
  USING (
    tenant_id IS NULL OR tenant_id IN (
      SELECT tenant_id FROM public.profiles WHERE id = auth.uid()
    )
  )
  WITH CHECK (
    tenant_id IS NULL OR tenant_id IN (
      SELECT tenant_id FROM public.profiles WHERE id = auth.uid()
    )
  );

CREATE OR REPLACE FUNCTION public.i18n_set_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_i18n_updated_at
  BEFORE UPDATE ON public.i18n_translations
  FOR EACH ROW EXECUTE FUNCTION public.i18n_set_updated_at();


-- ─── 20260619221926_26082489-faf5-4324-a198-36de66e649d4.sql ───
-- Kioszk kitöltés: autosave + resume + PIN-zár
CREATE EXTENSION IF NOT EXISTS pgcrypto;

ALTER TABLE public.questionnaire_assignments
  ADD COLUMN IF NOT EXISTS draft_answers jsonb,
  ADD COLUMN IF NOT EXISTS draft_saved_at timestamptz,
  ADD COLUMN IF NOT EXISTS kiosk_pin_hash text,
  ADD COLUMN IF NOT EXISTS last_activity_at timestamptz;

-- PIN-hash trigger: a páciens születési dátumának DDMM része; hash = sha256(token || pin)
CREATE OR REPLACE FUNCTION public.set_kiosk_pin_hash()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_birth date;
  v_pin text;
BEGIN
  IF NEW.patient_id IS NULL THEN
    RETURN NEW;
  END IF;
  SELECT szuletesi_datum INTO v_birth FROM public.patients WHERE id = NEW.patient_id;
  IF v_birth IS NULL THEN
    RETURN NEW;
  END IF;
  v_pin := to_char(v_birth, 'DDMM');
  NEW.kiosk_pin_hash := encode(digest(NEW.token || ':' || v_pin, 'sha256'), 'hex');
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_set_kiosk_pin_hash ON public.questionnaire_assignments;
CREATE TRIGGER trg_set_kiosk_pin_hash
  BEFORE INSERT ON public.questionnaire_assignments
  FOR EACH ROW EXECUTE FUNCTION public.set_kiosk_pin_hash();

-- Backfill meglévő assignmentekre
UPDATE public.questionnaire_assignments qa
   SET kiosk_pin_hash = encode(digest(qa.token || ':' || to_char(p.szuletesi_datum, 'DDMM'), 'sha256'), 'hex')
  FROM public.patients p
 WHERE qa.patient_id = p.id
   AND p.szuletesi_datum IS NOT NULL
   AND qa.kiosk_pin_hash IS NULL;

-- Belső segéd: token + PIN ellenőrzése, visszaadja az assignment-et (vagy NULL)
CREATE OR REPLACE FUNCTION public.kiosk_verify(_token text, _pin text)
RETURNS public.questionnaire_assignments
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_row public.questionnaire_assignments%ROWTYPE;
  v_expected text;
BEGIN
  SELECT * INTO v_row FROM public.questionnaire_assignments WHERE token = _token;
  IF NOT FOUND THEN RETURN NULL; END IF;
  IF v_row.kiosk_pin_hash IS NULL THEN
    RETURN v_row; -- anonim assignmenthez nincs PIN
  END IF;
  v_expected := encode(digest(_token || ':' || COALESCE(_pin, ''), 'sha256'), 'hex');
  IF v_expected = v_row.kiosk_pin_hash THEN
    RETURN v_row;
  END IF;
  RETURN NULL;
END;
$$;

-- Betöltés: assignment + questionnaire + páciens név + draft
CREATE OR REPLACE FUNCTION public.kiosk_load(_token text, _pin text)
RETURNS jsonb
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_asg public.questionnaire_assignments%ROWTYPE;
  v_q public.questionnaires%ROWTYPE;
  v_p record;
BEGIN
  v_asg := public.kiosk_verify(_token, _pin);
  IF v_asg.id IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'invalid_token_or_pin');
  END IF;
  IF v_asg.status NOT IN ('assigned','in_progress') THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'not_open', 'status', v_asg.status);
  END IF;

  SELECT * INTO v_q FROM public.questionnaires WHERE id = v_asg.questionnaire_id;

  SELECT vezeteknev, keresztnev INTO v_p
    FROM public.patients WHERE id = v_asg.patient_id;

  RETURN jsonb_build_object(
    'ok', true,
    'assignment', jsonb_build_object(
      'id', v_asg.id,
      'status', v_asg.status,
      'due_at', v_asg.due_at,
      'draft_answers', v_asg.draft_answers,
      'draft_saved_at', v_asg.draft_saved_at,
      'requires_pin', v_asg.kiosk_pin_hash IS NOT NULL
    ),
    'questionnaire', jsonb_build_object(
      'id', v_q.id, 'code', v_q.code, 'title', v_q.title, 'leiras', v_q.leiras,
      'language', v_q.language, 'items', v_q.items, 'becsult_perc', v_q.becsult_perc
    ),
    'patient_name', COALESCE(v_p.vezeteknev || ' ' || v_p.keresztnev, NULL)
  );
END;
$$;

-- Autosave: csak draft + last_activity_at frissítés, státusz in_progress-re vált
CREATE OR REPLACE FUNCTION public.kiosk_autosave(_token text, _pin text, _answers jsonb)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_asg public.questionnaire_assignments%ROWTYPE;
BEGIN
  v_asg := public.kiosk_verify(_token, _pin);
  IF v_asg.id IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'invalid_token_or_pin');
  END IF;
  IF v_asg.status NOT IN ('assigned','in_progress') THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'not_open');
  END IF;

  UPDATE public.questionnaire_assignments
     SET draft_answers = _answers,
         draft_saved_at = now(),
         last_activity_at = now(),
         status = CASE WHEN status = 'assigned' THEN 'in_progress'::questionnaire_assignment_status ELSE status END
   WHERE id = v_asg.id;

  RETURN jsonb_build_object('ok', true, 'saved_at', now());
END;
$$;

-- Submit: a server fn-nek kell scorolnia, majd ezt hívja az insert-hez.
-- Beilleszti a questionnaire_responses sort és lezárja az assignmentet.
CREATE OR REPLACE FUNCTION public.kiosk_submit_response(
  _token text, _pin text, _answers jsonb,
  _total_score numeric, _severity text, _subscale_scores jsonb,
  _critical_triggered boolean
) RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_asg public.questionnaire_assignments%ROWTYPE;
  v_response_id uuid;
BEGIN
  v_asg := public.kiosk_verify(_token, _pin);
  IF v_asg.id IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'invalid_token_or_pin');
  END IF;
  IF v_asg.status = 'completed' THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'already_completed');
  END IF;

  INSERT INTO public.questionnaire_responses (
    tenant_id, questionnaire_id, assignment_id, patient_id, appointment_id,
    answers, total_score, severity, subscale_scores, critical_triggered,
    is_anonymous, consent_to_record
  ) VALUES (
    v_asg.tenant_id, v_asg.questionnaire_id, v_asg.id, v_asg.patient_id, v_asg.appointment_id,
    _answers, _total_score, _severity, _subscale_scores, COALESCE(_critical_triggered, false),
    false, true
  ) RETURNING id INTO v_response_id;

  UPDATE public.questionnaire_assignments
     SET status = 'completed',
         draft_answers = NULL,
         last_activity_at = now()
   WHERE id = v_asg.id;

  RETURN jsonb_build_object('ok', true, 'response_id', v_response_id, 'critical_triggered', COALESCE(_critical_triggered, false));
END;
$$;

GRANT EXECUTE ON FUNCTION public.kiosk_load(text, text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.kiosk_autosave(text, text, jsonb) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.kiosk_submit_response(text, text, jsonb, numeric, text, jsonb, boolean) TO anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.kiosk_verify(text, text) FROM PUBLIC;

-- ─── 20260619222658_e3cd285c-1c1a-44f4-9bda-29e8b10969ec.sql ───

DO $$ BEGIN
  CREATE TYPE public.kiosk_print_status AS ENUM ('not_printed', 'printed', 'cancelled');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

ALTER TABLE public.questionnaire_assignments
  ADD COLUMN IF NOT EXISTS print_status public.kiosk_print_status NOT NULL DEFAULT 'not_printed',
  ADD COLUMN IF NOT EXISTS printed_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS printed_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS print_cancelled_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS print_cancelled_by UUID REFERENCES auth.users(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS questionnaire_assignments_print_status_idx
  ON public.questionnaire_assignments (print_status);


-- ─── 20260619223826_be2b162c-6209-4cc4-8c4c-d1983faadd16.sql ───

/* ===== 1. ENUMs ===== */
DO $$ BEGIN
  CREATE TYPE public.qet_event_type AS ENUM (
    'appointment_created',
    'appointment_scheduled',
    'surgery_created',
    'surgery_scheduled'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.reminder_channel AS ENUM ('notification', 'push', 'email', 'sms');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

/* ===== 2. questionnaire_event_triggers ===== */
CREATE TABLE IF NOT EXISTS public.questionnaire_event_triggers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  questionnaire_id UUID NOT NULL REFERENCES public.questionnaires(id) ON DELETE CASCADE,
  event_type public.qet_event_type NOT NULL,
  /* Esedékesség az esemény előtt (pozitív szám = előtte annyi nappal). */
  due_offset_days INTEGER NOT NULL DEFAULT 0,
  /* Bucketek napokban, pl. {-7,-3,-1,1,3,7}: negatív = esedékesség előtt, pozitív = után */
  reminder_buckets INTEGER[] NOT NULL DEFAULT ARRAY[-7,-3,-1,1,3,7],
  channel public.reminder_channel NOT NULL DEFAULT 'notification',
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, questionnaire_id, event_type)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.questionnaire_event_triggers TO authenticated;
GRANT ALL ON public.questionnaire_event_triggers TO service_role;
ALTER TABLE public.questionnaire_event_triggers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "qet_select" ON public.questionnaire_event_triggers
  FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_tenant'));

CREATE POLICY "qet_write" ON public.questionnaire_event_triggers
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_tenant'))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_tenant'));

CREATE TRIGGER trg_qet_touch BEFORE UPDATE ON public.questionnaire_event_triggers
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE INDEX IF NOT EXISTS qet_lookup_idx
  ON public.questionnaire_event_triggers (tenant_id, event_type) WHERE active;

/* ===== 3. assignment_reminder_log ===== */
CREATE TABLE IF NOT EXISTS public.assignment_reminder_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  assignment_id UUID NOT NULL REFERENCES public.questionnaire_assignments(id) ON DELETE CASCADE,
  /* Bucket napokban (negatív = előtte, pozitív = utána). */
  bucket_days INTEGER NOT NULL,
  channel public.reminder_channel NOT NULL DEFAULT 'notification',
  sent_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  notes TEXT,
  UNIQUE (assignment_id, bucket_days, channel)
);

GRANT SELECT ON public.assignment_reminder_log TO authenticated;
GRANT ALL ON public.assignment_reminder_log TO service_role;
ALTER TABLE public.assignment_reminder_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "arl_select" ON public.assignment_reminder_log
  FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_tenant'));

CREATE INDEX IF NOT EXISTS arl_assignment_idx ON public.assignment_reminder_log (assignment_id);

/* ===== 4. Auto-assignment helper ===== */
CREATE OR REPLACE FUNCTION public.auto_assign_from_event(
  _tenant_id UUID,
  _event_type public.qet_event_type,
  _patient_id UUID,
  _event_at TIMESTAMPTZ,
  _appointment_id UUID DEFAULT NULL
) RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_count INTEGER := 0;
  v_trig RECORD;
  v_due TIMESTAMPTZ;
  v_token TEXT;
BEGIN
  IF _patient_id IS NULL THEN RETURN 0; END IF;

  FOR v_trig IN
    SELECT id, questionnaire_id, due_offset_days
      FROM public.questionnaire_event_triggers
     WHERE tenant_id = _tenant_id
       AND event_type = _event_type
       AND active
  LOOP
    /* Ne dupla-rendeljünk ugyanahhoz a forrás eseményhez. */
    IF EXISTS (
      SELECT 1 FROM public.questionnaire_assignments qa
       WHERE qa.tenant_id = _tenant_id
         AND qa.patient_id = _patient_id
         AND qa.questionnaire_id = v_trig.questionnaire_id
         AND qa.status IN ('assigned', 'in_progress')
         AND ( _appointment_id IS NULL OR qa.appointment_id = _appointment_id )
    ) THEN CONTINUE; END IF;

    v_due := CASE
      WHEN _event_at IS NULL THEN now() + (v_trig.due_offset_days || ' days')::interval
      ELSE _event_at - (v_trig.due_offset_days || ' days')::interval
    END;

    v_token := encode(gen_random_bytes(16), 'hex');

    INSERT INTO public.questionnaire_assignments
      (tenant_id, questionnaire_id, patient_id, appointment_id, due_at, kind, status, token)
    VALUES
      (_tenant_id, v_trig.questionnaire_id, _patient_id, _appointment_id, v_due,
       'egyedi', 'assigned', v_token);

    v_count := v_count + 1;
  END LOOP;

  RETURN v_count;
END $$;

/* ===== 5. Triggers on appointments / surgery_cases ===== */
CREATE OR REPLACE FUNCTION public.trg_appt_auto_assign()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_event_at TIMESTAMPTZ;
BEGIN
  IF NEW.patient_id IS NULL THEN RETURN NEW; END IF;
  SELECT s.kezdo_ts INTO v_event_at FROM public.appointment_slots s WHERE s.id = NEW.slot_id;

  IF TG_OP = 'INSERT' THEN
    PERFORM public.auto_assign_from_event(
      NEW.tenant_id, 'appointment_created'::public.qet_event_type,
      NEW.patient_id, v_event_at, NEW.id);
    IF NEW.status = 'megerositett' OR NEW.status::text = 'foglalt' OR NEW.status::text = 'megerositett' THEN
      PERFORM public.auto_assign_from_event(
        NEW.tenant_id, 'appointment_scheduled'::public.qet_event_type,
        NEW.patient_id, v_event_at, NEW.id);
    END IF;
  ELSIF TG_OP = 'UPDATE'
        AND (OLD.status IS DISTINCT FROM NEW.status)
        AND NEW.status::text IN ('megerositett','foglalt') THEN
    PERFORM public.auto_assign_from_event(
      NEW.tenant_id, 'appointment_scheduled'::public.qet_event_type,
      NEW.patient_id, v_event_at, NEW.id);
  END IF;

  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_appt_auto_assign ON public.appointments;
CREATE TRIGGER trg_appt_auto_assign
  AFTER INSERT OR UPDATE OF status ON public.appointments
  FOR EACH ROW EXECUTE FUNCTION public.trg_appt_auto_assign();

CREATE OR REPLACE FUNCTION public.trg_surgery_auto_assign()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    PERFORM public.auto_assign_from_event(
      NEW.tenant_id, 'surgery_created'::public.qet_event_type,
      NEW.patient_id, NEW.tervezett_kezdo_ido, NULL);
    IF NEW.tervezett_kezdo_ido IS NOT NULL THEN
      PERFORM public.auto_assign_from_event(
        NEW.tenant_id, 'surgery_scheduled'::public.qet_event_type,
        NEW.patient_id, NEW.tervezett_kezdo_ido, NULL);
    END IF;
  ELSIF TG_OP = 'UPDATE'
        AND OLD.tervezett_kezdo_ido IS DISTINCT FROM NEW.tervezett_kezdo_ido
        AND NEW.tervezett_kezdo_ido IS NOT NULL THEN
    PERFORM public.auto_assign_from_event(
      NEW.tenant_id, 'surgery_scheduled'::public.qet_event_type,
      NEW.patient_id, NEW.tervezett_kezdo_ido, NULL);
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_surgery_auto_assign ON public.surgery_cases;
CREATE TRIGGER trg_surgery_auto_assign
  AFTER INSERT OR UPDATE OF tervezett_kezdo_ido ON public.surgery_cases
  FOR EACH ROW EXECUTE FUNCTION public.trg_surgery_auto_assign();

/* ===== 6. Bucket-tudatos send_questionnaire_reminders ===== */
CREATE OR REPLACE FUNCTION public.send_questionnaire_reminders()
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_count INTEGER := 0;
  v_rec RECORD;
  v_days_to_due INTEGER;
  v_bucket INTEGER;
  v_b INTEGER;
  v_buckets INTEGER[];
  v_channel public.reminder_channel;
BEGIN
  FOR v_rec IN
    SELECT qa.id, qa.tenant_id, qa.patient_id, qa.questionnaire_id, qa.due_at,
           p.felelos_user_id, q.title,
           COALESCE(t.reminder_buckets, ARRAY[-7,-3,-1,1,3,7]::INTEGER[]) AS buckets,
           COALESCE(t.channel, 'notification'::public.reminder_channel)   AS channel
      FROM public.questionnaire_assignments qa
      JOIN public.questionnaires q ON q.id = qa.questionnaire_id
      LEFT JOIN public.patients p ON p.id = qa.patient_id
      LEFT JOIN public.questionnaire_event_triggers t
             ON t.tenant_id = qa.tenant_id
            AND t.questionnaire_id = qa.questionnaire_id
            AND t.active
     WHERE qa.status IN ('assigned','in_progress')
       AND qa.due_at IS NOT NULL
  LOOP
    v_days_to_due := EXTRACT(DAY FROM (v_rec.due_at - now()))::INTEGER;
    /* Aktuális bucket = az a legközelebbi konfigurált küszöb, amit a "due-tól vett előjeles távolság" elért. */
    /* Negatív bucket = még due előtt vagyunk, pozitív = után. */
    /* Aktuális előjeles távolság: -v_days_to_due (mert v_days_to_due = due - now napokban). */
    v_bucket := NULL;
    v_buckets := v_rec.buckets;
    FOREACH v_b IN ARRAY v_buckets LOOP
      /* "elértük" akkor, ha v_b negatív: -v_days_to_due >= v_b  (azaz közelebb vagyunk due-hoz, mint a küszöb)
         ha v_b pozitív: -v_days_to_due >= v_b (azaz due óta legalább v_b nap telt el) */
      IF (-v_days_to_due) >= v_b THEN
        IF v_bucket IS NULL OR v_b > v_bucket THEN v_bucket := v_b; END IF;
      END IF;
    END LOOP;

    IF v_bucket IS NULL THEN CONTINUE; END IF;

    v_channel := v_rec.channel;

    /* Ha ehhez a buckethez már ment értesítés, ugorjuk. */
    IF EXISTS (
      SELECT 1 FROM public.assignment_reminder_log l
       WHERE l.assignment_id = v_rec.id
         AND l.bucket_days  = v_bucket
         AND l.channel      = v_channel
    ) THEN CONTINUE; END IF;

    /* Értesítés a felelős klinikusnak (jelenleg notification csatorna). */
    IF v_rec.felelos_user_id IS NOT NULL THEN
      INSERT INTO public.notifications (tenant_id, user_id, tipus, cim, uzenet, link)
      VALUES (v_rec.tenant_id, v_rec.felelos_user_id, 'kerdoiv',
              CASE WHEN v_bucket < 0 THEN 'Közelgő kérdőív' ELSE 'Lejárt kérdőív' END,
              format('A(z) "%s" kérdőív %s. (bucket: %s nap, határidő: %s)',
                     v_rec.title,
                     CASE WHEN v_bucket < 0 THEN 'hamarosan esedékes' ELSE 'lejárt és nincs kitöltve' END,
                     v_bucket,
                     to_char(v_rec.due_at AT TIME ZONE 'Europe/Budapest','YYYY-MM-DD')),
              '/kerdoivek');
    END IF;

    INSERT INTO public.assignment_reminder_log (tenant_id, assignment_id, bucket_days, channel, notes)
    VALUES (v_rec.tenant_id, v_rec.id, v_bucket, v_channel,
            format('days_to_due=%s', v_days_to_due));

    UPDATE public.questionnaire_assignments
       SET reminded_at = now(),
           reminder_count = reminder_count + 1
     WHERE id = v_rec.id;

    v_count := v_count + 1;
  END LOOP;

  RETURN v_count;
END $$;


-- ─── 20260619225352_090f661c-da51-4b20-91c8-69904679754f.sql ───

-- Extend i18n_translations
ALTER TABLE public.i18n_translations
  ADD COLUMN IF NOT EXISTS kind text NOT NULL DEFAULT 'ui',
  ADD COLUMN IF NOT EXISTS content_ref text;

CREATE UNIQUE INDEX IF NOT EXISTS i18n_translations_unique_key
  ON public.i18n_translations (COALESCE(tenant_id, '00000000-0000-0000-0000-000000000000'::uuid), namespace, key, lang);

-- Glossary table
CREATE TABLE IF NOT EXISTS public.translation_glossary (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  term text NOT NULL,
  target_lang text NOT NULL,
  translation text NOT NULL,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.translation_glossary TO authenticated;
GRANT ALL ON public.translation_glossary TO service_role;

ALTER TABLE public.translation_glossary ENABLE ROW LEVEL SECURITY;

CREATE POLICY "tenant members read glossary" ON public.translation_glossary
  FOR SELECT TO authenticated
  USING (tenant_id IS NULL OR tenant_id IN (SELECT p.tenant_id FROM public.profiles p WHERE p.id = auth.uid()));

CREATE POLICY "tenant members write glossary" ON public.translation_glossary
  FOR ALL TO authenticated
  USING (tenant_id IS NULL OR tenant_id IN (SELECT p.tenant_id FROM public.profiles p WHERE p.id = auth.uid()))
  WITH CHECK (tenant_id IS NULL OR tenant_id IN (SELECT p.tenant_id FROM public.profiles p WHERE p.id = auth.uid()));

CREATE INDEX IF NOT EXISTS translation_glossary_lookup ON public.translation_glossary (target_lang, tenant_id);


-- ─── 20260619225650_8631b730-c0c0-43ec-abd8-206ad08e6bdc.sql ───

DROP INDEX IF EXISTS public.i18n_translations_unique_key;
ALTER TABLE public.i18n_translations
  DROP CONSTRAINT IF EXISTS i18n_translations_ns_key_lang_unique;
ALTER TABLE public.i18n_translations
  ADD CONSTRAINT i18n_translations_ns_key_lang_unique UNIQUE (namespace, key, lang);


-- ─── 20260619230413_6038ab93-0c68-4b82-9da5-037b0be1bb6e.sql ───

-- 1) Profile locale
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS locale text;

-- 2) attendance_anchors: restrict select to managers
DROP POLICY IF EXISTS aa_select ON public.attendance_anchors;
CREATE POLICY aa_select ON public.attendance_anchors
  FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id()
    AND (public.has_permission(auth.uid(),'manage_tenant')
         OR public.has_permission(auth.uid(),'manage_schedule')));

-- 3) Clinical tables: require manage_patients OR manage_tenant
DO $$
DECLARE
  t text;
  tables text[] := ARRAY['measurements','contractions','fetal_movements','menstrual_cycles','stool_log','food_log','wearable_data','monitoring_alerts','monitoring_programs','monitoring_thresholds','questionnaire_schedules'];
  polname text;
BEGIN
  FOREACH t IN ARRAY tables LOOP
    polname := 'tenant_isolation_' || t;
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', polname, t);
    EXECUTE format($f$
      CREATE POLICY %I ON public.%I
        FOR ALL TO authenticated
        USING (tenant_id = public.current_tenant_id()
          AND (public.has_permission(auth.uid(),'manage_patients')
               OR public.has_permission(auth.uid(),'manage_tenant')))
        WITH CHECK (tenant_id = public.current_tenant_id()
          AND (public.has_permission(auth.uid(),'manage_patients')
               OR public.has_permission(auth.uid(),'manage_tenant')))
    $f$, polname, t);
  END LOOP;
END $$;

-- 4) patient_checkin: tighten write
DROP POLICY IF EXISTS pc_write ON public.patient_checkin;
CREATE POLICY pc_write ON public.patient_checkin
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id()
    AND (public.has_permission(auth.uid(),'manage_patients')
         OR public.has_permission(auth.uid(),'manage_schedule')
         OR public.has_permission(auth.uid(),'manage_tenant')))
  WITH CHECK (tenant_id = public.current_tenant_id()
    AND (public.has_permission(auth.uid(),'manage_patients')
         OR public.has_permission(auth.uid(),'manage_schedule')
         OR public.has_permission(auth.uid(),'manage_tenant')));


-- ─── 20260620060021_5a713931-b2b5-447b-b965-b4cf2f03eefd.sql ───
CREATE TABLE IF NOT EXISTS public.i18n_missing_keys (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  namespace text NOT NULL,
  key text NOT NULL,
  lang text NOT NULL,
  source_text text NOT NULL,
  kind text NOT NULL DEFAULT 'ui',
  hits integer NOT NULL DEFAULT 1,
  last_seen_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (namespace, key, lang)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.i18n_missing_keys TO authenticated;
GRANT ALL ON public.i18n_missing_keys TO service_role;

ALTER TABLE public.i18n_missing_keys ENABLE ROW LEVEL SECURITY;

CREATE POLICY "i18n_missing_keys_all_auth" ON public.i18n_missing_keys
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE INDEX IF NOT EXISTS idx_i18n_missing_keys_lang ON public.i18n_missing_keys (lang, last_seen_at DESC);

-- ─── 20260620060730_447289c3-39a0-4400-96a2-294ee921da20.sql ───
-- 1) Profiles: restrict full-row read to self or supervisors (view_team permission)
DROP POLICY IF EXISTS "profiles_select_self_or_tenant" ON public.profiles;

CREATE POLICY "profiles_select_self_or_supervisor" ON public.profiles
  FOR SELECT TO authenticated
  USING (
    id = auth.uid()
    OR (
      tenant_id IS NOT NULL
      AND tenant_id = current_tenant_id()
      AND has_permission(auth.uid(), 'view_team')
    )
  );

-- 2) user_roles bootstrap: prevent grabbing tenant_admin on a tenant that already has one
DROP POLICY IF EXISTS "user_roles_bootstrap_admin" ON public.user_roles;

CREATE POLICY "user_roles_bootstrap_admin" ON public.user_roles
  FOR INSERT TO authenticated
  WITH CHECK (
    user_id = auth.uid()
    AND role_id IN (SELECT id FROM public.roles WHERE kulcs = 'tenant_admin')
    AND EXISTS (SELECT 1 FROM public.tenants t WHERE t.id = user_roles.tenant_id)
    AND NOT EXISTS (
      SELECT 1
      FROM public.user_roles ur
      JOIN public.roles r ON r.id = ur.role_id
      WHERE ur.tenant_id = user_roles.tenant_id
        AND r.kulcs = 'tenant_admin'
    )
  );

-- ─── 20260620070448_25c28ddf-30d9-4f97-9ae0-5014fc7b2908.sql ───

CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;

CREATE TYPE public.conversation_kind AS ENUM ('dm','group','patient_provider','patient_team','ai_assistant');
CREATE TYPE public.message_sender_kind AS ENUM ('user','patient','ai','system');
CREATE TYPE public.attachment_summary_status AS ENUM ('pending','done','failed','skipped');

CREATE TABLE public.conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  kind public.conversation_kind NOT NULL,
  title text,
  patient_id uuid REFERENCES public.patients(id) ON DELETE SET NULL,
  created_by uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  last_message_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_conversations_tenant_last ON public.conversations(tenant_id, last_message_at DESC);
CREATE INDEX idx_conversations_patient ON public.conversations(patient_id) WHERE patient_id IS NOT NULL;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.conversations TO authenticated;
GRANT ALL ON public.conversations TO service_role;
ALTER TABLE public.conversations ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.conversation_participants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  patient_id uuid REFERENCES public.patients(id) ON DELETE CASCADE,
  role text NOT NULL DEFAULT 'member' CHECK (role IN ('member','owner','observer')),
  auto_translate boolean NOT NULL DEFAULT true,
  muted boolean NOT NULL DEFAULT false,
  last_read_at timestamptz,
  joined_at timestamptz NOT NULL DEFAULT now(),
  CHECK ((user_id IS NOT NULL) <> (patient_id IS NOT NULL))
);
CREATE UNIQUE INDEX uq_participants_conv_user ON public.conversation_participants(conversation_id, user_id) WHERE user_id IS NOT NULL;
CREATE UNIQUE INDEX uq_participants_conv_patient ON public.conversation_participants(conversation_id, patient_id) WHERE patient_id IS NOT NULL;
CREATE INDEX idx_participants_user ON public.conversation_participants(user_id) WHERE user_id IS NOT NULL;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.conversation_participants TO authenticated;
GRANT ALL ON public.conversation_participants TO service_role;
ALTER TABLE public.conversation_participants ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.is_conversation_participant(_conv_id uuid, _user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.conversation_participants
    WHERE conversation_id = _conv_id AND user_id = _user_id
  );
$$;

CREATE TABLE public.messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  sender_user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  sender_patient_id uuid REFERENCES public.patients(id) ON DELETE SET NULL,
  sender_kind public.message_sender_kind NOT NULL DEFAULT 'user',
  body text,
  source_lang text,
  reply_to_id uuid REFERENCES public.messages(id) ON DELETE SET NULL,
  edited_at timestamptz,
  deleted_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_messages_conv_created ON public.messages(conversation_id, created_at DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.messages TO authenticated;
GRANT ALL ON public.messages TO service_role;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.message_translations (
  message_id uuid NOT NULL REFERENCES public.messages(id) ON DELETE CASCADE,
  lang text NOT NULL,
  translated_text text NOT NULL,
  model text,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (message_id, lang)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.message_translations TO authenticated;
GRANT ALL ON public.message_translations TO service_role;
ALTER TABLE public.message_translations ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.message_attachments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id uuid REFERENCES public.messages(id) ON DELETE CASCADE,
  conversation_id uuid NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  uploaded_by uuid NOT NULL REFERENCES auth.users(id) ON DELETE SET NULL,
  storage_path text NOT NULL,
  mime text NOT NULL,
  size_bytes bigint NOT NULL,
  original_name text NOT NULL,
  kind text NOT NULL DEFAULT 'file' CHECK (kind IN ('image','pdf','spreadsheet','audio','file')),
  duration_ms integer,
  ai_summary text,
  ai_summary_status public.attachment_summary_status NOT NULL DEFAULT 'pending',
  ai_summary_lang text,
  transcript text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_attachments_message ON public.message_attachments(message_id);
CREATE INDEX idx_attachments_conv ON public.message_attachments(conversation_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.message_attachments TO authenticated;
GRANT ALL ON public.message_attachments TO service_role;
ALTER TABLE public.message_attachments ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.message_read_receipts (
  message_id uuid NOT NULL REFERENCES public.messages(id) ON DELETE CASCADE,
  reader_user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  read_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (message_id, reader_user_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.message_read_receipts TO authenticated;
GRANT ALL ON public.message_read_receipts TO service_role;
ALTER TABLE public.message_read_receipts ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.ai_assistant_actions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  kind text NOT NULL,
  payload jsonb,
  result jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_assistant_actions_conv ON public.ai_assistant_actions(conversation_id, created_at DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.ai_assistant_actions TO authenticated;
GRANT ALL ON public.ai_assistant_actions TO service_role;
ALTER TABLE public.ai_assistant_actions ENABLE ROW LEVEL SECURITY;

CREATE POLICY conversations_select_participant ON public.conversations FOR SELECT TO authenticated
  USING (public.is_conversation_participant(id, auth.uid()));
CREATE POLICY conversations_insert_self ON public.conversations FOR INSERT TO authenticated
  WITH CHECK (created_by = auth.uid());
CREATE POLICY conversations_update_participant ON public.conversations FOR UPDATE TO authenticated
  USING (public.is_conversation_participant(id, auth.uid()));

CREATE POLICY participants_select_same_conv ON public.conversation_participants FOR SELECT TO authenticated
  USING (public.is_conversation_participant(conversation_id, auth.uid()) OR user_id = auth.uid());
CREATE POLICY participants_insert_creator_or_self ON public.conversation_participants FOR INSERT TO authenticated
  WITH CHECK (
    user_id = auth.uid()
    OR EXISTS (SELECT 1 FROM public.conversations c WHERE c.id = conversation_id AND c.created_by = auth.uid())
  );
CREATE POLICY participants_update_self ON public.conversation_participants FOR UPDATE TO authenticated
  USING (user_id = auth.uid());
CREATE POLICY participants_delete_self_or_owner ON public.conversation_participants FOR DELETE TO authenticated
  USING (
    user_id = auth.uid()
    OR EXISTS (SELECT 1 FROM public.conversations c WHERE c.id = conversation_id AND c.created_by = auth.uid())
  );

CREATE POLICY messages_select_participant ON public.messages FOR SELECT TO authenticated
  USING (public.is_conversation_participant(conversation_id, auth.uid()));
CREATE POLICY messages_insert_participant ON public.messages FOR INSERT TO authenticated
  WITH CHECK (
    public.is_conversation_participant(conversation_id, auth.uid())
    AND (sender_user_id = auth.uid() OR sender_kind IN ('ai','system'))
  );
CREATE POLICY messages_update_own ON public.messages FOR UPDATE TO authenticated
  USING (sender_user_id = auth.uid());
CREATE POLICY messages_delete_own ON public.messages FOR DELETE TO authenticated
  USING (sender_user_id = auth.uid());

CREATE POLICY translations_select_participant ON public.message_translations FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.messages m WHERE m.id = message_id AND public.is_conversation_participant(m.conversation_id, auth.uid())));
CREATE POLICY translations_insert_participant ON public.message_translations FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM public.messages m WHERE m.id = message_id AND public.is_conversation_participant(m.conversation_id, auth.uid())));

CREATE POLICY attachments_select_participant ON public.message_attachments FOR SELECT TO authenticated
  USING (public.is_conversation_participant(conversation_id, auth.uid()));
CREATE POLICY attachments_insert_uploader ON public.message_attachments FOR INSERT TO authenticated
  WITH CHECK (uploaded_by = auth.uid() AND public.is_conversation_participant(conversation_id, auth.uid()));
CREATE POLICY attachments_update_uploader ON public.message_attachments FOR UPDATE TO authenticated
  USING (uploaded_by = auth.uid() OR public.is_conversation_participant(conversation_id, auth.uid()));
CREATE POLICY attachments_delete_uploader ON public.message_attachments FOR DELETE TO authenticated
  USING (uploaded_by = auth.uid());

CREATE POLICY receipts_select_participant ON public.message_read_receipts FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.messages m WHERE m.id = message_id AND public.is_conversation_participant(m.conversation_id, auth.uid())));
CREATE POLICY receipts_insert_self ON public.message_read_receipts FOR INSERT TO authenticated
  WITH CHECK (reader_user_id = auth.uid());

CREATE POLICY assistant_actions_select_own ON public.ai_assistant_actions FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_conversation_participant(conversation_id, auth.uid()));
CREATE POLICY assistant_actions_insert_self ON public.ai_assistant_actions FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE TRIGGER trg_conversations_updated_at
  BEFORE UPDATE ON public.conversations
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE OR REPLACE FUNCTION public.bump_conversation_last_message()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  UPDATE public.conversations SET last_message_at = NEW.created_at, updated_at = now() WHERE id = NEW.conversation_id;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_messages_bump_conv
  AFTER INSERT ON public.messages
  FOR EACH ROW EXECUTE FUNCTION public.bump_conversation_last_message();

ALTER PUBLICATION supabase_realtime ADD TABLE public.messages;
ALTER PUBLICATION supabase_realtime ADD TABLE public.message_read_receipts;
ALTER PUBLICATION supabase_realtime ADD TABLE public.message_attachments;
ALTER PUBLICATION supabase_realtime ADD TABLE public.conversations;


-- ─── 20260620070514_5245879f-2d15-442e-ada9-e211af40cbcf.sql ───

ALTER FUNCTION public.set_updated_at() SET search_path = public;
ALTER FUNCTION public.bump_conversation_last_message() SET search_path = public;

REVOKE EXECUTE ON FUNCTION public.is_conversation_participant(uuid, uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_conversation_participant(uuid, uuid) TO authenticated, service_role;

REVOKE EXECUTE ON FUNCTION public.bump_conversation_last_message() FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.set_updated_at() FROM PUBLIC, anon;


-- ─── 20260620070534_54f75b08-1a0f-4d1e-8b28-3097d4948f52.sql ───

CREATE POLICY chat_attach_select_participant ON storage.objects
  FOR SELECT TO authenticated
  USING (
    bucket_id = 'chat-attachments'
    AND public.is_conversation_participant((split_part(name, '/', 1))::uuid, auth.uid())
  );

CREATE POLICY chat_attach_insert_participant ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'chat-attachments'
    AND public.is_conversation_participant((split_part(name, '/', 1))::uuid, auth.uid())
    AND owner = auth.uid()
  );

CREATE POLICY chat_attach_delete_owner ON storage.objects
  FOR DELETE TO authenticated
  USING (
    bucket_id = 'chat-attachments'
    AND owner = auth.uid()
  );


-- ─── 20260620124139_9a581cc2-8ed5-4c14-aaf9-49e908b82948.sql ───
-- 1) Új permission kulcsok seedelése (idempotens)
INSERT INTO public.role_permissions (role_kulcs, perm)
SELECT r.kulcs, p.perm
FROM public.roles r
CROSS JOIN (VALUES
  ('view_or_board'),
  ('manage_or_blocks'),
  ('book_or_case'),
  ('sign_off_or_case'),
  ('trigger_or_emergency')
) AS p(perm)
WHERE
  (r.kulcs IN ('tenant_admin','igazgato','orvosigazgato','super_admin'))
  OR (r.kulcs IN ('mutos_koordinator','muteti_koordinator') AND p.perm IN ('view_or_board','manage_or_blocks','book_or_case','trigger_or_emergency'))
  OR (r.kulcs IN ('sebeszvezeto','sebesz_osztalyvezeto','osztalyvezeto') AND p.perm IN ('view_or_board','book_or_case','sign_off_or_case'))
  OR (r.kulcs IN ('sebesz','orvos','rezidens_sebesz') AND p.perm IN ('view_or_board','book_or_case'))
  OR (r.kulcs IN ('aneszteziologus','mutos_asszisztens','mutos_szakdolgozo','operacios_nover') AND p.perm = 'view_or_board')
ON CONFLICT DO NOTHING;

-- 2) or_staff_pool
CREATE TABLE IF NOT EXISTS public.or_staff_pool (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  user_id uuid NOT NULL,
  or_suite_id uuid NOT NULL REFERENCES public.or_suites(id) ON DELETE CASCADE,
  department_org_unit_id uuid NULL,
  eligible_szerep text NOT NULL CHECK (eligible_szerep IN ('operator','asszisztens','aneszteziologus','mutos_szakdolgozo','neonatologus','egyeb')),
  heti_keret_perc integer NOT NULL DEFAULT 0 CHECK (heti_keret_perc >= 0),
  havi_max_perc integer NULL CHECK (havi_max_perc IS NULL OR havi_max_perc >= 0),
  ervenyes_tol date NOT NULL DEFAULT current_date,
  ervenyes_ig date NULL,
  megjegyzes text NULL,
  created_by uuid NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.or_staff_pool TO authenticated;
GRANT ALL ON public.or_staff_pool TO service_role;
ALTER TABLE public.or_staff_pool ENABLE ROW LEVEL SECURITY;

CREATE POLICY "or_staff_pool_select" ON public.or_staff_pool
  FOR SELECT TO authenticated
  USING (
    tenant_id = public.current_tenant_id()
    AND (
      user_id = auth.uid()
      OR public.has_permission(auth.uid(), 'view_or_board')
      OR public.has_permission(auth.uid(), 'manage_or_blocks')
      OR public.has_permission(auth.uid(), 'view_team')
    )
  );

CREATE POLICY "or_staff_pool_write" ON public.or_staff_pool
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_or_blocks'))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_or_blocks'));

CREATE INDEX IF NOT EXISTS idx_or_staff_pool_user ON public.or_staff_pool(user_id, ervenyes_tol);
CREATE INDEX IF NOT EXISTS idx_or_staff_pool_suite ON public.or_staff_pool(or_suite_id);

CREATE TRIGGER trg_or_staff_pool_touch
  BEFORE UPDATE ON public.or_staff_pool
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- 3) or_emergency_responses
CREATE TABLE IF NOT EXISTS public.or_emergency_responses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  surgery_case_id uuid NOT NULL REFERENCES public.surgery_cases(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  notification_id uuid NULL REFERENCES public.notifications(id) ON DELETE SET NULL,
  tud_jonni boolean NOT NULL,
  eta_perc integer NULL CHECK (eta_perc IS NULL OR eta_perc >= 0),
  megjegyzes text NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (surgery_case_id, user_id)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.or_emergency_responses TO authenticated;
GRANT ALL ON public.or_emergency_responses TO service_role;
ALTER TABLE public.or_emergency_responses ENABLE ROW LEVEL SECURITY;

CREATE POLICY "oer_select" ON public.or_emergency_responses
  FOR SELECT TO authenticated
  USING (
    tenant_id = public.current_tenant_id()
    AND (
      user_id = auth.uid()
      OR public.has_permission(auth.uid(), 'manage_or_blocks')
      OR public.has_permission(auth.uid(), 'trigger_or_emergency')
    )
  );

CREATE POLICY "oer_insert_self" ON public.or_emergency_responses
  FOR INSERT TO authenticated
  WITH CHECK (tenant_id = public.current_tenant_id() AND user_id = auth.uid());

CREATE POLICY "oer_update_self" ON public.or_emergency_responses
  FOR UPDATE TO authenticated
  USING (tenant_id = public.current_tenant_id() AND user_id = auth.uid())
  WITH CHECK (tenant_id = public.current_tenant_id() AND user_id = auth.uid());

-- 4) can_book_into_block
CREATE OR REPLACE FUNCTION public.can_book_into_block(_user_id uuid, _block_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.or_blocks b
    WHERE b.id = _block_id
      AND b.tenant_id = public.current_tenant_id()
      AND public.has_permission(_user_id, 'book_or_case')
      AND (
        public.has_permission(_user_id, 'manage_or_blocks')
        OR b.sebesz_user_id = _user_id
        OR b.sebesz_user_id IS NULL
        OR EXISTS (
          SELECT 1 FROM public.org_unit_specialties ous
          JOIN public.profile_employment pe ON pe.org_unit_id = ous.org_unit_id
          WHERE ous.specialty_id = b.specialty_id
            AND pe.user_id = _user_id
            AND COALESCE(pe.ervenyes, true) = true
        )
      )
  )
$$;

-- 5) notify_or_emergency trigger
CREATE OR REPLACE FUNCTION public.notify_or_emergency()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_suite_id uuid;
  v_type_nev text;
  v_user record;
BEGIN
  IF NEW.prioritas <> 'azonnali' THEN RETURN NEW; END IF;
  IF TG_OP = 'UPDATE' AND OLD.prioritas = 'azonnali' THEN RETURN NEW; END IF;

  SELECT st.megnevezes INTO v_type_nev FROM public.surgery_types st WHERE st.id = NEW.surgery_type_id;

  SELECT rp.or_suite_id INTO v_suite_id
  FROM public.or_blocks b
  LEFT JOIN public.or_room_profiles rp ON rp.org_unit_id = b.org_unit_id
  WHERE b.id = NEW.or_block_id;

  FOR v_user IN
    SELECT DISTINCT p.id AS user_id
    FROM public.profiles p
    JOIN public.or_staff_pool sp ON sp.user_id = p.id
    WHERE p.tenant_id = NEW.tenant_id
      AND (sp.ervenyes_ig IS NULL OR sp.ervenyes_ig >= current_date)
      AND sp.ervenyes_tol <= current_date
      AND (v_suite_id IS NULL OR sp.or_suite_id = v_suite_id)
      AND EXISTS (
        SELECT 1 FROM public.attendance_events ae
        WHERE ae.user_id = p.id
          AND ae.idopont >= (now() - interval '12 hours')
      )
  LOOP
    INSERT INTO public.notifications (tenant_id, user_id, tipus, cim, uzenet, link)
    VALUES (
      NEW.tenant_id,
      v_user.user_id,
      'or_emergency',
      'SÜRGŐS MŰTÉT – segítség kérése',
      COALESCE('Beavatkozás: ' || v_type_nev, 'Azonnali műtéti segítség szükséges.')
        || ' Tervezett kezdés: '
        || to_char(COALESCE(NEW.tervezett_kezdo_ido, now()) AT TIME ZONE 'Europe/Budapest', 'HH24:MI'),
      '/muteti-terv/blokkok?case=' || NEW.id::text
    );
  END LOOP;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_notify_or_emergency_ins ON public.surgery_cases;
DROP TRIGGER IF EXISTS trg_notify_or_emergency_upd ON public.surgery_cases;
CREATE TRIGGER trg_notify_or_emergency_ins
  AFTER INSERT ON public.surgery_cases
  FOR EACH ROW EXECUTE FUNCTION public.notify_or_emergency();
CREATE TRIGGER trg_notify_or_emergency_upd
  AFTER UPDATE OF prioritas ON public.surgery_cases
  FOR EACH ROW EXECUTE FUNCTION public.notify_or_emergency();

-- 6) Realtime publikáció (idempotens)
DO $$
BEGIN
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.or_blocks; EXCEPTION WHEN duplicate_object THEN NULL; END;
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.surgery_cases; EXCEPTION WHEN duplicate_object THEN NULL; END;
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.resource_bookings; EXCEPTION WHEN duplicate_object THEN NULL; END;
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.or_emergency_responses; EXCEPTION WHEN duplicate_object THEN NULL; END;
END $$;


-- ─── 20260620142021_1267b2bb-c765-4545-a5e8-4512af1a1c99.sql ───

-- Helper: update_updated_at (idempotent)
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- =========================================================
-- 1) clinical_encounters
-- =========================================================
CREATE TABLE public.clinical_encounters (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tenant_id UUID,
  patient_id UUID NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  encounter_type TEXT NOT NULL DEFAULT 'ambulatory',
    -- 'ambulatory' | 'emergency' | 'inpatient' | 'obstetric' | 'home'
  status TEXT NOT NULL DEFAULT 'in-progress',
    -- 'planned' | 'in-progress' | 'finished' | 'cancelled'
  start_ts TIMESTAMPTZ NOT NULL DEFAULT now(),
  end_ts TIMESTAMPTZ,
  chief_complaint TEXT,
  location TEXT,
  created_by UUID NOT NULL REFERENCES auth.users(id),
  closed_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_clin_enc_patient ON public.clinical_encounters(patient_id, start_ts DESC);
CREATE INDEX idx_clin_enc_status ON public.clinical_encounters(status);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.clinical_encounters TO authenticated;
GRANT ALL ON public.clinical_encounters TO service_role;
ALTER TABLE public.clinical_encounters ENABLE ROW LEVEL SECURITY;

CREATE POLICY "auth users read encounters"
  ON public.clinical_encounters FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth users insert encounters"
  ON public.clinical_encounters FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = created_by);
CREATE POLICY "creator updates encounters"
  ON public.clinical_encounters FOR UPDATE TO authenticated
  USING (auth.uid() = created_by OR public.has_role(auth.uid(), 'admin'))
  WITH CHECK (true);
CREATE POLICY "creator deletes encounters"
  ON public.clinical_encounters FOR DELETE TO authenticated
  USING (auth.uid() = created_by OR public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER trg_clin_enc_updated
  BEFORE UPDATE ON public.clinical_encounters
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- =========================================================
-- 2) clinical_observations  (FHIR Observation)
-- =========================================================
CREATE TABLE public.clinical_observations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  encounter_id UUID NOT NULL REFERENCES public.clinical_encounters(id) ON DELETE CASCADE,
  patient_id UUID NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  category TEXT NOT NULL,
    -- 'vital-signs' | 'laboratory' | 'imaging' | 'exam' | 'survey' | 'fluid-balance' | 'pain'
  loinc_code TEXT,
  snomed_code TEXT,
  code_display TEXT NOT NULL,
  value_quantity NUMERIC,
  value_unit TEXT,
  value_string TEXT,
  value_json JSONB,
  interpretation TEXT,
    -- 'normal' | 'low' | 'high' | 'critical-low' | 'critical-high'
  effective_ts TIMESTAMPTZ NOT NULL DEFAULT now(),
  performer_id UUID REFERENCES auth.users(id),
  source TEXT NOT NULL DEFAULT 'manual',
    -- 'manual' | 'device' | 'calculator' | 'import'
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_clin_obs_encounter ON public.clinical_observations(encounter_id, effective_ts);
CREATE INDEX idx_clin_obs_patient ON public.clinical_observations(patient_id, effective_ts DESC);
CREATE INDEX idx_clin_obs_loinc ON public.clinical_observations(loinc_code);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.clinical_observations TO authenticated;
GRANT ALL ON public.clinical_observations TO service_role;
ALTER TABLE public.clinical_observations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "auth users read observations"
  ON public.clinical_observations FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth users insert observations"
  ON public.clinical_observations FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = performer_id OR performer_id IS NULL);
CREATE POLICY "performer updates observations"
  ON public.clinical_observations FOR UPDATE TO authenticated
  USING (auth.uid() = performer_id OR public.has_role(auth.uid(), 'admin'))
  WITH CHECK (true);
CREATE POLICY "performer deletes observations"
  ON public.clinical_observations FOR DELETE TO authenticated
  USING (auth.uid() = performer_id OR public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER trg_clin_obs_updated
  BEFORE UPDATE ON public.clinical_observations
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- =========================================================
-- 3) clinical_notes
-- =========================================================
CREATE TABLE public.clinical_notes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  encounter_id UUID NOT NULL REFERENCES public.clinical_encounters(id) ON DELETE CASCADE,
  patient_id UUID NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  kind TEXT NOT NULL,
    -- 'anamnesis' | 'complaint' | 'status' | 'ultrasound' | 'imaging'
    -- | 'epicrisis' | 'therapy' | 'recommendation' | 'summary'
    -- | 'lifestyle' | 'diet' | 'progress'
  title TEXT,
  body_md TEXT,
  structured_json JSONB,
  author_id UUID NOT NULL REFERENCES auth.users(id),
  signed_at TIMESTAMPTZ,
  signed_by UUID REFERENCES auth.users(id),
  version INT NOT NULL DEFAULT 1,
  parent_note_id UUID REFERENCES public.clinical_notes(id),
  ai_generated BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_clin_notes_encounter ON public.clinical_notes(encounter_id, kind);
CREATE INDEX idx_clin_notes_patient ON public.clinical_notes(patient_id, created_at DESC);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.clinical_notes TO authenticated;
GRANT ALL ON public.clinical_notes TO service_role;
ALTER TABLE public.clinical_notes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "auth users read notes"
  ON public.clinical_notes FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth users insert notes"
  ON public.clinical_notes FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = author_id);
CREATE POLICY "author updates unsigned notes"
  ON public.clinical_notes FOR UPDATE TO authenticated
  USING ((auth.uid() = author_id AND signed_at IS NULL) OR public.has_role(auth.uid(), 'admin'))
  WITH CHECK (true);
CREATE POLICY "author deletes unsigned notes"
  ON public.clinical_notes FOR DELETE TO authenticated
  USING ((auth.uid() = author_id AND signed_at IS NULL) OR public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER trg_clin_notes_updated
  BEFORE UPDATE ON public.clinical_notes
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- =========================================================
-- 4) clinical_diagnoses  (FHIR Condition)
-- =========================================================
CREATE TABLE public.clinical_diagnoses (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  encounter_id UUID NOT NULL REFERENCES public.clinical_encounters(id) ON DELETE CASCADE,
  patient_id UUID NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  icd10_code TEXT,
  snomed_code TEXT,
  display TEXT NOT NULL,
  certainty TEXT NOT NULL DEFAULT 'confirmed',
    -- 'suspected' | 'confirmed' | 'ruled-out' | 'differential'
  is_primary BOOLEAN NOT NULL DEFAULT false,
  onset_date DATE,
  note TEXT,
  created_by UUID NOT NULL REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_clin_dx_encounter ON public.clinical_diagnoses(encounter_id);
CREATE INDEX idx_clin_dx_patient ON public.clinical_diagnoses(patient_id);
CREATE INDEX idx_clin_dx_icd ON public.clinical_diagnoses(icd10_code);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.clinical_diagnoses TO authenticated;
GRANT ALL ON public.clinical_diagnoses TO service_role;
ALTER TABLE public.clinical_diagnoses ENABLE ROW LEVEL SECURITY;

CREATE POLICY "auth users read diagnoses"
  ON public.clinical_diagnoses FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth users insert diagnoses"
  ON public.clinical_diagnoses FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = created_by);
CREATE POLICY "creator updates diagnoses"
  ON public.clinical_diagnoses FOR UPDATE TO authenticated
  USING (auth.uid() = created_by OR public.has_role(auth.uid(), 'admin'))
  WITH CHECK (true);
CREATE POLICY "creator deletes diagnoses"
  ON public.clinical_diagnoses FOR DELETE TO authenticated
  USING (auth.uid() = created_by OR public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER trg_clin_dx_updated
  BEFORE UPDATE ON public.clinical_diagnoses
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- =========================================================
-- 5) clinical_therapy_orders
-- =========================================================
CREATE TABLE public.clinical_therapy_orders (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  encounter_id UUID NOT NULL REFERENCES public.clinical_encounters(id) ON DELETE CASCADE,
  patient_id UUID NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  kind TEXT NOT NULL,
    -- 'medication' | 'procedure' | 'lifestyle' | 'diet' | 'imaging' | 'lab-request' | 'referral'
  atc_code TEXT,
  snomed_code TEXT,
  display TEXT NOT NULL,
  dose TEXT,
  route TEXT,
  frequency TEXT,
  duration TEXT,
  instructions TEXT,
  status TEXT NOT NULL DEFAULT 'active',
    -- 'active' | 'completed' | 'cancelled' | 'on-hold' | 'draft'
  starts_on DATE,
  ends_on DATE,
  ai_generated BOOLEAN NOT NULL DEFAULT false,
  created_by UUID NOT NULL REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_clin_tx_encounter ON public.clinical_therapy_orders(encounter_id);
CREATE INDEX idx_clin_tx_patient ON public.clinical_therapy_orders(patient_id, status);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.clinical_therapy_orders TO authenticated;
GRANT ALL ON public.clinical_therapy_orders TO service_role;
ALTER TABLE public.clinical_therapy_orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "auth users read therapy"
  ON public.clinical_therapy_orders FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth users insert therapy"
  ON public.clinical_therapy_orders FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = created_by);
CREATE POLICY "creator updates therapy"
  ON public.clinical_therapy_orders FOR UPDATE TO authenticated
  USING (auth.uid() = created_by OR public.has_role(auth.uid(), 'admin'))
  WITH CHECK (true);
CREATE POLICY "creator deletes therapy"
  ON public.clinical_therapy_orders FOR DELETE TO authenticated
  USING (auth.uid() = created_by OR public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER trg_clin_tx_updated
  BEFORE UPDATE ON public.clinical_therapy_orders
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- =========================================================
-- 6) clinical_calculator_results
-- =========================================================
CREATE TABLE public.clinical_calculator_results (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  encounter_id UUID REFERENCES public.clinical_encounters(id) ON DELETE CASCADE,
  patient_id UUID REFERENCES public.patients(id) ON DELETE CASCADE,
  calculator TEXT NOT NULL,
    -- 'bloodgas' | 't2dm' | 'who-lcg' | 'qsofa' | 'sirs' | 'preeclampsia' | ...
  inputs_json JSONB NOT NULL,
  outputs_json JSONB NOT NULL,
  interpretation_md TEXT,
  created_by UUID NOT NULL REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_clin_calc_patient ON public.clinical_calculator_results(patient_id, calculator, created_at DESC);
CREATE INDEX idx_clin_calc_encounter ON public.clinical_calculator_results(encounter_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.clinical_calculator_results TO authenticated;
GRANT ALL ON public.clinical_calculator_results TO service_role;
ALTER TABLE public.clinical_calculator_results ENABLE ROW LEVEL SECURITY;

CREATE POLICY "auth users read calc results"
  ON public.clinical_calculator_results FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth users insert calc results"
  ON public.clinical_calculator_results FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = created_by);
CREATE POLICY "creator updates calc results"
  ON public.clinical_calculator_results FOR UPDATE TO authenticated
  USING (auth.uid() = created_by OR public.has_role(auth.uid(), 'admin'))
  WITH CHECK (true);
CREATE POLICY "creator deletes calc results"
  ON public.clinical_calculator_results FOR DELETE TO authenticated
  USING (auth.uid() = created_by OR public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER trg_clin_calc_updated
  BEFORE UPDATE ON public.clinical_calculator_results
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- ─── 20260620143252_0d7b9719-1fe7-4bc1-bb6a-2713e9b15c3f.sql ───
CREATE TABLE public.obstetric_partograms (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  encounter_id UUID NOT NULL REFERENCES public.clinical_encounters(id) ON DELETE CASCADE,
  patient_id UUID NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  labor_start_ts TIMESTAMPTZ NOT NULL DEFAULT now(),
  parity_gravida_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  membrane_status TEXT,
  notes_md TEXT,
  created_by UUID NOT NULL DEFAULT auth.uid(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.obstetric_partograms TO authenticated;
GRANT ALL ON public.obstetric_partograms TO service_role;
ALTER TABLE public.obstetric_partograms ENABLE ROW LEVEL SECURITY;
CREATE POLICY "partogram_select" ON public.obstetric_partograms FOR SELECT TO authenticated USING (created_by = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "partogram_insert" ON public.obstetric_partograms FOR INSERT TO authenticated WITH CHECK (created_by = auth.uid());
CREATE POLICY "partogram_update" ON public.obstetric_partograms FOR UPDATE TO authenticated USING (created_by = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "partogram_delete" ON public.obstetric_partograms FOR DELETE TO authenticated USING (created_by = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE TRIGGER update_obstetric_partograms_updated_at BEFORE UPDATE ON public.obstetric_partograms FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.obstetric_partogram_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  partogram_id UUID NOT NULL REFERENCES public.obstetric_partograms(id) ON DELETE CASCADE,
  recorded_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  cervix_cm NUMERIC(3,1),
  descent_station SMALLINT,
  contractions_per_10min SMALLINT,
  contraction_duration_sec SMALLINT,
  fetal_heart_rate SMALLINT,
  maternal_hr SMALLINT,
  maternal_bp_sys SMALLINT,
  maternal_bp_dia SMALLINT,
  temp_c NUMERIC(4,1),
  liquor_color TEXT,
  moulding TEXT,
  oxytocin_mu NUMERIC(6,2),
  drugs_text TEXT,
  notes TEXT,
  created_by UUID NOT NULL DEFAULT auth.uid(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.obstetric_partogram_entries TO authenticated;
GRANT ALL ON public.obstetric_partogram_entries TO service_role;
ALTER TABLE public.obstetric_partogram_entries ENABLE ROW LEVEL SECURITY;
CREATE POLICY "partogram_entry_select" ON public.obstetric_partogram_entries FOR SELECT TO authenticated USING (EXISTS (SELECT 1 FROM public.obstetric_partograms p WHERE p.id = partogram_id AND (p.created_by = auth.uid() OR public.has_role(auth.uid(),'admin'))));
CREATE POLICY "partogram_entry_insert" ON public.obstetric_partogram_entries FOR INSERT TO authenticated WITH CHECK (created_by = auth.uid() AND EXISTS (SELECT 1 FROM public.obstetric_partograms p WHERE p.id = partogram_id AND p.created_by = auth.uid()));
CREATE POLICY "partogram_entry_update" ON public.obstetric_partogram_entries FOR UPDATE TO authenticated USING (created_by = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "partogram_entry_delete" ON public.obstetric_partogram_entries FOR DELETE TO authenticated USING (created_by = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE INDEX idx_partogram_entries_partogram ON public.obstetric_partogram_entries(partogram_id, recorded_at);

-- ─── 20260620150550_212b53f3-7da4-449d-bfbd-e34897d6262d.sql ───

-- ============ Diabétesz modul + klinikai riasztások ============

-- 1) Inzulin session-ök
CREATE TABLE public.clinical_insulin_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  encounter_id UUID REFERENCES public.clinical_encounters(id) ON DELETE SET NULL,
  patient_id UUID NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  session_date DATE NOT NULL DEFAULT CURRENT_DATE,
  mode TEXT NOT NULL CHECK (mode IN ('bb','premix2','premix3')),
  diabetes_type TEXT NOT NULL CHECK (diabetes_type IN ('t1','t2','t2r','gest')),
  weight_kg NUMERIC(5,1) NOT NULL,
  bolus_type TEXT CHECK (bolus_type IN ('analog','regular')),
  meal_ratio TEXT,
  bolus_prep_id TEXT,
  basal_prep_id TEXT,
  premix_prep_id TEXT,
  tdd NUMERIC(6,2),
  basal NUMERIC(6,2),
  bolus_r NUMERIC(6,2),
  bolus_d NUMERIC(6,2),
  bolus_e NUMERIC(6,2),
  icr NUMERIC(6,2),
  isf NUMERIC(6,2),
  target_vc NUMERIC(4,2) DEFAULT 6.0,
  current_vc NUMERIC(5,2),
  correction_bolus NUMERIC(6,2),
  modifiers_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  notes TEXT,
  created_by UUID NOT NULL REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.clinical_insulin_sessions TO authenticated;
GRANT ALL ON public.clinical_insulin_sessions TO service_role;
ALTER TABLE public.clinical_insulin_sessions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated read insulin sessions" ON public.clinical_insulin_sessions
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated insert insulin sessions" ON public.clinical_insulin_sessions
  FOR INSERT TO authenticated WITH CHECK (created_by = auth.uid());
CREATE POLICY "Author update insulin sessions" ON public.clinical_insulin_sessions
  FOR UPDATE TO authenticated USING (created_by = auth.uid()) WITH CHECK (created_by = auth.uid());
CREATE POLICY "Author delete insulin sessions" ON public.clinical_insulin_sessions
  FOR DELETE TO authenticated USING (created_by = auth.uid());

CREATE INDEX idx_insulin_sessions_patient ON public.clinical_insulin_sessions(patient_id, session_date DESC);
CREATE INDEX idx_insulin_sessions_encounter ON public.clinical_insulin_sessions(encounter_id);

-- 2) Heti vércukor mérések
CREATE TABLE public.clinical_weekly_vc (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  encounter_id UUID REFERENCES public.clinical_encounters(id) ON DELETE SET NULL,
  measured_at TIMESTAMPTZ NOT NULL,
  value_mmol_l NUMERIC(5,2) NOT NULL,
  measurement_type TEXT NOT NULL CHECK (measurement_type IN
    ('night','fasting','regPP','lunchPre','lunchPP','dinnerPre','dinnerPP')),
  bolus_given NUMERIC(6,2),
  notes TEXT,
  created_by UUID NOT NULL REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.clinical_weekly_vc TO authenticated;
GRANT ALL ON public.clinical_weekly_vc TO service_role;
ALTER TABLE public.clinical_weekly_vc ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated read weekly vc" ON public.clinical_weekly_vc
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated insert weekly vc" ON public.clinical_weekly_vc
  FOR INSERT TO authenticated WITH CHECK (created_by = auth.uid());
CREATE POLICY "Author update weekly vc" ON public.clinical_weekly_vc
  FOR UPDATE TO authenticated USING (created_by = auth.uid()) WITH CHECK (created_by = auth.uid());
CREATE POLICY "Author delete weekly vc" ON public.clinical_weekly_vc
  FOR DELETE TO authenticated USING (created_by = auth.uid());
CREATE INDEX idx_weekly_vc_patient_date ON public.clinical_weekly_vc(patient_id, measured_at DESC);

-- 3) Gyógyszer státuszok (per encounter)
CREATE TABLE public.clinical_drug_statuses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  encounter_id UUID REFERENCES public.clinical_encounters(id) ON DELETE SET NULL,
  drug_id TEXT NOT NULL CHECK (drug_id IN ('metformin','su','sglt2','dpp4','glp1')),
  status TEXT NOT NULL CHECK (status IN ('none','current','planned','stop')),
  notes TEXT,
  created_by UUID NOT NULL REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (patient_id, drug_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.clinical_drug_statuses TO authenticated;
GRANT ALL ON public.clinical_drug_statuses TO service_role;
ALTER TABLE public.clinical_drug_statuses ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated read drug statuses" ON public.clinical_drug_statuses
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated upsert drug statuses" ON public.clinical_drug_statuses
  FOR INSERT TO authenticated WITH CHECK (created_by = auth.uid());
CREATE POLICY "Authenticated update drug statuses" ON public.clinical_drug_statuses
  FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Author delete drug statuses" ON public.clinical_drug_statuses
  FOR DELETE TO authenticated USING (created_by = auth.uid());

-- 4) Klinikai kritikus riasztások (cross-modul)
CREATE TABLE public.clinical_critical_alerts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  encounter_id UUID REFERENCES public.clinical_encounters(id) ON DELETE SET NULL,
  source TEXT NOT NULL CHECK (source IN ('insulin','weekly_vc','vergaz','lab','partogram','vital','other')),
  severity TEXT NOT NULL CHECK (severity IN ('info','warn','critical')),
  code TEXT NOT NULL,
  message TEXT NOT NULL,
  value_json JSONB,
  triggered_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  acknowledged_at TIMESTAMPTZ,
  acknowledged_by UUID REFERENCES auth.users(id),
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.clinical_critical_alerts TO authenticated;
GRANT ALL ON public.clinical_critical_alerts TO service_role;
ALTER TABLE public.clinical_critical_alerts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated read clinical alerts" ON public.clinical_critical_alerts
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated insert clinical alerts" ON public.clinical_critical_alerts
  FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated ack clinical alerts" ON public.clinical_critical_alerts
  FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Service role delete clinical alerts" ON public.clinical_critical_alerts
  FOR DELETE TO service_role USING (true);
CREATE INDEX idx_clinical_alerts_patient ON public.clinical_critical_alerts(patient_id, triggered_at DESC);
CREATE INDEX idx_clinical_alerts_unack ON public.clinical_critical_alerts(acknowledged_at) WHERE acknowledged_at IS NULL;

-- 5) updated_at triggerek
CREATE OR REPLACE FUNCTION public.update_clinical_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END $$;

CREATE TRIGGER trg_insulin_sessions_updated BEFORE UPDATE ON public.clinical_insulin_sessions
  FOR EACH ROW EXECUTE FUNCTION public.update_clinical_updated_at();
CREATE TRIGGER trg_drug_statuses_updated BEFORE UPDATE ON public.clinical_drug_statuses
  FOR EACH ROW EXECUTE FUNCTION public.update_clinical_updated_at();

-- 6) Auto-alarm trigger: heti VC mérés → kritikus / warn
CREATE OR REPLACE FUNCTION public.weekly_vc_alarm_trigger()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
DECLARE
  sev TEXT;
  msg TEXT;
  code TEXT;
BEGIN
  IF NEW.value_mmol_l < 3.9 THEN
    sev := 'critical'; code := 'HYPO'; msg := 'Hypoglikémia: VC ' || NEW.value_mmol_l || ' mmol/L';
  ELSIF NEW.value_mmol_l > 22 THEN
    sev := 'critical'; code := 'HYPER_SEVERE'; msg := 'Súlyos hiperglikémia: VC ' || NEW.value_mmol_l || ' mmol/L';
  ELSIF NEW.value_mmol_l > 15 THEN
    sev := 'warn'; code := 'HYPER'; msg := 'Magas vércukor: ' || NEW.value_mmol_l || ' mmol/L';
  ELSE
    RETURN NEW;
  END IF;
  INSERT INTO public.clinical_critical_alerts
    (patient_id, encounter_id, source, severity, code, message, value_json, created_by)
  VALUES
    (NEW.patient_id, NEW.encounter_id, 'weekly_vc', sev, code, msg,
     jsonb_build_object('value_mmol_l', NEW.value_mmol_l, 'measurement_type', NEW.measurement_type,
                        'measured_at', NEW.measured_at, 'vc_id', NEW.id),
     NEW.created_by);
  RETURN NEW;
END $$;

CREATE TRIGGER trg_weekly_vc_alarm AFTER INSERT ON public.clinical_weekly_vc
  FOR EACH ROW EXECUTE FUNCTION public.weekly_vc_alarm_trigger();

-- 7) Auto-alarm trigger: inzulin session → hypo overlay rögzítés
CREATE OR REPLACE FUNCTION public.insulin_session_alarm_trigger()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF NEW.current_vc IS NOT NULL AND NEW.current_vc < 3.9 THEN
    INSERT INTO public.clinical_critical_alerts
      (patient_id, encounter_id, source, severity, code, message, value_json, created_by)
    VALUES
      (NEW.patient_id, NEW.encounter_id, 'insulin', 'critical', 'HYPO_PRE_BOLUS',
       'Hypoglikémia bólusz előtt: VC ' || NEW.current_vc || ' mmol/L — bólusz tiltva',
       jsonb_build_object('current_vc', NEW.current_vc, 'session_id', NEW.id),
       NEW.created_by);
  END IF;
  RETURN NEW;
END $$;

CREATE TRIGGER trg_insulin_session_alarm AFTER INSERT ON public.clinical_insulin_sessions
  FOR EACH ROW EXECUTE FUNCTION public.insulin_session_alarm_trigger();


-- ─── 20260621083031_d4bbdd24-92d8-4261-abc9-c7a4a5eaf166.sql ───

-- Páciens portál: auth.users ↔ patients link + RLS bővítések

CREATE TABLE public.patient_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  tenant_id uuid REFERENCES public.tenants(id),
  kapcsolat text NOT NULL DEFAULT 'self' CHECK (kapcsolat IN ('self','szulo','gondozo','hozzatartozo','meghatalmazott')),
  verified_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, patient_id)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.patient_users TO authenticated;
GRANT ALL ON public.patient_users TO service_role;

ALTER TABLE public.patient_users ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Felhasználó látja a saját páciens-linkjeit"
  ON public.patient_users FOR SELECT TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Felhasználó létrehozhat saját páciens-linket (self)"
  ON public.patient_users FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid() AND kapcsolat = 'self');

CREATE TRIGGER trg_patient_users_updated_at
  BEFORE UPDATE ON public.patient_users
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Helper: aktuális user által hozzáférhető patient_id-k
CREATE OR REPLACE FUNCTION public.current_user_patient_ids()
RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT patient_id FROM public.patient_users WHERE user_id = auth.uid();
$$;

-- Páciens SELECT policy-k a saját adataihoz (additív, a meglévő staff policy-k mellé)
CREATE POLICY "Páciens látja saját adatát"
  ON public.patients FOR SELECT TO authenticated
  USING (id IN (SELECT public.current_user_patient_ids()));

CREATE POLICY "Páciens látja saját ellátásait"
  ON public.clinical_encounters FOR SELECT TO authenticated
  USING (patient_id IN (SELECT public.current_user_patient_ids()));

CREATE POLICY "Páciens látja saját megfigyeléseit"
  ON public.clinical_observations FOR SELECT TO authenticated
  USING (patient_id IN (SELECT public.current_user_patient_ids()));

CREATE POLICY "Páciens látja saját időpontjait"
  ON public.appointments FOR SELECT TO authenticated
  USING (patient_id IN (SELECT public.current_user_patient_ids()));

CREATE POLICY "Páciens látja saját diagnózisait"
  ON public.clinical_diagnoses FOR SELECT TO authenticated
  USING (patient_id IN (SELECT public.current_user_patient_ids()));

CREATE POLICY "Páciens látja saját kritikus riasztásait"
  ON public.clinical_critical_alerts FOR SELECT TO authenticated
  USING (patient_id IN (SELECT public.current_user_patient_ids()));

-- Időpont kérés workflow
CREATE TABLE public.patient_appointment_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  tenant_id uuid REFERENCES public.tenants(id),
  request_type text NOT NULL CHECK (request_type IN ('new','reschedule','cancel')),
  appointment_id uuid REFERENCES public.appointments(id),
  preferred_slot_id uuid REFERENCES public.appointment_slots(id),
  specialty_id uuid REFERENCES public.specialties(id),
  doctor_user_id uuid REFERENCES auth.users(id),
  urgency text NOT NULL DEFAULT 'normal' CHECK (urgency IN ('low','normal','high','urgent')),
  reason text,
  preferred_datetime timestamptz,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected','rescheduled','cancelled')),
  staff_response text,
  resolved_by uuid REFERENCES auth.users(id),
  resolved_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.patient_appointment_requests TO authenticated;
GRANT ALL ON public.patient_appointment_requests TO service_role;

ALTER TABLE public.patient_appointment_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Páciens kezeli a saját kéréseit"
  ON public.patient_appointment_requests FOR ALL TO authenticated
  USING (user_id = auth.uid() OR patient_id IN (SELECT public.current_user_patient_ids()))
  WITH CHECK (user_id = auth.uid() AND patient_id IN (SELECT public.current_user_patient_ids()));

CREATE TRIGGER trg_patient_appt_req_updated_at
  BEFORE UPDATE ON public.patient_appointment_requests
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- AI lelet-magyarázat cache
CREATE TABLE public.patient_ai_explanations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  source_table text NOT NULL,
  source_id uuid NOT NULL,
  language text NOT NULL DEFAULT 'hu',
  model text NOT NULL,
  prompt_hash text NOT NULL,
  explanation jsonb NOT NULL,
  critical_flags jsonb NOT NULL DEFAULT '[]'::jsonb,
  suggested_specialty_id uuid REFERENCES public.specialties(id),
  expires_at timestamptz NOT NULL DEFAULT (now() + interval '7 days'),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (patient_id, source_table, source_id, prompt_hash, language)
);

GRANT SELECT, INSERT ON public.patient_ai_explanations TO authenticated;
GRANT ALL ON public.patient_ai_explanations TO service_role;

ALTER TABLE public.patient_ai_explanations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Páciens olvashatja saját AI magyarázatait"
  ON public.patient_ai_explanations FOR SELECT TO authenticated
  USING (patient_id IN (SELECT public.current_user_patient_ids()));

-- Életmód napló
CREATE TABLE public.patient_lifestyle_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  logged_at timestamptz NOT NULL DEFAULT now(),
  category text NOT NULL CHECK (category IN ('etel','mozgas','alvas','hangulat','stressz','dohanyzas','alkohol','viz','gyogyszer','egyeb')),
  value_json jsonb NOT NULL DEFAULT '{}'::jsonb,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.patient_lifestyle_log TO authenticated;
GRANT ALL ON public.patient_lifestyle_log TO service_role;

ALTER TABLE public.patient_lifestyle_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Páciens kezeli saját életmód naplóját"
  ON public.patient_lifestyle_log FOR ALL TO authenticated
  USING (user_id = auth.uid() OR patient_id IN (SELECT public.current_user_patient_ids()))
  WITH CHECK (user_id = auth.uid() AND patient_id IN (SELECT public.current_user_patient_ids()));

CREATE INDEX idx_patient_lifestyle_log_patient_date
  ON public.patient_lifestyle_log (patient_id, logged_at DESC);

-- SOS / készenléti kártya
CREATE TABLE public.patient_emergency_card (
  patient_id uuid PRIMARY KEY REFERENCES public.patients(id) ON DELETE CASCADE,
  vercsoport text,
  allergiak text[],
  kronikus_betegsegek text[],
  gyogyszerek text[],
  sos_kontakt_nev text,
  sos_kontakt_telefon text,
  egyeb_info text,
  qr_token text UNIQUE DEFAULT encode(gen_random_bytes(16),'hex'),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.patient_emergency_card TO authenticated;
GRANT ALL ON public.patient_emergency_card TO service_role;

ALTER TABLE public.patient_emergency_card ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Páciens kezeli SOS kártyáját"
  ON public.patient_emergency_card FOR ALL TO authenticated
  USING (patient_id IN (SELECT public.current_user_patient_ids()))
  WITH CHECK (patient_id IN (SELECT public.current_user_patient_ids()));

CREATE TRIGGER trg_patient_emergency_updated_at
  BEFORE UPDATE ON public.patient_emergency_card
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- ─── 20260621102959_30367f80-bd12-44e1-979d-07c126ab83c8.sql ───

-- ============================================================
-- Step 2: Patient module RLS hardening
-- ============================================================

-- ---- patient_users: remove permissive client INSERT (only SECURITY DEFINER server path may insert) ----
DROP POLICY IF EXISTS "Felhasználó létrehozhat saját páciens-linket (self)" ON public.patient_users;

-- Allow patients to DELETE their own link (unlink)
CREATE POLICY "Felhasználó törölheti saját páciens-linkjét"
ON public.patient_users
FOR DELETE
TO authenticated
USING (user_id = auth.uid());

-- ---- measurements: patient can read & insert own ----
CREATE POLICY "Páciens olvashatja saját méréseit"
ON public.measurements
FOR SELECT
TO authenticated
USING (patient_id IN (SELECT current_user_patient_ids()));

CREATE POLICY "Páciens rögzíthet saját mérést"
ON public.measurements
FOR INSERT
TO authenticated
WITH CHECK (patient_id IN (SELECT current_user_patient_ids()));

CREATE POLICY "Páciens módosíthatja saját mérését"
ON public.measurements
FOR UPDATE
TO authenticated
USING (patient_id IN (SELECT current_user_patient_ids()))
WITH CHECK (patient_id IN (SELECT current_user_patient_ids()));

CREATE POLICY "Páciens törölheti saját mérését"
ON public.measurements
FOR DELETE
TO authenticated
USING (patient_id IN (SELECT current_user_patient_ids()));

-- ---- questionnaire_assignments: patient can read own & mark status ----
CREATE POLICY "Páciens olvashatja saját kérdőív kiosztásait"
ON public.questionnaire_assignments
FOR SELECT
TO authenticated
USING (patient_id IN (SELECT current_user_patient_ids()));

CREATE POLICY "Páciens frissítheti saját kérdőív státuszát"
ON public.questionnaire_assignments
FOR UPDATE
TO authenticated
USING (patient_id IN (SELECT current_user_patient_ids()))
WITH CHECK (patient_id IN (SELECT current_user_patient_ids()));

-- ---- questionnaire_responses: patient can insert & read own ----
CREATE POLICY "Páciens olvashatja saját kérdőív válaszait"
ON public.questionnaire_responses
FOR SELECT
TO authenticated
USING (patient_id IN (SELECT current_user_patient_ids()));

CREATE POLICY "Páciens rögzíthet saját kérdőív választ"
ON public.questionnaire_responses
FOR INSERT
TO authenticated
WITH CHECK (patient_id IN (SELECT current_user_patient_ids()));


-- ─── 20260621104219_388c10e1-840e-463c-b20a-d6990a10b85f.sql ───

CREATE TABLE public.patient_referral_requests (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tenant_id UUID,
  patient_id UUID NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  requested_by UUID REFERENCES auth.users(id),
  request_type TEXT NOT NULL CHECK (request_type IN ('referral','prescription','certificate')),
  specialty TEXT,
  reason TEXT NOT NULL,
  notes TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected','fulfilled','cancelled')),
  decision_note TEXT,
  decided_by UUID REFERENCES auth.users(id),
  decided_at TIMESTAMPTZ,
  eeszt_ref TEXT,
  pdf_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.patient_referral_requests TO authenticated;
GRANT ALL ON public.patient_referral_requests TO service_role;

ALTER TABLE public.patient_referral_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Patient sees own referral requests"
ON public.patient_referral_requests FOR SELECT TO authenticated
USING (patient_id IN (SELECT patient_id FROM public.patient_users WHERE user_id = auth.uid()));

CREATE POLICY "Patient creates own referral requests"
ON public.patient_referral_requests FOR INSERT TO authenticated
WITH CHECK (
  patient_id IN (SELECT patient_id FROM public.patient_users WHERE user_id = auth.uid())
  AND requested_by = auth.uid()
);

CREATE POLICY "Staff manages referral requests"
ON public.patient_referral_requests FOR ALL TO authenticated
USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'orvos'))
WITH CHECK (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'orvos'));

CREATE TRIGGER trg_pat_ref_req_updated
BEFORE UPDATE ON public.patient_referral_requests
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE INDEX idx_pat_ref_req_patient ON public.patient_referral_requests(patient_id, created_at DESC);
CREATE INDEX idx_pat_ref_req_status ON public.patient_referral_requests(status, created_at DESC);


-- ─── 20260621104859_6753b561-4178-4cb0-9bbc-1b2d11f7cb44.sql ───

CREATE TABLE public.notification_preferences (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  push_lab_results BOOLEAN NOT NULL DEFAULT true,
  push_messages BOOLEAN NOT NULL DEFAULT true,
  push_appointments BOOLEAN NOT NULL DEFAULT true,
  push_critical_alerts BOOLEAN NOT NULL DEFAULT true,
  push_questionnaire_reminders BOOLEAN NOT NULL DEFAULT true,
  push_lifestyle_tips BOOLEAN NOT NULL DEFAULT false,
  email_weekly_summary BOOLEAN NOT NULL DEFAULT true,
  quiet_hours_start TIME,
  quiet_hours_end TIME,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.notification_preferences TO authenticated;
GRANT ALL ON public.notification_preferences TO service_role;

ALTER TABLE public.notification_preferences ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage own notification prefs"
ON public.notification_preferences FOR ALL TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

CREATE TRIGGER trg_notif_prefs_updated
BEFORE UPDATE ON public.notification_preferences
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- ─── 20260621114327_86419ce3-c9fe-4fb7-ad81-7f42bdf1d779.sql ───

CREATE TABLE public.email_digest_settings (
  tenant_id uuid PRIMARY KEY REFERENCES public.tenants(id) ON DELETE CASCADE,
  enabled boolean NOT NULL DEFAULT false,
  day_of_week smallint NOT NULL DEFAULT 1 CHECK (day_of_week BETWEEN 0 AND 6),
  hour_local smallint NOT NULL DEFAULT 8 CHECK (hour_local BETWEEN 0 AND 23),
  timezone text NOT NULL DEFAULT 'Europe/Budapest',
  recipient_roles text[] NOT NULL DEFAULT ARRAY['tenant_admin','igazgato']::text[],
  include_sections jsonb NOT NULL DEFAULT '{"new_patients":true,"questionnaires":true,"critical_alerts":true,"referrals":true,"eeszt_errors":true}'::jsonb,
  last_sent_at timestamptz,
  updated_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.email_digest_settings TO authenticated;
GRANT ALL ON public.email_digest_settings TO service_role;

ALTER TABLE public.email_digest_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "admins_select_digest" ON public.email_digest_settings
  FOR SELECT TO authenticated
  USING (
    public.has_role(auth.uid(), 'tenant_admin')
    OR public.has_role(auth.uid(), 'igazgato')
  );

CREATE POLICY "admins_upsert_digest" ON public.email_digest_settings
  FOR ALL TO authenticated
  USING (
    public.has_role(auth.uid(), 'tenant_admin')
    OR public.has_role(auth.uid(), 'igazgato')
  )
  WITH CHECK (
    public.has_role(auth.uid(), 'tenant_admin')
    OR public.has_role(auth.uid(), 'igazgato')
  );

CREATE OR REPLACE FUNCTION public.email_digest_settings_touch()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER email_digest_settings_touch
BEFORE UPDATE ON public.email_digest_settings
FOR EACH ROW EXECUTE FUNCTION public.email_digest_settings_touch();


-- ─── 20260621120500_987f7f1d-9990-47fb-b4a7-de72b3626617.sql ───
DO $$ BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.ai_assistant_actions; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
ALTER TABLE public.ai_assistant_actions REPLICA IDENTITY FULL;

-- ─── 20260621123904_92c7717d-06a4-40cf-92e3-229e58884856.sql ───
-- 1) push_settings
CREATE TABLE IF NOT EXISTS public.push_settings (
  tenant_id UUID PRIMARY KEY REFERENCES public.tenants(id) ON DELETE CASCADE,
  vapid_subject TEXT NOT NULL DEFAULT 'mailto:szilikaroly@gmail.com',
  enabled BOOLEAN NOT NULL DEFAULT true,
  updated_by UUID REFERENCES auth.users(id),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.push_settings TO authenticated;
GRANT ALL ON public.push_settings TO service_role;
ALTER TABLE public.push_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "tenant admins read push settings" ON public.push_settings;
CREATE POLICY "tenant admins read push settings"
  ON public.push_settings FOR SELECT TO authenticated
  USING (
    tenant_id = public.current_tenant_id()
    AND (
      public.has_role(auth.uid(), 'tenant_admin')
      OR public.has_role(auth.uid(), 'igazgato')
      OR public.has_permission(auth.uid(), 'manage_tenant')
    )
  );

DROP POLICY IF EXISTS "tenant admins upsert push settings" ON public.push_settings;
CREATE POLICY "tenant admins upsert push settings"
  ON public.push_settings FOR INSERT TO authenticated
  WITH CHECK (
    tenant_id = public.current_tenant_id()
    AND (
      public.has_role(auth.uid(), 'tenant_admin')
      OR public.has_role(auth.uid(), 'igazgato')
      OR public.has_permission(auth.uid(), 'manage_tenant')
    )
  );

DROP POLICY IF EXISTS "tenant admins update push settings" ON public.push_settings;
CREATE POLICY "tenant admins update push settings"
  ON public.push_settings FOR UPDATE TO authenticated
  USING (
    tenant_id = public.current_tenant_id()
    AND (
      public.has_role(auth.uid(), 'tenant_admin')
      OR public.has_role(auth.uid(), 'igazgato')
      OR public.has_permission(auth.uid(), 'manage_tenant')
    )
  )
  WITH CHECK (tenant_id = public.current_tenant_id());

CREATE TRIGGER trg_push_settings_updated
  BEFORE UPDATE ON public.push_settings
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 2) can_access_patient helper
CREATE OR REPLACE FUNCTION public.can_access_patient(_patient_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.patients p
    WHERE p.id = _patient_id
      AND p.tenant_id = public.current_tenant_id()
  ) AND public.has_permission(auth.uid(), 'manage_patients');
$$;
REVOKE EXECUTE ON FUNCTION public.can_access_patient(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.can_access_patient(uuid) TO authenticated, service_role;

-- 3) Klinikai tablak SELECT szigoritasa
DROP POLICY IF EXISTS "auth users read encounters" ON public.clinical_encounters;
CREATE POLICY "tenant read encounters" ON public.clinical_encounters
  FOR SELECT TO authenticated USING (public.can_access_patient(patient_id));

DROP POLICY IF EXISTS "auth users read observations" ON public.clinical_observations;
CREATE POLICY "tenant read observations" ON public.clinical_observations
  FOR SELECT TO authenticated USING (public.can_access_patient(patient_id));

DROP POLICY IF EXISTS "auth users read notes" ON public.clinical_notes;
CREATE POLICY "tenant read notes" ON public.clinical_notes
  FOR SELECT TO authenticated USING (public.can_access_patient(patient_id));

DROP POLICY IF EXISTS "auth users read diagnoses" ON public.clinical_diagnoses;
CREATE POLICY "tenant read diagnoses" ON public.clinical_diagnoses
  FOR SELECT TO authenticated USING (public.can_access_patient(patient_id));

DROP POLICY IF EXISTS "auth users read therapy" ON public.clinical_therapy_orders;
CREATE POLICY "tenant read therapy" ON public.clinical_therapy_orders
  FOR SELECT TO authenticated USING (public.can_access_patient(patient_id));

DROP POLICY IF EXISTS "auth users read calc results" ON public.clinical_calculator_results;
CREATE POLICY "tenant read calc results" ON public.clinical_calculator_results
  FOR SELECT TO authenticated USING (patient_id IS NULL OR public.can_access_patient(patient_id));

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_tables WHERE schemaname='public' AND tablename='clinical_insulin_sessions') THEN
    EXECUTE 'DROP POLICY IF EXISTS "auth users read insulin sessions" ON public.clinical_insulin_sessions';
    EXECUTE 'DROP POLICY IF EXISTS "Authenticated read insulin sessions" ON public.clinical_insulin_sessions';
    EXECUTE 'CREATE POLICY "tenant read insulin sessions" ON public.clinical_insulin_sessions FOR SELECT TO authenticated USING (public.can_access_patient(patient_id))';
  END IF;
  IF EXISTS (SELECT 1 FROM pg_tables WHERE schemaname='public' AND tablename='clinical_weekly_vc') THEN
    EXECUTE 'DROP POLICY IF EXISTS "auth users read weekly vc" ON public.clinical_weekly_vc';
    EXECUTE 'DROP POLICY IF EXISTS "Authenticated read weekly vc" ON public.clinical_weekly_vc';
    EXECUTE 'CREATE POLICY "tenant read weekly vc" ON public.clinical_weekly_vc FOR SELECT TO authenticated USING (public.can_access_patient(patient_id))';
  END IF;
END $$;

-- 4) clinical_drug_statuses: olvasas + szerkesztes szigoritva
DROP POLICY IF EXISTS "Authenticated read drug statuses" ON public.clinical_drug_statuses;
DROP POLICY IF EXISTS "Authenticated upsert drug statuses" ON public.clinical_drug_statuses;
DROP POLICY IF EXISTS "Authenticated update drug statuses" ON public.clinical_drug_statuses;
DROP POLICY IF EXISTS "Author delete drug statuses" ON public.clinical_drug_statuses;

CREATE POLICY "tenant read drug statuses" ON public.clinical_drug_statuses
  FOR SELECT TO authenticated USING (public.can_access_patient(patient_id));
CREATE POLICY "tenant insert drug statuses" ON public.clinical_drug_statuses
  FOR INSERT TO authenticated WITH CHECK (created_by = auth.uid() AND public.can_access_patient(patient_id));
CREATE POLICY "tenant update drug statuses" ON public.clinical_drug_statuses
  FOR UPDATE TO authenticated USING (public.can_access_patient(patient_id))
  WITH CHECK (public.can_access_patient(patient_id));
CREATE POLICY "tenant delete drug statuses" ON public.clinical_drug_statuses
  FOR DELETE TO authenticated USING (public.can_access_patient(patient_id) AND (created_by = auth.uid() OR public.has_role(auth.uid(), 'admin')));

-- 5) realtime.messages deny-by-default (postgres_changes nem erinti)
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='realtime' AND table_name='messages') THEN
    BEGIN
      EXECUTE 'ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY';
      EXECUTE 'DROP POLICY IF EXISTS "deny_broadcast_subscribe" ON realtime.messages';
      EXECUTE 'CREATE POLICY "deny_broadcast_subscribe" ON realtime.messages FOR SELECT TO authenticated USING (false)';
      EXECUTE 'DROP POLICY IF EXISTS "deny_broadcast_send" ON realtime.messages';
      EXECUTE 'CREATE POLICY "deny_broadcast_send" ON realtime.messages FOR INSERT TO authenticated WITH CHECK (false)';
    EXCEPTION WHEN insufficient_privilege THEN
      RAISE NOTICE 'realtime.messages RLS skipped (insufficient privileges)';
    END;
  END IF;
END $$;

-- ─── 20260621152352_6b992c87-b549-4077-9e08-79f33b5cfef9.sql ───

-- ============================================================
-- Follow-up (visszajelentő) rendszer alapinfrastruktúra
-- ============================================================

-- 1) Enumok
DO $$ BEGIN
  CREATE TYPE public.followup_anchor_event AS ENUM (
    'birth', 'surgery_completed', 'discharge', 'visit_completed'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.followup_enrollment_status AS ENUM (
    'active', 'paused', 'completed', 'cancelled'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.followup_occurrence_status AS ENUM (
    'scheduled', 'sent', 'responded', 'missed', 'cancelled'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- qet_event_type enum bővítés
DO $$ BEGIN
  ALTER TYPE public.qet_event_type ADD VALUE IF NOT EXISTS 'birth_recorded';
EXCEPTION WHEN others THEN NULL; END $$;
DO $$ BEGIN
  ALTER TYPE public.qet_event_type ADD VALUE IF NOT EXISTS 'surgery_completed';
EXCEPTION WHEN others THEN NULL; END $$;
DO $$ BEGIN
  ALTER TYPE public.qet_event_type ADD VALUE IF NOT EXISTS 'encounter_discharged';
EXCEPTION WHEN others THEN NULL; END $$;
DO $$ BEGIN
  ALTER TYPE public.qet_event_type ADD VALUE IF NOT EXISTS 'visit_completed';
EXCEPTION WHEN others THEN NULL; END $$;

-- 2) Recall szabály mező a questionnaires-en
ALTER TABLE public.questionnaires
  ADD COLUMN IF NOT EXISTS recall_rules jsonb NOT NULL DEFAULT '{}'::jsonb;

-- 3) followup_protocols
CREATE TABLE IF NOT EXISTS public.followup_protocols (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  kod text NOT NULL,
  nev text NOT NULL,
  leiras text,
  anchor_event public.followup_anchor_event NOT NULL,
  default_window_days integer NOT NULL DEFAULT 365,
  aktiv boolean NOT NULL DEFAULT true,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, kod)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.followup_protocols TO authenticated;
GRANT ALL ON public.followup_protocols TO service_role;
ALTER TABLE public.followup_protocols ENABLE ROW LEVEL SECURITY;

CREATE POLICY "followup_protocols_select"
  ON public.followup_protocols FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());
CREATE POLICY "followup_protocols_write"
  ON public.followup_protocols FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_patients'))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_patients'));

-- 4) followup_protocol_steps
CREATE TABLE IF NOT EXISTS public.followup_protocol_steps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  protocol_id uuid NOT NULL REFERENCES public.followup_protocols(id) ON DELETE CASCADE,
  phase_label text NOT NULL,
  phase_order integer NOT NULL,
  questionnaire_id uuid NOT NULL REFERENCES public.questionnaires(id) ON DELETE RESTRICT,
  offset_days_from integer NOT NULL,
  offset_days_to integer NOT NULL,
  cadence_days integer NOT NULL,
  channel public.reminder_channel NOT NULL DEFAULT 'notification',
  reminder_buckets integer[] NOT NULL DEFAULT ARRAY[1,3]::integer[],
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (offset_days_to >= offset_days_from),
  CHECK (cadence_days > 0)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.followup_protocol_steps TO authenticated;
GRANT ALL ON public.followup_protocol_steps TO service_role;
ALTER TABLE public.followup_protocol_steps ENABLE ROW LEVEL SECURITY;

CREATE POLICY "followup_steps_select"
  ON public.followup_protocol_steps FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.followup_protocols p
                 WHERE p.id = protocol_id AND p.tenant_id = public.current_tenant_id()));
CREATE POLICY "followup_steps_write"
  ON public.followup_protocol_steps FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.followup_protocols p
                 WHERE p.id = protocol_id AND p.tenant_id = public.current_tenant_id()
                 AND public.has_permission(auth.uid(), 'manage_patients')))
  WITH CHECK (EXISTS (SELECT 1 FROM public.followup_protocols p
                      WHERE p.id = protocol_id AND p.tenant_id = public.current_tenant_id()
                      AND public.has_permission(auth.uid(), 'manage_patients')));

-- 5) followup_enrollments
CREATE TABLE IF NOT EXISTS public.followup_enrollments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  protocol_id uuid NOT NULL REFERENCES public.followup_protocols(id) ON DELETE RESTRICT,
  anchor_at timestamptz NOT NULL,
  anchor_ref jsonb NOT NULL DEFAULT '{}'::jsonb,
  status public.followup_enrollment_status NOT NULL DEFAULT 'active',
  paused_reason text,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (patient_id, protocol_id, anchor_at)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.followup_enrollments TO authenticated;
GRANT ALL ON public.followup_enrollments TO service_role;
ALTER TABLE public.followup_enrollments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "followup_enroll_select"
  ON public.followup_enrollments FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id()
         AND (public.has_permission(auth.uid(), 'manage_patients')
              OR public.has_permission(auth.uid(), 'view_patients')));
CREATE POLICY "followup_enroll_write"
  ON public.followup_enrollments FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_patients'))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_patients'));

CREATE INDEX IF NOT EXISTS followup_enroll_status_idx
  ON public.followup_enrollments(tenant_id, status);

-- 6) followup_occurrences
CREATE TABLE IF NOT EXISTS public.followup_occurrences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  enrollment_id uuid NOT NULL REFERENCES public.followup_enrollments(id) ON DELETE CASCADE,
  step_id uuid NOT NULL REFERENCES public.followup_protocol_steps(id) ON DELETE RESTRICT,
  occurrence_index integer NOT NULL,
  due_at timestamptz NOT NULL,
  assignment_id uuid REFERENCES public.questionnaire_assignments(id) ON DELETE SET NULL,
  status public.followup_occurrence_status NOT NULL DEFAULT 'scheduled',
  responded_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (enrollment_id, step_id, occurrence_index)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.followup_occurrences TO authenticated;
GRANT ALL ON public.followup_occurrences TO service_role;
ALTER TABLE public.followup_occurrences ENABLE ROW LEVEL SECURITY;

CREATE POLICY "followup_occ_select"
  ON public.followup_occurrences FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.followup_enrollments e
                 WHERE e.id = enrollment_id
                 AND e.tenant_id = public.current_tenant_id()
                 AND (public.has_permission(auth.uid(), 'manage_patients')
                      OR public.has_permission(auth.uid(), 'view_patients'))));
CREATE POLICY "followup_occ_write"
  ON public.followup_occurrences FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.followup_enrollments e
                 WHERE e.id = enrollment_id
                 AND e.tenant_id = public.current_tenant_id()
                 AND public.has_permission(auth.uid(), 'manage_patients')))
  WITH CHECK (EXISTS (SELECT 1 FROM public.followup_enrollments e
                      WHERE e.id = enrollment_id
                      AND e.tenant_id = public.current_tenant_id()
                      AND public.has_permission(auth.uid(), 'manage_patients')));

CREATE INDEX IF NOT EXISTS followup_occ_due_idx
  ON public.followup_occurrences(status, due_at);

-- 7) updated_at triggerek
CREATE TRIGGER followup_protocols_touch BEFORE UPDATE ON public.followup_protocols
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER followup_steps_touch BEFORE UPDATE ON public.followup_protocol_steps
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER followup_enroll_touch BEFORE UPDATE ON public.followup_enrollments
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER followup_occ_touch BEFORE UPDATE ON public.followup_occurrences
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 8) Idempotens enroll helper
CREATE OR REPLACE FUNCTION public.enroll_followup(
  _tenant_id uuid,
  _patient_id uuid,
  _protocol_kod text,
  _anchor_at timestamptz,
  _anchor_ref jsonb DEFAULT '{}'::jsonb
) RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_protocol_id uuid;
  v_enrollment_id uuid;
BEGIN
  SELECT id INTO v_protocol_id
    FROM public.followup_protocols
   WHERE tenant_id = _tenant_id AND kod = _protocol_kod AND aktiv = true
   LIMIT 1;
  IF v_protocol_id IS NULL THEN RETURN NULL; END IF;

  INSERT INTO public.followup_enrollments
    (tenant_id, patient_id, protocol_id, anchor_at, anchor_ref, status)
  VALUES (_tenant_id, _patient_id, v_protocol_id, _anchor_at, _anchor_ref, 'active')
  ON CONFLICT (patient_id, protocol_id, anchor_at) DO UPDATE SET updated_at = now()
  RETURNING id INTO v_enrollment_id;

  RETURN v_enrollment_id;
END $$;

REVOKE ALL ON FUNCTION public.enroll_followup(uuid, uuid, text, timestamptz, jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.enroll_followup(uuid, uuid, text, timestamptz, jsonb) TO service_role;

-- 9) Fő feldolgozó: generálja a soron következő occurrence-eket és assignment-eket
CREATE OR REPLACE FUNCTION public.process_followup_schedules()
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_enrollment record;
  v_step record;
  v_next_due timestamptz;
  v_idx integer;
  v_assignment_id uuid;
  v_count integer := 0;
  v_token text;
BEGIN
  FOR v_enrollment IN
    SELECT e.* FROM public.followup_enrollments e
     WHERE e.status = 'active'
  LOOP
    FOR v_step IN
      SELECT s.* FROM public.followup_protocol_steps s
       WHERE s.protocol_id = v_enrollment.protocol_id
       ORDER BY s.phase_order ASC
    LOOP
      -- Számolja, hány occurrence van már ehhez a stephez
      SELECT COALESCE(MAX(occurrence_index), -1) + 1
        INTO v_idx
        FROM public.followup_occurrences
       WHERE enrollment_id = v_enrollment.id AND step_id = v_step.id;

      LOOP
        v_next_due := v_enrollment.anchor_at + (v_step.offset_days_from || ' days')::interval
                      + (v_idx * v_step.cadence_days || ' days')::interval;

        -- Ha túllóg a fázis felső határán, kilépünk ebből a stepből
        IF v_next_due > v_enrollment.anchor_at + (v_step.offset_days_to || ' days')::interval THEN
          EXIT;
        END IF;

        -- Csak a jelen + következő 24 órás ablakon belüli due-kat hozzuk létre,
        -- hogy ne túltermeljünk; a cron napi futása fokozatosan tölti fel.
        IF v_next_due > now() + interval '1 day' THEN
          EXIT;
        END IF;

        -- Token generálás (sha256 + random bytes)
        v_token := encode(digest(gen_random_uuid()::text || clock_timestamp()::text, 'sha256'), 'hex');

        -- Assignment létrehozása
        INSERT INTO public.questionnaire_assignments
          (tenant_id, questionnaire_id, patient_id, due_at, status, token, assigned_by)
        VALUES (v_enrollment.tenant_id, v_step.questionnaire_id, v_enrollment.patient_id,
                v_next_due, 'assigned', substr(v_token, 1, 32), v_enrollment.created_by)
        RETURNING id INTO v_assignment_id;

        -- Occurrence rögzítése
        INSERT INTO public.followup_occurrences
          (enrollment_id, step_id, occurrence_index, due_at, assignment_id, status)
        VALUES (v_enrollment.id, v_step.id, v_idx, v_next_due, v_assignment_id, 'sent')
        ON CONFLICT (enrollment_id, step_id, occurrence_index) DO NOTHING;

        v_count := v_count + 1;
        v_idx := v_idx + 1;
      END LOOP;
    END LOOP;

    -- Ellenőrizzük lejárt enrollment-eket
    IF v_enrollment.anchor_at + (
        SELECT MAX(offset_days_to) FROM public.followup_protocol_steps
         WHERE protocol_id = v_enrollment.protocol_id) * interval '1 day' < now() THEN
      UPDATE public.followup_enrollments
         SET status = 'completed', updated_at = now()
       WHERE id = v_enrollment.id AND status = 'active';
    END IF;
  END LOOP;

  -- Lejárt (missed) occurrence-ek
  UPDATE public.followup_occurrences
     SET status = 'missed', updated_at = now()
   WHERE status = 'sent'
     AND due_at < now() - interval '14 days';

  RETURN v_count;
END $$;

REVOKE ALL ON FUNCTION public.process_followup_schedules() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.process_followup_schedules() TO service_role;

-- 10) Trigger: amikor egy assignment-hez tartozó response érkezik, jelöljük responded-ként
CREATE OR REPLACE FUNCTION public.mark_followup_occurrence_responded()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.assignment_id IS NOT NULL THEN
    UPDATE public.followup_occurrences
       SET status = 'responded', responded_at = NEW.completed_at, updated_at = now()
     WHERE assignment_id = NEW.assignment_id;
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_followup_mark_responded ON public.questionnaire_responses;
CREATE TRIGGER trg_followup_mark_responded
  AFTER INSERT ON public.questionnaire_responses
  FOR EACH ROW EXECUTE FUNCTION public.mark_followup_occurrence_responded();

-- 11) Esemény-triggerek a horgony eseményekhez
-- Surgery completed
CREATE OR REPLACE FUNCTION public.trg_surgery_followup_enroll()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_patient_id uuid;
BEGIN
  IF NEW.status = 'completed' AND (OLD.status IS DISTINCT FROM NEW.status) THEN
    -- Megpróbáljuk a páciens id-t az appointment kapcsolatból
    SELECT patient_id INTO v_patient_id FROM public.appointments
     WHERE id = NEW.appointment_id;
    IF v_patient_id IS NOT NULL THEN
      PERFORM public.enroll_followup(
        NEW.tenant_id, v_patient_id, 'postsurgery_symptoms',
        now(), jsonb_build_object('surgery_case_id', NEW.id));
    END IF;
  END IF;
  RETURN NEW;
END $$;

-- A surgery_cases táblának van appointment_id-je? Csak akkor kötjük be, ha igen.
DO $$ BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
     WHERE table_schema='public' AND table_name='surgery_cases' AND column_name='appointment_id'
  ) THEN
    DROP TRIGGER IF EXISTS trg_surgery_followup ON public.surgery_cases;
    CREATE TRIGGER trg_surgery_followup
      AFTER UPDATE ON public.surgery_cases
      FOR EACH ROW EXECUTE FUNCTION public.trg_surgery_followup_enroll();
  END IF;
END $$;

-- Encounter discharged
CREATE OR REPLACE FUNCTION public.trg_encounter_followup_enroll()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.discharged_at IS NOT NULL AND (OLD.discharged_at IS NULL) THEN
    PERFORM public.enroll_followup(
      NEW.tenant_id, NEW.patient_id, 'satisfaction_postvisit',
      NEW.discharged_at + interval '1 day',
      jsonb_build_object('encounter_id', NEW.id));
  END IF;
  RETURN NEW;
END $$;

DO $$ BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
     WHERE table_schema='public' AND table_name='clinical_encounters' AND column_name='discharged_at'
  ) THEN
    DROP TRIGGER IF EXISTS trg_encounter_followup ON public.clinical_encounters;
    CREATE TRIGGER trg_encounter_followup
      AFTER UPDATE ON public.clinical_encounters
      FOR EACH ROW EXECUTE FUNCTION public.trg_encounter_followup_enroll();
  END IF;
END $$;

-- Visit completed (appointments)
CREATE OR REPLACE FUNCTION public.trg_visit_followup_enroll()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.status = 'completed' AND (OLD.status IS DISTINCT FROM NEW.status) AND NEW.patient_id IS NOT NULL THEN
    PERFORM public.enroll_followup(
      NEW.tenant_id, NEW.patient_id, 'satisfaction_postvisit',
      now() + interval '1 day',
      jsonb_build_object('appointment_id', NEW.id));
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_visit_followup ON public.appointments;
CREATE TRIGGER trg_visit_followup
  AFTER UPDATE ON public.appointments
  FOR EACH ROW EXECUTE FUNCTION public.trg_visit_followup_enroll();

-- Obstetric: partogram lezárás → szülés rögzítve
CREATE OR REPLACE FUNCTION public.trg_birth_followup_enroll()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_patient_id uuid;
  v_tenant_id uuid;
BEGIN
  IF NEW.completed_at IS NOT NULL AND (OLD.completed_at IS NULL) THEN
    SELECT patient_id, tenant_id INTO v_patient_id, v_tenant_id
      FROM public.patients WHERE id = NEW.patient_id;
    -- v_patient_id ez maga a NEW.patient_id; tenant_id a partogramon vagy a patient-en
    IF v_tenant_id IS NULL THEN
      v_tenant_id := NEW.tenant_id;
    END IF;
    PERFORM public.enroll_followup(
      v_tenant_id, NEW.patient_id, 'postpartum_mother',
      NEW.completed_at,
      jsonb_build_object('partogram_id', NEW.id));
    -- Gyermek protokoll szintén az anyára indul; a páciens-portál a UI-ban
    -- külön kérdezi rá, ha külön child rekord jön létre.
    PERFORM public.enroll_followup(
      v_tenant_id, NEW.patient_id, 'postpartum_child',
      NEW.completed_at,
      jsonb_build_object('partogram_id', NEW.id, 'subject', 'child'));
  END IF;
  RETURN NEW;
END $$;

DO $$ BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
     WHERE table_schema='public' AND table_name='obstetric_partograms' AND column_name='completed_at'
  ) THEN
    DROP TRIGGER IF EXISTS trg_birth_followup ON public.obstetric_partograms;
    CREATE TRIGGER trg_birth_followup
      AFTER UPDATE ON public.obstetric_partograms
      FOR EACH ROW EXECUTE FUNCTION public.trg_birth_followup_enroll();
  END IF;
END $$;


-- ─── 20260621152619_3ce75efc-5a01-464e-a01a-4bcd99d7123a.sql ───

DO $$
DECLARE
  v_tenant record;
  v_q_mother uuid; v_q_child uuid; v_q_surgery uuid; v_q_sat uuid;
  v_p_mother uuid; v_p_child uuid; v_p_surgery uuid; v_p_sat uuid;
  v_items_mother jsonb := '[{"id":1,"code":"epds_total","text":"Hangulati skála (EPDS rövid 0-30)","type":"number"},{"id":2,"code":"fever_gt_38","text":"Van-e 38°C feletti láza?","type":"yesno"},{"id":3,"code":"heavy_bleeding","text":"Erős vérzés / véralvadékok?","type":"yesno"},{"id":4,"code":"pain_nrs","text":"Fájdalom 0-10","type":"number"},{"id":5,"code":"breastfeeding_ok","text":"Szoptatás megfelelő?","type":"yesno"}]'::jsonb;
  v_items_child jsonb := '[{"id":1,"code":"child_fever_gt_38","text":"38°C feletti láz?","type":"yesno"},{"id":2,"code":"child_milestone_miss","text":"Hány fejlődési mérföldkő hiányzik (0-5)?","type":"number"},{"id":3,"code":"feeding_difficulty","text":"Etetési nehézség 0-3","type":"number"},{"id":4,"code":"weight_concern","text":"Súlygyarapodás aggasztó?","type":"yesno"}]'::jsonb;
  v_items_surgery jsonb := '[{"id":1,"code":"fever_gt_38","text":"38°C feletti láz?","type":"yesno"},{"id":2,"code":"wound_redness","text":"Sebkörnyéki pír 0-3","type":"number"},{"id":3,"code":"pain_nrs","text":"Fájdalom 0-10","type":"number"},{"id":4,"code":"discharge","text":"Sebváladék?","type":"yesno"},{"id":5,"code":"mobility","text":"Mobilitás 0-5","type":"number"}]'::jsonb;
  v_items_sat jsonb := '[{"id":1,"code":"nps","text":"Mennyire ajánlana minket? (0-10)","type":"number"},{"id":2,"code":"communication","text":"Kommunikáció (1-5)","type":"number"},{"id":3,"code":"waiting","text":"Várakozási idő (1-5)","type":"number"},{"id":4,"code":"cleanliness","text":"Tisztaság (1-5)","type":"number"}]'::jsonb;
BEGIN
FOR v_tenant IN SELECT id FROM public.tenants LOOP
  INSERT INTO public.questionnaires (tenant_id, code, title, leiras, language, items, licenc, mode, recall_rules, kioszk_eligible)
  VALUES (v_tenant.id, 'fu_postpartum_mother_v1', 'Szülés utáni állapot — anya',
    'Hetente / havonta / évente jelentkező követés szülés után.', 'hu', v_items_mother, 'free', 'klinikai',
    jsonb_build_object('rules', jsonb_build_array(
      jsonb_build_object('if', jsonb_build_object('code','fever_gt_38','min',1),'then', jsonb_build_object('recall','urgent_24h','specialty','obgyn')),
      jsonb_build_object('if', jsonb_build_object('code','heavy_bleeding','min',1),'then', jsonb_build_object('recall','urgent_24h','specialty','obgyn')),
      jsonb_build_object('if', jsonb_build_object('code','epds_total','min',13),'then', jsonb_build_object('recall','soon_7d','specialty','psy'))
    )), false)
  ON CONFLICT (tenant_id, code, language) DO UPDATE SET title = EXCLUDED.title, recall_rules = EXCLUDED.recall_rules, items = EXCLUDED.items
  RETURNING id INTO v_q_mother;

  INSERT INTO public.questionnaires (tenant_id, code, title, leiras, language, items, licenc, mode, recall_rules, kioszk_eligible)
  VALUES (v_tenant.id, 'fu_postpartum_child_v1', 'Újszülött / gyermek fejlődés',
    'Súly, etetés, fejlődési mérföldkövek, allergiák.', 'hu', v_items_child, 'free', 'klinikai',
    jsonb_build_object('rules', jsonb_build_array(
      jsonb_build_object('if', jsonb_build_object('code','child_fever_gt_38','min',1),'then', jsonb_build_object('recall','urgent_24h','specialty','pediatry')),
      jsonb_build_object('if', jsonb_build_object('code','child_milestone_miss','min',2),'then', jsonb_build_object('recall','soon_14d','specialty','pediatry')),
      jsonb_build_object('if', jsonb_build_object('code','feeding_difficulty','min',2),'then', jsonb_build_object('recall','soon_7d','specialty','pediatry'))
    )), false)
  ON CONFLICT (tenant_id, code, language) DO UPDATE SET title = EXCLUDED.title, recall_rules = EXCLUDED.recall_rules, items = EXCLUDED.items
  RETURNING id INTO v_q_child;

  INSERT INTO public.questionnaires (tenant_id, code, title, leiras, language, items, licenc, mode, recall_rules, kioszk_eligible)
  VALUES (v_tenant.id, 'fu_postsurgery_v1', 'Műtét utáni tünetkövetés',
    'Seb állapota, fájdalom, funkcionális visszanyerés.', 'hu', v_items_surgery, 'free', 'klinikai',
    jsonb_build_object('rules', jsonb_build_array(
      jsonb_build_object('if', jsonb_build_object('code','fever_gt_38','min',1),'then', jsonb_build_object('recall','urgent_24h','specialty','surgery')),
      jsonb_build_object('if', jsonb_build_object('code','wound_redness','min',2),'then', jsonb_build_object('recall','soon_72h','specialty','surgery')),
      jsonb_build_object('if', jsonb_build_object('code','pain_nrs','min',7),'then', jsonb_build_object('recall','soon_72h','specialty','surgery'))
    )), false)
  ON CONFLICT (tenant_id, code, language) DO UPDATE SET title = EXCLUDED.title, recall_rules = EXCLUDED.recall_rules, items = EXCLUDED.items
  RETURNING id INTO v_q_surgery;

  INSERT INTO public.questionnaires (tenant_id, code, title, leiras, language, items, licenc, mode, recall_rules, kioszk_eligible)
  VALUES (v_tenant.id, 'fu_satisfaction_v1', 'Beteg-elégedettség (NPS)',
    'Rövid elégedettségi felmérés vizit után.', 'hu', v_items_sat, 'free', 'egeszsegfejlesztesi', '{}'::jsonb, true)
  ON CONFLICT (tenant_id, code, language) DO UPDATE SET title = EXCLUDED.title, items = EXCLUDED.items
  RETURNING id INTO v_q_sat;

  INSERT INTO public.followup_protocols (tenant_id, kod, nev, leiras, anchor_event, default_window_days)
  VALUES (v_tenant.id, 'postpartum_mother', 'Szülés utáni követés — anya','Heti az 1. hónapban, havi fél évig, évente 5 évig.', 'birth', 1825)
  ON CONFLICT (tenant_id, kod) DO UPDATE SET nev = EXCLUDED.nev RETURNING id INTO v_p_mother;

  INSERT INTO public.followup_protocols (tenant_id, kod, nev, leiras, anchor_event, default_window_days)
  VALUES (v_tenant.id, 'postpartum_child', 'Gyermek fejlődés követése','Heti 3 hónapig, havi 12 hónapig, félévente 18 éves korig.', 'birth', 6570)
  ON CONFLICT (tenant_id, kod) DO UPDATE SET nev = EXCLUDED.nev RETURNING id INTO v_p_child;

  INSERT INTO public.followup_protocols (tenant_id, kod, nev, leiras, anchor_event, default_window_days)
  VALUES (v_tenant.id, 'postsurgery_symptoms', 'Műtét utáni tünetkövetés','Rögzített időpontokban: 1./3./7./14./30./90. nap.', 'surgery_completed', 90)
  ON CONFLICT (tenant_id, kod) DO UPDATE SET nev = EXCLUDED.nev RETURNING id INTO v_p_surgery;

  INSERT INTO public.followup_protocols (tenant_id, kod, nev, leiras, anchor_event, default_window_days)
  VALUES (v_tenant.id, 'satisfaction_postvisit', 'Vizit utáni elégedettség','Egyszeri elégedettségi felmérés vizit után.', 'visit_completed', 7)
  ON CONFLICT (tenant_id, kod) DO UPDATE SET nev = EXCLUDED.nev RETURNING id INTO v_p_sat;

  DELETE FROM public.followup_protocol_steps WHERE protocol_id IN (v_p_mother, v_p_child, v_p_surgery, v_p_sat);

  INSERT INTO public.followup_protocol_steps (protocol_id, phase_label, phase_order, questionnaire_id, offset_days_from, offset_days_to, cadence_days, channel) VALUES
    (v_p_mother, '1. hónap — hetente', 1, v_q_mother, 7, 28, 7, 'notification'),
    (v_p_mother, '2-6. hónap — havonta', 2, v_q_mother, 60, 180, 30, 'notification'),
    (v_p_mother, '1-5. év — évente', 3, v_q_mother, 365, 1825, 365, 'notification'),
    (v_p_child, '0-3. hónap — hetente', 1, v_q_child, 7, 90, 7, 'notification'),
    (v_p_child, '3-12. hónap — havonta', 2, v_q_child, 120, 365, 30, 'notification'),
    (v_p_child, '1-18. év — félévente', 3, v_q_child, 545, 6570, 180, 'notification'),
    (v_p_surgery, '1-3. nap', 1, v_q_surgery, 1, 3, 2, 'push'),
    (v_p_surgery, '7-14. nap', 2, v_q_surgery, 7, 14, 7, 'notification'),
    (v_p_surgery, '30-90. nap', 3, v_q_surgery, 30, 90, 30, 'notification'),
    (v_p_sat, 'Egyszeri visszajelzés', 1, v_q_sat, 1, 1, 1, 'email');
END LOOP;
END $$;


-- ─── 20260621153755_a51b78f1-21f9-471b-aedb-8bf81b94adc6.sql ───
CREATE OR REPLACE FUNCTION public.notify_or_emergency()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_suite_id uuid;
  v_type_nev text;
  v_user record;
BEGIN
  IF NEW.prioritas <> 'azonnali' THEN RETURN NEW; END IF;
  IF TG_OP = 'UPDATE' AND OLD.prioritas = 'azonnali' THEN RETURN NEW; END IF;

  SELECT st.nev INTO v_type_nev FROM public.surgery_types st WHERE st.id = NEW.surgery_type_id;

  SELECT rp.or_suite_id INTO v_suite_id
  FROM public.or_blocks b
  LEFT JOIN public.or_room_profiles rp ON rp.org_unit_id = b.org_unit_id
  WHERE b.id = NEW.or_block_id;

  FOR v_user IN
    SELECT DISTINCT p.id AS user_id
    FROM public.profiles p
    JOIN public.or_staff_pool sp ON sp.user_id = p.id
    WHERE p.tenant_id = NEW.tenant_id
      AND (sp.ervenyes_ig IS NULL OR sp.ervenyes_ig >= current_date)
      AND sp.ervenyes_tol <= current_date
      AND (v_suite_id IS NULL OR sp.or_suite_id = v_suite_id)
      AND EXISTS (
        SELECT 1 FROM public.attendance_events ae
        WHERE ae.user_id = p.id
          AND ae.idopont >= (now() - interval '12 hours')
      )
  LOOP
    INSERT INTO public.notifications (tenant_id, user_id, tipus, cim, uzenet, link)
    VALUES (
      NEW.tenant_id,
      v_user.user_id,
      'or_emergency',
      'Sürgősségi műtét',
      COALESCE(v_type_nev, 'Sürgősségi eset') || ' – azonnali bevonás szükséges',
      '/muteti-terv/blokkok'
    );
  END LOOP;

  RETURN NEW;
END;
$$;

-- ─── 20260621154932_ac2b1133-9574-4fbb-a561-a83c3fb396fc.sql ───

CREATE TABLE IF NOT EXISTS public.error_log (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  code text NOT NULL UNIQUE,
  kind text NOT NULL DEFAULT 'unknown',
  title text,
  message text,
  technical text,
  route text,
  query_params jsonb,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  user_agent text,
  ai_suggestion text,
  ai_suggested_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_error_log_created_at ON public.error_log(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_error_log_kind ON public.error_log(kind);

GRANT SELECT, INSERT, UPDATE ON public.error_log TO authenticated;
GRANT INSERT ON public.error_log TO anon;
GRANT ALL ON public.error_log TO service_role;

ALTER TABLE public.error_log ENABLE ROW LEVEL SECURITY;

-- Anyone (anon + authed) can insert their own error log entries
CREATE POLICY "Anyone can insert error logs"
  ON public.error_log FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

-- Only admins can read
CREATE POLICY "Admins can view error logs"
  ON public.error_log FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

-- Only admins can update (for AI suggestion)
CREATE POLICY "Admins can update error logs"
  ON public.error_log FOR UPDATE
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Generate short support code if not provided
CREATE OR REPLACE FUNCTION public.error_log_set_code()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
DECLARE
  v_try int := 0;
  v_code text;
BEGIN
  IF NEW.code IS NOT NULL AND NEW.code <> '' THEN
    RETURN NEW;
  END IF;
  LOOP
    v_try := v_try + 1;
    v_code := 'ERR-' || upper(substring(encode(gen_random_bytes(4), 'hex') from 1 for 6));
    IF NOT EXISTS (SELECT 1 FROM public.error_log WHERE code = v_code) THEN
      NEW.code := v_code;
      RETURN NEW;
    END IF;
    IF v_try > 5 THEN
      NEW.code := 'ERR-' || upper(substring(encode(gen_random_bytes(8), 'hex') from 1 for 10));
      RETURN NEW;
    END IF;
  END LOOP;
END;
$$;

DROP TRIGGER IF EXISTS trg_error_log_set_code ON public.error_log;
CREATE TRIGGER trg_error_log_set_code
  BEFORE INSERT ON public.error_log
  FOR EACH ROW
  EXECUTE FUNCTION public.error_log_set_code();


-- ─── 20260621160425_19926d89-5447-4347-b123-db0bad28acd6.sql ───

-- 1) Profiles bővítése
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS szuletesi_datum date,
  ADD COLUMN IF NOT EXISTS gyermek_szamok jsonb NOT NULL DEFAULT '[]'::jsonb,
  ADD COLUMN IF NOT EXISTS vezetoi_szint text,
  ADD COLUMN IF NOT EXISTS sugarterheles_kategoria text,
  ADD COLUMN IF NOT EXISTS oktatoi_munkakor boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS klinikai_kombinalt boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS kjt_fizetesi_osztaly text,
  ADD COLUMN IF NOT EXISTS belepes_datum date;

ALTER TABLE public.profile_employment
  ADD COLUMN IF NOT EXISTS oktatoi_munkakor_arany smallint,
  ADD COLUMN IF NOT EXISTS vezetoi_szint text;

ALTER TABLE public.profile_unavailability
  ADD COLUMN IF NOT EXISTS is_kenyszer boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS forrasev integer,
  ADD COLUMN IF NOT EXISTS jogcim text NOT NULL DEFAULT 'alap',
  ADD COLUMN IF NOT EXISTS nap_szam numeric(5,2);

-- 2) leave_policy
CREATE TABLE IF NOT EXISTS public.leave_policy (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  ev integer NOT NULL,
  alapszabadsag_mt integer NOT NULL DEFAULT 20,
  eletkor_pot jsonb NOT NULL DEFAULT '[{"kor":25,"nap":1},{"kor":28,"nap":2},{"kor":31,"nap":3},{"kor":33,"nap":4},{"kor":35,"nap":5},{"kor":37,"nap":6},{"kor":39,"nap":7},{"kor":41,"nap":8},{"kor":43,"nap":9},{"kor":45,"nap":10}]'::jsonb,
  gyermek_pot jsonb NOT NULL DEFAULT '{"1":2,"2":4,"3+":7,"fogyatekos_plusz":2}'::jsonb,
  apasagi_nap integer NOT NULL DEFAULT 10,
  szuloi_nap integer NOT NULL DEFAULT 44,
  eu_alap jsonb NOT NULL DEFAULT '{"alap":20,"felsofoku":21}'::jsonb,
  oktatoi_max integer NOT NULL DEFAULT 25,
  oktatoi_max_targy integer NOT NULL DEFAULT 15,
  vezeto_magas_pot integer NOT NULL DEFAULT 10,
  vezeto_pot integer NOT NULL DEFAULT 5,
  sugar_pot integer NOT NULL DEFAULT 10,
  forced_takeout_deadline_mmdd text NOT NULL DEFAULT '01-30',
  max_carryover_alap_quarter boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, ev)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.leave_policy TO authenticated;
GRANT ALL ON public.leave_policy TO service_role;
ALTER TABLE public.leave_policy ENABLE ROW LEVEL SECURITY;

CREATE POLICY "leave_policy_select_own_tenant" ON public.leave_policy
  FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id());

CREATE POLICY "leave_policy_admin_write" ON public.leave_policy
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_any_role(auth.uid(), ARRAY['tenant_admin','igazgato','intezetvezeto']))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_any_role(auth.uid(), ARRAY['tenant_admin','igazgato','intezetvezeto']));

CREATE TRIGGER trg_leave_policy_updated BEFORE UPDATE ON public.leave_policy
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- 3) leave_entitlement
CREATE TABLE IF NOT EXISTS public.leave_entitlement (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  ev integer NOT NULL,
  jogcim text NOT NULL,
  jaro_nap numeric(6,2) NOT NULL DEFAULT 0,
  manual_korrekcio numeric(6,2) NOT NULL DEFAULT 0,
  athozott_nap numeric(6,2) NOT NULL DEFAULT 0,
  kiadott_nap numeric(6,2) NOT NULL DEFAULT 0,
  terv_nap numeric(6,2) NOT NULL DEFAULT 0,
  forced_taken_nap numeric(6,2) NOT NULL DEFAULT 0,
  hatralevo numeric(6,2) GENERATED ALWAYS AS (jaro_nap + manual_korrekcio + athozott_nap - kiadott_nap - terv_nap) STORED,
  lezart_at timestamptz,
  lezart_by uuid,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, user_id, ev, jogcim)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.leave_entitlement TO authenticated;
GRANT ALL ON public.leave_entitlement TO service_role;
ALTER TABLE public.leave_entitlement ENABLE ROW LEVEL SECURITY;

CREATE POLICY "leave_ent_select_own_or_hr" ON public.leave_entitlement
  FOR SELECT TO authenticated
  USING (
    tenant_id = public.current_tenant_id()
    AND (user_id = auth.uid()
         OR public.has_any_role(auth.uid(), ARRAY['tenant_admin','igazgato','intezetvezeto','beoszto','foorvos','telephelyvezeto']))
  );

CREATE POLICY "leave_ent_admin_write" ON public.leave_entitlement
  FOR ALL TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_any_role(auth.uid(), ARRAY['tenant_admin','igazgato','intezetvezeto','beoszto','foorvos']))
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_any_role(auth.uid(), ARRAY['tenant_admin','igazgato','intezetvezeto','beoszto','foorvos']));

CREATE TRIGGER trg_leave_ent_updated BEFORE UPDATE ON public.leave_entitlement
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE INDEX IF NOT EXISTS idx_leave_ent_user_ev ON public.leave_entitlement (user_id, ev);
CREATE INDEX IF NOT EXISTS idx_leave_ent_tenant_ev ON public.leave_entitlement (tenant_id, ev);

-- 4) leave_carryover_log
CREATE TABLE IF NOT EXISTS public.leave_carryover_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  user_id uuid NOT NULL,
  from_year integer NOT NULL,
  to_year integer,
  jogcim text NOT NULL,
  nap numeric(6,2) NOT NULL,
  tipus text NOT NULL CHECK (tipus IN ('carryover','forced_takeout','forfeit','manual_adjust')),
  appointment_id uuid,
  megjegyzes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  created_by uuid
);

GRANT SELECT, INSERT ON public.leave_carryover_log TO authenticated;
GRANT ALL ON public.leave_carryover_log TO service_role;
ALTER TABLE public.leave_carryover_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "leave_log_select_own_or_hr" ON public.leave_carryover_log
  FOR SELECT TO authenticated
  USING (
    tenant_id = public.current_tenant_id()
    AND (user_id = auth.uid()
         OR public.has_any_role(auth.uid(), ARRAY['tenant_admin','igazgato','intezetvezeto','beoszto','foorvos']))
  );

CREATE POLICY "leave_log_insert_hr" ON public.leave_carryover_log
  FOR INSERT TO authenticated
  WITH CHECK (tenant_id = public.current_tenant_id() AND public.has_any_role(auth.uid(), ARRAY['tenant_admin','igazgato','intezetvezeto','beoszto','foorvos']));

CREATE INDEX IF NOT EXISTS idx_leave_log_user ON public.leave_carryover_log (user_id, from_year);

-- 5) recalc függvény (jogcímenkénti járó nap)
CREATE OR REPLACE FUNCTION public.recalc_leave_entitlements(_user_id uuid, _ev integer)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $fn$
DECLARE
  v_prof RECORD;
  v_pol  RECORD;
  v_tenant uuid;
  v_age int;
  v_eletkor_nap numeric := 0;
  v_kor_szabaly jsonb;
  v_gyermek_alap int := 0;
  v_gyermek_fogy int := 0;
  v_gyermek_nap int := 0;
  v_emp RECORD;
  v_jogviszony text;
  v_eu_alap int := 20;
  v_oktatoi_nap int := 0;
  v_vezetoi_nap int := 0;
  v_sugar_nap int := 0;
  v_alap int := 20;
  v_full_year_days int;
  v_worked_days int;
  v_arany numeric := 1;
  v_kid jsonb;
  v_now date := make_date(_ev, 12, 31);
BEGIN
  SELECT * INTO v_prof FROM public.profiles WHERE id = _user_id;
  IF NOT FOUND THEN RETURN; END IF;
  v_tenant := v_prof.tenant_id;

  SELECT * INTO v_pol FROM public.leave_policy WHERE tenant_id = v_tenant AND ev = _ev;
  IF NOT FOUND THEN
    INSERT INTO public.leave_policy (tenant_id, ev) VALUES (v_tenant, _ev)
    ON CONFLICT (tenant_id, ev) DO NOTHING;
    SELECT * INTO v_pol FROM public.leave_policy WHERE tenant_id = v_tenant AND ev = _ev;
  END IF;

  -- elsődleges jogviszony
  SELECT * INTO v_emp FROM public.profile_employment
    WHERE user_id = _user_id AND COALESCE(ervenyes,true)=true
    ORDER BY elsodleges DESC NULLS LAST, kezdo_datum DESC NULLS LAST LIMIT 1;
  v_jogviszony := COALESCE(v_emp.jogviszony_tipus::text, 'munka_tv_kv');

  -- alapszabadság
  IF v_jogviszony = 'egeszsegugyi_szolgalati' THEN
    v_alap := COALESCE((v_pol.eu_alap->>'alap')::int, 20);
    IF v_prof.kjt_fizetesi_osztaly IS NOT NULL AND v_prof.kjt_fizetesi_osztaly ~ '^[E-J]' THEN
      v_alap := COALESCE((v_pol.eu_alap->>'felsofoku')::int, 21);
    END IF;
  ELSIF v_jogviszony = 'kjt_kozalkalmazott' THEN
    v_alap := CASE WHEN v_prof.kjt_fizetesi_osztaly IS NOT NULL AND v_prof.kjt_fizetesi_osztaly ~ '^[E-J]' THEN 21 ELSE 20 END;
  ELSE
    v_alap := v_pol.alapszabadsag_mt;
  END IF;

  -- életkori
  IF v_prof.szuletesi_datum IS NOT NULL THEN
    v_age := _ev - EXTRACT(year FROM v_prof.szuletesi_datum)::int;
    FOR v_kor_szabaly IN SELECT jsonb_array_elements(v_pol.eletkor_pot) LOOP
      IF v_age >= (v_kor_szabaly->>'kor')::int THEN
        v_eletkor_nap := GREATEST(v_eletkor_nap, (v_kor_szabaly->>'nap')::numeric);
      END IF;
    END LOOP;
  END IF;

  -- gyermek pótszabadság
  IF jsonb_typeof(v_prof.gyermek_szamok) = 'array' THEN
    FOR v_kid IN SELECT jsonb_array_elements(v_prof.gyermek_szamok) LOOP
      DECLARE
        d_birth date := NULLIF(v_kid->>'szuletes','')::date;
        d_age int;
      BEGIN
        IF d_birth IS NULL THEN CONTINUE; END IF;
        d_age := _ev - EXTRACT(year FROM d_birth)::int;
        IF d_age <= 16 AND _ev >= EXTRACT(year FROM d_birth)::int THEN
          v_gyermek_alap := v_gyermek_alap + 1;
          IF COALESCE((v_kid->>'fogyatekos')::boolean, false) THEN
            v_gyermek_fogy := v_gyermek_fogy + 1;
          END IF;
        END IF;
      END;
    END LOOP;
    v_gyermek_nap := CASE
      WHEN v_gyermek_alap = 0 THEN 0
      WHEN v_gyermek_alap = 1 THEN COALESCE((v_pol.gyermek_pot->>'1')::int, 2)
      WHEN v_gyermek_alap = 2 THEN COALESCE((v_pol.gyermek_pot->>'2')::int, 4)
      ELSE COALESCE((v_pol.gyermek_pot->>'3+')::int, 7)
    END + v_gyermek_fogy * COALESCE((v_pol.gyermek_pot->>'fogyatekos_plusz')::int, 2);
  END IF;

  -- vezetői vs oktatói (halmozódás: a magasabb)
  IF COALESCE(v_emp.vezetoi_szint, v_prof.vezetoi_szint) = 'magasabb_vezeto' THEN
    v_vezetoi_nap := v_pol.vezeto_magas_pot;
  ELSIF COALESCE(v_emp.vezetoi_szint, v_prof.vezetoi_szint) = 'vezeto' THEN
    v_vezetoi_nap := v_pol.vezeto_pot;
  END IF;

  IF v_prof.oktatoi_munkakor THEN
    v_oktatoi_nap := v_pol.oktatoi_max;
  END IF;

  -- a magasabbat tartjuk meg külön sorként, a kisebbet 0-ra
  IF v_vezetoi_nap >= v_oktatoi_nap THEN
    v_oktatoi_nap := 0;
  ELSE
    v_vezetoi_nap := 0;
  END IF;

  -- sugár pótszabadság
  IF v_prof.sugarterheles_kategoria IS NOT NULL THEN
    v_sugar_nap := v_pol.sugar_pot;
  END IF;

  -- arányosítás belépés/kilépés alapján
  v_full_year_days := (make_date(_ev,12,31) - make_date(_ev,1,1)) + 1;
  v_worked_days := v_full_year_days;
  IF v_prof.belepes_datum IS NOT NULL AND EXTRACT(year FROM v_prof.belepes_datum)::int = _ev THEN
    v_worked_days := (make_date(_ev,12,31) - v_prof.belepes_datum) + 1;
  END IF;
  v_arany := v_worked_days::numeric / v_full_year_days::numeric;

  -- upsert jogcímek
  PERFORM public._upsert_leave_ent(v_tenant, _user_id, _ev, 'alap', ROUND(v_alap * v_arany, 2));
  PERFORM public._upsert_leave_ent(v_tenant, _user_id, _ev, 'eletkor', ROUND(v_eletkor_nap * v_arany, 2));
  PERFORM public._upsert_leave_ent(v_tenant, _user_id, _ev, 'gyermek', ROUND(v_gyermek_nap * v_arany, 2));
  PERFORM public._upsert_leave_ent(v_tenant, _user_id, _ev, 'vezetoi', ROUND(v_vezetoi_nap * v_arany, 2));
  PERFORM public._upsert_leave_ent(v_tenant, _user_id, _ev, 'oktatoi', ROUND(v_oktatoi_nap * v_arany, 2));
  PERFORM public._upsert_leave_ent(v_tenant, _user_id, _ev, 'sugar', ROUND(v_sugar_nap * v_arany, 2));
END;
$fn$;

CREATE OR REPLACE FUNCTION public._upsert_leave_ent(_t uuid, _u uuid, _ev int, _jc text, _jaro numeric)
RETURNS void
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  INSERT INTO public.leave_entitlement (tenant_id, user_id, ev, jogcim, jaro_nap)
  VALUES (_t, _u, _ev, _jc, _jaro)
  ON CONFLICT (tenant_id, user_id, ev, jogcim)
  DO UPDATE SET jaro_nap = EXCLUDED.jaro_nap, updated_at = now();
$$;

-- 6) profile_unavailability trigger: kiadott_nap/terv_nap update
CREATE OR REPLACE FUNCTION public.leave_apply_unavailability()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $fn$
DECLARE
  v_ev int;
  v_napok numeric;
  v_jogcim text;
  v_tenant uuid;
  v_user uuid;
  v_old_status text;
  v_new_status text;
BEGIN
  IF TG_OP = 'DELETE' THEN
    IF OLD.tipus::text <> 'szabadsag' THEN RETURN OLD; END IF;
    v_ev := COALESCE(OLD.forrasev, EXTRACT(year FROM OLD.kezdo_datum)::int);
    v_napok := COALESCE(OLD.nap_szam, (OLD.zaro_datum - OLD.kezdo_datum + 1)::numeric);
    v_jogcim := COALESCE(OLD.jogcim, 'alap');
    IF OLD.status::text = 'jovahagyott' THEN
      UPDATE public.leave_entitlement SET kiadott_nap = GREATEST(0, kiadott_nap - v_napok)
       WHERE tenant_id = OLD.tenant_id AND user_id = OLD.user_id AND ev = v_ev AND jogcim = v_jogcim;
    ELSIF OLD.status::text IN ('tervezett','jovahagyasra_var') THEN
      UPDATE public.leave_entitlement SET terv_nap = GREATEST(0, terv_nap - v_napok)
       WHERE tenant_id = OLD.tenant_id AND user_id = OLD.user_id AND ev = v_ev AND jogcim = v_jogcim;
    END IF;
    RETURN OLD;
  END IF;

  IF NEW.tipus::text <> 'szabadsag' THEN RETURN NEW; END IF;

  -- napszám automatikus számítás munkanapokban (egyszerű: hétvégét levonjuk)
  IF NEW.nap_szam IS NULL THEN
    SELECT COUNT(*)::numeric INTO v_napok
      FROM generate_series(NEW.kezdo_datum, NEW.zaro_datum, interval '1 day') d
      WHERE EXTRACT(isodow FROM d) < 6;
    NEW.nap_szam := v_napok;
  ELSE
    v_napok := NEW.nap_szam;
  END IF;

  IF NEW.forrasev IS NULL THEN
    NEW.forrasev := EXTRACT(year FROM NEW.kezdo_datum)::int;
  END IF;
  v_ev := NEW.forrasev;
  v_jogcim := COALESCE(NEW.jogcim, 'alap');

  IF TG_OP = 'INSERT' THEN
    -- biztosítsuk hogy van entitlement sor
    INSERT INTO public.leave_entitlement (tenant_id, user_id, ev, jogcim, jaro_nap)
    VALUES (NEW.tenant_id, NEW.user_id, v_ev, v_jogcim, 0)
    ON CONFLICT (tenant_id, user_id, ev, jogcim) DO NOTHING;

    IF NEW.status::text = 'jovahagyott' THEN
      UPDATE public.leave_entitlement SET kiadott_nap = kiadott_nap + v_napok
       WHERE tenant_id = NEW.tenant_id AND user_id = NEW.user_id AND ev = v_ev AND jogcim = v_jogcim;
    ELSIF NEW.status::text IN ('tervezett','jovahagyasra_var') THEN
      UPDATE public.leave_entitlement SET terv_nap = terv_nap + v_napok
       WHERE tenant_id = NEW.tenant_id AND user_id = NEW.user_id AND ev = v_ev AND jogcim = v_jogcim;
    END IF;
  ELSIF TG_OP = 'UPDATE' THEN
    -- visszavonjuk a régit, alkalmazzuk az újat
    DECLARE
      old_napok numeric := COALESCE(OLD.nap_szam, (OLD.zaro_datum - OLD.kezdo_datum + 1)::numeric);
      old_ev int := COALESCE(OLD.forrasev, EXTRACT(year FROM OLD.kezdo_datum)::int);
      old_jc text := COALESCE(OLD.jogcim, 'alap');
    BEGIN
      IF OLD.status::text = 'jovahagyott' THEN
        UPDATE public.leave_entitlement SET kiadott_nap = GREATEST(0, kiadott_nap - old_napok)
          WHERE tenant_id = OLD.tenant_id AND user_id = OLD.user_id AND ev = old_ev AND jogcim = old_jc;
      ELSIF OLD.status::text IN ('tervezett','jovahagyasra_var') THEN
        UPDATE public.leave_entitlement SET terv_nap = GREATEST(0, terv_nap - old_napok)
          WHERE tenant_id = OLD.tenant_id AND user_id = OLD.user_id AND ev = old_ev AND jogcim = old_jc;
      END IF;
    END;

    INSERT INTO public.leave_entitlement (tenant_id, user_id, ev, jogcim, jaro_nap)
    VALUES (NEW.tenant_id, NEW.user_id, v_ev, v_jogcim, 0)
    ON CONFLICT (tenant_id, user_id, ev, jogcim) DO NOTHING;

    IF NEW.status::text = 'jovahagyott' THEN
      UPDATE public.leave_entitlement SET kiadott_nap = kiadott_nap + v_napok
       WHERE tenant_id = NEW.tenant_id AND user_id = NEW.user_id AND ev = v_ev AND jogcim = v_jogcim;
    ELSIF NEW.status::text IN ('tervezett','jovahagyasra_var') THEN
      UPDATE public.leave_entitlement SET terv_nap = terv_nap + v_napok
       WHERE tenant_id = NEW.tenant_id AND user_id = NEW.user_id AND ev = v_ev AND jogcim = v_jogcim;
    END IF;
  END IF;

  RETURN NEW;
END;
$fn$;

DROP TRIGGER IF EXISTS trg_leave_apply_unavail ON public.profile_unavailability;
CREATE TRIGGER trg_leave_apply_unavail
  BEFORE INSERT OR UPDATE OR DELETE ON public.profile_unavailability
  FOR EACH ROW EXECUTE FUNCTION public.leave_apply_unavailability();

-- 7) closeYear / enforceForcedTakeout helper függvények
CREATE OR REPLACE FUNCTION public.close_leave_year(_tenant uuid, _ev int, _actor uuid)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $fn$
DECLARE
  v_rec RECORD;
  v_cnt int := 0;
  v_pol RECORD;
  v_max_carry numeric;
BEGIN
  SELECT * INTO v_pol FROM public.leave_policy WHERE tenant_id = _tenant AND ev = _ev;

  FOR v_rec IN
    SELECT * FROM public.leave_entitlement
    WHERE tenant_id = _tenant AND ev = _ev AND hatralevo > 0 AND lezart_at IS NULL
  LOOP
    v_max_carry := v_rec.hatralevo;
    -- alapszabadság 1/4 korlát (Mt. 123. §) ha be van kapcsolva
    IF v_rec.jogcim = 'alap' AND COALESCE(v_pol.max_carryover_alap_quarter, true) THEN
      v_max_carry := LEAST(v_rec.hatralevo, ROUND(v_rec.jaro_nap / 4.0, 2));
    END IF;

    INSERT INTO public.leave_entitlement (tenant_id, user_id, ev, jogcim, jaro_nap, athozott_nap)
    VALUES (_tenant, v_rec.user_id, _ev + 1, v_rec.jogcim, 0, v_max_carry)
    ON CONFLICT (tenant_id, user_id, ev, jogcim)
    DO UPDATE SET athozott_nap = public.leave_entitlement.athozott_nap + v_max_carry, updated_at = now();

    INSERT INTO public.leave_carryover_log (tenant_id, user_id, from_year, to_year, jogcim, nap, tipus, created_by, megjegyzes)
    VALUES (_tenant, v_rec.user_id, _ev, _ev + 1, v_rec.jogcim, v_max_carry, 'carryover', _actor,
            CASE WHEN v_max_carry < v_rec.hatralevo THEN format('Korlát: %s nap nem hozható át', v_rec.hatralevo - v_max_carry) ELSE NULL END);

    IF v_max_carry < v_rec.hatralevo THEN
      INSERT INTO public.leave_carryover_log (tenant_id, user_id, from_year, jogcim, nap, tipus, created_by, megjegyzes)
      VALUES (_tenant, v_rec.user_id, _ev, v_rec.jogcim, v_rec.hatralevo - v_max_carry, 'forfeit', _actor, 'Mt. 123. § alap 1/4 korlát');
    END IF;

    UPDATE public.leave_entitlement SET lezart_at = now(), lezart_by = _actor WHERE id = v_rec.id;
    v_cnt := v_cnt + 1;
  END LOOP;

  RETURN v_cnt;
END;
$fn$;

CREATE OR REPLACE FUNCTION public.enforce_forced_leave_takeout(_tenant uuid, _ev int, _actor uuid, _dry_run boolean DEFAULT false)
RETURNS TABLE(user_id uuid, jogcim text, nap numeric, kezdo date, zaro date, applied boolean)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $fn$
DECLARE
  v_rec RECORD;
  v_start date;
  v_end date;
  v_uid uuid;
  v_napok numeric;
BEGIN
  FOR v_rec IN
    SELECT * FROM public.leave_entitlement
    WHERE tenant_id = _tenant AND ev = _ev + 1
      AND athozott_nap > 0
      AND athozott_nap > (kiadott_nap + forced_taken_nap)
  LOOP
    v_napok := v_rec.athozott_nap - v_rec.kiadott_nap - v_rec.forced_taken_nap;
    IF v_napok <= 0 THEN CONTINUE; END IF;

    -- következő hétköznap
    v_start := CURRENT_DATE;
    WHILE EXTRACT(isodow FROM v_start) > 5 LOOP v_start := v_start + 1; END LOOP;
    v_end := v_start;
    DECLARE
      added numeric := 1;
    BEGIN
      WHILE added < v_napok LOOP
        v_end := v_end + 1;
        IF EXTRACT(isodow FROM v_end) < 6 THEN added := added + 1; END IF;
      END LOOP;
    END;

    user_id := v_rec.user_id;
    jogcim := v_rec.jogcim;
    nap := v_napok;
    kezdo := v_start;
    zaro := v_end;
    applied := NOT _dry_run;

    IF NOT _dry_run THEN
      INSERT INTO public.profile_unavailability
        (tenant_id, user_id, tipus, kezdo_datum, zaro_datum, leiras, status, is_kenyszer, forrasev, jogcim, nap_szam, jovahagyo_id, jovahagyas_at, jovahagyas_indok)
      VALUES (_tenant, v_rec.user_id, 'szabadsag', v_start, v_end,
              format('Előző évi szabadság kényszerkiadása (%s)', _ev),
              'jovahagyott', true, _ev, v_rec.jogcim, v_napok, _actor, now(),
              'Mt./Eszjtv. — tárgyévet követő január 30. határidő');

      UPDATE public.leave_entitlement SET forced_taken_nap = forced_taken_nap + v_napok
        WHERE id = v_rec.id;

      INSERT INTO public.leave_carryover_log (tenant_id, user_id, from_year, to_year, jogcim, nap, tipus, created_by, megjegyzes)
      VALUES (_tenant, v_rec.user_id, _ev, _ev + 1, v_rec.jogcim, v_napok, 'forced_takeout', _actor,
              format('Kényszerkiadás %s — %s', v_start, v_end));
    END IF;

    RETURN NEXT;
  END LOOP;
END;
$fn$;


-- ─── 20260621161732_1049763a-a63c-467d-be05-6baf9842c770.sql ───

-- 1) leave_admin_audit table
CREATE TABLE IF NOT EXISTS public.leave_admin_audit (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  actor_user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  action TEXT NOT NULL CHECK (action IN ('recalc_tenant','close_year','enforce_dry_run','enforce_apply','policy_update')),
  ev INTEGER,
  target_user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  jogcim TEXT,
  nap NUMERIC(6,2),
  before_data JSONB,
  after_data JSONB,
  summary TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT ON public.leave_admin_audit TO authenticated;
GRANT ALL ON public.leave_admin_audit TO service_role;

ALTER TABLE public.leave_admin_audit ENABLE ROW LEVEL SECURITY;

CREATE POLICY "leave_audit_select_authorized"
  ON public.leave_admin_audit FOR SELECT TO authenticated
  USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(), 'manage_leave'));

CREATE INDEX IF NOT EXISTS idx_leave_admin_audit_tenant_created
  ON public.leave_admin_audit (tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_leave_admin_audit_ev
  ON public.leave_admin_audit (tenant_id, ev, created_at DESC);

-- 2) helper to log entries (SECURITY DEFINER bypasses no-INSERT policy)
CREATE OR REPLACE FUNCTION public.log_leave_admin(
  _tenant uuid,
  _actor uuid,
  _action text,
  _ev int,
  _target_user uuid,
  _jogcim text,
  _nap numeric,
  _before jsonb,
  _after jsonb,
  _summary text
) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_id uuid;
BEGIN
  INSERT INTO public.leave_admin_audit
    (tenant_id, actor_user_id, action, ev, target_user_id, jogcim, nap, before_data, after_data, summary)
  VALUES (_tenant, _actor, _action, _ev, _target_user, _jogcim, _nap, _before, _after, _summary)
  RETURNING id INTO v_id;
  RETURN v_id;
END $$;

REVOKE ALL ON FUNCTION public.log_leave_admin(uuid,uuid,text,int,uuid,text,numeric,jsonb,jsonb,text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.log_leave_admin(uuid,uuid,text,int,uuid,text,numeric,jsonb,jsonb,text) TO authenticated, service_role;

-- 3) manage_leave permission, granted to admin/leadership roles
INSERT INTO public.role_permissions (role_kulcs, perm)
SELECT r.kulcs, 'manage_leave'
FROM public.roles r
WHERE r.kulcs IN ('tenant_admin','igazgato','intezetvezeto','telephelyvezeto')
ON CONFLICT DO NOTHING;


-- ─── 20260621165729_202027ae-29f8-4b4e-a685-bf2b198cf101.sql ───

-- 1) clinical_critical_alerts: drop permissive policies, add tenant+permission scoped ones
DROP POLICY IF EXISTS "Authenticated read clinical alerts" ON public.clinical_critical_alerts;
DROP POLICY IF EXISTS "Authenticated insert clinical alerts" ON public.clinical_critical_alerts;
DROP POLICY IF EXISTS "Authenticated ack clinical alerts" ON public.clinical_critical_alerts;

CREATE POLICY "Staff read clinical alerts in own tenant"
ON public.clinical_critical_alerts
FOR SELECT
TO authenticated
USING (public.can_access_patient(patient_id));

CREATE POLICY "Staff insert clinical alerts in own tenant"
ON public.clinical_critical_alerts
FOR INSERT
TO authenticated
WITH CHECK (
  public.can_access_patient(patient_id)
  AND public.has_permission(auth.uid(), 'manage_patients')
);

CREATE POLICY "Staff ack clinical alerts in own tenant"
ON public.clinical_critical_alerts
FOR UPDATE
TO authenticated
USING (
  public.can_access_patient(patient_id)
  AND public.has_permission(auth.uid(), 'manage_patients')
)
WITH CHECK (
  public.can_access_patient(patient_id)
  AND public.has_permission(auth.uid(), 'manage_patients')
);

-- 2) patient_referral_requests: enforce tenant scope on staff policy
DROP POLICY IF EXISTS "Staff manages referral requests" ON public.patient_referral_requests;

CREATE POLICY "Staff manages referral requests in own tenant"
ON public.patient_referral_requests
FOR ALL
TO authenticated
USING (
  tenant_id = public.current_tenant_id()
  AND (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'orvos'))
)
WITH CHECK (
  tenant_id = public.current_tenant_id()
  AND (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'orvos'))
);

-- 3) i18n_missing_keys: anyone can log a missing key (insert), only admins can update/delete; read open (no sensitive data)
DROP POLICY IF EXISTS i18n_missing_keys_all_auth ON public.i18n_missing_keys;

CREATE POLICY i18n_missing_keys_read
ON public.i18n_missing_keys
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY i18n_missing_keys_insert
ON public.i18n_missing_keys
FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY i18n_missing_keys_admin_update
ON public.i18n_missing_keys
FOR UPDATE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY i18n_missing_keys_admin_delete
ON public.i18n_missing_keys
FOR DELETE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- 4) patient_ai_explanations: explicit tenant-scoped staff read
CREATE POLICY "Staff reads patient AI explanations in tenant"
ON public.patient_ai_explanations
FOR SELECT
TO authenticated
USING (public.can_access_patient(patient_id));

-- 5) chat-attachments storage: explicit restrictive UPDATE deny for non-owners
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname='storage' AND tablename='objects'
      AND policyname='chat_attachments_no_replace'
  ) THEN
    EXECUTE $p$
      CREATE POLICY chat_attachments_no_replace
      ON storage.objects
      AS RESTRICTIVE
      FOR UPDATE
      TO authenticated
      USING (
        bucket_id <> 'chat-attachments'
        OR owner = auth.uid()
      )
      WITH CHECK (
        bucket_id <> 'chat-attachments'
        OR owner = auth.uid()
      );
    $p$;
  END IF;
END $$;


-- ─── 20260621170439_e0678496-5c0c-48d9-b94f-34f9ea712874.sql ───

-- 1) Saved views (kedvencek) ----------------------------------------------------
CREATE TABLE public.paciens_360_saved_views (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  patient_id UUID NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  filters JSONB NOT NULL DEFAULT '{}'::jsonb,
  is_default BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX p360_saved_views_user_idx ON public.paciens_360_saved_views(user_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.paciens_360_saved_views TO authenticated;
GRANT ALL ON public.paciens_360_saved_views TO service_role;

ALTER TABLE public.paciens_360_saved_views ENABLE ROW LEVEL SECURITY;

CREATE POLICY "p360_saved_views_owner_all"
  ON public.paciens_360_saved_views FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- 2) Alert workflow status oszlop ----------------------------------------------
ALTER TABLE public.clinical_critical_alerts
  ADD COLUMN IF NOT EXISTS workflow_status TEXT NOT NULL DEFAULT 'open';

-- 3) Alert status log -----------------------------------------------------------
CREATE TABLE public.clinical_alert_status_log (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  alert_id UUID NOT NULL REFERENCES public.clinical_critical_alerts(id) ON DELETE CASCADE,
  actor_id UUID NULL REFERENCES auth.users(id) ON DELETE SET NULL,
  from_status TEXT NULL,
  to_status TEXT NOT NULL,
  note TEXT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX clinical_alert_status_log_alert_idx ON public.clinical_alert_status_log(alert_id, created_at DESC);

GRANT SELECT ON public.clinical_alert_status_log TO authenticated;
GRANT ALL ON public.clinical_alert_status_log TO service_role;

ALTER TABLE public.clinical_alert_status_log ENABLE ROW LEVEL SECURITY;

-- Csak hitelesített felhasználók olvashatják (klinikai napló). Írás csak server fn-en.
CREATE POLICY "alert_status_log_read_authenticated"
  ON public.clinical_alert_status_log FOR SELECT
  TO authenticated
  USING (true);

-- 4) Escalation rules -----------------------------------------------------------
CREATE TABLE public.clinical_alert_escalation_rules (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  severity TEXT NULL,
  source TEXT NULL,
  escalate_after_minutes INTEGER NOT NULL DEFAULT 30,
  target_role TEXT NULL,
  active BOOLEAN NOT NULL DEFAULT true,
  created_by UUID NULL REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX cae_rules_tenant_idx ON public.clinical_alert_escalation_rules(tenant_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.clinical_alert_escalation_rules TO authenticated;
GRANT ALL ON public.clinical_alert_escalation_rules TO service_role;

ALTER TABLE public.clinical_alert_escalation_rules ENABLE ROW LEVEL SECURITY;

CREATE POLICY "cae_rules_read_same_tenant"
  ON public.clinical_alert_escalation_rules FOR SELECT
  TO authenticated
  USING (tenant_id = public.current_tenant_id());

CREATE POLICY "cae_rules_write_admin_or_orvos"
  ON public.clinical_alert_escalation_rules FOR ALL
  TO authenticated
  USING (
    tenant_id = public.current_tenant_id()
    AND (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'orvos'))
  )
  WITH CHECK (
    tenant_id = public.current_tenant_id()
    AND (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'orvos'))
  );

-- 5) updated_at triggers --------------------------------------------------------
CREATE OR REPLACE FUNCTION public.touch_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END $$;

CREATE TRIGGER p360_saved_views_touch
  BEFORE UPDATE ON public.paciens_360_saved_views
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TRIGGER cae_rules_touch
  BEFORE UPDATE ON public.clinical_alert_escalation_rules
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


-- ─── 20260621172301_1f2df645-3ec5-4075-b52e-72a6dea2fa69.sql ───

-- ===== Security finding fixes =====

-- 1) clinical_alert_status_log: restrict to alerts the user can access (via patient)
DROP POLICY IF EXISTS alert_status_log_read_authenticated ON public.clinical_alert_status_log;
CREATE POLICY alert_status_log_read_scoped ON public.clinical_alert_status_log
  FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.clinical_critical_alerts a
    WHERE a.id = clinical_alert_status_log.alert_id
      AND public.can_access_patient(a.patient_id)
  ));

-- Allow the escalation worker (service_role) and authorized writers to insert via existing logic;
-- the application already inserts log rows from server functions, but RLS for INSERT was not defined.
-- Add an INSERT policy bound to patient access AND actor = auth.uid().
DROP POLICY IF EXISTS alert_status_log_insert_scoped ON public.clinical_alert_status_log;
CREATE POLICY alert_status_log_insert_scoped ON public.clinical_alert_status_log
  FOR INSERT TO authenticated
  WITH CHECK (
    actor_id = auth.uid()
    AND EXISTS (
      SELECT 1 FROM public.clinical_critical_alerts a
      WHERE a.id = clinical_alert_status_log.alert_id
        AND public.can_access_patient(a.patient_id)
    )
  );

-- 2) clinical_diagnoses: enforce can_access_patient on writes
DROP POLICY IF EXISTS "auth users insert diagnoses" ON public.clinical_diagnoses;
CREATE POLICY "auth users insert diagnoses" ON public.clinical_diagnoses
  FOR INSERT TO authenticated
  WITH CHECK (
    auth.uid() = created_by
    AND public.can_access_patient(patient_id)
  );

DROP POLICY IF EXISTS "creator updates diagnoses" ON public.clinical_diagnoses;
CREATE POLICY "creator updates diagnoses" ON public.clinical_diagnoses
  FOR UPDATE TO authenticated
  USING (
    (auth.uid() = created_by OR public.has_role(auth.uid(), 'admin'))
    AND public.can_access_patient(patient_id)
  )
  WITH CHECK (public.can_access_patient(patient_id));

DROP POLICY IF EXISTS "creator deletes diagnoses" ON public.clinical_diagnoses;
CREATE POLICY "creator deletes diagnoses" ON public.clinical_diagnoses
  FOR DELETE TO authenticated
  USING (
    (auth.uid() = created_by OR public.has_role(auth.uid(), 'admin'))
    AND public.can_access_patient(patient_id)
  );

-- 3) clinical_encounters: enforce can_access_patient on writes
DROP POLICY IF EXISTS "auth users insert encounters" ON public.clinical_encounters;
CREATE POLICY "auth users insert encounters" ON public.clinical_encounters
  FOR INSERT TO authenticated
  WITH CHECK (
    auth.uid() = created_by
    AND public.can_access_patient(patient_id)
  );

DROP POLICY IF EXISTS "creator updates encounters" ON public.clinical_encounters;
CREATE POLICY "creator updates encounters" ON public.clinical_encounters
  FOR UPDATE TO authenticated
  USING (
    (auth.uid() = created_by OR public.has_role(auth.uid(), 'admin'))
    AND public.can_access_patient(patient_id)
  )
  WITH CHECK (public.can_access_patient(patient_id));

DROP POLICY IF EXISTS "creator deletes encounters" ON public.clinical_encounters;
CREATE POLICY "creator deletes encounters" ON public.clinical_encounters
  FOR DELETE TO authenticated
  USING (
    (auth.uid() = created_by OR public.has_role(auth.uid(), 'admin'))
    AND public.can_access_patient(patient_id)
  );

-- ===== Escalation worker support =====
-- Track when an alert was last auto-evaluated, to avoid relogging on every run
ALTER TABLE public.clinical_critical_alerts
  ADD COLUMN IF NOT EXISTS escalated_at TIMESTAMPTZ;

-- Index to keep the worker query fast
CREATE INDEX IF NOT EXISTS clinical_critical_alerts_workflow_open_idx
  ON public.clinical_critical_alerts (workflow_status, triggered_at)
  WHERE workflow_status IS DISTINCT FROM 'resolved'
    AND workflow_status IS DISTINCT FROM 'escalated';


-- ─── 20260621173133_fc9856b2-aa5e-40c2-a0e3-d44eb03e628c.sql ───

-- clinical_insulin_sessions
DROP POLICY IF EXISTS "Authenticated insert insulin sessions" ON public.clinical_insulin_sessions;
CREATE POLICY "Authenticated insert insulin sessions" ON public.clinical_insulin_sessions
  FOR INSERT TO authenticated
  WITH CHECK (created_by = auth.uid() AND public.can_access_patient(patient_id));

DROP POLICY IF EXISTS "Author update insulin sessions" ON public.clinical_insulin_sessions;
CREATE POLICY "Author update insulin sessions" ON public.clinical_insulin_sessions
  FOR UPDATE TO authenticated
  USING (created_by = auth.uid() AND public.can_access_patient(patient_id))
  WITH CHECK (public.can_access_patient(patient_id));

DROP POLICY IF EXISTS "Author delete insulin sessions" ON public.clinical_insulin_sessions;
CREATE POLICY "Author delete insulin sessions" ON public.clinical_insulin_sessions
  FOR DELETE TO authenticated
  USING (created_by = auth.uid() AND public.can_access_patient(patient_id));

-- clinical_notes
DROP POLICY IF EXISTS "auth users insert notes" ON public.clinical_notes;
CREATE POLICY "auth users insert notes" ON public.clinical_notes
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = author_id AND public.can_access_patient(patient_id));

DROP POLICY IF EXISTS "author updates unsigned notes" ON public.clinical_notes;
CREATE POLICY "author updates unsigned notes" ON public.clinical_notes
  FOR UPDATE TO authenticated
  USING (
    (((auth.uid() = author_id) AND (signed_at IS NULL)) OR public.has_role(auth.uid(), 'admin'))
    AND public.can_access_patient(patient_id)
  )
  WITH CHECK (public.can_access_patient(patient_id));

DROP POLICY IF EXISTS "author deletes unsigned notes" ON public.clinical_notes;
CREATE POLICY "author deletes unsigned notes" ON public.clinical_notes
  FOR DELETE TO authenticated
  USING (
    (((auth.uid() = author_id) AND (signed_at IS NULL)) OR public.has_role(auth.uid(), 'admin'))
    AND public.can_access_patient(patient_id)
  );

-- clinical_observations
DROP POLICY IF EXISTS "auth users insert observations" ON public.clinical_observations;
CREATE POLICY "auth users insert observations" ON public.clinical_observations
  FOR INSERT TO authenticated
  WITH CHECK (
    ((auth.uid() = performer_id) OR (performer_id IS NULL))
    AND public.can_access_patient(patient_id)
  );

DROP POLICY IF EXISTS "performer updates observations" ON public.clinical_observations;
CREATE POLICY "performer updates observations" ON public.clinical_observations
  FOR UPDATE TO authenticated
  USING (
    ((auth.uid() = performer_id) OR public.has_role(auth.uid(), 'admin'))
    AND public.can_access_patient(patient_id)
  )
  WITH CHECK (public.can_access_patient(patient_id));

DROP POLICY IF EXISTS "performer deletes observations" ON public.clinical_observations;
CREATE POLICY "performer deletes observations" ON public.clinical_observations
  FOR DELETE TO authenticated
  USING (
    ((auth.uid() = performer_id) OR public.has_role(auth.uid(), 'admin'))
    AND public.can_access_patient(patient_id)
  );


-- ─── 20260621185226_183978ec-982b-4757-807a-79bf1a0db990.sql ───

-- ============================================================
-- Csapatmenedzsment: staff_import_runs + biztons\u00e1gi RLS jav\u00edt\u00e1sok
-- ============================================================

-- 1) staff_import_runs: HR Excel import audit
CREATE TABLE public.staff_import_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  imported_by uuid NOT NULL REFERENCES auth.users(id) ON DELETE SET NULL,
  file_name text,
  file_hash text,
  total_rows integer NOT NULL DEFAULT 0,
  inserted_rows integer NOT NULL DEFAULT 0,
  updated_rows integer NOT NULL DEFAULT 0,
  skipped_rows integer NOT NULL DEFAULT 0,
  error_rows integer NOT NULL DEFAULT 0,
  summary jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);
CREATE INDEX idx_staff_import_runs_tenant ON public.staff_import_runs(tenant_id, created_at DESC);

GRANT SELECT, INSERT ON public.staff_import_runs TO authenticated;
GRANT ALL ON public.staff_import_runs TO service_role;
ALTER TABLE public.staff_import_runs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "staff_import_runs_select_tenant_admin"
  ON public.staff_import_runs
  FOR SELECT TO authenticated
  USING (tenant_id = current_tenant_id() AND public.has_permission(auth.uid(), 'manage_tenant'));

CREATE POLICY "staff_import_runs_insert_self"
  ON public.staff_import_runs
  FOR INSERT TO authenticated
  WITH CHECK (
    tenant_id = current_tenant_id()
    AND imported_by = auth.uid()
    AND public.has_permission(auth.uid(), 'manage_tenant')
  );

-- 2) RPC: \u00e9ves szabads\u00e1g \u00fajrasz\u00e1mol\u00e1s magyar Mt. szerint
CREATE OR REPLACE FUNCTION public.compute_mt_leave_days(
  _birth date,
  _children_births date[],
  _children_disabled boolean[],
  _year integer
) RETURNS integer
LANGUAGE plpgsql IMMUTABLE
SET search_path = public
AS $$
DECLARE
  stichtag date := make_date(_year, 12, 31);
  age integer;
  base integer := 20;
  age_bonus integer := 0;
  child_bonus integer := 0;
  eligible_children integer := 0;
  disabled_bonus integer := 0;
  i integer;
  c_birth date;
  c_disabled boolean;
  c_age integer;
BEGIN
  IF _birth IS NULL THEN
    RETURN base;
  END IF;
  age := EXTRACT(YEAR FROM age(stichtag, _birth));
  IF age >= 45 THEN age_bonus := 10;
  ELSIF age >= 43 THEN age_bonus := 9;
  ELSIF age >= 41 THEN age_bonus := 8;
  ELSIF age >= 39 THEN age_bonus := 7;
  ELSIF age >= 37 THEN age_bonus := 6;
  ELSIF age >= 35 THEN age_bonus := 5;
  ELSIF age >= 33 THEN age_bonus := 4;
  ELSIF age >= 31 THEN age_bonus := 3;
  ELSIF age >= 28 THEN age_bonus := 2;
  ELSIF age >= 25 THEN age_bonus := 1;
  END IF;

  IF _children_births IS NOT NULL THEN
    FOR i IN 1..array_length(_children_births, 1) LOOP
      c_birth := _children_births[i];
      IF c_birth IS NULL THEN CONTINUE; END IF;
      c_age := EXTRACT(YEAR FROM age(stichtag, c_birth));
      IF c_age < 16 THEN
        eligible_children := eligible_children + 1;
        c_disabled := COALESCE(_children_disabled[i], false);
        IF c_disabled THEN
          disabled_bonus := disabled_bonus + 2;
        END IF;
      END IF;
    END LOOP;
  END IF;

  IF eligible_children >= 3 THEN child_bonus := 7;
  ELSIF eligible_children = 2 THEN child_bonus := 4;
  ELSIF eligible_children = 1 THEN child_bonus := 2;
  END IF;

  RETURN base + age_bonus + child_bonus + disabled_bonus;
END;
$$;

GRANT EXECUTE ON FUNCTION public.compute_mt_leave_days(date, date[], boolean[], integer) TO authenticated, service_role;

-- 3) Biztons\u00e1gi jav\u00edt\u00e1sok: clinical_weekly_vc INSERT
DROP POLICY IF EXISTS "Authenticated insert weekly vc" ON public.clinical_weekly_vc;
CREATE POLICY "Authenticated insert weekly vc"
  ON public.clinical_weekly_vc
  FOR INSERT TO authenticated
  WITH CHECK (created_by = auth.uid() AND can_access_patient(patient_id));

-- 4) obstetric_partograms: tenant-scope a can_access_patient(patient_id)-vel
DROP POLICY IF EXISTS partogram_select ON public.obstetric_partograms;
DROP POLICY IF EXISTS partogram_insert ON public.obstetric_partograms;
DROP POLICY IF EXISTS partogram_update ON public.obstetric_partograms;
DROP POLICY IF EXISTS partogram_delete ON public.obstetric_partograms;

CREATE POLICY partogram_select ON public.obstetric_partograms
  FOR SELECT TO authenticated
  USING (can_access_patient(patient_id));
CREATE POLICY partogram_insert ON public.obstetric_partograms
  FOR INSERT TO authenticated
  WITH CHECK (created_by = auth.uid() AND can_access_patient(patient_id));
CREATE POLICY partogram_update ON public.obstetric_partograms
  FOR UPDATE TO authenticated
  USING (can_access_patient(patient_id))
  WITH CHECK (can_access_patient(patient_id));
CREATE POLICY partogram_delete ON public.obstetric_partograms
  FOR DELETE TO authenticated
  USING (can_access_patient(patient_id) AND (created_by = auth.uid() OR has_permission(auth.uid(),'manage_patients')));

-- 5) obstetric_partogram_entries: a sz\u00fcl\u0151 partogram p\u00e1ciens\u00e9hez kapcsolt tenant-check
DROP POLICY IF EXISTS partogram_entry_select ON public.obstetric_partogram_entries;
DROP POLICY IF EXISTS partogram_entry_insert ON public.obstetric_partogram_entries;
DROP POLICY IF EXISTS partogram_entry_update ON public.obstetric_partogram_entries;
DROP POLICY IF EXISTS partogram_entry_delete ON public.obstetric_partogram_entries;

CREATE POLICY partogram_entry_select ON public.obstetric_partogram_entries
  FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.obstetric_partograms p
    WHERE p.id = obstetric_partogram_entries.partogram_id
      AND can_access_patient(p.patient_id)
  ));
CREATE POLICY partogram_entry_insert ON public.obstetric_partogram_entries
  FOR INSERT TO authenticated
  WITH CHECK (
    created_by = auth.uid()
    AND EXISTS (
      SELECT 1 FROM public.obstetric_partograms p
      WHERE p.id = obstetric_partogram_entries.partogram_id
        AND can_access_patient(p.patient_id)
    )
  );
CREATE POLICY partogram_entry_update ON public.obstetric_partogram_entries
  FOR UPDATE TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.obstetric_partograms p
    WHERE p.id = obstetric_partogram_entries.partogram_id
      AND can_access_patient(p.patient_id)
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM public.obstetric_partograms p
    WHERE p.id = obstetric_partogram_entries.partogram_id
      AND can_access_patient(p.patient_id)
  ));
CREATE POLICY partogram_entry_delete ON public.obstetric_partogram_entries
  FOR DELETE TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.obstetric_partograms p
    WHERE p.id = obstetric_partogram_entries.partogram_id
      AND can_access_patient(p.patient_id)
      AND (obstetric_partogram_entries.created_by = auth.uid() OR has_permission(auth.uid(),'manage_patients'))
  ));

-- 6) patient_referral_requests: has_role -> has_permission(manage_patients) + tenant_id g\u00e1t
DROP POLICY IF EXISTS "Staff manages referral requests in own tenant" ON public.patient_referral_requests;
CREATE POLICY "Staff manages referral requests in own tenant"
  ON public.patient_referral_requests
  FOR ALL TO authenticated
  USING (tenant_id = current_tenant_id() AND has_permission(auth.uid(), 'manage_patients'))
  WITH CHECK (tenant_id = current_tenant_id() AND has_permission(auth.uid(), 'manage_patients'));


-- ─── 20260621190859_a4841ed2-e74e-4e14-9e57-5840abf48530.sql ───

CREATE TABLE public.announcements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  cim text NOT NULL,
  tartalom text NOT NULL,
  prioritas text NOT NULL DEFAULT 'info' CHECK (prioritas IN ('info','warning','critical','success')),
  kategoria text NOT NULL DEFAULT 'hir' CHECK (kategoria IN ('hir','hirdetmeny','esemeny','figyelmeztetes')),
  cel_szerepkorok text[] NOT NULL DEFAULT '{}',
  cel_org_unit_ids uuid[] NOT NULL DEFAULT '{}',
  publikalt boolean NOT NULL DEFAULT true,
  publikalva_tol timestamptz NOT NULL DEFAULT now(),
  publikalva_ig timestamptz,
  link text,
  kep_url text,
  rogzitett boolean NOT NULL DEFAULT false,
  created_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_announcements_tenant_pub ON public.announcements(tenant_id, publikalva_tol DESC) WHERE publikalt = true;

GRANT SELECT, INSERT, UPDATE, DELETE ON public.announcements TO authenticated;
GRANT ALL ON public.announcements TO service_role;
ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;

CREATE POLICY "announcements_select" ON public.announcements
  FOR SELECT TO authenticated
  USING (
    publikalt = true
    AND (publikalva_ig IS NULL OR publikalva_ig > now())
    AND publikalva_tol <= now()
    AND tenant_id IN (SELECT tenant_id FROM public.profiles WHERE id = auth.uid())
    AND (
      cardinality(cel_szerepkorok) = 0
      OR EXISTS (
        SELECT 1 FROM public.user_roles ur
        JOIN public.roles r ON r.id = ur.role_id
        WHERE ur.user_id = auth.uid()
          AND r.kulcs = ANY(cel_szerepkorok)
      )
    )
    AND (
      cardinality(cel_org_unit_ids) = 0
      OR EXISTS (
        SELECT 1 FROM public.profile_employment pe
        WHERE pe.user_id = auth.uid()
          AND pe.org_unit_id = ANY(cel_org_unit_ids)
          AND pe.ervenyes = true
      )
    )
  );

CREATE POLICY "announcements_admin_all" ON public.announcements
  FOR ALL TO authenticated
  USING (
    tenant_id IN (SELECT tenant_id FROM public.profiles WHERE id = auth.uid())
    AND (public.has_role(auth.uid(), 'admin') OR public.has_permission(auth.uid(), 'manage_tenant'))
  )
  WITH CHECK (
    tenant_id IN (SELECT tenant_id FROM public.profiles WHERE id = auth.uid())
    AND (public.has_role(auth.uid(), 'admin') OR public.has_permission(auth.uid(), 'manage_tenant'))
  );

CREATE TRIGGER tg_announcements_updated_at BEFORE UPDATE ON public.announcements
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.announcement_reads (
  announcement_id uuid NOT NULL REFERENCES public.announcements(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  read_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (announcement_id, user_id)
);

GRANT SELECT, INSERT, DELETE ON public.announcement_reads TO authenticated;
GRANT ALL ON public.announcement_reads TO service_role;
ALTER TABLE public.announcement_reads ENABLE ROW LEVEL SECURITY;

CREATE POLICY "announcement_reads_own" ON public.announcement_reads
  FOR ALL TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

CREATE TABLE public.dashboard_widget_prefs (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  config jsonb NOT NULL DEFAULT '{"widgets":[]}'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.dashboard_widget_prefs TO authenticated;
GRANT ALL ON public.dashboard_widget_prefs TO service_role;
ALTER TABLE public.dashboard_widget_prefs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "dashboard_widget_prefs_own" ON public.dashboard_widget_prefs
  FOR ALL TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

CREATE TRIGGER tg_dashboard_widget_prefs_updated_at BEFORE UPDATE ON public.dashboard_widget_prefs
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- ─── 20260621191431_b2556c21-5216-4166-bb9a-361e0b56ee7f.sql ───

-- 1. Drop overlapping permissive policies (loose one wins via OR)
DROP POLICY IF EXISTS "tenant_isolation_fetal_mov" ON public.fetal_movements;
DROP POLICY IF EXISTS "tenant_isolation_menstrual" ON public.menstrual_cycles;
DROP POLICY IF EXISTS "tenant_isolation_mon_alerts" ON public.monitoring_alerts;
DROP POLICY IF EXISTS "tenant_isolation_mon_programs" ON public.monitoring_programs;
DROP POLICY IF EXISTS "tenant_isolation_thresholds" ON public.monitoring_thresholds;
DROP POLICY IF EXISTS "tenant_isolation_qsched" ON public.questionnaire_schedules;
DROP POLICY IF EXISTS "tenant_isolation_stool_log" ON public.stool_log;
DROP POLICY IF EXISTS "tenant_isolation_wearable" ON public.wearable_data;

-- 2. clinical_calculator_results: enforce can_access_patient on INSERT and UPDATE
DROP POLICY IF EXISTS "auth users insert calc results" ON public.clinical_calculator_results;
CREATE POLICY "auth users insert calc results" ON public.clinical_calculator_results
  FOR INSERT TO authenticated
  WITH CHECK (
    auth.uid() = created_by
    AND (patient_id IS NULL OR public.can_access_patient(patient_id))
  );

DROP POLICY IF EXISTS "creator updates calc results" ON public.clinical_calculator_results;
CREATE POLICY "creator updates calc results" ON public.clinical_calculator_results
  FOR UPDATE TO authenticated
  USING (auth.uid() = created_by)
  WITH CHECK (
    auth.uid() = created_by
    AND (patient_id IS NULL OR public.can_access_patient(patient_id))
  );

-- 3. clinical_therapy_orders: enforce can_access_patient on INSERT and UPDATE
DROP POLICY IF EXISTS "auth users insert therapy" ON public.clinical_therapy_orders;
CREATE POLICY "auth users insert therapy" ON public.clinical_therapy_orders
  FOR INSERT TO authenticated
  WITH CHECK (
    auth.uid() = created_by
    AND public.can_access_patient(patient_id)
  );

DROP POLICY IF EXISTS "creator updates therapy" ON public.clinical_therapy_orders;
CREATE POLICY "creator updates therapy" ON public.clinical_therapy_orders
  FOR UPDATE TO authenticated
  USING (auth.uid() = created_by)
  WITH CHECK (
    auth.uid() = created_by
    AND public.can_access_patient(patient_id)
  );

-- 4. email_digest_settings: add tenant filter
DROP POLICY IF EXISTS "admins_select_digest" ON public.email_digest_settings;
CREATE POLICY "admins_select_digest" ON public.email_digest_settings
  FOR SELECT TO authenticated
  USING (
    tenant_id = public.current_tenant_id()
    AND (public.has_role(auth.uid(), 'tenant_admin') OR public.has_role(auth.uid(), 'igazgato'))
  );

DROP POLICY IF EXISTS "admins_upsert_digest" ON public.email_digest_settings;
CREATE POLICY "admins_upsert_digest" ON public.email_digest_settings
  FOR ALL TO authenticated
  USING (
    tenant_id = public.current_tenant_id()
    AND (public.has_role(auth.uid(), 'tenant_admin') OR public.has_role(auth.uid(), 'igazgato'))
  )
  WITH CHECK (
    tenant_id = public.current_tenant_id()
    AND (public.has_role(auth.uid(), 'tenant_admin') OR public.has_role(auth.uid(), 'igazgato'))
  );

-- 5. clinical_alert_escalation_rules: replace has_role with has_permission + tenant
DROP POLICY IF EXISTS "cae_rules_write_admin_or_orvos" ON public.clinical_alert_escalation_rules;
CREATE POLICY "cae_rules_write_admin_or_orvos" ON public.clinical_alert_escalation_rules
  FOR ALL TO authenticated
  USING (
    tenant_id = public.current_tenant_id()
    AND public.has_permission(auth.uid(), 'manage_tenant')
  )
  WITH CHECK (
    tenant_id = public.current_tenant_id()
    AND public.has_permission(auth.uid(), 'manage_tenant')
  );

-- 6. i18n_translations: restrict writes to manage_tenant
DROP POLICY IF EXISTS "tenant members write i18n" ON public.i18n_translations;
CREATE POLICY "tenant members write i18n" ON public.i18n_translations
  FOR ALL TO authenticated
  USING (
    (tenant_id IS NULL OR tenant_id = public.current_tenant_id())
    AND public.has_permission(auth.uid(), 'manage_tenant')
  )
  WITH CHECK (
    (tenant_id IS NULL OR tenant_id = public.current_tenant_id())
    AND public.has_permission(auth.uid(), 'manage_tenant')
  );

-- 7. translation_glossary: restrict writes to manage_tenant
DROP POLICY IF EXISTS "tenant members write glossary" ON public.translation_glossary;
CREATE POLICY "tenant members write glossary" ON public.translation_glossary
  FOR ALL TO authenticated
  USING (
    (tenant_id IS NULL OR tenant_id = public.current_tenant_id())
    AND public.has_permission(auth.uid(), 'manage_tenant')
  )
  WITH CHECK (
    (tenant_id IS NULL OR tenant_id = public.current_tenant_id())
    AND public.has_permission(auth.uid(), 'manage_tenant')
  );

-- 8. questionnaire_assignments: require manage_patients permission for writes
DROP POLICY IF EXISTS "qa_write_auth" ON public.questionnaire_assignments;
CREATE POLICY "qa_write_auth" ON public.questionnaire_assignments
  FOR ALL TO authenticated
  USING (
    tenant_id = public.current_tenant_id()
    AND public.has_permission(auth.uid(), 'manage_patients')
  )
  WITH CHECK (
    tenant_id = public.current_tenant_id()
    AND public.has_permission(auth.uid(), 'manage_patients')
  );

-- 9. user_roles bootstrap: only allow when the target tenant has zero existing roles AND the user's profile is attached to it
DROP POLICY IF EXISTS "user_roles_bootstrap_admin" ON public.user_roles;
CREATE POLICY "user_roles_bootstrap_admin" ON public.user_roles
  FOR INSERT TO authenticated
  WITH CHECK (
    user_id = auth.uid()
    AND role_id IN (SELECT id FROM public.roles WHERE kulcs = 'tenant_admin')
    AND EXISTS (
      SELECT 1 FROM public.profiles p
      WHERE p.id = auth.uid() AND p.tenant_id = user_roles.tenant_id
    )
    AND NOT EXISTS (
      SELECT 1 FROM public.user_roles ur
      WHERE ur.tenant_id = user_roles.tenant_id
    )
  );


-- ─── 20260621203802_9389ee12-a438-42ae-b9be-2b3679e64476.sql ───
-- Phase 1: allow users to update only the megjegyzes field on their own schedule rows

CREATE POLICY "sa_user_update_own_note"
  ON public.schedule_assignments
  FOR UPDATE
  TO authenticated
  USING (tenant_id = current_tenant_id() AND user_id = auth.uid())
  WITH CHECK (tenant_id = current_tenant_id() AND user_id = auth.uid());

CREATE OR REPLACE FUNCTION public.enforce_user_only_megjegyzes_update()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Admins / schedule managers may update anything (their own policy already covers them)
  IF has_permission(auth.uid(), 'manage_schedule') OR has_permission(auth.uid(), 'manage_tenant') THEN
    RETURN NEW;
  END IF;

  -- For the owner editing their own row: only megjegyzes may change
  IF NEW.user_id = auth.uid() AND OLD.user_id = auth.uid() THEN
    IF NEW.tenant_id     IS DISTINCT FROM OLD.tenant_id
    OR NEW.user_id       IS DISTINCT FROM OLD.user_id
    OR NEW.org_unit_id   IS DISTINCT FROM OLD.org_unit_id
    OR NEW.site_id       IS DISTINCT FROM OLD.site_id
    OR NEW.feladatkor_id IS DISTINCT FROM OLD.feladatkor_id
    OR NEW.kezdo_idopont IS DISTINCT FROM OLD.kezdo_idopont
    OR NEW.zaro_idopont  IS DISTINCT FROM OLD.zaro_idopont
    OR NEW.ora           IS DISTINCT FROM OLD.ora
    OR NEW.kategoria     IS DISTINCT FROM OLD.kategoria
    OR NEW.status        IS DISTINCT FROM OLD.status
    OR NEW.pin           IS DISTINCT FROM OLD.pin
    OR NEW.forras        IS DISTINCT FROM OLD.forras
    OR NEW.created_by    IS DISTINCT FROM OLD.created_by
    OR NEW.run_id        IS DISTINCT FROM OLD.run_id THEN
      RAISE EXCEPTION 'Csak a megjegyzés módosítható a saját beosztáson.';
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS sa_enforce_user_note_only ON public.schedule_assignments;
CREATE TRIGGER sa_enforce_user_note_only
  BEFORE UPDATE ON public.schedule_assignments
  FOR EACH ROW
  EXECUTE FUNCTION public.enforce_user_only_megjegyzes_update();

-- ─── 20260621204416_8c7ee744-1f74-47fc-9c87-40be05c793e5.sql ───
-- =========================================================================
-- Phase 2: schedule_change_requests + skill check + change notifications
-- =========================================================================

-- 1) Enums
DO $$ BEGIN
  CREATE TYPE public.schedule_change_request_type AS ENUM ('cancel', 'swap');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.schedule_change_request_status AS ENUM ('pending', 'approved', 'rejected', 'cancelled');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- 2) Table
CREATE TABLE IF NOT EXISTS public.schedule_change_requests (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id        uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  assignment_id    uuid NOT NULL REFERENCES public.schedule_assignments(id) ON DELETE CASCADE,
  requester_id     uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  request_type     public.schedule_change_request_type NOT NULL,
  target_user_id   uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  reason           text,
  status           public.schedule_change_request_status NOT NULL DEFAULT 'pending',
  decided_by       uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  decided_at       timestamptz,
  decision_note    text,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT scr_swap_needs_target CHECK (
    (request_type = 'swap'   AND target_user_id IS NOT NULL)
 OR (request_type = 'cancel' AND target_user_id IS NULL)
  )
);

CREATE INDEX IF NOT EXISTS idx_scr_assignment ON public.schedule_change_requests(assignment_id);
CREATE INDEX IF NOT EXISTS idx_scr_requester  ON public.schedule_change_requests(requester_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_scr_target     ON public.schedule_change_requests(target_user_id) WHERE target_user_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_scr_pending    ON public.schedule_change_requests(tenant_id, status) WHERE status = 'pending';

-- 3) Grants (BEFORE RLS)
GRANT SELECT, INSERT, UPDATE, DELETE ON public.schedule_change_requests TO authenticated;
GRANT ALL ON public.schedule_change_requests TO service_role;

-- 4) RLS
ALTER TABLE public.schedule_change_requests ENABLE ROW LEVEL SECURITY;

-- SELECT: requester, target user, managers, admin
CREATE POLICY "scr_select"
  ON public.schedule_change_requests
  FOR SELECT TO authenticated
  USING (
    tenant_id = current_tenant_id() AND (
      requester_id = auth.uid()
      OR target_user_id = auth.uid()
      OR has_permission(auth.uid(), 'manage_schedule')
      OR has_permission(auth.uid(), 'manage_tenant')
    )
  );

-- INSERT: requester for OWN assignment, only when status is pending and no other pending exists
CREATE POLICY "scr_insert_own"
  ON public.schedule_change_requests
  FOR INSERT TO authenticated
  WITH CHECK (
    tenant_id = current_tenant_id()
    AND requester_id = auth.uid()
    AND status = 'pending'
    AND EXISTS (
      SELECT 1 FROM public.schedule_assignments sa
      WHERE sa.id = assignment_id AND sa.user_id = auth.uid()
    )
  );

-- UPDATE: requester can cancel own pending request; manager can decide
CREATE POLICY "scr_update_requester_cancel"
  ON public.schedule_change_requests
  FOR UPDATE TO authenticated
  USING (
    tenant_id = current_tenant_id()
    AND requester_id = auth.uid()
    AND status = 'pending'
  )
  WITH CHECK (
    tenant_id = current_tenant_id()
    AND requester_id = auth.uid()
    AND status IN ('pending','cancelled')
  );

CREATE POLICY "scr_update_manager"
  ON public.schedule_change_requests
  FOR UPDATE TO authenticated
  USING (
    tenant_id = current_tenant_id()
    AND (has_permission(auth.uid(), 'manage_schedule') OR has_permission(auth.uid(), 'manage_tenant'))
  )
  WITH CHECK (
    tenant_id = current_tenant_id()
    AND (has_permission(auth.uid(), 'manage_schedule') OR has_permission(auth.uid(), 'manage_tenant'))
  );

-- 5) Trigger: validate swap target has compatible skill (worked same feladatkor in last 12 months)
CREATE OR REPLACE FUNCTION public.validate_swap_request()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_feladatkor uuid;
  v_match int;
BEGIN
  IF NEW.request_type <> 'swap' THEN
    RETURN NEW;
  END IF;

  IF NEW.target_user_id = NEW.requester_id THEN
    RAISE EXCEPTION 'A célfelhasználó nem lehet azonos a kérelmezővel.';
  END IF;

  SELECT feladatkor_id INTO v_feladatkor
  FROM public.schedule_assignments WHERE id = NEW.assignment_id;

  -- If assignment has no feladatkor, require manager skill verification (block self-service swap)
  IF v_feladatkor IS NULL THEN
    RAISE EXCEPTION 'Ehhez a műszakhoz nincs feladatkör rendelve, csere csak vezetővel egyeztetve lehetséges.';
  END IF;

  SELECT count(*) INTO v_match
  FROM public.schedule_assignments
  WHERE user_id = NEW.target_user_id
    AND feladatkor_id = v_feladatkor
    AND kezdo_idopont >= now() - interval '12 months';

  IF v_match = 0 THEN
    RAISE EXCEPTION 'A választott felhasználó nem rendelkezik a szükséges tapasztalattal ehhez a feladatkörhöz (utolsó 12 hónap).';
  END IF;

  RETURN NEW;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.validate_swap_request() FROM PUBLIC, anon;

DROP TRIGGER IF EXISTS scr_validate_swap ON public.schedule_change_requests;
CREATE TRIGGER scr_validate_swap
  BEFORE INSERT ON public.schedule_change_requests
  FOR EACH ROW EXECUTE FUNCTION public.validate_swap_request();

-- 6) Trigger: touch updated_at + set decided_at when status leaves 'pending' by manager
CREATE OR REPLACE FUNCTION public.scr_touch_decided()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  IF NEW.status IS DISTINCT FROM OLD.status
     AND NEW.status IN ('approved','rejected')
     AND NEW.decided_at IS NULL THEN
    NEW.decided_at = now();
    NEW.decided_by = COALESCE(NEW.decided_by, auth.uid());
  END IF;
  RETURN NEW;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.scr_touch_decided() FROM PUBLIC, anon;

DROP TRIGGER IF EXISTS scr_touch ON public.schedule_change_requests;
CREATE TRIGGER scr_touch
  BEFORE UPDATE ON public.schedule_change_requests
  FOR EACH ROW EXECUTE FUNCTION public.scr_touch_decided();

-- 7) Trigger: notify requester + target on request lifecycle, notify managers on new pending
CREATE OR REPLACE FUNCTION public.notify_scr_lifecycle()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_label text;
  v_when  timestamptz;
  v_mgr   uuid;
BEGIN
  SELECT sa.kezdo_idopont INTO v_when
  FROM public.schedule_assignments sa WHERE sa.id = NEW.assignment_id;

  v_label := to_char(v_when AT TIME ZONE 'Europe/Budapest', 'YYYY-MM-DD HH24:MI');

  IF TG_OP = 'INSERT' THEN
    -- Notify all managers in tenant
    FOR v_mgr IN
      SELECT ur.user_id FROM public.user_roles ur
      WHERE ur.tenant_id = NEW.tenant_id
        AND (has_permission(ur.user_id, 'manage_schedule') OR has_permission(ur.user_id, 'manage_tenant'))
    LOOP
      INSERT INTO public.notifications(tenant_id, user_id, tipus, cim, uzenet, link)
      VALUES (NEW.tenant_id, v_mgr, 'beosztas_keres',
        CASE NEW.request_type WHEN 'cancel' THEN 'Új lemondási kérés' ELSE 'Új csere kérés' END,
        'Műszak: ' || v_label || ' – jóváhagyásra vár',
        '/beosztas');
    END LOOP;
    -- Notify target on swap
    IF NEW.request_type = 'swap' AND NEW.target_user_id IS NOT NULL THEN
      INSERT INTO public.notifications(tenant_id, user_id, tipus, cim, uzenet, link)
      VALUES (NEW.tenant_id, NEW.target_user_id, 'beosztas_keres',
        'Csereajánlat érkezett',
        'Egy kollégád felajánlotta a műszakát ('|| v_label ||') cserére.',
        '/beosztas');
    END IF;

  ELSIF TG_OP = 'UPDATE' AND NEW.status IS DISTINCT FROM OLD.status THEN
    -- Notify requester about decision
    INSERT INTO public.notifications(tenant_id, user_id, tipus, cim, uzenet, link)
    VALUES (NEW.tenant_id, NEW.requester_id, 'beosztas_keres',
      CASE NEW.status
        WHEN 'approved' THEN 'Kérelmed jóváhagyva'
        WHEN 'rejected' THEN 'Kérelmed elutasítva'
        WHEN 'cancelled' THEN 'Kérelmed visszavonva'
        ELSE 'Kérelem státusza módosult'
      END,
      'Műszak: ' || v_label || COALESCE(' – ' || NEW.decision_note, ''),
      '/beosztas');
  END IF;

  RETURN NEW;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.notify_scr_lifecycle() FROM PUBLIC, anon;

DROP TRIGGER IF EXISTS scr_notify ON public.schedule_change_requests;
CREATE TRIGGER scr_notify
  AFTER INSERT OR UPDATE ON public.schedule_change_requests
  FOR EACH ROW EXECUTE FUNCTION public.notify_scr_lifecycle();

-- 8) Trigger: notify owner when their assignment time/status/category changes
CREATE OR REPLACE FUNCTION public.notify_assignment_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_changes text[] := ARRAY[]::text[];
  v_msg text;
BEGIN
  IF NEW.user_id IS NULL THEN RETURN NEW; END IF;
  IF auth.uid() IS NOT NULL AND NEW.user_id = auth.uid() THEN
    -- Owner edited own row (e.g. note), skip self-notification
    RETURN NEW;
  END IF;

  IF NEW.kezdo_idopont IS DISTINCT FROM OLD.kezdo_idopont
     OR NEW.zaro_idopont IS DISTINCT FROM OLD.zaro_idopont THEN
    v_changes := array_append(v_changes,
      'Új időpont: ' || to_char(NEW.kezdo_idopont AT TIME ZONE 'Europe/Budapest','YYYY-MM-DD HH24:MI')
       || '–' || to_char(NEW.zaro_idopont AT TIME ZONE 'Europe/Budapest','HH24:MI'));
  END IF;
  IF NEW.status IS DISTINCT FROM OLD.status THEN
    v_changes := array_append(v_changes, 'Státusz: ' || NEW.status::text);
  END IF;
  IF NEW.kategoria IS DISTINCT FROM OLD.kategoria THEN
    v_changes := array_append(v_changes, 'Kategória: ' || NEW.kategoria::text);
  END IF;

  IF array_length(v_changes, 1) IS NULL THEN
    RETURN NEW;
  END IF;

  v_msg := array_to_string(v_changes, ' • ');

  INSERT INTO public.notifications(tenant_id, user_id, tipus, cim, uzenet, link)
  VALUES (NEW.tenant_id, NEW.user_id, 'beosztas',
    'Beosztásod változott',
    v_msg,
    '/iranyitopult');

  RETURN NEW;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.notify_assignment_change() FROM PUBLIC, anon;

DROP TRIGGER IF EXISTS sa_notify_change ON public.schedule_assignments;
CREATE TRIGGER sa_notify_change
  AFTER UPDATE ON public.schedule_assignments
  FOR EACH ROW EXECUTE FUNCTION public.notify_assignment_change();

-- ─── 20260621204454_eb68df68-8cf2-42a5-9565-81d21028a8c2.sql ───
CREATE OR REPLACE FUNCTION public.eligible_swap_targets(_assignment_id uuid)
RETURNS TABLE(user_id uuid, display_name text, last_worked timestamptz)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_feladatkor uuid;
  v_tenant     uuid;
  v_owner      uuid;
BEGIN
  SELECT sa.feladatkor_id, sa.tenant_id, sa.user_id
    INTO v_feladatkor, v_tenant, v_owner
  FROM public.schedule_assignments sa
  WHERE sa.id = _assignment_id;

  IF v_owner IS NULL THEN
    RETURN;
  END IF;

  -- Caller must own the assignment OR be a schedule manager
  IF v_owner <> auth.uid()
     AND NOT has_permission(auth.uid(), 'manage_schedule')
     AND NOT has_permission(auth.uid(), 'manage_tenant') THEN
    RETURN;
  END IF;

  IF v_feladatkor IS NULL THEN
    RETURN;
  END IF;

  RETURN QUERY
  SELECT p.id,
         COALESCE(p.full_name, p.email, 'Felhasználó') AS display_name,
         max(sa2.kezdo_idopont) AS last_worked
  FROM public.schedule_assignments sa2
  JOIN public.profiles p ON p.id = sa2.user_id
  WHERE sa2.tenant_id = v_tenant
    AND sa2.feladatkor_id = v_feladatkor
    AND sa2.kezdo_idopont >= now() - interval '12 months'
    AND sa2.user_id <> v_owner
  GROUP BY p.id, p.full_name, p.email
  ORDER BY display_name;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.eligible_swap_targets(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.eligible_swap_targets(uuid) TO authenticated;

-- ─── 20260621204644_0f35fa6b-1df8-45fe-b3b2-3ef814b95fba.sql ───
CREATE OR REPLACE FUNCTION public.eligible_swap_targets(_assignment_id uuid)
RETURNS TABLE(user_id uuid, display_name text, last_worked timestamptz)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_feladatkor uuid;
  v_tenant     uuid;
  v_owner      uuid;
BEGIN
  SELECT sa.feladatkor_id, sa.tenant_id, sa.user_id
    INTO v_feladatkor, v_tenant, v_owner
  FROM public.schedule_assignments sa
  WHERE sa.id = _assignment_id;

  IF v_owner IS NULL THEN
    RETURN;
  END IF;

  IF v_owner <> auth.uid()
     AND NOT has_permission(auth.uid(), 'manage_schedule')
     AND NOT has_permission(auth.uid(), 'manage_tenant') THEN
    RETURN;
  END IF;

  IF v_feladatkor IS NULL THEN
    RETURN;
  END IF;

  RETURN QUERY
  SELECT p.id,
         COALESCE(NULLIF(p.teljes_nev, ''), p.email, 'Felhasználó') AS display_name,
         max(sa2.kezdo_idopont) AS last_worked
  FROM public.schedule_assignments sa2
  JOIN public.profiles p ON p.id = sa2.user_id
  WHERE sa2.tenant_id = v_tenant
    AND sa2.feladatkor_id = v_feladatkor
    AND sa2.kezdo_idopont >= now() - interval '12 months'
    AND sa2.user_id <> v_owner
  GROUP BY p.id, p.teljes_nev, p.email
  ORDER BY display_name;
END;
$$;

-- ─── 20260621204743_8fe1d70b-926e-47ad-b651-b2de1bb9b2c5.sql ───
CREATE OR REPLACE FUNCTION public.apply_approved_change_request()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.status = 'approved' AND OLD.status <> 'approved' THEN
    IF NEW.request_type = 'cancel' THEN
      UPDATE public.schedule_assignments
         SET status = 'torolt'::assignment_status
       WHERE id = NEW.assignment_id;
    ELSIF NEW.request_type = 'swap' AND NEW.target_user_id IS NOT NULL THEN
      UPDATE public.schedule_assignments
         SET user_id = NEW.target_user_id
       WHERE id = NEW.assignment_id;
    END IF;
  END IF;
  RETURN NEW;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.apply_approved_change_request() FROM PUBLIC, anon;

DROP TRIGGER IF EXISTS scr_apply_approved ON public.schedule_change_requests;
CREATE TRIGGER scr_apply_approved
  AFTER UPDATE ON public.schedule_change_requests
  FOR EACH ROW EXECUTE FUNCTION public.apply_approved_change_request();

-- ─── 20260621210044_3b47f385-0f6d-4cad-9669-4f181abb7f2f.sql ───

-- Link organization OR units to the surgical plan board automatically.
-- An or_room_profile (+ a default or_suite per site) is auto-created for every
-- org_unit of type muto/kismuto, and kept active in sync with the unit.

CREATE OR REPLACE FUNCTION public.ensure_default_or_suite(_tenant_id uuid, _site_id uuid)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _suite_id uuid;
BEGIN
  IF _site_id IS NULL THEN
    RETURN NULL;
  END IF;
  SELECT id INTO _suite_id
    FROM public.or_suites
   WHERE tenant_id = _tenant_id AND site_id = _site_id
   ORDER BY created_at ASC
   LIMIT 1;
  IF _suite_id IS NULL THEN
    INSERT INTO public.or_suites (tenant_id, site_id, nev, aktiv)
    VALUES (_tenant_id, _site_id, 'Központi műtőblokk', true)
    RETURNING id INTO _suite_id;
  END IF;
  RETURN _suite_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.sync_or_room_profile_from_org_unit()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _suite_id uuid;
  _tipus or_tipus_enum;
  _is_or boolean;
BEGIN
  _is_or := NEW.tipus IN ('muto','kismuto');

  -- If unit is no longer an OR or became inactive, deactivate its profile.
  IF NOT _is_or OR NEW.aktiv = false THEN
    UPDATE public.or_room_profiles
       SET aktiv = false, updated_at = now()
     WHERE org_unit_id = NEW.id;
    RETURN NEW;
  END IF;

  IF NEW.site_id IS NULL THEN
    RETURN NEW; -- can't allocate a suite without a site
  END IF;

  _tipus := CASE NEW.tipus
              WHEN 'kismuto' THEN 'egynapos_kismuteti'::or_tipus_enum
              ELSE 'altalanos'::or_tipus_enum
            END;
  _suite_id := public.ensure_default_or_suite(NEW.tenant_id, NEW.site_id);

  INSERT INTO public.or_room_profiles (tenant_id, org_unit_id, or_suite_id, tipus, aktiv)
  VALUES (NEW.tenant_id, NEW.id, _suite_id, _tipus, true)
  ON CONFLICT (org_unit_id) DO UPDATE
    SET aktiv = true,
        or_suite_id = COALESCE(public.or_room_profiles.or_suite_id, EXCLUDED.or_suite_id),
        updated_at = now();

  RETURN NEW;
END;
$$;

-- Need a unique constraint on org_unit_id for ON CONFLICT to work.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes
     WHERE schemaname = 'public'
       AND indexname = 'or_room_profiles_org_unit_id_key'
  ) THEN
    -- Drop any duplicate rows first so the unique index can be created.
    DELETE FROM public.or_room_profiles a
     USING public.or_room_profiles b
     WHERE a.org_unit_id = b.org_unit_id AND a.ctid < b.ctid;
    CREATE UNIQUE INDEX or_room_profiles_org_unit_id_key
      ON public.or_room_profiles (org_unit_id);
  END IF;
END $$;

DROP TRIGGER IF EXISTS trg_sync_or_room_profile ON public.org_units;
CREATE TRIGGER trg_sync_or_room_profile
AFTER INSERT OR UPDATE OF tipus, aktiv, site_id, tenant_id ON public.org_units
FOR EACH ROW EXECUTE FUNCTION public.sync_or_room_profile_from_org_unit();

-- Backfill existing OR units.
INSERT INTO public.or_room_profiles (tenant_id, org_unit_id, or_suite_id, tipus, aktiv)
SELECT u.tenant_id,
       u.id,
       public.ensure_default_or_suite(u.tenant_id, u.site_id),
       CASE u.tipus WHEN 'kismuto' THEN 'egynapos_kismuteti'::or_tipus_enum
                    ELSE 'altalanos'::or_tipus_enum END,
       true
  FROM public.org_units u
 WHERE u.tipus IN ('muto','kismuto')
   AND u.aktiv = true
   AND u.site_id IS NOT NULL
ON CONFLICT (org_unit_id) DO UPDATE
  SET aktiv = true,
      or_suite_id = COALESCE(public.or_room_profiles.or_suite_id, EXCLUDED.or_suite_id),
      updated_at = now();


-- ─── 20260621210503_a4d92518-72c2-41aa-aee3-ef7b79b9dcc2.sql ───

-- Helper: get manager user ids for a tenant who can manage OR blocks
CREATE OR REPLACE FUNCTION public.or_block_managers(_tenant_id uuid)
RETURNS SETOF uuid
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT DISTINCT p.id
    FROM public.profiles p
   WHERE p.tenant_id = _tenant_id
     AND public.has_permission(p.id, 'manage_or_blocks');
$$;

-- 1) Conflict scan + notifications when an OR org_unit is deactivated or
--    its type is changed away from muto/kismuto.
CREATE OR REPLACE FUNCTION public.warn_org_unit_or_deactivation()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _was_or boolean;
  _is_or boolean;
  _affected_blocks int;
  _affected_cases int;
  _mgr uuid;
  _msg text;
BEGIN
  _was_or := OLD.tipus IN ('muto','kismuto') AND OLD.aktiv = true;
  _is_or  := NEW.tipus IN ('muto','kismuto') AND NEW.aktiv = true;
  IF _was_or AND NOT _is_or THEN
    SELECT count(*) INTO _affected_blocks
      FROM public.or_blocks b
     WHERE b.org_unit_id = NEW.id
       AND b.datum >= CURRENT_DATE
       AND b.statusz <> 'felszabaditott';
    SELECT count(*) INTO _affected_cases
      FROM public.surgery_cases c
      JOIN public.or_blocks b ON b.id = c.or_block_id
     WHERE b.org_unit_id = NEW.id
       AND b.datum >= CURRENT_DATE
       AND b.statusz <> 'felszabaditott';

    IF _affected_blocks > 0 OR _affected_cases > 0 THEN
      RAISE WARNING 'Műtő inaktiválás: % jövőbeli blokk és % beosztott eset ütközik (org_unit %).',
        _affected_blocks, _affected_cases, NEW.id;
      _msg := format('A(z) "%s" műtő inaktiválásra került. %s jövőbeli blokk és %s beosztott eset érintett a Blokk-naptárban — kérjük, ellenőrizze.',
                     NEW.nev, _affected_blocks, _affected_cases);
      FOR _mgr IN SELECT public.or_block_managers(NEW.tenant_id) LOOP
        INSERT INTO public.notifications (tenant_id, user_id, tipus, cim, uzenet, link)
        VALUES (NEW.tenant_id, _mgr, 'or_board_conflict',
                'Műtő inaktiválás — ütköző beosztások', _msg, '/muteti-terv/blokkok');
      END LOOP;
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_warn_org_unit_or_deactivation ON public.org_units;
CREATE TRIGGER trg_warn_org_unit_or_deactivation
BEFORE UPDATE OF aktiv, tipus ON public.org_units
FOR EACH ROW EXECUTE FUNCTION public.warn_org_unit_or_deactivation();

-- 2) Notifications when an OR room profile becomes active or inactive.
CREATE OR REPLACE FUNCTION public.notify_or_room_profile_state()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _nev text;
  _mgr uuid;
  _msg text;
  _cim text;
BEGIN
  IF OLD.aktiv IS DISTINCT FROM NEW.aktiv THEN
    SELECT u.nev INTO _nev FROM public.org_units u WHERE u.id = NEW.org_unit_id;
    IF NEW.aktiv THEN
      _cim := 'Műtő-profil aktiválva';
      _msg := format('A(z) "%s" műtő mostantól megjelenik a Blokk-naptárban.', COALESCE(_nev, NEW.org_unit_id::text));
    ELSE
      _cim := 'Műtő-profil inaktiválva';
      _msg := format('A(z) "%s" műtő eltűnt a Blokk-naptárból.', COALESCE(_nev, NEW.org_unit_id::text));
    END IF;
    FOR _mgr IN SELECT public.or_block_managers(NEW.tenant_id) LOOP
      INSERT INTO public.notifications (tenant_id, user_id, tipus, cim, uzenet, link)
      VALUES (NEW.tenant_id, _mgr, 'or_room_state', _cim, _msg, '/muteti-terv/blokkok');
    END LOOP;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_notify_or_room_profile_state ON public.or_room_profiles;
CREATE TRIGGER trg_notify_or_room_profile_state
AFTER UPDATE OF aktiv ON public.or_room_profiles
FOR EACH ROW EXECUTE FUNCTION public.notify_or_room_profile_state();

-- 3) Conflict check on OR block time changes / release.
CREATE OR REPLACE FUNCTION public.warn_or_block_conflicts()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _new_minutes int;
  _used_minutes int;
  _case_count int;
  _mgr uuid;
  _msg text;
BEGIN
  -- Only react to schedule-relevant changes.
  IF NEW.kezdo_ido = OLD.kezdo_ido
     AND NEW.veg_ido = OLD.veg_ido
     AND NEW.datum = OLD.datum
     AND NEW.statusz = OLD.statusz THEN
    RETURN NEW;
  END IF;

  SELECT COALESCE(SUM(c.becsult_idotartam_perc), 0), COUNT(*)
    INTO _used_minutes, _case_count
    FROM public.surgery_cases c
   WHERE c.or_block_id = NEW.id;

  _new_minutes := EXTRACT(EPOCH FROM (NEW.veg_ido - NEW.kezdo_ido))/60;

  IF _case_count > 0 AND (NEW.statusz = 'felszabaditott' OR _used_minutes > _new_minutes) THEN
    RAISE WARNING 'Műtőblokk módosítás: % beosztott eset (% perc) ütközik az új % perces blokkal.',
      _case_count, _used_minutes, _new_minutes;
    _msg := format('Műtőblokk módosult (%s %s–%s). %s beosztott eset (összesen %s perc) ütközhet — kérjük, ellenőrizze.',
                   NEW.datum, NEW.kezdo_ido, NEW.veg_ido, _case_count, _used_minutes);
    FOR _mgr IN SELECT public.or_block_managers(NEW.tenant_id) LOOP
      INSERT INTO public.notifications (tenant_id, user_id, tipus, cim, uzenet, link)
      VALUES (NEW.tenant_id, _mgr, 'or_board_conflict',
              'Műtőblokk ütközés', _msg, '/muteti-terv/blokkok');
    END LOOP;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_warn_or_block_conflicts ON public.or_blocks;
CREATE TRIGGER trg_warn_or_block_conflicts
AFTER UPDATE OF kezdo_ido, veg_ido, datum, statusz ON public.or_blocks
FOR EACH ROW EXECUTE FUNCTION public.warn_or_block_conflicts();

-- 4) Re-run backfill defensively for any OR units still missing a profile.
INSERT INTO public.or_room_profiles (tenant_id, org_unit_id, or_suite_id, tipus, aktiv)
SELECT u.tenant_id,
       u.id,
       public.ensure_default_or_suite(u.tenant_id, u.site_id),
       CASE u.tipus WHEN 'kismuto' THEN 'egynapos_kismuteti'::or_tipus_enum
                    ELSE 'altalanos'::or_tipus_enum END,
       true
  FROM public.org_units u
 WHERE u.tipus IN ('muto','kismuto')
   AND u.aktiv = true
   AND u.site_id IS NOT NULL
ON CONFLICT (org_unit_id) DO UPDATE
  SET aktiv = true,
      or_suite_id = COALESCE(public.or_room_profiles.or_suite_id, EXCLUDED.or_suite_id),
      updated_at = now();


-- ─── 20260621211939_6ac8699a-66fe-4e46-97a4-b0c73b41727b.sql ───
-- Add sort_order to surgery_cases for in-block sequencing
ALTER TABLE public.surgery_cases ADD COLUMN IF NOT EXISTS sort_order integer;
CREATE INDEX IF NOT EXISTS idx_surgery_cases_block_sort ON public.surgery_cases (or_block_id, sort_order);

-- Helper: recompute tervezett_kezdo_ido for all cases in a block based on sort_order + block start + per-case duration + turnover
CREATE OR REPLACE FUNCTION public.recompute_block_case_times(_block_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_block  record;
  v_room   record;
  v_turnover int := 15;
  v_cursor timestamptz;
  r record;
BEGIN
  SELECT b.* INTO v_block FROM public.or_blocks b WHERE b.id = _block_id;
  IF NOT FOUND THEN RETURN; END IF;

  SELECT rp.fordulo_ido_perc INTO v_turnover
    FROM public.or_room_profiles rp
   WHERE rp.org_unit_id = v_block.org_unit_id AND rp.aktiv = true
   LIMIT 1;
  IF v_turnover IS NULL THEN v_turnover := 15; END IF;

  v_cursor := (v_block.datum::text || ' ' || v_block.kezdo_ido::text)::timestamptz;

  FOR r IN
    SELECT id, becsult_idotartam_perc
      FROM public.surgery_cases
     WHERE or_block_id = _block_id
       AND statusz NOT IN ('torolt','elvegzett')
     ORDER BY COALESCE(sort_order, 999999), created_at
  LOOP
    UPDATE public.surgery_cases
       SET tervezett_kezdo_ido = v_cursor
     WHERE id = r.id;
    v_cursor := v_cursor + make_interval(mins => COALESCE(r.becsult_idotartam_perc, 60) + v_turnover);
  END LOOP;
END;
$$;

GRANT EXECUTE ON FUNCTION public.recompute_block_case_times(uuid) TO authenticated;

-- Reorder RPC: accepts an ordered array of case ids for a single block
CREATE OR REPLACE FUNCTION public.reorder_block_cases(_block_id uuid, _ordered_case_ids uuid[])
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_allowed boolean;
  i int;
BEGIN
  SELECT public.has_permission(v_uid, 'book_or_case') INTO v_allowed;
  IF NOT v_allowed THEN
    RAISE EXCEPTION 'Nincs jogosultsága a műtéti sor rendezéséhez';
  END IF;

  FOR i IN 1..array_length(_ordered_case_ids, 1) LOOP
    UPDATE public.surgery_cases
       SET sort_order = i
     WHERE id = _ordered_case_ids[i]
       AND or_block_id = _block_id;
  END LOOP;

  PERFORM public.recompute_block_case_times(_block_id);
END;
$$;

GRANT EXECUTE ON FUNCTION public.reorder_block_cases(uuid, uuid[]) TO authenticated;

-- ─── 20260622060800_53514c17-2836-4e01-96eb-379d328a2b2e.sql ───

-- 1. Add 'kiemelt' to surgery_types
ALTER TABLE public.surgery_types ADD COLUMN IF NOT EXISTS kiemelt boolean NOT NULL DEFAULT false;

-- 2. Add kiemelt + delegalt_operator + szukseges_szerepek override to surgery_cases
ALTER TABLE public.surgery_cases
  ADD COLUMN IF NOT EXISTS kiemelt boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS delegalt_operator_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS szukseges_szerepek jsonb;

-- 3. New table: surgery_case_assignments
CREATE TABLE IF NOT EXISTS public.surgery_case_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  case_id uuid NOT NULL REFERENCES public.surgery_cases(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  szerep text NOT NULL CHECK (szerep IN ('operator','asszisztens','felugyelo','aneszteziologus','mutos_szakdolgozo','egyeb')),
  indok text,
  ai_generated boolean NOT NULL DEFAULT false,
  created_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (case_id, user_id, szerep)
);

CREATE INDEX IF NOT EXISTS idx_sca_case ON public.surgery_case_assignments(case_id);
CREATE INDEX IF NOT EXISTS idx_sca_user ON public.surgery_case_assignments(user_id);
CREATE INDEX IF NOT EXISTS idx_sca_tenant ON public.surgery_case_assignments(tenant_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.surgery_case_assignments TO authenticated;
GRANT ALL ON public.surgery_case_assignments TO service_role;

ALTER TABLE public.surgery_case_assignments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "sca_select_tenant" ON public.surgery_case_assignments
  FOR SELECT TO authenticated
  USING (tenant_id = current_tenant_id());

CREATE POLICY "sca_write_or_team" ON public.surgery_case_assignments
  FOR ALL TO authenticated
  USING (
    tenant_id = current_tenant_id()
    AND (has_permission(auth.uid(),'manage_or_blocks') OR has_permission(auth.uid(),'book_or_case'))
  )
  WITH CHECK (
    tenant_id = current_tenant_id()
    AND (has_permission(auth.uid(),'manage_or_blocks') OR has_permission(auth.uid(),'book_or_case'))
  );

CREATE TRIGGER trg_sca_touch BEFORE UPDATE ON public.surgery_case_assignments
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


-- ─── 20260622080421_5a723058-d9e7-45f6-9a2c-c19b100bb65f.sql ───

ALTER TABLE public.surgery_types
  ADD COLUMN IF NOT EXISTS operator_min_seniority text CHECK (operator_min_seniority IN ('szakorvos','foorvos')),
  ADD COLUMN IF NOT EXISTS delegalas_kotelezo boolean NOT NULL DEFAULT false;

ALTER TABLE public.surgery_cases
  ADD COLUMN IF NOT EXISTS operator_min_seniority_override text CHECK (operator_min_seniority_override IN ('szakorvos','foorvos')),
  ADD COLUMN IF NOT EXISTS kotelezo_eroforrasok_override jsonb;

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS napi_mutet_cap integer;


-- ─── 20260622092128_54bd4615-068b-411d-b48a-aae0fb7bd59b.sql ───
CREATE POLICY "Staff olvashatja SOS kártyát" ON public.patient_emergency_card FOR SELECT TO authenticated USING (public.has_permission(auth.uid(), 'view_patient_data'));

-- ─── 20260622093951_5b449487-0a7f-49b0-8df5-eb3564931251.sql ───

-- Helper: notify linked patient_user (if any)
CREATE OR REPLACE FUNCTION public.notify_patient_user(
  _patient_id uuid,
  _tipus text,
  _cim text,
  _uzenet text,
  _link text
) RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _user_id uuid;
BEGIN
  IF _patient_id IS NULL THEN RETURN; END IF;
  SELECT user_id INTO _user_id
  FROM public.patient_users
  WHERE patient_id = _patient_id
  LIMIT 1;
  IF _user_id IS NULL THEN RETURN; END IF;
  INSERT INTO public.notifications (user_id, tipus, cim, uzenet, link)
  VALUES (_user_id, _tipus, _cim, _uzenet, _link);
END;
$$;

-- 1) Critical clinical alerts -> patient notification
CREATE OR REPLACE FUNCTION public.tg_critical_alert_notify()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.severity IN ('critical','high') THEN
    PERFORM public.notify_patient_user(
      NEW.patient_id,
      'danger',
      'Sürgős klinikai riasztás',
      COALESCE(NEW.message, NEW.code, 'Új klinikai riasztás érkezett. Kérjük, vegye fel a kapcsolatot kezelőorvosával.'),
      '/portal/leletek'
    );
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_critical_alert_notify ON public.clinical_critical_alerts;
CREATE TRIGGER trg_critical_alert_notify
AFTER INSERT ON public.clinical_critical_alerts
FOR EACH ROW EXECUTE FUNCTION public.tg_critical_alert_notify();

-- 2) Abnormal lab observations -> patient notification
CREATE OR REPLACE FUNCTION public.tg_observation_abnormal_notify()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.interpretation IN ('H','HH','L','LL','A','AA') THEN
    PERFORM public.notify_patient_user(
      NEW.patient_id,
      'info',
      'Új lelet elérhető',
      'Új laboreredménye érkezett. Tekintse meg a portálon.',
      '/portal/leletek'
    );
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_observation_abnormal_notify ON public.clinical_observations;
CREATE TRIGGER trg_observation_abnormal_notify
AFTER INSERT ON public.clinical_observations
FOR EACH ROW EXECUTE FUNCTION public.tg_observation_abnormal_notify();

-- 3) New appointment booking -> patient notification
CREATE OR REPLACE FUNCTION public.tg_appointment_booked_notify()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _start timestamptz;
BEGIN
  IF NEW.patient_id IS NULL THEN RETURN NEW; END IF;
  SELECT kezdo_ts INTO _start FROM public.appointment_slots WHERE id = NEW.slot_id;
  PERFORM public.notify_patient_user(
    NEW.patient_id,
    'success',
    'Időpont visszaigazolva',
    CASE WHEN _start IS NOT NULL
      THEN 'Új időpontja: ' || to_char(_start AT TIME ZONE 'Europe/Budapest','YYYY-MM-DD HH24:MI')
      ELSE 'Új időpontja került rögzítésre.'
    END,
    '/portal/idopontok'
  );
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_appointment_booked_notify ON public.appointments;
CREATE TRIGGER trg_appointment_booked_notify
AFTER INSERT ON public.appointments
FOR EACH ROW EXECUTE FUNCTION public.tg_appointment_booked_notify();

-- 4) Followup enrollment -> patient notification
CREATE OR REPLACE FUNCTION public.tg_followup_enrolled_notify()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  PERFORM public.notify_patient_user(
    NEW.patient_id,
    'info',
    'Utánkövetési programba sorolva',
    'A kezelőorvosa utánkövetési programba sorolta. A részleteket a portálon tekintheti meg.',
    '/portal'
  );
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_followup_enrolled_notify ON public.followup_enrollments;
CREATE TRIGGER trg_followup_enrolled_notify
AFTER INSERT ON public.followup_enrollments
FOR EACH ROW EXECUTE FUNCTION public.tg_followup_enrolled_notify();

-- 5) Patient can read their own signed clinical notes (zárójelentés, ambuláns lap)
CREATE POLICY "Patient reads own signed notes"
ON public.clinical_notes
FOR SELECT
TO authenticated
USING (
  signed_at IS NOT NULL
  AND EXISTS (
    SELECT 1 FROM public.patient_users pu
    WHERE pu.patient_id = clinical_notes.patient_id
      AND pu.user_id = auth.uid()
  )
);


-- ─── 20260622094012_f6d506d3-fbda-474d-9c51-86866c8c3d60.sql ───

REVOKE EXECUTE ON FUNCTION public.notify_patient_user(uuid, text, text, text, text) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.tg_critical_alert_notify() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.tg_observation_abnormal_notify() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.tg_appointment_booked_notify() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.tg_followup_enrolled_notify() FROM PUBLIC, anon, authenticated;


-- ─── 20260622095416_f837826b-c99e-488c-925c-d0180dd312a6.sql ───
create or replace function public.evaluate_questionnaire_red_flag()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_red_flag boolean := false;
  v_score_critical boolean := false;
  v_q_title text;
begin
  if new.answers is null then return new; end if;
  begin
    v_red_flag := coalesce((new.answers->>'_red_flag')::boolean, false);
  exception when others then v_red_flag := false; end;
  begin
    v_score_critical := coalesce((new.answers->>'_score_critical')::boolean, false);
  exception when others then v_score_critical := false; end;
  if not (v_red_flag or v_score_critical) then return new; end if;
  select title into v_q_title from public.questionnaires where id = new.questionnaire_id;
  insert into public.clinical_critical_alerts (
    patient_id, code, severity, source, message, value_json, triggered_at, workflow_status
  ) values (
    new.patient_id,
    'questionnaire_red_flag',
    case when v_score_critical then 'high' else 'medium' end,
    'patient_questionnaire',
    coalesce(v_q_title, 'Kérdőív válasz') || ' — automatikus eszkaláció',
    jsonb_build_object('questionnaire_id', new.questionnaire_id, 'response_id', new.id, 'assignment_id', new.assignment_id),
    now(),
    'open'
  );
  return new;
end;
$$;

drop trigger if exists trg_questionnaire_response_red_flag on public.questionnaire_responses;
create trigger trg_questionnaire_response_red_flag
  after insert on public.questionnaire_responses
  for each row execute function public.evaluate_questionnaire_red_flag();

create index if not exists idx_patient_appt_requests_status_created
  on public.patient_appointment_requests (status, created_at desc);

create index if not exists idx_patient_referral_requests_status_created
  on public.patient_referral_requests (status, created_at desc);

create index if not exists idx_monitoring_thresholds_kulcs_patient
  on public.monitoring_thresholds (kulcs, patient_id);

-- ─── 20260622100047_4b48cd09-918f-48f3-a145-ae4016df12c0.sql ───

-- Backfill profile_constraints.tenant_id from owning profile
UPDATE public.profile_constraints pc
SET tenant_id = p.tenant_id
FROM public.profiles p
WHERE pc.user_id = p.id AND pc.tenant_id IS NULL;

-- incompatibilities
DROP POLICY IF EXISTS inc_select ON public.incompatibilities;
DROP POLICY IF EXISTS inc_update ON public.incompatibilities;
DROP POLICY IF EXISTS inc_insert ON public.incompatibilities;
DROP POLICY IF EXISTS inc_delete ON public.incompatibilities;

CREATE POLICY inc_select ON public.incompatibilities FOR SELECT TO authenticated
USING (
  tenant_id = public.current_tenant_id()
  AND (user_id = auth.uid() OR public.has_permission(auth.uid(),'manage_tenant'))
);
CREATE POLICY inc_insert ON public.incompatibilities FOR INSERT TO authenticated
WITH CHECK (tenant_id = public.current_tenant_id() AND user_id = auth.uid());
CREATE POLICY inc_update ON public.incompatibilities FOR UPDATE TO authenticated
USING (
  tenant_id = public.current_tenant_id()
  AND (user_id = auth.uid() OR public.has_permission(auth.uid(),'manage_tenant'))
)
WITH CHECK (
  tenant_id = public.current_tenant_id()
  AND (user_id = auth.uid() OR public.has_permission(auth.uid(),'manage_tenant'))
);
CREATE POLICY inc_delete ON public.incompatibilities FOR DELETE TO authenticated
USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_tenant'));

-- opt_out_agreements
DROP POLICY IF EXISTS ooa_select ON public.opt_out_agreements;
DROP POLICY IF EXISTS ooa_update ON public.opt_out_agreements;
DROP POLICY IF EXISTS ooa_insert ON public.opt_out_agreements;
DROP POLICY IF EXISTS ooa_delete ON public.opt_out_agreements;

CREATE POLICY ooa_select ON public.opt_out_agreements FOR SELECT TO authenticated
USING (
  tenant_id = public.current_tenant_id()
  AND (user_id = auth.uid() OR public.has_permission(auth.uid(),'manage_tenant'))
);
CREATE POLICY ooa_insert ON public.opt_out_agreements FOR INSERT TO authenticated
WITH CHECK (
  tenant_id = public.current_tenant_id()
  AND (user_id = auth.uid() OR public.has_permission(auth.uid(),'manage_tenant'))
);
CREATE POLICY ooa_update ON public.opt_out_agreements FOR UPDATE TO authenticated
USING (
  tenant_id = public.current_tenant_id()
  AND (user_id = auth.uid() OR public.has_permission(auth.uid(),'manage_tenant'))
)
WITH CHECK (
  tenant_id = public.current_tenant_id()
  AND (user_id = auth.uid() OR public.has_permission(auth.uid(),'manage_tenant'))
);
CREATE POLICY ooa_delete ON public.opt_out_agreements FOR DELETE TO authenticated
USING (tenant_id = public.current_tenant_id() AND public.has_permission(auth.uid(),'manage_tenant'));

-- profile_constraints: enforce non-null tenant_id going forward and apply tenant filter
ALTER TABLE public.profile_constraints ALTER COLUMN tenant_id SET NOT NULL;

DROP POLICY IF EXISTS profile_constraints_select ON public.profile_constraints;
DROP POLICY IF EXISTS profile_constraints_write ON public.profile_constraints;

CREATE POLICY profile_constraints_select ON public.profile_constraints FOR SELECT TO authenticated
USING (
  tenant_id = public.current_tenant_id()
  AND (user_id = auth.uid() OR public.has_permission(auth.uid(),'manage_tenant'))
);
CREATE POLICY profile_constraints_write ON public.profile_constraints FOR ALL TO authenticated
USING (
  tenant_id = public.current_tenant_id()
  AND (user_id = auth.uid() OR public.has_permission(auth.uid(),'manage_tenant'))
)
WITH CHECK (
  tenant_id = public.current_tenant_id()
  AND (user_id = auth.uid() OR public.has_permission(auth.uid(),'manage_tenant'))
);


-- ─── 20260622100944_d1de359f-710d-40d5-b4dc-0d4ad5b8a4c7.sql ───

-- A) Phase: tighten RLS policies (error-level + warn-level findings)

-- 1) clinical_calculator_results: add patient access check to DELETE/UPDATE
DROP POLICY IF EXISTS "creator deletes calc results" ON public.clinical_calculator_results;
CREATE POLICY "creator deletes calc results"
ON public.clinical_calculator_results FOR DELETE
USING (
  ((auth.uid() = created_by) OR has_role(auth.uid(), 'admin'::text))
  AND ((patient_id IS NULL) OR can_access_patient(patient_id))
);

DROP POLICY IF EXISTS "creator updates calc results" ON public.clinical_calculator_results;
CREATE POLICY "creator updates calc results"
ON public.clinical_calculator_results FOR UPDATE
USING (
  (auth.uid() = created_by)
  AND ((patient_id IS NULL) OR can_access_patient(patient_id))
)
WITH CHECK (
  (auth.uid() = created_by)
  AND ((patient_id IS NULL) OR can_access_patient(patient_id))
);

-- 2) clinical_therapy_orders: add patient access check to DELETE
DROP POLICY IF EXISTS "creator deletes therapy" ON public.clinical_therapy_orders;
CREATE POLICY "creator deletes therapy"
ON public.clinical_therapy_orders FOR DELETE
USING (
  ((auth.uid() = created_by) OR has_role(auth.uid(), 'admin'::text))
  AND can_access_patient(patient_id)
);

-- 3) clinical_weekly_vc: add patient access check to DELETE/UPDATE
DROP POLICY IF EXISTS "Author delete weekly vc" ON public.clinical_weekly_vc;
CREATE POLICY "Author delete weekly vc"
ON public.clinical_weekly_vc FOR DELETE
USING ((created_by = auth.uid()) AND can_access_patient(patient_id));

DROP POLICY IF EXISTS "Author update weekly vc" ON public.clinical_weekly_vc;
CREATE POLICY "Author update weekly vc"
ON public.clinical_weekly_vc FOR UPDATE
USING ((created_by = auth.uid()) AND can_access_patient(patient_id))
WITH CHECK ((created_by = auth.uid()) AND can_access_patient(patient_id));

-- 4) questionnaire_assignments: narrow staff SELECT to view_patient_data permission
DROP POLICY IF EXISTS qa_select_auth ON public.questionnaire_assignments;
CREATE POLICY qa_select_auth
ON public.questionnaire_assignments FOR SELECT
USING (
  tenant_id = current_tenant_id()
  AND (
    has_permission(auth.uid(), 'view_patient_data'::text)
    OR has_permission(auth.uid(), 'manage_patients'::text)
    OR assigned_by = auth.uid()
  )
);

-- 5) incompatibilities: harden INSERT with tenant + user check (already in WITH CHECK; re-affirm)
-- (current policy is fine, but explicit re-create to ensure tenant_id is required)
DROP POLICY IF EXISTS inc_insert ON public.incompatibilities;
CREATE POLICY inc_insert
ON public.incompatibilities FOR INSERT
WITH CHECK (
  tenant_id = current_tenant_id()
  AND user_id = auth.uid()
);

-- 6) profile_preferences: enforce tenant scope on all policies
DROP POLICY IF EXISTS profile_preferences_select ON public.profile_preferences;
CREATE POLICY profile_preferences_select
ON public.profile_preferences FOR SELECT
USING (
  tenant_id = current_tenant_id()
  AND (
    user_id = auth.uid()
    OR has_permission(auth.uid(), 'manage_schedule'::text)
    OR has_permission(auth.uid(), 'manage_tenant'::text)
  )
);

DROP POLICY IF EXISTS profile_preferences_write ON public.profile_preferences;
CREATE POLICY profile_preferences_write
ON public.profile_preferences FOR ALL
USING (
  tenant_id = current_tenant_id()
  AND (
    user_id = auth.uid()
    OR has_permission(auth.uid(), 'manage_tenant'::text)
  )
)
WITH CHECK (
  tenant_id = current_tenant_id()
  AND (
    user_id = auth.uid()
    OR has_permission(auth.uid(), 'manage_tenant'::text)
  )
);


-- ─── 20260622102033_5daf59b3-779a-48fd-9a9f-b726531e6202.sql ───
-- Tighten RLS policy roles: change public -> authenticated for sensitive tables.

-- 1) clinical_calculator_results DELETE/UPDATE
DROP POLICY IF EXISTS "creator deletes calc results" ON public.clinical_calculator_results;
CREATE POLICY "creator deletes calc results"
ON public.clinical_calculator_results FOR DELETE TO authenticated
USING (
  ((auth.uid() = created_by) OR has_role(auth.uid(), 'admin'::text))
  AND ((patient_id IS NULL) OR can_access_patient(patient_id))
);

DROP POLICY IF EXISTS "creator updates calc results" ON public.clinical_calculator_results;
CREATE POLICY "creator updates calc results"
ON public.clinical_calculator_results FOR UPDATE TO authenticated
USING (
  (auth.uid() = created_by)
  AND ((patient_id IS NULL) OR can_access_patient(patient_id))
)
WITH CHECK (
  (auth.uid() = created_by)
  AND ((patient_id IS NULL) OR can_access_patient(patient_id))
);

-- 2) clinical_therapy_orders DELETE
DROP POLICY IF EXISTS "creator deletes therapy" ON public.clinical_therapy_orders;
CREATE POLICY "creator deletes therapy"
ON public.clinical_therapy_orders FOR DELETE TO authenticated
USING (
  ((auth.uid() = created_by) OR has_role(auth.uid(), 'admin'::text))
  AND can_access_patient(patient_id)
);

-- 3) clinical_weekly_vc DELETE/UPDATE
DROP POLICY IF EXISTS "Author delete weekly vc" ON public.clinical_weekly_vc;
CREATE POLICY "Author delete weekly vc"
ON public.clinical_weekly_vc FOR DELETE TO authenticated
USING ((created_by = auth.uid()) AND can_access_patient(patient_id));

DROP POLICY IF EXISTS "Author update weekly vc" ON public.clinical_weekly_vc;
CREATE POLICY "Author update weekly vc"
ON public.clinical_weekly_vc FOR UPDATE TO authenticated
USING ((created_by = auth.uid()) AND can_access_patient(patient_id))
WITH CHECK ((created_by = auth.uid()) AND can_access_patient(patient_id));

-- 4) questionnaire_assignments SELECT (qa_select_auth)
DROP POLICY IF EXISTS qa_select_auth ON public.questionnaire_assignments;
CREATE POLICY qa_select_auth
ON public.questionnaire_assignments FOR SELECT TO authenticated
USING (
  tenant_id = current_tenant_id()
  AND (
    has_permission(auth.uid(), 'view_patient_data'::text)
    OR has_permission(auth.uid(), 'manage_patients'::text)
    OR assigned_by = auth.uid()
  )
);

-- 5) incompatibilities INSERT
DROP POLICY IF EXISTS inc_insert ON public.incompatibilities;
CREATE POLICY inc_insert
ON public.incompatibilities FOR INSERT TO authenticated
WITH CHECK (
  tenant_id = current_tenant_id()
  AND user_id = auth.uid()
);

-- 6) profile_preferences SELECT + ALL
DROP POLICY IF EXISTS profile_preferences_select ON public.profile_preferences;
CREATE POLICY profile_preferences_select
ON public.profile_preferences FOR SELECT TO authenticated
USING (
  tenant_id = current_tenant_id()
  AND (
    user_id = auth.uid()
    OR has_permission(auth.uid(), 'manage_schedule'::text)
    OR has_permission(auth.uid(), 'manage_tenant'::text)
  )
);

DROP POLICY IF EXISTS profile_preferences_write ON public.profile_preferences;
CREATE POLICY profile_preferences_write
ON public.profile_preferences FOR ALL TO authenticated
USING (
  tenant_id = current_tenant_id()
  AND (
    user_id = auth.uid()
    OR has_permission(auth.uid(), 'manage_tenant'::text)
  )
)
WITH CHECK (
  tenant_id = current_tenant_id()
  AND (
    user_id = auth.uid()
    OR has_permission(auth.uid(), 'manage_tenant'::text)
  )
);

-- 7) profile_peer_links (all four policies) -> authenticated
DROP POLICY IF EXISTS profile_peer_links_select ON public.profile_peer_links;
CREATE POLICY profile_peer_links_select
ON public.profile_peer_links FOR SELECT TO authenticated
USING ((from_user_id = auth.uid()) OR (to_user_id = auth.uid()) OR has_permission(auth.uid(), 'manage_schedule'::text) OR has_permission(auth.uid(), 'manage_tenant'::text));

DROP POLICY IF EXISTS profile_peer_links_insert ON public.profile_peer_links;
CREATE POLICY profile_peer_links_insert
ON public.profile_peer_links FOR INSERT TO authenticated
WITH CHECK ((from_user_id = auth.uid()) OR has_permission(auth.uid(), 'manage_schedule'::text) OR has_permission(auth.uid(), 'manage_tenant'::text));

DROP POLICY IF EXISTS profile_peer_links_update ON public.profile_peer_links;
CREATE POLICY profile_peer_links_update
ON public.profile_peer_links FOR UPDATE TO authenticated
USING ((from_user_id = auth.uid()) OR has_permission(auth.uid(), 'manage_schedule'::text) OR has_permission(auth.uid(), 'manage_tenant'::text))
WITH CHECK ((from_user_id = auth.uid()) OR has_permission(auth.uid(), 'manage_schedule'::text) OR has_permission(auth.uid(), 'manage_tenant'::text));

DROP POLICY IF EXISTS profile_peer_links_delete ON public.profile_peer_links;
CREATE POLICY profile_peer_links_delete
ON public.profile_peer_links FOR DELETE TO authenticated
USING ((from_user_id = auth.uid()) OR has_permission(auth.uid(), 'manage_tenant'::text));

-- 8) push_subscriptions
DROP POLICY IF EXISTS "Users manage own push subscriptions" ON public.push_subscriptions;
CREATE POLICY "Users manage own push subscriptions"
ON public.push_subscriptions FOR ALL TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- 9) shift_notifications_sent
DROP POLICY IF EXISTS "Users see own shift notifications" ON public.shift_notifications_sent;
CREATE POLICY "Users see own shift notifications"
ON public.shift_notifications_sent FOR SELECT TO authenticated
USING (auth.uid() = user_id);

-- 10) error_log INSERT - restrict to authenticated only
DROP POLICY IF EXISTS "Anyone can insert error logs" ON public.error_log;
CREATE POLICY "Authenticated users can insert error logs"
ON public.error_log FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id OR user_id IS NULL);

-- ─── 20260622183533_6cb02741-5b5f-4b11-a706-b447da09f361.sql ───
-- Remove the unsafe anon insert policy; submissions now go through the
-- token-validated server route /api/public/elegedettseg which uses the
-- service-role client after verifying foglalas_kod + vendeg_email.
DROP POLICY IF EXISTS ss_insert_anon ON public.satisfaction_surveys;

-- ─── 20260622223822_4ff1374b-1d15-4077-aec8-c4e27c68febe.sql ───
-- 1) Revoke broad EXECUTE on all SECURITY DEFINER functions in public
DO $$
DECLARE
  r RECORD;
BEGIN
  FOR r IN
    SELECT p.oid::regprocedure::text AS sig
    FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public' AND p.prosecdef = true
  LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION %s FROM PUBLIC, anon', r.sig);
  END LOOP;
END $$;

-- 2) Re-grant EXECUTE to authenticated for functions used as RPC from app code
--    and for helpers referenced inside RLS policies.
DO $$
DECLARE
  fn text;
  fn_names text[] := ARRAY[
    -- App-called RPCs
    'can_book_into_block','close_leave_year','current_tenant_id','eligible_swap_targets',
    'enforce_forced_leave_takeout','ensure_role_permissions_seed',
    'expire_overdue_questionnaire_assignments','find_acute_replacements',
    'generate_demand_for_period','has_any_role','has_permission','has_role',
    'is_conversation_participant','kiosk_autosave','kiosk_load','kiosk_submit_response',
    'log_leave_admin','process_followup_schedules','process_questionnaire_schedules',
    'publish_schedule_run','recalc_leave_entitlements','recompute_block_case_times',
    'reorder_block_cases','search_patients','seed_default_org_for_tenant',
    'send_questionnaire_reminders','wage_simulation',
    -- RLS helpers
    'can_access_patient','current_user_patient_ids','bump_conversation_last_message',
    'apply_approved_change_request','enroll_followup'
  ];
  r RECORD;
BEGIN
  FOREACH fn IN ARRAY fn_names LOOP
    FOR r IN
      SELECT p.oid::regprocedure::text AS sig
      FROM pg_proc p
      JOIN pg_namespace n ON n.oid = p.pronamespace
      WHERE n.nspname = 'public' AND p.proname = fn
    LOOP
      EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO authenticated', r.sig);
    END LOOP;
  END LOOP;
END $$;

-- 3) Tighten i18n_missing_keys_insert: must include tenant_id matching current_tenant_id (if column exists)
--    Otherwise leave as-is. We check column existence dynamically.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema='public' AND table_name='i18n_missing_keys' AND column_name='tenant_id'
  ) THEN
    DROP POLICY IF EXISTS i18n_missing_keys_insert ON public.i18n_missing_keys;
    CREATE POLICY i18n_missing_keys_insert ON public.i18n_missing_keys
      FOR INSERT TO authenticated
      WITH CHECK (tenant_id = public.current_tenant_id());
  END IF;
END $$;


-- ─── 20260622223847_d19ee6f8-50a8-4388-9a00-125ab123b655.sql ───
DO $$
DECLARE
  r RECORD;
  whitelist text[] := ARRAY[
    'can_book_into_block','close_leave_year','current_tenant_id','eligible_swap_targets',
    'enforce_forced_leave_takeout','ensure_role_permissions_seed',
    'expire_overdue_questionnaire_assignments','find_acute_replacements',
    'generate_demand_for_period','has_any_role','has_permission','has_role',
    'is_conversation_participant','kiosk_autosave','kiosk_load','kiosk_submit_response',
    'log_leave_admin','process_followup_schedules','process_questionnaire_schedules',
    'publish_schedule_run','recalc_leave_entitlements','recompute_block_case_times',
    'reorder_block_cases','search_patients','seed_default_org_for_tenant',
    'send_questionnaire_reminders','wage_simulation',
    'can_access_patient','current_user_patient_ids','bump_conversation_last_message',
    'apply_approved_change_request','enroll_followup'
  ];
BEGIN
  FOR r IN
    SELECT p.oid::regprocedure::text AS sig, p.proname
    FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public' AND p.prosecdef = true
      AND NOT (p.proname = ANY(whitelist))
  LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION %s FROM authenticated', r.sig);
  END LOOP;
END $$;


-- ─── 20260623121419_5a34c541-6550-4001-a703-1859f744fc82.sql ───

-- ============================================================
-- 1) app_settings
-- ============================================================
CREATE TABLE public.app_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  namespace TEXT NOT NULL,
  key TEXT NOT NULL,
  value JSONB NOT NULL DEFAULT '{}'::jsonb,
  draft_value JSONB,
  is_public BOOLEAN NOT NULL DEFAULT false,
  schema_version INT NOT NULL DEFAULT 1,
  updated_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(namespace, key)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.app_settings TO authenticated;
GRANT SELECT ON public.app_settings TO anon;
GRANT ALL ON public.app_settings TO service_role;

ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins manage all settings"
  ON public.app_settings FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Authenticated read public settings"
  ON public.app_settings FOR SELECT
  TO authenticated
  USING (is_public = true OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Anon read public settings"
  ON public.app_settings FOR SELECT
  TO anon
  USING (is_public = true);

CREATE INDEX idx_app_settings_namespace ON public.app_settings(namespace);
CREATE INDEX idx_app_settings_public ON public.app_settings(is_public) WHERE is_public = true;

-- ============================================================
-- 2) app_settings_audit
-- ============================================================
CREATE TABLE public.app_settings_audit (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  setting_id UUID REFERENCES public.app_settings(id) ON DELETE SET NULL,
  namespace TEXT NOT NULL,
  key TEXT NOT NULL,
  action TEXT NOT NULL CHECK (action IN ('create','update','delete','publish','reset')),
  old_value JSONB,
  new_value JSONB,
  changed_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  reason TEXT,
  changed_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT ON public.app_settings_audit TO authenticated;
GRANT ALL ON public.app_settings_audit TO service_role;

ALTER TABLE public.app_settings_audit ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins read audit"
  ON public.app_settings_audit FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins insert audit"
  ON public.app_settings_audit FOR INSERT
  TO authenticated
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE INDEX idx_app_settings_audit_key ON public.app_settings_audit(namespace, key, changed_at DESC);

-- Trigger: log every change
CREATE OR REPLACE FUNCTION public.fn_app_settings_audit()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    INSERT INTO public.app_settings_audit(setting_id, namespace, key, action, old_value, new_value, changed_by)
    VALUES (NEW.id, NEW.namespace, NEW.key, 'create', NULL, NEW.value, NEW.updated_by);
    RETURN NEW;
  ELSIF TG_OP = 'UPDATE' THEN
    IF OLD.value IS DISTINCT FROM NEW.value OR OLD.draft_value IS DISTINCT FROM NEW.draft_value THEN
      INSERT INTO public.app_settings_audit(setting_id, namespace, key, action, old_value, new_value, changed_by)
      VALUES (NEW.id, NEW.namespace, NEW.key, 'update', OLD.value, NEW.value, NEW.updated_by);
    END IF;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    INSERT INTO public.app_settings_audit(setting_id, namespace, key, action, old_value, new_value, changed_by)
    VALUES (OLD.id, OLD.namespace, OLD.key, 'delete', OLD.value, NULL, OLD.updated_by);
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$;

CREATE TRIGGER trg_app_settings_audit
AFTER INSERT OR UPDATE OR DELETE ON public.app_settings
FOR EACH ROW EXECUTE FUNCTION public.fn_app_settings_audit();

-- updated_at trigger
CREATE OR REPLACE FUNCTION public.fn_app_settings_touch()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

CREATE TRIGGER trg_app_settings_touch
BEFORE UPDATE ON public.app_settings
FOR EACH ROW EXECUTE FUNCTION public.fn_app_settings_touch();

-- ============================================================
-- 3) landing_page_blocks
-- ============================================================
CREATE TABLE public.landing_page_blocks (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  block_type TEXT NOT NULL,
  position INT NOT NULL DEFAULT 0,
  locale TEXT NOT NULL DEFAULT 'hu',
  content JSONB NOT NULL DEFAULT '{}'::jsonb,
  draft_content JSONB,
  is_published BOOLEAN NOT NULL DEFAULT false,
  variant TEXT NOT NULL DEFAULT 'default',
  updated_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.landing_page_blocks TO authenticated;
GRANT SELECT ON public.landing_page_blocks TO anon;
GRANT ALL ON public.landing_page_blocks TO service_role;

ALTER TABLE public.landing_page_blocks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins manage landing blocks"
  ON public.landing_page_blocks FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Anon read published blocks"
  ON public.landing_page_blocks FOR SELECT
  TO anon
  USING (is_published = true);

CREATE POLICY "Authenticated read published blocks"
  ON public.landing_page_blocks FOR SELECT
  TO authenticated
  USING (is_published = true OR public.has_role(auth.uid(), 'admin'));

CREATE INDEX idx_landing_blocks_order ON public.landing_page_blocks(locale, variant, position);

CREATE TRIGGER trg_landing_blocks_touch
BEFORE UPDATE ON public.landing_page_blocks
FOR EACH ROW EXECUTE FUNCTION public.fn_app_settings_touch();

-- ============================================================
-- 4) landing_page_versions (snapshot)
-- ============================================================
CREATE TABLE public.landing_page_versions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  label TEXT,
  locale TEXT NOT NULL DEFAULT 'hu',
  variant TEXT NOT NULL DEFAULT 'default',
  snapshot JSONB NOT NULL,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, DELETE ON public.landing_page_versions TO authenticated;
GRANT ALL ON public.landing_page_versions TO service_role;

ALTER TABLE public.landing_page_versions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins manage landing versions"
  ON public.landing_page_versions FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE INDEX idx_landing_versions_created ON public.landing_page_versions(created_at DESC);

-- ============================================================
-- 5) ai_setting_suggestions
-- ============================================================
CREATE TABLE public.ai_setting_suggestions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  target_kind TEXT NOT NULL CHECK (target_kind IN ('setting','landing_block','landing_full')),
  target_namespace TEXT,
  target_key TEXT,
  goal TEXT,
  suggested_value JSONB NOT NULL,
  rationale TEXT,
  model TEXT,
  accepted BOOLEAN NOT NULL DEFAULT false,
  accepted_at TIMESTAMPTZ,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.ai_setting_suggestions TO authenticated;
GRANT ALL ON public.ai_setting_suggestions TO service_role;

ALTER TABLE public.ai_setting_suggestions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins manage AI suggestions"
  ON public.ai_setting_suggestions FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE INDEX idx_ai_suggestions_target ON public.ai_setting_suggestions(target_kind, target_namespace, target_key, created_at DESC);


-- ─── 20260623130641_73115991-6516-45d3-acc2-ff4faff18a3e.sql ───

-- ============================================================
-- E2E TESZT SEED — Szilika Klinika tenant
-- Idempotens: ismételt futtatás nem duplikál
-- ============================================================
DO $$
DECLARE
  v_tenant uuid := '13aacb24-a6c2-445c-84b5-5ddbd1fcca82';
  v_site uuid := '3843dfc1-7dd9-4722-bc41-4b8587e83c6c';
  v_muto_id uuid;
  v_ambulancia_id uuid;
  v_resource_id uuid;
  v_patient_id uuid;
BEGIN
  -- 1) E2E Műtő szervezeti egység
  SELECT id INTO v_muto_id FROM public.org_units
    WHERE tenant_id=v_tenant AND nev='E2E_Teszt Műtő' LIMIT 1;
  IF v_muto_id IS NULL THEN
    INSERT INTO public.org_units (tenant_id, site_id, nev, tipus, aktiv, mukodes_kezd, mukodes_veg, muto_blokk_perc)
    VALUES (v_tenant, v_site, 'E2E_Teszt Műtő', 'muto'::org_unit_tipus, true, '08:00','16:00',480)
    RETURNING id INTO v_muto_id;
  END IF;

  -- 2) E2E Kontroll Ambulancia szervezeti egység
  SELECT id INTO v_ambulancia_id FROM public.org_units
    WHERE tenant_id=v_tenant AND nev='E2E_Kontroll Ambulancia' LIMIT 1;
  IF v_ambulancia_id IS NULL THEN
    INSERT INTO public.org_units (tenant_id, site_id, nev, tipus, aktiv, mukodes_kezd, mukodes_veg)
    VALUES (v_tenant, v_site, 'E2E_Kontroll Ambulancia', 'ambulancia'::org_unit_tipus, true, '08:00','12:00')
    RETURNING id INTO v_ambulancia_id;
  END IF;

  -- 3) Appointment resource (rendelő típus) + sablon
  SELECT id INTO v_resource_id FROM public.appointment_resources
    WHERE tenant_id=v_tenant AND nev='E2E_Kontroll Ambulancia' LIMIT 1;
  IF v_resource_id IS NULL THEN
    INSERT INTO public.appointment_resources (tenant_id, nev, tipus, org_unit_id, aktiv, publikus, szin, leiras)
    VALUES (v_tenant, 'E2E_Kontroll Ambulancia', 'rendelo'::appt_resource_tipus, v_ambulancia_id, true, true, '#16a34a', 'E2E teszt — kontroll vizsgálatok')
    RETURNING id INTO v_resource_id;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM public.appointment_templates WHERE tenant_id=v_tenant AND nev='E2E_Kontroll napi sablon') THEN
    INSERT INTO public.appointment_templates
      (tenant_id, resource_id, nev, napok, kezd_ido, veg_ido, slot_perc, kapacitas, aktiv)
    VALUES (v_tenant, v_resource_id, 'E2E_Kontroll napi sablon',
            ARRAY[1,2,3,4,5]::int[], '08:00','12:00', 15, 1, true);
  END IF;

  -- 4) Surgery type
  IF NOT EXISTS (SELECT 1 FROM public.surgery_types WHERE tenant_id=v_tenant AND nev='E2E_Rutin Beavatkozás') THEN
    INSERT INTO public.surgery_types
      (tenant_id, kod, nev, becsult_idotartam_perc, posztop_apolasi_perc, szukseges_szerepek, aktiv)
    VALUES (v_tenant, 'E2E_RUTIN', 'E2E_Rutin Beavatkozás', 60, 30,
            '[{"role":"szakorvos","count":1},{"role":"szakdolgozo","count":1}]'::jsonb, true);
  END IF;

  -- 5) Teszt beteg
  SELECT id INTO v_patient_id FROM public.patients
    WHERE tenant_id=v_tenant AND vezeteknev='E2E_Teszt' AND keresztnev='Béla' LIMIT 1;
  IF v_patient_id IS NULL THEN
    INSERT INTO public.patients (tenant_id, taj, vezeteknev, keresztnev, szuletesi_datum, nem, megjegyzes)
    VALUES (v_tenant, '999000111', 'E2E_Teszt', 'Béla', '1980-01-01', 'ferfi', 'E2E automatizált tesztbeteg')
    RETURNING id INTO v_patient_id;
  END IF;

  -- 6) Monitoring küszöb — vércukor > 11 mmol/l kritikus
  IF NOT EXISTS (SELECT 1 FROM public.monitoring_thresholds WHERE tenant_id=v_tenant AND kulcs='E2E_vercukor_kritikus') THEN
    INSERT INTO public.monitoring_thresholds (tenant_id, kulcs, ertek, unit, megjegyzes)
    VALUES (v_tenant, 'E2E_vercukor_kritikus', 11.0, 'mmol/l', 'E2E: kritikus küszöb vércukorra');
  END IF;

  -- 7) Eszkalációs szabály
  IF NOT EXISTS (SELECT 1 FROM public.clinical_alert_escalation_rules WHERE tenant_id=v_tenant AND name='E2E_Kritikus alert eszkaláció') THEN
    INSERT INTO public.clinical_alert_escalation_rules
      (tenant_id, name, severity, source, escalate_after_minutes, target_role, active)
    VALUES (v_tenant, 'E2E_Kritikus alert eszkaláció', 'critical', 'measurement', 30, 'foorvos', true);
  END IF;
END $$;

-- ============================================================
-- CLEANUP FÜGGVÉNY — admin-only
-- ============================================================
CREATE OR REPLACE FUNCTION public.cleanup_e2e_test_data()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_tenant uuid := '13aacb24-a6c2-445c-84b5-5ddbd1fcca82';
  v_caller uuid := auth.uid();
  v_is_admin boolean;
  v_counts jsonb := '{}'::jsonb;
  v_n int;
BEGIN
  IF v_caller IS NULL THEN
    RAISE EXCEPTION 'Authentikáció szükséges';
  END IF;
  SELECT EXISTS(
    SELECT 1 FROM public.user_roles ur
    JOIN public.roles r ON r.id=ur.role_id
    WHERE ur.user_id=v_caller AND r.kulcs='tenant_admin' AND ur.tenant_id=v_tenant
  ) INTO v_is_admin;
  IF NOT v_is_admin THEN
    RAISE EXCEPTION 'Csak tenant_admin futtathatja (caller=%)', v_caller;
  END IF;

  -- Függő rekordok először
  DELETE FROM public.or_blocks WHERE tenant_id=v_tenant AND org_unit_id IN
    (SELECT id FROM public.org_units WHERE tenant_id=v_tenant AND nev LIKE 'E2E\_%' ESCAPE '\');
  GET DIAGNOSTICS v_n = ROW_COUNT; v_counts := v_counts || jsonb_build_object('or_blocks', v_n);

  DELETE FROM public.appointment_templates WHERE tenant_id=v_tenant AND nev LIKE 'E2E\_%' ESCAPE '\';
  GET DIAGNOSTICS v_n = ROW_COUNT; v_counts := v_counts || jsonb_build_object('appointment_templates', v_n);

  DELETE FROM public.appointment_resources WHERE tenant_id=v_tenant AND nev LIKE 'E2E\_%' ESCAPE '\';
  GET DIAGNOSTICS v_n = ROW_COUNT; v_counts := v_counts || jsonb_build_object('appointment_resources', v_n);

  DELETE FROM public.surgery_types WHERE tenant_id=v_tenant AND nev LIKE 'E2E\_%' ESCAPE '\';
  GET DIAGNOSTICS v_n = ROW_COUNT; v_counts := v_counts || jsonb_build_object('surgery_types', v_n);

  DELETE FROM public.monitoring_thresholds WHERE tenant_id=v_tenant AND kulcs LIKE 'E2E\_%' ESCAPE '\';
  GET DIAGNOSTICS v_n = ROW_COUNT; v_counts := v_counts || jsonb_build_object('monitoring_thresholds', v_n);

  DELETE FROM public.clinical_alert_escalation_rules WHERE tenant_id=v_tenant AND name LIKE 'E2E\_%' ESCAPE '\';
  GET DIAGNOSTICS v_n = ROW_COUNT; v_counts := v_counts || jsonb_build_object('escalation_rules', v_n);

  DELETE FROM public.patients WHERE tenant_id=v_tenant AND vezeteknev='E2E_Teszt';
  GET DIAGNOSTICS v_n = ROW_COUNT; v_counts := v_counts || jsonb_build_object('patients', v_n);

  DELETE FROM public.org_units WHERE tenant_id=v_tenant AND nev LIKE 'E2E\_%' ESCAPE '\';
  GET DIAGNOSTICS v_n = ROW_COUNT; v_counts := v_counts || jsonb_build_object('org_units', v_n);

  RETURN jsonb_build_object('ok', true, 'deleted', v_counts, 'tenant_id', v_tenant);
END;
$$;

GRANT EXECUTE ON FUNCTION public.cleanup_e2e_test_data() TO authenticated;


-- ─── 20260623213558_2c5ea89a-f38e-401c-82e0-8aeb5fa8b4bb.sql ───
ALTER TABLE public.patients
  ADD COLUMN IF NOT EXISTS telefon text,
  ADD COLUMN IF NOT EXISTS email text,
  ADD COLUMN IF NOT EXISTS iranyitoszam text,
  ADD COLUMN IF NOT EXISTS varos text,
  ADD COLUMN IF NOT EXISTS cim text;

ALTER TABLE public.patient_emergency_card
  ADD COLUMN IF NOT EXISTS gyogyszer_erzekenyseg text[],
  ADD COLUMN IF NOT EXISTS etrend text,
  ADD COLUMN IF NOT EXISTS kapcsolt_orvos_telefon text;

CREATE TABLE IF NOT EXISTS public.patient_medication_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  gyogyszer_nev text NOT NULL,
  hatas_eros text,
  mennyiseg text,
  ismetlodo boolean NOT NULL DEFAULT false,
  surgosseg text NOT NULL DEFAULT 'normal' CHECK (surgosseg IN ('normal','surgos')),
  megjegyzes text,
  status text NOT NULL DEFAULT 'uj' CHECK (status IN ('uj','elbiralas','jovahagyva','elutasitva','teljesitve')),
  reply text,
  reviewed_by uuid,
  reviewed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.patient_medication_requests TO authenticated;
GRANT ALL ON public.patient_medication_requests TO service_role;

ALTER TABLE public.patient_medication_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "patient owns med requests"
  ON public.patient_medication_requests FOR ALL TO authenticated
  USING (patient_id IN (SELECT current_user_patient_ids()))
  WITH CHECK (patient_id IN (SELECT current_user_patient_ids()) AND user_id = auth.uid());

CREATE POLICY "staff read med requests"
  ON public.patient_medication_requests FOR SELECT TO authenticated
  USING (has_permission(auth.uid(), 'view_patient_data'));

CREATE POLICY "staff update med requests"
  ON public.patient_medication_requests FOR UPDATE TO authenticated
  USING (has_permission(auth.uid(), 'view_patient_data'))
  WITH CHECK (has_permission(auth.uid(), 'view_patient_data'));

CREATE TRIGGER trg_medreq_updated_at BEFORE UPDATE ON public.patient_medication_requests
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE INDEX IF NOT EXISTS idx_medreq_patient ON public.patient_medication_requests(patient_id, created_at DESC);

CREATE TABLE IF NOT EXISTS public.patient_documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  uploaded_by uuid NOT NULL,
  uploader_kind text NOT NULL DEFAULT 'patient' CHECK (uploader_kind IN ('patient','staff','clinic')),
  category text NOT NULL DEFAULT 'general' CHECK (category IN ('general','lab','imaging','referral','discharge','prescription','other')),
  title text NOT NULL,
  description text,
  storage_path text NOT NULL,
  mime_type text,
  size_bytes integer,
  shared_with_patient boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.patient_documents TO authenticated;
GRANT ALL ON public.patient_documents TO service_role;

ALTER TABLE public.patient_documents ENABLE ROW LEVEL SECURITY;

CREATE POLICY "patient sees own documents"
  ON public.patient_documents FOR SELECT TO authenticated
  USING (patient_id IN (SELECT current_user_patient_ids()) AND shared_with_patient = true);

CREATE POLICY "patient uploads own documents"
  ON public.patient_documents FOR INSERT TO authenticated
  WITH CHECK (patient_id IN (SELECT current_user_patient_ids()) AND uploaded_by = auth.uid() AND uploader_kind = 'patient');

CREATE POLICY "patient deletes own uploads"
  ON public.patient_documents FOR DELETE TO authenticated
  USING (patient_id IN (SELECT current_user_patient_ids()) AND uploaded_by = auth.uid() AND uploader_kind = 'patient');

CREATE POLICY "staff manages documents"
  ON public.patient_documents FOR ALL TO authenticated
  USING (has_permission(auth.uid(), 'view_patient_data'))
  WITH CHECK (has_permission(auth.uid(), 'view_patient_data'));

CREATE TRIGGER trg_patdocs_updated_at BEFORE UPDATE ON public.patient_documents
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE INDEX IF NOT EXISTS idx_patdocs_patient ON public.patient_documents(patient_id, created_at DESC);

CREATE TABLE IF NOT EXISTS public.patient_health_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  patient_id uuid NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  cim text NOT NULL,
  cel text,
  lepesek jsonb NOT NULL DEFAULT '[]'::jsonb,
  status text NOT NULL DEFAULT 'aktiv' CHECK (status IN ('aktiv','befejezett','felfuggesztve')),
  kezdo_datum date,
  zaro_datum date,
  letrehozta uuid,
  paciens_jegyzet text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.patient_health_plans TO authenticated;
GRANT ALL ON public.patient_health_plans TO service_role;

ALTER TABLE public.patient_health_plans ENABLE ROW LEVEL SECURITY;

CREATE POLICY "patient reads own plans"
  ON public.patient_health_plans FOR SELECT TO authenticated
  USING (patient_id IN (SELECT current_user_patient_ids()));

CREATE POLICY "patient updates own note"
  ON public.patient_health_plans FOR UPDATE TO authenticated
  USING (patient_id IN (SELECT current_user_patient_ids()))
  WITH CHECK (patient_id IN (SELECT current_user_patient_ids()));

CREATE POLICY "staff manages plans"
  ON public.patient_health_plans FOR ALL TO authenticated
  USING (has_permission(auth.uid(), 'view_patient_data'))
  WITH CHECK (has_permission(auth.uid(), 'view_patient_data'));

CREATE TRIGGER trg_plans_updated_at BEFORE UPDATE ON public.patient_health_plans
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE INDEX IF NOT EXISTS idx_plans_patient ON public.patient_health_plans(patient_id, created_at DESC);

-- ─── 20260623213638_91088a15-e455-4dda-a291-54866b040c83.sql ───
CREATE POLICY "patient reads own docs in bucket"
  ON storage.objects FOR SELECT TO authenticated
  USING (
    bucket_id = 'patient-documents'
    AND EXISTS (
      SELECT 1 FROM public.patient_documents d
      WHERE d.storage_path = storage.objects.name
        AND d.patient_id IN (SELECT current_user_patient_ids())
        AND d.shared_with_patient = true
    )
  );

CREATE POLICY "patient uploads own docs to bucket"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'patient-documents'
    AND (storage.foldername(name))[1] IN (
      SELECT id::text FROM public.patients WHERE id IN (SELECT current_user_patient_ids())
    )
  );

CREATE POLICY "patient deletes own docs in bucket"
  ON storage.objects FOR DELETE TO authenticated
  USING (
    bucket_id = 'patient-documents'
    AND EXISTS (
      SELECT 1 FROM public.patient_documents d
      WHERE d.storage_path = storage.objects.name
        AND d.uploaded_by = auth.uid()
        AND d.uploader_kind = 'patient'
    )
  );

CREATE POLICY "staff manages docs in bucket"
  ON storage.objects FOR ALL TO authenticated
  USING (bucket_id = 'patient-documents' AND has_permission(auth.uid(), 'view_patient_data'))
  WITH CHECK (bucket_id = 'patient-documents' AND has_permission(auth.uid(), 'view_patient_data'));

-- ─── 20260624073330_7a6759b9-d29d-4753-b5e7-15f59a6c0e97.sql ───

-- patient_documents
DROP POLICY IF EXISTS "staff manages documents" ON public.patient_documents;
CREATE POLICY "staff manages documents accessible patients"
ON public.patient_documents
FOR ALL
TO authenticated
USING (
  has_permission(auth.uid(), 'view_patient_data')
  AND can_access_patient(patient_id)
)
WITH CHECK (
  has_permission(auth.uid(), 'view_patient_data')
  AND can_access_patient(patient_id)
);

-- patient_emergency_card
DROP POLICY IF EXISTS "Staff olvashatja SOS kártyát" ON public.patient_emergency_card;
CREATE POLICY "Staff olvashatja SOS kártyát"
ON public.patient_emergency_card
FOR SELECT
TO authenticated
USING (
  has_permission(auth.uid(), 'view_patient_data')
  AND can_access_patient(patient_id)
);

-- patient_health_plans
DROP POLICY IF EXISTS "staff manages plans" ON public.patient_health_plans;
CREATE POLICY "staff manages plans accessible patients"
ON public.patient_health_plans
FOR ALL
TO authenticated
USING (
  has_permission(auth.uid(), 'view_patient_data')
  AND can_access_patient(patient_id)
)
WITH CHECK (
  has_permission(auth.uid(), 'view_patient_data')
  AND can_access_patient(patient_id)
);

-- storage.objects - staff access to patient-documents bucket
DROP POLICY IF EXISTS "staff reads patient documents" ON storage.objects;
CREATE POLICY "staff reads patient documents"
ON storage.objects
FOR SELECT
TO authenticated
USING (
  bucket_id = 'patient-documents'
  AND has_permission(auth.uid(), 'view_patient_data')
  AND EXISTS (
    SELECT 1 FROM public.patient_documents d
    WHERE d.storage_path = objects.name
      AND can_access_patient(d.patient_id)
  )
);

DROP POLICY IF EXISTS "staff manages patient documents" ON storage.objects;
CREATE POLICY "staff manages patient documents"
ON storage.objects
FOR ALL
TO authenticated
USING (
  bucket_id = 'patient-documents'
  AND has_permission(auth.uid(), 'view_patient_data')
  AND EXISTS (
    SELECT 1 FROM public.patient_documents d
    WHERE d.storage_path = objects.name
      AND can_access_patient(d.patient_id)
  )
)
WITH CHECK (
  bucket_id = 'patient-documents'
  AND has_permission(auth.uid(), 'view_patient_data')
  AND EXISTS (
    SELECT 1 FROM public.patient_documents d
    WHERE d.storage_path = objects.name
      AND can_access_patient(d.patient_id)
  )
);


-- ─── 20260624073533_de690350-5c58-4c35-9b3d-c1620f2fb0e0.sql ───

DROP POLICY IF EXISTS "staff read med requests" ON public.patient_medication_requests;
CREATE POLICY "staff read med requests"
ON public.patient_medication_requests
FOR SELECT
TO authenticated
USING (
  has_permission(auth.uid(), 'view_patient_data')
  AND can_access_patient(patient_id)
);

DROP POLICY IF EXISTS "staff update med requests" ON public.patient_medication_requests;
CREATE POLICY "staff update med requests"
ON public.patient_medication_requests
FOR UPDATE
TO authenticated
USING (
  has_permission(auth.uid(), 'view_patient_data')
  AND can_access_patient(patient_id)
)
WITH CHECK (
  has_permission(auth.uid(), 'view_patient_data')
  AND can_access_patient(patient_id)
);


-- ─── 20260624073908_bce05968-f075-4c10-96da-b43220d29194.sql ───

DROP POLICY IF EXISTS profile_contacts_select ON public.profile_contacts;
CREATE POLICY profile_contacts_select
ON public.profile_contacts
FOR SELECT
TO authenticated
USING (
  user_id = auth.uid()
  OR (
    has_permission(auth.uid(), 'manage_tenant')
    AND tenant_id = current_tenant_id()
  )
);

DROP POLICY IF EXISTS profile_contacts_write ON public.profile_contacts;
CREATE POLICY profile_contacts_write
ON public.profile_contacts
FOR ALL
TO authenticated
USING (
  user_id = auth.uid()
  OR (
    has_permission(auth.uid(), 'manage_tenant')
    AND tenant_id = current_tenant_id()
  )
)
WITH CHECK (
  user_id = auth.uid()
  OR (
    has_permission(auth.uid(), 'manage_tenant')
    AND tenant_id = current_tenant_id()
  )
);


-- ─── 20260624075940_f8fcb9c5-c737-4ec4-abff-02f27b7524fe.sql ───
ALTER TABLE public.patient_emergency_card REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.patient_emergency_card;

-- ─── 20260624080319_97d09bcf-33d2-465a-86d5-ccf01a3f111a.sql ───
-- 1) Storage: tighten patient-documents bucket access to caller's tenant
DROP POLICY IF EXISTS "staff manages docs in bucket" ON storage.objects;
CREATE POLICY "staff manages docs in bucket"
ON storage.objects FOR ALL TO authenticated
USING (
  bucket_id = 'patient-documents'
  AND public.has_permission(auth.uid(), 'view_patient_data')
  AND EXISTS (
    SELECT 1 FROM public.patient_documents d
    JOIN public.patients p ON p.id = d.patient_id
    WHERE d.storage_path = storage.objects.name
      AND p.tenant_id = public.current_tenant_id()
  )
)
WITH CHECK (
  bucket_id = 'patient-documents'
  AND public.has_permission(auth.uid(), 'view_patient_data')
  AND EXISTS (
    SELECT 1 FROM public.patient_documents d
    JOIN public.patients p ON p.id = d.patient_id
    WHERE d.storage_path = storage.objects.name
      AND p.tenant_id = public.current_tenant_id()
  )
);

-- 2) profile_peer_links: enforce tenant on every branch
DROP POLICY IF EXISTS profile_peer_links_select ON public.profile_peer_links;
DROP POLICY IF EXISTS profile_peer_links_insert ON public.profile_peer_links;
DROP POLICY IF EXISTS profile_peer_links_update ON public.profile_peer_links;
DROP POLICY IF EXISTS profile_peer_links_delete ON public.profile_peer_links;

CREATE POLICY profile_peer_links_select ON public.profile_peer_links
FOR SELECT TO authenticated
USING (
  (tenant_id IS NULL OR tenant_id = public.current_tenant_id())
  AND (
    from_user_id = auth.uid()
    OR to_user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_schedule')
    OR public.has_permission(auth.uid(), 'manage_tenant')
  )
);

CREATE POLICY profile_peer_links_insert ON public.profile_peer_links
FOR INSERT TO authenticated
WITH CHECK (
  (tenant_id IS NULL OR tenant_id = public.current_tenant_id())
  AND (
    from_user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_schedule')
    OR public.has_permission(auth.uid(), 'manage_tenant')
  )
);

CREATE POLICY profile_peer_links_update ON public.profile_peer_links
FOR UPDATE TO authenticated
USING (
  (tenant_id IS NULL OR tenant_id = public.current_tenant_id())
  AND (
    from_user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_schedule')
    OR public.has_permission(auth.uid(), 'manage_tenant')
  )
)
WITH CHECK (
  (tenant_id IS NULL OR tenant_id = public.current_tenant_id())
  AND (
    from_user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_schedule')
    OR public.has_permission(auth.uid(), 'manage_tenant')
  )
);

CREATE POLICY profile_peer_links_delete ON public.profile_peer_links
FOR DELETE TO authenticated
USING (
  (tenant_id IS NULL OR tenant_id = public.current_tenant_id())
  AND (
    from_user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_tenant')
  )
);

-- 3) profile_unavailability: enforce tenant on select/write
DROP POLICY IF EXISTS profile_unavailability_select ON public.profile_unavailability;
DROP POLICY IF EXISTS profile_unavailability_write ON public.profile_unavailability;

CREATE POLICY profile_unavailability_select ON public.profile_unavailability
FOR SELECT TO authenticated
USING (
  (tenant_id IS NULL OR tenant_id = public.current_tenant_id())
  AND (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_schedule')
    OR public.has_permission(auth.uid(), 'manage_tenant')
  )
);

CREATE POLICY profile_unavailability_write ON public.profile_unavailability
FOR ALL TO authenticated
USING (
  (tenant_id IS NULL OR tenant_id = public.current_tenant_id())
  AND (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_schedule')
    OR public.has_permission(auth.uid(), 'manage_tenant')
  )
)
WITH CHECK (
  (tenant_id IS NULL OR tenant_id = public.current_tenant_id())
  AND (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_schedule')
    OR public.has_permission(auth.uid(), 'manage_tenant')
  )
);

-- ─── 20260624084551_8d55e554-e01f-4c46-9f0b-7c68899db60f.sql ───
-- Tenant cross-check szigorítás 5 táblán
-- 1) profile_beavatkozasok / certifications / skills / trainings:
--    A "saját" ág is kapjon tenant_id = current_tenant_id() szűrést,
--    hogy multi-tenant userek ne lássák/írják cross-tenant a saját rekordjaikat.
-- 2) app_settings_audit: SELECT-et szigorítjuk view_audit permre,
--    INSERT-nél marad az admin ellenőrzés.

-- profile_beavatkozasok
DROP POLICY IF EXISTS pb_select_own_or_team ON public.profile_beavatkozasok;
DROP POLICY IF EXISTS pb_write_own_or_training ON public.profile_beavatkozasok;
CREATE POLICY pb_select_own_or_team ON public.profile_beavatkozasok
  FOR SELECT TO authenticated
  USING (
    tenant_id = current_tenant_id()
    AND (user_id = auth.uid() OR has_permission(auth.uid(), 'view_team'))
  );
CREATE POLICY pb_write_own_or_training ON public.profile_beavatkozasok
  FOR ALL TO authenticated
  USING (
    tenant_id = current_tenant_id()
    AND (user_id = auth.uid() OR has_permission(auth.uid(), 'manage_training'))
  )
  WITH CHECK (
    tenant_id = current_tenant_id()
    AND (user_id = auth.uid() OR has_permission(auth.uid(), 'manage_training'))
  );

-- profile_certifications
DROP POLICY IF EXISTS pc_select_own_or_team ON public.profile_certifications;
DROP POLICY IF EXISTS pc_write_own_or_training ON public.profile_certifications;
CREATE POLICY pc_select_own_or_team ON public.profile_certifications
  FOR SELECT TO authenticated
  USING (
    tenant_id = current_tenant_id()
    AND (user_id = auth.uid() OR has_permission(auth.uid(), 'view_team'))
  );
CREATE POLICY pc_write_own_or_training ON public.profile_certifications
  FOR ALL TO authenticated
  USING (
    tenant_id = current_tenant_id()
    AND (user_id = auth.uid() OR has_permission(auth.uid(), 'manage_training'))
  )
  WITH CHECK (
    tenant_id = current_tenant_id()
    AND (user_id = auth.uid() OR has_permission(auth.uid(), 'manage_training'))
  );

-- profile_skills
DROP POLICY IF EXISTS ps_select_own_or_team ON public.profile_skills;
DROP POLICY IF EXISTS ps_write_own_or_training ON public.profile_skills;
CREATE POLICY ps_select_own_or_team ON public.profile_skills
  FOR SELECT TO authenticated
  USING (
    tenant_id = current_tenant_id()
    AND (user_id = auth.uid() OR has_permission(auth.uid(), 'view_team'))
  );
CREATE POLICY ps_write_own_or_training ON public.profile_skills
  FOR ALL TO authenticated
  USING (
    tenant_id = current_tenant_id()
    AND (user_id = auth.uid() OR has_permission(auth.uid(), 'manage_training'))
  )
  WITH CHECK (
    tenant_id = current_tenant_id()
    AND (user_id = auth.uid() OR has_permission(auth.uid(), 'manage_training'))
  );

-- profile_trainings
DROP POLICY IF EXISTS pt_select_own_or_team ON public.profile_trainings;
DROP POLICY IF EXISTS pt_write_own_or_training ON public.profile_trainings;
CREATE POLICY pt_select_own_or_team ON public.profile_trainings
  FOR SELECT TO authenticated
  USING (
    tenant_id = current_tenant_id()
    AND (user_id = auth.uid() OR has_permission(auth.uid(), 'view_team'))
  );
CREATE POLICY pt_write_own_or_training ON public.profile_trainings
  FOR ALL TO authenticated
  USING (
    tenant_id = current_tenant_id()
    AND (user_id = auth.uid() OR has_permission(auth.uid(), 'manage_training'))
  )
  WITH CHECK (
    tenant_id = current_tenant_id()
    AND (user_id = auth.uid() OR has_permission(auth.uid(), 'manage_training'))
  );

-- app_settings_audit: SELECT-et szigorítjuk view_audit permre (admin szerepkör nélkül is engedélyezhető),
-- így nem ad cross-tenant globális rálátást indokolatlanul. Az INSERT marad admin-only.
DROP POLICY IF EXISTS "Admins read audit" ON public.app_settings_audit;
CREATE POLICY app_settings_audit_select ON public.app_settings_audit
  FOR SELECT TO authenticated
  USING (has_permission(auth.uid(), 'view_audit'));


-- ─── 20260624094836_2aca66d8-f82c-4c76-97fa-67d27d187912.sql ───

-- 1. admin_audit_log: add tenant scoping to update policy
DROP POLICY IF EXISTS audit_update_own_recent ON public.admin_audit_log;
CREATE POLICY audit_update_own_recent ON public.admin_audit_log
  FOR UPDATE TO authenticated
  USING (user_id = auth.uid()
         AND tenant_id = current_tenant_id()
         AND created_at > (now() - interval '10 minutes'))
  WITH CHECK (user_id = auth.uid() AND tenant_id = current_tenant_id());

-- 2. app_settings_audit: restrict inserts via view_audit permission
DROP POLICY IF EXISTS "Admins insert audit" ON public.app_settings_audit;
CREATE POLICY app_settings_audit_insert ON public.app_settings_audit
  FOR INSERT TO authenticated
  WITH CHECK (has_permission(auth.uid(), 'manage_tenant'));

-- 3. profile_external_hours: enforce tenant_id on leader policies
DROP POLICY IF EXISTS external_hours_leaders_select ON public.profile_external_hours;
CREATE POLICY external_hours_leaders_select ON public.profile_external_hours
  FOR SELECT TO authenticated
  USING (tenant_id = current_tenant_id()
         AND (has_permission(auth.uid(), 'view_team')
              OR has_permission(auth.uid(), 'manage_org')
              OR has_permission(auth.uid(), 'manage_schedule')));

DROP POLICY IF EXISTS external_hours_leaders_modify ON public.profile_external_hours;
CREATE POLICY external_hours_leaders_modify ON public.profile_external_hours
  FOR ALL TO authenticated
  USING (tenant_id = current_tenant_id()
         AND (has_permission(auth.uid(), 'manage_org')
              OR has_permission(auth.uid(), 'manage_schedule')))
  WITH CHECK (tenant_id = current_tenant_id()
              AND (has_permission(auth.uid(), 'manage_org')
                   OR has_permission(auth.uid(), 'manage_schedule')));

-- 4. role_permissions: remove tenant_admin direct write path
DROP POLICY IF EXISTS role_perms_admin_write ON public.role_permissions;
-- service_role retains full access via existing GRANT ALL

-- 5. patient_lifestyle_log: add tenant-scoped staff read policy
CREATE POLICY patient_lifestyle_log_staff_select ON public.patient_lifestyle_log
  FOR SELECT TO authenticated
  USING (
    has_permission(auth.uid(), 'manage_patients')
    AND patient_id IN (
      SELECT id FROM public.patients WHERE tenant_id = current_tenant_id()
    )
  );

-- 6. messages: prevent participants from forging ai/system messages
DROP POLICY IF EXISTS messages_insert_participant ON public.messages;
CREATE POLICY messages_insert_participant ON public.messages
  FOR INSERT TO authenticated
  WITH CHECK (
    is_conversation_participant(conversation_id, auth.uid())
    AND sender_user_id = auth.uid()
    AND sender_kind = 'user'::message_sender_kind
  );


-- ─── 20260624095428_ea961ad5-dbaa-4188-8451-88f71a173b43.sql ───

-- =========================================================================
-- 1. questionnaire_assignments: tighten staff access
-- =========================================================================
DROP POLICY IF EXISTS qa_select_auth ON public.questionnaire_assignments;
DROP POLICY IF EXISTS qa_write_auth ON public.questionnaire_assignments;

CREATE POLICY qa_select_staff ON public.questionnaire_assignments
  FOR SELECT TO authenticated
  USING (
    tenant_id = current_tenant_id()
    AND (
      assigned_by = auth.uid()
      OR has_permission(auth.uid(), 'manage_patients')
      OR has_permission(auth.uid(), 'view_patient_data')
      OR has_permission(auth.uid(), 'manage_tenant')
    )
  );

CREATE POLICY qa_write_staff ON public.questionnaire_assignments
  FOR ALL TO authenticated
  USING (
    tenant_id = current_tenant_id()
    AND (
      has_permission(auth.uid(), 'manage_patients')
      OR has_permission(auth.uid(), 'manage_tenant')
    )
  )
  WITH CHECK (
    tenant_id = current_tenant_id()
    AND (
      has_permission(auth.uid(), 'manage_patients')
      OR has_permission(auth.uid(), 'manage_tenant')
    )
  );

-- =========================================================================
-- 2. has_permission cross-tenant: enforce tenant_id on write policies
-- =========================================================================
DROP POLICY IF EXISTS cl_write_admin ON public.competency_levels;
CREATE POLICY cl_write_admin ON public.competency_levels
  FOR ALL TO authenticated
  USING (
    (tenant_id IS NULL OR tenant_id = current_tenant_id())
    AND (has_permission(auth.uid(), 'manage_tenant') OR has_permission(auth.uid(), 'manage_training'))
  )
  WITH CHECK (
    (tenant_id IS NULL OR tenant_id = current_tenant_id())
    AND (has_permission(auth.uid(), 'manage_tenant') OR has_permission(auth.uid(), 'manage_training'))
  );

DROP POLICY IF EXISTS ph_write_admin ON public.public_holidays;
CREATE POLICY ph_write_admin ON public.public_holidays
  FOR ALL TO authenticated
  USING ((tenant_id IS NULL OR tenant_id = current_tenant_id())
         AND has_permission(auth.uid(), 'manage_tenant'))
  WITH CHECK ((tenant_id IS NULL OR tenant_id = current_tenant_id())
              AND has_permission(auth.uid(), 'manage_tenant'));

DROP POLICY IF EXISTS wc_write_admin ON public.wage_codes;
CREATE POLICY wc_write_admin ON public.wage_codes
  FOR ALL TO authenticated
  USING ((tenant_id IS NULL OR tenant_id = current_tenant_id())
         AND has_permission(auth.uid(), 'manage_tenant'))
  WITH CHECK ((tenant_id IS NULL OR tenant_id = current_tenant_id())
              AND has_permission(auth.uid(), 'manage_tenant'));

DROP POLICY IF EXISTS wm_write_admin ON public.wage_mapping;
CREATE POLICY wm_write_admin ON public.wage_mapping
  FOR ALL TO authenticated
  USING ((tenant_id IS NULL OR tenant_id = current_tenant_id())
         AND has_permission(auth.uid(), 'manage_tenant'))
  WITH CHECK ((tenant_id IS NULL OR tenant_id = current_tenant_id())
              AND has_permission(auth.uid(), 'manage_tenant'));

DROP POLICY IF EXISTS wtr_write_admin ON public.work_time_rules;
CREATE POLICY wtr_write_admin ON public.work_time_rules
  FOR ALL TO authenticated
  USING ((tenant_id IS NULL OR tenant_id = current_tenant_id())
         AND has_permission(auth.uid(), 'manage_tenant'))
  WITH CHECK ((tenant_id IS NULL OR tenant_id = current_tenant_id())
              AND has_permission(auth.uid(), 'manage_tenant'));

-- =========================================================================
-- 3. obstetric_partograms: explicit tenant column + scoped policies
-- =========================================================================
ALTER TABLE public.obstetric_partograms
  ADD COLUMN IF NOT EXISTS tenant_id UUID REFERENCES public.tenants(id);

UPDATE public.obstetric_partograms p
SET tenant_id = pat.tenant_id
FROM public.patients pat
WHERE p.patient_id = pat.id AND p.tenant_id IS NULL;

CREATE OR REPLACE FUNCTION public.partogram_set_tenant()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.tenant_id IS NULL THEN
    SELECT tenant_id INTO NEW.tenant_id FROM public.patients WHERE id = NEW.patient_id;
  END IF;
  RETURN NEW;
END $$;
REVOKE EXECUTE ON FUNCTION public.partogram_set_tenant() FROM PUBLIC, anon, authenticated;

DROP TRIGGER IF EXISTS trg_partogram_set_tenant ON public.obstetric_partograms;
CREATE TRIGGER trg_partogram_set_tenant
  BEFORE INSERT ON public.obstetric_partograms
  FOR EACH ROW EXECUTE FUNCTION public.partogram_set_tenant();

DROP POLICY IF EXISTS partogram_select ON public.obstetric_partograms;
DROP POLICY IF EXISTS partogram_insert ON public.obstetric_partograms;
DROP POLICY IF EXISTS partogram_update ON public.obstetric_partograms;
DROP POLICY IF EXISTS partogram_delete ON public.obstetric_partograms;

CREATE POLICY partogram_select ON public.obstetric_partograms
  FOR SELECT TO authenticated
  USING (tenant_id = current_tenant_id() AND can_access_patient(patient_id));

CREATE POLICY partogram_insert ON public.obstetric_partograms
  FOR INSERT TO authenticated
  WITH CHECK (
    created_by = auth.uid()
    AND can_access_patient(patient_id)
    AND (tenant_id IS NULL OR tenant_id = current_tenant_id())
  );

CREATE POLICY partogram_update ON public.obstetric_partograms
  FOR UPDATE TO authenticated
  USING (tenant_id = current_tenant_id() AND can_access_patient(patient_id))
  WITH CHECK (tenant_id = current_tenant_id() AND can_access_patient(patient_id));

CREATE POLICY partogram_delete ON public.obstetric_partograms
  FOR DELETE TO authenticated
  USING (
    tenant_id = current_tenant_id()
    AND can_access_patient(patient_id)
    AND (created_by = auth.uid() OR has_permission(auth.uid(), 'manage_patients'))
  );

DROP POLICY IF EXISTS partogram_entry_select ON public.obstetric_partogram_entries;
DROP POLICY IF EXISTS partogram_entry_insert ON public.obstetric_partogram_entries;
DROP POLICY IF EXISTS partogram_entry_update ON public.obstetric_partogram_entries;
DROP POLICY IF EXISTS partogram_entry_delete ON public.obstetric_partogram_entries;

CREATE POLICY partogram_entry_select ON public.obstetric_partogram_entries
  FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.obstetric_partograms p
    WHERE p.id = obstetric_partogram_entries.partogram_id
      AND p.tenant_id = current_tenant_id()
      AND can_access_patient(p.patient_id)
  ));

CREATE POLICY partogram_entry_insert ON public.obstetric_partogram_entries
  FOR INSERT TO authenticated
  WITH CHECK (created_by = auth.uid() AND EXISTS (
    SELECT 1 FROM public.obstetric_partograms p
    WHERE p.id = obstetric_partogram_entries.partogram_id
      AND p.tenant_id = current_tenant_id()
      AND can_access_patient(p.patient_id)
  ));

CREATE POLICY partogram_entry_update ON public.obstetric_partogram_entries
  FOR UPDATE TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.obstetric_partograms p
    WHERE p.id = obstetric_partogram_entries.partogram_id
      AND p.tenant_id = current_tenant_id()
      AND can_access_patient(p.patient_id)
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM public.obstetric_partograms p
    WHERE p.id = obstetric_partogram_entries.partogram_id
      AND p.tenant_id = current_tenant_id()
      AND can_access_patient(p.patient_id)
  ));

CREATE POLICY partogram_entry_delete ON public.obstetric_partogram_entries
  FOR DELETE TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.obstetric_partograms p
    WHERE p.id = obstetric_partogram_entries.partogram_id
      AND p.tenant_id = current_tenant_id()
      AND can_access_patient(p.patient_id)
      AND (obstetric_partogram_entries.created_by = auth.uid()
           OR has_permission(auth.uid(), 'manage_patients'))
  ));

-- =========================================================================
-- 4. always-true cleanup
-- =========================================================================
DROP POLICY IF EXISTS "Service role delete clinical alerts" ON public.clinical_critical_alerts;

DROP POLICY IF EXISTS i18n_missing_keys_insert ON public.i18n_missing_keys;
CREATE POLICY i18n_missing_keys_insert ON public.i18n_missing_keys
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() IS NOT NULL);

-- =========================================================================
-- 5. Move extensions out of public schema
-- =========================================================================
CREATE SCHEMA IF NOT EXISTS extensions;
GRANT USAGE ON SCHEMA extensions TO postgres, anon, authenticated, service_role;

ALTER EXTENSION pg_trgm SET SCHEMA extensions;

-- pg_net does not support SET SCHEMA, so drop and recreate it in the extensions schema.
DROP EXTENSION IF EXISTS pg_net;
CREATE EXTENSION IF NOT EXISTS pg_net WITH SCHEMA extensions;

-- =========================================================================
-- 6. Revoke EXECUTE on SECURITY DEFINER helpers from PUBLIC / anon
-- =========================================================================
DO $$
DECLARE
  fn RECORD;
BEGIN
  FOR fn IN
    SELECT p.oid::regprocedure AS sig
    FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public' AND p.prosecdef = true
  LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION %s FROM PUBLIC, anon', fn.sig);
  END LOOP;
END $$;


-- ─── 20260624102606_5c23e56c-0417-40f9-b5d5-e076fc713ccf.sql ───

-- 1) work_time_ledger új oszlopok
ALTER TABLE public.work_time_ledger
  ADD COLUMN IF NOT EXISTS potlek_kod text,
  ADD COLUMN IF NOT EXISTS projekt text,
  ADD COLUMN IF NOT EXISTS koltseghely text,
  ADD COLUMN IF NOT EXISTS dijazas_tipus text
    CHECK (dijazas_tipus IS NULL OR dijazas_tipus IN ('alap','potlek','bonusz','tulora','keszenleti_dij','ugyeleti_dij')),
  ADD COLUMN IF NOT EXISTS munkaltatoi_dontes jsonb;

COMMENT ON COLUMN public.work_time_ledger.munkaltatoi_dontes IS 'Munkáltatói döntés metaadat: {dontes_szam, dontes_datum, indok, hivatkozas}';

-- 2) work_time_rules új oszlopok
ALTER TABLE public.work_time_rules
  ADD COLUMN IF NOT EXISTS ugyelet_utan_piheno_nap boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS ugyelet_munkaidokeret_terhere boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS munkaszuneti_utan_szabadnap_fizetett boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS ejszakai_potlek_szazalek numeric NOT NULL DEFAULT 15,
  ADD COLUMN IF NOT EXISTS vasarnapi_potlek_szazalek numeric NOT NULL DEFAULT 50,
  ADD COLUMN IF NOT EXISTS unnepnapi_potlek_szazalek numeric NOT NULL DEFAULT 100,
  ADD COLUMN IF NOT EXISTS ugyeleti_dij_szazalek numeric NOT NULL DEFAULT 50,
  ADD COLUMN IF NOT EXISTS keszenleti_dij_szazalek numeric NOT NULL DEFAULT 25,
  ADD COLUMN IF NOT EXISTS munkaidokeret_honap integer NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS jogszabaly_hivatkozas text;

-- 3) Egyedi tenant-szintű munkaidő-szabályok
CREATE TABLE IF NOT EXISTS public.work_time_custom_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  nev text NOT NULL,
  szabaly_tipus text NOT NULL CHECK (szabaly_tipus IN (
    'ugyelet_utan_piheno','min_piheno_muszakok_kozott','unnep_auto_felar',
    'max_havi_potlek_ora','max_heti_ugyelet','kotelezo_ebed_szunet',
    'eltolt_muszak_korlat','egyedi'
  )),
  konfiguracio jsonb NOT NULL DEFAULT '{}'::jsonb,
  jogszabaly_hivatkozas text,
  prioritas smallint NOT NULL DEFAULT 100,
  aktiv boolean NOT NULL DEFAULT true,
  ervenyes_tol date NOT NULL DEFAULT CURRENT_DATE,
  ervenyes_ig date,
  jogviszony_tipus jogviszony_tipus,
  fenntarto_tipus  fenntarto_tipus,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_wtcr_tenant_aktiv
  ON public.work_time_custom_rules(tenant_id, aktiv, prioritas);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.work_time_custom_rules TO authenticated;
GRANT ALL ON public.work_time_custom_rules TO service_role;

ALTER TABLE public.work_time_custom_rules ENABLE ROW LEVEL SECURITY;

CREATE POLICY "wtcr_tenant_read"
  ON public.work_time_custom_rules FOR SELECT TO authenticated
  USING (tenant_id = current_tenant_id());

CREATE POLICY "wtcr_admin_write"
  ON public.work_time_custom_rules FOR ALL TO authenticated
  USING (
    tenant_id = current_tenant_id()
    AND (has_role(auth.uid(), 'tenant_admin')
         OR has_permission(auth.uid(), 'manage_worktime'))
  )
  WITH CHECK (
    tenant_id = current_tenant_id()
    AND (has_role(auth.uid(), 'tenant_admin')
         OR has_permission(auth.uid(), 'manage_worktime'))
  );

CREATE TRIGGER trg_wtcr_updated_at
  BEFORE UPDATE ON public.work_time_custom_rules
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER trg_wtcr_audit
  AFTER INSERT OR UPDATE OR DELETE ON public.work_time_custom_rules
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- 4) 2020. évi C. tv. bértábla
CREATE TABLE IF NOT EXISTS public.wage_table_egeszsegugyi (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  besorolasi_kategoria text NOT NULL,
  fizetesi_fokozat smallint NOT NULL,
  munkakor_megnevezes text,
  alapilletmeny_ft integer NOT NULL,
  garantalt_illetmeny_ft integer,
  potlek_alap_ft integer,
  ervenyes_tol date NOT NULL,
  ervenyes_ig date,
  jogszabaly_hivatkozas text DEFAULT '2020. évi C. törvény az egészségügyi szolgálati jogviszonyról',
  forrasszoveg text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, besorolasi_kategoria, fizetesi_fokozat, ervenyes_tol)
);

CREATE INDEX IF NOT EXISTS idx_wte_lookup
  ON public.wage_table_egeszsegugyi(tenant_id, ervenyes_tol);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.wage_table_egeszsegugyi TO authenticated;
GRANT ALL ON public.wage_table_egeszsegugyi TO service_role;

ALTER TABLE public.wage_table_egeszsegugyi ENABLE ROW LEVEL SECURITY;

CREATE POLICY "wte_read_global_or_tenant"
  ON public.wage_table_egeszsegugyi FOR SELECT TO authenticated
  USING (tenant_id IS NULL OR tenant_id = current_tenant_id());

CREATE POLICY "wte_admin_write"
  ON public.wage_table_egeszsegugyi FOR ALL TO authenticated
  USING (
    tenant_id = current_tenant_id()
    AND (has_role(auth.uid(), 'tenant_admin')
         OR has_permission(auth.uid(), 'manage_worktime'))
  )
  WITH CHECK (
    tenant_id = current_tenant_id()
    AND (has_role(auth.uid(), 'tenant_admin')
         OR has_permission(auth.uid(), 'manage_worktime'))
  );

CREATE TRIGGER trg_wte_updated_at
  BEFORE UPDATE ON public.wage_table_egeszsegugyi
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER trg_wte_audit
  AFTER INSERT OR UPDATE OR DELETE ON public.wage_table_egeszsegugyi
  FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- 5) Új jogosultság-kulcs: manage_worktime — alapból a tenant_admin szerepkör megkapja
INSERT INTO public.role_permissions (role_kulcs, perm)
VALUES ('tenant_admin', 'manage_worktime')
ON CONFLICT DO NOTHING;


-- ─── 20260624105822_d47f9216-6d32-4141-b952-7f050c7735fa.sql ───

DO $$ BEGIN
  CREATE TYPE public.eusztv_tabla_tipus AS ENUM ('orvos_1mell','szakdolgozo_1a_mell');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

ALTER TABLE public.wage_table_egeszsegugyi
  ADD COLUMN IF NOT EXISTS tabla_tipus public.eusztv_tabla_tipus NOT NULL DEFAULT 'orvos_1mell',
  ADD COLUMN IF NOT EXISTS gyakorlati_ido_tol_ev integer,
  ADD COLUMN IF NOT EXISTS gyakorlati_ido_ig_ev integer,
  ADD COLUMN IF NOT EXISTS vezeto_szorzo numeric(4,2) NOT NULL DEFAULT 1.20,
  ADD COLUMN IF NOT EXISTS fizetesi_osztaly text,
  ADD COLUMN IF NOT EXISTS osszeg_ft bigint;

CREATE INDEX IF NOT EXISTS idx_wte_eusztv_lookup
  ON public.wage_table_egeszsegugyi(tabla_tipus, ervenyes_tol, gyakorlati_ido_tol_ev);

CREATE TABLE IF NOT EXISTS public.profile_service_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  munkaltato_nev text NOT NULL,
  fenntarto_tipus text NOT NULL CHECK (fenntarto_tipus IN ('allami','onkormanyzati','egyhazi','magan','kulfoldi','egyeb')),
  munkakor text,
  kezdo_datum date NOT NULL,
  zaro_datum date,
  beszamithato_eusztv boolean NOT NULL DEFAULT true,
  beszamithato_jubileum boolean NOT NULL DEFAULT true,
  forras text NOT NULL DEFAULT 'nyilatkozat' CHECK (forras IN ('dokumentum','nyilatkozat','MOK','korabbi_munkaltato_igazolas')),
  csatolmany_url text,
  megjegyzes text,
  rogzitette_user_id uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (zaro_datum IS NULL OR zaro_datum >= kezdo_datum)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_service_history TO authenticated;
GRANT ALL ON public.profile_service_history TO service_role;
ALTER TABLE public.profile_service_history ENABLE ROW LEVEL SECURITY;
CREATE POLICY psh_read ON public.profile_service_history FOR SELECT TO authenticated
  USING (tenant_id = current_tenant_id() AND (user_id = auth.uid() OR has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));
CREATE POLICY psh_write ON public.profile_service_history FOR ALL TO authenticated
  USING (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')))
  WITH CHECK (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));
CREATE INDEX idx_psh_user ON public.profile_service_history(tenant_id, user_id);

CREATE TABLE IF NOT EXISTS public.profile_service_time_overrides (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  tipus text NOT NULL CHECK (tipus IN ('gyakorlati_ido','jubileumi')),
  napok_korrekcio integer NOT NULL,
  indok text NOT NULL,
  jovahagyo_user_id uuid REFERENCES auth.users(id),
  ervenyes_tol date NOT NULL DEFAULT CURRENT_DATE,
  ervenyes_ig date,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_service_time_overrides TO authenticated;
GRANT ALL ON public.profile_service_time_overrides TO service_role;
ALTER TABLE public.profile_service_time_overrides ENABLE ROW LEVEL SECURITY;
CREATE POLICY psto_read ON public.profile_service_time_overrides FOR SELECT TO authenticated
  USING (tenant_id = current_tenant_id() AND (user_id = auth.uid() OR has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));
CREATE POLICY psto_write ON public.profile_service_time_overrides FOR ALL TO authenticated
  USING (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')))
  WITH CHECK (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));

CREATE TABLE IF NOT EXISTS public.probaidok (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  profile_employment_id uuid NOT NULL REFERENCES public.profile_employment(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  tartam_honap smallint NOT NULL DEFAULT 3 CHECK (tartam_honap BETWEEN 1 AND 4),
  kezdo_datum date NOT NULL,
  zaro_datum date,
  mentesseg_jogcim text CHECK (mentesseg_jogcim IS NULL OR mentesseg_jogcim IN ('athelyezes','azonos_felek','kormrend_szakmai_gyakorlat','hatarozott_ido')),
  megjegyzes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE OR REPLACE FUNCTION public.set_probaido_zaro() RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.zaro_datum := (NEW.kezdo_datum + (NEW.tartam_honap || ' months')::interval)::date; RETURN NEW; END $$;
CREATE TRIGGER trg_probaido_zaro BEFORE INSERT OR UPDATE OF kezdo_datum, tartam_honap ON public.probaidok
  FOR EACH ROW EXECUTE FUNCTION public.set_probaido_zaro();
GRANT SELECT, INSERT, UPDATE, DELETE ON public.probaidok TO authenticated;
GRANT ALL ON public.probaidok TO service_role;
ALTER TABLE public.probaidok ENABLE ROW LEVEL SECURITY;
CREATE POLICY pid_read ON public.probaidok FOR SELECT TO authenticated
  USING (tenant_id = current_tenant_id() AND (user_id = auth.uid() OR has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));
CREATE POLICY pid_write ON public.probaidok FOR ALL TO authenticated
  USING (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')))
  WITH CHECK (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));

CREATE TABLE IF NOT EXISTS public.osszeferhetetlenseg_engedelyek (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  tipus text NOT NULL CHECK (tipus IN ('kulso_jogviszony','szekhelyen_tevekenyseg','tudomanyos','oktatoi','egyeb')),
  leiras text NOT NULL,
  engedelyezo_szerv text,
  kerelem_datum date,
  engedely_datum date,
  lejarat date,
  status text NOT NULL DEFAULT 'beadva' CHECK (status IN ('beadva','engedelyezve','elutasitva','visszavonva','lejart')),
  csatolmany_url text,
  megjegyzes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.osszeferhetetlenseg_engedelyek TO authenticated;
GRANT ALL ON public.osszeferhetetlenseg_engedelyek TO service_role;
ALTER TABLE public.osszeferhetetlenseg_engedelyek ENABLE ROW LEVEL SECURITY;
CREATE POLICY oe_read ON public.osszeferhetetlenseg_engedelyek FOR SELECT TO authenticated
  USING (tenant_id = current_tenant_id() AND (user_id = auth.uid() OR has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));
CREATE POLICY oe_write ON public.osszeferhetetlenseg_engedelyek FOR ALL TO authenticated
  USING (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')))
  WITH CHECK (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));

CREATE TABLE IF NOT EXISTS public.minosites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  ertekelo_user_id uuid REFERENCES auth.users(id),
  idoszak_tol date NOT NULL,
  idoszak_ig date NOT NULL,
  eredmeny text NOT NULL CHECK (eredmeny IN ('kivalo','jo','megfelelo','nem_megfelelo')),
  szoveges_ertekeles text,
  dokumentum_url text,
  alairt boolean NOT NULL DEFAULT false,
  alairas_datum date,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.minosites TO authenticated;
GRANT ALL ON public.minosites TO service_role;
ALTER TABLE public.minosites ENABLE ROW LEVEL SECURITY;
CREATE POLICY min_read ON public.minosites FOR SELECT TO authenticated
  USING (tenant_id = current_tenant_id() AND (user_id = auth.uid() OR ertekelo_user_id = auth.uid() OR has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));
CREATE POLICY min_write ON public.minosites FOR ALL TO authenticated
  USING (tenant_id = current_tenant_id() AND (ertekelo_user_id = auth.uid() OR has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')))
  WITH CHECK (tenant_id = current_tenant_id() AND (ertekelo_user_id = auth.uid() OR has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));

CREATE TABLE IF NOT EXISTS public.szabadsag_evente (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  ev smallint NOT NULL,
  alapszabadsag_nap smallint NOT NULL DEFAULT 0,
  potszabadsag_nap smallint NOT NULL DEFAULT 0,
  gyermek_potszabadsag_nap smallint NOT NULL DEFAULT 0,
  egyeb_jogcim_jsonb jsonb NOT NULL DEFAULT '{}'::jsonb,
  kivett_nap numeric(5,1) NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, user_id, ev)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.szabadsag_evente TO authenticated;
GRANT ALL ON public.szabadsag_evente TO service_role;
ALTER TABLE public.szabadsag_evente ENABLE ROW LEVEL SECURITY;
CREATE POLICY sze_read ON public.szabadsag_evente FOR SELECT TO authenticated
  USING (tenant_id = current_tenant_id() AND (user_id = auth.uid() OR has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));
CREATE POLICY sze_write ON public.szabadsag_evente FOR ALL TO authenticated
  USING (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')))
  WITH CHECK (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));

CREATE TABLE IF NOT EXISTS public.szolgalati_elismeres (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  fokozat smallint NOT NULL CHECK (fokozat IN (25,30,40,45,50)),
  varhato_datum date NOT NULL,
  kifizetes_datum date,
  osszeg_ft bigint,
  status text NOT NULL DEFAULT 'tervezett' CHECK (status IN ('tervezett','jovahagyva','kifizetve','elhalasztva')),
  megjegyzes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, user_id, fokozat)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.szolgalati_elismeres TO authenticated;
GRANT ALL ON public.szolgalati_elismeres TO service_role;
ALTER TABLE public.szolgalati_elismeres ENABLE ROW LEVEL SECURITY;
CREATE POLICY se_read ON public.szolgalati_elismeres FOR SELECT TO authenticated
  USING (tenant_id = current_tenant_id() AND (user_id = auth.uid() OR has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));
CREATE POLICY se_write ON public.szolgalati_elismeres FOR ALL TO authenticated
  USING (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')))
  WITH CHECK (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));

CREATE TABLE IF NOT EXISTS public.vegkielegites_szamitasok (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  user_id uuid NOT NULL,
  profile_employment_id uuid REFERENCES public.profile_employment(id) ON DELETE CASCADE,
  megszunes_jogcim text NOT NULL,
  felmentesi_ido_nap integer NOT NULL DEFAULT 0,
  vegkielegites_havi_szam numeric(3,1) NOT NULL DEFAULT 0,
  havi_illetmeny_ft bigint NOT NULL DEFAULT 0,
  osszeg_ft bigint NOT NULL DEFAULT 0,
  szamitas_datum date NOT NULL DEFAULT CURRENT_DATE,
  jovahagyo_user_id uuid REFERENCES auth.users(id),
  megjegyzes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE OR REPLACE FUNCTION public.set_vegki_osszeg() RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.osszeg_ft := (NEW.havi_illetmeny_ft * NEW.vegkielegites_havi_szam)::bigint; RETURN NEW; END $$;
CREATE TRIGGER trg_vegki_osszeg BEFORE INSERT OR UPDATE OF havi_illetmeny_ft, vegkielegites_havi_szam ON public.vegkielegites_szamitasok
  FOR EACH ROW EXECUTE FUNCTION public.set_vegki_osszeg();
GRANT SELECT, INSERT, UPDATE, DELETE ON public.vegkielegites_szamitasok TO authenticated;
GRANT ALL ON public.vegkielegites_szamitasok TO service_role;
ALTER TABLE public.vegkielegites_szamitasok ENABLE ROW LEVEL SECURITY;
CREATE POLICY vsz_read ON public.vegkielegites_szamitasok FOR SELECT TO authenticated
  USING (tenant_id = current_tenant_id() AND (user_id = auth.uid() OR has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));
CREATE POLICY vsz_write ON public.vegkielegites_szamitasok FOR ALL TO authenticated
  USING (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')))
  WITH CHECK (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));

CREATE TABLE IF NOT EXISTS public.juttatasok (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  tipus text NOT NULL CHECK (tipus IN ('lakhatasi_tamogatas','koltsegterites','utazasi','kepzesi','etkezesi','cafeteria','egyeb')),
  havi_osszeg_ft bigint NOT NULL DEFAULT 0,
  kezdo_datum date NOT NULL,
  zaro_datum date,
  dokumentum_url text,
  megjegyzes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.juttatasok TO authenticated;
GRANT ALL ON public.juttatasok TO service_role;
ALTER TABLE public.juttatasok ENABLE ROW LEVEL SECURITY;
CREATE POLICY jut_read ON public.juttatasok FOR SELECT TO authenticated
  USING (tenant_id = current_tenant_id() AND (user_id = auth.uid() OR has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));
CREATE POLICY jut_write ON public.juttatasok FOR ALL TO authenticated
  USING (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')))
  WITH CHECK (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));

CREATE TABLE IF NOT EXISTS public.kirendelesek (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  cel_egeszsegugyi_szolgaltato text NOT NULL,
  kezdo_datum date NOT NULL,
  zaro_datum date NOT NULL,
  indok text,
  napi_dij_ft bigint,
  hozzajarult boolean NOT NULL DEFAULT false,
  alairt_dokumentum_url text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (zaro_datum >= kezdo_datum)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.kirendelesek TO authenticated;
GRANT ALL ON public.kirendelesek TO service_role;
ALTER TABLE public.kirendelesek ENABLE ROW LEVEL SECURITY;
CREATE POLICY kir_read ON public.kirendelesek FOR SELECT TO authenticated
  USING (tenant_id = current_tenant_id() AND (user_id = auth.uid() OR has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));
CREATE POLICY kir_write ON public.kirendelesek FOR ALL TO authenticated
  USING (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')))
  WITH CHECK (tenant_id = current_tenant_id() AND (has_role(auth.uid(),'tenant_admin') OR has_permission(auth.uid(),'manage_eusztv')));

DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['profile_service_history','profile_service_time_overrides','probaidok','osszeferhetetlenseg_engedelyek','minosites','szabadsag_evente','szolgalati_elismeres','vegkielegites_szamitasok','juttatasok','kirendelesek'] LOOP
    EXECUTE format('CREATE TRIGGER trg_%I_updated_at BEFORE UPDATE ON public.%I FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column()', t, t);
  END LOOP;
END $$;

CREATE OR REPLACE FUNCTION public.calc_gyakorlati_ido(p_user_id uuid, p_datum date DEFAULT CURRENT_DATE)
RETURNS TABLE (napok integer, evek numeric)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE v_napok integer := 0; v_korrekcio integer := 0;
BEGIN
  WITH spans AS (
    SELECT kezdo_datum AS s, COALESCE(LEAST(zaro_datum, p_datum), p_datum) AS e FROM public.profile_employment WHERE user_id = p_user_id AND kezdo_datum <= p_datum
    UNION ALL
    SELECT kezdo_datum, COALESCE(LEAST(zaro_datum, p_datum), p_datum) FROM public.profile_service_history WHERE user_id = p_user_id AND beszamithato_eusztv = true AND kezdo_datum <= p_datum
  ),
  ordered AS (SELECT s, e FROM spans WHERE e >= s ORDER BY s, e),
  flagged AS (
    SELECT s, e, MAX(e) OVER (ORDER BY s, e ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING) AS prev_max FROM ordered
  ),
  grouped AS (
    SELECT s, e, SUM(CASE WHEN prev_max IS NULL OR s > prev_max THEN 1 ELSE 0 END) OVER (ORDER BY s, e ROWS UNBOUNDED PRECEDING) AS grp FROM flagged
  ),
  merged AS (SELECT grp, MIN(s) AS s, MAX(e) AS e FROM grouped GROUP BY grp)
  SELECT COALESCE(SUM((e - s) + 1), 0)::integer INTO v_napok FROM merged;

  SELECT COALESCE(SUM(napok_korrekcio),0) INTO v_korrekcio FROM public.profile_service_time_overrides
    WHERE user_id = p_user_id AND tipus = 'gyakorlati_ido' AND ervenyes_tol <= p_datum AND (ervenyes_ig IS NULL OR ervenyes_ig >= p_datum);
  v_napok := GREATEST(0, COALESCE(v_napok,0) + v_korrekcio);
  RETURN QUERY SELECT v_napok, ROUND(v_napok::numeric / 365.25, 2);
END $$;
GRANT EXECUTE ON FUNCTION public.calc_gyakorlati_ido(uuid, date) TO authenticated, service_role;

CREATE OR REPLACE FUNCTION public.calc_jubileumi_ido(p_user_id uuid, p_datum date DEFAULT CURRENT_DATE)
RETURNS TABLE (napok integer, evek numeric)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE v_napok integer := 0; v_korrekcio integer := 0;
BEGIN
  WITH spans AS (
    SELECT kezdo_datum AS s, COALESCE(LEAST(zaro_datum, p_datum), p_datum) AS e FROM public.profile_employment WHERE user_id = p_user_id AND kezdo_datum <= p_datum
    UNION ALL
    SELECT kezdo_datum, COALESCE(LEAST(zaro_datum, p_datum), p_datum) FROM public.profile_service_history WHERE user_id = p_user_id AND beszamithato_jubileum = true AND kezdo_datum <= p_datum
  ),
  ordered AS (SELECT s, e FROM spans WHERE e >= s ORDER BY s, e),
  flagged AS (SELECT s, e, MAX(e) OVER (ORDER BY s, e ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING) AS prev_max FROM ordered),
  grouped AS (SELECT s, e, SUM(CASE WHEN prev_max IS NULL OR s > prev_max THEN 1 ELSE 0 END) OVER (ORDER BY s, e ROWS UNBOUNDED PRECEDING) AS grp FROM flagged),
  merged AS (SELECT grp, MIN(s) AS s, MAX(e) AS e FROM grouped GROUP BY grp)
  SELECT COALESCE(SUM((e - s) + 1), 0)::integer INTO v_napok FROM merged;

  SELECT COALESCE(SUM(napok_korrekcio),0) INTO v_korrekcio FROM public.profile_service_time_overrides
    WHERE user_id = p_user_id AND tipus = 'jubileumi' AND ervenyes_tol <= p_datum AND (ervenyes_ig IS NULL OR ervenyes_ig >= p_datum);
  v_napok := GREATEST(0, COALESCE(v_napok,0) + v_korrekcio);
  RETURN QUERY SELECT v_napok, ROUND(v_napok::numeric / 365.25, 2);
END $$;
GRANT EXECUTE ON FUNCTION public.calc_jubileumi_ido(uuid, date) TO authenticated, service_role;

CREATE OR REPLACE FUNCTION public.calc_illetmeny(p_user_id uuid, p_datum date DEFAULT CURRENT_DATE)
RETURNS TABLE (alap_ft bigint, sav text, vezetoi_szorzo numeric, vegso_ft bigint, gyakorlati_evek numeric)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE v_evek numeric; v_napok integer; v_tabla_tipus public.eusztv_tabla_tipus; v_row record; v_orvos boolean := true; v_vezeto boolean := false;
BEGIN
  SELECT g.napok, g.evek INTO v_napok, v_evek FROM public.calc_gyakorlati_ido(p_user_id, p_datum) g;
  SELECT (lower(COALESCE(munkakor_megnevezes,'')) LIKE '%orvos%' OR lower(COALESCE(munkakor_megnevezes,'')) LIKE '%gyógyszerész%'), (vezetoi_szint IS NOT NULL)
    INTO v_orvos, v_vezeto
    FROM public.profile_employment WHERE user_id = p_user_id AND ervenyes = true
    ORDER BY elsodleges DESC NULLS LAST, kezdo_datum DESC LIMIT 1;
  v_tabla_tipus := CASE WHEN v_orvos THEN 'orvos_1mell'::public.eusztv_tabla_tipus ELSE 'szakdolgozo_1a_mell'::public.eusztv_tabla_tipus END;

  SELECT * INTO v_row FROM public.wage_table_egeszsegugyi
    WHERE tabla_tipus = v_tabla_tipus AND ervenyes_tol <= p_datum AND (ervenyes_ig IS NULL OR ervenyes_ig >= p_datum)
      AND COALESCE(gyakorlati_ido_tol_ev, 0) <= v_evek AND (gyakorlati_ido_ig_ev IS NULL OR v_evek <= gyakorlati_ido_ig_ev) AND osszeg_ft IS NOT NULL
    ORDER BY ervenyes_tol DESC, gyakorlati_ido_tol_ev DESC NULLS LAST LIMIT 1;

  IF v_row.id IS NULL THEN
    RETURN QUERY SELECT 0::bigint, 'nincs_besorolas'::text, 1.0::numeric, 0::bigint, v_evek; RETURN;
  END IF;
  RETURN QUERY SELECT v_row.osszeg_ft,
    COALESCE(v_row.gyakorlati_ido_tol_ev::text,'0') || '–' || COALESCE(v_row.gyakorlati_ido_ig_ev::text,'∞') || ' év',
    CASE WHEN v_vezeto THEN v_row.vezeto_szorzo ELSE 1.0 END,
    (v_row.osszeg_ft * CASE WHEN v_vezeto THEN v_row.vezeto_szorzo ELSE 1.0 END)::bigint,
    v_evek;
END $$;
GRANT EXECUTE ON FUNCTION public.calc_illetmeny(uuid, date) TO authenticated, service_role;

INSERT INTO public.role_permissions(role_kulcs, perm) VALUES ('tenant_admin','manage_eusztv') ON CONFLICT DO NOTHING;


-- ─── 20260629200555_3cc52d7a-3c14-4f89-aeed-57cef63f7baa.sql ───
-- =========================================================================
-- 1. profile_work_time_frame — időszakos havi munkaidő-keret munkavállalónként
-- =========================================================================
CREATE TABLE public.profile_work_time_frame (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  ervenyes_tol date NOT NULL,
  ervenyes_ig date,
  havi_orakeret numeric,
  szazalek numeric,
  indok text,
  rogzitette_user_id uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pwtf_value_present CHECK (havi_orakeret IS NOT NULL OR szazalek IS NOT NULL),
  CONSTRAINT pwtf_range CHECK (ervenyes_ig IS NULL OR ervenyes_ig >= ervenyes_tol)
);

CREATE INDEX pwtf_user_ervenyes_idx
  ON public.profile_work_time_frame (user_id, ervenyes_tol DESC);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.profile_work_time_frame TO authenticated;
GRANT ALL ON public.profile_work_time_frame TO service_role;

ALTER TABLE public.profile_work_time_frame ENABLE ROW LEVEL SECURITY;

CREATE POLICY "pwtf_select_self_or_admin"
  ON public.profile_work_time_frame
  FOR SELECT TO authenticated
  USING (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_eusztv')
  );

CREATE POLICY "pwtf_write_self_or_admin"
  ON public.profile_work_time_frame
  FOR ALL TO authenticated
  USING (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_eusztv')
  )
  WITH CHECK (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_eusztv')
  );

CREATE TRIGGER pwtf_touch
  BEFORE UPDATE ON public.profile_work_time_frame
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- =========================================================================
-- 2. illetmeny_snapshots — mentett havi illetmény-számítások
-- =========================================================================
CREATE TABLE public.illetmeny_snapshots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  cimke text NOT NULL,
  vonatkozasi_datum date NOT NULL DEFAULT CURRENT_DATE,
  bemenet jsonb NOT NULL DEFAULT '{}'::jsonb,
  eredmeny jsonb NOT NULL DEFAULT '{}'::jsonb,
  vegosszeg_ft numeric NOT NULL DEFAULT 0,
  jogi_hivatkozasok jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX illetmeny_snap_user_idx
  ON public.illetmeny_snapshots (user_id, created_at DESC);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.illetmeny_snapshots TO authenticated;
GRANT ALL ON public.illetmeny_snapshots TO service_role;

ALTER TABLE public.illetmeny_snapshots ENABLE ROW LEVEL SECURITY;

CREATE POLICY "isnap_select_self_or_admin"
  ON public.illetmeny_snapshots
  FOR SELECT TO authenticated
  USING (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_eusztv')
  );

CREATE POLICY "isnap_write_self_or_admin"
  ON public.illetmeny_snapshots
  FOR ALL TO authenticated
  USING (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_eusztv')
  )
  WITH CHECK (
    user_id = auth.uid()
    OR public.has_permission(auth.uid(), 'manage_eusztv')
  );

CREATE TRIGGER isnap_touch
  BEFORE UPDATE ON public.illetmeny_snapshots
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- ─── 20260629202107_7651e951-a62b-447f-92b8-e2e244651c89.sql ───

-- =====================================================================
-- CMS 1. fázis: oldalak, blokkok, menük, média, átirányítások, i18n
-- =====================================================================

-- Helper: van-e CMS jog (admin VAGY cms_editor)
CREATE OR REPLACE FUNCTION public.has_cms_access(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT public.has_role(_user_id, 'tenant_admin') OR public.has_role(_user_id, 'cms_editor');
$$;

-- ---------- cms_pages ----------
CREATE TABLE public.cms_pages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL,
  locale text NOT NULL DEFAULT 'hu',
  parent_id uuid REFERENCES public.cms_pages(id) ON DELETE SET NULL,
  title text NOT NULL,
  description text,
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published','archived')),
  published_at timestamptz,
  sort_order int NOT NULL DEFAULT 0,
  seo_title text,
  seo_description text,
  og_image_url text,
  show_in_sitemap boolean NOT NULL DEFAULT true,
  template text NOT NULL DEFAULT 'default',
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  updated_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (slug, locale)
);
CREATE INDEX cms_pages_status_idx ON public.cms_pages(status);
CREATE INDEX cms_pages_locale_idx ON public.cms_pages(locale);

GRANT SELECT ON public.cms_pages TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.cms_pages TO authenticated;
GRANT ALL ON public.cms_pages TO service_role;
ALTER TABLE public.cms_pages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read published pages" ON public.cms_pages FOR SELECT USING (status='published' OR public.has_cms_access(auth.uid()));
CREATE POLICY "cms editors manage pages" ON public.cms_pages FOR ALL TO authenticated USING (public.has_cms_access(auth.uid())) WITH CHECK (public.has_cms_access(auth.uid()));

-- ---------- cms_page_versions ----------
CREATE TABLE public.cms_page_versions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  page_id uuid NOT NULL REFERENCES public.cms_pages(id) ON DELETE CASCADE,
  version int NOT NULL,
  snapshot jsonb NOT NULL,
  is_published boolean NOT NULL DEFAULT false,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (page_id, version)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_page_versions TO authenticated;
GRANT ALL ON public.cms_page_versions TO service_role;
ALTER TABLE public.cms_page_versions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "cms editors manage versions" ON public.cms_page_versions FOR ALL TO authenticated USING (public.has_cms_access(auth.uid())) WITH CHECK (public.has_cms_access(auth.uid()));

-- ---------- cms_blocks ----------
CREATE TABLE public.cms_blocks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  page_id uuid NOT NULL REFERENCES public.cms_pages(id) ON DELETE CASCADE,
  block_type text NOT NULL,
  position int NOT NULL DEFAULT 0,
  locale text NOT NULL DEFAULT 'hu',
  content jsonb NOT NULL DEFAULT '{}'::jsonb,
  variant text NOT NULL DEFAULT 'default',
  is_published boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX cms_blocks_page_idx ON public.cms_blocks(page_id, position);
GRANT SELECT ON public.cms_blocks TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.cms_blocks TO authenticated;
GRANT ALL ON public.cms_blocks TO service_role;
ALTER TABLE public.cms_blocks ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read blocks of published pages" ON public.cms_blocks FOR SELECT USING (
  is_published AND EXISTS (SELECT 1 FROM public.cms_pages p WHERE p.id = cms_blocks.page_id AND p.status='published')
  OR public.has_cms_access(auth.uid())
);
CREATE POLICY "cms editors manage blocks" ON public.cms_blocks FOR ALL TO authenticated USING (public.has_cms_access(auth.uid())) WITH CHECK (public.has_cms_access(auth.uid()));

-- ---------- cms_menus ----------
CREATE TABLE public.cms_menus (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text NOT NULL UNIQUE,
  name text NOT NULL,
  location text NOT NULL DEFAULT 'header',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.cms_menus TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.cms_menus TO authenticated;
GRANT ALL ON public.cms_menus TO service_role;
ALTER TABLE public.cms_menus ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read menus" ON public.cms_menus FOR SELECT USING (true);
CREATE POLICY "cms editors manage menus" ON public.cms_menus FOR ALL TO authenticated USING (public.has_cms_access(auth.uid())) WITH CHECK (public.has_cms_access(auth.uid()));

-- ---------- cms_menu_items ----------
CREATE TABLE public.cms_menu_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  menu_id uuid NOT NULL REFERENCES public.cms_menus(id) ON DELETE CASCADE,
  parent_id uuid REFERENCES public.cms_menu_items(id) ON DELETE CASCADE,
  position int NOT NULL DEFAULT 0,
  label text NOT NULL,
  url text,
  page_id uuid REFERENCES public.cms_pages(id) ON DELETE SET NULL,
  locale text NOT NULL DEFAULT 'hu',
  open_in_new_tab boolean NOT NULL DEFAULT false,
  icon text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX cms_menu_items_menu_idx ON public.cms_menu_items(menu_id, position);
GRANT SELECT ON public.cms_menu_items TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.cms_menu_items TO authenticated;
GRANT ALL ON public.cms_menu_items TO service_role;
ALTER TABLE public.cms_menu_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read menu items" ON public.cms_menu_items FOR SELECT USING (true);
CREATE POLICY "cms editors manage menu items" ON public.cms_menu_items FOR ALL TO authenticated USING (public.has_cms_access(auth.uid())) WITH CHECK (public.has_cms_access(auth.uid()));

-- ---------- cms_media ----------
CREATE TABLE public.cms_media (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  storage_path text NOT NULL,
  file_name text NOT NULL,
  mime_type text NOT NULL,
  size_bytes bigint NOT NULL DEFAULT 0,
  width int,
  height int,
  alt_text text,
  caption text,
  category text,
  tags text[] DEFAULT '{}',
  uploaded_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX cms_media_category_idx ON public.cms_media(category);
GRANT SELECT ON public.cms_media TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.cms_media TO authenticated;
GRANT ALL ON public.cms_media TO service_role;
ALTER TABLE public.cms_media ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read media" ON public.cms_media FOR SELECT USING (true);
CREATE POLICY "cms editors manage media" ON public.cms_media FOR ALL TO authenticated USING (public.has_cms_access(auth.uid())) WITH CHECK (public.has_cms_access(auth.uid()));

-- ---------- cms_redirects ----------
CREATE TABLE public.cms_redirects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  source_path text NOT NULL UNIQUE,
  target_path text NOT NULL,
  status_code int NOT NULL DEFAULT 301 CHECK (status_code IN (301,302,307,308)),
  note text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.cms_redirects TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.cms_redirects TO authenticated;
GRANT ALL ON public.cms_redirects TO service_role;
ALTER TABLE public.cms_redirects ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read redirects" ON public.cms_redirects FOR SELECT USING (is_active);
CREATE POLICY "cms editors manage redirects" ON public.cms_redirects FOR ALL TO authenticated USING (public.has_cms_access(auth.uid())) WITH CHECK (public.has_cms_access(auth.uid()));

-- ---------- cms_i18n_content ----------
CREATE TABLE public.cms_i18n_content (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  entity_type text NOT NULL,
  entity_id uuid NOT NULL,
  locale text NOT NULL,
  data jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (entity_type, entity_id, locale)
);
GRANT SELECT ON public.cms_i18n_content TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.cms_i18n_content TO authenticated;
GRANT ALL ON public.cms_i18n_content TO service_role;
ALTER TABLE public.cms_i18n_content ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read i18n" ON public.cms_i18n_content FOR SELECT USING (true);
CREATE POLICY "cms editors manage i18n" ON public.cms_i18n_content FOR ALL TO authenticated USING (public.has_cms_access(auth.uid())) WITH CHECK (public.has_cms_access(auth.uid()));

-- ---------- updated_at trigger ----------
CREATE OR REPLACE FUNCTION public.cms_touch_updated_at() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

CREATE TRIGGER cms_pages_touch BEFORE UPDATE ON public.cms_pages FOR EACH ROW EXECUTE FUNCTION public.cms_touch_updated_at();
CREATE TRIGGER cms_blocks_touch BEFORE UPDATE ON public.cms_blocks FOR EACH ROW EXECUTE FUNCTION public.cms_touch_updated_at();
CREATE TRIGGER cms_menus_touch BEFORE UPDATE ON public.cms_menus FOR EACH ROW EXECUTE FUNCTION public.cms_touch_updated_at();
CREATE TRIGGER cms_menu_items_touch BEFORE UPDATE ON public.cms_menu_items FOR EACH ROW EXECUTE FUNCTION public.cms_touch_updated_at();
CREATE TRIGGER cms_redirects_touch BEFORE UPDATE ON public.cms_redirects FOR EACH ROW EXECUTE FUNCTION public.cms_touch_updated_at();

-- ---------- Default menus ----------
INSERT INTO public.cms_menus (key, name, location) VALUES
  ('main', 'Főmenü', 'header'),
  ('footer', 'Lábléc menü', 'footer')
ON CONFLICT (key) DO NOTHING;


-- ─── 20260629202145_91c856ab-2371-4c9a-8ed5-5b4b21c04da3.sql ───

CREATE POLICY "cms-media public read" ON storage.objects FOR SELECT USING (bucket_id = 'cms-media');
CREATE POLICY "cms-media editors upload" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'cms-media' AND public.has_cms_access(auth.uid()));
CREATE POLICY "cms-media editors update" ON storage.objects FOR UPDATE TO authenticated USING (bucket_id = 'cms-media' AND public.has_cms_access(auth.uid()));
CREATE POLICY "cms-media editors delete" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'cms-media' AND public.has_cms_access(auth.uid()));


-- ─── 20260629205127_39a48658-cb7c-4454-b9c4-82d5939d368c.sql ───
-- ============================================================
-- 1) cms_staff_profiles
-- ============================================================
CREATE TABLE IF NOT EXISTS public.cms_staff_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  slug text NOT NULL,
  locale text NOT NULL DEFAULT 'hu',
  display_name text NOT NULL,
  title text,
  photo_url text,
  bio text,
  specialties text[] DEFAULT '{}',
  languages text[] DEFAULT '{}',
  publications jsonb DEFAULT '[]'::jsonb,
  publish_schedule boolean DEFAULT false,
  is_published boolean DEFAULT false,
  sort_order int DEFAULT 0,
  seo_title text,
  seo_description text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (slug, locale)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_staff_profiles TO authenticated;
GRANT SELECT ON public.cms_staff_profiles TO anon;
GRANT ALL ON public.cms_staff_profiles TO service_role;

ALTER TABLE public.cms_staff_profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public can view published staff profiles"
  ON public.cms_staff_profiles FOR SELECT
  USING (is_published = true);

CREATE POLICY "CMS editors manage staff profiles"
  ON public.cms_staff_profiles FOR ALL
  TO authenticated
  USING (public.has_cms_access(auth.uid()))
  WITH CHECK (public.has_cms_access(auth.uid()));

-- ============================================================
-- 2) cms_faqs
-- ============================================================
CREATE TABLE IF NOT EXISTS public.cms_faqs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  locale text NOT NULL DEFAULT 'hu',
  question text NOT NULL,
  answer text NOT NULL,
  tags text[] DEFAULT '{}',
  sort_order int DEFAULT 0,
  is_published boolean DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_faqs TO authenticated;
GRANT SELECT ON public.cms_faqs TO anon;
GRANT ALL ON public.cms_faqs TO service_role;

ALTER TABLE public.cms_faqs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public can view published FAQs"
  ON public.cms_faqs FOR SELECT
  USING (is_published = true);

CREATE POLICY "CMS editors manage FAQs"
  ON public.cms_faqs FOR ALL
  TO authenticated
  USING (public.has_cms_access(auth.uid()))
  WITH CHECK (public.has_cms_access(auth.uid()));

CREATE INDEX IF NOT EXISTS cms_faqs_tags_idx ON public.cms_faqs USING GIN (tags);

-- ============================================================
-- 3) contact_messages
-- ============================================================
CREATE TABLE IF NOT EXISTS public.contact_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_unit_id uuid REFERENCES public.org_units(id) ON DELETE SET NULL,
  source_page_slug text,
  sender_name text NOT NULL,
  sender_email text NOT NULL,
  sender_phone text,
  subject text,
  body text NOT NULL,
  locale text DEFAULT 'hu',
  status text NOT NULL DEFAULT 'new',
  handled_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  handled_at timestamptz,
  ip_hash text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT INSERT ON public.contact_messages TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.contact_messages TO authenticated;
GRANT ALL ON public.contact_messages TO service_role;

ALTER TABLE public.contact_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can submit a contact message"
  ON public.contact_messages FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "CMS editors view contact messages"
  ON public.contact_messages FOR SELECT
  TO authenticated
  USING (public.has_cms_access(auth.uid()));

CREATE POLICY "CMS editors update contact messages"
  ON public.contact_messages FOR UPDATE
  TO authenticated
  USING (public.has_cms_access(auth.uid()))
  WITH CHECK (public.has_cms_access(auth.uid()));

CREATE INDEX IF NOT EXISTS contact_messages_status_idx ON public.contact_messages (status, created_at DESC);

-- ============================================================
-- 4) cms_site_settings (single-row config)
-- ============================================================
CREATE TABLE IF NOT EXISTS public.cms_site_settings (
  id int PRIMARY KEY DEFAULT 1,
  sos_active boolean NOT NULL DEFAULT false,
  sos_message text,
  robots_txt text,
  default_og_image_url text,
  default_locale text NOT NULL DEFAULT 'hu',
  organization_jsonld jsonb,
  updated_at timestamptz NOT NULL DEFAULT now(),
  updated_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  CONSTRAINT cms_site_settings_singleton CHECK (id = 1)
);

GRANT SELECT, INSERT, UPDATE ON public.cms_site_settings TO authenticated;
GRANT SELECT ON public.cms_site_settings TO anon;
GRANT ALL ON public.cms_site_settings TO service_role;

ALTER TABLE public.cms_site_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public can view site settings"
  ON public.cms_site_settings FOR SELECT
  USING (true);

CREATE POLICY "CMS editors manage site settings"
  ON public.cms_site_settings FOR ALL
  TO authenticated
  USING (public.has_cms_access(auth.uid()))
  WITH CHECK (public.has_cms_access(auth.uid()));

INSERT INTO public.cms_site_settings (id) VALUES (1) ON CONFLICT (id) DO NOTHING;

-- ============================================================
-- updated_at triggers
-- ============================================================
CREATE OR REPLACE FUNCTION public.cms_touch_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END $$;

DROP TRIGGER IF EXISTS trg_cms_staff_profiles_touch ON public.cms_staff_profiles;
CREATE TRIGGER trg_cms_staff_profiles_touch BEFORE UPDATE ON public.cms_staff_profiles
  FOR EACH ROW EXECUTE FUNCTION public.cms_touch_updated_at();

DROP TRIGGER IF EXISTS trg_cms_faqs_touch ON public.cms_faqs;
CREATE TRIGGER trg_cms_faqs_touch BEFORE UPDATE ON public.cms_faqs
  FOR EACH ROW EXECUTE FUNCTION public.cms_touch_updated_at();

DROP TRIGGER IF EXISTS trg_contact_messages_touch ON public.contact_messages;
CREATE TRIGGER trg_contact_messages_touch BEFORE UPDATE ON public.contact_messages
  FOR EACH ROW EXECUTE FUNCTION public.cms_touch_updated_at();

DROP TRIGGER IF EXISTS trg_cms_site_settings_touch ON public.cms_site_settings;
CREATE TRIGGER trg_cms_site_settings_touch BEFORE UPDATE ON public.cms_site_settings
  FOR EACH ROW EXECUTE FUNCTION public.cms_touch_updated_at();

-- ─── 20260630075216_1ba932bb-e3a9-41f6-98d5-43a076e440f7.sql ───
-- CMS news content type with categories (parent/child), tags and guest authors

-- Categories with parent/child support
CREATE TABLE public.cms_news_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_id uuid REFERENCES public.cms_news_categories(id) ON DELETE SET NULL,
  slug text NOT NULL UNIQUE,
  name text NOT NULL,
  description text,
  sort_order integer NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.cms_news_categories TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_news_categories TO authenticated;
GRANT ALL ON public.cms_news_categories TO service_role;
ALTER TABLE public.cms_news_categories ENABLE ROW LEVEL SECURITY;
CREATE POLICY "news cats public read" ON public.cms_news_categories FOR SELECT TO anon, authenticated USING (is_active = true);
CREATE POLICY "news cats cms manage" ON public.cms_news_categories FOR ALL TO authenticated USING (public.has_cms_access(auth.uid())) WITH CHECK (public.has_cms_access(auth.uid()));

-- Tags
CREATE TABLE public.cms_news_tags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  name text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.cms_news_tags TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_news_tags TO authenticated;
GRANT ALL ON public.cms_news_tags TO service_role;
ALTER TABLE public.cms_news_tags ENABLE ROW LEVEL SECURITY;
CREATE POLICY "news tags public read" ON public.cms_news_tags FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "news tags cms manage" ON public.cms_news_tags FOR ALL TO authenticated USING (public.has_cms_access(auth.uid())) WITH CHECK (public.has_cms_access(auth.uid()));

-- Guest authors (optional override of auth user)
CREATE TABLE public.cms_news_authors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  display_name text NOT NULL,
  bio text,
  avatar_url text,
  email text,
  is_guest boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.cms_news_authors TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_news_authors TO authenticated;
GRANT ALL ON public.cms_news_authors TO service_role;
ALTER TABLE public.cms_news_authors ENABLE ROW LEVEL SECURITY;
CREATE POLICY "news authors public read" ON public.cms_news_authors FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "news authors cms manage" ON public.cms_news_authors FOR ALL TO authenticated USING (public.has_cms_access(auth.uid())) WITH CHECK (public.has_cms_access(auth.uid()));

-- News posts
CREATE TABLE public.cms_news_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  locale text NOT NULL DEFAULT 'hu',
  title text NOT NULL,
  excerpt text,
  body jsonb NOT NULL DEFAULT '{}'::jsonb,
  featured_image_url text,
  featured_image_alt text,
  author_id uuid REFERENCES public.cms_news_authors(id) ON DELETE SET NULL,
  category_id uuid REFERENCES public.cms_news_categories(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','scheduled','published','archived')),
  published_at timestamptz,
  seo_title text,
  seo_description text,
  og_image_url text,
  view_count integer NOT NULL DEFAULT 0,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  updated_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.cms_news_posts TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_news_posts TO authenticated;
GRANT ALL ON public.cms_news_posts TO service_role;
ALTER TABLE public.cms_news_posts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "news public read published" ON public.cms_news_posts FOR SELECT TO anon, authenticated
  USING (status = 'published' AND published_at IS NOT NULL AND published_at <= now());
CREATE POLICY "news cms read all" ON public.cms_news_posts FOR SELECT TO authenticated USING (public.has_cms_access(auth.uid()));
CREATE POLICY "news cms manage" ON public.cms_news_posts FOR ALL TO authenticated USING (public.has_cms_access(auth.uid())) WITH CHECK (public.has_cms_access(auth.uid()));

CREATE INDEX cms_news_posts_status_published_idx ON public.cms_news_posts(status, published_at DESC);
CREATE INDEX cms_news_posts_category_idx ON public.cms_news_posts(category_id);
CREATE INDEX cms_news_posts_locale_idx ON public.cms_news_posts(locale);

-- Tag join
CREATE TABLE public.cms_news_post_tags (
  post_id uuid NOT NULL REFERENCES public.cms_news_posts(id) ON DELETE CASCADE,
  tag_id uuid NOT NULL REFERENCES public.cms_news_tags(id) ON DELETE CASCADE,
  PRIMARY KEY (post_id, tag_id)
);
GRANT SELECT ON public.cms_news_post_tags TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_news_post_tags TO authenticated;
GRANT ALL ON public.cms_news_post_tags TO service_role;
ALTER TABLE public.cms_news_post_tags ENABLE ROW LEVEL SECURITY;
CREATE POLICY "news post tags public read" ON public.cms_news_post_tags FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "news post tags cms manage" ON public.cms_news_post_tags FOR ALL TO authenticated USING (public.has_cms_access(auth.uid())) WITH CHECK (public.has_cms_access(auth.uid()));

-- updated_at triggers (use existing public.update_updated_at_column if available; otherwise create)
CREATE OR REPLACE FUNCTION public.cms_news_touch_updated_at()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;
CREATE TRIGGER trg_cms_news_categories_uat BEFORE UPDATE ON public.cms_news_categories
  FOR EACH ROW EXECUTE FUNCTION public.cms_news_touch_updated_at();
CREATE TRIGGER trg_cms_news_authors_uat BEFORE UPDATE ON public.cms_news_authors
  FOR EACH ROW EXECUTE FUNCTION public.cms_news_touch_updated_at();
CREATE TRIGGER trg_cms_news_posts_uat BEFORE UPDATE ON public.cms_news_posts
  FOR EACH ROW EXECUTE FUNCTION public.cms_news_touch_updated_at();

-- View count RPC (anon callable)
CREATE OR REPLACE FUNCTION public.cms_news_increment_view(_slug text)
RETURNS void LANGUAGE sql SECURITY DEFINER SET search_path = public AS $$
  UPDATE public.cms_news_posts SET view_count = view_count + 1
  WHERE slug = _slug AND status = 'published' AND published_at <= now();
$$;
GRANT EXECUTE ON FUNCTION public.cms_news_increment_view(text) TO anon, authenticated;

-- ─── 20260630080444_8f3073dc-86f5-46d1-b3b3-a9c4a7ae3ea7.sql ───

-- 1. cms_pages bővítés: home/system flag, layout, nav címke
ALTER TABLE public.cms_pages
  ADD COLUMN IF NOT EXISTS is_home boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS is_system boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS layout text NOT NULL DEFAULT 'default',
  ADD COLUMN IF NOT EXISTS nav_label text;

-- Csak EGY home page lehet egyszerre
CREATE UNIQUE INDEX IF NOT EXISTS cms_pages_only_one_home
  ON public.cms_pages ((1)) WHERE is_home = true;

-- 2. Globális régiók (header, top_bar, footer, mobile_drawer)
CREATE TABLE IF NOT EXISTS public.cms_global_regions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  region_key text NOT NULL,
  locale text NOT NULL DEFAULT 'hu',
  blocks jsonb NOT NULL DEFAULT '[]'::jsonb,
  status text NOT NULL DEFAULT 'published',
  updated_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (region_key, locale)
);
GRANT SELECT ON public.cms_global_regions TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_global_regions TO authenticated;
GRANT ALL ON public.cms_global_regions TO service_role;
ALTER TABLE public.cms_global_regions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "anyone reads published regions"
  ON public.cms_global_regions FOR SELECT
  USING (status = 'published');
CREATE POLICY "cms editors manage regions"
  ON public.cms_global_regions FOR ALL
  TO authenticated
  USING (public.has_cms_access(auth.uid()))
  WITH CHECK (public.has_cms_access(auth.uid()));

CREATE TRIGGER trg_cms_global_regions_updated
  BEFORE UPDATE ON public.cms_global_regions
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 3. Design tokenek (brand színek, betűk, sugarak)
CREATE TABLE IF NOT EXISTS public.cms_design_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  token_key text NOT NULL UNIQUE,
  value jsonb NOT NULL,
  scope text NOT NULL DEFAULT 'global',
  description text,
  updated_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.cms_design_tokens TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_design_tokens TO authenticated;
GRANT ALL ON public.cms_design_tokens TO service_role;
ALTER TABLE public.cms_design_tokens ENABLE ROW LEVEL SECURITY;

CREATE POLICY "anyone reads design tokens"
  ON public.cms_design_tokens FOR SELECT USING (true);
CREATE POLICY "cms editors manage tokens"
  ON public.cms_design_tokens FOR ALL
  TO authenticated
  USING (public.has_cms_access(auth.uid()))
  WITH CHECK (public.has_cms_access(auth.uid()));

CREATE TRIGGER trg_cms_design_tokens_updated
  BEFORE UPDATE ON public.cms_design_tokens
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 4. Egységes layout blokk tábla (oldal + globális blokk-tár alapja)
CREATE TABLE IF NOT EXISTS public.cms_layout_blocks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  page_id uuid REFERENCES public.cms_pages(id) ON DELETE CASCADE,
  region_key text,
  position integer NOT NULL DEFAULT 0,
  block_type text NOT NULL,
  content jsonb NOT NULL DEFAULT '{}'::jsonb,
  style jsonb NOT NULL DEFAULT '{}'::jsonb,
  visibility jsonb NOT NULL DEFAULT '{}'::jsonb,
  locale text NOT NULL DEFAULT 'hu',
  status text NOT NULL DEFAULT 'published',
  schedule_at timestamptz,
  end_at timestamptz,
  version integer NOT NULL DEFAULT 1,
  created_by uuid REFERENCES auth.users(id),
  updated_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT cms_layout_blocks_target_chk CHECK (
    (page_id IS NOT NULL AND region_key IS NULL)
    OR (page_id IS NULL AND region_key IS NOT NULL)
  )
);
CREATE INDEX IF NOT EXISTS cms_layout_blocks_page_idx
  ON public.cms_layout_blocks(page_id, locale, position);
CREATE INDEX IF NOT EXISTS cms_layout_blocks_region_idx
  ON public.cms_layout_blocks(region_key, locale, position);

GRANT SELECT ON public.cms_layout_blocks TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_layout_blocks TO authenticated;
GRANT ALL ON public.cms_layout_blocks TO service_role;
ALTER TABLE public.cms_layout_blocks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "anyone reads published layout blocks"
  ON public.cms_layout_blocks FOR SELECT
  USING (
    status = 'published'
    AND (schedule_at IS NULL OR schedule_at <= now())
    AND (end_at IS NULL OR end_at > now())
  );
CREATE POLICY "cms editors manage layout blocks"
  ON public.cms_layout_blocks FOR ALL
  TO authenticated
  USING (public.has_cms_access(auth.uid()))
  WITH CHECK (public.has_cms_access(auth.uid()));

CREATE TRIGGER trg_cms_layout_blocks_updated
  BEFORE UPDATE ON public.cms_layout_blocks
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 5. Verziók: autosave snapshot támogatás (ha még nincs)
ALTER TABLE public.cms_page_versions
  ADD COLUMN IF NOT EXISTS is_autosave boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS snapshot jsonb;

-- 6. Helper: aktuális home page lekérése (frontend gyors útvonal)
CREATE OR REPLACE FUNCTION public.get_home_page_id()
RETURNS uuid
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT id FROM public.cms_pages WHERE is_home = true AND status = 'published' LIMIT 1;
$$;


-- ─── 20260630093536_5e48ebae-4883-45a7-bc46-4c2752f19717.sql ───

ALTER TABLE public.cms_pages
  ADD COLUMN IF NOT EXISTS scheduled_publish_at timestamptz,
  ADD COLUMN IF NOT EXISTS noindex boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS preview_token uuid NOT NULL DEFAULT gen_random_uuid();

CREATE INDEX IF NOT EXISTS cms_pages_scheduled_publish_at_idx
  ON public.cms_pages (scheduled_publish_at)
  WHERE scheduled_publish_at IS NOT NULL;

-- Cron-szerű auto-publish: a scheduled státuszú oldalakat élesíti,
-- ha a scheduled_publish_at időpont elérkezett.
CREATE OR REPLACE FUNCTION public.cms_promote_scheduled_pages()
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  n integer;
BEGIN
  UPDATE public.cms_pages
     SET status = 'published',
         published_at = COALESCE(scheduled_publish_at, now()),
         scheduled_publish_at = NULL
   WHERE status = 'scheduled'
     AND scheduled_publish_at IS NOT NULL
     AND scheduled_publish_at <= now();
  GET DIAGNOSTICS n = ROW_COUNT;
  RETURN n;
END;
$$;


-- ─── 20260630093917_b61bcd63-beb3-4961-a343-763e3a7b7702.sql ───

CREATE OR REPLACE FUNCTION public.cms_pages_autoredirect_on_slug_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  old_path text;
  new_path text;
BEGIN
  IF NEW.slug = OLD.slug AND NEW.locale = OLD.locale THEN
    RETURN NEW;
  END IF;

  old_path := CASE WHEN OLD.locale = 'hu' THEN '/o/' || OLD.slug ELSE '/' || OLD.locale || '/o/' || OLD.slug END;
  new_path := CASE WHEN NEW.locale = 'hu' THEN '/o/' || NEW.slug ELSE '/' || NEW.locale || '/o/' || NEW.slug END;

  IF old_path = new_path THEN
    RETURN NEW;
  END IF;

  -- Ha már létezik aktív redirect ugyanerre a source-ra, frissítsük a célt;
  -- különben szúrjunk be újat.
  INSERT INTO public.cms_redirects (source_path, target_path, status_code, is_active, note)
  VALUES (old_path, new_path, 301, true, 'Auto: slug-változás')
  ON CONFLICT (source_path) DO UPDATE
    SET target_path = EXCLUDED.target_path,
        status_code = 301,
        is_active = true,
        updated_at = now();

  -- Láncreakció elkerülése: ha az új path ugyanaz, mint egy meglévő redirect source-a, kapcsoljuk ki azt.
  UPDATE public.cms_redirects SET is_active = false
   WHERE source_path = new_path;

  RETURN NEW;
END;
$$;

-- A trigger biztosítja, hogy a slug/locale módosulás előtt a régi értékek elérhetők.
DROP TRIGGER IF EXISTS cms_pages_slug_change_redirect ON public.cms_pages;
CREATE TRIGGER cms_pages_slug_change_redirect
  AFTER UPDATE OF slug, locale ON public.cms_pages
  FOR EACH ROW
  EXECUTE FUNCTION public.cms_pages_autoredirect_on_slug_change();

-- Az ON CONFLICT-hoz unique index a source_path-on (idempotens).
CREATE UNIQUE INDEX IF NOT EXISTS cms_redirects_source_path_uniq
  ON public.cms_redirects (source_path);


-- ─── 20260630095554_94dbb2f7-cedc-4472-974f-f7e43b4aad1b.sql ───

ALTER TABLE public.cms_news_posts
  ADD COLUMN IF NOT EXISTS post_type text NOT NULL DEFAULT 'blog',
  ADD COLUMN IF NOT EXISTS video_provider text,
  ADD COLUMN IF NOT EXISTS video_url text,
  ADD COLUMN IF NOT EXISTS video_embed_url text,
  ADD COLUMN IF NOT EXISTS video_thumbnail_url text,
  ADD COLUMN IF NOT EXISTS video_duration_seconds integer,
  ADD COLUMN IF NOT EXISTS video_transcript text;

ALTER TABLE public.cms_news_posts
  DROP CONSTRAINT IF EXISTS cms_news_posts_post_type_check;
ALTER TABLE public.cms_news_posts
  ADD CONSTRAINT cms_news_posts_post_type_check CHECK (post_type IN ('blog','vlog'));

ALTER TABLE public.cms_news_posts
  DROP CONSTRAINT IF EXISTS cms_news_posts_video_provider_check;
ALTER TABLE public.cms_news_posts
  ADD CONSTRAINT cms_news_posts_video_provider_check
  CHECK (video_provider IS NULL OR video_provider IN ('youtube','vimeo','file'));

CREATE INDEX IF NOT EXISTS cms_news_posts_post_type_status_idx
  ON public.cms_news_posts (post_type, status, published_at DESC);


-- ─── 20260630102522_324fff3b-4281-4ee4-aa37-768ababc9c32.sql ───
-- ===== CMS workflow + audit log: 1. fázis (A migráció) =====

-- 1) ENUM-ok
CREATE TYPE public.cms_workflow_state AS ENUM (
  'draft', 'in_review', 'approved', 'published', 'rejected', 'archived'
);

CREATE TYPE public.cms_audit_action AS ENUM (
  'create', 'update', 'delete',
  'submit_review', 'approve', 'reject',
  'publish', 'unpublish',
  'revert', 'restore'
);

-- 2) Új CMS szerepkörök (admin kategória)
INSERT INTO public.roles (kulcs, megnevezes, kategoria, sorrend) VALUES
  ('cms_reviewer', 'CMS véleményező', 'admin', 100),
  ('cms_publisher', 'CMS publikáló', 'admin', 101)
ON CONFLICT (kulcs) DO NOTHING;

-- 3) Bővített cms hozzáférés-ellenőrzés
CREATE OR REPLACE FUNCTION public.has_cms_access(_user_id uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT
    public.has_role(_user_id, 'tenant_admin')
    OR public.has_role(_user_id, 'cms_editor')
    OR public.has_role(_user_id, 'cms_reviewer')
    OR public.has_role(_user_id, 'cms_publisher');
$$;

CREATE OR REPLACE FUNCTION public.has_cms_editor(_user_id uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT
    public.has_role(_user_id, 'tenant_admin')
    OR public.has_role(_user_id, 'cms_editor')
    OR public.has_role(_user_id, 'cms_reviewer')
    OR public.has_role(_user_id, 'cms_publisher');
$$;

CREATE OR REPLACE FUNCTION public.has_cms_reviewer(_user_id uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT
    public.has_role(_user_id, 'tenant_admin')
    OR public.has_role(_user_id, 'cms_reviewer')
    OR public.has_role(_user_id, 'cms_publisher');
$$;

CREATE OR REPLACE FUNCTION public.has_cms_publisher(_user_id uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT
    public.has_role(_user_id, 'tenant_admin')
    OR public.has_role(_user_id, 'cms_publisher');
$$;

-- 4) Audit log tábla
CREATE TABLE public.cms_audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz NOT NULL DEFAULT now(),
  entity_type text NOT NULL,
  entity_id uuid,
  entity_slug text,
  entity_locale text,
  action public.cms_audit_action NOT NULL,
  actor_id uuid,
  actor_email text,
  before jsonb,
  after jsonb,
  diff jsonb,
  comment text,
  request_meta jsonb DEFAULT '{}'::jsonb
);

CREATE INDEX cms_audit_log_entity_idx
  ON public.cms_audit_log (entity_type, entity_id, created_at DESC);
CREATE INDEX cms_audit_log_actor_idx
  ON public.cms_audit_log (actor_id, created_at DESC);
CREATE INDEX cms_audit_log_action_idx
  ON public.cms_audit_log (action, created_at DESC);

GRANT SELECT ON public.cms_audit_log TO authenticated;
GRANT ALL ON public.cms_audit_log TO service_role;

ALTER TABLE public.cms_audit_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "cms_audit_log_select"
  ON public.cms_audit_log
  FOR SELECT
  TO authenticated
  USING (public.has_cms_access(auth.uid()));

-- (RLS enabled + nincs INSERT policy → tiltott; csak SECURITY DEFINER fn írhat)

-- 5) Audit író helper
CREATE OR REPLACE FUNCTION public.cms_audit_write(
  _entity_type text,
  _entity_id uuid,
  _action public.cms_audit_action,
  _before jsonb DEFAULT NULL,
  _after jsonb DEFAULT NULL,
  _comment text DEFAULT NULL,
  _entity_slug text DEFAULT NULL,
  _entity_locale text DEFAULT NULL,
  _request_meta jsonb DEFAULT '{}'::jsonb
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _id uuid;
  _email text;
  _diff jsonb;
BEGIN
  SELECT email INTO _email FROM auth.users WHERE id = auth.uid();

  IF _before IS NOT NULL AND _after IS NOT NULL THEN
    SELECT jsonb_object_agg(key, value) INTO _diff
    FROM jsonb_each(_after)
    WHERE COALESCE(_before -> key, 'null'::jsonb) IS DISTINCT FROM value;
  ELSE
    _diff := NULL;
  END IF;

  INSERT INTO public.cms_audit_log (
    entity_type, entity_id, entity_slug, entity_locale,
    action, actor_id, actor_email,
    before, after, diff, comment, request_meta
  ) VALUES (
    _entity_type, _entity_id, _entity_slug, _entity_locale,
    _action, auth.uid(), _email,
    _before, _after, _diff, _comment, COALESCE(_request_meta, '{}'::jsonb)
  )
  RETURNING id INTO _id;

  RETURN _id;
END;
$$;

REVOKE ALL ON FUNCTION public.cms_audit_write(text, uuid, public.cms_audit_action, jsonb, jsonb, text, text, text, jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.cms_audit_write(text, uuid, public.cms_audit_action, jsonb, jsonb, text, text, text, jsonb) TO authenticated;

-- ─── 20260630102639_f91133f9-8c23-4e66-8324-d1547865d035.sql ───
-- ===== CMS workflow + audit log: 1. fázis (B migráció) =====
-- Workflow oszlopok minden érintett CMS táblán

-- Helper: backfill expression (status alapján)
-- A táblák egy részén van 'status' column ('draft'/'published'/'scheduled'/'archived');
-- másoknál csak boolean 'is_active'/'is_published' van. Külön kezeljük.

DO $$
DECLARE
  t text;
  has_status boolean;
  has_is_active boolean;
  has_is_published boolean;
  tables text[] := ARRAY[
    'cms_pages', 'cms_news_posts', 'cms_blocks', 'cms_layout_blocks',
    'cms_menus', 'cms_menu_items', 'cms_redirects', 'cms_staff_profiles',
    'cms_faqs', 'cms_design_tokens', 'cms_site_settings',
    'cms_global_regions', 'cms_media'
  ];
BEGIN
  FOREACH t IN ARRAY tables LOOP
    -- 1. oszlopok hozzáadása (idempotens)
    EXECUTE format('ALTER TABLE public.%I
      ADD COLUMN IF NOT EXISTS workflow_state public.cms_workflow_state NOT NULL DEFAULT ''draft'',
      ADD COLUMN IF NOT EXISTS submitted_for_review_at timestamptz,
      ADD COLUMN IF NOT EXISTS submitted_by uuid,
      ADD COLUMN IF NOT EXISTS approved_at timestamptz,
      ADD COLUMN IF NOT EXISTS approved_by uuid,
      ADD COLUMN IF NOT EXISTS rejected_at timestamptz,
      ADD COLUMN IF NOT EXISTS rejected_by uuid,
      ADD COLUMN IF NOT EXISTS rejection_reason text', t);

    -- 2. backfill state
    SELECT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name=t AND column_name='status') INTO has_status;
    SELECT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name=t AND column_name='is_active') INTO has_is_active;
    SELECT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name=t AND column_name='is_published') INTO has_is_published;

    IF has_status THEN
      EXECUTE format(
        'UPDATE public.%I SET workflow_state = CASE
            WHEN status::text = ''published'' THEN ''published''::public.cms_workflow_state
            WHEN status::text = ''archived''  THEN ''archived''::public.cms_workflow_state
            ELSE ''draft''::public.cms_workflow_state
          END WHERE workflow_state = ''draft''', t);
    ELSIF has_is_published THEN
      EXECUTE format(
        'UPDATE public.%I SET workflow_state = CASE WHEN is_published THEN ''published''::public.cms_workflow_state ELSE ''draft''::public.cms_workflow_state END WHERE workflow_state = ''draft''', t);
    ELSIF has_is_active THEN
      EXECUTE format(
        'UPDATE public.%I SET workflow_state = CASE WHEN is_active THEN ''published''::public.cms_workflow_state ELSE ''draft''::public.cms_workflow_state END WHERE workflow_state = ''draft''', t);
    ELSE
      -- nincs publikációs jel → kezeljük publikáltnak (visszafelé kompatibilitás)
      EXECUTE format('UPDATE public.%I SET workflow_state = ''published''::public.cms_workflow_state WHERE workflow_state = ''draft''', t);
    END IF;

    -- 3. index a state-en
    EXECUTE format('CREATE INDEX IF NOT EXISTS %I ON public.%I (workflow_state)',
      t || '_workflow_state_idx', t);
  END LOOP;
END $$;

-- ─── 20260630103452_6cebef1e-fe21-465d-9c97-3aa9933165fe.sql ───
-- ===== A/B teszt: D. migráció =====

-- 1) Kísérlet
CREATE TABLE public.cms_experiments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  name text NOT NULL,
  description text,
  block_id uuid REFERENCES public.cms_blocks(id) ON DELETE CASCADE,
  layout_block_id uuid REFERENCES public.cms_layout_blocks(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'draft', -- draft|running|paused|completed
  traffic_allocation numeric(3,2) NOT NULL DEFAULT 1.00 CHECK (traffic_allocation BETWEEN 0.01 AND 1.00),
  goal_event text NOT NULL,
  started_at timestamptz,
  ended_at timestamptz,
  winner_variant_id uuid,
  -- Phase 1 workflow oszlopok
  workflow_state public.cms_workflow_state NOT NULL DEFAULT 'draft',
  submitted_for_review_at timestamptz,
  submitted_by uuid,
  approved_at timestamptz,
  approved_by uuid,
  rejected_at timestamptz,
  rejected_by uuid,
  rejection_reason text,
  CHECK (
    (block_id IS NOT NULL AND layout_block_id IS NULL) OR
    (block_id IS NULL AND layout_block_id IS NOT NULL)
  ),
  CHECK (status IN ('draft','running','paused','completed'))
);

CREATE INDEX cms_experiments_block_idx ON public.cms_experiments (block_id) WHERE block_id IS NOT NULL;
CREATE INDEX cms_experiments_layout_idx ON public.cms_experiments (layout_block_id) WHERE layout_block_id IS NOT NULL;
CREATE INDEX cms_experiments_status_idx ON public.cms_experiments (status);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_experiments TO authenticated;
GRANT SELECT ON public.cms_experiments TO anon;
GRANT ALL ON public.cms_experiments TO service_role;

ALTER TABLE public.cms_experiments ENABLE ROW LEVEL SECURITY;

-- Publikus olvasás: csak futó kísérletek (anon ↔ szükséges a publikus rendereléshez)
CREATE POLICY "cms_experiments_public_running" ON public.cms_experiments
  FOR SELECT TO anon, authenticated
  USING (status = 'running');
-- CMS-szerű olvasás: mind
CREATE POLICY "cms_experiments_cms_select" ON public.cms_experiments
  FOR SELECT TO authenticated USING (public.has_cms_access(auth.uid()));
CREATE POLICY "cms_experiments_cms_insert" ON public.cms_experiments
  FOR INSERT TO authenticated WITH CHECK (public.has_cms_editor(auth.uid()));
CREATE POLICY "cms_experiments_cms_update" ON public.cms_experiments
  FOR UPDATE TO authenticated
  USING (public.has_cms_editor(auth.uid()))
  WITH CHECK (public.has_cms_editor(auth.uid()));
CREATE POLICY "cms_experiments_cms_delete" ON public.cms_experiments
  FOR DELETE TO authenticated USING (public.has_cms_publisher(auth.uid()));

-- 2) Variánsok
CREATE TABLE public.cms_experiment_variants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  experiment_id uuid NOT NULL REFERENCES public.cms_experiments(id) ON DELETE CASCADE,
  key text NOT NULL,
  name text,
  is_control boolean NOT NULL DEFAULT false,
  weight numeric(5,3) NOT NULL DEFAULT 1.000 CHECK (weight >= 0),
  content jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (experiment_id, key)
);

CREATE INDEX cms_experiment_variants_exp_idx ON public.cms_experiment_variants (experiment_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_experiment_variants TO authenticated;
GRANT SELECT ON public.cms_experiment_variants TO anon;
GRANT ALL ON public.cms_experiment_variants TO service_role;

ALTER TABLE public.cms_experiment_variants ENABLE ROW LEVEL SECURITY;

-- Publikus: csak ha a hozzá tartozó kísérlet futó
CREATE POLICY "cms_exp_variants_public" ON public.cms_experiment_variants
  FOR SELECT TO anon, authenticated
  USING (EXISTS (
    SELECT 1 FROM public.cms_experiments e
    WHERE e.id = experiment_id AND e.status = 'running'
  ));
CREATE POLICY "cms_exp_variants_cms_select" ON public.cms_experiment_variants
  FOR SELECT TO authenticated USING (public.has_cms_access(auth.uid()));
CREATE POLICY "cms_exp_variants_cms_write" ON public.cms_experiment_variants
  FOR ALL TO authenticated
  USING (public.has_cms_editor(auth.uid()))
  WITH CHECK (public.has_cms_editor(auth.uid()));

-- 3) Események
CREATE TABLE public.cms_experiment_events (
  id bigserial PRIMARY KEY,
  created_at timestamptz NOT NULL DEFAULT now(),
  experiment_id uuid NOT NULL REFERENCES public.cms_experiments(id) ON DELETE CASCADE,
  variant_id uuid NOT NULL REFERENCES public.cms_experiment_variants(id) ON DELETE CASCADE,
  event_type text NOT NULL CHECK (event_type IN ('view','goal')),
  session_id text,
  path text,
  referrer text,
  user_agent text
);

CREATE INDEX cms_exp_events_agg_idx
  ON public.cms_experiment_events (experiment_id, variant_id, event_type, created_at);
CREATE INDEX cms_exp_events_session_idx
  ON public.cms_experiment_events (session_id, experiment_id);

GRANT SELECT ON public.cms_experiment_events TO authenticated;
GRANT ALL ON public.cms_experiment_events TO service_role;

ALTER TABLE public.cms_experiment_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "cms_exp_events_cms_select" ON public.cms_experiment_events
  FOR SELECT TO authenticated USING (public.has_cms_access(auth.uid()));
-- INSERT csak security definer fn-en át, nincs policy

-- 4) Esemény rögzítő fn (rate-limit megfontolás: 60 req/perc/session_id)
CREATE OR REPLACE FUNCTION public.cms_exp_event_record(
  _experiment_id uuid,
  _variant_id uuid,
  _event_type text,
  _session_id text,
  _path text DEFAULT NULL,
  _referrer text DEFAULT NULL,
  _user_agent text DEFAULT NULL
)
RETURNS bigint
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _id bigint;
  _recent_count int;
BEGIN
  IF _event_type NOT IN ('view','goal') THEN
    RAISE EXCEPTION 'invalid event_type';
  END IF;

  -- futó kísérlet ellenőrzése
  IF NOT EXISTS (
    SELECT 1 FROM public.cms_experiments e
    WHERE e.id = _experiment_id AND e.status = 'running'
  ) THEN
    RETURN NULL;
  END IF;

  -- variant tartozzon a kísérlethez
  IF NOT EXISTS (
    SELECT 1 FROM public.cms_experiment_variants v
    WHERE v.id = _variant_id AND v.experiment_id = _experiment_id
  ) THEN
    RAISE EXCEPTION 'variant mismatch';
  END IF;

  -- soft rate-limit: 60/perc/session/experiment
  IF _session_id IS NOT NULL THEN
    SELECT COUNT(*) INTO _recent_count
    FROM public.cms_experiment_events
    WHERE session_id = _session_id
      AND experiment_id = _experiment_id
      AND created_at > now() - interval '1 minute';
    IF _recent_count > 60 THEN
      RETURN NULL;
    END IF;
  END IF;

  -- view dedupe: csak első view/nap/session/experiment/variant
  IF _event_type = 'view' AND _session_id IS NOT NULL THEN
    IF EXISTS (
      SELECT 1 FROM public.cms_experiment_events
      WHERE session_id = _session_id
        AND experiment_id = _experiment_id
        AND variant_id = _variant_id
        AND event_type = 'view'
        AND created_at::date = CURRENT_DATE
    ) THEN
      RETURN NULL;
    END IF;
  END IF;

  INSERT INTO public.cms_experiment_events
    (experiment_id, variant_id, event_type, session_id, path, referrer, user_agent)
  VALUES
    (_experiment_id, _variant_id, _event_type, _session_id,
     LEFT(_path, 500), LEFT(_referrer, 500), LEFT(_user_agent, 500))
  RETURNING id INTO _id;

  RETURN _id;
END;
$$;

REVOKE ALL ON FUNCTION public.cms_exp_event_record(uuid, uuid, text, text, text, text, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.cms_exp_event_record(uuid, uuid, text, text, text, text, text) TO anon, authenticated;

-- 5) Napi statisztika view
CREATE OR REPLACE VIEW public.cms_experiment_daily_stats AS
SELECT
  experiment_id,
  variant_id,
  date_trunc('day', created_at)::date AS day,
  COUNT(*) FILTER (WHERE event_type = 'view') AS views,
  COUNT(*) FILTER (WHERE event_type = 'goal') AS goals,
  CASE WHEN COUNT(*) FILTER (WHERE event_type = 'view') > 0
       THEN COUNT(*) FILTER (WHERE event_type = 'goal')::numeric
            / COUNT(*) FILTER (WHERE event_type = 'view')::numeric
       ELSE 0 END AS conversion_rate
FROM public.cms_experiment_events
GROUP BY experiment_id, variant_id, day;

GRANT SELECT ON public.cms_experiment_daily_stats TO authenticated;

-- 6) updated_at triggerek
CREATE OR REPLACE FUNCTION public.cms_experiments_set_updated()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;

CREATE TRIGGER cms_experiments_updated_at
  BEFORE UPDATE ON public.cms_experiments
  FOR EACH ROW EXECUTE FUNCTION public.cms_experiments_set_updated();

CREATE TRIGGER cms_experiment_variants_updated_at
  BEFORE UPDATE ON public.cms_experiment_variants
  FOR EACH ROW EXECUTE FUNCTION public.cms_experiments_set_updated();

-- ─── 20260630103526_09c5259d-2846-4a24-a947-d8b82d19008d.sql ───
ALTER VIEW public.cms_experiment_daily_stats SET (security_invoker = on);

CREATE OR REPLACE FUNCTION public.cms_experiments_set_updated()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;

-- ─── 20260630105336_c8a7e236-6dc7-423e-b885-c58c1ac5e3f8.sql ───
ALTER TABLE public.cms_pages
  ADD COLUMN IF NOT EXISTS view_count integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS last_viewed_at timestamptz;

CREATE TABLE IF NOT EXISTS public.cms_page_views (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  page_id uuid NOT NULL REFERENCES public.cms_pages(id) ON DELETE CASCADE,
  day date NOT NULL DEFAULT CURRENT_DATE,
  views integer NOT NULL DEFAULT 0,
  UNIQUE (page_id, day)
);

GRANT SELECT ON public.cms_page_views TO authenticated;
GRANT ALL ON public.cms_page_views TO service_role;

ALTER TABLE public.cms_page_views ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "cms_page_views_admin_read" ON public.cms_page_views;
CREATE POLICY "cms_page_views_admin_read" ON public.cms_page_views
  FOR SELECT TO authenticated
  USING (public.has_cms_access(auth.uid()));

CREATE OR REPLACE FUNCTION public.cms_page_view_record(_page_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.cms_pages
     SET view_count = view_count + 1,
         last_viewed_at = now()
   WHERE id = _page_id AND status = 'published';

  IF FOUND THEN
    INSERT INTO public.cms_page_views (page_id, day, views)
    VALUES (_page_id, CURRENT_DATE, 1)
    ON CONFLICT (page_id, day) DO UPDATE
      SET views = public.cms_page_views.views + 1;
  END IF;
END;
$$;

GRANT EXECUTE ON FUNCTION public.cms_page_view_record(uuid) TO anon, authenticated;

-- ─── 20260630122044_331462c2-e3f3-48c3-8937-5797014a10c0.sql ───

-- ============== CMS Tips module ==============

-- Categories
CREATE TABLE public.cms_tip_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  name_i18n jsonb NOT NULL DEFAULT '{}'::jsonb,
  description_i18n jsonb NOT NULL DEFAULT '{}'::jsonb,
  icon text,
  color text,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.cms_tip_categories TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_tip_categories TO authenticated;
GRANT ALL ON public.cms_tip_categories TO service_role;
ALTER TABLE public.cms_tip_categories ENABLE ROW LEVEL SECURITY;
CREATE POLICY "cms_tip_categories_public_read" ON public.cms_tip_categories FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "cms_tip_categories_admin_write" ON public.cms_tip_categories FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor'))
  WITH CHECK (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor'));

-- Tags
CREATE TABLE public.cms_tip_tags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  name_i18n jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.cms_tip_tags TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_tip_tags TO authenticated;
GRANT ALL ON public.cms_tip_tags TO service_role;
ALTER TABLE public.cms_tip_tags ENABLE ROW LEVEL SECURITY;
CREATE POLICY "cms_tip_tags_public_read" ON public.cms_tip_tags FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "cms_tip_tags_admin_write" ON public.cms_tip_tags FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor'))
  WITH CHECK (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor'));

-- Audiences
CREATE TABLE public.cms_tip_audiences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  name_i18n jsonb NOT NULL DEFAULT '{}'::jsonb,
  description_i18n jsonb NOT NULL DEFAULT '{}'::jsonb,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.cms_tip_audiences TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_tip_audiences TO authenticated;
GRANT ALL ON public.cms_tip_audiences TO service_role;
ALTER TABLE public.cms_tip_audiences ENABLE ROW LEVEL SECURITY;
CREATE POLICY "cms_tip_audiences_public_read" ON public.cms_tip_audiences FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "cms_tip_audiences_admin_write" ON public.cms_tip_audiences FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor'))
  WITH CHECK (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor'));

-- Tips (main)
CREATE TABLE public.cms_tips (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  category_id uuid REFERENCES public.cms_tip_categories(id) ON DELETE SET NULL,
  cover_url text,
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published','archived')),
  featured boolean NOT NULL DEFAULT false,
  published_at timestamptz,
  author_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  reading_minutes int,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX cms_tips_status_pub_idx ON public.cms_tips(status, published_at DESC);
CREATE INDEX cms_tips_category_idx ON public.cms_tips(category_id);
GRANT SELECT ON public.cms_tips TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_tips TO authenticated;
GRANT ALL ON public.cms_tips TO service_role;
ALTER TABLE public.cms_tips ENABLE ROW LEVEL SECURITY;
CREATE POLICY "cms_tips_public_read_published" ON public.cms_tips FOR SELECT TO anon USING (status = 'published');
CREATE POLICY "cms_tips_auth_read" ON public.cms_tips FOR SELECT TO authenticated USING (
  status = 'published' OR public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor')
);
CREATE POLICY "cms_tips_admin_write" ON public.cms_tips FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor'))
  WITH CHECK (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor'));

-- Translations (1 row per locale)
CREATE TABLE public.cms_tip_translations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tip_id uuid NOT NULL REFERENCES public.cms_tips(id) ON DELETE CASCADE,
  locale text NOT NULL,
  title text NOT NULL DEFAULT '',
  lead text DEFAULT '',
  body_json jsonb NOT NULL DEFAULT '{}'::jsonb,
  body_html text DEFAULT '',
  seo_title text,
  seo_description text,
  og_image text,
  ai_generated boolean NOT NULL DEFAULT false,
  ai_source_lang text,
  translation_status text NOT NULL DEFAULT 'manual' CHECK (translation_status IN ('manual','ai','reviewed')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(tip_id, locale)
);
CREATE INDEX cms_tip_translations_locale_idx ON public.cms_tip_translations(locale);
GRANT SELECT ON public.cms_tip_translations TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_tip_translations TO authenticated;
GRANT ALL ON public.cms_tip_translations TO service_role;
ALTER TABLE public.cms_tip_translations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "cms_tip_translations_public_read" ON public.cms_tip_translations FOR SELECT TO anon USING (
  EXISTS (SELECT 1 FROM public.cms_tips t WHERE t.id = tip_id AND t.status = 'published')
);
CREATE POLICY "cms_tip_translations_auth_read" ON public.cms_tip_translations FOR SELECT TO authenticated USING (
  public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor')
  OR EXISTS (SELECT 1 FROM public.cms_tips t WHERE t.id = tip_id AND t.status = 'published')
);
CREATE POLICY "cms_tip_translations_admin_write" ON public.cms_tip_translations FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor'))
  WITH CHECK (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor'));

-- Versions
CREATE TABLE public.cms_tip_versions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tip_id uuid NOT NULL REFERENCES public.cms_tips(id) ON DELETE CASCADE,
  version int NOT NULL,
  snapshot jsonb NOT NULL,
  note text,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(tip_id, version)
);
CREATE INDEX cms_tip_versions_tip_idx ON public.cms_tip_versions(tip_id, version DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_tip_versions TO authenticated;
GRANT ALL ON public.cms_tip_versions TO service_role;
ALTER TABLE public.cms_tip_versions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "cms_tip_versions_admin" ON public.cms_tip_versions FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor'))
  WITH CHECK (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor'));

-- Tag map
CREATE TABLE public.cms_tip_tag_map (
  tip_id uuid NOT NULL REFERENCES public.cms_tips(id) ON DELETE CASCADE,
  tag_id uuid NOT NULL REFERENCES public.cms_tip_tags(id) ON DELETE CASCADE,
  PRIMARY KEY (tip_id, tag_id)
);
GRANT SELECT ON public.cms_tip_tag_map TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_tip_tag_map TO authenticated;
GRANT ALL ON public.cms_tip_tag_map TO service_role;
ALTER TABLE public.cms_tip_tag_map ENABLE ROW LEVEL SECURITY;
CREATE POLICY "cms_tip_tag_map_public_read" ON public.cms_tip_tag_map FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "cms_tip_tag_map_admin_write" ON public.cms_tip_tag_map FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor'))
  WITH CHECK (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor'));

-- Audience map
CREATE TABLE public.cms_tip_audience_map (
  tip_id uuid NOT NULL REFERENCES public.cms_tips(id) ON DELETE CASCADE,
  audience_id uuid NOT NULL REFERENCES public.cms_tip_audiences(id) ON DELETE CASCADE,
  PRIMARY KEY (tip_id, audience_id)
);
GRANT SELECT ON public.cms_tip_audience_map TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_tip_audience_map TO authenticated;
GRANT ALL ON public.cms_tip_audience_map TO service_role;
ALTER TABLE public.cms_tip_audience_map ENABLE ROW LEVEL SECURITY;
CREATE POLICY "cms_tip_audience_map_public_read" ON public.cms_tip_audience_map FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "cms_tip_audience_map_admin_write" ON public.cms_tip_audience_map FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor'))
  WITH CHECK (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'editor'));

-- updated_at triggers
CREATE TRIGGER trg_cms_tips_updated BEFORE UPDATE ON public.cms_tips
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_cms_tip_translations_updated BEFORE UPDATE ON public.cms_tip_translations
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_cms_tip_categories_updated BEFORE UPDATE ON public.cms_tip_categories
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_cms_tip_tags_updated BEFORE UPDATE ON public.cms_tip_tags
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_cms_tip_audiences_updated BEFORE UPDATE ON public.cms_tip_audiences
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Seed audiences
INSERT INTO public.cms_tip_audiences (slug, name_i18n, sort_order) VALUES
  ('general',   '{"hu":"Általános","en":"General","de":"Allgemein"}',          0),
  ('pregnant', '{"hu":"Várandós","en":"Pregnant","de":"Schwangere"}',          10),
  ('new-mother','{"hu":"Kismama","en":"New mother","de":"Junge Mutter"}',      20),
  ('child',    '{"hu":"Gyermek","en":"Child","de":"Kind"}',                    30),
  ('elderly',  '{"hu":"Idős","en":"Elderly","de":"Senioren"}',                 40),
  ('diabetic', '{"hu":"Cukorbeteg","en":"Diabetic","de":"Diabetiker"}',        50),
  ('chronic',  '{"hu":"Krónikus beteg","en":"Chronic patient","de":"Chronisch Kranke"}', 60),
  ('athlete',  '{"hu":"Sportoló","en":"Athlete","de":"Sportler"}',             70);


-- ─── 20260630123532_0554f3ca-6859-41ca-a28f-01f29d65a2b1.sql ───

-- 1. Staff public visibility
ALTER TABLE public.cms_staff_profiles
  ADD COLUMN IF NOT EXISTS public_visibility text NOT NULL DEFAULT 'private'
    CHECK (public_visibility IN ('private','partial','full')),
  ADD COLUMN IF NOT EXISTS public_fields jsonb NOT NULL DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS is_published boolean NOT NULL DEFAULT false;

CREATE INDEX IF NOT EXISTS cms_staff_profiles_published_idx
  ON public.cms_staff_profiles (is_published) WHERE is_published = true;

-- Add anon SELECT policy for published staff
DROP POLICY IF EXISTS "Public staff profiles are viewable" ON public.cms_staff_profiles;
CREATE POLICY "Public staff profiles are viewable"
  ON public.cms_staff_profiles FOR SELECT
  TO anon, authenticated
  USING (is_published = true AND public_visibility <> 'private');

GRANT SELECT ON public.cms_staff_profiles TO anon;

-- 2. Tip views
CREATE TABLE IF NOT EXISTS public.cms_tip_views (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tip_id uuid NOT NULL REFERENCES public.cms_tips(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  session_hash text,
  locale text,
  viewed_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS cms_tip_views_tip_idx ON public.cms_tip_views (tip_id, viewed_at DESC);
GRANT SELECT, INSERT ON public.cms_tip_views TO anon, authenticated;
GRANT ALL ON public.cms_tip_views TO service_role;
ALTER TABLE public.cms_tip_views ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can insert views" ON public.cms_tip_views FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Admins read views" ON public.cms_tip_views FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

-- 3. Tip likes
CREATE TABLE IF NOT EXISTS public.cms_tip_likes (
  tip_id uuid NOT NULL REFERENCES public.cms_tips(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tip_id, user_id)
);
GRANT SELECT, INSERT, DELETE ON public.cms_tip_likes TO authenticated;
GRANT SELECT ON public.cms_tip_likes TO anon;
GRANT ALL ON public.cms_tip_likes TO service_role;
ALTER TABLE public.cms_tip_likes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone reads likes" ON public.cms_tip_likes FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Users like" ON public.cms_tip_likes FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users unlike" ON public.cms_tip_likes FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- 4. Tip comments
CREATE TABLE IF NOT EXISTS public.cms_tip_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tip_id uuid NOT NULL REFERENCES public.cms_tips(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  parent_id uuid REFERENCES public.cms_tip_comments(id) ON DELETE CASCADE,
  body text NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS cms_tip_comments_tip_idx ON public.cms_tip_comments (tip_id, created_at DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_tip_comments TO authenticated;
GRANT SELECT ON public.cms_tip_comments TO anon;
GRANT ALL ON public.cms_tip_comments TO service_role;
ALTER TABLE public.cms_tip_comments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone reads approved" ON public.cms_tip_comments FOR SELECT TO anon, authenticated
  USING (status = 'approved' OR auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Users post comments" ON public.cms_tip_comments FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users edit own" ON public.cms_tip_comments FOR UPDATE TO authenticated
  USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'))
  WITH CHECK (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Users delete own" ON public.cms_tip_comments FOR DELETE TO authenticated
  USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));

-- 5. Tip subscribers (auth users opt-in)
CREATE TABLE IF NOT EXISTS public.cms_tip_subscribers (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email_enabled boolean NOT NULL DEFAULT true,
  push_enabled boolean NOT NULL DEFAULT false,
  audiences text[] DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_tip_subscribers TO authenticated;
GRANT ALL ON public.cms_tip_subscribers TO service_role;
ALTER TABLE public.cms_tip_subscribers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Own sub" ON public.cms_tip_subscribers FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- 6. Newsletter subscribers (external emails)
CREATE TABLE IF NOT EXISTS public.cms_newsletter_subscribers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL UNIQUE,
  confirmed_at timestamptz,
  unsubscribed_at timestamptz,
  unsubscribe_token text NOT NULL DEFAULT encode(gen_random_bytes(24),'hex'),
  source text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.cms_newsletter_subscribers TO anon, authenticated;
GRANT ALL ON public.cms_newsletter_subscribers TO service_role;
ALTER TABLE public.cms_newsletter_subscribers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone subscribes" ON public.cms_newsletter_subscribers FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Admins read" ON public.cms_newsletter_subscribers FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

-- 7. Newsletters
CREATE TABLE IF NOT EXISTS public.cms_newsletters (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subject text NOT NULL,
  body_html text NOT NULL,
  audience text NOT NULL DEFAULT 'all' CHECK (audience IN ('all','tips','news','newsletter')),
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','sending','sent','failed')),
  sent_at timestamptz,
  sent_count integer NOT NULL DEFAULT 0,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cms_newsletters TO authenticated;
GRANT ALL ON public.cms_newsletters TO service_role;
ALTER TABLE public.cms_newsletters ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins manage newsletters" ON public.cms_newsletters FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- 8. updated_at triggers
DROP TRIGGER IF EXISTS trg_cms_tip_comments_updated ON public.cms_tip_comments;
CREATE TRIGGER trg_cms_tip_comments_updated BEFORE UPDATE ON public.cms_tip_comments
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
DROP TRIGGER IF EXISTS trg_cms_newsletters_updated ON public.cms_newsletters;
CREATE TRIGGER trg_cms_newsletters_updated BEFORE UPDATE ON public.cms_newsletters
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- ─── 20260630125830_ac2f718e-097b-4d19-86dd-6e0841494de9.sql ───

-- Block-level draft + approval ---------------------------------------------
ALTER TABLE public.cms_layout_blocks
  ADD COLUMN IF NOT EXISTS draft_content jsonb,
  ADD COLUMN IF NOT EXISTS draft_style jsonb,
  ADD COLUMN IF NOT EXISTS draft_updated_at timestamptz,
  ADD COLUMN IF NOT EXISTS draft_updated_by uuid,
  ADD COLUMN IF NOT EXISTS draft_status text NOT NULL DEFAULT 'none',
  ADD COLUMN IF NOT EXISTS draft_note text;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'cms_layout_blocks_draft_status_check'
  ) THEN
    ALTER TABLE public.cms_layout_blocks
      ADD CONSTRAINT cms_layout_blocks_draft_status_check
      CHECK (draft_status IN ('none','pending','approved','rejected'));
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS cms_layout_blocks_pending_drafts_idx
  ON public.cms_layout_blocks (page_id)
  WHERE draft_status = 'pending';


-- ─── 20260701115625_018111cf-8452-4655-90ac-f8f97c76e5ab.sql ───

-- 1) Revoke broad EXECUTE on every SECURITY DEFINER function in public
DO $$
DECLARE
  fn record;
BEGIN
  FOR fn IN
    SELECT n.nspname AS schema_name, p.proname AS fn_name,
           pg_get_function_identity_arguments(p.oid) AS args
    FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public' AND p.prosecdef = true
  LOOP
    EXECUTE format(
      'REVOKE EXECUTE ON FUNCTION %I.%I(%s) FROM PUBLIC, anon, authenticated',
      fn.schema_name, fn.fn_name, fn.args
    );
  END LOOP;
END $$;

-- 2) Grant EXECUTE back only where the app actually needs it.
--    anon: public tracking + kiosk (no login).
GRANT EXECUTE ON FUNCTION public.kiosk_load(text, text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.kiosk_autosave(text, text, jsonb) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.kiosk_submit_response(text, text, jsonb, numeric, text, jsonb, boolean) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.cms_exp_event_record(uuid, uuid, text, text, text, text, text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.cms_news_increment_view(text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.cms_page_view_record(uuid) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.get_home_page_id() TO anon, authenticated;

--    authenticated: RLS-helper + admin/RPC callable functions.
GRANT EXECUTE ON FUNCTION public.has_role(uuid, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_any_role(uuid, text[]) TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_permission(uuid, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_cms_access(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_cms_editor(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_cms_publisher(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_cms_reviewer(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.can_access_patient(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.can_book_into_block(uuid, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.current_tenant_id() TO authenticated;
GRANT EXECUTE ON FUNCTION public.current_user_patient_ids() TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_conversation_participant(uuid, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.eligible_swap_targets(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.calc_gyakorlati_ido(uuid, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.calc_illetmeny(uuid, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.calc_jubileumi_ido(uuid, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.find_acute_replacements(uuid, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.generate_demand_for_period(uuid, date, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.publish_schedule_run(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.recompute_block_case_times(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.reorder_block_cases(uuid, uuid[]) TO authenticated;
GRANT EXECUTE ON FUNCTION public.recalc_leave_entitlements(uuid, integer) TO authenticated;
GRANT EXECUTE ON FUNCTION public.log_leave_admin(uuid, uuid, text, integer, uuid, text, numeric, jsonb, jsonb, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.close_leave_year(uuid, integer, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.enforce_forced_leave_takeout(uuid, integer, uuid, boolean) TO authenticated;
GRANT EXECUTE ON FUNCTION public.seed_default_org_for_tenant(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.ensure_role_permissions_seed() TO authenticated;
GRANT EXECUTE ON FUNCTION public.cleanup_e2e_test_data() TO authenticated;
GRANT EXECUTE ON FUNCTION public.cms_audit_write(text, uuid, cms_audit_action, jsonb, jsonb, text, text, text, jsonb) TO authenticated;
GRANT EXECUTE ON FUNCTION public.cms_promote_scheduled_pages() TO authenticated;

--    Cron / trigger / admin-only functions get NO anon or authenticated grant.
--    They are invoked by triggers or by service_role from /api/public/hooks/*:
--      process_questionnaire_schedules, expire_overdue_questionnaire_assignments,
--      send_questionnaire_reminders, process_followup_schedules,
--      apply_approved_change_request, bump_conversation_last_message,
--      cms_pages_autoredirect_on_slug_change, fn_app_settings_audit,
--      enroll_followup

-- 3) Tighten always-true RLS policies on public INSERT tables

-- Newsletter subscribers: enforce format & prevent pre-confirmation abuse
DROP POLICY IF EXISTS "Anyone subscribes" ON public.cms_newsletter_subscribers;
CREATE POLICY "Anyone subscribes"
  ON public.cms_newsletter_subscribers
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (
    email IS NOT NULL
    AND length(email) BETWEEN 3 AND 254
    AND email ~ '^[^@\s]+@[^@\s]+\.[^@\s]+$'
    AND confirmed_at IS NULL
    AND unsubscribed_at IS NULL
    AND unsubscribe_token IS NOT NULL
    AND length(unsubscribe_token) BETWEEN 16 AND 128
    AND (source IS NULL OR length(source) <= 64)
  );

-- Tip views: only own views can be attributed; length limits on session_hash/locale
DROP POLICY IF EXISTS "Anyone can insert views" ON public.cms_tip_views;
CREATE POLICY "Anyone can insert views"
  ON public.cms_tip_views
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (
    tip_id IS NOT NULL
    AND (user_id IS NULL OR user_id = auth.uid())
    AND (session_hash IS NULL OR length(session_hash) BETWEEN 8 AND 128)
    AND (locale IS NULL OR length(locale) <= 10)
  );

-- Contact messages: length limits + status must start as new/pending, cannot pre-assign handler
DROP POLICY IF EXISTS "Anyone can submit a contact message" ON public.contact_messages;
CREATE POLICY "Anyone can submit a contact message"
  ON public.contact_messages
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (
    sender_name IS NOT NULL
    AND length(sender_name) BETWEEN 2 AND 120
    AND sender_email IS NOT NULL
    AND length(sender_email) BETWEEN 3 AND 254
    AND sender_email ~ '^[^@\s]+@[^@\s]+\.[^@\s]+$'
    AND (sender_phone IS NULL OR length(sender_phone) <= 40)
    AND (subject IS NULL OR length(subject) <= 200)
    AND body IS NOT NULL
    AND length(body) BETWEEN 5 AND 5000
    AND status IN ('new','pending')
    AND handled_by IS NULL
    AND handled_at IS NULL
    AND (locale IS NULL OR length(locale) <= 10)
  );

-- 4) Drop redundant service_role catch-all policies (service_role bypasses RLS).
DROP POLICY IF EXISTS "service_role_contractions" ON public.contractions;
DROP POLICY IF EXISTS "service_role_fetal_mov" ON public.fetal_movements;
DROP POLICY IF EXISTS "service_role_food_log" ON public.food_log;
DROP POLICY IF EXISTS "service_role_measurements" ON public.measurements;
DROP POLICY IF EXISTS "service_role_menstrual" ON public.menstrual_cycles;
DROP POLICY IF EXISTS "service_role_mon_alerts" ON public.monitoring_alerts;
DROP POLICY IF EXISTS "service_role_mon_programs" ON public.monitoring_programs;
DROP POLICY IF EXISTS "service_role_thresholds" ON public.monitoring_thresholds;
DROP POLICY IF EXISTS "service_role_qsched" ON public.questionnaire_schedules;
DROP POLICY IF EXISTS "service_role_stool_log" ON public.stool_log;
DROP POLICY IF EXISTS "service_role_wearable" ON public.wearable_data;


-- ─── 20260701115834_beef0a09-a262-4239-8437-1a6aaa94c079.sql ───
GRANT EXECUTE ON FUNCTION public.cms_promote_scheduled_pages() TO anon, authenticated;

-- ─── 20260701120603_fdd0bd9f-8bb9-4871-acc6-52a6b180a56a.sql ───
-- Ensure cms_promote_scheduled_pages is executable in every context it may be called from
GRANT EXECUTE ON FUNCTION public.cms_promote_scheduled_pages() TO anon, authenticated, service_role;

-- ─── 20260702144028_e2d5908c-55ec-4850-a5de-b4799265d4b1.sql ───

CREATE EXTENSION IF NOT EXISTS pg_net;

-- Extend allowed kind values on shift_notifications_sent
ALTER TABLE public.shift_notifications_sent DROP CONSTRAINT IF EXISTS shift_notifications_sent_kind_check;
ALTER TABLE public.shift_notifications_sent ADD CONSTRAINT shift_notifications_sent_kind_check
  CHECK (kind IN ('24h','2h','new','change','cancel'));

-- Enqueue helper: fires an async POST to the public webhook, non-blocking.
CREATE OR REPLACE FUNCTION public.enqueue_assignment_push(_event text, _row jsonb, _changes text[])
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_url text := 'https://project--23fe2ad3-1ad0-4e50-b650-1486a8fd8e70.lovable.app/api/public/hooks/schedule-notify';
  v_apikey text := 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZpdWhueXp5eHFrc21kZ3BxdmloIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODE3OTg4NzgsImV4cCI6MjA5NzM3NDg3OH0.R2fE1KWLwyK-ftcJw7gDwJ43Xik32Iu_OiXSKqx_qiM';
BEGIN
  BEGIN
    PERFORM net.http_post(
      url := v_url,
      headers := jsonb_build_object('Content-Type','application/json','apikey', v_apikey),
      body := jsonb_build_object('event', _event, 'assignment', _row, 'changes', to_jsonb(_changes))
    );
  EXCEPTION WHEN OTHERS THEN
    -- swallow: never block the mutation on webhook failure
    NULL;
  END;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.enqueue_assignment_push(text, jsonb, text[]) FROM PUBLIC, anon, authenticated;

-- INSERT trigger: notify user of a newly-assigned shift
CREATE OR REPLACE FUNCTION public.notify_assignment_insert()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.user_id IS NULL THEN RETURN NEW; END IF;
  IF NEW.status::text = 'visszavont' THEN RETURN NEW; END IF;
  -- Skip if the user assigned it to themselves
  IF auth.uid() IS NOT NULL AND NEW.user_id = auth.uid() THEN RETURN NEW; END IF;

  PERFORM public.enqueue_assignment_push('new', to_jsonb(NEW), NULL);

  INSERT INTO public.notifications(tenant_id, user_id, tipus, cim, uzenet, link)
  VALUES (NEW.tenant_id, NEW.user_id, 'beosztas',
    'Új műszakot kaptál',
    to_char(NEW.kezdo_idopont AT TIME ZONE 'Europe/Budapest','YYYY-MM-DD HH24:MI')
      || ' (' || NEW.kategoria::text || ')',
    '/beosztas');

  RETURN NEW;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.notify_assignment_insert() FROM PUBLIC, anon;
DROP TRIGGER IF EXISTS sa_notify_insert ON public.schedule_assignments;
CREATE TRIGGER sa_notify_insert
  AFTER INSERT ON public.schedule_assignments
  FOR EACH ROW EXECUTE FUNCTION public.notify_assignment_insert();

-- DELETE trigger: notify user of a cancelled shift
CREATE OR REPLACE FUNCTION public.notify_assignment_delete()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF OLD.user_id IS NULL THEN RETURN OLD; END IF;
  IF auth.uid() IS NOT NULL AND OLD.user_id = auth.uid() THEN RETURN OLD; END IF;

  PERFORM public.enqueue_assignment_push('cancel', to_jsonb(OLD), NULL);

  INSERT INTO public.notifications(tenant_id, user_id, tipus, cim, uzenet, link)
  VALUES (OLD.tenant_id, OLD.user_id, 'beosztas',
    'Törölt műszak',
    to_char(OLD.kezdo_idopont AT TIME ZONE 'Europe/Budapest','YYYY-MM-DD HH24:MI')
      || ' (' || OLD.kategoria::text || ')',
    '/beosztas');

  RETURN OLD;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.notify_assignment_delete() FROM PUBLIC, anon;
DROP TRIGGER IF EXISTS sa_notify_delete ON public.schedule_assignments;
CREATE TRIGGER sa_notify_delete
  AFTER DELETE ON public.schedule_assignments
  FOR EACH ROW EXECUTE FUNCTION public.notify_assignment_delete();

-- UPDATE trigger: keep the existing in-app notification AND enqueue a push
CREATE OR REPLACE FUNCTION public.notify_assignment_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_changes text[] := ARRAY[]::text[];
  v_msg text;
BEGIN
  IF NEW.user_id IS NULL THEN RETURN NEW; END IF;
  IF auth.uid() IS NOT NULL AND NEW.user_id = auth.uid() THEN
    RETURN NEW;
  END IF;

  IF NEW.kezdo_idopont IS DISTINCT FROM OLD.kezdo_idopont
     OR NEW.zaro_idopont IS DISTINCT FROM OLD.zaro_idopont THEN
    v_changes := array_append(v_changes,
      'Új időpont: ' || to_char(NEW.kezdo_idopont AT TIME ZONE 'Europe/Budapest','YYYY-MM-DD HH24:MI')
       || '–' || to_char(NEW.zaro_idopont AT TIME ZONE 'Europe/Budapest','HH24:MI'));
  END IF;
  IF NEW.status IS DISTINCT FROM OLD.status THEN
    v_changes := array_append(v_changes, 'Státusz: ' || NEW.status::text);
  END IF;
  IF NEW.kategoria IS DISTINCT FROM OLD.kategoria THEN
    v_changes := array_append(v_changes, 'Kategória: ' || NEW.kategoria::text);
  END IF;

  IF array_length(v_changes, 1) IS NULL THEN
    RETURN NEW;
  END IF;

  v_msg := array_to_string(v_changes, ' • ');

  INSERT INTO public.notifications(tenant_id, user_id, tipus, cim, uzenet, link)
  VALUES (NEW.tenant_id, NEW.user_id, 'beosztas',
    'Beosztásod változott',
    v_msg,
    '/iranyitopult');

  PERFORM public.enqueue_assignment_push('change', to_jsonb(NEW), v_changes);

  RETURN NEW;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.notify_assignment_change() FROM PUBLIC, anon;


-- ─── 20260702154959_6bc0a62a-25c4-46b6-996b-061b5f8b7798.sql ───
CREATE OR REPLACE FUNCTION public.notify_contact_message()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_link  text := '/admin/cms?tab=contact&id=' || NEW.id::text;
  v_title text := COALESCE(NULLIF('Új üzenet: ' || NEW.subject, 'Új üzenet: '), 'Új kapcsolatfelvétel');
  v_body  text := left(coalesce(NEW.sender_name,'') || ' — ' || coalesce(NEW.body,''), 240);
  v_inserted integer := 0;
BEGIN
  -- 1) Részleg-hozzárendelt dolgozók
  IF NEW.org_unit_id IS NOT NULL THEN
    INSERT INTO public.notifications (tenant_id, user_id, tipus, cim, uzenet, link)
    SELECT DISTINCT ur.tenant_id, ur.user_id, 'contact_message', v_title, v_body, v_link
    FROM public.user_roles ur
    WHERE ur.org_unit_id = NEW.org_unit_id
      AND ur.user_id IS NOT NULL
      AND ur.tenant_id IS NOT NULL
      AND (ur.ervenyes_tol IS NULL OR ur.ervenyes_tol <= now())
      AND (ur.ervenyes_ig  IS NULL OR ur.ervenyes_ig  >= now());
    GET DIAGNOSTICS v_inserted = ROW_COUNT;
  END IF;

  -- 2) Fallback: CMS szerkesztők / tenant admin
  IF v_inserted = 0 THEN
    INSERT INTO public.notifications (tenant_id, user_id, tipus, cim, uzenet, link)
    SELECT DISTINCT ur.tenant_id, ur.user_id, 'contact_message', v_title, v_body, v_link
    FROM public.user_roles ur
    JOIN public.roles r ON r.id = ur.role_id
    WHERE r.kulcs IN ('tenant_admin','cms_editor','cms_reviewer','cms_publisher')
      AND ur.user_id IS NOT NULL
      AND ur.tenant_id IS NOT NULL
      AND (ur.ervenyes_tol IS NULL OR ur.ervenyes_tol <= now())
      AND (ur.ervenyes_ig  IS NULL OR ur.ervenyes_ig  >= now());
  END IF;

  RETURN NEW;
EXCEPTION WHEN OTHERS THEN
  -- Az értesítés sosem törheti meg a kapcsolatfelvétel mentését
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_contact_message_notify ON public.contact_messages;
CREATE TRIGGER trg_contact_message_notify
  AFTER INSERT ON public.contact_messages
  FOR EACH ROW EXECUTE FUNCTION public.notify_contact_message();


-- ─── 20260702155010_3f96efb0-1256-4e7c-b530-5556dfebaed2.sql ───
REVOKE EXECUTE ON FUNCTION public.notify_contact_message() FROM PUBLIC, anon, authenticated;


-- ─── 20260702160745_e0bfb9f6-35e3-4f0b-b878-f3dce2514d34.sql ───
ALTER TABLE public.cms_pages
  ADD COLUMN IF NOT EXISTS schema_type text NOT NULL DEFAULT 'auto';

COMMENT ON COLUMN public.cms_pages.schema_type IS
  'schema.org típus a JSON-LD auto-generátorhoz: auto | webpage | article | faqpage | contactpage | aboutpage | service | organization | localbusiness | collectionpage';

-- ─── 20260702162423_9bdf531b-ea59-4434-9f50-41731ec2a279.sql ───
-- 1. Kapcsolat hír → CMS oldal
ALTER TABLE public.cms_news_posts
  ADD COLUMN IF NOT EXISTS cms_page_id uuid REFERENCES public.cms_pages(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_cms_news_posts_cms_page_id ON public.cms_news_posts(cms_page_id);

-- 2. /hirek listaoldal seed
INSERT INTO public.cms_pages (slug, locale, title, description, status, seo_title, seo_description, template, published_at, schema_type)
VALUES (
  'hirek', 'hu', 'Hírek',
  'Kövesse a klinika legfrissebb híreit, tájékoztatóit és eseményeit.',
  'published',
  'Hírek – Klinika',
  'A klinika legfrissebb hírei, tájékoztatói és eseményei egy helyen.',
  'default', now(), 'collectionpage'
)
ON CONFLICT (slug, locale) DO UPDATE
  SET status = 'published',
      published_at = COALESCE(public.cms_pages.published_at, EXCLUDED.published_at);

-- Alap blokkok a hirek oldalhoz (csak ha még nincs blokkja)
DO $$
DECLARE
  v_page_id uuid;
BEGIN
  SELECT id INTO v_page_id FROM public.cms_pages WHERE slug = 'hirek' AND locale = 'hu';
  IF v_page_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM public.cms_blocks WHERE page_id = v_page_id) THEN
    INSERT INTO public.cms_blocks (page_id, block_type, position, locale, content, is_published) VALUES
      (v_page_id, 'heading', 0, 'hu', '{"text": "Hírek"}'::jsonb, true),
      (v_page_id, 'richtext', 1, 'hu', '{"html": "<p class=\"lead\">Kövesse a klinika legfrissebb híreit, tájékoztatóit és eseményeit.</p>"}'::jsonb, true),
      (v_page_id, 'dyn_news_list', 2, 'hu', '{"title": "Legfrissebb hírek", "limit": 12, "locale": "hu"}'::jsonb, true);
  END IF;
END $$;

-- 3. Backfill: minden meglévő hírhez CMS oldal létrehozása
DO $$
DECLARE
  r RECORD;
  v_page_id uuid;
  v_body_html text;
  v_cms_slug text;
BEGIN
  FOR r IN
    SELECT id, slug, title, excerpt, body, featured_image_url, featured_image_alt,
           seo_title, seo_description, og_image_url, status, published_at, locale
    FROM public.cms_news_posts
    WHERE cms_page_id IS NULL
  LOOP
    v_body_html := COALESCE((r.body->>'html'), '');
    v_cms_slug := 'hirek/' || r.slug;

    SELECT id INTO v_page_id FROM public.cms_pages WHERE slug = v_cms_slug AND locale = r.locale;

    IF v_page_id IS NULL THEN
      INSERT INTO public.cms_pages
        (slug, locale, title, description, status, seo_title, seo_description, og_image_url, template, published_at, schema_type)
      VALUES
        (v_cms_slug, r.locale, r.title, r.excerpt,
         CASE WHEN r.status IN ('draft','published','scheduled','archived') THEN r.status ELSE 'draft' END,
         r.seo_title, r.seo_description, COALESCE(r.og_image_url, r.featured_image_url),
         'default', r.published_at, 'article')
      RETURNING id INTO v_page_id;

      INSERT INTO public.cms_blocks (page_id, block_type, position, locale, content, is_published) VALUES
        (v_page_id, 'dyn_news_hero', 0, r.locale,
         jsonb_build_object(
           'title', r.title,
           'excerpt', r.excerpt,
           'cover', r.featured_image_url,
           'cover_alt', r.featured_image_alt,
           'post_slug', r.slug
         ), true),
        (v_page_id, 'richtext', 1, r.locale,
         jsonb_build_object('html', v_body_html), true),
        (v_page_id, 'dyn_share_bar', 2, r.locale,
         jsonb_build_object('title', r.title), true),
        (v_page_id, 'dyn_news_related', 3, r.locale,
         jsonb_build_object('title', 'Kapcsolódó cikkek', 'post_slug', r.slug, 'limit', 3), true);
    END IF;

    UPDATE public.cms_news_posts SET cms_page_id = v_page_id WHERE id = r.id;
  END LOOP;
END $$;

-- ─── 20260702163143_dd85b9ef-41d3-4ae7-b39c-b34dc07ca715.sql ───
create table if not exists public.symptom_match_feedback (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  query text not null,
  specialty_id uuid not null references public.specialties(id) on delete cascade,
  verdict text not null check (verdict in ('fit','miss')),
  urgency text,
  created_at timestamptz not null default now()
);

create index if not exists symptom_match_feedback_specialty_idx
  on public.symptom_match_feedback(specialty_id, verdict);
create index if not exists symptom_match_feedback_user_idx
  on public.symptom_match_feedback(user_id, created_at desc);

grant select, insert on public.symptom_match_feedback to authenticated;
grant all on public.symptom_match_feedback to service_role;

alter table public.symptom_match_feedback enable row level security;

create policy "own feedback insert" on public.symptom_match_feedback
  for insert to authenticated with check (auth.uid() = user_id);

create policy "own feedback select" on public.symptom_match_feedback
  for select to authenticated using (auth.uid() = user_id);


-- ─── 20260702165011_254d1532-3004-4484-9e9d-f34b4a5c8a55.sql ───

-- 1) user_provider_identities table
CREATE TABLE public.user_provider_identities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  provider TEXT NOT NULL,
  provider_user_id TEXT NOT NULL,
  email TEXT,
  avatar_url TEXT,
  raw JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (provider, provider_user_id)
);
CREATE INDEX idx_user_provider_identities_user ON public.user_provider_identities(user_id);

GRANT SELECT, DELETE ON public.user_provider_identities TO authenticated;
GRANT ALL ON public.user_provider_identities TO service_role;

ALTER TABLE public.user_provider_identities ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Own identities: select"
  ON public.user_provider_identities FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Own identities: delete"
  ON public.user_provider_identities FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE TRIGGER touch_user_provider_identities
  BEFORE UPDATE ON public.user_provider_identities
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- 2) sync function fired from auth.identities
CREATE OR REPLACE FUNCTION public.sync_provider_identity()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_email TEXT;
  v_avatar TEXT;
  v_name TEXT;
BEGIN
  v_email  := COALESCE(NEW.identity_data->>'email', NULL);
  v_avatar := COALESCE(
    NEW.identity_data->>'avatar_url',
    NEW.identity_data->>'picture'
  );
  v_name := COALESCE(
    NEW.identity_data->>'full_name',
    NEW.identity_data->>'name',
    NEW.identity_data->>'teljes_nev'
  );

  INSERT INTO public.user_provider_identities (
    user_id, provider, provider_user_id, email, avatar_url, raw
  )
  VALUES (
    NEW.user_id, NEW.provider, NEW.provider_id, v_email, v_avatar, NEW.identity_data
  )
  ON CONFLICT (provider, provider_user_id) DO UPDATE
  SET user_id    = EXCLUDED.user_id,
      email      = EXCLUDED.email,
      avatar_url = EXCLUDED.avatar_url,
      raw        = EXCLUDED.raw,
      updated_at = now();

  -- Backfill profile avatar/name if empty (first social login).
  UPDATE public.profiles
     SET avatar_url = COALESCE(profiles.avatar_url, v_avatar),
         teljes_nev = CASE
                        WHEN profiles.teljes_nev IS NULL
                          OR profiles.teljes_nev = ''
                          OR profiles.teljes_nev = split_part(profiles.email, '@', 1)
                        THEN COALESCE(v_name, profiles.teljes_nev)
                        ELSE profiles.teljes_nev
                      END,
         updated_at = now()
   WHERE id = NEW.user_id;

  RETURN NEW;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.sync_provider_identity() FROM PUBLIC, anon, authenticated;

DROP TRIGGER IF EXISTS on_auth_identity_upsert ON auth.identities;
CREATE TRIGGER on_auth_identity_upsert
  AFTER INSERT OR UPDATE ON auth.identities
  FOR EACH ROW EXECUTE FUNCTION public.sync_provider_identity();

-- 3) enrich handle_new_user with avatar/name from OAuth metadata
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, teljes_nev, avatar_url, foglalkozas_tipus)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(
      NEW.raw_user_meta_data->>'teljes_nev',
      NEW.raw_user_meta_data->>'full_name',
      NEW.raw_user_meta_data->>'name',
      split_part(NEW.email, '@', 1)
    ),
    COALESCE(
      NEW.raw_user_meta_data->>'avatar_url',
      NEW.raw_user_meta_data->>'picture'
    ),
    'egyeb'
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;


-- ─── 20260702170730_aa1d861c-da6e-4c92-b2fd-e5d4f723ae00.sql ───

-- 1) Allow 'scheduled' as a valid page status
ALTER TABLE public.cms_pages DROP CONSTRAINT IF EXISTS cms_pages_status_check;
ALTER TABLE public.cms_pages ADD CONSTRAINT cms_pages_status_check
  CHECK (status = ANY (ARRAY['draft'::text,'scheduled'::text,'published'::text,'archived'::text]));

-- 2) Auto-publish function: promote due scheduled pages to published
CREATE OR REPLACE FUNCTION public.run_scheduled_cms_publish()
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  updated_count integer;
BEGIN
  WITH promoted AS (
    UPDATE public.cms_pages
       SET status = 'published',
           published_at = now(),
           scheduled_publish_at = NULL,
           updated_at = now()
     WHERE status = 'scheduled'
       AND scheduled_publish_at IS NOT NULL
       AND scheduled_publish_at <= now()
     RETURNING id
  )
  SELECT count(*)::int INTO updated_count FROM promoted;
  RETURN updated_count;
END;
$$;

REVOKE ALL ON FUNCTION public.run_scheduled_cms_publish() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.run_scheduled_cms_publish() TO service_role;

-- 3) pg_cron: run every minute
DO $$
BEGIN
  PERFORM cron.unschedule('cms-auto-publish-scheduled');
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

SELECT cron.schedule(
  'cms-auto-publish-scheduled',
  '* * * * *',
  $cron$SELECT public.run_scheduled_cms_publish();$cron$
);


-- ─── 20260702174159_e4098bc4-5a04-4c85-8411-7500b049dbbb.sql ───
ALTER TABLE public.cms_news_posts ADD COLUMN IF NOT EXISTS preview_token uuid NOT NULL DEFAULT gen_random_uuid();
CREATE INDEX IF NOT EXISTS idx_cms_news_posts_preview_token ON public.cms_news_posts(preview_token);

-- ─── 20260702174549_1a7b997d-bf8f-4740-9d8b-2712960f6ef1.sql ───
ALTER TABLE public.cms_news_posts
  ADD COLUMN IF NOT EXISTS video_width integer,
  ADD COLUMN IF NOT EXISTS video_height integer;

-- ─── 20260702180809_d8d0965b-522f-4d10-9a42-19ef8cce02b0.sql ───
-- Allow public A/B experiment view/goal tracking through the Data API
GRANT SELECT, INSERT ON public.cms_experiment_events TO anon, authenticated;
GRANT ALL ON public.cms_experiment_events TO service_role;

-- Only allow inserts for events belonging to a running experiment,
-- limited to 'view' and 'goal' event types.
DROP POLICY IF EXISTS cms_exp_events_public_insert ON public.cms_experiment_events;
CREATE POLICY cms_exp_events_public_insert
  ON public.cms_experiment_events
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (
    event_type IN ('view','goal')
    AND EXISTS (
      SELECT 1 FROM public.cms_experiments e
      WHERE e.id = experiment_id AND e.status = 'running'
    )
    AND EXISTS (
      SELECT 1 FROM public.cms_experiment_variants v
      WHERE v.id = variant_id AND v.experiment_id = cms_experiment_events.experiment_id
    )
  );

-- ─── 20260702184759_03c73e6e-09b7-4871-9bba-a9f6455d81e3.sql ───

-- Konverziós eseménydefiníciók a kísérleten
ALTER TABLE public.cms_experiments
  ADD COLUMN IF NOT EXISTS conversion_events jsonb NOT NULL DEFAULT '[]'::jsonb;

-- Esemény név + paraméter tárolás
ALTER TABLE public.cms_experiment_events
  ADD COLUMN IF NOT EXISTS event_name text,
  ADD COLUMN IF NOT EXISTS params jsonb;

CREATE INDEX IF NOT EXISTS cms_experiment_events_name_idx
  ON public.cms_experiment_events (experiment_id, event_name);

-- Bővített RPC: event_name + params
CREATE OR REPLACE FUNCTION public.cms_exp_event_record(
  _experiment_id uuid,
  _variant_id uuid,
  _event_type text,
  _session_id text,
  _path text DEFAULT NULL,
  _referrer text DEFAULT NULL,
  _user_agent text DEFAULT NULL,
  _event_name text DEFAULT NULL,
  _params jsonb DEFAULT NULL
)
RETURNS bigint
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  _id bigint;
  _recent_count int;
BEGIN
  IF _event_type NOT IN ('view','goal') THEN
    RAISE EXCEPTION 'invalid event_type';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM public.cms_experiments e WHERE e.id = _experiment_id AND e.status = 'running') THEN
    RETURN NULL;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM public.cms_experiment_variants v WHERE v.id = _variant_id AND v.experiment_id = _experiment_id) THEN
    RAISE EXCEPTION 'variant mismatch';
  END IF;

  IF _session_id IS NOT NULL THEN
    SELECT COUNT(*) INTO _recent_count
    FROM public.cms_experiment_events
    WHERE session_id = _session_id
      AND experiment_id = _experiment_id
      AND created_at > now() - interval '1 minute';
    IF _recent_count > 60 THEN
      RETURN NULL;
    END IF;
  END IF;

  IF _event_type = 'view' AND _session_id IS NOT NULL THEN
    IF EXISTS (
      SELECT 1 FROM public.cms_experiment_events
      WHERE session_id = _session_id
        AND experiment_id = _experiment_id
        AND variant_id = _variant_id
        AND event_type = 'view'
        AND created_at::date = CURRENT_DATE
    ) THEN
      RETURN NULL;
    END IF;
  END IF;

  INSERT INTO public.cms_experiment_events
    (experiment_id, variant_id, event_type, session_id, path, referrer, user_agent, event_name, params)
  VALUES
    (_experiment_id, _variant_id, _event_type, _session_id,
     LEFT(_path, 500), LEFT(_referrer, 500), LEFT(_user_agent, 500),
     NULLIF(LEFT(_event_name, 80), ''), _params)
  RETURNING id INTO _id;

  RETURN _id;
END;
$$;


-- ─── 20260727110806_4b5d986f-5bd7-4375-adc1-0f32121398c9.sql ───
-- 1) Therapy orders: re-verify patient access on update
DROP POLICY IF EXISTS "creator updates therapy" ON public.clinical_therapy_orders;
CREATE POLICY "creator updates therapy"
ON public.clinical_therapy_orders
FOR UPDATE
USING ((auth.uid() = created_by) AND can_access_patient(patient_id))
WITH CHECK ((auth.uid() = created_by) AND can_access_patient(patient_id));

-- 2) Trigger-only SECURITY DEFINER functions must not be API-callable
REVOKE ALL ON FUNCTION public.notify_assignment_insert() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.notify_assignment_delete() FROM PUBLIC, anon, authenticated;

-- 3) Privileged SECURITY DEFINER functions: enforce in-function authorization
CREATE OR REPLACE FUNCTION public.close_leave_year(_tenant uuid, _ev integer, _actor uuid)
 RETURNS integer
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_rec RECORD;
  v_cnt int := 0;
  v_pol RECORD;
  v_max_carry numeric;
  v_uid uuid := auth.uid();
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Authentikáció szükséges.' USING ERRCODE = '42501';
  END IF;
  IF _tenant IS DISTINCT FROM public.current_tenant_id() THEN
    RAISE EXCEPTION 'Nincs jogosultság ehhez a szervezethez.' USING ERRCODE = '42501';
  END IF;
  IF NOT COALESCE(public.has_permission(v_uid, 'manage_tenant'), false) THEN
    RAISE EXCEPTION 'Csak adminisztrátor zárhatja le a szabadságévet.' USING ERRCODE = '42501';
  END IF;

  SELECT * INTO v_pol FROM public.leave_policy WHERE tenant_id = _tenant AND ev = _ev;

  FOR v_rec IN
    SELECT * FROM public.leave_entitlement
    WHERE tenant_id = _tenant AND ev = _ev AND hatralevo > 0 AND lezart_at IS NULL
  LOOP
    v_max_carry := v_rec.hatralevo;
    IF v_rec.jogcim = 'alap' AND COALESCE(v_pol.max_carryover_alap_quarter, true) THEN
      v_max_carry := LEAST(v_rec.hatralevo, ROUND(v_rec.jaro_nap / 4.0, 2));
    END IF;

    INSERT INTO public.leave_entitlement (tenant_id, user_id, ev, jogcim, jaro_nap, athozott_nap)
    VALUES (_tenant, v_rec.user_id, _ev + 1, v_rec.jogcim, 0, v_max_carry)
    ON CONFLICT (tenant_id, user_id, ev, jogcim)
    DO UPDATE SET athozott_nap = public.leave_entitlement.athozott_nap + v_max_carry, updated_at = now();

    INSERT INTO public.leave_carryover_log (tenant_id, user_id, from_year, to_year, jogcim, nap, tipus, created_by, megjegyzes)
    VALUES (_tenant, v_rec.user_id, _ev, _ev + 1, v_rec.jogcim, v_max_carry, 'carryover', _actor,
            CASE WHEN v_max_carry < v_rec.hatralevo THEN format('Korlát: %s nap nem hozható át', v_rec.hatralevo - v_max_carry) ELSE NULL END);

    IF v_max_carry < v_rec.hatralevo THEN
      INSERT INTO public.leave_carryover_log (tenant_id, user_id, from_year, jogcim, nap, tipus, created_by, megjegyzes)
      VALUES (_tenant, v_rec.user_id, _ev, v_rec.jogcim, v_rec.hatralevo - v_max_carry, 'forfeit', _actor, 'Mt. 123. § alap 1/4 korlát');
    END IF;

    UPDATE public.leave_entitlement SET lezart_at = now(), lezart_by = _actor WHERE id = v_rec.id;
    v_cnt := v_cnt + 1;
  END LOOP;

  RETURN v_cnt;
END;
$function$;

CREATE OR REPLACE FUNCTION public.log_leave_admin(_tenant uuid, _actor uuid, _action text, _ev integer, _target_user uuid, _jogcim text, _nap numeric, _before jsonb, _after jsonb, _summary text)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_id uuid;
  v_uid uuid := auth.uid();
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Authentikáció szükséges.' USING ERRCODE = '42501';
  END IF;
  IF _tenant IS DISTINCT FROM public.current_tenant_id() THEN
    RAISE EXCEPTION 'Nincs jogosultság ehhez a szervezethez.' USING ERRCODE = '42501';
  END IF;
  IF NOT COALESCE(public.has_permission(v_uid, 'manage_tenant'), false) THEN
    RAISE EXCEPTION 'Csak adminisztrátor naplózhat szabadság-műveletet.' USING ERRCODE = '42501';
  END IF;

  INSERT INTO public.leave_admin_audit
    (tenant_id, actor_user_id, action, ev, target_user_id, jogcim, nap, before_data, after_data, summary)
  VALUES (_tenant, v_uid, _action, _ev, _target_user, _jogcim, _nap, _before, _after, _summary)
  RETURNING id INTO v_id;
  RETURN v_id;
END $function$;


-- ─── 20260730201418_ccdda2a8-0a99-4479-b25d-775b740b28ca.sql ───
CREATE TABLE IF NOT EXISTS public.i18n_source_strings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  namespace text NOT NULL DEFAULT 'ui',
  key text NOT NULL,
  source_text text NOT NULL,
  element_type text NOT NULL DEFAULT 'label' CHECK (element_type IN ('label','button','title','placeholder','helper','error','menu','badge','content','other')),
  screen text,
  description text,
  translator_note text,
  max_length integer,
  is_active boolean NOT NULL DEFAULT true,
  ai_described boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (namespace, key)
);

CREATE INDEX IF NOT EXISTS i18n_source_strings_ns_idx ON public.i18n_source_strings(namespace);
CREATE INDEX IF NOT EXISTS i18n_source_strings_desc_idx ON public.i18n_source_strings(ai_described);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.i18n_source_strings TO authenticated;
GRANT ALL ON public.i18n_source_strings TO service_role;
ALTER TABLE public.i18n_source_strings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "i18n_source_strings_read" ON public.i18n_source_strings
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "i18n_source_strings_admin_write" ON public.i18n_source_strings
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'tenant_admin'))
  WITH CHECK (public.has_role(auth.uid(), 'tenant_admin'));

CREATE TABLE IF NOT EXISTS public.i18n_translation_jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  langs text[] NOT NULL,
  namespace text,
  mode text NOT NULL DEFAULT 'missing' CHECK (mode IN ('missing','full')),
  status text NOT NULL DEFAULT 'running' CHECK (status IN ('running','done','partial','failed')),
  total integer NOT NULL DEFAULT 0,
  translated integer NOT NULL DEFAULT 0,
  failed integer NOT NULL DEFAULT 0,
  error text,
  started_by uuid,
  started_at timestamptz NOT NULL DEFAULT now(),
  finished_at timestamptz
);

CREATE INDEX IF NOT EXISTS i18n_translation_jobs_started_idx ON public.i18n_translation_jobs(started_at DESC);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.i18n_translation_jobs TO authenticated;
GRANT ALL ON public.i18n_translation_jobs TO service_role;
ALTER TABLE public.i18n_translation_jobs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "i18n_translation_jobs_read" ON public.i18n_translation_jobs
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "i18n_translation_jobs_admin_write" ON public.i18n_translation_jobs
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'tenant_admin'))
  WITH CHECK (public.has_role(auth.uid(), 'tenant_admin'));

CREATE TRIGGER trg_i18n_source_strings_updated
  BEFORE UPDATE ON public.i18n_source_strings
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

ALTER TABLE public.i18n_translations DROP CONSTRAINT IF EXISTS i18n_translations_lang_check;
ALTER TABLE public.i18n_translations
  ADD CONSTRAINT i18n_translations_lang_check
  CHECK (lang IN ('en','hu','ro','sr','zh','fil','de','uk','ru','sk'));