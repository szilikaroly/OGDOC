/**
 * Fejlesztői dokumentáció generátor.
 *
 * Futtatás:  bun run scripts/generate-docs.ts
 *
 * Kimenet:
 *   docs/generated/*.md          – ember által olvasható referencia
 *   docs/export/project-export.json – gépi (importálható) projekt-manifeszt
 *   docs/export/schema.sql       – teljes adatbázis DDL (migrációk sorrendben)
 */
import { readdirSync, readFileSync, writeFileSync, mkdirSync, statSync } from "node:fs";
import { join, relative } from "node:path";

const ROOT = process.cwd();
const OUT_MD = join(ROOT, "docs/generated");
const OUT_EX = join(ROOT, "docs/export");
mkdirSync(OUT_MD, { recursive: true });
mkdirSync(OUT_EX, { recursive: true });

function walk(dir: string, out: string[] = []): string[] {
  for (const e of readdirSync(dir, { withFileTypes: true })) {
    const p = join(dir, e.name);
    if (e.isDirectory()) {
      if (["node_modules", ".git", "dist", ".output"].includes(e.name)) continue;
      walk(p, out);
    } else out.push(p);
  }
  return out;
}

const srcFiles = walk(join(ROOT, "src"));
const rel = (p: string) => relative(ROOT, p).replaceAll("\\", "/");

// ── 1. Route-ok ────────────────────────────────────────────────────────────
type RouteInfo = {
  file: string;
  path: string;
  kind: "public" | "authenticated" | "api";
  ssr: boolean;
  hasLoader: boolean;
  hasHead: boolean;
};
const routes: RouteInfo[] = [];
for (const f of srcFiles) {
  const r = rel(f);
  if (!r.startsWith("src/routes/") || !/\.(tsx|ts)$/.test(r)) continue;
  if (r.endsWith("routeTree.gen.ts")) continue;
  const src = readFileSync(f, "utf8");
  const m = src.match(/createFileRoute\(\s*["'`]([^"'`]+)["'`]\s*\)/);
  const path = m?.[1] ?? "(layout)";
  routes.push({
    file: r,
    path,
    kind: path.startsWith("/api") ? "api" : r.includes("_authenticated") ? "authenticated" : "public",
    ssr: !/ssr:\s*false/.test(src),
    hasLoader: /\bloader\s*:/.test(src),
    hasHead: /\bhead\s*:/.test(src),
  });
}
routes.sort((a, b) => a.path.localeCompare(b.path));

// ── 2. Server function-ök ──────────────────────────────────────────────────
type FnInfo = { file: string; name: string; method: string; auth: boolean; validated: boolean };
const serverFns: FnInfo[] = [];
for (const f of srcFiles) {
  if (!/\.(ts|tsx)$/.test(f)) continue;
  const src = readFileSync(f, "utf8");
  if (!src.includes("createServerFn")) continue;
  const re =
    /export\s+const\s+(\w+)\s*=\s*createServerFn\(\s*(\{[^}]*\})?\s*\)([\s\S]{0,400}?)\.handler/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(src))) {
    const opts = m[2] ?? "";
    const chain = m[3] ?? "";
    serverFns.push({
      file: rel(f),
      name: m[1],
      method: /method:\s*["'](\w+)["']/.exec(opts)?.[1] ?? "POST",
      auth: chain.includes("requireSupabaseAuth"),
      validated: chain.includes("inputValidator"),
    });
  }
}
serverFns.sort((a, b) => a.file.localeCompare(b.file) || a.name.localeCompare(b.name));

// ── 3. Környezeti változók ─────────────────────────────────────────────────
const envClient = new Set<string>();
const envServer = new Set<string>();
for (const f of srcFiles) {
  const src = readFileSync(f, "utf8");
  for (const m of src.matchAll(/import\.meta\.env\.(VITE_[A-Z0-9_]+)/g)) envClient.add(m[1]);
  for (const m of src.matchAll(/process\.env(?:\.|\[["'])([A-Z0-9_]+)/g)) envServer.add(m[1]);
}

// ── 4. CMS blokk-katalógus ────────────────────────────────────────────────
let blocks: Array<Record<string, unknown>> = [];
try {
  const bs = readFileSync(join(ROOT, "src/lib/cms/block-schema.ts"), "utf8");
  for (const m of bs.matchAll(
    /\{\s*type:\s*"([^"]+)",\s*label:\s*"([^"]+)",[\s\S]{0,400}?category:\s*"([^"]+)"/g,
  )) {
    blocks.push({ type: m[1], label: m[2], category: m[3] });
  }
  for (const m of bs.matchAll(/\{\s*type:\s*"([^"]+)",\s*label:\s*"([^"]+)",\s*category:\s*"([^"]+)"/g)) {
    if (!blocks.some((b) => b.type === m[1])) blocks.push({ type: m[1], label: m[2], category: m[3] });
  }
} catch {
  /* nincs katalógus */
}

// ── 5. i18n kulcsok ───────────────────────────────────────────────────────
let i18nKeys = 0;
let languages: string[] = [];
try {
  const hu = readFileSync(join(ROOT, "src/i18n/locales/hu.ts"), "utf8");
  i18nKeys = [...hu.matchAll(/^\s{2,}"?[\w.-]+"?\s*:/gm)].length;
  const langs = readFileSync(join(ROOT, "src/i18n/languages.ts"), "utf8");
  languages = [...langs.matchAll(/code:\s*"(\w+)"/g)].map((m) => m[1]);
} catch {
  /* opcionális */
}

// ── 6. Migrációk → teljes schema.sql ──────────────────────────────────────
const migDir = join(ROOT, "supabase/migrations");
let migrations: string[] = [];
try {
  migrations = readdirSync(migDir).filter((f) => f.endsWith(".sql")).sort();
} catch {
  /* nincs */
}
const schemaSql = [
  "-- =====================================================================",
  "-- TELJES ADATBÁZIS SÉMA (generált: minden migráció időrendben)",
  "-- Importálás üres Postgres/Supabase projektbe: psql -f schema.sql",
  `-- Generálva: ${new Date().toISOString()}  |  Migrációk: ${migrations.length}`,
  "-- =====================================================================",
  "",
  ...migrations.map((f) => `\n-- ─── ${f} ───\n${readFileSync(join(migDir, f), "utf8")}`),
].join("\n");
writeFileSync(join(OUT_EX, "schema.sql"), schemaSql);

// ── 7. Komponens / hook / lib leltár ──────────────────────────────────────
const inventory = {
  components: srcFiles.filter((f) => rel(f).startsWith("src/components/")).map(rel).sort(),
  hooks: srcFiles.filter((f) => rel(f).startsWith("src/hooks/")).map(rel).sort(),
  lib: srcFiles.filter((f) => rel(f).startsWith("src/lib/")).map(rel).sort(),
  tests: srcFiles.filter((f) => /\.test\.tsx?$/.test(f)).map(rel).sort(),
};

const pkg = JSON.parse(readFileSync(join(ROOT, "package.json"), "utf8"));

const manifest = {
  generatedAt: new Date().toISOString(),
  project: {
    name: "IntuiCare Planner — klinikai + HR + CMS platform",
    stack: {
      framework: "TanStack Start v1 (React 19, Vite 7)",
      styling: "Tailwind CSS v4 + shadcn/ui",
      backend: "Lovable Cloud (Supabase: Postgres + Auth + Storage + Realtime)",
      ai: "Lovable AI Gateway (google/gemini-3.6-flash, openai/gpt-4o-mini)",
      runtime: "Cloudflare Workers (edge, nodejs_compat)",
    },
    dependencies: pkg.dependencies,
    devDependencies: pkg.devDependencies,
    scripts: pkg.scripts,
  },
  stats: {
    routes: routes.length,
    serverFunctions: serverFns.length,
    migrations: migrations.length,
    components: inventory.components.length,
    hooks: inventory.hooks.length,
    libModules: inventory.lib.length,
    cmsBlocks: blocks.length,
    i18nKeysHu: i18nKeys,
  },
  languages,
  routes,
  serverFunctions: serverFns,
  cmsBlocks: blocks,
  env: {
    client: [...envClient].sort(),
    server: [...envServer].sort(),
  },
  inventory,
  migrations,
};
writeFileSync(join(OUT_EX, "project-export.json"), JSON.stringify(manifest, null, 2));

// ── 8. Markdown riportok ──────────────────────────────────────────────────
const table = (head: string[], rows: string[][]) =>
  [`| ${head.join(" | ")} |`, `| ${head.map(() => "---").join(" | ")} |`, ...rows.map((r) => `| ${r.join(" | ")} |`)].join("\n");

writeFileSync(
  join(OUT_MD, "routes.md"),
  `# Route-térkép (generált)\n\nÖsszesen: **${routes.length}** route.\n\n` +
    (["public", "authenticated", "api"] as const)
      .map(
        (k) =>
          `## ${k}\n\n` +
          table(
            ["Útvonal", "Fájl", "SSR", "loader", "head()"],
            routes.filter((r) => r.kind === k).map((r) => [
              `\`${r.path}\``,
              `\`${r.file}\``,
              r.ssr ? "igen" : "nem",
              r.hasLoader ? "✓" : "",
              r.hasHead ? "✓" : "",
            ]),
          ),
      )
      .join("\n\n") +
    "\n",
);

writeFileSync(
  join(OUT_MD, "server-functions.md"),
  `# Server function API (generált)\n\nÖsszesen: **${serverFns.length}** \`createServerFn\`.\n` +
    `\`auth\` = \`requireSupabaseAuth\` middleware, \`zod\` = \`inputValidator\` jelen van.\n\n` +
    table(
      ["Név", "Metódus", "auth", "zod", "Modul"],
      serverFns.map((f) => [`\`${f.name}\``, f.method, f.auth ? "✓" : "—", f.validated ? "✓" : "—", `\`${f.file}\``]),
    ) +
    "\n",
);

writeFileSync(
  join(OUT_MD, "cms-blocks.md"),
  `# CMS blokk-katalógus (generált)\n\n` +
    table(["type", "Címke", "Kategória"], blocks.map((b) => [`\`${b.type}\``, String(b.label), String(b.category)])) +
    "\n",
);

writeFileSync(
  join(OUT_MD, "env.md"),
  `# Környezeti változók (generált)\n\n## Kliens (\`import.meta.env\`)\n\n` +
    [...envClient].sort().map((e) => `- \`${e}\``).join("\n") +
    `\n\n## Szerver (\`process.env\`, csak handler-en belül)\n\n` +
    [...envServer].sort().map((e) => `- \`${e}\``).join("\n") +
    "\n",
);

writeFileSync(
  join(OUT_MD, "inventory.md"),
  `# Modul-leltár (generált)\n\n` +
    Object.entries(inventory)
      .map(([k, v]) => `## ${k} (${(v as string[]).length})\n\n` + (v as string[]).map((p) => `- \`${p}\``).join("\n"))
      .join("\n\n") +
    "\n",
);

console.log(
  JSON.stringify(
    { routes: routes.length, serverFns: serverFns.length, migrations: migrations.length, blocks: blocks.length, i18nKeys },
    null,
    2,
  ),
);

// ── 9. Adatbázis mező-referencia (a generált Supabase típusokból) ─────────
try {
  const t = readFileSync(join(ROOT, "src/integrations/supabase/types.ts"), "utf8");
  const tables: Array<{ table: string; columns: Array<{ name: string; type: string; required: boolean }> }> = [];
  const tblRe = /^ {6}(\w+): \{\n {8}Row: \{\n([\s\S]*?)\n {8}\}/gm;
  let tm: RegExpExecArray | null;
  while ((tm = tblRe.exec(t))) {
    const cols = [...tm[2].matchAll(/^ {10}(\w+)(\??): (.+)$/gm)].map((c) => ({
      name: c[1],
      type: c[3].trim(),
      required: !c[3].includes("null"),
    }));
    tables.push({ table: tm[1], columns: cols });
  }
  const enums: Record<string, string[]> = {};
  const enumSection = /Enums: \{\n([\s\S]*?)\n {4}\}/.exec(t.split("public: {")[1] ?? "");
  for (const m of (enumSection?.[1] ?? "").matchAll(/^ {6}(\w+):\s*\n?\s*((?:\| )?"[\s\S]*?)(?=\n {6}\w+:|\n *$)/gm)) {
    enums[m[1]] = [...m[2].matchAll(/"([^"]+)"/g)].map((v) => v[1]);
  }
  writeFileSync(join(OUT_EX, "database-fields.json"), JSON.stringify({ tables, enums }, null, 2));
  writeFileSync(
    join(OUT_MD, "database.md"),
    `# Adatbázis mező-referencia (generált)\n\nTáblák: **${tables.length}** · Enum típusok: **${Object.keys(enums).length}**\n\n` +
      tables
        .map(
          (tb) =>
            `## \`${tb.table}\`\n\n` +
            table(["Mező", "Típus", "Kötelező"], tb.columns.map((c) => [`\`${c.name}\``, `\`${c.type.replaceAll("|", "\\|")}\``, c.required ? "igen" : "nem"])),
        )
        .join("\n\n") +
      `\n\n## Enum típusok\n\n` +
      Object.entries(enums).map(([k, v]) => `- \`${k}\`: ${v.map((x) => `\`${x}\``).join(", ")}`).join("\n") +
      "\n",
  );
  console.log(`db tables: ${tables.length}, enums: ${Object.keys(enums).length}`);
} catch (e) {
  console.warn("DB típusok feldolgozása kihagyva:", (e as Error).message);
}
