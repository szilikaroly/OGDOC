# Admin Control Center

Központi konfigurációs felület, amelyen keresztül az adminok minden runtime-paraméterezhetőség nélkül módosíthatnak — kódváltoztatás nélkül.

## Áttekintés

- **Útvonal:** `/admin/beallitasok` — beállítások; `/admin/landing` — landing oldal szerkesztő.
- **Jogosultság:** csak `admin` szerepkör (`requires: "manage_tenant"`).
- **Forrásigazság:** `src/lib/admin/settings-catalog.ts` — minden beállítási pont itt van leírva (namespace, key, típus, default, scope, AI-prompt sablon).
- **Tárolás:** `app_settings` tábla (JSONB érték), minden változás `app_settings_audit`-be naplózva.

## Adatmodell

| Tábla | Cél |
|---|---|
| `app_settings` | Aktuális kulcs/érték konfigurációk, `(namespace, key)` PK. |
| `app_settings_audit` | Minden írás napló (régi → új érték, ki, mikor). |
| `landing_page_blocks` | Sorrendezett blokkok (hero, FAQ, CTA, stb.) JSONB tartalommal, `is_published` flaggel. |
| `landing_page_versions` | Verziózás (snapshot pubikáláskor, visszagörgetés). |
| `ai_setting_suggestions` | AI által generált javaslatok cache-elve (kulcs, érték, indoklás, elfogadva-e). |

Mind RLS-szel: `admin` ír/olvas, `authenticated` csak olvas, `anon` csak a `scope='public'` kulcsokat (`get_public_settings()` SECURITY DEFINER fn-en keresztül) és a publikált landing blokkokat.

## Scope: `public` vs `private`

- **public:** olvasható anon felhasználó által is — branding, modul-kapcsolók, landing-szövegek, feature flagek.
- **private:** csak hitelesített / admin — auth-szabályok, AI-promptok, klinikai küszöbök, email-feladók, integráció endpoint-ok.

A landing oldal `/` `getPublicSettings`-en keresztül olvas — soha nem szivárog ki private érték.

## Új beállítás hozzáadása

Csak `settings-catalog.ts` bővítendő:

```ts
{
  namespace: "general",
  key: "uj_kulcs",
  label: "Új beállítás",
  description: "Mire való.",
  type: "string", // string | text | markdown | number | boolean | color | enum | json | duration_seconds | role_list | string_list
  default: "alapérték",
  scope: "public",
  aiPrompt: "Opcionális — AI sablon",
}
```

A katalógusból automatikusan megjelenik az admin felületen, kap mezőkomponenst, "✨ Javaslat" gombot, "Reset to default"-ot és audit linket. Nincs új migrationra szükség (JSONB store).

## AI asszisztens

`src/lib/admin/ai-settings.functions.ts`:

| Server fn | Funkció |
|---|---|
| `suggestSettingValue` | Egy adott mezőre javaslatot ad (cél + jelenlegi érték + brand-kontextus alapján). |
| `suggestSettingsBatch` | "AI Setup Wizard" — szabad szöveg → több beállításra javaslat. |
| `explainSetting` | "Mit jelent ez a beállítás? Mire hat?" — info-tooltip tartalom. |
| `generateLandingBlock` | Egy mező AI generálás (pl. hero subtitle). |
| `generateFullLandingDraft` | Teljes landing vázlat blokkokkal. |

Mind védve `requireSupabaseAuth` + `has_role('admin')`. Lovable AI Gateway, alap modell `google/gemini-3-flash-preview`. Eredmények mentve `ai_setting_suggestions`-be (újrahasználat, audit).

## Landing oldal szerkesztő

- **Útvonal:** `/admin/landing`.
- Bal oldal: blokk-lista (drag-mentes mozgatás fel/le nyilakkal, törlés).
- Jobb oldal: élő preview a `DynamicLanding` komponenssel.
- Blokk-típusok: `hero`, `feature_grid`, `stats`, `cta_band`, `faq`, `image_text`, `custom_html`.
- "AI generálás" mezőszinten és teljes-oldal szinten is.
- Publikálás: `is_published=true` minden blokkra → a `/` az új tartalmat mutatja, amennyiben a `feature_flags.landing_dynamic` igaz.
- Bulk replace előtt automatikus verzió-mentés a `landing_page_versions`-be.

## Export / Import

A `/admin/beallitasok` felületen "Export" gomb letölt egy JSON-t az aktuális értékekkel (private kulcsok is, mert csak adminok férnek hozzá). "Import" visszaolvas — kulcsonként `upsert`-ezi az értékeket. Audit log minden importált rekordra létrejön.

## Frissítési ciklus

- Admin felület és landing TanStack Query-ből olvas, `staleTime: 5 perc`.
- Mentés után invalidate → 5 másodpercen belül élesedik.
- Publikálás landing oldalon szintén invalidate-eli a publikus query-t.

## Audit

Minden írás (`upsert_setting`, `reset_setting`, `import_settings`) trigger-rel naplózódik: ki, mikor, régi érték, új érték. Az audit napló admin oldalon vissza-kereshető (jövőbeni nézet).

## Tesztek

- `src/lib/admin/settings-catalog.test.ts` — katalógus integritás (nincs duplikátum, enum default benne van az options-ben, number a tartományban).
- `tests/e2e/admin-control-center.py` — admin login → beállítás módosítás → mentés → audit → landing szerkesztés → publikálás.
