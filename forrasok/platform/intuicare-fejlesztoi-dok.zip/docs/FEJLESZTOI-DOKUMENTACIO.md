# IntuiCare Planner — Teljes fejlesztői dokumentáció

> Generált kiegészítők: `docs/generated/*.md` (route-ok, server function API, adatbázis mezők, CMS blokkok, env, modul-leltár)
> Gépi export: `docs/export/project-export.json`, `docs/export/database-fields.json`, `docs/export/schema.sql`
> Újragenerálás: `bun run scripts/generate-docs.ts`

---

## 0. Gyorsadatok

| Metrika | Érték |
| --- | --- |
| Route-ok | 158 (publikus + `_authenticated` + `/api`) |
| Server function-ök (`createServerFn`) | 407 |
| Adatbázis-táblák (`public`) | 230 |
| Postgres enum típusok | 65 |
| SQL migrációk | 155 (teljes DDL: `docs/export/schema.sql`) |
| CMS blokk-típusok | 34 |
| Támogatott nyelvek | hu, en, de, ro, sk, sr, uk, ru, zh, fil |
| i18n kulcsok (hu) | ~473 + adatbázis-alapú Fordító Stúdió |

---

## 1. Rendszerarchitektúra

```text
                 ┌───────────────────────────────────────────┐
  Böngésző  ───► │ TanStack Start (React 19 + Vite 7)        │
  / PWA          │  • src/routes/**  (fájl-alapú routing)     │
                 │  • TanStack Query (cache + persist)        │
                 │  • Tailwind v4 + shadcn/ui design tokenek  │
                 └───────────────┬───────────────────────────┘
                                 │ RPC: createServerFn (bearer token)
                                 │ HTTP: /api/public/* (webhook, cron, sitemap, OG)
                 ┌───────────────▼───────────────────────────┐
                 │ Edge runtime (Cloudflare Workers)         │
                 │  • auth-middleware (requireSupabaseAuth)  │
                 │  • *.server.ts privilegizált logika       │
                 │  • Lovable AI Gateway hívások             │
                 └───────────────┬───────────────────────────┘
                                 │ PostgREST / RPC / Realtime / Storage
                 ┌───────────────▼───────────────────────────┐
                 │ Lovable Cloud (Postgres + Auth + Storage) │
                 │  • RLS minden táblán + GRANT-ok           │
                 │  • SECURITY DEFINER függvények, triggerek │
                 │  • pg_cron ütemezett feladatok            │
                 └───────────────────────────────────────────┘
```

### Rétegek és felelősségek

| Réteg | Hely | Szabály |
| --- | --- | --- |
| Route / oldal | `src/routes/**` | Csak komponáció + `loader` + `head()`. Üzleti logika nem itt van. |
| UI komponens | `src/components/**` | Prezentáció; kizárólag semantikus design tokenek. |
| Domain logika | `src/lib/<domain>/**` | Tiszta függvények, Zod sémák, formázók, számítások. |
| RPC | `src/lib/**/*.functions.ts` | `createServerFn` — kliensből hívható, kliens-biztos modulútvonalon. |
| Szerver-only | `src/lib/**/*.server.ts` | Admin kliens, AI kulcsok, PDF/OG renderelés. Kliensből soha nem importálható. |
| HTTP endpoint | `src/routes/api/**` | Webhook, cron, sitemap, OG-kép; `api/public/*` auth nélkül, saját ellenőrzéssel. |

---

## 2. Funkcionális modulok

| Modul | Fő útvonalak | Fő táblák |
| --- | --- | --- |
| **Beosztás / ütemezés** | `/beosztas`, `/admin/letszam-igeny`, `/vezeto/keresek` | `schedule_runs`, `schedule_assignments`, `duty_lines`, `duty_availability`, `schedule_change_requests` |
| **Munkaidő & jelenlét** | `/munkaido`, `/jelenlet`, `/admin/jelenlet-anomaliak` | `attendance_events`, `attendance_anchors`, `profile_work_time_frame`, `overtime_orders` |
| **Szabadság** | `/szabadsag`, `/admin/szabadsag-szabalyzat` | `leave_policy`, `leave_entitlement`, `leave_carryover_log`, `profile_unavailability` |
| **HR / karakterlap** | `/karakterlap`, `/csapat`, `/kepzes` | `profiles`, `profile_employment`, `profile_skills`, `minosites`, `illetmeny_snapshots` |
| **Klinikai** | `/klinika/*`, `/paciens-360/$patientId` | `clinical_encounters`, `clinical_observations`, `clinical_notes`, `clinical_therapy_orders`, `obstetric_partograms` |
| **Műtéti tervezés** | `/muteti-terv/*` | `or_blocks`, `or_suites`, `or_resources`, `or_staff_pool`, `incompatibilities` |
| **Páciens portál** | `/portal/*` | `patients`, `patient_users`, `measurements`, `patient_documents`, `patient_health_plans` |
| **Időpont / foglalás** | `/foglalas/*`, `/idopontok/*`, `/checkin` | `appointments`, `appointment_slots`, `appointment_templates`, `patient_checkin` |
| **Kérdőívek** | `/kerdoivek/*`, `/kiosk/$token` | `questionnaires`, `questionnaire_assignments`, `questionnaire_responses` |
| **Üzenetek** | `/uzenetek/*`, `/portal/uzenetek` | `conversations`, `messages`, `message_attachments`, `push_subscriptions` |
| **CMS + landing** | `/`, `/o/$slug`, `/hirek`, `/blog`, `/vlog`, `/admin/cms/*` | `cms_pages`, `cms_layout_blocks`, `cms_global_regions`, `cms_news_posts`, `cms_menus`, `cms_experiments` |
| **i18n / Fordító Stúdió** | `/admin/forditasok` | `i18n_source_strings`, `i18n_translations`, `i18n_translation_jobs`, `i18n_missing_keys` |
| **Adminisztráció** | `/admin/*` | `app_settings`, `role_permissions`, `admin_audit_log`, `feature_flags`, `error_log` |

---

## 3. Kód-minták (kötelező sablonok)

### 3.1 Server function (nyilvános olvasás)

```ts
// src/lib/<domain>/<domain>.functions.ts
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

const Input = z.object({ slug: z.string().min(1), locale: z.string().default("hu") });

export const getPublicThing = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) => Input.parse(d))
  .handler(async ({ data }) => {
    const sb = createClient<Database>(
      process.env["SUPABASE_URL"]!,
      process.env["SUPABASE_PUBLISHABLE_KEY"]!,
      { auth: { persistSession: false, autoRefreshToken: false, storage: undefined } },
    );
    const { data: row, error } = await sb
      .from("cms_pages").select("id,title,slug").eq("slug", data.slug).maybeSingle();
    if (error) throw error;
    return row;
  });
```

### 3.2 Server function (bejelentkezett felhasználó)

```ts
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const listMyItems = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("profile_skills").select("*").eq("profile_id", context.userId);
    if (error) throw error;
    return data;
  });
```

### 3.3 Privilegizált művelet (RLS megkerülés, csak ellenőrzés után)

```ts
export const adminFix = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data: ok } = await context.supabase.rpc("has_role", {
      _user_id: context.userId, _role: "tenant_admin",
    });
    if (!ok) throw new Error("Nincs jogosultság");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    // ... admin művelet
  });
```

### 3.4 Route adatbetöltés

```tsx
export const Route = createFileRoute("/o/$slug")({
  validateSearch: (s: Record<string, unknown>): { preview?: string } => ({
    preview: typeof s.preview === "string" ? s.preview : undefined,
  }),
  loaderDeps: ({ search }) => ({ preview: search.preview }),
  loader: ({ params, deps }) => getPublicThing({ data: { slug: params.slug, ...deps } }),
  head: ({ loaderData }) => ({
    meta: [
      { title: `${loaderData?.title} – Klinika` },
      { name: "description", content: loaderData?.excerpt ?? "" },
      { property: "og:title", content: loaderData?.title ?? "" },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  errorComponent: ErrorPage,
  notFoundComponent: NotFound,
  component: Page,
});
```

**Fontos:** minden `validateSearch` visszatérési típusa opcionális mezőkkel legyen annotálva (`{ x?: string }`), különben a `<Link>` kötelezővé teszi a `search` propot.

### 3.5 Migráció-sablon (kötelező sorrend)

```sql
create table public.new_table (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

grant select, insert, update, delete on public.new_table to authenticated;
grant all on public.new_table to service_role;
-- grant select on public.new_table to anon;  -- CSAK ha van anon policy

alter table public.new_table enable row level security;

create policy "own rows" on public.new_table
  for all to authenticated
  using (auth.uid() = user_id) with check (auth.uid() = user_id);
```

Szerepkörök **soha** nem a `profiles` táblán: `user_roles` + `public.has_role(uuid, app_role)` SECURITY DEFINER függvény.

---

## 4. Adatbázis-konvenciók

- Elnevezés: tábla és mező **snake_case, magyar** domain-szókinccsel (`profile_employment`, `jogviszony_tipus`).
- Kötelező oszlopok új tábláknál: `id uuid pk`, `created_at timestamptz`, ahol releváns `tenant_id`, `updated_at`.
- Multi-tenant szűrés: `tenant_id` + `public.current_tenant_id()`.
- Auditálás: `admin_audit_log`, `app_settings_audit`, `cms_audit_log`, `leave_admin_audit` — `audit_trigger_fn()` triggerrel.
- Enumok Postgres `create type ... as enum`, a TS oldalon a generált `Database["public"]["Enums"]` típusból származnak — kézzel ne duplikáld.
- Teljes mező- és enum-referencia: `docs/generated/database.md`, gépi formában `docs/export/database-fields.json`.

---

## 5. Változó- és mező-előkészítés (integrációhoz)

### 5.1 Környezeti változók

Kliens (`import.meta.env`): `VITE_SUPABASE_URL`, `VITE_SUPABASE_PUBLISHABLE_KEY`, `VITE_SUPABASE_PROJECT_ID`.

Szerver (`process.env`, kizárólag handleren belül): `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, `LOVABLE_API_KEY`, valamint push/e-mail kulcsok. A pontos, kódból kinyert lista: `docs/generated/env.md`.

### 5.2 Névterek

| Névtér | Használat |
| --- | --- |
| `app_settings.namespace/key` | Futásidejű, adminban szerkeszthető beállítások (`use-app-settings.ts`) |
| `i18n_source_strings.namespace::key` | Fordítható UI feliratok, magyarázattal |
| `cms_layout_blocks.block_type` | CMS blokk-típus kulcs (lásd `src/lib/cms/block-schema.ts`) |
| `feature_flags.key` | Funkciókapcsolók |
| `role_permissions.permission` | Jogosultság-kulcsok (`use-permissions.tsx`) |

### 5.3 Új mező bevezetésének checklistje

1. Migráció: oszlop + `grant` + policy-hatás ellenőrzés.
2. Generált típusok frissülése (`src/integrations/supabase/types.ts`) — kézzel nem szerkesztjük.
3. Zod séma bővítése a domain `*-schema.ts` fájlban (pl. `src/lib/monitoring/threshold-schema.ts` mintájára).
4. Server function `inputValidator` frissítése.
5. UI mező + i18n kulcs (`src/i18n/locales/hu.ts` és a Fordító Stúdió szinkron).
6. Audit/log mező szükséges-e (`reason` kötelező érzékeny műveleteknél).
7. Doksi újragenerálás: `bun run scripts/generate-docs.ts`.

---

## 6. CMS és vizuális szerkesztő

- Blokk-katalógus: `src/lib/cms/block-schema.ts` (34 típus: `klinika_*` layout, generikus, `dyn_*` élő adatbázis-blokkok).
- Tartalom: `cms_pages` → `cms_layout_blocks` (`content jsonb`), globális régiók: `cms_global_regions` (`top_bar`, `header`, `main_nav`, `footer`, `mobile_drawer`).
- Szerkesztő: `/admin/cms/visual` — `EditorWorkbench` egységes engine (drag&drop paletta, iframe live preview, `PreviewDeviceSwitcher` mobil/tablet/desktop, autosave + verziótörténet + undo/redo, Tiptap WYSIWYG).
- Workflow: `cms_workflow_state` (draft → in_review → approved → published), ütemezett publikálás `pg_cron`-nal, `cms_audit_log` naplóval.
- SEO: automatikus JSON-LD (`src/lib/cms/jsonld.ts`), OG-kép generálás (`/api/public/og/*`), sitemap-index (`/sitemap.xml` + al-sitemapek), slug-váltásnál automatikus 301 (`cms_redirects`).
- A/B teszt: `cms_experiments` / `_variants` / `_events`, `useExperiment(blockId)` hook sticky variánssal, `?expdebug=1` admin overlay, CSV export.
- Biztonság: minden nyers HTML `src/lib/cms/sanitize-html.ts` (DOMPurify + SSR regex fallback) szűrésen megy át.

---

## 7. Többnyelvűség (Fordító Stúdió)

- Statikus kulcsok: `src/i18n/locales/*.ts`, `useTranslation()` / `<T>` komponens.
- Adatbázis-alapú: `i18n_source_strings` (forrásszöveg + **részletes magyarázat**, `element_type`, `screen`, `max_length`), `i18n_translations`, `i18n_translation_jobs`.
- AI: `src/lib/i18n/registry.server.ts` — `describeSourceStrings()` magyarázatot generál, `translateWithContext()` kontextussal + kötelező szótárral fordít (`google/gemini-3.6-flash`).
- Módok: nyelvenkénti vagy teljes futtatás, `missing` (csak hiányzó) vagy `full` (újrafordítás). Kézi fordítás (`edited_by_user`) soha nem íródik felül.
- Hiányzó kulcsok monitorozása: `?tdebug=1` panel + `i18n_missing_keys`.

---

## 8. Biztonság és megfelelőség

- RLS mindenhol; `service_role` csak szerveroldali, ellenőrzés utáni műveletekre.
- SECURITY DEFINER függvények `set search_path = public`, `execute` visszavonva `anon`-tól ott, ahol nem publikus.
- Páciens-hozzáférés: `can_access_patient()`, `current_user_patient_ids()`.
- GDPR: `gdpr_consents`, páciens-adat export (`src/lib/patient-gdpr-export.ts`), jogi leírás: `docs/jogi-megfeleloseg.md`.
- Naplózás: `error_log` + `src/lib/server-fn-logger.ts`, globális hiba-toastok.
- Tesztek: `src/__tests__/*` (Vitest), `tests/rls/*.sql` invariánsok, `tests/e2e/*.py` (Playwright).

---

## 9. Integrálás / importálás másik környezetbe

### 9.1 Adatbázis

```bash
# Üres Supabase/Postgres projektbe – a teljes séma egy fájlban
psql "$DATABASE_URL" -f docs/export/schema.sql
```

Vagy migrációnként, időrendben: `supabase/migrations/*.sql` (155 fájl, fájlnév = időbélyeg).

### 9.2 Alkalmazás

```bash
bun install
cp .env.example .env       # majd töltsd ki a docs/generated/env.md szerinti kulcsokat
bun run dev                # http://localhost:8080
bun run build              # edge (Workers) build
```

### 9.3 Gépi manifeszt

`docs/export/project-export.json` tartalma: stack- és függőségleírás, összes route (útvonal, fájl, SSR, loader, head), összes server function (név, metódus, auth, validáció, modul), CMS blokk-katalógus, env-változók, modul-leltár, migrációlista, statisztikák. Ez a fájl közvetlenül feldolgozható kódgenerátorral vagy másik rendszer importőrével.

`docs/export/database-fields.json`: minden tábla minden mezője (név, TS-típus, kötelezőség) + az összes enum és értékkészlete — ebből mappelhető külső rendszer adatmodellje.

### 9.4 Kompatibilitási korlátok

- Edge runtime: nincs `child_process`, `sharp`, natív addon; PDF/OG WASM-alapú (`@react-pdf/renderer`, `@resvg/resvg-wasm`).
- Router kötött: TanStack Router (react-router nem támogatott).
- Backend-logika `createServerFn` / server route — Supabase Edge Function nem használatos.

---

## 10. Dokumentáció karbantartása

| Fájl | Tartalom | Forrás |
| --- | --- | --- |
| `docs/FEJLESZTOI-DOKUMENTACIO.md` | ez a dokumentum (kézi) | — |
| `docs/architektura.md` | rövid architektúra-áttekintés | kézi |
| `docs/admin-control-center.md` | admin modul leírás | kézi |
| `docs/jogi-megfeleloseg.md` | GDPR / jogi | kézi |
| `docs/generated/*.md` | route-ok, server API, DB mezők, blokkok, env, leltár | `scripts/generate-docs.ts` |
| `docs/export/*` | gépi export + teljes DDL | `scripts/generate-docs.ts` |

Minden nagyobb fejlesztés után: `bun run docs`.
