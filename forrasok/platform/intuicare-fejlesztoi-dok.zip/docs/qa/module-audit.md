# MedRoster — Modulonkénti audit mátrix

Generálva: 2026-06-23 (kódstatikus audit). PASS = audit hibát nem azonosított. REVIEW = élő futás javasolt. BUG = lásd `MedRoster_E2E_Bug_List.md`.

## 1. Védett route-ok (_authenticated/)

| Route | Elsődleges szerepkör | Server fn | Tábla(k) | Audit státusz |
|---|---|---|---|---|
| `dashboard.tsx` | minden staff | `csapat.functions.ts` | `dashboard_widget_prefs`, `profiles` | PASS |
| `iranyitopult.tsx` | vezető+ | `or/board.functions.ts` | `or_blocks`, `surgery_cases` | REVIEW |
| `beosztas.tsx` | vezető, beoszto | `csapat.functions.ts` | `schedule_assignments`, `schedule_runs` | REVIEW |
| `csapat.tsx` | orvos+ | `csapat.functions.ts` | `profiles`, `user_roles` | PASS |
| `csapat-mutatok.tsx` | vezető | — | `profile_skills`, `competency_levels` | PASS |
| `muteti-terv.tsx` + `.blokkok.tsx` + `.varolista.tsx` | sebész, vezető | `or/board`, `or/sequence` | `or_blocks`, `surgery_cases`, `surgery_case_assignments` | BUG-005, BUG-006 |
| `klinika.tsx` + `.lazlap.$encounterId` + `.partogram.$encounterId` | orvos, szakdolgozó | `clinical/ai-notes` | `clinical_encounters`, `clinical_notes`, `clinical_observations` | BUG-008, BUG-009 |
| `klinika.eszkozok.diab/embolia/kardio/szepszis/szules/t2dm/vergaz/vese` | orvos | `monitoring/thresholds`, `ai-medical` | `clinical_calculator_results`, `monitoring_thresholds` | REVIEW |
| `idopontok.index.tsx` + `.sablonok.tsx` | recepció, vezető | `booking/booking.functions.ts` | `appointments`, `appointment_slots`, `appointment_templates`, `appointment_resources` | PASS |
| `paciensek.tsx` + `paciens-360.$patientId.tsx` | orvos, vezető | `paciens-360/paciens-360.functions.ts` | `patients`, `patient_encounters`, `paciens_360_saved_views` | REVIEW |
| `kerdoivek.index/.attekintes/.recepcio/.varo/.riasztasok` | orvos, recepció | `questionnaires/questionnaires.functions.ts` | `questionnaires`, `questionnaire_responses`, `questionnaire_assignments` | REVIEW |
| `visszajelzesek.tsx` | orvos, vezető | `questionnaires`, `monitoring` | `critical_result_alerts`, `clinical_alert_status_log` | BUG-011 |
| `elegedettseg.tsx` | vezető | — | `satisfaction_surveys` | PASS |
| `uzenetek.*` (index, $conversationId, uj) | minden | `messaging/conversations`, `messages` | `conversations`, `messages`, `message_translations` | REVIEW |
| `munkaido.tsx` | orvos, vezető | `leave/leave.functions.ts` | `work_time_ledger`, `work_time_rules` | PASS |
| `szabadsag.tsx` | orvos, vezető | `leave/leave.functions.ts` | `leave_entitlement`, `leave_carryover_log` | PASS |
| `kepzes.tsx` + `karakterlap.tsx` | orvos | `csapat` | `training_programs`, `profile_trainings` | PASS |
| `jelenlet.tsx` | minden | — | `attendance_events`, `attendance_anchors` | REVIEW |
| `vezeto.keresek.tsx` | vezető | — | `schedule_change_requests` | PASS |
| `audit.tsx` | tenant_admin | — | `admin_audit_log` | PASS (RLS szigorú) |

## 2. Admin route-ok (`_authenticated/admin/*`)

| Route | Server fn | Tábla(k) | Státusz |
|---|---|---|---|
| `beallitasok.tsx` | `admin/settings.functions.ts` | `app_settings`, `app_settings_audit` | BUG-001, BUG-002 |
| `landing.tsx` | `admin/landing.functions.ts` | `landing_page_blocks`, `landing_page_versions` | PASS |
| `szervezet.tsx` + `szervezet-sugo.tsx` | `csapat` | `org_units`, `floors`, `sites` | REVIEW |
| `szerepkorok.tsx` + `jogosultsagok.tsx` | `csapat` | `roles`, `user_roles`, `role_permissions` | BUG-007 |
| `mutet-szabalyok.tsx` | `or/surgery-rules` | `or_room_profiles`, `incompatibilities` | REVIEW |
| `kotelezo-ugyelet.tsx` | — | `mandatory_duty_rules`, `mandatory_duty_exemptions` | PASS |
| `munkaido-szabalyok.tsx` | — | `work_time_rules` | PASS |
| `szabadsag-szabalyzat.tsx` + `szabadsag-felugyelet.tsx` | `leave` | `leave_policy`, `leave_admin_audit` | PASS |
| `letszam-igeny.tsx` + `potlas.tsx` + `tulora-pool.tsx` | `csapat`, `ai-schedule` | `staffing_templates`, `staffing_template_roles`, `overtime_orders` | REVIEW |
| `monitoring-szabalyok.tsx` | `monitoring/thresholds` | `monitoring_thresholds`, `monitoring_programs` | **BUG-009 (P0)** |
| `eszkalacio.tsx` | `monitoring` | `clinical_alert_escalation_rules` | BUG-010 |
| `followup.tsx` | `followup/followup.functions.ts` | `followup_protocols`, `followup_enrollments` | REVIEW |
| `paciens-kerelmek.tsx` | `portal/patient-requests` | `patient_appointment_requests` | BUG-004, BUG-005 |
| `portal-analitika.tsx` | `admin/portal-analytics.functions.ts` | — | PASS |
| `forditasok.tsx` | `i18n/admin.functions.ts` | `i18n_translations`, `i18n_missing_keys` | PASS |
| `email.tsx` | `email-admin.functions.ts` | (Resend integráció) | REVIEW |
| `hibanaplo.tsx` | `errors/error-log.functions.ts` | `error_log` | PASS |
| `jelenlet-anomaliak.tsx` + `jelenlet-horgonyok.tsx` | — | `attendance_anchors` | PASS |
| `kerdoiv-emlekeztetok.tsx` | `questionnaires` | `assignment_reminder_log` | PASS |

## 3. Portál route-ok (beteg)

| Route | Server fn | Státusz |
|---|---|---|
| `portal.index.tsx` | `portal/user-classification` | PASS |
| `portal.elojegyzes.tsx` | `portal/patient-requests` | BUG-004 |
| `portal.idopontok.tsx` | `booking` | BUG-013 (REVIEW) |
| `portal.ertesitesek.tsx` | `notifications/emit` | PASS |
| `portal.leletek.tsx` + `portal.zarojelentes.tsx` | `portal/gdpr-export`, `lab-explain` | PASS |
| `portal.kerdoivek.tsx` + `portal.utokovetes.tsx` | `questionnaires/kiosk`, `followup/portal` | REVIEW |
| `portal.meresek.tsx` + `portal.eletmod.tsx` | `monitoring` | PASS |
| `portal.uzenetek.tsx` | `messaging` | REVIEW |
| `portal.orvos-kereso.tsx` | `portal/doctor-search` | PASS |
| `portal.sos.tsx` + `sos.$token.tsx` | `portal/sos` | REVIEW (rate-limit) |
| `portal.beutalok.tsx` | — | REVIEW |
| `portal.profil.tsx` | `portal/link-patient` | PASS |

## 4. Publikus (anonim / token) route-ok

| Route | Megjegyzés | Státusz |
|---|---|---|
| `auth.tsx` | Google OAuth + email/pw | PASS |
| `foglalas.uj.tsx` + `foglalas.visszaigazolas.$kod.tsx` | Nyilvános foglalás | REVIEW (rate-limit, captcha?) |
| `checkin.tsx` | Kioszk-mód | REVIEW (auth) |
| `kiosk.$token.tsx` + `.koszonjuk` | Token-alapú | PASS |
| `elegedettseg.$kod.tsx` | Anonim survey | PASS |
| `share.schedule.$token.tsx` | Beosztás megosztó link | PASS |
| `index.tsx` | Marketing landing | PASS |

## 5. Szerepkör → Route mátrix (összefoglaló)

| Szerepkör | Domén route-ok | Admin route-ok | Portál |
|---|---|---|---|
| tenant_admin | minden domén route | minden `admin/*` | — |
| ugyeletvezeto+ (vezető kategória) | iranyitopult, beosztas, muteti-terv, idopontok, csapat-mutatok, kepzes-felugyelet | letszam-igeny, potlas, tulora-pool, eszkalacio (view) | — |
| foorvos/szakorvos (orvos) | klinika, paciensek, paciens-360, kerdoivek, visszajelzesek, idopontok (saját), uzenetek, munkaido, szabadsag | — | — |
| szakdolgozo | klinika.eszkozok, kerdoivek, uzenetek, jelenlet | — | — |
| beoszto (admin kat.) | beosztas, idopontok, muteti-terv (view), paciensek | paciens-kerelmek, kotelezo-ugyelet | — |
| recepcio (BUG-007: hiányzó role-kulcs) | idopontok, kerdoivek.recepcio, paciensek | paciens-kerelmek | — |
| patient_users (beteg) | — | — | minden portal.* |

## 6. RLS és role-bootstrap megjegyzések

- **`current_tenant_id()`**: a legtöbb tenant-scope policy ezt a függvényt hívja; helmes JWT-claim szükséges a sikerhez.
- **`has_role(_user_id uuid, _role app_role)`**: a forgatókönyv minden lépésénél ezt használjuk (security definer, `search_path=public`).
- **`user_roles_bootstrap_admin`**: BUG-015 — új tenant első user-e bárki, aki insert-elni tud — élesben szigorítandó.
- **`patient_users.user_id`**: a portál minden self-policy-jának bázisa; cross-tenant kockázat ha egy user több tenanthoz van linkelve.
