# MedRoster — Architektúra (élő dokumentum)

> Frissítve: F1 fázis. Minden további fázis bővíti.

## Modulok

| Modul | Frontend útvonal | Adattáblák | RPC / View |
|---|---|---|---|
| Szervezeti fa | `/admin/szervezet` | `clinics`, `sites`, `floors`, `org_units`, `org_unit_departments` | `seed_default_org_for_tenant`, `org_unit_conflicts` |
| Ügyeleti sorok | `/admin/szervezet` (telephely panel) | `duty_lines`, `duty_line_coverage`, `duty_line_eligibility` | `current_duty_lines` |
| Létszámigény | `/admin/letszam-igeny` | `staffing_templates`, `staffing_template_roles` | `generate_demand_for_period` |
| Karakterlap | `/karakterlap` | `profile_*` (20+ tábla) | `wage_simulation`, `get_required_monthly_duty` |
| Önkéntes rendelkezésre állás | `/karakterlap` ▸ Rendelkezésre állás | `duty_availability` | `notify_duty_availability_offer` (trigger) |
| Beosztás | `/beosztas` | `schedule_runs`, `schedule_assignments`, `schedule_explanations`, `schedule_share_tokens` | `publish_schedule_run` |
| Munkaidő ledger | `/munkaido` | `work_time_ledger`, `work_time_rules` | `compute_potlek_savs`, `wtl_compute_savs_fn` |
| Jelenlét | `/jelenlet`, `/admin/jelenlet-*` | `attendance_anchors`, `attendance_events` | – |
| Kötelező ügyelet | `/admin/kotelezo-ugyelet` | `mandatory_duty_rules`, `mandatory_duty_exemptions` | `get_required_monthly_duty` |
| **Pótlás (F1)** | `/admin/potlas` | `schedule_assignments` (UPDATE) | `find_acute_replacements` |
| **Túlóra-pool (F1)** | `/admin/tulora-pool` | `overtime_orders`, `overtime_preferences` | – |
| Audit | `/audit` | `admin_audit_log` | `audit_trigger_fn` |
| Értesítések | (in-app harang) | `notifications` | `notify_*` triggerek |

## Szerver-réteg

- **Adatkliens (böngésző):** `@/integrations/supabase/client` — RLS érvényesül.
- **Authenticated server fn:** `requireSupabaseAuth` middleware. F1-ben nem kerül használatba (RLS + trigger elegendő).
- **Edge functions:** csak webhookhoz / publikus API-hoz. F1 nem hoz létre újat.

## RLS-modell

Minden user-tábla: tenant-scope + `auth.uid()`-egyezés. Admin műveletek `has_permission()` / `has_role()` ellenőrzéssel.

## Trigger-lánc

- `schedule_assignments` INSERT/UPDATE/DELETE → `audit_trigger_fn` (audit) + `notify_new_shift` (értesítés a felhasználónak).
- `duty_availability` INSERT (`tipus = szabad_vagyok`) → `notify_duty_availability_offer` (koordinátorok értesítése).
- Engedélyhez kötött státusz-átmenetek (`mandatory_duty_exemptions`, `incompatibilities`, `profile_*`): saját guard-trigger HR-permission ellenőrzéssel, audit-bejegyzéssel.

## Páciens-portál integrációs fázis (záró állapot)

| Terület | Útvonal / modul | Megjegyzés |
|---|---|---|
| Páciens 360 nézet | `/paciens-360/$patientId` | AI magyarázat panel modell/dátum/kritikus szűrőkkel |
| Beutaló / Előjegyzés | `/portal/beutalok`, `/portal/elojegyzes` | Orvos-keresőből deep-link |
| Utánkövetés | `/portal/utokovetes` | Függő kérdőívek listája `?assignment=…` deep-linkkel |
| Monitoring szabályok | `/admin/monitoring-szabalyok` | `PatientPicker` + program-választó, Zod validáció |
| Publikus elégedettségi űrlap | `POST /api/public/elegedettseg` | Foglalási kód + e-mail validáció, `supabaseAdmin` insert |
| Cron webhookok | `/api/public/hooks/*` | `Authorization: Bearer CRON_SECRET` + `timingSafeEqual` |

### Biztonsági szigorítások (RLS / RNG)

- A klinikai páciens-adat táblák (`clinical_calculator_results`, `clinical_therapy_orders`, `clinical_weekly_vc`) DELETE/UPDATE policy-jai `TO authenticated`, és `can_access_patient(patient_id)` ellenőrzésre épülnek.
- `questionnaire_assignments` SELECT csak `view_patient_data` / `manage_patients` / `assigned_by` jogosultsággal olvasható.
- `incompatibilities`, `profile_preferences`, `profile_peer_links`, `push_subscriptions`, `shift_notifications_sent`, `error_log` policy-i a `public` szerepkörről `authenticated`-re kerültek.
- `satisfaction_surveys` anon insert policy eltávolítva — minden publikus beküldés a token-validált szerveroldali végponton megy keresztül.
- Foglalási kód generálás `crypto.getRandomValues` + Crockford base32 (10 karakter, O/0/1/I/L nélkül), rejection sampling.
- Regressziós SQL: `tests/rls/portal_integration_invariants.sql` (7 invariáns); RNG Vitest: `src/__tests__/booking-code-rng.test.ts`.
