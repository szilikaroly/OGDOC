# Route-térkép (generált)

Összesen: **158** route.

## public

| Útvonal | Fájl | SSR | loader | head() |
| --- | --- | --- | --- | --- |
| `(layout)` | `src/routes/__root.tsx` | igen |  | ✓ |
| `/` | `src/routes/index.tsx` | nem |  | ✓ |
| `/auth` | `src/routes/auth.tsx` | nem |  |  |
| `/auth/callback` | `src/routes/auth.callback.tsx` | nem |  |  |
| `/blog/` | `src/routes/blog.index.tsx` | nem | ✓ | ✓ |
| `/blog/$slug` | `src/routes/blog.$slug.tsx` | nem | ✓ | ✓ |
| `/checkin` | `src/routes/checkin.tsx` | igen |  | ✓ |
| `/elegedettseg/$kod` | `src/routes/elegedettseg.$kod.tsx` | igen |  | ✓ |
| `/foglalas/` | `src/routes/foglalas.index.tsx` | igen |  | ✓ |
| `/foglalas/uj` | `src/routes/foglalas.uj.tsx` | igen |  | ✓ |
| `/foglalas/visszaigazolas/$kod` | `src/routes/foglalas.visszaigazolas.$kod.tsx` | igen |  | ✓ |
| `/hirek/` | `src/routes/hirek.index.tsx` | nem | ✓ | ✓ |
| `/hirek/$slug` | `src/routes/hirek.$slug.tsx` | nem | ✓ | ✓ |
| `/kiosk/$token` | `src/routes/kiosk.$token.tsx` | nem |  | ✓ |
| `/kiosk/$token/koszonjuk` | `src/routes/kiosk.$token.koszonjuk.tsx` | nem |  | ✓ |
| `/munkatarsak` | `src/routes/munkatarsak.tsx` | igen | ✓ | ✓ |
| `/o/$slug` | `src/routes/o.$slug.tsx` | nem | ✓ | ✓ |
| `/portal` | `src/routes/portal.tsx` | nem |  |  |
| `/portal/` | `src/routes/portal.index.tsx` | igen |  | ✓ |
| `/portal/beutalok` | `src/routes/portal.beutalok.tsx` | igen |  |  |
| `/portal/dokumentumok` | `src/routes/portal.dokumentumok.tsx` | igen |  |  |
| `/portal/egeszsegterv` | `src/routes/portal.egeszsegterv.tsx` | igen |  |  |
| `/portal/eletmod` | `src/routes/portal.eletmod.tsx` | igen |  |  |
| `/portal/elojegyzes` | `src/routes/portal.elojegyzes.tsx` | igen |  |  |
| `/portal/ertesitesek` | `src/routes/portal.ertesitesek.tsx` | igen |  |  |
| `/portal/gyogyszer-keres` | `src/routes/portal.gyogyszer-keres.tsx` | igen |  |  |
| `/portal/idopontok` | `src/routes/portal.idopontok.tsx` | igen |  |  |
| `/portal/informaciok` | `src/routes/portal.informaciok.tsx` | igen |  |  |
| `/portal/kerdoivek` | `src/routes/portal.kerdoivek.tsx` | igen |  |  |
| `/portal/leletek` | `src/routes/portal.leletek.tsx` | igen |  |  |
| `/portal/meresek` | `src/routes/portal.meresek.tsx` | igen |  |  |
| `/portal/orvos-kereso` | `src/routes/portal.orvos-kereso.tsx` | igen |  |  |
| `/portal/profil` | `src/routes/portal.profil.tsx` | igen |  |  |
| `/portal/sos` | `src/routes/portal.sos.tsx` | igen |  |  |
| `/portal/utokovetes` | `src/routes/portal.utokovetes.tsx` | igen |  |  |
| `/portal/uzenetek` | `src/routes/portal.uzenetek.tsx` | igen |  |  |
| `/portal/zarojelentes` | `src/routes/portal.zarojelentes.tsx` | igen |  |  |
| `/r/$path` | `src/routes/r.$path.tsx` | nem | ✓ |  |
| `/reset-password` | `src/routes/reset-password.tsx` | nem |  |  |
| `/share/schedule/$token` | `src/routes/share.schedule.$token.tsx` | igen |  |  |
| `/sitemap.xml` | `src/routes/sitemap[.]xml.tsx` | igen |  |  |
| `/sos/$token` | `src/routes/sos.$token.tsx` | nem |  |  |
| `/tanacsok` | `src/routes/tanacsok.tsx` | igen | ✓ | ✓ |
| `/tanacsok/$slug` | `src/routes/tanacsok.$slug.tsx` | igen | ✓ | ✓ |
| `/unauthorized` | `src/routes/unauthorized.tsx` | nem |  | ✓ |
| `/vlog/` | `src/routes/vlog.index.tsx` | nem | ✓ | ✓ |
| `/vlog/$slug` | `src/routes/vlog.$slug.tsx` | nem | ✓ | ✓ |

## authenticated

| Útvonal | Fájl | SSR | loader | head() |
| --- | --- | --- | --- | --- |
| `/_authenticated` | `src/routes/_authenticated/route.tsx` | nem |  |  |
| `/_authenticated/admin` | `src/routes/_authenticated/admin/route.tsx` | nem |  |  |
| `/_authenticated/admin/beallitasok` | `src/routes/_authenticated/admin/beallitasok.tsx` | igen |  | ✓ |
| `/_authenticated/admin/cms` | `src/routes/_authenticated/admin/cms.tsx` | nem |  |  |
| `/_authenticated/admin/cms/` | `src/routes/_authenticated/admin/cms.index.tsx` | nem |  |  |
| `/_authenticated/admin/cms/hirlevel` | `src/routes/_authenticated/admin/cms.hirlevel.tsx` | nem |  |  |
| `/_authenticated/admin/cms/jovahagyas` | `src/routes/_authenticated/admin/cms.jovahagyas.tsx` | nem |  |  |
| `/_authenticated/admin/cms/naplo` | `src/routes/_authenticated/admin/cms.naplo.tsx` | nem |  |  |
| `/_authenticated/admin/cms/visual` | `src/routes/_authenticated/admin/cms.visual.tsx` | nem |  |  |
| `/_authenticated/admin/cms/visual/` | `src/routes/_authenticated/admin/cms.visual.index.tsx` | nem |  |  |
| `/_authenticated/admin/cms/visual/legacy` | `src/routes/_authenticated/admin/cms.visual.legacy.tsx` | nem |  |  |
| `/_authenticated/admin/e2e-teszt` | `src/routes/_authenticated/admin/e2e-teszt.tsx` | igen |  |  |
| `/_authenticated/admin/email` | `src/routes/_authenticated/admin/email.tsx` | igen |  |  |
| `/_authenticated/admin/eszkalacio` | `src/routes/_authenticated/admin/eszkalacio.tsx` | igen |  |  |
| `/_authenticated/admin/eusztv` | `src/routes/_authenticated/admin/eusztv.tsx` | igen |  |  |
| `/_authenticated/admin/followup` | `src/routes/_authenticated/admin/followup.tsx` | igen |  |  |
| `/_authenticated/admin/forditasok` | `src/routes/_authenticated/admin/forditasok.tsx` | igen |  | ✓ |
| `/_authenticated/admin/hibanaplo` | `src/routes/_authenticated/admin/hibanaplo.tsx` | igen |  | ✓ |
| `/_authenticated/admin/jelenlet-anomaliak` | `src/routes/_authenticated/admin/jelenlet-anomaliak.tsx` | igen |  |  |
| `/_authenticated/admin/jelenlet-horgonyok` | `src/routes/_authenticated/admin/jelenlet-horgonyok.tsx` | igen |  |  |
| `/_authenticated/admin/jogosultsagok` | `src/routes/_authenticated/admin/jogosultsagok.tsx` | igen |  |  |
| `/_authenticated/admin/kerdoiv-emlekeztetok` | `src/routes/_authenticated/admin/kerdoiv-emlekeztetok.tsx` | igen |  |  |
| `/_authenticated/admin/kotelezo-ugyelet` | `src/routes/_authenticated/admin/kotelezo-ugyelet.tsx` | igen |  |  |
| `/_authenticated/admin/landing` | `src/routes/_authenticated/admin/landing.tsx` | igen |  | ✓ |
| `/_authenticated/admin/letszam-igeny` | `src/routes/_authenticated/admin/letszam-igeny.tsx` | igen |  |  |
| `/_authenticated/admin/monitoring-szabalyok` | `src/routes/_authenticated/admin/monitoring-szabalyok.tsx` | igen |  |  |
| `/_authenticated/admin/munkaido-szabalyok` | `src/routes/_authenticated/admin/munkaido-szabalyok.tsx` | igen |  |  |
| `/_authenticated/admin/mutet-szabalyok` | `src/routes/_authenticated/admin/mutet-szabalyok.tsx` | igen |  | ✓ |
| `/_authenticated/admin/paciens-kerelmek` | `src/routes/_authenticated/admin/paciens-kerelmek.tsx` | igen |  |  |
| `/_authenticated/admin/portal-analitika` | `src/routes/_authenticated/admin/portal-analitika.tsx` | igen |  | ✓ |
| `/_authenticated/admin/potlas` | `src/routes/_authenticated/admin/potlas.tsx` | igen |  |  |
| `/_authenticated/admin/szabadsag-felugyelet` | `src/routes/_authenticated/admin/szabadsag-felugyelet.tsx` | igen |  |  |
| `/_authenticated/admin/szabadsag-szabalyzat` | `src/routes/_authenticated/admin/szabadsag-szabalyzat.tsx` | igen |  |  |
| `/_authenticated/admin/szerepkorok` | `src/routes/_authenticated/admin/szerepkorok.tsx` | igen |  |  |
| `/_authenticated/admin/szervezet` | `src/routes/_authenticated/admin/szervezet.tsx` | igen |  |  |
| `/_authenticated/admin/szervezet-sugo` | `src/routes/_authenticated/admin/szervezet-sugo.tsx` | igen |  |  |
| `/_authenticated/admin/tulora-pool` | `src/routes/_authenticated/admin/tulora-pool.tsx` | igen |  |  |
| `/_authenticated/audit` | `src/routes/_authenticated/audit.tsx` | igen |  |  |
| `/_authenticated/beosztas` | `src/routes/_authenticated/beosztas.tsx` | igen |  |  |
| `/_authenticated/csapat` | `src/routes/_authenticated/csapat.tsx` | igen |  |  |
| `/_authenticated/csapat-mutatok` | `src/routes/_authenticated/csapat-mutatok.tsx` | igen |  |  |
| `/_authenticated/dashboard` | `src/routes/_authenticated/dashboard.tsx` | igen |  |  |
| `/_authenticated/elegedettseg` | `src/routes/_authenticated/elegedettseg.tsx` | igen |  | ✓ |
| `/_authenticated/fiok` | `src/routes/_authenticated/fiok.tsx` | igen |  |  |
| `/_authenticated/idopontok/` | `src/routes/_authenticated/idopontok.index.tsx` | igen |  | ✓ |
| `/_authenticated/idopontok/sablonok` | `src/routes/_authenticated/idopontok.sablonok.tsx` | igen |  | ✓ |
| `/_authenticated/iranyitopult` | `src/routes/_authenticated/iranyitopult.tsx` | nem |  |  |
| `/_authenticated/jelenlet` | `src/routes/_authenticated/jelenlet.tsx` | igen |  |  |
| `/_authenticated/karakterlap` | `src/routes/_authenticated/karakterlap.tsx` | igen |  |  |
| `/_authenticated/kepzes` | `src/routes/_authenticated/kepzes.tsx` | igen |  |  |
| `/_authenticated/kerdoivek/` | `src/routes/_authenticated/kerdoivek.index.tsx` | igen |  | ✓ |
| `/_authenticated/kerdoivek/attekintes` | `src/routes/_authenticated/kerdoivek.attekintes.tsx` | igen |  |  |
| `/_authenticated/kerdoivek/recepcio` | `src/routes/_authenticated/kerdoivek.recepcio.tsx` | igen |  |  |
| `/_authenticated/kerdoivek/riasztasok` | `src/routes/_authenticated/kerdoivek.riasztasok.tsx` | igen |  | ✓ |
| `/_authenticated/kerdoivek/varo` | `src/routes/_authenticated/kerdoivek.varo.tsx` | igen |  | ✓ |
| `/_authenticated/klinika` | `src/routes/_authenticated/klinika.tsx` | igen |  |  |
| `/_authenticated/klinika/` | `src/routes/_authenticated/klinika.index.tsx` | igen |  |  |
| `/_authenticated/klinika/beteg/$patientId` | `src/routes/_authenticated/klinika.beteg.$patientId.tsx` | igen |  | ✓ |
| `/_authenticated/klinika/eszkozok/` | `src/routes/_authenticated/klinika.eszkozok.index.tsx` | igen |  |  |
| `/_authenticated/klinika/eszkozok/diab` | `src/routes/_authenticated/klinika.eszkozok.diab.tsx` | igen |  |  |
| `/_authenticated/klinika/eszkozok/embolia` | `src/routes/_authenticated/klinika.eszkozok.embolia.tsx` | igen |  |  |
| `/_authenticated/klinika/eszkozok/kardio` | `src/routes/_authenticated/klinika.eszkozok.kardio.tsx` | igen |  |  |
| `/_authenticated/klinika/eszkozok/szepszis` | `src/routes/_authenticated/klinika.eszkozok.szepszis.tsx` | igen |  |  |
| `/_authenticated/klinika/eszkozok/szules` | `src/routes/_authenticated/klinika.eszkozok.szules.tsx` | igen |  |  |
| `/_authenticated/klinika/eszkozok/t2dm` | `src/routes/_authenticated/klinika.eszkozok.t2dm.tsx` | igen |  |  |
| `/_authenticated/klinika/eszkozok/vergaz` | `src/routes/_authenticated/klinika.eszkozok.vergaz.tsx` | igen |  |  |
| `/_authenticated/klinika/eszkozok/vese` | `src/routes/_authenticated/klinika.eszkozok.vese.tsx` | igen |  |  |
| `/_authenticated/klinika/lazlap/$encounterId` | `src/routes/_authenticated/klinika.lazlap.$encounterId.tsx` | igen |  |  |
| `/_authenticated/klinika/partogram/$encounterId` | `src/routes/_authenticated/klinika.partogram.$encounterId.tsx` | igen |  |  |
| `/_authenticated/munkaido` | `src/routes/_authenticated/munkaido.tsx` | igen |  |  |
| `/_authenticated/muteti-terv` | `src/routes/_authenticated/muteti-terv.tsx` | igen |  |  |
| `/_authenticated/muteti-terv/` | `src/routes/_authenticated/muteti-terv.index.tsx` | igen |  |  |
| `/_authenticated/muteti-terv/blokkok` | `src/routes/_authenticated/muteti-terv.blokkok.tsx` | igen |  | ✓ |
| `/_authenticated/muteti-terv/varolista` | `src/routes/_authenticated/muteti-terv.varolista.tsx` | igen |  | ✓ |
| `/_authenticated/paciens-360/$patientId` | `src/routes/_authenticated/paciens-360.$patientId.tsx` | igen |  |  |
| `/_authenticated/paciensek` | `src/routes/_authenticated/paciensek.tsx` | igen |  |  |
| `/_authenticated/portal/tanacsok` | `src/routes/_authenticated/portal.tanacsok.tsx` | igen |  |  |
| `/_authenticated/szabadsag` | `src/routes/_authenticated/szabadsag.tsx` | igen |  |  |
| `/_authenticated/uzenetek` | `src/routes/_authenticated/uzenetek.tsx` | igen |  |  |
| `/_authenticated/uzenetek/` | `src/routes/_authenticated/uzenetek.index.tsx` | igen |  |  |
| `/_authenticated/uzenetek/$conversationId` | `src/routes/_authenticated/uzenetek.$conversationId.tsx` | igen |  |  |
| `/_authenticated/uzenetek/uj` | `src/routes/_authenticated/uzenetek.uj.tsx` | igen |  |  |
| `/_authenticated/vezeto/keresek` | `src/routes/_authenticated/vezeto.keresek.tsx` | igen |  | ✓ |
| `/_authenticated/visszajelzesek` | `src/routes/_authenticated/visszajelzesek.tsx` | igen |  |  |

## api

| Útvonal | Fájl | SSR | loader | head() |
| --- | --- | --- | --- | --- |
| `/api/chat` | `src/routes/api/chat.ts` | igen |  |  |
| `/api/dictate` | `src/routes/api/dictate.ts` | igen |  |  |
| `/api/public/booking/book` | `src/routes/api/public/booking/book.ts` | igen |  |  |
| `/api/public/booking/cancel` | `src/routes/api/public/booking/cancel.ts` | igen |  |  |
| `/api/public/booking/checkin` | `src/routes/api/public/booking/checkin.ts` | igen |  | ✓ |
| `/api/public/booking/lookup` | `src/routes/api/public/booking/lookup.ts` | igen |  |  |
| `/api/public/booking/slots` | `src/routes/api/public/booking/slots.ts` | igen |  |  |
| `/api/public/cron/weekly-summary` | `src/routes/api/public/cron/weekly-summary.ts` | igen |  | ✓ |
| `/api/public/eeszt-sync` | `src/routes/api/public/eeszt-sync.ts` | igen |  |  |
| `/api/public/elegedettseg` | `src/routes/api/public/elegedettseg.ts` | igen |  |  |
| `/api/public/experiments/track` | `src/routes/api/public/experiments/track.ts` | igen |  |  |
| `/api/public/hooks/escalate-alerts` | `src/routes/api/public/hooks/escalate-alerts.ts` | igen |  |  |
| `/api/public/hooks/questionnaire-cron` | `src/routes/api/public/hooks/questionnaire-cron.ts` | igen |  |  |
| `/api/public/hooks/schedule-notify` | `src/routes/api/public/hooks/schedule-notify.ts` | igen |  |  |
| `/api/public/hooks/shift-reminders` | `src/routes/api/public/hooks/shift-reminders.ts` | igen |  |  |
| `/api/public/hooks/weekly-digest` | `src/routes/api/public/hooks/weekly-digest.ts` | igen |  |  |
| `/api/public/og/$slug` | `src/routes/api/public/og/$slug.ts` | igen |  |  |
| `/api/public/schedule/$token` | `src/routes/api/public/schedule.$token.ts` | igen |  |  |
| `/api/public/sitemap` | `src/routes/api/public/sitemap.ts` | igen |  |  |
| `/api/public/sitemap-blog` | `src/routes/api/public/sitemap-blog.ts` | igen |  |  |
| `/api/public/sitemap-hirek` | `src/routes/api/public/sitemap-hirek.ts` | igen |  |  |
| `/api/public/sitemap-news` | `src/routes/api/public/sitemap-news.ts` | igen |  |  |
| `/api/public/sitemap-pages` | `src/routes/api/public/sitemap-pages.ts` | igen |  |  |
| `/api/public/sitemap-staff` | `src/routes/api/public/sitemap-staff.ts` | igen |  |  |
| `/api/public/sitemap-tips` | `src/routes/api/public/sitemap-tips.ts` | igen |  |  |
| `/api/public/sitemap-vlog` | `src/routes/api/public/sitemap-vlog.ts` | igen |  |  |
| `/api/push/test` | `src/routes/api/push/test.ts` | igen |  |  |
