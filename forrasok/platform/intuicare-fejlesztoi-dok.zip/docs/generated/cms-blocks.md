# CMS blokk-katalógus (generált)

| type | Címke | Kategória |
| --- | --- | --- |
| `klinika_top_bar` | Felső sáv | klinika |
| `klinika_site_header` | Egyetemi fejléc | klinika |
| `klinika_main_nav` | Fő navigáció | klinika |
| `klinika_hero` | Hero kép + cím | hero |
| `klinika_intro_grid` | 3 oszlopos bemutató | content |
| `klinika_stats` | Statisztika sáv | content |
| `klinika_icon_grid` | Ikon-rács (sötét) | content |
| `klinika_schedule_table` | Rendelési idők | content |
| `klinika_team` | Csapat rács | list |
| `klinika_3col_features` | 3 oszlopos kiemelés | content |
| `klinika_news` | Hírek (kézi) | list |
| `klinika_logo_grid` | Projekt-logó rács | list |
| `klinika_jobs` | Álláslehetőségek | cta |
| `klinika_links_grid` | Hasznos linkek | list |
| `klinika_faq` | GYIK | content |
| `klinika_contact` | Kapcsolat + térkép | content |
| `klinika_footer` | Lábléc (4 oszlop) | klinika |
| `rich_text` | Szöveg (rich) | content |
| `image_text` | Kép + szöveg | content |
| `cta_band` | CTA sáv | cta |
| `embed_html` | Egyedi HTML | media |
| `divider` | Elválasztó | layout |
| `nav_menu` | Menü (cms_menus) | layout |
| `dyn_doctor_card` | Orvos kártya (élő) | content |
| `dyn_faq` | GYIK (élő, tag-szűrt) | content |
| `dyn_contact_form` | Kapcsolatfelvétel űrlap | cta |
| `dyn_doctor_schedule` | Orvos szabad időpontok (élő) | content |
| `dyn_booking_widget` | Foglalási widget (élő) | cta |
| `dyn_staff_grid` | Munkatársak (élő) | list |
| `dyn_news_list` | Hírek lista (élő) | list |
| `dyn_tips_list` | Tanácsok lista (élő) | list |
| `dyn_news_hero` | Hír fejléc (élő) | hero |
| `dyn_news_related` | Kapcsolódó hírek (élő) | list |
| `dyn_share_bar` | Megosztó sáv | cta |
