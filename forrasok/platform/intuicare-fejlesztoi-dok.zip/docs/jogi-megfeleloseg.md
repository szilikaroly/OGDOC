# MedRoster — Jogi megfelelőség térkép

> Melyik kódrész / tábla / trigger implementálja a magyar munkajog mely §-át.

## Munkaidő (mindkét jogviszony)

| § | Forrás | Implementáció |
|---|---|---|
| Mt. 134. § (munkaidő-nyilvántartás) | Mt. 2012. évi I. tv. | `work_time_ledger` tábla + `wtl_compute_savs_fn` trigger |
| Mt. 140–143. § (vasárnapi, éjszakai, túlóra pótlék) | Mt. | `compute_potlek_savs()` RPC + `wage_mapping` |
| Eütev. 12/A–12/G. § (heti 48/60/72, napi 12/24, 416 h, 11 h pihenő) | Eütev. 2003. évi LXXXIV. tv. | `work_time_rules` konfig + beosztómotor kemény constraint |
| Eütev. 12/B. § (ÖVT önkéntessége) | Eütev. | `opt_out_agreements` + `opt_out_revocation_guard` (12 hónap) |
| Eütev. 13/A. § (ügyeleti díj) | Eütev. | `wage_codes` UGYELET_MN/PN/MSZ |
| Eütev. 14. § (készenléti díj) | Eütev. | `wage_codes` KESZENLET |

## Állami fenntartó (Eszjtv. + 528/2020)

| § | Forrás | Implementáció |
|---|---|---|
| Eszjtv. 1. § (hatály) | 2020. évi C. tv. | `tenants.fenntarto_tipus` szerinti szabálykészlet-váltás (jövőbeli F4) |
| 528/2020 16. § (rendkívüli munka írásban) | 528/2020. Korm. r. | **F1**: `overtime_orders.irasos_hivatkozas` mező |
| 528/2020 (havi max 14 ügyelet+készenlét, 10 készenlét, 250 ó rendkívüli) | 528/2020 | `work_time_rules` + ledger-view (`v_havi_alkalmak`) |

## GDPR / Eüak

| § | Forrás | Implementáció |
|---|---|---|
| GDPR Art. 9 (különleges adat) | EU 2016/679 | RLS minden `profile_*` táblán; `gdpr_consents` (F6) |
| GDPR Art. 20 (hordozhatóság) | EU 2016/679 | F6: data-export server fn |
| Eüak 1997. évi XLVII. tv. | – | RLS + audit + EU-régió hosting |

## Kötelező ügyelet és mentesség

| § | Forrás | Implementáció |
|---|---|---|
| Kötelező részvétel + indokolt mentesítés | Eütev. 12/D. § | `mandatory_duty_rules` + `mandatory_duty_exemptions` + `mandatory_duty_exemption_guard` (HR-jóváhagyás) |

## Felügyelet (képzés)

| § | Forrás | Implementáció |
|---|---|---|
| 22/2012 EMMI (akkreditált tutor) | 22/2012 EMMI r. | `person_accreditations` + `supervises()` RPC (F4-ben kötelező constraint) |
