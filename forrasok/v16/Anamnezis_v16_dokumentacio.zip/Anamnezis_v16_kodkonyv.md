# Anamnézis-asszisztens v16 — kódkönyv

A teljes forrás, rétegenként tagolva. Generálva: 2026-09-01.

Forrás: `Anamnezis_asszisztens_v16_tobbnyelvu.html` — 3901 sor, 1088 KB, 15 script-blokk.

> **A HTML a build kimenete.** Módosítani a `build/` alatti szkripteket kell, majd a láncot
> újrafuttatni a v15-ből. A kézi javítást a következő build csendben visszaírja.
> A build-szkriptek teljes forrása a dokumentum végén.

A beágyazott törzsadat-tömbök (EESZT, PUPHA) sorai 2000 karakternél csonkolva — ezek adatok,
nem kód, és a nyers fájlban változatlanul megvannak.

## Tartalom

1. [Dokumentumfej és stílus](#1-dokumentumfej-és-stílus)
2. [Űrlap-markup](#2-űrlap-markup)
3. [Rétegek](#3-rétegek)
   - [dictation — Beszédfelismerés (Web Speech API), offline; hosztolt Whisper-kampó](#dictation-543585)
   - [mag + v2 — Űrlap, állapot, generate(), teendőmotor; műtétek, szupplementáció, labor, PUPHA, kockázat](#mag--v2-5891529)
   - [v3 + v4 + v6 — Kalkulátorok, esetmentés, export; EESZT rizikótényezők; enrich](#v3--v4--v6-15311615)
   - [v7 — Kiegészítő kampó](#v7-16171642)
   - [v8 — Kiegészítő kampó](#v8-16441680)
   - [v9 — Narratíva, GA-időzítés, PHQ-2, aktív allergia](#v9-16821926)
   - [v12 — Automatikus és beágyazott külső kalkulátorok](#v12-19282138)
   - [v13 — Kibővített natív kalkulátorok](#v13-21402388)
   - [EESZT adat — Beágyazott kódtörzsek (ATC, BNO, OENO, FEOR, irányítószám, ország)](#eeszt-adat-23902390)
   - [v15 — EESZT törzsek, BNO minden mezőre, teendő-indoklás, betegtájékoztató](#v15-23912556)
   - [i18n — Futásidejű fordítóréteg, 316 kulcs, 6 nyelv](#i18n-25572663)
   - [v16/2 — Dinamikus családfa (pedigré)](#v162-26652928)
   - [v16/3 — Kalkulátor-bemenetek áthelyezése](#v163-29303044)
   - [v16/4 — Ultrahang-modul](#v164-30463512)
   - [v16/6 — EKG-modul, 296 munkafüzet-képlet](#v166-35143899)
4. [Build-lánc forrása](#4-build-lánc-forrása)

---

## 1. Dokumentumfej és stílus

Sorok 1–277: `<head>`, a teljes beágyazott CSS, a fejléc és az útvonalválasztó.

```html
<meta charset="utf-8">
<title>Anamnézis-asszisztens — AI-asszisztált betegfelvétel</title>
<style>
  :root{
    --bg:#eaeff1; --surface:#ffffff; --surface-2:#f4f8f9; --ink:#15212a; --muted:#5a6a72;
    --line:#d6dfe3; --line-strong:#c2ced3;
    --accent:#0e7c74; --accent-ink:#0a5a54; --accent-soft:#e2f1ef;
    --ok:#2e7d5b; --ok-bg:#e7f3ec; --warn:#9a6410; --warn-bg:#fbf1dc; --crit:#b23a2e; --crit-bg:#fbe8e5;
    --shadow:0 1px 2px rgba(20,40,50,.06),0 8px 24px rgba(20,40,50,.06);
    --radius:10px; --mono:ui-monospace,"SF Mono",Menlo,Consolas,"Liberation Mono",monospace;
    --sans:system-ui,-apple-system,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;
  }
  @media (prefers-color-scheme:dark){
    :root{
      --bg:#0d1316; --surface:#141d21; --surface-2:#0f1a1e; --ink:#e6eef0; --muted:#9db0b6;
      --line:#233238; --line-strong:#2f424a;
      --accent:#3fb6ab; --accent-ink:#8fded6; --accent-soft:#123029;
      --ok:#5fce9a; --ok-bg:#122820; --warn:#e0b25e; --warn-bg:#2a2213; --crit:#e88b7f; --crit-bg:#2a1512;
      --shadow:0 1px 2px rgba(0,0,0,.4),0 10px 30px rgba(0,0,0,.35);
    }
  }
  :root[data-theme="light"]{
    --bg:#eaeff1; --surface:#ffffff; --surface-2:#f4f8f9; --ink:#15212a; --muted:#5a6a72;
    --line:#d6dfe3; --line-strong:#c2ced3; --accent:#0e7c74; --accent-ink:#0a5a54; --accent-soft:#e2f1ef;
    --ok:#2e7d5b; --ok-bg:#e7f3ec; --warn:#9a6410; --warn-bg:#fbf1dc; --crit:#b23a2e; --crit-bg:#fbe8e5;
    --shadow:0 1px 2px rgba(20,40,50,.06),0 8px 24px rgba(20,40,50,.06);
  }
  :root[data-theme="dark"]{
    --bg:#0d1316; --surface:#141d21; --surface-2:#0f1a1e; --ink:#e6eef0; --muted:#9db0b6;
    --line:#233238; --line-strong:#2f424a; --accent:#3fb6ab; --accent-ink:#8fded6; --accent-soft:#123029;
    --ok:#5fce9a; --ok-bg:#122820; --warn:#e0b25e; --warn-bg:#2a2213; --crit:#e88b7f; --crit-bg:#2a1512;
    --shadow:0 1px 2px rgba(0,0,0,.4),0 10px 30px rgba(0,0,0,.35);
  }
  *{box-sizing:border-box}
  html{scroll-behavior:smooth}
  body{margin:0;background:var(--bg);color:var(--ink);font-family:var(--sans);font-size:14px;line-height:1.5;-webkit-font-smoothing:antialiased}
  h1,h2,h3{margin:0;font-weight:650;text-wrap:balance}
  button{font-family:inherit;cursor:pointer}
  input,select,textarea{font-family:inherit;font-size:14px;color:var(--ink)}
  a{color:var(--accent-ink)}

  /* top bar */
  .top{position:sticky;top:0;z-index:20;background:color-mix(in srgb,var(--surface) 88%,transparent);
    backdrop-filter:saturate(1.2) blur(8px);border-bottom:1px solid var(--line);}
  .top-in{max-width:1400px;margin:0 auto;padding:10px 18px;display:flex;align-items:center;gap:16px;flex-wrap:wrap}
  .brand{display:flex;flex-direction:column;line-height:1.15}
  .brand b{font-size:15px;letter-spacing:.2px}
  .brand span{font-size:11px;color:var(--muted)}
  .seg{display:flex;background:var(--surface-2);border:1px solid var(--line);border-radius:8px;padding:3px;gap:2px}
  .seg button{border:0;background:transparent;color:var(--muted);padding:6px 12px;border-radius:6px;font-size:12.5px;font-weight:600}
  .seg button[aria-pressed="true"]{background:var(--accent);color:#fff}
  :root[data-theme="dark"] .seg button[aria-pressed="true"]{color:#04110f}
  .grow{flex:1}
  .pill{display:inline-flex;align-items:center;gap:6px;font-size:11px;color:var(--muted);border:1px solid var(--line);border-radius:999px;padding:4px 10px}
  .dot{width:7px;height:7px;border-radius:50%;background:var(--ok)}
  .icon-btn{border:1px solid var(--line);background:var(--surface);color:var(--ink);border-radius:8px;padding:7px 10px;font-size:12.5px;font-weight:600}
  .icon-btn:hover{border-color:var(--line-strong)}

  /* layout */
  .wrap{max-width:1400px;margin:0 auto;padding:18px;display:grid;grid-template-columns:1fr 1fr;gap:18px;align-items:start}
  @media (max-width:980px){.wrap{grid-template-columns:1fr}}
  .col-out{position:sticky;top:70px}
  @media (max-width:980px){.col-out{position:static}}

  .card{background:var(--surface);border:1px solid var(--line);border-radius:var(--radius);box-shadow:var(--shadow)}
  .sec{border:1px solid var(--line);border-radius:var(--radius);background:var(--surface);margin-bottom:14px;overflow:hidden}
  .sec>summary{list-style:none;cursor:pointer;padding:12px 15px;display:flex;align-items:center;gap:10px;font-weight:650;font-size:13.5px;
    background:var(--surface-2);border-bottom:1px solid transparent}
  .sec[open]>summary{border-bottom:1px solid var(--line)}
  .sec>summary::-webkit-details-marker{display:none}
  .sec>summary .chev{margin-left:auto;color:var(--muted);transition:transform .18s}
  .sec[open]>summary .chev{transform:rotate(90deg)}
  .sec .body{padding:14px 15px}
  .num{font-variant-numeric:tabular-nums;font-family:var(--mono);font-size:11px;color:var(--accent-ink);
    background:var(--accent-soft);border-radius:6px;padding:2px 7px;font-weight:700}

  .grid{display:grid;gap:12px}
  .g2{grid-template-columns:1fr 1fr}
  .g3{grid-template-columns:1fr 1fr 1fr}
  @media (max-width:560px){.g2,.g3{grid-template-columns:1fr}}
  label.fld{display:flex;flex-direction:column;gap:4px;font-size:12px;color:var(--muted);font-weight:600}
  .fld input,.fld select,textarea{width:100%;background:var(--surface-2);border:1px solid var(--line);border-radius:8px;padding:8px 10px;color:var(--ink)}
  .fld input:focus,.fld select:focus,textarea:focus,.chip:focus-visible,button:focus-visible{outline:2px solid var(--accent);outline-offset:1px}
  textarea{resize:vertical;min-height:66px;line-height:1.5}
  .hint{font-size:11px;color:var(--muted);font-weight:500}

  /* ROS three-state rows */
  .rosgrp{margin-bottom:10px}
  .rosgrp .gh{display:flex;align-items:center;gap:8px;margin:2px 0 8px}
  .rosgrp .gh b{font-size:12px;letter-spacing:.03em;text-transform:uppercase;color:var(--muted)}
  .allneg{margin-left:auto;border:1px solid var(--line);background:var(--surface);color:var(--muted);border-radius:6px;font-size:11px;padding:3px 8px;font-weight:600}
  .ros{display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px dashed var(--line)}
  .ros:last-child{border-bottom:0}
  .ros .lb{flex:1;font-size:13px}
  .ros .rf{font-size:9.5px;font-weight:800;color:var(--crit);border:1px solid var(--crit);border-radius:4px;padding:1px 4px;letter-spacing:.03em}
  .yn{display:flex;border:1px solid var(--line);border-radius:7px;overflow:hidden}
  .yn button{border:0;background:var(--surface-2);color:var(--muted);padding:5px 11px;font-size:12px;font-weight:700}
  .yn button.no[aria-pressed="true"]{background:var(--ok);color:#fff}
  .yn button.yes[aria-pressed="true"]{background:var(--crit);color:#fff}
  :root[data-theme="dark"] .yn button.no[aria-pressed="true"],:root[data-theme="dark"] .yn button.yes[aria-pressed="true"]{color:#0b1410}
  .ros .det{flex-basis:100%;margin-top:6px;display:none}
  .ros.on .det{display:block}
  .ros .det input{width:100%;background:var(--surface-2);border:1px solid var(--line);border-radius:7px;padding:6px 9px}

  .chips{display:flex;flex-wrap:wrap;gap:7px}
  .chip{border:1px solid var(--line);background:var(--surface-2);color:var(--ink);border-radius:999px;padding:6px 12px;font-size:12.5px;font-weight:600}
  .chip:hover{border-color:var(--accent)}

  /* meds */
  .medrow{display:flex;gap:8px;align-items:flex-start;margin-bottom:8px}
  .medrow input{flex:1}
  .medrow .del{border:1px solid var(--line);background:var(--surface);color:var(--muted);border-radius:8px;padding:8px 11px;font-weight:700}
  .flagline{font-size:11.5px;margin-top:4px;padding:6px 9px;border-radius:7px;font-weight:600;display:flex;gap:7px;align-items:flex-start}
  .flag-crit{background:var(--crit-bg);color:var(--crit)}
  .flag-warn{background:var(--warn-bg);color:var(--warn)}
  .flag-info{background:var(--accent-soft);color:var(--accent-ink)}

  /* output */
  .out-head{display:flex;align-items:center;gap:10px;padding:11px 14px;border-bottom:1px solid var(--line);background:var(--surface-2);border-radius:var(--radius) var(--radius) 0 0}
  .out-head h3{font-size:13.5px}
  .out-actions{margin-left:auto;display:flex;gap:7px}
  .btn{border:1px solid var(--line);background:var(--surface);color:var(--ink);border-radius:8px;padding:7px 12px;font-size:12.5px;font-weight:650}
  .btn.primary{background:var(--accent);border-color:var(--accent);color:#fff}
  :root[data-theme="dark"] .btn.primary{color:#04110f}
  .btn:hover{filter:brightness(.98)}
  pre.rec{margin:0;padding:14px;font-family:var(--mono);font-size:12px;line-height:1.55;white-space:pre-wrap;word-break:break-word;max-height:46vh;overflow:auto;color:var(--ink)}

  .todo{padding:12px 14px;max-height:52vh;overflow:auto}
  .tcat{margin-bottom:12px}
  .tcat h4{font-size:11px;letter-spacing:.05em;text-transform:uppercase;color:var(--muted);margin:0 0 6px;display:flex;align-items:center;gap:8px}
  .tcat h4 .cnt{font-family:var(--mono);font-size:10px;background:var(--surface-2);border:1px solid var(--line);border-radius:5px;padding:1px 6px}
  .titem{display:flex;gap:9px;align-items:flex-start;padding:7px 9px;border:1px solid var(--line);border-left-width:3px;border-radius:8px;margin-bottom:6px;background:var(--surface-2)}
  .titem.s-crit{border-left-color:var(--crit)}
  .titem.s-warn{border-left-color:var(--warn)}
  .titem.s-info{border-left-color:var(--accent)}
  .titem .tx{flex:1;font-size:12.5px}
  .titem .src{display:block;font-size:10.5px;color:var(--muted);margin-top:2px}
  .empty{color:var(--muted);font-size:12.5px;padding:8px}
  .toast{position:fixed;bottom:18px;left:50%;transform:translateX(-50%) translateY(20px);background:var(--ink);color:var(--bg);
    padding:9px 16px;border-radius:8px;font-size:13px;font-weight:600;opacity:0;transition:.25s;pointer-events:none;z-index:50}
  .toast.show{opacity:1;transform:translateX(-50%) translateY(0)}
  .legal{font-size:11px;color:var(--muted);padding:10px 14px;border-top:1px solid var(--line);line-height:1.5}
  @media (prefers-reduced-motion:reduce){*{transition:none!important;animation:none!important}}

  /* v3 toolbar / calculators / print */
  .toolbar{position:sticky;top:0;z-index:18;background:var(--surface-2);border-bottom:1px solid var(--line)}
  .tb-in{max-width:1400px;margin:0 auto;padding:6px 18px;display:flex;gap:8px;align-items:center;flex-wrap:wrap}
  .tbbtn{border:1px solid var(--line);background:var(--surface);color:var(--ink);border-radius:8px;padding:6px 11px;font-size:12.5px;font-weight:600}
  .tbbtn:hover{border-color:var(--accent)}
  .tbgrow{flex:1}
  .casepanel{max-width:1400px;margin:0 auto;padding:8px 18px;display:flex;flex-direction:column;gap:6px;border-top:1px dashed var(--line)}
  .caseitem{display:flex;gap:8px;align-items:center;font-size:12.5px;padding:5px 8px;border:1px solid var(--line);border-radius:8px;background:var(--surface)}
  .caseitem b{flex:1}
  .calcrow{border:1px solid var(--line);border-left:3px solid var(--accent);border-radius:8px;padding:8px 10px;margin-bottom:7px;background:var(--surface-2)}
  .calcrow h5{margin:0 0 5px;font-size:12.5px}
  .calcrow .cin{display:flex;flex-wrap:wrap;gap:6px 10px;margin-bottom:5px;align-items:center}
  .calcrow .cin label{font-size:11px;color:var(--muted);display:flex;gap:4px;align-items:center}
  .calcrow .cin input,.calcrow .cin select{background:var(--surface);border:1px solid var(--line);border-radius:6px;padding:4px 7px;font-size:12px;color:var(--ink)}
  .calcrow .cres{font-size:12.5px;font-weight:700;color:var(--accent-ink)}
  @media print{
    .top,.toolbar,.col-form,.out-actions,.pill{display:none!important}
    .wrap{display:block!important;max-width:100%!important}
    .col-out{position:static!important}
    .card{break-inside:avoid;box-shadow:none;border:1px solid #bbb;margin-bottom:10px}
    body{background:#fff}
    pre.rec{max-height:none!important}
    .todo{max-height:none!important}
  }

/* --- v16 --- */
#ekgWrap{display:flex;flex-direction:column;gap:12px}
.ekgset{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:8px}
.ekgset label{display:flex;flex-direction:column;font-size:.75rem;gap:3px}
.ekgset input,.ekgset select{padding:5px;border-radius:6px;border:1px solid var(--bd,#d9dde3);background:transparent;color:inherit;font:inherit}
.ekgtblwrap{overflow-x:auto;border:1px solid var(--bd,#d9dde3);border-radius:10px}
.ekgtbl{border-collapse:collapse;font-size:.72rem;min-width:900px}
.ekgtbl th,.ekgtbl td{border:1px solid var(--bd,#e2e6ec);padding:2px 4px;text-align:center}
.ekgtbl th{font-weight:600;opacity:.8;position:sticky;top:0;background:var(--bg,#fff)}
.ekgtbl td:first-child,.ekgtbl th:first-child{text-align:left;font-weight:600;position:sticky;left:0;background:var(--bg,#fff)}
.ekgtbl input{width:52px;padding:2px 3px;border:1px solid transparent;border-radius:4px;background:transparent;color:inherit;font:inherit;text-align:right}
.ekgtbl input:focus{border-color:#2d6cdf;outline:none}
.ekgtbl select{padding:1px;border:1px solid transparent;border-radius:4px;background:transparent;color:inherit;font:inherit;font-size:.7rem}
.ekgtbl td.abn input,.ekgtbl td.abn select{background:rgba(192,57,43,.10);border-color:#c0392b}
.ekgtbl td.susp input{background:rgba(138,109,59,.12);border-color:#8a6d3b}
.ekgout{border:1px solid var(--bd,#d9dde3);border-radius:10px;padding:10px;font-size:.78rem;line-height:1.55;white-space:pre-wrap}
.ekgout b{display:inline-block;min-width:78px}
.ekgcrit{color:#c0392b;font-weight:700}
.ekgnote{font-size:.72rem;opacity:.75;line-height:1.5;margin:0 0 8px}
.ekgblk{margin-top:8px;padding:8px 10px;border-left:3px solid #8a6d3b;background:rgba(138,109,59,.08);border-radius:0 8px 8px 0;font-size:.75rem}

#usWrap{display:flex;flex-direction:column;gap:12px}
.usbtns{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:4px}
.usbtns button{border:1px dashed var(--bd,#9aa3ad);background:transparent;color:inherit;border-radius:8px;padding:6px 11px;cursor:pointer;font:inherit;font-size:.8rem}
.usbtns button.pri{border-style:solid;border-color:#2d6cdf;color:#2d6cdf;font-weight:600}
.usvisit{border:1px solid var(--bd,#d9dde3);border-radius:10px;padding:10px}
.usvhead{display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:8px}
.usvhead b{font-size:.85rem}
.usgrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:8px}
.usgrid label{display:flex;flex-direction:column;font-size:.75rem;gap:3px}
.usgrid input{padding:5px;border-radius:6px;border:1px solid var(--bd,#d9dde3);background:transparent;color:inherit;font:inherit}
.usgrid input.p10{border-color:#c0392b;background:rgba(192,57,43,.06)}
.usgrid input.p90{border-color:#8a6d3b;background:rgba(138,109,59,.08)}
.usgh{grid-column:1/-1;font-size:.72rem;font-weight:700;opacity:.7;text-transform:uppercase;letter-spacing:.03em;margin-top:6px}
.uspct{font-size:.68rem;opacity:.75}
.uspct.bad{color:#c0392b;font-weight:700;opacity:1}
.uspct.warnp{color:#8a6d3b;font-weight:600;opacity:1}
.uschart{border:1px solid var(--bd,#d9dde3);border-radius:10px;padding:8px;margin-bottom:10px;overflow-x:auto}
.uschart h6{margin:0 0 4px;font-size:.8rem}
.uschart .src{font-size:.68rem;opacity:.7;margin-bottom:4px}
.usnormrow{display:flex;flex-wrap:wrap;gap:6px;align-items:center;font-size:.75rem;padding:5px 0;border-bottom:1px solid var(--bd,#e6e9ee)}
.usnormrow b{min-width:90px}
.ustbl{width:100%;border-collapse:collapse;font-size:.72rem}
.ustbl th,.ustbl td{border:1px solid var(--bd,#d9dde3);padding:3px 5px;text-align:right}
.ustbl th:first-child,.ustbl td:first-child{text-align:left}
.usflag{font-size:.76rem;color:#c0392b;margin-top:6px}

.miggrp{margin:0 0 12px}
.migh{font-size:.76rem;font-weight:700;opacity:.75;margin:0 0 5px;text-transform:uppercase;letter-spacing:.03em}
.migbox{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:8px}
.migbox label{display:flex;flex-direction:column;font-size:.78rem;gap:3px}
.mignote{grid-column:1/-1;font-size:.75rem;opacity:.7;margin:0 0 8px;line-height:1.45}
.migus{margin-top:6px;font-size:.75rem;color:#2d6cdf}

.calcnote{margin:0 0 10px;padding:8px 11px;border-left:3px solid #8a6d3b;background:rgba(138,109,59,.09);border-radius:0 8px 8px 0;font-size:.78rem;line-height:1.5}

.endowrap{margin-bottom:2px}
.pregline{margin:-2px 0 10px;padding:7px 10px;border-left:3px solid #2d6cdf;background:rgba(45,108,223,.07);border-radius:0 8px 8px 0;font-size:.8rem;line-height:1.45}
.pregline b{color:#2d6cdf}

.ros .yn .unk{opacity:.85}
.ros .yn .unk[aria-pressed="true"]{background:#8a6d3b;color:#fff;border-color:#8a6d3b}
.ros.unkon{background:rgba(138,109,59,.07)}
#pedWrap{display:flex;flex-direction:column;gap:10px}
.pedrow{border:1px solid var(--bd,#d9dde3);border-radius:10px;padding:10px;display:flex;flex-direction:column;gap:8px}
.pedrow.rfhit{border-color:#c0392b;background:rgba(192,57,43,.05)}
.pedgrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px}
.pedgrid label{display:flex;flex-direction:column;font-size:.78rem;gap:3px}
.pedgrid input,.pedgrid select{padding:5px;border-radius:6px;border:1px solid var(--bd,#d9dde3);background:transparent;color:inherit;font:inherit}
.dxchips{display:flex;flex-wrap:wrap;gap:5px}
.dxchips button{border:1px solid var(--bd,#d9dde3);background:transparent;color:inherit;border-radius:999px;padding:3px 9px;font-size:.75rem;cursor:pointer}
.dxchips button.on{background:#2d6cdf;color:#fff;border-color:#2d6cdf}
.dxchips button.on.rf{background:#c0392b;border-color:#c0392b}
.pedhead{display:flex;justify-content:space-between;align-items:center;gap:8px}
.pedhead b{font-size:.85rem}
.pedbtns{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:4px}
.pedbtns button{border:1px dashed var(--bd,#9aa3ad);background:transparent;color:inherit;border-radius:8px;padding:6px 11px;cursor:pointer;font:inherit;font-size:.8rem}
.pedwarn{font-size:.78rem;color:#c0392b}
</style>

<div class="top">
  <div class="top-in">
    <div class="brand"><b>Anamnézis-asszisztens</b><span>AI-asszisztált betegfelvétel · reprodukció &amp; terhesgondozás</span></div>
    <div class="seg" role="group" aria-label="Felvételi kontextus">
      <button data-stage="preivf" aria-pressed="true">Pre-IVF</button>
      <button data-stage="antenatal" aria-pressed="false">Terhesgondozás</button>
      <button data-stage="inpatient" aria-pressed="false">Terhespatológia</button>
    </div>
    <div class="grow"></div>
    <span class="pill"><span class="dot"></span> Az adatok a böngészőben maradnak</span>
    <button class="icon-btn" id="themeBtn" aria-label="Téma váltása">◐ Téma</button>
  </div>
</div>

<div class="toolbar">
  <div class="tb-in">
    <button class="tbbtn" id="tbNew">+ Új eset</button>
    <button class="tbbtn" id="tbSave">💾 Mentés</button>
    <button class="tbbtn" id="tbCases">🗂 Esetek</button>
    <span class="tbgrow"></span>
    <button class="tbbtn" id="tbPrint">🖨 PDF / Nyomtatás</button>
    <button class="tbbtn" id="tbFhir">⬇ FHIR export</button>
    <button class="tbbtn" id="tbDict">🎙 Diktálás</button>
  </div>
  <div class="casepanel" id="casePanel" hidden></div>
</div>

<div class="wrap">
```

---

## 2. Űrlap-markup

Sorok 278–542: a statikus űrlapváz (81 mező) és a kimeneti panel. A további szekciókat a
rétegek futásidőben építik.

```html
  <!-- ============ FORM ============ -->
  <div class="col-form" id="form">

    <details class="sec" open><summary><span class="num">01</span> Kontextus &amp; alapadatok <span class="chev">›</span></summary>
      <div class="body">
        <div class="grid g3">
          <label class="fld">Fogantatás módja
            <select id="conception"><option value="spontan">Spontán</option><option value="ovind">Ovuláció-indukció</option><option value="insem">Inszemináció (IUI)</option><option value="ivf" selected>IVF / lombik</option><option value="icsi">ICSI</option><option value="fet">Fagyasztott embrió (FET)</option><option value="donor">Donor gaméta</option></select></label>
          <label class="fld">Ikerterhesség
            <select id="twins"><option value="no" selected>Nem</option><option value="dcda">Igen – DCDA</option><option value="mcda">Igen – MCDA</option><option value="mcma">Igen – MCMA</option></select></label>
          <label class="fld">Terhességi kor (hét)
            <input id="ga" type="number" min="0" max="42" placeholder="pl. 12"></label>
          <label class="fld">Életkor (év)
            <input id="age" type="number" min="12" max="60" placeholder="pl. 30"></label>
          <label class="fld">Születési idő
            <input id="birth" type="date"></label>
          <label class="fld">Születési hely
            <input id="birthplace" placeholder="pl. Szeged"></label>
          <label class="fld">Irányítószám (lakhely)
            <input id="irsz" placeholder="pl. 6720" inputmode="numeric"></label>
          <label class="fld">Település (automatikus)
            <input id="telepules" placeholder="irsz alapján" readonly></label>
          <label class="fld">Foglalkozás
            <input id="occupation" placeholder="pl. tanár"></label>
          <label class="fld">FEOR (foglalkozás, automatikus)
            <input id="feorRes" placeholder="foglalkozás alapján" readonly></label>
          <label class="fld">Apai (partner) életkor
            <input id="patage" type="number" min="14" max="90" placeholder="pl. 34"></label>
          <label class="fld">Beteg-azonosító (PID)
            <input id="pid" placeholder="belső azonosító"></label>
          <label class="fld">TAJ (csak helyi mentéshez)
            <input id="taj" placeholder="nem kerül szerverre"></label>
          <label class="fld">Testmagasság (cm)
            <input id="height" type="number" min="120" max="210" placeholder="pl. 175"></label>
          <label class="fld">Testsúly (kg)
            <input id="weight" type="number" min="35" max="250" placeholder="pl. 128"></label>
          <label class="fld">Terhesség előtti súly (kg)
            <input id="ppweight" type="number" min="35" max="250" placeholder="opcionális"></label>
          <label class="fld">Vérnyomás (Hgmm)
            <input id="bp" placeholder="pl. 152/96"></label>
          <label class="fld">Napi folyadékbevitel (l)
            <input id="fluid" placeholder="pl. 2,5"></label>
          <label class="fld">Diéta / étrend
            <input id="diet" placeholder="pl. diabetes diéta / sószegény / nincs"></label>
          <label class="fld">BMI (számított)
            <input id="bmi" readonly placeholder="—" style="font-family:var(--mono);font-weight:700"></label>
          <label class="fld">Testfelület (m²)
            <input id="bsa" readonly placeholder="—" style="font-family:var(--mono);font-weight:700"></label>
          <label class="fld">MAP (MoM) — FMF PE-marker
            <input id="map_mom" type="number" step="any" placeholder="pl. 1,05"></label>
          <label class="fld">Uterina PI (MoM)
            <input id="uta_mom" type="number" step="any" placeholder="pl. 1,20"></label>
          <label class="fld">PlGF (MoM)
            <input id="plgf_mom" type="number" step="any" placeholder="pl. 0,70"></label>
        </div>
      </div>
    </details>

    <details class="sec"><summary><span class="num">R</span> Hivatalos várandós-rizikótényezők (EESZT) <span class="chev">›</span></summary>
      <div class="body">
        <p class="hint" style="margin:0 0 8px">Az EESZT várandósgondozási rizikótényező-törzs alapján; a pozitív tételek a hivatalos kóddal bekerülnek az anamnézisbe.</p>
        <div id="rosEeszt"></div>
      </div>
    </details>

    <details class="sec" id="secComplaint"><summary><span class="num">02</span> Jelen panaszok / állapot <span class="chev">›</span></summary>
      <div class="body">
        <div id="rosComplaint"></div>
        <label class="fld" style="margin-top:8px">Szabadszöveges panasz
          <textarea id="complaintText" placeholder="pl. mindkét láb ödémás, fejfájás nincs…"></textarea></label>
      </div>
    </details>

    <details class="sec"><summary><span class="num">03</span> Kórelőzmény — szervrendszerek <span class="chev">›</span></summary>
      <div class="body"><div id="rosSystems"></div></div>
    </details>

    <details class="sec"><summary><span class="num">3b</span> Endokrin anamnézis — kiemelt terhességi vonallal <span class="chev">›</span></summary>
      <div class="body">
        <p class="hint" style="margin:0 0 10px">Minden endokrin tétel alatt a <b>terhességi vonal</b> olvasható: mi változik terhességben, és mi a teendő. A pozitív válasz ezt automatikusan beemeli a teendőlistába.</p>
        <div id="rosEndo"></div>
      </div>
    </details>

    <details class="sec"><summary><span class="num">04</span> Gyógyszeres terápia <span class="chev">›</span></summary>
      <div class="body">
        <p class="hint" style="margin:0 0 8px">Írd be a szereket (hatóanyag vagy készítmény). A rendszer jelzi a terhességben kontraindikált / módosítandó szereket és javaslatot tesz.</p>
        <div class="chips" id="medQuick" style="margin-bottom:10px"></div>
        <div id="medList"></div>
        <button class="chip" id="addMed" style="margin-top:4px">+ Gyógyszer hozzáadása</button>
        <label class="fld" style="margin-top:12px">Egyéb / környezeti allergológiai megjegyzés
          <input id="allergy" placeholder="pl. pollen, háziporatka, méhcsípés"></label>
      </div>
    </details>

    <details class="sec" open><summary><span class="num">4b</span> Allergiák (gyógyszer &amp; étel) <span class="chev">›</span></summary>
      <div class="body">
        <label style="display:flex;align-items:center;gap:8px;font-size:13px;margin:0 0 10px">
          <input type="checkbox" id="allNone"> <b>Nincs ismert allergia</b> (a beteg tagadja)</label>
        <p class="hint" style="margin:0 0 6px"><b>Gyógyszer-allergiák</b> — kattints a gyakoriakra vagy adj hozzá sajátot; jelöld az anafilaxiát.</p>
        <div class="chips" id="drugAllQuick" style="margin-bottom:8px"></div>
        <div id="drugAllList"></div>
        <button class="chip" id="addDrugAll" style="margin-top:4px">+ Gyógyszer-allergia</button>
        <p class="hint" style="margin:14px 0 6px"><b>Étel-allergiák / -intoleranciák</b></p>
        <div class="chips" id="foodAllQuick" style="margin-bottom:8px"></div>
        <div id="foodAllList"></div>
        <button class="chip" id="addFoodAll" style="margin-top:4px">+ Étel-allergia</button>
      </div>
    </details>

    <details class="sec"><summary><span class="num">05</span> Reprodukciós &amp; szülészeti anamnézis <span class="chev">›</span></summary>
      <div class="body">
        <div class="usgrid" id="gpaHost" style="margin-bottom:12px">
          <div class="usgh">Terhességi összegzés (GPA)</div>
          <label><span>Gravida (összes terhesség)</span><input type="number" min="0" id="gp_g"></label>
          <label><span>Para (24. hét után szült)</span><input type="number" min="0" id="gp_p"></label>
          <label><span>Spontán vetélés (db)</span><input type="number" min="0" id="gp_absp"></label>
          <label><span>Művi megszakítás (db)</span><input type="number" min="0" id="gp_abind"></label>
          <label><span>Extrauterin (db)</span><input type="number" min="0" id="gp_ect"></label>
          <label><span>Élő gyermek</span><input type="number" min="0" id="gp_liv"></label>
        </div>
        <div id="rosRepro"></div>
      </div>
    </details>

    <details class="sec"><summary><span class="num">06</span> Családi anamnézis — vér szerinti rokonok (3 generáció) <span class="chev">›</span></summary>
      <div class="body">
        <p class="hint" style="margin:0 0 10px">A <b style="color:var(--crit)">VÖRÖS ZÁSZLÓ</b> jelölésű tételek pozitív válasza automatikus genetikai/kardiológiai teendőt indít.</p>
        <div id="rosFamily"></div>
      </div>
    </details>

    <details class="sec"><summary><span class="num">07</span> Életmód <span class="chev">›</span></summary>
      <div class="body"><div id="rosLifestyle"></div></div>
    </details>

    <details class="sec"><summary><span class="num">7c</span> Rövid depresszió-szűrés (PHQ-2) <span class="chev">›</span></summary>
      <div class="body">
        <p class="hint" style="margin:0 0 10px">Az elmúlt <b>2 hétben</b> milyen gyakran zavarták az alábbiak? (Perinatális szűrés — pozitív eredménynél EPDS/PHQ-9 és pszichés konzílium javasolt.)</p>
        <div class="grid" style="gap:10px">
          <label class="fld">Lehangoltság, levertség vagy reménytelenség érzése
            <select id="phq2_a"><option value="">—</option><option value="0">Egyáltalán nem</option><option value="1">Néhány napon</option><option value="2">A napok több mint felében</option><option value="3">Szinte minden nap</option></select></label>
          <label class="fld">Érdeklődés vagy öröm hiánya a szokásos tevékenységekben
            <select id="phq2_b"><option value="">—</option><option value="0">Egyáltalán nem</option><option value="1">Néhány napon</option><option value="2">A napok több mint felében</option><option value="3">Szinte minden nap</option></select></label>
        </div>
        <div class="cres" id="phq2res" style="margin-top:10px">Válaszolj mindkét kérdésre a pontszámhoz.</div>
        <p class="hint" style="margin:8px 0 0;color:var(--crit)">Ha bármikor önmaga bántására vagy halálra vonatkozó gondolatai vannak, azonnali szakmai segítség szükséges (krízisellátás).</p>
      </div>
    </details>

    <details class="sec"><summary><span class="num">7d</span> Pszichoszociális / munkahelyi tényezők <span class="chev">›</span></summary>
      <div class="body">
        <p class="hint" style="margin:0 0 8px">Ezek automatikusan BNO Z-/F-kódot kapnak és bekerülnek az anamnézisbe.</p>
        <label style="display:block;font-size:13px;margin:3px 0"><input type="checkbox" id="ps_work" class="psx"> Munkahelyi stressz / konfliktus (pl. rossz főnök, túlterhelés, műszakok)</label>
        <label style="display:block;font-size:13px;margin:3px 0"><input type="checkbox" id="ps_fin" class="psx"> Anyagi vagy lakhatási nehézség</label>
        <label style="display:block;font-size:13px;margin:3px 0"><input type="checkbox" id="ps_rel" class="psx"> Párkapcsolati / családi konfliktus</label>
        <label style="display:block;font-size:13px;margin:3px 0"><input type="checkbox" id="ps_supp" class="psx"> Elégtelen szociális támogatás / egyedüllét</label>
        <label style="display:block;font-size:13px;margin:3px 0"><input type="checkbox" id="ps_anx" class="psx"> Anyai szorongás / fokozott aggodalom a terhesség miatt</label>
        <label style="display:block;font-size:13px;margin:3px 0"><input type="checkbox" id="ps_viol" class="psx"> Bántalmazás (fizikai/lelki) gyanúja</label>
      </div>
    </details>

    <details class="sec"><summary><span class="num">7b</span> Származási / fejlődési anamnézis (3 generáció) <span class="chev">›</span></summary>
      <div class="body">
        <p class="hint" style="margin:0 0 8px">A beteg saját születési körülményei és a felmenők (DOHaD — fejlődési eredetű kockázatok).</p>
        <div class="grid g3" style="margin-bottom:10px">
          <label class="fld">Hányadik héten született a beteg
            <input id="birthGA" type="number" min="20" max="43" placeholder="pl. 40"></label>
          <label class="fld">A beteg születési súlya (g)
            <input id="birthWt" type="number" min="300" max="6000" placeholder="pl. 3200"></label>
        </div>
        <div id="rosOrigin"></div>
      </div>
    </details>

    <details class="sec"><summary><span class="num">08</span> Korábbi műtétek <span class="chev">›</span></summary>
      <div class="body"><div id="rosSurg"></div></div>
    </details>

    <details class="sec"><summary><span class="num">09</span> Vitamin / szupplementáció monitoring <span class="chev">›</span></summary>
      <div class="body">
        <p class="hint" style="margin:0 0 8px">Jelöld, mit szed és milyen dózisban. A hiányzó kulcsfontosságú pótlások automatikusan a teendőlistába kerülnek.</p>
        <div id="suppHost"></div>
      </div>
    </details>

    <details class="sec"><summary><span class="num">10</span> Laborértékek (beemelés) <span class="chev">›</span></summary>
      <div class="body">
        <p class="hint" style="margin:0 0 8px">Írd be az elérhető laborértékeket; a kóros értékek automatikus teendőt generálnak és bekerülnek az anamnézisbe.</p>
        <div class="grid g3" id="labHost"></div>
      </div>
    </details>

    <details class="sec"><summary><span class="num">11</span> Előzmények beillesztése <span class="chev">›</span></summary>
      <div class="body">
        <p class="hint" style="margin:0 0 8px">Korábbi zárójelentés, ambuláns lap, lelet szövege ide másolható — bekerül az anamnézisbe (forrásmegjelöléssel).</p>
        <textarea id="prior" style="min-height:120px" placeholder="Korábbi dokumentáció beillesztése…"></textarea>
      </div>
    </details>

  </div>

  <!-- ============ OUTPUT ============ -->
  <div class="col-out">
    <div class="card" style="margin-bottom:16px">
      <div class="out-head">
        <h3>Strukturált anamnézis</h3>
        <span class="pill" id="riskPill" style="border-color:var(--line)">Rizikó: —</span>
        <div class="out-actions">
          <button class="btn" id="copyAnam">Másolás</button>
          <button class="btn" id="dlAnam">.txt</button>
        </div>
      </div>
      <pre class="rec" id="anamOut">Töltsd ki a kérdőívet — az anamnézis itt épül fel élőben.</pre>
      <div class="legal" id="legalNote"></div>
    </div>

    <div class="card">
      <div class="out-head">
        <h3>Orvosi teendőlista</h3>
        <span class="pill" id="todoCount">0 tétel</span>
        <div class="out-actions">
          <button class="btn primary" id="copyTodo">Teendők másolása</button>
        </div>
      </div>
      <div class="todo" id="todoOut"><div class="empty">A teendők a kitöltés alapján automatikusan generálódnak.</div></div>
    </div>

    <div class="card" style="margin-top:16px">
      <div class="out-head">
        <h3>Kockázati becslés</h3>
        <span class="pill" id="riskNote" style="border-color:var(--line)">tájékoztató</span>
      </div>
      <div class="calcnote">A kalkulátorok <b>kockázatbecslést</b> adnak, nem diagnózist. A szűrővizsgálatok — az ultrahangot is beleértve — egyetlen állapotban sem 100%-os érzékenységűek, ezért a negatív eredmény nem zárja ki a kórképet. A részletes tájékoztató a nyomtatott dokumentum végén olvasható.</div>
<div class="todo" id="riskOut"><div class="empty">Add meg az életkort és a rizikófaktorokat — a becslések itt jelennek meg.</div></div>
      <div class="legal">FMF a priori (Snijders/FMF) triszómia-kockázat és NICE preeclampsia/GDM besorolás + epidemiológiai becslések; tájékoztató, NEM validált kalkulátor, és nem helyettesíti a formális szűrést (kombinált teszt / NIPT / FMF competing-risks / szakorvosi rizikóbecslés). A végső értékelés a kezelőorvosé.</div>
    </div>

    <div class="card" style="margin-top:16px">
      <div class="out-head">
        <h3>BNO / OENO kódajánló</h3>
        <span class="pill" style="border-color:var(--line)">automatikus</span>
      </div>
      <div class="todo" id="bnoOut"><div class="empty">A rögzített diagnózisok alapján itt jelennek meg a BNO-kódok; az OENO-beavatkozások kódja megerősítendő.</div></div>
      <div class="legal">A BNO-kódok a hivatalos BNO-10 törzsből (PUPHA BNOKODOK) származó javaslatok; a végső kódolás a kezelőorvos felelőssége. OENO-kódtár nem volt a mellékelt adatbázisban, ezért a beavatkozások névvel jelennek meg — OENO-tábla megadásával a pontos kódok is automatikusan beépíthetők.</div>
    </div>

    <div class="card" style="margin-top:16px">
      <div class="out-head"><h3>EESZT szabvány kódtörzsek</h3><span class="pill" id="eesztPill" style="border-color:var(--line)">beágyazott</span></div>
      <div class="todo">
        <div class="calcrow"><h5>Teljes törzs betöltése (offline)</h5><p class="hint" style="margin:0 0 6px">Beágyazva: teljes ATC + szülészeti BNO/OENO + irsz→település + FEOR. A TELJES BNO/OENO/labor/FNO kereséshez töltsd be az <code>eeszt_bundle.json</code>-t.</p><input type="file" id="eesztFile" accept="application/json,.json"><div class="cres" id="eesztStatus">—</div></div>
        <div class="calcrow"><h5>Kódkeresés</h5><div class="cin"><label>Rendszer <select id="eesztType"><option value="bno">BNO (diagnózis)</option><option value="atc">ATC (gyógyszer)</option><option value="oeno">OENO (beavatkozás)</option><option value="feor">FEOR (foglalkozás)</option><option value="fno">FNO (funkció)</option><option value="lab">Labor (UCUM)</option><option value="telep">Település (irsz)</option></select></label> <label>Keresés <input id="eesztQ" placeholder="kód vagy név…"></label></div><div class="cres" id="eesztRes">Írj be legalább 2 karaktert.</div></div>
      </div>
      <div class="legal">Tájékoztató kódfeloldás; a végleges kódolás a kezelőorvos felelőssége. Forrás: EESZT / NNK törzsadatok.</div>
    </div>

    <div class="card" style="margin-top:16px">
      <div class="out-head"><h3>Kalkulátorok</h3><span class="pill" style="border-color:var(--line)">paletta</span></div>
      <div class="todo" id="calcHost"></div>
      <div class="legal">Tájékoztató klinikai kalkulátorok: EDD/gestatiós kor, IOM súlygyarapodás, MAP, eGFR, HbA1c↔eAG, CARPREG II, Bishop, QTc, HOMA-IR, mWHO, RCOG-VTE (Green-top 37a) — az adatokból AUTOMATIKUSAN számolva. A prediktív FMF (PE, vetélés, halvaszületés, SGA, macrosomia, keltezés, növekedés, UtA-PI) és a fullPIERS modellek a hivatalos, validált kalkulátort BEÁGYAZOTT KERETBEN (iframe) futtatják — a másik oldal számol, ugyanezen a lapon, új ablak nélkül. A végső értékelés a kezelőorvosé.</div>
    </div>
  </div>
</div>


```

---

## 3. Rétegek

<a id="dictation-543585"></a>

### dictation — Beszédfelismerés (Web Speech API), offline; hosztolt Whisper-kampó

Sorok 543–585 (43 sor).

```javascript
<script>
/* ===== dictation (speech-to-text) — Web Speech API, offline; hosted Whisper hook ===== */
(function(){
  "use strict";
  var q=function(s){return document.querySelector(s);};
  var SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  var LOCALE={hu:"hu-HU",en:"en-US",fr:"fr-FR",de:"de-DE",es:"es-ES",zh:"zh-CN"};
  var rec=null, listening=false, target=null, base="";
  function toastMsg(m){ try{ if(typeof toast==="function"){toast(m);return;} }catch(e){} var t=q("#toast"); if(t){t.textContent=m;t.classList.add("show");setTimeout(function(){t.classList.remove("show");},2200);} }
  function curLang(){ var s=q("#langSel"); return (s&&s.value)||localStorage.getItem("anam_lang")||"hu"; }
  // remember last focused editable text field (dictation target)
  document.addEventListener("focusin",function(e){var el=e.target; if(!el)return; if(el.id==="langSel"||el.id==="puphaSearch")return;
    if(el.tagName==="TEXTAREA"||(el.tagName==="INPUT"&&/^(text|search|tel|email|number|date|)$/i.test(el.getAttribute("type")||"text"))) target=el; });
  var bar=null;
  function bshow(html){ if(!bar){bar=document.createElement("div");bar.id="dictBar";
      bar.style.cssText="position:fixed;bottom:16px;left:50%;transform:translateX(-50%);z-index:60;background:var(--ink);color:var(--bg);padding:9px 14px;border-radius:10px;font-size:13px;max-width:82vw;box-shadow:0 8px 28px rgba(0,0,0,.35);display:none;align-items:center;gap:10px";document.body.appendChild(bar);}
    bar.innerHTML=html; bar.style.display="flex"; var s=q("#dictStop"); if(s)s.onclick=stop; }
  function bhide(){ if(bar)bar.style.display="none"; }
  function stopBtnHTML(){ return ' <button id="dictStop" style="border:0;background:#fff;color:#111;border-radius:6px;padding:3px 9px;cursor:pointer;font-weight:600">Leállítás</button>'; }
  function start(){
    if(!SR){ toastMsg("A böngésző nem támogatja a beszédfelismerést — használj Chrome/Edge/Safari böngészőt. (A hosztolt változat Whisper-alapú diktálást is kap.)"); return; }
    if(!target||!document.body.contains(target)) target=q("#prior")||q("#complaintText");
    if(!target){ toastMsg("Előbb kattints egy szövegmezőbe, ahová diktálni szeretnél."); return; }
    try{ rec=new SR(); }catch(e){ toastMsg("A diktálás nem indítható."); return; }
    rec.lang=LOCALE[curLang()]||"hu-HU"; rec.interimResults=true; rec.continuous=true; rec.maxAlternatives=1;
    base=target.value||""; var finalAdd="";
    rec.onresult=function(ev){ var interim=""; for(var i=ev.resultIndex;i<ev.results.length;i++){ var r=ev.results[i]; if(r.isFinal)finalAdd+=r[0].transcript; else interim+=r[0].transcript; }
      var sep=(base&&!/\s$/.test(base))?" ":""; target.value=base+sep+finalAdd+interim;
      try{ target.dispatchEvent(new Event("input",{bubbles:true})); }catch(e){}
      bshow('<span style="width:9px;height:9px;border-radius:50%;background:#e05a4b;display:inline-block;animation:dictpulse 1s infinite"></span> Diktálás… <i style="opacity:.85">'+((interim||finalAdd)||"").slice(-70)+'</i>'+stopBtnHTML()); };
    rec.onerror=function(e){ toastMsg("Diktálás hiba: "+(e&&e.error||"")); stop(); };
    rec.onend=function(){ if(listening){ try{ base=(target.value||""); rec.start(); }catch(_e){} } };
    listening=true; try{ rec.start(); }catch(e){}
    var b=q("#tbDict"); if(b)b.textContent="⏹ Diktálás leáll";
    bshow('<span style="width:9px;height:9px;border-radius:50%;background:#e05a4b;display:inline-block"></span> Diktálj a mikrofonba… (nyelv: '+ (LOCALE[curLang()]||"hu-HU") +')'+stopBtnHTML());
  }
  function stop(){ listening=false; if(rec){ try{rec.stop();}catch(e){} } rec=null; bhide(); var b=q("#tbDict"); if(b)b.textContent="🎙 Diktálás"; }
  var btn=q("#tbDict"); if(btn)btn.onclick=function(){ listening?stop():start(); };
  var st=document.createElement("style"); st.textContent="@keyframes dictpulse{0%,100%{opacity:1}50%{opacity:.25}}"; document.head.appendChild(st);
  // hosted hook (future): if window.VOICE_ENDPOINT is set, a MediaRecorder path could POST audio for Whisper+AI structuring/routing (see patient-intake voice-note).
  window.__dictation={start:start,stop:stop};
})();
</script>
```

<a id="mag--v2-5891529"></a>

### mag + v2 — Űrlap, állapot, generate(), teendőmotor; műtétek, szupplementáció, labor, PUPHA, kockázat

Sorok 589–1529 (941 sor).

```javascript
<script>
"use strict";
window.addEventListener("error",function(ev){try{var b=document.getElementById("__err");if(!b){b=document.createElement("div");b.id="__err";b.style.cssText="position:fixed;top:0;left:0;right:0;z-index:99999;background:#b23a2e;color:#fff;padding:8px 14px;font:13px/1.4 sans-serif";(document.body||document.documentElement).appendChild(b);}b.textContent="⚠ Betöltési hiba (küldd el a fejlesztőnek): "+((ev&&(ev.message||(ev.error&&ev.error.message)))||"?")+" @"+((ev&&ev.lineno)||"")+":"+((ev&&ev.colno)||"");}catch(e){}});
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const el=(t,c,h)=>{const e=document.createElement(t); if(c)e.className=c; if(h!=null)e.innerHTML=h; return e;};
let STAGE="preivf";
const state={ros:{},fam:{},meds:[]};

/* ---------- config ---------- */
const COMPLAINT=[
  {id:"c_head",l:"Fejfájás / látászavar"},
  {id:"c_epi",l:"Epigasztriális / jobb bordaív alatti fájdalom"},
  {id:"c_edema",l:"Végtag- vagy generalizált oedema"},
  {id:"c_dysp",l:"Nehézlégzés / mellkasi panasz",rf:1},
  {id:"c_bleed",l:"Vérzés / görcs"},
  {id:"c_move",l:"Csökkent magzatmozgás"},
];
const SYSTEMS=[
  {g:"Kardiovaszkuláris",items:[
    {id:"s_htn",l:"Magas vérnyomás (krónikus)"},
    {id:"s_card",l:"Ismert szívbetegség / billentyűhiba",rf:1},
    {id:"s_arr",l:"Ritmuszavar / ájulás / palpitáció",rf:1},
    {id:"s_dev",l:"Pacemaker / ICD",rf:1},
  ]},
  {g:"Endokrin / metabolikus",items:[
    {id:"s_dm",l:"Diabetes / korábbi GDM"},
    {id:"s_t1dm",l:"1-es típusú diabetes (T1DM)"},
    {id:"s_t2dm",l:"2-es típusú diabetes (T2DM)"},
    {id:"s_lada",l:"LADA (lassan progrediáló autoimmun diabetes)"},
    {id:"s_thy",l:"Pajzsmirigy-betegség"},
    {id:"s_pcos",l:"PCOS / PMOS"},
  ]},
  {g:"Nőgyógyászat / reprodukció",items:[
    {id:"s_endo",l:"Endometriosis / adenomyosis"},
    {id:"s_hpv",l:"HPV-pozitivitás / kóros cervikális cytológia"},
    {id:"s_infert",l:"Meddőségi kezelés (ART) az anamnézisben"},
  ]},
  {g:"Vese / máj / GI",items:[
    {id:"s_ren",l:"Vesebetegség / fehérjevizelet"},
    {id:"s_icp",l:"Terhességi cholestasis (ICP) előzmény"},
    {id:"s_liv",l:"Májbetegség / IBD / coeliakia"},
  ]},
  {g:"Légző / alvás",items:[
    {id:"s_ast",l:"Asztma / krónikus légúti betegség"},
    {id:"s_osa",l:"Alvási apnoe (horkolás, nappali álmosság)"},
  ]},
  {g:"Haematológia / immun",items:[
    {id:"s_thr",l:"Thrombosis / thrombophilia",rf:1},
    {id:"s_ana",l:"Anaemia / vérzészavar"},
    {id:"s_ai",l:"Autoimmun betegség (SLE / APS)",rf:1},
  ]},
  {g:"Neuro / pszichiátria",items:[
    {id:"s_epi",l:"Epilepszia / neurológiai betegség"},
    {id:"s_psy",l:"Pszichiátriai betegség (depresszió, szorongás, bipoláris)"},
  ]},
  {g:"Egyéb",items:[
    {id:"s_onc",l:"Daganatos betegség / örökletes daganatszindróma",rf:1},
    {id:"s_ct",l:"Kötőszöveti betegség (Marfan / Ehlers-Danlos)",rf:1},
  ]},
];
const REPRO=[
  {id:"r_prev",l:"Volt korábbi terhesség / szülés"},
  {id:"r_loss",l:"Ismételt (≥2) vetélés / magzati elhalás",rf:1},
  {id:"r_pe",l:"Korábbi preeclampsia / HELLP"},
  {id:"r_gdm",l:"Korábbi gesztációs diabetes"},
  {id:"r_macro",l:"Korábbi makroszóm újszülött (≥ 4,5 kg)"},
  {id:"r_ptb",l:"Korábbi koraszülés / FGR"},
  {id:"r_tri",l:"Korábbi igazolt triszómiás terhesség",rf:1},
  {id:"r_anom",l:"Korábbi terhességben veleszületett rendellenesség",rf:1},
  /* --- v16: terhessegvesztes es meh-uri beavatkozasok --- */
  {id:"r_absp",l:"Spontán vetélés (egy vagy több)"},
  {id:"r_abind",l:"Művi terhességmegszakítás (mű abortus)"},
  {id:"r_abmis",l:"Missed abortion / nem fejlődő terhesség"},
  {id:"r_ectop",l:"Méhen kívüli (extrauterin) terhesség",rf:1},
  {id:"r_mola",l:"Molaterhesség",rf:1},
  {id:"r_cur",l:"Méhűri beavatkozás terhesség után (curettage, hysteroscopia)"},
];
const FAMILY=[
  {id:"f_scd",l:"Hirtelen szívhalál < 50 évesen vér szerinti rokonnál",rf:1},
  {id:"f_cmp",l:"Öröklődő cardiomyopathia (DCM / HCM / ARVC)",rf:1},
  {id:"f_chan",l:"Örökletes ritmuszavar / channelopathia (LQTS, Brugada)",rf:1},
  {id:"f_chd",l:"Veleszületett szívhiba",rf:1},
  {id:"f_thr",l:"Fiatalkori thrombosis / thrombophilia",rf:1},
  {id:"f_mono",l:"Ismert öröklődő (monogénes) betegség",rf:1},
  {id:"f_dev",l:"Értelmi fogyatékosság / fejlődési zavar",rf:1},
  {id:"f_canc",l:"Örökletes daganatszindróma (BRCA, Lynch)",rf:1},
  {id:"f_cons",l:"Vérrokonság a szülők között (konszangvinitás)",rf:1},
  {id:"f_ethn",l:"Etnikai hordozói kockázat (thalassaemia, CF, Tay-Sachs…)",rf:1},
  {id:"f_dm",l:"Diabetes / hypertonia halmozódása"},
  {id:"f_dm1",l:"Cukorbetegség I. fokú rokonnál (szülő/testvér)"},
  {id:"f_pe",l:"Preeclampsia elsőfokú rokonnál"},
  /* --- v16: tisztázatlan diagnózisú tételek. A klasszikus checkboxok csak KIMONDOTT
     diagnózist fognak meg; a valóságban a családi adat gyakran laikus leírás. --- */
  {id:"f_ucard",l:"Fiatalon (< 50 é.) szívbetegségben elhunyt vér szerinti rokon — a diagnózis nem tisztázott",rf:1},
  {id:"f_udeath",l:"Tisztázatlan okú fiatalkori halál a családban",rf:1},
  {id:"f_uneuro",l:"Fiatalon kialakult neurológiai / izombetegség — a diagnózis nem tisztázott",rf:1},
  {id:"f_uren",l:"Fiatalon kialakult vesebetegség / dialízis — a diagnózis nem tisztázott",rf:1},
  {id:"f_ucanc",l:"Fiatalon (< 50 é.) kialakult daganat — a típus nem tisztázott",rf:1},
  {id:"f_uhaem",l:"Ismétlődő thrombosis / vérzékenység — a diagnózis nem tisztázott",rf:1},
  {id:"f_umeta",l:"Csecsemő- vagy gyermekkori hirtelen halál / anyagcsere-betegség gyanúja",rf:1},
  {id:"f_usyn",l:"Több rokonnál halmozódó, meg nem magyarázott betegség",rf:1},
];
const ENDO=[
  {id:"en_hypo",l:"Hypothyreosis (pajzsmirigy-alulműködés)",cat:"med",sev:"warn",preg:"Terhesség megállapításakor a levotiroxin-dózis azonnali emelése (kb. +25–30%); TSH-cél az I. trimeszterben < 2,5 mIU/L; TSH 4 hetente a 20. hétig."},
  {id:"en_hyper",l:"Hyperthyreosis / Graves-kór",cat:"med",sev:"warn",preg:"Az I. trimeszterben propiltiouracil, utána methimazol; TRAK-mérés a 20–24. héten (magzati thyreotoxicosis kockázata); magzati pajzsmirigy-ultrahang."},
  {id:"en_tpo",l:"Pozitív TPO-ellenanyag / thyreoiditis euthyreosis mellett",cat:"lab",sev:"info",preg:"TSH trimeszterenként; fokozott hypothyreosis- és vetélési kockázat."},
  {id:"en_thyop",l:"Pajzsmirigy-göb, korábbi pajzsmirigyműtét vagy radiojód-kezelés",cat:"lab",sev:"info",preg:"Radiojód után legalább 6 hónap várakozás a fogantatásig; a szubsztitúció terhességi dózisemelése; ultrahang-követés."},
  {id:"en_pcos",l:"PCOS (policisztás ovárium szindróma)",cat:"lab",sev:"warn",preg:"Emelkedett GDM- és preeclampsia-kockázat; korai OGTT (16–18. hét) mérlegelése, majd ismétlés a 24–28. héten."},
  {id:"en_dm1",l:"1-es típusú diabetes mellitus",cat:"med",sev:"crit",preg:"Prekoncepcionálisan HbA1c < 6,5%; 5 mg folsav; retina- és vesestátusz felmérése; ACE-gátló / ARB / statin leállítása; szoros glykaemiás követés; ASA a 16. hét előtt."},
  {id:"en_dm2",l:"2-es típusú diabetes mellitus",cat:"med",sev:"crit",preg:"Orális szerek felülvizsgálata (metformin / inzulin); HbA1c-cél a fogantatás előtt; 5 mg folsav; ASA preeclampsia-profilaxis a 16. hét előtt."},
  {id:"en_gdm",l:"Korábbi gesztációs diabetes",cat:"lab",sev:"warn",preg:"Korai OGTT (16–18. hét), majd ismétlés a 24–28. héten; postpartum 4–12 héttel ismételt OGTT."},
  {id:"en_ir",l:"Inzulinrezisztencia / metformin-szedés",cat:"med",sev:"info",preg:"A metformin terhességben folytatható, de a kezelés célját újra kell értékelni; a GDM-szűrés időzítése előrehozandó."},
  {id:"en_glp",l:"GLP-1 receptor agonista szedése (pl. semaglutid, liraglutid, tirzepatid)",cat:"med",sev:"crit",preg:"Terhességben nem javasolt: a fogantatás előtti leállítás és a készítményspecifikus washout betartása (hosszú felezési idejű szereknél hetek); fogamzásgátlás a washout alatt."},
  {id:"en_bar",l:"Bariátriai (elhízás-)műtét utáni állapot",cat:"lab",sev:"warn",preg:"A műtét után legalább 12–18 hónap várakozás; vas, B12, folsav, D-vitamin és kalcium célzott pótlása és követése; dömping miatt módosított GDM-szűrés."},
  {id:"en_prl",l:"Hyperprolactinaemia / prolactinoma",cat:"ref",sev:"warn",preg:"Makroadenománál látótér-vizsgálat trimeszterenként; a dopamin-agonista folytatásának egyedi mérlegelése; új fejfájás vagy látászavar azonnali kivizsgálása."},
  {id:"en_adr",l:"Mellékvese-betegség (Addison, Cushing, CAH)",cat:"ref",sev:"crit",preg:"Addison-kórban stressz-dózisú hidrokortizon a szülés alatt; CAH-ban genetikai tanácsadás; Cushing-szindrómában fokozott preeclampsia-, GDM- és koraszülés-kockázat."},
  {id:"en_pth",l:"Mellékpajzsmirigy-betegség / kalcium-anyagcsere zavara",cat:"lab",sev:"warn",preg:"Szérum-kalcium és albumin követése; az anyai hypercalcaemia magzati mellékpajzsmirigy-szuppressziót és újszülöttkori tetaniát okozhat."},
  {id:"en_pit",l:"Hypophysis-elégtelenség / korábbi Sheehan-szindróma",cat:"med",sev:"crit",preg:"A hormonpótlás dózisának terhességi felülvizsgálata; szülés körüli szteroid-fedés; postpartum vérzés esetén fokozott figyelem."},
  {id:"en_ost",l:"Osteoporosis / biszfoszfonát-kezelés",cat:"med",sev:"warn",preg:"A biszfoszfonát a csontban perzisztál; fogantatás előtti leállítás és egyedi kockázatértékelés szükséges."},
  {id:"en_vitd",l:"Ismert D-vitamin-hiány",cat:"lab",sev:"info",preg:"Pótlás beállítása (800–2000 NE/nap) és a szint ellenőrzése."},
];
const LIFE=[
  {id:"l_smoke",l:"Dohányzás"},
  {id:"l_alc",l:"Rendszeres alkoholfogyasztás"},
  {id:"l_drug",l:"Droghasználat"},
];
const ORIGIN=[
 {id:"o_preterm",l:"A beteg koraszülöttként született (< 37. hét)"},
 {id:"o_cs",l:"A beteg császármetszéssel született"},
 {id:"o_lbw",l:"A beteg alacsony súllyal született (< 2500 g)"},
 {id:"o_msmoke",l:"Az anya dohányzott a beteg terhessége alatt"},
 {id:"o_gmsmoke",l:"Nagymama dohányzott"},
 {id:"o_mdm",l:"Anyai gesztációs diabetes a beteg terhességekor"},
 {id:"o_mpe",l:"Anyai preeclampsia / hypertonia a beteg terhességekor"},
 {id:"o_consang",l:"Szülők közötti vérrokonság (konszangvinitás)"},
];
const MEDQUICK=["Dopegyt (methyldopa)","Nepresol (hydralazin)","Normodipin (amlodipin)","Cordaflex (nifedipin)","Acizalep (ASA)","Enalapril","Ramipril","Losartan","Metformin","Atorvastatin","Levotiroxin","Insulin","Escitalopram","Valproát"];


/* ===== v2 additions: surgery / supplements / labs / PUPHA / risk ===== */
state.supp={};
const SURG=[
 {id:"su_abd",l:"Hasi / kismedencei műtét"},
 {id:"su_cs",l:"Korábbi császármetszés"},
 {id:"su_myom",l:"Myomectomia / méhműtét"},
 {id:"su_lsc",l:"Laparoszkópia (endometriosis / cysta)"},
 {id:"su_cone",l:"Cervix-conisatio / LLETZ"},
 {id:"su_cerc",l:"Cerclage"},
 {id:"su_bar",l:"Bariátriai műtét"},
 {id:"su_thyr",l:"Pajzsmirigy-műtét"},
 {id:"su_card",l:"Szív- / érműtét"},
 {id:"su_oth",l:"Egyéb jelentős műtét"},
];
const SUPP=[
 {id:"sp_folate",l:"Folsav / folát"},
 {id:"sp_d",l:"D-vitamin"},
 {id:"sp_iron",l:"Vas"},
 {id:"sp_iod",l:"Jód"},
 {id:"sp_b12",l:"B12 / B-komplex"},
 {id:"sp_omega",l:"Omega-3 (DHA)"},
 {id:"sp_ca",l:"Kalcium"},
 {id:"sp_multi",l:"Terhes-multivitamin"},
];
const LABF=[
 {id:"lb_hgb",l:"Hemoglobin",u:"g/l"},{id:"lb_plt",l:"Thrombocyta",u:"×10⁹/l"},
 {id:"lb_ldh",l:"LDH",u:"U/l"},{id:"lb_got",l:"GOT/GPT (max.)",u:"U/l"},
 {id:"lb_creat",l:"Kreatinin",u:"µmol/l"},{id:"lb_alb",l:"Albumin",u:"g/l"},
 {id:"lb_tsh",l:"TSH",u:"mIU/l"},{id:"lb_hba1c",l:"HbA1c",u:"%"},
 {id:"lb_glu",l:"Éhomi vércukor",u:"mmol/l"},{id:"lb_prot",l:"Vizelet-fehérje (24h)",u:"g/nap"},
 {id:"lb_bnp",l:"NT-proBNP",u:"pg/ml"},{id:"lb_trop",l:"hs-Troponin",u:"ng/l"},
 {id:"lb_bile",l:"Epesav",u:"µmol/l"},
];
const PUPHA=[{"n":"131I-MIBG","h":"iobenguane (131i)","a":"V09IX02"},{"n":"14C-HELIZO","h":"","a":"V09HX"},{"n":"3FLUART","h":"influenza, inactivated, whole virus","a":"J07BB01"},{"n":"5-FLUOROURACIL SANDOZ","h":"fluorouracil","a":"L01BC02"},{"n":"ABACAVIR/LAMIVUDINE TEVA","h":"lamivudine and abacavir","a":"J05AR02"},{"n":"ABAXAN","h":"abiraterone","a":"L02BX03"},{"n":"ABILIFY","h":"aripiprazol","a":"N05AX12"},{"n":"ABILIFY MAINTENA","h":"aripiprazol","a":"N05AX12"},{"n":"ABIRATERON STADA","h":"abiraterone","a":"L02BX03"},{"n":"ABIRATERON ZENTIVA","h":"abiraterone","a":"L02BX03"},{"n":"ABIRATERONE ACCORD","h":"abiraterone","a":"L02BX03"},{"n":"ABIRATERONE KRKA","h":"abiraterone","a":"L02BX03"},{"n":"ABIRATERONE PHARMASCIENCE","h":"abiraterone","a":"L02BX03"},{"n":"ABIRATERONE QILU","h":"abiraterone","a":"L02BX03"},{"n":"ABIRATERONE RICHTER","h":"abiraterone","a":"L02BX03"},{"n":"ABIRATERONE SANDOZ","h":"abiraterone","a":"L02BX03"},{"n":"ABIRATERONE VIPHARM","h":"abiraterone","a":"L02BX03"},{"n":"ABRAXANE","h":"paclitaxel","a":"L01CD01"},{"n":"ABRYSVO","h":"vakcinák, egyéb virális vakcinák","a":"J07BX05"},{"n":"ACARIZAX","h":"house dust","a":"V01AA03"},{"n":"ACC","h":"acetil-cisztein","a":"R05CB01"},{"n":"ACC LONG","h":"acetil-cisztein","a":"R05CB01"},{"n":"ACCOFIL","h":"filgastrim","a":"L03AA02"},{"n":"ACEOMEL","h":"kaptopril","a":"C09AA01"},{"n":"ACEPRAMIN","h":"aminokapronsav","a":"B02AA01"},{"n":"ACICLOVIR AL","h":"aciklovir","a":"J05AB01"},{"n":"ACICLOVIR AZEVEDOS","h":"aciklovir","a":"J05AB01"},{"n":"ACICLOVIR ROMPHARM","h":"aciklovir","a":"J05AB01"},{"n":"ACICLOVIR STADA","h":"aciklovir","a":"D06BB03"},{"n":"ACIDA","h":"pantoprazol","a":"A02BC02"},{"n":"ACIDUM NICOTINICUM","h":"nikotinsav","a":"C04AC01"},{"n":"ACILESOL","h":"rabeprazol","a":"A02BC04"},{"n":"ACIZALEP","h":"acetilszalicilsav","a":"B01AC06"},{"n":"ACLASTA","h":"zoledronic acid anhydrous","a":"M05BA08"},{"n":"ACLOTIN","h":"ticlopidin","a":"B01AC05"},{"n":"ACTIFED","h":"xilometazolin","a":"R01AB06"
/* … [ 163736 karakter csonkolva — beágyazott adat, lásd a törzsadat-fejezetet ] … */

/* --- renderers --- */
function renderSupp(){const host=$("#suppHost"); if(!host)return; SUPP.forEach(s=>{
  const row=el("div","ros"); const lb=el("div","lb",s.l);
  const yn=el("div","yn"); const no=el("button","no","Nem"),yes=el("button","yes","Szedi");
  no.type="button";yes.type="button";no.setAttribute("aria-pressed","false");yes.setAttribute("aria-pressed","false");
  const det=el("div","det"); const di=el("input"); di.placeholder="dózis (pl. 400 µg/nap)"; det.appendChild(di);
  state.supp[s.id]={on:false,dose:""};
  no.onclick=()=>{state.supp[s.id]={on:false,dose:di.value};no.setAttribute("aria-pressed","true");yes.setAttribute("aria-pressed","false");row.classList.remove("on");generate();};
  yes.onclick=()=>{state.supp[s.id]={on:true,dose:di.value};yes.setAttribute("aria-pressed","true");no.setAttribute("aria-pressed","false");row.classList.add("on");generate();};
  di.oninput=()=>{if(state.supp[s.id]){state.supp[s.id].dose=di.value;generate();}};
  yn.append(no,yes); row.append(lb,yn,det); host.appendChild(row);
});}
function renderLab(){const host=$("#labHost"); if(!host)return; LABF.forEach(l=>{
  const lab=el("label","fld",l.l+" ("+l.u+")"); const inp=el("input"); inp.id=l.id; inp.type="number"; inp.step="any"; inp.placeholder="—";
  inp.addEventListener("input",generate); lab.appendChild(inp); host.appendChild(lab);
});}
function buildPuphaSearch(){
  const ml=$("#medList"); if(!ml||typeof PUPHA==="undefined")return;
  const box=el("div"); box.style.cssText="position:relative;margin-bottom:10px";
  const inp=el("input"); inp.id="puphaSearch"; inp.placeholder="Gyógyszer keresése a PUPHA törzsből (név vagy hatóanyag)…";
  inp.style.cssText="width:100%;background:var(--surface-2);border:1px solid var(--line);border-radius:8px;padding:8px 10px";
  const res=el("div"); res.id="puphaRes";
  res.style.cssText="position:absolute;z-index:30;left:0;right:0;top:100%;background:var(--surface);border:1px solid var(--line);border-radius:8px;max-height:280px;overflow:auto;display:none;box-shadow:var(--shadow)";
  box.append(inp,res); ml.parentNode.insertBefore(box, ml);
  const norm=s=>(s||"").toLowerCase();
  inp.oninput=()=>{const q=norm(inp.value).trim(); if(q.length<2){res.style.display="none";return;}
    const hits=[]; for(let i=0;i<PUPHA.length&&hits.length<40;i++){const d=PUPHA[i]; if(norm(d.n).indexOf(q)!==-1||norm(d.h).indexOf(q)!==-1)hits.push(d);}
    res.innerHTML=""; if(!hits.length){res.style.display="none";return;}
    hits.forEach(d=>{const r=el("div");
      r.style.cssText="padding:7px 10px;border-bottom:1px solid var(--line);cursor:pointer;font-size:12.5px";
      r.innerHTML="<b>"+d.n+"</b>"+(d.h?' <span style=\"color:var(--muted)\">— '+d.h+'</span>':'')+(d.a?' <span class=\"num\">'+d.a+'</span>':'');
      r.onmousedown=(e)=>{e.preventDefault(); addMedRow(d.n+(d.h?" ("+d.h+")":"")); inp.value=""; res.style.display="none";};
      res.appendChild(r);});
    res.style.display="block";
  };
  inp.addEventListener("blur",()=>setTimeout(()=>{res.style.display="none";},160));
}

/* --- risk engine (approximate, illustrative) --- */
function _interp(pts,x){ if(x<=pts[0][0])return pts[0][1];
  for(let i=1;i<pts.length;i++){ if(x<=pts[i][0]){const p0=pts[i-1],p1=pts[i]; return p0[1]+(p1[1]-p0[1])*(x-p0[0])/(p1[0]-p0[0]);} }
  return pts[pts.length-1][1]; }
const _MISC=[[20,.11],[25,.11],[30,.12],[33,.15],[35,.18],[38,.22],[40,.25],[43,.35],[45,.50]];
const _T21_12=[[20,1068],[25,946],[30,626],[31,543],[32,461],[33,383],[34,312],[35,249],[36,196],[37,152],[38,117],[39,89],[40,68],[41,51],[42,38],[43,29],[44,21],[45,16]];
const _T21_TERM=[[20,1527],[25,1352],[30,895],[31,776],[32,659],[33,547],[34,446],[35,356],[36,280],[37,218],[38,167],[39,128],[40,97],[41,73],[42,55],[43,41],[44,30],[45,23]];
function fmtR(p){ if(!p||p<=0)return "—"; const pct=p*100; return (pct>=10?pct.toFixed(0):pct.toFixed(1))+"%  ·  1:"+Math.round(1/p); }
/* FMF a priori (Snijders/FMF) trisomy 21 + NICE preeclampsia & GDM classification */
function computeRisk(st,bmi,sysBP){
  const host=$("#riskOut"); if(!host)return;
  const pos=id=>st[id]&&st[id].v==="pos";
  const age=parseFloat($("#age").value), twin=$("#twins").value!=="no";
  const dmPre=pos("s_dm")||pos("s_t1dm")||pos("s_t2dm")||pos("s_lada");
  const rows=[];
  if(!isNaN(age)){
    const ga=parseFloat($("#ga").value), term=(!isNaN(ga)&&ga>=14);
    rows.push(["21-es triszómia — FMF a priori ("+(term?"terminus":"12. hét")+")",1/_interp(term?_T21_TERM:_T21_12,age),"crit","kombinált teszt/NIPT pontosítja (Snijders/FMF)"]);
    rows.push(["Vetélés (életkori, epidemiológiai)",_interp(_MISC,age),"warn",""]);
  }
  const high=[(((pos("s_htn"))||(sysBP&&sysBP[0]>=140))?"krónikus hypertonia":0),(pos("r_pe")?"korábbi hypertoniás terhesség":0),(pos("s_ren")?"krónikus vesebetegség":0),(pos("s_ai")?"autoimmun betegség":0),(dmPre?"praegestatiós diabetes":0)].filter(Boolean);
  const mod=[((!pos("r_prev"))?"első terhesség":0),((!isNaN(age)&&age>=40)?"életkor ≥40":0),((bmi&&bmi>=35)?"BMI ≥35":0),(pos("f_pe")?"családi preeclampsia":0),(twin?"többes terhesség":0)].filter(Boolean);
  const peCat=(high.length>=1||mod.length>=2)?"MAGAS":(mod.length===1?"közepes":"alacsony");
  rows.push(["Preeclampsia — NICE besorolás",peCat==="MAGAS"?0.17:(peCat==="közepes"?0.08:0.03),peCat==="MAGAS"?"crit":"warn","NICE: "+peCat+(peCat==="MAGAS"?" → aszpirin 75–150 mg/nap a 12. héttől":"")+"  ["+([].concat(high,mod).join(", ")||"nincs tényező")+"]"]);
  const mMAP=parseFloat(($("#map_mom")||{}).value),mUtA=parseFloat(($("#uta_mom")||{}).value),mPlGF=parseFloat(($("#plgf_mom")||{}).value);
  if(!isNaN(mMAP)||!isNaN(mUtA)||!isNaN(mPlGF)){
    const prior=peCat==="MAGAS"?0.17:(peCat==="közepes"?0.08:0.03);
    let z=0; if(!isNaN(mMAP)&&mMAP>0)z+=3.2*Math.log(mMAP); if(!isNaN(mUtA)&&mUtA>0)z+=2.0*Math.log(mUtA); if(!isNaN(mPlGF)&&mPlGF>0)z+=-2.2*Math.log(mPlGF);
    const o=(prior/(1-prior))*Math.exp(z); let padj=Math.min(0.9,Math.max(0.003,o/(1+o)));
    rows.push(["Preeclampsia — FMF-elvű (markerekkel)",padj,padj>=0.15?"crit":"warn","MAP/UtA-PI/PlGF MoM alapján, közelítő log-odds; a validált egyéni kockázat a hivatalos FMF-kalkulátorból (fetalmedicine.org)"]);
  }
  const gdmF=[((bmi&&bmi>30)?"BMI >30":0),(pos("r_gdm")?"korábbi GDM":0),((pos("f_dm")||pos("f_dm1"))?"elsőfokú rokon diabetes":0),(pos("r_macro")?"korábbi makroszómia":0),(pos("s_pcos")?"PCOS":0)].filter(Boolean);
  rows.push(["Gesztációs diabetes — NICE",gdmF.length?0.15:0.04,gdmF.length?"warn":"info","NICE: "+(gdmF.length?"OGTT javallt — "+gdmF.join(", "):"rutin szűrés (nincs kiemelt tényező)")]);
  let ptv=twin?0.50:0.08; if(pos("r_ptb"))ptv+=0.15; if(pos("su_cone"))ptv+=0.10; if(high.length)ptv+=0.05; ptv=Math.min(0.85,ptv);
  rows.push(["Koraszülés (<37. hét, epidemiológiai)",ptv,ptv>=0.30?"crit":"warn",""]);
  let sb=0.004+((bmi&&bmi>=30)?0.002:0)+((bmi&&bmi>=40)?0.004:0)+(dmPre?0.003:0)+((pos("s_htn")||pos("r_pe"))?0.003:0)+(twin?0.006:0)+(pos("r_loss")?0.003:0)+((!isNaN(age)&&age>=40)?0.002:0)+(pos("l_smoke")?0.002:0); sb=Math.min(0.05,sb);
  rows.push(["Halvaszületés (epidemiológiai)",sb,sb>=0.01?"crit":"warn",""]);
  host.innerHTML="";
  rows.forEach(r=>{const it=el("div","titem s-"+r[2]);
    it.appendChild(el("div","tx","<b>"+r[0]+":</b> "+fmtR(r[1])+(r[3]?('<span class=\"src\">'+r[3]+'</span>'):'')));
    host.appendChild(it);});
}

/* --- BNO (PUPHA BNOKODOK) + OENO suggester --- */
const BNO=[
 {k:"O10.0",l:"Terhesség előtt fennálló magasvérnyomás",t:(p,c)=>p("s_htn")},
 {k:"O13",l:"Terhességi magasvérnyomás",t:(p,c)=>c.sysHigh&&!p("s_htn")},
 {k:"O14.9",l:"Prae-eclampsia k.m.n.",t:(p,c)=>c.pe&&!c.peSev},
 {k:"O14.1",l:"Súlyos prae-eclampsia",t:(p,c)=>c.peSev},
 {k:"O24.0",l:"Terhesség előtt fennálló IDDM (T1/LADA)",t:(p,c)=>p("s_t1dm")||p("s_lada")},
 {k:"O24.1",l:"Terhesség előtt fennálló NIDDM (T2)",t:(p,c)=>p("s_t2dm")},
 {k:"O24.4",l:"Gesztációs diabetes (GDM)",t:(p,c)=>p("r_gdm")||c.gdmLab},
 {k:"O30.0",l:"Ikerterhesség",t:(p,c)=>c.twin},
 {k:"O26.6",l:"Májbetegség a terhességben (ICP)",t:(p,c)=>p("s_icp")||c.bileHigh},
 {k:"O26.2",l:"Szokványos vetélés miatt veszélyeztetett terhesség",t:(p,c)=>p("r_loss")},
 {k:"O99.0",l:"Terhességet komplikáló anaemia",t:(p,c)=>c.anemia},
 {k:"O99.2",l:"Terhességet komplikáló elhízás / anyagcsere",t:(p,c)=>c.preg&&c.bmi>=30},
 {k:"E28.2",l:"Polycystás ovarium szindróma (PCOS)",t:(p,c)=>p("s_pcos")},
 {k:"N80.0",l:"A méh endometriosisa",t:(p,c)=>p("s_endo")},
 {k:"N87.9",l:"Cervicalis dysplasia k.m.n.",t:(p,c)=>p("s_hpv")},
 {k:"B97.7",l:"Papillomavírus mint kórok",t:(p,c)=>p("s_hpv")},
 {k:"E66.9",l:"Elhízás k.m.n.",t:(p,c)=>c.bmi>=30},
 {k:"E03.9",l:"Hypothyreosis k.m.n. (pontosítandó: E05 is)",t:(p,c)=>p("s_thy")},
 {k:"G47.3",l:"Alvási apnoe",t:(p,c)=>p("s_osa")},
 {k:"Z83.3",l:"Cukorbaj a család kórtörténetében",t:(p,c)=>p("f_dm")||p("f_dm1")},
 {k:"Z82.4",l:"Keringési betegség a családi anamnézisben",t:(p,c)=>p("f_scd")||p("f_cmp")||p("f_chan")},
 {k:"Z35.8",l:"Veszélyeztetett terhes gondozása",t:(p,c)=>c.preg&&c.highrisk},
];
const OENO_SUGG=[
 {p:"Oralis glükóz tolerancia teszt (OGTT)",t:(p,c)=>c.gdmRisk},
 {p:"Terhességi (szülészeti) ultrahang-vizsgálat",t:(p,c)=>c.preg},
 {p:"Cervix-hossz mérése (transvaginalis UH)",t:(p,c)=>p("r_ptb")||p("su_cone")},
 {p:"Echocardiographia",t:(p,c)=>p("s_htn")||p("s_card")||p("f_cmp")||p("f_scd")||c.peSev},
 {p:"Colposcopia",t:(p,c)=>p("s_hpv")},
 {p:"24 órás vizelet-fehérje meghatározás",t:(p,c)=>c.pe||c.protHigh},
 {p:"Genetikai tanácsadás / magzati mintavétel mérlegelése",t:(p,c)=>p("f_cmp")||p("f_mono")||p("r_loss")||p("r_anom")},
];
function renderBno(st){
  const host=$("#bnoOut"); if(!host)return;
  const pos=id=>st[id]&&st[id].v==="pos";
  const bmi=(()=>{const hh=parseFloat($("#height").value)/100,ww=parseFloat($("#weight").value);return(hh>0&&ww>0)?ww/(hh*hh):0;})();
  const sysBP=(()=>{const m=($("#bp").value||"").match(/(\d{2,3})\s*\/\s*(\d{2,3})/);return m?[+m[1],+m[2]]:null;})();
  const numL=id=>{const v=parseFloat((($("#"+id))||{}).value);return isNaN(v)?null:v;};
  const preg=(typeof STAGE!=="undefined"&&STAGE!=="preivf")||$("#twins").value!=="no"||(parseFloat($("#ga").value)>0);
  const c={preg,twin:$("#twins").value!=="no",bmi,
    sysHigh:sysBP&&(sysBP[0]>=140||sysBP[1]>=90),
    pe:(sysBP&&sysBP[0]>=140)&&((numL("lb_prot")||0)>=0.3),
    peSev:(sysBP&&sysBP[0]>=160)||((numL("lb_plt")||999)<100),
    gdmLab:((numL("lb_hba1c")||0)>=6.5)||((numL("lb_glu")||0)>=7),
    bileHigh:(numL("lb_bile")||0)>=10,anemia:(numL("lb_hgb")||999)<105,
    protHigh:(numL("lb_prot")||0)>=0.3,
    gdmRisk:(bmi>30)||pos("r_gdm")||pos("f_dm")||pos("f_dm1")||pos("s_pcos"),
    highrisk:true};
  const bn=BNO.filter(b=>{try{return b.t(pos,c);}catch(e){return false;}});
  const oe=OENO_SUGG.filter(o=>{try{return o.t(pos,c);}catch(e){return false;}});
  host.innerHTML="";
  if(!bn.length&&!oe.length){host.innerHTML='<div class="empty">A rögzített adatok alapján még nincs kódajánlat.</div>';return;}
  if(bn.length){const box=el("div","tcat"); box.appendChild(el("h4",null,'BNO-kódajánlat <span class="cnt">'+bn.length+'</span>'));
    bn.forEach(b=>{const it=el("div","titem s-info"); it.appendChild(el("div","tx","<b>"+b.k+"</b> — "+b.l)); box.appendChild(it);}); host.appendChild(box);}
  if(oe.length){const box=el("div","tcat"); box.appendChild(el("h4",null,'OENO — javasolt beavatkozás (kód megerősítendő) <span class="cnt">'+oe.length+'</span>'));
    oe.forEach(o=>{const it=el("div","titem s-info"); it.appendChild(el("div","tx",o.p+'<span class="src">OENO-kód megadandó</span>')); box.appendChild(it);}); host.appendChild(box);}
}

/* medication pregnancy-conversion knowledge base */
const MEDDB=[
  {re:/(pril\b|enalapr|ramipr|lisinopr|perindopr|captopr|zofenopr)/i,sev:"crit",cat:"med",act:"ACE-gátló — terhességben KONTRAINDIKÁLT (fetotoxikus). Váltás: methyldopa / labetalol / nifedipin retard; a szer leállítása."},
  {re:/(sartan\b|losart|valsart|candesart|telmisart|irbesart|olmesart)/i,sev:"crit",cat:"med",act:"ARB — terhességben KONTRAINDIKÁLT (fetotoxikus). Váltás: methyldopa / labetalol / nifedipin retard."},
  {re:/(atenolol)/i,sev:"warn",cat:"med",act:"Atenolol — terhességben kerülendő (FGR). Váltás labetalolra."},
  {re:/(statin|atorvast|rosuvast|simvast|pravast|fluvast)/i,sev:"warn",cat:"med",act:"Sztatin — terhességben általában leállítandó (a kockázat/haszon egyénileg mérlegelendő)."},
  {re:/(warfarin|acenocoumar|marfarin|kumadin|syncumar)/i,sev:"crit",cat:"med",act:"Kumarin — teratogén; váltás terápiás LMWH-ra (fogamzás előtt/megállapításkor)."},
  {re:/(rivaroxab|apixab|dabigat|edoxab|xarelto|eliquis)/i,sev:"crit",cat:"med",act:"DOAC — terhességben nem ajánlott; váltás LMWH-ra."},
  {re:/(gliclaz|glimepir|glibencl|gliqui|sulfonilur)/i,sev:"warn",cat:"med",act:"Szulfonilurea — terhességben inzulinra váltás javasolt."},
  {re:/(gliflozin|dapagli|empagli|canagli)/i,sev:"warn",cat:"med",act:"SGLT2-gátló — terhesség alatt leállítandó; inzulin-alapú kezelés."},
  {re:/(glutid|semaglut|liraglut|dulaglut|ozempic|victoza|saxenda|mounjaro|tirzepat)/i,sev:"warn",cat:"med",act:"GLP-1/GIP receptor-agonista — fogamzás előtt leállítandó (megfelelő washout); nem terhesség alatti szer."},
  {re:/(metformin)/i,sev:"info",cat:"med",act:"Metformin — terhességben folytatható lehet, de GDM-ben az inzulin az elsővonal; diabetológiai egyeztetés."},
  {re:/(valpro|depakine|convulex)/i,sev:"crit",cat:"med",act:"Valproát — erősen teratogén; sürgős neurológiai konzílium, alternatívára váltás (ne önállóan)."},
  {re:/(topiram|carbamazep|tegretol|fenito|phenyto)/i,sev:"warn",cat:"med",act:"Antiepileptikum — teratogén kockázat; neurológiai konzílium, folsav-pótlás."},
  {re:/(isotretinoin|acnetin|roaccutan)/i,sev:"crit",cat:"med",act:"Isotretinoin — teratogén, KONTRAINDIKÁLT; azonnali leállítás, fogamzásgátlás-tanácsadás."},
  {re:/(methotrex|metotrex)/i,sev:"crit",cat:"med",act:"Methotrexát — teratogén, KONTRAINDIKÁLT; leállítás, reumatológiai/onkológiai egyeztetés."},
  {re:/(mycophenol|cellcept)/i,sev:"crit",cat:"med",act:"Mycophenolate — teratogén, KONTRAINDIKÁLT; transzplant/immunológiai egyeztetés, váltás."},
  {re:/(lithium|litium)/i,sev:"warn",cat:"psy",act:"Lítium — kardiális malformáció (Ebstein) kockázata; pszichiátriai konzílium, NE önállóan leállítani."},
  {re:/(paroxet)/i,sev:"warn",cat:"psy",act:"Paroxetin — kardiális malformáció-kockázat; pszichiátriai felülvizsgálat."},
  {re:/(escitalo|citalo|sertralin|fluoxet|venlafax|duloxet|ssri|szsri)/i,sev:"info",cat:"psy",act:"Antidepresszáns — a kezelést szakorvosi (pszichiátriai) vizsgálatig fenntartani; ne hirtelen leállítani."},
  {re:/(alprazol|clonazep|diazep|benzodiaz)/i,sev:"warn",cat:"psy",act:"Benzodiazepin — pszichiátriai felülvizsgálat; a kockázat/haszon mérlegelése."},
  {re:/(ibupro|diclofen|naproxe|nsaid|ketoprofe)/i,sev:"warn",cat:"med",act:"NSAID — terhességben kerülendő (különösen a 20/30. hét után); paracetamol előnyben."},
  {re:/(spironolact)/i,sev:"warn",cat:"med",act:"Spironolakton — antiandrogén hatás; terhességben kerülendő."},
  {re:/(doxycyclin|tetracyclin)/i,sev:"warn",cat:"med",act:"Tetraciklin — a 2–3. trimeszterben kontraindikált."},
];

/* ---------- render helpers ---------- */
function rosRow(item){
  const row=el("div","ros"); row.dataset.id=item.id;
  const lb=el("div","lb",item.l); if(item.rf) lb.appendChild(el("span","rf"," VÖRÖS ZÁSZLÓ".trim()));
  const yn=el("div","yn");
  const no=el("button","no","Nem"), yes=el("button","yes","Igen"), unk=el("button","unk","Nem tudom");
  no.type="button"; yes.type="button"; unk.type="button";
  no.setAttribute("aria-pressed","false"); yes.setAttribute("aria-pressed","false"); unk.setAttribute("aria-pressed","false");
  unk.title="A beteg nem tudja / az adat nem ismert. Ez NEM azonos a negatív válasszal, és nem azonos a kitöltetlen mezővel.";
  const det=el("div","det"); const di=el("input"); di.placeholder="részletek (opcionális) — pl. rokon, életkor, dg."; det.appendChild(di);
  const press=(a,b,c)=>{a.setAttribute("aria-pressed","true");b.setAttribute("aria-pressed","false");c.setAttribute("aria-pressed","false");};
  no.onclick=()=>{state.ros[item.id]={v:"neg"};press(no,yes,unk);row.classList.remove("on");row.classList.remove("unkon");generate();};
  yes.onclick=()=>{state.ros[item.id]={v:"pos",det:di.value};press(yes,no,unk);row.classList.add("on");row.classList.remove("unkon");generate();};
  unk.onclick=()=>{state.ros[item.id]={v:"unk",det:di.value};press(unk,no,yes);row.classList.remove("on");row.classList.add("unkon");generate();};
  di.oninput=()=>{if(state.ros[item.id]&&(state.ros[item.id].v==="pos"||state.ros[item.id].v==="unk")){state.ros[item.id].det=di.value;generate();}};
  yn.append(no,yes,unk); row.append(lb,yn,det); return row;
}
function renderRosList(host,arr){arr.forEach(i=>host.appendChild(rosRow(i)));}
function renderGrouped(host,groups){
  groups.forEach(gr=>{
    const wrap=el("div","rosgrp");
    const gh=el("div","gh"); gh.append(el("b",null,gr.g));
    const an=el("button","allneg","Összes negatív"); an.type="button";
    an.onclick=()=>{gr.items.forEach(it=>{const r=host.querySelector('.ros[data-id="'+it.id+'"]');if(r&&!(state.ros[it.id])){r.querySelector(".no").click();}else if(r&&state.ros[it.id]&&state.ros[it.id].v!=="pos"&&state.ros[it.id].v!=="unk"){r.querySelector(".no").click();}});};
    gh.append(an); wrap.append(gh);
    gr.items.forEach(it=>wrap.appendChild(rosRow(it)));
    host.appendChild(wrap);
  });
}
function famRow(item){return rosRow(item);}
/* v16: endokrin sor + kiemelt terhessegi vonal */
function renderEndoList(host,arr){
  if(!host) return;
  arr.forEach(function(i){
    var wrap=el('div','endowrap');
    wrap.appendChild(rosRow(i));
    wrap.appendChild(el('div','pregline','<b>Terhességi vonal:</b> '+i.preg));
    host.appendChild(wrap);
  });
}

/* meds */
function addMedRow(val){
  const row=el("div"); row.className="medwrap";
  const line=el("div","medrow");
  const inp=el("input"); inp.placeholder="pl. Enalapril 10 mg"; if(val)inp.value=val;
  const del=el("button","del","✕"); del.type="button"; del.setAttribute("aria-label","Törlés");
  const flags=el("div");
  const scan=()=>{flags.innerHTML=""; const hits=matchMed(inp.value); hits.forEach(h=>{const f=el("div","flagline flag-"+h.sev, "<span>▲</span><span>"+h.act+"</span>");flags.appendChild(f);}); syncMeds(); generate();};
  inp.oninput=scan; del.onclick=()=>{row.remove();syncMeds();generate();};
  line.append(inp,del); row.append(line,flags); $("#medList").appendChild(row);
  if(val)scan();
}
function matchMed(name){const n=(name||"").trim(); if(!n)return[]; return MEDDB.filter(m=>m.re.test(n));}
function syncMeds(){state.meds=$$("#medList .medrow input").map(i=>i.value.trim()).filter(Boolean);}

/* ---------- generation ---------- */
function calcBMI(){
  const hc=parseFloat($("#height").value), w=parseFloat($("#weight").value), h=hc/100;
  const be=$("#bsa");
  if(hc>0&&w>0){ if(be)be.value=Math.sqrt(hc*w/3600).toFixed(2)+" m²"; } else if(be){be.value="";}
  if(h>0&&w>0){const b=w/(h*h); $("#bmi").value=b.toFixed(1)+" ("+bmiCat(b)+")"; return b;}
  $("#bmi").value=""; return null;
}
function bmiCat(b){return b<18.5?"sovány":b<25?"normál":b<30?"túlsúly":b<35?"I. o. obesitas":b<40?"II. o. obesitas":"III. o. obesitas";}
const posList=arr=>arr.filter(i=>state.ros[i.id]&&state.ros[i.id].v==="pos");
const negList=arr=>arr.filter(i=>state.ros[i.id]&&state.ros[i.id].v==="neg");
function labelWithDet(i){const s=state.ros[i.id]; return i.l+(s&&s.det?(" ("+s.det+")"):"");}
function flatSystems(){return SYSTEMS.flatMap(g=>g.items);}

function generate(){
  const bmi=calcBMI();
  const stageName={preivf:"Pre-IVF / prekoncepcionális",antenatal:"Terhesgondozás (járóbeteg)",inpatient:"Terhespatológia (fekvőbeteg)"}[STAGE];
  const now=new Date();
  const ds=now.getFullYear()+"."+String(now.getMonth()+1).padStart(2,"0")+"."+String(now.getDate()).padStart(2,"0")+". "+String(now.getHours()).padStart(2,"0")+":"+String(now.getMinutes()).padStart(2,"0");
  const age=$("#age").value, ht=$("#height").value, wt=$("#weight").value, ppw=$("#ppweight").value, bp=$("#bp").value.trim();
  const conception={spontan:"spontán",ovind:"ovuláció-indukció",insem:"inszemináció (IUI)",ivf:"IVF",icsi:"ICSI",fet:"fagyasztott embrió-transzfer (FET)",donor:"donor gaméta"}[$("#conception").value];
  const twins={no:"egyes terhesség",dcda:"DCDA ikerterhesség",mcda:"MCDA ikerterhesség",mcma:"MCMA ikerterhesség"}[$("#twins").value];
  const ga=$("#ga").value;

  /* ---- structured anamnesis text ---- */
  let A=[];
  A.push("STRUKTURÁLT ANAMNÉZIS — döntéstámogató vázlat (orvosi ellenőrzést igényel)");
  A.push("Felvétel típusa: "+stageName+"   |   Kelt: "+ds);
  A.push("Forrás: a beteg elmondása és a rendelkezésre bocsátott dokumentumok alapján rögzítve.");
  A.push("".padEnd(64,"─"));
  let al=[];
  if(age)al.push(age+" éves");
  al.push(conception+" fogantatás"); if($("#twins").value!=="no")al.push(twins);
  if(ga)al.push(ga+". gestatiós hét");
  if(ht&&wt)al.push("testmagasság "+ht+" cm, testsúly "+wt+" kg, BMI "+(bmi?bmi.toFixed(1):"—")+(bmi?(" ("+bmiCat(bmi)+")"):""));
  if(ht&&wt)al.push("testfelület "+Math.sqrt(parseFloat(ht)*parseFloat(wt)/3600).toFixed(2)+" m²");
  if(ppw)al.push("terhesség előtti súly "+ppw+" kg");
  if(bp)al.push("vérnyomás "+bp+" Hgmm");
  A.push("ALAPADATOK: "+(al.length?al.join("; ")+".":"nem került rögzítésre."));

  // complaints
  const cp=posList(COMPLAINT), cn=negList(COMPLAINT), ctext=$("#complaintText").value.trim();
  if(STAGE!=="preivf"||cp.length||ctext){
    let s="JELEN PANASZOK: ";
    s+= cp.length? cp.map(labelWithDet).join(", ")+"." : "érdemi panaszt nem jelez.";
    if(ctext)s+=" "+ctext+(/[.!?]$/.test(ctext)?"":".");
    if(cn.length)s+=" Tagadja: "+cn.map(i=>i.l.toLowerCase()).join(", ")+".";
    A.push(s);
  }

  // systems
  const sys=flatSystems(); const sp=posList(sys), sn=negList(sys);
  let sline="KÓRELŐZMÉNY: ";
  sline+= sp.length? sp.map(labelWithDet).join("; ")+"." : "érdemi belgyógyászati előzményt nem említ.";
  if(sn.length)sline+=" Tagadja / nem ismert: "+sn.map(i=>i.l.toLowerCase()).join(", ")+".";
  A.push(sline);

  // meds
  syncMeds();
  if(state.meds.length){
    A.push("GYÓGYSZERELÉS: "+state.meds.join(", ")+".");
    const flagged=state.meds.filter(m=>matchMed(m).length);
    if(flagged.length)A.push("  (Terhesség-kompatibilitási jelzés a teendőlistában: "+flagged.join(", ")+".)");
  } else A.push("GYÓGYSZERELÉS: rendszeres gyógyszert nem szed / nem nyilatkozott.");
  const allergy=$("#allergy").value.trim();
  A.push("ALLERGIA: "+(allergy||"nem ismert / nem nyilatkozott")+".");

  // repro
  const rp=posList(REPRO), rn=negList(REPRO);
  try{
    const gv=id=>{const e=document.getElementById(id); const n=e?parseInt(e.value,10):NaN; return isFinite(n)?n:null;};
    const gg=gv("gp_g"),pp=gv("gp_p"),as_=gv("gp_absp"),ai=gv("gp_abind"),ec=gv("gp_ect"),li=gv("gp_liv");
    if([gg,pp,as_,ai,ec,li].some(x=>x!=null)){
      const bits=[];
      if(gg!=null)bits.push("gravida "+gg);
      if(pp!=null)bits.push("para "+pp);
      if(as_!=null)bits.push("spontán vetélés "+as_);
      if(ai!=null)bits.push("művi megszakítás "+ai);
      if(ec!=null)bits.push("extrauterin "+ec);
      if(li!=null)bits.push("élő gyermek "+li);
      A.push("TERHESSÉGI ÖSSZEGZÉS: "+bits.join(", ")+".");
    }
  }catch(e){}
  let rl="REPRODUKCIÓS / SZÜLÉSZETI ANAMNÉZIS: ";
  rl+= rp.length? rp.map(labelWithDet).join("; ")+"." : "érdemi szülészeti előzmény nem ismert.";
  if(rn.length)rl+=" Tagadja: "+rn.map(i=>i.l.toLowerCase()).join(", ")+".";
  A.push(rl);

  // family
  const fp=FAMILY.filter(i=>state.ros[i.id]&&state.ros[i.id].v==="pos");
  const fn=FAMILY.filter(i=>state.ros[i.id]&&state.ros[i.id].v==="neg");
  let fl="CSALÁDI ANAMNÉZIS (vér szerinti rokonok): ";
  fl+= fp.length? fp.map(labelWithDet).join("; ")+"." : "az célzottan kérdezett tételekre negatív.";
  if(fn.length)fl+=" Célzottan tagadva: "+fn.map(i=>i.l.toLowerCase().replace(" vér szerinti rokonnál","")).join(", ")+".";
  const fu=FAMILY.filter(i=>state.ros[i.id]&&state.ros[i.id].v==="unk");
  if(fu.length)fl+=" NEM ISMERT (a beteg nem tudja, aktív kizárás nem történt): "+fu.map(i=>i.l.toLowerCase().replace(" vér szerinti rokonnál","")).join(", ")+".";
  A.push(fl);

  // endokrin (v16)
  try{
    const ep=ENDO.filter(i=>state.ros[i.id]&&state.ros[i.id].v==="pos");
    const eu=ENDO.filter(i=>state.ros[i.id]&&state.ros[i.id].v==="unk");
    if(ep.length||eu.length){
      let ez="ENDOKRIN ANAMNÉZIS: ";
      ez+= ep.length? ep.map(i=>i.l).join("; ")+"." : "érdemi endokrin előzmény nem ismert.";
      if(eu.length)ez+=" NEM ISMERT: "+eu.map(i=>i.l).join(", ")+".";
      if(ep.length)ez+=" A terhességi teendők tételesen a teendőlistában.";
      A.push(ez);
    }
  }catch(e){}

  // lifestyle
  const lp=posList(LIFE), ln=negList(LIFE);
  A.push("ÉLETMÓD: "+(lp.length?lp.map(labelWithDet).join(", ")+".":"")+(ln.length?" Tagadja: "+ln.map(i=>i.l.toLowerCase()).join(", ")+".":(lp.length?"":"nem nyilatkozott.")));

  // nutrition / fluid
  const dietv=$("#diet").value.trim(), fluidv=$("#fluid").value.trim();
  if(dietv||fluidv){const np=[]; if(dietv)np.push("étrend: "+dietv); if(fluidv)np.push("napi folyadékbevitel: "+fluidv+" l"); A.push("TÁPLÁLKOZÁS / FOLYADÉK: "+np.join("; ")+".");}

  // surgery / supplementation / labs (v2)
  const surgP=SURG.filter(i=>state.ros[i.id]&&state.ros[i.id].v==="pos");
  if(surgP.length) A.push("MŰTÉTI ELŐZMÉNYEK: "+surgP.map(labelWithDet).join("; ")+".");
  const suppP=SUPP.filter(s=>state.supp[s.id]&&(state.supp[s.id].on||state.supp[s.id].dose));
  if(suppP.length) A.push("SZUPPLEMENTÁCIÓ: "+suppP.map(s=>{const x=state.supp[s.id];return s.l+(x.on?"":" (nem szedi)")+(x.dose?(" — "+x.dose):"");}).join("; ")+".");
  const labP=LABF.map(l=>({l,v:(($("#"+l.id)||{}).value||"").trim()})).filter(x=>x.v);
  if(labP.length) A.push("LABOR: "+labP.map(x=>x.l.l+" "+x.v+" "+x.l.u).join("; ")+".");

  // prior
  const prior=$("#prior").value.trim();
  if(prior){A.push("".padEnd(64,"─"));A.push("BEILLESZTETT KORÁBBI DOKUMENTÁCIÓ (a beteg/rendszer által átadva, szó szerint):");A.push(prior);}

  A.push("".padEnd(64,"─"));
  A.push("NYILATKOZAT: A fenti adatok a beteg közlésén és az átadott dokumentumokon alapulnak. A vázlat klinikai");
  A.push("döntéstámogató célú, a szakorvosi értékelést nem helyettesíti. Ellenőrizte és kiegészítette: ……………………  (orvos)");
  A.push("A beteg a felvett adatokat megismerte: ……………………  (aláírás)   Dátum: "+ds);

  $("#anamOut").textContent=A.join("\n");

  /* ---- physician to-do ---- */
  const T={med:[],ref:[],lab:[],obs:[],obes:[],fu:[],gen:[],adm:[],deliv:[],prof:[]};
  const add=(cat,tx,src,sev="info")=>T[cat].push({tx,src,sev});
  const isPreg = STAGE!=="preivf" || $("#conception").value!=="spontan";

  // medications
  state.meds.forEach(m=>{matchMed(m).forEach(h=>{
    const cat=h.cat==="psy"?"ref":"med";
    add(cat, (h.cat==="psy"?"Pszichiátriai felülvizsgálat: ":"")+h.act, "gyógyszer: "+m, h.sev);
  });});

  // BMI / obesitology
  if(bmi){
    if(bmi>=30) add("obes","Obesitológiai + dietetikai tanácsadás; strukturált életmód-intervenció.","BMI "+bmi.toFixed(1),"warn");
    if(bmi>=40){
      add("obes","III. fokú obesitas: prekoncepcionális testsúly-optimalizálás mérlegelése (dietetika, bariátria/GLP-1RA az IVF ELŐTT, megfelelő washout-tal).","BMI "+bmi.toFixed(1),"crit");
      add("fu","Fokozott terhesgondozás (magas rizikó): korai MDT-terv, aneszteziológiai és képalkotási korlátok dokumentálása.","BMI "+bmi.toFixed(1),"warn");
    }
    if(bmi>=30) add("lab","OGTT elvégzése; korai vérnyomás-monitorozás.","obesitas","info");
    if(bmi>=30 && isPreg) add("med","Alacsony dózisú aszpirin (100–150 mg) preeclampsia-profilaxis mérlegelése — a 16. hét ELŐTT.","preeclampsia-rizikó","warn");
    (function(){var tw=document.querySelector("#twins");
      if(tw&&tw.value&&tw.value!=="no"){
        add("med","Alacsony dózisú aszpirin (100–150 mg/nap) preeclampsia-profilaxis — a többes terhesség ÖNMAGÁBAN magas rizikójú tényező (ACOG/USPSTF, NICE); a 16. hét ELŐTT megkezdve.","ikerterhesség","warn");
        add("ref","Ikerterhesség: MFM (magas rizikójú szülészeti) gondozási útvonal; chorionicitás dokumentálása.","ikerterhesség","warn");
      }})();
  }

  // BP / chronic HT
  const st=state.ros;
  const sysBP=(()=>{const m=bp.match(/(\d{2,3})\s*\/\s*(\d{2,3})/);return m?[+m[1],+m[2]]:null;})();
  if(st.s_htn&&st.s_htn.v==="pos" || (sysBP&&(sysBP[0]>=140||sysBP[1]>=90))){
    add("ref","Kardiológiai konzílium; terhességi kardiovaszkuláris rizikóbesorolás (mWHO).","hypertonia","warn");
    add("med","Terhességgel kompatibilis antihypertenzív beállítás (methyldopa / labetalol / nifedipin retard); ACE-gátló/ARB tilos.","hypertonia","warn");
    add("lab","Kiindulási EKG; vizelet-fehérje; szükség szerint echokardiográfia, NT-proBNP.","hypertonia","info");
  }
  if(sysBP&&(sysBP[0]>=160||sysBP[1]>=110)){
    add("adm","Súlyos vérnyomás (≥160/110): sürgős értékelés, akut antihypertenzív kezelés, terhespatológiai felvétel mérlegelése.","RR "+bp,"crit");
  }

  // diabetes
  if(st.s_dm&&st.s_dm.v==="pos"){
    add("ref","Diabetológiai konzílium; terhesség alatt inzulin-alapú kezelés, orális szerek felülvizsgálata.","diabetes","warn");
    add("lab","HbA1c, OGTT/vércukor-profil; szemészet, vesefunkció szükség szerint.","diabetes","info");
  }
  // thyroid/pcos
  if(st.s_thy&&st.s_thy.v==="pos") add("lab","Pajzsmirigy-funkció (TSH) ellenőrzése; endokrinológiai egyeztetés szükség szerint.","pajzsmirigy","info");

  // renal / hepatic / ICP
  if(st.s_ren&&st.s_ren.v==="pos"){add("ref","Nefrológiai konzílium.","vesebetegség","warn");add("lab","Kreatinin/eGFR, 24 órás vizelet-fehérje, vizelet-üledék.","vesebetegség","info");}
  if(st.s_icp&&st.s_icp.v==="pos"){add("lab","Epesav- és májfunkció-monitorozás.","ICP előzmény","warn");add("med","Intrahepaticus cholestasis esetén ursodeoxycholsav (UDCA) az elsővonal.","ICP előzmény","info");}

  // OSA
  if(st.s_osa&&st.s_osa.v==="pos"){add("ref","Alvásvizsgálat (poligráfia) OSA irányában; szükség szerint pulmonológia.","alvási apnoe","info");add("fu","Fokozott vérnyomás- és preeclampsia-figyelés (OSA rontja a HDP-kimenetelt).","alvási apnoe","warn");}

  // thrombophilia / autoimmun
  if(st.s_thr&&st.s_thr.v==="pos"){add("ref","Haematológiai konzílium (thrombophilia).","thrombosis/thrombophilia","warn");add("med","Súly-alapú LMWH-thromboprofilaxis mérlegelése a rizikó szerint.","thrombophilia","warn");}
  if(st.s_ai&&st.s_ai.v==="pos"){add("ref","Immunológiai/reumatológiai konzílium (SLE/APS).","autoimmun","warn");add("med","APS esetén ASA ± LMWH a protokoll szerint.","APS","warn");}

  // neuro / psychiatry
  if(st.s_epi&&st.s_epi.v==="pos") add("ref","Neurológiai konzílium; antiepileptikum terhesség-kompatibilitásának felülvizsgálata; folsav.","epilepszia","warn");
  if(st.s_psy&&st.s_psy.v==="pos") add("ref","Pszichiátriai konzílium: a kezelés a SZAKORVOSI vizsgálatig fenntartandó, önállóan nem módosítandó.","pszichiátriai betegség","warn");

  // connective tissue → genetics+cardio
  if(st.s_ct&&st.s_ct.v==="pos"){add("gen","Klinikai genetikai konzílium (Marfan/EDS); aorta-érintettség kizárása.","kötőszöveti betegség","warn");add("ref","Kardiológia (aorta-imaging).","kötőszöveti betegség","warn");}
  if(st.s_onc&&st.s_onc.v==="pos") add("gen","Onkogenetikai tanácsadás (örökletes daganatszindróma).","onkológiai előzmény","warn");

  // repro red flags
  if(st.r_loss&&st.r_loss.v==="pos"){add("gen","Ismételt vetélés kivizsgálása: a pár kariotípusa/microarray; genetikai tanácsadás.","ismételt vetélés","warn");add("lab","Antifoszfolipid- és thrombophilia-szűrés.","ismételt vetélés","info");}
  if(st.r_anom&&st.r_anom.v==="pos") add("gen","Korábbi congenitalis rendellenesség: genetikai tanácsadás, célzott magzati diagnosztika terve.","korábbi malformáció","warn");
  if(st.r_ectop&&st.r_ectop.v==="pos"){
    add("lab","Korai (5–6. hét) ultrahang a terhesség méhen belüli elhelyezkedésének igazolására; szérum-hCG követés, amíg a lokalizáció nem egyértelmű.","korábbi extrauterin terhesség","crit");
    add("ref","Ismételt extrauterin terhesség fokozott kockázata — korai szülészeti kontroll.","korábbi extrauterin terhesség","warn");
  }
  if(st.r_mola&&st.r_mola.v==="pos"){
    add("lab","Molaterhesség után: hCG-követés a negatívvá válásig, majd a protokoll szerinti utánkövetés; korai ultrahang az aktuális terhességben.","korábbi molaterhesség","crit");
    add("gen","Ismétlődő mola esetén genetikai (NLRP7/KHDC3L) tanácsadás mérlegelése.","korábbi molaterhesség","info");
  }
  if((st.r_cur&&st.r_cur.v==="pos")||(st.r_abind&&st.r_abind.v==="pos")||(st.r_abmis&&st.r_abmis.v==="pos")){
    add("lab","Korábbi méhűri beavatkozás: a placenta tapadási helyének célzott vizsgálata (placenta praevia és accreta spektrum), valamint az endometrium értékelése (Asherman-szindróma lehetősége).","korábbi méhűri beavatkozás","warn");
  }
  if(st.r_absp&&st.r_absp.v==="pos"){
    add("lab","Vetélés az anamnézisben: Rh-vércsoport és ellenanyagszűrés ellenőrzése; RhD-negatív anyánál az anti-D profilaxis dokumentálása.","korábbi vetélés","info");
  }
  if(st.r_pe&&st.r_pe.v==="pos"){add("med","Korábbi preeclampsia: aszpirin-profilaxis a 16. hét előtt.","korábbi preeclampsia","warn");add("fu","Fokozott vérnyomás- és proteinuria-követés.","korábbi preeclampsia","info");}
  if(st.r_gdm&&st.r_gdm.v==="pos") add("lab","Korai OGTT (korábbi GDM).","korábbi GDM","info");
  if(st.r_ptb&&st.r_ptb.v==="pos") add("fu","Koraszülés-megelőzési terv; cervix-hossz követése.","korábbi koraszülés/FGR","info");

  // family genetic red flags
  const famSCD = st.f_scd&&st.f_scd.v==="pos";
  const famCMP = st.f_cmp&&st.f_cmp.v==="pos";
  const famChan = st.f_chan&&st.f_chan.v==="pos";
  const famUCard = (st.f_ucard&&st.f_ucard.v==="pos")||(st.f_udeath&&st.f_udeath.v==="pos")||(st.f_umeta&&st.f_umeta.v==="pos");
  if(famSCD||famCMP||famChan||famUCard){
    add("gen","Kardiogenetikai tanácsadás + célzott génpanel (cardiomyopathia/aritmia: pl. ARVC/DCM/HCM/channelopathia); kaszkádszűrés a rokonoknál.","családi hirtelen szívhalál / öröklődő CMP","crit");
    add("lab","A betegnél kiindulási EKG + echokardiográfia + NT-proBNP.","familiáris kardiológiai terheltség","warn");
    add("ref","Kardiológiai gondozásba vétel; szülés-terv egyeztetése.","familiáris kardiológiai terheltség","warn");
    if(famUCard&&!(famSCD||famCMP||famChan)) add("gen","A családi kardiális adat laikus leíráson alapul: az eredeti orvosi dokumentum (zárójelentés, boncjegyzőkönyv, halotti bizonyítvány) beszerzése javasolt a fenotípus tisztázásához.","tisztázatlan családi kardiális adat","crit");
  }
  if(st.f_chd&&st.f_chd.v==="pos") add("lab","Részletes magzati echokardiográfia (családi CHD).","családi congenitalis szívhiba","info");
  try{ ENDO.forEach(function(e){ if(st[e.id]&&st[e.id].v==="pos") add(e.cat||"med", e.preg, e.l, e.sev||"warn"); }); }catch(e){}
  if(st.f_dm1&&st.f_dm1.v==="pos") add("lab","Korai OGTT mérlegelése (családi cukorbetegség, I. fokú rokon).","családi diabetes","info");
  if((st.f_thr&&st.f_thr.v==="pos")||(st.f_uhaem&&st.f_uhaem.v==="pos")){add("lab","Thrombophilia-szűrés.","családi thrombosis","info");add("med","LMWH-profilaxis mérlegelése.","családi thrombosis","info");}
  if((st.f_mono&&st.f_mono.v==="pos")||(st.f_cons&&st.f_cons.v==="pos")||(st.f_ethn&&st.f_ethn.v==="pos")||(st.f_canc&&st.f_canc.v==="pos")||(st.f_dev&&st.f_dev.v==="pos")||(st.f_uneuro&&st.f_uneuro.v==="pos")||(st.f_ucanc&&st.f_ucanc.v==="pos")||(st.f_usyn&&st.f_usyn.v==="pos")||(st.f_uren&&st.f_uren.v==="pos")){
    add("gen","Klinikai genetikai tanácsadás + expanded carrier screening (a párnak); indokolt esetben PGT-M/PGT-A mérlegelése.","családi genetikai terheltség","warn");
  }

  // severe features (inpatient)
  if(STAGE==="inpatient"){
    const sev=(st.c_dysp&&st.c_dysp.v==="pos")||(st.c_epi&&st.c_epi.v==="pos")||(sysBP&&(sysBP[0]>=160||sysBP[1]>=110));
    if(sev) add("adm","Súlyos jellemzők gyanúja: terhespatológiai (fekvő) obszerváció, súlyos preeclampsia protokoll, MgSO4 mérlegelése (<32. hét neuroprotekció + eclampsia-profilaxis).","súlyos jellemzők","crit");
    add("obs","Napi RR-, testsúly-, diurézis- és labor-trend követés (máj, thrombocyta, LDH, albumin, proteinuria, kardiális biomarker).","fekvőbeteg-obszerváció","info");
  }

  // delivery planning
  if($("#twins").value.startsWith("mc")) add("deliv","Monochorionicitás: szoros magzati monitorozás; szülés-mód és -időzítés protokoll szerint.","monochorialis iker","warn");
  if(famSCD||famCMP) add("deliv","Kardiológiai szülés-terv (anesztéziai egyeztetés); szükség szerint programozott, ellenőrzött körülmények közötti szülés.","kardiológiai rizikó","info");

  // generic follow-up / screening plan by stage
  if(STAGE==="preivf"){
    add("prof","Prekoncepcionális folsav (0,4–5 mg a rizikó szerint), rubeola/varicella szerológia és oltás-pótlás, D-vitamin.","prekoncepció","info");
    add("gen","A genetikai szűrés lehetőségének felajánlása és dokumentálása (expanded carrier screening).","prekoncepció","info");
  }
  if(STAGE==="antenatal"){
    add("prof","Szűrővizsgálati naptár: kombinált szűrés/NIPT, morfológiai UH, OGTT (24–28. hét), rizikó szerinti magzati echo.","terhesgondozás","info");
  }

  // v2 extra to-do: gyn/endo, diabetes types, supplementation monitoring, labs
  const P=id=>st[id]&&st[id].v==="pos";
  if(P("s_pcos")) T.lab.push({tx:"PCOS / PMOS: korai OGTT és metabolikus szűrés; fokozott GDM-figyelem.",src:"PCOS/PMOS",sev:"info"});
  if(P("s_endo")) T.fu.push({tx:"Endometriosis / adenomyosis: fokozott preeclampsia/placentációs figyelem; fájdalomkezelési terv.",src:"endometriosis",sev:"info"});
  if(P("s_hpv")) T.ref.push({tx:"HPV-pozitivitás / kóros cytológia: kolposzkópiás követés a terhességi protokoll szerint.",src:"HPV",sev:"info"});
  if(P("s_infert")) T.fu.push({tx:"ART / meddőségi kezelés utáni terhesség: fokozott korai monitorozás (PE, GDM, ikret is beleértve).",src:"meddőségi kezelés",sev:"info"});
  if(P("s_t1dm")||P("s_t2dm")||P("s_lada")) T.ref.push({tx:"Pregestatiós diabetes (T1DM / T2DM / LADA): diabetológiai gondozás, szoros glykaemiás kontroll, retinopathia/nephropathia szűrés; aszpirin- és folsav-optimalizálás.",src:"pregestatiós diabetes",sev:"warn"});
  if(P("su_cone")) T.fu.push({tx:"Cervix-conisatio/LLETZ előzmény: cervix-hossz követése (koraszülés-rizikó).",src:"korábbi conisatio",sev:"info"});
  if(P("su_cs")||P("su_myom")) T.deliv.push({tx:"Korábbi méhfali műtét: szülés-mód és -időzítés egyeztetése (ruptura-kockázat mérlegelése).",src:"korábbi méhműtét",sev:"info"});
  // supplementation monitoring
  const miss=id=>!(state.supp[id]&&state.supp[id].on);
  if(miss("sp_folate")) T.gen.push({tx:"Folsav-pótlás indítása/megerősítése (400 µg/nap; magas rizikó vagy előzmény esetén 5 mg) — ideálisan a fogamzás előtt legalább 1 hónappal.",src:"szupplementáció",sev:"warn"});
  if(miss("sp_d")) T.lab.push({tx:"D-vitamin-státusz ellenőrzése és pótlás mérlegelése (800–2000 NE/nap).",src:"szupplementáció",sev:"info"});
  if(miss("sp_iod")) T.med.push({tx:"Jód-pótlás mérlegelése (150–200 µg/nap) terhességben/szoptatásban.",src:"szupplementáció",sev:"info"});
  if(!miss("sp_multi")) T.prof.push({tx:"Terhes-multivitamin szedése — ellenőrizd, hogy a retinol (A-vitamin) dózisa a biztonságos tartományban van.",src:"multivitamin",sev:"info"});
  // labs auto-flags
  const numL=id=>{const v=parseFloat((($("#"+id))||{}).value); return isNaN(v)?null:v;};
  const plt=numL("lb_plt"),ldh=numL("lb_ldh"),alb=numL("lb_alb"),prot=numL("lb_prot"),hba=numL("lb_hba1c"),bile=numL("lb_bile"),tsh=numL("lb_tsh"),hgb=numL("lb_hgb"),glu=numL("lb_glu");
  if(plt!==null&&plt<100) T.adm.push({tx:"Thrombocytopenia (<100 ×10⁹/l): HELLP/preeclampsia irányú kivizsgálás, ismételt vérkép, terhespatológiai értékelés.",src:"labor: thr "+plt,sev:"crit"});
  if(ldh!==null&&ldh>600) T.lab.push({tx:"Emelkedett LDH (>600 U/l): haemolysis/HELLP-panel (haptoglobin, kenet, bilirubin).",src:"labor: LDH "+ldh,sev:"warn"});
  if(prot!==null&&prot>=0.3) T.lab.push({tx:"Proteinuria (≥0,3 g/nap): preeclampsia irányú értékelés (PlGF/sFlt-1 mérlegelése).",src:"labor: prot "+prot,sev:"warn"});
  if(alb!==null&&alb<25) T.lab.push({tx:"Hypalbuminaemia (<25 g/l): oedema/serositis és tápláltsági-volumen értékelés.",src:"labor: alb "+alb,sev:"info"});
  if((hba!==null&&hba>=6.5)||(glu!==null&&glu>=7)) T.ref.push({tx:"Kóros glykaemia (HbA1c ≥6,5% vagy éhomi ≥7): diabetológiai konzílium, kezelés indítása.",src:"labor: glykaemia",sev:"warn"});
  if(bile!==null&&bile>=10) T.med.push({tx:"Emelkedett epesav (≥10 µmol/l): ICP irányú kezelés (UDCA a pruritusra), magzati monitorozás.",src:"labor: epesav "+bile,sev:"warn"});
  if(tsh!==null&&tsh>4) T.lab.push({tx:"Emelkedett TSH: pajzsmirigy-pótlás mérlegelése, endokrinológia.",src:"labor: TSH "+tsh,sev:"info"});
  if(hgb!==null&&hgb<105) T.lab.push({tx:"Anaemia (Hgb <105 g/l): vaspótlás és kivizsgálás.",src:"labor: Hgb "+hgb,sev:"info"});

  try{ computeRisk(st, bmi, sysBP); }catch(e){}
  try{ renderBno(st); }catch(e){}
  renderTodo(T);

  // risk pill
  const crit=Object.values(T).flat().filter(x=>x.sev==="crit").length;
  const warn=Object.values(T).flat().filter(x=>x.sev==="warn").length;
  const rp2=$("#riskPill");
  if(crit){rp2.textContent="Rizikó: magas ("+crit+" kritikus)";rp2.style.color="var(--crit)";rp2.style.borderColor="var(--crit)";}
  else if(warn){rp2.textContent="Rizikó: közepes ("+warn+" figyelem)";rp2.style.color="var(--warn)";rp2.style.borderColor="var(--warn)";}
  else {rp2.textContent="Rizikó: alacsony";rp2.style.color="var(--ok)";rp2.style.borderColor="var(--ok)";}

  $("#legalNote").textContent="A vázlat a beteg közlésén alapul, klinikai döntéstámogató célú, és nem helyettesíti a szakorvosi értékelést. A gyógyszer-átalakítási javaslatok általános irányelveken alapulnak; a végső döntés a kezelőorvosé. Az adatok a böngészőben maradnak, külső szerverre nem kerülnek.";
}

const CATLABEL={med:"Gyógyszeres teendő / átalakítás",ref:"Beutalások / konzíliumok",lab:"Labor / vizsgálatok",obs:"Obszerváció / követés",obes:"Obesitológia + diéta",fu:"Fokozott követés",gen:"Genetikai tanácsadás / vizsgálat",adm:"Terhespatológiai felvétel / sürgős",deliv:"Szülés-terv / programozott sectio",prof:"Profilaxis / szűrés"};
const CATORDER=["adm","med","gen","ref","lab","deliv","obes","fu","obs","prof"];
function renderTodo(T){
  const host=$("#todoOut"); host.innerHTML="";
  let total=0;
  CATORDER.forEach(cat=>{
    const items=T[cat]; if(!items||!items.length)return;
    // dedup
    const seen=new Set(); const uniq=items.filter(i=>{const k=i.tx;if(seen.has(k))return false;seen.add(k);return true;});
    total+=uniq.length;
    const box=el("div","tcat");
    box.appendChild(el("h4",null,CATLABEL[cat]+' <span class="cnt">'+uniq.length+'</span>'));
    uniq.sort((a,b)=>({crit:0,warn:1,info:2}[a.sev]-{crit:0,warn:1,info:2}[b.sev]));
    uniq.forEach(i=>{
      const it=el("div","titem s-"+i.sev);
      it.appendChild(el("div","tx",i.tx+(i.src?'<span class="src">indok: '+i.src+'</span>':'')));
      box.appendChild(it);
    });
    host.appendChild(box);
  });
  if(!total)host.innerHTML='<div class="empty">A kitöltés alapján jelenleg nincs kiemelt teendő.</div>';
  $("#todoCount").textContent=total+" tétel";
}
function todoPlainText(){
  let out=["ORVOSI TEENDŐLISTA — "+({preivf:"Pre-IVF",antenatal:"Terhesgondozás",inpatient:"Terhespatológia"}[STAGE])];
  $$("#todoOut .tcat").forEach(c=>{
    out.push(""); out.push("■ "+c.querySelector("h4").textContent.replace(/\s*\d+\s*$/,"").toUpperCase());
    c.querySelectorAll(".titem .tx").forEach(t=>{
      const src=t.querySelector(".src"); const main=t.childNodes[0].textContent.trim();
      out.push("  • "+main+(src?"  ["+src.textContent.replace("indok: ","")+"]":""));
    });
  });
  return out.join("\n");
}

/* ---------- copy / download ---------- */
function toast(m){const t=$("#toast");t.textContent=m;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),1600);}
function copy(txt,msg){
  if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(txt).then(()=>toast(msg||"Vágólapra másolva")).catch(()=>fallbackCopy(txt,msg));}
  else fallbackCopy(txt,msg);
}
function fallbackCopy(txt,msg){const ta=el("textarea");ta.value=txt;ta.style.position="fixed";ta.style.opacity="0";document.body.appendChild(ta);ta.select();try{document.execCommand("copy");toast(msg||"Vágólapra másolva");}catch(e){toast("A másolás nem sikerült");}ta.remove();}
function download(txt,name){const b=new Blob([txt],{type:"text/plain;charset=utf-8"});const u=URL.createObjectURL(b);const a=el("a");a.href=u;a.download=name;a.click();URL.revokeObjectURL(u);}

/* ---------- init ---------- */
renderRosList($("#rosComplaint"),COMPLAINT);
renderGrouped($("#rosSystems"),SYSTEMS);
renderRosList($("#rosRepro"),REPRO);
renderRosList($("#rosFamily"),FAMILY);
try{renderEndoList($("#rosEndo"),ENDO);}catch(e){}
renderRosList($("#rosLifestyle"),LIFE);
renderRosList($("#rosOrigin"),ORIGIN);
renderRosList($("#rosSurg"),SURG);
renderSupp(); renderLab(); buildPuphaSearch();
["map_mom","uta_mom","plgf_mom"].forEach(id=>{const e=document.getElementById(id); if(e)e.addEventListener("input",generate);});
MEDQUICK.forEach(m=>{const c=el("button","chip","+ "+m);c.type="button";c.onclick=()=>addMedRow(m);$("#medQuick").appendChild(c);});
addMedRow("");
$("#addMed").onclick=()=>addMedRow("");
["age","height","weight","ppweight","bp","fluid","diet","ga","conception","twins","allergy","complaintText","prior"].forEach(id=>{const e=document.getElementById(id);e.addEventListener("input",generate);e.addEventListener("change",generate);});
$$(".seg button").forEach(b=>b.onclick=()=>{STAGE=b.dataset.stage;$$(".seg button").forEach(x=>x.setAttribute("aria-pressed",x===b));$("#secComplaint").open=(STAGE!=="preivf");generate();});
$("#copyAnam").onclick=()=>copy($("#anamOut").textContent,"Anamnézis másolva");
$("#dlAnam").onclick=()=>download($("#anamOut").textContent,"anamnezis.txt");
$("#copyTodo").onclick=()=>copy(todoPlainText(),"Teendők másolva");

/* theme toggle */
(function(){const b=$("#themeBtn");let t=null;b.onclick=()=>{const cur=document.documentElement.getAttribute("data-theme")|| (matchMedia("(prefers-color-scheme:dark)").matches?"dark":"light");t=cur==="dark"?"light":"dark";document.documentElement.setAttribute("data-theme",t);};})();

generate();

/* ===================== v3 module: calculators / cases / export ===================== */
(function(){
  function N(id){var v=parseFloat((($("#"+id))||{}).value);return isNaN(v)?null:v;}
  function bmiV(){var hh=N("height"),ww=N("weight");return(hh>0&&ww>0)?ww/((hh/100)*(hh/100)):null;}
  function sysdia(){var m=(($("#bp")||{}).value||"").match(/(\d{2,3})\s*\/\s*(\d{2,3})/);return m?[+m[1],+m[2]]:null;}

  // ---- calculator palette UI ----
  var carpregDefs=[["Korábbi cardialis esemény / arrhythmia",3],["Kiindulási NYHA III-IV vagy cyanosis",3],["Mechanikus műbillentyű",3],["Kamrai dysfunctio (EF<55%)",2],["Magas rizikójú bal szívfél-obstrukció",2],["Pulmonalis hypertonia",2],["Coronaria-betegség",2],["Magas rizikójú aortopathia",2],["Nem volt korábbi cardialis intervenció",1],["Késői (>20. hét) terhes-kardiológiai értékelés",1]];
  var bishopDefs=[["Tágulat (cm)","dilation",["0 (zárt)","1-2","3-4","≥5"]],["Elvékonyodás %","efface",["0-30","40-50","60-70","≥80"]],["Beszállás (station)","station",["-3","-2","-1/0","+1/+2"]],["Konzisztencia","consist",["kemény","közepes","puha"]],["Pozíció","posit",["hátsó","közép","elülső"]]];
  function calcHTML(){
    var carp=carpregDefs.map(function(d,i){return '<label><input type="checkbox" class="carp" data-p="'+d[1]+'"> '+d[0]+' ('+d[1]+')</label>';}).join(" ");
    var bish=bishopDefs.map(function(d){var o=d[2].map(function(x,i){return '<option value="'+i+'">'+x+'</option>';}).join("");return '<label>'+d[0]+' <select class="bish" data-k="'+d[1]+'">'+o+'</select></label>';}).join(" ");
    return ''
    +'<div class="calcrow"><h5>Szülés várható ideje (EDD) és gestatiós kor</h5><div class="cin"><label>Utolsó menstruáció 1. napja <input type="date" id="calc_lmp"></label></div><div class="cres" id="res_edd">—</div></div>'
    +'<div class="calcrow"><h5>IOM ajánlott súlygyarapodás (BMI szerint)</h5><div class="cres" id="res_iom">—</div></div>'
    +'<div class="calcrow"><h5>Középartériás nyomás (MAP)</h5><div class="cres" id="res_map">—</div></div>'
    +'<div class="calcrow"><h5>Kreatinin-clearance (Cockcroft-Gault, nő)</h5><div class="cres" id="res_egfr">—</div></div>'
    +'<div class="calcrow"><h5>HbA1c ↔ átlag vércukor (eAG)</h5><div class="cres" id="res_a1c">—</div></div>'
    +'<div class="calcrow"><h5>CARPREG II — anyai cardialis rizikó</h5><div class="cin">'+carp+'</div><div class="cres" id="res_carpreg">Pontszám: 0 → ~5%</div></div>'
    +'<div class="calcrow"><h5>Bishop-score</h5><div class="cin">'+bish+'</div><div class="cres" id="res_bishop">—</div></div>';
  }
  function fmtP(p){return (p*100>=10?(p*100).toFixed(0):(p*100).toFixed(1))+"% · 1:"+Math.round(1/p);}
  function updateCalcs(){
    var set=function(id,t){var e=$("#"+id);if(e)e.textContent=t;};
    // EDD / GA
    var lmp=(($("#calc_lmp")||{}).value)||"";
    if(lmp){var d0=new Date(lmp+"T00:00:00"),edd=new Date(d0.getTime()+280*864e5),now=new Date();var days=Math.floor((now-d0)/864e5);var w=Math.floor(days/7),dd=days%7;set("res_edd","EDD: "+edd.toISOString().slice(0,10)+"  ·  GA (LMP alapján): "+(days>=0?(w+" hét "+dd+" nap"):"—"));}
    else set("res_edd","Add meg az utolsó menstruáció első napját.");
    // IOM
    var b=bmiV();
    if(b){var r=b<18.5?"12,5–18 kg":b<25?"11,5–16 kg":b<30?"7–11,5 kg":"5–9 kg";var tw=($("#twins")&&$("#twins").value!=="no")?"  (iker: kb. 14–23 kg BMI szerint)":"";set("res_iom","BMI "+b.toFixed(1)+" → teljes: "+r+tw);}
    else set("res_iom","Add meg a testmagasságot és -súlyt.");
    // MAP
    var sd=sysdia();
    if(sd)set("res_map","MAP = "+Math.round(sd[1]+(sd[0]-sd[1])/3)+" Hgmm  ("+sd[0]+"/"+sd[1]+")");
    else set("res_map","Add meg a vérnyomást (pl. 152/96).");
    // eGFR Cockcroft-Gault
    var age=N("age"),wt=N("weight"),cr=N("lb_creat");
    if(age&&wt&&cr){var crmg=cr/88.4;var crcl=((140-age)*wt*0.85)/(72*crmg);var ob=(b&&b>=30)?"  ⚠ elhízásban a C-G túlbecsül (IBW/ABW mérlegelendő)":"";set("res_egfr","CrCl ≈ "+crcl.toFixed(0)+" ml/perc  (kreatinin "+cr+" µmol/l)"+ob);}
    else set("res_egfr","Kell: életkor, testsúly és kreatinin (labor).");
    // HbA1c
    var a1c=N("lb_hba1c");
    if(a1c){var eag=(28.7*a1c-46.7)/18;set("res_a1c","HbA1c "+a1c+"% → eAG ≈ "+eag.toFixed(1)+" mmol/l");}
    else set("res_a1c","Add meg a HbA1c-t (labor).");
    // CARPREG II
    var pts=0;$$(".carp").forEach(function(c){if(c.checked)pts+=+c.dataset.p;});
    var risk=pts<=1?0.05:pts===2?0.10:pts===3?0.15:pts===4?0.22:0.41;
    set("res_carpreg","Pontszám: "+pts+" → becsült anyai cardialis szövődmény ~"+Math.round(risk*100)+"%");
    // Bishop
    var bs=0;$$(".bish").forEach(function(s){bs+=+s.value;});
    set("res_bishop","Bishop = "+bs+"/13 — "+(bs>=8?"kedvező (indukció valószínűen sikeres)":bs>=6?"közepes":"kedvezőtlen (érlelés mérlegelendő)"));
  }

  // ---- multi-case save/load (localStorage) ----
  function collect(){
    var f={};$$("#form input, #form select, #form textarea").forEach(function(e){if(e.id&&e.type!=="button")f[e.id]=(e.type==="checkbox")?e.checked:e.value;});
    var lmpEl=$("#calc_lmp"); if(lmpEl)f["calc_lmp"]=lmpEl.value;
    var meds=$$("#medList .medrow input").map(function(i){return i.value;}).filter(Boolean);
    return {v:1,ros:JSON.parse(JSON.stringify(state.ros||{})),supp:JSON.parse(JSON.stringify(state.supp||{})),fields:f,meds:meds};
  }
  function resetAll(){
    $$("#form input, #form select, #form textarea").forEach(function(e){if(e.type==="checkbox")e.checked=false;else if(e.tagName==="SELECT")e.selectedIndex=0;else if(!e.readOnly)e.value="";});
    for(var k in state.ros)delete state.ros[k];
    $$(".ros[data-id]").forEach(function(row){row.querySelector(".no").setAttribute("aria-pressed","false");row.querySelector(".yes").setAttribute("aria-pressed","false");row.classList.remove("on");var di=row.querySelector(".det input");if(di)di.value="";});
    if(state.supp)for(var s in state.supp)state.supp[s]={on:false,dose:""};
    $$("#suppHost .ros").forEach(function(row){row.querySelector(".no").setAttribute("aria-pressed","false");row.querySelector(".yes").setAttribute("aria-pressed","false");row.classList.remove("on");var di=row.querySelector(".det input");if(di)di.value="";});
    $("#medList").innerHTML="";addMedRow("");
    var lmpEl=$("#calc_lmp");if(lmpEl)lmpEl.value="";
  }
  function apply(c){
    resetAll();
    Object.keys(c.fields||{}).forEach(function(id){var e=document.getElementById(id);if(e){if(e.type==="checkbox")e.checked=!!c.fields[id];else e.value=c.fields[id];}});
    state.ros=c.ros||{};state.supp=c.supp||{};
    $$(".ros[data-id]").forEach(function(row){var s=state.ros[row.dataset.id];var no=row.querySelector(".no"),yes=row.querySelector(".yes"),di=row.querySelector(".det input");no.setAttribute("aria-pressed",!!(s&&s.v==="neg"));yes.setAttribute("aria-pressed",!!(s&&s.v==="pos"));if(s&&s.v==="pos"){row.classList.add("on");if(di&&s.det)di.value=s.det;}else row.classList.remove("on");});
    var sr=$$("#suppHost .ros");
    if(typeof SUPP!=="undefined")SUPP.forEach(function(sp,i){var row=sr[i];if(!row)return;var s2=state.supp[sp.id]||{};row.querySelector(".no").setAttribute("aria-pressed",!s2.on);row.querySelector(".yes").setAttribute("aria-pressed",!!s2.on);if(s2.on)row.classList.add("on");else row.classList.remove("on");var di=row.querySelector(".det input");if(di&&s2.dose)di.value=s2.dose;});
    $("#medList").innerHTML="";(c.meds||[]).forEach(function(m){addMedRow(m);});if(!(c.meds||[]).length)addMedRow("");
    try{calcBMI();}catch(e){}generate();updateCalcs();
  }
  function casesLoad(){try{return JSON.parse(localStorage.getItem("anam_cases")||"{}");}catch(e){return {};}}
  function casesSave(o){try{localStorage.setItem("anam_cases",JSON.stringify(o));}catch(e){toast("Mentés sikertelen (tárhely).");}}
  function renderCases(show){
    var p=$("#casePanel"),o=casesLoad(),ids=Object.keys(o).sort(function(a,b){return o[b].ts-o[a].ts;});
    p.innerHTML="";
    var note=el("div","hint");note.textContent="Az esetek CSAK ebben a böngészőben, helyben tárolódnak (nem kerülnek szerverre). Betegadat tárolásához az intézményi adatvédelmi szabályokat tartsd be.";p.appendChild(note);
    if(!ids.length){var e0=el("div","hint");e0.textContent="Nincs mentett eset.";p.appendChild(e0);}
    ids.forEach(function(id){var it=el("div","caseitem");var b=el("b",null,o[id].name);var bl=el("button","tbbtn","Betöltés"),bd=el("button","tbbtn","Törlés");bl.type="button";bd.type="button";bl.onclick=function(){apply(o[id].data);toast("Betöltve: "+o[id].name);};bd.onclick=function(){var oo=casesLoad();delete oo[id];casesSave(oo);renderCases(true);};it.append(b,bl,bd);p.appendChild(it);});
    if(show!==undefined)p.hidden=!show;
  }

  // ---- FHIR export (QuestionnaireResponse; indicative coding) ----
  var SNOMED={s_htn:["38341003","Hypertensive disorder"],s_dm:["73211009","Diabetes mellitus"],s_t1dm:["46635009","Type 1 diabetes mellitus"],s_t2dm:["44054006","Type 2 diabetes mellitus"],s_pcos:["69878008","Polycystic ovary syndrome"],s_endo:["129103003","Endometriosis"],s_osa:["78275009","Obstructive sleep apnea"],s_thy:["14304000","Thyroid disorder"],s_ren:["90708001","Kidney disease"],s_ai:["85828009","Autoimmune disease"]};
  var LOINC={lb_hgb:["718-7","Hemoglobin"],lb_plt:["777-3","Platelets"],lb_ldh:["2532-0","Lactate dehydrogenase"],lb_creat:["2160-0","Creatinine"],lb_alb:["1751-7","Albumin"],lb_tsh:["3016-3","TSH"],lb_hba1c:["4548-4","HbA1c"],lb_glu:["1558-6","Fasting glucose"],lb_bnp:["33762-6","NT-proBNP"],lb_trop:["6598-7","Troponin T"],lb_bile:["14629-0","Bile acids"]};
  function buildFHIR(){
    var now=new Date().toISOString();var items=[];
    var add=function(linkId,text,ans){if(ans!==null&&ans!==undefined&&ans!=="")items.push({linkId:linkId,text:text,answer:[ans]});};
    add("age","Age (years)",N("age")!=null?{valueDecimal:N("age")}:null);
    var b=bmiV();add("bmi","BMI (kg/m2)",b?{valueDecimal:+b.toFixed(1)}:null);
    add("bp","Blood pressure",(($("#bp")||{}).value)?{valueString:$("#bp").value}:null);
    add("ga","Gestational age (weeks)",N("ga")!=null?{valueDecimal:N("ga")}:null);
    // conditions
    var conds=[];
    Object.keys(state.ros||{}).forEach(function(id){if(state.ros[id]&&state.ros[id].v==="pos"){var a={valueString:id};if(SNOMED[id])a={valueCoding:{system:"http://snomed.info/sct",code:SNOMED[id][0],display:SNOMED[id][1]}};conds.push({linkId:"condition."+id,text:"Positive finding: "+id,answer:[a]});}});
    // labs
    Object.keys(LOINC).forEach(function(id){var v=N(id);if(v!=null)items.push({linkId:"lab."+id,text:LOINC[id][1],answer:[{valueQuantity:{value:v}}],extension:[{url:"loinc",valueCoding:{system:"http://loinc.org",code:LOINC[id][0],display:LOINC[id][1]}}]});});
    items=items.concat(conds);
    return {resourceType:"QuestionnaireResponse",status:"completed",authored:now,
      meta:{tag:[{system:"local",code:"indicative-coding",display:"Codes are indicative and must be validated against the terminology server / EESZT."}]},
      item:items};
  }
  function download(name,txt,type){var b=new Blob([txt],{type:type||"application/json"});var u=URL.createObjectURL(b);var a=el("a");a.href=u;a.download=name;a.click();URL.revokeObjectURL(u);}

  // ---- init: mount calculators + wire toolbar ----
  var host=$("#calcHost");if(host){host.innerHTML=calcHTML();
    var l=$("#calc_lmp");if(l)l.addEventListener("input",updateCalcs);
    $$(".carp").forEach(function(c){c.addEventListener("change",updateCalcs);});
    $$(".bish").forEach(function(s){s.addEventListener("change",updateCalcs);});
    updateCalcs();
  }
  // refresh auto-calculators after each generate()
  if(typeof window.generate==="function"){var og=window.generate;window.generate=function(){var r=og.apply(this,arguments);try{updateCalcs();}catch(e){}return r;};}
  var by=function(id){return $("#"+id);};
  if(by("tbNew"))by("tbNew").onclick=function(){if(confirm("Új üres eset? A nem mentett adatok elvesznek."))resetAll(),calcBMI(),generate(),updateCalcs();};
  if(by("tbSave"))by("tbSave").onclick=function(){var _id=((($("#pid")||{}).value||"").trim())||((($("#taj")||{}).value||"").trim());var nm=prompt("Eset neve / azonosító (PID vagy TAJ):",_id||("Eset "+new Date().toLocaleDateString()));if(!nm)return;if((($("#taj")||{}).value||"").trim()){ if(!confirm("Figyelem: a TAJ különleges személyes adat. Csak helyben (böngésző) tárolódik, szerverre NEM kerül. Folytatod?")) return; }var o=casesLoad();var _k=_id?("id_"+_id):("c"+new Date().getTime());o[_k]={name:nm,ts:new Date().getTime(),data:collect()};casesSave(o);toast("Eset mentve: "+nm);renderCases(true);};
  if(by("tbCases"))by("tbCases").onclick=function(){var p=$("#casePanel");var willShow=p.hidden;renderCases(willShow);};
  if(by("tbPrint"))by("tbPrint").onclick=function(){window.print();};
  if(by("tbFhir"))by("tbFhir").onclick=function(){download("anamnesis_fhir.json",JSON.stringify(buildFHIR(),null,2),"application/fhir+json");toast("FHIR export letöltve");};
})();


/* ===================== v4: EESZT official antenatal risk factors ===================== */
(function(){
  var EESZT_RISK=[
   {id:"ee_1",k:"1",l:"Az anya kora 40 felett vagy 18 év alatt (magas kockázat)",cat:"Általános rizikótényezők"},
   {id:"ee_10",k:"10",l:"Krónikus gastrointestinalis, máj-, tüdő- (súlyos asthma), vesebetegség",cat:"Várandósság előtt ismert / felmért betegségek"},
   {id:"ee_11",k:"11",l:"Idegrendszeri és (kezelést igénylő) pszichiátriai megbetegedés (epilepsia, schizophrenia, depressio)",cat:"Várandósság előtt ismert / felmért betegségek"},
   {id:"ee_12",k:"12",l:"Haematológiai, autoimmun, thromboemboliás betegség, antiphospholipid sy",cat:"Várandósság előtt ismert / felmért betegségek"},
   {id:"ee_13",k:"13",l:"Daganatos megbetegedések",cat:"Várandósság előtt ismert / felmért betegségek"},
   {id:"ee_14",k:"14",l:"Genetikai betegségek a családban",cat:"Várandósság előtt ismert / felmért betegségek"},
   {id:"ee_15",k:"15",l:"Ikerterhesség, többes iker",cat:"Várandósság előtt ismert / felmért betegségek"},
   {id:"ee_16",k:"16",l:"Vérzés a jelen terhességben (fenyegető vetélés)",cat:"Várandósság előtt ismert / felmért betegségek"},
   {id:"ee_17",k:"17",l:"Habituális vetélés",cat:"Előző terhesség(ek)/szülés(ek) szövődményei"},
   {id:"ee_18",k:"18",l:"Méhen végzett műtét, császármetszés, conizáció",cat:"Előző terhesség(ek)/szülés(ek) szövődményei"},
   {id:"ee_19",k:"19",l:"Koraszülés",cat:"Előző terhesség(ek)/szülés(ek) szövődményei"},
   {id:"ee_21",k:"21",l:"Rh(D)-isoimmunisatio",cat:"Előző terhesség(ek)/szülés(ek) szövődményei"},
  ];
  window.EESZT_RISK=EESZT_RISK;
  // group + render (reuse global renderGrouped/rosRow)
  var groups=[];var seen={};
  EESZT_RISK.forEach(function(it){if(!seen[it.cat]){seen[it.cat]={g:it.cat,items:[]};groups.push(seen[it.cat]);}seen[it.cat].items.push({id:it.id,l:it.l});});
  var host=$("#rosEeszt"); if(host&&typeof renderGrouped==="function"){renderGrouped(host,groups);}
  // append official risk line + code list to the anamnesis after each generate()
  if(typeof window.generate==="function"){
    var og=window.generate;
    window.generate=function(){
      var r=og.apply(this,arguments);
      try{
        var pos=EESZT_RISK.filter(function(x){return state.ros[x.id]&&state.ros[x.id].v==="pos";});
        var out=$("#anamOut");
        if(out&&pos.length){
          out.textContent += "\n\nHIVATALOS VÁRANDÓS-RIZIKÓTÉNYEZŐK (EESZT): "+pos.map(function(x){return "["+x.k+"] "+x.l;}).join("; ")+".";
        }
      }catch(e){}
      return r;
    };
    window.generate();
  }
})();
</script>
```

<a id="v3--v4--v6-15311615"></a>

### v3 + v4 + v6 — Kalkulátorok, esetmentés, export; EESZT rizikótényezők; enrich

Sorok 1531–1615 (85 sor).

```javascript
<script>
/* ===== v6: enrich structured anamnesis (risk / codes / recommendations / prevention / declarations) ===== */
(function(){
  "use strict";
  var q=function(s){return document.querySelector(s);};
  var RULE="────────────────────────────────────────────────────────────";
  function cardRows(sel){var host=q(sel);if(!host)return "";var out=[];
    host.querySelectorAll(".titem").forEach(function(it){var t=(it.textContent||"").replace(/\s+/g," ").trim();if(t)out.push("  • "+t);});
    return out.join("\n");}
  function recRows(){ // physician to-do
    try{ if(typeof todoPlainText==="function"){var s=todoPlainText();return s.replace(/^ORVOSI TEEND[^\n]*\n?/,"").trim();} }catch(e){}
    return cardRows("#todoOut");
  }
  function bmiV(){var h=parseFloat((q("#height")||{}).value)/100,w=parseFloat((q("#weight")||{}).value);return(h>0&&w>0)?w/(h*h):0;}
  function buildPrevention(){
    var st=(window.state&&state.ros)||{}, sp=(window.state&&state.supp)||{}, p=function(id){return st[id]&&st[id].v==="pos";};
    var bmi=bmiV(), out=[];
    if(bmi>=30) out.push("Prekoncepcionális testsúly-optimalizálás (dietetika, strukturált életmód; indokolt esetben bariátria/GLP-1RA az IVF ELŐTT, megfelelő washout-tal).");
    else if(bmi>=25) out.push("Étrend- és mozgástanácsadás; reális gestatiós súlygyarapodási cél (IOM).");
    if(p("s_htn")||p("r_pe")||p("s_ren")||p("s_ai")||p("s_dm")||p("s_t1dm")||p("s_t2dm")||p("s_lada")||bmi>=35)
      out.push("Alacsony dózisú aszpirin (75–150 mg/nap) preeclampsia-profilaxis a 12–16. hét ELŐTT megkezdve; vérnyomás- és proteinuria-monitorozás.");
    if(p("s_pcos")||p("f_dm")||p("f_dm1")||p("r_gdm")||bmi>=30)
      out.push("Korai OGTT és glykaemiás életmód-optimalizálás a gestatiós diabetes megelőzésére / korai felismerésére.");
    if(p("l_smoke")) out.push("Dohányzás-elhagyás támogatása (koraszülés, FGR és halvaszületés kockázatának csökkentése).");
    if(p("l_alc")) out.push("Alkoholfogyasztás elhagyása a fogamzás előtt és a terhesség alatt.");
    if(!(sp.sp_folate&&sp.sp_folate.on)) out.push("Folsav-pótlás (400 µg/nap; magas rizikó vagy előzmény esetén 5 mg) a fogamzás előtt legalább 1 hónappal.");
    if(!(sp.sp_d&&sp.sp_d.on)) out.push("D-vitamin-státusz ellenőrzése és szükség szerinti pótlás.");
    if(p("r_tri")) out.push("Korábbi igazolt triszómia: emelt visszatérési kockázat — genetikai tanácsadás, korai kombinált teszt/NIPT és invazív diagnosztika felajánlása.");
    if(p("f_scd")||p("f_cmp")||p("f_chan")) out.push("Kardiogenetikai tanácsadás + kaszkádszűrés a rokonoknál; kiindulási EKG/echokardiográfia a terhesség előtt vagy korai szakában.");
    if(p("s_thr")||p("f_thr")) out.push("Thrombophilia-értékelés; súly-alapú LMWH-thromboprofilaxis mérlegelése a rizikó szerint.");
    if(p("su_cone")||p("r_ptb")) out.push("Koraszülés-megelőzés: cervix-hossz követése, indokolt esetben progeszteron.");
    out.push("Prekoncepcionális gondozás: oltási státusz (rubeola, varicella) és fogászati/általános állapot rendezése; multidiszciplináris terv.");
    return out;
  }
  function enrich(){
    var pre=q("#anamOut"); if(!pre)return; var txt=pre.textContent||"";
    if(!txt || /Töltsd ki a kérdőívet/.test(txt)) return;   // nothing generated yet
    var add=[];
    var risk=cardRows("#riskOut"); if(risk){ add.push(RULE); add.push("KOCKÁZATBECSLÉS (tájékoztató, NEM validált kalkulátor; a formális szűrést nem helyettesíti):"); add.push(risk); }
    var codes=cardRows("#bnoOut"); if(codes){ add.push("JAVASOLT KÓDOK (BNO / OENO — javaslat; a végső kódolás a kezelőorvos felelőssége):"); add.push(codes); }
    var rec=recRows(); if(rec){ add.push("ORVOSI JAVASLATOK / TEENDŐK:"); add.push(rec.split("\n").map(function(l){return l.trim()?("  "+l.trim()):"";}).join("\n")); }
    var prev=buildPrevention(); if(prev.length){ add.push("MEGELŐZÉS ÉS KOCKÁZATCSÖKKENTÉS:"); prev.forEach(function(x){add.push("  • "+x);}); }
    var decl=[RULE,
      "TÁJÉKOZTATÓ A KOCKÁZATBECSLÉS ÉS A SZŰRŐVIZSGÁLATOK TERMÉSZETÉRŐL",
      "1. A fenti kalkulátorok KOCKÁZATBECSLÉST adnak, nem diagnózist. A százalékos érték populációs valószínűség, amely az adott személyre nem mondja meg, bekövetkezik-e az esemény.",
      "2. A szűrővizsgálatok — beleértve az ultrahangot — természetüknél fogva NEM 100%-os érzékenységűek, egyetlen állapotban sem. A kimutatási arányt befolyásolja a terhességi kor, a magzat helyzete, a magzatvíz mennyisége, az anyai testalkat (magasabb testtömegindex esetén érdemben csökken a képminőség), a többes terhesség és a készülék felbontása.",
      "3. Ebből következően a NEGATÍV (eltérést nem mutató) szűrővizsgálat a rendellenességet vagy a szövődményt NEM ZÁRJA KI, a pozitív szűrőeredmény pedig önmagában nem jelent betegséget — mindkét esetben további, diagnosztikus vizsgálat szükséges. Álnegatív és álpozitív eredmény a szakmai szabályok maradéktalan betartása mellett is előfordul.",
      "4. A szűrővizsgálat tehát nem diagnosztikus vizsgálat. A szakmai szabályoknak megfelelően elvégzett és dokumentált szűrés korlátja a módszer sajátja. Az ellátó felelőssége a vizsgálat szakszerű elvégzésére, dokumentálására és a tájékoztatásra terjed ki.",
      "5. Ez az alkalmazás klinikai DÖNTÉSTÁMOGATÓ eszköz: a szakorvosi értékelést nem helyettesíti, és önállóan diagnózist nem állít fel. A végső klinikai döntés minden esetben a kezelőorvosé.",
      "   A tájékoztatást megértettem — Beteg aláírása: ……………………………    Dátum: ……………………",
      RULE,
      "ELTITKOLT BETEGSÉG NYILATKOZAT: Kijelentem, hogy tudomásom szerint semmilyen betegséget, panaszt, korábbi kezelést, gyógyszerszedést vagy egyéb lényeges körülményt NEM titkoltam el, és a fenti adatokat a legjobb tudásom szerint, a valóságnak megfelelően adtam meg.",
      "   Beteg aláírása: ……………………………………    Dátum: ……………………",
      "TUDOMÁNYOS ÉS BIOBANKI FELHASZNÁLÁS — HOZZÁJÁRULÓ NYILATKOZAT",
      "Az alábbi pontok mindegyike ÖNÁLLÓAN választható. A hozzájárulás ÖNKÉNTES, bármikor, indoklás nélkül, írásban VISSZAVONHATÓ, és a visszavonás a további ellátás minőségét nem befolyásolja. A visszavonás a már elvégzett, anonimizált elemzések eredményét nem érinti.",
      "  1. Anonimizált egészségügyi adataim felhasználása tudományos kutatás, oktatás és minőségfejlesztés céljára.    ☐ HOZZÁJÁRULOK   ☐ nem",
      "  2. A diagnosztikai célból levett minták maradékának (vér, szövet) biobanki tárolása és kutatási felhasználása.    ☐ HOZZÁJÁRULOK   ☐ nem",
      "  3. A szülés során egyébként megsemmisítésre kerülő anyagok (placenta, köldökzsinór és köldökzsinórvér, magzatburok) kutatási célú felhasználása.    ☐ HOZZÁJÁRULOK   ☐ nem",
      "  4. Genetikai vizsgálat végzése a tárolt mintán, kutatási céllal, anonimizáltan.    ☐ HOZZÁJÁRULOK   ☐ nem",
      "  5. Széles körű (broad consent) felhasználás: a minta és az adat jövőbeni, még meg nem határozott, etikai engedéllyel rendelkező kutatásokban való felhasználása.    ☐ HOZZÁJÁRULOK   ☐ nem",
      "  6. Anonimizált adatok és minták továbbítása hazai és nemzetközi kutatási együttműködés keretében (EGT-n kívülre is, megfelelő garanciákkal).    ☐ HOZZÁJÁRULOK   ☐ nem",
      "  7. Kapcsolatfelvétel a jövőben további kutatási részvétel felajánlása céljából.    ☐ HOZZÁJÁRULOK   ☐ nem",
      "  8. A kutatás során véletlenül felfedezett, klinikailag jelentős (érdemi beavatkozást lehetővé tevő) lelet visszajelzése számomra.    ☐ KÉREM   ☐ nem kérem",
      "A tárolás és felhasználás a GDPR és a vonatkozó hazai egészségügyi adatvédelmi szabályok szerint, illetékes etikai bizottsági engedély birtokában történik. A minta és az adat kereskedelmi értékesítése nem történik.",
      "A tájékoztatást megértettem, kérdéseimre választ kaptam, és a fenti pontokban jelöltek szerint nyilatkozom.",
      "   Beteg aláírása: ……………………………    Tájékoztató orvos: ……………………………    Dátum: ……………………",
      "   Beteg aláírása: ……………………………………    Dátum: ……………………"];
    var enriched=add.join("\n");
    var m="NYILATKOZAT:";
    var i=txt.indexOf(m);
    if(i>=0){
      var ls=txt.lastIndexOf("\n", i-1); if(ls<0)ls=0;
      // remove a lone separator line just before NYILATKOZAT to avoid doubling
      pre.textContent = txt.slice(0,ls) + "\n" + enriched + txt.slice(ls) + "\n" + decl.join("\n");
    } else {
      pre.textContent = txt + "\n" + enriched + "\n" + decl.join("\n");
    }
  }
  if(typeof window.generate==="function"){
    var og=window.generate;
    window.__enrich=enrich; window.generate=function(){ var r=og.apply(this,arguments); try{ enrich(); }catch(e){ window.__enrichErr=(e&&e.message)||String(e); } return r; };
    try{ window.generate(); }catch(e){}
  }
})();
</script>
```

<a id="v7-16171642"></a>

### v7 — Kiegészítő kampó

Sorok 1617–1642 (26 sor).

```javascript
<script>
/* v7: demographics + three-generation developmental history into the anamnesis */
(function(){
  "use strict";
  var q=function(s){return document.querySelector(s);};
  function v(id){var e=q("#"+id);return e?(e.value||"").trim():"";}
  function enrich2(){
    var pre=q("#anamOut"); if(!pre)return; var t=pre.textContent||""; if(!t||/Töltsd ki a kérdőívet/.test(t))return;
    var demo=[]; var b=v("birth"); if(b)demo.push("születési idő "+b); var bp=v("birthplace"); if(bp)demo.push("születési hely "+bp);
    var oc=v("occupation"); if(oc)demo.push("foglalkozás "+oc); var pa=v("patage"); if(pa)demo.push("apai (partner) életkor "+pa+" év");
    var pid=v("pid"); if(pid)demo.push("PID "+pid);
    var st=(typeof state!=="undefined"&&state.ros)?state.ros:{};
    var ORIG=(typeof ORIGIN!=="undefined")?ORIGIN:[];
    var oo=[]; var bga=v("birthGA"); if(bga)oo.push("a beteg a "+bga+". gestatiós héten született"); var bwt=v("birthWt"); if(bwt)oo.push("születési súlya "+bwt+" g");
    ORIG.forEach(function(i){var s=st[i.id]; if(s&&s.v==="pos")oo.push(i.l.charAt(0).toLowerCase()+i.l.slice(1));});
    var ins="";
    if(demo.length) ins+="\nDEMOGRÁFIA: "+demo.join("; ")+".";
    if(oo.length) ins+="\nSZÁRMAZÁSI / FEJLŐDÉSI ANAMNÉZIS (3 generáció): "+oo.join("; ")+".";
    if(!ins)return;
    var m=t.indexOf("ALAPADATOK:");
    if(m>=0){ var le=t.indexOf("\n",m); if(le<0)le=t.length; pre.textContent=t.slice(0,le)+ins+t.slice(le); }
    else { pre.textContent=t+ins; }
  }
  if(typeof window.generate==="function"){ var og=window.generate; window.generate=function(){ var r=og.apply(this,arguments); try{ enrich2(); }catch(e){} return r; }; try{ window.generate(); }catch(e){} }
})();
</script>
```

<a id="v8-16441680"></a>

### v8 — Kiegészítő kampó

Sorok 1644–1680 (37 sor).

```javascript
<script>
/* v8: positive-only detailed anamnesis + abbreviation/spelling normalisation */
(function(){
  "use strict";
  var q=function(s){return document.querySelector(s);};
  // abbreviation / spelling expansions (conservative; keep standard acronyms like HELLP, PCOS, T1DM)
  var ABBR=[
    [/\bdg\./g,"diagnózis"],[/\bpl\.\s*/g,"például "],[/\bstb\.?/g,"és egyéb"],
    [/\bRR\b/g,"vérnyomás"],[/\bsy\b/g,"szindróma"],[/\bk\.m\.n\./g,"közelebbről meg nem határozott"],
    [/\bhtn\b/gi,"hypertonia"],[/\bCMP\b/g,"cardiomyopathia"],[/\bSCD\b/g,"hirtelen szívhalál"],
    [/\bICP\b/g,"intrahepaticus cholestasis"],[/\bGDM\b/g,"gesztációs diabetes"],
    [/\bFGR\b/g,"magzati növekedési restrikció"],[/\bART\b/g,"asszisztált reprodukció"],
    [/\bLMWH\b/g,"kis molekulatömegű heparin"],[/\bOGTT\b/g,"oralis glükóz tolerancia teszt"],
    [/\bTAPSE\b/g,"tricuspidalis anulus systolés kitérés"]
  ];
  function normalise(t){
    // 1) drop explicit negative lists
    t=t.replace(/\s*Tagadja \/ nem ismert:[^\n]*/g,"")
       .replace(/\s*Célzottan tagadva:[^\n]*/g,"")
       .replace(/\s*Tagadja:[^\n]*/g,"");
    // 2) expand abbreviations (skip the declaration block to keep it verbatim)
    var cut=t.indexOf("NYILATKOZAT:"); var head=cut>=0?t.slice(0,cut):t; var tail=cut>=0?t.slice(cut):"";
    ABBR.forEach(function(a){head=head.replace(a[0],a[1]);});
    t=head+tail;
    // 3) tidy spacing / punctuation
    t=t.replace(/[ \t]{2,}/g," ")
       .replace(/\s+;/g,";").replace(/;\s*\./g,".").replace(/\.\s*\./g,".")
       .replace(/\(\s+/g,"(").replace(/\s+\)/g,")")
       .replace(/[ \t]+\n/g,"\n").replace(/\n{3,}/g,"\n\n");
    // capitalise after section colon + sentence start
    t=t.replace(/(: )([a-záéíóöőúüű])/g,function(_,a,b){return a+b.toUpperCase();});
    return t;
  }
  function clean(){ var pre=q("#anamOut"); if(!pre)return; var t=pre.textContent; if(!t||/Töltsd ki a kérdőívet/.test(t))return; var n=normalise(t); if(n!==t) pre.textContent=n; }
  if(typeof window.generate==="function"){ var og=window.generate; window.generate=function(){ var r=og.apply(this,arguments); try{ clean(); }catch(e){} return r; }; try{ window.generate(); }catch(e){} }
})();
</script>
```

<a id="v9-16821926"></a>

### v9 — Narratíva, GA-időzítés, PHQ-2, aktív allergia

Sorok 1682–1926 (245 sor).

```javascript
<script>
/* ===================== v9: narrative + GA-timing + PHQ-2 + active allergy ===================== */
(function(){
  "use strict";
  var q=function(s){return document.querySelector(s);};
  var qq=function(s){return [].slice.call(document.querySelectorAll(s));};
  var el=function(t,c,htm){var e=document.createElement(t);if(c)e.className=c;if(htm!=null)e.innerHTML=htm;return e;};
  var RULE="".padEnd?("").padEnd(64,"─"):Array(65).join("─");
  var S=(typeof state!=="undefined")?state:null;   /* classic-script global const, not a window property */
  if(S){ S.allergyDrug=S.allergyDrug||[]; S.allergyFood=S.allergyFood||[]; }

  function val(id){var e=q("#"+id);return e?((e.value||"")+"").trim():"";}
  function num(id){var e=q("#"+id);return e?parseFloat(e.value):NaN;}
  function P(id){return S&&S.ros&&S.ros[id]&&S.ros[id].v==="pos";}
  function lc(s){return s?s.charAt(0).toLowerCase()+s.slice(1):s;}
  function clean(s){return (s||"").replace(/ +\/ +/g,", ").replace(/\s{2,}/g," ").trim();}   /* drop spaced " / " only (keeps kg/m², mmol/l) */
  function listPhrase(arr){return arr.map(function(i){return lc(clean(labelWithDet(i)));}).join("; ");}
  function gen(){ if(typeof window.generate==="function"){ try{window.generate();}catch(e){} } }

  /* ---------- active allergy widget ---------- */
  var DRUGS=["Penicillin","Cephalosporin","Szulfonamid","NSAID / ASA","Jód / kontrasztanyag","Lokálanesztetikum","Makrolid","Opioid","Heparin","Latex"];
  var FOODS=["Tejfehérje","Tojás","Földimogyoró","Diófélék","Glutén / búza","Szója","Hal","Kagyló / tenger gyümölcsei","Szezám","Gyümölcs (pl. eper)"];
  function addAllergyRow(listSel,ph,val0){
    var host=q(listSel); if(!host)return;
    var row=el("div","medwrap"); var line=el("div","medrow");
    var inp=el("input"); inp.placeholder=ph||"pl. Penicillin"; if(val0)inp.value=val0;
    var lab=el("label",null,'<input type="checkbox" class="anaf"> anafilaxia');
    lab.style.cssText="font-size:11px;display:flex;align-items:center;gap:4px;white-space:nowrap;color:var(--crit)";
    var del=el("button","del","✕"); del.type="button"; del.setAttribute("aria-label","Törlés");
    inp.oninput=function(){syncAllergy();gen();};
    lab.querySelector("input").onchange=function(){syncAllergy();gen();};
    del.onclick=function(){row.parentNode.removeChild(row);syncAllergy();gen();};
    line.appendChild(inp); line.appendChild(lab); line.appendChild(del);
    row.appendChild(line); host.appendChild(row);
  }
  function readHost(listSel){
    return qq(listSel+" .medrow").map(function(r){
      var i=r.querySelector('input:not(.anaf)'); var a=r.querySelector('.anaf');
      var v=(i&&i.value||"").trim(); return v?{n:v,anaf:!!(a&&a.checked)}:null;
    }).filter(Boolean);
  }
  function syncAllergy(){
    if(!S)return;
    S.allergyDrug=readHost("#drugAllList");
    S.allergyFood=readHost("#foodAllList");
    var none=q("#allNone");
    if(none&&none.checked&&(state.allergyDrug.length||state.allergyFood.length)){ none.checked=false; }
  }
  function mountAllergy(){
    var dq=q("#drugAllQuick"); if(dq&&!dq.childNodes.length){ DRUGS.forEach(function(m){var c=el("button","chip","+ "+m);c.type="button";c.onclick=function(){addAllergyRow("#drugAllList","pl. Penicillin",m);syncAllergy();gen();};dq.appendChild(c);}); }
    var fq=q("#foodAllQuick"); if(fq&&!fq.childNodes.length){ FOODS.forEach(function(m){var c=el("button","chip","+ "+m);c.type="button";c.onclick=function(){addAllergyRow("#foodAllList","pl. Tejfehérje",m);syncAllergy();gen();};fq.appendChild(c);}); }
    var ad=q("#addDrugAll"); if(ad)ad.onclick=function(){addAllergyRow("#drugAllList","pl. Penicillin");};
    var af=q("#addFoodAll"); if(af)af.onclick=function(){addAllergyRow("#foodAllList","pl. Tejfehérje");};
    var none=q("#allNone"); if(none)none.onchange=function(){ if(none.checked){ ["#drugAllList","#foodAllList"].forEach(function(s){var hh=q(s);if(hh)hh.innerHTML="";}); syncAllergy(); } gen(); };
    if(q("#drugAllList")&&!q("#drugAllList").childNodes.length)addAllergyRow("#drugAllList","pl. Penicillin");
    if(q("#foodAllList")&&!q("#foodAllList").childNodes.length)addAllergyRow("#foodAllList","pl. Tejfehérje");
  }
  function buildAllergyLine(){
    syncAllergy();
    var none=q("#allNone"); var d=(S&&S.allergyDrug)||[], f=(S&&S.allergyFood)||[];
    var envv=val("allergy");
    if(none&&none.checked&&!d.length&&!f.length&&!envv) return "ALLERGIA: nem ismert allergia (a beteg tagadja).";
    var parts=[];
    parts.push(d.length?("gyógyszer-allergia — "+d.map(function(x){return x.n+(x.anaf?" (ANAFILAXIA!)":"");}).join(", ")):"gyógyszer-allergia nem ismert");
    if(f.length)parts.push("étel-allergia — "+f.map(function(x){return x.n+(x.anaf?" (ANAFILAXIA!)":"");}).join(", "));
    if(envv)parts.push("egyéb / környezeti: "+envv);
    return "ALLERGIA: "+parts.join("; ")+".";
  }

  /* ---------- PHQ-2 depression screen ---------- */
  function phq2Interpret(){
    var a=val("phq2_a"), b=val("phq2_b");
    if(a===""||b==="")return null;
    var sc=(parseInt(a,10)||0)+(parseInt(b,10)||0);
    var pos=sc>=3;
    return {score:sc,pos:pos,
      line:"DEPRESSZIÓ-SZŰRÉS (PHQ-2): "+sc+"/6 pont — "+(pos?"POZITÍV szűrés (≥3): kiterjesztett értékelés (EPDS vagy PHQ-9) és pszichés/pszichiátriai konzílium javasolt.":"negatív szűrés (<3)."),
      sentence: pos?("A rövid depresszió-szűrés (PHQ-2 "+sc+"/6) pozitív, ami teljes körű perinatális hangulati értékelést (EPDS vagy PHQ-9) és pszichés támogatás felajánlását indokolja."):("A rövid depresszió-szűrés (PHQ-2 "+sc+"/6) negatív.")};
  }
  function updatePhq(){
    var e=q("#phq2res"); if(!e)return;
    var r=phq2Interpret();
    if(!r){ e.textContent="Válaszolj mindkét kérdésre a pontszámhoz."; e.style.color=""; return; }
    e.textContent="PHQ-2 pontszám: "+r.score+"/6 — "+(r.pos?"pozitív szűrés (≥3) → EPDS/PHQ-9 + pszichés konzílium javasolt":"negatív (<3)");
    e.style.color=r.pos?"var(--crit)":"";
  }
  function mountPhq(){ ["phq2_a","phq2_b"].forEach(function(id){var s=q("#"+id); if(s)s.addEventListener("change",function(){updatePhq();gen();});}); updatePhq(); }

  /* ---------- calculators summary (weave results into the anamnesis) ---------- */
  function calcSummary(){
    var ids=[["res_edd",""],["res_carpreg",""],["res_map",""]];
    var out=[];
    ids.forEach(function(p){var e=q("#"+p[0]); if(!e)return; var t=(e.textContent||"").trim();
      if(!t||/^Add meg|^Kell:|^—$/.test(t))return;
      out.push(t.replace(/\s+/g," "));});   /* CARPREG 0 is included per user request */
    return out.length? ("A kalkulátorok alapján: "+out.join("; ")+"."):"";
  }

  /* ---------- GA / trimester timing ---------- */
  function trimester(ga){ga=parseFloat(ga); if(!ga)return ""; return ga<14?"I. trimeszter":ga<28?"II. trimeszter":"III. trimeszter";}
  function timingLine(){
    var ga=parseFloat(val("ga")); if(!ga)return "";
    var a=["Aktuális terhességi kor: "+ga+". hét ("+trimester(ga)+")."];
    var peRisk=P("s_htn")||P("r_pe")||P("s_ren")||P("s_ai")||(function(){var tw=document.querySelector("#twins");return !!(tw&&tw.value&&tw.value!=="no");})()||(num("height")>0&&num("weight")>0&&(num("weight")/Math.pow(num("height")/100,2))>=35);
    if(ga<16&&peRisk)a.push("Alacsony dózisú aszpirin megkezdésének ablaka még nyitva (ideálisan a 12–16. hét között).");
    if(ga>=11&&ga<14)a.push("Kombinált I. trimeszteri szűrés (11–13+6. hét) időszaka.");
    if(ga>=18&&ga<23)a.push("Részletes anatómiai ultrahang időzítése (18–22. hét).");
    if(ga>=24&&ga<28)a.push("OGTT esedékes (24–28. hét).");
    if(ga>=28&&ga<31)a.push("Anti-D profilaxis (RhD-negatív esetén) és III. trimeszteri követés.");
    return "TERHESSÉGI KOR ÉS IDŐZÍTETT TEENDŐK: "+a.join(" ");
  }

  /* ---------- word-wrap for clean copy/.txt ---------- */
  function wrapText(s,w){w=w||96; var words=s.split(/\s+/),line="",out=[];
    words.forEach(function(x){ if((line+" "+x).trim().length>w){out.push(line.trim());line=x;} else line+=" "+x; });
    if(line.trim())out.push(line.trim()); return out.join("\n");}

  /* ---------- narrative prose from POSITIVE entries — structured blocks ---------- */
  function narrative(){
    var age=val("age"), ga=val("ga");
    var CM={spontan:"spontán",ovind:"ovuláció-indukciós",insem:"inszeminációs (IUI)",ivf:"IVF-",icsi:"ICSI-",fet:"FET-",donor:"donor gamétás"};
    var conc=CM[val("conception")]||"";
    var concPhrase=conc?((conc.slice(-1)==="-")?(conc+"fogantatású"):(conc+" fogantatású")):"";
    var TW={no:"",dcda:"DCDA ikerterhesség",mcda:"MCDA ikerterhesség",mcma:"MCMA ikerterhesség"};
    var tw=TW[val("twins")]||"";
    var hh=num("height"),ww=num("weight"); var bmi=(hh>0&&ww>0)?ww/Math.pow(hh/100,2):null;
    var B=[];

    /* 1) Jelen terhesség (+ antropometria) */
    var s=(age?("A "+age+" éves beteg"):"A beteg"); var pr=[];
    if(concPhrase)pr.push(concPhrase); if(tw)pr.push(lc(tw));
    if(ga)pr.push("jelenleg a "+ga+". gestatiós héten"+(trimester(ga)?(" ("+trimester(ga)+")"):"")+" járó várandós");
    s+= pr.length?(" "+pr.join(", ")):""; s+=".";
    if(bmi){ var cat=(typeof window.bmiCat==="function")?bmiCat(bmi):"";
      s+=" Testtömegindexe "+bmi.toFixed(1)+" kg/m²"+(cat?(" ("+clean(cat)+")"):"")+".";
      if(bmi>=30)s+=" Az elhízás fokozott gesztációs cukorbetegség-, preeclampsia- és thrombosishajlammal jár, ezért a gondozás kiemelt figyelmet igényel.";
    }
    B.push(["Jelen terhesség",s]);

    /* 2) Aktuális panaszok */
    var cp=(typeof posList==="function")?posList(COMPLAINT):[];
    if(cp.length)B.push(["Aktuális panaszok","A beteg jelenleg "+listPhrase(cp)+" panaszáról számol be."]);

    /* 3) Belgyógyászati háttér és gyógyszerelés */
    if(typeof syncMeds==="function")syncMeds();
    var sp=(typeof posList==="function")?posList(flatSystems()):[];
    var meds=(S&&S.meds)||[];
    if(sp.length||meds.length){
      var bs="";
      if(sp.length){ bs="A kórelőzményben "+listPhrase(sp)+" szerepel.";
        var ex=[];
        if(P("s_htn"))ex.push("a krónikus magas vérnyomás a preeclampsia egyik legfontosabb rizikófaktora, ezért alacsony dózisú aszpirin és rendszeres vérnyomás-követés indokolt");
        if(P("s_dm"))ex.push("a szénhidrátanyagcsere-zavar szoros vércukor-kontrollt és korai terheléses cukorvizsgálatot kíván");
        if(P("s_thr"))ex.push("a fokozott véralvadási hajlam thrombosis-megelőzés mérlegelését veti fel");
        if(P("s_card")||P("s_arr")||P("s_dev"))ex.push("az ismert szívbetegség kardiológiai gondozást és anyai rizikóbecslést tesz szükségessé");
        if(P("s_thy"))ex.push("a pajzsmirigy-eltérés rendszeres hormonszint-ellenőrzést igényel");
        if(ex.length)bs+=" Klinikai szempontból "+ex.join(", ")+".";
      }
      if(meds.length)bs+=(bs?" ":"")+"Rendszeres gyógyszerei: "+meds.map(clean).join(", ")+"; ezek terhesség alatti biztonságosságát a teendőlista jelzi.";
      B.push(["Belgyógyászati háttér",bs]);
    }

    /* 4) Szülészeti-reprodukciós és családi előzmény */
    var rp=(typeof posList==="function")?posList(REPRO):[];
    var fp=(typeof FAMILY!=="undefined")?FAMILY.filter(function(i){return P(i.id);}):[];
    if(rp.length||fp.length){
      var rs="";
      if(rp.length)rs+="Szülészeti-reprodukciós előzményében "+listPhrase(rp)+" ismert.";
      if(fp.length){ rs+=(rs?" ":"")+"A vér szerinti rokonoknál "+listPhrase(fp)+" fordul elő";
        rs+=(P("f_scd")||P("f_cmp"))?", ami kardiogenetikai tanácsadást és a rokonok kaszkádszűrését indokolja.":".";
      }
      B.push(["Szülészeti-reprodukciós és családi előzmény",rs]);
    }

    /* 5) Életmód és szupplementáció */
    var lp=(typeof posList==="function")?posList(LIFE):[];
    var suppOn=(typeof SUPP!=="undefined")?SUPP.filter(function(x){return S&&S.supp&&S.supp[x.id]&&S.supp[x.id].on;}):[];
    if(lp.length||suppOn.length){
      var ls="";
      if(lp.length){ ls+="Életmódját "+listPhrase(lp)+" jellemzi.";
        if(P("l_smoke"))ls+=" A dohányzás elhagyása a koraszülés és a magzati növekedési elmaradás kockázatának csökkentése miatt kiemelten fontos.";
      }
      if(suppOn.length)ls+=(ls?" ":"")+"Jelenleg "+suppOn.map(function(x){return lc(clean(x.l));}).join(", ")+" pótlást szed.";
      B.push(["Életmód és szupplementáció",ls]);
    }

    /* 6) Allergia */
    var d=(S&&S.allergyDrug)||[],f=(S&&S.allergyFood)||[];
    if(d.length||f.length){
      var al=[];
      if(d.length)al.push("gyógyszer-allergia ismert ("+d.map(function(x){return x.n+(x.anaf?", anafilaxiával":"");}).join(", ")+")");
      if(f.length)al.push("étel-allergia áll fenn ("+f.map(function(x){return x.n;}).join(", ")+")");
      var as="A betegnél "+al.join(", ")+".";
      if(d.some(function(x){return x.anaf;})||f.some(function(x){return x.anaf;}))as+=" Az anafilaxia veszélye miatt a kiváltó szerek szigorú kerülése és írásos sürgősségi terv szükséges.";
      B.push(["Allergia",as]);
    } else if(q("#allNone")&&q("#allNone").checked){ B.push(["Allergia","Ismert gyógyszer- vagy ételallergiája nincs."]); }

    /* 7) Pszichés státusz */
    var dep=phq2Interpret(); if(dep)B.push(["Pszichés státusz",dep.sentence]);

    /* 8) Kockázati összegzés és gondozási terv */
    var cl=[];
    if(bmi&&bmi>=30)cl.push("a testsúly gondozása");
    if(P("s_htn")||P("r_pe"))cl.push("preeclampsia-megelőzés aszpirinnel a 16. terhességi hét előtt");
    if(P("s_dm")||P("s_pcos")||P("r_gdm")||(bmi&&bmi>=30))cl.push("korai terheléses cukorvizsgálat");
    if(dep&&dep.pos)cl.push("perinatális lelki támogatás");
    var cs=calcSummary();
    var ks="";
    if(cl.length)ks+="A fentiek alapján a gondozás fő hangsúlyai: "+cl.join(", ")+".";
    if(cs)ks+=(ks?" ":"")+cs;
    if(ks){ ks+=" A tételes kockázatbecslés, a javasolt kódok és a részletes teendők a lenti blokkokban olvashatók.";
      B.push(["Kockázati összegzés és gondozási terv",ks]);
    }

    return B.map(function(b){ return "• "+b[0]+" — "+wrapText(clean(b[1]),92).replace(/\n/g,"\n  "); }).join("\n\n");
  }

  /* ---------- enrich the #anamOut ---------- */
  function enrich9(){
    var pre=q("#anamOut"); if(!pre)return; var t=pre.textContent||"";
    if(!t||/Töltsd ki a kérdőívet/.test(t))return;
    // active allergy line
    var allLine=buildAllergyLine();
    if(/^ALLERGIA:.*$/m.test(t)) t=t.replace(/^ALLERGIA:.*$/m,function(){return allLine;});
    // depression + GA timing lines, inserted right after the allergy line
    var extra=[]; var dep=phq2Interpret(); if(dep)extra.push(dep.line);
    var tim=timingLine(); if(tim)extra.push(tim);
    if(extra.length){ var idx=t.indexOf(allLine); if(idx>=0){ var end=t.indexOf("\n",idx); if(end<0)end=t.length; t=t.slice(0,end)+"\n"+extra.join("\n")+t.slice(end); } }
    // narrative after ALAPADATOK line
    var nar=narrative();
    if(nar){ t=t.replace(/^(ALAPADATOK:.*)$/m,function(m0,g1){return g1+"\n\n"+RULE+"\nNARRATÍV ÖSSZEFOGLALÓ (elbeszélő anamnézis, csak a pozitív adatokból):\n"+nar+"\n"+RULE;}); }
    t=t.replace(/ +\/ +/g,", ");   /* global: drop spaced " / " in structured lines too (units unaffected) */
    pre.textContent=t;
  }

  function mountAll(){ try{mountAllergy();}catch(e){} try{mountPhq();}catch(e){} }
  if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",mountAll); else mountAll();

  if(typeof window.generate==="function"){
    var og=window.generate;
    window.generate=function(){ var r=og.apply(this,arguments); try{enrich9();}catch(e){window.__v9err=(e&&e.message)||String(e);} return r; };
    try{ window.generate(); }catch(e){}
  }
})();
</script>
```

<a id="v12-19282138"></a>

### v12 — Automatikus és beágyazott külső kalkulátorok

Sorok 1928–2138 (211 sor).

```javascript
<script>
/* ===================== v12: automatic calculators + embedded external calculators (iframe) ===================== */
(function(){
  "use strict";
  var q=function(s){return document.querySelector(s);};
  var qq=function(s){return [].slice.call(document.querySelectorAll(s));};
  function num(id){var e=q("#"+id);return e?parseFloat(e.value):NaN;}
  function val(id){var e=q("#"+id);return e?((e.value||"")+"").trim():"";}
  function P(id){return (typeof state!=="undefined")&&state.ros&&state.ros[id]&&state.ros[id].v==="pos";}
  var cbrt=Math.cbrt||function(x){return Math.pow(x,1/3);};
  function toastMsg(m){ try{ if(typeof toast==="function"){toast(m);return;} }catch(e){} var t=q("#toast"); if(t){t.textContent=m;t.classList.add("show");setTimeout(function(){t.classList.remove("show");},1800);} }
  function copyText(t){
    try{ if(navigator.clipboard&&navigator.clipboard.writeText){ navigator.clipboard.writeText(t); toastMsg("URL a vágólapra másolva"); return; } }catch(e){}
    try{ var ta=document.createElement("textarea"); ta.value=t; ta.style.position="fixed"; ta.style.opacity="0"; document.body.appendChild(ta); ta.focus(); ta.select(); document.execCommand("copy"); document.body.removeChild(ta); toastMsg("URL a vágólapra másolva"); }catch(e){ toastMsg("Másolás nem sikerült — jelöld ki kézzel."); }
  }

  var MWHO={
    "I":"alacsony kockázat (esemény ~2,5–5%); helyi gondozás, 1–2 kontroll a terhesség alatt.",
    "II":"kissé emelt kockázat (~5,7–10,5%); helyi/megyei gondozás, trimeszterenkénti kontroll.",
    "II–III":"közepes kockázat (~10–19%); kijelölt centrum, kb. kéthavi kontroll.",
    "III":"jelentős kockázat (~19–27%); szakcentrum (kardio-obstetrikai team), havi–kéthavi kontroll, szülés szakcentrumban.",
    "IV":"nagyon magas kockázat (~40–100%), a terhesség ellenjavallt; ha mégis folytatódik, szakcentrum, havi kontroll."
  };

  /* RCOG Green-top 37a — auto factors derived from the anamnesis; manual = not-recorded transient factors */
  var VTE_MANUAL=[
    {id:"vte_pvte", l:"Korábbi VTE (bármely, kivéve egyszeri, nagy műtéthez kötött)", pts:4, high:true},
    {id:"vte_thrhi", l:"IGAZOLT magas kockázatú thrombophilia", pts:3, high:true},
    {id:"vte_par3", l:"Parity ≥ 3 (3 vagy több szülés)", pts:1},
    {id:"vte_varix", l:"Kifejezett visszértágulat (varicositas)", pts:1},
    {id:"vte_pe", l:"Aktuális preeclampsia", pts:1},
    {id:"vte_surg", l:"Bármilyen műtét a jelen terhességben", pts:3},
    {id:"vte_ohss", l:"OHSS (csak az I. trimeszterben)", pts:4},
    {id:"vte_immob", l:"Immobilitás / kiszáradás", pts:1},
    {id:"vte_infect", l:"Aktuális szisztémás fertőzés", pts:1}
  ];
  function vteAuto(){
    var a=[]; var age=num("age");
    var hh=num("height"),ww=num("weight"); var bmi=(hh>0&&ww>0)?ww/Math.pow(hh/100,2):null;
    if(age>35)a.push({l:"Életkor > 35 év",pts:1});
    if(bmi&&bmi>=40)a.push({l:"Elhízás BMI ≥ 40",pts:2}); else if(bmi&&bmi>=30)a.push({l:"Elhízás BMI 30–39,9",pts:1});
    if(["dcda","mcda","mcma"].indexOf(val("twins"))>=0)a.push({l:"Ikerterhesség",pts:1});
    if(["ivf","icsi","fet"].indexOf(val("conception"))>=0||P("s_infert"))a.push({l:"Asszisztált reprodukció (ART)",pts:1});
    if(P("l_smoke"))a.push({l:"Dohányzás",pts:1});
    if(P("s_thr"))a.push({l:"Thrombosis/thrombophilia az anamnézisben (pontosítandó: korábbi VTE vs thrombophilia)",pts:1});
    if(P("s_ai")||P("s_onc")||P("s_ren")||P("s_liv"))a.push({l:"Társbetegség (autoimmun/SLE-APS, daganat, vese/nephrosis, IBD)",pts:3});
    if(P("f_thr"))a.push({l:"Első fokú rokon fiatalkori thrombosisa/thrombophiliája",pts:1});
    return a;
  }
  function computeVTE(){
    var auto=vteAuto(), score=0, high=false, items=[];
    auto.forEach(function(x){score+=x.pts;items.push(x.l+" (+"+x.pts+")");});
    VTE_MANUAL.forEach(function(m){var c=q("#"+m.id);if(c&&c.checked){score+=m.pts;items.push(m.l+" (+"+m.pts+")");if(m.high)high=true;}});
    var plan;
    if(high)plan="MAGAS KOCKÁZAT: antenatális LMWH a terhesség egészében (korábbi VTE / igazolt magas kockázatú thrombophilia — a pontszámtól függetlenül).";
    else if(score>=4)plan="≥4 pont: profilaktikus LMWH az I. trimesztertől a szülés utáni 6. hétig.";
    else if(score===3)plan="3 pont: profilaktikus LMWH a 28. héttől a szülés utáni 6. hétig.";
    else plan="<3 pont: korai mobilizáció, hidratáció; ismételt kockázatbecslés állapotváltozáskor és intrapartum/postpartum.";
    return {score:score,high:high,plan:plan,items:items};
  }

  /* fullPIERS severe-feature flag — inputs auto-fill from labs (lb_plt/lb_creat/lb_got). NOT the validated probability. */
  function computePiers(){
    var ga=num("ga"), sp=num("c_spo2");
    var plt=num("c_plt"); if(isNaN(plt))plt=num("lb_plt");
    var cr=num("c_creat2"); if(isNaN(cr))cr=num("lb_creat");
    var ast=num("c_ast"); if(isNaN(ast))ast=num("lb_got");
    var chest=q("#c_chest")&&q("#c_chest").checked;
    var any=[], severe=[];
    if(!isNaN(sp)){ if(sp<90)severe.push("SpO₂ "+sp+"%"); else if(sp<93)any.push("SpO₂ "+sp+"%"); }
    if(!isNaN(plt)){ if(plt<50)severe.push("thrombocyta "+plt); else if(plt<100)any.push("thrombocyta "+plt); }
    if(!isNaN(cr)){ if(cr>125)severe.push("kreatinin "+cr+" µmol/l"); else if(cr>90)any.push("kreatinin "+cr+" µmol/l"); }
    if(!isNaN(ast)){ if(ast>150)severe.push("AST "+ast+" U/l"); else if(ast>75)any.push("AST "+ast+" U/l"); }
    if(chest)severe.push("mellkasi fájdalom/dyspnoe");
    if(!isNaN(ga)&&ga<34)any.push("korai gestatiós kor (<34. hét)");
    if(!any.length&&!severe.length)return {txt:"A paraméterek a laborból automatikusan beszámítanak (thrombocyta, kreatinin, AST); az SpO₂-t és a tünetet add meg. A validált fullPIERS-valószínűséget a hivatalos kalkulátorral számítsd (a beágyazott keret lent).",flag:0};
    var parts=[];
    if(severe.length)parts.push("SÚLYOS jellemző: "+severe.join(", "));
    if(any.length)parts.push("figyelendő: "+any.join(", "));
    return {txt:parts.join(" · ")+" — NEM a validált valószínűség; a fullPIERS-kockázatot a hivatalos kalkulátorral számítsd ki (a beágyazott keret lent).",flag:severe.length?2:1};
  }

  function set(id,t){var e=q("#"+id);if(e)e.textContent=t;}
  function computeAll(){
    var lines=[];
    // QTc
    var qt=num("c_qt"), hr=num("c_hr");
    if(qt>0&&hr>0){ var rr=60/hr; var baz=qt/Math.sqrt(rr), fri=qt/cbrt(rr);
      var ib=baz>500?"jelentősen megnyúlt":baz>470?"megnyúlt (nő)":baz>=450?"határérték":"normális";
      set("res_qtc","QTc (Bazett) "+Math.round(baz)+" ms · (Fridericia) "+Math.round(fri)+" ms — "+ib);
      lines.push("QTc "+Math.round(baz)+" ms (Bazett) — "+ib);
    } else set("res_qtc","Add meg a QT-t (ms) és a pulzust (/perc).");
    // HOMA-IR (glucose auto from lb_glu)
    var glu=num("c_glu"); if(isNaN(glu))glu=num("lb_glu"); var ins=num("c_ins");
    if(glu>0&&ins>0){ var homa=glu*ins/22.5; var ih=homa>=2.5?"inzulinrezisztencia valószínű":"normál tartomány";
      set("res_homa","HOMA-IR "+homa.toFixed(2)+" — "+ih+" (a vércukor a laborból automatikusan; terhességben az inzulinrezisztencia élettanilag fokozott)");
      lines.push("HOMA-IR "+homa.toFixed(2)+" — "+ih);
    } else set("res_homa","Éhomi inzulin (µU/ml) szükséges; a vércukor a laborból automatikusan beszámít.");
    // mWHO (+ auto suggestion from cardiac lesions)
    var mw=val("c_mwho");
    if(mw&&MWHO[mw]){ set("res_mwho","mWHO "+mw+" — "+MWHO[mw]); lines.push("mWHO "+mw); }
    else { var sug=[];
      if(P("f_chan"))sug.push("örökletes ritmuszavar (LQTS) — QT-függő");
      if(P("s_dev"))sug.push("pacemaker/ICD — jellemzően III+");
      if(P("s_card"))sug.push("ismert szívbetegség — a léziótól függ (II–IV)");
      if(P("s_arr"))sug.push("ritmuszavar — gyakran II");
      set("res_mwho", sug.length?("Javaslat az anamnézisből: "+sug.join("; ")+". Válaszd ki a pontos osztályt."):"Válaszd ki a módosított WHO osztályt (a szívlézió alapján).");
    }
    // RCOG-VTE (auto from anamnesis)
    var v=computeVTE();
    set("res_vte","Összpontszám: "+v.score+(v.high?" (magas kockázatú tényező jelen)":"")+" — "+v.plan+"  |  Beszámítva: "+(v.items.length?v.items.join(", "):"nincs beszámítható tényező"));
    lines.push("RCOG-VTE "+v.score+" pont — "+(v.high?"magas kockázat, LMWH végig":(v.score>=4?"LMWH I. trimesztertől":(v.score===3?"LMWH 28. héttől":"nem indokolt rutin LMWH"))));
    // fullPIERS flag (labs auto)
    var pr=computePiers(); set("res_piers",pr.txt);
    if(pr.flag)lines.push("fullPIERS "+(pr.flag===2?"SÚLYOS figyelmeztető jel":"figyelmeztető jel")+" — validált kockázat a hivatalos kalkulátorral");
    // FMF transcription markers (live, from BP)
    var ext=q("#res_ext");
    if(ext){ var bp=val("bp"); var map=""; var mm=bp.match(/(\d+)\D+(\d+)/); if(mm){var sB=+mm[1],dB=+mm[2]; map=Math.round(dB+(sB-dB)/3);}
      var hh2=num("height"),ww2=num("weight"); var bmi2=(hh2>0&&ww2>0)?(ww2/Math.pow(hh2/100,2)).toFixed(1):"";
      var CMx={spontan:"spontán",ovind:"ovuláció-indukció",insem:"IUI",ivf:"IVF",icsi:"ICSI",fet:"FET",donor:"donor"};
      var d=[]; var a;
      a=val("age"); if(a)d.push("kor "+a);
      if(hh2)d.push("magasság "+hh2+" cm"); if(ww2)d.push("súly "+ww2+" kg"); if(bmi2)d.push("BMI "+bmi2);
      a=val("ga"); if(a)d.push("GA "+a+". hét");
      if(map)d.push("MAP "+map+" Hgmm"); if(bp)d.push("RR "+bp);
      a=CMx[val("conception")]; if(a)d.push("fogantatás "+a);
      if(P("s_dm")||P("s_t1dm")||P("s_t2dm"))d.push("diabetes: igen");
      if(P("r_pe"))d.push("korábbi PE: igen");
      if(P("l_smoke"))d.push("dohányzás: igen");
      var lab=[]; a=val("lb_plt")||"—"; lab.push("thrombocyta "+a); a=val("lb_creat")||"—"; lab.push("kreatinin "+a); a=val("lb_got")||"—"; lab.push("AST "+a); a=val("c_spo2")||"—"; lab.push("SpO₂ "+a);
      ext.textContent="Átviteli adatok — "+(d.length?d.join("; "):"(tölts ki adatokat)")+".  fullPIERS/labor: "+lab.join("; ")+".  (UtA-PI, PlGF, PAPP-A a keretbe kézzel.)"; }
    window.__v12lines=lines;
    return lines;
  }

  function enrich12(){
    var pre=q("#anamOut"); if(!pre)return; var t=pre.textContent||"";
    if(!t||/Töltsd ki a kérdőívet/.test(t))return;
    var lines=window.__v12lines||[]; if(!lines.length)return;
    var block="TOVÁBBI KOCKÁZATI MODELLEK / KALKULÁTOROK (automatikus):\n"+lines.map(function(x){return "  • "+x;}).join("\n");
    t=t.replace(/\nTOVÁBBI KOCKÁZATI MODELLEK[\s\S]*?(?=\n─|\nNYILATKOZAT:|$)/,"");
    var i=t.indexOf("NYILATKOZAT:");
    if(i>=0){ var ls=t.lastIndexOf("\n",i-1); if(ls<0)ls=i; t=t.slice(0,ls)+"\n"+block+"\n"+t.slice(ls+1); }
    else t=t+"\n"+block;
    pre.textContent=t;
  }

  var FMF=[
    ["Preeclampsia (I. trim. kompetitív kockázat)","https://courses.fetalmedicine.com/calculator/pe?locale=en"],
    ["Vetélés (miscarriage)","https://courses.fetalmedicine.com/calculator/miscarriage?locale=en"],
    ["Halvaszületés (stillbirth)","https://courses.fetalmedicine.com/calculator/stillbirth?locale=en"],
    ["SGA (kis súly)","https://courses.fetalmedicine.com/calculator/sga?locale=en"],
    ["Macrosomia","https://courses.fetalmedicine.com/calculator/macrosomia?locale=en"],
    ["Terhesség keltezése (dating)","https://archive.fetalmedicine.org/research/pregnancyDating"],
    ["Magzati növekedés (growth)","https://archive.fetalmedicine.org/research/assess/growth"],
    ["Arteria uterina PI percentilis","https://archive.fetalmedicine.org/research/utpi"]
  ];
  var PIERS_LINKS=[
    ["fullPIERS – Evidencio (interaktív)","https://www.evidencio.com/models/show/1155"],
    ["fullPIERS – Perinatology.com","https://perinatology.com/calculators/fulpiers.htm"],
    ["fullPIERS – UBC PRE-EMPT","https://pre-empt.obgyn.ubc.ca/home-page/past-projects/fullpiers/"]
  ];
  /* embedded external calculators — inline IFRAME on the SAME page; NO new window, popups sandboxed off */
  function makeFrame(url){ var f=document.createElement("iframe"); f.src=url; f.setAttribute("loading","lazy"); f.setAttribute("referrerpolicy","no-referrer");
    f.setAttribute("sandbox","allow-scripts allow-same-origin allow-forms");
    f.style.cssText="width:100%;height:560px;border:1px solid rgba(127,127,127,.35);border-radius:8px;margin-top:8px;background:#fff"; return f; }
  function embedRows(arr){ return '<div style="margin-top:6px">'+arr.map(function(a){
      return '<div class="embedrow" style="margin:4px 0;border-top:1px solid rgba(127,127,127,.15);padding-top:6px">'
        +'<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap"><span style="font-size:12px;flex:1 1 220px">'+a[0]+'</span>'
        +'<button type="button" class="chip embedbtn" data-u="'+a[1]+'" style="padding:2px 10px">Számítás beágyazva ▾</button></div>'
        +'<div class="embedhost"></div></div>';
    }).join("")+'</div>'; }
  function wireEmbed(){ qq(".embedbtn").forEach(function(b){ if(b.__w)return; b.__w=1; b.addEventListener("click",function(){
      var row=b.parentNode.parentNode; var host=row.querySelector(".embedhost"); if(!host)return;
      if(host.childNodes.length){ host.innerHTML=""; b.textContent="Számítás beágyazva ▾"; }
      else { host.appendChild(makeFrame(b.getAttribute("data-u"))); b.textContent="Keret bezárása ▴"; }
    }); }); }
  function vteBoxHTML(){ return VTE_MANUAL.map(function(m){
      return '<label style="display:block;font-size:12px;margin:2px 0"><input type="checkbox" id="'+m.id+'" class="vtebox"> '+m.l+' (+'+m.pts+')</label>';
    }).join(""); }

  function rowsHTML(){
    return ''
    +'<div class="calcrow"><h5>QTc (Bazett & Fridericia)</h5><div class="cin"><label>QT (ms) <input type="number" id="c_qt" min="200" max="700"></label> <label>Pulzus (/perc) <input type="number" id="c_hr" min="30" max="220"></label></div><div class="cres" id="res_qtc">Add meg a QT-t (ms) és a pulzust (/perc).</div></div>'
    +'<div class="calcrow"><h5>HOMA-IR (inzulinrezisztencia)</h5><div class="cin"><label>Éhomi inzulin (µU/ml) <input type="number" step="0.1" id="c_ins"></label></div><p class="hint" style="margin:4px 0 0">Az éhomi vércukor a Laborértékek szekcióból automatikusan beszámít.</p><div class="cres" id="res_homa">Éhomi inzulin szükséges; a vércukor a laborból automatikusan.</div></div>'
    +'<div class="calcrow"><h5>mWHO — anyai kardiovaszkuláris kockázati osztály</h5><div class="cin"><label>Osztály <select id="c_mwho"><option value="">—</option><option>I</option><option>II</option><option>II–III</option><option>III</option><option>IV</option></select></label></div><div class="cres" id="res_mwho">Válaszd ki a módosított WHO osztályt (a szívlézió alapján).</div></div>'
    +'<div class="calcrow"><h5>RCOG VTE-kockázat (antenatális, Green-top 37a) — automatikus</h5><p class="hint" style="margin:0 0 6px">Életkor, BMI, ikerterhesség, ART, dohányzás és a rögzített társbetegségek/thrombophilia AUTOMATIKUSAN beszámítanak az anamnézisből. Csak a nem rögzített, aktuális tényezőket jelöld:</p><div class="cin" id="vte_box">'+vteBoxHTML()+'</div><div class="cres" id="res_vte">—</div></div>'
    +'<div class="calcrow"><h5>fullPIERS — a validált valószínűség beágyazott kalkulátorral</h5><p class="hint" style="margin:0 0 6px">Helyi gyorsjelzés: a thrombocyta, kreatinin és AST a laborból automatikusan; az SpO₂-t és a tünetet add meg. A pontos, validált valószínűséget a lenti keret számolja ki (ugyanezen a lapon).</p><div class="cin"><label>SpO₂ (%) <input type="number" id="c_spo2"></label> <label style="white-space:nowrap"><input type="checkbox" id="c_chest"> mellkasi fájdalom/dyspnoe</label></div><div class="cres" id="res_piers">Add meg a paramétereket a figyelmeztető jelekhez.</div>'+embedRows(PIERS_LINKS)+'</div>'
    +'<div class="calcrow"><h5>Külső validált kalkulátorok — Fetal Medicine Foundation (FMF)</h5><p class="hint" style="margin:0 0 4px">A másik oldal a beágyazott keretben számol (nem nyílik új ablak). A keresztoldalú korlát miatt a keret eredményét a felület nem tudja automatikusan a szövegbe emelni — az alábbi átviteli adatokat gépeld be a keretbe:</p><div class="cres" id="res_ext"></div>'+embedRows(FMF)+'</div>';
  }

  function wireCopy(){ qq(".copyurl").forEach(function(b){ if(b.__w)return; b.__w=1; b.addEventListener("click",function(){copyText(b.getAttribute("data-u"));}); }); }
  function mount(){
    var host=q("#calcHost"); if(!host||q("#c_qt"))return;
    host.insertAdjacentHTML("beforeend", rowsHTML());
    ["c_qt","c_hr","c_ins","c_spo2"].forEach(function(id){var e=q("#"+id);if(e)e.addEventListener("input",refresh);});
    ["c_mwho"].forEach(function(id){var e=q("#"+id);if(e)e.addEventListener("change",refresh);});
    ["c_chest"].forEach(function(id){var e=q("#"+id);if(e)e.addEventListener("change",refresh);});
    qq(".vtebox").forEach(function(c){c.addEventListener("change",refresh);});
    wireEmbed();
  }
  function refresh(){ try{computeAll();}catch(e){window.__v12err=(e&&e.message)||String(e);} try{ if(typeof window.generate==="function")window.generate(); }catch(e){} }

  if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",function(){mount();computeAll();}); else {mount();computeAll();}
  if(typeof window.generate==="function"){
    var og=window.generate;
    window.generate=function(){ var r=og.apply(this,arguments); try{computeAll();}catch(e){} try{enrich12();}catch(e){window.__v12err=(e&&e.message)||String(e);} return r; };
    try{ window.generate(); }catch(e){}
  }
})();
</script>
```

<a id="v13-21402388"></a>

### v13 — Kibővített natív kalkulátorok

Sorok 2140–2388 (249 sor).

```javascript
<script>
/* ===================== v13: extended native calculators ===================== */
(function(){
  "use strict";
  var q=function(s){return document.querySelector(s);};
  var qq=function(s){return [].slice.call(document.querySelectorAll(s));};
  function numv(id){var e=q("#"+id);if(!e)return NaN;var s=((e.value||"")+"").replace(",",".").trim();return s===""?NaN:parseFloat(s);}
  function val(id){var e=q("#"+id);return e?((e.value||"")+"").trim():"";}
  function P(id){return (typeof state!=="undefined")&&state.ros&&state.ros[id]&&state.ros[id].v==="pos";}
  function set(id,t){var e=q("#"+id);if(e)e.textContent=t;}
  var log10=Math.log10||function(x){return Math.log(x)/Math.LN10;};

  /* ---------- EPDS-10 (Cox 1987) — value = item score (reverse already encoded) ---------- */
  var EPDS=[
   ["Tudtam nevetni és a dolgok vidám oldalát látni",[["Annyira, mint mindig",0],["Már nem egészen annyira",1],["Határozottan kevésbé",2],["Egyáltalán nem",3]]],
   ["Örömmel tekintettem a dolgok elé",[["Annyira, mint valaha",0],["Kissé kevésbé, mint korábban",1],["Határozottan kevésbé",2],["Alig",3]]],
   ["Szükségtelenül magamat hibáztattam, ha valami rosszul ment",[["Igen, legtöbbször",3],["Igen, néha",2],["Nem túl gyakran",1],["Soha",0]]],
   ["Ok nélkül szorongtam vagy aggódtam",[["Egyáltalán nem",0],["Alig valaha",1],["Igen, néha",2],["Igen, nagyon gyakran",3]]],
   ["Ok nélkül féltem vagy pánikot éreztem",[["Igen, elég sokszor",3],["Igen, néha",2],["Nem, nem nagyon",1],["Nem, egyáltalán",0]]],
   ["A dolgok a fejemre nőttek",[["Igen, többnyire nem bírtam megbirkózni",3],["Igen, néha nehezebben, mint szoktam",2],["Nem, többnyire jól megbirkóztam",1],["Nem, ugyanolyan jól, mint mindig",0]]],
   ["Olyan boldogtalan voltam, hogy nehezen aludtam",[["Igen, legtöbbször",3],["Igen, néha",2],["Nem túl gyakran",1],["Egyáltalán nem",0]]],
   ["Szomorúnak vagy nyomorultnak éreztem magam",[["Igen, legtöbbször",3],["Igen, elég gyakran",2],["Nem túl gyakran",1],["Egyáltalán nem",0]]],
   ["Olyan boldogtalan voltam, hogy sírtam",[["Igen, legtöbbször",3],["Igen, elég gyakran",2],["Csak alkalmanként",1],["Soha",0]]],
   ["Az a gondolat, hogy ártsak magamnak, megfordult a fejemben",[["Igen, elég gyakran",3],["Néha",2],["Alig valaha",1],["Soha",0]]]
  ];
  function epdsHTML(){
    var r='<p class="hint" style="margin:0 0 6px">Elmúlt 7 nap. Teljes perinatális depresszió-skála (a PHQ-2 kiegészítése).</p>';
    EPDS.forEach(function(it,i){ var opts='<option value="">—</option>'+it[1].map(function(o){return '<option value="'+o[1]+'">'+o[0]+'</option>';}).join("");
      r+='<label class="fld" style="margin:4px 0;font-size:12px">'+(i+1)+'. '+it[0]+'<select class="epds" data-i="'+i+'">'+opts+'</select></label>'; });
    return r;
  }
  function epdsScore(){ var done=0,sum=0,item10=NaN;
    qq(".epds").forEach(function(s){ var v=s.value; if(v!==""){done++;var n=parseInt(v,10);sum+=n; if(s.getAttribute("data-i")==="9")item10=n;} });
    return {done:done,sum:sum,item10:item10};
  }

  /* ---------- AUDIT-C ---------- */
  var AUDITC=[
   ["Milyen gyakran iszik alkoholt?",[["Soha",0],["Havonta vagy ritkábban",1],["Havi 2–4 alkalommal",2],["Heti 2–3 alkalommal",3],["Heti 4 vagy több",4]]],
   ["Ha iszik, jellemzően hány italt fogyaszt egy nap?",[["1–2",0],["3–4",1],["5–6",2],["7–9",3],["10 vagy több",4]]],
   ["Milyen gyakran iszik 6 vagy több italt egy alkalommal?",[["Soha",0],["Ritkábban, mint havonta",1],["Havonta",2],["Hetente",3],["Naponta vagy szinte naponta",4]]]
  ];
  function auditHTML(){ return AUDITC.map(function(it,i){ var opts='<option value="">—</option>'+it[1].map(function(o){return '<option value="'+o[1]+'">'+o[0]+'</option>';}).join("");
      return '<label class="fld" style="margin:4px 0;font-size:12px">'+it[0]+'<select class="auditc">'+opts+'</select></label>'; }).join(""); }
  function auditScore(){ var done=0,sum=0; qq(".auditc").forEach(function(s){if(s.value!==""){done++;sum+=parseInt(s.value,10);}}); return {done:done,sum:sum}; }

  /* ---------- CMQCC PPH risk factors ---------- */
  var PPH_HIGH=[
   {id:"pph_prev",l:"Placenta praevia / low-lying / accreta-spektrum"},
   {id:"pph_pprevpph",l:"Korábbi postpartum vérzés (PPH)"},
   {id:"pph_coag",l:"Ismert véralvadási zavar"},
   {id:"pph_bleed",l:"Aktív vérzés felvételkor"},
   {id:"pph_hct",l:"Hematokrit < 30% + egyéb rizikó"}
  ];
  var PPH_MED=[
   {id:"pph_grand",l:"Nagy paritás (≥ 4 szülés)"},
   {id:"pph_fib",l:"Nagy myoma"},
   {id:"pph_poly",l:"Polyhydramnion"},
   {id:"pph_chorio",l:"Chorioamnionitis / láz"},
   {id:"pph_oxy",l:"Elhúzódó oxytocin / elhúzódó szülés"},
   {id:"pph_mg",l:"Magnézium-szulfát kezelés"}
  ];
  function pphCompute(){
    var high=PPH_HIGH.filter(function(x){var c=q("#"+x.id);return c&&c.checked;}).map(function(x){return x.l;});
    var med=PPH_MED.filter(function(x){var c=q("#"+x.id);return c&&c.checked;}).map(function(x){return x.l;});
    if(["dcda","mcda","mcma"].indexOf(val("twins"))>=0)med.push("többes terhesség");
    if(P("su_cs"))med.push("korábbi CS/méhműtét");
    if(P("r_macro"))med.push("korábbi makroszómia");
    var hh=numv("height"),ww=numv("weight"); if(hh>0&&ww>0&&(ww/Math.pow(hh/100,2))>35)med.push("BMI>35");
    var counted=(high.concat(med)); var suffix=counted.length?("  |  Beszámítva: "+counted.join(", ")):"";
    if(high.length||med.length>=2) return {lvl:"MAGAS",txt:"MAGAS kockázat — keresztpróba (crossmatch), aktív III. szak, vérkészítmény elérhetőség, PPH-protokoll készenlét."+suffix};
    if(med.length>=1) return {lvl:"KÖZEPES",txt:"KÖZEPES kockázat — vércsoport + antitest-szűrés (type & screen), aktív III. szak, fokozott megfigyelés."+suffix};
    return {lvl:"ALACSONY",txt:"ALACSONY kockázat — vércsoport dokumentálás, standard aktív III. szak."+suffix};
  }

  /* ---------- RCOG postnatal VTE (auto + manual) ---------- */
  var PNVTE_MANUAL=[
   {id:"pn_csl",l:"Császármetszés vajúdásban",pts:2},
   {id:"pn_cse",l:"Elektív császármetszés",pts:1},
   {id:"pn_pph",l:"PPH > 1 liter vagy transzfúzió",pts:1},
   {id:"pn_ptb",l:"Koraszülés (< 37. hét) ebben a terhességben",pts:1},
   {id:"pn_still",l:"Halvaszületés ebben a terhességben",pts:1},
   {id:"pn_prolab",l:"Elhúzódó vajúdás (> 24 óra)",pts:1},
   {id:"pn_midforc",l:"Középvezetéses / rotációs műtétes szülés",pts:1},
   {id:"pn_pvte",l:"Korábbi VTE",pts:4,high:true},
   {id:"pn_thrhi",l:"Magas kockázatú thrombophilia",pts:3,high:true}
  ];
  function pnvteAuto(){ var a=[]; var age=numv("age"); var hh=numv("height"),ww=numv("weight"); var bmi=(hh>0&&ww>0)?ww/Math.pow(hh/100,2):null;
    if(age>35)a.push({l:"Életkor > 35",pts:1});
    if(bmi&&bmi>=40)a.push({l:"BMI ≥ 40",pts:2}); else if(bmi&&bmi>=30)a.push({l:"BMI 30–39,9",pts:1});
    if(["dcda","mcda","mcma"].indexOf(val("twins"))>=0)a.push({l:"Ikerterhesség",pts:1});
    if(P("l_smoke"))a.push({l:"Dohányzás",pts:1});
    if(P("s_ai")||P("s_onc")||P("s_ren")||P("s_liv"))a.push({l:"Társbetegség",pts:3});
    if(P("s_thr"))a.push({l:"Thrombophilia/thrombosis az anamnézisben",pts:1});
    if(P("f_thr"))a.push({l:"Családi VTE",pts:1});
    return a; }
  function pnvteCompute(){ var auto=pnvteAuto(),score=0,high=false,items=[];
    auto.forEach(function(x){score+=x.pts;items.push(x.l+" (+"+x.pts+")");});
    PNVTE_MANUAL.forEach(function(m){var c=q("#"+m.id);if(c&&c.checked){score+=m.pts;items.push(m.l+" (+"+m.pts+")");if(m.high)high=true;}});
    var plan; if(high)plan="MAGAS: legalább 6 hét postnatalis LMWH.";
    else if(score>=4)plan="≥4 pont: 6 hét postnatalis LMWH mérlegelése.";
    else if(score===2||score===3)plan="2–3 pont: legalább 10 nap postnatalis LMWH.";
    else plan="<2 pont: korai mobilizáció, hidratáció.";
    return {score:score,high:high,plan:plan,items:items}; }

  /* ---------- rows HTML ---------- */
  function chkList(arr,cls){ return arr.map(function(m){return '<label style="display:block;font-size:12px;margin:2px 0"><input type="checkbox" id="'+m.id+'" class="'+cls+'"> '+m.l+(m.pts?(" (+"+m.pts+")"):"")+'</label>';}).join(""); }
  function rowsHTML(){
    return ''
    +'<div class="calcrow"><h5>OGTT — GDM osztályozás (IADPSG / WHO 2013)</h5><div class="cin"><label>Éhomi (mmol/l) <input type="number" step="0.1" id="k_og0"></label> <label>60 perc <input type="number" step="0.1" id="k_og1"></label> <label>120 perc <input type="number" step="0.1" id="k_og2"></label></div><div class="cres" id="res_ogtt">Küszöb: éhomi ≥5,1 · 1h ≥10,0 · 2h ≥8,5 mmol/l (bármelyik → GDM).</div></div>'
    +'<div class="calcrow"><h5>GDM korai kockázat (az anamnézisből)</h5><div class="cres" id="res_gdmrisk">—</div></div>'
    +'<div class="calcrow"><h5>HOMA-%B és QUICKI</h5><p class="hint" style="margin:0 0 4px">Az éhomi inzulin (HOMA-IR mező) és a labor-vércukor alapján.</p><div class="cres" id="res_homab">—</div></div>'
    +'<div class="calcrow"><h5>Becsült magzati súly (EFW, Hadlock-4)</h5><div class="cin"><label>BPD (cm) <input type="number" step="0.1" id="k_bpd"></label> <label>HC (cm) <input type="number" step="0.1" id="k_hc"></label> <label>AC (cm) <input type="number" step="0.1" id="k_ac"></label> <label>FL (cm) <input type="number" step="0.1" id="k_fl"></label></div><div class="cres" id="res_efw">Add meg a 4 biometriai adatot (cm).</div></div>'
    +'<div class="calcrow"><h5>CRL → terhességi kor (Robinson-Fielding)</h5><div class="cin"><label>CRL (mm) <input type="number" step="0.1" id="k_crl"></label></div><div class="cres" id="res_crl">—</div></div>'
    +'<div class="calcrow"><h5>Cerebroplacentáris arány (CPR = MCA-PI / UA-PI)</h5><div class="cin"><label>MCA-PI <input type="number" step="0.01" id="k_mca"></label> <label>UA-PI <input type="number" step="0.01" id="k_ua"></label></div><div class="cres" id="res_cpr">—</div></div>'
    +'<div class="calcrow"><h5>Magzatvíz-index (AFI)</h5><div class="cin"><label>AFI (cm) <input type="number" step="0.1" id="k_afi"></label></div><div class="cres" id="res_afi">—</div></div>'
    +'<div class="calcrow"><h5>sFlt-1 / PlGF arány (preeclampsia)</h5><div class="cin"><label>Arány (vagy add meg külön) <input type="number" step="1" id="k_ratio"></label> <label>sFlt-1 (pg/ml) <input type="number" id="k_sflt"></label> <label>PlGF (pg/ml) <input type="number" step="0.1" id="k_plgf"></label></div><div class="cres" id="res_sflt">Küszöb: ≤38 kizárja a PE-t 1 hétre; magas érték beindulást valószínűsít.</div></div>'
    +'<div class="calcrow"><h5>ICP — epesav döntéstámogatás</h5><div class="cin"><label>Össz epesav (µmol/l) <input type="number" step="0.1" id="k_ba"></label></div><div class="cres" id="res_icp">—</div></div>'
    +'<div class="calcrow"><h5>Ganzoni — vas-deficit (IV vaspótlás)</h5><div class="cin"><label>Cél-Hb (g/l) <input type="number" id="k_hbtar" value="120"></label></div><p class="hint" style="margin:4px 0 0">Testsúly és az aktuális Hb (labor) alapján.</p><div class="cres" id="res_iron">—</div></div>'
    +'<div class="calcrow"><h5>Korrigált kalcium és nátrium</h5><div class="cin"><label>Mért Ca (mmol/l) <input type="number" step="0.01" id="k_ca"></label> <label>Mért Na (mmol/l) <input type="number" step="1" id="k_na"></label></div><p class="hint" style="margin:4px 0 0">Albumin és vércukor a laborból automatikusan.</p><div class="cres" id="res_cana">—</div></div>'
    +'<div class="calcrow"><h5>eGFR — CKD-EPI 2021 (rassz-mentes, nő)</h5><p class="hint" style="margin:0 0 4px">Életkor és kreatinin (labor) alapján. Terhességben nem validált — tájékoztató.</p><div class="cres" id="res_ckd">—</div></div>'
    +'<div class="calcrow"><h5>EPDS-10 — perinatális depresszió-skála</h5><div class="cin" id="epds_box" style="display:block">'+epdsHTML()+'</div><div class="cres" id="res_epds">Töltsd ki mind a 10 tételt.</div></div>'
    +'<div class="calcrow"><h5>AUDIT-C — alkoholszűrés</h5><div class="cin" id="audit_box" style="display:block">'+auditHTML()+'</div><div class="cres" id="res_audit">—</div></div>'
    +'<div class="calcrow"><h5>Shock index (vérzés/keringés)</h5><div class="cin"><label>Pulzus (/perc) <input type="number" id="k_hr2"></label> <label>Szisztolés RR (Hgmm) <input type="number" id="k_sbp"></label></div><p class="hint" style="margin:4px 0 0">A szisztolés érték a Vérnyomás mezőből automatikusan, ha üres.</p><div class="cres" id="res_shock">—</div></div>'
    +'<div class="calcrow"><h5>CMQCC — postpartum vérzés (PPH) kockázat</h5><p class="hint" style="margin:0 0 4px">A többes terhesség, korábbi CS, makroszómia és BMI&gt;35 automatikusan bejelölődik.</p><div class="cin" style="display:block"><b style="font-size:11px">Magas kockázatú:</b>'+chkList(PPH_HIGH,"pphh")+'<b style="font-size:11px">Közepes kockázatú:</b>'+chkList(PPH_MED,"pphm")+'</div><div class="cres" id="res_pph">—</div></div>'
    +'<div class="calcrow"><h5>RCOG postnatalis VTE-kockázat</h5><p class="hint" style="margin:0 0 4px">Kor, BMI, iker, dohányzás, társbetegségek automatikusan; a szülési tényezőket jelöld:</p><div class="cin" style="display:block">'+chkList(PNVTE_MANUAL,"pnvte")+'</div><div class="cres" id="res_pnvte">—</div></div>';
  }

  /* ---------- compute ---------- */
  function computeAll(){
    var lines=[];
    // OGTT
    var g0=numv("k_og0"),g1=numv("k_og1"),g2=numv("k_og2");
    if(!isNaN(g0)||!isNaN(g1)||!isNaN(g2)){ var hit=[]; if(g0>=5.1)hit.push("éhomi "+g0); if(g1>=10.0)hit.push("1h "+g1); if(g2>=8.5)hit.push("2h "+g2);
      if(hit.length){ set("res_ogtt","GDM (IADPSG): pozitív — "+hit.join(", ")+" (küszöb felett)."); lines.push("OGTT: GDM-tartomány ("+hit.join(", ")+")"); }
      else set("res_ogtt","GDM (IADPSG): a megadott értékek küszöb alatt (éhomi <5,1; 1h <10,0; 2h <8,5)."); }
    else set("res_ogtt","Küszöb: éhomi ≥5,1 · 1h ≥10,0 · 2h ≥8,5 mmol/l (bármelyik → GDM).");
    // GDM risk (NICE-style)
    var gr=[]; var hh=numv("height"),ww=numv("weight"); var bmi=(hh>0&&ww>0)?ww/Math.pow(hh/100,2):null;
    if(bmi&&bmi>=30)gr.push("BMI ≥ 30"); if(P("r_gdm"))gr.push("korábbi GDM"); if(P("s_pcos"))gr.push("PCOS"); if(P("r_macro"))gr.push("korábbi makroszómia (≥4,5 kg)"); if(numv("age")>=40)gr.push("életkor ≥ 40");
    if(gr.length){ set("res_gdmrisk","GDM-kockázati tényező: "+gr.join(", ")+" → korai/ismételt OGTT javasolt (NICE)."); lines.push("GDM-kockázat: "+gr.join(", ")+" → OGTT javasolt"); }
    else set("res_gdmrisk","Nincs rögzített kiemelt GDM-kockázati tényező (a 24–28. heti OGTT az általános ajánlás szerint).");
    // HOMA-%B & QUICKI
    var ins=numv("c_ins"); var glu=numv("lb_glu");
    if(ins>0&&glu>0){ var beta=(glu>3.5)?(20*ins/(glu-3.5)):NaN; var quicki=1/(log10(ins)+log10(glu*18.0));
      set("res_homab","HOMA-%B ≈ "+(isNaN(beta)?"—":Math.round(beta)+"%")+" · QUICKI ≈ "+quicki.toFixed(3)+" (alacsonyabb QUICKI = nagyobb inzulinrezisztencia)"); }
    else set("res_homab","Kell: éhomi inzulin (HOMA mező) és labor-vércukor.");
    // EFW Hadlock-4
    var bpd=numv("k_bpd"),hc=numv("k_hc"),ac=numv("k_ac"),fl=numv("k_fl");
    if(bpd>0&&hc>0&&ac>0&&fl>0){ var lg=1.3596-0.00386*ac*fl+0.0064*hc+0.00061*bpd*ac+0.0424*ac+0.174*fl; var efw=Math.pow(10,lg);
      set("res_efw","EFW ≈ "+Math.round(efw)+" g (Hadlock, BPD/HC/AC/FL). Percentilis: az FMF-növekedés keret ad centilist."); lines.push("EFW ≈ "+Math.round(efw)+" g (Hadlock)"); }
    else set("res_efw","Add meg a 4 biometriai adatot (cm).");
    // CRL -> GA
    var crl=numv("k_crl");
    if(crl>0){ var days=8.052*Math.sqrt(crl)+23.73; var wk=Math.floor(days/7),dd=Math.round(days%7); set("res_crl","GA (CRL alapján) ≈ "+wk+" hét "+dd+" nap ("+Math.round(days)+" nap)."); }
    else set("res_crl","Add meg a CRL-t (mm) — 45–84 mm között validált.");
    // CPR
    var mca=numv("k_mca"),ua=numv("k_ua");
    if(mca>0&&ua>0){ var cpr=mca/ua; var f=cpr<1.08?" — KÓROSAN alacsony (placentáris elégtelenség gyanúja; GA-specifikus centilis szükséges)":" — a referencia GA-függő"; set("res_cpr","CPR = "+cpr.toFixed(2)+f); if(cpr<1.08)lines.push("CPR "+cpr.toFixed(2)+" — kórosan alacsony"); }
    else set("res_cpr","Add meg az MCA-PI és UA-PI értékeket.");
    // AFI
    var afi=numv("k_afi");
    if(!isNaN(afi)){ var a=afi<5?"oligohydramnion":afi>25?"polyhydramnion":afi>=24?"emelkedett":"normális (5–25 cm)"; set("res_afi","AFI "+afi+" cm — "+a+"."); if(afi<5||afi>25)lines.push("AFI "+afi+" cm — "+a); }
    else set("res_afi","Add meg az AFI-t (cm). Oligo <5, normál 5–25, poly >25.");
    // sFlt/PlGF
    var ratio=numv("k_ratio"); var sflt=numv("k_sflt"),plgf=numv("k_plgf"); if(isNaN(ratio)&&sflt>0&&plgf>0)ratio=sflt/plgf;
    if(!isNaN(ratio)){ var ga=numv("ga"); var early=(!isNaN(ga)&&ga<34); var ri;
      if(ratio<=38)ri="≤38: preeclampsia 1 héten belül nagy valószínűséggel kizárható.";
      else if(early?ratio<85:ratio<110)ri="köztes tartomány: fokozott megfigyelés, ismétlés.";
      else ri=(early?"≥85":"≥110")+": preeclampsia/mellékhatás nagy valószínűsége — szoros ellátás.";
      set("res_sflt","sFlt-1/PlGF arány = "+Math.round(ratio)+" — "+ri); if(ratio>38)lines.push("sFlt-1/PlGF "+Math.round(ratio)+" — emelkedett"); }
    else set("res_sflt","Küszöb: ≤38 kizárja a PE-t 1 hétre; magas érték beindulást valószínűsít.");
    // ICP bile acids
    var ba=numv("k_ba");
    if(!isNaN(ba)){ var sev,plan; if(ba>=100){sev="súlyos";plan="szülés a 35–36. hét körül mérlegelendő (emelkedett halvaszületési kockázat).";} else if(ba>=40){sev="közepes";plan="szülés a 38–39. hét körül; fokozott magzati követés.";} else {sev="enyhe";plan="szülés a 39. hét körül; tünetek és epesav követése.";}
      set("res_icp","Össz epesav "+ba+" µmol/l — "+sev+" ICP: "+plan); lines.push("ICP epesav "+ba+" µmol/l — "+sev); }
    else set("res_icp","Add meg az össz epesavat (µmol/l). <40 enyhe, 40–99 közepes, ≥100 súlyos.");
    // Ganzoni
    var wtk=numv("weight"); var hb=numv("lb_hgb"); var tgt=numv("k_hbtar"); if(isNaN(tgt))tgt=120;
    if(wtk>0&&hb>0){ var hbg=hb<25?hb*10:hb; var tg=tgt<25?tgt*10:tgt; var deficit=wtk*(tg-hbg)*0.24+(wtk>=35?500:15*wtk);
      if(deficit>0){ set("res_iron","Teljes vas-deficit ≈ "+Math.round(deficit)+" mg (Ganzoni; aktuális Hb "+hbg+" g/l, cél "+tg+" g/l)."); lines.push("Vas-deficit ≈ "+Math.round(deficit)+" mg (Ganzoni)"); }
      else set("res_iron","A Hb eléri a célértéket — számított deficit ~0."); }
    else set("res_iron","Kell: testsúly és aktuális hemoglobin (labor).");
    // corrected Ca + Na
    var ca=numv("k_ca"),alb=numv("lb_alb"),na=numv("k_na"),glu2=numv("lb_glu");
    var parts=[];
    if(ca>0&&alb>0)parts.push("korrigált Ca ≈ "+(ca+0.02*(40-alb)).toFixed(2)+" mmol/l (albumin "+alb+" g/l)");
    else if(ca>0)parts.push("korrigált Ca-hoz albumin (labor) kell");
    if(na>0&&glu2>5.5)parts.push("glükózra korrigált Na ≈ "+(na+0.3*(glu2-5.5)).toFixed(0)+" mmol/l");
    else if(na>0)parts.push("Na korrekció csak emelkedett vércukornál releváns");
    set("res_cana",parts.length?parts.join(" · "):"Add meg a mért Ca-t és/vagy Na-t (albumin és vércukor a laborból).");
    // CKD-EPI 2021 (female)
    var age=numv("age"),cr=numv("lb_creat");
    if(age>0&&cr>0){ var scr=cr/88.4; var k=0.7,al=-0.241; var egfr=142*Math.pow(Math.min(scr/k,1),al)*Math.pow(Math.max(scr/k,1),-1.200)*Math.pow(0.9938,age)*1.012;
      set("res_ckd","eGFR ≈ "+Math.round(egfr)+" ml/perc/1,73m² (CKD-EPI 2021, nő; terhességben tájékoztató)."); }
    else set("res_ckd","Kell: életkor és kreatinin (labor).");
    // EPDS
    var ep=epdsScore();
    if(ep.done===10){ var ei=ep.sum>=13?"valószínű depresszió (≥13)":ep.sum>=10?"lehetséges depresszió (10–12)":"nem valószínű (<10)";
      var s10=(!isNaN(ep.item10)&&ep.item10>0)?"  ⚠ 10. tétel pozitív: azonnali önsértés-kockázat értékelés!":"";
      set("res_epds","EPDS-10 = "+ep.sum+"/30 — "+ei+s10); lines.push("EPDS-10 "+ep.sum+"/30 — "+ei+(s10?" (10. tétel pozitív!)":"")); }
    else set("res_epds","Töltsd ki mind a 10 tételt ("+ep.done+"/10).");
    // AUDIT-C
    var au=auditScore();
    if(au.done===3){ var ai=au.sum>=3?"pozitív szűrés (nő ≥3) — rövid intervenció javasolt":"negatív"; set("res_audit","AUDIT-C = "+au.sum+"/12 — "+ai); if(au.sum>=3)lines.push("AUDIT-C "+au.sum+"/12 — pozitív"); }
    else set("res_audit","Töltsd ki mindhárom kérdést ("+au.done+"/3).");
    // Shock index
    var hr=numv("k_hr2"); var sbp=numv("k_sbp"); if(isNaN(sbp)){var bp=val("bp");var m=bp.match(/(\d+)/);if(m)sbp=+m[1];}
    if(hr>0&&sbp>0){ var si=hr/sbp; var sf=si>=1.0?" — kifejezetten emelkedett (súlyos vérzés/keringési instabilitás gyanúja)":si>=0.9?" — emelkedett (fokozott figyelem)":" — normális"; set("res_shock","Shock index = "+si.toFixed(2)+sf); if(si>=0.9)lines.push("Shock index "+si.toFixed(2)+" — emelkedett"); }
    else set("res_shock","Kell: pulzus és szisztolés vérnyomás.");
    // PPH
    var pph=pphCompute(); set("res_pph","PPH-kockázat: "+pph.txt); if(pph.lvl!=="ALACSONY")lines.push("PPH-kockázat: "+pph.lvl);
    // postnatal VTE
    var pv=pnvteCompute(); set("res_pnvte","Postnatalis VTE összpontszám: "+pv.score+(pv.high?" (magas rizikójú tényező)":"")+" — "+pv.plan+"  |  "+(pv.items.length?pv.items.join(", "):"nincs beszámítható tényező")); if(pv.high||pv.score>=2)lines.push("Postnatalis VTE "+pv.score+" pont — "+(pv.high?"6 hét LMWH":(pv.score>=4?"6 hét LMWH mérlegelés":"10 nap LMWH")));
    window.__v13lines=lines; return lines;
  }

  /* ---------- merge v12 + v13 lines into ONE anamnesis block ---------- */
  function enrich13(){
    var pre=q("#anamOut"); if(!pre)return; var t=pre.textContent||"";
    if(!t||/Töltsd ki a kérdőívet/.test(t))return;
    var all=[].concat(window.__v12lines||[], window.__v13lines||[]);
    t=t.replace(/\nTOVÁBBI KOCKÁZATI MODELLEK[\s\S]*?(?=\n─|\nNYILATKOZAT:|$)/,"");
    if(all.length){
      var block="TOVÁBBI KOCKÁZATI MODELLEK / KALKULÁTOROK (automatikus):\n"+all.map(function(x){return "  • "+x;}).join("\n");
      var i=t.indexOf("NYILATKOZAT:");
      if(i>=0){ var ls=t.lastIndexOf("\n",i-1); if(ls<0)ls=i; t=t.slice(0,ls)+"\n"+block+"\n"+t.slice(ls+1); }
      else t=t+"\n"+block;
    }
    pre.textContent=t;
  }

  function mount(){
    var host=q("#calcHost"); if(!host||q("#k_og0"))return;
    host.insertAdjacentHTML("beforeend", rowsHTML());
    qq("#calcHost input, #calcHost select").forEach(function(e){ if(e.__w13)return; e.__w13=1;
      if(e.id&&e.id.indexOf("c_")===0)return; // v12 inputs already wired
      e.addEventListener(e.tagName==="SELECT"?"change":"input",refresh); });
  }
  function refresh(){ try{computeAll();}catch(e){window.__v13err=(e&&e.message)||String(e);} try{ if(typeof window.generate==="function")window.generate(); }catch(e){} }

  if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",function(){mount();computeAll();}); else {mount();computeAll();}
  if(typeof window.generate==="function"){
    var og=window.generate;
    window.generate=function(){ var r=og.apply(this,arguments); try{computeAll();}catch(e){} try{enrich13();}catch(e){window.__v13err=(e&&e.message)||String(e);} return r; };
    try{ window.generate(); }catch(e){}
  }
})();
</script>
```

<a id="eeszt-adat-23902390"></a>

### EESZT adat — Beágyazott kódtörzsek (ATC, BNO, OENO, FEOR, irányítószám, ország)

Sorok 2390–2390 (1 sor).

```javascript
<script>window.__EESZT_EMBED={"bnoObs":[["B18","Krónikus vírusos hepatitis"],["B18.0","Krónikus vírusos B-típusú hepatitis delta-ágenssel"],["B18.1","Krónikus vírusos B-típusú hepatitis delta-ágens nélkül"],["B18.2","Krónikus vírusos C-típusú hepatitis"],["B18.8","Egyéb krónikus vírusos hepatitis"],["B18.9","Krónikus vírusos hepatitis k.m.n."],["B20","Fertozo és parazitás betegségeket eredményezo HIV betegség"],["B20.0","Mycobacteriális fertozést eredményezo HIV betegség"],["B20.1","Egyéb bakteriális fertozést eredményezo HIV betegség"],["B20.2","Cytomegalovírus betegséget eredményezo HIV betegség"],["B20.3","Egyéb vírusfertozést eredményezo HIV betegség"],["B20.4","Candidiasist eredményezo HIV betegség"],["B20.5","Egyéb gombás fertozést eredményezo HIV betegség"],["B20.6","Pneumocystis jirovecii tüdogyulladást eredményezo HIV betegség"],["B20.7","Többféle fertozést eredményezo HIV betegség"],["B20.8","Egyéb fertozo és parazitás betegséget eredményezo HIV betegség"],["B20.9","K.m.n. fertozo vagy parazitás betegséget eredményezo HIV betegség"],["D25","A méh simaizom daganata"],["D25.0","A méh submucosus leiomyomája"],["D25.1","A méh intramurális leiomyomája"],["D25.2","A méh subserosus leiomyomája"],["D25.9","A méh leiomyomája, k.m.n."],["D50","Vashiányos anaemia"],["D50.0","Vashiányos anaemia vérveszteségtol (krónikus)"],["D50.1","Sideropeniás dysphagia"],["D50.8","Egyéb vashiány anaemiák"],["D50.9","Vashiány anaemia k.m.n."],["D51","B12-vitamin hiány anaemia"],["D51.0","B12-vitamin hiány anaemia intrinsic faktor hiány miatt"],["D51.1","Anaemia B12-vitamin szelektív felszívódási zavara miatt, proteinuriával"],["D51.2","Transcobalamin-II hiány"],["D51.3","Egyéb vérszegénység étrendi B12-vitamin hiány miatt"],["D51.8","Egyéb B12 vitamin hiány miatti anaemia"],["D51.9","B12-vitaminhiány miatti anaemia, k.m.n."],["D52","Folsavhiány anaemia"],["D52.0","Folsavhiány anaemia, táplálkozási"],["D52.1","Gyógyszer indukált folsavhiány anaemia"],["D52.8","Egyéb folsavhiány anaem
/* … [ 580500 karakter csonkolva — beágyazott adat, lásd a törzsadat-fejezetet ] … */
```

<a id="v15-23912556"></a>

### v15 — EESZT törzsek, BNO minden mezőre, teendő-indoklás, betegtájékoztató

Sorok 2391–2556 (166 sor).

```javascript
<script>
/* ===================== v15: EESZT masters + all-field BNO + teendő rationale/leaflet ===================== */
(function(){
  "use strict";
  var q=function(s){return document.querySelector(s);};
  var E=window.__EESZT_EMBED||{};
  var S={ atc:E.atc||[], bno:E.bnoObs||[], oeno:E.oenoObs||[], feor:E.feor||[], irsz:E.irszmap||{}, fno:[], lab:[], orszag:E.orszag||[], xwalk:E.xwalk||{}, full:false };
  function toastMsg(m){ try{ if(typeof toast==="function"){toast(m);return;} }catch(e){} }
  function norm(s){return (s||"").toString().toLowerCase();}
  function numv(id){var e=q("#"+id);if(!e)return NaN;var s=((e.value||"")+"").replace(",",".").trim();return s===""?NaN:parseFloat(s);}
  function val(id){var e=q("#"+id);return e?((e.value||"")+"").trim():"";}
  function P(id){return (typeof state!=="undefined")&&state.ros&&state.ros[id]&&state.ros[id].v==="pos";}
  function C(id){var e=q("#"+id);return !!(e&&e.checked);}
  function copyText(t){ try{ if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(t);toastMsg("Kód másolva: "+t);return;} }catch(e){} try{var ta=document.createElement("textarea");ta.value=t;ta.style.position="fixed";ta.style.opacity="0";document.body.appendChild(ta);ta.select();document.execCommand("copy");document.body.removeChild(ta);toastMsg("Kód másolva: "+t);}catch(e){} }

  /* non-obstetric code names (shown even without the full bundle) */
  var CODEN={
   "Z88.9":"Gyógyszer-allergia az anamnézisben","Z88.0":"Penicillin-allergia","Z88.2":"Szulfonamid-allergia","Z88.6":"Analgetikum-allergia","Z91.018":"Étel-allergia az anamnézisben","T78.2":"Anaphylaxia",
   "Z72.0":"Dohányzás","Z72.1":"Alkoholfogyasztás",
   "O99.0":"Anaemia a terhességben","D64.9":"Anaemia k.m.n.","O99.1":"Vérképzőszervi betegség terhességben","D69.6":"Thrombocytopenia k.m.n.",
   "O12.1":"Terhességi proteinuria","R80":"Proteinuria","R94.4":"Kóros vesefunkciós lelet","N19":"Veseelégtelenség k.m.n.","R73.0":"Kóros glükóz-terheléses lelet","R74.0":"Emelkedett szérum-transzamináz","O26.6":"Terhességi májérintettség (ICP)",
   "Z56":"Munkahelyi / foglalkozási problémák","Z59":"Lakhatási és anyagi problémák","Z63":"Elsődleges támogató csoporttal kapcsolatos problémák (család/pár)","Z60.2":"Egyedülélettel / elégtelen támogatással kapcsolatos probléma","Z91.41":"Bántalmazás az anamnézisben","T74":"Bántalmazási szindróma",
   "O99.3":"Mentális/idegrendszeri betegség terhességben","F41.9":"Szorongásos zavar k.m.n.","F32.9":"Depresszív epizód k.m.n."
  };
  var _bnoMap=null;
  function bnoMap(){ if(_bnoMap&&_bnoMap.__n===S.bno.length)return _bnoMap; var m={}; S.bno.forEach(function(r){m[(r[0]||"").toUpperCase().replace(".","")]=r[1];}); m.__n=S.bno.length; _bnoMap=m; return m; }
  function bnoName(c){ if(CODEN[c])return CODEN[c]; var k=(c||"").toUpperCase().replace(".",""); var m=bnoMap(); return m[k]||m[k.slice(0,3)]||""; }

  /* medication -> ATC */
  function atcFor(name){ var n=norm(name).replace(/[0-9]+.*$/,"").trim(); if(n.length<3)return null;
    var toks=n.split(/[^a-záéíóöőúüű]+/).filter(function(x){return x.length>=4;}); if(!toks.length)return null; var best=null;
    for(var i=0;i<S.atc.length;i++){ var code=S.atc[i][0]; if(!code||code.length<5)continue; var hu=norm(S.atc[i][1]),en=norm(S.atc[i][2]);
      for(var j=0;j<toks.length;j++){ if(hu.indexOf(toks[j])>=0||en.indexOf(toks[j])>=0){ if(!best||code.length>best[0].length)best=[code,S.atc[i][1]]; } } } return best; }

  /* lab helpers with unit-guessing */
  function hbLow(){ var v=numv("lb_hgb"); if(isNaN(v))return false; if(v<25)v*=10; return v<110; }
  function pltLow(){ var v=numv("lb_plt"); return !isNaN(v)&&v<150; }
  function protPos(){ var s=val("lb_prot").toLowerCase(); if(!s)return false; if(/neg|0|nincs|^-$/.test(s))return false; return true; }
  function creatHigh(){ var v=numv("lb_creat"); return !isNaN(v)&&v>90; }
  function gluHigh(){ var v=numv("lb_glu"); return !isNaN(v)&&v>=7.0; }
  function astHigh(){ var v=numv("lb_got"); return !isNaN(v)&&v>35; }

  /* ===== BNO across ALL fields ===== */
  function computeBNO(){
    var out=[], seen={};
    function add(c){ if(c&&!seen[c]){seen[c]=1; var nm=bnoName(c); out.push(c+(nm?(" — "+nm):"")); } }
    // 1) diagnoses / complaints / repro / surgery
    Object.keys(S.xwalk).forEach(function(id){ if(P(id))S.xwalk[id].forEach(add); });
    // 2) allergies
    var d=(typeof state!=="undefined"&&state.allergyDrug)||[], f=(typeof state!=="undefined"&&state.allergyFood)||[];
    if(d.length){ add("Z88.9"); d.forEach(function(x){var n=norm(x.n); if(/penicillin|amoxi|ampi/.test(n))add("Z88.0"); if(/szulfon|sulfon|sulfa/.test(n))add("Z88.2"); if(/nsaid|ibupro|diclof|aspirin|asa|analg/.test(n))add("Z88.6"); if(x.anaf)add("T78.2");}); }
    if(f.length){ add("Z91.018"); if(f.some(function(x){return x.anaf;}))add("T78.2"); }
    // 3) lifestyle
    if(P("l_smoke"))add("Z72.0"); if(P("l_alc"))add("Z72.1");
    // 4) abnormal labs
    if(hbLow())add("O99.0"),add("D64.9");
    if(pltLow())add("O99.1"),add("D69.6");
    if(protPos())add("O12.1"),add("R80");
    if(creatHigh())add("R94.4");
    if(gluHigh())add("R73.0");
    if(astHigh())add("R74.0");
    if(numv("k_ba")>=40||P("s_icp"))add("O26.6");
    // 5) psychosocial / occupational
    if(C("ps_work"))add("Z56");
    if(C("ps_fin"))add("Z59");
    if(C("ps_rel"))add("Z63");
    if(C("ps_supp"))add("Z60.2");
    if(C("ps_viol"))add("Z91.41"),add("T74");
    if(C("ps_anx"))add("O99.3"),add("F41.9");
    return out;
  }

  /* ===== teendő rationale + patient leaflet knowledge base ===== */
  function bmi(){ var hh=numv("height"),ww=numv("weight"); return (hh>0&&ww>0)?ww/Math.pow(hh/100,2):null; }
  var KB=[
   {w:function(){var b=bmi();return b&&b>=30;},t:"Prekoncepcionális / gondozási testsúlymenedzsment (dietetika, mozgás).",
    i:"Az elhízás (BMI ≥ 30) igazoltan növeli a gesztációs diabetes, a preeclampsia, a thromboembolia, a makroszómia és a császármetszés kockázatát, és rontja az ultrahangos képalkotást. A célzott életmód-intervenció és reális súlygyarapodási cél (IOM) e kockázatokat mérsékli.",
    p:"A testsúly rendezése csökkenti a cukorbetegség, a magas vérnyomás és a szülési szövődmények esélyét — dietetikus és mozgásterv segít ebben."},
   {w:function(){return P("s_htn")||P("r_pe");},t:"Alacsony dózisú aszpirin (100–150 mg/nap) a 12–16. hét előtt megkezdve, vérnyomás- és proteinuria-követés.",
    i:"Krónikus hypertonia vagy korábbi preeclampsia esetén a preeclampsia visszatérési kockázata jelentős; a 16. hét előtt indított aszpirin a koraszülött preeclampsia kockázatát bizonyítottan csökkenti (ASPRE).",
    p:"Napi egy kis dózisú aszpirin (orvosi javaslatra) sokat csökkent a terhességi magas vérnyomás súlyos formájának esélyén. A vérnyomását rendszeresen ellenőrizzük."},
   {w:function(){return P("s_dm")||P("s_t1dm")||P("s_t2dm")||P("r_gdm")||P("s_pcos")||(bmi()&&bmi()>=30);},t:"Korai OGTT és glykaemiás életmód-optimalizálás.",
    i:"A cukoranyagcsere-zavar, PCOS, korábbi GDM vagy elhízás mellett a gesztációs diabetes kockázata magas; a korai felismerés és kezelés csökkenti a makroszómia, a szülési sérülés és az újszülöttkori szövődmények arányát.",
    p:"Egy cukorterheléses vizsgálattal időben kiszűrhető a terhességi cukorbetegség, amely étrenddel (és ha kell, inzulinnal) jól kezelhető."},
   {w:function(){return P("l_smoke");},t:"Dohányzás-elhagyás támogatása (tanácsadás, szükség esetén terápia).",
    i:"A dohányzás a magzati növekedési restrikció, a koraszülés, a lepényleválás és a halvaszületés független rizikófaktora; az elhagyás bármely terhességi szakaszban csökkenti e kockázatokat.",
    p:"A cigaretta elhagyása a legfontosabb dolog, amit a baba egészségéért tehet — segítséget és támogatást tudunk nyújtani hozzá."},
   {w:function(){return P("s_thr")||P("f_thr");},t:"Thrombophilia-értékelés; súly-alapú LMWH-thromboprofilaxis mérlegelése (RCOG 37a).",
    i:"Fokozott véralvadási hajlam vagy korábbi thrombosis mellett a terhességi és gyermekágyi vénás thromboembolia kockázata emelkedett; a kockázatarányos kis molekulatömegű heparin csökkenti az eseményt.",
    p:"A vérrögösödés kockázatát felmérjük; ha indokolt, hasba adott véralvadásgátló injekció véd a trombózis ellen."},
   {w:function(){return P("f_scd")||P("f_cmp")||P("f_chan")||P("s_card");},t:"Kardiológiai / kardiogenetikai konzílium, kiindulási EKG/echokardiográfia.",
    i:"Öröklődő szívbetegség vagy fiatalkori hirtelen szívhalál a családban a terhesség alatti kardiális szövődmény kockázatát növeli; a rizikóbecslés (pl. CARPREG II, mWHO) és a gondozási szint meghatározása kulcsfontosságú.",
    p:"A szív terhelhetőségét a terhesség előtt/elején felmérjük, hogy a szülést biztonságosan tervezhessük."},
   {w:function(){return P("s_thy");},t:"Pajzsmirigyfunkció (TSH) trimeszter-specifikus követése, szükség szerint levotiroxin-dózis emelése.",
    i:"A terhesség alatt a pajzsmirigyhormon-igény ~30%-kal nő; a nem kezelt hypothyreosis rontja a magzati idegrendszeri fejlődést és növeli a vetélés kockázatát.",
    p:"A pajzsmirigy-hormon szintjét rendszeresen ellenőrizzük, és szükség esetén a gyógyszeradagot igazítjuk."},
   {w:function(){return hbLow();},t:"Vashiányos anaemia kivizsgálása és pótlása (Ganzoni szerinti IV vas mérlegelése).",
    i:"A terhességi anaemia növeli a koraszülés, az alacsony születési súly és az anyai fáradékonyság kockázatát; a célzott vas- (és szükség szerint folsav/B12-) pótlás rendezi a vérképet.",
    p:"A vérszegénységet vaspótlással kezeljük, ez javítja az Ön és a baba oxigénellátását."},
   {w:function(){return numv("k_ba")>=40||P("s_icp");},t:"Intrahepaticus cholestasis (ICP) követése; epesav-ellenőrzés, szülésidőzítés mérlegelése.",
    i:"Emelkedett epesav mellett (különösen ≥ 100 µmol/l) nő a halvaszületés kockázata; a szoros követés és az időzített szülés csökkenti a magzati veszélyt.",
    p:"A viszketés és a magas epesav miatt szorosabban követjük a terhességet, és a szülés idejét ehhez igazítjuk."},
   {w:function(){return C("ps_anx")||C("ps_work")||C("ps_fin")||C("ps_rel")||C("ps_viol");},t:"Pszichoszociális támogatás felajánlása; szükség esetén pszichológiai/pszichiátriai konzílium, védőnői segítség.",
    i:"A tartós stressz, a szorongás és a kedvezőtlen szociális körülmények rontják a terhességi kimenetelt és az anyai mentális egészséget; a korai támogatás javítja a jóllétet és a gondozáshoz való kötődést.",
    p:"A terhesség alatti feszültség és aggodalom természetes — beszéljünk róla; van, aki segít, és ez Önnek és a babának is jót tesz."},
   {w:function(){return numv("age")>=40;},t:"Kombinált első trimeszteri szűrés / NIPT felajánlása, fokozott gondozás.",
    i:"A 40 év feletti anyai életkor növeli a kromoszóma-rendellenességek, a preeclampsia és a gesztációs diabetes kockázatát; a célzott szűrés és gondozás e kockázatokat kezeli.",
    p:"Az életkor miatt felajánljuk a részletesebb genetikai szűrést és a gyakoribb ellenőrzést."},
   {w:function(){var tw=val("twins");return tw&&tw!=="no";},t:"Ikerterhesség-protokoll: gyakoribb ultrahang, növekedés- és preeclampsia-követés, szülési terv.",
    i:"A többes terhesség növeli a koraszülés, a növekedési eltérés, a preeclampsia és a vérzés kockázatát; a strukturált követés és a szülőhely megválasztása javítja a kimenetelt.",
    p:"Ikreknél gyakrabban ellenőrizzük a babák növekedését és az Ön állapotát, és előre megtervezzük a szülést."}
  ];
  function buildTeendo(){
    var out=[];
    KB.forEach(function(k){ try{ if(k.w())out.push(k); }catch(e){} });
    if(!out.length)return "";
    return "TEENDŐK — INDOKLÁS ÉS BETEGTÁJÉKOZTATÓ:\n"+out.map(function(k){
      return "• "+k.t+"\n   Indoklás: "+k.i+"\n   Tájékoztató (betegnek): "+k.p;
    }).join("\n\n");
  }

  /* ---- search / loader / demographics (as v14) ---- */
  function esc(s){return (s||"").toString().replace(/[&<>]/g,function(c){return{"&":"&amp;","<":"&lt;",">":"&gt;"}[c];});}
  function rowsFor(type,ql){ var q2=norm(ql), out=[];
    if(type==="telep"){ var m=S.irsz; for(var k in m){ if(k.indexOf(ql)===0||norm(m[k]).indexOf(q2)>=0){ out.push([k,m[k]]); if(out.length>=40)break; } } return out; }
    var arr=type==="atc"?S.atc:type==="bno"?S.bno:type==="oeno"?S.oeno:type==="feor"?S.feor:type==="fno"?S.fno:type==="lab"?S.lab:[];
    for(var i=0;i<arr.length;i++){ var c=arr[i][0]||"",n=arr[i][1]||""; if(norm(c).indexOf(q2)>=0||norm(n).indexOf(q2)>=0){ out.push([c,n,arr[i][2]||""]); if(out.length>=40)break; } } return out; }
  function renderSearch(){ var type=(q("#eesztType")||{}).value||"bno"; var ql=((q("#eesztQ")||{}).value||"").trim(); var box=q("#eesztRes"); if(!box)return;
    if(ql.length<2){box.textContent="Írj be legalább 2 karaktert.";return;} var rows=rowsFor(type,ql);
    if(!rows.length){box.innerHTML="Nincs találat"+(S.full?"":" — a teljes kereséshez töltsd be az eeszt_bundle.json-t.");return;}
    box.innerHTML=rows.map(function(r){var src=r[2]?(" ["+r[2]+"]"):""; return '<div style="display:flex;gap:8px;align-items:baseline;margin:2px 0"><code style="min-width:74px;background:rgba(127,127,127,.12);padding:1px 6px;border-radius:5px">'+esc(r[0])+'</code><span style="flex:1;font-size:12px">'+esc(r[1])+esc(src)+'</span><button type="button" class="chip cpc" data-c="'+esc(r[0])+'" style="padding:1px 8px">másol</button></div>';}).join("");
    [].slice.call(box.querySelectorAll(".cpc")).forEach(function(b){b.onclick=function(){copyText(b.getAttribute("data-c"));};}); }
  function status(){ var s=q("#eesztStatus"),pill=q("#eesztPill");
    if(s)s.textContent="Betöltve — ATC "+S.atc.length+" · BNO "+S.bno.length+" · OENO "+S.oeno.length+" · FEOR "+S.feor.length+" · FNO "+S.fno.length+" · labor "+S.lab.length+" · irsz "+Object.keys(S.irsz).length+(S.full?"  (teljes korpusz)":"  (beágyazott kivágat)");
    if(pill)pill.textContent=S.full?"teljes":"beágyazott"; }
  function loadBundle(o){ if(!o)return; if(o.bno&&o.bno.length)S.bno=o.bno; if(o.oeno&&o.oeno.length)S.oeno=o.oeno; if(o.atc&&o.atc.length)S.atc=o.atc; if(o.feor&&o.feor.length)S.feor=o.feor; if(o.fno&&o.fno.length)S.fno=o.fno; if(o.lab&&o.lab.length)S.lab=o.lab; if(o.orszag&&o.orszag.length)S.orszag=o.orszag; if(o.irsz&&o.irsz.length){var m={};o.irsz.forEach(function(r){if(r[0]&&!m[r[0]])m[r[0]]=r[1];});S.irsz=m;} S.full=true;_bnoMap=null;status();renderSearch();try{gen();}catch(e){} }
  function wireLoader(){ var f=q("#eesztFile"); if(f)f.addEventListener("change",function(){var file=f.files&&f.files[0];if(!file)return;var rd=new FileReader();rd.onload=function(){try{loadBundle(JSON.parse(rd.result));toastMsg("EESZT teljes törzs betöltve");}catch(e){toastMsg("Hibás JSON");}};rd.readAsText(file);});
    try{fetch("eeszt_data/eeszt_bundle.json").then(function(r){return r.ok?r.json():null;}).then(function(o){if(o)loadBundle(o);}).catch(function(){});}catch(e){}
    var t=q("#eesztType"),qq2=q("#eesztQ"); if(t)t.addEventListener("change",renderSearch); if(qq2)qq2.addEventListener("input",renderSearch); }
  function wireDemo(){ var z=q("#irsz"); if(z)z.addEventListener("input",function(){var v=(z.value||"").trim();var t=q("#telepules");if(t)t.value=S.irsz[v]||"";try{gen();}catch(e){}});
    var oc=q("#occupation"); if(oc)oc.addEventListener("input",function(){var v=norm(oc.value);var r=q("#feorRes");if(!r)return;if(v.length<3){r.value="";return;}var hit=null;for(var i=0;i<S.feor.length;i++){if(norm(S.feor[i][1]).indexOf(v)>=0){hit=S.feor[i];break;}}r.value=hit?(hit[0]+" — "+hit[1]):"";try{gen();}catch(e){}});
    [].slice.call(document.querySelectorAll(".psx")).forEach(function(c){c.addEventListener("change",function(){try{gen();}catch(e){}});}); }

  /* ---- enrich transcript ---- */
  function gen(){ if(typeof window.generate==="function"){ try{window.generate();}catch(e){} } }
  function enrich15(){
    var pre=q("#anamOut"); if(!pre)return; var t=pre.textContent||""; if(!t||/Töltsd ki a kérdőívet/.test(t))return;
    // remove previous v15 blocks
    t=t.replace(/\nTEENDŐK — INDOKLÁS ÉS BETEGTÁJÉKOZTATÓ:[\s\S]*?(?=\n─|\nEESZT SZABVÁNY|\nNYILATKOZAT:|$)/,"");
    t=t.replace(/\nEESZT SZABVÁNY KÓDOK \(belső utak\):[\s\S]*?(?=\n─|\nNYILATKOZAT:|$)/,"");
    var blocks=[];
    var te=buildTeendo(); if(te)blocks.push(te);
    var bno=computeBNO();
    var lines=[]; if(bno.length)lines.push("BNO (EESZT, minden mező): "+bno.join("; "));
    try{ if(typeof syncMeds==="function")syncMeds(); }catch(e){}
    var meds=(typeof state!=="undefined"&&state.meds)||[]; var atc=[]; meds.forEach(function(m){var a=atcFor(m);if(a)atc.push(m+" → "+a[0]);}); if(atc.length)lines.push("ATC (gyógyszer): "+atc.join("; "));
    var z=val("irsz"),tp=val("telepules"),fe=val("feorRes"); var demo=[]; if(z)demo.push("irsz "+z+(tp?(" "+tp):"")); if(fe)demo.push("FEOR "+fe); if(demo.length)lines.push("Lakhely / foglalkozás: "+demo.join("; "));
    if(lines.length)blocks.push("EESZT SZABVÁNY KÓDOK (belső utak):\n"+lines.map(function(x){return "  • "+x;}).join("\n"));
    if(blocks.length){ var ins="\n"+blocks.join("\n\n"); var i=t.indexOf("NYILATKOZAT:"); if(i>=0){var ls=t.lastIndexOf("\n",i-1);if(ls<0)ls=i;t=t.slice(0,ls)+ins+"\n"+t.slice(ls+1);} else t=t+ins; }
    pre.textContent=t;
  }
  function mountAll(){ try{wireLoader();}catch(e){} try{wireDemo();}catch(e){} try{status();}catch(e){} try{renderSearch();}catch(e){} }
  if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",mountAll); else mountAll();
  if(typeof window.generate==="function"){ var og=window.generate; window.generate=function(){ var r=og.apply(this,arguments); try{enrich15();}catch(e){window.__v15err=(e&&e.message)||String(e);} return r; }; try{window.generate();}catch(e){} }
})();
</script>
```

<a id="i18n-25572663"></a>

### i18n — Futásidejű fordítóréteg, 316 kulcs, 6 nyelv

Sorok 2557–2663 (107 sor).

```javascript
<script>
/* ===== i18n runtime layer (added; does not alter clinical logic) ===== */
(function(){
  "use strict";
  var DICT = {"AI-asszisztált betegfelvétel · reprodukció &amp; terhesgondozás": ["AI-assisted patient intake · reproduction &amp; antenatal care", "Admission assistée par IA · reproduction &amp; suivi prénatal", "KI-gestützte Patientenaufnahme · Reproduktion &amp; Schwangerenvorsorge", "Admisión asistida por IA · reproducción y control prenatal", "AI 辅助病史采集 · 生殖与产前保健"], "Anamnézis-asszisztens": ["History assistant", "Assistant d'anamnèse", "Anamnese-Assistent", "Asistente de anamnesis", "病史助手"], "Az adatok a böngészőben maradnak": ["Data stays in your browser", "Les données restent dans le navigateur", "Daten bleiben im Browser", "Los datos permanecen en el navegador", "数据仅保存在浏览器中"], "Téma": ["Theme", "Thème", "Design", "Tema", "主题"], "Felvételi kontextus": ["Intake context", "Contexte d'admission", "Aufnahmekontext", "Contexto de admisión", "采集情境"], "Terhesgondozás": ["Antenatal care", "Suivi prénatal", "Schwangerenvorsorge", "Control prenatal", "产前保健"], "Terhespatológia": ["Maternal-fetal (inpatient)", "Pathologie de grossesse", "Schwangerschaftspathologie", "Patología del embarazo", "孕产病理(住院)"], "Kontextus &amp; alapadatok": ["Context &amp; baseline data", "Contexte et données de base", "Kontext &amp; Basisdaten", "Contexto y datos basales", "情境与基础数据"], "Jelen panaszok / állapot": ["Present complaints / status", "Plaintes actuelles / état", "Aktuelle Beschwerden / Status", "Molestias actuales / estado", "现病史 / 状态"], "Kórelőzmény — szervrendszerek": ["Past history — organ systems", "Antécédents — systèmes", "Vorgeschichte — Organsysteme", "Antecedentes — sistemas", "既往史 — 各系统"], "Gyógyszeres terápia": ["Medications", "Traitement médicamenteux", "Medikation", "Medicación", "用药"], "Reprodukciós &amp; szülészeti anamnézis": ["Reproductive &amp; obstetric history", "Antécédents reproductifs et obstétricaux", "Reproduktions- &amp; Geburtsanamnese", "Antecedentes reproductivos y obstétricos", "生殖与产科病史"], "Családi anamnézis — vér szerinti rokonok (3 generáció)": ["Famil
/* … [ 51477 karakter csonkolva — beágyazott adat, lásd a törzsadat-fejezetet ] … */
  var IDX = {en:0,fr:1,de:2,es:3,zh:4};
  var DISC = {"hu": "A magyar az eredeti nyelv. A többi nyelv gépi fordítás — klinikai használat előtt orvosi ellenőrzés szükséges. A rendszer klinikai döntéstámogató, a szakorvosi értékelést nem helyettesíti.", "en": "Hungarian is the source language. Other languages are machine-translated — clinician verification is required before clinical use. This tool is clinical decision support and does not replace physician judgment.", "fr": "Le hongrois est la langue source. Les autres langues sont traduites automatiquement — une vérification médicale est requise avant tout usage clinique. Outil d'aide à la décision, il ne remplace pas le jugement médical.", "de": "Ungarisch ist die Ausgangssprache. Andere Sprachen sind maschinell übersetzt — vor klinischer Nutzung ist eine ärztliche Prüfung erforderlich. Das Werkzeug ist eine Entscheidungshilfe und ersetzt nicht das ärztliche Urteil.", "es": "El húngaro es el idioma de origen. Los demás idiomas son traducción automática — se requiere verificación médica antes del uso clínico. Herramienta de apoyo a la decisión; no sustituye el juicio médico.", "zh": "匈牙利语为源语言。其他语言为机器翻译 —— 临床使用前须经医师核对。本工具为临床决策支持,不替代医师判断。"};
  var KEYS = Object.keys(DICT).sort(function(a,b){return b.length-a.length;});
  var lang = localStorage.getItem("anam_lang") || "hu";

  function esc(s){return s.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");}
  var RE = {};
  // >=7-char keys match case-insensitively (to catch lower-cased "denied" lists);
  // short keys stay case-sensitive so patient free-text words are not altered.
  KEYS.forEach(function(k){ RE[k]=new RegExp(esc(k), k.length>=7?"gi":"g"); });

  function tr(text, lg){
    if(lg==="hu"||!text) return text;
    var i=IDX[lg], out=text;
    for(var j=0;j<KEYS.length;j++){
      var k=KEYS[j], v=DICT[k][i];
      if(v && out.indexOf(k)!==-1) out=out.replace(RE[k], v);
    }
    return out;
  }

  // snapshot original Hungarian for STATIC text nodes + placeholders once
  var DYN = ["anamOut","todoOut","riskPill","legalNote","todoCount","medList","bnoOut","riskOut","calcHost","casePanel","suppHost","labHost","rizHost","riskNote","drugAllList","foodAllList","phq2res"];
  function inDyn(node){ for(var n=node; n; n=n.parentNode){ if(n.id && DYN.indexOf(n.id)!==-1) return true; } return false; }
  var staticNodes=[];
  function snapshot(){
    var w=document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);
    var n; while((n=w.nextNode())){
      if(!n.nodeValue || !n.nodeValue.trim()) continue;
      if(n.parentNode && (n.parentNode.tagName==="SCRIPT"||n.parentNode.tagName==="STYLE")) continue;
      if(inDyn(n)) continue;
      n.__hu = n.nodeValue; staticNodes.push(n);
    }
    // placeholders
    Array.prototype.forEach.call(document.querySelectorAll("[placeholder]"), function(el){ el.__huph=el.getAttribute("placeholder"); });
  }
  function applyStatic(lg){
    staticNodes.forEach(function(n){ n.nodeValue = tr(n.__hu, lg); });
    Array.prototype.forEach.call(document.querySelectorAll("[placeholder]"), function(el){
      if(el.__huph!=null) el.setAttribute("placeholder", tr(el.__huph, lg));
    });
  }
  function applyDynamic(lg){
    if(lg==="hu") return;
    DYN.forEach(function(id){
      var root=document.getElementById(id); if(!root) return;
      var w=document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null); var n;
      while((n=w.nextNode())){ if(n.nodeValue && n.nodeValue.trim()) n.nodeValue = tr(n.nodeValue, lg); }
    });
  }

  // wrap generate so translation re-applies after every update
  function wrap(){
    if(typeof window.generate!=="function") return false;
    var orig=window.generate;
    window.generate=function(){ var r=orig.apply(this,arguments); try{ applyDynamic(lang); }catch(e){} return r; };
    return true;
  }

  function setLang(lg){
    lang=lg; localStorage.setItem("anam_lang",lg);
    document.documentElement.setAttribute("lang", lg);
    applyStatic(lg);
    if(typeof window.generate==="function") window.generate();
    var d=document.getElementById("i18nDisc"); if(d) d.textContent=DISC[lg]||DISC.hu;
    var sel=document.getElementById("langSel"); if(sel) sel.value=lg;
  }

  function init(){
    // build language selector into the top bar
    var host=document.querySelector(".top-in");
    if(host){
      var sel=document.createElement("select");
      sel.id="langSel"; sel.className="icon-btn"; sel.setAttribute("aria-label","Language");
      sel.style.padding="6px 8px";
      var names={"hu": "Magyar", "en": "English", "fr": "Français", "de": "Deutsch", "es": "Español", "zh": "中文"};
      ["hu","en","fr","de","es","zh"].forEach(function(code){
        var o=document.createElement("option"); o.value=code; o.textContent="🌐 "+names[code]; sel.appendChild(o);
      });
      sel.value=lang;
      sel.addEventListener("change", function(){ setLang(sel.value); });
      var themeBtn=document.getElementById("themeBtn");
      if(themeBtn && themeBtn.parentNode===host) host.insertBefore(sel, themeBtn); else host.appendChild(sel);
    }
    // disclaimer line under the top bar
    var top=document.querySelector(".top");
    if(top){
      var bar=document.createElement("div");
      bar.id="i18nDisc";
      bar.style.cssText="max-width:1400px;margin:0 auto;padding:6px 18px;font-size:11px;color:var(--muted);border-top:1px solid var(--line)";
      bar.textContent=DISC[lang]||DISC.hu;
      top.appendChild(bar);
    }
    snapshot();
    wrap();
    if(lang!=="hu") setLang(lang);
  }

  if(document.readyState==="loading") document.addEventListener("DOMContentLoaded",init);
  else init();
})();
</script>
```

<a id="v162-26652928"></a>

### v16/2 — Dinamikus családfa (pedigré)

Sorok 2665–2928 (264 sor).

```javascript
<script>
/* ================= v16: dinamikus családfa (pedigré) =================
   Rokononkénti betegség-hozzárendelés anyai/apai/saját ág szerint, az adat
   FORRÁSÁVAL és dokumentáltságával. A klasszikus checkbox-lista csak azt tudja,
   HOGY van-e ilyen a családban; ez azt is, hogy KINÉL, HÁNY ÉVESEN, KITŐL
   tudjuk, és hogy VAN-E RÓLA DOKUMENTUM. ==================================== */
(function(){
  "use strict";
  /* az app sajat 'state'-je egy IIFE-n belul el, nincs a window-on: sajat tarolo kell */
  var S = window.state || (window.__pedState = window.__pedState || {});
  S.ped = S.ped || [];
  window.__pedState = S;
  var seq = 0;

  var BRANCH = [
    {id:"sajat", l:"Saját ág (szülők, testvérek, gyermekek)",
     rels:["édesanya","édesapa","leánytestvér","fiútestvér","féltestvér","leánygyermek","fiúgyermek"]},
    {id:"anyai", l:"Anyai ág",
     rels:["anyai nagyanya","anyai nagyapa","anyai nagynéni","anyai nagybácsi","anyai unokatestvér","anyai dédszülő"]},
    {id:"apai", l:"Apai ág",
     rels:["apai nagyanya","apai nagyapa","apai nagynéni","apai nagybácsi","apai unokatestvér","apai dédszülő"]}
  ];

  /* rf:"card" = kardiogenetikai út, "gen" = klinikai genetika, "haem", "onc", "pe" */
  var DX = [
    {id:"cmp",  l:"Cardiomyopathia (DCM/HCM/ARVC)", rf:"card"},
    {id:"scd",  l:"Hirtelen szívhalál",             rf:"card"},
    {id:"arr",  l:"Ritmuszavar / channelopathia",   rf:"card"},
    {id:"hf",   l:"Szívizombetegség / szívelégtelenség — közelebbi dg nélkül", rf:"card"},
    {id:"chd",  l:"Veleszületett szívhiba",         rf:"gen"},
    {id:"mi",   l:"Korai infarktus / stroke (férfi <55, nő <65)"},
    {id:"htn",  l:"Hypertonia"},
    {id:"vte",  l:"Thrombosis / thrombophilia",     rf:"haem"},
    {id:"dm",   l:"Diabetes"},
    {id:"pe",   l:"Preeclampsia / HELLP",           rf:"pe"},
    {id:"canc", l:"Daganat",                        rf:"onc"},
    {id:"ren",  l:"Vesebetegség / dialízis"},
    {id:"hep",  l:"Májbetegség"},
    {id:"ai",   l:"Autoimmun betegség"},
    {id:"neu",  l:"Neurológiai / izombetegség",     rf:"gen"},
    {id:"dev",  l:"Értelmi fogyatékosság / fejlődési zavar", rf:"gen"},
    {id:"mal",  l:"Veleszületett rendellenesség",   rf:"gen"},
    {id:"mono", l:"Ismert öröklődő (monogénes) betegség", rf:"gen"},
    {id:"unkn", l:"Tisztázatlan okú betegség vagy halál", rf:"card"},
    {id:"oth",  l:"Egyéb"}
  ];
  var DXMAP={}; DX.forEach(function(d){DXMAP[d.id]=d;});

  var CERT = [
    {id:"doc",  l:"orvosi dokumentummal igazolt"},
    {id:"phys", l:"orvos közölte, dokumentum nincs"},
    {id:"fam",  l:"családi elmondás"},
    {id:"none", l:"nem tisztázott"}
  ];
  var STATUS = [
    {id:"alive", l:"él"},
    {id:"dead",  l:"elhunyt"},
    {id:"unk",   l:"nem tudom"}
  ];

  function gen(){ if(typeof window.generate==="function"){ try{window.generate();}catch(e){} } }
  function eln(tag,cls,html){var e=document.createElement(tag); if(cls)e.className=cls; if(html!=null)e.innerHTML=html; return e;}
  function opts(sel,arr,valKey,labKey,cur){
    arr.forEach(function(o){
      var op=document.createElement("option");
      op.value = valKey?o[valKey]:o; op.textContent = labKey?o[labKey]:o;
      if(cur!=null && op.value===cur) op.selected=true;
      sel.appendChild(op);
    });
  }
  function isRF(p){ return (p.dx||[]).some(function(id){return DXMAP[id]&&DXMAP[id].rf;}); }

  /* ---- egy rokon sora ---- */
  function pedRow(p, host){
    var row = eln("div","pedrow");
    var head = eln("div","pedhead");
    var title = eln("b", null, "");
    var del = eln("button",null,"✕ Törlés");
    del.type="button"; del.style.cssText="border:0;background:transparent;color:inherit;cursor:pointer;opacity:.7";
    del.onclick=function(){ S.ped=S.ped.filter(function(x){return x!==p;}); host.removeChild(row); gen(); };
    head.append(title, del); row.append(head);

    var grid = eln("div","pedgrid");

    var lRel=eln("label",null,"<span>Rokon</span>"); var sRel=document.createElement("select");
    var br = BRANCH.filter(function(b){return b.id===p.branch;})[0]||BRANCH[0];
    opts(sRel, br.rels, null, null, p.rel); sRel.value=p.rel||br.rels[0];
    lRel.appendChild(sRel); grid.appendChild(lRel);

    var lSt=eln("label",null,"<span>Állapot</span>"); var sSt=document.createElement("select");
    opts(sSt, STATUS,"id","l",p.status||"alive"); lSt.appendChild(sSt); grid.appendChild(lSt);

    var lAge=eln("label",null,"<span>Életkor (év) / elhalálozási kor</span>");
    var iAge=document.createElement("input"); iAge.type="number"; iAge.min="0"; iAge.max="120";
    iAge.placeholder="pl. 35"; if(p.age)iAge.value=p.age; lAge.appendChild(iAge); grid.appendChild(lAge);

    var lCert=eln("label",null,"<span>A diagnózis megbízhatósága</span>"); var sCert=document.createElement("select");
    opts(sCert, CERT,"id","l",p.cert||"fam"); lCert.appendChild(sCert); grid.appendChild(lCert);

    var lSrc=eln("label",null,"<span>Az adat forrása (ki közölte)</span>");
    var iSrc=document.createElement("input"); iSrc.placeholder="pl. a beteg édesanyja";
    if(p.src)iSrc.value=p.src; lSrc.appendChild(iSrc); grid.appendChild(lSrc);

    var lNote=eln("label",null,"<span>Megjegyzés</span>");
    var iNote=document.createElement("input"); iNote.placeholder="szabad szöveg";
    if(p.note)iNote.value=p.note; lNote.appendChild(iNote); grid.appendChild(lNote);

    row.appendChild(grid);

    var chips = eln("div","dxchips");
    DX.forEach(function(d){
      var b=eln("button",null,d.l); b.type="button";
      if(d.rf) b.classList.add("rf");
      if((p.dx||[]).indexOf(d.id)>=0) b.classList.add("on");
      b.onclick=function(){
        p.dx = p.dx||[];
        var i=p.dx.indexOf(d.id);
        if(i>=0){p.dx.splice(i,1); b.classList.remove("on");}
        else {p.dx.push(d.id); b.classList.add("on");}
        refresh(); gen();
      };
      chips.appendChild(b);
    });
    row.appendChild(chips);

    var warn = eln("div","pedwarn","");
    row.appendChild(warn);

    function refresh(){
      p.rel=sRel.value; p.status=sSt.value; p.age=iAge.value; p.cert=sCert.value;
      p.src=iSrc.value; p.note=iNote.value;
      title.textContent = (br.l.split(" (")[0]) + " · " + (p.rel||"");
      row.classList.toggle("rfhit", isRF(p));
      var msgs=[];
      if(isRF(p) && p.cert!=="doc")
        msgs.push("▲ Vörös zászlós adat orvosi dokumentum nélkül — az eredeti dokumentum (zárójelentés, boncjegyzőkönyv, halotti bizonyítvány) beszerzése javasolt.");
      if(isRF(p) && !p.src)
        msgs.push("▲ Nincs megadva, hogy kitől származik az adat.");
      warn.innerHTML = msgs.join("<br>");
    }
    [sRel,sSt,sCert].forEach(function(x){x.onchange=function(){refresh();gen();};});
    [iAge,iSrc,iNote].forEach(function(x){x.oninput=function(){refresh();gen();};});
    refresh();
    return row;
  }

  /* ---- szekció beépítése a 06-os után ---- */
  function mount(){
    var famSec = document.querySelector("#rosFamily");
    if(!famSec) return false;
    var det = famSec.closest("details");
    if(!det || document.querySelector("#pedWrap")) return true;

    var sec = document.createElement("details");
    sec.className="sec";
    sec.innerHTML =
      '<summary><span class="num">6b</span> Családfa (pedigré) — rokononkénti betegségek, anyai / apai ág <span class="chev">›</span></summary>'+
      '<div class="body">'+
      '<p class="hint" style="margin:0 0 10px">Itt nem azt rögzítjük, hogy <i>van-e</i> a családban valami, hanem hogy <b>kinél</b>, '+
      '<b>hány évesen</b>, <b>kitől tudjuk</b>, és hogy <b>van-e róla orvosi dokumentum</b>. '+
      'A piros keretes címkék genetikai/kardiológiai utat indítanak.</p>'+
      '<div class="pedbtns"></div><div id="pedWrap"></div>'+
      '</div>';
    det.parentNode.insertBefore(sec, det.nextSibling);

    var btns = sec.querySelector(".pedbtns");
    var host = sec.querySelector("#pedWrap");
    BRANCH.forEach(function(b){
      var bt=eln("button",null,"+ "+b.l); bt.type="button";
      bt.onclick=function(){
        var p={id:++seq,branch:b.id,rel:b.rels[0],status:"alive",age:"",dx:[],cert:"fam",src:"",note:""};
        S.ped.push(p); host.appendChild(pedRow(p,host)); gen();
      };
      btns.appendChild(bt);
    });
    return true;
  }

  /* ---- szöveges kimenet + vörös zászlók ---- */
  function pedText(){
    if(!S.ped || !S.ped.length) return "";
    var L=[]; L.push("");
    L.push("CSALÁDFA (PEDIGRÉ) — rokononkénti adatok:");
    BRANCH.forEach(function(b){
      var rows=S.ped.filter(function(p){return p.branch===b.id;});
      if(!rows.length) return;
      L.push("  "+b.l.split(" (")[0]+":");
      rows.forEach(function(p){
        var s = "   • "+(p.rel||"rokon");
        var stx = (p.status==="dead")?"elhunyt":(p.status==="unk"?"állapota nem ismert":"él");
        s += ", "+stx;
        if(p.age) s += " "+p.age+" évesen";
        var dxs=(p.dx||[]).map(function(id){return DXMAP[id]?DXMAP[id].l:id;});
        s += dxs.length? " — "+dxs.join(", ") : " — nincs rögzített betegség";
        var c=CERT.filter(function(x){return x.id===p.cert;})[0];
        s += "; a diagnózis "+((c&&c.l)||"nem tisztázott");
        if(p.src) s += "; az adat forrása: "+p.src;
        else if(dxs.length) s += "; az adat forrása nincs rögzítve";
        if(p.note) s += " ("+p.note+")";
        L.push(s+".");
      });
    });

    var card=[], gene=[], haem=[], onc=[], pe=[], undoc=[];
    S.ped.forEach(function(p){
      (p.dx||[]).forEach(function(id){
        var d=DXMAP[id]; if(!d||!d.rf) return;
        var who=(p.rel||"rokon")+(p.age?(" ("+p.age+" é.)"):"");
        if(d.rf==="card")card.push(who+" — "+d.l);
        else if(d.rf==="gen")gene.push(who+" — "+d.l);
        else if(d.rf==="haem")haem.push(who+" — "+d.l);
        else if(d.rf==="onc")onc.push(who+" — "+d.l);
        else if(d.rf==="pe")pe.push(who+" — "+d.l);
      });
      if(isRF(p)&&p.cert!=="doc") undoc.push((p.rel||"rokon"));
    });

    if(card.length||gene.length||haem.length||onc.length||pe.length){
      L.push("");
      L.push("GENETIKAI / KARDIOLÓGIAI VÖRÖS ZÁSZLÓK A CSALÁDFÁBÓL:");
      if(card.length){
        L.push("  ■ Kardiogenetika: "+card.join("; ")+".");
        L.push("    → Kardiogenetikai tanácsadás + célzott génpanel (DCM/HCM/ARVC/channelopathia); kaszkádszűrés a rokonoknál.");
        L.push("    → A betegnél kiindulási EKG + echokardiográfia + NT-proBNP.");
      }
      if(gene.length) L.push("  ■ Klinikai genetika: "+gene.join("; ")+". → genetikai tanácsadás, indokolt esetben célzott vizsgálat / carrier screening.");
      if(haem.length) L.push("  ■ Haematologia: "+haem.join("; ")+". → thrombophilia-szűrés, LMWH-terv mérlegelése.");
      if(onc.length)  L.push("  ■ Onkogenetika: "+onc.join("; ")+". → örökletes daganatszindróma irányában tanácsadás.");
      if(pe.length)   L.push("  ■ Preeclampsia-rizikó: "+pe.join("; ")+". → alacsony dózisú aszpirin a 16. hét előtt.");
    }
    if(undoc.length){
      L.push("");
      L.push("DOKUMENTÁCIÓS HIÁNY: "+undoc.length+" vörös zászlós tétel ("+undoc.join(", ")+
             ") nincs orvosi dokumentummal alátámasztva. Az eredeti dokumentum beszerzése javasolt; "+
             "a fenotípus enélkül nem tisztázható, és a célzott génpanel választását is befolyásolja.");
    }
    return L.join("\n");
  }

  function enrichPed(){
    var out=document.querySelector("#anamOut");
    if(!out) return;
    var txt=pedText();
    var prev=out.querySelector("#pedBlock");
    if(prev) prev.parentNode.removeChild(prev);
    if(!txt) return;
    var span=document.createElement("span");
    span.id="pedBlock"; span.textContent=txt+"\n";
    out.appendChild(span);
  }

  function init(){
    if(!mount()) { setTimeout(init,300); return; }
    if(typeof window.generate==="function"){
      var og=window.generate;
      window.generate=function(){ var r=og.apply(this,arguments); try{enrichPed();}catch(e){window.__pedErr=(e&&e.message)||String(e);} return r; };
      try{ window.generate(); }catch(e){}
    }
    window.__ped = {DX:DX,BRANCH:BRANCH,text:pedText};
  }
  if(document.readyState==="loading") document.addEventListener("DOMContentLoaded",init);
  else init();
})();
</script>
```

<a id="v163-29303044"></a>

### v16/3 — Kalkulátor-bemenetek áthelyezése

Sorok 2930–3044 (115 sor).

```javascript
<script>
/* ============ v16/3: kalkulator-bemenetek athelyezese a bal oldalra ============
   A jobb oldali kalkulator-panel eddig sajat beviteli mezoket tartott. Ezek a
   mezok tartalom szerint a bal oldalra valok: a laborertekek a Labor szekciohoz,
   a vitalis parameterek az alapadatokhoz. Az input ELEMEKET mozgatjuk at, az
   id-k valtozatlanul - igy minden meglevo kalkulator-koto valtozatlanul mukodik.
   ============================================================================ */
(function(){
  "use strict";

  var LAB = [
    ["OGTT (75 g)",            ["k_og0","k_og1","k_og2"]],
    ["Angiogén markerek",      ["k_plgf","k_sflt","k_ratio"]],
    ["Ionok, anyagcsere",      ["k_na","k_ca","c_ins"]],
    ["Epesav / transzfúzió",   ["k_ba","k_hbtar"]]
  ];
  var VIT = [
    ["Vitális paraméterek",    ["c_hr","k_hr2","c_spo2","k_sbp"]],
    ["Kardiológiai besorolás", ["c_mwho","c_qt","c_chest"]]
  ];
  /* a magzati parameterek NEM ide kerulnek: azok az ultrahang-modul sajatjai */
  var US = ["k_crl","k_bpd","k_hc","k_ac","k_fl","k_afi","k_ua","k_mca"];

  function eln(tag,cls,html){var e=document.createElement(tag); if(cls)e.className=cls; if(html!=null)e.innerHTML=html; return e;}

  function holder(id){
    var i=document.getElementById(id);
    if(!i) return null;
    var lab=i.closest("label");
    return lab||i.parentNode;
  }

  function ensureGroup(host, title, key){
    var g=host.querySelector('[data-mig="'+key+'"]');
    if(g) return g;
    g=eln("div","miggrp"); g.setAttribute("data-mig",key);
    g.appendChild(eln("div","migh",title));
    var box=eln("div","migbox"); g.appendChild(box);
    host.appendChild(g);
    return g;
  }

  function moveInto(host, groups){
    if(!host) return 0;
    var n=0;
    groups.forEach(function(pair){
      var title=pair[0], ids=pair[1];
      var present=ids.filter(function(id){return !!document.getElementById(id);});
      if(!present.length) return;
      var box=ensureGroup(host,title,title).querySelector(".migbox");
      present.forEach(function(id){
        var h=holder(id);
        if(!h||h.parentNode===box) return;
        box.appendChild(h); n++;
      });
    });
    return n;
  }

  function vitalsHost(){
    /* az alapadat-r\u00e1cs, ahol a v\u00e9rnyom\u00e1s/testmagass\u00e1g mezok vannak */
    var bp=document.getElementById("bp");
    if(!bp) return null;
    var lab=bp.closest("label"); if(!lab) return null;
    var grid=lab.parentNode;
    var wrap=grid.parentNode.querySelector('[data-mig="vitwrap"]');
    if(!wrap){
      wrap=eln("div",null,""); wrap.setAttribute("data-mig","vitwrap");
      grid.parentNode.insertBefore(wrap, grid.nextSibling);
    }
    return wrap;
  }

  function note(host, txt){
    if(!host || host.querySelector(".mignote")) return;
    host.insertBefore(eln("div","mignote",txt), host.firstChild);
  }

  function migrate(){
    var lab=document.getElementById("labHost");
    if(lab){
      note(lab,"Az al\u00e1bbi \u00e9rt\u00e9kek kor\u00e1bban a jobb oldali kalkul\u00e1tor-s\u00e1vban voltak. "+
                "Itt r\u00f6gz\u00edtve ugyan\u00fagy t\u00e1pl\u00e1lj\u00e1k a kalkul\u00e1torokat.");
      moveInto(lab, LAB);
    }
    var vh=vitalsHost();
    if(vh){
      note(vh,"Vit\u00e1lis \u00e9s kardiol\u00f3giai param\u00e9terek \u2014 a kalkul\u00e1torok innen olvassák.");
      moveInto(vh, VIT);
    }
    /* a magzati param\u00e9terek mell\u00e9 mutat\u00f3 jelz\u00e9s, am\u00edg az UH-modul el nem k\u00e9sz\u00fcl */
    var first=document.getElementById(US[0]);
    if(first){
      var h=first.closest(".calcrow")||first.closest("label");
      if(h&&!h.querySelector(".migus")){
        h.appendChild(eln("div","migus","\u25b8 Ezek a magzati param\u00e9terek az Ultrahang-modulba ker\u00fclnek \u00e1t, "+
                                        "vizitenk\u00e9nt (d\u00e1tum + terhess\u00e9gi h\u00e9t) r\u00f6gz\u00edtve."));
      }
    }
  }

  function init(){
    try{ migrate(); }catch(e){ window.__migErr=(e&&e.message)||String(e); }
    if(typeof window.generate==="function"){
      var og=window.generate;
      window.generate=function(){ var r=og.apply(this,arguments); try{migrate();}catch(e){} return r; };
    }
    /* a kalkul\u00e1tor-modulok k\u00e9sleltetve injekt\u00e1lnak, ez\u00e9rt m\u00e9g p\u00e1rszor pr\u00f3b\u00e1lkozunk */
    var tries=0, iv=setInterval(function(){ tries++; try{migrate();}catch(e){} if(tries>10)clearInterval(iv); }, 400);
    window.__mig={migrate:migrate};
  }
  if(document.readyState==="loading") document.addEventListener("DOMContentLoaded",init);
  else init();
})();
</script>
```

<a id="v164-30463512"></a>

### v16/4 — Ultrahang-modul

Sorok 3046–3512 (467 sor).

```javascript
<script>
/* =============== v16/4: ULTRAHANG-MODUL ====================================
   Vizitsoros magzati biometria (dátum + terhességi hét), páros szervek,
   paraméterenkénti SVG-diagram, és publikációból betölthető normogramok.
   FONTOS: beépített normogram szándékosan NINCS. Referenciaadatot csak a
   felhasználó tölthet be, a forrás megadásával — kitalált percentilis egy
   klinikai eszközben veszélyes volna.
   ========================================================================= */
(function(){
  "use strict";
  var S = window.__usState = {visits:[], norms:{}};
  var seq = 0;

  /* --- paraméterek: egyszeres --- */
  var P1 = [
    {g:"Biometria"},
    {id:"crl", l:"CRL",  u:"mm"},
    {id:"bpd", l:"BPD",  u:"mm"},
    {id:"hc",  l:"HC",   u:"mm"},
    {id:"ac",  l:"AC",   u:"mm"},
    {id:"fl",  l:"FL",   u:"mm"},
    {id:"hl",  l:"HL",   u:"mm"},
    {id:"efw", l:"Becsült súly (EFW)", u:"g"},
    {id:"nt",  l:"NT",   u:"mm"},
    {g:"Magzatvíz és szív"},
    {id:"afi", l:"AFI",  u:"mm"},
    {id:"sdp", l:"Legmélyebb tasak", u:"mm"},
    {id:"fhr", l:"Magzati szívfrekvencia", u:"/perc"},
    {g:"Doppler"},
    {id:"ua",  l:"A. umbilicalis PI", u:""},
    {id:"mca", l:"A. cerebri media PI", u:""},
    {id:"cpr", l:"Cerebroplacentaris arány (CPR)", u:""},
    {id:"dv",  l:"Ductus venosus PI", u:""}
  ];
  /* --- páros szervek / testrészek: jobb + bal --- */
  var P2 = [
    {id:"ut",   l:"A. uterina PI"},
    {id:"kid",  l:"Vese hossz", u:"mm"},
    {id:"vent", l:"Oldalkamra átmérő", u:"mm"},
    {id:"fem",  l:"Femur hossz", u:"mm"},
    {id:"hum",  l:"Humerus hossz", u:"mm"},
    {id:"orb",  l:"Orbita átmérő", u:"mm"}
  ];
  var ALL1 = P1.filter(function(x){return x.id;});

  function eln(t,c,h){var e=document.createElement(t); if(c)e.className=c; if(h!=null)e.innerHTML=h; return e;}
  function gen(){ if(typeof window.generate==="function"){ try{window.generate();}catch(e){} } }
  function num(v){ v=parseFloat(String(v).replace(",",".")); return isFinite(v)?v:null; }
  function gaDec(v){ // "27+2" vagy 27.2 -> tizedes hét
    if(v==null) return null;
    var s=String(v).trim();
    var m=s.match(/^(\d{1,2})\s*[+\/]\s*(\d)$/);
    if(m) return parseInt(m[1],10)+parseInt(m[2],10)/7;
    return num(s);
  }
  function gaShow(g){ if(g==null)return "—"; var w=Math.floor(g), d=Math.round((g-w)*7); return w+"+"+d; }

  /* ---------- normogram tárolás ----------
     norms[paramId] = {src:"szerző, folyóirat, év", mode:"table"|"formula",
                       rows:[{ga,p3,p10,p50,p90,p97}], mu:"expr", sd:"expr"} */
  var LSK="anam_us_norms";
  function loadNorms(){ try{ S.norms=JSON.parse(localStorage.getItem(LSK)||"{}"); }catch(e){ S.norms={}; } }
  function saveNorms(){ try{ localStorage.setItem(LSK, JSON.stringify(S.norms)); }catch(e){} }

  /* biztonsagos keplet-kiertekeles: csak szamok, operatorok, GA, Math.* */
  function safeExpr(expr){
    if(!/^[-+*/(). 0-9GAMathelogxpsqrtinc,^]*$/i.test(expr)) return null;
    if(/[a-z]{2,}/i.test(expr.replace(/GA|Math|log|exp|sqrt|pow|abs|sin|cos/gi,""))) return null;
    try{ var f=new Function("GA","with(Math){return ("+expr.replace(/\^/g,"**")+");}"); f(20); return f; }
    catch(e){ return null; }
  }

  function interp(rows,ga,key){
    if(!rows||!rows.length) return null;
    var a=rows.filter(function(r){return r[key]!=null;}).sort(function(x,y){return x.ga-y.ga;});
    if(!a.length) return null;
    if(ga<=a[0].ga) return a[0][key];
    if(ga>=a[a.length-1].ga) return a[a.length-1][key];
    for(var i=1;i<a.length;i++){
      if(ga<=a[i].ga){
        var t=(ga-a[i-1].ga)/(a[i].ga-a[i-1].ga);
        return a[i-1][key]+t*(a[i][key]-a[i-1][key]);
      }
    }
    return null;
  }
  var ZOF={p3:-1.881,p10:-1.282,p50:0,p90:1.282,p97:1.881};
  function normPct(cdf){ return cdf; }
  function zToPct(z){ // standard normal CDF, Abramowitz-Stegun
    var t=1/(1+0.2316419*Math.abs(z));
    var d=0.3989423*Math.exp(-z*z/2);
    var p=d*t*(0.3193815+t*(-0.3565638+t*(1.781478+t*(-1.821256+t*1.330274))));
    return (z>0?1-p:p)*100;
  }
  /** merteket -> percentilis a betoltott normogram alapjan */
  function pctOf(pid, ga, val){
    var n=S.norms[pid]; if(!n||ga==null||val==null) return null;
    if(n.mode==="formula"){
      var fm=safeExpr(n.mu||""), fs=safeExpr(n.sd||"");
      if(!fm||!fs) return null;
      var mu=fm(ga), sd=fs(ga);
      if(!isFinite(mu)||!isFinite(sd)||sd<=0) return null;
      var z=(val-mu)/sd;
      return {pct:zToPct(z), z:z, src:n.src};
    }
    var keys=["p3","p10","p50","p90","p97"], pts=[];
    keys.forEach(function(k){ var v=interp(n.rows,ga,k); if(v!=null) pts.push({z:ZOF[k], v:v}); });
    if(pts.length<2) return null;
    pts.sort(function(a,b){return a.v-b.v;});
    var z;
    if(val<=pts[0].v) z=pts[0].z-(pts[0].v-val)/Math.max(1e-9,(pts[1].v-pts[0].v))*(pts[1].z-pts[0].z);
    else if(val>=pts[pts.length-1].v){var L=pts.length-1; z=pts[L].z+(val-pts[L].v)/Math.max(1e-9,(pts[L].v-pts[L-1].v))*(pts[L].z-pts[L-1].z);}
    else { for(var i=1;i<pts.length;i++){ if(val<=pts[i].v){ var tt=(val-pts[i-1].v)/Math.max(1e-9,(pts[i].v-pts[i-1].v)); z=pts[i-1].z+tt*(pts[i].z-pts[i-1].z); break; } } }
    return {pct:zToPct(z), z:z, src:n.src};
  }

  /* ---------------- vizit sora ---------------- */
  function visitRow(v, host){
    var row=eln("div","usvisit");
    var head=eln("div","usvhead");
    var ttl=eln("b",null,"");
    var del=eln("button",null,"✕ Törlés"); del.type="button";
    del.style.cssText="border:0;background:transparent;color:inherit;cursor:pointer;opacity:.7";
    del.onclick=function(){ S.visits=S.visits.filter(function(x){return x!==v;}); host.removeChild(row); redrawAll(); gen(); };
    head.append(ttl,del); row.append(head);

    var top=eln("div","usgrid");
    var lD=eln("label",null,"<span>Dátum</span>"); var iD=document.createElement("input");
    iD.type="date"; if(v.date)iD.value=v.date; lD.appendChild(iD); top.appendChild(lD);
    var lG=eln("label",null,"<span>Terhességi hét (pl. 27+2)</span>"); var iG=document.createElement("input");
    iG.placeholder="27+2"; if(v.gaRaw)iG.value=v.gaRaw; lG.appendChild(iG); top.appendChild(lG);
    row.appendChild(top);

    var grid=eln("div","usgrid");
    var inputs={};
    P1.forEach(function(p){
      if(p.g){ grid.appendChild(eln("div","usgh",p.g)); return; }
      var lab=eln("label",null,"<span>"+p.l+(p.u?(" ("+p.u+")"):"")+"</span>");
      var inp=document.createElement("input"); inp.type="text"; inp.inputMode="decimal";
      if(v.p[p.id]!=null) inp.value=v.p[p.id];
      var pc=eln("div","uspct","");
      lab.appendChild(inp); lab.appendChild(pc);
      grid.appendChild(lab); inputs[p.id]={i:inp,pc:pc};
    });
    grid.appendChild(eln("div","usgh","Páros szervek / testrészek — jobb és bal"));
    P2.forEach(function(p){
      ["j","b"].forEach(function(side){
        var key=p.id+"_"+side;
        var lab=eln("label",null,"<span>"+p.l+" "+(side==="j"?"jobb":"bal")+(p.u?(" ("+p.u+")"):"")+"</span>");
        var inp=document.createElement("input"); inp.type="text"; inp.inputMode="decimal";
        if(v.p[key]!=null) inp.value=v.p[key];
        var pc=eln("div","uspct","");
        lab.appendChild(inp); lab.appendChild(pc);
        grid.appendChild(lab); inputs[key]={i:inp,pc:pc};
      });
    });
    row.appendChild(grid);
    var flags=eln("div","usflag",""); row.appendChild(flags);

    function refresh(){
      v.date=iD.value; v.gaRaw=iG.value; v.ga=gaDec(iG.value);
      ttl.textContent = (v.date||"dátum nélkül")+"  ·  "+gaShow(v.ga)+" hét";
      var bad=[];
      Object.keys(inputs).forEach(function(k){
        var o=inputs[k]; var val=num(o.i.value);
        v.p[k] = (o.i.value==="")?null:val;
        o.i.classList.remove("p10","p90"); o.pc.className="uspct"; o.pc.textContent="";
        var base=k.replace(/_(j|b)$/,"");
        var r=pctOf(base, v.ga, val);
        if(r&&isFinite(r.pct)){
          o.pc.textContent="P"+r.pct.toFixed(1)+" (z="+r.z.toFixed(2)+")";
          if(r.pct<3){o.i.classList.add("p10");o.pc.classList.add("bad");bad.push(labelOf(k)+": P"+r.pct.toFixed(1));}
          else if(r.pct<10){o.i.classList.add("p10");o.pc.classList.add("bad");bad.push(labelOf(k)+": P"+r.pct.toFixed(1));}
          else if(r.pct>90){o.i.classList.add("p90");o.pc.classList.add("warnp");bad.push(labelOf(k)+": P"+r.pct.toFixed(1));}
        }
      });
      if(bad.length) flags.textContent="▲ Referenciatartományon kívül: "+bad.join(" · ");
    }
    [iD,iG].forEach(function(x){x.oninput=function(){refresh();redrawAll();gen();};});
    Object.keys(inputs).forEach(function(k){ inputs[k].i.oninput=function(){refresh();redrawAll();gen();}; });
    refresh();
    return row;
  }

  function labelOf(k){
    var s=k.replace(/_(j|b)$/,""), side=/_j$/.test(k)?" jobb":(/_b$/.test(k)?" bal":"");
    var a=ALL1.filter(function(p){return p.id===s;})[0]; if(a) return a.l+side;
    var b=P2.filter(function(p){return p.id===s;})[0]; if(b) return b.l+side;
    return k;
  }

  /* ---------------- SVG diagram ---------------- */
  function chart(pid, title, series){
    // series: [{name, pts:[{x,y}], color}]
    var W=560,H=200,ml=44,mr=12,mt=10,mb=26;
    var n=S.norms[pid];
    var xs=[], ys=[];
    series.forEach(function(s){ s.pts.forEach(function(p){ xs.push(p.x); ys.push(p.y); }); });
    var bands=[];
    if(n){
      var lo=Math.min.apply(null,xs.concat([40])), hi=Math.max.apply(null,xs.concat([0]));
      lo=Math.max(5,Math.floor(Math.min.apply(null,xs)-2)); hi=Math.ceil(Math.max.apply(null,xs)+2);
      ["p3","p10","p50","p90","p97"].forEach(function(k){
        var pts=[];
        for(var g=lo;g<=hi;g+=0.5){
          var val;
          if(n.mode==="formula"){ var fm=safeExpr(n.mu||""),fs=safeExpr(n.sd||""); if(!fm||!fs)break; val=fm(g)+ZOF[k]*fs(g); }
          else val=interp(n.rows,g,k);
          if(val!=null&&isFinite(val)){pts.push({x:g,y:val}); ys.push(val);}
        }
        if(pts.length) bands.push({k:k,pts:pts});
      });
    }
    if(!xs.length||!ys.length) return null;
    var x0=Math.min.apply(null,xs)-1, x1=Math.max.apply(null,xs)+1;
    if(bands.length){ x0=Math.min(x0, bands[0].pts[0].x); x1=Math.max(x1, bands[0].pts[bands[0].pts.length-1].x); }
    var y0=Math.min.apply(null,ys), y1=Math.max.apply(null,ys);
    if(y0===y1){y0-=1;y1+=1;}
    var py=(y1-y0)*0.08; y0-=py; y1+=py;
    var X=function(v){return ml+(v-x0)/(x1-x0)*(W-ml-mr);};
    var Y=function(v){return mt+(1-(v-y0)/(y1-y0))*(H-mt-mb);};
    var s=['<svg viewBox="0 0 '+W+' '+H+'" width="100%" height="'+H+'" role="img">'];
    s.push('<rect x="'+ml+'" y="'+mt+'" width="'+(W-ml-mr)+'" height="'+(H-mt-mb)+'" fill="none" stroke="currentColor" stroke-opacity=".22"/>');
    for(var i=0;i<=4;i++){
      var yv=y0+(y1-y0)*i/4, yy=Y(yv);
      s.push('<line x1="'+ml+'" y1="'+yy+'" x2="'+(W-mr)+'" y2="'+yy+'" stroke="currentColor" stroke-opacity=".10"/>');
      s.push('<text x="'+(ml-5)+'" y="'+(yy+3)+'" font-size="9" text-anchor="end" fill="currentColor" opacity=".65">'+(Math.round(yv*10)/10)+'</text>');
    }
    var step=Math.max(1,Math.round((x1-x0)/8));
    for(var g=Math.ceil(x0);g<=x1;g+=step){
      s.push('<line x1="'+X(g)+'" y1="'+mt+'" x2="'+X(g)+'" y2="'+(H-mb)+'" stroke="currentColor" stroke-opacity=".08"/>');
      s.push('<text x="'+X(g)+'" y="'+(H-mb+13)+'" font-size="9" text-anchor="middle" fill="currentColor" opacity=".65">'+g+'</text>');
    }
    s.push('<text x="'+(W/2)+'" y="'+(H-3)+'" font-size="9" text-anchor="middle" fill="currentColor" opacity=".6">terhességi hét</text>');
    var bandCol={p3:".55",p10:".4",p50:".75",p90:".4",p97:".55"};
    bands.forEach(function(b){
      var d=b.pts.map(function(p,i){return (i?"L":"M")+X(p.x)+" "+Y(p.y);}).join(" ");
      s.push('<path d="'+d+'" fill="none" stroke="currentColor" stroke-opacity="'+bandCol[b.k]+'" stroke-width="'+(b.k==="p50"?1.4:1)+'" stroke-dasharray="'+(b.k==="p50"?"":"4 3")+'"/>');
      var last=b.pts[b.pts.length-1];
      s.push('<text x="'+(X(last.x)-2)+'" y="'+(Y(last.y)-3)+'" font-size="8" text-anchor="end" fill="currentColor" opacity=".6">'+b.k.toUpperCase()+'</text>');
    });
    var cols=["#2d6cdf","#c0392b"];
    series.forEach(function(se,si){
      var col=se.color||cols[si%cols.length];
      var pp=se.pts.slice().sort(function(a,b){return a.x-b.x;});
      if(pp.length>1){
        var d=pp.map(function(p,i){return (i?"L":"M")+X(p.x)+" "+Y(p.y);}).join(" ");
        s.push('<path d="'+d+'" fill="none" stroke="'+col+'" stroke-width="1.8"/>');
      }
      pp.forEach(function(p){ s.push('<circle cx="'+X(p.x)+'" cy="'+Y(p.y)+'" r="3.2" fill="'+col+'"/>'); });
      if(series.length>1){
        s.push('<text x="'+(ml+6+si*70)+'" y="'+(mt+12)+'" font-size="9" fill="'+col+'">● '+se.name+'</text>');
      }
    });
    s.push('</svg>');
    var box=eln("div","uschart");
    box.appendChild(eln("h6",null,title));
    if(n) box.appendChild(eln("div","src","Normogram: "+(n.src||"forrás nincs megadva")));
    else box.appendChild(eln("div","src","Nincs betöltött normogram — csak a mért értékek láthatók."));
    box.insertAdjacentHTML("beforeend", s.join(""));
    return box;
  }

  function redrawAll(){
    var host=document.querySelector("#usCharts"); if(!host) return;
    host.innerHTML="";
    var vs=S.visits.filter(function(v){return v.ga!=null;});
    if(!vs.length){ host.appendChild(eln("div","src","Adj hozzá legalább egy vizitet terhességi héttel.")); return; }
    ALL1.forEach(function(p){
      var pts=vs.filter(function(v){return v.p[p.id]!=null;}).map(function(v){return {x:v.ga,y:v.p[p.id]};});
      if(pts.length){ var c=chart(p.id, p.l+(p.u?(" ["+p.u+"]"):""), [{name:p.l,pts:pts}]); if(c)host.appendChild(c); }
    });
    P2.forEach(function(p){
      var j=vs.filter(function(v){return v.p[p.id+"_j"]!=null;}).map(function(v){return {x:v.ga,y:v.p[p.id+"_j"]};});
      var b=vs.filter(function(v){return v.p[p.id+"_b"]!=null;}).map(function(v){return {x:v.ga,y:v.p[p.id+"_b"]};});
      if(j.length||b.length){
        var ser=[]; if(j.length)ser.push({name:"jobb",pts:j,color:"#2d6cdf"}); if(b.length)ser.push({name:"bal",pts:b,color:"#c0392b"});
        var c=chart(p.id, p.l+" — jobb és bal"+(p.u?(" ["+p.u+"]"):""), ser); if(c)host.appendChild(c);
      }
    });
  }

  /* ---------------- normogram-kezelő ---------------- */
  function normUI(host){
    host.innerHTML="";
    host.appendChild(eln("div","src",
      "Beépített normogram szándékosan nincs: referenciaadatot csak publikációból, forrásmegadással tölts be. "+
      "Táblázat formátum soronként: <code>hét;P3;P10;P50;P90;P97</code> (a P3/P97 elhagyható). "+
      "Képlet formátum: átlag és szórás GA (hét) függvényében, pl. <code>-28.28+1.29*GA</code>."));
    var all=ALL1.concat(P2);
    all.forEach(function(p){
      var n=S.norms[p.id];
      var r=eln("div","usnormrow");
      r.appendChild(eln("b",null,p.l));
      r.appendChild(eln("span",null, n? ("✔ "+(n.mode==="formula"?"képlet":"táblázat")+" — "+(n.src||"forrás nincs")) : "nincs betöltve"));
      var bAdd=eln("button",null,n?"Csere":"Betöltés"); bAdd.type="button";
      bAdd.style.cssText="border:1px solid var(--bd,#9aa3ad);background:transparent;color:inherit;border-radius:6px;padding:2px 9px;cursor:pointer;font:inherit;font-size:.72rem";
      bAdd.onclick=function(){ openLoader(p, host); };
      r.appendChild(bAdd);
      if(n){
        var bDel=eln("button",null,"Törlés"); bDel.type="button";
        bDel.style.cssText=bAdd.style.cssText;
        bDel.onclick=function(){ delete S.norms[p.id]; saveNorms(); normUI(host); redrawAll(); gen(); };
        r.appendChild(bDel);
      }
      host.appendChild(r);
    });
  }

  function openLoader(p, host){
    var box=eln("div","usvisit");
    box.innerHTML='<div class="usvhead"><b>Normogram betöltése — '+p.l+'</b></div>';
    var g=eln("div","usgrid");
    var lS=eln("label",null,"<span>Forrás (szerző, folyóirat, év) — kötelező</span>");
    var iS=document.createElement("input"); iS.placeholder="pl. Hadlock FP, et al. Radiology. 1991;181:129-33."; lS.appendChild(iS);
    var lM=eln("label",null,"<span>Mód</span>"); var sM=document.createElement("select");
    ["táblázat","képlet"].forEach(function(o){var op=document.createElement("option");op.value=(o==="képlet"?"formula":"table");op.textContent=o;sM.appendChild(op);});
    lM.appendChild(sM);
    g.append(lS,lM); box.appendChild(g);

    var ta=document.createElement("textarea");
    ta.rows=7; ta.style.cssText="width:100%;margin-top:8px;padding:6px;border-radius:6px;border:1px solid var(--bd,#d9dde3);background:transparent;color:inherit;font:inherit;font-size:.75rem";
    ta.placeholder="20;250;270;300;335;360\n21;270;292;325;362;389\n…";
    box.appendChild(ta);

    var fg=eln("div","usgrid"); fg.style.display="none";
    var lMu=eln("label",null,"<span>Átlag μ(GA)</span>"); var iMu=document.createElement("input"); iMu.placeholder="-28.28+1.29*GA"; lMu.appendChild(iMu);
    var lSd=eln("label",null,"<span>Szórás σ(GA)</span>"); var iSd=document.createElement("input"); iSd.placeholder="0.08*GA"; lSd.appendChild(iSd);
    fg.append(lMu,lSd); box.appendChild(fg);
    sM.onchange=function(){ var f=sM.value==="formula"; fg.style.display=f?"":"none"; ta.style.display=f?"none":""; };

    var msg=eln("div","usflag","");
    box.appendChild(msg);
    var bar=eln("div","usbtns");
    var ok=eln("button","pri","Mentés"); ok.type="button";
    var no=eln("button",null,"Mégse"); no.type="button";
    bar.append(ok,no); box.appendChild(bar);
    no.onclick=function(){ normUI(host); };
    ok.onclick=function(){
      if(!iS.value.trim()){ msg.textContent="A forrás megadása kötelező."; return; }
      if(sM.value==="formula"){
        if(!safeExpr(iMu.value)||!safeExpr(iSd.value)){ msg.textContent="A képlet nem értelmezhető (csak számok, + - * / ( ), GA és Math-függvények)."; return; }
        S.norms[p.id]={src:iS.value.trim(),mode:"formula",mu:iMu.value.trim(),sd:iSd.value.trim()};
      } else {
        var rows=[];
        ta.value.split(/\n/).forEach(function(line){
          var c=line.split(/[;,\t]/).map(function(x){return x.trim();});
          if(c.length<2) return;
          var ga=parseFloat(c[0].replace(",",".")); if(!isFinite(ga)) return;
          var o={ga:ga};
          var keys=(c.length>=6)?["p3","p10","p50","p90","p97"]:["p10","p50","p90"];
          keys.forEach(function(k,i){ var v=parseFloat((c[i+1]||"").replace(",",".")); if(isFinite(v))o[k]=v; });
          rows.push(o);
        });
        if(rows.length<2){ msg.textContent="Legalább két értelmezhető sor kell."; return; }
        S.norms[p.id]={src:iS.value.trim(),mode:"table",rows:rows};
      }
      saveNorms(); normUI(host); redrawAll(); gen();
    };
    host.innerHTML=""; host.appendChild(box);
  }

  /* ---------------- szöveges kimenet ---------------- */
  function usText(){
    var vs=S.visits.filter(function(v){return v.ga!=null||v.date;});
    if(!vs.length) return "";
    var L=["","ULTRAHANG — MAGZATI BIOMETRIA ÉS DOPPLER (vizitenként):"];
    var risk=[];
    vs.sort(function(a,b){return (a.ga||0)-(b.ga||0);}).forEach(function(v){
      var parts=[];
      ALL1.forEach(function(p){ if(v.p[p.id]!=null) parts.push(p.l+" "+v.p[p.id]+(p.u?(" "+p.u):"")); });
      P2.forEach(function(p){
        var j=v.p[p.id+"_j"], b=v.p[p.id+"_b"];
        if(j!=null||b!=null) parts.push(p.l+" j/b: "+(j==null?"—":j)+" / "+(b==null?"—":b)+(p.u?(" "+p.u):""));
      });
      L.push("  • "+(v.date||"dátum nélkül")+", "+gaShow(v.ga)+" hét — "+(parts.length?parts.join("; "):"nincs rögzített érték")+".");
      Object.keys(v.p).forEach(function(k){
        var r=pctOf(k.replace(/_(j|b)$/,""), v.ga, v.p[k]);
        if(r&&isFinite(r.pct)&&(r.pct<10||r.pct>90))
          risk.push(gaShow(v.ga)+" hét — "+labelOf(k)+": P"+r.pct.toFixed(1)+" (z="+r.z.toFixed(2)+")");
      });
    });
    var used={}; ALL1.concat(P2).forEach(function(p){ if(S.norms[p.id]) used[p.l]=S.norms[p.id].src||"forrás nincs megadva"; });
    if(Object.keys(used).length){
      L.push("  Használt normogramok:");
      Object.keys(used).forEach(function(k){ L.push("   – "+k+": "+used[k]); });
    }
    if(risk.length){
      L.push("");
      L.push("NÖVEKEDÉS- ÉS KOCKÁZATKONTROLL — referenciatartományon kívüli értékek:");
      risk.forEach(function(r){ L.push("  ▲ "+r); });
      L.push("  A percentilis a betöltött normogramból számolt; a klinikai értékelés a kezelőorvosé. "+
             "A P10 alatti becsült súly növekedési restrikció, a P90 feletti macrosomia irányában igényel további vizsgálatot.");
    }
    return L.join("\n");
  }

  function enrichUS(){
    var out=document.querySelector("#anamOut"); if(!out) return;
    var prev=out.querySelector("#usBlock"); if(prev) prev.parentNode.removeChild(prev);
    var txt=usText(); if(!txt) return;
    var sp=document.createElement("span"); sp.id="usBlock"; sp.textContent=txt+"\n";
    out.appendChild(sp);
  }

  /* ---------------- beépítés ---------------- */
  function mount(){
    var lab=document.querySelector("#labHost"); if(!lab) return false;
    var det=lab.closest("details"); if(!det||document.querySelector("#usWrap")) return true;
    var sec=document.createElement("details"); sec.className="sec";
    sec.innerHTML='<summary><span class="num">10b</span> Ultrahang — magzati biometria, páros szervek, normogramok <span class="chev">›</span></summary>'+
      '<div class="body">'+
      '<p class="hint" style="margin:0 0 10px">Vizitenként (dátum + terhességi hét) rögzített mérések. '+
      'A diagramok paraméterenként, a páros szervek jobb/bal görbével egy ábrán jelennek meg. '+
      'A percentilis csak akkor számolódik, ha a paraméterhez normogramot töltöttél be.</p>'+
      '<div class="usbtns"><button type="button" class="pri" data-a="add">+ Új vizit</button>'+
      '<button type="button" data-a="calc">Beemelés a kalkulátor mezőiből</button>'+
      '<button type="button" data-a="norm">Normogramok kezelése</button></div>'+
      '<div id="usWrap"></div>'+
      '<div id="usNorm" style="margin-top:12px;display:none"></div>'+
      '<h5 style="margin:14px 0 6px;font-size:.85rem">Görbék</h5><div id="usCharts"></div>'+
      '</div>';
    det.parentNode.insertBefore(sec, det.nextSibling);
    var host=sec.querySelector("#usWrap"), nh=sec.querySelector("#usNorm");

    function addVisit(pre){
      var v={id:++seq,date:(new Date()).toISOString().slice(0,10),gaRaw:"",ga:null,p:{}};
      if(pre) Object.keys(pre).forEach(function(k){v.p[k]=pre[k];});
      S.visits.push(v); host.appendChild(visitRow(v,host)); redrawAll(); gen();
    }
    sec.querySelectorAll(".usbtns button").forEach(function(b){
      b.onclick=function(){
        var a=b.getAttribute("data-a");
        if(a==="add") addVisit(null);
        else if(a==="norm"){ var vis=nh.style.display==="none"; nh.style.display=vis?"":"none"; if(vis)normUI(nh); }
        else if(a==="calc"){
          var map={k_crl:"crl",k_bpd:"bpd",k_hc:"hc",k_ac:"ac",k_fl:"fl",k_afi:"afi",k_ua:"ua",k_mca:"mca"};
          var pre={}, any=false;
          Object.keys(map).forEach(function(id){
            var e=document.getElementById(id);
            if(e&&e.value!==""){ var val=num(e.value); if(val!=null){ pre[map[id]]= (["bpd","hc","ac","fl"].indexOf(map[id])>=0? val*10 : val); any=true; } }
          });
          if(!any){ alert("A kalkulátor magzati mezői üresek."); return; }
          var ga=document.getElementById("ga");
          addVisit(pre);
          var last=S.visits[S.visits.length-1];
          if(ga&&ga.value){ last.gaRaw=ga.value; last.ga=gaDec(ga.value); }
          host.removeChild(host.lastChild); host.appendChild(visitRow(last,host)); redrawAll(); gen();
        }
      };
    });
    return true;
  }

  function init(){
    loadNorms();
    if(!mount()){ setTimeout(init,300); return; }
    if(typeof window.generate==="function"){
      var og=window.generate;
      window.generate=function(){ var r=og.apply(this,arguments); try{enrichUS();}catch(e){window.__usErr=(e&&e.message)||String(e);} return r; };
    }
    window.__us={text:usText,P1:P1,P2:P2,addNorm:function(pid,o){S.norms[pid]=o;saveNorms();redrawAll();}};
  }
  if(document.readyState==="loading") document.addEventListener("DOMContentLoaded",init);
  else init();
})();
</script>
```

<a id="v166-35143899"></a>

### v16/6 — EKG-modul, 296 munkafüzet-képlet

Sorok 3514–3899 (386 sor).

```javascript
<script>
/* ================== v16/6: EKG-MODUL =======================================
   Az ekg.xlsx munkafüzet logikájának portja. A számítási küszöbök és a
   szöveggenerálás a munkafüzet képleteit követik; ahol a munkafüzetben
   hiba volt (elcsúszott hivatkozás, összehasonlítás szöveggel), ott a
   HELYES számítás szerepel, és a modul ezt külön jelzi.
   ========================================================================= */
(function(){
  "use strict";
  var LEADS=["I.","II.","III.","aVL","aVR","aVF","V1","V2","V3","V4","V5","V6"];
  var E = window.__ekg = {set:{speed:25,sens:10,age:"",sex:"Nő",chest:"nem"}, lead:{}, g:{}};
  LEADS.forEach(function(L){ E.lead[L]={pPol:"",pDur:"",pAmp:"",qDur:"",qAmp:"",rAmp:"",rId:"",sPol:"",sAmp:"",tPol:"",tAmp:"",qrs:""}; });

  var MORPH=["","QR","qR","R","rS","RS","rsR'","QS","Rs","M-alak"];
  var POL=["","poz","neg","equiphasic"];

  function eln(t,c,h){var e=document.createElement(t); if(c)e.className=c; if(h!=null)e.innerHTML=h; return e;}
  function gen(){ if(typeof window.generate==="function"){ try{window.generate();}catch(e){} } }
  function n(v){ if(v===""||v==null) return null; var x=parseFloat(String(v).replace(",",".")); return isFinite(x)?x:null; }
  /* kiskocka -> mp  /  kiskocka -> mV  (a munkafüzet F3 és F4 cellái) */
  function sPerSq(){ return 1/(E.set.speed||25); }
  function mvPerSq(){ return 1/(E.set.sens||10); }
  function dur(v){ var x=n(v); return x==null?null:x*sPerSq(); }
  function amp(v){ var x=n(v); return x==null?null:x*mvPerSq(); }
  function f2(x){ return x==null?"—":(Math.round(x*1000)/1000); }

  /* ---------------- egyes lapok logikája ---------------- */

  /* Tengely lap: I, II, aVF polaritásból */
  function axis(){
    var a=(E.lead["I."].qrsPol||""), b=(E.lead["II."].qrsPol||""), c=(E.lead["aVF"].qrsPol||"");
    var P="poz",N="neg",Q="equiphasic";
    if(a===P&&b===P&&c===P) return "kp. tengely";
    if(a===P&&c===N&&b===Q) return "bal tengely (élettani variáns)";
    if(a===P&&b===N&&c===N) return "pathológiás bal tengely";
    if(a===N&&b===N&&c===N) return "extrém jobb tengely";
    if(a===N&&b===P&&c===P) return "jobb tengely";
    if(a===Q&&b===Q&&c===Q) return "nem meghatározott tengely";
    if(!a||!b||!c) return "tengely: hiányzó adat (I., II., aVF QRS-polaritás kell)";
    return "nem besorolható tengelyállás";
  }

  /* ritmus lap */
  function rhythm(){
    var g=E.g, out=[];
    var pII=E.lead["II."].pPol;
    var base=g.base||"";
    var sr=(pII==="poz"&&base==="SR/egyenes"&&g.pWave==="Jelen")?"SR":"arrhythmia? vagy hiányzó P-adat a II. elvezetésben";
    out.push(sr);
    var base2 = !base?"hiányzó adat":(base==="SR/egyenes"?"SR":(base==="hullámzó"?"pitvarfibrilláció?":(base==="sinusoid"?"flutter?":(base==="csak R vagy QRS P nélkül"?"kamrai ritmus":base))));
    if(base2!==sr) out.push(base2);
    var rr=n(g.rrBig), hr=null;
    if(rr) hr=300/rr*25/(E.set.speed||25);
    var hrTxt = hr==null?"":(hr<60?"bradycardia":(hr>90?"tachycardia":"normofrekvenciás"))+", "+Math.round(hr)+"/perc";
    var wide=qrsWidth();
    var qrsTxt = wide.w==null?"":(wide.wide?"széles QRS":"keskeny QRS");
    var axFix = !g.rFix?"":(g.rFix==="Fix"?"nem változó QRS":"változó R-amplitúdó?");
    var pace = !g.pace?"":(g.pace==="nincs"?"pacemakerre utaló eltérés nem látható":
               (g.pace==="P előtt"?"AAI vagy DDD pacemaker?":
               (g.pace==="QRS előtt"?"kamrai pacemaker (VDD, DDD)":"aszinkron pacemaker (hiba/mágnes?)")));
    var es = !g.es?"":(g.es==="nincs"?"ES / VES / SVES nincs":g.es);
    return {text:"Ritmus: "+out.join(", ")+(qrsTxt?", "+qrsTxt:"")+(hrTxt?", "+hrTxt:"")+
            (axFix?". "+axFix:"")+(es?". "+es:"")+(pace?". "+pace:"")+".", hr:hr};
  }

  /* P lap */
  function pWave(){
    var res=[], warn=[];
    var dII=dur(E.lead["II."].pDur), dV1=dur(E.lead["V1"].pDur), dI=dur(E.lead["I."].pDur);
    if(dII!=null) res.push(dII<0.119?"normál P-hullám a II.-ben ("+Math.round(dII*1000)+" ms)":"kóros P-hullám a II.-ben ("+Math.round(dII*1000)+" ms)");
    if(dV1!=null) res.push(dV1<0.119?"normál P a V1-ben":"kóros P a V1-ben");
    var aII=amp(E.lead["II."].pAmp), aIII=amp(E.lead["III."].pAmp), aVF=amp(E.lead["aVF"].pAmp);
    var morph="norm.";
    if(dI!=null&&dII!=null&&dI>0.08&&dII<0.08) morph="P-mitrale";
    else if(aII!=null&&aIII!=null&&aVF!=null&&aII>0.25&&aIII>0.25&&aVF>0.25) morph="P-pulmonale";
    if(morph!=="norm.") warn.push(morph);
    LEADS.forEach(function(L){
      var p=E.lead[L].pPol;
      if(p==="neg"&&(L==="I."||L==="II."||L==="aVF")) warn.push(L+"-ben negatív P (AV-junkcionális vagy kamrai ritmus?)");
      var a=amp(E.lead[L].pAmp);
      if(a!=null&&a>=0.251) warn.push(L+"-ben magas P ("+f2(a)+" mV)");
    });
    return {text:"P-hullám: "+(res.length?res.join("; ")+". ":"")+(warn.length?warn.join("; ")+".":(res.length?"":"nincs rögzített adat.")), morph:morph};
  }

  /* PR lap */
  function pr(){
    var d=dur(E.g.pr);
    if(d==null) return {text:"", d:null};
    var s = d<0.12?"rövid PR-szakasz":(d>0.22?"megnyúlt PR — I. fokú AV-blokk":"normál PR");
    var extra="";
    if(d<0.12) extra = (E.g.delta==="Igen")?" — WPW-szindróma gyanúja":" — preexcitációs szindróma lehetősége";
    return {text:"PR: "+Math.round(d*1000)+" ms — "+s+extra+".", d:d};
  }

  /* Q lap — kóros Q: >=0.04 s, vagy >0.03 s gyanús; amplitúdó >= az R 25%-a */
  function qWave(){
    var patho=[], susp=[];
    LEADS.forEach(function(L){
      var qd=dur(E.lead[L].qDur), qa=amp(E.lead[L].qAmp), ra=amp(E.lead[L].rAmp);
      var byDur = qd==null?null:(qd>=0.04?"p":(qd>0.03?"s":"n"));
      var byAmp = (qa==null||ra==null||ra<=0)?null:((0.25*ra<=qa)?"s":"n");
      var v;
      if(byDur==="p"&&byAmp==="s") v="p";
      else if(byDur==="p") v="p";
      else if(byDur==="s"&&byAmp==="s") v="p";
      else if(byDur==="s"||byAmp==="s") v="s";
      else v="n";
      if(v==="p") patho.push(L); else if(v==="s") susp.push(L);
    });
    var txt;
    if(!patho.length&&!susp.length) txt="Q-hullám: normál.";
    else {
      txt="Q-hullám: ";
      if(patho.length) txt+="kóros Q "+patho.join(", ")+" elvezetésben. ";
      if(susp.length) txt+="kóros Q gyanúja "+susp.join(", ")+" elvezetésben.";
    }
    return {text:txt.trim(), patho:patho, susp:susp};
  }

  /* R lap — amplitúdó-küszöbök és intrinsicoid deflexió */
  var RMAX={"I.":2,"aVL":1.2,"V1":5,"V5":2.6};
  function rWave(){
    var high=[], id=[];
    LEADS.forEach(function(L){
      var a=amp(E.lead[L].rAmp), lim=RMAX[L];
      if(a!=null&&lim!=null&&a>lim) high.push(L+" ("+f2(a)+" mV, határ "+lim+")");
    });
    var idV1=dur(E.lead["V1"].rId), idV5=dur(E.lead["V5"].rId);
    if(idV1!=null&&idV1>0.04) id.push("V1 ID "+Math.round(idV1*1000)+" ms — bal szárblokk vagy hypertrophia gyanúja");
    if(idV5!=null&&idV5>0.06) id.push("V5 ID "+Math.round(idV5*1000)+" ms — jobb szárblokk vagy hypertrophia gyanúja");
    var t="R-hullám: "+(high.length?("kórosan magas amplitúdó: "+high.join("; ")+". "):"az amplitúdók a határértéken belül. ")+
          (id.length?id.join("; ")+". ":"")+(E.g.mono==="igen"?"V5–V6-ban monomorf R.":"");
    return {text:t.trim(), high:high};
  }

  /* S lap */
  var SMAX={"I.":2,"V5":2.6};
  function sWave(){
    var parts=[], high=[];
    LEADS.forEach(function(L){
      var p=E.lead[L].sPol, a=amp(E.lead[L].sAmp);
      if(!p&&a==null) return;
      parts.push(L+"-ben "+(p||"?")+(a!=null?(" ("+f2(a)+" mV)"):""));
      var lim=SMAX[L];
      if(a!=null&&lim!=null&&a>lim) high.push(L);
    });
    return {text: parts.length?("S-hullám: "+parts.join(", ")+"."+(high.length?(" Kórosan mély: "+high.join(", ")+"."):"")):"", high:high};
  }

  /* QRS lap */
  function qrsWidth(){ var d=dur(E.g.qrs); return {w:d, wide:(d!=null&&d>=0.12)}; }
  function qrsWave(){
    var w=qrsWidth(), morf=[];
    LEADS.forEach(function(L){ var m=E.lead[L].qrs; if(m) morf.push(L+": "+m); });
    var bbbb="";
    var v14=["V1","V2","V3","V4"].map(function(L){return E.lead[L].qrs;});
    if(w.wide && (v14.every(function(x){return x==="QS";})||v14.every(function(x){return x==="rS";}))) bbbb="kétköteges (bifascicularis) blokk gyanúja";
    var t="QRS: "+(w.w==null?"szélesség nincs megadva":(Math.round(w.w*1000)+" ms — "+(w.wide?"széles":"keskeny")))+
          (morf.length?". Morfológia — "+morf.join(", "):"")+
          (E.g.rprog==="van"?". Abnormális R-progresszió.":"")+(bbbb?". "+bbbb:"")+".";
    return {text:t, wide:w.wide, w:w.w};
  }

  /* T lap — nemtől függő amplitúdó-küszöb */
  function tWave(){
    var lim = (E.set.sex==="Férfi")?0.9:0.7, parts=[], abn=[];
    LEADS.forEach(function(L){
      var p=E.lead[L].tPol, a=amp(E.lead[L].tAmp);
      if(!p&&a==null) return;
      var st=(a!=null&&a>lim)?"abnormális":"norm.";
      if(st==="abnormális") abn.push(L);
      parts.push(L+"-ben "+(p||"?")+" "+st);
    });
    return {text: parts.length?("T-hullám (küszöb "+lim+" mV, "+E.set.sex.toLowerCase()+"): "+parts.join(", ")+"."):"", abn:abn};
  }

  /* Vezetési idők: QTc + szárblokk + Sgarbossa */
  function qtc(){
    var qt=dur(E.g.qt), rrBig=n(E.g.rrBig);
    if(qt==null||!rrBig) return null;
    var rr=rrBig*5*sPerSq();               /* nagykocka = 5 kiskocka */
    return {rr:rr, qt:qt,
            bazett: qt/Math.sqrt(rr)*1000,
            fridericia: qt/Math.pow(rr,1/3)*1000,
            framingham: (qt-(0.134*(1-rr)))*1000};
  }
  function blocks(){
    var w=qrsWidth(), q=qWave();
    var noQ = ["I.","V5","V6"].every(function(L){ var a=n(E.lead[L].qDur); return !a; });
    var lbbb = (w.wide&&noQ&&E.g.notchL==="igen")?"komplett bal Tawara-szár-blokk":
               ((noQ&&E.g.notchL==="igen")?"inkomplett bal Tawara-szár-blokk":"bal szárblokk nem igazolható");
    var rbbb = (w.wide&&E.g.notchR==="igen"&&E.g.rsr==="igen")?"komplett jobb Tawara-szár-blokk":
               ((E.g.notchR==="igen"&&E.g.rsr==="igen")?"inkomplett jobb Tawara-szár-blokk":"jobb szárblokk nem igazolható");
    return lbbb+"; "+rbbb+".";
  }
  function sgarbossa(){
    var p=(E.g.sg1==="igen"?5:0)+(E.g.sg2==="igen"?3:0)+(E.g.sg3==="igen"?2:0);
    return {p:p, txt:"Sgarbossa-pontszám: "+p+" — "+(p>=3?"akut myocardialis infarctus valószínű":"akut infarctus a kritériumok alapján nem valószínű")+"."};
  }
  /* S1Q3T3 — a munkafüzet vegyes mértékegységeit egységesítve, mind mV/s */
  function s1q3t3(){
    var s1=amp(E.lead["I."].sAmp), q3=amp(E.lead["III."].qAmp), t3=E.lead["III."].tPol;
    if(s1==null&&q3==null&&!t3) return "";
    var hit=(s1!=null&&s1>0.15)&&(q3!=null&&q3>0.15)&&(t3==="neg");
    return "S1Q3T3: S(I.) "+f2(s1)+" mV, Q(III.) "+f2(q3)+" mV, T(III.) "+(t3||"—")+
           (hit?" — a mintázat teljesül; jobbszívfél-terhelés / tüdőembólia irányában további vizsgálat indokolt.":" — a mintázat nem teljesül.");
  }

  /* ---------------- összegzés ---------------- */
  function summary(){
    var L=[];
    L.push("EKG — 12 ELVEZETÉSES ÉRTÉKELÉS");
    L.push("Beállítás: "+E.set.speed+" mm/s, "+E.set.sens+" mm/mV (1 kiskocka = "+
           Math.round(sPerSq()*1000)+" ms és "+mvPerSq()+" mV)"+(E.set.age?("; kor: "+E.set.age):"")+
           "; nem: "+E.set.sex+(E.set.chest==="igen"?"; mellkasi panasz: igen":""));
    L.push("Tengely: "+axis()+".");
    var r=rhythm(); L.push(r.text);
    var q=qtc();
    if(q) L.push("QT "+Math.round(q.qt*1000)+" ms; QTc — Bazett "+Math.round(q.bazett)+" ms, Fridericia "+
                 Math.round(q.fridericia)+" ms, Framingham "+Math.round(q.framingham)+" ms.");
    [pWave().text, pr().text, qWave().text, rWave().text, sWave().text, qrsWave().text, tWave().text]
      .forEach(function(x){ if(x) L.push(x); });
    L.push("Vezetés: "+blocks());
    L.push(sgarbossa().txt);
    var pe=s1q3t3(); if(pe) L.push(pe);
    if(E.g.st) L.push("ST-szakasz: "+E.g.st+".");
    if(E.g.jp) L.push("J-pont: "+E.g.jp+".");
    if(E.g.u)  L.push("U-hullám: "+E.g.u+".");
    if(E.g.other) L.push("Egyéb: "+E.g.other+".");
    return L.join("\n");
  }

  /* ---------------- UI ---------------- */
  var COLS=[
    ["qrsPol","QRS pol.","sel",POL],
    ["pPol","P pol.","sel",POL],["pDur","P idő","num"],["pAmp","P ampl.","num"],
    ["qDur","Q idő","num"],["qAmp","Q ampl.","num"],
    ["rAmp","R ampl.","num"],["rId","R ID","num"],
    ["sPol","S pol.","sel",POL],["sAmp","S ampl.","num"],
    ["tPol","T pol.","sel",POL],["tAmp","T ampl.","num"],
    ["qrs","QRS morf.","sel",MORPH]
  ];

  function build(host){
    host.innerHTML="";
    host.appendChild(eln("p","ekgnote",
      "Minden numerikus mező <b>kiskockában</b> értendő (a papírsebesség és az érzékenység szerint váltjuk át). "+
      "1 kiskocka = "+Math.round(sPerSq()*1000)+" ms, illetve "+mvPerSq()+" mV. "+
      "Az üresen hagyott mező nem számít bele az értékelésbe."));

    /* beállítások */
    var st=eln("div","ekgset");
    function fld(lab, key, type, opts, obj){
      var l=eln("label",null,"<span>"+lab+"</span>");
      var e=(type==="sel")?document.createElement("select"):document.createElement("input");
      if(type==="sel") opts.forEach(function(o){var op=document.createElement("option");op.value=o;op.textContent=o||"—";e.appendChild(op);});
      else { e.type="text"; e.inputMode="decimal"; }
      e.value=obj[key]||"";
      e.onchange=e.oninput=function(){ obj[key]=e.value; render(); };
      l.appendChild(e); st.appendChild(l); return e;
    }
    fld("Papírsebesség (mm/s)","speed","num",null,E.set);
    fld("Érzékenység (mm/mV)","sens","num",null,E.set);
    fld("Kor","age","num",null,E.set);
    fld("Nem","sex","sel",["Nő","Férfi"],E.set);
    fld("Mellkasi panasz","chest","sel",["nem","igen"],E.set);
    host.appendChild(st);

    /* globális mezők */
    var g=eln("div","ekgset");
    fld("P-hullám","pWave","sel",["","Jelen","Nincs"],E.g);
    fld("Alapvonal","base","sel",["","SR/egyenes","hullámzó","sinusoid","csak R vagy QRS P nélkül"],E.g);
    fld("RR (nagykocka)","rrBig","num",null,E.g);
    fld("PR (kiskocka)","pr","num",null,E.g);
    fld("QRS szélesség (kiskocka)","qrs","num",null,E.g);
    fld("QT (kiskocka)","qt","num",null,E.g);
    fld("Delta-hullám","delta","sel",["","Igen","Nem"],E.g);
    fld("R-tengely","rFix","sel",["","Fix","Változó"],E.g);
    fld("Pace-jel","pace","sel",["","nincs","P előtt","QRS előtt","folyamatos (EKG-független)"],E.g);
    fld("ES / VES / SVES","es","sel",["","nincs","SVES","VES","vegyes"],E.g);
    fld("V5–V6 monomorf R","mono","sel",["","igen","nem"],E.g);
    fld("Abnormális R-progresszió","rprog","sel",["","van","nincs"],E.g);
    fld("Csomós R (bal, I/V5/V6)","notchL","sel",["","igen","nem"],E.g);
    fld("Csomós R (jobb, V1/V2)","notchR","sel",["","igen","nem"],E.g);
    fld("rsR' V1–V2","rsr","sel",["","igen","nem"],E.g);
    fld("Sgarbossa: konkordáns ST-eleváció ≥1 mm","sg1","sel",["","igen","nem"],E.g);
    fld("Sgarbossa: konkordáns ST-depresszió ≥1 mm V1–V3","sg2","sel",["","igen","nem"],E.g);
    fld("Sgarbossa: diszkordáns ST-eleváció ≥5 mm","sg3","sel",["","igen","nem"],E.g);
    fld("ST-szakasz (szöveg)","st","num",null,E.g);
    fld("J-pont (szöveg)","jp","num",null,E.g);
    fld("U-hullám (szöveg)","u","num",null,E.g);
    fld("Egyéb megjegyzés","other","num",null,E.g);
    host.appendChild(g);

    /* elvezetés-táblázat */
    var wrap=eln("div","ekgtblwrap");
    var tb=eln("table","ekgtbl");
    var thead=eln("thead"); var tr=eln("tr");
    tr.appendChild(eln("th",null,"Elvezetés"));
    COLS.forEach(function(c){ tr.appendChild(eln("th",null,c[1])); });
    thead.appendChild(tr); tb.appendChild(thead);
    var tbody=eln("tbody");
    LEADS.forEach(function(L){
      var row=eln("tr"); row.appendChild(eln("td",null,L));
      COLS.forEach(function(c){
        var td=eln("td"); td.setAttribute("data-l",L); td.setAttribute("data-k",c[0]);
        var e;
        if(c[2]==="sel"){ e=document.createElement("select");
          c[3].forEach(function(o){var op=document.createElement("option");op.value=o;op.textContent=o||"—";e.appendChild(op);});
        } else { e=document.createElement("input"); e.type="text"; e.inputMode="decimal"; }
        e.value=E.lead[L][c[0]]||"";
        e.onchange=e.oninput=function(){ E.lead[L][c[0]]=e.value; render(); };
        td.appendChild(e); row.appendChild(td);
      });
      tbody.appendChild(row);
    });
    tb.appendChild(tbody); wrap.appendChild(tb); host.appendChild(wrap);

    var out=eln("div","ekgout"); out.id="ekgOut"; host.appendChild(out);
    host.appendChild(eln("div","ekgblk",
      "<b>Eltérés a munkafüzettől.</b> A portolás közben négy hibát találtam az <code>ekg.xlsx</code>-ben, "+
      "és ezeken a pontokon a modul a <b>helyes</b> számítást használja: (1) a Q lapon a 3–13. sor "+
      "elcsúszott átváltó cellákra hivatkozik (F5, F6, F7…), így az I. elvezetésen kívül minden Q-érték "+
      "hibásan 0; (2) az R lap V1-küszöbe szöveget hasonlít számhoz (<code>\"V1S\"&gt;F8</code>), ezért soha nem jelez; "+
      "(3) a QRS lap A20 cellája <code>#N/A</code>; (4) az S1Q3T3-szabály mV-ot és kiskockát kever. "+
      "A modul minden mértéket a beállított papírsebesség és érzékenység szerint vált át."));
  }

  function render(){
    var out=document.querySelector("#ekgOut"); if(!out) return;
    /* mezők színezése */
    var q=qWave(), r=rWave(), tw=tWave(), s=sWave();
    document.querySelectorAll(".ekgtbl td[data-l]").forEach(function(td){
      td.classList.remove("abn","susp");
      var L=td.getAttribute("data-l"), k=td.getAttribute("data-k");
      if(k==="qDur"||k==="qAmp"){ if(q.patho.indexOf(L)>=0)td.classList.add("abn"); else if(q.susp.indexOf(L)>=0)td.classList.add("susp"); }
      if(k==="tAmp"&&tw.abn.indexOf(L)>=0) td.classList.add("abn");
      if(k==="rAmp"&&r.high.some(function(x){return x.indexOf(L+" ")===0;})) td.classList.add("abn");
      if(k==="sAmp"&&s.high.indexOf(L)>=0) td.classList.add("abn");
    });
    var txt=summary();
    out.textContent=txt;
    var sg=sgarbossa(), pe=s1q3t3();
    if(sg.p>=3||/teljesül;/.test(pe)){
      var w=eln("div","ekgcrit", (sg.p>=3?"▲ Sgarbossa ≥3 — akut infarctus lehetősége. ":"")+
                                 (/teljesül;/.test(pe)?"▲ S1Q3T3 mintázat — tüdőembólia irányában további vizsgálat.":""));
      out.appendChild(w);
    }
    gen();
  }

  function enrichEKG(){
    var out=document.querySelector("#anamOut"); if(!out) return;
    var prev=out.querySelector("#ekgBlock"); if(prev) prev.parentNode.removeChild(prev);
    var any=Object.keys(E.g).some(function(k){return E.g[k];}) ||
            LEADS.some(function(L){ return Object.keys(E.lead[L]).some(function(k){return E.lead[L][k];}); });
    if(!any) return;
    var sp=document.createElement("span"); sp.id="ekgBlock"; sp.textContent="\n"+summary()+"\n";
    out.appendChild(sp);
  }

  function mount(){
    var us=document.querySelector("#usWrap"); if(!us) return false;
    var det=us.closest("details"); if(!det||document.querySelector("#ekgWrap")) return true;
    var sec=document.createElement("details"); sec.className="sec";
    sec.innerHTML='<summary><span class="num">10c</span> EKG — 12 elvezetéses értékelés <span class="chev">›</span></summary>'+
                  '<div class="body"><div id="ekgWrap"></div></div>';
    det.parentNode.insertBefore(sec, det.nextSibling);
    build(sec.querySelector("#ekgWrap"));
    render();
    return true;
  }

  function init(){
    if(!mount()){ setTimeout(init,300); return; }
    if(typeof window.generate==="function"){
      var og=window.generate;
      window.generate=function(){ var r=og.apply(this,arguments); try{enrichEKG();}catch(e){window.__ekgErr=(e&&e.message)||String(e);} return r; };
    }
    E.summary=summary; E.axis=axis; E.qtc=qtc; E.sgarbossa=sgarbossa;
  }
  if(document.readyState==="loading") document.addEventListener("DOMContentLoaded",init);
  else init();
})();
</script>
```

---

## 4. Build-lánc forrása

Ezek a fájlok a kanonikus forrás. A lánc a v15-ből építi újra a v16-ot, sorrendben.

### `build_v16.py`

423 sor, 23 KB.

```python
# -*- coding: utf-8 -*-
"""v15_tobbnyelvu -> v16: iker->peRisk, ismeretlen-dg csaladi tetelek,
'Nem tudom' harmadik allapot, dinamikus csaladfa (pedigre) rokononkenti forrassal."""
import io, os, shutil

D = r"C:\Users\szili\Documents\claude\apps\anamnezis-asszisztens"
SRC = os.path.join(D, "Anamnezis_asszisztens_v15_tobbnyelvu.html")
OUT = os.path.join(D, "Anamnezis_asszisztens_v16_tobbnyelvu.html")

t = io.open(SRC, encoding="utf-8").read()
n0 = len(t)
applied = []


def patch(old, new, tag, count=1):
    global t
    assert t.count(old) >= 1, "NEM TALALOM: " + tag
    t = t.replace(old, new, count)
    applied.append(tag)


# =========================================================== 1. IKER -> peRisk
patch(
    'var peRisk=P("s_htn")||P("r_pe")||P("s_ren")||P("s_ai")||'
    '(num("height")>0&&num("weight")>0&&(num("weight")/Math.pow(num("height")/100,2))>=35);',
    'var peRisk=P("s_htn")||P("r_pe")||P("s_ren")||P("s_ai")||'
    '(function(){var tw=document.querySelector("#twins");return !!(tw&&tw.value&&tw.value!=="no");})()||'
    '(num("height")>0&&num("weight")>0&&(num("weight")/Math.pow(num("height")/100,2))>=35);',
    "1a: iker a peRisk-be")

# explicit iker -> ASA javaslat, a BMI-szabaly melle
patch(
    'if(bmi>=30 && isPreg) add("med","Alacsony dózisú aszpirin (100–150 mg) preeclampsia-profilaxis mérlegelése — a 16. hét ELŐTT.","preeclampsia-rizikó","warn");',
    'if(bmi>=30 && isPreg) add("med","Alacsony dózisú aszpirin (100–150 mg) preeclampsia-profilaxis mérlegelése — a 16. hét ELŐTT.","preeclampsia-rizikó","warn");\n'
    '    (function(){var tw=document.querySelector("#twins");\n'
    '      if(tw&&tw.value&&tw.value!=="no"){\n'
    '        add("med","Alacsony dózisú aszpirin (100–150 mg/nap) preeclampsia-profilaxis — a többes terhesség ÖNMAGÁBAN magas rizikójú tényező (ACOG/USPSTF, NICE); a 16. hét ELŐTT megkezdve.","ikerterhesség","warn");\n'
    '        add("ref","Ikerterhesség: MFM (magas rizikójú szülészeti) gondozási útvonal; chorionicitás dokumentálása.","ikerterhesség","warn");\n'
    '      }})();',
    "1b: iker -> ASA javaslat")

# =============================== 2. ISMERETLEN DIAGNOZISU CSALADI TETELEK
patch(
    '  {id:"f_pe",l:"Preeclampsia elsőfokú rokonnál"},\n];',
    '  {id:"f_pe",l:"Preeclampsia elsőfokú rokonnál"},\n'
    '  /* --- v16: tisztázatlan diagnózisú tételek. A klasszikus checkboxok csak KIMONDOTT\n'
    '     diagnózist fognak meg; a valóságban a családi adat gyakran laikus leírás. --- */\n'
    '  {id:"f_ucard",l:"Fiatalon (< 50 é.) szívbetegségben elhunyt vér szerinti rokon — a diagnózis nem tisztázott",rf:1},\n'
    '  {id:"f_udeath",l:"Tisztázatlan okú fiatalkori halál a családban",rf:1},\n'
    '  {id:"f_uneuro",l:"Fiatalon kialakult neurológiai / izombetegség — a diagnózis nem tisztázott",rf:1},\n'
    '  {id:"f_uren",l:"Fiatalon kialakult vesebetegség / dialízis — a diagnózis nem tisztázott",rf:1},\n'
    '  {id:"f_ucanc",l:"Fiatalon (< 50 é.) kialakult daganat — a típus nem tisztázott",rf:1},\n'
    '  {id:"f_uhaem",l:"Ismétlődő thrombosis / vérzékenység — a diagnózis nem tisztázott",rf:1},\n'
    '  {id:"f_umeta",l:"Csecsemő- vagy gyermekkori hirtelen halál / anyagcsere-betegség gyanúja",rf:1},\n'
    '  {id:"f_usyn",l:"Több rokonnál halmozódó, meg nem magyarázott betegség",rf:1},\n];',
    "2: uj csaladi tetelek")

# az uj kardialis tetelek is inditsak a kardiogenetikai utvonalat
patch(
    '  if(famSCD||famCMP||famChan){',
    '  const famUCard = (st.f_ucard&&st.f_ucard.v==="pos")||(st.f_udeath&&st.f_udeath.v==="pos")||(st.f_umeta&&st.f_umeta.v==="pos");\n'
    '  if(famSCD||famCMP||famChan||famUCard){',
    "2b: uj tetelek -> kardiogenetika")

patch(
    '    add("ref","Kardiológiai gondozásba vétel; szülés-terv egyeztetése.","familiáris kardiológiai terheltség","warn");\n  }',
    '    add("ref","Kardiológiai gondozásba vétel; szülés-terv egyeztetése.","familiáris kardiológiai terheltség","warn");\n'
    '    if(famUCard&&!(famSCD||famCMP||famChan)) add("gen","A családi kardiális adat laikus leíráson alapul: az eredeti orvosi dokumentum (zárójelentés, boncjegyzőkönyv, halotti bizonyítvány) beszerzése javasolt a fenotípus tisztázásához.","tisztázatlan családi kardiális adat","crit");\n  }',
    "2c: dokumentum-beszerzes javaslat")

patch(
    '  if((st.f_mono&&st.f_mono.v==="pos")||(st.f_cons&&st.f_cons.v==="pos")||(st.f_ethn&&st.f_ethn.v==="pos")||(st.f_canc&&st.f_canc.v==="pos")||(st.f_dev&&st.f_dev.v==="pos")){',
    '  if((st.f_mono&&st.f_mono.v==="pos")||(st.f_cons&&st.f_cons.v==="pos")||(st.f_ethn&&st.f_ethn.v==="pos")||(st.f_canc&&st.f_canc.v==="pos")||(st.f_dev&&st.f_dev.v==="pos")||(st.f_uneuro&&st.f_uneuro.v==="pos")||(st.f_ucanc&&st.f_ucanc.v==="pos")||(st.f_usyn&&st.f_usyn.v==="pos")||(st.f_uren&&st.f_uren.v==="pos")){',
    "2d: uj tetelek -> klinikai genetika")

patch(
    '  if(st.f_thr&&st.f_thr.v==="pos"){add("lab","Thrombophilia-szűrés.","családi thrombosis","info");add("med","LMWH-profilaxis mérlegelése.","családi thrombosis","info");}',
    '  if((st.f_thr&&st.f_thr.v==="pos")||(st.f_uhaem&&st.f_uhaem.v==="pos")){add("lab","Thrombophilia-szűrés.","családi thrombosis","info");add("med","LMWH-profilaxis mérlegelése.","családi thrombosis","info");}',
    "2e: uhaem -> thrombophilia")

# ============================ 3. HARMADIK ALLAPOT: "Nem tudom / nem ismert"
patch(
    '  const no=el("button","no","Nem"), yes=el("button","yes","Igen");\n'
    '  no.type="button"; yes.type="button"; no.setAttribute("aria-pressed","false"); yes.setAttribute("aria-pressed","false");',
    '  const no=el("button","no","Nem"), yes=el("button","yes","Igen"), unk=el("button","unk","Nem tudom");\n'
    '  no.type="button"; yes.type="button"; unk.type="button";\n'
    '  no.setAttribute("aria-pressed","false"); yes.setAttribute("aria-pressed","false"); unk.setAttribute("aria-pressed","false");\n'
    '  unk.title="A beteg nem tudja / az adat nem ismert. Ez NEM azonos a negatív válasszal, és nem azonos a kitöltetlen mezővel.";',
    "3a: harmadik gomb")

patch(
    '  no.onclick=()=>{state.ros[item.id]={v:"neg"};no.setAttribute("aria-pressed","true");yes.setAttribute("aria-pressed","false");row.classList.remove("on");generate();};\n'
    '  yes.onclick=()=>{state.ros[item.id]={v:"pos",det:di.value};yes.setAttribute("aria-pressed","true");no.setAttribute("aria-pressed","false");row.classList.add("on");generate();};',
    '  const press=(a,b,c)=>{a.setAttribute("aria-pressed","true");b.setAttribute("aria-pressed","false");c.setAttribute("aria-pressed","false");};\n'
    '  no.onclick=()=>{state.ros[item.id]={v:"neg"};press(no,yes,unk);row.classList.remove("on");row.classList.remove("unkon");generate();};\n'
    '  yes.onclick=()=>{state.ros[item.id]={v:"pos",det:di.value};press(yes,no,unk);row.classList.add("on");row.classList.remove("unkon");generate();};\n'
    '  unk.onclick=()=>{state.ros[item.id]={v:"unk",det:di.value};press(unk,no,yes);row.classList.remove("on");row.classList.add("unkon");generate();};',
    "3b: harmadik allapot kezelese")

patch(
    '  di.oninput=()=>{if(state.ros[item.id]&&state.ros[item.id].v==="pos"){state.ros[item.id].det=di.value;generate();}};\n'
    '  yn.append(no,yes); row.append(lb,yn,det); return row;',
    '  di.oninput=()=>{if(state.ros[item.id]&&(state.ros[item.id].v==="pos"||state.ros[item.id].v==="unk")){state.ros[item.id].det=di.value;generate();}};\n'
    '  yn.append(no,yes,unk); row.append(lb,yn,det); return row;',
    "3c: gomb beillesztes")

# "Osszes negativ" ne irja felul a "Nem tudom"-ot
patch(
    'else if(r&&state.ros[it.id]&&state.ros[it.id].v!=="pos"){r.querySelector(".no").click();}',
    'else if(r&&state.ros[it.id]&&state.ros[it.id].v!=="pos"&&state.ros[it.id].v!=="unk"){r.querySelector(".no").click();}',
    "3d: Osszes negativ tiszteli az unk-ot")

# osszefoglaloban jelenjen meg a "nem ismert" csoport
patch(
    '  if(fn.length)fl+=" Célzottan tagadva: "+fn.map(i=>i.l.toLowerCase().replace(" vér szerinti rokonnál","")).join(", ")+".";\n  A.push(fl);',
    '  if(fn.length)fl+=" Célzottan tagadva: "+fn.map(i=>i.l.toLowerCase().replace(" vér szerinti rokonnál","")).join(", ")+".";\n'
    '  const fu=FAMILY.filter(i=>state.ros[i.id]&&state.ros[i.id].v==="unk");\n'
    '  if(fu.length)fl+=" NEM ISMERT (a beteg nem tudja, aktív kizárás nem történt): "+fu.map(i=>i.l.toLowerCase().replace(" vér szerinti rokonnál","")).join(", ")+".";\n'
    '  A.push(fl);',
    "3e: unk az osszefoglaloban")

# CSS a harmadik gombhoz
patch(
    "</style>",
    "\n/* --- v16 --- */\n"
    ".ros .yn .unk{opacity:.85}\n"
    ".ros .yn .unk[aria-pressed=\"true\"]{background:#8a6d3b;color:#fff;border-color:#8a6d3b}\n"
    ".ros.unkon{background:rgba(138,109,59,.07)}\n"
    "#pedWrap{display:flex;flex-direction:column;gap:10px}\n"
    ".pedrow{border:1px solid var(--bd,#d9dde3);border-radius:10px;padding:10px;display:flex;flex-direction:column;gap:8px}\n"
    ".pedrow.rfhit{border-color:#c0392b;background:rgba(192,57,43,.05)}\n"
    ".pedgrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px}\n"
    ".pedgrid label{display:flex;flex-direction:column;font-size:.78rem;gap:3px}\n"
    ".pedgrid input,.pedgrid select{padding:5px;border-radius:6px;border:1px solid var(--bd,#d9dde3);background:transparent;color:inherit;font:inherit}\n"
    ".dxchips{display:flex;flex-wrap:wrap;gap:5px}\n"
    ".dxchips button{border:1px solid var(--bd,#d9dde3);background:transparent;color:inherit;border-radius:999px;padding:3px 9px;font-size:.75rem;cursor:pointer}\n"
    ".dxchips button.on{background:#2d6cdf;color:#fff;border-color:#2d6cdf}\n"
    ".dxchips button.on.rf{background:#c0392b;border-color:#c0392b}\n"
    ".pedhead{display:flex;justify-content:space-between;align-items:center;gap:8px}\n"
    ".pedhead b{font-size:.85rem}\n"
    ".pedbtns{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:4px}\n"
    ".pedbtns button{border:1px dashed var(--bd,#9aa3ad);background:transparent;color:inherit;border-radius:8px;padding:6px 11px;cursor:pointer;font:inherit;font-size:.8rem}\n"
    ".pedwarn{font-size:.78rem;color:#c0392b}\n"
    "</style>",
    "3f: CSS")

# ============================================ 4+5. CSALADFA (PEDIGRE) MODUL
MODULE = r"""
<script>
/* ================= v16: dinamikus családfa (pedigré) =================
   Rokononkénti betegség-hozzárendelés anyai/apai/saját ág szerint, az adat
   FORRÁSÁVAL és dokumentáltságával. A klasszikus checkbox-lista csak azt tudja,
   HOGY van-e ilyen a családban; ez azt is, hogy KINÉL, HÁNY ÉVESEN, KITŐL
   tudjuk, és hogy VAN-E RÓLA DOKUMENTUM. ==================================== */
(function(){
  "use strict";
  /* az app sajat 'state'-je egy IIFE-n belul el, nincs a window-on: sajat tarolo kell */
  var S = window.state || (window.__pedState = window.__pedState || {});
  S.ped = S.ped || [];
  window.__pedState = S;
  var seq = 0;

  var BRANCH = [
    {id:"sajat", l:"Saját ág (szülők, testvérek, gyermekek)",
     rels:["édesanya","édesapa","leánytestvér","fiútestvér","féltestvér","leánygyermek","fiúgyermek"]},
    {id:"anyai", l:"Anyai ág",
     rels:["anyai nagyanya","anyai nagyapa","anyai nagynéni","anyai nagybácsi","anyai unokatestvér","anyai dédszülő"]},
    {id:"apai", l:"Apai ág",
     rels:["apai nagyanya","apai nagyapa","apai nagynéni","apai nagybácsi","apai unokatestvér","apai dédszülő"]}
  ];

  /* rf:"card" = kardiogenetikai út, "gen" = klinikai genetika, "haem", "onc", "pe" */
  var DX = [
    {id:"cmp",  l:"Cardiomyopathia (DCM/HCM/ARVC)", rf:"card"},
    {id:"scd",  l:"Hirtelen szívhalál",             rf:"card"},
    {id:"arr",  l:"Ritmuszavar / channelopathia",   rf:"card"},
    {id:"hf",   l:"Szívizombetegség / szívelégtelenség — közelebbi dg nélkül", rf:"card"},
    {id:"chd",  l:"Veleszületett szívhiba",         rf:"gen"},
    {id:"mi",   l:"Korai infarktus / stroke (férfi <55, nő <65)"},
    {id:"htn",  l:"Hypertonia"},
    {id:"vte",  l:"Thrombosis / thrombophilia",     rf:"haem"},
    {id:"dm",   l:"Diabetes"},
    {id:"pe",   l:"Preeclampsia / HELLP",           rf:"pe"},
    {id:"canc", l:"Daganat",                        rf:"onc"},
    {id:"ren",  l:"Vesebetegség / dialízis"},
    {id:"hep",  l:"Májbetegség"},
    {id:"ai",   l:"Autoimmun betegség"},
    {id:"neu",  l:"Neurológiai / izombetegség",     rf:"gen"},
    {id:"dev",  l:"Értelmi fogyatékosság / fejlődési zavar", rf:"gen"},
    {id:"mal",  l:"Veleszületett rendellenesség",   rf:"gen"},
    {id:"mono", l:"Ismert öröklődő (monogénes) betegség", rf:"gen"},
    {id:"unkn", l:"Tisztázatlan okú betegség vagy halál", rf:"card"},
    {id:"oth",  l:"Egyéb"}
  ];
  var DXMAP={}; DX.forEach(function(d){DXMAP[d.id]=d;});

  var CERT = [
    {id:"doc",  l:"orvosi dokumentummal igazolt"},
    {id:"phys", l:"orvos közölte, dokumentum nincs"},
    {id:"fam",  l:"családi elmondás"},
    {id:"none", l:"nem tisztázott"}
  ];
  var STATUS = [
    {id:"alive", l:"él"},
    {id:"dead",  l:"elhunyt"},
    {id:"unk",   l:"nem tudom"}
  ];

  function gen(){ if(typeof window.generate==="function"){ try{window.generate();}catch(e){} } }
  function eln(tag,cls,html){var e=document.createElement(tag); if(cls)e.className=cls; if(html!=null)e.innerHTML=html; return e;}
  function opts(sel,arr,valKey,labKey,cur){
    arr.forEach(function(o){
      var op=document.createElement("option");
      op.value = valKey?o[valKey]:o; op.textContent = labKey?o[labKey]:o;
      if(cur!=null && op.value===cur) op.selected=true;
      sel.appendChild(op);
    });
  }
  function isRF(p){ return (p.dx||[]).some(function(id){return DXMAP[id]&&DXMAP[id].rf;}); }

  /* ---- egy rokon sora ---- */
  function pedRow(p, host){
    var row = eln("div","pedrow");
    var head = eln("div","pedhead");
    var title = eln("b", null, "");
    var del = eln("button",null,"✕ Törlés");
    del.type="button"; del.style.cssText="border:0;background:transparent;color:inherit;cursor:pointer;opacity:.7";
    del.onclick=function(){ S.ped=S.ped.filter(function(x){return x!==p;}); host.removeChild(row); gen(); };
    head.append(title, del); row.append(head);

    var grid = eln("div","pedgrid");

    var lRel=eln("label",null,"<span>Rokon</span>"); var sRel=document.createElement("select");
    var br = BRANCH.filter(function(b){return b.id===p.branch;})[0]||BRANCH[0];
    opts(sRel, br.rels, null, null, p.rel); sRel.value=p.rel||br.rels[0];
    lRel.appendChild(sRel); grid.appendChild(lRel);

    var lSt=eln("label",null,"<span>Állapot</span>"); var sSt=document.createElement("select");
    opts(sSt, STATUS,"id","l",p.status||"alive"); lSt.appendChild(sSt); grid.appendChild(lSt);

    var lAge=eln("label",null,"<span>Életkor (év) / elhalálozási kor</span>");
    var iAge=document.createElement("input"); iAge.type="number"; iAge.min="0"; iAge.max="120";
    iAge.placeholder="pl. 35"; if(p.age)iAge.value=p.age; lAge.appendChild(iAge); grid.appendChild(lAge);

    var lCert=eln("label",null,"<span>A diagnózis megbízhatósága</span>"); var sCert=document.createElement("select");
    opts(sCert, CERT,"id","l",p.cert||"fam"); lCert.appendChild(sCert); grid.appendChild(lCert);

    var lSrc=eln("label",null,"<span>Az adat forrása (ki közölte)</span>");
    var iSrc=document.createElement("input"); iSrc.placeholder="pl. a beteg édesanyja";
    if(p.src)iSrc.value=p.src; lSrc.appendChild(iSrc); grid.appendChild(lSrc);

    var lNote=eln("label",null,"<span>Megjegyzés</span>");
    var iNote=document.createElement("input"); iNote.placeholder="szabad szöveg";
    if(p.note)iNote.value=p.note; lNote.appendChild(iNote); grid.appendChild(lNote);

    row.appendChild(grid);

    var chips = eln("div","dxchips");
    DX.forEach(function(d){
      var b=eln("button",null,d.l); b.type="button";
      if(d.rf) b.classList.add("rf");
      if((p.dx||[]).indexOf(d.id)>=0) b.classList.add("on");
      b.onclick=function(){
        p.dx = p.dx||[];
        var i=p.dx.indexOf(d.id);
        if(i>=0){p.dx.splice(i,1); b.classList.remove("on");}
        else {p.dx.push(d.id); b.classList.add("on");}
        refresh(); gen();
      };
      chips.appendChild(b);
    });
    row.appendChild(chips);

    var warn = eln("div","pedwarn","");
    row.appendChild(warn);

    function refresh(){
      p.rel=sRel.value; p.status=sSt.value; p.age=iAge.value; p.cert=sCert.value;
      p.src=iSrc.value; p.note=iNote.value;
      title.textContent = (br.l.split(" (")[0]) + " · " + (p.rel||"");
      row.classList.toggle("rfhit", isRF(p));
      var msgs=[];
      if(isRF(p) && p.cert!=="doc")
        msgs.push("▲ Vörös zászlós adat orvosi dokumentum nélkül — az eredeti dokumentum (zárójelentés, boncjegyzőkönyv, halotti bizonyítvány) beszerzése javasolt.");
      if(isRF(p) && !p.src)
        msgs.push("▲ Nincs megadva, hogy kitől származik az adat.");
      warn.innerHTML = msgs.join("<br>");
    }
    [sRel,sSt,sCert].forEach(function(x){x.onchange=function(){refresh();gen();};});
    [iAge,iSrc,iNote].forEach(function(x){x.oninput=function(){refresh();gen();};});
    refresh();
    return row;
  }

  /* ---- szekció beépítése a 06-os után ---- */
  function mount(){
    var famSec = document.querySelector("#rosFamily");
    if(!famSec) return false;
    var det = famSec.closest("details");
    if(!det || document.querySelector("#pedWrap")) return true;

    var sec = document.createElement("details");
    sec.className="sec";
    sec.innerHTML =
      '<summary><span class="num">6b</span> Családfa (pedigré) — rokononkénti betegségek, anyai / apai ág <span class="chev">›</span></summary>'+
      '<div class="body">'+
      '<p class="hint" style="margin:0 0 10px">Itt nem azt rögzítjük, hogy <i>van-e</i> a családban valami, hanem hogy <b>kinél</b>, '+
      '<b>hány évesen</b>, <b>kitől tudjuk</b>, és hogy <b>van-e róla orvosi dokumentum</b>. '+
      'A piros keretes címkék genetikai/kardiológiai utat indítanak.</p>'+
      '<div class="pedbtns"></div><div id="pedWrap"></div>'+
      '</div>';
    det.parentNode.insertBefore(sec, det.nextSibling);

    var btns = sec.querySelector(".pedbtns");
    var host = sec.querySelector("#pedWrap");
    BRANCH.forEach(function(b){
      var bt=eln("button",null,"+ "+b.l); bt.type="button";
      bt.onclick=function(){
        var p={id:++seq,branch:b.id,rel:b.rels[0],status:"alive",age:"",dx:[],cert:"fam",src:"",note:""};
        S.ped.push(p); host.appendChild(pedRow(p,host)); gen();
      };
      btns.appendChild(bt);
    });
    return true;
  }

  /* ---- szöveges kimenet + vörös zászlók ---- */
  function pedText(){
    if(!S.ped || !S.ped.length) return "";
    var L=[]; L.push("");
    L.push("CSALÁDFA (PEDIGRÉ) — rokononkénti adatok:");
    BRANCH.forEach(function(b){
      var rows=S.ped.filter(function(p){return p.branch===b.id;});
      if(!rows.length) return;
      L.push("  "+b.l.split(" (")[0]+":");
      rows.forEach(function(p){
        var s = "   • "+(p.rel||"rokon");
        var stx = (p.status==="dead")?"elhunyt":(p.status==="unk"?"állapota nem ismert":"él");
        s += ", "+stx;
        if(p.age) s += " "+p.age+" évesen";
        var dxs=(p.dx||[]).map(function(id){return DXMAP[id]?DXMAP[id].l:id;});
        s += dxs.length? " — "+dxs.join(", ") : " — nincs rögzített betegség";
        var c=CERT.filter(function(x){return x.id===p.cert;})[0];
        s += "; a diagnózis "+((c&&c.l)||"nem tisztázott");
        if(p.src) s += "; az adat forrása: "+p.src;
        else if(dxs.length) s += "; az adat forrása nincs rögzítve";
        if(p.note) s += " ("+p.note+")";
        L.push(s+".");
      });
    });

    var card=[], gene=[], haem=[], onc=[], pe=[], undoc=[];
    S.ped.forEach(function(p){
      (p.dx||[]).forEach(function(id){
        var d=DXMAP[id]; if(!d||!d.rf) return;
        var who=(p.rel||"rokon")+(p.age?(" ("+p.age+" é.)"):"");
        if(d.rf==="card")card.push(who+" — "+d.l);
        else if(d.rf==="gen")gene.push(who+" — "+d.l);
        else if(d.rf==="haem")haem.push(who+" — "+d.l);
        else if(d.rf==="onc")onc.push(who+" — "+d.l);
        else if(d.rf==="pe")pe.push(who+" — "+d.l);
      });
      if(isRF(p)&&p.cert!=="doc") undoc.push((p.rel||"rokon"));
    });

    if(card.length||gene.length||haem.length||onc.length||pe.length){
      L.push("");
      L.push("GENETIKAI / KARDIOLÓGIAI VÖRÖS ZÁSZLÓK A CSALÁDFÁBÓL:");
      if(card.length){
        L.push("  ■ Kardiogenetika: "+card.join("; ")+".");
        L.push("    → Kardiogenetikai tanácsadás + célzott génpanel (DCM/HCM/ARVC/channelopathia); kaszkádszűrés a rokonoknál.");
        L.push("    → A betegnél kiindulási EKG + echokardiográfia + NT-proBNP.");
      }
      if(gene.length) L.push("  ■ Klinikai genetika: "+gene.join("; ")+". → genetikai tanácsadás, indokolt esetben célzott vizsgálat / carrier screening.");
      if(haem.length) L.push("  ■ Haematologia: "+haem.join("; ")+". → thrombophilia-szűrés, LMWH-terv mérlegelése.");
      if(onc.length)  L.push("  ■ Onkogenetika: "+onc.join("; ")+". → örökletes daganatszindróma irányában tanácsadás.");
      if(pe.length)   L.push("  ■ Preeclampsia-rizikó: "+pe.join("; ")+". → alacsony dózisú aszpirin a 16. hét előtt.");
    }
    if(undoc.length){
      L.push("");
      L.push("DOKUMENTÁCIÓS HIÁNY: "+undoc.length+" vörös zászlós tétel ("+undoc.join(", ")+
             ") nincs orvosi dokumentummal alátámasztva. Az eredeti dokumentum beszerzése javasolt; "+
             "a fenotípus enélkül nem tisztázható, és a célzott génpanel választását is befolyásolja.");
    }
    return L.join("\n");
  }

  function enrichPed(){
    var out=document.querySelector("#anamOut");
    if(!out) return;
    var txt=pedText();
    var prev=out.querySelector("#pedBlock");
    if(prev) prev.parentNode.removeChild(prev);
    if(!txt) return;
    var span=document.createElement("span");
    span.id="pedBlock"; span.textContent=txt+"\n";
    out.appendChild(span);
  }

  function init(){
    if(!mount()) { setTimeout(init,300); return; }
    if(typeof window.generate==="function"){
      var og=window.generate;
      window.generate=function(){ var r=og.apply(this,arguments); try{enrichPed();}catch(e){window.__pedErr=(e&&e.message)||String(e);} return r; };
      try{ window.generate(); }catch(e){}
    }
    window.__ped = {DX:DX,BRANCH:BRANCH,text:pedText};
  }
  if(document.readyState==="loading") document.addEventListener("DOMContentLoaded",init);
  else init();
})();
</script>
"""

t = t.rstrip() + "\n" + MODULE + "\n"
applied.append("4+5: csaladfa modul")

io.open(OUT, "w", encoding="utf-8").write(t)
print("kesz:", os.path.basename(OUT))
print("meret: %d -> %d B (+%d)" % (n0, len(t), len(t) - n0))
for a in applied:
    print("  OK", a)

```

### `build_v16_part2.py`

212 sor, 13 KB.

```python
# -*- coding: utf-8 -*-
"""v16 masodik szakasz: endokrin anamnezis terhessegi vonallal,
biobanki/tudomanyos ENGEDELYEZO nyilatkozat, kalkulator- es UH-tajekoztato."""
import io, os, json

D = r"C:\Users\szili\Documents\claude\apps\anamnezis-asszisztens"
F = os.path.join(D, "Anamnezis_asszisztens_v16_tobbnyelvu.html")
t = io.open(F, encoding="utf-8").read()
n0 = len(t)
applied = []


def patch(old, new, tag):
    global t
    assert old in t, "NEM TALALOM: " + tag
    t = t.replace(old, new, 1)
    applied.append(tag)


def js_lines(lines, indent="      "):
    return "\n".join(indent + json.dumps(x, ensure_ascii=False) + "," for x in lines)


# ================================================== 6. ENDOKRIN SZEKCIO (HTML)
patch(
    '    <details class="sec"><summary><span class="num">04</span> Gyógyszeres terápia',
    '    <details class="sec"><summary><span class="num">3b</span> Endokrin anamnézis — kiemelt terhességi vonallal <span class="chev">›</span></summary>\n'
    '      <div class="body">\n'
    '        <p class="hint" style="margin:0 0 10px">Minden endokrin tétel alatt a <b>terhességi vonal</b> olvasható: '
    'mi változik terhességben, és mi a teendő. A pozitív válasz ezt automatikusan beemeli a teendőlistába.</p>\n'
    '        <div id="rosEndo"></div>\n'
    '      </div>\n'
    '    </details>\n\n'
    '    <details class="sec"><summary><span class="num">04</span> Gyógyszeres terápia',
    "6a: endokrin szekcio HTML")

ENDO_ITEMS = [
 ("en_hypo", "Hypothyreosis (pajzsmirigy-alulműködés)", "med", "warn",
  "Terhesség megállapításakor a levotiroxin-dózis azonnali emelése (kb. +25–30%); TSH-cél az I. trimeszterben < 2,5 mIU/L; TSH 4 hetente a 20. hétig."),
 ("en_hyper", "Hyperthyreosis / Graves-kór", "med", "warn",
  "Az I. trimeszterben propiltiouracil, utána methimazol; TRAK-mérés a 20–24. héten (magzati thyreotoxicosis kockázata); magzati pajzsmirigy-ultrahang."),
 ("en_tpo", "Pozitív TPO-ellenanyag / thyreoiditis euthyreosis mellett", "lab", "info",
  "TSH trimeszterenként; fokozott hypothyreosis- és vetélési kockázat."),
 ("en_thyop", "Pajzsmirigy-göb, korábbi pajzsmirigyműtét vagy radiojód-kezelés", "lab", "info",
  "Radiojód után legalább 6 hónap várakozás a fogantatásig; a szubsztitúció terhességi dózisemelése; ultrahang-követés."),
 ("en_pcos", "PCOS (policisztás ovárium szindróma)", "lab", "warn",
  "Emelkedett GDM- és preeclampsia-kockázat; korai OGTT (16–18. hét) mérlegelése, majd ismétlés a 24–28. héten."),
 ("en_dm1", "1-es típusú diabetes mellitus", "med", "crit",
  "Prekoncepcionálisan HbA1c < 6,5%; 5 mg folsav; retina- és vesestátusz felmérése; ACE-gátló / ARB / statin leállítása; szoros glykaemiás követés; ASA a 16. hét előtt."),
 ("en_dm2", "2-es típusú diabetes mellitus", "med", "crit",
  "Orális szerek felülvizsgálata (metformin / inzulin); HbA1c-cél a fogantatás előtt; 5 mg folsav; ASA preeclampsia-profilaxis a 16. hét előtt."),
 ("en_gdm", "Korábbi gesztációs diabetes", "lab", "warn",
  "Korai OGTT (16–18. hét), majd ismétlés a 24–28. héten; postpartum 4–12 héttel ismételt OGTT."),
 ("en_ir", "Inzulinrezisztencia / metformin-szedés", "med", "info",
  "A metformin terhességben folytatható, de a kezelés célját újra kell értékelni; a GDM-szűrés időzítése előrehozandó."),
 ("en_glp", "GLP-1 receptor agonista szedése (pl. semaglutid, liraglutid, tirzepatid)", "med", "crit",
  "Terhességben nem javasolt: a fogantatás előtti leállítás és a készítményspecifikus washout betartása (hosszú felezési idejű szereknél hetek); fogamzásgátlás a washout alatt."),
 ("en_bar", "Bariátriai (elhízás-)műtét utáni állapot", "lab", "warn",
  "A műtét után legalább 12–18 hónap várakozás; vas, B12, folsav, D-vitamin és kalcium célzott pótlása és követése; dömping miatt módosított GDM-szűrés."),
 ("en_prl", "Hyperprolactinaemia / prolactinoma", "ref", "warn",
  "Makroadenománál látótér-vizsgálat trimeszterenként; a dopamin-agonista folytatásának egyedi mérlegelése; új fejfájás vagy látászavar azonnali kivizsgálása."),
 ("en_adr", "Mellékvese-betegség (Addison, Cushing, CAH)", "ref", "crit",
  "Addison-kórban stressz-dózisú hidrokortizon a szülés alatt; CAH-ban genetikai tanácsadás; Cushing-szindrómában fokozott preeclampsia-, GDM- és koraszülés-kockázat."),
 ("en_pth", "Mellékpajzsmirigy-betegség / kalcium-anyagcsere zavara", "lab", "warn",
  "Szérum-kalcium és albumin követése; az anyai hypercalcaemia magzati mellékpajzsmirigy-szuppressziót és újszülöttkori tetaniát okozhat."),
 ("en_pit", "Hypophysis-elégtelenség / korábbi Sheehan-szindróma", "med", "crit",
  "A hormonpótlás dózisának terhességi felülvizsgálata; szülés körüli szteroid-fedés; postpartum vérzés esetén fokozott figyelem."),
 ("en_ost", "Osteoporosis / biszfoszfonát-kezelés", "med", "warn",
  "A biszfoszfonát a csontban perzisztál; fogantatás előtti leállítás és egyedi kockázatértékelés szükséges."),
 ("en_vitd", "Ismert D-vitamin-hiány", "lab", "info",
  "Pótlás beállítása (800–2000 NE/nap) és a szint ellenőrzése."),
]

endo_js = "const ENDO=[\n" + "\n".join(
    "  {id:%s,l:%s,cat:%s,sev:%s,preg:%s}," % (
        json.dumps(i, ensure_ascii=False), json.dumps(l, ensure_ascii=False),
        json.dumps(c, ensure_ascii=False), json.dumps(s, ensure_ascii=False),
        json.dumps(p, ensure_ascii=False))
    for i, l, c, s, p in ENDO_ITEMS) + "\n];\n"

patch("const LIFE=[", endo_js + "const LIFE=[", "6b: ENDO adatszerkezet")

patch(
    "function famRow(item){return rosRow(item);}",
    "function famRow(item){return rosRow(item);}\n"
    "/* v16: endokrin sor + kiemelt terhessegi vonal */\n"
    "function renderEndoList(host,arr){\n"
    "  if(!host) return;\n"
    "  arr.forEach(function(i){\n"
    "    var wrap=el('div','endowrap');\n"
    "    wrap.appendChild(rosRow(i));\n"
    "    wrap.appendChild(el('div','pregline','<b>Terhességi vonal:</b> '+i.preg));\n"
    "    host.appendChild(wrap);\n"
    "  });\n"
    "}",
    "6c: endokrin renderer")

patch('renderRosList($("#rosFamily"),FAMILY);',
      'renderRosList($("#rosFamily"),FAMILY);\ntry{renderEndoList($("#rosEndo"),ENDO);}catch(e){}',
      "6d: endokrin render hivas")

patch(
    '  if(st.f_chd&&st.f_chd.v==="pos") add("lab","Részletes magzati echokardiográfia (családi CHD).","családi congenitalis szívhiba","info");',
    '  if(st.f_chd&&st.f_chd.v==="pos") add("lab","Részletes magzati echokardiográfia (családi CHD).","családi congenitalis szívhiba","info");\n'
    '  try{ ENDO.forEach(function(e){ if(st[e.id]&&st[e.id].v==="pos") add(e.cat||"med", e.preg, e.l, e.sev||"warn"); }); }catch(e){}',
    "6e: endokrin -> teendok")

patch(
    "  // lifestyle\n  const lp=posList(LIFE), ln=negList(LIFE);",
    "  // endokrin (v16)\n"
    "  try{\n"
    "    const ep=ENDO.filter(i=>state.ros[i.id]&&state.ros[i.id].v===\"pos\");\n"
    "    const eu=ENDO.filter(i=>state.ros[i.id]&&state.ros[i.id].v===\"unk\");\n"
    "    if(ep.length||eu.length){\n"
    "      let ez=\"ENDOKRIN ANAMNÉZIS: \";\n"
    "      ez+= ep.length? ep.map(i=>i.l).join(\"; \")+\".\" : \"érdemi endokrin előzmény nem ismert.\";\n"
    "      if(eu.length)ez+=\" NEM ISMERT: \"+eu.map(i=>i.l).join(\", \")+\".\";\n"
    "      if(ep.length)ez+=\" A terhességi teendők tételesen a teendőlistában.\";\n"
    "      A.push(ez);\n"
    "    }\n"
    "  }catch(e){}\n\n"
    "  // lifestyle\n  const lp=posList(LIFE), ln=negList(LIFE);",
    "6f: endokrin osszefoglalo")

patch("/* --- v16 --- */",
      "/* --- v16 --- */\n"
      ".endowrap{margin-bottom:2px}\n"
      ".pregline{margin:-2px 0 10px;padding:7px 10px;border-left:3px solid #2d6cdf;"
      "background:rgba(45,108,223,.07);border-radius:0 8px 8px 0;font-size:.8rem;line-height:1.45}\n"
      ".pregline b{color:#2d6cdf}\n",
      "6g: endokrin CSS")

# ============================ 7. BIOBANKI / TUDOMANYOS ENGEDELYEZO NYILATKOZAT
OLD7 = ('      "TUDOMÁNYOS CÉLÚ FELHASZNÁLÁS: Hozzájárulok ahhoz, hogy anonimizált '
        '(személyazonosításra alkalmatlan) egészségügyi adataimat tudományos kutatás, oktatás '
        'és minőségfejlesztés céljából felhasználják.    ☐ Hozzájárulok     ☐ Nem járulok hozzá",')

CONSENT = [
 "TUDOMÁNYOS ÉS BIOBANKI FELHASZNÁLÁS — HOZZÁJÁRULÓ NYILATKOZAT",
 "Az alábbi pontok mindegyike ÖNÁLLÓAN választható. A hozzájárulás ÖNKÉNTES, bármikor, "
 "indoklás nélkül, írásban VISSZAVONHATÓ, és a visszavonás a további ellátás minőségét nem "
 "befolyásolja. A visszavonás a már elvégzett, anonimizált elemzések eredményét nem érinti.",
 "  1. Anonimizált egészségügyi adataim felhasználása tudományos kutatás, oktatás és "
 "minőségfejlesztés céljára.    ☐ HOZZÁJÁRULOK   ☐ nem",
 "  2. A diagnosztikai célból levett minták maradékának (vér, szövet) biobanki tárolása és "
 "kutatási felhasználása.    ☐ HOZZÁJÁRULOK   ☐ nem",
 "  3. A szülés során egyébként megsemmisítésre kerülő anyagok (placenta, köldökzsinór és "
 "köldökzsinórvér, magzatburok) kutatási célú felhasználása.    ☐ HOZZÁJÁRULOK   ☐ nem",
 "  4. Genetikai vizsgálat végzése a tárolt mintán, kutatási céllal, anonimizáltan.    "
 "☐ HOZZÁJÁRULOK   ☐ nem",
 "  5. Széles körű (broad consent) felhasználás: a minta és az adat jövőbeni, még meg nem "
 "határozott, etikai engedéllyel rendelkező kutatásokban való felhasználása.    "
 "☐ HOZZÁJÁRULOK   ☐ nem",
 "  6. Anonimizált adatok és minták továbbítása hazai és nemzetközi kutatási együttműködés "
 "keretében (EGT-n kívülre is, megfelelő garanciákkal).    ☐ HOZZÁJÁRULOK   ☐ nem",
 "  7. Kapcsolatfelvétel a jövőben további kutatási részvétel felajánlása céljából.    "
 "☐ HOZZÁJÁRULOK   ☐ nem",
 "  8. A kutatás során véletlenül felfedezett, klinikailag jelentős (érdemi beavatkozást "
 "lehetővé tevő) lelet visszajelzése számomra.    ☐ KÉREM   ☐ nem kérem",
 "A tárolás és felhasználás a GDPR és a vonatkozó hazai egészségügyi adatvédelmi szabályok "
 "szerint, illetékes etikai bizottsági engedély birtokában történik. A minta és az adat "
 "kereskedelmi értékesítése nem történik.",
 "A tájékoztatást megértettem, kérdéseimre választ kaptam, és a fenti pontokban jelöltek "
 "szerint nyilatkozom.",
 "   Beteg aláírása: ……………………………    Tájékoztató orvos: ……………………………    Dátum: ……………………",
]
patch(OLD7, js_lines(CONSENT), "7: biobanki engedelyezo nyilatkozat")

# ================= 8. KALKULATOR- ES ULTRAHANG-TAJEKOZTATO
INFO = [
 "TÁJÉKOZTATÓ A KOCKÁZATBECSLÉS ÉS A SZŰRŐVIZSGÁLATOK TERMÉSZETÉRŐL",
 "1. A fenti kalkulátorok KOCKÁZATBECSLÉST adnak, nem diagnózist. A százalékos érték "
 "populációs valószínűség, amely az adott személyre nem mondja meg, bekövetkezik-e az esemény.",
 "2. A szűrővizsgálatok — beleértve az ultrahangot — természetüknél fogva NEM 100%-os "
 "érzékenységűek, egyetlen állapotban sem. A kimutatási arányt befolyásolja a terhességi kor, "
 "a magzat helyzete, a magzatvíz mennyisége, az anyai testalkat (magasabb testtömegindex "
 "esetén érdemben csökken a képminőség), a többes terhesség és a készülék felbontása.",
 "3. Ebből következően a NEGATÍV (eltérést nem mutató) szűrővizsgálat a rendellenességet vagy "
 "a szövődményt NEM ZÁRJA KI, a pozitív szűrőeredmény pedig önmagában nem jelent betegséget — "
 "mindkét esetben további, diagnosztikus vizsgálat szükséges. Álnegatív és álpozitív eredmény "
 "a szakmai szabályok maradéktalan betartása mellett is előfordul.",
 "4. A szűrővizsgálat tehát nem diagnosztikus vizsgálat. A szakmai szabályoknak megfelelően "
 "elvégzett és dokumentált szűrés korlátja a módszer sajátja. Az ellátó felelőssége a "
 "vizsgálat szakszerű elvégzésére, dokumentálására és a tájékoztatásra terjed ki.",
 "5. Ez az alkalmazás klinikai DÖNTÉSTÁMOGATÓ eszköz: a szakorvosi értékelést nem "
 "helyettesíti, és önállóan diagnózist nem állít fel. A végső klinikai döntés minden esetben "
 "a kezelőorvosé.",
 "   A tájékoztatást megértettem — Beteg aláírása: ……………………………    Dátum: ……………………",
]
patch("    var decl=[RULE,",
      "    var decl=[RULE,\n" + js_lines(INFO) + "\n      RULE,",
      "8a: kalkulator/UH tajekoztato")

patch('<div class="todo" id="riskOut">',
      '<div class="calcnote">A kalkulátorok <b>kockázatbecslést</b> adnak, nem diagnózist. '
      'A szűrővizsgálatok — az ultrahangot is beleértve — egyetlen állapotban sem 100%-os '
      'érzékenységűek, ezért a negatív eredmény nem zárja ki a kórképet. A részletes '
      'tájékoztató a nyomtatott dokumentum végén olvasható.</div>\n'
      '<div class="todo" id="riskOut">',
      "8b: lathato banner")

patch("/* --- v16 --- */",
      "/* --- v16 --- */\n"
      ".calcnote{margin:0 0 10px;padding:8px 11px;border-left:3px solid #8a6d3b;"
      "background:rgba(138,109,59,.09);border-radius:0 8px 8px 0;font-size:.78rem;line-height:1.5}\n",
      "8c: banner CSS")

io.open(F, "w", encoding="utf-8").write(t)
print("meret: %d -> %d B (+%d)" % (n0, len(t), len(t) - n0))
for a in applied:
    print("  OK", a)

```

### `build_v16_part3.py`

145 sor, 6 KB.

```python
# -*- coding: utf-8 -*-
"""v16 harmadik szakasz: a kalkulator-panel bemeneteinek athelyezese a bal oldalra.
Az id-k valtozatlanok maradnak, ezert minden kalkulator-logika tovabb mukodik."""
import io, os

D = r"C:\Users\szili\Documents\claude\apps\anamnezis-asszisztens"
F = os.path.join(D, "Anamnezis_asszisztens_v16_tobbnyelvu.html")
t = io.open(F, encoding="utf-8").read()
n0 = len(t)

MODULE = r"""
<script>
/* ============ v16/3: kalkulator-bemenetek athelyezese a bal oldalra ============
   A jobb oldali kalkulator-panel eddig sajat beviteli mezoket tartott. Ezek a
   mezok tartalom szerint a bal oldalra valok: a laborertekek a Labor szekciohoz,
   a vitalis parameterek az alapadatokhoz. Az input ELEMEKET mozgatjuk at, az
   id-k valtozatlanul - igy minden meglevo kalkulator-koto valtozatlanul mukodik.
   ============================================================================ */
(function(){
  "use strict";

  var LAB = [
    ["OGTT (75 g)",            ["k_og0","k_og1","k_og2"]],
    ["Angiogén markerek",      ["k_plgf","k_sflt","k_ratio"]],
    ["Ionok, anyagcsere",      ["k_na","k_ca","c_ins"]],
    ["Epesav / transzfúzió",   ["k_ba","k_hbtar"]]
  ];
  var VIT = [
    ["Vitális paraméterek",    ["c_hr","k_hr2","c_spo2","k_sbp"]],
    ["Kardiológiai besorolás", ["c_mwho","c_qt","c_chest"]]
  ];
  /* a magzati parameterek NEM ide kerulnek: azok az ultrahang-modul sajatjai */
  var US = ["k_crl","k_bpd","k_hc","k_ac","k_fl","k_afi","k_ua","k_mca"];

  function eln(tag,cls,html){var e=document.createElement(tag); if(cls)e.className=cls; if(html!=null)e.innerHTML=html; return e;}

  function holder(id){
    var i=document.getElementById(id);
    if(!i) return null;
    var lab=i.closest("label");
    return lab||i.parentNode;
  }

  function ensureGroup(host, title, key){
    var g=host.querySelector('[data-mig="'+key+'"]');
    if(g) return g;
    g=eln("div","miggrp"); g.setAttribute("data-mig",key);
    g.appendChild(eln("div","migh",title));
    var box=eln("div","migbox"); g.appendChild(box);
    host.appendChild(g);
    return g;
  }

  function moveInto(host, groups){
    if(!host) return 0;
    var n=0;
    groups.forEach(function(pair){
      var title=pair[0], ids=pair[1];
      var present=ids.filter(function(id){return !!document.getElementById(id);});
      if(!present.length) return;
      var box=ensureGroup(host,title,title).querySelector(".migbox");
      present.forEach(function(id){
        var h=holder(id);
        if(!h||h.parentNode===box) return;
        box.appendChild(h); n++;
      });
    });
    return n;
  }

  function vitalsHost(){
    /* az alapadat-r\u00e1cs, ahol a v\u00e9rnyom\u00e1s/testmagass\u00e1g mezok vannak */
    var bp=document.getElementById("bp");
    if(!bp) return null;
    var lab=bp.closest("label"); if(!lab) return null;
    var grid=lab.parentNode;
    var wrap=grid.parentNode.querySelector('[data-mig="vitwrap"]');
    if(!wrap){
      wrap=eln("div",null,""); wrap.setAttribute("data-mig","vitwrap");
      grid.parentNode.insertBefore(wrap, grid.nextSibling);
    }
    return wrap;
  }

  function note(host, txt){
    if(!host || host.querySelector(".mignote")) return;
    host.insertBefore(eln("div","mignote",txt), host.firstChild);
  }

  function migrate(){
    var lab=document.getElementById("labHost");
    if(lab){
      note(lab,"Az al\u00e1bbi \u00e9rt\u00e9kek kor\u00e1bban a jobb oldali kalkul\u00e1tor-s\u00e1vban voltak. "+
                "Itt r\u00f6gz\u00edtve ugyan\u00fagy t\u00e1pl\u00e1lj\u00e1k a kalkul\u00e1torokat.");
      moveInto(lab, LAB);
    }
    var vh=vitalsHost();
    if(vh){
      note(vh,"Vit\u00e1lis \u00e9s kardiol\u00f3giai param\u00e9terek \u2014 a kalkul\u00e1torok innen olvassák.");
      moveInto(vh, VIT);
    }
    /* a magzati param\u00e9terek mell\u00e9 mutat\u00f3 jelz\u00e9s, am\u00edg az UH-modul el nem k\u00e9sz\u00fcl */
    var first=document.getElementById(US[0]);
    if(first){
      var h=first.closest(".calcrow")||first.closest("label");
      if(h&&!h.querySelector(".migus")){
        h.appendChild(eln("div","migus","\u25b8 Ezek a magzati param\u00e9terek az Ultrahang-modulba ker\u00fclnek \u00e1t, "+
                                        "vizitenk\u00e9nt (d\u00e1tum + terhess\u00e9gi h\u00e9t) r\u00f6gz\u00edtve."));
      }
    }
  }

  function init(){
    try{ migrate(); }catch(e){ window.__migErr=(e&&e.message)||String(e); }
    if(typeof window.generate==="function"){
      var og=window.generate;
      window.generate=function(){ var r=og.apply(this,arguments); try{migrate();}catch(e){} return r; };
    }
    /* a kalkul\u00e1tor-modulok k\u00e9sleltetve injekt\u00e1lnak, ez\u00e9rt m\u00e9g p\u00e1rszor pr\u00f3b\u00e1lkozunk */
    var tries=0, iv=setInterval(function(){ tries++; try{migrate();}catch(e){} if(tries>10)clearInterval(iv); }, 400);
    window.__mig={migrate:migrate};
  }
  if(document.readyState==="loading") document.addEventListener("DOMContentLoaded",init);
  else init();
})();
</script>
"""

CSS = ("/* --- v16 --- */\n"
       ".miggrp{margin:0 0 12px}\n"
       ".migh{font-size:.76rem;font-weight:700;opacity:.75;margin:0 0 5px;"
       "text-transform:uppercase;letter-spacing:.03em}\n"
       ".migbox{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:8px}\n"
       ".migbox label{display:flex;flex-direction:column;font-size:.78rem;gap:3px}\n"
       ".mignote{grid-column:1/-1;font-size:.75rem;opacity:.7;margin:0 0 8px;line-height:1.45}\n"
       ".migus{margin-top:6px;font-size:.75rem;color:#2d6cdf}\n")

assert "/* --- v16 --- */" in t
t = t.replace("/* --- v16 --- */", CSS, 1)
t = t.rstrip() + "\n" + MODULE + "\n"

io.open(F, "w", encoding="utf-8").write(t)
print("meret: %d -> %d B (+%d)" % (n0, len(t), len(t) - n0))
print("  OK athelyezo modul + CSS")

```

### `build_v16_part4.py`

515 sor, 27 KB.

```python
# -*- coding: utf-8 -*-
"""v16/4: ultrahang-modul - vizitsoros magzati biometria, paros szervek,
SVG diagramok es publikaciobol tolthető normogramok (novekedes- es kockazatkontroll)."""
import io, os

D = r"C:\Users\szili\Documents\claude\apps\anamnezis-asszisztens"
F = os.path.join(D, "Anamnezis_asszisztens_v16_tobbnyelvu.html")
t = io.open(F, encoding="utf-8").read()
n0 = len(t)

CSS = """/* --- v16 --- */
#usWrap{display:flex;flex-direction:column;gap:12px}
.usbtns{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:4px}
.usbtns button{border:1px dashed var(--bd,#9aa3ad);background:transparent;color:inherit;border-radius:8px;padding:6px 11px;cursor:pointer;font:inherit;font-size:.8rem}
.usbtns button.pri{border-style:solid;border-color:#2d6cdf;color:#2d6cdf;font-weight:600}
.usvisit{border:1px solid var(--bd,#d9dde3);border-radius:10px;padding:10px}
.usvhead{display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:8px}
.usvhead b{font-size:.85rem}
.usgrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:8px}
.usgrid label{display:flex;flex-direction:column;font-size:.75rem;gap:3px}
.usgrid input{padding:5px;border-radius:6px;border:1px solid var(--bd,#d9dde3);background:transparent;color:inherit;font:inherit}
.usgrid input.p10{border-color:#c0392b;background:rgba(192,57,43,.06)}
.usgrid input.p90{border-color:#8a6d3b;background:rgba(138,109,59,.08)}
.usgh{grid-column:1/-1;font-size:.72rem;font-weight:700;opacity:.7;text-transform:uppercase;letter-spacing:.03em;margin-top:6px}
.uspct{font-size:.68rem;opacity:.75}
.uspct.bad{color:#c0392b;font-weight:700;opacity:1}
.uspct.warnp{color:#8a6d3b;font-weight:600;opacity:1}
.uschart{border:1px solid var(--bd,#d9dde3);border-radius:10px;padding:8px;margin-bottom:10px;overflow-x:auto}
.uschart h6{margin:0 0 4px;font-size:.8rem}
.uschart .src{font-size:.68rem;opacity:.7;margin-bottom:4px}
.usnormrow{display:flex;flex-wrap:wrap;gap:6px;align-items:center;font-size:.75rem;padding:5px 0;border-bottom:1px solid var(--bd,#e6e9ee)}
.usnormrow b{min-width:90px}
.ustbl{width:100%;border-collapse:collapse;font-size:.72rem}
.ustbl th,.ustbl td{border:1px solid var(--bd,#d9dde3);padding:3px 5px;text-align:right}
.ustbl th:first-child,.ustbl td:first-child{text-align:left}
.usflag{font-size:.76rem;color:#c0392b;margin-top:6px}
"""

MODULE = r"""
<script>
/* =============== v16/4: ULTRAHANG-MODUL ====================================
   Vizitsoros magzati biometria (dátum + terhességi hét), páros szervek,
   paraméterenkénti SVG-diagram, és publikációból betölthető normogramok.
   FONTOS: beépített normogram szándékosan NINCS. Referenciaadatot csak a
   felhasználó tölthet be, a forrás megadásával — kitalált percentilis egy
   klinikai eszközben veszélyes volna.
   ========================================================================= */
(function(){
  "use strict";
  var S = window.__usState = {visits:[], norms:{}};
  var seq = 0;

  /* --- paraméterek: egyszeres --- */
  var P1 = [
    {g:"Biometria"},
    {id:"crl", l:"CRL",  u:"mm"},
    {id:"bpd", l:"BPD",  u:"mm"},
    {id:"hc",  l:"HC",   u:"mm"},
    {id:"ac",  l:"AC",   u:"mm"},
    {id:"fl",  l:"FL",   u:"mm"},
    {id:"hl",  l:"HL",   u:"mm"},
    {id:"efw", l:"Becsült súly (EFW)", u:"g"},
    {id:"nt",  l:"NT",   u:"mm"},
    {g:"Magzatvíz és szív"},
    {id:"afi", l:"AFI",  u:"mm"},
    {id:"sdp", l:"Legmélyebb tasak", u:"mm"},
    {id:"fhr", l:"Magzati szívfrekvencia", u:"/perc"},
    {g:"Doppler"},
    {id:"ua",  l:"A. umbilicalis PI", u:""},
    {id:"mca", l:"A. cerebri media PI", u:""},
    {id:"cpr", l:"Cerebroplacentaris arány (CPR)", u:""},
    {id:"dv",  l:"Ductus venosus PI", u:""}
  ];
  /* --- páros szervek / testrészek: jobb + bal --- */
  var P2 = [
    {id:"ut",   l:"A. uterina PI"},
    {id:"kid",  l:"Vese hossz", u:"mm"},
    {id:"vent", l:"Oldalkamra átmérő", u:"mm"},
    {id:"fem",  l:"Femur hossz", u:"mm"},
    {id:"hum",  l:"Humerus hossz", u:"mm"},
    {id:"orb",  l:"Orbita átmérő", u:"mm"}
  ];
  var ALL1 = P1.filter(function(x){return x.id;});

  function eln(t,c,h){var e=document.createElement(t); if(c)e.className=c; if(h!=null)e.innerHTML=h; return e;}
  function gen(){ if(typeof window.generate==="function"){ try{window.generate();}catch(e){} } }
  function num(v){ v=parseFloat(String(v).replace(",",".")); return isFinite(v)?v:null; }
  function gaDec(v){ // "27+2" vagy 27.2 -> tizedes hét
    if(v==null) return null;
    var s=String(v).trim();
    var m=s.match(/^(\d{1,2})\s*[+\/]\s*(\d)$/);
    if(m) return parseInt(m[1],10)+parseInt(m[2],10)/7;
    return num(s);
  }
  function gaShow(g){ if(g==null)return "—"; var w=Math.floor(g), d=Math.round((g-w)*7); return w+"+"+d; }

  /* ---------- normogram tárolás ----------
     norms[paramId] = {src:"szerző, folyóirat, év", mode:"table"|"formula",
                       rows:[{ga,p3,p10,p50,p90,p97}], mu:"expr", sd:"expr"} */
  var LSK="anam_us_norms";
  function loadNorms(){ try{ S.norms=JSON.parse(localStorage.getItem(LSK)||"{}"); }catch(e){ S.norms={}; } }
  function saveNorms(){ try{ localStorage.setItem(LSK, JSON.stringify(S.norms)); }catch(e){} }

  /* biztonsagos keplet-kiertekeles: csak szamok, operatorok, GA, Math.* */
  function safeExpr(expr){
    if(!/^[-+*/(). 0-9GAMathelogxpsqrtinc,^]*$/i.test(expr)) return null;
    if(/[a-z]{2,}/i.test(expr.replace(/GA|Math|log|exp|sqrt|pow|abs|sin|cos/gi,""))) return null;
    try{ var f=new Function("GA","with(Math){return ("+expr.replace(/\^/g,"**")+");}"); f(20); return f; }
    catch(e){ return null; }
  }

  function interp(rows,ga,key){
    if(!rows||!rows.length) return null;
    var a=rows.filter(function(r){return r[key]!=null;}).sort(function(x,y){return x.ga-y.ga;});
    if(!a.length) return null;
    if(ga<=a[0].ga) return a[0][key];
    if(ga>=a[a.length-1].ga) return a[a.length-1][key];
    for(var i=1;i<a.length;i++){
      if(ga<=a[i].ga){
        var t=(ga-a[i-1].ga)/(a[i].ga-a[i-1].ga);
        return a[i-1][key]+t*(a[i][key]-a[i-1][key]);
      }
    }
    return null;
  }
  var ZOF={p3:-1.881,p10:-1.282,p50:0,p90:1.282,p97:1.881};
  function normPct(cdf){ return cdf; }
  function zToPct(z){ // standard normal CDF, Abramowitz-Stegun
    var t=1/(1+0.2316419*Math.abs(z));
    var d=0.3989423*Math.exp(-z*z/2);
    var p=d*t*(0.3193815+t*(-0.3565638+t*(1.781478+t*(-1.821256+t*1.330274))));
    return (z>0?1-p:p)*100;
  }
  /** merteket -> percentilis a betoltott normogram alapjan */
  function pctOf(pid, ga, val){
    var n=S.norms[pid]; if(!n||ga==null||val==null) return null;
    if(n.mode==="formula"){
      var fm=safeExpr(n.mu||""), fs=safeExpr(n.sd||"");
      if(!fm||!fs) return null;
      var mu=fm(ga), sd=fs(ga);
      if(!isFinite(mu)||!isFinite(sd)||sd<=0) return null;
      var z=(val-mu)/sd;
      return {pct:zToPct(z), z:z, src:n.src};
    }
    var keys=["p3","p10","p50","p90","p97"], pts=[];
    keys.forEach(function(k){ var v=interp(n.rows,ga,k); if(v!=null) pts.push({z:ZOF[k], v:v}); });
    if(pts.length<2) return null;
    pts.sort(function(a,b){return a.v-b.v;});
    var z;
    if(val<=pts[0].v) z=pts[0].z-(pts[0].v-val)/Math.max(1e-9,(pts[1].v-pts[0].v))*(pts[1].z-pts[0].z);
    else if(val>=pts[pts.length-1].v){var L=pts.length-1; z=pts[L].z+(val-pts[L].v)/Math.max(1e-9,(pts[L].v-pts[L-1].v))*(pts[L].z-pts[L-1].z);}
    else { for(var i=1;i<pts.length;i++){ if(val<=pts[i].v){ var tt=(val-pts[i-1].v)/Math.max(1e-9,(pts[i].v-pts[i-1].v)); z=pts[i-1].z+tt*(pts[i].z-pts[i-1].z); break; } } }
    return {pct:zToPct(z), z:z, src:n.src};
  }

  /* ---------------- vizit sora ---------------- */
  function visitRow(v, host){
    var row=eln("div","usvisit");
    var head=eln("div","usvhead");
    var ttl=eln("b",null,"");
    var del=eln("button",null,"✕ Törlés"); del.type="button";
    del.style.cssText="border:0;background:transparent;color:inherit;cursor:pointer;opacity:.7";
    del.onclick=function(){ S.visits=S.visits.filter(function(x){return x!==v;}); host.removeChild(row); redrawAll(); gen(); };
    head.append(ttl,del); row.append(head);

    var top=eln("div","usgrid");
    var lD=eln("label",null,"<span>Dátum</span>"); var iD=document.createElement("input");
    iD.type="date"; if(v.date)iD.value=v.date; lD.appendChild(iD); top.appendChild(lD);
    var lG=eln("label",null,"<span>Terhességi hét (pl. 27+2)</span>"); var iG=document.createElement("input");
    iG.placeholder="27+2"; if(v.gaRaw)iG.value=v.gaRaw; lG.appendChild(iG); top.appendChild(lG);
    row.appendChild(top);

    var grid=eln("div","usgrid");
    var inputs={};
    P1.forEach(function(p){
      if(p.g){ grid.appendChild(eln("div","usgh",p.g)); return; }
      var lab=eln("label",null,"<span>"+p.l+(p.u?(" ("+p.u+")"):"")+"</span>");
      var inp=document.createElement("input"); inp.type="text"; inp.inputMode="decimal";
      if(v.p[p.id]!=null) inp.value=v.p[p.id];
      var pc=eln("div","uspct","");
      lab.appendChild(inp); lab.appendChild(pc);
      grid.appendChild(lab); inputs[p.id]={i:inp,pc:pc};
    });
    grid.appendChild(eln("div","usgh","Páros szervek / testrészek — jobb és bal"));
    P2.forEach(function(p){
      ["j","b"].forEach(function(side){
        var key=p.id+"_"+side;
        var lab=eln("label",null,"<span>"+p.l+" "+(side==="j"?"jobb":"bal")+(p.u?(" ("+p.u+")"):"")+"</span>");
        var inp=document.createElement("input"); inp.type="text"; inp.inputMode="decimal";
        if(v.p[key]!=null) inp.value=v.p[key];
        var pc=eln("div","uspct","");
        lab.appendChild(inp); lab.appendChild(pc);
        grid.appendChild(lab); inputs[key]={i:inp,pc:pc};
      });
    });
    row.appendChild(grid);
    var flags=eln("div","usflag",""); row.appendChild(flags);

    function refresh(){
      v.date=iD.value; v.gaRaw=iG.value; v.ga=gaDec(iG.value);
      ttl.textContent = (v.date||"dátum nélkül")+"  ·  "+gaShow(v.ga)+" hét";
      var bad=[];
      Object.keys(inputs).forEach(function(k){
        var o=inputs[k]; var val=num(o.i.value);
        v.p[k] = (o.i.value==="")?null:val;
        o.i.classList.remove("p10","p90"); o.pc.className="uspct"; o.pc.textContent="";
        var base=k.replace(/_(j|b)$/,"");
        var r=pctOf(base, v.ga, val);
        if(r&&isFinite(r.pct)){
          o.pc.textContent="P"+r.pct.toFixed(1)+" (z="+r.z.toFixed(2)+")";
          if(r.pct<3){o.i.classList.add("p10");o.pc.classList.add("bad");bad.push(labelOf(k)+": P"+r.pct.toFixed(1));}
          else if(r.pct<10){o.i.classList.add("p10");o.pc.classList.add("bad");bad.push(labelOf(k)+": P"+r.pct.toFixed(1));}
          else if(r.pct>90){o.i.classList.add("p90");o.pc.classList.add("warnp");bad.push(labelOf(k)+": P"+r.pct.toFixed(1));}
        }
      });
      if(bad.length) flags.textContent="▲ Referenciatartományon kívül: "+bad.join(" · ");
    }
    [iD,iG].forEach(function(x){x.oninput=function(){refresh();redrawAll();gen();};});
    Object.keys(inputs).forEach(function(k){ inputs[k].i.oninput=function(){refresh();redrawAll();gen();}; });
    refresh();
    return row;
  }

  function labelOf(k){
    var s=k.replace(/_(j|b)$/,""), side=/_j$/.test(k)?" jobb":(/_b$/.test(k)?" bal":"");
    var a=ALL1.filter(function(p){return p.id===s;})[0]; if(a) return a.l+side;
    var b=P2.filter(function(p){return p.id===s;})[0]; if(b) return b.l+side;
    return k;
  }

  /* ---------------- SVG diagram ---------------- */
  function chart(pid, title, series){
    // series: [{name, pts:[{x,y}], color}]
    var W=560,H=200,ml=44,mr=12,mt=10,mb=26;
    var n=S.norms[pid];
    var xs=[], ys=[];
    series.forEach(function(s){ s.pts.forEach(function(p){ xs.push(p.x); ys.push(p.y); }); });
    var bands=[];
    if(n){
      var lo=Math.min.apply(null,xs.concat([40])), hi=Math.max.apply(null,xs.concat([0]));
      lo=Math.max(5,Math.floor(Math.min.apply(null,xs)-2)); hi=Math.ceil(Math.max.apply(null,xs)+2);
      ["p3","p10","p50","p90","p97"].forEach(function(k){
        var pts=[];
        for(var g=lo;g<=hi;g+=0.5){
          var val;
          if(n.mode==="formula"){ var fm=safeExpr(n.mu||""),fs=safeExpr(n.sd||""); if(!fm||!fs)break; val=fm(g)+ZOF[k]*fs(g); }
          else val=interp(n.rows,g,k);
          if(val!=null&&isFinite(val)){pts.push({x:g,y:val}); ys.push(val);}
        }
        if(pts.length) bands.push({k:k,pts:pts});
      });
    }
    if(!xs.length||!ys.length) return null;
    var x0=Math.min.apply(null,xs)-1, x1=Math.max.apply(null,xs)+1;
    if(bands.length){ x0=Math.min(x0, bands[0].pts[0].x); x1=Math.max(x1, bands[0].pts[bands[0].pts.length-1].x); }
    var y0=Math.min.apply(null,ys), y1=Math.max.apply(null,ys);
    if(y0===y1){y0-=1;y1+=1;}
    var py=(y1-y0)*0.08; y0-=py; y1+=py;
    var X=function(v){return ml+(v-x0)/(x1-x0)*(W-ml-mr);};
    var Y=function(v){return mt+(1-(v-y0)/(y1-y0))*(H-mt-mb);};
    var s=['<svg viewBox="0 0 '+W+' '+H+'" width="100%" height="'+H+'" role="img">'];
    s.push('<rect x="'+ml+'" y="'+mt+'" width="'+(W-ml-mr)+'" height="'+(H-mt-mb)+'" fill="none" stroke="currentColor" stroke-opacity=".22"/>');
    for(var i=0;i<=4;i++){
      var yv=y0+(y1-y0)*i/4, yy=Y(yv);
      s.push('<line x1="'+ml+'" y1="'+yy+'" x2="'+(W-mr)+'" y2="'+yy+'" stroke="currentColor" stroke-opacity=".10"/>');
      s.push('<text x="'+(ml-5)+'" y="'+(yy+3)+'" font-size="9" text-anchor="end" fill="currentColor" opacity=".65">'+(Math.round(yv*10)/10)+'</text>');
    }
    var step=Math.max(1,Math.round((x1-x0)/8));
    for(var g=Math.ceil(x0);g<=x1;g+=step){
      s.push('<line x1="'+X(g)+'" y1="'+mt+'" x2="'+X(g)+'" y2="'+(H-mb)+'" stroke="currentColor" stroke-opacity=".08"/>');
      s.push('<text x="'+X(g)+'" y="'+(H-mb+13)+'" font-size="9" text-anchor="middle" fill="currentColor" opacity=".65">'+g+'</text>');
    }
    s.push('<text x="'+(W/2)+'" y="'+(H-3)+'" font-size="9" text-anchor="middle" fill="currentColor" opacity=".6">terhességi hét</text>');
    var bandCol={p3:".55",p10:".4",p50:".75",p90:".4",p97:".55"};
    bands.forEach(function(b){
      var d=b.pts.map(function(p,i){return (i?"L":"M")+X(p.x)+" "+Y(p.y);}).join(" ");
      s.push('<path d="'+d+'" fill="none" stroke="currentColor" stroke-opacity="'+bandCol[b.k]+'" stroke-width="'+(b.k==="p50"?1.4:1)+'" stroke-dasharray="'+(b.k==="p50"?"":"4 3")+'"/>');
      var last=b.pts[b.pts.length-1];
      s.push('<text x="'+(X(last.x)-2)+'" y="'+(Y(last.y)-3)+'" font-size="8" text-anchor="end" fill="currentColor" opacity=".6">'+b.k.toUpperCase()+'</text>');
    });
    var cols=["#2d6cdf","#c0392b"];
    series.forEach(function(se,si){
      var col=se.color||cols[si%cols.length];
      var pp=se.pts.slice().sort(function(a,b){return a.x-b.x;});
      if(pp.length>1){
        var d=pp.map(function(p,i){return (i?"L":"M")+X(p.x)+" "+Y(p.y);}).join(" ");
        s.push('<path d="'+d+'" fill="none" stroke="'+col+'" stroke-width="1.8"/>');
      }
      pp.forEach(function(p){ s.push('<circle cx="'+X(p.x)+'" cy="'+Y(p.y)+'" r="3.2" fill="'+col+'"/>'); });
      if(series.length>1){
        s.push('<text x="'+(ml+6+si*70)+'" y="'+(mt+12)+'" font-size="9" fill="'+col+'">● '+se.name+'</text>');
      }
    });
    s.push('</svg>');
    var box=eln("div","uschart");
    box.appendChild(eln("h6",null,title));
    if(n) box.appendChild(eln("div","src","Normogram: "+(n.src||"forrás nincs megadva")));
    else box.appendChild(eln("div","src","Nincs betöltött normogram — csak a mért értékek láthatók."));
    box.insertAdjacentHTML("beforeend", s.join(""));
    return box;
  }

  function redrawAll(){
    var host=document.querySelector("#usCharts"); if(!host) return;
    host.innerHTML="";
    var vs=S.visits.filter(function(v){return v.ga!=null;});
    if(!vs.length){ host.appendChild(eln("div","src","Adj hozzá legalább egy vizitet terhességi héttel.")); return; }
    ALL1.forEach(function(p){
      var pts=vs.filter(function(v){return v.p[p.id]!=null;}).map(function(v){return {x:v.ga,y:v.p[p.id]};});
      if(pts.length){ var c=chart(p.id, p.l+(p.u?(" ["+p.u+"]"):""), [{name:p.l,pts:pts}]); if(c)host.appendChild(c); }
    });
    P2.forEach(function(p){
      var j=vs.filter(function(v){return v.p[p.id+"_j"]!=null;}).map(function(v){return {x:v.ga,y:v.p[p.id+"_j"]};});
      var b=vs.filter(function(v){return v.p[p.id+"_b"]!=null;}).map(function(v){return {x:v.ga,y:v.p[p.id+"_b"]};});
      if(j.length||b.length){
        var ser=[]; if(j.length)ser.push({name:"jobb",pts:j,color:"#2d6cdf"}); if(b.length)ser.push({name:"bal",pts:b,color:"#c0392b"});
        var c=chart(p.id, p.l+" — jobb és bal"+(p.u?(" ["+p.u+"]"):""), ser); if(c)host.appendChild(c);
      }
    });
  }

  /* ---------------- normogram-kezelő ---------------- */
  function normUI(host){
    host.innerHTML="";
    host.appendChild(eln("div","src",
      "Beépített normogram szándékosan nincs: referenciaadatot csak publikációból, forrásmegadással tölts be. "+
      "Táblázat formátum soronként: <code>hét;P3;P10;P50;P90;P97</code> (a P3/P97 elhagyható). "+
      "Képlet formátum: átlag és szórás GA (hét) függvényében, pl. <code>-28.28+1.29*GA</code>."));
    var all=ALL1.concat(P2);
    all.forEach(function(p){
      var n=S.norms[p.id];
      var r=eln("div","usnormrow");
      r.appendChild(eln("b",null,p.l));
      r.appendChild(eln("span",null, n? ("✔ "+(n.mode==="formula"?"képlet":"táblázat")+" — "+(n.src||"forrás nincs")) : "nincs betöltve"));
      var bAdd=eln("button",null,n?"Csere":"Betöltés"); bAdd.type="button";
      bAdd.style.cssText="border:1px solid var(--bd,#9aa3ad);background:transparent;color:inherit;border-radius:6px;padding:2px 9px;cursor:pointer;font:inherit;font-size:.72rem";
      bAdd.onclick=function(){ openLoader(p, host); };
      r.appendChild(bAdd);
      if(n){
        var bDel=eln("button",null,"Törlés"); bDel.type="button";
        bDel.style.cssText=bAdd.style.cssText;
        bDel.onclick=function(){ delete S.norms[p.id]; saveNorms(); normUI(host); redrawAll(); gen(); };
        r.appendChild(bDel);
      }
      host.appendChild(r);
    });
  }

  function openLoader(p, host){
    var box=eln("div","usvisit");
    box.innerHTML='<div class="usvhead"><b>Normogram betöltése — '+p.l+'</b></div>';
    var g=eln("div","usgrid");
    var lS=eln("label",null,"<span>Forrás (szerző, folyóirat, év) — kötelező</span>");
    var iS=document.createElement("input"); iS.placeholder="pl. Hadlock FP, et al. Radiology. 1991;181:129-33."; lS.appendChild(iS);
    var lM=eln("label",null,"<span>Mód</span>"); var sM=document.createElement("select");
    ["táblázat","képlet"].forEach(function(o){var op=document.createElement("option");op.value=(o==="képlet"?"formula":"table");op.textContent=o;sM.appendChild(op);});
    lM.appendChild(sM);
    g.append(lS,lM); box.appendChild(g);

    var ta=document.createElement("textarea");
    ta.rows=7; ta.style.cssText="width:100%;margin-top:8px;padding:6px;border-radius:6px;border:1px solid var(--bd,#d9dde3);background:transparent;color:inherit;font:inherit;font-size:.75rem";
    ta.placeholder="20;250;270;300;335;360\n21;270;292;325;362;389\n…";
    box.appendChild(ta);

    var fg=eln("div","usgrid"); fg.style.display="none";
    var lMu=eln("label",null,"<span>Átlag μ(GA)</span>"); var iMu=document.createElement("input"); iMu.placeholder="-28.28+1.29*GA"; lMu.appendChild(iMu);
    var lSd=eln("label",null,"<span>Szórás σ(GA)</span>"); var iSd=document.createElement("input"); iSd.placeholder="0.08*GA"; lSd.appendChild(iSd);
    fg.append(lMu,lSd); box.appendChild(fg);
    sM.onchange=function(){ var f=sM.value==="formula"; fg.style.display=f?"":"none"; ta.style.display=f?"none":""; };

    var msg=eln("div","usflag","");
    box.appendChild(msg);
    var bar=eln("div","usbtns");
    var ok=eln("button","pri","Mentés"); ok.type="button";
    var no=eln("button",null,"Mégse"); no.type="button";
    bar.append(ok,no); box.appendChild(bar);
    no.onclick=function(){ normUI(host); };
    ok.onclick=function(){
      if(!iS.value.trim()){ msg.textContent="A forrás megadása kötelező."; return; }
      if(sM.value==="formula"){
        if(!safeExpr(iMu.value)||!safeExpr(iSd.value)){ msg.textContent="A képlet nem értelmezhető (csak számok, + - * / ( ), GA és Math-függvények)."; return; }
        S.norms[p.id]={src:iS.value.trim(),mode:"formula",mu:iMu.value.trim(),sd:iSd.value.trim()};
      } else {
        var rows=[];
        ta.value.split(/\n/).forEach(function(line){
          var c=line.split(/[;,\t]/).map(function(x){return x.trim();});
          if(c.length<2) return;
          var ga=parseFloat(c[0].replace(",",".")); if(!isFinite(ga)) return;
          var o={ga:ga};
          var keys=(c.length>=6)?["p3","p10","p50","p90","p97"]:["p10","p50","p90"];
          keys.forEach(function(k,i){ var v=parseFloat((c[i+1]||"").replace(",",".")); if(isFinite(v))o[k]=v; });
          rows.push(o);
        });
        if(rows.length<2){ msg.textContent="Legalább két értelmezhető sor kell."; return; }
        S.norms[p.id]={src:iS.value.trim(),mode:"table",rows:rows};
      }
      saveNorms(); normUI(host); redrawAll(); gen();
    };
    host.innerHTML=""; host.appendChild(box);
  }

  /* ---------------- szöveges kimenet ---------------- */
  function usText(){
    var vs=S.visits.filter(function(v){return v.ga!=null||v.date;});
    if(!vs.length) return "";
    var L=["","ULTRAHANG — MAGZATI BIOMETRIA ÉS DOPPLER (vizitenként):"];
    var risk=[];
    vs.sort(function(a,b){return (a.ga||0)-(b.ga||0);}).forEach(function(v){
      var parts=[];
      ALL1.forEach(function(p){ if(v.p[p.id]!=null) parts.push(p.l+" "+v.p[p.id]+(p.u?(" "+p.u):"")); });
      P2.forEach(function(p){
        var j=v.p[p.id+"_j"], b=v.p[p.id+"_b"];
        if(j!=null||b!=null) parts.push(p.l+" j/b: "+(j==null?"—":j)+" / "+(b==null?"—":b)+(p.u?(" "+p.u):""));
      });
      L.push("  • "+(v.date||"dátum nélkül")+", "+gaShow(v.ga)+" hét — "+(parts.length?parts.join("; "):"nincs rögzített érték")+".");
      Object.keys(v.p).forEach(function(k){
        var r=pctOf(k.replace(/_(j|b)$/,""), v.ga, v.p[k]);
        if(r&&isFinite(r.pct)&&(r.pct<10||r.pct>90))
          risk.push(gaShow(v.ga)+" hét — "+labelOf(k)+": P"+r.pct.toFixed(1)+" (z="+r.z.toFixed(2)+")");
      });
    });
    var used={}; ALL1.concat(P2).forEach(function(p){ if(S.norms[p.id]) used[p.l]=S.norms[p.id].src||"forrás nincs megadva"; });
    if(Object.keys(used).length){
      L.push("  Használt normogramok:");
      Object.keys(used).forEach(function(k){ L.push("   – "+k+": "+used[k]); });
    }
    if(risk.length){
      L.push("");
      L.push("NÖVEKEDÉS- ÉS KOCKÁZATKONTROLL — referenciatartományon kívüli értékek:");
      risk.forEach(function(r){ L.push("  ▲ "+r); });
      L.push("  A percentilis a betöltött normogramból számolt; a klinikai értékelés a kezelőorvosé. "+
             "A P10 alatti becsült súly növekedési restrikció, a P90 feletti macrosomia irányában igényel további vizsgálatot.");
    }
    return L.join("\n");
  }

  function enrichUS(){
    var out=document.querySelector("#anamOut"); if(!out) return;
    var prev=out.querySelector("#usBlock"); if(prev) prev.parentNode.removeChild(prev);
    var txt=usText(); if(!txt) return;
    var sp=document.createElement("span"); sp.id="usBlock"; sp.textContent=txt+"\n";
    out.appendChild(sp);
  }

  /* ---------------- beépítés ---------------- */
  function mount(){
    var lab=document.querySelector("#labHost"); if(!lab) return false;
    var det=lab.closest("details"); if(!det||document.querySelector("#usWrap")) return true;
    var sec=document.createElement("details"); sec.className="sec";
    sec.innerHTML='<summary><span class="num">10b</span> Ultrahang — magzati biometria, páros szervek, normogramok <span class="chev">›</span></summary>'+
      '<div class="body">'+
      '<p class="hint" style="margin:0 0 10px">Vizitenként (dátum + terhességi hét) rögzített mérések. '+
      'A diagramok paraméterenként, a páros szervek jobb/bal görbével egy ábrán jelennek meg. '+
      'A percentilis csak akkor számolódik, ha a paraméterhez normogramot töltöttél be.</p>'+
      '<div class="usbtns"><button type="button" class="pri" data-a="add">+ Új vizit</button>'+
      '<button type="button" data-a="calc">Beemelés a kalkulátor mezőiből</button>'+
      '<button type="button" data-a="norm">Normogramok kezelése</button></div>'+
      '<div id="usWrap"></div>'+
      '<div id="usNorm" style="margin-top:12px;display:none"></div>'+
      '<h5 style="margin:14px 0 6px;font-size:.85rem">Görbék</h5><div id="usCharts"></div>'+
      '</div>';
    det.parentNode.insertBefore(sec, det.nextSibling);
    var host=sec.querySelector("#usWrap"), nh=sec.querySelector("#usNorm");

    function addVisit(pre){
      var v={id:++seq,date:(new Date()).toISOString().slice(0,10),gaRaw:"",ga:null,p:{}};
      if(pre) Object.keys(pre).forEach(function(k){v.p[k]=pre[k];});
      S.visits.push(v); host.appendChild(visitRow(v,host)); redrawAll(); gen();
    }
    sec.querySelectorAll(".usbtns button").forEach(function(b){
      b.onclick=function(){
        var a=b.getAttribute("data-a");
        if(a==="add") addVisit(null);
        else if(a==="norm"){ var vis=nh.style.display==="none"; nh.style.display=vis?"":"none"; if(vis)normUI(nh); }
        else if(a==="calc"){
          var map={k_crl:"crl",k_bpd:"bpd",k_hc:"hc",k_ac:"ac",k_fl:"fl",k_afi:"afi",k_ua:"ua",k_mca:"mca"};
          var pre={}, any=false;
          Object.keys(map).forEach(function(id){
            var e=document.getElementById(id);
            if(e&&e.value!==""){ var val=num(e.value); if(val!=null){ pre[map[id]]= (["bpd","hc","ac","fl"].indexOf(map[id])>=0? val*10 : val); any=true; } }
          });
          if(!any){ alert("A kalkulátor magzati mezői üresek."); return; }
          var ga=document.getElementById("ga");
          addVisit(pre);
          var last=S.visits[S.visits.length-1];
          if(ga&&ga.value){ last.gaRaw=ga.value; last.ga=gaDec(ga.value); }
          host.removeChild(host.lastChild); host.appendChild(visitRow(last,host)); redrawAll(); gen();
        }
      };
    });
    return true;
  }

  function init(){
    loadNorms();
    if(!mount()){ setTimeout(init,300); return; }
    if(typeof window.generate==="function"){
      var og=window.generate;
      window.generate=function(){ var r=og.apply(this,arguments); try{enrichUS();}catch(e){window.__usErr=(e&&e.message)||String(e);} return r; };
    }
    window.__us={text:usText,P1:P1,P2:P2,addNorm:function(pid,o){S.norms[pid]=o;saveNorms();redrawAll();}};
  }
  if(document.readyState==="loading") document.addEventListener("DOMContentLoaded",init);
  else init();
})();
</script>
"""

assert "/* --- v16 --- */" in t
t = t.replace("/* --- v16 --- */", CSS, 1)
t = t.rstrip() + "\n" + MODULE + "\n"
io.open(F, "w", encoding="utf-8").write(t)
print("meret: %d -> %d B (+%d)" % (n0, len(t), len(t) - n0))
print("  OK ultrahang-modul + CSS")

```

### `build_v16_part5.py`

109 sor, 5 KB.

```python
# -*- coding: utf-8 -*-
"""v16/5: reprodukcios-szuleszeti anamnezis kiegeszitese - vetelesek,
muvi terhessegmegszakitas, extrauterin, mola, meh-uri beavatkozas + GPA szamlalok."""
import io, os, json

D = r"C:\Users\szili\Documents\claude\apps\anamnezis-asszisztens"
F = os.path.join(D, "Anamnezis_asszisztens_v16_tobbnyelvu.html")
t = io.open(F, encoding="utf-8").read()
n0 = len(t)
applied = []


def patch(old, new, tag):
    global t
    assert old in t, "NEM TALALOM: " + tag
    t = t.replace(old, new, 1)
    applied.append(tag)


# ------------------------------------------------- 1. uj REPRO tetelek
NEW = [
 ("r_absp",  "Spontán vetélés (egy vagy több)", 0),
 ("r_abind", "Művi terhességmegszakítás (mű abortus)", 0),
 ("r_abmis", "Missed abortion / nem fejlődő terhesség", 0),
 ("r_ectop", "Méhen kívüli (extrauterin) terhesség", 1),
 ("r_mola",  "Molaterhesség", 1),
 ("r_cur",   "Méhűri beavatkozás terhesség után (curettage, hysteroscopia)", 0),
]
items = "\n".join(
    '  {id:%s,l:%s%s},' % (json.dumps(i, ensure_ascii=False), json.dumps(l, ensure_ascii=False),
                           ",rf:1" if rf else "")
    for i, l, rf in NEW)

patch(
    '  {id:"r_anom",l:"Korábbi terhességben veleszületett rendellenesség",rf:1},\n];',
    '  {id:"r_anom",l:"Korábbi terhességben veleszületett rendellenesség",rf:1},\n'
    '  /* --- v16: terhessegvesztes es meh-uri beavatkozasok --- */\n'
    + items + '\n];',
    "1: uj REPRO tetelek")

# ------------------------------------------- 2. GPA szamlalok a szekcioba
GPA_FIELDS = [
    ("gp_g", "Gravida (összes terhesség)"),
    ("gp_p", "Para (24. hét után szült)"),
    ("gp_absp", "Spontán vetélés (db)"),
    ("gp_abind", "Művi megszakítás (db)"),
    ("gp_ect", "Extrauterin (db)"),
    ("gp_liv", "Élő gyermek"),
]
gpa_html = "".join(
    '          <label><span>%s</span><input type="number" min="0" id="%s"></label>\n' % (lab, fid)
    for fid, lab in GPA_FIELDS)

patch(
    '      <div class="body"><div id="rosRepro"></div></div>',
    '      <div class="body">\n'
    '        <div class="usgrid" id="gpaHost" style="margin-bottom:12px">\n'
    '          <div class="usgh">Terhességi összegzés (GPA)</div>\n'
    + gpa_html +
    '        </div>\n'
    '        <div id="rosRepro"></div>\n'
    '      </div>',
    "2: GPA szamlalok")

# ------------------------------------------------- 3. teendok az uj tetelekhez
patch(
    '  if(st.r_anom&&st.r_anom.v==="pos") add("gen","Korábbi congenitalis rendellenesség: genetikai tanácsadás, célzott magzati diagnosztika terve.","korábbi malformáció","warn");',
    '  if(st.r_anom&&st.r_anom.v==="pos") add("gen","Korábbi congenitalis rendellenesség: genetikai tanácsadás, célzott magzati diagnosztika terve.","korábbi malformáció","warn");\n'
    '  if(st.r_ectop&&st.r_ectop.v==="pos"){\n'
    '    add("lab","Korai (5–6. hét) ultrahang a terhesség méhen belüli elhelyezkedésének igazolására; szérum-hCG követés, amíg a lokalizáció nem egyértelmű.","korábbi extrauterin terhesség","crit");\n'
    '    add("ref","Ismételt extrauterin terhesség fokozott kockázata — korai szülészeti kontroll.","korábbi extrauterin terhesség","warn");\n'
    '  }\n'
    '  if(st.r_mola&&st.r_mola.v==="pos"){\n'
    '    add("lab","Molaterhesség után: hCG-követés a negatívvá válásig, majd a protokoll szerinti utánkövetés; korai ultrahang az aktuális terhességben.","korábbi molaterhesség","crit");\n'
    '    add("gen","Ismétlődő mola esetén genetikai (NLRP7/KHDC3L) tanácsadás mérlegelése.","korábbi molaterhesség","info");\n'
    '  }\n'
    '  if((st.r_cur&&st.r_cur.v==="pos")||(st.r_abind&&st.r_abind.v==="pos")||(st.r_abmis&&st.r_abmis.v==="pos")){\n'
    '    add("lab","Korábbi méhűri beavatkozás: a placenta tapadási helyének célzott vizsgálata (placenta praevia és accreta spektrum), valamint az endometrium értékelése (Asherman-szindróma lehetősége).","korábbi méhűri beavatkozás","warn");\n'
    '  }\n'
    '  if(st.r_absp&&st.r_absp.v==="pos"){\n'
    '    add("lab","Vetélés az anamnézisben: Rh-vércsoport és ellenanyagszűrés ellenőrzése; RhD-negatív anyánál az anti-D profilaxis dokumentálása.","korábbi vetélés","info");\n'
    '  }',
    "3: teendok")

# ------------------------------------------- 4. GPA az osszefoglaloba
patch(
    '  let rl="REPRODUKCIÓS / SZÜLÉSZETI ANAMNÉZIS: ";',
    '  try{\n'
    '    const gv=id=>{const e=document.getElementById(id); const n=e?parseInt(e.value,10):NaN; return isFinite(n)?n:null;};\n'
    '    const gg=gv("gp_g"),pp=gv("gp_p"),as_=gv("gp_absp"),ai=gv("gp_abind"),ec=gv("gp_ect"),li=gv("gp_liv");\n'
    '    if([gg,pp,as_,ai,ec,li].some(x=>x!=null)){\n'
    '      const bits=[];\n'
    '      if(gg!=null)bits.push("gravida "+gg);\n'
    '      if(pp!=null)bits.push("para "+pp);\n'
    '      if(as_!=null)bits.push("spontán vetélés "+as_);\n'
    '      if(ai!=null)bits.push("művi megszakítás "+ai);\n'
    '      if(ec!=null)bits.push("extrauterin "+ec);\n'
    '      if(li!=null)bits.push("élő gyermek "+li);\n'
    '      A.push("TERHESSÉGI ÖSSZEGZÉS: "+bits.join(", ")+".");\n'
    '    }\n'
    '  }catch(e){}\n'
    '  let rl="REPRODUKCIÓS / SZÜLÉSZETI ANAMNÉZIS: ";',
    "4: GPA az osszefoglaloba")

io.open(F, "w", encoding="utf-8").write(t)
print("meret: %d -> %d B (+%d)" % (n0, len(t), len(t) - n0))
for a in applied:
    print("  OK", a)

```

### `build_v16_part6.py`

427 sor, 22 KB.

```python
# -*- coding: utf-8 -*-
"""v16/6: EKG-modul az ekg.xlsx logikaja alapjan (296 keplet portolva)."""
import io, os

D = r"C:\Users\szili\Documents\claude\apps\anamnezis-asszisztens"
F = os.path.join(D, "Anamnezis_asszisztens_v16_tobbnyelvu.html")
t = io.open(F, encoding="utf-8").read()
n0 = len(t)

CSS = """/* --- v16 --- */
#ekgWrap{display:flex;flex-direction:column;gap:12px}
.ekgset{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:8px}
.ekgset label{display:flex;flex-direction:column;font-size:.75rem;gap:3px}
.ekgset input,.ekgset select{padding:5px;border-radius:6px;border:1px solid var(--bd,#d9dde3);background:transparent;color:inherit;font:inherit}
.ekgtblwrap{overflow-x:auto;border:1px solid var(--bd,#d9dde3);border-radius:10px}
.ekgtbl{border-collapse:collapse;font-size:.72rem;min-width:900px}
.ekgtbl th,.ekgtbl td{border:1px solid var(--bd,#e2e6ec);padding:2px 4px;text-align:center}
.ekgtbl th{font-weight:600;opacity:.8;position:sticky;top:0;background:var(--bg,#fff)}
.ekgtbl td:first-child,.ekgtbl th:first-child{text-align:left;font-weight:600;position:sticky;left:0;background:var(--bg,#fff)}
.ekgtbl input{width:52px;padding:2px 3px;border:1px solid transparent;border-radius:4px;background:transparent;color:inherit;font:inherit;text-align:right}
.ekgtbl input:focus{border-color:#2d6cdf;outline:none}
.ekgtbl select{padding:1px;border:1px solid transparent;border-radius:4px;background:transparent;color:inherit;font:inherit;font-size:.7rem}
.ekgtbl td.abn input,.ekgtbl td.abn select{background:rgba(192,57,43,.10);border-color:#c0392b}
.ekgtbl td.susp input{background:rgba(138,109,59,.12);border-color:#8a6d3b}
.ekgout{border:1px solid var(--bd,#d9dde3);border-radius:10px;padding:10px;font-size:.78rem;line-height:1.55;white-space:pre-wrap}
.ekgout b{display:inline-block;min-width:78px}
.ekgcrit{color:#c0392b;font-weight:700}
.ekgnote{font-size:.72rem;opacity:.75;line-height:1.5;margin:0 0 8px}
.ekgblk{margin-top:8px;padding:8px 10px;border-left:3px solid #8a6d3b;background:rgba(138,109,59,.08);border-radius:0 8px 8px 0;font-size:.75rem}
"""

MODULE = r"""
<script>
/* ================== v16/6: EKG-MODUL =======================================
   Az ekg.xlsx munkafüzet logikájának portja. A számítási küszöbök és a
   szöveggenerálás a munkafüzet képleteit követik; ahol a munkafüzetben
   hiba volt (elcsúszott hivatkozás, összehasonlítás szöveggel), ott a
   HELYES számítás szerepel, és a modul ezt külön jelzi.
   ========================================================================= */
(function(){
  "use strict";
  var LEADS=["I.","II.","III.","aVL","aVR","aVF","V1","V2","V3","V4","V5","V6"];
  var E = window.__ekg = {set:{speed:25,sens:10,age:"",sex:"Nő",chest:"nem"}, lead:{}, g:{}};
  LEADS.forEach(function(L){ E.lead[L]={pPol:"",pDur:"",pAmp:"",qDur:"",qAmp:"",rAmp:"",rId:"",sPol:"",sAmp:"",tPol:"",tAmp:"",qrs:""}; });

  var MORPH=["","QR","qR","R","rS","RS","rsR'","QS","Rs","M-alak"];
  var POL=["","poz","neg","equiphasic"];

  function eln(t,c,h){var e=document.createElement(t); if(c)e.className=c; if(h!=null)e.innerHTML=h; return e;}
  function gen(){ if(typeof window.generate==="function"){ try{window.generate();}catch(e){} } }
  function n(v){ if(v===""||v==null) return null; var x=parseFloat(String(v).replace(",",".")); return isFinite(x)?x:null; }
  /* kiskocka -> mp  /  kiskocka -> mV  (a munkafüzet F3 és F4 cellái) */
  function sPerSq(){ return 1/(E.set.speed||25); }
  function mvPerSq(){ return 1/(E.set.sens||10); }
  function dur(v){ var x=n(v); return x==null?null:x*sPerSq(); }
  function amp(v){ var x=n(v); return x==null?null:x*mvPerSq(); }
  function f2(x){ return x==null?"—":(Math.round(x*1000)/1000); }

  /* ---------------- egyes lapok logikája ---------------- */

  /* Tengely lap: I, II, aVF polaritásból */
  function axis(){
    var a=(E.lead["I."].qrsPol||""), b=(E.lead["II."].qrsPol||""), c=(E.lead["aVF"].qrsPol||"");
    var P="poz",N="neg",Q="equiphasic";
    if(a===P&&b===P&&c===P) return "kp. tengely";
    if(a===P&&c===N&&b===Q) return "bal tengely (élettani variáns)";
    if(a===P&&b===N&&c===N) return "pathológiás bal tengely";
    if(a===N&&b===N&&c===N) return "extrém jobb tengely";
    if(a===N&&b===P&&c===P) return "jobb tengely";
    if(a===Q&&b===Q&&c===Q) return "nem meghatározott tengely";
    if(!a||!b||!c) return "tengely: hiányzó adat (I., II., aVF QRS-polaritás kell)";
    return "nem besorolható tengelyállás";
  }

  /* ritmus lap */
  function rhythm(){
    var g=E.g, out=[];
    var pII=E.lead["II."].pPol;
    var base=g.base||"";
    var sr=(pII==="poz"&&base==="SR/egyenes"&&g.pWave==="Jelen")?"SR":"arrhythmia? vagy hiányzó P-adat a II. elvezetésben";
    out.push(sr);
    var base2 = !base?"hiányzó adat":(base==="SR/egyenes"?"SR":(base==="hullámzó"?"pitvarfibrilláció?":(base==="sinusoid"?"flutter?":(base==="csak R vagy QRS P nélkül"?"kamrai ritmus":base))));
    if(base2!==sr) out.push(base2);
    var rr=n(g.rrBig), hr=null;
    if(rr) hr=300/rr*25/(E.set.speed||25);
    var hrTxt = hr==null?"":(hr<60?"bradycardia":(hr>90?"tachycardia":"normofrekvenciás"))+", "+Math.round(hr)+"/perc";
    var wide=qrsWidth();
    var qrsTxt = wide.w==null?"":(wide.wide?"széles QRS":"keskeny QRS");
    var axFix = !g.rFix?"":(g.rFix==="Fix"?"nem változó QRS":"változó R-amplitúdó?");
    var pace = !g.pace?"":(g.pace==="nincs"?"pacemakerre utaló eltérés nem látható":
               (g.pace==="P előtt"?"AAI vagy DDD pacemaker?":
               (g.pace==="QRS előtt"?"kamrai pacemaker (VDD, DDD)":"aszinkron pacemaker (hiba/mágnes?)")));
    var es = !g.es?"":(g.es==="nincs"?"ES / VES / SVES nincs":g.es);
    return {text:"Ritmus: "+out.join(", ")+(qrsTxt?", "+qrsTxt:"")+(hrTxt?", "+hrTxt:"")+
            (axFix?". "+axFix:"")+(es?". "+es:"")+(pace?". "+pace:"")+".", hr:hr};
  }

  /* P lap */
  function pWave(){
    var res=[], warn=[];
    var dII=dur(E.lead["II."].pDur), dV1=dur(E.lead["V1"].pDur), dI=dur(E.lead["I."].pDur);
    if(dII!=null) res.push(dII<0.119?"normál P-hullám a II.-ben ("+Math.round(dII*1000)+" ms)":"kóros P-hullám a II.-ben ("+Math.round(dII*1000)+" ms)");
    if(dV1!=null) res.push(dV1<0.119?"normál P a V1-ben":"kóros P a V1-ben");
    var aII=amp(E.lead["II."].pAmp), aIII=amp(E.lead["III."].pAmp), aVF=amp(E.lead["aVF"].pAmp);
    var morph="norm.";
    if(dI!=null&&dII!=null&&dI>0.08&&dII<0.08) morph="P-mitrale";
    else if(aII!=null&&aIII!=null&&aVF!=null&&aII>0.25&&aIII>0.25&&aVF>0.25) morph="P-pulmonale";
    if(morph!=="norm.") warn.push(morph);
    LEADS.forEach(function(L){
      var p=E.lead[L].pPol;
      if(p==="neg"&&(L==="I."||L==="II."||L==="aVF")) warn.push(L+"-ben negatív P (AV-junkcionális vagy kamrai ritmus?)");
      var a=amp(E.lead[L].pAmp);
      if(a!=null&&a>=0.251) warn.push(L+"-ben magas P ("+f2(a)+" mV)");
    });
    return {text:"P-hullám: "+(res.length?res.join("; ")+". ":"")+(warn.length?warn.join("; ")+".":(res.length?"":"nincs rögzített adat.")), morph:morph};
  }

  /* PR lap */
  function pr(){
    var d=dur(E.g.pr);
    if(d==null) return {text:"", d:null};
    var s = d<0.12?"rövid PR-szakasz":(d>0.22?"megnyúlt PR — I. fokú AV-blokk":"normál PR");
    var extra="";
    if(d<0.12) extra = (E.g.delta==="Igen")?" — WPW-szindróma gyanúja":" — preexcitációs szindróma lehetősége";
    return {text:"PR: "+Math.round(d*1000)+" ms — "+s+extra+".", d:d};
  }

  /* Q lap — kóros Q: >=0.04 s, vagy >0.03 s gyanús; amplitúdó >= az R 25%-a */
  function qWave(){
    var patho=[], susp=[];
    LEADS.forEach(function(L){
      var qd=dur(E.lead[L].qDur), qa=amp(E.lead[L].qAmp), ra=amp(E.lead[L].rAmp);
      var byDur = qd==null?null:(qd>=0.04?"p":(qd>0.03?"s":"n"));
      var byAmp = (qa==null||ra==null||ra<=0)?null:((0.25*ra<=qa)?"s":"n");
      var v;
      if(byDur==="p"&&byAmp==="s") v="p";
      else if(byDur==="p") v="p";
      else if(byDur==="s"&&byAmp==="s") v="p";
      else if(byDur==="s"||byAmp==="s") v="s";
      else v="n";
      if(v==="p") patho.push(L); else if(v==="s") susp.push(L);
    });
    var txt;
    if(!patho.length&&!susp.length) txt="Q-hullám: normál.";
    else {
      txt="Q-hullám: ";
      if(patho.length) txt+="kóros Q "+patho.join(", ")+" elvezetésben. ";
      if(susp.length) txt+="kóros Q gyanúja "+susp.join(", ")+" elvezetésben.";
    }
    return {text:txt.trim(), patho:patho, susp:susp};
  }

  /* R lap — amplitúdó-küszöbök és intrinsicoid deflexió */
  var RMAX={"I.":2,"aVL":1.2,"V1":5,"V5":2.6};
  function rWave(){
    var high=[], id=[];
    LEADS.forEach(function(L){
      var a=amp(E.lead[L].rAmp), lim=RMAX[L];
      if(a!=null&&lim!=null&&a>lim) high.push(L+" ("+f2(a)+" mV, határ "+lim+")");
    });
    var idV1=dur(E.lead["V1"].rId), idV5=dur(E.lead["V5"].rId);
    if(idV1!=null&&idV1>0.04) id.push("V1 ID "+Math.round(idV1*1000)+" ms — bal szárblokk vagy hypertrophia gyanúja");
    if(idV5!=null&&idV5>0.06) id.push("V5 ID "+Math.round(idV5*1000)+" ms — jobb szárblokk vagy hypertrophia gyanúja");
    var t="R-hullám: "+(high.length?("kórosan magas amplitúdó: "+high.join("; ")+". "):"az amplitúdók a határértéken belül. ")+
          (id.length?id.join("; ")+". ":"")+(E.g.mono==="igen"?"V5–V6-ban monomorf R.":"");
    return {text:t.trim(), high:high};
  }

  /* S lap */
  var SMAX={"I.":2,"V5":2.6};
  function sWave(){
    var parts=[], high=[];
    LEADS.forEach(function(L){
      var p=E.lead[L].sPol, a=amp(E.lead[L].sAmp);
      if(!p&&a==null) return;
      parts.push(L+"-ben "+(p||"?")+(a!=null?(" ("+f2(a)+" mV)"):""));
      var lim=SMAX[L];
      if(a!=null&&lim!=null&&a>lim) high.push(L);
    });
    return {text: parts.length?("S-hullám: "+parts.join(", ")+"."+(high.length?(" Kórosan mély: "+high.join(", ")+"."):"")):"", high:high};
  }

  /* QRS lap */
  function qrsWidth(){ var d=dur(E.g.qrs); return {w:d, wide:(d!=null&&d>=0.12)}; }
  function qrsWave(){
    var w=qrsWidth(), morf=[];
    LEADS.forEach(function(L){ var m=E.lead[L].qrs; if(m) morf.push(L+": "+m); });
    var bbbb="";
    var v14=["V1","V2","V3","V4"].map(function(L){return E.lead[L].qrs;});
    if(w.wide && (v14.every(function(x){return x==="QS";})||v14.every(function(x){return x==="rS";}))) bbbb="kétköteges (bifascicularis) blokk gyanúja";
    var t="QRS: "+(w.w==null?"szélesség nincs megadva":(Math.round(w.w*1000)+" ms — "+(w.wide?"széles":"keskeny")))+
          (morf.length?". Morfológia — "+morf.join(", "):"")+
          (E.g.rprog==="van"?". Abnormális R-progresszió.":"")+(bbbb?". "+bbbb:"")+".";
    return {text:t, wide:w.wide, w:w.w};
  }

  /* T lap — nemtől függő amplitúdó-küszöb */
  function tWave(){
    var lim = (E.set.sex==="Férfi")?0.9:0.7, parts=[], abn=[];
    LEADS.forEach(function(L){
      var p=E.lead[L].tPol, a=amp(E.lead[L].tAmp);
      if(!p&&a==null) return;
      var st=(a!=null&&a>lim)?"abnormális":"norm.";
      if(st==="abnormális") abn.push(L);
      parts.push(L+"-ben "+(p||"?")+" "+st);
    });
    return {text: parts.length?("T-hullám (küszöb "+lim+" mV, "+E.set.sex.toLowerCase()+"): "+parts.join(", ")+"."):"", abn:abn};
  }

  /* Vezetési idők: QTc + szárblokk + Sgarbossa */
  function qtc(){
    var qt=dur(E.g.qt), rrBig=n(E.g.rrBig);
    if(qt==null||!rrBig) return null;
    var rr=rrBig*5*sPerSq();               /* nagykocka = 5 kiskocka */
    return {rr:rr, qt:qt,
            bazett: qt/Math.sqrt(rr)*1000,
            fridericia: qt/Math.pow(rr,1/3)*1000,
            framingham: (qt-(0.134*(1-rr)))*1000};
  }
  function blocks(){
    var w=qrsWidth(), q=qWave();
    var noQ = ["I.","V5","V6"].every(function(L){ var a=n(E.lead[L].qDur); return !a; });
    var lbbb = (w.wide&&noQ&&E.g.notchL==="igen")?"komplett bal Tawara-szár-blokk":
               ((noQ&&E.g.notchL==="igen")?"inkomplett bal Tawara-szár-blokk":"bal szárblokk nem igazolható");
    var rbbb = (w.wide&&E.g.notchR==="igen"&&E.g.rsr==="igen")?"komplett jobb Tawara-szár-blokk":
               ((E.g.notchR==="igen"&&E.g.rsr==="igen")?"inkomplett jobb Tawara-szár-blokk":"jobb szárblokk nem igazolható");
    return lbbb+"; "+rbbb+".";
  }
  function sgarbossa(){
    var p=(E.g.sg1==="igen"?5:0)+(E.g.sg2==="igen"?3:0)+(E.g.sg3==="igen"?2:0);
    return {p:p, txt:"Sgarbossa-pontszám: "+p+" — "+(p>=3?"akut myocardialis infarctus valószínű":"akut infarctus a kritériumok alapján nem valószínű")+"."};
  }
  /* S1Q3T3 — a munkafüzet vegyes mértékegységeit egységesítve, mind mV/s */
  function s1q3t3(){
    var s1=amp(E.lead["I."].sAmp), q3=amp(E.lead["III."].qAmp), t3=E.lead["III."].tPol;
    if(s1==null&&q3==null&&!t3) return "";
    var hit=(s1!=null&&s1>0.15)&&(q3!=null&&q3>0.15)&&(t3==="neg");
    return "S1Q3T3: S(I.) "+f2(s1)+" mV, Q(III.) "+f2(q3)+" mV, T(III.) "+(t3||"—")+
           (hit?" — a mintázat teljesül; jobbszívfél-terhelés / tüdőembólia irányában további vizsgálat indokolt.":" — a mintázat nem teljesül.");
  }

  /* ---------------- összegzés ---------------- */
  function summary(){
    var L=[];
    L.push("EKG — 12 ELVEZETÉSES ÉRTÉKELÉS");
    L.push("Beállítás: "+E.set.speed+" mm/s, "+E.set.sens+" mm/mV (1 kiskocka = "+
           Math.round(sPerSq()*1000)+" ms és "+mvPerSq()+" mV)"+(E.set.age?("; kor: "+E.set.age):"")+
           "; nem: "+E.set.sex+(E.set.chest==="igen"?"; mellkasi panasz: igen":""));
    L.push("Tengely: "+axis()+".");
    var r=rhythm(); L.push(r.text);
    var q=qtc();
    if(q) L.push("QT "+Math.round(q.qt*1000)+" ms; QTc — Bazett "+Math.round(q.bazett)+" ms, Fridericia "+
                 Math.round(q.fridericia)+" ms, Framingham "+Math.round(q.framingham)+" ms.");
    [pWave().text, pr().text, qWave().text, rWave().text, sWave().text, qrsWave().text, tWave().text]
      .forEach(function(x){ if(x) L.push(x); });
    L.push("Vezetés: "+blocks());
    L.push(sgarbossa().txt);
    var pe=s1q3t3(); if(pe) L.push(pe);
    if(E.g.st) L.push("ST-szakasz: "+E.g.st+".");
    if(E.g.jp) L.push("J-pont: "+E.g.jp+".");
    if(E.g.u)  L.push("U-hullám: "+E.g.u+".");
    if(E.g.other) L.push("Egyéb: "+E.g.other+".");
    return L.join("\n");
  }

  /* ---------------- UI ---------------- */
  var COLS=[
    ["qrsPol","QRS pol.","sel",POL],
    ["pPol","P pol.","sel",POL],["pDur","P idő","num"],["pAmp","P ampl.","num"],
    ["qDur","Q idő","num"],["qAmp","Q ampl.","num"],
    ["rAmp","R ampl.","num"],["rId","R ID","num"],
    ["sPol","S pol.","sel",POL],["sAmp","S ampl.","num"],
    ["tPol","T pol.","sel",POL],["tAmp","T ampl.","num"],
    ["qrs","QRS morf.","sel",MORPH]
  ];

  function build(host){
    host.innerHTML="";
    host.appendChild(eln("p","ekgnote",
      "Minden numerikus mező <b>kiskockában</b> értendő (a papírsebesség és az érzékenység szerint váltjuk át). "+
      "1 kiskocka = "+Math.round(sPerSq()*1000)+" ms, illetve "+mvPerSq()+" mV. "+
      "Az üresen hagyott mező nem számít bele az értékelésbe."));

    /* beállítások */
    var st=eln("div","ekgset");
    function fld(lab, key, type, opts, obj){
      var l=eln("label",null,"<span>"+lab+"</span>");
      var e=(type==="sel")?document.createElement("select"):document.createElement("input");
      if(type==="sel") opts.forEach(function(o){var op=document.createElement("option");op.value=o;op.textContent=o||"—";e.appendChild(op);});
      else { e.type="text"; e.inputMode="decimal"; }
      e.value=obj[key]||"";
      e.onchange=e.oninput=function(){ obj[key]=e.value; render(); };
      l.appendChild(e); st.appendChild(l); return e;
    }
    fld("Papírsebesség (mm/s)","speed","num",null,E.set);
    fld("Érzékenység (mm/mV)","sens","num",null,E.set);
    fld("Kor","age","num",null,E.set);
    fld("Nem","sex","sel",["Nő","Férfi"],E.set);
    fld("Mellkasi panasz","chest","sel",["nem","igen"],E.set);
    host.appendChild(st);

    /* globális mezők */
    var g=eln("div","ekgset");
    fld("P-hullám","pWave","sel",["","Jelen","Nincs"],E.g);
    fld("Alapvonal","base","sel",["","SR/egyenes","hullámzó","sinusoid","csak R vagy QRS P nélkül"],E.g);
    fld("RR (nagykocka)","rrBig","num",null,E.g);
    fld("PR (kiskocka)","pr","num",null,E.g);
    fld("QRS szélesség (kiskocka)","qrs","num",null,E.g);
    fld("QT (kiskocka)","qt","num",null,E.g);
    fld("Delta-hullám","delta","sel",["","Igen","Nem"],E.g);
    fld("R-tengely","rFix","sel",["","Fix","Változó"],E.g);
    fld("Pace-jel","pace","sel",["","nincs","P előtt","QRS előtt","folyamatos (EKG-független)"],E.g);
    fld("ES / VES / SVES","es","sel",["","nincs","SVES","VES","vegyes"],E.g);
    fld("V5–V6 monomorf R","mono","sel",["","igen","nem"],E.g);
    fld("Abnormális R-progresszió","rprog","sel",["","van","nincs"],E.g);
    fld("Csomós R (bal, I/V5/V6)","notchL","sel",["","igen","nem"],E.g);
    fld("Csomós R (jobb, V1/V2)","notchR","sel",["","igen","nem"],E.g);
    fld("rsR' V1–V2","rsr","sel",["","igen","nem"],E.g);
    fld("Sgarbossa: konkordáns ST-eleváció ≥1 mm","sg1","sel",["","igen","nem"],E.g);
    fld("Sgarbossa: konkordáns ST-depresszió ≥1 mm V1–V3","sg2","sel",["","igen","nem"],E.g);
    fld("Sgarbossa: diszkordáns ST-eleváció ≥5 mm","sg3","sel",["","igen","nem"],E.g);
    fld("ST-szakasz (szöveg)","st","num",null,E.g);
    fld("J-pont (szöveg)","jp","num",null,E.g);
    fld("U-hullám (szöveg)","u","num",null,E.g);
    fld("Egyéb megjegyzés","other","num",null,E.g);
    host.appendChild(g);

    /* elvezetés-táblázat */
    var wrap=eln("div","ekgtblwrap");
    var tb=eln("table","ekgtbl");
    var thead=eln("thead"); var tr=eln("tr");
    tr.appendChild(eln("th",null,"Elvezetés"));
    COLS.forEach(function(c){ tr.appendChild(eln("th",null,c[1])); });
    thead.appendChild(tr); tb.appendChild(thead);
    var tbody=eln("tbody");
    LEADS.forEach(function(L){
      var row=eln("tr"); row.appendChild(eln("td",null,L));
      COLS.forEach(function(c){
        var td=eln("td"); td.setAttribute("data-l",L); td.setAttribute("data-k",c[0]);
        var e;
        if(c[2]==="sel"){ e=document.createElement("select");
          c[3].forEach(function(o){var op=document.createElement("option");op.value=o;op.textContent=o||"—";e.appendChild(op);});
        } else { e=document.createElement("input"); e.type="text"; e.inputMode="decimal"; }
        e.value=E.lead[L][c[0]]||"";
        e.onchange=e.oninput=function(){ E.lead[L][c[0]]=e.value; render(); };
        td.appendChild(e); row.appendChild(td);
      });
      tbody.appendChild(row);
    });
    tb.appendChild(tbody); wrap.appendChild(tb); host.appendChild(wrap);

    var out=eln("div","ekgout"); out.id="ekgOut"; host.appendChild(out);
    host.appendChild(eln("div","ekgblk",
      "<b>Eltérés a munkafüzettől.</b> A portolás közben négy hibát találtam az <code>ekg.xlsx</code>-ben, "+
      "és ezeken a pontokon a modul a <b>helyes</b> számítást használja: (1) a Q lapon a 3–13. sor "+
      "elcsúszott átváltó cellákra hivatkozik (F5, F6, F7…), így az I. elvezetésen kívül minden Q-érték "+
      "hibásan 0; (2) az R lap V1-küszöbe szöveget hasonlít számhoz (<code>\"V1S\"&gt;F8</code>), ezért soha nem jelez; "+
      "(3) a QRS lap A20 cellája <code>#N/A</code>; (4) az S1Q3T3-szabály mV-ot és kiskockát kever. "+
      "A modul minden mértéket a beállított papírsebesség és érzékenység szerint vált át."));
  }

  function render(){
    var out=document.querySelector("#ekgOut"); if(!out) return;
    /* mezők színezése */
    var q=qWave(), r=rWave(), tw=tWave(), s=sWave();
    document.querySelectorAll(".ekgtbl td[data-l]").forEach(function(td){
      td.classList.remove("abn","susp");
      var L=td.getAttribute("data-l"), k=td.getAttribute("data-k");
      if(k==="qDur"||k==="qAmp"){ if(q.patho.indexOf(L)>=0)td.classList.add("abn"); else if(q.susp.indexOf(L)>=0)td.classList.add("susp"); }
      if(k==="tAmp"&&tw.abn.indexOf(L)>=0) td.classList.add("abn");
      if(k==="rAmp"&&r.high.some(function(x){return x.indexOf(L+" ")===0;})) td.classList.add("abn");
      if(k==="sAmp"&&s.high.indexOf(L)>=0) td.classList.add("abn");
    });
    var txt=summary();
    out.textContent=txt;
    var sg=sgarbossa(), pe=s1q3t3();
    if(sg.p>=3||/teljesül;/.test(pe)){
      var w=eln("div","ekgcrit", (sg.p>=3?"▲ Sgarbossa ≥3 — akut infarctus lehetősége. ":"")+
                                 (/teljesül;/.test(pe)?"▲ S1Q3T3 mintázat — tüdőembólia irányában további vizsgálat.":""));
      out.appendChild(w);
    }
    gen();
  }

  function enrichEKG(){
    var out=document.querySelector("#anamOut"); if(!out) return;
    var prev=out.querySelector("#ekgBlock"); if(prev) prev.parentNode.removeChild(prev);
    var any=Object.keys(E.g).some(function(k){return E.g[k];}) ||
            LEADS.some(function(L){ return Object.keys(E.lead[L]).some(function(k){return E.lead[L][k];}); });
    if(!any) return;
    var sp=document.createElement("span"); sp.id="ekgBlock"; sp.textContent="\n"+summary()+"\n";
    out.appendChild(sp);
  }

  function mount(){
    var us=document.querySelector("#usWrap"); if(!us) return false;
    var det=us.closest("details"); if(!det||document.querySelector("#ekgWrap")) return true;
    var sec=document.createElement("details"); sec.className="sec";
    sec.innerHTML='<summary><span class="num">10c</span> EKG — 12 elvezetéses értékelés <span class="chev">›</span></summary>'+
                  '<div class="body"><div id="ekgWrap"></div></div>';
    det.parentNode.insertBefore(sec, det.nextSibling);
    build(sec.querySelector("#ekgWrap"));
    render();
    return true;
  }

  function init(){
    if(!mount()){ setTimeout(init,300); return; }
    if(typeof window.generate==="function"){
      var og=window.generate;
      window.generate=function(){ var r=og.apply(this,arguments); try{enrichEKG();}catch(e){window.__ekgErr=(e&&e.message)||String(e);} return r; };
    }
    E.summary=summary; E.axis=axis; E.qtc=qtc; E.sgarbossa=sgarbossa;
  }
  if(document.readyState==="loading") document.addEventListener("DOMContentLoaded",init);
  else init();
})();
</script>
"""

assert "/* --- v16 --- */" in t
t = t.replace("/* --- v16 --- */", CSS, 1)
t = t.rstrip() + "\n" + MODULE + "\n"
io.open(F, "w", encoding="utf-8").write(t)
print("meret: %d -> %d B (+%d)" % (n0, len(t), len(t) - n0))
print("  OK EKG-modul + CSS")

```

### `ekg_spec.py`

63 sor, 3 KB.

```python
# -*- coding: utf-8 -*-
"""Az ekg.xlsx teljes kiexportalasa: cellaertekek + minden keplet, laponkent."""
import io, os, warnings
import openpyxl
warnings.filterwarnings("ignore")

SRC = r"C:\Users\szili\Downloads\ekg.xlsx"
OUT = r"C:\Users\szili\Documents\claude\apps\anamnezis-asszisztens\EKG_munkafuzet_spec.md"

wv = openpyxl.load_workbook(SRC, data_only=True)   # ertekek
wf = openpyxl.load_workbook(SRC, data_only=False)  # kepletek

L = []
L.append("# EKG munkafüzet — teljes kivonat\n")
L.append("Forrás: `ekg.xlsx`. Ez a fájl a portolás ellenőrizhetőségéért készült: "
         "minden lap minden kitöltött cellája és minden képlete szerepel benne, "
         "hogy a JavaScript-implementáció soronként visszaellenőrizhető legyen.\n")
L.append("| lap | sor | oszlop | képlet | kiszámolt érték |")
L.append("|---|---|---|---|---|")

nf = 0
for wsf in wf.worksheets:
    wsv = wv[wsf.title]
    for row in wsf.iter_rows():
        for c in row:
            if isinstance(c.value, str) and c.value.startswith("="):
                nf += 1
                val = wsv[c.coordinate].value
                val = "" if val is None else str(val).replace("|", "\\|").replace("\n", " ")
                f = c.value.replace("|", "\\|").replace("\n", " ")
                L.append("| %s | %d | %s | `%s` | %s |" % (
                    wsf.title, c.row, c.column_letter, f[:1500], val[:220]))

L.append("\n\n# Laponkénti cellatartalom (nem képlet)\n")
for wsv in wv.worksheets:
    L.append("\n## %s\n" % wsv.title)
    L.append("| cella | tartalom |")
    L.append("|---|---|")
    for row in wsv.iter_rows():
        for c in row:
            if c.value is None:
                continue
            wsf_cell = wf[wsv.title][c.coordinate].value
            if isinstance(wsf_cell, str) and wsf_cell.startswith("="):
                continue
            s = str(c.value).replace("|", "\\|").replace("\n", " ")
            L.append("| %s | %s |" % (c.coordinate, s[:400]))

# adatervenyesites (legordulo listak) - ezek adjak a valaszthato ertekeket
L.append("\n\n# Legördülő listák (adatérvényesítés)\n")
for wsf in wf.worksheets:
    try:
        dvs = list(wsf.data_validations.dataValidation)
    except Exception:
        dvs = []
    for dv in dvs:
        if dv.formula1:
            L.append("- **%s** — %s → `%s`" % (wsf.title, str(dv.sqref), str(dv.formula1)[:300]))

io.open(OUT, "w", encoding="utf-8").write("\n".join(L) + "\n")
print("kesz:", os.path.basename(OUT))
print("keplet:", nf, "| sor a fajlban:", len(L))

```

