# Anamnézis-asszisztens — fejlesztői kézikönyv

**v16 · 2026-09-01**

Offline, egyetlen HTML-fájlba csomagolt, klinikai döntéstámogató betegfelvételi eszköz
reprodukciós és terhesgondozási használatra. Ez a dokumentum azt írja le, hogyan épül fel,
hogyan kell módosítani, és mi az, ami a felszín alatt nem nyilvánvaló.

| | |
|---|---|
| Fájlméret | 1 084 KB |
| Script-blokk | 15 |
| Réteg | 14 |
| Szekció | 20 |
| Nyelv | 6 |
| Beágyazott kód-törzs | 13 |

---

## 1. Mi ez, és mi nem

Egy fájl, semmi build-idejű futtatókörnyezet a felhasználó oldalán, semmi hálózat.
A klinikus megnyitja a HTML-t, kitölti, és kap egy strukturált anamnézist, egy teendőlistát,
kockázatbecslést és kódajánlásokat.

### Kemény megkötések

- **Offline, egyetlen fájl.** Minden CSS, JS és adat beágyazva. Nincs CDN, nincs API-hívás
  futásidőben. Ami külső törzsadat kell, az *build-időben* kerül be.
- **Az adat a böngészőben marad.** Nincs szerver, nincs feltöltés. A mentés `localStorage`-ba
  megy, ami eszközhöz és böngészőhöz kötött.
- **Nem diagnosztikai eszköz.** Döntéstámogató. A kockázatbecslők tájékoztató jellegűek, a
  szűrések érzékenysége egyik állapotban sem 100%.
- **A repó nem tartalmaz beteg-azonosításra alkalmas adatot.** Ez nem udvariassági megjegyzés,
  hanem befogadási feltétel minden commitra.

> **Jogi státusz.** A biobanki hozzájáruló nyilatkozat és a szűrővizsgálati tájékoztató szövege
> **sablon**. Éles használat előtt adatvédelmi tisztviselői, jogi és etikai bizottsági jóváhagyás
> kell. Ez nem fejlesztői döntés.

### Három felvételi útvonal

A fejlécben váltható: **Pre-IVF** (prekoncepcionális), **Terhesgondozás**, **Terhespatológia**.
Ugyanaz az űrlapváz, más alapértelmezésekkel és más teendő-logikával.

---

## 2. Architektúra: a dekorátorlánc

Ez a legfontosabb dolog, amit meg kell érteni az appról. Nincs keretrendszer, nincs komponensfa.
Van egy mag, ami tud egy `window.generate()` függvényt, és minden további funkció egy **önálló
IIFE, ami becsomagolja az előző `generate`-et.**

```javascript
if (typeof window.generate === "function") {
  var og = window.generate;
  window.generate = function () {
    var r = og.apply(this, arguments);   // előző rétegek lefutnak
    try { enrichEKG(); }                 // ez a réteg hozzáfűzi a magáét
    catch (e) { window.__ekgErr = e.message; }
    return r;
  };
}
```

Tizennégy réteg csinálja ugyanezt. A kimenet így additív: a mag legenerálja a narratív
anamnézist, majd sorban ráépül a kockázati blokk, a BNO-kódok, a családfa, az ultrahang-lelet és
az EKG-értékelés.

```
űrlapmezők ──▶ generate() ──▶ v4  EESZT-rizikó          ──▶ #anamOut
   (DOM)        mag: narratíva    v6  enrich: kód + prevenció   + teendőlista
                + teendők         v9  narratíva + PHQ-2
                                  v12–v13 kalkulátorok
                                  v15 BNO minden mezőre
                                  i18n futásidejű fordítás
                                  v16/2 családfa
                                  v16/4 ultrahang
                                  v16/6 EKG
```

### Amit ez az architektúra megkövetel

- **A sorrend jelentéses.** Aki később fut, az látja a korábbiak kimenetét, és felül tudja írni.
  Az i18n réteg például szándékosan a klinikai rétegek után jön, hogy a dinamikusan generált
  szöveget is fordítsa.
- **Minden réteg védve fut.** Mindegyik `try/catch`-ben, és a hibát egy saját globálisba írja
  (`window.__ekgErr`, `__usErr`, `__pedErr`…). Egy hibás réteg nem viszi magával az egész
  kimenetet — viszont *némán* hal el. Hibakeresésnél ezeket a globálisokat kell megnézni először.
- **A rétegek nem függenek egymás belső állapotától**, csak a DOM-tól és a saját globálisuktól.
  Ezért lehet egy réteget kivenni a build-láncból anélkül, hogy a többi elszállna.

> **Miért így.** Mert a fájl egyetlen artefaktum, amit orvosok kapnak meg e-mailben, és mert
> minden új funkció egy külön, visszavonható build-lépésként született. Az ár: a
> `window.generate` tizennégyszeresen becsomagolt, és a hívási verem hibakeresésnél mély.

---

## 3. Rétegtérkép

A sorszámok a fejlesztési sorrendet jelölik, és a fájlban is ebben a sorrendben állnak.
A sortartományok a v16-os fájlra vonatkoznak.

| Réteg | Sorok | Mit ad hozzá |
|---|---|---|
| dictation | 543–585 | Beszédfelismerés (Web Speech API), offline; kampó hosztolt Whisperhez |
| mag + v2 | 589–1529 | Az űrlap, az állapot, a `generate()`, a teendőmotor. Ezen belül a v2: műtétek, szupplementáció, laborbevitel, PUPHA-gyógyszerkereső, kockázatbecslés |
| v3 | 1361–1490 | Kalkulátorok, több eset mentése/betöltése, exportok |
| v4 | 1491–1529 | Hivatalos EESZT várandós-rizikótényezők külön szekcióként |
| v6 | 1532–1615 | `enrich`: kockázat, kódok, ajánlások, prevenció, nyilatkozatok |
| v9 | 1683–1926 | Narratív összefoglaló, gesztációs kor szerinti időzítés, PHQ-2, aktív allergia |
| v12 | 1929–2138 | Automatikus kalkulátorok és beágyazott külső kalkulátorok |
| v13 | 2141–2388 | Kibővített natív kalkulátorok |
| v15 | 2391–2556 | EESZT törzsek, BNO-ajánlás *minden* mezőre, teendő-indoklás és betegtájékoztató tudásbázis |
| i18n | 2558–2663 | Futásidejű fordítóréteg. Klinikai logikát nem módosít |
| v16/2 | 2666–2928 | Dinamikus családfa (pedigré) rokononként, az adat forrásával és dokumentáltságával |
| v16/3 | 2931–3044 | Kalkulátor-bemenetek áthelyezése a bal oldalra. Az azonosítók változatlanok |
| v16/4 | 3047–3512 | Ultrahang-modul: vizitsoros biometria, páros szervek, SVG-görbék, normogramok |
| v16/6 | 3514–3899 | EKG-modul, 296 munkafüzet-képlet portolva |

> **Ami nincs a listán.** A `v16/5` (reprodukciós bővítés) és a `v16` első szakasza nem külön
> IIFE — ezek a meglévő szekciókat és a `peRisk` logikát módosítják a helyükön. A build-láncban
> viszont önálló lépések.

---

## 4. Beágyazott adatrétegek

Az offline megkötés ára: minden törzsadat a fájlban van. Ez adja az 1 MB nagy részét.
Egyik sem futásidőben töltődik — mind build-időben kerül be.

### EESZT kódtörzsek — `window.__EESZT_EMBED`

| Kulcs | Tétel | Mire szolgál |
|---|---:|---|
| `atc` | 5 592 | Hatóanyag-besorolás a gyógyszerkeresőhöz |
| `irszmap` | 3 294 | Irányítószám → település automatikus kitöltés |
| `bnoObs` | 1 922 | BNO-kódajánlás, labor-vezérelt súlyossággal |
| `feor` | 1 217 | Foglalkozás-besorolás |
| `oenoObs` | 650 | Beavatkozás-kódok |
| `orszag` | 251 | Országkódok |
| `xwalk` | 40 | Kereszthivatkozás törzsek között |
| `small` | 11 | Kis kódlisták (rizikótényezők, eredményközlés) |

> **Ez megoldódott.** Korábban nem volt valódi OENO-tábla, és a beavatkozások „kód megadandó"
> jelöléssel jelentek meg. A v15-ös EESZT-ingest óta **650 valódi OENO-kód** van beágyazva.
> A régi megkerülő megoldást nem kell visszaírni.

### Gyógyszer-átalakítási szabályok — `MEDDB`

22 szabály, mindegyik egy reguláris kifejezéssel illeszkedik a beírt gyógyszernévre, és
terhességi átalakítási javaslatot ad. A hozzáadott hatóanyag magát az átalakítás-motort is
triggereli. A `matchMed()` a belépési pont.

### Fordítás — `DICT`

**316 kulcs**, hat nyelv (HU alap + EN/FR/DE/ES/ZH). Futásidejű, kulcs-alapú csere, ≥7 karakteres
kulcsokra kis/nagybetű-független illesztéssel. A beteg szabadszövegét és a bevitt értékeket *nem*
fordítja. Gépi fordítás, disclaimerrel.

> **Ami HU-ban maradt.** A hosszú MEDDB-üzenetek (~22) és a teendőlista-mondatok egy része nincs
> a szótárban — ezek nyelvváltás után is magyarul jelennek meg. Ez tudatos: a klinikai mondatok
> gépi fordítása kockázatosabb, mint a hiányuk.

---

## 5. Modulok közelről

### Kockázatbecslők

Három külön logika, szándékosan nem összemosva:

- **Triszómia** — FMF a priori (Snijders), gesztációs kor szerinti táblából.
- **Preeclampsia és GDM** — NICE-besorolás (magas / közepes / alacsony), a besorolást kiváltó
  tényezők felsorolásával, aszpirin- illetve OGTT-javallattal.
- **FMF-elvű, markerekkel** — ha a MAP / UtA-PI / PlGF MoM mezők ki vannak töltve, közelítő
  log-odds számítás fut. Kiírja, hogy nem a hivatalos FMF-kalkulátor.

A vetélés / koraszülés / halvaszületés becslés epidemiológiai, tájékoztató, nem validált — és ezt
a felület ki is mondja.

### Kalkulátorok

EDD és gesztációs kor LMP-ből · IOM súlygyarapodás · MAP · kreatinin-clearance (Cockcroft–Gault,
elhízás-figyelmeztetéssel) · HbA1c ↔ eAG · CARPREG II · Bishop-score · BMI · testfelület
(Mosteller).

A v16/3 áthelyezte a bemeneteiket a bal oldalra — **az azonosítók változatlanok maradtak**, ezért
minden kalkulátor-logika érintetlen. Ha új mezőt teszel be, tartsd ezt a szabályt.

### Ultrahang-modul (v16/4)

Vizitsoros biometria dátummal és terhességi héttel, 16 egyszeres és 6 páros paraméter,
SVG-görbék, páros szervek jobb/bal egy ábrán. Publikációból tölthető normogram táblázatos és
képlet módban; percentilis, z-érték és P10/P90 kockázatjelzés. A betöltött normogramok
`localStorage`-ba mentődnek.

### EKG-modul (v16/6) — tesztelve

Az `ekg.xlsx` munkafüzet 296 képletének portja. A modul a **10c** szekcióként épül be, a
`mount()` a `#usWrap`-hoz horgonyoz — vagyis *az ultrahang-modul után*, és ha az nincs kész,
300 ms-onként újrapróbálkozik. API: `window.__ekg` (`axis`, `qtc`, `sgarbossa`, `summary`).

#### Négy hiba a munkafüzetben, amit a modul szándékosan másképp csinál

| # | Hol | Mi a hiba |
|---|---|---|
| 1 | `Q` lap, 3–13. sor | Elcsúszott átváltó-hivatkozás (`G3=F5*E3`), pedig csak `F3` és `F4` létezik. Az I. elvezetésen kívül minden Q-érték 0. |
| 2 | `R!G8` | `IF("V1S">F8,…)` — szöveget hasonlít számhoz, és nincs `else` ág. A V1 R-amplitúdó küszöbe soha nem jelez. |
| 3 | `QRS!A20` | `#N/A` |
| 4 | `EKG!I29` | S1Q3T3: `S!G2` mV-ban, `Q!E4` kiskockában — a küszöbök nem összemérhetők. |

A modul minden mértéket a beállított papírsebesség és érzékenység szerint vált át, és a felületen
kiírja, hogy eltér a munkafüzettől.

#### A munkafüzet saját tesztesete visszaellenőrizve (2026-09-01)

| Munkafüzet | Modul | |
|---|---|---|
| `Tengely!B5` → extrém jobb tengely | extrém jobb tengely | egyezik |
| `ritmus!D4` = 150 → tachycardia. | tachycardia, 150/perc | egyezik |
| `QRS!F2` → QRS 0,16 sec, Széles QRS | QRS: 160 ms — széles | egyezik |
| `ritmus!D2` → arythmia??? vagy P kitöltés hiánya | arrhythmia? vagy hiányzó P-adat a II.-ben | egyezik |
| `EKG!B18` → Q norm. | Q-hullám: normál | egyezik |
| `EKG!B29` → S1: neg 1.2mV | S-hullám: I.-ben neg (1.2 mV) | egyezik |
| `EKG!I29` → Pulmonális Embólia gyanúja!!! | S1Q3T3 teljesül, PE irányában vizsgálat | egyezik, **helyes mértékegységgel** |

A 4. hibánál a következtetés ugyanaz, de a modul Q(III.)-at helyesen 0,3 mV-ként írja ki a
munkafüzet „3"-a helyett — más bemenetnél ezért el fog térni, és ez a kívánt viselkedés.

---

## 6. Build-lánc

> **Az egyetlen szabály: a v16-os HTML-t soha ne szerkeszd kézzel.** Az a build kimenete. Minden
> módosítás egy build-szkriptbe megy, és a lánc újrafut a v15-ből. Kézi javítás után a következő
> build csendben visszaírja.

A szkriptek **sorrendben, a v15-ből** építik újra a v16-ot. Mindig az egészet futtasd, mert
mindegyik az előző kimenetére épül.

```bash
cd "C:/Users/szili/Documents/claude/apps/anamnezis-asszisztens/build"
PY="C:/Users/szili/.claude/.venv/Scripts/python.exe"
PYTHONUTF8=1 PYTHONIOENCODING=utf-8 "$PY" build_v16.py && \
PYTHONUTF8=1 PYTHONIOENCODING=utf-8 "$PY" build_v16_part2.py && \
PYTHONUTF8=1 PYTHONIOENCODING=utf-8 "$PY" build_v16_part3.py && \
PYTHONUTF8=1 PYTHONIOENCODING=utf-8 "$PY" build_v16_part4.py && \
PYTHONUTF8=1 PYTHONIOENCODING=utf-8 "$PY" build_v16_part5.py && \
PYTHONUTF8=1 PYTHONIOENCODING=utf-8 "$PY" build_v16_part6.py
```

| Szkript | Bemenet → kimenet | Mit tesz hozzá |
|---|---|---|
| `build_v16.py` | v15 → v16 | Iker → `peRisk`, tisztázatlan diagnózisú családi tételek, „Nem tudom" harmadik állapot, dinamikus családfa |
| `…_part2.py` | v16 helyben | Endokrin anamnézis terhességi vonallal, biobanki nyilatkozat, kalkulátor- és UH-tájékoztató |
| `…_part3.py` | v16 helyben | Kalkulátor-bemenetek a bal oldalra |
| `…_part4.py` | v16 helyben | Ultrahang-modul |
| `…_part5.py` | v16 helyben | Reprodukciós bővítés + GPA-számlálók |
| `…_part6.py` | v16 helyben | EKG-modul |
| `ekg_spec.py` | ekg.xlsx → .md | A munkafüzet teljes kiexportálása cellánként és képletenként |

A part2–part6 **helyben írja felül** a v16-ot. Készíts másolatot futtatás előtt.

### Törzsadat frissítése

Az EESZT kódtörzsek havonta frissülnek, és letölthető törzsadatként érhetők el — nem böngészőből
hívható API. Az útvonal ezért mindig ugyanaz: **letöltés → konverter → beágyazott JSON → app
újraépítés.** Ugyanez igaz a PUPHA gyógyszertörzsre. Az `eeszt_ingest.py` pipe-tagolt,
UTF-8/BOM-toleráns bemenetet vár.

---

## 7. Konvenciók és buktatók

Ezek mind valódi, egyszer már megfizetett hibák. Mindegyik órákat vitt el, mire kiderült.

### Injektálás: a fő scripten *belülre*

Új kódot a fő script `</script>`-je **elé** kell beszúrni, nem külön script-blokkba. Egy
különálló blokk nem látja a `const $` helpert, és néma `ReferenceError`-ral hal el. Kivétel, ha a
modul kifejezetten önálló IIFE, és mindent maga hoz létre — így csinálja az ultrahang- és az
EKG-modul.

### Python-escape elrontja a JS-regexet

Ha a base runtime template-et a forrásszövegből extrahálod és Python-oldalon escape-eled, a JS
`esc()` reguláris kifejezése elromlik: a nyitó zárójel nem escape-elődik, és „Unterminated group"
hibát kapsz. **A feloldott sztringből dolgozz, és a szótárat regexszel cseréld** — ne a forrást
alakítsd.

### Windows: UTF-8 mód kötelező

A build-szkriptek és a memo-guard eszközei `write_text()`-et hívnak encoding nélkül, így
Windowson cp1250-re esnek vissza, és `UnicodeEncodeError`-ral elszállnak az első nem-latin2
karakteren. Ezért van minden hívás előtt `PYTHONUTF8=1 PYTHONIOENCODING=utf-8`. Tartós javítás:
`encoding="utf-8"` minden fájlműveletbe.

### Build után kemény újratöltés

A böngésző a régi fájlt szolgálja ki. Cache-törő query paraméter a legegyszerűbb (`?v=2`).
Enélkül azt hiszed, a modulod nem épült be — pedig csak nem látod.

### A csukott `<details>` üres `innerText`-et ad

Rejtett elem `innerText`-je üres sztring, akkor is, ha a tartalom megvan. Teszteléskor ez úgy néz
ki, mintha a render nem futott volna le. Nézd az `innerHTML`-t, vagy nyisd ki a szekciót.

### Azonosítók megőrzése

Ha mezőt mozgatsz a felületen, **tartsd meg az `id`-t**. A kalkulátorok, a kockázatmotorok és az
exportok mind azonosító alapján olvasnak. A v16/3 teljes átrendezése pontosan azért volt
kockázatmentes, mert egyetlen azonosító sem változott.

---

## 8. Tesztelés

### Három szint

1. **jsdom-smoke.** Betölthető-e a fájl, lefut-e a `generate()` hiba nélkül. Ez fogja meg a
   szintaktikai és a scope-hibákat.
2. **Böngésző.** Konzolhibák, a modulok tényleges beépülése, a `window.__*Err` globálisok
   ellenőrzése. Ezek nélkül a néma `try/catch`-ek elrejtik a hibát.
3. **Referencia-visszaellenőrzés.** Ahol a logika külső forrásból származik, ott legyen egy ismert
   bemenet és egy ismert kimenet. Az EKG-modulnál ez az `EKG_munkafuzet_spec.md`: minden képlet
   mellett ott a munkafüzet saját eredménye, tehát soronként összevethető.

### Hibakeresési sorrend

Ha egy modul „nem csinál semmit":

1. tényleg az új fájlt látod? — cache
2. `window.__<modul>Err` — elhasalt a réteg?
3. létrejött-e a horgony, amire a `mount()` vár?
4. nyitva van-e a `<details>`, amiből olvasol?

---

## 9. Ismert hibák, nyitott feladatok

### Kódszintű

| Tétel | Állapot | Megjegyzés |
|---|---|---|
| A lead-objektumokból hiányzik a `qrsPol` kulcs az inicializálásnál | hiba | Az `axis()` ezt olvassa. Működik, mert az értékadás létrehozza, de a többivel együtt fel kell venni |
| Duplikált mezők: `c_hr` / `k_hr2`, `k_ba` / `lb_bile`, `k_sbp` / `#bp` | nyitott | Pulzus, epesav, szisztolés vérnyomás kétszer vehető fel. El kell dönteni, melyik a kanonikus |
| Legördülők értékkészlete | nyitott | Az openpyxl nem tudta kiolvasni a forrást (mind `0`-ként exportálódott); a választható értékek a képletek összehasonlításaiból lettek levezetve. Egyeztetendő |

### Funkcionális

- **Foglalkozás-egészségügyi lap.** Hiányzó elemek: beteg-oldali anamnézis tételek és orvosi
  fizikális státusz modul — audiogram, légzésfunkció, visus, neurológiai státusz, alkalmassági
  vélemény.
- **A kézirat supplementuma elavult.** Még a régi, 45 kB-os `anamnezis_app.html`-re hivatkozik,
  nem a v16-ra.
- **Az `ekg.xlsx` négy hibája** az eredeti munkafüzetben is javítandó, ha azt is használják.

### Infrastruktúra

- **Szinkron.** A v16, a build-lánc és az EKG-spec csak a `Documents\claude` alatt van; a
  `C:\claude\04_apps` a v15-nél áll.
- **Jóváhagyás.** A biobanki nyilatkozat és az ultrahang-tájékoztató adatvédelmi, jogi és etikai
  bizottsági jóváhagyása.

### Tervezett irány

Hosztolt változat egyszerű adatbázis-tárolással, a jelenlegi egyfájlos verzió megtartása mellett.
Ez az első pont, ahol a „minden a böngészőben marad" megkötés megszűnik — vagyis ahol az
adatvédelmi tervet *előbb* kell megírni, mint a kódot.

---

## 10. Referencia

### Globális objektumok

| Globális | Modul | Tartalom |
|---|---|---|
| `__ekg` | EKG | `set`, `lead`, `g` + `axis()`, `qtc()`, `sgarbossa()`, `summary()` |
| `__us` | Ultrahang | Modul-API |
| `__usState` | Ultrahang | Vizitsoros mérési állapot |
| `__ped` | Családfa | Modul-API |
| `__pedState` | Családfa | Rokononkénti adatok |
| `__enrich` | v6 | Kód- és ajánlásgenerálás |
| `__mig` | v16/3 | Mezőáthelyezés |
| `__dictation` | dictation | Beszédfelismerés |
| `__EESZT_EMBED` | v15 | Beágyazott kódtörzsek |
| `__*Err` | mind | Az adott réteg elkapott hibája — **hibakeresésnél ezt nézd először** |

### localStorage-kulcsok

| Kulcs | Tartalom |
|---|---|
| `anam_cases` | Mentett esetek (több eset, helyi tárolás) |
| `anam_lang` | Kiválasztott nyelv |
| `LSK` | Betöltött ultrahang-normogramok |

### Exportok

- **FHIR QuestionnaireResponse** — indikatív SNOMED/LOINC kódokkal, „validálandó" jelöléssel.
- **PDF / nyomtatás** — `window.print()`, külön print-CSS-sel.
- **.txt** és vágólapra másolás — a strukturált anamnézis és a teendőlista külön.

### Fájlok

| Fájl | Mi ez |
|---|---|
| `Anamnezis_asszisztens_v16_tobbnyelvu.html` | Az aktuális, tesztelt változat |
| `Anamnezis_asszisztens_v15_tobbnyelvu.html` | A v16 kiindulópontja — **ne módosítsd** |
| `build/` | A v15 → v16 build-lánc, újrafuttatható |
| `EKG_munkafuzet_spec.md` | Az `ekg.xlsx` teljes kivonata, 296 képlet |
| `FEJLESZTOI_KEZIKONYV.md` | Ez a dokumentum |
| `Anamnezis_v16_kodkonyv.md` | A teljes forrás rétegenként tagolva |
| `ALLAPOT.md` | Hol tart a munka, mi a következő lépés |
